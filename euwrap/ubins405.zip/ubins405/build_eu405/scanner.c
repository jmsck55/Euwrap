// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _60set_qualified_fwd(int _fwd_23599)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_23599)) {
        _1 = (long)(DBL_PTR(_fwd_23599)->dbl);
        DeRefDS(_fwd_23599);
        _fwd_23599 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23596 = _fwd_23599;

    /** end procedure*/
    return;
    ;
}


int _60get_qualified_fwd()
{
    int _fwd_23602 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fwd = qualified_fwd*/
    _fwd_23602 = _60qualified_fwd_23596;

    /** 	set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23596 = -1;

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** 	return fwd*/
    return _fwd_23602;
    ;
}


void _60InitLex()
{
    int _13582 = NOVALUE;
    int _13581 = NOVALUE;
    int _13580 = NOVALUE;
    int _13578 = NOVALUE;
    int _13577 = NOVALUE;
    int _13576 = NOVALUE;
    int _13575 = NOVALUE;
    int _0, _1, _2;
    

    /** 	gline_number = 0*/
    _12gline_number_11687 = 0;

    /** 	line_number = 0*/
    _12line_number_11683 = 0;

    /** 	IncludeStk = {}*/
    RefDS(_5);
    DeRef(_60IncludeStk_23573);
    _60IncludeStk_23573 = _5;

    /** 	char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_60char_class_23571);
    _60char_class_23571 = Repeat(-20, 255);

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23571;
    AssignSlice(48, 57, -7);

    /** 	char_class['_']      = DIGIT*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = -7;

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23571;
    AssignSlice(97, 122, -2);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23571;
    AssignSlice(65, 90, -2);

    /** 	char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _13575 = 129;
    _13576 = 152;
    assign_slice_seq = (s1_ptr *)&_60char_class_23571;
    AssignSlice(129, 152, -10);
    _13575 = NOVALUE;
    _13576 = NOVALUE;

    /** 	char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _13577 = 171;
    _13578 = 234;
    assign_slice_seq = (s1_ptr *)&_60char_class_23571;
    AssignSlice(171, 234, -9);
    _13577 = NOVALUE;
    _13578 = NOVALUE;

    /** 	char_class[' '] = BLANK*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = -8;

    /** 	char_class['\t'] = BLANK*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = -8;

    /** 	char_class['+'] = PLUS*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 43);
    *(int *)_2 = 11;

    /** 	char_class['-'] = MINUS*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 10;

    /** 	char_class['*'] = res:MULTIPLY*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 42);
    *(int *)_2 = 13;

    /** 	char_class['/'] = res:DIVIDE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 14;

    /** 	char_class['='] = EQUALS*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 61);
    *(int *)_2 = 3;

    /** 	char_class['<'] = LESS*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 60);
    *(int *)_2 = 1;

    /** 	char_class['>'] = GREATER*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 62);
    *(int *)_2 = 6;

    /** 	char_class['\''] = SINGLE_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = -5;

    /** 	char_class['"'] = DOUBLE_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = -4;

    /** 	char_class['`'] = BACK_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = -12;

    /** 	char_class['.'] = DOT*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 46);
    *(int *)_2 = -3;

    /** 	char_class[':'] = COLON*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 58);
    *(int *)_2 = -23;

    /** 	char_class['\r'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = -6;

    /** 	char_class['\n'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = -6;

    /** 	char_class['!'] = BANG*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 33);
    *(int *)_2 = -1;

    /** 	char_class['{'] = LEFT_BRACE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = -24;

    /** 	char_class['}'] = RIGHT_BRACE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = -25;

    /** 	char_class['('] = LEFT_ROUND*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = -26;

    /** 	char_class[')'] = RIGHT_ROUND*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = -27;

    /** 	char_class['['] = LEFT_SQUARE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = -28;

    /** 	char_class[']'] = RIGHT_SQUARE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = -29;

    /** 	char_class['$'] = DOLLAR*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = -22;

    /** 	char_class[','] = COMMA*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 44);
    *(int *)_2 = -30;

    /** 	char_class['&'] = res:CONCAT*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 38);
    *(int *)_2 = 15;

    /** 	char_class['?'] = QUESTION_MARK*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 63);
    *(int *)_2 = -31;

    /** 	char_class['#'] = NUMBER_SIGN*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 35);
    *(int *)_2 = -11;

    /** 	char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _2 = (int)(((s1_ptr)_2)->base + 26);
    *(int *)_2 = -21;

    /** 	id_char = repeat(FALSE, 255)*/
    DeRefi(_60id_char_23572);
    _60id_char_23572 = Repeat(_9FALSE_429, 255);

    /** 	for i = 1 to 255 do*/
    {
        int _i_23650;
        _i_23650 = 1;
L1: 
        if (_i_23650 > 255){
            goto L2; // [407] 456
        }

        /** 		if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (int)SEQ_PTR(_60char_class_23571);
        _13580 = (int)*(((s1_ptr)_2)->base + _i_23650);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = -7;
        _13581 = MAKE_SEQ(_1);
        _13582 = find_from(_13580, _13581, 1);
        _13580 = NOVALUE;
        DeRefDS(_13581);
        _13581 = NOVALUE;
        if (_13582 == 0)
        {
            _13582 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _13582 = NOVALUE;
        }

        /** 			id_char[i] = TRUE*/
        _2 = (int)SEQ_PTR(_60id_char_23572);
        _2 = (int)(((s1_ptr)_2)->base + _i_23650);
        *(int *)_2 = _9TRUE_431;
L3: 

        /** 	end for*/
        _i_23650 = _i_23650 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** 	default_namespaces = {0}*/
    _0 = _60default_namespaces_23570;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _60default_namespaces_23570 = MAKE_SEQ(_1);
    DeRef(_0);

    /** end procedure*/
    return;
    ;
}


void _60ResetTP()
{
    int _0, _1, _2;
    

    /** 	OpTrace = FALSE*/
    _12OpTrace_11752 = _9FALSE_429;

    /** 	OpProfileStatement = FALSE*/
    _12OpProfileStatement_11754 = _9FALSE_429;

    /** 	OpProfileTime = FALSE*/
    _12OpProfileTime_11755 = _9FALSE_429;

    /** 	AnyStatementProfile = FALSE*/
    _13AnyStatementProfile_10661 = _9FALSE_429;

    /** 	AnyTimeProfile = FALSE*/
    _13AnyTimeProfile_10660 = _9FALSE_429;

    /** end procedure*/
    return;
    ;
}


int _60pack_source(int _src_23680)
{
    int _start_23681 = NOVALUE;
    int _13606 = NOVALUE;
    int _13605 = NOVALUE;
    int _13604 = NOVALUE;
    int _13603 = NOVALUE;
    int _13601 = NOVALUE;
    int _13599 = NOVALUE;
    int _13598 = NOVALUE;
    int _13597 = NOVALUE;
    int _13593 = NOVALUE;
    int _13591 = NOVALUE;
    int _13590 = NOVALUE;
    int _13587 = NOVALUE;
    int _13586 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(src, 0) then*/
    if (_src_23680 == 0)
    _13586 = 1;
    else if (IS_ATOM_INT(_src_23680) && IS_ATOM_INT(0))
    _13586 = 0;
    else
    _13586 = (compare(_src_23680, 0) == 0);
    if (_13586 == 0)
    {
        _13586 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _13586 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_src_23680);
    return 0;
L1: 

    /** 	if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_23680)){
            _13587 = SEQ_PTR(_src_23680)->length;
    }
    else {
        _13587 = 1;
    }
    if (_13587 < 10000)
    goto L2; // [22] 34

    /** 		src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_23680;
    RHS_Slice(_src_23680, 1, 100);
L2: 

    /** 	if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_23680)){
            _13590 = SEQ_PTR(_src_23680)->length;
    }
    else {
        _13590 = 1;
    }
    _13591 = _60current_source_next_23676 + _13590;
    if ((long)((unsigned long)_13591 + (unsigned long)HIGH_BITS) >= 0) 
    _13591 = NewDouble((double)_13591);
    _13590 = NOVALUE;
    if (binary_op_a(LESS, _13591, 10000)){
        DeRef(_13591);
        _13591 = NOVALUE;
        goto L3; // [45] 94
    }
    DeRef(_13591);
    _13591 = NOVALUE;

    /** 		current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _13593 = 10400;
    _0 = _4allocate(10400, 0);
    DeRef(_60current_source_23675);
    _60current_source_23675 = _0;
    _13593 = NOVALUE;

    /** 		if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _60current_source_23675, 0)){
        goto L4; // [64] 76
    }

    /** 			CompileErr(123)*/
    RefDS(_21829);
    _43CompileErr(123, _21829, 0);
L4: 

    /** 		all_source = append(all_source, current_source)*/
    Ref(_60current_source_23675);
    Append(&_13all_source_10662, _13all_source_10662, _60current_source_23675);

    /** 		current_source_next = 1*/
    _60current_source_next_23676 = 1;
L3: 

    /** 	start = current_source_next*/
    _start_23681 = _60current_source_next_23676;

    /** 	poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_60current_source_23675)) {
        _13597 = _60current_source_23675 + _60current_source_next_23676;
        if ((long)((unsigned long)_13597 + (unsigned long)HIGH_BITS) >= 0) 
        _13597 = NewDouble((double)_13597);
    }
    else {
        _13597 = NewDouble(DBL_PTR(_60current_source_23675)->dbl + (double)_60current_source_next_23676);
    }
    if (IS_ATOM_INT(_13597)){
        poke_addr = (unsigned char *)_13597;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13597)->dbl);
    }
    if (IS_ATOM_INT(_src_23680)) {
        *poke_addr = (unsigned char)_src_23680;
    }
    else if (IS_ATOM(_src_23680)) {
        *poke_addr = (signed char)DBL_PTR(_src_23680)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_src_23680);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13597);
    _13597 = NOVALUE;

    /** 	current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_23680)){
            _13598 = SEQ_PTR(_src_23680)->length;
    }
    else {
        _13598 = 1;
    }
    _13599 = _13598 - 1;
    _13598 = NOVALUE;
    _60current_source_next_23676 = _60current_source_next_23676 + _13599;
    _13599 = NOVALUE;

    /** 	poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_60current_source_23675)) {
        _13601 = _60current_source_23675 + _60current_source_next_23676;
        if ((long)((unsigned long)_13601 + (unsigned long)HIGH_BITS) >= 0) 
        _13601 = NewDouble((double)_13601);
    }
    else {
        _13601 = NewDouble(DBL_PTR(_60current_source_23675)->dbl + (double)_60current_source_next_23676);
    }
    if (IS_ATOM_INT(_13601)){
        poke_addr = (unsigned char *)_13601;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13601)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13601);
    _13601 = NOVALUE;

    /** 	current_source_next += 1*/
    _60current_source_next_23676 = _60current_source_next_23676 + 1;

    /** 	return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_13all_source_10662)){
            _13603 = SEQ_PTR(_13all_source_10662)->length;
    }
    else {
        _13603 = 1;
    }
    _13604 = _13603 - 1;
    _13603 = NOVALUE;
    if (_13604 <= INT15)
    _13605 = 10000 * _13604;
    else
    _13605 = NewDouble(10000 * (double)_13604);
    _13604 = NOVALUE;
    if (IS_ATOM_INT(_13605)) {
        _13606 = _start_23681 + _13605;
        if ((long)((unsigned long)_13606 + (unsigned long)HIGH_BITS) >= 0) 
        _13606 = NewDouble((double)_13606);
    }
    else {
        _13606 = NewDouble((double)_start_23681 + DBL_PTR(_13605)->dbl);
    }
    DeRef(_13605);
    _13605 = NOVALUE;
    DeRef(_src_23680);
    return _13606;
    ;
}


int _60fetch_line(int _start_23714)
{
    int _line_23715 = NOVALUE;
    int _memdata_23716 = NOVALUE;
    int _c_23717 = NOVALUE;
    int _chunk_23718 = NOVALUE;
    int _p_23719 = NOVALUE;
    int _n_23720 = NOVALUE;
    int _m_23721 = NOVALUE;
    int _13631 = NOVALUE;
    int _13630 = NOVALUE;
    int _13628 = NOVALUE;
    int _13626 = NOVALUE;
    int _13620 = NOVALUE;
    int _13618 = NOVALUE;
    int _13614 = NOVALUE;
    int _13612 = NOVALUE;
    int _13609 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_23714)) {
        _1 = (long)(DBL_PTR(_start_23714)->dbl);
        DeRefDS(_start_23714);
        _start_23714 = _1;
    }

    /** 	if start = 0 then*/
    if (_start_23714 != 0)
    goto L1; // [5] 16

    /** 		return ""*/
    RefDS(_5);
    DeRef(_line_23715);
    DeRefi(_memdata_23716);
    DeRef(_p_23719);
    return _5;
L1: 

    /** 	line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_23715);
    _line_23715 = Repeat(0, 400);

    /** 	n = 0*/
    _n_23720 = 0;

    /** 	chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_23714 >= 0) {
        _13609 = _start_23714 / 10000;
    }
    else {
        temp_dbl = floor((double)_start_23714 / (double)10000);
        _13609 = (long)temp_dbl;
    }
    _chunk_23718 = _13609 + 1;
    _13609 = NOVALUE;

    /** 	start = remainder(start, SOURCE_CHUNK)*/
    _start_23714 = (_start_23714 % 10000);

    /** 	p = all_source[chunk] + start*/
    _2 = (int)SEQ_PTR(_13all_source_10662);
    _13612 = (int)*(((s1_ptr)_2)->base + _chunk_23718);
    DeRef(_p_23719);
    if (IS_ATOM_INT(_13612)) {
        _p_23719 = _13612 + _start_23714;
        if ((long)((unsigned long)_p_23719 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23719 = NewDouble((double)_p_23719);
    }
    else {
        _p_23719 = NewDouble(DBL_PTR(_13612)->dbl + (double)_start_23714);
    }
    _13612 = NOVALUE;

    /** 	memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_23719);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_23719;
    ((int *)_2)[2] = 400;
    _13614 = MAKE_SEQ(_1);
    DeRefi(_memdata_23716);
    _1 = (int)SEQ_PTR(_13614);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_23716 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13614);
    _13614 = NOVALUE;

    /** 	p += LINE_BUFLEN*/
    _0 = _p_23719;
    if (IS_ATOM_INT(_p_23719)) {
        _p_23719 = _p_23719 + 400;
        if ((long)((unsigned long)_p_23719 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23719 = NewDouble((double)_p_23719);
    }
    else {
        _p_23719 = NewDouble(DBL_PTR(_p_23719)->dbl + (double)400);
    }
    DeRef(_0);

    /** 	m = 0*/
    _m_23721 = 0;

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_431 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** 		m += 1*/
    _m_23721 = _m_23721 + 1;

    /** 		if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_23716)){
            _13618 = SEQ_PTR(_memdata_23716)->length;
    }
    else {
        _13618 = 1;
    }
    if (_m_23721 <= _13618)
    goto L4; // [98] 125

    /** 			memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_23719);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_23719;
    ((int *)_2)[2] = 400;
    _13620 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_23716);
    _1 = (int)SEQ_PTR(_13620);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_23716 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13620);
    _13620 = NOVALUE;

    /** 			p += LINE_BUFLEN*/
    _0 = _p_23719;
    if (IS_ATOM_INT(_p_23719)) {
        _p_23719 = _p_23719 + 400;
        if ((long)((unsigned long)_p_23719 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23719 = NewDouble((double)_p_23719);
    }
    else {
        _p_23719 = NewDouble(DBL_PTR(_p_23719)->dbl + (double)400);
    }
    DeRef(_0);

    /** 			m = 1*/
    _m_23721 = 1;
L4: 

    /** 		c = memdata[m]*/
    _2 = (int)SEQ_PTR(_memdata_23716);
    _c_23717 = (int)*(((s1_ptr)_2)->base + _m_23721);

    /** 		if c = 0 then*/
    if (_c_23717 != 0)
    goto L5; // [133] 142

    /** 			exit*/
    goto L3; // [139] 179
L5: 

    /** 		n += 1*/
    _n_23720 = _n_23720 + 1;

    /** 		if n > length(line) then*/
    if (IS_SEQUENCE(_line_23715)){
            _13626 = SEQ_PTR(_line_23715)->length;
    }
    else {
        _13626 = 1;
    }
    if (_n_23720 <= _13626)
    goto L6; // [153] 168

    /** 			line &= repeat(0, LINE_BUFLEN)*/
    _13628 = Repeat(0, 400);
    Concat((object_ptr)&_line_23715, _line_23715, _13628);
    DeRefDS(_13628);
    _13628 = NOVALUE;
L6: 

    /** 		line[n] = c*/
    _2 = (int)SEQ_PTR(_line_23715);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _line_23715 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_23720);
    _1 = *(int *)_2;
    *(int *)_2 = _c_23717;
    DeRef(_1);

    /** 	end while*/
    goto L2; // [176] 82
L3: 

    /** 	line = remove( line, n+1, length( line ) )*/
    _13630 = _n_23720 + 1;
    if (_13630 > MAXINT){
        _13630 = NewDouble((double)_13630);
    }
    if (IS_SEQUENCE(_line_23715)){
            _13631 = SEQ_PTR(_line_23715)->length;
    }
    else {
        _13631 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_23715);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13630)) ? _13630 : (long)(DBL_PTR(_13630)->dbl);
        int stop = (IS_ATOM_INT(_13631)) ? _13631 : (long)(DBL_PTR(_13631)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_23715), start, &_line_23715 );
            }
            else Tail(SEQ_PTR(_line_23715), stop+1, &_line_23715);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_23715), start, &_line_23715);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_23715 = Remove_elements(start, stop, (SEQ_PTR(_line_23715)->ref == 1));
        }
    }
    DeRef(_13630);
    _13630 = NOVALUE;
    _13631 = NOVALUE;

    /** 	return line*/
    DeRefi(_memdata_23716);
    DeRef(_p_23719);
    return _line_23715;
    ;
}


void _60AppendSourceLine()
{
    int _new_23757 = NOVALUE;
    int _old_23758 = NOVALUE;
    int _options_23759 = NOVALUE;
    int _src_23760 = NOVALUE;
    int _13672 = NOVALUE;
    int _13668 = NOVALUE;
    int _13666 = NOVALUE;
    int _13665 = NOVALUE;
    int _13662 = NOVALUE;
    int _13661 = NOVALUE;
    int _13660 = NOVALUE;
    int _13659 = NOVALUE;
    int _13658 = NOVALUE;
    int _13657 = NOVALUE;
    int _13656 = NOVALUE;
    int _13655 = NOVALUE;
    int _13654 = NOVALUE;
    int _13653 = NOVALUE;
    int _13652 = NOVALUE;
    int _13651 = NOVALUE;
    int _13650 = NOVALUE;
    int _13649 = NOVALUE;
    int _13648 = NOVALUE;
    int _13647 = NOVALUE;
    int _13646 = NOVALUE;
    int _13645 = NOVALUE;
    int _13643 = NOVALUE;
    int _13642 = NOVALUE;
    int _13641 = NOVALUE;
    int _13639 = NOVALUE;
    int _13634 = NOVALUE;
    int _13633 = NOVALUE;
    int _0, _1, _2;
    

    /** 	src = 0*/
    DeRef(_src_23760);
    _src_23760 = 0;

    /** 	options = 0*/
    _options_23759 = 0;

    /** 	if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_12TRANSLATE_11319 != 0) {
        _13633 = 1;
        goto L1; // [15] 25
    }
    _13633 = (_12OpTrace_11752 != 0);
L1: 
    if (_13633 != 0) {
        _13634 = 1;
        goto L2; // [25] 35
    }
    _13634 = (_12OpProfileStatement_11754 != 0);
L2: 
    if (_13634 != 0) {
        goto L3; // [35] 46
    }
    if (_12OpProfileTime_11755 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** 		src = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_src_23760);
    _src_23760 = _43ThisLine_48158;

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** 			options = SOP_TRACE*/
    _options_23759 = 1;
L5: 

    /** 		if OpProfileTime then*/
    if (_12OpProfileTime_11755 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_TIME)*/
    {unsigned long tu;
         tu = (unsigned long)_options_23759 | (unsigned long)2;
         _options_23759 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_23759)) {
        _1 = (long)(DBL_PTR(_options_23759)->dbl);
        DeRefDS(_options_23759);
        _options_23759 = _1;
    }
L6: 

    /** 		if OpProfileStatement then*/
    if (_12OpProfileStatement_11754 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {unsigned long tu;
         tu = (unsigned long)_options_23759 | (unsigned long)4;
         _options_23759 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_23759)) {
        _1 = (long)(DBL_PTR(_options_23759)->dbl);
        DeRefDS(_options_23759);
        _options_23759 = _1;
    }
L7: 

    /** 		if OpProfileStatement or OpProfileTime then*/
    if (_12OpProfileStatement_11754 != 0) {
        goto L8; // [110] 121
    }
    if (_12OpProfileTime_11755 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** 			src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _13639 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13639) && IS_ATOM(_src_23760)) {
        Ref(_src_23760);
        Append(&_src_23760, _13639, _src_23760);
    }
    else if (IS_ATOM(_13639) && IS_SEQUENCE(_src_23760)) {
    }
    else {
        Concat((object_ptr)&_src_23760, _13639, _src_23760);
        DeRefDS(_13639);
        _13639 = NOVALUE;
    }
    DeRef(_13639);
    _13639 = NOVALUE;
L9: 
L4: 

    /** 	if length(slist) then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _13641 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13641 = 1;
    }
    if (_13641 == 0)
    {
        _13641 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _13641 = NOVALUE;
    }

    /** 		old = slist[$-1]*/
    if (IS_SEQUENCE(_12slist_11773)){
            _13642 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13642 = 1;
    }
    _13643 = _13642 - 1;
    _13642 = NOVALUE;
    DeRef(_old_23758);
    _2 = (int)SEQ_PTR(_12slist_11773);
    _old_23758 = (int)*(((s1_ptr)_2)->base + _13643);
    Ref(_old_23758);

    /** 		if equal(src, old[SRC]) and*/
    _2 = (int)SEQ_PTR(_old_23758);
    _13645 = (int)*(((s1_ptr)_2)->base + 1);
    if (_src_23760 == _13645)
    _13646 = 1;
    else if (IS_ATOM_INT(_src_23760) && IS_ATOM_INT(_13645))
    _13646 = 0;
    else
    _13646 = (compare(_src_23760, _13645) == 0);
    _13645 = NOVALUE;
    if (_13646 == 0) {
        _13647 = 0;
        goto LB; // [175] 195
    }
    _2 = (int)SEQ_PTR(_old_23758);
    _13648 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_13648)) {
        _13649 = (_12current_file_no_11682 == _13648);
    }
    else {
        _13649 = binary_op(EQUALS, _12current_file_no_11682, _13648);
    }
    _13648 = NOVALUE;
    if (IS_ATOM_INT(_13649))
    _13647 = (_13649 != 0);
    else
    _13647 = DBL_PTR(_13649)->dbl != 0.0;
LB: 
    if (_13647 == 0) {
        _13650 = 0;
        goto LC; // [195] 232
    }
    _2 = (int)SEQ_PTR(_old_23758);
    _13651 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13651)) {
        _13652 = _13651 + 1;
        if (_13652 > MAXINT){
            _13652 = NewDouble((double)_13652);
        }
    }
    else
    _13652 = binary_op(PLUS, 1, _13651);
    _13651 = NOVALUE;
    if (IS_SEQUENCE(_12slist_11773)){
            _13653 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13653 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _13654 = (int)*(((s1_ptr)_2)->base + _13653);
    if (IS_ATOM_INT(_13652) && IS_ATOM_INT(_13654)) {
        _13655 = _13652 + _13654;
        if ((long)((unsigned long)_13655 + (unsigned long)HIGH_BITS) >= 0) 
        _13655 = NewDouble((double)_13655);
    }
    else {
        _13655 = binary_op(PLUS, _13652, _13654);
    }
    DeRef(_13652);
    _13652 = NOVALUE;
    _13654 = NOVALUE;
    if (IS_ATOM_INT(_13655)) {
        _13656 = (_12line_number_11683 == _13655);
    }
    else {
        _13656 = binary_op(EQUALS, _12line_number_11683, _13655);
    }
    DeRef(_13655);
    _13655 = NOVALUE;
    if (IS_ATOM_INT(_13656))
    _13650 = (_13656 != 0);
    else
    _13650 = DBL_PTR(_13656)->dbl != 0.0;
LC: 
    if (_13650 == 0) {
        goto LD; // [232] 272
    }
    _2 = (int)SEQ_PTR(_old_23758);
    _13658 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_13658)) {
        _13659 = (_options_23759 == _13658);
    }
    else {
        _13659 = binary_op(EQUALS, _options_23759, _13658);
    }
    _13658 = NOVALUE;
    if (_13659 == 0) {
        DeRef(_13659);
        _13659 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_13659) && DBL_PTR(_13659)->dbl == 0.0){
            DeRef(_13659);
            _13659 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_13659);
        _13659 = NOVALUE;
    }
    DeRef(_13659);
    _13659 = NOVALUE;

    /** 			slist[$] += 1*/
    if (IS_SEQUENCE(_12slist_11773)){
            _13660 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13660 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _13661 = (int)*(((s1_ptr)_2)->base + _13660);
    if (IS_ATOM_INT(_13661)) {
        _13662 = _13661 + 1;
        if (_13662 > MAXINT){
            _13662 = NewDouble((double)_13662);
        }
    }
    else
    _13662 = binary_op(PLUS, 1, _13661);
    _13661 = NOVALUE;
    _2 = (int)SEQ_PTR(_12slist_11773);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12slist_11773 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13660);
    _1 = *(int *)_2;
    *(int *)_2 = _13662;
    if( _1 != _13662 ){
        DeRef(_1);
    }
    _13662 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** 			src = pack_source(src)*/
    Ref(_src_23760);
    _0 = _src_23760;
    _src_23760 = _60pack_source(_src_23760);
    DeRef(_0);

    /** 			new = {src, line_number, current_file_no, options}*/
    _0 = _new_23757;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_23760);
    *((int *)(_2+4)) = _src_23760;
    *((int *)(_2+8)) = _12line_number_11683;
    *((int *)(_2+12)) = _12current_file_no_11682;
    *((int *)(_2+16)) = _options_23759;
    _new_23757 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			if slist[$] = 0 then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _13665 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13665 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _13666 = (int)*(((s1_ptr)_2)->base + _13665);
    if (binary_op_a(NOTEQ, _13666, 0)){
        _13666 = NOVALUE;
        goto LF; // [302] 320
    }
    _13666 = NOVALUE;

    /** 				slist[$] = new*/
    if (IS_SEQUENCE(_12slist_11773)){
            _13668 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _13668 = 1;
    }
    RefDS(_new_23757);
    _2 = (int)SEQ_PTR(_12slist_11773);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12slist_11773 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13668);
    _1 = *(int *)_2;
    *(int *)_2 = _new_23757;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** 				slist = append(slist, new)*/
    RefDS(_new_23757);
    Append(&_12slist_11773, _12slist_11773, _new_23757);
L10: 

    /** 			slist = append(slist, 0)*/
    Append(&_12slist_11773, _12slist_11773, 0);
    goto LE; // [342] 371
LA: 

    /** 		src = pack_source(src)*/
    Ref(_src_23760);
    _0 = _src_23760;
    _src_23760 = _60pack_source(_src_23760);
    DeRef(_0);

    /** 		slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_23760);
    *((int *)(_2+4)) = _src_23760;
    *((int *)(_2+8)) = _12line_number_11683;
    *((int *)(_2+12)) = _12current_file_no_11682;
    *((int *)(_2+16)) = _options_23759;
    _13672 = MAKE_SEQ(_1);
    DeRef(_12slist_11773);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13672;
    ((int *)_2)[2] = 0;
    _12slist_11773 = MAKE_SEQ(_1);
    _13672 = NOVALUE;
LE: 

    /** end procedure*/
    DeRef(_new_23757);
    DeRef(_old_23758);
    DeRef(_src_23760);
    DeRef(_13643);
    _13643 = NOVALUE;
    DeRef(_13656);
    _13656 = NOVALUE;
    DeRef(_13649);
    _13649 = NOVALUE;
    return;
    ;
}


int _60s_expand(int _slist_23849)
{
    int _new_slist_23850 = NOVALUE;
    int _13686 = NOVALUE;
    int _13685 = NOVALUE;
    int _13684 = NOVALUE;
    int _13683 = NOVALUE;
    int _13681 = NOVALUE;
    int _13680 = NOVALUE;
    int _13679 = NOVALUE;
    int _13677 = NOVALUE;
    int _13676 = NOVALUE;
    int _13675 = NOVALUE;
    int _13674 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_23850);
    _new_slist_23850 = _5;

    /** 	for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_23849)){
            _13674 = SEQ_PTR(_slist_23849)->length;
    }
    else {
        _13674 = 1;
    }
    {
        int _i_23852;
        _i_23852 = 1;
L1: 
        if (_i_23852 > _13674){
            goto L2; // [15] 114
        }

        /** 		if sequence(slist[i]) then*/
        _2 = (int)SEQ_PTR(_slist_23849);
        _13675 = (int)*(((s1_ptr)_2)->base + _i_23852);
        _13676 = IS_SEQUENCE(_13675);
        _13675 = NOVALUE;
        if (_13676 == 0)
        {
            _13676 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _13676 = NOVALUE;
        }

        /** 			new_slist = append(new_slist, slist[i])*/
        _2 = (int)SEQ_PTR(_slist_23849);
        _13677 = (int)*(((s1_ptr)_2)->base + _i_23852);
        Ref(_13677);
        Append(&_new_slist_23850, _new_slist_23850, _13677);
        _13677 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** 			for j = 1 to slist[i] do*/
        _2 = (int)SEQ_PTR(_slist_23849);
        _13679 = (int)*(((s1_ptr)_2)->base + _i_23852);
        {
            int _j_23861;
            _j_23861 = 1;
L5: 
            if (binary_op_a(GREATER, _j_23861, _13679)){
                goto L6; // [53] 106
            }

            /** 				slist[i-1][LINE] += 1*/
            _13680 = _i_23852 - 1;
            _2 = (int)SEQ_PTR(_slist_23849);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _slist_23849 = MAKE_SEQ(_2);
            }
            _3 = (int)(_13680 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            _13683 = (int)*(((s1_ptr)_2)->base + 2);
            _13681 = NOVALUE;
            if (IS_ATOM_INT(_13683)) {
                _13684 = _13683 + 1;
                if (_13684 > MAXINT){
                    _13684 = NewDouble((double)_13684);
                }
            }
            else
            _13684 = binary_op(PLUS, 1, _13683);
            _13683 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _13684;
            if( _1 != _13684 ){
                DeRef(_1);
            }
            _13684 = NOVALUE;
            _13681 = NOVALUE;

            /** 				new_slist = append(new_slist, slist[i-1])*/
            _13685 = _i_23852 - 1;
            _2 = (int)SEQ_PTR(_slist_23849);
            _13686 = (int)*(((s1_ptr)_2)->base + _13685);
            Ref(_13686);
            Append(&_new_slist_23850, _new_slist_23850, _13686);
            _13686 = NOVALUE;

            /** 			end for*/
            _0 = _j_23861;
            if (IS_ATOM_INT(_j_23861)) {
                _j_23861 = _j_23861 + 1;
                if ((long)((unsigned long)_j_23861 +(unsigned long) HIGH_BITS) >= 0){
                    _j_23861 = NewDouble((double)_j_23861);
                }
            }
            else {
                _j_23861 = binary_op_a(PLUS, _j_23861, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_23861);
        }
L4: 

        /** 	end for*/
        _i_23852 = _i_23852 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** 	return new_slist*/
    DeRefDS(_slist_23849);
    _13679 = NOVALUE;
    DeRef(_13680);
    _13680 = NOVALUE;
    DeRef(_13685);
    _13685 = NOVALUE;
    return _new_slist_23850;
    ;
}


void _60set_dont_read(int _read_23876)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_read_23876)) {
        _1 = (long)(DBL_PTR(_read_23876)->dbl);
        DeRefDS(_read_23876);
        _read_23876 = _1;
    }

    /** 	dont_read = read*/
    _60dont_read_23873 = _read_23876;

    /** end procedure*/
    return;
    ;
}


void _60read_line()
{
    int _n_23879 = NOVALUE;
    int _13700 = NOVALUE;
    int _13699 = NOVALUE;
    int _13697 = NOVALUE;
    int _13696 = NOVALUE;
    int _13694 = NOVALUE;
    int _13693 = NOVALUE;
    int _0, _1, _2;
    

    /** 	line_number += 1*/
    _12line_number_11683 = _12line_number_11683 + 1;

    /** 	gline_number += 1*/
    _12gline_number_11687 = _12gline_number_11687 + 1;

    /** 	if dont_read then*/
    if (_60dont_read_23873 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** 		ThisLine = -1*/
    DeRef(_43ThisLine_48158);
    _43ThisLine_48158 = -1;
    goto L2; // [33] 108
L1: 

    /** 	elsif src_file < 0 then*/
    if (_12src_file_11804 >= 0)
    goto L3; // [40] 52

    /** 		ThisLine = -1*/
    DeRef(_43ThisLine_48158);
    _43ThisLine_48158 = -1;
    goto L2; // [49] 108
L3: 

    /** 		ThisLine = gets(src_file)*/
    DeRef(_43ThisLine_48158);
    _43ThisLine_48158 = EGets(_12src_file_11804);

    /** 		if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _13693 = IS_SEQUENCE(_43ThisLine_48158);
    if (_13693 == 0) {
        goto L4; // [66] 107
    }
    RefDS(_13695);
    Ref(_43ThisLine_48158);
    _13696 = _20ends(_13695, _43ThisLine_48158);
    if (_13696 == 0) {
        DeRef(_13696);
        _13696 = NOVALUE;
        goto L4; // [78] 107
    }
    else {
        if (!IS_ATOM_INT(_13696) && DBL_PTR(_13696)->dbl == 0.0){
            DeRef(_13696);
            _13696 = NOVALUE;
            goto L4; // [78] 107
        }
        DeRef(_13696);
        _13696 = NOVALUE;
    }
    DeRef(_13696);
    _13696 = NOVALUE;

    /** 			ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_43ThisLine_48158)){
            _13697 = SEQ_PTR(_43ThisLine_48158)->length;
    }
    else {
        _13697 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43ThisLine_48158);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13697)) ? _13697 : (long)(DBL_PTR(_13697)->dbl);
        int stop = (IS_ATOM_INT(_13697)) ? _13697 : (long)(DBL_PTR(_13697)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43ThisLine_48158), start, &_43ThisLine_48158 );
            }
            else Tail(SEQ_PTR(_43ThisLine_48158), stop+1, &_43ThisLine_48158);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43ThisLine_48158), start, &_43ThisLine_48158);
        }
        else {
            assign_slice_seq = &assign_space;
            _43ThisLine_48158 = Remove_elements(start, stop, (SEQ_PTR(_43ThisLine_48158)->ref == 1));
        }
    }
    _13697 = NOVALUE;
    _13697 = NOVALUE;

    /** 			ThisLine[$] = 10*/
    if (IS_SEQUENCE(_43ThisLine_48158)){
            _13699 = SEQ_PTR(_43ThisLine_48158)->length;
    }
    else {
        _13699 = 1;
    }
    _2 = (int)SEQ_PTR(_43ThisLine_48158);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _43ThisLine_48158 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13699);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);
L4: 
L2: 

    /** 	if atom(ThisLine) then*/
    _13700 = IS_ATOM(_43ThisLine_48158);
    if (_13700 == 0)
    {
        _13700 = NOVALUE;
        goto L5; // [115] 149
    }
    else{
        _13700 = NOVALUE;
    }

    /** 		ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _43ThisLine_48158;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 26;
    _43ThisLine_48158 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if src_file >= 0 then*/
    if (_12src_file_11804 < 0)
    goto L6; // [130] 141

    /** 			close(src_file)*/
    EClose(_12src_file_11804);
L6: 

    /** 		src_file = -1*/
    _12src_file_11804 = -1;
L5: 

    /** 	bp = 1*/
    _43bp_48162 = 1;

    /** 	AppendSourceLine()*/
    _60AppendSourceLine();

    /** end procedure*/
    return;
    ;
}


int _60getch()
{
    int _c_23923 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_43ThisLine_48158);
    _c_23923 = (int)*(((s1_ptr)_2)->base + _43bp_48162);
    if (!IS_ATOM_INT(_c_23923)){
        _c_23923 = (long)DBL_PTR(_c_23923)->dbl;
    }

    /** 	bp += 1*/
    _43bp_48162 = _43bp_48162 + 1;

    /** 	return c*/
    return _c_23923;
    ;
}


void _60ungetch()
{
    int _0, _1, _2;
    

    /** 	bp -= 1*/
    _43bp_48162 = _43bp_48162 - 1;

    /** end procedure*/
    return;
    ;
}


int _60get_file_path(int _s_23935)
{
    int _13711 = NOVALUE;
    int _13709 = NOVALUE;
    int _13708 = NOVALUE;
    int _13707 = NOVALUE;
    int _13706 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_23935)){
            _13706 = SEQ_PTR(_s_23935)->length;
    }
    else {
        _13706 = 1;
    }
    {
        int _t_23937;
        _t_23937 = _13706;
L1: 
        if (_t_23937 < 1){
            goto L2; // [8] 50
        }

        /** 				if find(s[t],SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_s_23935);
        _13707 = (int)*(((s1_ptr)_2)->base + _t_23937);
        _13708 = find_from(_13707, _36SLASH_CHARS_14019, 1);
        _13707 = NOVALUE;
        if (_13708 == 0)
        {
            _13708 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _13708 = NOVALUE;
        }

        /** 						return s[1..t]*/
        rhs_slice_target = (object_ptr)&_13709;
        RHS_Slice(_s_23935, 1, _t_23937);
        DeRefDS(_s_23935);
        return _13709;
L3: 

        /** 		end for*/
        _t_23937 = _t_23937 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** 		return "." & SLASH*/
    Append(&_13711, _13710, 47);
    DeRefDS(_s_23935);
    DeRef(_13709);
    _13709 = NOVALUE;
    return _13711;
    ;
}


int _60find_file(int _fname_23949)
{
    int _try_23950 = NOVALUE;
    int _full_path_23951 = NOVALUE;
    int _errbuff_23952 = NOVALUE;
    int _currdir_23953 = NOVALUE;
    int _conf_path_23954 = NOVALUE;
    int _scan_result_23955 = NOVALUE;
    int _inc_path_23956 = NOVALUE;
    int _mainpath_23975 = NOVALUE;
    int _31401 = NOVALUE;
    int _31400 = NOVALUE;
    int _13808 = NOVALUE;
    int _13806 = NOVALUE;
    int _13805 = NOVALUE;
    int _13804 = NOVALUE;
    int _13802 = NOVALUE;
    int _13800 = NOVALUE;
    int _13798 = NOVALUE;
    int _13797 = NOVALUE;
    int _13795 = NOVALUE;
    int _13794 = NOVALUE;
    int _13791 = NOVALUE;
    int _13788 = NOVALUE;
    int _13787 = NOVALUE;
    int _13786 = NOVALUE;
    int _13785 = NOVALUE;
    int _13784 = NOVALUE;
    int _13783 = NOVALUE;
    int _13782 = NOVALUE;
    int _13781 = NOVALUE;
    int _13778 = NOVALUE;
    int _13777 = NOVALUE;
    int _13773 = NOVALUE;
    int _13770 = NOVALUE;
    int _13769 = NOVALUE;
    int _13768 = NOVALUE;
    int _13767 = NOVALUE;
    int _13766 = NOVALUE;
    int _13765 = NOVALUE;
    int _13764 = NOVALUE;
    int _13763 = NOVALUE;
    int _13760 = NOVALUE;
    int _13756 = NOVALUE;
    int _13754 = NOVALUE;
    int _13753 = NOVALUE;
    int _13752 = NOVALUE;
    int _13751 = NOVALUE;
    int _13750 = NOVALUE;
    int _13747 = NOVALUE;
    int _13746 = NOVALUE;
    int _13745 = NOVALUE;
    int _13744 = NOVALUE;
    int _13743 = NOVALUE;
    int _13742 = NOVALUE;
    int _13740 = NOVALUE;
    int _13739 = NOVALUE;
    int _13738 = NOVALUE;
    int _13737 = NOVALUE;
    int _13736 = NOVALUE;
    int _13734 = NOVALUE;
    int _13733 = NOVALUE;
    int _13730 = NOVALUE;
    int _13727 = NOVALUE;
    int _13725 = NOVALUE;
    int _13722 = NOVALUE;
    int _13720 = NOVALUE;
    int _13719 = NOVALUE;
    int _13716 = NOVALUE;
    int _13715 = NOVALUE;
    int _13713 = NOVALUE;
    int _13712 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(fname) then*/
    RefDS(_fname_23949);
    _13712 = _14absolute_path(_fname_23949);
    if (_13712 == 0) {
        DeRef(_13712);
        _13712 = NOVALUE;
        goto L1; // [9] 42
    }
    else {
        if (!IS_ATOM_INT(_13712) && DBL_PTR(_13712)->dbl == 0.0){
            DeRef(_13712);
            _13712 = NOVALUE;
            goto L1; // [9] 42
        }
        DeRef(_13712);
        _13712 = NOVALUE;
    }
    DeRef(_13712);
    _13712 = NOVALUE;

    /** 		if not file_exists(fname) then*/
    RefDS(_fname_23949);
    _13713 = _14file_exists(_fname_23949);
    if (IS_ATOM_INT(_13713)) {
        if (_13713 != 0){
            DeRef(_13713);
            _13713 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    else {
        if (DBL_PTR(_13713)->dbl != 0.0){
            DeRef(_13713);
            _13713 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    DeRef(_13713);
    _13713 = NOVALUE;

    /** 			CompileErr(51, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_12new_include_name_11805);
    *((int *)(_2+4)) = _12new_include_name_11805;
    _13715 = MAKE_SEQ(_1);
    _43CompileErr(51, _13715, 0);
    _13715 = NOVALUE;
L2: 

    /** 		return fname*/
    DeRef(_full_path_23951);
    DeRef(_errbuff_23952);
    DeRef(_currdir_23953);
    DeRef(_conf_path_23954);
    DeRef(_scan_result_23955);
    DeRef(_inc_path_23956);
    DeRef(_mainpath_23975);
    return _fname_23949;
L1: 

    /** 	currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _13716 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_13716);
    _0 = _currdir_23953;
    _currdir_23953 = _60get_file_path(_13716);
    DeRef(_0);
    _13716 = NOVALUE;

    /** 	full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_23951, _currdir_23953, _fname_23949);

    /** 	if file_exists(full_path) then*/
    RefDS(_full_path_23951);
    _13719 = _14file_exists(_full_path_23951);
    if (_13719 == 0) {
        DeRef(_13719);
        _13719 = NOVALUE;
        goto L3; // [70] 80
    }
    else {
        if (!IS_ATOM_INT(_13719) && DBL_PTR(_13719)->dbl == 0.0){
            DeRef(_13719);
            _13719 = NOVALUE;
            goto L3; // [70] 80
        }
        DeRef(_13719);
        _13719 = NOVALUE;
    }
    DeRef(_13719);
    _13719 = NOVALUE;

    /** 		return full_path*/
    DeRefDS(_fname_23949);
    DeRef(_errbuff_23952);
    DeRefDS(_currdir_23953);
    DeRef(_conf_path_23954);
    DeRef(_scan_result_23955);
    DeRef(_inc_path_23956);
    DeRef(_mainpath_23975);
    return _full_path_23951;
L3: 

    /** 	sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_12main_path_11803);
    DeRef(_31400);
    _31400 = _12main_path_11803;
    if (IS_SEQUENCE(_31400)){
            _31401 = SEQ_PTR(_31400)->length;
    }
    else {
        _31401 = 1;
    }
    _31400 = NOVALUE;
    RefDS(_12main_path_11803);
    _13720 = _20rfind(47, _12main_path_11803, _31401);
    _31401 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_23975;
    RHS_Slice(_12main_path_11803, 1, _13720);

    /** 	if not equal(mainpath, currdir) then*/
    if (_mainpath_23975 == _currdir_23953)
    _13722 = 1;
    else if (IS_ATOM_INT(_mainpath_23975) && IS_ATOM_INT(_currdir_23953))
    _13722 = 0;
    else
    _13722 = (compare(_mainpath_23975, _currdir_23953) == 0);
    if (_13722 != 0)
    goto L4; // [111] 139
    _13722 = NOVALUE;

    /** 		full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_23951, _mainpath_23975, _12new_include_name_11805);

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_23951);
    _13725 = _14file_exists(_full_path_23951);
    if (_13725 == 0) {
        DeRef(_13725);
        _13725 = NOVALUE;
        goto L5; // [128] 138
    }
    else {
        if (!IS_ATOM_INT(_13725) && DBL_PTR(_13725)->dbl == 0.0){
            DeRef(_13725);
            _13725 = NOVALUE;
            goto L5; // [128] 138
        }
        DeRef(_13725);
        _13725 = NOVALUE;
    }
    DeRef(_13725);
    _13725 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_23949);
    DeRef(_errbuff_23952);
    DeRefDS(_currdir_23953);
    DeRef(_conf_path_23954);
    DeRef(_scan_result_23955);
    DeRef(_inc_path_23956);
    DeRefDS(_mainpath_23975);
    _31400 = NOVALUE;
    DeRef(_13720);
    _13720 = NOVALUE;
    return _full_path_23951;
L5: 
L4: 

    /** 	scan_result = ConfPath(new_include_name)*/
    RefDS(_12new_include_name_11805);
    _0 = _scan_result_23955;
    _scan_result_23955 = _38ConfPath(_12new_include_name_11805);
    DeRef(_0);

    /** 	if atom(scan_result) then*/
    _13727 = IS_ATOM(_scan_result_23955);
    if (_13727 == 0)
    {
        _13727 = NOVALUE;
        goto L6; // [152] 164
    }
    else{
        _13727 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_23949);
    RefDS(_13728);
    _0 = _scan_result_23955;
    _scan_result_23955 = _38ScanPath(_fname_23949, _13728, 0);
    DeRef(_0);
L6: 

    /** 	if atom(scan_result) then*/
    _13730 = IS_ATOM(_scan_result_23955);
    if (_13730 == 0)
    {
        _13730 = NOVALUE;
        goto L7; // [169] 181
    }
    else{
        _13730 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_23949);
    RefDS(_13731);
    _0 = _scan_result_23955;
    _scan_result_23955 = _38ScanPath(_fname_23949, _13731, 1);
    DeRef(_0);
L7: 

    /** 	if atom(scan_result) then*/
    _13733 = IS_ATOM(_scan_result_23955);
    if (_13733 == 0)
    {
        _13733 = NOVALUE;
        goto L8; // [186] 223
    }
    else{
        _13733 = NOVALUE;
    }

    /** 		full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _13734 = _13get_eudir();
    {
        int concat_list[5];

        concat_list[0] = _fname_23949;
        concat_list[1] = 47;
        concat_list[2] = _13154;
        concat_list[3] = 47;
        concat_list[4] = _13734;
        Concat_N((object_ptr)&_full_path_23951, concat_list, 5);
    }
    DeRef(_13734);
    _13734 = NOVALUE;

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_23951);
    _13736 = _14file_exists(_full_path_23951);
    if (_13736 == 0) {
        DeRef(_13736);
        _13736 = NOVALUE;
        goto L9; // [212] 222
    }
    else {
        if (!IS_ATOM_INT(_13736) && DBL_PTR(_13736)->dbl == 0.0){
            DeRef(_13736);
            _13736 = NOVALUE;
            goto L9; // [212] 222
        }
        DeRef(_13736);
        _13736 = NOVALUE;
    }
    DeRef(_13736);
    _13736 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_23949);
    DeRef(_errbuff_23952);
    DeRef(_currdir_23953);
    DeRef(_conf_path_23954);
    DeRef(_scan_result_23955);
    DeRef(_inc_path_23956);
    DeRef(_mainpath_23975);
    _31400 = NOVALUE;
    DeRef(_13720);
    _13720 = NOVALUE;
    return _full_path_23951;
L9: 
L8: 

    /** 	if sequence(scan_result) then*/
    _13737 = IS_SEQUENCE(_scan_result_23955);
    if (_13737 == 0)
    {
        _13737 = NOVALUE;
        goto LA; // [228] 250
    }
    else{
        _13737 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_23955);
    _13738 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13738))
    EClose(_13738);
    else
    EClose((int)DBL_PTR(_13738)->dbl);
    _13738 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_23955);
    _13739 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_13739);
    DeRefDS(_fname_23949);
    DeRef(_full_path_23951);
    DeRef(_errbuff_23952);
    DeRef(_currdir_23953);
    DeRef(_conf_path_23954);
    DeRef(_scan_result_23955);
    DeRef(_inc_path_23956);
    DeRef(_mainpath_23975);
    _31400 = NOVALUE;
    DeRef(_13720);
    _13720 = NOVALUE;
    return _13739;
LA: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_23952);
    _errbuff_23952 = _5;

    /** 	full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_23951);
    _full_path_23951 = _5;

    /** 	if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_23953)){
            _13740 = SEQ_PTR(_currdir_23953)->length;
    }
    else {
        _13740 = 1;
    }
    if (_13740 <= 0)
    goto LB; // [269] 321

    /** 		if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_23953)){
            _13742 = SEQ_PTR(_currdir_23953)->length;
    }
    else {
        _13742 = 1;
    }
    _2 = (int)SEQ_PTR(_currdir_23953);
    _13743 = (int)*(((s1_ptr)_2)->base + _13742);
    _13744 = find_from(_13743, _36SLASH_CHARS_14019, 1);
    _13743 = NOVALUE;
    if (_13744 == 0)
    {
        _13744 = NOVALUE;
        goto LC; // [289] 313
    }
    else{
        _13744 = NOVALUE;
    }

    /** 			full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_23953)){
            _13745 = SEQ_PTR(_currdir_23953)->length;
    }
    else {
        _13745 = 1;
    }
    _13746 = _13745 - 1;
    _13745 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13747;
    RHS_Slice(_currdir_23953, 1, _13746);
    RefDS(_13747);
    Append(&_full_path_23951, _full_path_23951, _13747);
    DeRefDS(_13747);
    _13747 = NOVALUE;
    goto LD; // [310] 320
LC: 

    /** 			full_path = append(full_path, currdir)*/
    RefDS(_currdir_23953);
    Append(&_full_path_23951, _full_path_23951, _currdir_23953);
LD: 
LB: 

    /** 	if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_12main_path_11803)){
            _13750 = SEQ_PTR(_12main_path_11803)->length;
    }
    else {
        _13750 = 1;
    }
    _2 = (int)SEQ_PTR(_12main_path_11803);
    _13751 = (int)*(((s1_ptr)_2)->base + _13750);
    _13752 = find_from(_13751, _36SLASH_CHARS_14019, 1);
    _13751 = NOVALUE;
    if (_13752 == 0)
    {
        _13752 = NOVALUE;
        goto LE; // [339] 361
    }
    else{
        _13752 = NOVALUE;
    }

    /** 		errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_12main_path_11803)){
            _13753 = SEQ_PTR(_12main_path_11803)->length;
    }
    else {
        _13753 = 1;
    }
    _13754 = _13753 - 1;
    _13753 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_23952;
    RHS_Slice(_12main_path_11803, 1, _13754);
    goto LF; // [358] 371
LE: 

    /** 		errbuff = main_path*/
    RefDS(_12main_path_11803);
    DeRef(_errbuff_23952);
    _errbuff_23952 = _12main_path_11803;
LF: 

    /** 	if not find(errbuff, full_path) then*/
    _13756 = find_from(_errbuff_23952, _full_path_23951, 1);
    if (_13756 != 0)
    goto L10; // [378] 388
    _13756 = NOVALUE;

    /** 		full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_23952);
    Append(&_full_path_23951, _full_path_23951, _errbuff_23952);
L10: 

    /** 	conf_path = get_conf_dirs()*/
    _0 = _conf_path_23954;
    _conf_path_23954 = _38get_conf_dirs();
    DeRef(_0);

    /** 	if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_23954)){
            _13760 = SEQ_PTR(_conf_path_23954)->length;
    }
    else {
        _13760 = 1;
    }
    if (_13760 <= 0)
    goto L11; // [400] 507

    /** 		conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_23954);
    _0 = _conf_path_23954;
    _conf_path_23954 = _24split(_conf_path_23954, 58, 0, 0);
    DeRefDS(_0);

    /** 		for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_23954)){
            _13763 = SEQ_PTR(_conf_path_23954)->length;
    }
    else {
        _13763 = 1;
    }
    {
        int _i_24056;
        _i_24056 = 1;
L12: 
        if (_i_24056 > _13763){
            goto L13; // [422] 506
        }

        /** 			if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_conf_path_23954);
        _13764 = (int)*(((s1_ptr)_2)->base + _i_24056);
        if (IS_SEQUENCE(_13764)){
                _13765 = SEQ_PTR(_13764)->length;
        }
        else {
            _13765 = 1;
        }
        _2 = (int)SEQ_PTR(_13764);
        _13766 = (int)*(((s1_ptr)_2)->base + _13765);
        _13764 = NOVALUE;
        _13767 = find_from(_13766, _36SLASH_CHARS_14019, 1);
        _13766 = NOVALUE;
        if (_13767 == 0)
        {
            _13767 = NOVALUE;
            goto L14; // [449] 473
        }
        else{
            _13767 = NOVALUE;
        }

        /** 				errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_conf_path_23954);
        _13768 = (int)*(((s1_ptr)_2)->base + _i_24056);
        if (IS_SEQUENCE(_13768)){
                _13769 = SEQ_PTR(_13768)->length;
        }
        else {
            _13769 = 1;
        }
        _13770 = _13769 - 1;
        _13769 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_23952;
        RHS_Slice(_13768, 1, _13770);
        _13768 = NOVALUE;
        goto L15; // [470] 482
L14: 

        /** 				errbuff = conf_path[i]*/
        DeRef(_errbuff_23952);
        _2 = (int)SEQ_PTR(_conf_path_23954);
        _errbuff_23952 = (int)*(((s1_ptr)_2)->base + _i_24056);
        Ref(_errbuff_23952);
L15: 

        /** 			if not find(errbuff, full_path) then*/
        _13773 = find_from(_errbuff_23952, _full_path_23951, 1);
        if (_13773 != 0)
        goto L16; // [489] 499
        _13773 = NOVALUE;

        /** 				full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_23952);
        Append(&_full_path_23951, _full_path_23951, _errbuff_23952);
L16: 

        /** 		end for*/
        _i_24056 = _i_24056 + 1;
        goto L12; // [501] 429
L13: 
        ;
    }
L11: 

    /** 	inc_path = getenv("EUINC")*/
    DeRef(_inc_path_23956);
    _inc_path_23956 = EGetEnv(_13728);

    /** 	if sequence(inc_path) then*/
    _13777 = IS_SEQUENCE(_inc_path_23956);
    if (_13777 == 0)
    {
        _13777 = NOVALUE;
        goto L17; // [517] 631
    }
    else{
        _13777 = NOVALUE;
    }

    /** 		if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_23956)){
            _13778 = SEQ_PTR(_inc_path_23956)->length;
    }
    else {
        _13778 = 1;
    }
    if (_13778 <= 0)
    goto L18; // [525] 630

    /** 			inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_23956);
    _0 = _inc_path_23956;
    _inc_path_23956 = _24split(_inc_path_23956, 58, 0, 0);
    DeRefi(_0);

    /** 			for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_23956)){
            _13781 = SEQ_PTR(_inc_path_23956)->length;
    }
    else {
        _13781 = 1;
    }
    {
        int _i_24084;
        _i_24084 = 1;
L19: 
        if (_i_24084 > _13781){
            goto L1A; // [545] 629
        }

        /** 				if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_inc_path_23956);
        _13782 = (int)*(((s1_ptr)_2)->base + _i_24084);
        if (IS_SEQUENCE(_13782)){
                _13783 = SEQ_PTR(_13782)->length;
        }
        else {
            _13783 = 1;
        }
        _2 = (int)SEQ_PTR(_13782);
        _13784 = (int)*(((s1_ptr)_2)->base + _13783);
        _13782 = NOVALUE;
        _13785 = find_from(_13784, _36SLASH_CHARS_14019, 1);
        _13784 = NOVALUE;
        if (_13785 == 0)
        {
            _13785 = NOVALUE;
            goto L1B; // [572] 596
        }
        else{
            _13785 = NOVALUE;
        }

        /** 					errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_inc_path_23956);
        _13786 = (int)*(((s1_ptr)_2)->base + _i_24084);
        if (IS_SEQUENCE(_13786)){
                _13787 = SEQ_PTR(_13786)->length;
        }
        else {
            _13787 = 1;
        }
        _13788 = _13787 - 1;
        _13787 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_23952;
        RHS_Slice(_13786, 1, _13788);
        _13786 = NOVALUE;
        goto L1C; // [593] 605
L1B: 

        /** 					errbuff = inc_path[i]*/
        DeRef(_errbuff_23952);
        _2 = (int)SEQ_PTR(_inc_path_23956);
        _errbuff_23952 = (int)*(((s1_ptr)_2)->base + _i_24084);
        Ref(_errbuff_23952);
L1C: 

        /** 				if not find(errbuff, full_path) then*/
        _13791 = find_from(_errbuff_23952, _full_path_23951, 1);
        if (_13791 != 0)
        goto L1D; // [612] 622
        _13791 = NOVALUE;

        /** 					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_23952);
        Append(&_full_path_23951, _full_path_23951, _errbuff_23952);
L1D: 

        /** 			end for*/
        _i_24084 = _i_24084 + 1;
        goto L19; // [624] 552
L1A: 
        ;
    }
L18: 
L17: 

    /** 	if length(get_eudir()) > 0 then*/
    _13794 = _13get_eudir();
    if (IS_SEQUENCE(_13794)){
            _13795 = SEQ_PTR(_13794)->length;
    }
    else {
        _13795 = 1;
    }
    DeRef(_13794);
    _13794 = NOVALUE;
    if (_13795 <= 0)
    goto L1E; // [639] 667

    /** 		if not find(get_eudir(), full_path) then*/
    _13797 = _13get_eudir();
    _13798 = find_from(_13797, _full_path_23951, 1);
    DeRef(_13797);
    _13797 = NOVALUE;
    if (_13798 != 0)
    goto L1F; // [653] 666
    _13798 = NOVALUE;

    /** 			full_path = append(full_path, get_eudir())*/
    _13800 = _13get_eudir();
    Ref(_13800);
    Append(&_full_path_23951, _full_path_23951, _13800);
    DeRef(_13800);
    _13800 = NOVALUE;
L1F: 
L1E: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_23952);
    _errbuff_23952 = _5;

    /** 	for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_23951)){
            _13802 = SEQ_PTR(_full_path_23951)->length;
    }
    else {
        _13802 = 1;
    }
    {
        int _i_24116;
        _i_24116 = 1;
L20: 
        if (_i_24116 > _13802){
            goto L21; // [679] 711
        }

        /** 		errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (int)SEQ_PTR(_full_path_23951);
        _13804 = (int)*(((s1_ptr)_2)->base + _i_24116);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13804);
        *((int *)(_2+4)) = _13804;
        _13805 = MAKE_SEQ(_1);
        _13804 = NOVALUE;
        _13806 = EPrintf(-9999999, _13803, _13805);
        DeRefDS(_13805);
        _13805 = NOVALUE;
        Concat((object_ptr)&_errbuff_23952, _errbuff_23952, _13806);
        DeRefDS(_13806);
        _13806 = NOVALUE;

        /** 	end for*/
        _i_24116 = _i_24116 + 1;
        goto L20; // [706] 686
L21: 
        ;
    }

    /** 	CompileErr(52, {new_include_name, errbuff})*/
    RefDS(_errbuff_23952);
    RefDS(_12new_include_name_11805);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12new_include_name_11805;
    ((int *)_2)[2] = _errbuff_23952;
    _13808 = MAKE_SEQ(_1);
    _43CompileErr(52, _13808, 0);
    _13808 = NOVALUE;
    ;
}


int _60path_open()
{
    int _fh_24128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_include_name = find_file(new_include_name)*/
    RefDS(_12new_include_name_11805);
    _0 = _60find_file(_12new_include_name_11805);
    DeRefDS(_12new_include_name_11805);
    _12new_include_name_11805 = _0;

    /** 	new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_12new_include_name_11805);
    _0 = _63maybe_preprocess(_12new_include_name_11805);
    DeRefDS(_12new_include_name_11805);
    _12new_include_name_11805 = _0;

    /** 	fh = open_locked(new_include_name)*/
    RefDS(_12new_include_name_11805);
    _fh_24128 = _13open_locked(_12new_include_name_11805);
    if (!IS_ATOM_INT(_fh_24128)) {
        _1 = (long)(DBL_PTR(_fh_24128)->dbl);
        DeRefDS(_fh_24128);
        _fh_24128 = _1;
    }

    /** 	return fh*/
    return _fh_24128;
    ;
}


int _60NameSpace_declaration(int _sym_24152)
{
    int _h_24153 = NOVALUE;
    int _13830 = NOVALUE;
    int _13828 = NOVALUE;
    int _13826 = NOVALUE;
    int _13824 = NOVALUE;
    int _13823 = NOVALUE;
    int _13822 = NOVALUE;
    int _13820 = NOVALUE;
    int _13819 = NOVALUE;
    int _13818 = NOVALUE;
    int _13817 = NOVALUE;
    int _13816 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_24152)) {
        _1 = (long)(DBL_PTR(_sym_24152)->dbl);
        DeRefDS(_sym_24152);
        _sym_24152 = _1;
    }

    /** 	DefinedYet(sym)*/
    _52DefinedYet(_sym_24152);

    /** 	if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _13816 = (int)*(((s1_ptr)_2)->base + _sym_24152);
    _2 = (int)SEQ_PTR(_13816);
    _13817 = (int)*(((s1_ptr)_2)->base + 4);
    _13816 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 11;
    *((int *)(_2+16)) = 7;
    _13818 = MAKE_SEQ(_1);
    _13819 = find_from(_13817, _13818, 1);
    _13817 = NOVALUE;
    DeRefDS(_13818);
    _13818 = NOVALUE;
    if (_13819 == 0)
    {
        _13819 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _13819 = NOVALUE;
    }

    /** 		h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _13820 = (int)*(((s1_ptr)_2)->base + _sym_24152);
    _2 = (int)SEQ_PTR(_13820);
    _h_24153 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_24153)){
        _h_24153 = (long)DBL_PTR(_h_24153)->dbl;
    }
    _13820 = NOVALUE;

    /** 		sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _13822 = (int)*(((s1_ptr)_2)->base + _sym_24152);
    _2 = (int)SEQ_PTR(_13822);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _13823 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _13823 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _13822 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _13824 = (int)*(((s1_ptr)_2)->base + _h_24153);
    Ref(_13823);
    Ref(_13824);
    _sym_24152 = _52NewEntry(_13823, 0, 0, -100, _h_24153, _13824, 0);
    _13823 = NOVALUE;
    _13824 = NOVALUE;
    if (!IS_ATOM_INT(_sym_24152)) {
        _1 = (long)(DBL_PTR(_sym_24152)->dbl);
        DeRefDS(_sym_24152);
        _sym_24152 = _1;
    }

    /** 		buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _2 = (int)(((s1_ptr)_2)->base + _h_24153);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_24152;
    DeRef(_1);
L1: 

    /** 	SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24152 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
    _13826 = NOVALUE;

    /** 	SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24152 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _13828 = NOVALUE;

    /** 	SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24152 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_11359))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    _1 = *(int *)_2;
    *(int *)_2 = 523;
    DeRef(_1);
    _13830 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** 		num_routines += 1 -- order of ns declaration relative to routines*/
    _12num_routines_11691 = _12num_routines_11691 + 1;
L2: 

    /** 	return sym*/
    return _sym_24152;
    ;
}


void _60default_namespace()
{
    int _tok_24203 = NOVALUE;
    int _sym_24205 = NOVALUE;
    int _13854 = NOVALUE;
    int _13853 = NOVALUE;
    int _13851 = NOVALUE;
    int _13849 = NOVALUE;
    int _13846 = NOVALUE;
    int _13843 = NOVALUE;
    int _13841 = NOVALUE;
    int _13839 = NOVALUE;
    int _13838 = NOVALUE;
    int _13837 = NOVALUE;
    int _13836 = NOVALUE;
    int _13835 = NOVALUE;
    int _13834 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_60scanner_rid_24199].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24203);
    _tok_24203 = _1;

    /** 	if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (int)SEQ_PTR(_tok_24203);
    _13834 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13834)) {
        _13835 = (_13834 == -100);
    }
    else {
        _13835 = binary_op(EQUALS, _13834, -100);
    }
    _13834 = NOVALUE;
    if (IS_ATOM_INT(_13835)) {
        if (_13835 == 0) {
            goto L1; // [23] 177
        }
    }
    else {
        if (DBL_PTR(_13835)->dbl == 0.0) {
            goto L1; // [23] 177
        }
    }
    _2 = (int)SEQ_PTR(_tok_24203);
    _13837 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_13837)){
        _13838 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13837)->dbl));
    }
    else{
        _13838 = (int)*(((s1_ptr)_2)->base + _13837);
    }
    _2 = (int)SEQ_PTR(_13838);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _13839 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _13839 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _13838 = NOVALUE;
    if (_13839 == _13840)
    _13841 = 1;
    else if (IS_ATOM_INT(_13839) && IS_ATOM_INT(_13840))
    _13841 = 0;
    else
    _13841 = (compare(_13839, _13840) == 0);
    _13839 = NOVALUE;
    if (_13841 == 0)
    {
        _13841 = NOVALUE;
        goto L1; // [50] 177
    }
    else{
        _13841 = NOVALUE;
    }

    /** 		tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_60scanner_rid_24199].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24203);
    _tok_24203 = _1;

    /** 		if tok[T_ID] != VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_24203);
    _13843 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _13843, -100)){
        _13843 = NOVALUE;
        goto L2; // [71] 83
    }
    _13843 = NOVALUE;

    /** 			CompileErr(114)*/
    RefDS(_21829);
    _43CompileErr(114, _21829, 0);
L2: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_24203);
    _sym_24205 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_24205)){
        _sym_24205 = (long)DBL_PTR(_sym_24205)->dbl;
    }

    /** 		SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24205 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_11350))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);
    _13846 = NOVALUE;

    /** 		sym  = NameSpace_declaration( sym )*/
    _sym_24205 = _60NameSpace_declaration(_sym_24205);
    if (!IS_ATOM_INT(_sym_24205)) {
        _1 = (long)(DBL_PTR(_sym_24205)->dbl);
        DeRefDS(_sym_24205);
        _sym_24205 = _1;
    }

    /** 		SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24205 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);
    _13849 = NOVALUE;

    /** 		SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24205 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 13;
    DeRef(_1);
    _13851 = NOVALUE;

    /** 		default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _13853 = (int)*(((s1_ptr)_2)->base + _sym_24205);
    _2 = (int)SEQ_PTR(_13853);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _13854 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _13854 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _13853 = NOVALUE;
    Ref(_13854);
    _2 = (int)SEQ_PTR(_60default_namespaces_23570);
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _13854;
    if( _1 != _13854 ){
        DeRef(_1);
    }
    _13854 = NOVALUE;
    goto L3; // [174] 185
L1: 

    /** 		bp = 1*/
    _43bp_48162 = 1;
L3: 

    /** end procedure*/
    DeRef(_tok_24203);
    _13837 = NOVALUE;
    DeRef(_13835);
    _13835 = NOVALUE;
    return;
    ;
}


void _60add_exports(int _from_file_24255, int _to_file_24256)
{
    int _exports_24257 = NOVALUE;
    int _direct_24258 = NOVALUE;
    int _13874 = NOVALUE;
    int _13873 = NOVALUE;
    int _13872 = NOVALUE;
    int _13871 = NOVALUE;
    int _13870 = NOVALUE;
    int _13868 = NOVALUE;
    int _13866 = NOVALUE;
    int _13865 = NOVALUE;
    int _13863 = NOVALUE;
    int _13862 = NOVALUE;
    int _13861 = NOVALUE;
    int _13859 = NOVALUE;
    int _13858 = NOVALUE;
    int _13857 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	direct = file_include[to_file]*/
    DeRef(_direct_24258);
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _direct_24258 = (int)*(((s1_ptr)_2)->base + _to_file_24256);
    Ref(_direct_24258);

    /** 	exports = file_public[from_file]*/
    DeRef(_exports_24257);
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _exports_24257 = (int)*(((s1_ptr)_2)->base + _from_file_24255);
    Ref(_exports_24257);

    /** 	for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_24257)){
            _13857 = SEQ_PTR(_exports_24257)->length;
    }
    else {
        _13857 = 1;
    }
    {
        int _i_24264;
        _i_24264 = 1;
L1: 
        if (_i_24264 > _13857){
            goto L2; // [30] 127
        }

        /** 		if not find( exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24257);
        _13858 = (int)*(((s1_ptr)_2)->base + _i_24264);
        _13859 = find_from(_13858, _direct_24258, 1);
        _13858 = NOVALUE;
        if (_13859 != 0)
        goto L3; // [48] 120
        _13859 = NOVALUE;

        /** 			if not find( -exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24257);
        _13861 = (int)*(((s1_ptr)_2)->base + _i_24264);
        if (IS_ATOM_INT(_13861)) {
            if ((unsigned long)_13861 == 0xC0000000)
            _13862 = (int)NewDouble((double)-0xC0000000);
            else
            _13862 = - _13861;
        }
        else {
            _13862 = unary_op(UMINUS, _13861);
        }
        _13861 = NOVALUE;
        _13863 = find_from(_13862, _direct_24258, 1);
        DeRef(_13862);
        _13862 = NOVALUE;
        if (_13863 != 0)
        goto L4; // [65] 82
        _13863 = NOVALUE;

        /** 				direct &= -exports[i]*/
        _2 = (int)SEQ_PTR(_exports_24257);
        _13865 = (int)*(((s1_ptr)_2)->base + _i_24264);
        if (IS_ATOM_INT(_13865)) {
            if ((unsigned long)_13865 == 0xC0000000)
            _13866 = (int)NewDouble((double)-0xC0000000);
            else
            _13866 = - _13865;
        }
        else {
            _13866 = unary_op(UMINUS, _13865);
        }
        _13865 = NOVALUE;
        if (IS_SEQUENCE(_direct_24258) && IS_ATOM(_13866)) {
            Ref(_13866);
            Append(&_direct_24258, _direct_24258, _13866);
        }
        else if (IS_ATOM(_direct_24258) && IS_SEQUENCE(_13866)) {
        }
        else {
            Concat((object_ptr)&_direct_24258, _direct_24258, _13866);
        }
        DeRef(_13866);
        _13866 = NOVALUE;
L4: 

        /** 			include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13include_matrix_10643 = MAKE_SEQ(_2);
        }
        _3 = (int)(_to_file_24256 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_exports_24257);
        _13870 = (int)*(((s1_ptr)_2)->base + _i_24264);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _13871 = (int)*(((s1_ptr)_2)->base + _to_file_24256);
        _2 = (int)SEQ_PTR(_exports_24257);
        _13872 = (int)*(((s1_ptr)_2)->base + _i_24264);
        _2 = (int)SEQ_PTR(_13871);
        if (!IS_ATOM_INT(_13872)){
            _13873 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13872)->dbl));
        }
        else{
            _13873 = (int)*(((s1_ptr)_2)->base + _13872);
        }
        _13871 = NOVALUE;
        if (IS_ATOM_INT(_13873)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13873;
                 _13874 = MAKE_UINT(tu);
            }
        }
        else {
            _13874 = binary_op(OR_BITS, 4, _13873);
        }
        _13873 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13870))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13870)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _13870);
        _1 = *(int *)_2;
        *(int *)_2 = _13874;
        if( _1 != _13874 ){
            DeRef(_1);
        }
        _13874 = NOVALUE;
        _13868 = NOVALUE;
L3: 

        /** 	end for*/
        _i_24264 = _i_24264 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** 	file_include[to_file] = direct*/
    RefDS(_direct_24258);
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _2 = (int)(((s1_ptr)_2)->base + _to_file_24256);
    _1 = *(int *)_2;
    *(int *)_2 = _direct_24258;
    DeRef(_1);

    /** end procedure*/
    DeRef(_exports_24257);
    DeRefDS(_direct_24258);
    _13870 = NOVALUE;
    _13872 = NOVALUE;
    return;
    ;
}


void _60patch_exports(int _for_file_24291)
{
    int _export_len_24292 = NOVALUE;
    int _13885 = NOVALUE;
    int _13884 = NOVALUE;
    int _13882 = NOVALUE;
    int _13881 = NOVALUE;
    int _13880 = NOVALUE;
    int _13879 = NOVALUE;
    int _13877 = NOVALUE;
    int _13876 = NOVALUE;
    int _13875 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _13875 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _13875 = 1;
    }
    {
        int _i_24294;
        _i_24294 = 1;
L1: 
        if (_i_24294 > _13875){
            goto L2; // [10] 99
        }

        /** 		if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (int)SEQ_PTR(_13file_include_10641);
        _13876 = (int)*(((s1_ptr)_2)->base + _i_24294);
        _13877 = find_from(_for_file_24291, _13876, 1);
        _13876 = NOVALUE;
        if (_13877 != 0) {
            goto L3; // [30] 53
        }
        if ((unsigned long)_for_file_24291 == 0xC0000000)
        _13879 = (int)NewDouble((double)-0xC0000000);
        else
        _13879 = - _for_file_24291;
        _2 = (int)SEQ_PTR(_13file_include_10641);
        _13880 = (int)*(((s1_ptr)_2)->base + _i_24294);
        _13881 = find_from(_13879, _13880, 1);
        DeRef(_13879);
        _13879 = NOVALUE;
        _13880 = NOVALUE;
        if (_13881 == 0)
        {
            _13881 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _13881 = NOVALUE;
        }
L3: 

        /** 			export_len = length( file_include[i] )*/
        _2 = (int)SEQ_PTR(_13file_include_10641);
        _13882 = (int)*(((s1_ptr)_2)->base + _i_24294);
        if (IS_SEQUENCE(_13882)){
                _export_len_24292 = SEQ_PTR(_13882)->length;
        }
        else {
            _export_len_24292 = 1;
        }
        _13882 = NOVALUE;

        /** 			add_exports( for_file, i )*/
        _60add_exports(_for_file_24291, _i_24294);

        /** 			if length( file_include[i] ) != export_len then*/
        _2 = (int)SEQ_PTR(_13file_include_10641);
        _13884 = (int)*(((s1_ptr)_2)->base + _i_24294);
        if (IS_SEQUENCE(_13884)){
                _13885 = SEQ_PTR(_13884)->length;
        }
        else {
            _13885 = 1;
        }
        _13884 = NOVALUE;
        if (_13885 == _export_len_24292)
        goto L5; // [81] 91

        /** 				patch_exports( i )*/
        _60patch_exports(_i_24294);
L5: 
L4: 

        /** 	end for*/
        _i_24294 = _i_24294 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** end procedure*/
    _13882 = NOVALUE;
    _13884 = NOVALUE;
    return;
    ;
}


void _60update_include_matrix(int _included_file_24316, int _from_file_24317)
{
    int _add_public_24327 = NOVALUE;
    int _px_24345 = NOVALUE;
    int _indirect_24404 = NOVALUE;
    int _mask_24407 = NOVALUE;
    int _ix_24418 = NOVALUE;
    int _indirect_file_24422 = NOVALUE;
    int _13961 = NOVALUE;
    int _13960 = NOVALUE;
    int _13958 = NOVALUE;
    int _13957 = NOVALUE;
    int _13956 = NOVALUE;
    int _13955 = NOVALUE;
    int _13954 = NOVALUE;
    int _13953 = NOVALUE;
    int _13952 = NOVALUE;
    int _13951 = NOVALUE;
    int _13950 = NOVALUE;
    int _13947 = NOVALUE;
    int _13945 = NOVALUE;
    int _13944 = NOVALUE;
    int _13943 = NOVALUE;
    int _13941 = NOVALUE;
    int _13939 = NOVALUE;
    int _13938 = NOVALUE;
    int _13936 = NOVALUE;
    int _13935 = NOVALUE;
    int _13934 = NOVALUE;
    int _13933 = NOVALUE;
    int _13932 = NOVALUE;
    int _13930 = NOVALUE;
    int _13929 = NOVALUE;
    int _13928 = NOVALUE;
    int _13927 = NOVALUE;
    int _13926 = NOVALUE;
    int _13925 = NOVALUE;
    int _13923 = NOVALUE;
    int _13922 = NOVALUE;
    int _13921 = NOVALUE;
    int _13919 = NOVALUE;
    int _13918 = NOVALUE;
    int _13917 = NOVALUE;
    int _13916 = NOVALUE;
    int _13915 = NOVALUE;
    int _13914 = NOVALUE;
    int _13913 = NOVALUE;
    int _13912 = NOVALUE;
    int _13911 = NOVALUE;
    int _13910 = NOVALUE;
    int _13909 = NOVALUE;
    int _13907 = NOVALUE;
    int _13906 = NOVALUE;
    int _13904 = NOVALUE;
    int _13902 = NOVALUE;
    int _13900 = NOVALUE;
    int _13899 = NOVALUE;
    int _13898 = NOVALUE;
    int _13897 = NOVALUE;
    int _13895 = NOVALUE;
    int _13894 = NOVALUE;
    int _13893 = NOVALUE;
    int _13891 = NOVALUE;
    int _13890 = NOVALUE;
    int _13889 = NOVALUE;
    int _13887 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    _3 = (int)(_from_file_24317 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13889 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    _2 = (int)SEQ_PTR(_13889);
    _13890 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
    _13889 = NOVALUE;
    if (IS_ATOM_INT(_13890)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_13890;
             _13891 = MAKE_UINT(tu);
        }
    }
    else {
        _13891 = binary_op(OR_BITS, 2, _13890);
    }
    _13890 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24316);
    _1 = *(int *)_2;
    *(int *)_2 = _13891;
    if( _1 != _13891 ){
        DeRef(_1);
    }
    _13891 = NOVALUE;
    _13887 = NOVALUE;

    /** 	if public_include then*/
    if (_60public_include_23567 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** 		sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_24327);
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _add_public_24327 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    Ref(_add_public_24327);

    /** 		for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_24327)){
            _13893 = SEQ_PTR(_add_public_24327)->length;
    }
    else {
        _13893 = 1;
    }
    {
        int _i_24331;
        _i_24331 = 1;
L2: 
        if (_i_24331 > _13893){
            goto L3; // [56] 107
        }

        /** 			include_matrix[add_public[i]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13894 = (int)*(((s1_ptr)_2)->base + _i_24331);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13include_matrix_10643 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13894))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13894)->dbl));
        else
        _3 = (int)(_13894 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13897 = (int)*(((s1_ptr)_2)->base + _i_24331);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!IS_ATOM_INT(_13897)){
            _13898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13897)->dbl));
        }
        else{
            _13898 = (int)*(((s1_ptr)_2)->base + _13897);
        }
        _2 = (int)SEQ_PTR(_13898);
        _13899 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
        _13898 = NOVALUE;
        if (IS_ATOM_INT(_13899)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13899;
                 _13900 = MAKE_UINT(tu);
            }
        }
        else {
            _13900 = binary_op(OR_BITS, 4, _13899);
        }
        _13899 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24316);
        _1 = *(int *)_2;
        *(int *)_2 = _13900;
        if( _1 != _13900 ){
            DeRef(_1);
        }
        _13900 = NOVALUE;
        _13895 = NOVALUE;

        /** 		end for*/
        _i_24331 = _i_24331 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** 		add_public = file_public_by[from_file]*/
    DeRef(_add_public_24327);
    _2 = (int)SEQ_PTR(_13file_public_by_10653);
    _add_public_24327 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    Ref(_add_public_24327);

    /** 		integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_24327)){
            _13902 = SEQ_PTR(_add_public_24327)->length;
    }
    else {
        _13902 = 1;
    }
    _px_24345 = _13902 + 1;
    _13902 = NOVALUE;

    /** 		while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_24327)){
            _13904 = SEQ_PTR(_add_public_24327)->length;
    }
    else {
        _13904 = 1;
    }
    if (_px_24345 > _13904)
    goto L5; // [134] 338

    /** 			include_matrix[add_public[px]][included_file] =*/
    _2 = (int)SEQ_PTR(_add_public_24327);
    _13906 = (int)*(((s1_ptr)_2)->base + _px_24345);
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13906))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13906)->dbl));
    else
    _3 = (int)(_13906 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_add_public_24327);
    _13909 = (int)*(((s1_ptr)_2)->base + _px_24345);
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!IS_ATOM_INT(_13909)){
        _13910 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13909)->dbl));
    }
    else{
        _13910 = (int)*(((s1_ptr)_2)->base + _13909);
    }
    _2 = (int)SEQ_PTR(_13910);
    _13911 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
    _13910 = NOVALUE;
    if (IS_ATOM_INT(_13911)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_13911;
             _13912 = MAKE_UINT(tu);
        }
    }
    else {
        _13912 = binary_op(OR_BITS, 4, _13911);
    }
    _13911 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24316);
    _1 = *(int *)_2;
    *(int *)_2 = _13912;
    if( _1 != _13912 ){
        DeRef(_1);
    }
    _13912 = NOVALUE;
    _13907 = NOVALUE;

    /** 			for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24327);
    _13913 = (int)*(((s1_ptr)_2)->base + _px_24345);
    _2 = (int)SEQ_PTR(_13file_public_by_10653);
    if (!IS_ATOM_INT(_13913)){
        _13914 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13913)->dbl));
    }
    else{
        _13914 = (int)*(((s1_ptr)_2)->base + _13913);
    }
    if (IS_SEQUENCE(_13914)){
            _13915 = SEQ_PTR(_13914)->length;
    }
    else {
        _13915 = 1;
    }
    _13914 = NOVALUE;
    {
        int _i_24362;
        _i_24362 = 1;
L6: 
        if (_i_24362 > _13915){
            goto L7; // [190] 249
        }

        /** 				if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13916 = (int)*(((s1_ptr)_2)->base + _px_24345);
        _2 = (int)SEQ_PTR(_13file_public_10649);
        if (!IS_ATOM_INT(_13916)){
            _13917 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13916)->dbl));
        }
        else{
            _13917 = (int)*(((s1_ptr)_2)->base + _13916);
        }
        _2 = (int)SEQ_PTR(_13917);
        _13918 = (int)*(((s1_ptr)_2)->base + _i_24362);
        _13917 = NOVALUE;
        _13919 = find_from(_13918, _add_public_24327, 1);
        _13918 = NOVALUE;
        if (_13919 != 0)
        goto L8; // [218] 242
        _13919 = NOVALUE;

        /** 					add_public &= file_public[add_public[px]][i]*/
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13921 = (int)*(((s1_ptr)_2)->base + _px_24345);
        _2 = (int)SEQ_PTR(_13file_public_10649);
        if (!IS_ATOM_INT(_13921)){
            _13922 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13921)->dbl));
        }
        else{
            _13922 = (int)*(((s1_ptr)_2)->base + _13921);
        }
        _2 = (int)SEQ_PTR(_13922);
        _13923 = (int)*(((s1_ptr)_2)->base + _i_24362);
        _13922 = NOVALUE;
        if (IS_SEQUENCE(_add_public_24327) && IS_ATOM(_13923)) {
            Ref(_13923);
            Append(&_add_public_24327, _add_public_24327, _13923);
        }
        else if (IS_ATOM(_add_public_24327) && IS_SEQUENCE(_13923)) {
        }
        else {
            Concat((object_ptr)&_add_public_24327, _add_public_24327, _13923);
        }
        _13923 = NOVALUE;
L8: 

        /** 			end for*/
        _i_24362 = _i_24362 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** 			for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24327);
    _13925 = (int)*(((s1_ptr)_2)->base + _px_24345);
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    if (!IS_ATOM_INT(_13925)){
        _13926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13925)->dbl));
    }
    else{
        _13926 = (int)*(((s1_ptr)_2)->base + _13925);
    }
    if (IS_SEQUENCE(_13926)){
            _13927 = SEQ_PTR(_13926)->length;
    }
    else {
        _13927 = 1;
    }
    _13926 = NOVALUE;
    {
        int _i_24380;
        _i_24380 = 1;
L9: 
        if (_i_24380 > _13927){
            goto LA; // [264] 327
        }

        /** 				include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13928 = (int)*(((s1_ptr)_2)->base + _px_24345);
        _2 = (int)SEQ_PTR(_13file_include_by_10651);
        if (!IS_ATOM_INT(_13928)){
            _13929 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13928)->dbl));
        }
        else{
            _13929 = (int)*(((s1_ptr)_2)->base + _13928);
        }
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13include_matrix_10643 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13929))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13929)->dbl));
        else
        _3 = (int)(_13929 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24327);
        _13932 = (int)*(((s1_ptr)_2)->base + _px_24345);
        _2 = (int)SEQ_PTR(_13file_include_by_10651);
        if (!IS_ATOM_INT(_13932)){
            _13933 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13932)->dbl));
        }
        else{
            _13933 = (int)*(((s1_ptr)_2)->base + _13932);
        }
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!IS_ATOM_INT(_13933)){
            _13934 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13933)->dbl));
        }
        else{
            _13934 = (int)*(((s1_ptr)_2)->base + _13933);
        }
        _2 = (int)SEQ_PTR(_13934);
        _13935 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
        _13934 = NOVALUE;
        if (IS_ATOM_INT(_13935)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13935;
                 _13936 = MAKE_UINT(tu);
            }
        }
        else {
            _13936 = binary_op(OR_BITS, 4, _13935);
        }
        _13935 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24316);
        _1 = *(int *)_2;
        *(int *)_2 = _13936;
        if( _1 != _13936 ){
            DeRef(_1);
        }
        _13936 = NOVALUE;
        _13930 = NOVALUE;

        /** 			end for*/
        _i_24380 = _i_24380 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** 			px += 1*/
    _px_24345 = _px_24345 + 1;

    /** 		end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_24327);
    _add_public_24327 = NOVALUE;

    /** 	if indirect_include[from_file][included_file] then*/
    _2 = (int)SEQ_PTR(_13indirect_include_10646);
    _13938 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    _2 = (int)SEQ_PTR(_13938);
    _13939 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
    _13938 = NOVALUE;
    if (_13939 == 0) {
        _13939 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_13939) && DBL_PTR(_13939)->dbl == 0.0){
            _13939 = NOVALUE;
            goto LB; // [353] 545
        }
        _13939 = NOVALUE;
    }
    _13939 = NOVALUE;

    /** 		sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_24404);
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _indirect_24404 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    Ref(_indirect_24404);

    /** 		sequence mask = include_matrix[included_file] != 0*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13941 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
    DeRef(_mask_24407);
    if (IS_ATOM_INT(_13941)) {
        _mask_24407 = (_13941 != 0);
    }
    else {
        _mask_24407 = binary_op(NOTEQ, _13941, 0);
    }
    _13941 = NOVALUE;

    /** 		include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13943 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    _13944 = binary_op(OR_BITS, _13943, _mask_24407);
    _13943 = NOVALUE;
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _2 = (int)(((s1_ptr)_2)->base + _from_file_24317);
    _1 = *(int *)_2;
    *(int *)_2 = _13944;
    if( _1 != _13944 ){
        DeRef(_1);
    }
    _13944 = NOVALUE;

    /** 		mask = include_matrix[from_file] != 0*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13945 = (int)*(((s1_ptr)_2)->base + _from_file_24317);
    DeRefDS(_mask_24407);
    if (IS_ATOM_INT(_13945)) {
        _mask_24407 = (_13945 != 0);
    }
    else {
        _mask_24407 = binary_op(NOTEQ, _13945, 0);
    }
    _13945 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_24418 = 1;

    /** 		while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_24404)){
            _13947 = SEQ_PTR(_indirect_24404)->length;
    }
    else {
        _13947 = 1;
    }
    if (_ix_24418 > _13947)
    goto LD; // [425] 544

    /** 			integer indirect_file = indirect[ix]*/
    _2 = (int)SEQ_PTR(_indirect_24404);
    _indirect_file_24422 = (int)*(((s1_ptr)_2)->base + _ix_24418);
    if (!IS_ATOM_INT(_indirect_file_24422))
    _indirect_file_24422 = (long)DBL_PTR(_indirect_file_24422)->dbl;

    /** 			if indirect_include[indirect_file][included_file] then*/
    _2 = (int)SEQ_PTR(_13indirect_include_10646);
    _13950 = (int)*(((s1_ptr)_2)->base + _indirect_file_24422);
    _2 = (int)SEQ_PTR(_13950);
    _13951 = (int)*(((s1_ptr)_2)->base + _included_file_24316);
    _13950 = NOVALUE;
    if (_13951 == 0) {
        _13951 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_13951) && DBL_PTR(_13951)->dbl == 0.0){
            _13951 = NOVALUE;
            goto LE; // [447] 531
        }
        _13951 = NOVALUE;
    }
    _13951 = NOVALUE;

    /** 				include_matrix[indirect_file] =*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13952 = (int)*(((s1_ptr)_2)->base + _indirect_file_24422);
    _13953 = binary_op(OR_BITS, _mask_24407, _13952);
    _13952 = NOVALUE;
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _2 = (int)(((s1_ptr)_2)->base + _indirect_file_24422);
    _1 = *(int *)_2;
    *(int *)_2 = _13953;
    if( _1 != _13953 ){
        DeRef(_1);
    }
    _13953 = NOVALUE;

    /** 				for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _13954 = (int)*(((s1_ptr)_2)->base + _indirect_file_24422);
    if (IS_SEQUENCE(_13954)){
            _13955 = SEQ_PTR(_13954)->length;
    }
    else {
        _13955 = 1;
    }
    _13954 = NOVALUE;
    {
        int _i_24433;
        _i_24433 = 1;
LF: 
        if (_i_24433 > _13955){
            goto L10; // [479] 530
        }

        /** 					if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (int)SEQ_PTR(_13file_include_by_10651);
        _13956 = (int)*(((s1_ptr)_2)->base + _indirect_file_24422);
        _2 = (int)SEQ_PTR(_13956);
        _13957 = (int)*(((s1_ptr)_2)->base + _i_24433);
        _13956 = NOVALUE;
        _13958 = find_from(_13957, _indirect_24404, 1);
        _13957 = NOVALUE;
        if (_13958 != 0)
        goto L11; // [503] 523
        _13958 = NOVALUE;

        /** 						indirect &= file_include_by[indirect_file][i]*/
        _2 = (int)SEQ_PTR(_13file_include_by_10651);
        _13960 = (int)*(((s1_ptr)_2)->base + _indirect_file_24422);
        _2 = (int)SEQ_PTR(_13960);
        _13961 = (int)*(((s1_ptr)_2)->base + _i_24433);
        _13960 = NOVALUE;
        if (IS_SEQUENCE(_indirect_24404) && IS_ATOM(_13961)) {
            Ref(_13961);
            Append(&_indirect_24404, _indirect_24404, _13961);
        }
        else if (IS_ATOM(_indirect_24404) && IS_SEQUENCE(_13961)) {
        }
        else {
            Concat((object_ptr)&_indirect_24404, _indirect_24404, _13961);
        }
        _13961 = NOVALUE;
L11: 

        /** 				end for*/
        _i_24433 = _i_24433 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** 			ix += 1*/
    _ix_24418 = _ix_24418 + 1;

    /** 		end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_24404);
    _indirect_24404 = NOVALUE;
    DeRef(_mask_24407);
    _mask_24407 = NOVALUE;

    /** 	public_include = FALSE*/
    _60public_include_23567 = _9FALSE_429;

    /** end procedure*/
    _13894 = NOVALUE;
    _13906 = NOVALUE;
    _13897 = NOVALUE;
    _13913 = NOVALUE;
    _13909 = NOVALUE;
    _13914 = NOVALUE;
    _13916 = NOVALUE;
    _13921 = NOVALUE;
    _13925 = NOVALUE;
    _13926 = NOVALUE;
    _13928 = NOVALUE;
    _13929 = NOVALUE;
    _13954 = NOVALUE;
    _13932 = NOVALUE;
    _13933 = NOVALUE;
    return;
    ;
}


void _60add_include_by(int _by_file_24451, int _included_file_24452, int _is_public_24453)
{
    int _14008 = NOVALUE;
    int _14007 = NOVALUE;
    int _14006 = NOVALUE;
    int _14004 = NOVALUE;
    int _14003 = NOVALUE;
    int _14002 = NOVALUE;
    int _14001 = NOVALUE;
    int _13999 = NOVALUE;
    int _13998 = NOVALUE;
    int _13997 = NOVALUE;
    int _13996 = NOVALUE;
    int _13995 = NOVALUE;
    int _13994 = NOVALUE;
    int _13993 = NOVALUE;
    int _13992 = NOVALUE;
    int _13990 = NOVALUE;
    int _13989 = NOVALUE;
    int _13988 = NOVALUE;
    int _13987 = NOVALUE;
    int _13985 = NOVALUE;
    int _13984 = NOVALUE;
    int _13983 = NOVALUE;
    int _13982 = NOVALUE;
    int _13980 = NOVALUE;
    int _13979 = NOVALUE;
    int _13978 = NOVALUE;
    int _13977 = NOVALUE;
    int _13975 = NOVALUE;
    int _13974 = NOVALUE;
    int _13973 = NOVALUE;
    int _13972 = NOVALUE;
    int _13971 = NOVALUE;
    int _13969 = NOVALUE;
    int _13968 = NOVALUE;
    int _13967 = NOVALUE;
    int _13966 = NOVALUE;
    int _13964 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24451 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13966 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    _2 = (int)SEQ_PTR(_13966);
    _13967 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    _13966 = NOVALUE;
    if (IS_ATOM_INT(_13967)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_13967;
             _13968 = MAKE_UINT(tu);
        }
    }
    else {
        _13968 = binary_op(OR_BITS, 2, _13967);
    }
    _13967 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24452);
    _1 = *(int *)_2;
    *(int *)_2 = _13968;
    if( _1 != _13968 ){
        DeRef(_1);
    }
    _13968 = NOVALUE;
    _13964 = NOVALUE;

    /** 	if is_public then*/
    if (_is_public_24453 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** 		include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24451 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13971 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    _2 = (int)SEQ_PTR(_13971);
    _13972 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    _13971 = NOVALUE;
    if (IS_ATOM_INT(_13972)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_13972;
             _13973 = MAKE_UINT(tu);
        }
    }
    else {
        _13973 = binary_op(OR_BITS, 4, _13972);
    }
    _13972 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24452);
    _1 = *(int *)_2;
    *(int *)_2 = _13973;
    if( _1 != _13973 ){
        DeRef(_1);
    }
    _13973 = NOVALUE;
    _13969 = NOVALUE;
L1: 

    /** 	if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _13974 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    _13975 = find_from(_by_file_24451, _13974, 1);
    _13974 = NOVALUE;
    if (_13975 != 0)
    goto L2; // [84] 104
    _13975 = NOVALUE;

    /** 		file_include_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _13977 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    if (IS_SEQUENCE(_13977) && IS_ATOM(_by_file_24451)) {
        Append(&_13978, _13977, _by_file_24451);
    }
    else if (IS_ATOM(_13977) && IS_SEQUENCE(_by_file_24451)) {
    }
    else {
        Concat((object_ptr)&_13978, _13977, _by_file_24451);
        _13977 = NOVALUE;
    }
    _13977 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_by_10651);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24452);
    _1 = *(int *)_2;
    *(int *)_2 = _13978;
    if( _1 != _13978 ){
        DeRef(_1);
    }
    _13978 = NOVALUE;
L2: 

    /** 	if not find( included_file, file_include[by_file] ) then*/
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _13979 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    _13980 = find_from(_included_file_24452, _13979, 1);
    _13979 = NOVALUE;
    if (_13980 != 0)
    goto L3; // [117] 137
    _13980 = NOVALUE;

    /** 		file_include[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _13982 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    if (IS_SEQUENCE(_13982) && IS_ATOM(_included_file_24452)) {
        Append(&_13983, _13982, _included_file_24452);
    }
    else if (IS_ATOM(_13982) && IS_SEQUENCE(_included_file_24452)) {
    }
    else {
        Concat((object_ptr)&_13983, _13982, _included_file_24452);
        _13982 = NOVALUE;
    }
    _13982 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24451);
    _1 = *(int *)_2;
    *(int *)_2 = _13983;
    if( _1 != _13983 ){
        DeRef(_1);
    }
    _13983 = NOVALUE;
L3: 

    /** 	if is_public then*/
    if (_is_public_24453 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** 		if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_13file_public_by_10653);
    _13984 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    _13985 = find_from(_by_file_24451, _13984, 1);
    _13984 = NOVALUE;
    if (_13985 != 0)
    goto L5; // [155] 175
    _13985 = NOVALUE;

    /** 			file_public_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_13file_public_by_10653);
    _13987 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    if (IS_SEQUENCE(_13987) && IS_ATOM(_by_file_24451)) {
        Append(&_13988, _13987, _by_file_24451);
    }
    else if (IS_ATOM(_13987) && IS_SEQUENCE(_by_file_24451)) {
    }
    else {
        Concat((object_ptr)&_13988, _13987, _by_file_24451);
        _13987 = NOVALUE;
    }
    _13987 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_public_by_10653);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24452);
    _1 = *(int *)_2;
    *(int *)_2 = _13988;
    if( _1 != _13988 ){
        DeRef(_1);
    }
    _13988 = NOVALUE;
L5: 

    /** 		if not find( included_file, file_public[by_file] ) then*/
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _13989 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    _13990 = find_from(_included_file_24452, _13989, 1);
    _13989 = NOVALUE;
    if (_13990 != 0)
    goto L6; // [188] 208
    _13990 = NOVALUE;

    /** 			file_public[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _13992 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
    if (IS_SEQUENCE(_13992) && IS_ATOM(_included_file_24452)) {
        Append(&_13993, _13992, _included_file_24452);
    }
    else if (IS_ATOM(_13992) && IS_SEQUENCE(_included_file_24452)) {
    }
    else {
        Concat((object_ptr)&_13993, _13992, _included_file_24452);
        _13992 = NOVALUE;
    }
    _13992 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24451);
    _1 = *(int *)_2;
    *(int *)_2 = _13993;
    if( _1 != _13993 ){
        DeRef(_1);
    }
    _13993 = NOVALUE;
L6: 
L4: 

    /** 	for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _13994 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
    if (IS_SEQUENCE(_13994)){
            _13995 = SEQ_PTR(_13994)->length;
    }
    else {
        _13995 = 1;
    }
    _13994 = NOVALUE;
    {
        int _propagate_24505;
        _propagate_24505 = 1;
L7: 
        if (_propagate_24505 > _13995){
            goto L8; // [220] 320
        }

        /** 		if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _13996 = (int)*(((s1_ptr)_2)->base + _included_file_24452);
        _2 = (int)SEQ_PTR(_13996);
        _13997 = (int)*(((s1_ptr)_2)->base + _propagate_24505);
        _13996 = NOVALUE;
        if (IS_ATOM_INT(_13997)) {
            {unsigned long tu;
                 tu = (unsigned long)4 & (unsigned long)_13997;
                 _13998 = MAKE_UINT(tu);
            }
        }
        else {
            _13998 = binary_op(AND_BITS, 4, _13997);
        }
        _13997 = NOVALUE;
        if (_13998 == 0) {
            DeRef(_13998);
            _13998 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_13998) && DBL_PTR(_13998)->dbl == 0.0){
                DeRef(_13998);
                _13998 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_13998);
            _13998 = NOVALUE;
        }
        DeRef(_13998);
        _13998 = NOVALUE;

        /** 			include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13include_matrix_10643 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24451 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _14001 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
        _2 = (int)SEQ_PTR(_14001);
        _14002 = (int)*(((s1_ptr)_2)->base + _propagate_24505);
        _14001 = NOVALUE;
        if (IS_ATOM_INT(_14002)) {
            {unsigned long tu;
                 tu = (unsigned long)2 | (unsigned long)_14002;
                 _14003 = MAKE_UINT(tu);
            }
        }
        else {
            _14003 = binary_op(OR_BITS, 2, _14002);
        }
        _14002 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24505);
        _1 = *(int *)_2;
        *(int *)_2 = _14003;
        if( _1 != _14003 ){
            DeRef(_1);
        }
        _14003 = NOVALUE;
        _13999 = NOVALUE;

        /** 			if is_public then*/
        if (_is_public_24453 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** 				include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13include_matrix_10643 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24451 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _14006 = (int)*(((s1_ptr)_2)->base + _by_file_24451);
        _2 = (int)SEQ_PTR(_14006);
        _14007 = (int)*(((s1_ptr)_2)->base + _propagate_24505);
        _14006 = NOVALUE;
        if (IS_ATOM_INT(_14007)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14007;
                 _14008 = MAKE_UINT(tu);
            }
        }
        else {
            _14008 = binary_op(OR_BITS, 4, _14007);
        }
        _14007 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24505);
        _1 = *(int *)_2;
        *(int *)_2 = _14008;
        if( _1 != _14008 ){
            DeRef(_1);
        }
        _14008 = NOVALUE;
        _14004 = NOVALUE;
LA: 
L9: 

        /** 	end for*/
        _propagate_24505 = _propagate_24505 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** end procedure*/
    _13994 = NOVALUE;
    return;
    ;
}


void _60IncludePush()
{
    int _new_file_handle_24534 = NOVALUE;
    int _old_file_no_24535 = NOVALUE;
    int _new_hash_24536 = NOVALUE;
    int _idx_24537 = NOVALUE;
    int _14095 = NOVALUE;
    int _14092 = NOVALUE;
    int _14090 = NOVALUE;
    int _14089 = NOVALUE;
    int _14088 = NOVALUE;
    int _14086 = NOVALUE;
    int _14085 = NOVALUE;
    int _14079 = NOVALUE;
    int _14078 = NOVALUE;
    int _14077 = NOVALUE;
    int _14076 = NOVALUE;
    int _14075 = NOVALUE;
    int _14074 = NOVALUE;
    int _14073 = NOVALUE;
    int _14070 = NOVALUE;
    int _14068 = NOVALUE;
    int _14066 = NOVALUE;
    int _14065 = NOVALUE;
    int _14064 = NOVALUE;
    int _14062 = NOVALUE;
    int _14061 = NOVALUE;
    int _14059 = NOVALUE;
    int _14058 = NOVALUE;
    int _14056 = NOVALUE;
    int _14055 = NOVALUE;
    int _14054 = NOVALUE;
    int _14053 = NOVALUE;
    int _14052 = NOVALUE;
    int _14051 = NOVALUE;
    int _14050 = NOVALUE;
    int _14046 = NOVALUE;
    int _14044 = NOVALUE;
    int _14043 = NOVALUE;
    int _14042 = NOVALUE;
    int _14041 = NOVALUE;
    int _14040 = NOVALUE;
    int _14039 = NOVALUE;
    int _14038 = NOVALUE;
    int _14037 = NOVALUE;
    int _14036 = NOVALUE;
    int _14034 = NOVALUE;
    int _14033 = NOVALUE;
    int _14032 = NOVALUE;
    int _14030 = NOVALUE;
    int _14029 = NOVALUE;
    int _14028 = NOVALUE;
    int _14027 = NOVALUE;
    int _14025 = NOVALUE;
    int _14024 = NOVALUE;
    int _14023 = NOVALUE;
    int _14022 = NOVALUE;
    int _14021 = NOVALUE;
    int _14019 = NOVALUE;
    int _14018 = NOVALUE;
    int _14017 = NOVALUE;
    int _14016 = NOVALUE;
    int _14014 = NOVALUE;
    int _14010 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	start_include = FALSE*/
    _60start_include_23564 = _9FALSE_429;

    /** 	new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_24534 = _60path_open();
    if (!IS_ATOM_INT(_new_file_handle_24534)) {
        _1 = (long)(DBL_PTR(_new_file_handle_24534)->dbl);
        DeRefDS(_new_file_handle_24534);
        _new_file_handle_24534 = _1;
    }

    /** 	new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_12new_include_name_11805);
    _14010 = _14canonical_path(_12new_include_name_11805, 0, 2);
    DeRef(_new_hash_24536);
    _new_hash_24536 = calc_hash(_14010, -5);
    DeRef(_14010);
    _14010 = NOVALUE;

    /** 	idx = find(new_hash, known_files_hash)*/
    _idx_24537 = find_from(_new_hash_24536, _13known_files_hash_10638, 1);

    /** 	if idx then*/
    if (_idx_24537 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** 		if new_include_space != 0 then*/
    if (_60new_include_space_23562 == 0)
    goto L2; // [49] 71

    /** 			SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_60new_include_space_23562 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24537;
    DeRef(_1);
    _14014 = NOVALUE;
L2: 

    /** 		close(new_file_handle)*/
    EClose(_new_file_handle_24534);

    /** 		if find( -idx, file_include[current_file_no] ) then*/
    if ((unsigned long)_idx_24537 == 0xC0000000)
    _14016 = (int)NewDouble((double)-0xC0000000);
    else
    _14016 = - _idx_24537;
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _14017 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _14018 = find_from(_14016, _14017, 1);
    DeRef(_14016);
    _14016 = NOVALUE;
    _14017 = NOVALUE;
    if (_14018 == 0)
    {
        _14018 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14018 = NOVALUE;
    }

    /** 			file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (int)SEQ_PTR(_13file_include_10641);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13file_include_10641 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12current_file_no_11682 + ((s1_ptr)_2)->base);
    if ((unsigned long)_idx_24537 == 0xC0000000)
    _14021 = (int)NewDouble((double)-0xC0000000);
    else
    _14021 = - _idx_24537;
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _14022 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _14023 = find_from(_14021, _14022, 1);
    DeRef(_14021);
    _14021 = NOVALUE;
    _14022 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14023);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24537;
    DeRef(_1);
    _14019 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** 		elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _14024 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _14025 = find_from(_idx_24537, _14024, 1);
    _14024 = NOVALUE;
    if (_14025 != 0)
    goto L5; // [145] 227
    _14025 = NOVALUE;

    /** 			file_include[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _14027 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14027) && IS_ATOM(_idx_24537)) {
        Append(&_14028, _14027, _idx_24537);
    }
    else if (IS_ATOM(_14027) && IS_SEQUENCE(_idx_24537)) {
    }
    else {
        Concat((object_ptr)&_14028, _14027, _idx_24537);
        _14027 = NOVALUE;
    }
    _14027 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14028;
    if( _1 != _14028 ){
        DeRef(_1);
    }
    _14028 = NOVALUE;

    /** 			add_exports( idx, current_file_no )*/
    _60add_exports(_idx_24537, _12current_file_no_11682);

    /** 			if public_include then*/
    if (_60public_include_23567 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** 				if not find( idx, file_public[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _14029 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _14030 = find_from(_idx_24537, _14029, 1);
    _14029 = NOVALUE;
    if (_14030 != 0)
    goto L7; // [196] 225
    _14030 = NOVALUE;

    /** 					file_public[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _14032 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14032) && IS_ATOM(_idx_24537)) {
        Append(&_14033, _14032, _idx_24537);
    }
    else if (IS_ATOM(_14032) && IS_SEQUENCE(_idx_24537)) {
    }
    else {
        Concat((object_ptr)&_14033, _14032, _idx_24537);
        _14032 = NOVALUE;
    }
    _14032 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14033;
    if( _1 != _14033 ){
        DeRef(_1);
    }
    _14033 = NOVALUE;

    /** 					patch_exports( current_file_no )*/
    _60patch_exports(_12current_file_no_11682);
L7: 
L6: 
L5: 
L4: 

    /** 		indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_13indirect_include_10646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13indirect_include_10646 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12current_file_no_11682 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_24537);
    _1 = *(int *)_2;
    *(int *)_2 = _12OpIndirectInclude_11758;
    DeRef(_1);
    _14034 = NOVALUE;

    /** 		add_include_by( current_file_no, idx, public_include )*/
    _60add_include_by(_12current_file_no_11682, _idx_24537, _60public_include_23567);

    /** 		update_include_matrix( idx, current_file_no )*/
    _60update_include_matrix(_idx_24537, _12current_file_no_11682);

    /** 		public_include = FALSE*/
    _60public_include_23567 = _9FALSE_429;

    /** 		read_line() -- we can't return without reading a line first*/
    _60read_line();

    /** 		if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (int)SEQ_PTR(_13file_include_depend_10640);
    _14036 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _14037 = find_from(_idx_24537, _14036, 1);
    _14036 = NOVALUE;
    _14038 = (_14037 == 0);
    _14037 = NOVALUE;
    if (_14038 == 0) {
        goto L8; // [293] 329
    }
    _2 = (int)SEQ_PTR(_13finished_files_10639);
    _14040 = (int)*(((s1_ptr)_2)->base + _idx_24537);
    _14041 = (_14040 == 0);
    _14040 = NOVALUE;
    if (_14041 == 0)
    {
        DeRef(_14041);
        _14041 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14041);
        _14041 = NOVALUE;
    }

    /** 			file_include_depend[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_13file_include_depend_10640);
    _14042 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14042) && IS_ATOM(_idx_24537)) {
        Append(&_14043, _14042, _idx_24537);
    }
    else if (IS_ATOM(_14042) && IS_SEQUENCE(_idx_24537)) {
    }
    else {
        Concat((object_ptr)&_14043, _14042, _idx_24537);
        _14042 = NOVALUE;
    }
    _14042 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_depend_10640);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13file_include_depend_10640 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14043;
    if( _1 != _14043 ){
        DeRef(_1);
    }
    _14043 = NOVALUE;
L8: 

    /** 		return -- ignore it*/
    DeRef(_new_hash_24536);
    DeRef(_14038);
    _14038 = NOVALUE;
    return;
L1: 

    /** 	if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_60IncludeStk_23573)){
            _14044 = SEQ_PTR(_60IncludeStk_23573)->length;
    }
    else {
        _14044 = 1;
    }
    if (_14044 < 30)
    goto L9; // [342] 354

    /** 		CompileErr(104)*/
    RefDS(_21829);
    _43CompileErr(104, _21829, 0);
L9: 

    /** 	IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12current_file_no_11682;
    *((int *)(_2+8)) = _12line_number_11683;
    *((int *)(_2+12)) = _12src_file_11804;
    *((int *)(_2+16)) = _12file_start_sym_11688;
    *((int *)(_2+20)) = _12OpWarning_11750;
    *((int *)(_2+24)) = _12OpTrace_11752;
    *((int *)(_2+28)) = _12OpTypeCheck_11753;
    *((int *)(_2+32)) = _12OpProfileTime_11755;
    *((int *)(_2+36)) = _12OpProfileStatement_11754;
    RefDS(_12OpDefines_11756);
    *((int *)(_2+40)) = _12OpDefines_11756;
    *((int *)(_2+44)) = _12prev_OpWarning_11751;
    *((int *)(_2+48)) = _12OpInline_11757;
    *((int *)(_2+52)) = _12OpIndirectInclude_11758;
    *((int *)(_2+56)) = _12putback_fwd_line_number_11685;
    Ref(_43putback_ForwardLine_48160);
    *((int *)(_2+60)) = _43putback_ForwardLine_48160;
    *((int *)(_2+64)) = _43putback_forward_bp_48164;
    *((int *)(_2+68)) = _12last_fwd_line_number_11686;
    Ref(_43last_ForwardLine_48161);
    *((int *)(_2+72)) = _43last_ForwardLine_48161;
    *((int *)(_2+76)) = _43last_forward_bp_48165;
    Ref(_43ThisLine_48158);
    *((int *)(_2+80)) = _43ThisLine_48158;
    *((int *)(_2+84)) = _12fwd_line_number_11684;
    *((int *)(_2+88)) = _43forward_bp_48163;
    _14046 = MAKE_SEQ(_1);
    RefDS(_14046);
    Append(&_60IncludeStk_23573, _60IncludeStk_23573, _14046);
    DeRefDS(_14046);
    _14046 = NOVALUE;

    /** 	file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_13file_include_10641, _13file_include_10641, _5);

    /** 	file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_13file_include_by_10651, _13file_include_by_10651, _5);

    /** 	for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_13include_matrix_10643)){
            _14050 = SEQ_PTR(_13include_matrix_10643)->length;
    }
    else {
        _14050 = 1;
    }
    {
        int _i_24649;
        _i_24649 = 1;
LA: 
        if (_i_24649 > _14050){
            goto LB; // [458] 504
        }

        /** 		include_matrix[i]   &= 0*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _14051 = (int)*(((s1_ptr)_2)->base + _i_24649);
        if (IS_SEQUENCE(_14051) && IS_ATOM(0)) {
            Append(&_14052, _14051, 0);
        }
        else if (IS_ATOM(_14051) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14052, _14051, 0);
            _14051 = NOVALUE;
        }
        _14051 = NOVALUE;
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _2 = (int)(((s1_ptr)_2)->base + _i_24649);
        _1 = *(int *)_2;
        *(int *)_2 = _14052;
        if( _1 != _14052 ){
            DeRef(_1);
        }
        _14052 = NOVALUE;

        /** 		indirect_include[i] &= 0*/
        _2 = (int)SEQ_PTR(_13indirect_include_10646);
        _14053 = (int)*(((s1_ptr)_2)->base + _i_24649);
        if (IS_SEQUENCE(_14053) && IS_ATOM(0)) {
            Append(&_14054, _14053, 0);
        }
        else if (IS_ATOM(_14053) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14054, _14053, 0);
            _14053 = NOVALUE;
        }
        _14053 = NOVALUE;
        _2 = (int)SEQ_PTR(_13indirect_include_10646);
        _2 = (int)(((s1_ptr)_2)->base + _i_24649);
        _1 = *(int *)_2;
        *(int *)_2 = _14054;
        if( _1 != _14054 ){
            DeRef(_1);
        }
        _14054 = NOVALUE;

        /** 	end for*/
        _i_24649 = _i_24649 + 1;
        goto LA; // [499] 465
LB: 
        ;
    }

    /** 	include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _14055 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _14055 = 1;
    }
    _14056 = Repeat(0, _14055);
    _14055 = NOVALUE;
    RefDS(_14056);
    Append(&_13include_matrix_10643, _13include_matrix_10643, _14056);
    DeRefDS(_14056);
    _14056 = NOVALUE;

    /** 	include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_13include_matrix_10643)){
            _14058 = SEQ_PTR(_13include_matrix_10643)->length;
    }
    else {
        _14058 = 1;
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    _3 = (int)(_14058 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14061 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14061 = 1;
    }
    _14059 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14061);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14059 = NOVALUE;

    /** 	include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13include_matrix_10643 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12current_file_no_11682 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14064 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14064 = 1;
    }
    _14062 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14064);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14062 = NOVALUE;

    /** 	indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _14065 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _14065 = 1;
    }
    _14066 = Repeat(0, _14065);
    _14065 = NOVALUE;
    RefDS(_14066);
    Append(&_13indirect_include_10646, _13indirect_include_10646, _14066);
    DeRefDS(_14066);
    _14066 = NOVALUE;

    /** 	indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_13indirect_include_10646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13indirect_include_10646 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12current_file_no_11682 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14070 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14070 = 1;
    }
    _14068 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14070);
    _1 = *(int *)_2;
    *(int *)_2 = _12OpIndirectInclude_11758;
    DeRef(_1);
    _14068 = NOVALUE;

    /** 	OpIndirectInclude = 1*/
    _12OpIndirectInclude_11758 = 1;

    /** 	file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_13file_public_10649, _13file_public_10649, _5);

    /** 	file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_13file_public_by_10653, _13file_public_by_10653, _5);

    /** 	file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _14073 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _14073 = 1;
    }
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _14074 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14074) && IS_ATOM(_14073)) {
        Append(&_14075, _14074, _14073);
    }
    else if (IS_ATOM(_14074) && IS_SEQUENCE(_14073)) {
    }
    else {
        Concat((object_ptr)&_14075, _14074, _14073);
        _14074 = NOVALUE;
    }
    _14074 = NOVALUE;
    _14073 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_10641);
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14075;
    if( _1 != _14075 ){
        DeRef(_1);
    }
    _14075 = NOVALUE;

    /** 	add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _14076 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _14076 = 1;
    }
    _60add_include_by(_12current_file_no_11682, _14076, _60public_include_23567);
    _14076 = NOVALUE;

    /** 	if public_include then*/
    if (_60public_include_23567 == 0)
    {
        goto LC; // [673] 707
    }
    else{
    }

    /** 		file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_13file_public_10649)){
            _14077 = SEQ_PTR(_13file_public_10649)->length;
    }
    else {
        _14077 = 1;
    }
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _14078 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14078) && IS_ATOM(_14077)) {
        Append(&_14079, _14078, _14077);
    }
    else if (IS_ATOM(_14078) && IS_SEQUENCE(_14077)) {
    }
    else {
        Concat((object_ptr)&_14079, _14078, _14077);
        _14078 = NOVALUE;
    }
    _14078 = NOVALUE;
    _14077 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_public_10649);
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14079;
    if( _1 != _14079 ){
        DeRef(_1);
    }
    _14079 = NOVALUE;

    /** 		patch_exports( current_file_no )*/
    _60patch_exports(_12current_file_no_11682);
LC: 

    /** ifdef STDDEBUG then*/

    /** 	src_file = new_file_handle*/
    _12src_file_11804 = _new_file_handle_24534;

    /** 	file_start_sym = last_sym*/
    _12file_start_sym_11688 = _52last_sym_45740;

    /** 	if current_file_no >= MAX_FILE then*/
    if (_12current_file_no_11682 < 256)
    goto LD; // [729] 741

    /** 		CompileErr(126)*/
    RefDS(_21829);
    _43CompileErr(126, _21829, 0);
LD: 

    /** 	known_files = append(known_files, new_include_name)*/
    RefDS(_12new_include_name_11805);
    Append(&_13known_files_10637, _13known_files_10637, _12new_include_name_11805);

    /** 	known_files_hash &= new_hash*/
    Ref(_new_hash_24536);
    Append(&_13known_files_hash_10638, _13known_files_hash_10638, _new_hash_24536);

    /** 	finished_files &= 0*/
    Append(&_13finished_files_10639, _13finished_files_10639, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _14085 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _14085 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14085;
    _14086 = MAKE_SEQ(_1);
    _14085 = NOVALUE;
    RefDS(_14086);
    Append(&_13file_include_depend_10640, _13file_include_depend_10640, _14086);
    DeRefDS(_14086);
    _14086 = NOVALUE;

    /** 	file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _14088 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _14088 = 1;
    }
    _2 = (int)SEQ_PTR(_13file_include_depend_10640);
    _14089 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_14089) && IS_ATOM(_14088)) {
        Append(&_14090, _14089, _14088);
    }
    else if (IS_ATOM(_14089) && IS_SEQUENCE(_14088)) {
    }
    else {
        Concat((object_ptr)&_14090, _14089, _14088);
        _14089 = NOVALUE;
    }
    _14089 = NOVALUE;
    _14088 = NOVALUE;
    _2 = (int)SEQ_PTR(_13file_include_depend_10640);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13file_include_depend_10640 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _14090;
    if( _1 != _14090 ){
        DeRef(_1);
    }
    _14090 = NOVALUE;

    /** 	check_coverage()*/
    _49check_coverage();

    /** 	default_namespaces &= 0*/
    Append(&_60default_namespaces_23570, _60default_namespaces_23570, 0);

    /** 	update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_13file_include_10641)){
            _14092 = SEQ_PTR(_13file_include_10641)->length;
    }
    else {
        _14092 = 1;
    }
    _60update_include_matrix(_14092, _12current_file_no_11682);
    _14092 = NOVALUE;

    /** 	old_file_no = current_file_no*/
    _old_file_no_24535 = _12current_file_no_11682;

    /** 	current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _12current_file_no_11682 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _12current_file_no_11682 = 1;
    }

    /** 	line_number = 0*/
    _12line_number_11683 = 0;

    /** 	read_line()*/
    _60read_line();

    /** 	if new_include_space != 0 then*/
    if (_60new_include_space_23562 == 0)
    goto LE; // [873] 897

    /** 		SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_60new_include_space_23562 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);
    _14095 = NOVALUE;
LE: 

    /** 	default_namespace( )*/
    _60default_namespace();

    /** end procedure*/
    DeRef(_new_hash_24536);
    DeRef(_14038);
    _14038 = NOVALUE;
    return;
    ;
}


void _60update_include_completion(int _file_no_24759)
{
    int _fx_24768 = NOVALUE;
    int _14105 = NOVALUE;
    int _14104 = NOVALUE;
    int _14103 = NOVALUE;
    int _14102 = NOVALUE;
    int _14100 = NOVALUE;
    int _14099 = NOVALUE;
    int _14098 = NOVALUE;
    int _14097 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_13file_include_depend_10640)){
            _14097 = SEQ_PTR(_13file_include_depend_10640)->length;
    }
    else {
        _14097 = 1;
    }
    {
        int _i_24761;
        _i_24761 = 1;
L1: 
        if (_i_24761 > _14097){
            goto L2; // [10] 114
        }

        /** 		if length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_13file_include_depend_10640);
        _14098 = (int)*(((s1_ptr)_2)->base + _i_24761);
        if (IS_SEQUENCE(_14098)){
                _14099 = SEQ_PTR(_14098)->length;
        }
        else {
            _14099 = 1;
        }
        _14098 = NOVALUE;
        if (_14099 == 0)
        {
            _14099 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14099 = NOVALUE;
        }

        /** 			integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (int)SEQ_PTR(_13file_include_depend_10640);
        _14100 = (int)*(((s1_ptr)_2)->base + _i_24761);
        _fx_24768 = find_from(_file_no_24759, _14100, 1);
        _14100 = NOVALUE;

        /** 			if fx then*/
        if (_fx_24768 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** 				file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (int)SEQ_PTR(_13file_include_depend_10640);
        _14102 = (int)*(((s1_ptr)_2)->base + _i_24761);
        {
            s1_ptr assign_space = SEQ_PTR(_14102);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_24768)) ? _fx_24768 : (long)(DBL_PTR(_fx_24768)->dbl);
            int stop = (IS_ATOM_INT(_fx_24768)) ? _fx_24768 : (long)(DBL_PTR(_fx_24768)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_14102);
                DeRef(_14103);
                _14103 = _14102;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14102), start, &_14103 );
                }
                else Tail(SEQ_PTR(_14102), stop+1, &_14103);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14102), start, &_14103);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14103);
                _14103 = _1;
            }
        }
        _14102 = NOVALUE;
        _2 = (int)SEQ_PTR(_13file_include_depend_10640);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13file_include_depend_10640 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_24761);
        _1 = *(int *)_2;
        *(int *)_2 = _14103;
        if( _1 != _14103 ){
            DeRef(_1);
        }
        _14103 = NOVALUE;

        /** 				if not length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_13file_include_depend_10640);
        _14104 = (int)*(((s1_ptr)_2)->base + _i_24761);
        if (IS_SEQUENCE(_14104)){
                _14105 = SEQ_PTR(_14104)->length;
        }
        else {
            _14105 = 1;
        }
        _14104 = NOVALUE;
        if (_14105 != 0)
        goto L5; // [79] 103
        _14105 = NOVALUE;

        /** 					finished_files[i] = 1*/
        _2 = (int)SEQ_PTR(_13finished_files_10639);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13finished_files_10639 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_24761);
        *(int *)_2 = 1;

        /** 					if i != file_no then*/
        if (_i_24761 == _file_no_24759)
        goto L6; // [92] 102

        /** 						update_include_completion( i )*/
        _60update_include_completion(_i_24761);
L6: 
L5: 
L4: 
L3: 

        /** 	end for*/
        _i_24761 = _i_24761 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** end procedure*/
    _14098 = NOVALUE;
    _14104 = NOVALUE;
    return;
    ;
}


int _60IncludePop()
{
    int _top_24799 = NOVALUE;
    int _14136 = NOVALUE;
    int _14134 = NOVALUE;
    int _14133 = NOVALUE;
    int _14111 = NOVALUE;
    int _14109 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	update_include_completion( current_file_no )*/
    _60update_include_completion(_12current_file_no_11682);

    /** 	Resolve_forward_references()*/
    _29Resolve_forward_references(0);

    /** 	HideLocals()*/
    _52HideLocals();

    /** 	if src_file >= 0 then*/
    if (_12src_file_11804 < 0)
    goto L1; // [21] 39

    /** 		close(src_file)*/
    EClose(_12src_file_11804);

    /** 		src_file = -1*/
    _12src_file_11804 = -1;
L1: 

    /** 	if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_60IncludeStk_23573)){
            _14109 = SEQ_PTR(_60IncludeStk_23573)->length;
    }
    else {
        _14109 = 1;
    }
    if (_14109 != 0)
    goto L2; // [46] 59

    /** 		return FALSE  -- the end*/
    DeRef(_top_24799);
    return _9FALSE_429;
L2: 

    /** 	sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_60IncludeStk_23573)){
            _14111 = SEQ_PTR(_60IncludeStk_23573)->length;
    }
    else {
        _14111 = 1;
    }
    DeRef(_top_24799);
    _2 = (int)SEQ_PTR(_60IncludeStk_23573);
    _top_24799 = (int)*(((s1_ptr)_2)->base + _14111);
    RefDS(_top_24799);

    /** 	current_file_no    = top[FILE_NO]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12current_file_no_11682 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_12current_file_no_11682)){
        _12current_file_no_11682 = (long)DBL_PTR(_12current_file_no_11682)->dbl;
    }

    /** 	line_number        = top[LINE_NO]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_12line_number_11683)){
        _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
    }

    /** 	src_file           = top[FILE_PTR]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12src_file_11804 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12src_file_11804)){
        _12src_file_11804 = (long)DBL_PTR(_12src_file_11804)->dbl;
    }

    /** 	file_start_sym     = top[FILE_START_SYM]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12file_start_sym_11688 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_12file_start_sym_11688)){
        _12file_start_sym_11688 = (long)DBL_PTR(_12file_start_sym_11688)->dbl;
    }

    /** 	OpWarning          = top[OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpWarning_11750 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_12OpWarning_11750)){
        _12OpWarning_11750 = (long)DBL_PTR(_12OpWarning_11750)->dbl;
    }

    /** 	OpTrace            = top[OP_TRACE]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpTrace_11752 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_12OpTrace_11752)){
        _12OpTrace_11752 = (long)DBL_PTR(_12OpTrace_11752)->dbl;
    }

    /** 	OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpTypeCheck_11753 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_12OpTypeCheck_11753)){
        _12OpTypeCheck_11753 = (long)DBL_PTR(_12OpTypeCheck_11753)->dbl;
    }

    /** 	OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpProfileTime_11755 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_12OpProfileTime_11755)){
        _12OpProfileTime_11755 = (long)DBL_PTR(_12OpProfileTime_11755)->dbl;
    }

    /** 	OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpProfileStatement_11754 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_12OpProfileStatement_11754)){
        _12OpProfileStatement_11754 = (long)DBL_PTR(_12OpProfileStatement_11754)->dbl;
    }

    /** 	OpDefines          = top[OP_DEFINES]*/
    DeRef(_12OpDefines_11756);
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpDefines_11756 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_12OpDefines_11756);

    /** 	prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12prev_OpWarning_11751 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_12prev_OpWarning_11751)){
        _12prev_OpWarning_11751 = (long)DBL_PTR(_12prev_OpWarning_11751)->dbl;
    }

    /** 	OpInline           = top[OP_INLINE]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpInline_11757 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_12OpInline_11757)){
        _12OpInline_11757 = (long)DBL_PTR(_12OpInline_11757)->dbl;
    }

    /** 	OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12OpIndirectInclude_11758 = (int)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_12OpIndirectInclude_11758)){
        _12OpIndirectInclude_11758 = (long)DBL_PTR(_12OpIndirectInclude_11758)->dbl;
    }

    /** 	putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _12putback_fwd_line_number_11685 = _12line_number_11683;

    /** 	putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_43putback_ForwardLine_48160);
    _2 = (int)SEQ_PTR(_top_24799);
    _43putback_ForwardLine_48160 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_43putback_ForwardLine_48160);

    /** 	putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _43putback_forward_bp_48164 = (int)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_43putback_forward_bp_48164)){
        _43putback_forward_bp_48164 = (long)DBL_PTR(_43putback_forward_bp_48164)->dbl;
    }

    /** 	last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _12last_fwd_line_number_11686 = (int)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_12last_fwd_line_number_11686)){
        _12last_fwd_line_number_11686 = (long)DBL_PTR(_12last_fwd_line_number_11686)->dbl;
    }

    /** 	last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_43last_ForwardLine_48161);
    _2 = (int)SEQ_PTR(_top_24799);
    _43last_ForwardLine_48161 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_43last_ForwardLine_48161);

    /** 	last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _43last_forward_bp_48165 = (int)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_43last_forward_bp_48165)){
        _43last_forward_bp_48165 = (long)DBL_PTR(_43last_forward_bp_48165)->dbl;
    }

    /** 	ThisLine = top[THISLINE]*/
    DeRef(_43ThisLine_48158);
    _2 = (int)SEQ_PTR(_top_24799);
    _43ThisLine_48158 = (int)*(((s1_ptr)_2)->base + 20);
    Ref(_43ThisLine_48158);

    /** 	fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _12fwd_line_number_11684 = _12line_number_11683;

    /** 	forward_bp = top[FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24799);
    _43forward_bp_48163 = (int)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_43forward_bp_48163)){
        _43forward_bp_48163 = (long)DBL_PTR(_43forward_bp_48163)->dbl;
    }

    /** 	ForwardLine = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43ForwardLine_48159);
    _43ForwardLine_48159 = _43ThisLine_48158;

    /** 	putback_ForwardLine = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43putback_ForwardLine_48160);
    _43putback_ForwardLine_48160 = _43ThisLine_48158;

    /** 	last_ForwardLine = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43last_ForwardLine_48161);
    _43last_ForwardLine_48161 = _43ThisLine_48158;

    /** 	IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_60IncludeStk_23573)){
            _14133 = SEQ_PTR(_60IncludeStk_23573)->length;
    }
    else {
        _14133 = 1;
    }
    _14134 = _14133 - 1;
    _14133 = NOVALUE;
    rhs_slice_target = (object_ptr)&_60IncludeStk_23573;
    RHS_Slice(_60IncludeStk_23573, 1, _14134);

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _14136 = NOVALUE;

    /** 	return TRUE*/
    DeRefDS(_top_24799);
    _14134 = NOVALUE;
    return _9TRUE_431;
    ;
}


int _60MakeInt(int _text_24887, int _nBase_24888)
{
    int _num_24889 = NOVALUE;
    int _fnum_24890 = NOVALUE;
    int _digit_24891 = NOVALUE;
    int _maxchk_24892 = NOVALUE;
    int _14181 = NOVALUE;
    int _14179 = NOVALUE;
    int _14177 = NOVALUE;
    int _14174 = NOVALUE;
    int _14173 = NOVALUE;
    int _14172 = NOVALUE;
    int _14170 = NOVALUE;
    int _14168 = NOVALUE;
    int _14167 = NOVALUE;
    int _14164 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_24888)) {
        _1 = (long)(DBL_PTR(_nBase_24888)->dbl);
        DeRefDS(_nBase_24888);
        _nBase_24888 = _1;
    }

    /** 	switch nBase do*/
    _0 = _nBase_24888;
    switch ( _0 ){ 

        /** 		case 2 then*/
        case 2:

        /** 			maxchk = 536870911*/
        _maxchk_24892 = 536870911;
        goto L1; // [21] 82

        /** 		case 8 then*/
        case 8:

        /** 			maxchk = 134217727*/
        _maxchk_24892 = 134217727;
        goto L1; // [32] 82

        /** 		case 10 then*/
        case 10:

        /** 			num = find(text, common_int_text)*/
        _num_24889 = find_from(_text_24887, _60common_int_text_24862, 1);

        /** 			if num then*/
        if (_num_24889 == 0)
        {
            goto L2; // [49] 65
        }
        else{
        }

        /** 				return common_ints[num]*/
        _2 = (int)SEQ_PTR(_60common_ints_24882);
        _14164 = (int)*(((s1_ptr)_2)->base + _num_24889);
        DeRefDS(_text_24887);
        DeRef(_fnum_24890);
        return _14164;
L2: 

        /** 			maxchk = 107374181*/
        _maxchk_24892 = 107374181;
        goto L1; // [70] 82

        /** 		case 16 then*/
        case 16:

        /** 			maxchk = 67108863*/
        _maxchk_24892 = 67108863;
    ;}L1: 

    /** 	num = 0*/
    _num_24889 = 0;

    /** 	fnum = 0*/
    DeRef(_fnum_24890);
    _fnum_24890 = 0;

    /** 	for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_24887)){
            _14167 = SEQ_PTR(_text_24887)->length;
    }
    else {
        _14167 = 1;
    }
    {
        int _i_24907;
        _i_24907 = 1;
L3: 
        if (_i_24907 > _14167){
            goto L4; // [97] 212
        }

        /** 		digit = (text[i] - '0')*/
        _2 = (int)SEQ_PTR(_text_24887);
        _14168 = (int)*(((s1_ptr)_2)->base + _i_24907);
        if (IS_ATOM_INT(_14168)) {
            _digit_24891 = _14168 - 48;
        }
        else {
            _digit_24891 = binary_op(MINUS, _14168, 48);
        }
        _14168 = NOVALUE;
        if (!IS_ATOM_INT(_digit_24891)) {
            _1 = (long)(DBL_PTR(_digit_24891)->dbl);
            DeRefDS(_digit_24891);
            _digit_24891 = _1;
        }

        /** 		if digit >= nBase or digit < 0 then*/
        _14170 = (_digit_24891 >= _nBase_24888);
        if (_14170 != 0) {
            goto L5; // [122] 135
        }
        _14172 = (_digit_24891 < 0);
        if (_14172 == 0)
        {
            DeRef(_14172);
            _14172 = NOVALUE;
            goto L6; // [131] 151
        }
        else{
            DeRef(_14172);
            _14172 = NOVALUE;
        }
L5: 

        /** 			CompileErr(62, {text[i],i})*/
        _2 = (int)SEQ_PTR(_text_24887);
        _14173 = (int)*(((s1_ptr)_2)->base + _i_24907);
        Ref(_14173);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _14173;
        ((int *)_2)[2] = _i_24907;
        _14174 = MAKE_SEQ(_1);
        _14173 = NOVALUE;
        _43CompileErr(62, _14174, 0);
        _14174 = NOVALUE;
L6: 

        /** 		if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_24890, 0)){
            goto L7; // [153] 194
        }

        /** 			if num <= maxchk then*/
        if (_num_24889 > _maxchk_24892)
        goto L8; // [161] 180

        /** 				num = num * nBase + digit*/
        if (_num_24889 == (short)_num_24889 && _nBase_24888 <= INT15 && _nBase_24888 >= -INT15)
        _14177 = _num_24889 * _nBase_24888;
        else
        _14177 = NewDouble(_num_24889 * (double)_nBase_24888);
        if (IS_ATOM_INT(_14177)) {
            _num_24889 = _14177 + _digit_24891;
        }
        else {
            _num_24889 = NewDouble(DBL_PTR(_14177)->dbl + (double)_digit_24891);
        }
        DeRef(_14177);
        _14177 = NOVALUE;
        if (!IS_ATOM_INT(_num_24889)) {
            _1 = (long)(DBL_PTR(_num_24889)->dbl);
            DeRefDS(_num_24889);
            _num_24889 = _1;
        }
        goto L9; // [177] 205
L8: 

        /** 				fnum = num * nBase + digit*/
        if (_num_24889 == (short)_num_24889 && _nBase_24888 <= INT15 && _nBase_24888 >= -INT15)
        _14179 = _num_24889 * _nBase_24888;
        else
        _14179 = NewDouble(_num_24889 * (double)_nBase_24888);
        DeRef(_fnum_24890);
        if (IS_ATOM_INT(_14179)) {
            _fnum_24890 = _14179 + _digit_24891;
            if ((long)((unsigned long)_fnum_24890 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_24890 = NewDouble((double)_fnum_24890);
        }
        else {
            _fnum_24890 = NewDouble(DBL_PTR(_14179)->dbl + (double)_digit_24891);
        }
        DeRef(_14179);
        _14179 = NOVALUE;
        goto L9; // [191] 205
L7: 

        /** 			fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_24890)) {
            if (_fnum_24890 == (short)_fnum_24890 && _nBase_24888 <= INT15 && _nBase_24888 >= -INT15)
            _14181 = _fnum_24890 * _nBase_24888;
            else
            _14181 = NewDouble(_fnum_24890 * (double)_nBase_24888);
        }
        else {
            _14181 = NewDouble(DBL_PTR(_fnum_24890)->dbl * (double)_nBase_24888);
        }
        DeRef(_fnum_24890);
        if (IS_ATOM_INT(_14181)) {
            _fnum_24890 = _14181 + _digit_24891;
            if ((long)((unsigned long)_fnum_24890 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_24890 = NewDouble((double)_fnum_24890);
        }
        else {
            _fnum_24890 = NewDouble(DBL_PTR(_14181)->dbl + (double)_digit_24891);
        }
        DeRef(_14181);
        _14181 = NOVALUE;
L9: 

        /** 	end for*/
        _i_24907 = _i_24907 + 1;
        goto L3; // [207] 104
L4: 
        ;
    }

    /** 	if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_24890, 0)){
        goto LA; // [214] 227
    }

    /** 		return num*/
    DeRefDS(_text_24887);
    DeRef(_fnum_24890);
    _14164 = NOVALUE;
    DeRef(_14170);
    _14170 = NOVALUE;
    return _num_24889;
    goto LB; // [224] 234
LA: 

    /** 		return fnum*/
    DeRefDS(_text_24887);
    _14164 = NOVALUE;
    DeRef(_14170);
    _14170 = NOVALUE;
    return _fnum_24890;
LB: 
    ;
}


int _60GetHexChar(int _cnt_24935, int _errno_24936)
{
    int _val_24937 = NOVALUE;
    int _d_24938 = NOVALUE;
    int _14191 = NOVALUE;
    int _14190 = NOVALUE;
    int _14185 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val = 0*/
    DeRef(_val_24937);
    _val_24937 = 0;

    /** 	while cnt > 0 do*/
L1: 
    if (_cnt_24935 <= 0)
    goto L2; // [15] 88

    /** 		d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14185 = _60getch();
    _d_24938 = find_from(_14185, _14186, 1);
    DeRef(_14185);
    _14185 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_24938 != 0)
    goto L3; // [31] 43

    /** 			CompileErr( errno )*/
    RefDS(_21829);
    _43CompileErr(_errno_24936, _21829, 0);
L3: 

    /** 		if d != 23 then*/
    if (_d_24938 == 23)
    goto L1; // [45] 15

    /** 			val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_24937)) {
        if (_val_24937 == (short)_val_24937)
        _14190 = _val_24937 * 16;
        else
        _14190 = NewDouble(_val_24937 * (double)16);
    }
    else {
        _14190 = NewDouble(DBL_PTR(_val_24937)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14190)) {
        _14191 = _14190 + _d_24938;
        if ((long)((unsigned long)_14191 + (unsigned long)HIGH_BITS) >= 0) 
        _14191 = NewDouble((double)_14191);
    }
    else {
        _14191 = NewDouble(DBL_PTR(_14190)->dbl + (double)_d_24938);
    }
    DeRef(_14190);
    _14190 = NOVALUE;
    DeRef(_val_24937);
    if (IS_ATOM_INT(_14191)) {
        _val_24937 = _14191 - 1;
        if ((long)((unsigned long)_val_24937 +(unsigned long) HIGH_BITS) >= 0){
            _val_24937 = NewDouble((double)_val_24937);
        }
    }
    else {
        _val_24937 = NewDouble(DBL_PTR(_14191)->dbl - (double)1);
    }
    DeRef(_14191);
    _14191 = NOVALUE;

    /** 			if d > 16 then*/
    if (_d_24938 <= 16)
    goto L4; // [65] 76

    /** 				val -= 6*/
    _0 = _val_24937;
    if (IS_ATOM_INT(_val_24937)) {
        _val_24937 = _val_24937 - 6;
        if ((long)((unsigned long)_val_24937 +(unsigned long) HIGH_BITS) >= 0){
            _val_24937 = NewDouble((double)_val_24937);
        }
    }
    else {
        _val_24937 = NewDouble(DBL_PTR(_val_24937)->dbl - (double)6);
    }
    DeRef(_0);
L4: 

    /** 			cnt -= 1*/
    _cnt_24935 = _cnt_24935 - 1;

    /** 	end while*/
    goto L1; // [85] 15
L2: 

    /** 	return val*/
    return _val_24937;
    ;
}


int _60GetBinaryChar(int _delim_24958)
{
    int _val_24959 = NOVALUE;
    int _d_24960 = NOVALUE;
    int _vchars_24961 = NOVALUE;
    int _cnt_24964 = NOVALUE;
    int _14205 = NOVALUE;
    int _14204 = NOVALUE;
    int _14198 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence vchars = "01_ " & delim*/
    Append(&_vchars_24961, _14196, _delim_24958);

    /** 	integer cnt = 0*/
    _cnt_24964 = 0;

    /** 	val = 0*/
    DeRef(_val_24959);
    _val_24959 = 0;

    /** 	while 1 do*/
L1: 

    /** 		d = find(getch(), vchars)*/
    _14198 = _60getch();
    _d_24960 = find_from(_14198, _vchars_24961, 1);
    DeRef(_14198);
    _14198 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_24960 != 0)
    goto L2; // [36] 48

    /** 			CompileErr( 343 )*/
    RefDS(_21829);
    _43CompileErr(343, _21829, 0);
L2: 

    /** 		if d = 5 then*/
    if (_d_24960 != 5)
    goto L3; // [50] 63

    /** 			ungetch()*/
    _60ungetch();

    /** 			exit*/
    goto L4; // [60] 106
L3: 

    /** 		if d = 4 then*/
    if (_d_24960 != 4)
    goto L5; // [65] 74

    /** 			exit*/
    goto L4; // [71] 106
L5: 

    /** 		if d != 3 then*/
    if (_d_24960 == 3)
    goto L1; // [76] 24

    /** 			val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_24959) && IS_ATOM_INT(_val_24959)) {
        _14204 = _val_24959 + _val_24959;
        if ((long)((unsigned long)_14204 + (unsigned long)HIGH_BITS) >= 0) 
        _14204 = NewDouble((double)_14204);
    }
    else {
        if (IS_ATOM_INT(_val_24959)) {
            _14204 = NewDouble((double)_val_24959 + DBL_PTR(_val_24959)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_24959)) {
                _14204 = NewDouble(DBL_PTR(_val_24959)->dbl + (double)_val_24959);
            }
            else
            _14204 = NewDouble(DBL_PTR(_val_24959)->dbl + DBL_PTR(_val_24959)->dbl);
        }
    }
    if (IS_ATOM_INT(_14204)) {
        _14205 = _14204 + _d_24960;
        if ((long)((unsigned long)_14205 + (unsigned long)HIGH_BITS) >= 0) 
        _14205 = NewDouble((double)_14205);
    }
    else {
        _14205 = NewDouble(DBL_PTR(_14204)->dbl + (double)_d_24960);
    }
    DeRef(_14204);
    _14204 = NOVALUE;
    DeRef(_val_24959);
    if (IS_ATOM_INT(_14205)) {
        _val_24959 = _14205 - 1;
        if ((long)((unsigned long)_val_24959 +(unsigned long) HIGH_BITS) >= 0){
            _val_24959 = NewDouble((double)_val_24959);
        }
    }
    else {
        _val_24959 = NewDouble(DBL_PTR(_14205)->dbl - (double)1);
    }
    DeRef(_14205);
    _14205 = NOVALUE;

    /** 			cnt += 1*/
    _cnt_24964 = _cnt_24964 + 1;

    /** 	end while*/
    goto L1; // [103] 24
L4: 

    /** 	if cnt = 0 then*/
    if (_cnt_24964 != 0)
    goto L6; // [108] 120

    /** 		CompileErr(343)*/
    RefDS(_21829);
    _43CompileErr(343, _21829, 0);
L6: 

    /** 	return val*/
    DeRefi(_vchars_24961);
    return _val_24959;
    ;
}


int _60EscapeChar(int _delim_24986)
{
    int _c_24987 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = getch()*/
    _0 = _c_24987;
    _c_24987 = _60getch();
    DeRef(_0);

    /** 	switch c do*/
    if (IS_SEQUENCE(_c_24987) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_24987)){
        if( (DBL_PTR(_c_24987)->dbl != (double) ((int) DBL_PTR(_c_24987)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (int) DBL_PTR(_c_24987)->dbl;
    }
    else {
        _0 = _c_24987;
    };
    switch ( _0 ){ 

        /** 		case 'n' then*/
        case 110:

        /** 			c = 10 -- Newline*/
        DeRef(_c_24987);
        _c_24987 = 10;
        goto L2; // [24] 145

        /** 		case 't' then*/
        case 116:

        /** 			c = 9 -- Tabulator*/
        DeRef(_c_24987);
        _c_24987 = 9;
        goto L2; // [35] 145

        /** 		case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** 		case 'r' then*/
        goto L2; // [47] 145
        case 114:

        /** 			c = 13 -- Carriage Return*/
        DeRef(_c_24987);
        _c_24987 = 13;
        goto L2; // [56] 145

        /** 		case '0' then*/
        case 48:

        /** 			c = 0 -- Null*/
        DeRef(_c_24987);
        _c_24987 = 0;
        goto L2; // [67] 145

        /** 		case 'e', 'E' then*/
        case 101:
        case 69:

        /** 			c = 27 -- escape char.*/
        DeRef(_c_24987);
        _c_24987 = 27;
        goto L2; // [80] 145

        /** 		case 'x' then*/
        case 120:

        /** 			c = GetHexChar(2, 340)*/
        _0 = _c_24987;
        _c_24987 = _60GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 145

        /** 		case 'u' then*/
        case 117:

        /** 			c = GetHexChar(4, 341)*/
        _0 = _c_24987;
        _c_24987 = _60GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 145

        /** 		case 'U' then*/
        case 85:

        /** 			c = GetHexChar(8, 342)*/
        _0 = _c_24987;
        _c_24987 = _60GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 145

        /** 		case 'b' then*/
        case 98:

        /** 			c = GetBinaryChar(delim)*/
        _0 = _c_24987;
        _c_24987 = _60GetBinaryChar(_delim_24986);
        DeRef(_0);
        goto L2; // [131] 145

        /** 		case else*/
        default:
L1: 

        /** 			CompileErr(155)*/
        RefDS(_21829);
        _43CompileErr(155, _21829, 0);
    ;}L2: 

    /** 	return c*/
    return _c_24987;
    ;
}


int _60my_sscanf(int _yytext_25009)
{
    int _e_sign_25010 = NOVALUE;
    int _ndigits_25011 = NOVALUE;
    int _e_mag_25012 = NOVALUE;
    int _mantissa_25013 = NOVALUE;
    int _c_25014 = NOVALUE;
    int _i_25015 = NOVALUE;
    int _dec_25016 = NOVALUE;
    int _frac_25046 = NOVALUE;
    int _14249 = NOVALUE;
    int _14244 = NOVALUE;
    int _14243 = NOVALUE;
    int _14241 = NOVALUE;
    int _14240 = NOVALUE;
    int _14239 = NOVALUE;
    int _14231 = NOVALUE;
    int _14230 = NOVALUE;
    int _14227 = NOVALUE;
    int _14226 = NOVALUE;
    int _14225 = NOVALUE;
    int _14221 = NOVALUE;
    int _14220 = NOVALUE;
    int _14218 = NOVALUE;
    int _14216 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_25009)){
            _14216 = SEQ_PTR(_yytext_25009)->length;
    }
    else {
        _14216 = 1;
    }
    if (_14216 >= 2)
    goto L1; // [8] 20

    /** 		CompileErr(121)*/
    RefDS(_21829);
    _43CompileErr(121, _21829, 0);
L1: 

    /** 	if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14218 = find_from(101, _yytext_25009, 1);
    if (_14218 != 0) {
        goto L2; // [27] 41
    }
    _14220 = find_from(69, _yytext_25009, 1);
    if (_14220 == 0)
    {
        _14220 = NOVALUE;
        goto L3; // [37] 52
    }
    else{
        _14220 = NOVALUE;
    }
L2: 

    /** 		return scientific_to_atom( yytext )*/
    RefDS(_yytext_25009);
    _14221 = _61scientific_to_atom(_yytext_25009);
    DeRefDS(_yytext_25009);
    DeRef(_mantissa_25013);
    DeRef(_dec_25016);
    return _14221;
L3: 

    /** 	mantissa = 0.0*/
    RefDS(_14222);
    DeRef(_mantissa_25013);
    _mantissa_25013 = _14222;

    /** 	ndigits = 0*/
    _ndigits_25011 = 0;

    /** 	yytext &= 0 -- end marker*/
    Append(&_yytext_25009, _yytext_25009, 0);

    /** 	c = yytext[1]*/
    _2 = (int)SEQ_PTR(_yytext_25009);
    _c_25014 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_25014))
    _c_25014 = (long)DBL_PTR(_c_25014)->dbl;

    /** 	i = 2*/
    _i_25015 = 2;

    /** 	while c >= '0' and c <= '9' do*/
L4: 
    _14225 = (_c_25014 >= 48);
    if (_14225 == 0) {
        goto L5; // [88] 137
    }
    _14227 = (_c_25014 <= 57);
    if (_14227 == 0)
    {
        DeRef(_14227);
        _14227 = NOVALUE;
        goto L5; // [97] 137
    }
    else{
        DeRef(_14227);
        _14227 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_25011 = _ndigits_25011 + 1;

    /** 		mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_25013)) {
        _14230 = NewDouble((double)_mantissa_25013 * DBL_PTR(_14229)->dbl);
    }
    else {
        _14230 = NewDouble(DBL_PTR(_mantissa_25013)->dbl * DBL_PTR(_14229)->dbl);
    }
    _14231 = _c_25014 - 48;
    if ((long)((unsigned long)_14231 +(unsigned long) HIGH_BITS) >= 0){
        _14231 = NewDouble((double)_14231);
    }
    DeRef(_mantissa_25013);
    if (IS_ATOM_INT(_14231)) {
        _mantissa_25013 = NewDouble(DBL_PTR(_14230)->dbl + (double)_14231);
    }
    else
    _mantissa_25013 = NewDouble(DBL_PTR(_14230)->dbl + DBL_PTR(_14231)->dbl);
    DeRefDS(_14230);
    _14230 = NOVALUE;
    DeRef(_14231);
    _14231 = NOVALUE;

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25009);
    _c_25014 = (int)*(((s1_ptr)_2)->base + _i_25015);
    if (!IS_ATOM_INT(_c_25014))
    _c_25014 = (long)DBL_PTR(_c_25014)->dbl;

    /** 		i += 1*/
    _i_25015 = _i_25015 + 1;

    /** 	end while*/
    goto L4; // [134] 84
L5: 

    /** 	if c = '.' then*/
    if (_c_25014 != 46)
    goto L6; // [139] 240

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25009);
    _c_25014 = (int)*(((s1_ptr)_2)->base + _i_25015);
    if (!IS_ATOM_INT(_c_25014))
    _c_25014 = (long)DBL_PTR(_c_25014)->dbl;

    /** 		i += 1*/
    _i_25015 = _i_25015 + 1;

    /** 		dec = 1.0*/
    RefDS(_14238);
    DeRef(_dec_25016);
    _dec_25016 = _14238;

    /** 		atom frac = 0*/
    DeRef(_frac_25046);
    _frac_25046 = 0;

    /** 		while c >= '0' and c <= '9' do*/
L7: 
    _14239 = (_c_25014 >= 48);
    if (_14239 == 0) {
        goto L8; // [174] 229
    }
    _14241 = (_c_25014 <= 57);
    if (_14241 == 0)
    {
        DeRef(_14241);
        _14241 = NOVALUE;
        goto L8; // [183] 229
    }
    else{
        DeRef(_14241);
        _14241 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_25011 = _ndigits_25011 + 1;

    /** 			frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_25046)) {
        if (_frac_25046 == (short)_frac_25046)
        _14243 = _frac_25046 * 10;
        else
        _14243 = NewDouble(_frac_25046 * (double)10);
    }
    else {
        _14243 = NewDouble(DBL_PTR(_frac_25046)->dbl * (double)10);
    }
    _14244 = _c_25014 - 48;
    if ((long)((unsigned long)_14244 +(unsigned long) HIGH_BITS) >= 0){
        _14244 = NewDouble((double)_14244);
    }
    DeRef(_frac_25046);
    if (IS_ATOM_INT(_14243) && IS_ATOM_INT(_14244)) {
        _frac_25046 = _14243 + _14244;
        if ((long)((unsigned long)_frac_25046 + (unsigned long)HIGH_BITS) >= 0) 
        _frac_25046 = NewDouble((double)_frac_25046);
    }
    else {
        if (IS_ATOM_INT(_14243)) {
            _frac_25046 = NewDouble((double)_14243 + DBL_PTR(_14244)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14244)) {
                _frac_25046 = NewDouble(DBL_PTR(_14243)->dbl + (double)_14244);
            }
            else
            _frac_25046 = NewDouble(DBL_PTR(_14243)->dbl + DBL_PTR(_14244)->dbl);
        }
    }
    DeRef(_14243);
    _14243 = NOVALUE;
    DeRef(_14244);
    _14244 = NOVALUE;

    /** 			dec *= 10.0*/
    _0 = _dec_25016;
    if (IS_ATOM_INT(_dec_25016)) {
        _dec_25016 = NewDouble((double)_dec_25016 * DBL_PTR(_14229)->dbl);
    }
    else {
        _dec_25016 = NewDouble(DBL_PTR(_dec_25016)->dbl * DBL_PTR(_14229)->dbl);
    }
    DeRef(_0);

    /** 			c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25009);
    _c_25014 = (int)*(((s1_ptr)_2)->base + _i_25015);
    if (!IS_ATOM_INT(_c_25014))
    _c_25014 = (long)DBL_PTR(_c_25014)->dbl;

    /** 			i += 1*/
    _i_25015 = _i_25015 + 1;

    /** 		end while*/
    goto L7; // [226] 170
L8: 

    /** 		mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_25046) && IS_ATOM_INT(_dec_25016)) {
        _14249 = (_frac_25046 % _dec_25016) ? NewDouble((double)_frac_25046 / _dec_25016) : (_frac_25046 / _dec_25016);
    }
    else {
        if (IS_ATOM_INT(_frac_25046)) {
            _14249 = NewDouble((double)_frac_25046 / DBL_PTR(_dec_25016)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_25016)) {
                _14249 = NewDouble(DBL_PTR(_frac_25046)->dbl / (double)_dec_25016);
            }
            else
            _14249 = NewDouble(DBL_PTR(_frac_25046)->dbl / DBL_PTR(_dec_25016)->dbl);
        }
    }
    _0 = _mantissa_25013;
    if (IS_ATOM_INT(_mantissa_25013) && IS_ATOM_INT(_14249)) {
        _mantissa_25013 = _mantissa_25013 + _14249;
        if ((long)((unsigned long)_mantissa_25013 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_25013 = NewDouble((double)_mantissa_25013);
    }
    else {
        if (IS_ATOM_INT(_mantissa_25013)) {
            _mantissa_25013 = NewDouble((double)_mantissa_25013 + DBL_PTR(_14249)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14249)) {
                _mantissa_25013 = NewDouble(DBL_PTR(_mantissa_25013)->dbl + (double)_14249);
            }
            else
            _mantissa_25013 = NewDouble(DBL_PTR(_mantissa_25013)->dbl + DBL_PTR(_14249)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14249);
    _14249 = NOVALUE;
L6: 
    DeRef(_frac_25046);
    _frac_25046 = NOVALUE;

    /** 	if ndigits = 0 then*/
    if (_ndigits_25011 != 0)
    goto L9; // [244] 256

    /** 		CompileErr(121)  -- no digits*/
    RefDS(_21829);
    _43CompileErr(121, _21829, 0);
L9: 

    /** 	return mantissa*/
    DeRefDS(_yytext_25009);
    DeRef(_dec_25016);
    DeRef(_14221);
    _14221 = NOVALUE;
    DeRef(_14225);
    _14225 = NOVALUE;
    DeRef(_14239);
    _14239 = NOVALUE;
    return _mantissa_25013;
    ;
}


void _60maybe_namespace()
{
    int _0, _1, _2;
    

    /** 	might_be_namespace = 1*/
    _60might_be_namespace_25063 = 1;

    /** end procedure*/
    return;
    ;
}


int _60ExtendedString(int _ech_25073)
{
    int _ch_25074 = NOVALUE;
    int _fch_25075 = NOVALUE;
    int _cline_25076 = NOVALUE;
    int _string_text_25077 = NOVALUE;
    int _trimming_25078 = NOVALUE;
    int _14302 = NOVALUE;
    int _14301 = NOVALUE;
    int _14299 = NOVALUE;
    int _14298 = NOVALUE;
    int _14297 = NOVALUE;
    int _14296 = NOVALUE;
    int _14295 = NOVALUE;
    int _14294 = NOVALUE;
    int _14293 = NOVALUE;
    int _14292 = NOVALUE;
    int _14290 = NOVALUE;
    int _14289 = NOVALUE;
    int _14288 = NOVALUE;
    int _14287 = NOVALUE;
    int _14286 = NOVALUE;
    int _14285 = NOVALUE;
    int _14282 = NOVALUE;
    int _14281 = NOVALUE;
    int _14280 = NOVALUE;
    int _14278 = NOVALUE;
    int _14277 = NOVALUE;
    int _14276 = NOVALUE;
    int _14275 = NOVALUE;
    int _14272 = NOVALUE;
    int _14257 = NOVALUE;
    int _14255 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25076 = _12line_number_11683;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_25077);
    _string_text_25077 = _5;

    /** 	trimming = 0*/
    _trimming_25078 = 0;

    /** 	ch = getch()*/
    _ch_25074 = _60getch();
    if (!IS_ATOM_INT(_ch_25074)) {
        _1 = (long)(DBL_PTR(_ch_25074)->dbl);
        DeRefDS(_ch_25074);
        _ch_25074 = _1;
    }

    /** 	if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_43ThisLine_48158)){
            _14255 = SEQ_PTR(_43ThisLine_48158)->length;
    }
    else {
        _14255 = 1;
    }
    if (_43bp_48162 <= _14255)
    goto L1; // [40] 101

    /** 		read_line()*/
    _60read_line();

    /** 		while ThisLine[bp] = '_' do*/
L2: 
    _2 = (int)SEQ_PTR(_43ThisLine_48158);
    _14257 = (int)*(((s1_ptr)_2)->base + _43bp_48162);
    if (binary_op_a(NOTEQ, _14257, 95)){
        _14257 = NOVALUE;
        goto L3; // [61] 86
    }
    _14257 = NOVALUE;

    /** 			trimming += 1*/
    _trimming_25078 = _trimming_25078 + 1;

    /** 			bp += 1*/
    _43bp_48162 = _43bp_48162 + 1;

    /** 		end while*/
    goto L2; // [83] 53
L3: 

    /** 		if trimming > 0 then*/
    if (_trimming_25078 <= 0)
    goto L4; // [88] 100

    /** 			ch = getch()*/
    _ch_25074 = _60getch();
    if (!IS_ATOM_INT(_ch_25074)) {
        _1 = (long)(DBL_PTR(_ch_25074)->dbl);
        DeRefDS(_ch_25074);
        _ch_25074 = _1;
    }
L4: 
L1: 

    /** 	while 1 do*/
L5: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25074 != 26)
    goto L6; // [110] 122

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25076, 0);
L6: 

    /** 		if ch = ech then*/
    if (_ch_25074 != _ech_25073)
    goto L7; // [124] 180

    /** 			if ech != '"' then*/
    if (_ech_25073 == 34)
    goto L8; // [130] 139

    /** 				exit*/
    goto L9; // [136] 310
L8: 

    /** 			fch = getch()*/
    _fch_25075 = _60getch();
    if (!IS_ATOM_INT(_fch_25075)) {
        _1 = (long)(DBL_PTR(_fch_25075)->dbl);
        DeRefDS(_fch_25075);
        _fch_25075 = _1;
    }

    /** 			if fch = '"' then*/
    if (_fch_25075 != 34)
    goto LA; // [148] 175

    /** 				fch = getch()*/
    _fch_25075 = _60getch();
    if (!IS_ATOM_INT(_fch_25075)) {
        _1 = (long)(DBL_PTR(_fch_25075)->dbl);
        DeRefDS(_fch_25075);
        _fch_25075 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25075 != 34)
    goto LB; // [161] 170

    /** 					exit*/
    goto L9; // [167] 310
LB: 

    /** 				ungetch()*/
    _60ungetch();
LA: 

    /** 			ungetch()*/
    _60ungetch();
L7: 

    /** 		if ch != '\r' then*/
    if (_ch_25074 == 13)
    goto LC; // [182] 193

    /** 			string_text &= ch*/
    Append(&_string_text_25077, _string_text_25077, _ch_25074);
LC: 

    /** 		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_43ThisLine_48158)){
            _14272 = SEQ_PTR(_43ThisLine_48158)->length;
    }
    else {
        _14272 = 1;
    }
    if (_43bp_48162 <= _14272)
    goto LD; // [202] 298

    /** 			read_line() -- sets bp to 1, btw.*/
    _60read_line();

    /** 			if trimming > 0 then*/
    if (_trimming_25078 <= 0)
    goto LE; // [212] 297

    /** 				while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14275 = (_43bp_48162 <= _trimming_25078);
    if (_14275 == 0) {
        goto L10; // [227] 296
    }
    if (IS_SEQUENCE(_43ThisLine_48158)){
            _14277 = SEQ_PTR(_43ThisLine_48158)->length;
    }
    else {
        _14277 = 1;
    }
    _14278 = (_43bp_48162 <= _14277);
    _14277 = NOVALUE;
    if (_14278 == 0)
    {
        DeRef(_14278);
        _14278 = NOVALUE;
        goto L10; // [243] 296
    }
    else{
        DeRef(_14278);
        _14278 = NOVALUE;
    }

    /** 					ch = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_43ThisLine_48158);
    _ch_25074 = (int)*(((s1_ptr)_2)->base + _43bp_48162);
    if (!IS_ATOM_INT(_ch_25074)){
        _ch_25074 = (long)DBL_PTR(_ch_25074)->dbl;
    }

    /** 					if ch != ' ' and ch != '\t' then*/
    _14280 = (_ch_25074 != 32);
    if (_14280 == 0) {
        goto L11; // [264] 281
    }
    _14282 = (_ch_25074 != 9);
    if (_14282 == 0)
    {
        DeRef(_14282);
        _14282 = NOVALUE;
        goto L11; // [273] 281
    }
    else{
        DeRef(_14282);
        _14282 = NOVALUE;
    }

    /** 						exit*/
    goto L10; // [278] 296
L11: 

    /** 					bp += 1*/
    _43bp_48162 = _43bp_48162 + 1;

    /** 				end while*/
    goto LF; // [293] 221
L10: 
LE: 
LD: 

    /** 		ch = getch()*/
    _ch_25074 = _60getch();
    if (!IS_ATOM_INT(_ch_25074)) {
        _1 = (long)(DBL_PTR(_ch_25074)->dbl);
        DeRefDS(_ch_25074);
        _ch_25074 = _1;
    }

    /** 	end while*/
    goto L5; // [307] 106
L9: 

    /** 	if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25077)){
            _14285 = SEQ_PTR(_string_text_25077)->length;
    }
    else {
        _14285 = 1;
    }
    _14286 = (_14285 > 0);
    _14285 = NOVALUE;
    if (_14286 == 0) {
        goto L12; // [319] 389
    }
    _2 = (int)SEQ_PTR(_string_text_25077);
    _14288 = (int)*(((s1_ptr)_2)->base + 1);
    _14289 = (_14288 == 10);
    _14288 = NOVALUE;
    if (_14289 == 0)
    {
        DeRef(_14289);
        _14289 = NOVALUE;
        goto L12; // [332] 389
    }
    else{
        DeRef(_14289);
        _14289 = NOVALUE;
    }

    /** 		string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_25077)){
            _14290 = SEQ_PTR(_string_text_25077)->length;
    }
    else {
        _14290 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_25077;
    RHS_Slice(_string_text_25077, 2, _14290);

    /** 		if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25077)){
            _14292 = SEQ_PTR(_string_text_25077)->length;
    }
    else {
        _14292 = 1;
    }
    _14293 = (_14292 > 0);
    _14292 = NOVALUE;
    if (_14293 == 0) {
        goto L13; // [354] 388
    }
    if (IS_SEQUENCE(_string_text_25077)){
            _14295 = SEQ_PTR(_string_text_25077)->length;
    }
    else {
        _14295 = 1;
    }
    _2 = (int)SEQ_PTR(_string_text_25077);
    _14296 = (int)*(((s1_ptr)_2)->base + _14295);
    _14297 = (_14296 == 10);
    _14296 = NOVALUE;
    if (_14297 == 0)
    {
        DeRef(_14297);
        _14297 = NOVALUE;
        goto L13; // [370] 388
    }
    else{
        DeRef(_14297);
        _14297 = NOVALUE;
    }

    /** 			string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_25077)){
            _14298 = SEQ_PTR(_string_text_25077)->length;
    }
    else {
        _14298 = 1;
    }
    _14299 = _14298 - 1;
    _14298 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_25077;
    RHS_Slice(_string_text_25077, 1, _14299);
L13: 
L12: 

    /** 	return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_25077);
    _14301 = _52NewStringSym(_string_text_25077);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14301;
    _14302 = MAKE_SEQ(_1);
    _14301 = NOVALUE;
    DeRefDSi(_string_text_25077);
    DeRef(_14275);
    _14275 = NOVALUE;
    DeRef(_14280);
    _14280 = NOVALUE;
    DeRef(_14286);
    _14286 = NOVALUE;
    DeRef(_14293);
    _14293 = NOVALUE;
    DeRef(_14299);
    _14299 = NOVALUE;
    return _14302;
    ;
}


int _60GetHexString(int _maxnibbles_25164)
{
    int _ch_25165 = NOVALUE;
    int _digit_25166 = NOVALUE;
    int _val_25167 = NOVALUE;
    int _cline_25168 = NOVALUE;
    int _nibble_25169 = NOVALUE;
    int _string_text_25170 = NOVALUE;
    int _14316 = NOVALUE;
    int _14315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25168 = _12line_number_11683;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25170);
    _string_text_25170 = _5;

    /** 	nibble = 1*/
    _nibble_25169 = 1;

    /** 	val = -1*/
    DeRef(_val_25167);
    _val_25167 = -1;

    /** 	ch = getch()*/
    _ch_25165 = _60getch();
    if (!IS_ATOM_INT(_ch_25165)) {
        _1 = (long)(DBL_PTR(_ch_25165)->dbl);
        DeRefDS(_ch_25165);
        _ch_25165 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25165 != 26)
    goto L2; // [45] 57

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25168, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25165 != 34)
    goto L3; // [59] 68

    /** 			exit*/
    goto L4; // [65] 224
L3: 

    /** 		digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_25166 = find_from(_ch_25165, _14306, 1);

    /** 		if digit = 0 then*/
    if (_digit_25166 != 0)
    goto L5; // [77] 89

    /** 			CompileErr(329)*/
    RefDS(_21829);
    _43CompileErr(329, _21829, 0);
L5: 

    /** 		if digit <= 23 then*/
    if (_digit_25166 > 23)
    goto L6; // [91] 177

    /** 			if digit != 23 then*/
    if (_digit_25166 == 23)
    goto L7; // [97] 212

    /** 				if digit > 16 then*/
    if (_digit_25166 <= 16)
    goto L8; // [103] 114

    /** 					digit -= 6*/
    _digit_25166 = _digit_25166 - 6;
L8: 

    /** 				if nibble = 1 then*/
    if (_nibble_25169 != 1)
    goto L9; // [116] 129

    /** 					val = digit - 1*/
    DeRef(_val_25167);
    _val_25167 = _digit_25166 - 1;
    if ((long)((unsigned long)_val_25167 +(unsigned long) HIGH_BITS) >= 0){
        _val_25167 = NewDouble((double)_val_25167);
    }
    goto LA; // [126] 167
L9: 

    /** 					val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_25167)) {
        if (_val_25167 == (short)_val_25167)
        _14315 = _val_25167 * 16;
        else
        _14315 = NewDouble(_val_25167 * (double)16);
    }
    else {
        _14315 = NewDouble(DBL_PTR(_val_25167)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14315)) {
        _14316 = _14315 + _digit_25166;
        if ((long)((unsigned long)_14316 + (unsigned long)HIGH_BITS) >= 0) 
        _14316 = NewDouble((double)_14316);
    }
    else {
        _14316 = NewDouble(DBL_PTR(_14315)->dbl + (double)_digit_25166);
    }
    DeRef(_14315);
    _14315 = NOVALUE;
    DeRef(_val_25167);
    if (IS_ATOM_INT(_14316)) {
        _val_25167 = _14316 - 1;
        if ((long)((unsigned long)_val_25167 +(unsigned long) HIGH_BITS) >= 0){
            _val_25167 = NewDouble((double)_val_25167);
        }
    }
    else {
        _val_25167 = NewDouble(DBL_PTR(_14316)->dbl - (double)1);
    }
    DeRef(_14316);
    _14316 = NOVALUE;

    /** 					if nibble = maxnibbles then*/
    if (_nibble_25169 != _maxnibbles_25164)
    goto LB; // [145] 166

    /** 						string_text &= val*/
    Ref(_val_25167);
    Append(&_string_text_25170, _string_text_25170, _val_25167);

    /** 						val = -1*/
    DeRef(_val_25167);
    _val_25167 = -1;

    /** 						nibble = 0*/
    _nibble_25169 = 0;
LB: 
LA: 

    /** 				nibble += 1*/
    _nibble_25169 = _nibble_25169 + 1;
    goto L7; // [174] 212
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25167, 0)){
        goto LC; // [179] 195
    }

    /** 				string_text &= val*/
    Ref(_val_25167);
    Append(&_string_text_25170, _string_text_25170, _val_25167);

    /** 				val = -1*/
    DeRef(_val_25167);
    _val_25167 = -1;
LC: 

    /** 			nibble = 1*/
    _nibble_25169 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25165 != 10)
    goto LD; // [202] 211

    /** 				read_line()*/
    _60read_line();
LD: 
L7: 

    /** 		ch = getch()*/
    _ch_25165 = _60getch();
    if (!IS_ATOM_INT(_ch_25165)) {
        _1 = (long)(DBL_PTR(_ch_25165)->dbl);
        DeRefDS(_ch_25165);
        _ch_25165 = _1;
    }

    /** 	end while*/
    goto L1; // [221] 41
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25167, 0)){
        goto LE; // [226] 237
    }

    /** 		string_text &= val*/
    Ref(_val_25167);
    Append(&_string_text_25170, _string_text_25170, _val_25167);
LE: 

    /** 	return string_text*/
    DeRef(_val_25167);
    return _string_text_25170;
    ;
}


int _60GetBitString()
{
    int _ch_25215 = NOVALUE;
    int _digit_25216 = NOVALUE;
    int _val_25217 = NOVALUE;
    int _cline_25218 = NOVALUE;
    int _bitcnt_25219 = NOVALUE;
    int _string_text_25220 = NOVALUE;
    int _14338 = NOVALUE;
    int _14337 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25218 = _12line_number_11683;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25220);
    _string_text_25220 = _5;

    /** 	bitcnt = 1*/
    _bitcnt_25219 = 1;

    /** 	val = -1*/
    DeRef(_val_25217);
    _val_25217 = -1;

    /** 	ch = getch()*/
    _ch_25215 = _60getch();
    if (!IS_ATOM_INT(_ch_25215)) {
        _1 = (long)(DBL_PTR(_ch_25215)->dbl);
        DeRefDS(_ch_25215);
        _ch_25215 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25215 != 26)
    goto L2; // [43] 55

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25218, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25215 != 34)
    goto L3; // [57] 66

    /** 			exit*/
    goto L4; // [63] 186
L3: 

    /** 		digit = find(ch, "01_ \t\n\r")*/
    _digit_25216 = find_from(_ch_25215, _14330, 1);

    /** 		if digit = 0 then*/
    if (_digit_25216 != 0)
    goto L5; // [75] 87

    /** 			CompileErr(329)*/
    RefDS(_21829);
    _43CompileErr(329, _21829, 0);
L5: 

    /** 		if digit <= 3 then*/
    if (_digit_25216 > 3)
    goto L6; // [89] 139

    /** 			if digit != 3 then*/
    if (_digit_25216 == 3)
    goto L7; // [95] 174

    /** 				if bitcnt = 1 then*/
    if (_bitcnt_25219 != 1)
    goto L8; // [101] 114

    /** 					val = digit - 1*/
    DeRef(_val_25217);
    _val_25217 = _digit_25216 - 1;
    if ((long)((unsigned long)_val_25217 +(unsigned long) HIGH_BITS) >= 0){
        _val_25217 = NewDouble((double)_val_25217);
    }
    goto L9; // [111] 129
L8: 

    /** 					val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_25217) && IS_ATOM_INT(_val_25217)) {
        _14337 = _val_25217 + _val_25217;
        if ((long)((unsigned long)_14337 + (unsigned long)HIGH_BITS) >= 0) 
        _14337 = NewDouble((double)_14337);
    }
    else {
        if (IS_ATOM_INT(_val_25217)) {
            _14337 = NewDouble((double)_val_25217 + DBL_PTR(_val_25217)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25217)) {
                _14337 = NewDouble(DBL_PTR(_val_25217)->dbl + (double)_val_25217);
            }
            else
            _14337 = NewDouble(DBL_PTR(_val_25217)->dbl + DBL_PTR(_val_25217)->dbl);
        }
    }
    if (IS_ATOM_INT(_14337)) {
        _14338 = _14337 + _digit_25216;
        if ((long)((unsigned long)_14338 + (unsigned long)HIGH_BITS) >= 0) 
        _14338 = NewDouble((double)_14338);
    }
    else {
        _14338 = NewDouble(DBL_PTR(_14337)->dbl + (double)_digit_25216);
    }
    DeRef(_14337);
    _14337 = NOVALUE;
    DeRef(_val_25217);
    if (IS_ATOM_INT(_14338)) {
        _val_25217 = _14338 - 1;
        if ((long)((unsigned long)_val_25217 +(unsigned long) HIGH_BITS) >= 0){
            _val_25217 = NewDouble((double)_val_25217);
        }
    }
    else {
        _val_25217 = NewDouble(DBL_PTR(_14338)->dbl - (double)1);
    }
    DeRef(_14338);
    _14338 = NOVALUE;
L9: 

    /** 				bitcnt += 1*/
    _bitcnt_25219 = _bitcnt_25219 + 1;
    goto L7; // [136] 174
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25217, 0)){
        goto LA; // [141] 157
    }

    /** 				string_text &= val*/
    Ref(_val_25217);
    Append(&_string_text_25220, _string_text_25220, _val_25217);

    /** 				val = -1*/
    DeRef(_val_25217);
    _val_25217 = -1;
LA: 

    /** 			bitcnt = 1*/
    _bitcnt_25219 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25215 != 10)
    goto LB; // [164] 173

    /** 				read_line()*/
    _60read_line();
LB: 
L7: 

    /** 		ch = getch()*/
    _ch_25215 = _60getch();
    if (!IS_ATOM_INT(_ch_25215)) {
        _1 = (long)(DBL_PTR(_ch_25215)->dbl);
        DeRefDS(_ch_25215);
        _ch_25215 = _1;
    }

    /** 	end while*/
    goto L1; // [183] 39
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25217, 0)){
        goto LC; // [188] 199
    }

    /** 		string_text &= val*/
    Ref(_val_25217);
    Append(&_string_text_25220, _string_text_25220, _val_25217);
LC: 

    /** 	return string_text*/
    DeRef(_val_25217);
    return _string_text_25220;
    ;
}


int _60Scanner()
{
    int _fwd_inlined_set_qualified_fwd_at_441_25358 = NOVALUE;
    int _ch_25259 = NOVALUE;
    int _i_25260 = NOVALUE;
    int _sp_25261 = NOVALUE;
    int _prev_Nne_25262 = NOVALUE;
    int _pch_25263 = NOVALUE;
    int _cline_25264 = NOVALUE;
    int _yytext_25265 = NOVALUE;
    int _namespaces_25266 = NOVALUE;
    int _d_25267 = NOVALUE;
    int _tok_25269 = NOVALUE;
    int _is_int_25270 = NOVALUE;
    int _class_25271 = NOVALUE;
    int _name_25272 = NOVALUE;
    int _is_namespace_25331 = NOVALUE;
    int _basetype_25565 = NOVALUE;
    int _hdigit_25605 = NOVALUE;
    int _fch_25743 = NOVALUE;
    int _cnest_25920 = NOVALUE;
    int _ach_25949 = NOVALUE;
    int _31399 = NOVALUE;
    int _31398 = NOVALUE;
    int _31397 = NOVALUE;
    int _31396 = NOVALUE;
    int _31395 = NOVALUE;
    int _31394 = NOVALUE;
    int _31393 = NOVALUE;
    int _14734 = NOVALUE;
    int _14733 = NOVALUE;
    int _14731 = NOVALUE;
    int _14729 = NOVALUE;
    int _14728 = NOVALUE;
    int _14727 = NOVALUE;
    int _14725 = NOVALUE;
    int _14724 = NOVALUE;
    int _14723 = NOVALUE;
    int _14722 = NOVALUE;
    int _14720 = NOVALUE;
    int _14719 = NOVALUE;
    int _14717 = NOVALUE;
    int _14715 = NOVALUE;
    int _14714 = NOVALUE;
    int _14712 = NOVALUE;
    int _14710 = NOVALUE;
    int _14709 = NOVALUE;
    int _14707 = NOVALUE;
    int _14705 = NOVALUE;
    int _14704 = NOVALUE;
    int _14703 = NOVALUE;
    int _14702 = NOVALUE;
    int _14701 = NOVALUE;
    int _14699 = NOVALUE;
    int _14698 = NOVALUE;
    int _14688 = NOVALUE;
    int _14675 = NOVALUE;
    int _14671 = NOVALUE;
    int _14670 = NOVALUE;
    int _14666 = NOVALUE;
    int _14665 = NOVALUE;
    int _14664 = NOVALUE;
    int _14663 = NOVALUE;
    int _14661 = NOVALUE;
    int _14660 = NOVALUE;
    int _14657 = NOVALUE;
    int _14656 = NOVALUE;
    int _14655 = NOVALUE;
    int _14654 = NOVALUE;
    int _14653 = NOVALUE;
    int _14652 = NOVALUE;
    int _14650 = NOVALUE;
    int _14649 = NOVALUE;
    int _14648 = NOVALUE;
    int _14647 = NOVALUE;
    int _14646 = NOVALUE;
    int _14645 = NOVALUE;
    int _14643 = NOVALUE;
    int _14642 = NOVALUE;
    int _14639 = NOVALUE;
    int _14636 = NOVALUE;
    int _14631 = NOVALUE;
    int _14630 = NOVALUE;
    int _14629 = NOVALUE;
    int _14628 = NOVALUE;
    int _14627 = NOVALUE;
    int _14626 = NOVALUE;
    int _14624 = NOVALUE;
    int _14623 = NOVALUE;
    int _14622 = NOVALUE;
    int _14621 = NOVALUE;
    int _14620 = NOVALUE;
    int _14619 = NOVALUE;
    int _14617 = NOVALUE;
    int _14616 = NOVALUE;
    int _14613 = NOVALUE;
    int _14610 = NOVALUE;
    int _14608 = NOVALUE;
    int _14607 = NOVALUE;
    int _14603 = NOVALUE;
    int _14602 = NOVALUE;
    int _14598 = NOVALUE;
    int _14597 = NOVALUE;
    int _14596 = NOVALUE;
    int _14594 = NOVALUE;
    int _14589 = NOVALUE;
    int _14586 = NOVALUE;
    int _14585 = NOVALUE;
    int _14584 = NOVALUE;
    int _14583 = NOVALUE;
    int _14577 = NOVALUE;
    int _14575 = NOVALUE;
    int _14570 = NOVALUE;
    int _14569 = NOVALUE;
    int _14568 = NOVALUE;
    int _14567 = NOVALUE;
    int _14566 = NOVALUE;
    int _14565 = NOVALUE;
    int _14564 = NOVALUE;
    int _14562 = NOVALUE;
    int _14560 = NOVALUE;
    int _14559 = NOVALUE;
    int _14558 = NOVALUE;
    int _14557 = NOVALUE;
    int _14556 = NOVALUE;
    int _14554 = NOVALUE;
    int _14550 = NOVALUE;
    int _14549 = NOVALUE;
    int _14548 = NOVALUE;
    int _14547 = NOVALUE;
    int _14546 = NOVALUE;
    int _14544 = NOVALUE;
    int _14543 = NOVALUE;
    int _14541 = NOVALUE;
    int _14537 = NOVALUE;
    int _14534 = NOVALUE;
    int _14533 = NOVALUE;
    int _14531 = NOVALUE;
    int _14530 = NOVALUE;
    int _14529 = NOVALUE;
    int _14526 = NOVALUE;
    int _14524 = NOVALUE;
    int _14523 = NOVALUE;
    int _14519 = NOVALUE;
    int _14515 = NOVALUE;
    int _14512 = NOVALUE;
    int _14506 = NOVALUE;
    int _14498 = NOVALUE;
    int _14497 = NOVALUE;
    int _14496 = NOVALUE;
    int _14494 = NOVALUE;
    int _14491 = NOVALUE;
    int _14489 = NOVALUE;
    int _14487 = NOVALUE;
    int _14484 = NOVALUE;
    int _14481 = NOVALUE;
    int _14479 = NOVALUE;
    int _14477 = NOVALUE;
    int _14475 = NOVALUE;
    int _14474 = NOVALUE;
    int _14470 = NOVALUE;
    int _14467 = NOVALUE;
    int _14465 = NOVALUE;
    int _14462 = NOVALUE;
    int _14455 = NOVALUE;
    int _14453 = NOVALUE;
    int _14450 = NOVALUE;
    int _14444 = NOVALUE;
    int _14443 = NOVALUE;
    int _14442 = NOVALUE;
    int _14441 = NOVALUE;
    int _14440 = NOVALUE;
    int _14439 = NOVALUE;
    int _14438 = NOVALUE;
    int _14436 = NOVALUE;
    int _14434 = NOVALUE;
    int _14432 = NOVALUE;
    int _14430 = NOVALUE;
    int _14428 = NOVALUE;
    int _14427 = NOVALUE;
    int _14426 = NOVALUE;
    int _14425 = NOVALUE;
    int _14424 = NOVALUE;
    int _14422 = NOVALUE;
    int _14419 = NOVALUE;
    int _14417 = NOVALUE;
    int _14416 = NOVALUE;
    int _14415 = NOVALUE;
    int _14413 = NOVALUE;
    int _14408 = NOVALUE;
    int _14404 = NOVALUE;
    int _14401 = NOVALUE;
    int _14399 = NOVALUE;
    int _14398 = NOVALUE;
    int _14396 = NOVALUE;
    int _14394 = NOVALUE;
    int _14392 = NOVALUE;
    int _14391 = NOVALUE;
    int _14390 = NOVALUE;
    int _14388 = NOVALUE;
    int _14383 = NOVALUE;
    int _14380 = NOVALUE;
    int _14378 = NOVALUE;
    int _14375 = NOVALUE;
    int _14374 = NOVALUE;
    int _14372 = NOVALUE;
    int _14371 = NOVALUE;
    int _14370 = NOVALUE;
    int _14369 = NOVALUE;
    int _14368 = NOVALUE;
    int _14367 = NOVALUE;
    int _14366 = NOVALUE;
    int _14365 = NOVALUE;
    int _14364 = NOVALUE;
    int _14363 = NOVALUE;
    int _14362 = NOVALUE;
    int _14361 = NOVALUE;
    int _14360 = NOVALUE;
    int _14355 = NOVALUE;
    int _14353 = NOVALUE;
    int _14350 = NOVALUE;
    int _14348 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer is_int, class*/

    /** 	sequence name*/

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_431 == 0)
    {
        goto L2; // [12] 3802
    }
    else{
    }

    /** 		ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 		while ch = ' ' or ch = '\t' do*/
L3: 
    _14348 = (_ch_25259 == 32);
    if (_14348 != 0) {
        goto L4; // [31] 44
    }
    _14350 = (_ch_25259 == 9);
    if (_14350 == 0)
    {
        DeRef(_14350);
        _14350 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_14350);
        _14350 = NOVALUE;
    }
L4: 

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 		end while*/
    goto L3; // [53] 27
L5: 

    /** 		class = char_class[ch]*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _class_25271 = (int)*(((s1_ptr)_2)->base + _ch_25259);

    /** 		if class = LETTER or ch = '_' then*/
    _14353 = (_class_25271 == -2);
    if (_14353 != 0) {
        goto L6; // [72] 85
    }
    _14355 = (_ch_25259 == 95);
    if (_14355 == 0)
    {
        DeRef(_14355);
        _14355 = NOVALUE;
        goto L7; // [81] 1282
    }
    else{
        DeRef(_14355);
        _14355 = NOVALUE;
    }
L6: 

    /** 			sp = bp*/
    _sp_25261 = _43bp_48162;

    /** 			pch = ch*/
    _pch_25263 = _ch_25259;

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25259 != 34)
    goto L8; // [108] 222

    /** 				switch pch do*/
    _0 = _pch_25263;
    switch ( _0 ){ 

        /** 					case 'x' then*/
        case 120:

        /** 						return {STRING, NewStringSym(GetHexString(2))}*/
        _14360 = _60GetHexString(2);
        _14361 = _52NewStringSym(_14360);
        _14360 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14361;
        _14362 = MAKE_SEQ(_1);
        _14361 = NOVALUE;
        DeRef(_yytext_25265);
        DeRef(_namespaces_25266);
        DeRef(_d_25267);
        DeRef(_tok_25269);
        DeRef(_name_25272);
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14353);
        _14353 = NOVALUE;
        return _14362;
        goto L9; // [143] 221

        /** 					case 'u' then*/
        case 117:

        /** 						return {STRING, NewStringSym(GetHexString(4))}*/
        _14363 = _60GetHexString(4);
        _14364 = _52NewStringSym(_14363);
        _14363 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14364;
        _14365 = MAKE_SEQ(_1);
        _14364 = NOVALUE;
        DeRef(_yytext_25265);
        DeRef(_namespaces_25266);
        DeRef(_d_25267);
        DeRef(_tok_25269);
        DeRef(_name_25272);
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14353);
        _14353 = NOVALUE;
        DeRef(_14362);
        _14362 = NOVALUE;
        return _14365;
        goto L9; // [169] 221

        /** 					case 'U' then*/
        case 85:

        /** 						return {STRING, NewStringSym(GetHexString(8))}*/
        _14366 = _60GetHexString(8);
        _14367 = _52NewStringSym(_14366);
        _14366 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14367;
        _14368 = MAKE_SEQ(_1);
        _14367 = NOVALUE;
        DeRef(_yytext_25265);
        DeRef(_namespaces_25266);
        DeRef(_d_25267);
        DeRef(_tok_25269);
        DeRef(_name_25272);
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14353);
        _14353 = NOVALUE;
        DeRef(_14362);
        _14362 = NOVALUE;
        DeRef(_14365);
        _14365 = NOVALUE;
        return _14368;
        goto L9; // [195] 221

        /** 					case 'b' then*/
        case 98:

        /** 						return {STRING, NewStringSym(GetBitString())}*/
        _14369 = _60GetBitString();
        _14370 = _52NewStringSym(_14369);
        _14369 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14370;
        _14371 = MAKE_SEQ(_1);
        _14370 = NOVALUE;
        DeRef(_yytext_25265);
        DeRef(_namespaces_25266);
        DeRef(_d_25267);
        DeRef(_tok_25269);
        DeRef(_name_25272);
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14353);
        _14353 = NOVALUE;
        DeRef(_14362);
        _14362 = NOVALUE;
        DeRef(_14365);
        _14365 = NOVALUE;
        DeRef(_14368);
        _14368 = NOVALUE;
        return _14371;
    ;}L9: 
L8: 

    /** 			while id_char[ch] do*/
LA: 
    _2 = (int)SEQ_PTR(_60id_char_23572);
    _14372 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14372 == 0)
    {
        _14372 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _14372 = NOVALUE;
    }

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			end while*/
    goto LA; // [245] 227
LB: 

    /** 			yytext = ThisLine[sp-1..bp-2]*/
    _14374 = _sp_25261 - 1;
    if ((long)((unsigned long)_14374 +(unsigned long) HIGH_BITS) >= 0){
        _14374 = NewDouble((double)_14374);
    }
    _14375 = _43bp_48162 - 2;
    rhs_slice_target = (object_ptr)&_yytext_25265;
    RHS_Slice(_43ThisLine_48158, _14374, _14375);

    /** 			ungetch()*/
    _60ungetch();

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			while ch = ' ' or ch = '\t' do*/
LC: 
    _14378 = (_ch_25259 == 32);
    if (_14378 != 0) {
        goto LD; // [287] 300
    }
    _14380 = (_ch_25259 == 9);
    if (_14380 == 0)
    {
        DeRef(_14380);
        _14380 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_14380);
        _14380 = NOVALUE;
    }
LD: 

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			end while*/
    goto LC; // [309] 283
LE: 

    /** 			integer is_namespace*/

    /** 			if might_be_namespace then*/
    if (_60might_be_namespace_25063 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** 				tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_25265);
    _31399 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, -1, _12current_file_no_11682, -1, _31399);
    DeRef(_0);
    _31399 = NOVALUE;

    /** 				is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14383 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14383)) {
        _is_namespace_25331 = (_14383 == 523);
    }
    else {
        _is_namespace_25331 = binary_op(EQUALS, _14383, 523);
    }
    _14383 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_25331)) {
        _1 = (long)(DBL_PTR(_is_namespace_25331)->dbl);
        DeRefDS(_is_namespace_25331);
        _is_namespace_25331 = _1;
    }

    /** 				might_be_namespace = 0*/
    _60might_be_namespace_25063 = 0;
    goto L10; // [358] 384
LF: 

    /** 				is_namespace = ch = ':'*/
    _is_namespace_25331 = (_ch_25259 == 58);

    /** 				tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_25265);
    _31398 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, -1, _12current_file_no_11682, _is_namespace_25331, _31398);
    DeRef(_0);
    _31398 = NOVALUE;
L10: 

    /** 			if not is_namespace then*/
    if (_is_namespace_25331 != 0)
    goto L11; // [388] 396

    /** 				ungetch()*/
    _60ungetch();
L11: 

    /** 			if is_namespace then*/
    if (_is_namespace_25331 == 0)
    {
        goto L12; // [398] 1119
    }
    else{
    }

    /** 				namespaces = yytext*/
    RefDS(_yytext_25265);
    DeRef(_namespaces_25266);
    _namespaces_25266 = _yytext_25265;

    /** 				if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14388 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14388, 523)){
        _14388 = NOVALUE;
        goto L13; // [420] 974
    }
    _14388 = NOVALUE;

    /** 					set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14390 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_14390)){
        _14391 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14390)->dbl));
    }
    else{
        _14391 = (int)*(((s1_ptr)_2)->base + _14390);
    }
    _2 = (int)SEQ_PTR(_14391);
    _14392 = (int)*(((s1_ptr)_2)->base + 1);
    _14391 = NOVALUE;
    Ref(_14392);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25358);
    _fwd_inlined_set_qualified_fwd_at_441_25358 = _14392;
    _14392 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_25358)) {
        _1 = (long)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_25358)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_25358);
        _fwd_inlined_set_qualified_fwd_at_441_25358 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23596 = _fwd_inlined_set_qualified_fwd_at_441_25358;

    /** end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25358);
    _fwd_inlined_set_qualified_fwd_at_441_25358 = NOVALUE;

    /** 					ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 					while ch = ' ' or ch = '\t' do*/
L15: 
    _14394 = (_ch_25259 == 32);
    if (_14394 != 0) {
        goto L16; // [477] 490
    }
    _14396 = (_ch_25259 == 9);
    if (_14396 == 0)
    {
        DeRef(_14396);
        _14396 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_14396);
        _14396 = NOVALUE;
    }
L16: 

    /** 						ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 					end while*/
    goto L15; // [499] 473
L17: 

    /** 					yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25265);
    _yytext_25265 = _5;

    /** 					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14398 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    _14399 = (_14398 == -2);
    _14398 = NOVALUE;
    if (_14399 != 0) {
        goto L18; // [523] 536
    }
    _14401 = (_ch_25259 == 95);
    if (_14401 == 0)
    {
        DeRef(_14401);
        _14401 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_14401);
        _14401 = NOVALUE;
    }
L18: 

    /** 						yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 						ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 						while id_char[ch] = TRUE do*/
L1A: 
    _2 = (int)SEQ_PTR(_60id_char_23572);
    _14404 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14404 != _9TRUE_431)
    goto L1B; // [562] 584

    /** 							yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 							ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 						end while*/
    goto L1A; // [581] 554
L1B: 

    /** 						ungetch()*/
    _60ungetch();
L19: 

    /** 					if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_25265)){
            _14408 = SEQ_PTR(_yytext_25265)->length;
    }
    else {
        _14408 = 1;
    }
    if (_14408 != 0)
    goto L1C; // [594] 606

    /** 						CompileErr(32)*/
    RefDS(_21829);
    _43CompileErr(32, _21829, 0);
L1C: 

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_11788 != 1)
    goto L1D; // [612] 773

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25265);
    Append(&_12Recorded_11789, _12Recorded_11789, _yytext_25265);

    /** 		                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_25266);
    Append(&_12Ns_recorded_11790, _12Ns_recorded_11790, _namespaces_25266);

    /** 		                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14413 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Ns_recorded_sym_11792) && IS_ATOM(_14413)) {
        Ref(_14413);
        Append(&_12Ns_recorded_sym_11792, _12Ns_recorded_sym_11792, _14413);
    }
    else if (IS_ATOM(_12Ns_recorded_sym_11792) && IS_SEQUENCE(_14413)) {
    }
    else {
        Concat((object_ptr)&_12Ns_recorded_sym_11792, _12Ns_recorded_sym_11792, _14413);
    }
    _14413 = NOVALUE;

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25262 = _52No_new_entry_46903;

    /** 						No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14415 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_14415)){
        _14416 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14415)->dbl));
    }
    else{
        _14416 = (int)*(((s1_ptr)_2)->base + _14415);
    }
    _2 = (int)SEQ_PTR(_14416);
    _14417 = (int)*(((s1_ptr)_2)->base + 1);
    _14416 = NOVALUE;
    RefDS(_yytext_25265);
    _31397 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    Ref(_14417);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, _14417, _12current_file_no_11682, 0, _31397);
    DeRef(_0);
    _14417 = NOVALUE;
    _31397 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14419 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14419, 509)){
        _14419 = NOVALUE;
        goto L1E; // [712] 729
    }
    _14419 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, 0);
    goto L1F; // [726] 746
L1E: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14422 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_11791) && IS_ATOM(_14422)) {
        Ref(_14422);
        Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, _14422);
    }
    else if (IS_ATOM(_12Recorded_sym_11791) && IS_SEQUENCE(_14422)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_11791, _12Recorded_sym_11791, _14422);
    }
    _14422 = NOVALUE;
L1F: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_46903 = _prev_Nne_25262;

    /** 		                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_11789)){
            _14424 = SEQ_PTR(_12Recorded_11789)->length;
    }
    else {
        _14424 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14424;
    _14425 = MAKE_SEQ(_1);
    _14424 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    _14415 = NOVALUE;
    return _14425;
    goto L20; // [770] 915
L1D: 

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14426 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_14426)){
        _14427 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14426)->dbl));
    }
    else{
        _14427 = (int)*(((s1_ptr)_2)->base + _14426);
    }
    _2 = (int)SEQ_PTR(_14427);
    _14428 = (int)*(((s1_ptr)_2)->base + 1);
    _14427 = NOVALUE;
    RefDS(_yytext_25265);
    _31396 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    Ref(_14428);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, _14428, _12current_file_no_11682, 0, _31396);
    DeRef(_0);
    _14428 = NOVALUE;
    _31396 = NOVALUE;

    /** 						if tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14430 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14430, -100)){
        _14430 = NOVALUE;
        goto L21; // [817] 834
    }
    _14430 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (int)SEQ_PTR(_tok_25269);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25269 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 512;
    DeRef(_1);
    goto L22; // [831] 914
L21: 

    /** 						elsif tok[T_ID] = FUNC then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14432 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14432, 501)){
        _14432 = NOVALUE;
        goto L23; // [844] 861
    }
    _14432 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (int)SEQ_PTR(_tok_25269);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25269 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 520;
    DeRef(_1);
    goto L22; // [858] 914
L23: 

    /** 						elsif tok[T_ID] = PROC then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14434 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14434, 27)){
        _14434 = NOVALUE;
        goto L24; // [871] 888
    }
    _14434 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_PROC*/
    _2 = (int)SEQ_PTR(_tok_25269);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25269 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 521;
    DeRef(_1);
    goto L22; // [885] 914
L24: 

    /** 						elsif tok[T_ID] = TYPE then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14436 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14436, 504)){
        _14436 = NOVALUE;
        goto L25; // [898] 913
    }
    _14436 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (int)SEQ_PTR(_tok_25269);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25269 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** 					if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14438 = (int)*(((s1_ptr)_2)->base + 2);
    _14439 = IS_ATOM(_14438);
    _14438 = NOVALUE;
    if (_14439 == 0) {
        goto L26; // [926] 1269
    }
    _2 = (int)SEQ_PTR(_tok_25269);
    _14441 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_14441)){
        _14442 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14441)->dbl));
    }
    else{
        _14442 = (int)*(((s1_ptr)_2)->base + _14441);
    }
    _2 = (int)SEQ_PTR(_14442);
    _14443 = (int)*(((s1_ptr)_2)->base + 4);
    _14442 = NOVALUE;
    if (IS_ATOM_INT(_14443)) {
        _14444 = (_14443 != 9);
    }
    else {
        _14444 = binary_op(NOTEQ, _14443, 9);
    }
    _14443 = NOVALUE;
    if (_14444 == 0) {
        DeRef(_14444);
        _14444 = NOVALUE;
        goto L26; // [955] 1269
    }
    else {
        if (!IS_ATOM_INT(_14444) && DBL_PTR(_14444)->dbl == 0.0){
            DeRef(_14444);
            _14444 = NOVALUE;
            goto L26; // [955] 1269
        }
        DeRef(_14444);
        _14444 = NOVALUE;
    }
    DeRef(_14444);
    _14444 = NOVALUE;

    /** 						set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23596 = -1;

    /** end procedure*/
    goto L26; // [967] 1269
    goto L26; // [971] 1269
L13: 

    /** 					ungetch()*/
    _60ungetch();

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_11788 != 1)
    goto L26; // [984] 1269

    /** 		                Ns_recorded &= 0*/
    Append(&_12Ns_recorded_11790, _12Ns_recorded_11790, 0);

    /** 		                Ns_recorded_sym &= 0*/
    Append(&_12Ns_recorded_sym_11792, _12Ns_recorded_sym_11792, 0);

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25265);
    Append(&_12Recorded_11789, _12Recorded_11789, _yytext_25265);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25262 = _52No_new_entry_46903;

    /** 						No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25265);
    _31395 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, -1, _12current_file_no_11682, 0, _31395);
    DeRef(_0);
    _31395 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14450 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14450, 509)){
        _14450 = NOVALUE;
        goto L27; // [1060] 1077
    }
    _14450 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, 0);
    goto L28; // [1074] 1094
L27: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14453 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_11791) && IS_ATOM(_14453)) {
        Ref(_14453);
        Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, _14453);
    }
    else if (IS_ATOM(_12Recorded_sym_11791) && IS_SEQUENCE(_14453)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_11791, _12Recorded_sym_11791, _14453);
    }
    _14453 = NOVALUE;
L28: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_46903 = _prev_Nne_25262;

    /** 		                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_11789)){
            _14455 = SEQ_PTR(_12Recorded_11789)->length;
    }
    else {
        _14455 = 1;
    }
    DeRef(_tok_25269);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14455;
    _tok_25269 = MAKE_SEQ(_1);
    _14455 = NOVALUE;
    goto L26; // [1116] 1269
L12: 

    /** 				set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23596 = -1;

    /** end procedure*/
    goto L29; // [1128] 1131
L29: 

    /** 			    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_11788 != 1)
    goto L2A; // [1137] 1268

    /** 	                Ns_recorded_sym &= 0*/
    Append(&_12Ns_recorded_sym_11792, _12Ns_recorded_sym_11792, 0);

    /** 						Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_25265);
    Append(&_12Recorded_11789, _12Recorded_11789, _yytext_25265);

    /** 		                Ns_recorded &= 0*/
    Append(&_12Ns_recorded_11790, _12Ns_recorded_11790, 0);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25262 = _52No_new_entry_46903;

    /** 						No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25265);
    _31394 = _52hashfn(_yytext_25265);
    RefDS(_yytext_25265);
    _0 = _tok_25269;
    _tok_25269 = _52keyfind(_yytext_25265, -1, _12current_file_no_11682, 0, _31394);
    DeRef(_0);
    _31394 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14462 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14462, 509)){
        _14462 = NOVALUE;
        goto L2B; // [1213] 1230
    }
    _14462 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, 0);
    goto L2C; // [1227] 1247
L2B: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25269);
    _14465 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_11791) && IS_ATOM(_14465)) {
        Ref(_14465);
        Append(&_12Recorded_sym_11791, _12Recorded_sym_11791, _14465);
    }
    else if (IS_ATOM(_12Recorded_sym_11791) && IS_SEQUENCE(_14465)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_11791, _12Recorded_sym_11791, _14465);
    }
    _14465 = NOVALUE;
L2C: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_46903 = _prev_Nne_25262;

    /** 	                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_11789)){
            _14467 = SEQ_PTR(_12Recorded_11789)->length;
    }
    else {
        _14467 = 1;
    }
    DeRef(_tok_25269);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14467;
    _tok_25269 = MAKE_SEQ(_1);
    _14467 = NOVALUE;
L2A: 
L26: 

    /** 			return tok*/
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_name_25272);
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    _14415 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    _14426 = NOVALUE;
    _14441 = NOVALUE;
    return _tok_25269;
    goto L1; // [1279] 10
L7: 

    /** 		elsif class < ILLEGAL_CHAR then*/
    if (_class_25271 >= -20)
    goto L2D; // [1286] 1303

    /** 			return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25271;
    ((int *)_2)[2] = 0;
    _14470 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    _14415 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    _14426 = NOVALUE;
    _14441 = NOVALUE;
    return _14470;
    goto L1; // [1300] 10
L2D: 

    /** 		elsif class = ILLEGAL_CHAR then*/
    if (_class_25271 != -20)
    goto L2E; // [1307] 1321

    /** 			CompileErr(101)*/
    RefDS(_21829);
    _43CompileErr(101, _21829, 0);
    goto L1; // [1318] 10
L2E: 

    /** 		elsif class = NEWLINE then*/
    if (_class_25271 != -6)
    goto L2F; // [1325] 1351

    /** 			if start_include then*/
    if (_60start_include_23564 == 0)
    {
        goto L30; // [1333] 1343
    }
    else{
    }

    /** 				IncludePush()*/
    _60IncludePush();
    goto L1; // [1340] 10
L30: 

    /** 				read_line()*/
    _60read_line();
    goto L1; // [1348] 10
L2F: 

    /** 		elsif class = EQUALS then*/
    if (_class_25271 != 3)
    goto L31; // [1355] 1372

    /** 			return {class, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25271;
    ((int *)_2)[2] = 0;
    _14474 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    _14415 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    _14426 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    return _14474;
    goto L1; // [1369] 10
L31: 

    /** 		elsif class = DOT or class = DIGIT then*/
    _14475 = (_class_25271 == -3);
    if (_14475 != 0) {
        goto L32; // [1380] 1395
    }
    _14477 = (_class_25271 == -7);
    if (_14477 == 0)
    {
        DeRef(_14477);
        _14477 = NOVALUE;
        goto L33; // [1391] 2196
    }
    else{
        DeRef(_14477);
        _14477 = NOVALUE;
    }
L32: 

    /** 			integer basetype*/

    /** 			if class = DOT then*/
    if (_class_25271 != -3)
    goto L34; // [1401] 1435

    /** 				if getch() = '.' then*/
    _14479 = _60getch();
    if (binary_op_a(NOTEQ, _14479, 46)){
        DeRef(_14479);
        _14479 = NOVALUE;
        goto L35; // [1410] 1429
    }
    DeRef(_14479);
    _14479 = NOVALUE;

    /** 					return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 513;
    ((int *)_2)[2] = 0;
    _14481 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    _14415 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    _14426 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    return _14481;
    goto L36; // [1426] 1434
L35: 

    /** 					ungetch()*/
    _60ungetch();
L36: 
L34: 

    /** 			yytext = {ch}*/
    _0 = _yytext_25265;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25259;
    _yytext_25265 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			is_int = (ch != '.')*/
    _is_int_25270 = (_ch_25259 != 46);

    /** 			basetype = -1 -- default is decimal*/
    _basetype_25565 = -1;

    /** 			while 1 with entry do*/
    goto L37; // [1454] 1645
L38: 

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14484 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14484 != -7)
    goto L39; // [1467] 1480

    /** 					yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);
    goto L3A; // [1477] 1642
L39: 

    /** 				elsif equal(yytext, "0") then*/
    if (_yytext_25265 == _14138)
    _14487 = 1;
    else if (IS_ATOM_INT(_yytext_25265) && IS_ATOM_INT(_14138))
    _14487 = 0;
    else
    _14487 = (compare(_yytext_25265, _14138) == 0);
    if (_14487 == 0)
    {
        _14487 = NOVALUE;
        goto L3B; // [1486] 1581
    }
    else{
        _14487 = NOVALUE;
    }

    /** 					basetype = find(ch, nbasecode)*/
    _basetype_25565 = find_from(_ch_25259, _60nbasecode_25067, 1);

    /** 					if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_60nbase_25066)){
            _14489 = SEQ_PTR(_60nbase_25066)->length;
    }
    else {
        _14489 = 1;
    }
    if (_basetype_25565 <= _14489)
    goto L3C; // [1501] 1515

    /** 						basetype -= length(nbase)*/
    if (IS_SEQUENCE(_60nbase_25066)){
            _14491 = SEQ_PTR(_60nbase_25066)->length;
    }
    else {
        _14491 = 1;
    }
    _basetype_25565 = _basetype_25565 - _14491;
    _14491 = NOVALUE;
L3C: 

    /** 					if basetype = 0 then*/
    if (_basetype_25565 != 0)
    goto L3D; // [1517] 1572

    /** 						if char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14494 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14494 != -2)
    goto L3E; // [1531] 1562

    /** 							if ch != 'e' and ch != 'E' then*/
    _14496 = (_ch_25259 != 101);
    if (_14496 == 0) {
        goto L3F; // [1541] 1561
    }
    _14498 = (_ch_25259 != 69);
    if (_14498 == 0)
    {
        DeRef(_14498);
        _14498 = NOVALUE;
        goto L3F; // [1550] 1561
    }
    else{
        DeRef(_14498);
        _14498 = NOVALUE;
    }

    /** 								CompileErr(105, ch)*/
    _43CompileErr(105, _ch_25259, 0);
L3F: 
L3E: 

    /** 						basetype = -1 -- decimal*/
    _basetype_25565 = -1;

    /** 						exit*/
    goto L40; // [1569] 1657
L3D: 

    /** 					yytext &= '0'*/
    Append(&_yytext_25265, _yytext_25265, 48);
    goto L3A; // [1578] 1642
L3B: 

    /** 				elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_25565 != 4)
    goto L40; // [1583] 1657

    /** 					integer hdigit*/

    /** 					hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_25605 = find_from(_ch_25259, _14501, 1);

    /** 					if hdigit = 0 then*/
    if (_hdigit_25605 != 0)
    goto L41; // [1598] 1609

    /** 						exit*/
    goto L40; // [1606] 1657
L41: 

    /** 					if hdigit > 6 then*/
    if (_hdigit_25605 <= 6)
    goto L42; // [1611] 1622

    /** 						hdigit -= 6*/
    _hdigit_25605 = _hdigit_25605 - 6;
L42: 

    /** 					yytext &= hexasc[hdigit]*/
    _2 = (int)SEQ_PTR(_60hexasc_25069);
    _14506 = (int)*(((s1_ptr)_2)->base + _hdigit_25605);
    if (IS_SEQUENCE(_yytext_25265) && IS_ATOM(_14506)) {
        Ref(_14506);
        Append(&_yytext_25265, _yytext_25265, _14506);
    }
    else if (IS_ATOM(_yytext_25265) && IS_SEQUENCE(_14506)) {
    }
    else {
        Concat((object_ptr)&_yytext_25265, _yytext_25265, _14506);
    }
    _14506 = NOVALUE;
    goto L3A; // [1634] 1642

    /** 					exit*/
    goto L40; // [1639] 1657
L3A: 

    /** 			entry*/
L37: 

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			end while*/
    goto L38; // [1654] 1457
L40: 

    /** 			if ch = '.' then*/
    if (_ch_25259 != 46)
    goto L43; // [1659] 1794

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 				if ch = '.' then*/
    if (_ch_25259 != 46)
    goto L44; // [1672] 1683

    /** 					ungetch()*/
    _60ungetch();
    goto L45; // [1680] 1793
L44: 

    /** 					is_int = FALSE*/
    _is_int_25270 = _9FALSE_429;

    /** 					if yytext[1] = '.' then*/
    _2 = (int)SEQ_PTR(_yytext_25265);
    _14512 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14512, 46)){
        _14512 = NOVALUE;
        goto L46; // [1698] 1712
    }
    _14512 = NOVALUE;

    /** 						CompileErr(124)*/
    RefDS(_21829);
    _43CompileErr(124, _21829, 0);
    goto L47; // [1709] 1719
L46: 

    /** 						yytext &= '.'*/
    Append(&_yytext_25265, _yytext_25265, 46);
L47: 

    /** 					if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14515 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14515 != -7)
    goto L48; // [1729] 1784

    /** 						yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 						ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 						while char_class[ch] = DIGIT do*/
L49: 
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14519 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14519 != -7)
    goto L4A; // [1759] 1792

    /** 							yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 							ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 						end while*/
    goto L49; // [1778] 1751
    goto L4A; // [1781] 1792
L48: 

    /** 						CompileErr(94)*/
    RefDS(_21829);
    _43CompileErr(94, _21829, 0);
L4A: 
L45: 
L43: 

    /** 			if basetype = -1 and find(ch, "eE") then*/
    _14523 = (_basetype_25565 == -1);
    if (_14523 == 0) {
        goto L4B; // [1800] 1936
    }
    _14526 = find_from(_ch_25259, _14525, 1);
    if (_14526 == 0)
    {
        _14526 = NOVALUE;
        goto L4B; // [1810] 1936
    }
    else{
        _14526 = NOVALUE;
    }

    /** 				is_int = FALSE*/
    _is_int_25270 = _9FALSE_429;

    /** 				yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 				if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _14529 = (_ch_25259 == 45);
    if (_14529 != 0) {
        _14530 = 1;
        goto L4C; // [1841] 1853
    }
    _14531 = (_ch_25259 == 43);
    _14530 = (_14531 != 0);
L4C: 
    if (_14530 != 0) {
        goto L4D; // [1853] 1874
    }
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14533 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    _14534 = (_14533 == -7);
    _14533 = NOVALUE;
    if (_14534 == 0)
    {
        DeRef(_14534);
        _14534 = NOVALUE;
        goto L4E; // [1870] 1883
    }
    else{
        DeRef(_14534);
        _14534 = NOVALUE;
    }
L4D: 

    /** 					yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);
    goto L4F; // [1880] 1891
L4E: 

    /** 					CompileErr(86)*/
    RefDS(_21829);
    _43CompileErr(86, _21829, 0);
L4F: 

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 				while char_class[ch] = DIGIT do*/
L50: 
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14537 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14537 != -7)
    goto L51; // [1911] 1967

    /** 					yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);

    /** 					ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 				end while*/
    goto L50; // [1930] 1903
    goto L51; // [1933] 1967
L4B: 

    /** 			elsif char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14541 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14541 != -2)
    goto L52; // [1946] 1966

    /** 				CompileErr(127, {{ch}})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25259;
    _14543 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14543;
    _14544 = MAKE_SEQ(_1);
    _14543 = NOVALUE;
    _43CompileErr(127, _14544, 0);
    _14544 = NOVALUE;
L52: 
L51: 

    /** 			ungetch()*/
    _60ungetch();

    /** 			while i != 0 with entry do*/
    goto L53; // [1973] 2012
L54: 
    if (_i_25260 == 0)
    goto L55; // [1978] 2024

    /** 			    yytext = yytext[1 .. i-1] & yytext[i+1 .. $]*/
    _14546 = _i_25260 - 1;
    rhs_slice_target = (object_ptr)&_14547;
    RHS_Slice(_yytext_25265, 1, _14546);
    _14548 = _i_25260 + 1;
    if (_14548 > MAXINT){
        _14548 = NewDouble((double)_14548);
    }
    if (IS_SEQUENCE(_yytext_25265)){
            _14549 = SEQ_PTR(_yytext_25265)->length;
    }
    else {
        _14549 = 1;
    }
    rhs_slice_target = (object_ptr)&_14550;
    RHS_Slice(_yytext_25265, _14548, _14549);
    Concat((object_ptr)&_yytext_25265, _14547, _14550);
    DeRefDS(_14547);
    _14547 = NOVALUE;
    DeRef(_14547);
    _14547 = NOVALUE;
    DeRefDS(_14550);
    _14550 = NOVALUE;

    /** 			  entry*/
L53: 

    /** 			    i = find('_', yytext)*/
    _i_25260 = find_from(95, _yytext_25265, 1);

    /** 			end while*/
    goto L54; // [2021] 1976
L55: 

    /** 			if is_int then*/
    if (_is_int_25270 == 0)
    {
        goto L56; // [2026] 2097
    }
    else{
    }

    /** 				if basetype = -1 then*/
    if (_basetype_25565 != -1)
    goto L57; // [2031] 2041

    /** 					basetype = 3 -- decimal*/
    _basetype_25565 = 3;
L57: 

    /** 				d = MakeInt(yytext, nbase[basetype])*/
    _2 = (int)SEQ_PTR(_60nbase_25066);
    _14554 = (int)*(((s1_ptr)_2)->base + _basetype_25565);
    RefDS(_yytext_25265);
    Ref(_14554);
    _0 = _d_25267;
    _d_25267 = _60MakeInt(_yytext_25265, _14554);
    DeRef(_0);
    _14554 = NOVALUE;

    /** 				if integer(d) then*/
    if (IS_ATOM_INT(_d_25267))
    _14556 = 1;
    else if (IS_ATOM_DBL(_d_25267))
    _14556 = IS_ATOM_INT(DoubleToInt(_d_25267));
    else
    _14556 = 0;
    if (_14556 == 0)
    {
        _14556 = NOVALUE;
        goto L58; // [2057] 2079
    }
    else{
        _14556 = NOVALUE;
    }

    /** 					return {ATOM, NewIntSym(d)}*/
    Ref(_d_25267);
    _14557 = _52NewIntSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14557;
    _14558 = MAKE_SEQ(_1);
    _14557 = NOVALUE;
    DeRefDS(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14558;
    goto L59; // [2076] 2096
L58: 

    /** 					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25267);
    _14559 = _52NewDoubleSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14559;
    _14560 = MAKE_SEQ(_1);
    _14559 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14560;
L59: 
L56: 

    /** 			if basetype != -1 then*/
    if (_basetype_25565 == -1)
    goto L5A; // [2099] 2115

    /** 				CompileErr(125, nbasecode[basetype])*/
    _2 = (int)SEQ_PTR(_60nbasecode_25067);
    _14562 = (int)*(((s1_ptr)_2)->base + _basetype_25565);
    Ref(_14562);
    _43CompileErr(125, _14562, 0);
    _14562 = NOVALUE;
L5A: 

    /** 			d = my_sscanf(yytext)*/
    RefDS(_yytext_25265);
    _0 = _d_25267;
    _d_25267 = _60my_sscanf(_yytext_25265);
    DeRef(_0);

    /** 			if sequence(d) then*/
    _14564 = IS_SEQUENCE(_d_25267);
    if (_14564 == 0)
    {
        _14564 = NOVALUE;
        goto L5B; // [2126] 2139
    }
    else{
        _14564 = NOVALUE;
    }

    /** 				CompileErr(121)*/
    RefDS(_21829);
    _43CompileErr(121, _21829, 0);
    goto L5C; // [2136] 2191
L5B: 

    /** 			elsif is_int and d <= MAXINT_DBL then*/
    if (_is_int_25270 == 0) {
        goto L5D; // [2141] 2174
    }
    if (IS_ATOM_INT(_d_25267)) {
        _14566 = (_d_25267 <= 1073741823);
    }
    else {
        _14566 = binary_op(LESSEQ, _d_25267, 1073741823);
    }
    if (_14566 == 0) {
        DeRef(_14566);
        _14566 = NOVALUE;
        goto L5D; // [2152] 2174
    }
    else {
        if (!IS_ATOM_INT(_14566) && DBL_PTR(_14566)->dbl == 0.0){
            DeRef(_14566);
            _14566 = NOVALUE;
            goto L5D; // [2152] 2174
        }
        DeRef(_14566);
        _14566 = NOVALUE;
    }
    DeRef(_14566);
    _14566 = NOVALUE;

    /** 				return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_25267);
    _14567 = _52NewIntSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14567;
    _14568 = MAKE_SEQ(_1);
    _14567 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14568;
    goto L5C; // [2171] 2191
L5D: 

    /** 				return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25267);
    _14569 = _52NewDoubleSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14569;
    _14570 = MAKE_SEQ(_1);
    _14569 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14570;
L5C: 
    goto L1; // [2193] 10
L33: 

    /** 		elsif class = MINUS then*/
    if (_class_25271 != 10)
    goto L5E; // [2200] 2286

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_25259 != 45)
    goto L5F; // [2213] 2239

    /** 				if start_include then*/
    if (_60start_include_23564 == 0)
    {
        goto L60; // [2221] 2231
    }
    else{
    }

    /** 					IncludePush()*/
    _60IncludePush();
    goto L1; // [2228] 10
L60: 

    /** 					read_line()*/
    _60read_line();
    goto L1; // [2236] 10
L5F: 

    /** 			elsif ch = '=' then*/
    if (_ch_25259 != 61)
    goto L61; // [2241] 2260

    /** 				return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 516;
    ((int *)_2)[2] = 0;
    _14575 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14575;
    goto L1; // [2257] 10
L61: 

    /** 				bp -= 1*/
    _43bp_48162 = _43bp_48162 - 1;

    /** 				return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 0;
    _14577 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14577;
    goto L1; // [2283] 10
L5E: 

    /** 		elsif class = DOUBLE_QUOTE then*/
    if (_class_25271 != -4)
    goto L62; // [2290] 2484

    /** 			integer fch*/

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25259 != 34)
    goto L63; // [2305] 2341

    /** 				fch = getch()*/
    _fch_25743 = _60getch();
    if (!IS_ATOM_INT(_fch_25743)) {
        _1 = (long)(DBL_PTR(_fch_25743)->dbl);
        DeRefDS(_fch_25743);
        _fch_25743 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25743 != 34)
    goto L64; // [2318] 2335

    /** 					return ExtendedString( fch )*/
    _14583 = _60ExtendedString(_fch_25743);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14583;
    goto L65; // [2332] 2340
L64: 

    /** 					ungetch()*/
    _60ungetch();
L65: 
L63: 

    /** 			yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25265);
    _yytext_25265 = _5;

    /** 			while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _14584 = (_ch_25259 != 10);
    if (_14584 == 0) {
        goto L67; // [2357] 2436
    }
    _14586 = (_ch_25259 != 13);
    if (_14586 == 0)
    {
        DeRef(_14586);
        _14586 = NOVALUE;
        goto L67; // [2366] 2436
    }
    else{
        DeRef(_14586);
        _14586 = NOVALUE;
    }

    /** 				if ch = '"' then*/
    if (_ch_25259 != 34)
    goto L68; // [2371] 2382

    /** 					exit*/
    goto L67; // [2377] 2436
    goto L69; // [2379] 2424
L68: 

    /** 				elsif ch = '\\' then*/
    if (_ch_25259 != 92)
    goto L6A; // [2384] 2401

    /** 					yytext &= EscapeChar('"')*/
    _14589 = _60EscapeChar(34);
    if (IS_SEQUENCE(_yytext_25265) && IS_ATOM(_14589)) {
        Ref(_14589);
        Append(&_yytext_25265, _yytext_25265, _14589);
    }
    else if (IS_ATOM(_yytext_25265) && IS_SEQUENCE(_14589)) {
    }
    else {
        Concat((object_ptr)&_yytext_25265, _yytext_25265, _14589);
    }
    DeRef(_14589);
    _14589 = NOVALUE;
    goto L69; // [2398] 2424
L6A: 

    /** 				elsif ch = '\t' then*/
    if (_ch_25259 != 9)
    goto L6B; // [2403] 2417

    /** 					CompileErr(145)*/
    RefDS(_21829);
    _43CompileErr(145, _21829, 0);
    goto L69; // [2414] 2424
L6B: 

    /** 					yytext &= ch*/
    Append(&_yytext_25265, _yytext_25265, _ch_25259);
L69: 

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			end while*/
    goto L66; // [2433] 2353
L67: 

    /** 			if ch = '\n' or ch = '\r' then*/
    _14594 = (_ch_25259 == 10);
    if (_14594 != 0) {
        goto L6C; // [2442] 2455
    }
    _14596 = (_ch_25259 == 13);
    if (_14596 == 0)
    {
        DeRef(_14596);
        _14596 = NOVALUE;
        goto L6D; // [2451] 2463
    }
    else{
        DeRef(_14596);
        _14596 = NOVALUE;
    }
L6C: 

    /** 				CompileErr(67)*/
    RefDS(_21829);
    _43CompileErr(67, _21829, 0);
L6D: 

    /** 			return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_25265);
    _14597 = _52NewStringSym(_yytext_25265);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14597;
    _14598 = MAKE_SEQ(_1);
    _14597 = NOVALUE;
    DeRefDS(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14598;
    goto L1; // [2481] 10
L62: 

    /** 		elsif class = PLUS then*/
    if (_class_25271 != 11)
    goto L6E; // [2488] 2540

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25259 != 61)
    goto L6F; // [2501] 2520

    /** 				return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 515;
    ((int *)_2)[2] = 0;
    _14602 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14602;
    goto L1; // [2517] 10
L6F: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 11;
    ((int *)_2)[2] = 0;
    _14603 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14603;
    goto L1; // [2537] 10
L6E: 

    /** 		elsif class = res:CONCAT then*/
    if (_class_25271 != 15)
    goto L70; // [2542] 2592

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25259 != 61)
    goto L71; // [2555] 2574

    /** 				return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 0;
    _14607 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14607;
    goto L1; // [2571] 10
L71: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 15;
    ((int *)_2)[2] = 0;
    _14608 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14608;
    goto L1; // [2589] 10
L70: 

    /** 		elsif class = NUMBER_SIGN then*/
    if (_class_25271 != -11)
    goto L72; // [2596] 3114

    /** 			i = 0*/
    _i_25260 = 0;

    /** 			is_int = -1*/
    _is_int_25270 = -1;

    /** 			while i < MAXINT/32 do*/
L73: 
    _14610 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(GREATEREQ, _i_25260, _14610)){
        DeRef(_14610);
        _14610 = NOVALUE;
        goto L74; // [2621] 2791
    }
    DeRef(_14610);
    _14610 = NOVALUE;

    /** 				ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14613 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14613 != -7)
    goto L75; // [2642] 2681

    /** 					if ch != '_' then*/
    if (_ch_25259 == 95)
    goto L73; // [2648] 2615

    /** 						i = i * 16 + ch - '0'*/
    if (_i_25260 == (short)_i_25260)
    _14616 = _i_25260 * 16;
    else
    _14616 = NewDouble(_i_25260 * (double)16);
    if (IS_ATOM_INT(_14616)) {
        _14617 = _14616 + _ch_25259;
        if ((long)((unsigned long)_14617 + (unsigned long)HIGH_BITS) >= 0) 
        _14617 = NewDouble((double)_14617);
    }
    else {
        _14617 = NewDouble(DBL_PTR(_14616)->dbl + (double)_ch_25259);
    }
    DeRef(_14616);
    _14616 = NOVALUE;
    if (IS_ATOM_INT(_14617)) {
        _i_25260 = _14617 - 48;
    }
    else {
        _i_25260 = NewDouble(DBL_PTR(_14617)->dbl - (double)48);
    }
    DeRef(_14617);
    _14617 = NOVALUE;
    if (!IS_ATOM_INT(_i_25260)) {
        _1 = (long)(DBL_PTR(_i_25260)->dbl);
        DeRefDS(_i_25260);
        _i_25260 = _1;
    }

    /** 						is_int = TRUE*/
    _is_int_25270 = _9TRUE_431;
    goto L73; // [2678] 2615
L75: 

    /** 				elsif ch >= 'A' and ch <= 'F' then*/
    _14619 = (_ch_25259 >= 65);
    if (_14619 == 0) {
        goto L76; // [2687] 2731
    }
    _14621 = (_ch_25259 <= 70);
    if (_14621 == 0)
    {
        DeRef(_14621);
        _14621 = NOVALUE;
        goto L76; // [2696] 2731
    }
    else{
        DeRef(_14621);
        _14621 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('A'-10)*/
    if (_i_25260 == (short)_i_25260)
    _14622 = _i_25260 * 16;
    else
    _14622 = NewDouble(_i_25260 * (double)16);
    if (IS_ATOM_INT(_14622)) {
        _14623 = _14622 + _ch_25259;
        if ((long)((unsigned long)_14623 + (unsigned long)HIGH_BITS) >= 0) 
        _14623 = NewDouble((double)_14623);
    }
    else {
        _14623 = NewDouble(DBL_PTR(_14622)->dbl + (double)_ch_25259);
    }
    DeRef(_14622);
    _14622 = NOVALUE;
    _14624 = 55;
    if (IS_ATOM_INT(_14623)) {
        _i_25260 = _14623 - 55;
    }
    else {
        _i_25260 = NewDouble(DBL_PTR(_14623)->dbl - (double)55);
    }
    DeRef(_14623);
    _14623 = NOVALUE;
    _14624 = NOVALUE;
    if (!IS_ATOM_INT(_i_25260)) {
        _1 = (long)(DBL_PTR(_i_25260)->dbl);
        DeRefDS(_i_25260);
        _i_25260 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25270 = _9TRUE_431;
    goto L73; // [2728] 2615
L76: 

    /** 				elsif ch >= 'a' and ch <= 'f' then*/
    _14626 = (_ch_25259 >= 97);
    if (_14626 == 0) {
        goto L74; // [2737] 2791
    }
    _14628 = (_ch_25259 <= 102);
    if (_14628 == 0)
    {
        DeRef(_14628);
        _14628 = NOVALUE;
        goto L74; // [2746] 2791
    }
    else{
        DeRef(_14628);
        _14628 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('a'-10)*/
    if (_i_25260 == (short)_i_25260)
    _14629 = _i_25260 * 16;
    else
    _14629 = NewDouble(_i_25260 * (double)16);
    if (IS_ATOM_INT(_14629)) {
        _14630 = _14629 + _ch_25259;
        if ((long)((unsigned long)_14630 + (unsigned long)HIGH_BITS) >= 0) 
        _14630 = NewDouble((double)_14630);
    }
    else {
        _14630 = NewDouble(DBL_PTR(_14629)->dbl + (double)_ch_25259);
    }
    DeRef(_14629);
    _14629 = NOVALUE;
    _14631 = 87;
    if (IS_ATOM_INT(_14630)) {
        _i_25260 = _14630 - 87;
    }
    else {
        _i_25260 = NewDouble(DBL_PTR(_14630)->dbl - (double)87);
    }
    DeRef(_14630);
    _14630 = NOVALUE;
    _14631 = NOVALUE;
    if (!IS_ATOM_INT(_i_25260)) {
        _1 = (long)(DBL_PTR(_i_25260)->dbl);
        DeRefDS(_i_25260);
        _i_25260 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25270 = _9TRUE_431;
    goto L73; // [2778] 2615

    /** 					exit*/
    goto L74; // [2783] 2791

    /** 			end while*/
    goto L73; // [2788] 2615
L74: 

    /** 			if is_int = -1 then*/
    if (_is_int_25270 != -1)
    goto L77; // [2793] 2856

    /** 				if ch = '!' then*/
    if (_ch_25259 != 33)
    goto L78; // [2799] 2845

    /** 					if line_number > 1 then*/
    if (_12line_number_11683 <= 1)
    goto L79; // [2807] 2819

    /** 						CompileErr(161)*/
    RefDS(_21829);
    _43CompileErr(161, _21829, 0);
L79: 

    /** 					shebang = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_60shebang_23569);
    _60shebang_23569 = _43ThisLine_48158;

    /** 					if start_include then*/
    if (_60start_include_23564 == 0)
    {
        goto L7A; // [2830] 2838
    }
    else{
    }

    /** 						IncludePush()*/
    _60IncludePush();
L7A: 

    /** 					read_line()*/
    _60read_line();
    goto L1; // [2842] 10
L78: 

    /** 					CompileErr(97)*/
    RefDS(_21829);
    _43CompileErr(97, _21829, 0);
    goto L1; // [2853] 10
L77: 

    /** 				if i >= MAXINT/32 then*/
    _14636 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(LESS, _i_25260, _14636)){
        DeRef(_14636);
        _14636 = NOVALUE;
        goto L7B; // [2864] 3035
    }
    DeRef(_14636);
    _14636 = NOVALUE;

    /** 					d = i*/
    DeRef(_d_25267);
    _d_25267 = _i_25260;

    /** 					is_int = FALSE*/
    _is_int_25270 = _9FALSE_429;

    /** 					while TRUE do*/
L7C: 
    if (_9TRUE_431 == 0)
    {
        goto L7D; // [2889] 3034
    }
    else{
    }

    /** 						ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 						if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14639 = (int)*(((s1_ptr)_2)->base + _ch_25259);
    if (_14639 != -7)
    goto L7E; // [2909] 2937

    /** 							if ch != '_' then*/
    if (_ch_25259 == 95)
    goto L7C; // [2915] 2887

    /** 								d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_25267)) {
        if (_d_25267 == (short)_d_25267)
        _14642 = _d_25267 * 16;
        else
        _14642 = NewDouble(_d_25267 * (double)16);
    }
    else {
        _14642 = binary_op(MULTIPLY, _d_25267, 16);
    }
    if (IS_ATOM_INT(_14642)) {
        _14643 = _14642 + _ch_25259;
        if ((long)((unsigned long)_14643 + (unsigned long)HIGH_BITS) >= 0) 
        _14643 = NewDouble((double)_14643);
    }
    else {
        _14643 = binary_op(PLUS, _14642, _ch_25259);
    }
    DeRef(_14642);
    _14642 = NOVALUE;
    DeRef(_d_25267);
    if (IS_ATOM_INT(_14643)) {
        _d_25267 = _14643 - 48;
        if ((long)((unsigned long)_d_25267 +(unsigned long) HIGH_BITS) >= 0){
            _d_25267 = NewDouble((double)_d_25267);
        }
    }
    else {
        _d_25267 = binary_op(MINUS, _14643, 48);
    }
    DeRef(_14643);
    _14643 = NOVALUE;
    goto L7C; // [2934] 2887
L7E: 

    /** 						elsif ch >= 'A' and ch <= 'F' then*/
    _14645 = (_ch_25259 >= 65);
    if (_14645 == 0) {
        goto L7F; // [2943] 2976
    }
    _14647 = (_ch_25259 <= 70);
    if (_14647 == 0)
    {
        DeRef(_14647);
        _14647 = NOVALUE;
        goto L7F; // [2952] 2976
    }
    else{
        DeRef(_14647);
        _14647 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_25267)) {
        if (_d_25267 == (short)_d_25267)
        _14648 = _d_25267 * 16;
        else
        _14648 = NewDouble(_d_25267 * (double)16);
    }
    else {
        _14648 = binary_op(MULTIPLY, _d_25267, 16);
    }
    if (IS_ATOM_INT(_14648)) {
        _14649 = _14648 + _ch_25259;
        if ((long)((unsigned long)_14649 + (unsigned long)HIGH_BITS) >= 0) 
        _14649 = NewDouble((double)_14649);
    }
    else {
        _14649 = binary_op(PLUS, _14648, _ch_25259);
    }
    DeRef(_14648);
    _14648 = NOVALUE;
    _14650 = 55;
    DeRef(_d_25267);
    if (IS_ATOM_INT(_14649)) {
        _d_25267 = _14649 - 55;
        if ((long)((unsigned long)_d_25267 +(unsigned long) HIGH_BITS) >= 0){
            _d_25267 = NewDouble((double)_d_25267);
        }
    }
    else {
        _d_25267 = binary_op(MINUS, _14649, 55);
    }
    DeRef(_14649);
    _14649 = NOVALUE;
    _14650 = NOVALUE;
    goto L7C; // [2973] 2887
L7F: 

    /** 						elsif ch >= 'a' and ch <= 'f' then*/
    _14652 = (_ch_25259 >= 97);
    if (_14652 == 0) {
        goto L80; // [2982] 3015
    }
    _14654 = (_ch_25259 <= 102);
    if (_14654 == 0)
    {
        DeRef(_14654);
        _14654 = NOVALUE;
        goto L80; // [2991] 3015
    }
    else{
        DeRef(_14654);
        _14654 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_25267)) {
        if (_d_25267 == (short)_d_25267)
        _14655 = _d_25267 * 16;
        else
        _14655 = NewDouble(_d_25267 * (double)16);
    }
    else {
        _14655 = binary_op(MULTIPLY, _d_25267, 16);
    }
    if (IS_ATOM_INT(_14655)) {
        _14656 = _14655 + _ch_25259;
        if ((long)((unsigned long)_14656 + (unsigned long)HIGH_BITS) >= 0) 
        _14656 = NewDouble((double)_14656);
    }
    else {
        _14656 = binary_op(PLUS, _14655, _ch_25259);
    }
    DeRef(_14655);
    _14655 = NOVALUE;
    _14657 = 87;
    DeRef(_d_25267);
    if (IS_ATOM_INT(_14656)) {
        _d_25267 = _14656 - 87;
        if ((long)((unsigned long)_d_25267 +(unsigned long) HIGH_BITS) >= 0){
            _d_25267 = NewDouble((double)_d_25267);
        }
    }
    else {
        _d_25267 = binary_op(MINUS, _14656, 87);
    }
    DeRef(_14656);
    _14656 = NOVALUE;
    _14657 = NOVALUE;
    goto L7C; // [3012] 2887
L80: 

    /** 						elsif ch = '_' then*/
    if (_ch_25259 != 95)
    goto L7D; // [3017] 3034
    goto L7C; // [3021] 2887

    /** 							exit*/
    goto L7D; // [3026] 3034

    /** 					end while*/
    goto L7C; // [3031] 2887
L7D: 
L7B: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				if is_int then*/
    if (_is_int_25270 == 0)
    {
        goto L81; // [3041] 3063
    }
    else{
    }

    /** 					return {ATOM, NewIntSym(i)}*/
    _14660 = _52NewIntSym(_i_25260);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14660;
    _14661 = MAKE_SEQ(_1);
    _14660 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14661;
    goto L1; // [3060] 10
L81: 

    /** 					if d <= MAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_25267, 1073741823)){
        goto L82; // [3069] 3092
    }

    /** 						return {ATOM, NewIntSym(d)}*/
    Ref(_d_25267);
    _14663 = _52NewIntSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14663;
    _14664 = MAKE_SEQ(_1);
    _14663 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14664;
    goto L1; // [3089] 10
L82: 

    /** 						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25267);
    _14665 = _52NewDoubleSym(_d_25267);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14665;
    _14666 = MAKE_SEQ(_1);
    _14665 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14666;
    goto L1; // [3111] 10
L72: 

    /** 		elsif class = res:MULTIPLY then*/
    if (_class_25271 != 13)
    goto L83; // [3116] 3166

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25259 != 61)
    goto L84; // [3129] 3148

    /** 				return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 517;
    ((int *)_2)[2] = 0;
    _14670 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14670;
    goto L1; // [3145] 10
L84: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 13;
    ((int *)_2)[2] = 0;
    _14671 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14671;
    goto L1; // [3163] 10
L83: 

    /** 		elsif class = res:DIVIDE then*/
    if (_class_25271 != 14)
    goto L85; // [3168] 3370

    /** 			ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25259 != 61)
    goto L86; // [3181] 3200

    /** 				return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 518;
    ((int *)_2)[2] = 0;
    _14675 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14675;
    goto L1; // [3197] 10
L86: 

    /** 			elsif ch = '*' then*/
    if (_ch_25259 != 42)
    goto L87; // [3202] 3352

    /** 				cline = line_number*/
    _cline_25264 = _12line_number_11683;

    /** 				integer cnest = 1*/
    _cnest_25920 = 1;

    /** 				while cnest > 0 do*/
L88: 
    if (_cnest_25920 <= 0)
    goto L89; // [3225] 3333

    /** 					ch = getch()*/
    _ch_25259 = _60getch();
    if (!IS_ATOM_INT(_ch_25259)) {
        _1 = (long)(DBL_PTR(_ch_25259)->dbl);
        DeRefDS(_ch_25259);
        _ch_25259 = _1;
    }

    /** 					switch ch do*/
    _0 = _ch_25259;
    switch ( _0 ){ 

        /** 						case  END_OF_FILE_CHAR then*/
        case 26:

        /** 							exit*/
        goto L89; // [3249] 3333
        goto L88; // [3251] 3225

        /** 						case '\n' then*/
        case 10:

        /** 							read_line()*/
        _60read_line();
        goto L88; // [3261] 3225

        /** 						case '*' then*/
        case 42:

        /** 							ch = getch()*/
        _ch_25259 = _60getch();
        if (!IS_ATOM_INT(_ch_25259)) {
            _1 = (long)(DBL_PTR(_ch_25259)->dbl);
            DeRefDS(_ch_25259);
            _ch_25259 = _1;
        }

        /** 							if ch = '/' then*/
        if (_ch_25259 != 47)
        goto L8A; // [3276] 3289

        /** 								cnest -= 1*/
        _cnest_25920 = _cnest_25920 - 1;
        goto L88; // [3286] 3225
L8A: 

        /** 								ungetch()*/
        _60ungetch();
        goto L88; // [3294] 3225

        /** 						case '/' then*/
        case 47:

        /** 							ch = getch()*/
        _ch_25259 = _60getch();
        if (!IS_ATOM_INT(_ch_25259)) {
            _1 = (long)(DBL_PTR(_ch_25259)->dbl);
            DeRefDS(_ch_25259);
            _ch_25259 = _1;
        }

        /** 							if ch = '*' then*/
        if (_ch_25259 != 42)
        goto L8B; // [3309] 3322

        /** 								cnest += 1*/
        _cnest_25920 = _cnest_25920 + 1;
        goto L8C; // [3319] 3327
L8B: 

        /** 								ungetch()*/
        _60ungetch();
L8C: 
    ;}
    /** 				end while*/
    goto L88; // [3330] 3225
L89: 

    /** 				if cnest > 0 then*/
    if (_cnest_25920 <= 0)
    goto L8D; // [3335] 3347

    /** 					CompileErr(42, cline)*/
    _43CompileErr(42, _cline_25264, 0);
L8D: 
    goto L1; // [3349] 10
L87: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 14;
    ((int *)_2)[2] = 0;
    _14688 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14688;
    goto L1; // [3367] 10
L85: 

    /** 		elsif class = SINGLE_QUOTE then*/
    if (_class_25271 != -5)
    goto L8E; // [3374] 3515

    /** 			atom ach = getch()*/
    _0 = _ach_25949;
    _ach_25949 = _60getch();
    DeRef(_0);

    /** 			if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_25949, 92)){
        goto L8F; // [3385] 3398
    }

    /** 				ach = EscapeChar('\'')*/
    _0 = _ach_25949;
    _ach_25949 = _60EscapeChar(39);
    DeRef(_0);
    goto L90; // [3395] 3449
L8F: 

    /** 			elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_25949, 9)){
        goto L91; // [3400] 3414
    }

    /** 				CompileErr(145)*/
    RefDS(_21829);
    _43CompileErr(145, _21829, 0);
    goto L90; // [3411] 3449
L91: 

    /** 			elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_25949, 39)){
        goto L92; // [3416] 3430
    }

    /** 				CompileErr(137)*/
    RefDS(_21829);
    _43CompileErr(137, _21829, 0);
    goto L90; // [3427] 3449
L92: 

    /** 			elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_25949, 10)){
        goto L93; // [3432] 3448
    }

    /** 				CompileErr(68, {"character", "end of line"})*/
    RefDS(_14697);
    RefDS(_14696);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14696;
    ((int *)_2)[2] = _14697;
    _14698 = MAKE_SEQ(_1);
    _43CompileErr(68, _14698, 0);
    _14698 = NOVALUE;
L93: 
L90: 

    /** 			if getch() != '\'' then*/
    _14699 = _60getch();
    if (binary_op_a(EQUALS, _14699, 39)){
        DeRef(_14699);
        _14699 = NOVALUE;
        goto L94; // [3454] 3466
    }
    DeRef(_14699);
    _14699 = NOVALUE;

    /** 				CompileErr(56)*/
    RefDS(_21829);
    _43CompileErr(56, _21829, 0);
L94: 

    /** 			if integer(ach) then*/
    if (IS_ATOM_INT(_ach_25949))
    _14701 = 1;
    else if (IS_ATOM_DBL(_ach_25949))
    _14701 = IS_ATOM_INT(DoubleToInt(_ach_25949));
    else
    _14701 = 0;
    if (_14701 == 0)
    {
        _14701 = NOVALUE;
        goto L95; // [3471] 3493
    }
    else{
        _14701 = NOVALUE;
    }

    /** 				return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_25949);
    _14702 = _52NewIntSym(_ach_25949);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14702;
    _14703 = MAKE_SEQ(_1);
    _14702 = NOVALUE;
    DeRef(_ach_25949);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14703;
    goto L96; // [3490] 3510
L95: 

    /** 				return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_25949);
    _14704 = _52NewDoubleSym(_ach_25949);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14704;
    _14705 = MAKE_SEQ(_1);
    _14704 = NOVALUE;
    DeRef(_ach_25949);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14705;
L96: 
    DeRef(_ach_25949);
    _ach_25949 = NOVALUE;
    goto L1; // [3512] 10
L8E: 

    /** 		elsif class = LESS then*/
    if (_class_25271 != 1)
    goto L97; // [3519] 3567

    /** 			if getch() = '=' then*/
    _14707 = _60getch();
    if (binary_op_a(NOTEQ, _14707, 61)){
        DeRef(_14707);
        _14707 = NOVALUE;
        goto L98; // [3528] 3547
    }
    DeRef(_14707);
    _14707 = NOVALUE;

    /** 				return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5;
    ((int *)_2)[2] = 0;
    _14709 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14709;
    goto L1; // [3544] 10
L98: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _14710 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14710;
    goto L1; // [3564] 10
L97: 

    /** 		elsif class = GREATER then*/
    if (_class_25271 != 6)
    goto L99; // [3571] 3619

    /** 			if getch() = '=' then*/
    _14712 = _60getch();
    if (binary_op_a(NOTEQ, _14712, 61)){
        DeRef(_14712);
        _14712 = NOVALUE;
        goto L9A; // [3580] 3599
    }
    DeRef(_14712);
    _14712 = NOVALUE;

    /** 				return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = 0;
    _14714 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14714;
    goto L1; // [3596] 10
L9A: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = 0;
    _14715 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14715;
    goto L1; // [3616] 10
L99: 

    /** 		elsif class = BANG then*/
    if (_class_25271 != -1)
    goto L9B; // [3623] 3671

    /** 			if getch() = '=' then*/
    _14717 = _60getch();
    if (binary_op_a(NOTEQ, _14717, 61)){
        DeRef(_14717);
        _14717 = NOVALUE;
        goto L9C; // [3632] 3651
    }
    DeRef(_14717);
    _14717 = NOVALUE;

    /** 				return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = 0;
    _14719 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14715);
    _14715 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14719;
    goto L1; // [3648] 10
L9C: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _14720 = MAKE_SEQ(_1);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14719);
    _14719 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14715);
    _14715 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14720;
    goto L1; // [3668] 10
L9B: 

    /** 		elsif class = KEYWORD then*/
    if (_class_25271 != -10)
    goto L9D; // [3675] 3708

    /** 			return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _14722 = _ch_25259 - 128;
    _2 = (int)SEQ_PTR(_62keylist_22497);
    _14723 = (int)*(((s1_ptr)_2)->base + _14722);
    _2 = (int)SEQ_PTR(_14723);
    _14724 = (int)*(((s1_ptr)_2)->base + 3);
    _14723 = NOVALUE;
    Ref(_14724);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14724;
    ((int *)_2)[2] = 0;
    _14725 = MAKE_SEQ(_1);
    _14724 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    _14722 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14719);
    _14719 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14715);
    _14715 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14725;
    goto L1; // [3705] 10
L9D: 

    /** 		elsif class = BUILTIN then*/
    if (_class_25271 != -9)
    goto L9E; // [3712] 3765

    /** 			name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _14727 = _ch_25259 - 170;
    if ((long)((unsigned long)_14727 +(unsigned long) HIGH_BITS) >= 0){
        _14727 = NewDouble((double)_14727);
    }
    if (IS_ATOM_INT(_14727)) {
        _14728 = _14727 + 24;
    }
    else {
        _14728 = NewDouble(DBL_PTR(_14727)->dbl + (double)24);
    }
    DeRef(_14727);
    _14727 = NOVALUE;
    _2 = (int)SEQ_PTR(_62keylist_22497);
    if (!IS_ATOM_INT(_14728)){
        _14729 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14728)->dbl));
    }
    else{
        _14729 = (int)*(((s1_ptr)_2)->base + _14728);
    }
    DeRef(_name_25272);
    _2 = (int)SEQ_PTR(_14729);
    _name_25272 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_name_25272);
    _14729 = NOVALUE;

    /** 			return keyfind(name, -1)*/
    RefDS(_name_25272);
    _31393 = _52hashfn(_name_25272);
    RefDS(_name_25272);
    _14731 = _52keyfind(_name_25272, -1, _12current_file_no_11682, 0, _31393);
    _31393 = NOVALUE;
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRefDS(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14722);
    _14722 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14719);
    _14719 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14715);
    _14715 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    DeRef(_14725);
    _14725 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14731;
    goto L1; // [3762] 10
L9E: 

    /** 		elsif class = BACK_QUOTE then*/
    if (_class_25271 != -12)
    goto L9F; // [3769] 3786

    /** 			return ExtendedString( '`' )*/
    _14733 = _60ExtendedString(96);
    DeRef(_yytext_25265);
    DeRef(_namespaces_25266);
    DeRef(_d_25267);
    DeRef(_tok_25269);
    DeRef(_name_25272);
    DeRef(_14371);
    _14371 = NOVALUE;
    DeRef(_14626);
    _14626 = NOVALUE;
    DeRef(_14575);
    _14575 = NOVALUE;
    _14639 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14470);
    _14470 = NOVALUE;
    DeRef(_14670);
    _14670 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14481);
    _14481 = NOVALUE;
    DeRef(_14496);
    _14496 = NOVALUE;
    DeRef(_14531);
    _14531 = NOVALUE;
    _14537 = NOVALUE;
    DeRef(_14558);
    _14558 = NOVALUE;
    DeRef(_14394);
    _14394 = NOVALUE;
    _14415 = NOVALUE;
    _14494 = NOVALUE;
    DeRef(_14671);
    _14671 = NOVALUE;
    _14404 = NOVALUE;
    DeRef(_14560);
    _14560 = NOVALUE;
    DeRef(_14710);
    _14710 = NOVALUE;
    DeRef(_14722);
    _14722 = NOVALUE;
    DeRef(_14731);
    _14731 = NOVALUE;
    DeRef(_14365);
    _14365 = NOVALUE;
    _14441 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    DeRef(_14666);
    _14666 = NOVALUE;
    DeRef(_14375);
    _14375 = NOVALUE;
    DeRef(_14399);
    _14399 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14603);
    _14603 = NOVALUE;
    DeRef(_14619);
    _14619 = NOVALUE;
    DeRef(_14688);
    _14688 = NOVALUE;
    DeRef(_14475);
    _14475 = NOVALUE;
    _14613 = NOVALUE;
    DeRef(_14608);
    _14608 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14719);
    _14719 = NOVALUE;
    DeRef(_14425);
    _14425 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    DeRef(_14703);
    _14703 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14728);
    _14728 = NOVALUE;
    _14519 = NOVALUE;
    DeRef(_14568);
    _14568 = NOVALUE;
    DeRef(_14675);
    _14675 = NOVALUE;
    DeRef(_14378);
    _14378 = NOVALUE;
    DeRef(_14474);
    _14474 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    DeRef(_14529);
    _14529 = NOVALUE;
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14577);
    _14577 = NOVALUE;
    DeRef(_14715);
    _14715 = NOVALUE;
    DeRef(_14523);
    _14523 = NOVALUE;
    DeRef(_14709);
    _14709 = NOVALUE;
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14368);
    _14368 = NOVALUE;
    _14484 = NOVALUE;
    DeRef(_14583);
    _14583 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14664);
    _14664 = NOVALUE;
    DeRef(_14720);
    _14720 = NOVALUE;
    DeRef(_14362);
    _14362 = NOVALUE;
    DeRef(_14607);
    _14607 = NOVALUE;
    DeRef(_14725);
    _14725 = NOVALUE;
    _14426 = NOVALUE;
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_14645);
    _14645 = NOVALUE;
    _14515 = NOVALUE;
    _14541 = NOVALUE;
    return _14733;
    goto L1; // [3783] 10
L9F: 

    /** 			InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _class_25271;
    _14734 = MAKE_SEQ(_1);
    _43InternalErr(268, _14734);
    _14734 = NOVALUE;

    /**    end while*/
    goto L1; // [3799] 10
L2: 
    ;
}


void _60eu_namespace()
{
    int _eu_tok_26046 = NOVALUE;
    int _eu_ns_26048 = NOVALUE;
    int _31392 = NOVALUE;
    int _31391 = NOVALUE;
    int _14743 = NOVALUE;
    int _14741 = NOVALUE;
    int _14739 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_14737);
    _31391 = _14737;
    _31392 = _52hashfn(_31391);
    _31391 = NOVALUE;
    RefDS(_14737);
    _0 = _eu_tok_26046;
    _eu_tok_26046 = _52keyfind(_14737, -1, _12current_file_no_11682, 1, _31392);
    DeRef(_0);
    _31392 = NOVALUE;

    /** 	eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_eu_tok_26046);
    _14739 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14739);
    _eu_ns_26048 = _60NameSpace_declaration(_14739);
    _14739 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_26048)) {
        _1 = (long)(DBL_PTR(_eu_ns_26048)->dbl);
        DeRefDS(_eu_ns_26048);
        _eu_ns_26048 = _1;
    }

    /** 	SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26048 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _14741 = NOVALUE;

    /** 	SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26048 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);
    _14743 = NOVALUE;

    /** end procedure*/
    DeRef(_eu_tok_26046);
    return;
    ;
}


int _60StringToken(int _pDelims_26066)
{
    int _ch_26067 = NOVALUE;
    int _m_26068 = NOVALUE;
    int _gtext_26069 = NOVALUE;
    int _level_26100 = NOVALUE;
    int _14782 = NOVALUE;
    int _14780 = NOVALUE;
    int _14778 = NOVALUE;
    int _14759 = NOVALUE;
    int _14758 = NOVALUE;
    int _14752 = NOVALUE;
    int _14750 = NOVALUE;
    int _14748 = NOVALUE;
    int _14746 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14746 = (_ch_26067 == 32);
    if (_14746 != 0) {
        goto L2; // [19] 32
    }
    _14748 = (_ch_26067 == 9);
    if (_14748 == 0)
    {
        DeRef(_14748);
        _14748 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14748);
        _14748 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14750 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_26066, _pDelims_26066, _14750);
    DeRefDS(_14750);
    _14750 = NOVALUE;

    /** 	gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_26069);
    _gtext_26069 = _5;

    /** 	while not find(ch,  pDelims) label "top" do*/
L4: 
    _14752 = find_from(_ch_26067, _pDelims_26066, 1);
    if (_14752 != 0)
    goto L5; // [77] 391
    _14752 = NOVALUE;

    /** 		if ch = '-' then*/
    if (_ch_26067 != 45)
    goto L6; // [82] 145

    /** 			ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_26067 != 45)
    goto L7; // [95] 137

    /** 				while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 26;
    _14758 = MAKE_SEQ(_1);
    _14759 = find_from(_ch_26067, _14758, 1);
    DeRefDS(_14758);
    _14758 = NOVALUE;
    if (_14759 != 0)
    goto L5; // [115] 391
    _14759 = NOVALUE;

    /** 					ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 				end while*/
    goto L8; // [127] 104

    /** 				exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** 				ungetch()*/
    _60ungetch();
    goto L9; // [142] 373
L6: 

    /** 		elsif ch = '/' then*/
    if (_ch_26067 != 47)
    goto LA; // [147] 372

    /** 			ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 			if ch = '*' then*/
    if (_ch_26067 != 42)
    goto LB; // [160] 361

    /** 				integer level = 1*/
    _level_26100 = 1;

    /** 				while level > 0 do*/
LC: 
    if (_level_26100 <= 0)
    goto LD; // [174] 293

    /** 					ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 					if ch = '/' then*/
    if (_ch_26067 != 47)
    goto LE; // [187] 221

    /** 						ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 						if ch = '*' then*/
    if (_ch_26067 != 42)
    goto LF; // [200] 213

    /** 							level += 1*/
    _level_26100 = _level_26100 + 1;
    goto LC; // [210] 174
LF: 

    /** 							ungetch()*/
    _60ungetch();
    goto LC; // [218] 174
LE: 

    /** 					elsif ch = '*' then*/
    if (_ch_26067 != 42)
    goto L10; // [223] 257

    /** 						ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 						if ch = '/' then*/
    if (_ch_26067 != 47)
    goto L11; // [236] 249

    /** 							level -= 1*/
    _level_26100 = _level_26100 - 1;
    goto LC; // [246] 174
L11: 

    /** 							ungetch()*/
    _60ungetch();
    goto LC; // [254] 174
L10: 

    /** 					elsif ch = '\n' then*/
    if (_ch_26067 != 10)
    goto L12; // [259] 270

    /** 						read_line()*/
    _60read_line();
    goto LC; // [267] 174
L12: 

    /** 					elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_26067 != 26)
    goto LC; // [274] 174

    /** 						ungetch()*/
    _60ungetch();

    /** 						exit*/
    goto LD; // [284] 293

    /** 				end while*/
    goto LC; // [290] 174
LD: 

    /** 				ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 				if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26069)){
            _14778 = SEQ_PTR(_gtext_26069)->length;
    }
    else {
        _14778 = 1;
    }
    if (_14778 != 0)
    goto L13; // [305] 350

    /** 					while ch = ' ' or ch = '\t' do*/
L14: 
    _14780 = (_ch_26067 == 32);
    if (_14780 != 0) {
        goto L15; // [318] 331
    }
    _14782 = (_ch_26067 == 9);
    if (_14782 == 0)
    {
        DeRef(_14782);
        _14782 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_14782);
        _14782 = NOVALUE;
    }
L15: 

    /** 						ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 					end while*/
    goto L14; // [340] 314
L16: 

    /** 					continue "top"*/
    goto L4; // [347] 72
L13: 

    /** 				exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				ch = '/'*/
    _ch_26067 = 47;
L17: 
LA: 
L9: 

    /** 		gtext &= ch*/
    Append(&_gtext_26069, _gtext_26069, _ch_26067);

    /** 		ch = getch()*/
    _ch_26067 = _60getch();
    if (!IS_ATOM_INT(_ch_26067)) {
        _1 = (long)(DBL_PTR(_ch_26067)->dbl);
        DeRefDS(_ch_26067);
        _ch_26067 = _1;
    }

    /** 	end while*/
    goto L4; // [388] 72
L5: 

    /** 	ungetch() -- put back end-word token.*/
    _60ungetch();

    /** 	return gtext*/
    DeRefDS(_pDelims_26066);
    DeRef(_14746);
    _14746 = NOVALUE;
    DeRef(_14780);
    _14780 = NOVALUE;
    return _gtext_26069;
    ;
}


void _60IncludeScan(int _is_public_26137)
{
    int _ch_26138 = NOVALUE;
    int _gtext_26139 = NOVALUE;
    int _s_26141 = NOVALUE;
    int _31390 = NOVALUE;
    int _14845 = NOVALUE;
    int _14844 = NOVALUE;
    int _14842 = NOVALUE;
    int _14840 = NOVALUE;
    int _14839 = NOVALUE;
    int _14834 = NOVALUE;
    int _14831 = NOVALUE;
    int _14829 = NOVALUE;
    int _14828 = NOVALUE;
    int _14826 = NOVALUE;
    int _14824 = NOVALUE;
    int _14822 = NOVALUE;
    int _14820 = NOVALUE;
    int _14814 = NOVALUE;
    int _14812 = NOVALUE;
    int _14807 = NOVALUE;
    int _14803 = NOVALUE;
    int _14802 = NOVALUE;
    int _14797 = NOVALUE;
    int _14794 = NOVALUE;
    int _14793 = NOVALUE;
    int _14789 = NOVALUE;
    int _14787 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_is_public_26137)) {
        _1 = (long)(DBL_PTR(_is_public_26137)->dbl);
        DeRefDS(_is_public_26137);
        _is_public_26137 = _1;
    }

    /** 	ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14787 = (_ch_26138 == 32);
    if (_14787 != 0) {
        goto L2; // [19] 32
    }
    _14789 = (_ch_26138 == 9);
    if (_14789 == 0)
    {
        DeRef(_14789);
        _14789 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14789);
        _14789 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_26139);
    _gtext_26139 = _5;

    /** 	if ch = '"' then*/
    if (_ch_26138 != 34)
    goto L4; // [53] 141

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 34;
    *((int *)(_2+16)) = 26;
    _14793 = MAKE_SEQ(_1);
    _14794 = find_from(_ch_26138, _14793, 1);
    DeRefDS(_14793);
    _14793 = NOVALUE;
    if (_14794 != 0)
    goto L6; // [83] 124
    _14794 = NOVALUE;

    /** 			if ch = '\\' then*/
    if (_ch_26138 != 92)
    goto L7; // [88] 105

    /** 				gtext &= EscapeChar('"')*/
    _14797 = _60EscapeChar(34);
    if (IS_SEQUENCE(_gtext_26139) && IS_ATOM(_14797)) {
        Ref(_14797);
        Append(&_gtext_26139, _gtext_26139, _14797);
    }
    else if (IS_ATOM(_gtext_26139) && IS_SEQUENCE(_14797)) {
    }
    else {
        Concat((object_ptr)&_gtext_26139, _gtext_26139, _14797);
    }
    DeRef(_14797);
    _14797 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** 				gtext &= ch*/
    Append(&_gtext_26139, _gtext_26139, _ch_26138);
L8: 

    /** 			ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		end while*/
    goto L5; // [121] 69
L6: 

    /** 		if ch != '"' then*/
    if (_ch_26138 == 34)
    goto L9; // [126] 187

    /** 			CompileErr(115)*/
    RefDS(_21829);
    _43CompileErr(115, _21829, 0);
    goto L9; // [138] 187
L4: 

    /** 		while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14802 = MAKE_SEQ(_1);
    _14803 = find_from(_ch_26138, _14802, 1);
    DeRefDS(_14802);
    _14802 = NOVALUE;
    if (_14803 != 0)
    goto LB; // [161] 182
    _14803 = NOVALUE;

    /** 			gtext &= ch*/
    Append(&_gtext_26139, _gtext_26139, _ch_26138);

    /** 			ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		end while*/
    goto LA; // [179] 146
LB: 

    /** 		ungetch()*/
    _60ungetch();
L9: 

    /** 	if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26139)){
            _14807 = SEQ_PTR(_gtext_26139)->length;
    }
    else {
        _14807 = 1;
    }
    if (_14807 != 0)
    goto LC; // [192] 204

    /** 		CompileErr(95)*/
    RefDS(_21829);
    _43CompileErr(95, _21829, 0);
LC: 

    /** 	ifdef WINDOWS then*/

    /** 		new_include_name = gtext*/
    RefDS(_gtext_26139);
    DeRef(_12new_include_name_11805);
    _12new_include_name_11805 = _gtext_26139;

    /** 	ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
LD: 
    _14812 = (_ch_26138 == 32);
    if (_14812 != 0) {
        goto LE; // [229] 242
    }
    _14814 = (_ch_26138 == 9);
    if (_14814 == 0)
    {
        DeRef(_14814);
        _14814 = NOVALUE;
        goto LF; // [238] 254
    }
    else{
        DeRef(_14814);
        _14814 = NOVALUE;
    }
LE: 

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 	end while*/
    goto LD; // [251] 225
LF: 

    /** 	new_include_space = 0*/
    _60new_include_space_23562 = 0;

    /** 	if ch = 'a' then*/
    if (_ch_26138 != 97)
    goto L10; // [263] 520

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		if ch = 's' then*/
    if (_ch_26138 != 115)
    goto L11; // [276] 509

    /** 			ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 			if ch = ' ' or ch = '\t' then*/
    _14820 = (_ch_26138 == 32);
    if (_14820 != 0) {
        goto L12; // [293] 306
    }
    _14822 = (_ch_26138 == 9);
    if (_14822 == 0)
    {
        DeRef(_14822);
        _14822 = NOVALUE;
        goto L13; // [302] 498
    }
    else{
        DeRef(_14822);
        _14822 = NOVALUE;
    }
L12: 

    /** 				ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 				while ch = ' ' or ch = '\t' do*/
L14: 
    _14824 = (_ch_26138 == 32);
    if (_14824 != 0) {
        goto L15; // [322] 335
    }
    _14826 = (_ch_26138 == 9);
    if (_14826 == 0)
    {
        DeRef(_14826);
        _14826 = NOVALUE;
        goto L16; // [331] 347
    }
    else{
        DeRef(_14826);
        _14826 = NOVALUE;
    }
L15: 

    /** 					ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 				end while*/
    goto L14; // [344] 318
L16: 

    /** 				if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_60char_class_23571);
    _14828 = (int)*(((s1_ptr)_2)->base + _ch_26138);
    _14829 = (_14828 == -2);
    _14828 = NOVALUE;
    if (_14829 != 0) {
        goto L17; // [361] 374
    }
    _14831 = (_ch_26138 == 95);
    if (_14831 == 0)
    {
        DeRef(_14831);
        _14831 = NOVALUE;
        goto L18; // [370] 487
    }
    else{
        DeRef(_14831);
        _14831 = NOVALUE;
    }
L17: 

    /** 					gtext = {ch}*/
    _0 = _gtext_26139;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_26138;
    _gtext_26139 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 					ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 					while id_char[ch] = TRUE do*/
L19: 
    _2 = (int)SEQ_PTR(_60id_char_23572);
    _14834 = (int)*(((s1_ptr)_2)->base + _ch_26138);
    if (_14834 != _9TRUE_431)
    goto L1A; // [400] 422

    /** 						gtext &= ch*/
    Append(&_gtext_26139, _gtext_26139, _ch_26138);

    /** 						ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 					end while*/
    goto L19; // [419] 392
L1A: 

    /** 					ungetch()*/
    _60ungetch();

    /** 					s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_26139);
    _31390 = _52hashfn(_gtext_26139);
    RefDS(_gtext_26139);
    _0 = _s_26141;
    _s_26141 = _52keyfind(_gtext_26139, -1, _12current_file_no_11682, 1, _31390);
    DeRef(_0);
    _31390 = NOVALUE;

    /** 					if not find(s[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_s_26141);
    _14839 = (int)*(((s1_ptr)_2)->base + 1);
    _14840 = find_from(_14839, _28ID_TOKS_11308, 1);
    _14839 = NOVALUE;
    if (_14840 != 0)
    goto L1B; // [459] 470
    _14840 = NOVALUE;

    /** 						CompileErr(36)*/
    RefDS(_21829);
    _43CompileErr(36, _21829, 0);
L1B: 

    /** 					new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (int)SEQ_PTR(_s_26141);
    _14842 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14842);
    _0 = _60NameSpace_declaration(_14842);
    _60new_include_space_23562 = _0;
    _14842 = NOVALUE;
    if (!IS_ATOM_INT(_60new_include_space_23562)) {
        _1 = (long)(DBL_PTR(_60new_include_space_23562)->dbl);
        DeRefDS(_60new_include_space_23562);
        _60new_include_space_23562 = _1;
    }
    goto L1C; // [484] 629
L18: 

    /** 					CompileErr(113)*/
    RefDS(_21829);
    _43CompileErr(113, _21829, 0);
    goto L1C; // [495] 629
L13: 

    /** 				CompileErr(100)*/
    RefDS(_21829);
    _43CompileErr(100, _21829, 0);
    goto L1C; // [506] 629
L11: 

    /** 			CompileErr(100)*/
    RefDS(_21829);
    _43CompileErr(100, _21829, 0);
    goto L1C; // [517] 629
L10: 

    /** 	elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 26;
    _14844 = MAKE_SEQ(_1);
    _14845 = find_from(_ch_26138, _14844, 1);
    DeRefDS(_14844);
    _14844 = NOVALUE;
    if (_14845 == 0)
    {
        _14845 = NOVALUE;
        goto L1D; // [535] 545
    }
    else{
        _14845 = NOVALUE;
    }

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [542] 629
L1D: 

    /** 	elsif ch = '-' then*/
    if (_ch_26138 != 45)
    goto L1E; // [547] 583

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		if ch != '-' then*/
    if (_ch_26138 == 45)
    goto L1F; // [560] 572

    /** 			CompileErr(100)*/
    RefDS(_21829);
    _43CompileErr(100, _21829, 0);
L1F: 

    /** 		ungetch()*/
    _60ungetch();

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [580] 629
L1E: 

    /** 	elsif ch = '/' then*/
    if (_ch_26138 != 47)
    goto L20; // [585] 621

    /** 		ch = getch()*/
    _ch_26138 = _60getch();
    if (!IS_ATOM_INT(_ch_26138)) {
        _1 = (long)(DBL_PTR(_ch_26138)->dbl);
        DeRefDS(_ch_26138);
        _ch_26138 = _1;
    }

    /** 		if ch != '*' then*/
    if (_ch_26138 == 42)
    goto L21; // [598] 610

    /** 			CompileErr(100)*/
    RefDS(_21829);
    _43CompileErr(100, _21829, 0);
L21: 

    /** 		ungetch()*/
    _60ungetch();

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [618] 629
L20: 

    /** 		CompileErr(100)*/
    RefDS(_21829);
    _43CompileErr(100, _21829, 0);
L1C: 

    /** 	start_include = TRUE -- let scanner know*/
    _60start_include_23564 = _9TRUE_431;

    /** 	public_include = is_public*/
    _60public_include_23567 = _is_public_26137;

    /** end procedure*/
    DeRef(_gtext_26139);
    DeRef(_s_26141);
    DeRef(_14787);
    _14787 = NOVALUE;
    DeRef(_14812);
    _14812 = NOVALUE;
    DeRef(_14820);
    _14820 = NOVALUE;
    DeRef(_14824);
    _14824 = NOVALUE;
    _14834 = NOVALUE;
    DeRef(_14829);
    _14829 = NOVALUE;
    return;
    ;
}


void _60main_file()
{
    int _0, _1, _2;
    

    /** 	ifdef STDDEBUG then*/

    /** 		read_line()*/
    _60read_line();

    /** 		default_namespace( )*/
    _60default_namespace();

    /** end procedure*/
    return;
    ;
}


void _60cleanup_open_includes()
{
    int _14855 = NOVALUE;
    int _14854 = NOVALUE;
    int _14853 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_60IncludeStk_23573)){
            _14853 = SEQ_PTR(_60IncludeStk_23573)->length;
    }
    else {
        _14853 = 1;
    }
    {
        int _i_26260;
        _i_26260 = 1;
L1: 
        if (_i_26260 > _14853){
            goto L2; // [8] 36
        }

        /** 		close( IncludeStk[i][FILE_PTR] )*/
        _2 = (int)SEQ_PTR(_60IncludeStk_23573);
        _14854 = (int)*(((s1_ptr)_2)->base + _i_26260);
        _2 = (int)SEQ_PTR(_14854);
        _14855 = (int)*(((s1_ptr)_2)->base + 3);
        _14854 = NOVALUE;
        if (IS_ATOM_INT(_14855))
        EClose(_14855);
        else
        EClose((int)DBL_PTR(_14855)->dbl);
        _14855 = NOVALUE;

        /** 	end for*/
        _i_26260 = _i_26260 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}



// 0x6B91D634
