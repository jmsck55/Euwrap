// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _66advance(int _pc_52256, int _code_52257)
{
    int _26951 = NOVALUE;
    int _26949 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prev_pc = pc*/
    _66prev_pc_52241 = _pc_52256;

    /** 	if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_52257)){
            _26949 = SEQ_PTR(_code_52257)->length;
    }
    else {
        _26949 = 1;
    }
    if (_pc_52256 <= _26949)
    goto L1; // [15] 26

    /** 		return pc*/
    DeRefDS(_code_52257);
    return _pc_52256;
L1: 

    /** 	return shift:advance( pc, code )*/
    RefDS(_code_52257);
    _26951 = _64advance(_pc_52256, _code_52257);
    DeRefDS(_code_52257);
    return _26951;
    ;
}


void _66shift(int _start_52264, int _amount_52265, int _bound_52266)
{
    int _temp_LineTable_52267 = NOVALUE;
    int _temp_Code_52269 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_52265)) {
        _1 = (long)(DBL_PTR(_amount_52265)->dbl);
        DeRefDS(_amount_52265);
        _amount_52265 = _1;
    }

    /** 		temp_LineTable = LineTable,*/
    RefDS(_12LineTable_11772);
    DeRef(_temp_LineTable_52267);
    _temp_LineTable_52267 = _12LineTable_11772;

    /** 		temp_Code = Code*/
    RefDS(_12Code_11771);
    DeRef(_temp_Code_52269);
    _temp_Code_52269 = _12Code_11771;

    /** 	LineTable = {}*/
    RefDS(_21829);
    DeRefDS(_12LineTable_11772);
    _12LineTable_11772 = _21829;

    /** 	Code = inline_code*/
    RefDS(_66inline_code_52233);
    DeRefDS(_12Code_11771);
    _12Code_11771 = _66inline_code_52233;

    /** 	inline_code = {}*/
    RefDS(_21829);
    DeRefDS(_66inline_code_52233);
    _66inline_code_52233 = _21829;

    /** 	shift:shift( start, amount, bound )*/
    _64shift(_start_52264, _amount_52265, _bound_52266);

    /** 	LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_52267);
    DeRefDS(_12LineTable_11772);
    _12LineTable_11772 = _temp_LineTable_52267;

    /** 	inline_code = Code*/
    RefDS(_12Code_11771);
    DeRefDS(_66inline_code_52233);
    _66inline_code_52233 = _12Code_11771;

    /** 	Code = temp_Code*/
    RefDS(_temp_Code_52269);
    DeRefDS(_12Code_11771);
    _12Code_11771 = _temp_Code_52269;

    /** end procedure*/
    DeRefDS(_temp_LineTable_52267);
    DeRefDS(_temp_Code_52269);
    return;
    ;
}


void _66insert_code(int _code_52278, int _index_52279)
{
    int _26953 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_52279)) {
        _1 = (long)(DBL_PTR(_index_52279)->dbl);
        DeRefDS(_index_52279);
        _index_52279 = _1;
    }

    /** 	inline_code = splice( inline_code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_52279;
        if (insert_pos <= 0) {
            Concat(&_66inline_code_52233,_code_52278,_66inline_code_52233);
        }
        else if (insert_pos > SEQ_PTR(_66inline_code_52233)->length){
            Concat(&_66inline_code_52233,_66inline_code_52233,_code_52278);
        }
        else if (IS_SEQUENCE(_code_52278)) {
            if( _66inline_code_52233 != _66inline_code_52233 || SEQ_PTR( _66inline_code_52233 )->ref != 1 ){
                DeRef( _66inline_code_52233 );
                RefDS( _66inline_code_52233 );
            }
            assign_space = Add_internal_space( _66inline_code_52233, insert_pos,((s1_ptr)SEQ_PTR(_code_52278))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_52278), _66inline_code_52233 == _66inline_code_52233 );
            _66inline_code_52233 = MAKE_SEQ( assign_space );
        }
        else {
            if( _66inline_code_52233 != _66inline_code_52233 && SEQ_PTR( _66inline_code_52233 )->ref != 1 ){
                _66inline_code_52233 = Insert( _66inline_code_52233, _code_52278, insert_pos);
            }
            else {
                DeRef( _66inline_code_52233 );
                RefDS( _66inline_code_52233 );
                _66inline_code_52233 = Insert( _66inline_code_52233, _code_52278, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_52278)){
            _26953 = SEQ_PTR(_code_52278)->length;
    }
    else {
        _26953 = 1;
    }
    _66shift(_index_52279, _26953, _index_52279);
    _26953 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52278);
    return;
    ;
}


void _66replace_code(int _code_52284, int _start_52285, int _finish_52286)
{
    int _26958 = NOVALUE;
    int _26957 = NOVALUE;
    int _26956 = NOVALUE;
    int _26955 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_52285)) {
        _1 = (long)(DBL_PTR(_start_52285)->dbl);
        DeRefDS(_start_52285);
        _start_52285 = _1;
    }
    if (!IS_ATOM_INT(_finish_52286)) {
        _1 = (long)(DBL_PTR(_finish_52286)->dbl);
        DeRefDS(_finish_52286);
        _finish_52286 = _1;
    }

    /** 	inline_code = replace( inline_code, code, start, finish )*/
    {
        int p1 = _66inline_code_52233;
        int p2 = _code_52284;
        int p3 = _start_52285;
        int p4 = _finish_52286;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_66inline_code_52233;
        Replace( &replace_params );
    }

    /** 	shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_52284)){
            _26955 = SEQ_PTR(_code_52284)->length;
    }
    else {
        _26955 = 1;
    }
    _26956 = _finish_52286 - _start_52285;
    if ((long)((unsigned long)_26956 +(unsigned long) HIGH_BITS) >= 0){
        _26956 = NewDouble((double)_26956);
    }
    if (IS_ATOM_INT(_26956)) {
        _26957 = _26956 + 1;
        if (_26957 > MAXINT){
            _26957 = NewDouble((double)_26957);
        }
    }
    else
    _26957 = binary_op(PLUS, 1, _26956);
    DeRef(_26956);
    _26956 = NOVALUE;
    if (IS_ATOM_INT(_26957)) {
        _26958 = _26955 - _26957;
        if ((long)((unsigned long)_26958 +(unsigned long) HIGH_BITS) >= 0){
            _26958 = NewDouble((double)_26958);
        }
    }
    else {
        _26958 = NewDouble((double)_26955 - DBL_PTR(_26957)->dbl);
    }
    _26955 = NOVALUE;
    DeRef(_26957);
    _26957 = NOVALUE;
    _66shift(_start_52285, _26958, _finish_52286);
    _26958 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52284);
    return;
    ;
}


void _66defer()
{
    int _dx_52294 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_52294 = find_from(_66inline_sub_52247, _66deferred_inline_decisions_52249, 1);

    /** 	if not dx then*/
    if (_dx_52294 != 0)
    goto L1; // [14] 36

    /** 		deferred_inline_decisions &= inline_sub*/
    Append(&_66deferred_inline_decisions_52249, _66deferred_inline_decisions_52249, _66inline_sub_52247);

    /** 		deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_21829);
    Append(&_66deferred_inline_calls_52250, _66deferred_inline_calls_52250, _21829);
L1: 

    /** end procedure*/
    return;
    ;
}


int _66new_inline_temp(int _sym_52303)
{
    int _26964 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_temps &= sym*/
    Append(&_66inline_temps_52235, _66inline_temps_52235, _sym_52303);

    /** 	return length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_52235)){
            _26964 = SEQ_PTR(_66inline_temps_52235)->length;
    }
    else {
        _26964 = 1;
    }
    return _26964;
    ;
}


int _66get_inline_temp(int _sym_52309)
{
    int _temp_num_52310 = NOVALUE;
    int _26968 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = find( sym, inline_params )*/
    _temp_num_52310 = find_from(_sym_52309, _66inline_params_52238, 1);

    /** 	if temp_num then*/
    if (_temp_num_52310 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52310;
L1: 

    /** 	temp_num = find( sym, proc_vars )*/
    _temp_num_52310 = find_from(_sym_52309, _66proc_vars_52234, 1);

    /** 	if temp_num then*/
    if (_temp_num_52310 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52310;
L2: 

    /** 	temp_num = find( sym, inline_temps )*/
    _temp_num_52310 = find_from(_sym_52309, _66inline_temps_52235, 1);

    /** 	if temp_num then*/
    if (_temp_num_52310 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52310;
L3: 

    /** 	return new_inline_temp( sym )*/
    _26968 = _66new_inline_temp(_sym_52309);
    return _26968;
    ;
}


int _66generic_symbol(int _sym_52321)
{
    int _inline_type_52322 = NOVALUE;
    int _px_52323 = NOVALUE;
    int _eentry_52330 = NOVALUE;
    int _26977 = NOVALUE;
    int _26976 = NOVALUE;
    int _26975 = NOVALUE;
    int _26974 = NOVALUE;
    int _26972 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer px = find( sym, inline_params )*/
    _px_52323 = find_from(_sym_52321, _66inline_params_52238, 1);

    /** 	if px then*/
    if (_px_52323 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		inline_type = INLINE_PARAM*/
    _inline_type_52322 = 1;
    goto L2; // [22] 100
L1: 

    /** 		px = find( sym, proc_vars )*/
    _px_52323 = find_from(_sym_52321, _66proc_vars_52234, 1);

    /** 		if px then*/
    if (_px_52323 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** 			inline_type = INLINE_VAR*/
    _inline_type_52322 = 6;
    goto L4; // [44] 99
L3: 

    /** 			sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52330);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _eentry_52330 = (int)*(((s1_ptr)_2)->base + _sym_52321);
    Ref(_eentry_52330);

    /** 			if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _26972 = _66is_literal(_sym_52321);
    if (IS_ATOM_INT(_26972)) {
        if (_26972 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_26972)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (int)SEQ_PTR(_eentry_52330);
    _26974 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_26974)) {
        _26975 = (_26974 > 3);
    }
    else {
        _26975 = binary_op(GREATER, _26974, 3);
    }
    _26974 = NOVALUE;
    if (_26975 == 0) {
        DeRef(_26975);
        _26975 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_26975) && DBL_PTR(_26975)->dbl == 0.0){
            DeRef(_26975);
            _26975 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_26975);
        _26975 = NOVALUE;
    }
    DeRef(_26975);
    _26975 = NOVALUE;
L5: 

    /** 				return sym*/
    DeRef(_eentry_52330);
    DeRef(_26972);
    _26972 = NOVALUE;
    return _sym_52321;
L6: 

    /** 			inline_type = INLINE_TEMP*/
    _inline_type_52322 = 2;
    DeRef(_eentry_52330);
    _eentry_52330 = NOVALUE;
L4: 
L2: 

    /** 	return { inline_type, get_inline_temp( sym ) }*/
    _26976 = _66get_inline_temp(_sym_52321);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _inline_type_52322;
    ((int *)_2)[2] = _26976;
    _26977 = MAKE_SEQ(_1);
    _26976 = NOVALUE;
    DeRef(_26972);
    _26972 = NOVALUE;
    return _26977;
    ;
}


int _66adjust_symbol(int _pc_52345)
{
    int _sym_52347 = NOVALUE;
    int _eentry_52353 = NOVALUE;
    int _26985 = NOVALUE;
    int _26983 = NOVALUE;
    int _26982 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52345)) {
        _1 = (long)(DBL_PTR(_pc_52345)->dbl);
        DeRefDS(_pc_52345);
        _pc_52345 = _1;
    }

    /** 	symtab_index sym = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _sym_52347 = (int)*(((s1_ptr)_2)->base + _pc_52345);
    if (!IS_ATOM_INT(_sym_52347)){
        _sym_52347 = (long)DBL_PTR(_sym_52347)->dbl;
    }

    /** 	if sym < 0 then*/
    if (_sym_52347 >= 0)
    goto L1; // [15] 28

    /** 		return 0*/
    DeRef(_eentry_52353);
    return 0;
    goto L2; // [25] 41
L1: 

    /** 	elsif not sym then*/
    if (_sym_52347 != 0)
    goto L3; // [30] 40

    /** 		return 1*/
    DeRef(_eentry_52353);
    return 1;
L3: 
L2: 

    /** 	sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52353);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _eentry_52353 = (int)*(((s1_ptr)_2)->base + _sym_52347);
    Ref(_eentry_52353);

    /** 	if is_literal( sym ) then*/
    _26982 = _66is_literal(_sym_52347);
    if (_26982 == 0) {
        DeRef(_26982);
        _26982 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_26982) && DBL_PTR(_26982)->dbl == 0.0){
            DeRef(_26982);
            _26982 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_26982);
        _26982 = NOVALUE;
    }
    DeRef(_26982);
    _26982 = NOVALUE;

    /** 		return 1*/
    DeRefDS(_eentry_52353);
    return 1;
    goto L5; // [66] 95
L4: 

    /** 	elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_eentry_52353);
    _26983 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _26983, 9)){
        _26983 = NOVALUE;
        goto L6; // [79] 94
    }
    _26983 = NOVALUE;

    /** 		defer()*/
    _66defer();

    /** 		return 0*/
    DeRefDS(_eentry_52353);
    return 0;
L6: 
L5: 

    /** 	inline_code[pc] = generic_symbol( sym )*/
    _26985 = _66generic_symbol(_sym_52347);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52345);
    _1 = *(int *)_2;
    *(int *)_2 = _26985;
    if( _1 != _26985 ){
        DeRef(_1);
    }
    _26985 = NOVALUE;

    /** 	return 1*/
    DeRef(_eentry_52353);
    return 1;
    ;
}


int _66check_for_param(int _pc_52367)
{
    int _px_52368 = NOVALUE;
    int _26988 = NOVALUE;
    int _26986 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52367)) {
        _1 = (long)(DBL_PTR(_pc_52367)->dbl);
        DeRefDS(_pc_52367);
        _pc_52367 = _1;
    }

    /** 	integer px = find( inline_code[pc], inline_params )*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _26986 = (int)*(((s1_ptr)_2)->base + _pc_52367);
    _px_52368 = find_from(_26986, _66inline_params_52238, 1);
    _26986 = NOVALUE;

    /** 	if px then*/
    if (_px_52368 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** 		if not find( px, assigned_params ) then*/
    _26988 = find_from(_px_52368, _66assigned_params_52239, 1);
    if (_26988 != 0)
    goto L2; // [32] 44
    _26988 = NOVALUE;

    /** 			assigned_params &= px*/
    Append(&_66assigned_params_52239, _66assigned_params_52239, _px_52368);
L2: 

    /** 		return 1*/
    return 1;
L1: 

    /** 	return 0*/
    return 0;
    ;
}


void _66check_target(int _pc_52378, int _op_52379)
{
    int _targets_52380 = NOVALUE;
    int _26997 = NOVALUE;
    int _26996 = NOVALUE;
    int _26995 = NOVALUE;
    int _26994 = NOVALUE;
    int _26993 = NOVALUE;
    int _26991 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence targets = op_info[op][OP_TARGET]*/
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _26991 = (int)*(((s1_ptr)_2)->base + _op_52379);
    DeRef(_targets_52380);
    _2 = (int)SEQ_PTR(_26991);
    _targets_52380 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_52380);
    _26991 = NOVALUE;

    /** 	if length( targets ) then*/
    if (IS_SEQUENCE(_targets_52380)){
            _26993 = SEQ_PTR(_targets_52380)->length;
    }
    else {
        _26993 = 1;
    }
    if (_26993 == 0)
    {
        _26993 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _26993 = NOVALUE;
    }

    /** 	for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_52380)){
            _26994 = SEQ_PTR(_targets_52380)->length;
    }
    else {
        _26994 = 1;
    }
    {
        int _i_52388;
        _i_52388 = 1;
L2: 
        if (_i_52388 > _26994){
            goto L3; // [34] 71
        }

        /** 			if check_for_param( pc + targets[i] ) then*/
        _2 = (int)SEQ_PTR(_targets_52380);
        _26995 = (int)*(((s1_ptr)_2)->base + _i_52388);
        if (IS_ATOM_INT(_26995)) {
            _26996 = _pc_52378 + _26995;
            if ((long)((unsigned long)_26996 + (unsigned long)HIGH_BITS) >= 0) 
            _26996 = NewDouble((double)_26996);
        }
        else {
            _26996 = binary_op(PLUS, _pc_52378, _26995);
        }
        _26995 = NOVALUE;
        _26997 = _66check_for_param(_26996);
        _26996 = NOVALUE;
        if (_26997 == 0) {
            DeRef(_26997);
            _26997 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_26997) && DBL_PTR(_26997)->dbl == 0.0){
                DeRef(_26997);
                _26997 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_26997);
            _26997 = NOVALUE;
        }
        DeRef(_26997);
        _26997 = NOVALUE;

        /** 				return*/
        DeRefDS(_targets_52380);
        return;
L4: 

        /** 		end for*/
        _i_52388 = _i_52388 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_targets_52380);
    return;
    ;
}


int _66adjust_il(int _pc_52396, int _op_52397)
{
    int _addr_52405 = NOVALUE;
    int _sub_52411 = NOVALUE;
    int _27022 = NOVALUE;
    int _27021 = NOVALUE;
    int _27020 = NOVALUE;
    int _27019 = NOVALUE;
    int _27018 = NOVALUE;
    int _27017 = NOVALUE;
    int _27016 = NOVALUE;
    int _27014 = NOVALUE;
    int _27013 = NOVALUE;
    int _27012 = NOVALUE;
    int _27011 = NOVALUE;
    int _27010 = NOVALUE;
    int _27009 = NOVALUE;
    int _27008 = NOVALUE;
    int _27007 = NOVALUE;
    int _27005 = NOVALUE;
    int _27004 = NOVALUE;
    int _27002 = NOVALUE;
    int _27001 = NOVALUE;
    int _27000 = NOVALUE;
    int _26999 = NOVALUE;
    int _26998 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _26998 = (int)*(((s1_ptr)_2)->base + _op_52397);
    _2 = (int)SEQ_PTR(_26998);
    _26999 = (int)*(((s1_ptr)_2)->base + 2);
    _26998 = NOVALUE;
    if (IS_ATOM_INT(_26999)) {
        _27000 = _26999 - 1;
        if ((long)((unsigned long)_27000 +(unsigned long) HIGH_BITS) >= 0){
            _27000 = NewDouble((double)_27000);
        }
    }
    else {
        _27000 = binary_op(MINUS, _26999, 1);
    }
    _26999 = NOVALUE;
    {
        int _i_52399;
        _i_52399 = 1;
L1: 
        if (binary_op_a(GREATER, _i_52399, _27000)){
            goto L2; // [23] 214
        }

        /** 		integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (int)SEQ_PTR(_64op_info_26268);
        _27001 = (int)*(((s1_ptr)_2)->base + _op_52397);
        _2 = (int)SEQ_PTR(_27001);
        _27002 = (int)*(((s1_ptr)_2)->base + 3);
        _27001 = NOVALUE;
        _addr_52405 = find_from(_i_52399, _27002, 1);
        _27002 = NOVALUE;

        /** 		integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (int)SEQ_PTR(_64op_info_26268);
        _27004 = (int)*(((s1_ptr)_2)->base + _op_52397);
        _2 = (int)SEQ_PTR(_27004);
        _27005 = (int)*(((s1_ptr)_2)->base + 5);
        _27004 = NOVALUE;
        _sub_52411 = find_from(_i_52399, _27005, 1);
        _27005 = NOVALUE;

        /** 		if addr then*/
        if (_addr_52405 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** 			if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_52399)) {
            _27007 = _pc_52396 + _i_52399;
        }
        else {
            _27007 = NewDouble((double)_pc_52396 + DBL_PTR(_i_52399)->dbl);
        }
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!IS_ATOM_INT(_27007)){
            _27008 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27007)->dbl));
        }
        else{
            _27008 = (int)*(((s1_ptr)_2)->base + _27007);
        }
        if (IS_ATOM_INT(_27008))
        _27009 = 1;
        else if (IS_ATOM_DBL(_27008))
        _27009 = IS_ATOM_INT(DoubleToInt(_27008));
        else
        _27009 = 0;
        _27008 = NOVALUE;
        if (_27009 == 0)
        {
            _27009 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27009 = NOVALUE;
        }

        /** 				inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_52399)) {
            _27010 = _pc_52396 + _i_52399;
            if ((long)((unsigned long)_27010 + (unsigned long)HIGH_BITS) >= 0) 
            _27010 = NewDouble((double)_27010);
        }
        else {
            _27010 = NewDouble((double)_pc_52396 + DBL_PTR(_i_52399)->dbl);
        }
        if (IS_ATOM_INT(_i_52399)) {
            _27011 = _pc_52396 + _i_52399;
        }
        else {
            _27011 = NewDouble((double)_pc_52396 + DBL_PTR(_i_52399)->dbl);
        }
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!IS_ATOM_INT(_27011)){
            _27012 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27011)->dbl));
        }
        else{
            _27012 = (int)*(((s1_ptr)_2)->base + _27011);
        }
        Ref(_27012);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 4;
        ((int *)_2)[2] = _27012;
        _27013 = MAKE_SEQ(_1);
        _27012 = NOVALUE;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52233 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27010))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27010)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27010);
        _1 = *(int *)_2;
        *(int *)_2 = _27013;
        if( _1 != _27013 ){
            DeRef(_1);
        }
        _27013 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** 		elsif sub then*/
        if (_sub_52411 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** 			inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_52399)) {
            _27014 = _pc_52396 + _i_52399;
        }
        else {
            _27014 = NewDouble((double)_pc_52396 + DBL_PTR(_i_52399)->dbl);
        }
        RefDS(_27015);
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52233 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27014))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27014)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27014);
        _1 = *(int *)_2;
        *(int *)_2 = _27015;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** 			if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27016 = (_op_52397 != 58);
        if (_27016 == 0) {
            _27017 = 0;
            goto L6; // [149] 163
        }
        _27018 = (_op_52397 != 210);
        _27017 = (_27018 != 0);
L6: 
        if (_27017 == 0) {
            goto L7; // [163] 204
        }
        _27020 = (_op_52397 != 211);
        if (_27020 == 0)
        {
            DeRef(_27020);
            _27020 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27020);
            _27020 = NOVALUE;
        }

        /** 				check_target( pc, op )*/
        _66check_target(_pc_52396, _op_52397);

        /** 				if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_52399)) {
            _27021 = _pc_52396 + _i_52399;
            if ((long)((unsigned long)_27021 + (unsigned long)HIGH_BITS) >= 0) 
            _27021 = NewDouble((double)_27021);
        }
        else {
            _27021 = NewDouble((double)_pc_52396 + DBL_PTR(_i_52399)->dbl);
        }
        _27022 = _66adjust_symbol(_27021);
        _27021 = NOVALUE;
        if (IS_ATOM_INT(_27022)) {
            if (_27022 != 0){
                DeRef(_27022);
                _27022 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27022)->dbl != 0.0){
                DeRef(_27022);
                _27022 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27022);
        _27022 = NOVALUE;

        /** 					return 0*/
        DeRef(_i_52399);
        DeRef(_27007);
        _27007 = NOVALUE;
        DeRef(_27000);
        _27000 = NOVALUE;
        DeRef(_27010);
        _27010 = NOVALUE;
        DeRef(_27011);
        _27011 = NOVALUE;
        DeRef(_27014);
        _27014 = NOVALUE;
        DeRef(_27016);
        _27016 = NOVALUE;
        DeRef(_27018);
        _27018 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** 	end for*/
        _0 = _i_52399;
        if (IS_ATOM_INT(_i_52399)) {
            _i_52399 = _i_52399 + 1;
            if ((long)((unsigned long)_i_52399 +(unsigned long) HIGH_BITS) >= 0){
                _i_52399 = NewDouble((double)_i_52399);
            }
        }
        else {
            _i_52399 = binary_op_a(PLUS, _i_52399, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_52399);
    }

    /** 	return 1*/
    DeRef(_27007);
    _27007 = NOVALUE;
    DeRef(_27000);
    _27000 = NOVALUE;
    DeRef(_27010);
    _27010 = NOVALUE;
    DeRef(_27011);
    _27011 = NOVALUE;
    DeRef(_27014);
    _27014 = NOVALUE;
    DeRef(_27016);
    _27016 = NOVALUE;
    DeRef(_27018);
    _27018 = NOVALUE;
    return 1;
    ;
}


int _66is_temp(int _sym_52446)
{
    int _27033 = NOVALUE;
    int _27032 = NOVALUE;
    int _27031 = NOVALUE;
    int _27030 = NOVALUE;
    int _27029 = NOVALUE;
    int _27028 = NOVALUE;
    int _27027 = NOVALUE;
    int _27026 = NOVALUE;
    int _27025 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52446 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27025 = (int)*(((s1_ptr)_2)->base + _sym_52446);
    _2 = (int)SEQ_PTR(_27025);
    _27026 = (int)*(((s1_ptr)_2)->base + 3);
    _27025 = NOVALUE;
    if (IS_ATOM_INT(_27026)) {
        _27027 = (_27026 == 3);
    }
    else {
        _27027 = binary_op(EQUALS, _27026, 3);
    }
    _27026 = NOVALUE;
    _27028 = (_12TRANSLATE_11319 == 0);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27029 = (int)*(((s1_ptr)_2)->base + _sym_52446);
    _2 = (int)SEQ_PTR(_27029);
    _27030 = (int)*(((s1_ptr)_2)->base + 1);
    _27029 = NOVALUE;
    if (_12NOVALUE_11536 == _27030)
    _27031 = 1;
    else if (IS_ATOM_INT(_12NOVALUE_11536) && IS_ATOM_INT(_27030))
    _27031 = 0;
    else
    _27031 = (compare(_12NOVALUE_11536, _27030) == 0);
    _27030 = NOVALUE;
    _27032 = (_27028 != 0 || _27031 != 0);
    _27028 = NOVALUE;
    _27031 = NOVALUE;
    if (IS_ATOM_INT(_27027)) {
        _27033 = (_27027 != 0 && _27032 != 0);
    }
    else {
        _27033 = binary_op(AND, _27027, _27032);
    }
    DeRef(_27027);
    _27027 = NOVALUE;
    _27032 = NOVALUE;
    return _27033;
    ;
}


int _66is_literal(int _sym_52468)
{
    int _mode_52471 = NOVALUE;
    int _27048 = NOVALUE;
    int _27047 = NOVALUE;
    int _27046 = NOVALUE;
    int _27045 = NOVALUE;
    int _27044 = NOVALUE;
    int _27043 = NOVALUE;
    int _27041 = NOVALUE;
    int _27040 = NOVALUE;
    int _27039 = NOVALUE;
    int _27038 = NOVALUE;
    int _27037 = NOVALUE;
    int _27035 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52468 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	integer mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27035 = (int)*(((s1_ptr)_2)->base + _sym_52468);
    _2 = (int)SEQ_PTR(_27035);
    _mode_52471 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_52471)){
        _mode_52471 = (long)DBL_PTR(_mode_52471)->dbl;
    }
    _27035 = NOVALUE;

    /** 	if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27037 = (_mode_52471 == 2);
    if (_27037 == 0) {
        _27038 = 0;
        goto L2; // [40] 66
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27039 = (int)*(((s1_ptr)_2)->base + _sym_52468);
    _2 = (int)SEQ_PTR(_27039);
    _27040 = (int)*(((s1_ptr)_2)->base + 1);
    _27039 = NOVALUE;
    if (IS_ATOM_INT(_12NOVALUE_11536) && IS_ATOM_INT(_27040)){
        _27041 = (_12NOVALUE_11536 < _27040) ? -1 : (_12NOVALUE_11536 > _27040);
    }
    else{
        _27041 = compare(_12NOVALUE_11536, _27040);
    }
    _27040 = NOVALUE;
    _27038 = (_27041 != 0);
L2: 
    if (_27038 != 0) {
        goto L3; // [66] 117
    }
    if (_12TRANSLATE_11319 == 0) {
        _27043 = 0;
        goto L4; // [72] 86
    }
    _27044 = (_mode_52471 == 3);
    _27043 = (_27044 != 0);
L4: 
    if (_27043 == 0) {
        DeRef(_27045);
        _27045 = 0;
        goto L5; // [86] 112
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27046 = (int)*(((s1_ptr)_2)->base + _sym_52468);
    _2 = (int)SEQ_PTR(_27046);
    _27047 = (int)*(((s1_ptr)_2)->base + 1);
    _27046 = NOVALUE;
    if (IS_ATOM_INT(_27047) && IS_ATOM_INT(_12NOVALUE_11536)){
        _27048 = (_27047 < _12NOVALUE_11536) ? -1 : (_27047 > _12NOVALUE_11536);
    }
    else{
        _27048 = compare(_27047, _12NOVALUE_11536);
    }
    _27047 = NOVALUE;
    _27045 = (_27048 != 0);
L5: 
    if (_27045 == 0)
    {
        _27045 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27045 = NOVALUE;
    }
L3: 

    /** 		return 1*/
    DeRef(_27037);
    _27037 = NOVALUE;
    DeRef(_27044);
    _27044 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** 		return 0*/
    DeRef(_27037);
    _27037 = NOVALUE;
    DeRef(_27044);
    _27044 = NOVALUE;
    return 0;
L7: 
    ;
}


int _66returnf(int _pc_52518)
{
    int _retsym_52520 = NOVALUE;
    int _code_52553 = NOVALUE;
    int _ret_pc_52554 = NOVALUE;
    int _code_52599 = NOVALUE;
    int _ret_pc_52613 = NOVALUE;
    int _27121 = NOVALUE;
    int _27120 = NOVALUE;
    int _27118 = NOVALUE;
    int _27116 = NOVALUE;
    int _27115 = NOVALUE;
    int _27113 = NOVALUE;
    int _27112 = NOVALUE;
    int _27110 = NOVALUE;
    int _27109 = NOVALUE;
    int _27108 = NOVALUE;
    int _27106 = NOVALUE;
    int _27105 = NOVALUE;
    int _27103 = NOVALUE;
    int _27101 = NOVALUE;
    int _27100 = NOVALUE;
    int _27098 = NOVALUE;
    int _27097 = NOVALUE;
    int _27095 = NOVALUE;
    int _27094 = NOVALUE;
    int _27093 = NOVALUE;
    int _27091 = NOVALUE;
    int _27090 = NOVALUE;
    int _27089 = NOVALUE;
    int _27088 = NOVALUE;
    int _27087 = NOVALUE;
    int _27085 = NOVALUE;
    int _27084 = NOVALUE;
    int _27083 = NOVALUE;
    int _27082 = NOVALUE;
    int _27080 = NOVALUE;
    int _27078 = NOVALUE;
    int _27077 = NOVALUE;
    int _27076 = NOVALUE;
    int _27075 = NOVALUE;
    int _27074 = NOVALUE;
    int _27073 = NOVALUE;
    int _27072 = NOVALUE;
    int _27071 = NOVALUE;
    int _27070 = NOVALUE;
    int _27068 = NOVALUE;
    int _27067 = NOVALUE;
    int _27066 = NOVALUE;
    int _27064 = NOVALUE;
    int _27063 = NOVALUE;
    int _27062 = NOVALUE;
    int _27061 = NOVALUE;
    int _27060 = NOVALUE;
    int _27059 = NOVALUE;
    int _27057 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index retsym = inline_code[pc+3]*/
    _27057 = _pc_52518 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _retsym_52520 = (int)*(((s1_ptr)_2)->base + _27057);
    if (!IS_ATOM_INT(_retsym_52520)){
        _retsym_52520 = (long)DBL_PTR(_retsym_52520)->dbl;
    }

    /** 	if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27059 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27059 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27060 = (int)*(((s1_ptr)_2)->base + _27059);
    if (_27060 == 43)
    _27061 = 1;
    else if (IS_ATOM_INT(_27060) && IS_ATOM_INT(43))
    _27061 = 0;
    else
    _27061 = (compare(_27060, 43) == 0);
    _27060 = NOVALUE;
    if (_27061 == 0)
    {
        _27061 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27061 = NOVALUE;
    }

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27062 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27062 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27062);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** 		elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27063 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52247);
    _2 = (int)SEQ_PTR(_27063);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _27064 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _27064 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _27063 = NOVALUE;
    if (binary_op_a(NOTEQ, _27064, 27)){
        _27064 = NOVALUE;
        goto L4; // [78] 100
    }
    _27064 = NOVALUE;

    /** 			replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27066 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27066 = 1;
    }
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27067 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27067 = 1;
    }
    RefDS(_21829);
    _66replace_code(_21829, _27066, _27067);
    _27066 = NOVALUE;
    _27067 = NOVALUE;
L4: 
L3: 
L1: 

    /** 	if is_temp( retsym ) */
    _27068 = _66is_temp(_retsym_52520);
    if (IS_ATOM_INT(_27068)) {
        if (_27068 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27068)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27070 = _66is_literal(_retsym_52520);
    if (IS_ATOM_INT(_27070)) {
        _27071 = (_27070 == 0);
    }
    else {
        _27071 = unary_op(NOT, _27070);
    }
    DeRef(_27070);
    _27070 = NOVALUE;
    if (IS_ATOM_INT(_27071)) {
        if (_27071 == 0) {
            DeRef(_27072);
            _27072 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27071)->dbl == 0.0) {
            DeRef(_27072);
            _27072 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27073 = (int)*(((s1_ptr)_2)->base + _retsym_52520);
    _2 = (int)SEQ_PTR(_27073);
    _27074 = (int)*(((s1_ptr)_2)->base + 4);
    _27073 = NOVALUE;
    if (IS_ATOM_INT(_27074)) {
        _27075 = (_27074 <= 3);
    }
    else {
        _27075 = binary_op(LESSEQ, _27074, 3);
    }
    _27074 = NOVALUE;
    DeRef(_27072);
    if (IS_ATOM_INT(_27075))
    _27072 = (_27075 != 0);
    else
    _27072 = DBL_PTR(_27075)->dbl != 0.0;
L6: 
    if (_27072 == 0)
    {
        _27072 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27072 = NOVALUE;
    }
L5: 

    /** 		sequence code = {}*/
    RefDS(_21829);
    DeRef(_code_52553);
    _code_52553 = _21829;

    /** 		integer ret_pc = 0*/
    _ret_pc_52554 = 0;

    /** 		if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27076 = find_from(_retsym_52520, _66inline_params_52238, 1);
    if (_27076 != 0) {
        DeRef(_27077);
        _27077 = 1;
        goto L8; // [171] 186
    }
    _27078 = find_from(_retsym_52520, _66proc_vars_52234, 1);
    _27077 = (_27078 != 0);
L8: 
    if (_27077 != 0)
    goto L9; // [186] 206
    _27077 = NOVALUE;

    /** 			ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27080 = _66generic_symbol(_retsym_52520);
    RefDS(_66inline_code_52233);
    _ret_pc_52554 = _20rfind(_27080, _66inline_code_52233, _pc_52518);
    _27080 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_52554)) {
        _1 = (long)(DBL_PTR(_ret_pc_52554)->dbl);
        DeRefDS(_ret_pc_52554);
        _ret_pc_52554 = _1;
    }
L9: 

    /** 		if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_52554 == 0) {
        goto LA; // [208] 277
    }
    _27083 = _ret_pc_52554 - 1;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27084 = (int)*(((s1_ptr)_2)->base + _27083);
    if (IS_ATOM_INT(_27084) && IS_ATOM_INT(30)){
        _27085 = (_27084 < 30) ? -1 : (_27084 > 30);
    }
    else{
        _27085 = compare(_27084, 30);
    }
    _27084 = NOVALUE;
    if (_27085 == 0)
    {
        _27085 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27085 = NOVALUE;
    }

    /** 			inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27086);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_pc_52554);
    _1 = *(int *)_2;
    *(int *)_2 = _27086;
    DeRef(_1);

    /** 			if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27087 = _ret_pc_52554 - 1;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27088 = (int)*(((s1_ptr)_2)->base + _27087);
    if (_27088 == 207)
    _27089 = 1;
    else if (IS_ATOM_INT(_27088) && IS_ATOM_INT(207))
    _27089 = 0;
    else
    _27089 = (compare(_27088, 207) == 0);
    _27088 = NOVALUE;
    if (_27089 == 0)
    {
        _27089 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27089 = NOVALUE;
    }

    /** 				inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27090 = _ret_pc_52554 - 2;
    RefDS(_27086);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27090);
    _1 = *(int *)_2;
    *(int *)_2 = _27086;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** 			code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27091 = _66generic_symbol(_retsym_52520);
    _0 = _code_52553;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _27091;
    RefDS(_27086);
    *((int *)(_2+12)) = _27086;
    _code_52553 = MAKE_SEQ(_1);
    DeRef(_0);
    _27091 = NOVALUE;
LB: 

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27093 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27093 = 1;
    }
    _27094 = 3 + _12TRANSLATE_11319;
    _27095 = _27093 - _27094;
    _27093 = NOVALUE;
    _27094 = NOVALUE;
    if (_pc_52518 == _27095)
    goto LC; // [309] 330

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27097 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27097;
    _27098 = MAKE_SEQ(_1);
    _27097 = NOVALUE;
    Concat((object_ptr)&_code_52553, _code_52553, _27098);
    DeRefDS(_27098);
    _27098 = NOVALUE;
LC: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27100 = _pc_52518 + 3;
    if ((long)((unsigned long)_27100 + (unsigned long)HIGH_BITS) >= 0) 
    _27100 = NewDouble((double)_27100);
    RefDS(_code_52553);
    _66replace_code(_code_52553, _pc_52518, _27100);
    _27100 = NOVALUE;

    /** 		ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27101 = MAKE_SEQ(_1);
    _ret_pc_52554 = find_from(_27101, _66inline_code_52233, _pc_52518);
    DeRefDS(_27101);
    _27101 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_52554 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_52554 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27105 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27105 = 1;
    }
    _27106 = _27105 + 1;
    _27105 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27106;
    if( _1 != _27106 ){
        DeRef(_1);
    }
    _27106 = NOVALUE;
    _27103 = NOVALUE;
LD: 

    /** 		return 1*/
    DeRef(_code_52553);
    DeRef(_27057);
    _27057 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_27071);
    _27071 = NOVALUE;
    DeRef(_27083);
    _27083 = NOVALUE;
    DeRef(_27075);
    _27075 = NOVALUE;
    DeRef(_27087);
    _27087 = NOVALUE;
    DeRef(_27090);
    _27090 = NOVALUE;
    DeRef(_27095);
    _27095 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** 		sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_52599;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _retsym_52520;
    RefDS(_27086);
    *((int *)(_2+12)) = _27086;
    _code_52599 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27108 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27108 = 1;
    }
    _27109 = 3 + _12TRANSLATE_11319;
    _27110 = _27108 - _27109;
    _27108 = NOVALUE;
    _27109 = NOVALUE;
    if (_pc_52518 == _27110)
    goto LF; // [420] 441

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27112 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27112;
    _27113 = MAKE_SEQ(_1);
    _27112 = NOVALUE;
    Concat((object_ptr)&_code_52599, _code_52599, _27113);
    DeRefDS(_27113);
    _27113 = NOVALUE;
LF: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27115 = _pc_52518 + 3;
    if ((long)((unsigned long)_27115 + (unsigned long)HIGH_BITS) >= 0) 
    _27115 = NewDouble((double)_27115);
    RefDS(_code_52599);
    _66replace_code(_code_52599, _pc_52518, _27115);
    _27115 = NOVALUE;

    /** 		integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27116 = MAKE_SEQ(_1);
    _ret_pc_52613 = find_from(_27116, _66inline_code_52233, _pc_52518);
    DeRefDS(_27116);
    _27116 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_52613 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_52613 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27120 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27120 = 1;
    }
    _27121 = _27120 + 1;
    _27120 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27121;
    if( _1 != _27121 ){
        DeRef(_1);
    }
    _27121 = NOVALUE;
    _27118 = NOVALUE;
L10: 

    /** 		return 1*/
    DeRef(_code_52599);
    DeRef(_27057);
    _27057 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_27071);
    _27071 = NOVALUE;
    DeRef(_27083);
    _27083 = NOVALUE;
    DeRef(_27075);
    _27075 = NOVALUE;
    DeRef(_27087);
    _27087 = NOVALUE;
    DeRef(_27090);
    _27090 = NOVALUE;
    DeRef(_27095);
    _27095 = NOVALUE;
    DeRef(_27110);
    _27110 = NOVALUE;
    return 1;
LE: 

    /** 	return 0*/
    DeRef(_27057);
    _27057 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_27071);
    _27071 = NOVALUE;
    DeRef(_27083);
    _27083 = NOVALUE;
    DeRef(_27075);
    _27075 = NOVALUE;
    DeRef(_27087);
    _27087 = NOVALUE;
    DeRef(_27090);
    _27090 = NOVALUE;
    DeRef(_27095);
    _27095 = NOVALUE;
    DeRef(_27110);
    _27110 = NOVALUE;
    return 0;
    ;
}


int _66inline_op(int _pc_52623)
{
    int _op_52624 = NOVALUE;
    int _code_52629 = NOVALUE;
    int _stlen_52662 = NOVALUE;
    int _file_52667 = NOVALUE;
    int _ok_52672 = NOVALUE;
    int _original_table_52695 = NOVALUE;
    int _jump_table_52699 = NOVALUE;
    int _27182 = NOVALUE;
    int _27181 = NOVALUE;
    int _27180 = NOVALUE;
    int _27179 = NOVALUE;
    int _27178 = NOVALUE;
    int _27177 = NOVALUE;
    int _27176 = NOVALUE;
    int _27175 = NOVALUE;
    int _27174 = NOVALUE;
    int _27173 = NOVALUE;
    int _27172 = NOVALUE;
    int _27171 = NOVALUE;
    int _27168 = NOVALUE;
    int _27167 = NOVALUE;
    int _27166 = NOVALUE;
    int _27165 = NOVALUE;
    int _27163 = NOVALUE;
    int _27161 = NOVALUE;
    int _27160 = NOVALUE;
    int _27158 = NOVALUE;
    int _27154 = NOVALUE;
    int _27153 = NOVALUE;
    int _27152 = NOVALUE;
    int _27151 = NOVALUE;
    int _27150 = NOVALUE;
    int _27149 = NOVALUE;
    int _27146 = NOVALUE;
    int _27145 = NOVALUE;
    int _27143 = NOVALUE;
    int _27142 = NOVALUE;
    int _27140 = NOVALUE;
    int _27138 = NOVALUE;
    int _27137 = NOVALUE;
    int _27136 = NOVALUE;
    int _27135 = NOVALUE;
    int _27134 = NOVALUE;
    int _27133 = NOVALUE;
    int _27132 = NOVALUE;
    int _27130 = NOVALUE;
    int _27129 = NOVALUE;
    int _27128 = NOVALUE;
    int _27126 = NOVALUE;
    int _27125 = NOVALUE;
    int _27124 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _op_52624 = (int)*(((s1_ptr)_2)->base + _pc_52623);
    if (!IS_ATOM_INT(_op_52624))
    _op_52624 = (long)DBL_PTR(_op_52624)->dbl;

    /** 	if op = RETURNP then*/
    if (_op_52624 != 29)
    goto L1; // [15] 150

    /** 		sequence code = ""*/
    RefDS(_21829);
    DeRef(_code_52629);
    _code_52629 = _21829;

    /** 		if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27124 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27124 = 1;
    }
    _27125 = _27124 - 1;
    _27124 = NOVALUE;
    _27126 = _27125 - _12TRANSLATE_11319;
    _27125 = NOVALUE;
    if (_pc_52623 == _27126)
    goto L2; // [43] 92

    /** 			code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27128 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27128 = 1;
    }
    _27129 = _27128 + 1;
    _27128 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _27129;
    _27130 = MAKE_SEQ(_1);
    _27129 = NOVALUE;
    DeRefDS(_code_52629);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27130;
    _code_52629 = MAKE_SEQ(_1);
    _27130 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** 				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27132 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27132 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27132);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** 		elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_12TRANSLATE_11319 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27134 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27134 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27135 = (int)*(((s1_ptr)_2)->base + _27134);
    if (IS_ATOM_INT(_27135)) {
        _27136 = (_27135 == 43);
    }
    else {
        _27136 = binary_op(EQUALS, _27135, 43);
    }
    _27135 = NOVALUE;
    if (_27136 == 0) {
        DeRef(_27136);
        _27136 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27136) && DBL_PTR(_27136)->dbl == 0.0){
            DeRef(_27136);
            _27136 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27136);
        _27136 = NOVALUE;
    }
    DeRef(_27136);
    _27136 = NOVALUE;

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27137 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27137 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27137);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** 		replace_code( code, pc, pc + 2 )*/
    _27138 = _pc_52623 + 2;
    if ((long)((unsigned long)_27138 + (unsigned long)HIGH_BITS) >= 0) 
    _27138 = NewDouble((double)_27138);
    RefDS(_code_52629);
    _66replace_code(_code_52629, _pc_52623, _27138);
    _27138 = NOVALUE;
    DeRefDS(_code_52629);
    _code_52629 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** 	elsif op = RETURNF then*/
    if (_op_52624 != 28)
    goto L6; // [154] 171

    /** 		return returnf( pc )*/
    _27140 = _66returnf(_pc_52623);
    DeRef(_27126);
    _27126 = NOVALUE;
    return _27140;
    goto L5; // [168] 526
L6: 

    /** 	elsif op = ROUTINE_ID then*/
    if (_op_52624 != 134)
    goto L7; // [175] 273

    /** 		integer*/

    /** 			stlen = inline_code[pc+2+TRANSLATE],*/
    _27142 = _pc_52623 + 2;
    if ((long)((unsigned long)_27142 + (unsigned long)HIGH_BITS) >= 0) 
    _27142 = NewDouble((double)_27142);
    if (IS_ATOM_INT(_27142)) {
        _27143 = _27142 + _12TRANSLATE_11319;
    }
    else {
        _27143 = NewDouble(DBL_PTR(_27142)->dbl + (double)_12TRANSLATE_11319);
    }
    DeRef(_27142);
    _27142 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!IS_ATOM_INT(_27143)){
        _stlen_52662 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27143)->dbl));
    }
    else{
        _stlen_52662 = (int)*(((s1_ptr)_2)->base + _27143);
    }
    if (!IS_ATOM_INT(_stlen_52662))
    _stlen_52662 = (long)DBL_PTR(_stlen_52662)->dbl;

    /** 			file  = inline_code[pc+4+TRANSLATE],*/
    _27145 = _pc_52623 + 4;
    if ((long)((unsigned long)_27145 + (unsigned long)HIGH_BITS) >= 0) 
    _27145 = NewDouble((double)_27145);
    if (IS_ATOM_INT(_27145)) {
        _27146 = _27145 + _12TRANSLATE_11319;
    }
    else {
        _27146 = NewDouble(DBL_PTR(_27145)->dbl + (double)_12TRANSLATE_11319);
    }
    DeRef(_27145);
    _27145 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!IS_ATOM_INT(_27146)){
        _file_52667 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27146)->dbl));
    }
    else{
        _file_52667 = (int)*(((s1_ptr)_2)->base + _27146);
    }
    if (!IS_ATOM_INT(_file_52667))
    _file_52667 = (long)DBL_PTR(_file_52667)->dbl;

    /** 			ok    = adjust_il( pc, op )*/
    _ok_52672 = _66adjust_il(_pc_52623, _op_52624);
    if (!IS_ATOM_INT(_ok_52672)) {
        _1 = (long)(DBL_PTR(_ok_52672)->dbl);
        DeRefDS(_ok_52672);
        _ok_52672 = _1;
    }

    /** 		inline_code[pc+2+TRANSLATE] = stlen*/
    _27149 = _pc_52623 + 2;
    if ((long)((unsigned long)_27149 + (unsigned long)HIGH_BITS) >= 0) 
    _27149 = NewDouble((double)_27149);
    if (IS_ATOM_INT(_27149)) {
        _27150 = _27149 + _12TRANSLATE_11319;
    }
    else {
        _27150 = NewDouble(DBL_PTR(_27149)->dbl + (double)_12TRANSLATE_11319);
    }
    DeRef(_27149);
    _27149 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27150))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27150)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27150);
    _1 = *(int *)_2;
    *(int *)_2 = _stlen_52662;
    DeRef(_1);

    /** 		inline_code[pc+4+TRANSLATE] = file*/
    _27151 = _pc_52623 + 4;
    if ((long)((unsigned long)_27151 + (unsigned long)HIGH_BITS) >= 0) 
    _27151 = NewDouble((double)_27151);
    if (IS_ATOM_INT(_27151)) {
        _27152 = _27151 + _12TRANSLATE_11319;
    }
    else {
        _27152 = NewDouble(DBL_PTR(_27151)->dbl + (double)_12TRANSLATE_11319);
    }
    DeRef(_27151);
    _27151 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27152))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27152)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27152);
    _1 = *(int *)_2;
    *(int *)_2 = _file_52667;
    DeRef(_1);

    /** 		return ok*/
    DeRef(_27140);
    _27140 = NOVALUE;
    DeRef(_27126);
    _27126 = NOVALUE;
    DeRef(_27143);
    _27143 = NOVALUE;
    DeRef(_27146);
    _27146 = NOVALUE;
    DeRef(_27150);
    _27150 = NOVALUE;
    DeRef(_27152);
    _27152 = NOVALUE;
    return _ok_52672;
    goto L5; // [270] 526
L7: 

    /** 	elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _27153 = (int)*(((s1_ptr)_2)->base + _op_52624);
    _2 = (int)SEQ_PTR(_27153);
    _27154 = (int)*(((s1_ptr)_2)->base + 1);
    _27153 = NOVALUE;
    if (binary_op_a(NOTEQ, _27154, 1)){
        _27154 = NOVALUE;
        goto L8; // [289] 397
    }
    _27154 = NOVALUE;

    /** 		switch op do*/
    _0 = _op_52624;
    switch ( _0 ){ 

        /** 			case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** 				symtab_index original_table = inline_code[pc + 3]*/
        _27158 = _pc_52623 + 3;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _original_table_52695 = (int)*(((s1_ptr)_2)->base + _27158);
        if (!IS_ATOM_INT(_original_table_52695)){
            _original_table_52695 = (long)DBL_PTR(_original_table_52695)->dbl;
        }

        /** 				symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_13SymTab_10636)){
                _27160 = SEQ_PTR(_13SymTab_10636)->length;
        }
        else {
            _27160 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = _27160;
        _27161 = MAKE_SEQ(_1);
        _27160 = NOVALUE;
        _jump_table_52699 = _52NewStringSym(_27161);
        _27161 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_52699)) {
            _1 = (long)(DBL_PTR(_jump_table_52699)->dbl);
            DeRefDS(_jump_table_52699);
            _jump_table_52699 = _1;
        }

        /** 				SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_jump_table_52699 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27165 = (int)*(((s1_ptr)_2)->base + _original_table_52695);
        _2 = (int)SEQ_PTR(_27165);
        _27166 = (int)*(((s1_ptr)_2)->base + 1);
        _27165 = NOVALUE;
        Ref(_27166);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _27166;
        if( _1 != _27166 ){
            DeRef(_1);
        }
        _27166 = NOVALUE;
        _27163 = NOVALUE;

        /** 				inline_code[pc+3] = jump_table*/
        _27167 = _pc_52623 + 3;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52233 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27167);
        _1 = *(int *)_2;
        *(int *)_2 = _jump_table_52699;
        DeRef(_1);
    ;}
    /** 		return adjust_il( pc, op )*/
    _27168 = _66adjust_il(_pc_52623, _op_52624);
    DeRef(_27140);
    _27140 = NOVALUE;
    DeRef(_27126);
    _27126 = NOVALUE;
    DeRef(_27158);
    _27158 = NOVALUE;
    DeRef(_27143);
    _27143 = NOVALUE;
    DeRef(_27146);
    _27146 = NOVALUE;
    DeRef(_27150);
    _27150 = NOVALUE;
    DeRef(_27152);
    _27152 = NOVALUE;
    DeRef(_27167);
    _27167 = NOVALUE;
    return _27168;
    goto L5; // [394] 526
L8: 

    /** 		switch op with fallthru do*/
    _0 = _op_52624;
    switch ( _0 ){ 

        /** 			case REF_TEMP then*/
        case 207:

        /** 				inline_code[pc+1] = {INLINE_TARGET}*/
        _27171 = _pc_52623 + 1;
        RefDS(_27086);
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52233 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27171);
        _1 = *(int *)_2;
        *(int *)_2 = _27086;
        DeRef(_1);

        /** 			case CONCAT_N then*/
        case 157:
        case 31:

        /** 				if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27172 = _pc_52623 + 2;
        if ((long)((unsigned long)_27172 + (unsigned long)HIGH_BITS) >= 0) 
        _27172 = NewDouble((double)_27172);
        _27173 = _pc_52623 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27174 = (int)*(((s1_ptr)_2)->base + _27173);
        if (IS_ATOM_INT(_27172) && IS_ATOM_INT(_27174)) {
            _27175 = _27172 + _27174;
            if ((long)((unsigned long)_27175 + (unsigned long)HIGH_BITS) >= 0) 
            _27175 = NewDouble((double)_27175);
        }
        else {
            _27175 = binary_op(PLUS, _27172, _27174);
        }
        DeRef(_27172);
        _27172 = NOVALUE;
        _27174 = NOVALUE;
        _27176 = _66check_for_param(_27175);
        _27175 = NOVALUE;
        if (_27176 == 0) {
            DeRef(_27176);
            _27176 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27176) && DBL_PTR(_27176)->dbl == 0.0){
                DeRef(_27176);
                _27176 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27176);
            _27176 = NOVALUE;
        }
        DeRef(_27176);
        _27176 = NOVALUE;
L9: 

        /** 				for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27177 = _pc_52623 + 2;
        if ((long)((unsigned long)_27177 + (unsigned long)HIGH_BITS) >= 0) 
        _27177 = NewDouble((double)_27177);
        _27178 = _pc_52623 + 2;
        if ((long)((unsigned long)_27178 + (unsigned long)HIGH_BITS) >= 0) 
        _27178 = NewDouble((double)_27178);
        _27179 = _pc_52623 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27180 = (int)*(((s1_ptr)_2)->base + _27179);
        if (IS_ATOM_INT(_27178) && IS_ATOM_INT(_27180)) {
            _27181 = _27178 + _27180;
            if ((long)((unsigned long)_27181 + (unsigned long)HIGH_BITS) >= 0) 
            _27181 = NewDouble((double)_27181);
        }
        else {
            _27181 = binary_op(PLUS, _27178, _27180);
        }
        DeRef(_27178);
        _27178 = NOVALUE;
        _27180 = NOVALUE;
        {
            int _i_52731;
            Ref(_27177);
            _i_52731 = _27177;
LA: 
            if (binary_op_a(GREATER, _i_52731, _27181)){
                goto LB; // [478] 508
            }

            /** 					if not adjust_symbol( i ) then*/
            Ref(_i_52731);
            _27182 = _66adjust_symbol(_i_52731);
            if (IS_ATOM_INT(_27182)) {
                if (_27182 != 0){
                    DeRef(_27182);
                    _27182 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27182)->dbl != 0.0){
                    DeRef(_27182);
                    _27182 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27182);
            _27182 = NOVALUE;

            /** 						return 0*/
            DeRef(_i_52731);
            DeRef(_27140);
            _27140 = NOVALUE;
            DeRef(_27126);
            _27126 = NOVALUE;
            DeRef(_27158);
            _27158 = NOVALUE;
            DeRef(_27143);
            _27143 = NOVALUE;
            DeRef(_27146);
            _27146 = NOVALUE;
            DeRef(_27150);
            _27150 = NOVALUE;
            DeRef(_27152);
            _27152 = NOVALUE;
            DeRef(_27167);
            _27167 = NOVALUE;
            DeRef(_27168);
            _27168 = NOVALUE;
            DeRef(_27171);
            _27171 = NOVALUE;
            DeRef(_27177);
            _27177 = NOVALUE;
            DeRef(_27173);
            _27173 = NOVALUE;
            DeRef(_27179);
            _27179 = NOVALUE;
            DeRef(_27181);
            _27181 = NOVALUE;
            return 0;
LC: 

            /** 				end for*/
            _0 = _i_52731;
            if (IS_ATOM_INT(_i_52731)) {
                _i_52731 = _i_52731 + 1;
                if ((long)((unsigned long)_i_52731 +(unsigned long) HIGH_BITS) >= 0){
                    _i_52731 = NewDouble((double)_i_52731);
                }
            }
            else {
                _i_52731 = binary_op_a(PLUS, _i_52731, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_52731);
        }

        /** 				return 1*/
        DeRef(_27140);
        _27140 = NOVALUE;
        DeRef(_27126);
        _27126 = NOVALUE;
        DeRef(_27158);
        _27158 = NOVALUE;
        DeRef(_27143);
        _27143 = NOVALUE;
        DeRef(_27146);
        _27146 = NOVALUE;
        DeRef(_27150);
        _27150 = NOVALUE;
        DeRef(_27152);
        _27152 = NOVALUE;
        DeRef(_27167);
        _27167 = NOVALUE;
        DeRef(_27168);
        _27168 = NOVALUE;
        DeRef(_27171);
        _27171 = NOVALUE;
        DeRef(_27177);
        _27177 = NOVALUE;
        DeRef(_27173);
        _27173 = NOVALUE;
        DeRef(_27179);
        _27179 = NOVALUE;
        DeRef(_27181);
        _27181 = NOVALUE;
        return 1;

        /** 			case else*/
        default:

        /** 				return 0*/
        DeRef(_27140);
        _27140 = NOVALUE;
        DeRef(_27126);
        _27126 = NOVALUE;
        DeRef(_27158);
        _27158 = NOVALUE;
        DeRef(_27143);
        _27143 = NOVALUE;
        DeRef(_27146);
        _27146 = NOVALUE;
        DeRef(_27150);
        _27150 = NOVALUE;
        DeRef(_27152);
        _27152 = NOVALUE;
        DeRef(_27167);
        _27167 = NOVALUE;
        DeRef(_27168);
        _27168 = NOVALUE;
        DeRef(_27171);
        _27171 = NOVALUE;
        DeRef(_27177);
        _27177 = NOVALUE;
        DeRef(_27173);
        _27173 = NOVALUE;
        DeRef(_27179);
        _27179 = NOVALUE;
        DeRef(_27181);
        _27181 = NOVALUE;
        return 0;
    ;}L5: 

    /** 	return 1*/
    DeRef(_27140);
    _27140 = NOVALUE;
    DeRef(_27126);
    _27126 = NOVALUE;
    DeRef(_27158);
    _27158 = NOVALUE;
    DeRef(_27143);
    _27143 = NOVALUE;
    DeRef(_27146);
    _27146 = NOVALUE;
    DeRef(_27150);
    _27150 = NOVALUE;
    DeRef(_27152);
    _27152 = NOVALUE;
    DeRef(_27167);
    _27167 = NOVALUE;
    DeRef(_27168);
    _27168 = NOVALUE;
    DeRef(_27171);
    _27171 = NOVALUE;
    DeRef(_27177);
    _27177 = NOVALUE;
    DeRef(_27173);
    _27173 = NOVALUE;
    DeRef(_27179);
    _27179 = NOVALUE;
    DeRef(_27181);
    _27181 = NOVALUE;
    return 1;
    ;
}


void _66restore_code()
{
    int _27184 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( temp_code ) then*/
    if (IS_SEQUENCE(_66temp_code_52741)){
            _27184 = SEQ_PTR(_66temp_code_52741)->length;
    }
    else {
        _27184 = 1;
    }
    if (_27184 == 0)
    {
        _27184 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27184 = NOVALUE;
    }

    /** 		Code = temp_code*/
    RefDS(_66temp_code_52741);
    DeRef(_12Code_11771);
    _12Code_11771 = _66temp_code_52741;
L1: 

    /** end procedure*/
    return;
    ;
}


void _66check_inline(int _sub_52750)
{
    int _pc_52779 = NOVALUE;
    int _s_52781 = NOVALUE;
    int _backpatch_op_52819 = NOVALUE;
    int _op_52823 = NOVALUE;
    int _rtn_idx_52834 = NOVALUE;
    int _args_52839 = NOVALUE;
    int _args_52871 = NOVALUE;
    int _values_52900 = NOVALUE;
    int _27271 = NOVALUE;
    int _27270 = NOVALUE;
    int _27268 = NOVALUE;
    int _27265 = NOVALUE;
    int _27263 = NOVALUE;
    int _27262 = NOVALUE;
    int _27261 = NOVALUE;
    int _27259 = NOVALUE;
    int _27258 = NOVALUE;
    int _27257 = NOVALUE;
    int _27256 = NOVALUE;
    int _27255 = NOVALUE;
    int _27254 = NOVALUE;
    int _27253 = NOVALUE;
    int _27252 = NOVALUE;
    int _27251 = NOVALUE;
    int _27249 = NOVALUE;
    int _27248 = NOVALUE;
    int _27247 = NOVALUE;
    int _27246 = NOVALUE;
    int _27245 = NOVALUE;
    int _27243 = NOVALUE;
    int _27242 = NOVALUE;
    int _27241 = NOVALUE;
    int _27240 = NOVALUE;
    int _27239 = NOVALUE;
    int _27237 = NOVALUE;
    int _27236 = NOVALUE;
    int _27235 = NOVALUE;
    int _27234 = NOVALUE;
    int _27233 = NOVALUE;
    int _27232 = NOVALUE;
    int _27231 = NOVALUE;
    int _27230 = NOVALUE;
    int _27229 = NOVALUE;
    int _27228 = NOVALUE;
    int _27227 = NOVALUE;
    int _27226 = NOVALUE;
    int _27225 = NOVALUE;
    int _27224 = NOVALUE;
    int _27222 = NOVALUE;
    int _27219 = NOVALUE;
    int _27214 = NOVALUE;
    int _27212 = NOVALUE;
    int _27209 = NOVALUE;
    int _27208 = NOVALUE;
    int _27207 = NOVALUE;
    int _27206 = NOVALUE;
    int _27205 = NOVALUE;
    int _27204 = NOVALUE;
    int _27203 = NOVALUE;
    int _27202 = NOVALUE;
    int _27200 = NOVALUE;
    int _27198 = NOVALUE;
    int _27197 = NOVALUE;
    int _27195 = NOVALUE;
    int _27193 = NOVALUE;
    int _27191 = NOVALUE;
    int _27189 = NOVALUE;
    int _27188 = NOVALUE;
    int _27187 = NOVALUE;
    int _27186 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_52750)) {
        _1 = (long)(DBL_PTR(_sub_52750)->dbl);
        DeRefDS(_sub_52750);
        _sub_52750 = _1;
    }

    /** 	if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_12OpTrace_11752 != 0) {
        goto L1; // [7] 34
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27186 = (int)*(((s1_ptr)_2)->base + _sub_52750);
    _2 = (int)SEQ_PTR(_27186);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _27187 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _27187 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _27186 = NOVALUE;
    if (IS_ATOM_INT(_27187)) {
        _27188 = (_27187 == 504);
    }
    else {
        _27188 = binary_op(EQUALS, _27187, 504);
    }
    _27187 = NOVALUE;
    if (_27188 == 0) {
        DeRef(_27188);
        _27188 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27188) && DBL_PTR(_27188)->dbl == 0.0){
            DeRef(_27188);
            _27188 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27188);
        _27188 = NOVALUE;
    }
    DeRef(_27188);
    _27188 = NOVALUE;
L1: 

    /** 		return*/
    DeRefi(_backpatch_op_52819);
    return;
L2: 

    /** 	inline_sub      = sub*/
    _66inline_sub_52247 = _sub_52750;

    /** 	if get_fwdref_count() then*/
    _27189 = _29get_fwdref_count();
    if (_27189 == 0) {
        DeRef(_27189);
        _27189 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27189) && DBL_PTR(_27189)->dbl == 0.0){
            DeRef(_27189);
            _27189 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27189);
        _27189 = NOVALUE;
    }
    DeRef(_27189);
    _27189 = NOVALUE;

    /** 		defer()*/
    _66defer();

    /** 		return*/
    DeRefi(_backpatch_op_52819);
    return;
L3: 

    /** 	temp_code = ""*/
    RefDS(_21829);
    DeRef(_66temp_code_52741);
    _66temp_code_52741 = _21829;

    /** 	if sub != CurrentSub then*/
    if (_sub_52750 == _12CurrentSub_11690)
    goto L4; // [76] 99

    /** 		Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27191 = (int)*(((s1_ptr)_2)->base + _sub_52750);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_27191);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _27191 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** 		temp_code = Code*/
    RefDS(_12Code_11771);
    DeRef(_66temp_code_52741);
    _66temp_code_52741 = _12Code_11771;
L5: 

    /** 	if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_12Code_11771)){
            _27193 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _27193 = 1;
    }
    if (_27193 <= _12OpInline_11757)
    goto L6; // [118] 128

    /** 		return*/
    DeRefi(_backpatch_op_52819);
    return;
L6: 

    /** 	inline_code     = Code*/
    RefDS(_12Code_11771);
    DeRef(_66inline_code_52233);
    _66inline_code_52233 = _12Code_11771;

    /** 	return_gotos    = 0*/
    _66return_gotos_52242 = 0;

    /** 	prev_pc         = 1*/
    _66prev_pc_52241 = 1;

    /** 	proc_vars       = {}*/
    RefDS(_21829);
    DeRefi(_66proc_vars_52234);
    _66proc_vars_52234 = _21829;

    /** 	inline_temps    = {}*/
    RefDS(_21829);
    DeRef(_66inline_temps_52235);
    _66inline_temps_52235 = _21829;

    /** 	inline_params   = {}*/
    RefDS(_21829);
    DeRefi(_66inline_params_52238);
    _66inline_params_52238 = _21829;

    /** 	assigned_params = {}*/
    RefDS(_21829);
    DeRef(_66assigned_params_52239);
    _66assigned_params_52239 = _21829;

    /** 	integer pc = 1*/
    _pc_52779 = 1;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27195 = (int)*(((s1_ptr)_2)->base + _sub_52750);
    _2 = (int)SEQ_PTR(_27195);
    _s_52781 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_52781)){
        _s_52781 = (long)DBL_PTR(_s_52781)->dbl;
    }
    _27195 = NOVALUE;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27197 = (int)*(((s1_ptr)_2)->base + _sub_52750);
    _2 = (int)SEQ_PTR(_27197);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _27198 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _27198 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _27197 = NOVALUE;
    {
        int _p_52787;
        _p_52787 = 1;
L7: 
        if (binary_op_a(GREATER, _p_52787, _27198)){
            goto L8; // [210] 248
        }

        /** 		inline_params &= s*/
        Append(&_66inline_params_52238, _66inline_params_52238, _s_52781);

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27200 = (int)*(((s1_ptr)_2)->base + _s_52781);
        _2 = (int)SEQ_PTR(_27200);
        _s_52781 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_52781)){
            _s_52781 = (long)DBL_PTR(_s_52781)->dbl;
        }
        _27200 = NOVALUE;

        /** 	end for*/
        _0 = _p_52787;
        if (IS_ATOM_INT(_p_52787)) {
            _p_52787 = _p_52787 + 1;
            if ((long)((unsigned long)_p_52787 +(unsigned long) HIGH_BITS) >= 0){
                _p_52787 = NewDouble((double)_p_52787);
            }
        }
        else {
            _p_52787 = binary_op_a(PLUS, _p_52787, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_52787);
    }

    /** 	while s != 0 and */
L9: 
    _27202 = (_s_52781 != 0);
    if (_27202 == 0) {
        goto LA; // [257] 335
    }
    _27204 = _52sym_scope(_s_52781);
    if (IS_ATOM_INT(_27204)) {
        _27205 = (_27204 <= 3);
    }
    else {
        _27205 = binary_op(LESSEQ, _27204, 3);
    }
    DeRef(_27204);
    _27204 = NOVALUE;
    if (IS_ATOM_INT(_27205)) {
        if (_27205 != 0) {
            DeRef(_27206);
            _27206 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27205)->dbl != 0.0) {
            DeRef(_27206);
            _27206 = 1;
            goto LB; // [271] 289
        }
    }
    _27207 = _52sym_scope(_s_52781);
    if (IS_ATOM_INT(_27207)) {
        _27208 = (_27207 == 9);
    }
    else {
        _27208 = binary_op(EQUALS, _27207, 9);
    }
    DeRef(_27207);
    _27207 = NOVALUE;
    DeRef(_27206);
    if (IS_ATOM_INT(_27208))
    _27206 = (_27208 != 0);
    else
    _27206 = DBL_PTR(_27208)->dbl != 0.0;
LB: 
    if (_27206 == 0)
    {
        _27206 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27206 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27209 = _52sym_scope(_s_52781);
    if (binary_op_a(EQUALS, _27209, 9)){
        DeRef(_27209);
        _27209 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27209);
    _27209 = NOVALUE;

    /** 			proc_vars &= s*/
    Append(&_66proc_vars_52234, _66proc_vars_52234, _s_52781);
LC: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27212 = (int)*(((s1_ptr)_2)->base + _s_52781);
    _2 = (int)SEQ_PTR(_27212);
    _s_52781 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_52781)){
        _s_52781 = (long)DBL_PTR(_s_52781)->dbl;
    }
    _27212 = NOVALUE;

    /** 	end while*/
    goto L9; // [332] 253
LA: 

    /** 	sequence backpatch_op = {}*/
    RefDS(_21829);
    DeRefi(_backpatch_op_52819);
    _backpatch_op_52819 = _21829;

    /** 	while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27214 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27214 = 1;
    }
    if (_pc_52779 >= _27214)
    goto LE; // [352] 869

    /** 		integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _op_52823 = (int)*(((s1_ptr)_2)->base + _pc_52779);
    if (!IS_ATOM_INT(_op_52823))
    _op_52823 = (long)DBL_PTR(_op_52823)->dbl;

    /** 		switch op do*/
    _0 = _op_52823;
    switch ( _0 ){ 

        /** 			case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 				defer()*/
        _66defer();

        /** 				restore_code()*/
        _66restore_code();

        /** 				return*/
        DeRefi(_backpatch_op_52819);
        _27198 = NOVALUE;
        DeRef(_27202);
        _27202 = NOVALUE;
        DeRef(_27205);
        _27205 = NOVALUE;
        DeRef(_27208);
        _27208 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** 			case PROC, FUNC then*/
        case 27:
        case 501:

        /** 				symtab_index rtn_idx = inline_code[pc+1]*/
        _27219 = _pc_52779 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _rtn_idx_52834 = (int)*(((s1_ptr)_2)->base + _27219);
        if (!IS_ATOM_INT(_rtn_idx_52834)){
            _rtn_idx_52834 = (long)DBL_PTR(_rtn_idx_52834)->dbl;
        }

        /** 				if rtn_idx = sub then*/
        if (_rtn_idx_52834 != _sub_52750)
        goto L10; // [414] 428

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52819);
        _27198 = NOVALUE;
        DeRef(_27202);
        _27202 = NOVALUE;
        _27219 = NOVALUE;
        DeRef(_27205);
        _27205 = NOVALUE;
        DeRef(_27208);
        _27208 = NOVALUE;
        return;
L10: 

        /** 				integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27222 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52834);
        _2 = (int)SEQ_PTR(_27222);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
            _args_52839 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
        }
        else{
            _args_52839 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
        }
        if (!IS_ATOM_INT(_args_52839)){
            _args_52839 = (long)DBL_PTR(_args_52839)->dbl;
        }
        _27222 = NOVALUE;

        /** 				if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27224 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52834);
        _2 = (int)SEQ_PTR(_27224);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _27225 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _27225 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _27224 = NOVALUE;
        if (IS_ATOM_INT(_27225)) {
            _27226 = (_27225 != 27);
        }
        else {
            _27226 = binary_op(NOTEQ, _27225, 27);
        }
        _27225 = NOVALUE;
        if (IS_ATOM_INT(_27226)) {
            if (_27226 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27226)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27228 = _pc_52779 + _args_52839;
        if ((long)((unsigned long)_27228 + (unsigned long)HIGH_BITS) >= 0) 
        _27228 = NewDouble((double)_27228);
        if (IS_ATOM_INT(_27228)) {
            _27229 = _27228 + 2;
            if ((long)((unsigned long)_27229 + (unsigned long)HIGH_BITS) >= 0) 
            _27229 = NewDouble((double)_27229);
        }
        else {
            _27229 = NewDouble(DBL_PTR(_27228)->dbl + (double)2);
        }
        DeRef(_27228);
        _27228 = NOVALUE;
        _27230 = _66check_for_param(_27229);
        _27229 = NOVALUE;
        if (_27230 == 0) {
            DeRef(_27230);
            _27230 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27230) && DBL_PTR(_27230)->dbl == 0.0){
                DeRef(_27230);
                _27230 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27230);
            _27230 = NOVALUE;
        }
        DeRef(_27230);
        _27230 = NOVALUE;
L11: 

        /** 				for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27231 = _args_52839 + 1;
        if (_27231 > MAXINT){
            _27231 = NewDouble((double)_27231);
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27232 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52834);
        _2 = (int)SEQ_PTR(_27232);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _27233 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _27233 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _27232 = NOVALUE;
        if (IS_ATOM_INT(_27233)) {
            _27234 = (_27233 != 27);
        }
        else {
            _27234 = binary_op(NOTEQ, _27233, 27);
        }
        _27233 = NOVALUE;
        if (IS_ATOM_INT(_27231) && IS_ATOM_INT(_27234)) {
            _27235 = _27231 + _27234;
            if ((long)((unsigned long)_27235 + (unsigned long)HIGH_BITS) >= 0) 
            _27235 = NewDouble((double)_27235);
        }
        else {
            _27235 = binary_op(PLUS, _27231, _27234);
        }
        DeRef(_27231);
        _27231 = NOVALUE;
        DeRef(_27234);
        _27234 = NOVALUE;
        {
            int _i_52856;
            _i_52856 = 2;
L12: 
            if (binary_op_a(GREATER, _i_52856, _27235)){
                goto L13; // [513] 550
            }

            /** 					if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_52856)) {
                _27236 = _pc_52779 + _i_52856;
                if ((long)((unsigned long)_27236 + (unsigned long)HIGH_BITS) >= 0) 
                _27236 = NewDouble((double)_27236);
            }
            else {
                _27236 = NewDouble((double)_pc_52779 + DBL_PTR(_i_52856)->dbl);
            }
            _27237 = _66adjust_symbol(_27236);
            _27236 = NOVALUE;
            if (IS_ATOM_INT(_27237)) {
                if (_27237 != 0){
                    DeRef(_27237);
                    _27237 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27237)->dbl != 0.0){
                    DeRef(_27237);
                    _27237 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27237);
            _27237 = NOVALUE;

            /** 						defer()*/
            _66defer();

            /** 						return*/
            DeRef(_i_52856);
            DeRefi(_backpatch_op_52819);
            _27198 = NOVALUE;
            DeRef(_27202);
            _27202 = NOVALUE;
            DeRef(_27219);
            _27219 = NOVALUE;
            DeRef(_27205);
            _27205 = NOVALUE;
            DeRef(_27208);
            _27208 = NOVALUE;
            DeRef(_27226);
            _27226 = NOVALUE;
            DeRef(_27235);
            _27235 = NOVALUE;
            return;
L14: 

            /** 				end for*/
            _0 = _i_52856;
            if (IS_ATOM_INT(_i_52856)) {
                _i_52856 = _i_52856 + 1;
                if ((long)((unsigned long)_i_52856 +(unsigned long) HIGH_BITS) >= 0){
                    _i_52856 = NewDouble((double)_i_52856);
                }
            }
            else {
                _i_52856 = binary_op_a(PLUS, _i_52856, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_52856);
        }
        goto LF; // [552] 851

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27239 = _pc_52779 + 2;
        if ((long)((unsigned long)_27239 + (unsigned long)HIGH_BITS) >= 0) 
        _27239 = NewDouble((double)_27239);
        _27240 = _pc_52779 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27241 = (int)*(((s1_ptr)_2)->base + _27240);
        if (IS_ATOM_INT(_27241)) {
            _27242 = _27241 + _pc_52779;
            if ((long)((unsigned long)_27242 + (unsigned long)HIGH_BITS) >= 0) 
            _27242 = NewDouble((double)_27242);
        }
        else {
            _27242 = binary_op(PLUS, _27241, _pc_52779);
        }
        _27241 = NOVALUE;
        if (IS_ATOM_INT(_27242)) {
            _27243 = _27242 + 1;
        }
        else
        _27243 = binary_op(PLUS, 1, _27242);
        DeRef(_27242);
        _27242 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_52871;
        RHS_Slice(_66inline_code_52233, _27239, _27243);

        /** 				for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_52871)){
                _27245 = SEQ_PTR(_args_52871)->length;
        }
        else {
            _27245 = 1;
        }
        _27246 = _27245 - 1;
        _27245 = NOVALUE;
        {
            int _i_52879;
            _i_52879 = 1;
L15: 
            if (_i_52879 > _27246){
                goto L16; // [598] 644
            }

            /** 					if find( args[i], args, i + 1 ) then*/
            _2 = (int)SEQ_PTR(_args_52871);
            _27247 = (int)*(((s1_ptr)_2)->base + _i_52879);
            _27248 = _i_52879 + 1;
            _27249 = find_from(_27247, _args_52871, _27248);
            _27247 = NOVALUE;
            _27248 = NOVALUE;
            if (_27249 == 0)
            {
                _27249 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27249 = NOVALUE;
            }

            /** 						defer()*/
            _66defer();

            /** 						restore_code()*/
            _66restore_code();

            /** 						return*/
            DeRefDS(_args_52871);
            DeRefi(_backpatch_op_52819);
            _27198 = NOVALUE;
            DeRef(_27202);
            _27202 = NOVALUE;
            DeRef(_27219);
            _27219 = NOVALUE;
            DeRef(_27205);
            _27205 = NOVALUE;
            DeRef(_27208);
            _27208 = NOVALUE;
            DeRef(_27239);
            _27239 = NOVALUE;
            DeRef(_27226);
            _27226 = NOVALUE;
            DeRef(_27235);
            _27235 = NOVALUE;
            DeRef(_27240);
            _27240 = NOVALUE;
            DeRef(_27243);
            _27243 = NOVALUE;
            DeRef(_27246);
            _27246 = NOVALUE;
            return;
L17: 

            /** 				end for*/
            _i_52879 = _i_52879 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** 				goto "inline op"*/
        DeRef(_args_52871);
        _args_52871 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27251 = _pc_52779 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27252 = (int)*(((s1_ptr)_2)->base + _27251);
        _27253 = _pc_52779 + 2;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27254 = (int)*(((s1_ptr)_2)->base + _27253);
        if (_27252 == _27254)
        _27255 = 1;
        else if (IS_ATOM_INT(_27252) && IS_ATOM_INT(_27254))
        _27255 = 0;
        else
        _27255 = (compare(_27252, _27254) == 0);
        _27252 = NOVALUE;
        _27254 = NOVALUE;
        if (_27255 == 0)
        {
            _27255 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27255 = NOVALUE;
        }

        /** 					defer()*/
        _66defer();

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52819);
        _27198 = NOVALUE;
        DeRef(_27202);
        _27202 = NOVALUE;
        DeRef(_27219);
        _27219 = NOVALUE;
        DeRef(_27205);
        _27205 = NOVALUE;
        DeRef(_27208);
        _27208 = NOVALUE;
        DeRef(_27239);
        _27239 = NOVALUE;
        DeRef(_27226);
        _27226 = NOVALUE;
        DeRef(_27235);
        _27235 = NOVALUE;
        DeRef(_27240);
        _27240 = NOVALUE;
        DeRef(_27243);
        _27243 = NOVALUE;
        DeRef(_27246);
        _27246 = NOVALUE;
        _27251 = NOVALUE;
        _27253 = NOVALUE;
        return;
L19: 

        /** 				goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				replace_code( "", pc, pc + 1 )*/
        _27256 = _pc_52779 + 1;
        if (_27256 > MAXINT){
            _27256 = NewDouble((double)_27256);
        }
        RefDS(_21829);
        _66replace_code(_21829, _pc_52779, _27256);
        _27256 = NOVALUE;

        /** 				continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27257 = _pc_52779 + 2;
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27258 = (int)*(((s1_ptr)_2)->base + _27257);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_27258)){
            _27259 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27258)->dbl));
        }
        else{
            _27259 = (int)*(((s1_ptr)_2)->base + _27258);
        }
        DeRef(_values_52900);
        _2 = (int)SEQ_PTR(_27259);
        _values_52900 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_values_52900);
        _27259 = NOVALUE;

        /** 				for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_52900)){
                _27261 = SEQ_PTR(_values_52900)->length;
        }
        else {
            _27261 = 1;
        }
        {
            int _i_52908;
            _i_52908 = 1;
L1A: 
            if (_i_52908 > _27261){
                goto L1B; // [771] 811
            }

            /** 					if sequence( values[i] ) then*/
            _2 = (int)SEQ_PTR(_values_52900);
            _27262 = (int)*(((s1_ptr)_2)->base + _i_52908);
            _27263 = IS_SEQUENCE(_27262);
            _27262 = NOVALUE;
            if (_27263 == 0)
            {
                _27263 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27263 = NOVALUE;
            }

            /** 						defer()*/
            _66defer();

            /** 						restore_code()*/
            _66restore_code();

            /** 						return*/
            DeRefDS(_values_52900);
            DeRefi(_backpatch_op_52819);
            _27198 = NOVALUE;
            DeRef(_27202);
            _27202 = NOVALUE;
            DeRef(_27219);
            _27219 = NOVALUE;
            DeRef(_27205);
            _27205 = NOVALUE;
            DeRef(_27208);
            _27208 = NOVALUE;
            DeRef(_27239);
            _27239 = NOVALUE;
            DeRef(_27226);
            _27226 = NOVALUE;
            DeRef(_27235);
            _27235 = NOVALUE;
            DeRef(_27240);
            _27240 = NOVALUE;
            DeRef(_27243);
            _27243 = NOVALUE;
            DeRef(_27246);
            _27246 = NOVALUE;
            DeRef(_27251);
            _27251 = NOVALUE;
            DeRef(_27257);
            _27257 = NOVALUE;
            DeRef(_27253);
            _27253 = NOVALUE;
            _27258 = NOVALUE;
            return;
L1C: 

            /** 				end for*/
            _i_52908 = _i_52908 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** 				backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_52819, _backpatch_op_52819, _pc_52779);
        DeRef(_values_52900);
        _values_52900 = NOVALUE;

        /** 			case else*/
        default:

        /** 			label "inline op"*/
G18:

        /** 				if not inline_op( pc ) then*/
        _27265 = _66inline_op(_pc_52779);
        if (IS_ATOM_INT(_27265)) {
            if (_27265 != 0){
                DeRef(_27265);
                _27265 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27265)->dbl != 0.0){
                DeRef(_27265);
                _27265 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27265);
        _27265 = NOVALUE;

        /** 					defer()*/
        _66defer();

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52819);
        _27198 = NOVALUE;
        DeRef(_27202);
        _27202 = NOVALUE;
        DeRef(_27219);
        _27219 = NOVALUE;
        DeRef(_27205);
        _27205 = NOVALUE;
        DeRef(_27208);
        _27208 = NOVALUE;
        DeRef(_27239);
        _27239 = NOVALUE;
        DeRef(_27226);
        _27226 = NOVALUE;
        DeRef(_27235);
        _27235 = NOVALUE;
        DeRef(_27240);
        _27240 = NOVALUE;
        DeRef(_27243);
        _27243 = NOVALUE;
        DeRef(_27246);
        _27246 = NOVALUE;
        DeRef(_27251);
        _27251 = NOVALUE;
        DeRef(_27257);
        _27257 = NOVALUE;
        DeRef(_27253);
        _27253 = NOVALUE;
        _27258 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** 		pc = advance( pc, inline_code )*/
    RefDS(_66inline_code_52233);
    _pc_52779 = _66advance(_pc_52779, _66inline_code_52233);
    if (!IS_ATOM_INT(_pc_52779)) {
        _1 = (long)(DBL_PTR(_pc_52779)->dbl);
        DeRefDS(_pc_52779);
        _pc_52779 = _1;
    }

    /** 	end while*/
    goto LD; // [866] 347
LE: 

    /** 	SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_52750 + ((s1_ptr)_2)->base);
    RefDS(_66assigned_params_52239);
    _27270 = _25sort(_66assigned_params_52239, 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27270;
    RefDS(_66inline_code_52233);
    *((int *)(_2+8)) = _66inline_code_52233;
    RefDS(_backpatch_op_52819);
    *((int *)(_2+12)) = _backpatch_op_52819;
    _27271 = MAKE_SEQ(_1);
    _27270 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _27271;
    if( _1 != _27271 ){
        DeRef(_1);
    }
    _27271 = NOVALUE;
    _27268 = NOVALUE;

    /** 	restore_code()*/
    _66restore_code();

    /** end procedure*/
    DeRefDSi(_backpatch_op_52819);
    _27198 = NOVALUE;
    DeRef(_27202);
    _27202 = NOVALUE;
    DeRef(_27219);
    _27219 = NOVALUE;
    DeRef(_27205);
    _27205 = NOVALUE;
    DeRef(_27208);
    _27208 = NOVALUE;
    DeRef(_27239);
    _27239 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27235);
    _27235 = NOVALUE;
    DeRef(_27240);
    _27240 = NOVALUE;
    DeRef(_27243);
    _27243 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_27251);
    _27251 = NOVALUE;
    DeRef(_27257);
    _27257 = NOVALUE;
    DeRef(_27253);
    _27253 = NOVALUE;
    _27258 = NOVALUE;
    return;
    ;
}


void _66replace_temp(int _pc_52928)
{
    int _temp_num_52929 = NOVALUE;
    int _needed_52932 = NOVALUE;
    int _27284 = NOVALUE;
    int _27283 = NOVALUE;
    int _27282 = NOVALUE;
    int _27281 = NOVALUE;
    int _27279 = NOVALUE;
    int _27277 = NOVALUE;
    int _27274 = NOVALUE;
    int _27272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = inline_code[pc][2]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27272 = (int)*(((s1_ptr)_2)->base + _pc_52928);
    _2 = (int)SEQ_PTR(_27272);
    _temp_num_52929 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_52929)){
        _temp_num_52929 = (long)DBL_PTR(_temp_num_52929)->dbl;
    }
    _27272 = NOVALUE;

    /** 	integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_52235)){
            _27274 = SEQ_PTR(_66inline_temps_52235)->length;
    }
    else {
        _27274 = 1;
    }
    _needed_52932 = _temp_num_52929 - _27274;
    _27274 = NOVALUE;

    /** 	if needed > 0 then*/
    if (_needed_52932 <= 0)
    goto L1; // [30] 47

    /** 		inline_temps &= repeat( 0, needed )*/
    _27277 = Repeat(0, _needed_52932);
    Concat((object_ptr)&_66inline_temps_52235, _66inline_temps_52235, _27277);
    DeRefDS(_27277);
    _27277 = NOVALUE;
L1: 

    /** 	if not inline_temps[temp_num] then*/
    _2 = (int)SEQ_PTR(_66inline_temps_52235);
    _27279 = (int)*(((s1_ptr)_2)->base + _temp_num_52929);
    if (IS_ATOM_INT(_27279)) {
        if (_27279 != 0){
            _27279 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27279)->dbl != 0.0){
            _27279 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27279 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** 			inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((unsigned long)_temp_num_52929 == 0xC0000000)
    _27281 = (int)NewDouble((double)-0xC0000000);
    else
    _27281 = - _temp_num_52929;
    _27282 = _66new_inline_var(_27281, 0);
    _27281 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_temps_52235);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_temps_52235 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_52929);
    _1 = *(int *)_2;
    *(int *)_2 = _27282;
    if( _1 != _27282 ){
        DeRef(_1);
    }
    _27282 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** 			inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27283 = _52NewTempSym(_9TRUE_431);
    _2 = (int)SEQ_PTR(_66inline_temps_52235);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_temps_52235 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_52929);
    _1 = *(int *)_2;
    *(int *)_2 = _27283;
    if( _1 != _27283 ){
        DeRef(_1);
    }
    _27283 = NOVALUE;
L4: 
L2: 

    /** 	inline_code[pc] = inline_temps[temp_num]*/
    _2 = (int)SEQ_PTR(_66inline_temps_52235);
    _27284 = (int)*(((s1_ptr)_2)->base + _temp_num_52929);
    Ref(_27284);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52928);
    _1 = *(int *)_2;
    *(int *)_2 = _27284;
    if( _1 != _27284 ){
        DeRef(_1);
    }
    _27284 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _66get_param_sym(int _pc_52954)
{
    int _il_52955 = NOVALUE;
    int _px_52963 = NOVALUE;
    int _27291 = NOVALUE;
    int _27288 = NOVALUE;
    int _27287 = NOVALUE;
    int _27286 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object il = inline_code[pc]*/
    DeRef(_il_52955);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _il_52955 = (int)*(((s1_ptr)_2)->base + _pc_52954);
    Ref(_il_52955);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_52955))
    _27286 = 1;
    else if (IS_ATOM_DBL(_il_52955))
    _27286 = IS_ATOM_INT(DoubleToInt(_il_52955));
    else
    _27286 = 0;
    if (_27286 == 0)
    {
        _27286 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27286 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27287 = (int)*(((s1_ptr)_2)->base + _pc_52954);
    Ref(_27287);
    DeRef(_il_52955);
    return _27287;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_52955)){
            _27288 = SEQ_PTR(_il_52955)->length;
    }
    else {
        _27288 = 1;
    }
    if (_27288 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_52955);
    _27287 = NOVALUE;
    return _66inline_target_52240;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_52955);
    _px_52963 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_52963)){
        _px_52963 = (long)DBL_PTR(_px_52963)->dbl;
    }

    /** 	return passed_params[px]*/
    _2 = (int)SEQ_PTR(_66passed_params_52236);
    _27291 = (int)*(((s1_ptr)_2)->base + _px_52963);
    Ref(_27291);
    DeRef(_il_52955);
    _27287 = NOVALUE;
    return _27291;
    ;
}


int _66get_original_sym(int _pc_52968)
{
    int _il_52969 = NOVALUE;
    int _px_52977 = NOVALUE;
    int _27298 = NOVALUE;
    int _27295 = NOVALUE;
    int _27294 = NOVALUE;
    int _27293 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52968)) {
        _1 = (long)(DBL_PTR(_pc_52968)->dbl);
        DeRefDS(_pc_52968);
        _pc_52968 = _1;
    }

    /** 	object il = inline_code[pc]*/
    DeRef(_il_52969);
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _il_52969 = (int)*(((s1_ptr)_2)->base + _pc_52968);
    Ref(_il_52969);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_52969))
    _27293 = 1;
    else if (IS_ATOM_DBL(_il_52969))
    _27293 = IS_ATOM_INT(DoubleToInt(_il_52969));
    else
    _27293 = 0;
    if (_27293 == 0)
    {
        _27293 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27293 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27294 = (int)*(((s1_ptr)_2)->base + _pc_52968);
    Ref(_27294);
    DeRef(_il_52969);
    return _27294;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_52969)){
            _27295 = SEQ_PTR(_il_52969)->length;
    }
    else {
        _27295 = 1;
    }
    if (_27295 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_52969);
    _27294 = NOVALUE;
    return _66inline_target_52240;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_52969);
    _px_52977 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_52977)){
        _px_52977 = (long)DBL_PTR(_px_52977)->dbl;
    }

    /** 	return original_params[px]*/
    _2 = (int)SEQ_PTR(_66original_params_52237);
    _27298 = (int)*(((s1_ptr)_2)->base + _px_52977);
    Ref(_27298);
    DeRef(_il_52969);
    _27294 = NOVALUE;
    return _27298;
    ;
}


void _66replace_var(int _pc_52986)
{
    int _27302 = NOVALUE;
    int _27301 = NOVALUE;
    int _27300 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27300 = (int)*(((s1_ptr)_2)->base + _pc_52986);
    _2 = (int)SEQ_PTR(_27300);
    _27301 = (int)*(((s1_ptr)_2)->base + 2);
    _27300 = NOVALUE;
    _2 = (int)SEQ_PTR(_66proc_vars_52234);
    if (!IS_ATOM_INT(_27301)){
        _27302 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27301)->dbl));
    }
    else{
        _27302 = (int)*(((s1_ptr)_2)->base + _27301);
    }
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52986);
    _1 = *(int *)_2;
    *(int *)_2 = _27302;
    if( _1 != _27302 ){
        DeRef(_1);
    }
    _27302 = NOVALUE;

    /** end procedure*/
    _27301 = NOVALUE;
    return;
    ;
}


void _66fix_switch_rt(int _pc_52992)
{
    int _value_table_52994 = NOVALUE;
    int _jump_table_53001 = NOVALUE;
    int _27322 = NOVALUE;
    int _27321 = NOVALUE;
    int _27320 = NOVALUE;
    int _27319 = NOVALUE;
    int _27318 = NOVALUE;
    int _27317 = NOVALUE;
    int _27315 = NOVALUE;
    int _27314 = NOVALUE;
    int _27313 = NOVALUE;
    int _27312 = NOVALUE;
    int _27311 = NOVALUE;
    int _27309 = NOVALUE;
    int _27307 = NOVALUE;
    int _27306 = NOVALUE;
    int _27304 = NOVALUE;
    int _27303 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _27303 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _27303 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27303;
    _27304 = MAKE_SEQ(_1);
    _27303 = NOVALUE;
    _value_table_52994 = _52NewStringSym(_27304);
    _27304 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_52994)) {
        _1 = (long)(DBL_PTR(_value_table_52994)->dbl);
        DeRefDS(_value_table_52994);
        _value_table_52994 = _1;
    }

    /** 	symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _27306 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _27306 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27306;
    _27307 = MAKE_SEQ(_1);
    _27306 = NOVALUE;
    _jump_table_53001 = _52NewStringSym(_27307);
    _27307 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_53001)) {
        _1 = (long)(DBL_PTR(_jump_table_53001)->dbl);
        DeRefDS(_jump_table_53001);
        _jump_table_53001 = _1;
    }

    /** 	SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_value_table_52994 + ((s1_ptr)_2)->base);
    _27311 = _pc_52992 + 2;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27312 = (int)*(((s1_ptr)_2)->base + _27311);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_27312)){
        _27313 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27312)->dbl));
    }
    else{
        _27313 = (int)*(((s1_ptr)_2)->base + _27312);
    }
    _2 = (int)SEQ_PTR(_27313);
    _27314 = (int)*(((s1_ptr)_2)->base + 1);
    _27313 = NOVALUE;
    Ref(_27314);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27314;
    if( _1 != _27314 ){
        DeRef(_1);
    }
    _27314 = NOVALUE;
    _27309 = NOVALUE;

    /** 	SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_53001 + ((s1_ptr)_2)->base);
    _27317 = _pc_52992 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _27318 = (int)*(((s1_ptr)_2)->base + _27317);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_27318)){
        _27319 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27318)->dbl));
    }
    else{
        _27319 = (int)*(((s1_ptr)_2)->base + _27318);
    }
    _2 = (int)SEQ_PTR(_27319);
    _27320 = (int)*(((s1_ptr)_2)->base + 1);
    _27319 = NOVALUE;
    Ref(_27320);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27320;
    if( _1 != _27320 ){
        DeRef(_1);
    }
    _27320 = NOVALUE;
    _27315 = NOVALUE;

    /** 	inline_code[pc+2] = value_table*/
    _27321 = _pc_52992 + 2;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27321);
    _1 = *(int *)_2;
    *(int *)_2 = _value_table_52994;
    DeRef(_1);

    /** 	inline_code[pc+3] = jump_table*/
    _27322 = _pc_52992 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27322);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_table_53001;
    DeRef(_1);

    /** end procedure*/
    _27321 = NOVALUE;
    _27311 = NOVALUE;
    _27312 = NOVALUE;
    _27317 = NOVALUE;
    _27318 = NOVALUE;
    _27322 = NOVALUE;
    return;
    ;
}


void _66fixup_special_op(int _pc_53031)
{
    int _op_53032 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53031)) {
        _1 = (long)(DBL_PTR(_pc_53031)->dbl);
        DeRefDS(_pc_53031);
        _pc_53031 = _1;
    }

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _op_53032 = (int)*(((s1_ptr)_2)->base + _pc_53031);
    if (!IS_ATOM_INT(_op_53032))
    _op_53032 = (long)DBL_PTR(_op_53032)->dbl;

    /** 	switch op with fallthru do*/
    _0 = _op_53032;
    switch ( _0 ){ 

        /** 		case SWITCH_RT then*/
        case 202:

        /** 			fix_switch_rt( pc )*/
        _66fix_switch_rt(_pc_53031);

        /** 			break*/
        goto L1; // [29] 32
    ;}L1: 

    /** end procedure*/
    return;
    ;
}


int _66new_inline_var(int _ps_53043, int _reuse_53044)
{
    int _var_53046 = NOVALUE;
    int _vtype_53047 = NOVALUE;
    int _name_53048 = NOVALUE;
    int _s_53050 = NOVALUE;
    int _27385 = NOVALUE;
    int _27384 = NOVALUE;
    int _27382 = NOVALUE;
    int _27379 = NOVALUE;
    int _27378 = NOVALUE;
    int _27376 = NOVALUE;
    int _27373 = NOVALUE;
    int _27372 = NOVALUE;
    int _27371 = NOVALUE;
    int _27369 = NOVALUE;
    int _27364 = NOVALUE;
    int _27359 = NOVALUE;
    int _27358 = NOVALUE;
    int _27357 = NOVALUE;
    int _27356 = NOVALUE;
    int _27353 = NOVALUE;
    int _27351 = NOVALUE;
    int _27348 = NOVALUE;
    int _27343 = NOVALUE;
    int _27342 = NOVALUE;
    int _27341 = NOVALUE;
    int _27340 = NOVALUE;
    int _27339 = NOVALUE;
    int _27336 = NOVALUE;
    int _27335 = NOVALUE;
    int _27334 = NOVALUE;
    int _27333 = NOVALUE;
    int _27332 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_53043)) {
        _1 = (long)(DBL_PTR(_ps_53043)->dbl);
        DeRefDS(_ps_53043);
        _ps_53043 = _1;
    }

    /** 		var = 0, */
    _var_53046 = 0;

    /** 	sequence name*/

    /** 	if reuse then*/

    /** 	if not var then*/

    /** 		if ps > 0 then*/
    if (_ps_53043 <= 0)
    goto L1; // [45] 222

    /** 			s = ps*/
    _s_53050 = _ps_53043;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** 				name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27332 = (int)*(((s1_ptr)_2)->base + _s_53050);
    _2 = (int)SEQ_PTR(_27332);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27333 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27332 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27334 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52247);
    _2 = (int)SEQ_PTR(_27334);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27335 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27335 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27334 = NOVALUE;
    Ref(_27335);
    Ref(_27333);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27333;
    ((int *)_2)[2] = _27335;
    _27336 = MAKE_SEQ(_1);
    _27335 = NOVALUE;
    _27333 = NOVALUE;
    DeRefi(_name_53048);
    _name_53048 = EPrintf(-9999999, _27331, _27336);
    DeRefDS(_27336);
    _27336 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** 				name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27339 = (int)*(((s1_ptr)_2)->base + _s_53050);
    _2 = (int)SEQ_PTR(_27339);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27340 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27340 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27339 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27341 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52247);
    _2 = (int)SEQ_PTR(_27341);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27342 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27342 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27341 = NOVALUE;
    Ref(_27342);
    Ref(_27340);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27340;
    ((int *)_2)[2] = _27342;
    _27343 = MAKE_SEQ(_1);
    _27342 = NOVALUE;
    _27340 = NOVALUE;
    DeRefi(_name_53048);
    _name_53048 = EPrintf(-9999999, _27338, _27343);
    DeRefDS(_27343);
    _27343 = NOVALUE;
L3: 

    /** 			if reuse then*/
    if (_reuse_53044 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** 				if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L5; // [148] 203

    /** 					name &= ")"*/
    Concat((object_ptr)&_name_53048, _name_53048, _26126);
    goto L5; // [160] 203
L4: 

    /** 				if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** 					name &= sprintf( "_at_%d", inline_start)*/
    _27348 = EPrintf(-9999999, _27347, _66inline_start_52245);
    Concat((object_ptr)&_name_53048, _name_53048, _27348);
    DeRefDS(_27348);
    _27348 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** 					name &= sprintf( " at %d)", inline_start)*/
    _27351 = EPrintf(-9999999, _27350, _66inline_start_52245);
    Concat((object_ptr)&_name_53048, _name_53048, _27351);
    DeRefDS(_27351);
    _27351 = NOVALUE;
L7: 
L5: 

    /** 			vtype = SymTab[s][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27353 = (int)*(((s1_ptr)_2)->base + _s_53050);
    _2 = (int)SEQ_PTR(_27353);
    _vtype_53047 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_53047)){
        _vtype_53047 = (long)DBL_PTR(_vtype_53047)->dbl;
    }
    _27353 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** 			name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27356 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52247);
    _2 = (int)SEQ_PTR(_27356);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27357 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27357 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27356 = NOVALUE;
    if ((unsigned long)_ps_53043 == 0xC0000000)
    _27358 = (int)NewDouble((double)-0xC0000000);
    else
    _27358 = - _ps_53043;
    Ref(_27357);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27357;
    ((int *)_2)[2] = _27358;
    _27359 = MAKE_SEQ(_1);
    _27358 = NOVALUE;
    _27357 = NOVALUE;
    DeRefi(_name_53048);
    _name_53048 = EPrintf(-9999999, _27355, _27359);
    DeRefDS(_27359);
    _27359 = NOVALUE;

    /** 			if reuse then*/
    if (_reuse_53044 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** 				name &= "__tmp"*/
    Concat((object_ptr)&_name_53048, _name_53048, _27361);
    goto LA; // [260] 276
L9: 

    /** 				name &= sprintf( "__tmp_at%d", inline_start)*/
    _27364 = EPrintf(-9999999, _27363, _66inline_start_52245);
    Concat((object_ptr)&_name_53048, _name_53048, _27364);
    DeRefDS(_27364);
    _27364 = NOVALUE;
LA: 

    /** 			vtype = object_type*/
    _vtype_53047 = _52object_type_45731;
L8: 

    /** 		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_11690 != _12TopLevelSub_11689)
    goto LB; // [292] 325

    /** 			var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53048);
    _var_53046 = _52NewEntry(_name_53048, _66varnum_52244, 5, -100, 2004, 0, _vtype_53047);
    if (!IS_ATOM_INT(_var_53046)) {
        _1 = (long)(DBL_PTR(_var_53046)->dbl);
        DeRefDS(_var_53046);
        _var_53046 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** 			var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53048);
    _var_53046 = _52NewBasicEntry(_name_53048, _66varnum_52244, 3, -100, 2004, 0, _vtype_53047);
    if (!IS_ATOM_INT(_var_53046)) {
        _1 = (long)(DBL_PTR(_var_53046)->dbl);
        DeRefDS(_var_53046);
        _var_53046 = _1;
    }

    /** 			SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53046 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27371 = (int)*(((s1_ptr)_2)->base + _66last_param_52248);
    _2 = (int)SEQ_PTR(_27371);
    _27372 = (int)*(((s1_ptr)_2)->base + 2);
    _27371 = NOVALUE;
    Ref(_27372);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27372;
    if( _1 != _27372 ){
        DeRef(_1);
    }
    _27372 = NOVALUE;
    _27369 = NOVALUE;

    /** 			SymTab[last_param][S_NEXT] = var*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66last_param_52248 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _var_53046;
    DeRef(_1);
    _27373 = NOVALUE;

    /** 			if last_param = last_sym then*/
    if (_66last_param_52248 != _52last_sym_45740)
    goto LD; // [403] 415

    /** 				last_sym = var*/
    _52last_sym_45740 = _var_53046;
LD: 
LC: 

    /** 		if deferred_inlining then*/
    if (_66deferred_inlining_52243 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _27378 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _27378 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _27376 = NOVALUE;
    if (IS_ATOM_INT(_27378)) {
        _27379 = _27378 + 1;
        if (_27379 > MAXINT){
            _27379 = NewDouble((double)_27379);
        }
    }
    else
    _27379 = binary_op(PLUS, 1, _27378);
    _27378 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    _1 = *(int *)_2;
    *(int *)_2 = _27379;
    if( _1 != _27379 ){
        DeRef(_1);
    }
    _27379 = NOVALUE;
    _27376 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** 			if param_num != -1 then*/
    if (_30param_num_53694 == -1)
    goto L10; // [455] 470

    /** 				param_num += 1*/
    _30param_num_53694 = _30param_num_53694 + 1;
L10: 
LF: 

    /** 		SymTab[var][S_USAGE] = U_USED*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53046 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _27382 = NOVALUE;

    /** 		if reuse then*/
    if (_reuse_53044 == 0)
    {
        goto L11; // [490] 513
    }
    else{
    }

    /** 			map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12CurrentSub_11690;
    ((int *)_2)[2] = _ps_53043;
    _27384 = MAKE_SEQ(_1);
    Ref(_66inline_var_map_52252);
    _32nested_put(_66inline_var_map_52252, _27384, _var_53046, 1, 23);
    _27384 = NOVALUE;
L11: 

    /** 	Block_var( var )*/
    _65Block_var(_var_53046);

    /** 	if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L12; // [523] 538
    }
    else{
    }

    /** 		add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _var_53046;
    _27385 = MAKE_SEQ(_1);
    _52add_ref(_27385);
    _27385 = NOVALUE;
L12: 

    /** 	return var*/
    DeRefi(_name_53048);
    return _var_53046;
    ;
}


int _66get_inlined_code(int _sub_53180, int _start_53181, int _deferred_53182)
{
    int _is_proc_53183 = NOVALUE;
    int _backpatches_53201 = NOVALUE;
    int _prolog_53207 = NOVALUE;
    int _epilog_53208 = NOVALUE;
    int _s_53224 = NOVALUE;
    int _last_sym_53247 = NOVALUE;
    int _int_sym_53274 = NOVALUE;
    int _param_53282 = NOVALUE;
    int _ax_53285 = NOVALUE;
    int _var_53292 = NOVALUE;
    int _final_target_53307 = NOVALUE;
    int _var_53326 = NOVALUE;
    int _create_target_var_53339 = NOVALUE;
    int _check_pc_53362 = NOVALUE;
    int _op_53366 = NOVALUE;
    int _sym_53375 = NOVALUE;
    int _check_result_53380 = NOVALUE;
    int _inline_type_53457 = NOVALUE;
    int _replace_param_1__tmp_at1341_53468 = NOVALUE;
    int _27539 = NOVALUE;
    int _27538 = NOVALUE;
    int _27537 = NOVALUE;
    int _27536 = NOVALUE;
    int _27535 = NOVALUE;
    int _27534 = NOVALUE;
    int _27533 = NOVALUE;
    int _27532 = NOVALUE;
    int _27530 = NOVALUE;
    int _27527 = NOVALUE;
    int _27524 = NOVALUE;
    int _27523 = NOVALUE;
    int _27522 = NOVALUE;
    int _27521 = NOVALUE;
    int _27520 = NOVALUE;
    int _27519 = NOVALUE;
    int _27518 = NOVALUE;
    int _27517 = NOVALUE;
    int _27513 = NOVALUE;
    int _27512 = NOVALUE;
    int _27511 = NOVALUE;
    int _27510 = NOVALUE;
    int _27506 = NOVALUE;
    int _27505 = NOVALUE;
    int _27504 = NOVALUE;
    int _27503 = NOVALUE;
    int _27502 = NOVALUE;
    int _27501 = NOVALUE;
    int _27500 = NOVALUE;
    int _27498 = NOVALUE;
    int _27497 = NOVALUE;
    int _27496 = NOVALUE;
    int _27495 = NOVALUE;
    int _27494 = NOVALUE;
    int _27493 = NOVALUE;
    int _27492 = NOVALUE;
    int _27491 = NOVALUE;
    int _27490 = NOVALUE;
    int _27489 = NOVALUE;
    int _27488 = NOVALUE;
    int _27486 = NOVALUE;
    int _27485 = NOVALUE;
    int _27483 = NOVALUE;
    int _27482 = NOVALUE;
    int _27480 = NOVALUE;
    int _27479 = NOVALUE;
    int _27476 = NOVALUE;
    int _27475 = NOVALUE;
    int _27473 = NOVALUE;
    int _27471 = NOVALUE;
    int _27466 = NOVALUE;
    int _27462 = NOVALUE;
    int _27459 = NOVALUE;
    int _27455 = NOVALUE;
    int _27448 = NOVALUE;
    int _27447 = NOVALUE;
    int _27446 = NOVALUE;
    int _27445 = NOVALUE;
    int _27444 = NOVALUE;
    int _27443 = NOVALUE;
    int _27442 = NOVALUE;
    int _27440 = NOVALUE;
    int _27435 = NOVALUE;
    int _27432 = NOVALUE;
    int _27427 = NOVALUE;
    int _27426 = NOVALUE;
    int _27424 = NOVALUE;
    int _27423 = NOVALUE;
    int _27422 = NOVALUE;
    int _27419 = NOVALUE;
    int _27418 = NOVALUE;
    int _27417 = NOVALUE;
    int _27416 = NOVALUE;
    int _27415 = NOVALUE;
    int _27414 = NOVALUE;
    int _27413 = NOVALUE;
    int _27411 = NOVALUE;
    int _27410 = NOVALUE;
    int _27409 = NOVALUE;
    int _27407 = NOVALUE;
    int _27405 = NOVALUE;
    int _27404 = NOVALUE;
    int _27403 = NOVALUE;
    int _27402 = NOVALUE;
    int _27401 = NOVALUE;
    int _27400 = NOVALUE;
    int _27399 = NOVALUE;
    int _27396 = NOVALUE;
    int _27395 = NOVALUE;
    int _27393 = NOVALUE;
    int _27392 = NOVALUE;
    int _27390 = NOVALUE;
    int _27389 = NOVALUE;
    int _27387 = NOVALUE;
    int _27386 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53180)) {
        _1 = (long)(DBL_PTR(_sub_53180)->dbl);
        DeRefDS(_sub_53180);
        _sub_53180 = _1;
    }
    if (!IS_ATOM_INT(_start_53181)) {
        _1 = (long)(DBL_PTR(_start_53181)->dbl);
        DeRefDS(_start_53181);
        _start_53181 = _1;
    }
    if (!IS_ATOM_INT(_deferred_53182)) {
        _1 = (long)(DBL_PTR(_deferred_53182)->dbl);
        DeRefDS(_deferred_53182);
        _deferred_53182 = _1;
    }

    /** 	integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27386 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27386);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _27387 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _27387 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _27386 = NOVALUE;
    if (IS_ATOM_INT(_27387)) {
        _is_proc_53183 = (_27387 == 27);
    }
    else {
        _is_proc_53183 = binary_op(EQUALS, _27387, 27);
    }
    _27387 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_53183)) {
        _1 = (long)(DBL_PTR(_is_proc_53183)->dbl);
        DeRefDS(_is_proc_53183);
        _is_proc_53183 = _1;
    }

    /** 	clear_inline_targets()*/
    _37clear_inline_targets();

    /** 	inline_temps = {}*/
    RefDS(_21829);
    DeRef(_66inline_temps_52235);
    _66inline_temps_52235 = _21829;

    /** 	inline_params = {}*/
    RefDS(_21829);
    DeRefi(_66inline_params_52238);
    _66inline_params_52238 = _21829;

    /** 	assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27389 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27389);
    _27390 = (int)*(((s1_ptr)_2)->base + 29);
    _27389 = NOVALUE;
    DeRef(_66assigned_params_52239);
    _2 = (int)SEQ_PTR(_27390);
    _66assigned_params_52239 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_66assigned_params_52239);
    _27390 = NOVALUE;

    /** 	inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27392 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27392);
    _27393 = (int)*(((s1_ptr)_2)->base + 29);
    _27392 = NOVALUE;
    DeRef(_66inline_code_52233);
    _2 = (int)SEQ_PTR(_27393);
    _66inline_code_52233 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_66inline_code_52233);
    _27393 = NOVALUE;

    /** 	sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27395 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27395);
    _27396 = (int)*(((s1_ptr)_2)->base + 29);
    _27395 = NOVALUE;
    DeRef(_backpatches_53201);
    _2 = (int)SEQ_PTR(_27396);
    _backpatches_53201 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_53201);
    _27396 = NOVALUE;

    /** 	passed_params = {}*/
    RefDS(_21829);
    DeRef(_66passed_params_52236);
    _66passed_params_52236 = _21829;

    /** 	original_params = {}*/
    RefDS(_21829);
    DeRef(_66original_params_52237);
    _66original_params_52237 = _21829;

    /** 	proc_vars = {}*/
    RefDS(_21829);
    DeRefi(_66proc_vars_52234);
    _66proc_vars_52234 = _21829;

    /** 	sequence prolog = {}*/
    RefDS(_21829);
    DeRefi(_prolog_53207);
    _prolog_53207 = _21829;

    /** 	sequence epilog = {}*/
    RefDS(_21829);
    DeRef(_epilog_53208);
    _epilog_53208 = _21829;

    /** 	Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27399 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27399);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27400 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27400 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27399 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27401 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_27401);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _27402 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _27402 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _27401 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27400);
    *((int *)(_2+4)) = _27400;
    Ref(_27402);
    *((int *)(_2+8)) = _27402;
    *((int *)(_2+12)) = _start_53181;
    _27403 = MAKE_SEQ(_1);
    _27402 = NOVALUE;
    _27400 = NOVALUE;
    _27404 = EPrintf(-9999999, _27398, _27403);
    DeRefDS(_27403);
    _27403 = NOVALUE;
    _65Start_block(206, _27404);
    _27404 = NOVALUE;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27405 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27405);
    _s_53224 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53224)){
        _s_53224 = (long)DBL_PTR(_s_53224)->dbl;
    }
    _27405 = NOVALUE;

    /** 	varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27407 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_27407);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _66varnum_52244 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _66varnum_52244 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_66varnum_52244)){
        _66varnum_52244 = (long)DBL_PTR(_66varnum_52244)->dbl;
    }
    _27407 = NOVALUE;

    /** 	inline_start = start*/
    _66inline_start_52245 = _start_53181;

    /** 	last_param = CurrentSub*/
    _66last_param_52248 = _12CurrentSub_11690;

    /** 	for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27409 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_27409);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _27410 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _27410 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _27409 = NOVALUE;
    {
        int _p_53236;
        _p_53236 = 1;
L1: 
        if (binary_op_a(GREATER, _p_53236, _27410)){
            goto L2; // [250] 282
        }

        /** 		last_param = SymTab[last_param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27411 = (int)*(((s1_ptr)_2)->base + _66last_param_52248);
        _2 = (int)SEQ_PTR(_27411);
        _66last_param_52248 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_66last_param_52248)){
            _66last_param_52248 = (long)DBL_PTR(_66last_param_52248)->dbl;
        }
        _27411 = NOVALUE;

        /** 	end for*/
        _0 = _p_53236;
        if (IS_ATOM_INT(_p_53236)) {
            _p_53236 = _p_53236 + 1;
            if ((long)((unsigned long)_p_53236 +(unsigned long) HIGH_BITS) >= 0){
                _p_53236 = NewDouble((double)_p_53236);
            }
        }
        else {
            _p_53236 = binary_op_a(PLUS, _p_53236, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_53236);
    }

    /** 	symtab_index last_sym = last_param*/
    _last_sym_53247 = _66last_param_52248;

    /** 	while last_sym and */
L3: 
    if (_last_sym_53247 == 0) {
        goto L4; // [296] 368
    }
    _27414 = _52sym_scope(_last_sym_53247);
    if (IS_ATOM_INT(_27414)) {
        _27415 = (_27414 <= 3);
    }
    else {
        _27415 = binary_op(LESSEQ, _27414, 3);
    }
    DeRef(_27414);
    _27414 = NOVALUE;
    if (IS_ATOM_INT(_27415)) {
        if (_27415 != 0) {
            DeRef(_27416);
            _27416 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27415)->dbl != 0.0) {
            DeRef(_27416);
            _27416 = 1;
            goto L5; // [310] 328
        }
    }
    _27417 = _52sym_scope(_last_sym_53247);
    if (IS_ATOM_INT(_27417)) {
        _27418 = (_27417 == 9);
    }
    else {
        _27418 = binary_op(EQUALS, _27417, 9);
    }
    DeRef(_27417);
    _27417 = NOVALUE;
    DeRef(_27416);
    if (IS_ATOM_INT(_27418))
    _27416 = (_27418 != 0);
    else
    _27416 = DBL_PTR(_27418)->dbl != 0.0;
L5: 
    if (_27416 == 0)
    {
        _27416 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27416 = NOVALUE;
    }

    /** 		last_param = last_sym*/
    _66last_param_52248 = _last_sym_53247;

    /** 		last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27419 = (int)*(((s1_ptr)_2)->base + _last_sym_53247);
    _2 = (int)SEQ_PTR(_27419);
    _last_sym_53247 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_53247)){
        _last_sym_53247 = (long)DBL_PTR(_last_sym_53247)->dbl;
    }
    _27419 = NOVALUE;

    /** 		varnum += 1*/
    _66varnum_52244 = _66varnum_52244 + 1;

    /** 	end while*/
    goto L3; // [365] 296
L4: 

    /** 	for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27422 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27422);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _27423 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _27423 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _27422 = NOVALUE;
    {
        int _p_53265;
        Ref(_27423);
        _p_53265 = _27423;
L6: 
        if (binary_op_a(LESS, _p_53265, 1)){
            goto L7; // [382] 407
        }

        /** 		passed_params = prepend( passed_params, Pop() )*/
        _27424 = _37Pop();
        Ref(_27424);
        Prepend(&_66passed_params_52236, _66passed_params_52236, _27424);
        DeRef(_27424);
        _27424 = NOVALUE;

        /** 	end for*/
        _0 = _p_53265;
        if (IS_ATOM_INT(_p_53265)) {
            _p_53265 = _p_53265 + -1;
            if ((long)((unsigned long)_p_53265 +(unsigned long) HIGH_BITS) >= 0){
                _p_53265 = NewDouble((double)_p_53265);
            }
        }
        else {
            _p_53265 = binary_op_a(PLUS, _p_53265, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_53265);
    }

    /** 	original_params = passed_params*/
    RefDS(_66passed_params_52236);
    DeRef(_66original_params_52237);
    _66original_params_52237 = _66passed_params_52236;

    /** 	symtab_index int_sym = 0*/
    _int_sym_53274 = 0;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27426 = (int)*(((s1_ptr)_2)->base + _sub_53180);
    _2 = (int)SEQ_PTR(_27426);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _27427 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _27427 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _27426 = NOVALUE;
    {
        int _p_53276;
        _p_53276 = 1;
L8: 
        if (binary_op_a(GREATER, _p_53276, _27427)){
            goto L9; // [437] 575
        }

        /** 		symtab_index param = passed_params[p]*/
        _2 = (int)SEQ_PTR(_66passed_params_52236);
        if (!IS_ATOM_INT(_p_53276)){
            _param_53282 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53276)->dbl));
        }
        else{
            _param_53282 = (int)*(((s1_ptr)_2)->base + _p_53276);
        }
        if (!IS_ATOM_INT(_param_53282)){
            _param_53282 = (long)DBL_PTR(_param_53282)->dbl;
        }

        /** 		inline_params &= s*/
        Append(&_66inline_params_52238, _66inline_params_52238, _s_53224);

        /** 		integer ax = find( p, assigned_params )*/
        _ax_53285 = find_from(_p_53276, _66assigned_params_52239, 1);

        /** 		if ax or is_temp( param ) then*/
        if (_ax_53285 != 0) {
            goto LA; // [473] 486
        }
        _27432 = _66is_temp(_param_53282);
        if (_27432 == 0) {
            DeRef(_27432);
            _27432 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27432) && DBL_PTR(_27432)->dbl == 0.0){
                DeRef(_27432);
                _27432 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27432);
            _27432 = NOVALUE;
        }
        DeRef(_27432);
        _27432 = NOVALUE;
LA: 

        /** 			varnum += 1*/
        _66varnum_52244 = _66varnum_52244 + 1;

        /** 			symtab_index var = new_inline_var( s, 0 )*/
        _var_53292 = _66new_inline_var(_s_53224, 0);
        if (!IS_ATOM_INT(_var_53292)) {
            _1 = (long)(DBL_PTR(_var_53292)->dbl);
            DeRefDS(_var_53292);
            _var_53292 = _1;
        }

        /** 			prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 18;
        *((int *)(_2+8)) = _param_53282;
        *((int *)(_2+12)) = _var_53292;
        _27435 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_53207, _prolog_53207, _27435);
        DeRefDS(_27435);
        _27435 = NOVALUE;

        /** 			if not int_sym then*/
        if (_int_sym_53274 != 0)
        goto LC; // [519] 531

        /** 				int_sym = NewIntSym( 0 )*/
        _int_sym_53274 = _52NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_53274)) {
            _1 = (long)(DBL_PTR(_int_sym_53274)->dbl);
            DeRefDS(_int_sym_53274);
            _int_sym_53274 = _1;
        }
LC: 

        /** 			inline_start += 3*/
        _66inline_start_52245 = _66inline_start_52245 + 3;

        /** 			passed_params[p] = var*/
        _2 = (int)SEQ_PTR(_66passed_params_52236);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66passed_params_52236 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_53276))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53276)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _p_53276);
        _1 = *(int *)_2;
        *(int *)_2 = _var_53292;
        DeRef(_1);
LB: 

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27440 = (int)*(((s1_ptr)_2)->base + _s_53224);
        _2 = (int)SEQ_PTR(_27440);
        _s_53224 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53224)){
            _s_53224 = (long)DBL_PTR(_s_53224)->dbl;
        }
        _27440 = NOVALUE;

        /** 	end for*/
        _0 = _p_53276;
        if (IS_ATOM_INT(_p_53276)) {
            _p_53276 = _p_53276 + 1;
            if ((long)((unsigned long)_p_53276 +(unsigned long) HIGH_BITS) >= 0){
                _p_53276 = NewDouble((double)_p_53276);
            }
        }
        else {
            _p_53276 = binary_op_a(PLUS, _p_53276, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_53276);
    }

    /** 	symtab_index final_target = 0*/
    _final_target_53307 = 0;

    /** 	while s and */
LD: 
    if (_s_53224 == 0) {
        goto LE; // [587] 699
    }
    _27443 = _52sym_scope(_s_53224);
    if (IS_ATOM_INT(_27443)) {
        _27444 = (_27443 <= 3);
    }
    else {
        _27444 = binary_op(LESSEQ, _27443, 3);
    }
    DeRef(_27443);
    _27443 = NOVALUE;
    if (IS_ATOM_INT(_27444)) {
        if (_27444 != 0) {
            DeRef(_27445);
            _27445 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27444)->dbl != 0.0) {
            DeRef(_27445);
            _27445 = 1;
            goto LF; // [601] 619
        }
    }
    _27446 = _52sym_scope(_s_53224);
    if (IS_ATOM_INT(_27446)) {
        _27447 = (_27446 == 9);
    }
    else {
        _27447 = binary_op(EQUALS, _27446, 9);
    }
    DeRef(_27446);
    _27446 = NOVALUE;
    DeRef(_27445);
    if (IS_ATOM_INT(_27447))
    _27445 = (_27447 != 0);
    else
    _27445 = DBL_PTR(_27447)->dbl != 0.0;
LF: 
    if (_27445 == 0)
    {
        _27445 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27445 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27448 = _52sym_scope(_s_53224);
    if (binary_op_a(EQUALS, _27448, 9)){
        DeRef(_27448);
        _27448 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27448);
    _27448 = NOVALUE;

    /** 			varnum += 1*/
    _66varnum_52244 = _66varnum_52244 + 1;

    /** 			symtab_index var = new_inline_var( s, 0 )*/
    _var_53326 = _66new_inline_var(_s_53224, 0);
    if (!IS_ATOM_INT(_var_53326)) {
        _1 = (long)(DBL_PTR(_var_53326)->dbl);
        DeRefDS(_var_53326);
        _var_53326 = _1;
    }

    /** 			proc_vars &= var*/
    Append(&_66proc_vars_52234, _66proc_vars_52234, _var_53326);

    /** 			if int_sym = 0 then*/
    if (_int_sym_53274 != 0)
    goto L11; // [662] 675

    /** 				int_sym = NewIntSym( 0 )*/
    _int_sym_53274 = _52NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_53274)) {
        _1 = (long)(DBL_PTR(_int_sym_53274)->dbl);
        DeRefDS(_int_sym_53274);
        _int_sym_53274 = _1;
    }
L11: 
L10: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27455 = (int)*(((s1_ptr)_2)->base + _s_53224);
    _2 = (int)SEQ_PTR(_27455);
    _s_53224 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53224)){
        _s_53224 = (long)DBL_PTR(_s_53224)->dbl;
    }
    _27455 = NOVALUE;

    /** 	end while*/
    goto LD; // [696] 587
LE: 

    /** 	if not is_proc then*/
    if (_is_proc_53183 != 0)
    goto L12; // [701] 831

    /** 		integer create_target_var = 1*/
    _create_target_var_53339 = 1;

    /** 		if deferred then*/
    if (_deferred_53182 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** 			inline_target = Pop()*/
    _0 = _37Pop();
    _66inline_target_52240 = _0;
    if (!IS_ATOM_INT(_66inline_target_52240)) {
        _1 = (long)(DBL_PTR(_66inline_target_52240)->dbl);
        DeRefDS(_66inline_target_52240);
        _66inline_target_52240 = _1;
    }

    /** 			if is_temp( inline_target ) then*/
    _27459 = _66is_temp(_66inline_target_52240);
    if (_27459 == 0) {
        DeRef(_27459);
        _27459 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27459) && DBL_PTR(_27459)->dbl == 0.0){
            DeRef(_27459);
            _27459 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27459);
        _27459 = NOVALUE;
    }
    DeRef(_27459);
    _27459 = NOVALUE;

    /** 				final_target = inline_target*/
    _final_target_53307 = _66inline_target_52240;
    goto L15; // [741] 750
L14: 

    /** 				create_target_var = 0*/
    _create_target_var_53339 = 0;
L15: 
L13: 

    /** 		if create_target_var then*/
    if (_create_target_var_53339 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** 			varnum += 1*/
    _66varnum_52244 = _66varnum_52244 + 1;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** 				inline_target = new_inline_var( sub, 0 )*/
    _0 = _66new_inline_var(_sub_53180, 0);
    _66inline_target_52240 = _0;
    if (!IS_ATOM_INT(_66inline_target_52240)) {
        _1 = (long)(DBL_PTR(_66inline_target_52240)->dbl);
        DeRefDS(_66inline_target_52240);
        _66inline_target_52240 = _1;
    }

    /** 				SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66inline_target_52240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_45731;
    DeRef(_1);
    _27462 = NOVALUE;

    /** 				Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** 				inline_target = NewTempSym()*/
    _0 = _52NewTempSym(0);
    _66inline_target_52240 = _0;
    if (!IS_ATOM_INT(_66inline_target_52240)) {
        _1 = (long)(DBL_PTR(_66inline_target_52240)->dbl);
        DeRefDS(_66inline_target_52240);
        _66inline_target_52240 = _1;
    }
L18: 
L16: 

    /** 		proc_vars &= inline_target*/
    Append(&_66proc_vars_52234, _66proc_vars_52234, _66inline_target_52240);
    goto L19; // [828] 837
L12: 

    /** 		inline_target = 0*/
    _66inline_target_52240 = 0;
L19: 

    /** 	integer check_pc = 1*/
    _check_pc_53362 = 1;

    /** 	while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27466 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27466 = 1;
    }
    if (_27466 <= _check_pc_53362)
    goto L1B; // [852] 1216

    /** 		integer op = inline_code[check_pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52233);
    _op_53366 = (int)*(((s1_ptr)_2)->base + _check_pc_53362);
    if (!IS_ATOM_INT(_op_53366))
    _op_53366 = (long)DBL_PTR(_op_53366)->dbl;

    /** 		switch op with fallthru do*/
    _0 = _op_53366;
    switch ( _0 ){ 

        /** 			case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** 				symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27471 = _check_pc_53362 + 1;
        if (_27471 > MAXINT){
            _27471 = NewDouble((double)_27471);
        }
        _sym_53375 = _66get_original_sym(_27471);
        _27471 = NOVALUE;
        if (!IS_ATOM_INT(_sym_53375)) {
            _1 = (long)(DBL_PTR(_sym_53375)->dbl);
            DeRefDS(_sym_53375);
            _sym_53375 = _1;
        }

        /** 				if is_literal( sym ) then*/
        _27473 = _66is_literal(_sym_53375);
        if (_27473 == 0) {
            DeRef(_27473);
            _27473 = NOVALUE;
            goto L1C; // [897] 1010
        }
        else {
            if (!IS_ATOM_INT(_27473) && DBL_PTR(_27473)->dbl == 0.0){
                DeRef(_27473);
                _27473 = NOVALUE;
                goto L1C; // [897] 1010
            }
            DeRef(_27473);
            _27473 = NOVALUE;
        }
        DeRef(_27473);
        _27473 = NOVALUE;

        /** 					integer check_result*/

        /** 					if op = INTEGER_CHECK then*/
        if (_op_53366 != 96)
        goto L1D; // [906] 930

        /** 						check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27475 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27475);
        _27476 = (int)*(((s1_ptr)_2)->base + 1);
        _27475 = NOVALUE;
        if (IS_ATOM_INT(_27476))
        _check_result_53380 = 1;
        else if (IS_ATOM_DBL(_27476))
        _check_result_53380 = IS_ATOM_INT(DoubleToInt(_27476));
        else
        _check_result_53380 = 0;
        _27476 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** 					elsif op = SEQUENCE_CHECK then*/
        if (_op_53366 != 97)
        goto L1F; // [934] 958

        /** 						check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27479 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27479);
        _27480 = (int)*(((s1_ptr)_2)->base + 1);
        _27479 = NOVALUE;
        _check_result_53380 = IS_SEQUENCE(_27480);
        _27480 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** 						check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27482 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27482);
        _27483 = (int)*(((s1_ptr)_2)->base + 1);
        _27482 = NOVALUE;
        _check_result_53380 = IS_ATOM(_27483);
        _27483 = NOVALUE;
L1E: 

        /** 					if check_result then*/
        if (_check_result_53380 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27485 = _check_pc_53362 + 1;
        if (_27485 > MAXINT){
            _27485 = NewDouble((double)_27485);
        }
        RefDS(_21829);
        _66replace_code(_21829, _check_pc_53362, _27485);
        _27485 = NOVALUE;
        goto L21; // [994] 1005
L20: 

        /** 						CompileErr(146)*/
        RefDS(_21829);
        _43CompileErr(146, _21829, 0);
L21: 
        goto L22; // [1007] 1172
L1C: 

        /** 				elsif not is_temp( sym ) then*/
        _27486 = _66is_temp(_sym_53375);
        if (IS_ATOM_INT(_27486)) {
            if (_27486 != 0){
                DeRef(_27486);
                _27486 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        else {
            if (DBL_PTR(_27486)->dbl != 0.0){
                DeRef(_27486);
                _27486 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        DeRef(_27486);
        _27486 = NOVALUE;

        /** 					if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27488 = (_op_53366 == 96);
        if (_27488 == 0) {
            _27489 = 0;
            goto L24; // [1027] 1053
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27490 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27490);
        _27491 = (int)*(((s1_ptr)_2)->base + 15);
        _27490 = NOVALUE;
        if (IS_ATOM_INT(_27491)) {
            _27492 = (_27491 == _52integer_type_45737);
        }
        else {
            _27492 = binary_op(EQUALS, _27491, _52integer_type_45737);
        }
        _27491 = NOVALUE;
        if (IS_ATOM_INT(_27492))
        _27489 = (_27492 != 0);
        else
        _27489 = DBL_PTR(_27492)->dbl != 0.0;
L24: 
        if (_27489 != 0) {
            _27493 = 1;
            goto L25; // [1053] 1093
        }
        _27494 = (_op_53366 == 97);
        if (_27494 == 0) {
            _27495 = 0;
            goto L26; // [1063] 1089
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27496 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27496);
        _27497 = (int)*(((s1_ptr)_2)->base + 15);
        _27496 = NOVALUE;
        if (IS_ATOM_INT(_27497)) {
            _27498 = (_27497 == _52sequence_type_45735);
        }
        else {
            _27498 = binary_op(EQUALS, _27497, _52sequence_type_45735);
        }
        _27497 = NOVALUE;
        if (IS_ATOM_INT(_27498))
        _27495 = (_27498 != 0);
        else
        _27495 = DBL_PTR(_27498)->dbl != 0.0;
L26: 
        _27493 = (_27495 != 0);
L25: 
        if (_27493 != 0) {
            goto L27; // [1093] 1141
        }
        _27500 = (_op_53366 == 101);
        if (_27500 == 0) {
            DeRef(_27501);
            _27501 = 0;
            goto L28; // [1103] 1136
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27502 = (int)*(((s1_ptr)_2)->base + _sym_53375);
        _2 = (int)SEQ_PTR(_27502);
        _27503 = (int)*(((s1_ptr)_2)->base + 15);
        _27502 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _52integer_type_45737;
        ((int *)_2)[2] = _52atom_type_45733;
        _27504 = MAKE_SEQ(_1);
        _27505 = find_from(_27503, _27504, 1);
        _27503 = NOVALUE;
        DeRefDS(_27504);
        _27504 = NOVALUE;
        _27501 = (_27505 != 0);
L28: 
        if (_27501 == 0)
        {
            _27501 = NOVALUE;
            goto L29; // [1137] 1155
        }
        else{
            _27501 = NOVALUE;
        }
L27: 

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27506 = _check_pc_53362 + 1;
        if (_27506 > MAXINT){
            _27506 = NewDouble((double)_27506);
        }
        RefDS(_21829);
        _66replace_code(_21829, _check_pc_53362, _27506);
        _27506 = NOVALUE;
        goto L22; // [1152] 1172
L29: 

        /** 						check_pc += 2*/
        _check_pc_53362 = _check_pc_53362 + 2;
        goto L22; // [1162] 1172
L23: 

        /** 					check_pc += 2*/
        _check_pc_53362 = _check_pc_53362 + 2;
L22: 

        /** 				continue*/
        goto L1A; // [1178] 847

        /** 			case STARTLINE then*/
        case 58:

        /** 				check_pc += 2*/
        _check_pc_53362 = _check_pc_53362 + 2;

        /** 				continue*/
        goto L1A; // [1196] 847

        /** 			case else*/
        default:

        /** 				exit*/
        goto L1B; // [1206] 1216
    ;}
    /** 	end while*/
    goto L1A; // [1213] 847
L1B: 

    /** 	for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27510 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27510 = 1;
    }
    {
        int _pc_53452;
        _pc_53452 = 1;
L2A: 
        if (_pc_53452 > _27510){
            goto L2B; // [1223] 1420
        }

        /** 		if sequence( inline_code[pc] ) then*/
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27511 = (int)*(((s1_ptr)_2)->base + _pc_53452);
        _27512 = IS_SEQUENCE(_27511);
        _27511 = NOVALUE;
        if (_27512 == 0)
        {
            _27512 = NOVALUE;
            goto L2C; // [1241] 1411
        }
        else{
            _27512 = NOVALUE;
        }

        /** 			integer inline_type = inline_code[pc][1]*/
        _2 = (int)SEQ_PTR(_66inline_code_52233);
        _27513 = (int)*(((s1_ptr)_2)->base + _pc_53452);
        _2 = (int)SEQ_PTR(_27513);
        _inline_type_53457 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_53457)){
            _inline_type_53457 = (long)DBL_PTR(_inline_type_53457)->dbl;
        }
        _27513 = NOVALUE;

        /** 			switch inline_type do*/
        _0 = _inline_type_53457;
        switch ( _0 ){ 

            /** 				case INLINE_SUB then*/
            case 5:

            /** 					inline_code[pc] = CurrentSub*/
            _2 = (int)SEQ_PTR(_66inline_code_52233);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52233 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53452);
            _1 = *(int *)_2;
            *(int *)_2 = _12CurrentSub_11690;
            DeRef(_1);
            goto L2D; // [1279] 1410

            /** 				case INLINE_VAR then*/
            case 6:

            /** 					replace_var( pc )*/
            _66replace_var(_pc_53452);

            /** 					break*/
            goto L2D; // [1292] 1410
            goto L2D; // [1294] 1410

            /** 				case INLINE_TEMP then*/
            case 2:

            /** 					replace_temp( pc )*/
            _66replace_temp(_pc_53452);
            goto L2D; // [1305] 1410

            /** 				case INLINE_PARAM then*/
            case 1:

            /** 					replace_param( pc )*/

            /** 	inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1341_53468;
            _replace_param_1__tmp_at1341_53468 = _66get_param_sym(_pc_53452);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1341_53468);
            _2 = (int)SEQ_PTR(_66inline_code_52233);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52233 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53452);
            _1 = *(int *)_2;
            *(int *)_2 = _replace_param_1__tmp_at1341_53468;
            DeRef(_1);

            /** end procedure*/
            goto L2E; // [1327] 1330
L2E: 
            DeRef(_replace_param_1__tmp_at1341_53468);
            _replace_param_1__tmp_at1341_53468 = NOVALUE;
            goto L2D; // [1332] 1410

            /** 				case INLINE_ADDR then*/
            case 4:

            /** 					inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (int)SEQ_PTR(_66inline_code_52233);
            _27517 = (int)*(((s1_ptr)_2)->base + _pc_53452);
            _2 = (int)SEQ_PTR(_27517);
            _27518 = (int)*(((s1_ptr)_2)->base + 2);
            _27517 = NOVALUE;
            if (IS_ATOM_INT(_27518)) {
                _27519 = _66inline_start_52245 + _27518;
                if ((long)((unsigned long)_27519 + (unsigned long)HIGH_BITS) >= 0) 
                _27519 = NewDouble((double)_27519);
            }
            else {
                _27519 = binary_op(PLUS, _66inline_start_52245, _27518);
            }
            _27518 = NOVALUE;
            _2 = (int)SEQ_PTR(_66inline_code_52233);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52233 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53452);
            _1 = *(int *)_2;
            *(int *)_2 = _27519;
            if( _1 != _27519 ){
                DeRef(_1);
            }
            _27519 = NOVALUE;
            goto L2D; // [1362] 1410

            /** 				case INLINE_TARGET then*/
            case 3:

            /** 					inline_code[pc] = inline_target*/
            _2 = (int)SEQ_PTR(_66inline_code_52233);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52233 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53452);
            _1 = *(int *)_2;
            *(int *)_2 = _66inline_target_52240;
            DeRef(_1);

            /** 					add_inline_target( pc + inline_start )*/
            _27520 = _pc_53452 + _66inline_start_52245;
            if ((long)((unsigned long)_27520 + (unsigned long)HIGH_BITS) >= 0) 
            _27520 = NewDouble((double)_27520);
            _37add_inline_target(_27520);
            _27520 = NOVALUE;

            /** 					break*/
            goto L2D; // [1391] 1410
            goto L2D; // [1393] 1410

            /** 				case else*/
            default:

            /** 					InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _inline_type_53457;
            _27521 = MAKE_SEQ(_1);
            _43InternalErr(265, _27521);
            _27521 = NOVALUE;
        ;}L2D: 
L2C: 

        /** 	end for*/
        _pc_53452 = _pc_53452 + 1;
        goto L2A; // [1415] 1230
L2B: 
        ;
    }

    /** 	for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_53201)){
            _27522 = SEQ_PTR(_backpatches_53201)->length;
    }
    else {
        _27522 = 1;
    }
    {
        int _i_53480;
        _i_53480 = 1;
L2F: 
        if (_i_53480 > _27522){
            goto L30; // [1425] 1448
        }

        /** 		fixup_special_op( backpatches[i] )*/
        _2 = (int)SEQ_PTR(_backpatches_53201);
        _27523 = (int)*(((s1_ptr)_2)->base + _i_53480);
        Ref(_27523);
        _66fixup_special_op(_27523);
        _27523 = NOVALUE;

        /** 	end for*/
        _i_53480 = _i_53480 + 1;
        goto L2F; // [1443] 1432
L30: 
        ;
    }

    /** 	epilog &= End_inline_block( EXIT_BLOCK )*/
    _27524 = _65End_inline_block(206);
    if (IS_SEQUENCE(_epilog_53208) && IS_ATOM(_27524)) {
        Ref(_27524);
        Append(&_epilog_53208, _epilog_53208, _27524);
    }
    else if (IS_ATOM(_epilog_53208) && IS_SEQUENCE(_27524)) {
    }
    else {
        Concat((object_ptr)&_epilog_53208, _epilog_53208, _27524);
    }
    DeRef(_27524);
    _27524 = NOVALUE;

    /** 	if is_proc then*/
    if (_is_proc_53183 == 0)
    {
        goto L31; // [1462] 1472
    }
    else{
    }

    /** 		clear_op()*/
    _37clear_op();
    goto L32; // [1469] 1595
L31: 

    /** 		if not deferred then*/
    if (_deferred_53182 != 0)
    goto L33; // [1474] 1489

    /** 			Push( inline_target )*/
    _37Push(_66inline_target_52240);

    /** 			inlined_function()*/
    _37inlined_function();
L33: 

    /** 		if final_target then*/
    if (_final_target_53307 == 0)
    {
        goto L34; // [1491] 1521
    }
    else{
    }

    /** 			epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _66inline_target_52240;
    *((int *)(_2+12)) = _final_target_53307;
    _27527 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53208, _epilog_53208, _27527);
    DeRefDS(_27527);
    _27527 = NOVALUE;

    /** 			emit_temp( final_target, NEW_REFERENCE )*/
    _37emit_temp(_final_target_53307, 1);
    goto L35; // [1518] 1594
L34: 

    /** 			emit_temp( inline_target, NEW_REFERENCE )*/
    _37emit_temp(_66inline_target_52240, 1);

    /** 			if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L36; // [1535] 1593

    /** 				epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 23;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 30;
    *((int *)(_2+16)) = _66inline_target_52240;
    _27530 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53208, _epilog_53208, _27530);
    DeRefDS(_27530);
    _27530 = NOVALUE;

    /** 				epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_53208)){
            _27532 = SEQ_PTR(_epilog_53208)->length;
    }
    else {
        _27532 = 1;
    }
    _27533 = _27532 - 2;
    _27532 = NOVALUE;
    if (IS_SEQUENCE(_66inline_code_52233)){
            _27534 = SEQ_PTR(_66inline_code_52233)->length;
    }
    else {
        _27534 = 1;
    }
    if (IS_SEQUENCE(_epilog_53208)){
            _27535 = SEQ_PTR(_epilog_53208)->length;
    }
    else {
        _27535 = 1;
    }
    _27536 = _27534 + _27535;
    if ((long)((unsigned long)_27536 + (unsigned long)HIGH_BITS) >= 0) 
    _27536 = NewDouble((double)_27536);
    _27534 = NOVALUE;
    _27535 = NOVALUE;
    if (IS_ATOM_INT(_27536)) {
        _27537 = _27536 + _66inline_start_52245;
        if ((long)((unsigned long)_27537 + (unsigned long)HIGH_BITS) >= 0) 
        _27537 = NewDouble((double)_27537);
    }
    else {
        _27537 = NewDouble(DBL_PTR(_27536)->dbl + (double)_66inline_start_52245);
    }
    DeRef(_27536);
    _27536 = NOVALUE;
    if (IS_ATOM_INT(_27537)) {
        _27538 = _27537 + 1;
        if (_27538 > MAXINT){
            _27538 = NewDouble((double)_27538);
        }
    }
    else
    _27538 = binary_op(PLUS, 1, _27537);
    DeRef(_27537);
    _27537 = NOVALUE;
    _2 = (int)SEQ_PTR(_epilog_53208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _epilog_53208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27533);
    _1 = *(int *)_2;
    *(int *)_2 = _27538;
    if( _1 != _27538 ){
        DeRef(_1);
    }
    _27538 = NOVALUE;
L36: 
L35: 
L32: 

    /** 	return prolog & inline_code & epilog*/
    {
        int concat_list[3];

        concat_list[0] = _epilog_53208;
        concat_list[1] = _66inline_code_52233;
        concat_list[2] = _prolog_53207;
        Concat_N((object_ptr)&_27539, concat_list, 3);
    }
    DeRef(_backpatches_53201);
    DeRefDSi(_prolog_53207);
    DeRefDS(_epilog_53208);
    _27410 = NOVALUE;
    _27423 = NOVALUE;
    DeRef(_27415);
    _27415 = NOVALUE;
    DeRef(_27418);
    _27418 = NOVALUE;
    _27427 = NOVALUE;
    DeRef(_27488);
    _27488 = NOVALUE;
    DeRef(_27444);
    _27444 = NOVALUE;
    DeRef(_27447);
    _27447 = NOVALUE;
    DeRef(_27494);
    _27494 = NOVALUE;
    DeRef(_27492);
    _27492 = NOVALUE;
    DeRef(_27500);
    _27500 = NOVALUE;
    DeRef(_27498);
    _27498 = NOVALUE;
    DeRef(_27533);
    _27533 = NOVALUE;
    return _27539;
    ;
}


void _66defer_call()
{
    int _defer_53520 = NOVALUE;
    int _27542 = NOVALUE;
    int _27541 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_53520 = find_from(_66inline_sub_52247, _66deferred_inline_decisions_52249, 1);

    /** 	if defer then*/
    if (_defer_53520 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_66deferred_inline_calls_52250);
    _27541 = (int)*(((s1_ptr)_2)->base + _defer_53520);
    if (IS_SEQUENCE(_27541) && IS_ATOM(_12CurrentSub_11690)) {
        Append(&_27542, _27541, _12CurrentSub_11690);
    }
    else if (IS_ATOM(_27541) && IS_SEQUENCE(_12CurrentSub_11690)) {
    }
    else {
        Concat((object_ptr)&_27542, _27541, _12CurrentSub_11690);
        _27541 = NOVALUE;
    }
    _27541 = NOVALUE;
    _2 = (int)SEQ_PTR(_66deferred_inline_calls_52250);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66deferred_inline_calls_52250 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _defer_53520);
    _1 = *(int *)_2;
    *(int *)_2 = _27542;
    if( _1 != _27542 ){
        DeRef(_1);
    }
    _27542 = NOVALUE;
L1: 

    /** end procedure*/
    return;
    ;
}


void _66emit_or_inline()
{
    int _sub_53529 = NOVALUE;
    int _code_53548 = NOVALUE;
    int _27549 = NOVALUE;
    int _27548 = NOVALUE;
    int _27546 = NOVALUE;
    int _27545 = NOVALUE;
    int _27544 = NOVALUE;
    int _0, _1, _2;
    

    /** 	symtab_index sub = op_info1*/
    _sub_53529 = _37op_info1_49791;

    /** 	inline_sub = sub*/
    _66inline_sub_52247 = _sub_53529;

    /** 	if Parser_mode != PAM_NORMAL then*/
    if (_12Parser_mode_11788 == 0)
    goto L1; // [23] 42

    /** 		emit_op( PROC )*/
    _37emit_op(27);

    /** 		return*/
    DeRef(_code_53548);
    return;
    goto L2; // [39] 90
L1: 

    /** 	elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27544 = (int)*(((s1_ptr)_2)->base + _sub_53529);
    _2 = (int)SEQ_PTR(_27544);
    _27545 = (int)*(((s1_ptr)_2)->base + 29);
    _27544 = NOVALUE;
    _27546 = IS_ATOM(_27545);
    _27545 = NOVALUE;
    if (_27546 != 0) {
        goto L3; // [59] 72
    }
    _27548 = _37has_forward_params(_sub_53529);
    if (_27548 == 0) {
        DeRef(_27548);
        _27548 = NOVALUE;
        goto L4; // [68] 89
    }
    else {
        if (!IS_ATOM_INT(_27548) && DBL_PTR(_27548)->dbl == 0.0){
            DeRef(_27548);
            _27548 = NOVALUE;
            goto L4; // [68] 89
        }
        DeRef(_27548);
        _27548 = NOVALUE;
    }
    DeRef(_27548);
    _27548 = NOVALUE;
L3: 

    /** 		defer_call()*/
    _66defer_call();

    /** 		emit_op( PROC )*/
    _37emit_op(27);

    /** 		return*/
    DeRef(_code_53548);
    return;
L4: 
L2: 

    /** 	sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_12Code_11771)){
            _27549 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _27549 = 1;
    }
    _0 = _code_53548;
    _code_53548 = _66get_inlined_code(_sub_53529, _27549, 0);
    DeRef(_0);
    _27549 = NOVALUE;

    /** 	emit_inline( code )*/
    RefDS(_code_53548);
    _37emit_inline(_code_53548);

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    DeRefDS(_code_53548);
    return;
    ;
}


void _66inline_deferred_calls()
{
    int _sub_53562 = NOVALUE;
    int _ix_53574 = NOVALUE;
    int _calling_sub_53576 = NOVALUE;
    int _code_53590 = NOVALUE;
    int _calls_53591 = NOVALUE;
    int _is_func_53595 = NOVALUE;
    int _offset_53602 = NOVALUE;
    int _op_53613 = NOVALUE;
    int _size_53616 = NOVALUE;
    int _27607 = NOVALUE;
    int _27605 = NOVALUE;
    int _27603 = NOVALUE;
    int _27602 = NOVALUE;
    int _27601 = NOVALUE;
    int _27599 = NOVALUE;
    int _27598 = NOVALUE;
    int _27597 = NOVALUE;
    int _27596 = NOVALUE;
    int _27595 = NOVALUE;
    int _27594 = NOVALUE;
    int _27593 = NOVALUE;
    int _27592 = NOVALUE;
    int _27591 = NOVALUE;
    int _27590 = NOVALUE;
    int _27588 = NOVALUE;
    int _27587 = NOVALUE;
    int _27586 = NOVALUE;
    int _27585 = NOVALUE;
    int _27583 = NOVALUE;
    int _27582 = NOVALUE;
    int _27581 = NOVALUE;
    int _27579 = NOVALUE;
    int _27577 = NOVALUE;
    int _27575 = NOVALUE;
    int _27573 = NOVALUE;
    int _27572 = NOVALUE;
    int _27571 = NOVALUE;
    int _27570 = NOVALUE;
    int _27568 = NOVALUE;
    int _27567 = NOVALUE;
    int _27564 = NOVALUE;
    int _27562 = NOVALUE;
    int _27560 = NOVALUE;
    int _27559 = NOVALUE;
    int _27558 = NOVALUE;
    int _27557 = NOVALUE;
    int _27556 = NOVALUE;
    int _27555 = NOVALUE;
    int _27553 = NOVALUE;
    int _27552 = NOVALUE;
    int _27551 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	deferred_inlining = 1*/
    _66deferred_inlining_52243 = 1;

    /** 	for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_66deferred_inline_decisions_52249)){
            _27551 = SEQ_PTR(_66deferred_inline_decisions_52249)->length;
    }
    else {
        _27551 = 1;
    }
    {
        int _i_53557;
        _i_53557 = 1;
L1: 
        if (_i_53557 > _27551){
            goto L2; // [13] 476
        }

        /** 		if length( deferred_inline_calls[i] ) then*/
        _2 = (int)SEQ_PTR(_66deferred_inline_calls_52250);
        _27552 = (int)*(((s1_ptr)_2)->base + _i_53557);
        if (IS_SEQUENCE(_27552)){
                _27553 = SEQ_PTR(_27552)->length;
        }
        else {
            _27553 = 1;
        }
        _27552 = NOVALUE;
        if (_27553 == 0)
        {
            _27553 = NOVALUE;
            goto L3; // [31] 467
        }
        else{
            _27553 = NOVALUE;
        }

        /** 			integer sub = deferred_inline_decisions[i]*/
        _2 = (int)SEQ_PTR(_66deferred_inline_decisions_52249);
        _sub_53562 = (int)*(((s1_ptr)_2)->base + _i_53557);

        /** 			check_inline( sub )*/
        _66check_inline(_sub_53562);

        /** 			if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _27555 = (int)*(((s1_ptr)_2)->base + _sub_53562);
        _2 = (int)SEQ_PTR(_27555);
        _27556 = (int)*(((s1_ptr)_2)->base + 29);
        _27555 = NOVALUE;
        _27557 = IS_ATOM(_27556);
        _27556 = NOVALUE;
        if (_27557 == 0)
        {
            _27557 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27557 = NOVALUE;
        }

        /** 				continue*/
        goto L5; // [71] 471
L4: 

        /** 			for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (int)SEQ_PTR(_66deferred_inline_calls_52250);
        _27558 = (int)*(((s1_ptr)_2)->base + _i_53557);
        if (IS_SEQUENCE(_27558)){
                _27559 = SEQ_PTR(_27558)->length;
        }
        else {
            _27559 = 1;
        }
        _27558 = NOVALUE;
        {
            int _cx_53571;
            _cx_53571 = 1;
L6: 
            if (_cx_53571 > _27559){
                goto L7; // [85] 466
            }

            /** 				integer ix = 1*/
            _ix_53574 = 1;

            /** 				symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (int)SEQ_PTR(_66deferred_inline_calls_52250);
            _27560 = (int)*(((s1_ptr)_2)->base + _i_53557);
            _2 = (int)SEQ_PTR(_27560);
            _calling_sub_53576 = (int)*(((s1_ptr)_2)->base + _cx_53571);
            if (!IS_ATOM_INT(_calling_sub_53576)){
                _calling_sub_53576 = (long)DBL_PTR(_calling_sub_53576)->dbl;
            }
            _27560 = NOVALUE;

            /** 				CurrentSub = calling_sub*/
            _12CurrentSub_11690 = _calling_sub_53576;

            /** 				Code = SymTab[calling_sub][S_CODE]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _27562 = (int)*(((s1_ptr)_2)->base + _calling_sub_53576);
            DeRef(_12Code_11771);
            _2 = (int)SEQ_PTR(_27562);
            if (!IS_ATOM_INT(_12S_CODE_11366)){
                _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
            }
            else{
                _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
            }
            Ref(_12Code_11771);
            _27562 = NOVALUE;

            /** 				LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _27564 = (int)*(((s1_ptr)_2)->base + _calling_sub_53576);
            DeRef(_12LineTable_11772);
            _2 = (int)SEQ_PTR(_27564);
            if (!IS_ATOM_INT(_12S_LINETAB_11389)){
                _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
            }
            else{
                _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + _12S_LINETAB_11389);
            }
            Ref(_12LineTable_11772);
            _27564 = NOVALUE;

            /** 				sequence code = {}*/
            RefDS(_21829);
            DeRef(_code_53590);
            _code_53590 = _21829;

            /** 				sequence calls = find_ops( 1, PROC )*/
            RefDS(_12Code_11771);
            _0 = _calls_53591;
            _calls_53591 = _64find_ops(1, 27, _12Code_11771);
            DeRef(_0);

            /** 				integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _27567 = (int)*(((s1_ptr)_2)->base + _sub_53562);
            _2 = (int)SEQ_PTR(_27567);
            if (!IS_ATOM_INT(_12S_TOKEN_11359)){
                _27568 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
            }
            else{
                _27568 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
            }
            _27567 = NOVALUE;
            if (IS_ATOM_INT(_27568)) {
                _is_func_53595 = (_27568 != 27);
            }
            else {
                _is_func_53595 = binary_op(NOTEQ, _27568, 27);
            }
            _27568 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_53595)) {
                _1 = (long)(DBL_PTR(_is_func_53595)->dbl);
                DeRefDS(_is_func_53595);
                _is_func_53595 = _1;
            }

            /** 				integer offset = 0*/
            _offset_53602 = 0;

            /** 				for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_53591)){
                    _27570 = SEQ_PTR(_calls_53591)->length;
            }
            else {
                _27570 = 1;
            }
            {
                int _o_53604;
                _o_53604 = 1;
L8: 
                if (_o_53604 > _27570){
                    goto L9; // [203] 423
                }

                /** 					if calls[o][2][2] = sub then*/
                _2 = (int)SEQ_PTR(_calls_53591);
                _27571 = (int)*(((s1_ptr)_2)->base + _o_53604);
                _2 = (int)SEQ_PTR(_27571);
                _27572 = (int)*(((s1_ptr)_2)->base + 2);
                _27571 = NOVALUE;
                _2 = (int)SEQ_PTR(_27572);
                _27573 = (int)*(((s1_ptr)_2)->base + 2);
                _27572 = NOVALUE;
                if (binary_op_a(NOTEQ, _27573, _sub_53562)){
                    _27573 = NOVALUE;
                    goto LA; // [224] 414
                }
                _27573 = NOVALUE;

                /** 						ix = calls[o][1]*/
                _2 = (int)SEQ_PTR(_calls_53591);
                _27575 = (int)*(((s1_ptr)_2)->base + _o_53604);
                _2 = (int)SEQ_PTR(_27575);
                _ix_53574 = (int)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_53574)){
                    _ix_53574 = (long)DBL_PTR(_ix_53574)->dbl;
                }
                _27575 = NOVALUE;

                /** 						sequence op = calls[o][2]*/
                _2 = (int)SEQ_PTR(_calls_53591);
                _27577 = (int)*(((s1_ptr)_2)->base + _o_53604);
                DeRef(_op_53613);
                _2 = (int)SEQ_PTR(_27577);
                _op_53613 = (int)*(((s1_ptr)_2)->base + 2);
                Ref(_op_53613);
                _27577 = NOVALUE;

                /** 						integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_53613)){
                        _27579 = SEQ_PTR(_op_53613)->length;
                }
                else {
                    _27579 = 1;
                }
                _size_53616 = _27579 - 1;
                _27579 = NOVALUE;

                /** 						if is_func then*/
                if (_is_func_53595 == 0)
                {
                    goto LB; // [263] 289
                }
                else{
                }

                /** 							Push( op[$] )*/
                if (IS_SEQUENCE(_op_53613)){
                        _27581 = SEQ_PTR(_op_53613)->length;
                }
                else {
                    _27581 = 1;
                }
                _2 = (int)SEQ_PTR(_op_53613);
                _27582 = (int)*(((s1_ptr)_2)->base + _27581);
                Ref(_27582);
                _37Push(_27582);
                _27582 = NOVALUE;

                /** 							op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_53613)){
                        _27583 = SEQ_PTR(_op_53613)->length;
                }
                else {
                    _27583 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_53613);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27583)) ? _27583 : (long)(DBL_PTR(_27583)->dbl);
                    int stop = (IS_ATOM_INT(_27583)) ? _27583 : (long)(DBL_PTR(_27583)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<0) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_53613), start, &_op_53613 );
                        }
                        else Tail(SEQ_PTR(_op_53613), stop+1, &_op_53613);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_53613), start, &_op_53613);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_53613 = Remove_elements(start, stop, (SEQ_PTR(_op_53613)->ref == 1));
                    }
                }
                _27583 = NOVALUE;
                _27583 = NOVALUE;
LB: 

                /** 						for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_53613)){
                        _27585 = SEQ_PTR(_op_53613)->length;
                }
                else {
                    _27585 = 1;
                }
                {
                    int _p_53626;
                    _p_53626 = 3;
LC: 
                    if (_p_53626 > _27585){
                        goto LD; // [294] 317
                    }

                    /** 							Push( op[p] )*/
                    _2 = (int)SEQ_PTR(_op_53613);
                    _27586 = (int)*(((s1_ptr)_2)->base + _p_53626);
                    Ref(_27586);
                    _37Push(_27586);
                    _27586 = NOVALUE;

                    /** 						end for*/
                    _p_53626 = _p_53626 + 1;
                    goto LC; // [312] 301
LD: 
                    ;
                }

                /** 						code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27587 = _ix_53574 + _offset_53602;
                if ((long)((unsigned long)_27587 + (unsigned long)HIGH_BITS) >= 0) 
                _27587 = NewDouble((double)_27587);
                if (IS_ATOM_INT(_27587)) {
                    _27588 = _27587 - 1;
                    if ((long)((unsigned long)_27588 +(unsigned long) HIGH_BITS) >= 0){
                        _27588 = NewDouble((double)_27588);
                    }
                }
                else {
                    _27588 = NewDouble(DBL_PTR(_27587)->dbl - (double)1);
                }
                DeRef(_27587);
                _27587 = NOVALUE;
                _0 = _code_53590;
                _code_53590 = _66get_inlined_code(_sub_53562, _27588, 1);
                DeRef(_0);
                _27588 = NOVALUE;

                /** 						shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_53590)){
                        _27590 = SEQ_PTR(_code_53590)->length;
                }
                else {
                    _27590 = 1;
                }
                _27591 = Repeat(159, _27590);
                _27590 = NOVALUE;
                _27592 = _ix_53574 + _offset_53602;
                if ((long)((unsigned long)_27592 + (unsigned long)HIGH_BITS) >= 0) 
                _27592 = NewDouble((double)_27592);
                _27593 = _ix_53574 + _offset_53602;
                if ((long)((unsigned long)_27593 + (unsigned long)HIGH_BITS) >= 0) 
                _27593 = NewDouble((double)_27593);
                if (IS_ATOM_INT(_27593)) {
                    _27594 = _27593 + _size_53616;
                    if ((long)((unsigned long)_27594 + (unsigned long)HIGH_BITS) >= 0) 
                    _27594 = NewDouble((double)_27594);
                }
                else {
                    _27594 = NewDouble(DBL_PTR(_27593)->dbl + (double)_size_53616);
                }
                DeRef(_27593);
                _27593 = NOVALUE;
                _64replace_code(_27591, _27592, _27594);
                _27591 = NOVALUE;
                _27592 = NOVALUE;
                _27594 = NOVALUE;

                /** 						Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27595 = _ix_53574 + _offset_53602;
                if ((long)((unsigned long)_27595 + (unsigned long)HIGH_BITS) >= 0) 
                _27595 = NewDouble((double)_27595);
                _27596 = _ix_53574 + _offset_53602;
                if ((long)((unsigned long)_27596 + (unsigned long)HIGH_BITS) >= 0) 
                _27596 = NewDouble((double)_27596);
                if (IS_SEQUENCE(_code_53590)){
                        _27597 = SEQ_PTR(_code_53590)->length;
                }
                else {
                    _27597 = 1;
                }
                if (IS_ATOM_INT(_27596)) {
                    _27598 = _27596 + _27597;
                    if ((long)((unsigned long)_27598 + (unsigned long)HIGH_BITS) >= 0) 
                    _27598 = NewDouble((double)_27598);
                }
                else {
                    _27598 = NewDouble(DBL_PTR(_27596)->dbl + (double)_27597);
                }
                DeRef(_27596);
                _27596 = NOVALUE;
                _27597 = NOVALUE;
                if (IS_ATOM_INT(_27598)) {
                    _27599 = _27598 - 1;
                    if ((long)((unsigned long)_27599 +(unsigned long) HIGH_BITS) >= 0){
                        _27599 = NewDouble((double)_27599);
                    }
                }
                else {
                    _27599 = NewDouble(DBL_PTR(_27598)->dbl - (double)1);
                }
                DeRef(_27598);
                _27598 = NOVALUE;
                {
                    int p1 = _12Code_11771;
                    int p2 = _code_53590;
                    int p3 = _27595;
                    int p4 = _27599;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_12Code_11771;
                    Replace( &replace_params );
                }
                DeRef(_27595);
                _27595 = NOVALUE;
                DeRef(_27599);
                _27599 = NOVALUE;

                /** 						offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_53590)){
                        _27601 = SEQ_PTR(_code_53590)->length;
                }
                else {
                    _27601 = 1;
                }
                _27602 = _27601 - _size_53616;
                if ((long)((unsigned long)_27602 +(unsigned long) HIGH_BITS) >= 0){
                    _27602 = NewDouble((double)_27602);
                }
                _27601 = NOVALUE;
                if (IS_ATOM_INT(_27602)) {
                    _27603 = _27602 - 1;
                    if ((long)((unsigned long)_27603 +(unsigned long) HIGH_BITS) >= 0){
                        _27603 = NewDouble((double)_27603);
                    }
                }
                else {
                    _27603 = NewDouble(DBL_PTR(_27602)->dbl - (double)1);
                }
                DeRef(_27602);
                _27602 = NOVALUE;
                if (IS_ATOM_INT(_27603)) {
                    _offset_53602 = _offset_53602 + _27603;
                }
                else {
                    _offset_53602 = NewDouble((double)_offset_53602 + DBL_PTR(_27603)->dbl);
                }
                DeRef(_27603);
                _27603 = NOVALUE;
                if (!IS_ATOM_INT(_offset_53602)) {
                    _1 = (long)(DBL_PTR(_offset_53602)->dbl);
                    DeRefDS(_offset_53602);
                    _offset_53602 = _1;
                }
LA: 
                DeRef(_op_53613);
                _op_53613 = NOVALUE;

                /** 				end for*/
                _o_53604 = _o_53604 + 1;
                goto L8; // [418] 210
L9: 
                ;
            }

            /** 				SymTab[calling_sub][S_CODE] = Code*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _13SymTab_10636 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_53576 + ((s1_ptr)_2)->base);
            RefDS(_12Code_11771);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_CODE_11366))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
            _1 = *(int *)_2;
            *(int *)_2 = _12Code_11771;
            DeRef(_1);
            _27605 = NOVALUE;

            /** 				SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _13SymTab_10636 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_53576 + ((s1_ptr)_2)->base);
            RefDS(_12LineTable_11772);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_LINETAB_11389))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
            _1 = *(int *)_2;
            *(int *)_2 = _12LineTable_11772;
            DeRef(_1);
            _27607 = NOVALUE;
            DeRef(_code_53590);
            _code_53590 = NOVALUE;
            DeRef(_calls_53591);
            _calls_53591 = NOVALUE;

            /** 			end for*/
            _cx_53571 = _cx_53571 + 1;
            goto L6; // [461] 92
L7: 
            ;
        }
L3: 

        /** 	end for*/
L5: 
        _i_53557 = _i_53557 + 1;
        goto L1; // [471] 20
L2: 
        ;
    }

    /** end procedure*/
    _27552 = NOVALUE;
    _27558 = NOVALUE;
    return;
    ;
}



// 0xD2D2601E
