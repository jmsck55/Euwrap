// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _65block_type_name(int _opcode_45307)
{
    int _23944 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45307)) {
        _1 = (long)(DBL_PTR(_opcode_45307)->dbl);
        DeRefDS(_opcode_45307);
        _opcode_45307 = _1;
    }

    /** 	switch opcode do*/
    _0 = _opcode_45307;
    switch ( _0 ){ 

        /** 		case LOOP then*/
        case 422:

        /** 			return "LOOP"*/
        RefDS(_23942);
        return _23942;
        goto L1; // [20] 63

        /** 		case PROC then*/
        case 27:

        /** 			return "PROC"*/
        RefDS(_21587);
        return _21587;
        goto L1; // [32] 63

        /** 		case FUNC then*/
        case 501:

        /** 			return "FUNC"*/
        RefDS(_23943);
        return _23943;
        goto L1; // [44] 63

        /** 		case else*/
        default:

        /** 			return opnames[opcode]*/
        _2 = (int)SEQ_PTR(_59opnames_21863);
        _23944 = (int)*(((s1_ptr)_2)->base + _opcode_45307);
        RefDS(_23944);
        return _23944;
    ;}L1: 
    ;
}


void _65check_block(int _got_45323)
{
    int _expected_45324 = NOVALUE;
    int _23952 = NOVALUE;
    int _23951 = NOVALUE;
    int _23950 = NOVALUE;
    int _23946 = NOVALUE;
    int _23945 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _23945 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _23945 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _23946 = (int)*(((s1_ptr)_2)->base + _23945);
    _2 = (int)SEQ_PTR(_23946);
    _expected_45324 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_45324)){
        _expected_45324 = (long)DBL_PTR(_expected_45324)->dbl;
    }
    _23946 = NOVALUE;

    /** 	if got = FUNC then*/
    if (_got_45323 != 501)
    goto L1; // [24] 38

    /** 		got = PROC*/
    _got_45323 = 27;
L1: 

    /** 	if got != expected then*/
    if (_got_45323 == _expected_45324)
    goto L2; // [40] 64

    /** 		CompileErr( 79, {block_type_name( expected ), block_type_name( got)} )*/
    _23950 = _65block_type_name(_expected_45324);
    _23951 = _65block_type_name(_got_45323);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23950;
    ((int *)_2)[2] = _23951;
    _23952 = MAKE_SEQ(_1);
    _23951 = NOVALUE;
    _23950 = NOVALUE;
    _43CompileErr(79, _23952, 0);
    _23952 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


void _65Block_var(int _sym_45341)
{
    int _block_45342 = NOVALUE;
    int _23973 = NOVALUE;
    int _23972 = NOVALUE;
    int _23971 = NOVALUE;
    int _23969 = NOVALUE;
    int _23968 = NOVALUE;
    int _23966 = NOVALUE;
    int _23965 = NOVALUE;
    int _23964 = NOVALUE;
    int _23963 = NOVALUE;
    int _23962 = NOVALUE;
    int _23961 = NOVALUE;
    int _23960 = NOVALUE;
    int _23958 = NOVALUE;
    int _23956 = NOVALUE;
    int _23955 = NOVALUE;
    int _23953 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45341)) {
        _1 = (long)(DBL_PTR(_sym_45341)->dbl);
        DeRefDS(_sym_45341);
        _sym_45341 = _1;
    }

    /** 	sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _23953 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _23953 = 1;
    }
    DeRef(_block_45342);
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _block_45342 = (int)*(((s1_ptr)_2)->base + _23953);
    Ref(_block_45342);

    /** 	block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _23955 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _23955 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _2 = (int)(((s1_ptr)_2)->base + _23955);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _23956 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _23956 = 1;
    }
    if (_23956 <= 1)
    goto L1; // [34] 58

    /** 		SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45341 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_block_45342);
    _23960 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23960);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_11374))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    _1 = *(int *)_2;
    *(int *)_2 = _23960;
    if( _1 != _23960 ){
        DeRef(_1);
    }
    _23960 = NOVALUE;
    _23958 = NOVALUE;
L1: 

    /** 	if length(block[BLOCK_VARS]) then*/
    _2 = (int)SEQ_PTR(_block_45342);
    _23961 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23961)){
            _23962 = SEQ_PTR(_23961)->length;
    }
    else {
        _23962 = 1;
    }
    _23961 = NOVALUE;
    if (_23962 == 0)
    {
        _23962 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _23962 = NOVALUE;
    }

    /** 		SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45342);
    _23963 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23963)){
            _23964 = SEQ_PTR(_23963)->length;
    }
    else {
        _23964 = 1;
    }
    _2 = (int)SEQ_PTR(_23963);
    _23965 = (int)*(((s1_ptr)_2)->base + _23964);
    _23963 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23965))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23965)->dbl));
    else
    _3 = (int)(_23965 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45341;
    DeRef(_1);
    _23966 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** 		SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45342);
    _23968 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23968))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23968)->dbl));
    else
    _3 = (int)(_23968 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45341;
    DeRef(_1);
    _23969 = NOVALUE;
L3: 

    /** 	block[BLOCK_VARS] &= sym*/
    _2 = (int)SEQ_PTR(_block_45342);
    _23971 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23971) && IS_ATOM(_sym_45341)) {
        Append(&_23972, _23971, _sym_45341);
    }
    else if (IS_ATOM(_23971) && IS_SEQUENCE(_sym_45341)) {
    }
    else {
        Concat((object_ptr)&_23972, _23971, _sym_45341);
        _23971 = NOVALUE;
    }
    _23971 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45342);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45342 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _23972;
    if( _1 != _23972 ){
        DeRef(_1);
    }
    _23972 = NOVALUE;

    /** 	block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _23973 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _23973 = 1;
    }
    RefDS(_block_45342);
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _2 = (int)(((s1_ptr)_2)->base + _23973);
    _1 = *(int *)_2;
    *(int *)_2 = _block_45342;
    DeRef(_1);

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRefDS(_block_45342);
    _23961 = NOVALUE;
    _23965 = NOVALUE;
    _23968 = NOVALUE;
    return;
    ;
}


void _65NewBlock(int _opcode_45376, int _block_label_45377)
{
    int _block_45395 = NOVALUE;
    int _23987 = NOVALUE;
    int _23986 = NOVALUE;
    int _23985 = NOVALUE;
    int _23983 = NOVALUE;
    int _23981 = NOVALUE;
    int _23980 = NOVALUE;
    int _23978 = NOVALUE;
    int _23977 = NOVALUE;
    int _23975 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _23975 = Repeat(0, _12SIZEOF_BLOCK_ENTRY_11485);
    RefDS(_23975);
    Append(&_13SymTab_10636, _13SymTab_10636, _23975);
    DeRefDS(_23975);
    _23975 = NOVALUE;

    /** 	SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _23977 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _23977 = 1;
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_23977 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _23978 = NOVALUE;

    /** 	SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _23980 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _23980 = 1;
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_23980 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRST_LINE_11379))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRST_LINE_11379)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FIRST_LINE_11379);
    _1 = *(int *)_2;
    *(int *)_2 = _12gline_number_11687;
    DeRef(_1);
    _23981 = NOVALUE;

    /** 	sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _23983 = 6;
    DeRef(_block_45395);
    _block_45395 = Repeat(0, 6);
    _23983 = NOVALUE;

    /** 	block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _23985 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _23985 = 1;
    }
    _2 = (int)SEQ_PTR(_block_45395);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45395 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _23985;
    if( _1 != _23985 ){
    }
    _23985 = NOVALUE;

    /** 	block[BLOCK_OPCODE] = opcode*/
    _2 = (int)SEQ_PTR(_block_45395);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45395 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = _opcode_45376;

    /** 	block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_45377);
    _2 = (int)SEQ_PTR(_block_45395);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45395 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    *(int *)_2 = _block_label_45377;

    /** 	block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _23986 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _23986 = 1;
    }
    _23987 = _23986 + 1;
    _23986 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45395);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45395 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _23987;
    if( _1 != _23987 ){
        DeRef(_1);
    }
    _23987 = NOVALUE;

    /** 	block[BLOCK_VARS]   = {}*/
    RefDS(_21829);
    _2 = (int)SEQ_PTR(_block_45395);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45395 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);

    /** 	block_stack = append( block_stack, block )*/
    RefDS(_block_45395);
    Append(&_65block_stack_45297, _65block_stack_45297, _block_45395);

    /** 	current_block = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _65current_block_45304 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _65current_block_45304 = 1;
    }

    /** end procedure*/
    DeRef(_block_label_45377);
    DeRefDS(_block_45395);
    return;
    ;
}


void _65Start_block(int _opcode_45408, int _block_label_45409)
{
    int _last_block_45411 = NOVALUE;
    int _label_name_45439 = NOVALUE;
    int _24009 = NOVALUE;
    int _24008 = NOVALUE;
    int _24007 = NOVALUE;
    int _24004 = NOVALUE;
    int _24003 = NOVALUE;
    int _24001 = NOVALUE;
    int _24000 = NOVALUE;
    int _23999 = NOVALUE;
    int _23998 = NOVALUE;
    int _23997 = NOVALUE;
    int _23994 = NOVALUE;
    int _23992 = NOVALUE;
    int _23991 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_opcode_45408)) {
        _1 = (long)(DBL_PTR(_opcode_45408)->dbl);
        DeRefDS(_opcode_45408);
        _opcode_45408 = _1;
    }

    /** 	symtab_index last_block = current_block*/
    _last_block_45411 = _65current_block_45304;

    /** 	if opcode = FUNC then*/
    if (_opcode_45408 != 501)
    goto L1; // [16] 30

    /** 		opcode = PROC*/
    _opcode_45408 = 27;
L1: 

    /** 	NewBlock( opcode, block_label )*/
    Ref(_block_label_45409);
    _65NewBlock(_opcode_45408, _block_label_45409);

    /** 	if find(opcode, RTN_TOKS) then*/
    _23991 = find_from(_opcode_45408, _28RTN_TOKS_11302, 1);
    if (_23991 == 0)
    {
        _23991 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _23991 = NOVALUE;
    }

    /** 		SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_45409))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45409)->dbl));
    else
    _3 = (int)(_block_label_45409 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_11374))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    _1 = *(int *)_2;
    *(int *)_2 = _65current_block_45304;
    DeRef(_1);
    _23992 = NOVALUE;

    /** 		SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45304 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_block_label_45409)){
        _23997 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45409)->dbl));
    }
    else{
        _23997 = (int)*(((s1_ptr)_2)->base + _block_label_45409);
    }
    _2 = (int)SEQ_PTR(_23997);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _23998 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _23998 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _23997 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23998);
    *((int *)(_2+4)) = _23998;
    _23999 = MAKE_SEQ(_1);
    _23998 = NOVALUE;
    _24000 = EPrintf(-9999999, _23996, _23999);
    DeRefDS(_23999);
    _23999 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_11354))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NAME_11354);
    _1 = *(int *)_2;
    *(int *)_2 = _24000;
    if( _1 != _24000 ){
        DeRef(_1);
    }
    _24000 = NOVALUE;
    _23994 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** 	elsif current_block then*/
    if (_65current_block_45304 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** 		SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45304 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_11374))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    _1 = *(int *)_2;
    *(int *)_2 = _last_block_45411;
    DeRef(_1);
    _24001 = NOVALUE;

    /** 		sequence label_name = ""*/
    RefDS(_21829);
    DeRef(_label_name_45439);
    _label_name_45439 = _21829;

    /** 		if sequence(block_label) then*/
    _24003 = IS_SEQUENCE(_block_label_45409);
    if (_24003 == 0)
    {
        _24003 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _24003 = NOVALUE;
    }

    /** 			label_name = block_label*/
    Ref(_block_label_45409);
    DeRefDS(_label_name_45439);
    _label_name_45439 = _block_label_45409;
L5: 

    /** 		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45304 + ((s1_ptr)_2)->base);
    _24007 = _65block_type_name(_opcode_45408);
    RefDS(_label_name_45439);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24007;
    ((int *)_2)[2] = _label_name_45439;
    _24008 = MAKE_SEQ(_1);
    _24007 = NOVALUE;
    _24009 = EPrintf(-9999999, _24006, _24008);
    DeRefDS(_24008);
    _24008 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_11354))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NAME_11354);
    _1 = *(int *)_2;
    *(int *)_2 = _24009;
    if( _1 != _24009 ){
        DeRef(_1);
    }
    _24009 = NOVALUE;
    _24004 = NOVALUE;
L4: 
    DeRef(_label_name_45439);
    _label_name_45439 = NOVALUE;
L3: 

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRef(_block_label_45409);
    return;
    ;
}


void _65block_label(int _label_name_45455)
{
    int _24023 = NOVALUE;
    int _24022 = NOVALUE;
    int _24021 = NOVALUE;
    int _24020 = NOVALUE;
    int _24019 = NOVALUE;
    int _24018 = NOVALUE;
    int _24016 = NOVALUE;
    int _24014 = NOVALUE;
    int _24013 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24013 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24013 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65block_stack_45297 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24013 + ((s1_ptr)_2)->base);
    RefDS(_label_name_45455);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _label_name_45455;
    DeRef(_1);
    _24014 = NOVALUE;

    /** 	SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45304 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24018 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24018 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24019 = (int)*(((s1_ptr)_2)->base + _24018);
    _2 = (int)SEQ_PTR(_24019);
    _24020 = (int)*(((s1_ptr)_2)->base + 2);
    _24019 = NOVALUE;
    Ref(_24020);
    _24021 = _65block_type_name(_24020);
    _24020 = NOVALUE;
    RefDS(_label_name_45455);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24021;
    ((int *)_2)[2] = _label_name_45455;
    _24022 = MAKE_SEQ(_1);
    _24021 = NOVALUE;
    _24023 = EPrintf(-9999999, _24006, _24022);
    DeRefDS(_24022);
    _24022 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_11354))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NAME_11354);
    _1 = *(int *)_2;
    *(int *)_2 = _24023;
    if( _1 != _24023 ){
        DeRef(_1);
    }
    _24023 = NOVALUE;
    _24016 = NOVALUE;

    /** end procedure*/
    DeRefDS(_label_name_45455);
    return;
    ;
}


int _65pop_block()
{
    int _block_45474 = NOVALUE;
    int _block_vars_45487 = NOVALUE;
    int _24052 = NOVALUE;
    int _24050 = NOVALUE;
    int _24049 = NOVALUE;
    int _24048 = NOVALUE;
    int _24047 = NOVALUE;
    int _24045 = NOVALUE;
    int _24044 = NOVALUE;
    int _24043 = NOVALUE;
    int _24042 = NOVALUE;
    int _24041 = NOVALUE;
    int _24040 = NOVALUE;
    int _24039 = NOVALUE;
    int _24038 = NOVALUE;
    int _24037 = NOVALUE;
    int _24036 = NOVALUE;
    int _24032 = NOVALUE;
    int _24031 = NOVALUE;
    int _24029 = NOVALUE;
    int _24028 = NOVALUE;
    int _24026 = NOVALUE;
    int _24024 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24024 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24024 = 1;
    }
    if (_24024 != 0)
    goto L1; // [8] 18
    _24024 = NOVALUE;

    /** 		return 0*/
    DeRef(_block_45474);
    DeRef(_block_vars_45487);
    return 0;
L1: 

    /** 	sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24026 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24026 = 1;
    }
    DeRef(_block_45474);
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _block_45474 = (int)*(((s1_ptr)_2)->base + _24026);
    Ref(_block_45474);

    /** 	block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24028 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24028 = 1;
    }
    _24029 = _24028 - 1;
    _24028 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_45297;
    RHS_Slice(_65block_stack_45297, 1, _24029);

    /** 	SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (int)SEQ_PTR(_block_45474);
    _24031 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24031))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24031)->dbl));
    else
    _3 = (int)(_24031 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LAST_LINE_11384))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LAST_LINE_11384)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LAST_LINE_11384);
    _1 = *(int *)_2;
    *(int *)_2 = _12gline_number_11687;
    DeRef(_1);
    _24032 = NOVALUE;

    /** 	ifdef BDEBUG then*/

    /** 	sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_45487);
    _2 = (int)SEQ_PTR(_block_45474);
    _block_vars_45487 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_45487);

    /** 	for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_45487)){
            _24036 = SEQ_PTR(_block_vars_45487)->length;
    }
    else {
        _24036 = 1;
    }
    {
        int _sx_45490;
        _sx_45490 = 1;
L2: 
        if (_sx_45490 > _24036){
            goto L3; // [83] 172
        }

        /** 		if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (int)SEQ_PTR(_block_vars_45487);
        _24037 = (int)*(((s1_ptr)_2)->base + _sx_45490);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_24037)){
            _24038 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24037)->dbl));
        }
        else{
            _24038 = (int)*(((s1_ptr)_2)->base + _24037);
        }
        _2 = (int)SEQ_PTR(_24038);
        _24039 = (int)*(((s1_ptr)_2)->base + 3);
        _24038 = NOVALUE;
        if (IS_ATOM_INT(_24039)) {
            _24040 = (_24039 == 1);
        }
        else {
            _24040 = binary_op(EQUALS, _24039, 1);
        }
        _24039 = NOVALUE;
        if (IS_ATOM_INT(_24040)) {
            if (_24040 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_24040)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (int)SEQ_PTR(_block_vars_45487);
        _24042 = (int)*(((s1_ptr)_2)->base + _sx_45490);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_24042)){
            _24043 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24042)->dbl));
        }
        else{
            _24043 = (int)*(((s1_ptr)_2)->base + _24042);
        }
        _2 = (int)SEQ_PTR(_24043);
        _24044 = (int)*(((s1_ptr)_2)->base + 4);
        _24043 = NOVALUE;
        if (IS_ATOM_INT(_24044)) {
            _24045 = (_24044 <= 5);
        }
        else {
            _24045 = binary_op(LESSEQ, _24044, 5);
        }
        _24044 = NOVALUE;
        if (_24045 == 0) {
            DeRef(_24045);
            _24045 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_24045) && DBL_PTR(_24045)->dbl == 0.0){
                DeRef(_24045);
                _24045 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_24045);
            _24045 = NOVALUE;
        }
        DeRef(_24045);
        _24045 = NOVALUE;

        /** 			ifdef BDEBUG then*/

        /** 			Hide( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45487);
        _24047 = (int)*(((s1_ptr)_2)->base + _sx_45490);
        Ref(_24047);
        _52Hide(_24047);
        _24047 = NOVALUE;

        /** 			LintCheck( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45487);
        _24048 = (int)*(((s1_ptr)_2)->base + _sx_45490);
        Ref(_24048);
        _52LintCheck(_24048);
        _24048 = NOVALUE;
L4: 

        /** 	end for*/
        _sx_45490 = _sx_45490 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** 	current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24049 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24049 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24050 = (int)*(((s1_ptr)_2)->base + _24049);
    _2 = (int)SEQ_PTR(_24050);
    _65current_block_45304 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_65current_block_45304)){
        _65current_block_45304 = (long)DBL_PTR(_65current_block_45304)->dbl;
    }
    _24050 = NOVALUE;

    /** 	return block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_block_45474);
    _24052 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24052);
    DeRefDS(_block_45474);
    DeRef(_block_vars_45487);
    DeRef(_24029);
    _24029 = NOVALUE;
    _24031 = NOVALUE;
    _24037 = NOVALUE;
    _24042 = NOVALUE;
    DeRef(_24040);
    _24040 = NOVALUE;
    return _24052;
    ;
}


int _65top_block(int _offset_45519)
{
    int _24060 = NOVALUE;
    int _24059 = NOVALUE;
    int _24058 = NOVALUE;
    int _24057 = NOVALUE;
    int _24056 = NOVALUE;
    int _24055 = NOVALUE;
    int _24053 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45519)) {
        _1 = (long)(DBL_PTR(_offset_45519)->dbl);
        DeRefDS(_offset_45519);
        _offset_45519 = _1;
    }

    /** 	if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24053 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24053 = 1;
    }
    if (_offset_45519 < _24053)
    goto L1; // [10] 33

    /** 		CompileErr(107, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24055 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24055 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _offset_45519;
    ((int *)_2)[2] = _24055;
    _24056 = MAKE_SEQ(_1);
    _24055 = NOVALUE;
    _43CompileErr(107, _24056, 0);
    _24056 = NOVALUE;
    goto L2; // [30] 57
L1: 

    /** 		return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24057 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24057 = 1;
    }
    _24058 = _24057 - _offset_45519;
    _24057 = NOVALUE;
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24059 = (int)*(((s1_ptr)_2)->base + _24058);
    _2 = (int)SEQ_PTR(_24059);
    _24060 = (int)*(((s1_ptr)_2)->base + 1);
    _24059 = NOVALUE;
    Ref(_24060);
    _24058 = NOVALUE;
    return _24060;
L2: 
    ;
}


void _65End_block(int _opcode_45533)
{
    int _ix_45544 = NOVALUE;
    int _24068 = NOVALUE;
    int _24065 = NOVALUE;
    int _24064 = NOVALUE;
    int _24063 = NOVALUE;
    int _24062 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45533)) {
        _1 = (long)(DBL_PTR(_opcode_45533)->dbl);
        DeRefDS(_opcode_45533);
        _opcode_45533 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45533 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45533 = 27;
L1: 

    /** 	check_block( opcode )*/
    _65check_block(_opcode_45533);

    /** 	if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24062 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24062 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24063 = (int)*(((s1_ptr)_2)->base + _24062);
    _2 = (int)SEQ_PTR(_24063);
    _24064 = (int)*(((s1_ptr)_2)->base + 6);
    _24063 = NOVALUE;
    if (IS_SEQUENCE(_24064)){
            _24065 = SEQ_PTR(_24064)->length;
    }
    else {
        _24065 = 1;
    }
    _24064 = NOVALUE;
    if (_24065 != 0)
    goto L2; // [44] 64
    _24065 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_45544 = 1;

    /** 		ix = pop_block()*/
    _ix_45544 = _65pop_block();
    if (!IS_ATOM_INT(_ix_45544)) {
        _1 = (long)(DBL_PTR(_ix_45544)->dbl);
        DeRefDS(_ix_45544);
        _ix_45544 = _1;
    }
    goto L3; // [61] 80
L2: 

    /** 		Push( pop_block() )*/
    _24068 = _65pop_block();
    _37Push(_24068);
    _24068 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _37emit_op(206);
L3: 

    /** end procedure*/
    _24064 = NOVALUE;
    return;
    ;
}


int _65End_inline_block(int _opcode_45553)
{
    int _24075 = NOVALUE;
    int _24074 = NOVALUE;
    int _24073 = NOVALUE;
    int _24072 = NOVALUE;
    int _24071 = NOVALUE;
    int _24070 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45553)) {
        _1 = (long)(DBL_PTR(_opcode_45553)->dbl);
        DeRefDS(_opcode_45553);
        _opcode_45553 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45553 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45553 = 27;
L1: 

    /** 	if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24070 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24070 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24071 = (int)*(((s1_ptr)_2)->base + _24070);
    _2 = (int)SEQ_PTR(_24071);
    _24072 = (int)*(((s1_ptr)_2)->base + 6);
    _24071 = NOVALUE;
    if (IS_SEQUENCE(_24072)){
            _24073 = SEQ_PTR(_24072)->length;
    }
    else {
        _24073 = 1;
    }
    _24072 = NOVALUE;
    if (_24073 == 0)
    {
        _24073 = NOVALUE;
        goto L2; // [39] 60
    }
    else{
        _24073 = NOVALUE;
    }

    /** 		return { EXIT_BLOCK, pop_block() }*/
    _24074 = _65pop_block();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _24074;
    _24075 = MAKE_SEQ(_1);
    _24074 = NOVALUE;
    _24072 = NOVALUE;
    return _24075;
    goto L3; // [57] 72
L2: 

    /** 		Drop_block( opcode )*/
    _65Drop_block(_opcode_45553);

    /** 		return {}*/
    RefDS(_21829);
    _24072 = NOVALUE;
    DeRef(_24075);
    _24075 = NOVALUE;
    return _21829;
L3: 
    ;
}


void _65Sibling_block(int _opcode_45570)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45570)) {
        _1 = (long)(DBL_PTR(_opcode_45570)->dbl);
        DeRefDS(_opcode_45570);
        _opcode_45570 = _1;
    }

    /** 	End_block( opcode )*/
    _65End_block(_opcode_45570);

    /** 	Start_block( opcode )*/
    _65Start_block(_opcode_45570, 0);

    /** end procedure*/
    return;
    ;
}


void _65Leave_block(int _offset_45573)
{
    int _24081 = NOVALUE;
    int _24080 = NOVALUE;
    int _24079 = NOVALUE;
    int _24078 = NOVALUE;
    int _24077 = NOVALUE;
    int _24076 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45573)) {
        _1 = (long)(DBL_PTR(_offset_45573)->dbl);
        DeRefDS(_offset_45573);
        _offset_45573 = _1;
    }

    /** 	if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24076 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24076 = 1;
    }
    _24077 = _24076 - _offset_45573;
    _24076 = NOVALUE;
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24078 = (int)*(((s1_ptr)_2)->base + _24077);
    _2 = (int)SEQ_PTR(_24078);
    _24079 = (int)*(((s1_ptr)_2)->base + 6);
    _24078 = NOVALUE;
    if (IS_SEQUENCE(_24079)){
            _24080 = SEQ_PTR(_24079)->length;
    }
    else {
        _24080 = 1;
    }
    _24079 = NOVALUE;
    if (_24080 == 0)
    {
        _24080 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _24080 = NOVALUE;
    }

    /** 		Push( top_block( offset ) )*/
    _24081 = _65top_block(_offset_45573);
    _37Push(_24081);
    _24081 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _37emit_op(206);
L1: 

    /** end procedure*/
    DeRef(_24077);
    _24077 = NOVALUE;
    _24079 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(int _blocks_45593, int _block_type_45594)
{
    int _bx_45595 = NOVALUE;
    int _Block_opcode_3__tmp_at29_45602 = NOVALUE;
    int _Block_opcode_2__tmp_at29_45601 = NOVALUE;
    int _Block_opcode_1__tmp_at29_45600 = NOVALUE;
    int _Block_opcode_inlined_Block_opcode_at_29_45599 = NOVALUE;
    int _24094 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_45593)) {
        _1 = (long)(DBL_PTR(_blocks_45593)->dbl);
        DeRefDS(_blocks_45593);
        _blocks_45593 = _1;
    }
    if (!IS_ATOM_INT(_block_type_45594)) {
        _1 = (long)(DBL_PTR(_block_type_45594)->dbl);
        DeRefDS(_block_type_45594);
        _block_type_45594 = _1;
    }

    /** 	integer bx = 0*/
    _bx_45595 = 0;

    /** 	while blocks do*/
L1: 
    if (_blocks_45593 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** 		Leave_block( bx )*/
    _65Leave_block(_bx_45595);

    /** 		if block_type then*/
    if (_block_type_45594 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** 			switch Block_opcode( bx ) do*/

    /** 	return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _Block_opcode_1__tmp_at29_45600 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_45600 = 1;
    }
    _Block_opcode_2__tmp_at29_45601 = _Block_opcode_1__tmp_at29_45600 - _bx_45595;
    DeRef(_Block_opcode_3__tmp_at29_45602);
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _Block_opcode_3__tmp_at29_45602 = (int)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_45601);
    Ref(_Block_opcode_3__tmp_at29_45602);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_45599);
    _2 = (int)SEQ_PTR(_Block_opcode_3__tmp_at29_45602);
    _Block_opcode_inlined_Block_opcode_at_29_45599 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_45599);
    DeRef(_Block_opcode_3__tmp_at29_45602);
    _Block_opcode_3__tmp_at29_45602 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_45599) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_45599)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45599)->dbl != (double) ((int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45599)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45599)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_45599;
    };
    switch ( _0 ){ 

        /** 				case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** 					if block_type = LOOP_BLOCK then*/
        if (_block_type_45594 != 1)
        goto L5; // [67] 108

        /** 						blocks -= 1*/
        _blocks_45593 = _blocks_45593 - 1;
        goto L5; // [78] 108

        /** 				case else*/
        default:
L4: 

        /** 					if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_45594 != 2)
        goto L6; // [86] 97

        /** 						blocks -= 1*/
        _blocks_45593 = _blocks_45593 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** 			blocks -= 1*/
    _blocks_45593 = _blocks_45593 - 1;
L5: 

    /** 		bx += 1*/
    _bx_45595 = _bx_45595 + 1;

    /** 	end while*/
    goto L1; // [116] 15
L2: 

    /** 	for i = 0 to blocks - 1 do*/
    _24094 = _blocks_45593 - 1;
    if ((long)((unsigned long)_24094 +(unsigned long) HIGH_BITS) >= 0){
        _24094 = NewDouble((double)_24094);
    }
    {
        int _i_45620;
        _i_45620 = 0;
L7: 
        if (binary_op_a(GREATER, _i_45620, _24094)){
            goto L8; // [125] 144
        }

        /** 		Leave_block( i )*/
        Ref(_i_45620);
        _65Leave_block(_i_45620);

        /** 	end for*/
        _0 = _i_45620;
        if (IS_ATOM_INT(_i_45620)) {
            _i_45620 = _i_45620 + 1;
            if ((long)((unsigned long)_i_45620 +(unsigned long) HIGH_BITS) >= 0){
                _i_45620 = NewDouble((double)_i_45620);
            }
        }
        else {
            _i_45620 = binary_op_a(PLUS, _i_45620, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_45620);
    }

    /** end procedure*/
    DeRef(_24094);
    _24094 = NOVALUE;
    return;
    ;
}


void _65Drop_block(int _opcode_45624)
{
    int _x_45626 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45624)) {
        _1 = (long)(DBL_PTR(_opcode_45624)->dbl);
        DeRefDS(_opcode_45624);
        _opcode_45624 = _1;
    }

    /** 	check_block( opcode )*/
    _65check_block(_opcode_45624);

    /** 	symtab_index x = pop_block()*/
    _x_45626 = _65pop_block();
    if (!IS_ATOM_INT(_x_45626)) {
        _1 = (long)(DBL_PTR(_x_45626)->dbl);
        DeRefDS(_x_45626);
        _x_45626 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    int _sym_45631 = NOVALUE;
    int _block_sym_45638 = NOVALUE;
    int _24122 = NOVALUE;
    int _24121 = NOVALUE;
    int _24120 = NOVALUE;
    int _24119 = NOVALUE;
    int _24118 = NOVALUE;
    int _24117 = NOVALUE;
    int _24116 = NOVALUE;
    int _24115 = NOVALUE;
    int _24113 = NOVALUE;
    int _24112 = NOVALUE;
    int _24110 = NOVALUE;
    int _24109 = NOVALUE;
    int _24107 = NOVALUE;
    int _24104 = NOVALUE;
    int _24102 = NOVALUE;
    int _24101 = NOVALUE;
    int _24099 = NOVALUE;
    int _24098 = NOVALUE;
    int _24097 = NOVALUE;
    int _24096 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24096 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24096 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24097 = (int)*(((s1_ptr)_2)->base + _24096);
    _2 = (int)SEQ_PTR(_24097);
    _24098 = (int)*(((s1_ptr)_2)->base + 6);
    _24097 = NOVALUE;
    if (IS_SEQUENCE(_24098)){
            _24099 = SEQ_PTR(_24098)->length;
    }
    else {
        _24099 = 1;
    }
    _2 = (int)SEQ_PTR(_24098);
    _sym_45631 = (int)*(((s1_ptr)_2)->base + _24099);
    if (!IS_ATOM_INT(_sym_45631)){
        _sym_45631 = (long)DBL_PTR(_sym_45631)->dbl;
    }
    _24098 = NOVALUE;

    /** 	symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24101 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24101 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24102 = (int)*(((s1_ptr)_2)->base + _24101);
    _2 = (int)SEQ_PTR(_24102);
    _block_sym_45638 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_45638)){
        _block_sym_45638 = (long)DBL_PTR(_block_sym_45638)->dbl;
    }
    _24102 = NOVALUE;

    /** 	while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _24104 = _52sym_next_in_block(_block_sym_45638);
    if (binary_op_a(EQUALS, _24104, _sym_45631)){
        DeRef(_24104);
        _24104 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_24104);
    _24104 = NOVALUE;

    /** 		block_sym = sym_next_in_block( block_sym )*/
    _block_sym_45638 = _52sym_next_in_block(_block_sym_45638);
    if (!IS_ATOM_INT(_block_sym_45638)) {
        _1 = (long)(DBL_PTR(_block_sym_45638)->dbl);
        DeRefDS(_block_sym_45638);
        _block_sym_45638 = _1;
    }

    /** 	end while*/
    goto L1; // [65] 47
L2: 

    /** 	SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_block_sym_45638 + ((s1_ptr)_2)->base);
    _24109 = _52sym_next_in_block(_sym_45631);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    _1 = *(int *)_2;
    *(int *)_2 = _24109;
    if( _1 != _24109 ){
        DeRef(_1);
    }
    _24109 = NOVALUE;
    _24107 = NOVALUE;

    /** 	SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45631 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24110 = NOVALUE;

    /** 	block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24112 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24112 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65block_stack_45297 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24112 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24115 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24115 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24116 = (int)*(((s1_ptr)_2)->base + _24115);
    _2 = (int)SEQ_PTR(_24116);
    _24117 = (int)*(((s1_ptr)_2)->base + 6);
    _24116 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_45297)){
            _24118 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _24118 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24119 = (int)*(((s1_ptr)_2)->base + _24118);
    _2 = (int)SEQ_PTR(_24119);
    _24120 = (int)*(((s1_ptr)_2)->base + 6);
    _24119 = NOVALUE;
    if (IS_SEQUENCE(_24120)){
            _24121 = SEQ_PTR(_24120)->length;
    }
    else {
        _24121 = 1;
    }
    _24120 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_24117);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_24121)) ? _24121 : (long)(DBL_PTR(_24121)->dbl);
        int stop = (IS_ATOM_INT(_24121)) ? _24121 : (long)(DBL_PTR(_24121)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_24117);
            DeRef(_24122);
            _24122 = _24117;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_24117), start, &_24122 );
            }
            else Tail(SEQ_PTR(_24117), stop+1, &_24122);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_24117), start, &_24122);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_24122);
            _24122 = _1;
        }
    }
    _24117 = NOVALUE;
    _24121 = NOVALUE;
    _24121 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24122;
    if( _1 != _24122 ){
        DeRef(_1);
    }
    _24122 = NOVALUE;
    _24113 = NOVALUE;

    /** end procedure*/
    _24120 = NOVALUE;
    return;
    ;
}


void _65Goto_block(int _from_block_45672, int _to_block_45674, int _pc_45675)
{
    int _code_45676 = NOVALUE;
    int _next_block_45678 = NOVALUE;
    int _24133 = NOVALUE;
    int _24130 = NOVALUE;
    int _24129 = NOVALUE;
    int _24128 = NOVALUE;
    int _24127 = NOVALUE;
    int _24126 = NOVALUE;
    int _24125 = NOVALUE;
    int _24124 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_45672)) {
        _1 = (long)(DBL_PTR(_from_block_45672)->dbl);
        DeRefDS(_from_block_45672);
        _from_block_45672 = _1;
    }
    if (!IS_ATOM_INT(_to_block_45674)) {
        _1 = (long)(DBL_PTR(_to_block_45674)->dbl);
        DeRefDS(_to_block_45674);
        _to_block_45674 = _1;
    }
    if (!IS_ATOM_INT(_pc_45675)) {
        _1 = (long)(DBL_PTR(_pc_45675)->dbl);
        DeRefDS(_pc_45675);
        _pc_45675 = _1;
    }

    /** 	sequence code = {}*/
    RefDS(_21829);
    DeRefi(_code_45676);
    _code_45676 = _21829;

    /** 	symtab_index next_block = sym_block( from_block )*/
    _next_block_45678 = _52sym_block(_from_block_45672);
    if (!IS_ATOM_INT(_next_block_45678)) {
        _1 = (long)(DBL_PTR(_next_block_45678)->dbl);
        DeRefDS(_next_block_45678);
        _next_block_45678 = _1;
    }

    /** 	while next_block */
L1: 
    if (_next_block_45678 == 0) {
        _24124 = 0;
        goto L2; // [27] 39
    }
    _24125 = (_from_block_45672 != _to_block_45674);
    _24124 = (_24125 != 0);
L2: 
    if (_24124 == 0) {
        goto L3; // [39] 93
    }
    _24127 = _52sym_token(_next_block_45678);
    _24128 = find_from(_24127, _28RTN_TOKS_11302, 1);
    DeRef(_24127);
    _24127 = NOVALUE;
    _24129 = (_24128 == 0);
    _24128 = NOVALUE;
    if (_24129 == 0)
    {
        DeRef(_24129);
        _24129 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_24129);
        _24129 = NOVALUE;
    }

    /** 		code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _from_block_45672;
    _24130 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_45676, _code_45676, _24130);
    DeRefDS(_24130);
    _24130 = NOVALUE;

    /** 		from_block = next_block*/
    _from_block_45672 = _next_block_45678;

    /** 		next_block = sym_block( next_block )*/
    _next_block_45678 = _52sym_block(_next_block_45678);
    if (!IS_ATOM_INT(_next_block_45678)) {
        _1 = (long)(DBL_PTR(_next_block_45678)->dbl);
        DeRefDS(_next_block_45678);
        _next_block_45678 = _1;
    }

    /** 	end while*/
    goto L1; // [90] 27
L3: 

    /** 	if length(code) then*/
    if (IS_SEQUENCE(_code_45676)){
            _24133 = SEQ_PTR(_code_45676)->length;
    }
    else {
        _24133 = 1;
    }
    if (_24133 == 0)
    {
        _24133 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _24133 = NOVALUE;
    }

    /** 		if pc then*/
    if (_pc_45675 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** 			insert_code( code, pc )*/
    RefDS(_code_45676);
    _64insert_code(_code_45676, _pc_45675);
    goto L6; // [112] 126
L5: 

    /** 			Code &= code*/
    Concat((object_ptr)&_12Code_11771, _12Code_11771, _code_45676);
L6: 
L4: 

    /** end procedure*/
    DeRefi(_code_45676);
    DeRef(_24125);
    _24125 = NOVALUE;
    return;
    ;
}


void _65blocks_info()
{
    int _0, _1, _2;
    

    /** 	? block_stack*/
    StdPrint(1, _65block_stack_45297, 1);

    /** end procedure*/
    return;
    ;
}


int _65Least_block()
{
    int _ix_45706 = NOVALUE;
    int _sub_block_45709 = NOVALUE;
    int _24147 = NOVALUE;
    int _24146 = NOVALUE;
    int _24144 = NOVALUE;
    int _24143 = NOVALUE;
    int _24142 = NOVALUE;
    int _24141 = NOVALUE;
    int _24140 = NOVALUE;
    int _24139 = NOVALUE;
    int _24138 = NOVALUE;
    int _24137 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_45297)){
            _ix_45706 = SEQ_PTR(_65block_stack_45297)->length;
    }
    else {
        _ix_45706 = 1;
    }

    /** 	symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_45709 = _52sym_block(_12CurrentSub_11690);
    if (!IS_ATOM_INT(_sub_block_45709)) {
        _1 = (long)(DBL_PTR(_sub_block_45709)->dbl);
        DeRefDS(_sub_block_45709);
        _sub_block_45709 = _1;
    }

    /** 	while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24137 = (int)*(((s1_ptr)_2)->base + _ix_45706);
    _2 = (int)SEQ_PTR(_24137);
    _24138 = (int)*(((s1_ptr)_2)->base + 6);
    _24137 = NOVALUE;
    if (IS_SEQUENCE(_24138)){
            _24139 = SEQ_PTR(_24138)->length;
    }
    else {
        _24139 = 1;
    }
    _24138 = NOVALUE;
    _24140 = (_24139 == 0);
    _24139 = NOVALUE;
    if (_24140 == 0) {
        goto L2; // [39] 72
    }
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24142 = (int)*(((s1_ptr)_2)->base + _ix_45706);
    _2 = (int)SEQ_PTR(_24142);
    _24143 = (int)*(((s1_ptr)_2)->base + 1);
    _24142 = NOVALUE;
    if (IS_ATOM_INT(_24143)) {
        _24144 = (_24143 != _sub_block_45709);
    }
    else {
        _24144 = binary_op(NOTEQ, _24143, _sub_block_45709);
    }
    _24143 = NOVALUE;
    if (_24144 <= 0) {
        if (_24144 == 0) {
            DeRef(_24144);
            _24144 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_24144) && DBL_PTR(_24144)->dbl == 0.0){
                DeRef(_24144);
                _24144 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_24144);
            _24144 = NOVALUE;
        }
    }
    DeRef(_24144);
    _24144 = NOVALUE;

    /** 		ix -= 1	*/
    _ix_45706 = _ix_45706 - 1;

    /** 	end while*/
    goto L1; // [69] 23
L2: 

    /** 	return block_stack[ix][BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_65block_stack_45297);
    _24146 = (int)*(((s1_ptr)_2)->base + _ix_45706);
    _2 = (int)SEQ_PTR(_24146);
    _24147 = (int)*(((s1_ptr)_2)->base + 1);
    _24146 = NOVALUE;
    Ref(_24147);
    _24138 = NOVALUE;
    DeRef(_24140);
    _24140 = NOVALUE;
    return _24147;
    ;
}



// 0xFBC3A679
