// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _64init_op_info()
{
    int _SHORT_CIRCUIT_26666 = NOVALUE;
    int _15070 = NOVALUE;
    int _15069 = NOVALUE;
    int _15068 = NOVALUE;
    int _15067 = NOVALUE;
    int _15066 = NOVALUE;
    int _15065 = NOVALUE;
    int _15064 = NOVALUE;
    int _15063 = NOVALUE;
    int _15062 = NOVALUE;
    int _15061 = NOVALUE;
    int _15060 = NOVALUE;
    int _15059 = NOVALUE;
    int _15058 = NOVALUE;
    int _15057 = NOVALUE;
    int _15056 = NOVALUE;
    int _15055 = NOVALUE;
    int _15054 = NOVALUE;
    int _15052 = NOVALUE;
    int _15051 = NOVALUE;
    int _15050 = NOVALUE;
    int _15049 = NOVALUE;
    int _15048 = NOVALUE;
    int _15047 = NOVALUE;
    int _15046 = NOVALUE;
    int _15045 = NOVALUE;
    int _15044 = NOVALUE;
    int _15043 = NOVALUE;
    int _15042 = NOVALUE;
    int _15041 = NOVALUE;
    int _15040 = NOVALUE;
    int _15039 = NOVALUE;
    int _15038 = NOVALUE;
    int _15037 = NOVALUE;
    int _15036 = NOVALUE;
    int _15035 = NOVALUE;
    int _15034 = NOVALUE;
    int _15033 = NOVALUE;
    int _15032 = NOVALUE;
    int _15031 = NOVALUE;
    int _15030 = NOVALUE;
    int _15029 = NOVALUE;
    int _15028 = NOVALUE;
    int _15027 = NOVALUE;
    int _15026 = NOVALUE;
    int _15025 = NOVALUE;
    int _15024 = NOVALUE;
    int _15023 = NOVALUE;
    int _15022 = NOVALUE;
    int _15021 = NOVALUE;
    int _15020 = NOVALUE;
    int _15019 = NOVALUE;
    int _15018 = NOVALUE;
    int _15017 = NOVALUE;
    int _15016 = NOVALUE;
    int _15015 = NOVALUE;
    int _15014 = NOVALUE;
    int _15013 = NOVALUE;
    int _15012 = NOVALUE;
    int _15011 = NOVALUE;
    int _15010 = NOVALUE;
    int _15009 = NOVALUE;
    int _15008 = NOVALUE;
    int _15007 = NOVALUE;
    int _15006 = NOVALUE;
    int _15005 = NOVALUE;
    int _15004 = NOVALUE;
    int _15003 = NOVALUE;
    int _15002 = NOVALUE;
    int _15001 = NOVALUE;
    int _15000 = NOVALUE;
    int _14999 = NOVALUE;
    int _14998 = NOVALUE;
    int _14997 = NOVALUE;
    int _14996 = NOVALUE;
    int _14995 = NOVALUE;
    int _14994 = NOVALUE;
    int _14993 = NOVALUE;
    int _14992 = NOVALUE;
    int _14991 = NOVALUE;
    int _14990 = NOVALUE;
    int _14989 = NOVALUE;
    int _14988 = NOVALUE;
    int _14987 = NOVALUE;
    int _14986 = NOVALUE;
    int _14985 = NOVALUE;
    int _14984 = NOVALUE;
    int _14983 = NOVALUE;
    int _14982 = NOVALUE;
    int _14981 = NOVALUE;
    int _14980 = NOVALUE;
    int _14979 = NOVALUE;
    int _14978 = NOVALUE;
    int _14977 = NOVALUE;
    int _14976 = NOVALUE;
    int _14975 = NOVALUE;
    int _14974 = NOVALUE;
    int _14973 = NOVALUE;
    int _14972 = NOVALUE;
    int _14971 = NOVALUE;
    int _14970 = NOVALUE;
    int _14969 = NOVALUE;
    int _14968 = NOVALUE;
    int _14967 = NOVALUE;
    int _14966 = NOVALUE;
    int _14965 = NOVALUE;
    int _14964 = NOVALUE;
    int _14963 = NOVALUE;
    int _14962 = NOVALUE;
    int _14961 = NOVALUE;
    int _14960 = NOVALUE;
    int _14959 = NOVALUE;
    int _14958 = NOVALUE;
    int _14957 = NOVALUE;
    int _14956 = NOVALUE;
    int _14955 = NOVALUE;
    int _14954 = NOVALUE;
    int _14953 = NOVALUE;
    int _14952 = NOVALUE;
    int _14951 = NOVALUE;
    int _14950 = NOVALUE;
    int _14949 = NOVALUE;
    int _14948 = NOVALUE;
    int _14947 = NOVALUE;
    int _14946 = NOVALUE;
    int _14945 = NOVALUE;
    int _14944 = NOVALUE;
    int _14943 = NOVALUE;
    int _14942 = NOVALUE;
    int _14941 = NOVALUE;
    int _14939 = NOVALUE;
    int _14938 = NOVALUE;
    int _14937 = NOVALUE;
    int _14936 = NOVALUE;
    int _14935 = NOVALUE;
    int _14934 = NOVALUE;
    int _14933 = NOVALUE;
    int _14932 = NOVALUE;
    int _14931 = NOVALUE;
    int _14930 = NOVALUE;
    int _14929 = NOVALUE;
    int _14928 = NOVALUE;
    int _14927 = NOVALUE;
    int _14926 = NOVALUE;
    int _14925 = NOVALUE;
    int _14924 = NOVALUE;
    int _14923 = NOVALUE;
    int _14922 = NOVALUE;
    int _14921 = NOVALUE;
    int _14920 = NOVALUE;
    int _14919 = NOVALUE;
    int _14918 = NOVALUE;
    int _14917 = NOVALUE;
    int _14916 = NOVALUE;
    int _14915 = NOVALUE;
    int _14914 = NOVALUE;
    int _14913 = NOVALUE;
    int _14911 = NOVALUE;
    int _14910 = NOVALUE;
    int _14909 = NOVALUE;
    int _14908 = NOVALUE;
    int _14907 = NOVALUE;
    int _14906 = NOVALUE;
    int _14905 = NOVALUE;
    int _14904 = NOVALUE;
    int _14903 = NOVALUE;
    int _14902 = NOVALUE;
    int _14901 = NOVALUE;
    int _14900 = NOVALUE;
    int _14899 = NOVALUE;
    int _14898 = NOVALUE;
    int _14897 = NOVALUE;
    int _14896 = NOVALUE;
    int _14895 = NOVALUE;
    int _14894 = NOVALUE;
    int _14893 = NOVALUE;
    int _14892 = NOVALUE;
    int _14891 = NOVALUE;
    int _14890 = NOVALUE;
    int _14889 = NOVALUE;
    int _14888 = NOVALUE;
    int _14887 = NOVALUE;
    int _14886 = NOVALUE;
    int _14885 = NOVALUE;
    int _14884 = NOVALUE;
    int _14883 = NOVALUE;
    int _14882 = NOVALUE;
    int _14881 = NOVALUE;
    int _14880 = NOVALUE;
    int _14879 = NOVALUE;
    int _14878 = NOVALUE;
    int _14877 = NOVALUE;
    int _14876 = NOVALUE;
    int _14875 = NOVALUE;
    int _14874 = NOVALUE;
    int _14873 = NOVALUE;
    int _14872 = NOVALUE;
    int _14871 = NOVALUE;
    int _14870 = NOVALUE;
    int _14869 = NOVALUE;
    int _14868 = NOVALUE;
    int _14867 = NOVALUE;
    int _14866 = NOVALUE;
    int _14865 = NOVALUE;
    int _14864 = NOVALUE;
    int _14863 = NOVALUE;
    int _14862 = NOVALUE;
    int _14861 = NOVALUE;
    int _14860 = NOVALUE;
    int _14859 = NOVALUE;
    int _14858 = NOVALUE;
    int _14857 = NOVALUE;
    int _0, _1, _2;
    

    /** 	op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_64op_info_26268);
    _64op_info_26268 = Repeat(0, 213);

    /** 	op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14857 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 126);
    *(int *)_2 = _14857;
    if( _1 != _14857 ){
    }
    _14857 = NOVALUE;

    /** 	op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14858 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _14858;
    if( _1 != _14858 ){
        DeRef(_1);
    }
    _14858 = NOVALUE;

    /** 	op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14859 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 56);
    _1 = *(int *)_2;
    *(int *)_2 = _14859;
    if( _1 != _14859 ){
        DeRef(_1);
    }
    _14859 = NOVALUE;

    /** 	op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14860 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _14860;
    if( _1 != _14860 ){
        DeRef(_1);
    }
    _14860 = NOVALUE;

    /** 	op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14861 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 73);
    _1 = *(int *)_2;
    *(int *)_2 = _14861;
    if( _1 != _14861 ){
        DeRef(_1);
    }
    _14861 = NOVALUE;

    /** 	op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14862 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _14862;
    if( _1 != _14862 ){
        DeRef(_1);
    }
    _14862 = NOVALUE;

    /** 	op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14863 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 113);
    _1 = *(int *)_2;
    *(int *)_2 = _14863;
    if( _1 != _14863 ){
        DeRef(_1);
    }
    _14863 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14864 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 150);
    _1 = *(int *)_2;
    *(int *)_2 = _14864;
    if( _1 != _14864 ){
        DeRef(_1);
    }
    _14864 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14865 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 149);
    _1 = *(int *)_2;
    *(int *)_2 = _14865;
    if( _1 != _14865 ){
        DeRef(_1);
    }
    _14865 = NOVALUE;

    /** 	op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14866 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _14866;
    if( _1 != _14866 ){
        DeRef(_1);
    }
    _14866 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14867 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _14867;
    if( _1 != _14867 ){
        DeRef(_1);
    }
    _14867 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14868 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 84);
    _1 = *(int *)_2;
    *(int *)_2 = _14868;
    if( _1 != _14868 ){
        DeRef(_1);
    }
    _14868 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14869 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 118);
    _1 = *(int *)_2;
    *(int *)_2 = _14869;
    if( _1 != _14869 ){
        DeRef(_1);
    }
    _14869 = NOVALUE;

    /** 	op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14870 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _14870;
    if( _1 != _14870 ){
        DeRef(_1);
    }
    _14870 = NOVALUE;

    /** 	op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14871 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 129);
    _1 = *(int *)_2;
    *(int *)_2 = _14871;
    if( _1 != _14871 ){
        DeRef(_1);
    }
    _14871 = NOVALUE;

    /** 	op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14872 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 136);
    _1 = *(int *)_2;
    *(int *)_2 = _14872;
    if( _1 != _14872 ){
        DeRef(_1);
    }
    _14872 = NOVALUE;

    /** 	op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14873 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 137);
    _1 = *(int *)_2;
    *(int *)_2 = _14873;
    if( _1 != _14873 ){
        DeRef(_1);
    }
    _14873 = NOVALUE;

    /** 	op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14874 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 186);
    _1 = *(int *)_2;
    *(int *)_2 = _14874;
    if( _1 != _14874 ){
        DeRef(_1);
    }
    _14874 = NOVALUE;

    /** 	op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14875 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 59);
    _1 = *(int *)_2;
    *(int *)_2 = _14875;
    if( _1 != _14875 ){
        DeRef(_1);
    }
    _14875 = NOVALUE;

    /** 	op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14876 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 86);
    _1 = *(int *)_2;
    *(int *)_2 = _14876;
    if( _1 != _14876 ){
        DeRef(_1);
    }
    _14876 = NOVALUE;

    /** 	op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14877 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 100);
    _1 = *(int *)_2;
    *(int *)_2 = _14877;
    if( _1 != _14877 ){
        DeRef(_1);
    }
    _14877 = NOVALUE;

    /** 	op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14878 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 76);
    _1 = *(int *)_2;
    *(int *)_2 = _14878;
    if( _1 != _14878 ){
        DeRef(_1);
    }
    _14878 = NOVALUE;

    /** 	op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14879 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _14879;
    if( _1 != _14879 ){
        DeRef(_1);
    }
    _14879 = NOVALUE;

    /** 	op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14880 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 81);
    _1 = *(int *)_2;
    *(int *)_2 = _14880;
    if( _1 != _14880 ){
        DeRef(_1);
    }
    _14880 = NOVALUE;

    /** 	op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14881 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 210);
    _1 = *(int *)_2;
    *(int *)_2 = _14881;
    if( _1 != _14881 ){
        DeRef(_1);
    }
    _14881 = NOVALUE;

    /** 	op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14882 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 211);
    _1 = *(int *)_2;
    *(int *)_2 = _14882;
    if( _1 != _14882 ){
        DeRef(_1);
    }
    _14882 = NOVALUE;

    /** 	op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_13220);
    *((int *)(_2+20)) = _13220;
    _14883 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 133);
    _1 = *(int *)_2;
    *(int *)_2 = _14883;
    if( _1 != _14883 ){
        DeRef(_1);
    }
    _14883 = NOVALUE;

    /** 	op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 2);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    RefDS(_13220);
    *((int *)(_2+20)) = _13220;
    _14884 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 132);
    _1 = *(int *)_2;
    *(int *)_2 = _14884;
    if( _1 != _14884 ){
        DeRef(_1);
    }
    _14884 = NOVALUE;

    /** 	op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14885 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 69);
    _1 = *(int *)_2;
    *(int *)_2 = _14885;
    if( _1 != _14885 ){
        DeRef(_1);
    }
    _14885 = NOVALUE;

    /** 	op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14886 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 204);
    _1 = *(int *)_2;
    *(int *)_2 = _14886;
    if( _1 != _14886 ){
        DeRef(_1);
    }
    _14886 = NOVALUE;

    /** 	op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14887 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 205);
    _1 = *(int *)_2;
    *(int *)_2 = _14887;
    if( _1 != _14887 ){
        DeRef(_1);
    }
    _14887 = NOVALUE;

    /** 	op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14888 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 98);
    _1 = *(int *)_2;
    *(int *)_2 = _14888;
    if( _1 != _14888 ){
        DeRef(_1);
    }
    _14888 = NOVALUE;

    /** 	op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14889 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _14889;
    if( _1 != _14889 ){
        DeRef(_1);
    }
    _14889 = NOVALUE;

    /** 	op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14890 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _14890;
    if( _1 != _14890 ){
        DeRef(_1);
    }
    _14890 = NOVALUE;

    /** 	op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14891 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 61);
    _1 = *(int *)_2;
    *(int *)_2 = _14891;
    if( _1 != _14891 ){
        DeRef(_1);
    }
    _14891 = NOVALUE;

    /** 	op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14892 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 206);
    _1 = *(int *)_2;
    *(int *)_2 = _14892;
    if( _1 != _14892 ){
        DeRef(_1);
    }
    _14892 = NOVALUE;

    /** 	op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14893 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 22);
    _1 = *(int *)_2;
    *(int *)_2 = _14893;
    if( _1 != _14893 ){
        DeRef(_1);
    }
    _14893 = NOVALUE;

    /** 	op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14894 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 184);
    _1 = *(int *)_2;
    *(int *)_2 = _14894;
    if( _1 != _14894 ){
        DeRef(_1);
    }
    _14894 = NOVALUE;

    /** 	op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14895 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 188);
    _1 = *(int *)_2;
    *(int *)_2 = _14895;
    if( _1 != _14895 ){
        DeRef(_1);
    }
    _14895 = NOVALUE;

    /** 	op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14896 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _14896;
    if( _1 != _14896 ){
        DeRef(_1);
    }
    _14896 = NOVALUE;

    /** 	op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14897 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _14897;
    if( _1 != _14897 ){
        DeRef(_1);
    }
    _14897 = NOVALUE;

    /** 	op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14898 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 50);
    _1 = *(int *)_2;
    *(int *)_2 = _14898;
    if( _1 != _14898 ){
        DeRef(_1);
    }
    _14898 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14899 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _14899;
    if( _1 != _14899 ){
        DeRef(_1);
    }
    _14899 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14900 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _14900;
    if( _1 != _14900 ){
        DeRef(_1);
    }
    _14900 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14901 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 55);
    _1 = *(int *)_2;
    *(int *)_2 = _14901;
    if( _1 != _14901 ){
        DeRef(_1);
    }
    _14901 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14902 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _14902;
    if( _1 != _14902 ){
        DeRef(_1);
    }
    _14902 = NOVALUE;

    /** 	op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14903 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 153);
    _1 = *(int *)_2;
    *(int *)_2 = _14903;
    if( _1 != _14903 ){
        DeRef(_1);
    }
    _14903 = NOVALUE;

    /** 	op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14904 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _14904;
    if( _1 != _14904 ){
        DeRef(_1);
    }
    _14904 = NOVALUE;

    /** 	op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14905 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 104);
    _1 = *(int *)_2;
    *(int *)_2 = _14905;
    if( _1 != _14905 ){
        DeRef(_1);
    }
    _14905 = NOVALUE;

    /** 	op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14906 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 121);
    _1 = *(int *)_2;
    *(int *)_2 = _14906;
    if( _1 != _14906 ){
        DeRef(_1);
    }
    _14906 = NOVALUE;

    /** 	op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14907 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 77);
    _1 = *(int *)_2;
    *(int *)_2 = _14907;
    if( _1 != _14907 ){
        DeRef(_1);
    }
    _14907 = NOVALUE;

    /** 	op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14908 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 176);
    _1 = *(int *)_2;
    *(int *)_2 = _14908;
    if( _1 != _14908 ){
        DeRef(_1);
    }
    _14908 = NOVALUE;

    /** 	op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14909 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 83);
    _1 = *(int *)_2;
    *(int *)_2 = _14909;
    if( _1 != _14909 ){
        DeRef(_1);
    }
    _14909 = NOVALUE;

    /** 	op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14910 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 63);
    _1 = *(int *)_2;
    *(int *)_2 = _14910;
    if( _1 != _14910 ){
        DeRef(_1);
    }
    _14910 = NOVALUE;

    /** 	op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14911 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 66);
    _1 = *(int *)_2;
    *(int *)_2 = _14911;
    if( _1 != _14911 ){
        DeRef(_1);
    }
    _14911 = NOVALUE;

    /** 	op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_14912);
    *((int *)(_2+12)) = _14912;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14913 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 21);
    _1 = *(int *)_2;
    *(int *)_2 = _14913;
    if( _1 != _14913 ){
        DeRef(_1);
    }
    _14913 = NOVALUE;

    /** 	op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_14912);
    *((int *)(_2+12)) = _14912;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14914 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 125);
    _1 = *(int *)_2;
    *(int *)_2 = _14914;
    if( _1 != _14914 ){
        DeRef(_1);
    }
    _14914 = NOVALUE;

    /** 	op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14915 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _14915;
    if( _1 != _14915 ){
        DeRef(_1);
    }
    _14915 = NOVALUE;

    /** 	op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14916 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 91);
    _1 = *(int *)_2;
    *(int *)_2 = _14916;
    if( _1 != _14916 ){
        DeRef(_1);
    }
    _14916 = NOVALUE;

    /** 	op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14917 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _14917;
    if( _1 != _14917 ){
        DeRef(_1);
    }
    _14917 = NOVALUE;

    /** 	op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14918 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 79);
    _1 = *(int *)_2;
    *(int *)_2 = _14918;
    if( _1 != _14918 ){
        DeRef(_1);
    }
    _14918 = NOVALUE;

    /** 	op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12902);
    *((int *)(_2+12)) = _12902;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14919 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 189);
    _1 = *(int *)_2;
    *(int *)_2 = _14919;
    if( _1 != _14919 ){
        DeRef(_1);
    }
    _14919 = NOVALUE;

    /** 	op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14920 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 109);
    _1 = *(int *)_2;
    *(int *)_2 = _14920;
    if( _1 != _14920 ){
        DeRef(_1);
    }
    _14920 = NOVALUE;

    /** 	op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14921 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _14921;
    if( _1 != _14921 ){
        DeRef(_1);
    }
    _14921 = NOVALUE;

    /** 	op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14922 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _14922;
    if( _1 != _14922 ){
        DeRef(_1);
    }
    _14922 = NOVALUE;

    /** 	op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14923 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _14923;
    if( _1 != _14923 ){
        DeRef(_1);
    }
    _14923 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14924 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 103);
    _1 = *(int *)_2;
    *(int *)_2 = _14924;
    if( _1 != _14924 ){
        DeRef(_1);
    }
    _14924 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14925 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 120);
    _1 = *(int *)_2;
    *(int *)_2 = _14925;
    if( _1 != _14925 ){
        DeRef(_1);
    }
    _14925 = NOVALUE;

    /** 	op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14926 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 107);
    _1 = *(int *)_2;
    *(int *)_2 = _14926;
    if( _1 != _14926 ){
        DeRef(_1);
    }
    _14926 = NOVALUE;

    /** 	op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14927 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 124);
    _1 = *(int *)_2;
    *(int *)_2 = _14927;
    if( _1 != _14927 ){
        DeRef(_1);
    }
    _14927 = NOVALUE;

    /** 	op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14928 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 194);
    _1 = *(int *)_2;
    *(int *)_2 = _14928;
    if( _1 != _14928 ){
        DeRef(_1);
    }
    _14928 = NOVALUE;

    /** 	op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14929 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 198);
    _1 = *(int *)_2;
    *(int *)_2 = _14929;
    if( _1 != _14929 ){
        DeRef(_1);
    }
    _14929 = NOVALUE;

    /** 	op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13283);
    *((int *)(_2+12)) = _13283;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14930 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 20);
    _1 = *(int *)_2;
    *(int *)_2 = _14930;
    if( _1 != _14930 ){
        DeRef(_1);
    }
    _14930 = NOVALUE;

    /** 	op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14931 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 191);
    _1 = *(int *)_2;
    *(int *)_2 = _14931;
    if( _1 != _14931 ){
        DeRef(_1);
    }
    _14931 = NOVALUE;

    /** 	op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14932 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _14932;
    if( _1 != _14932 ){
        DeRef(_1);
    }
    _14932 = NOVALUE;

    /** 	op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14933 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _14933;
    if( _1 != _14933 ){
        DeRef(_1);
    }
    _14933 = NOVALUE;

    /** 	op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14934 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _14934;
    if( _1 != _14934 ){
        DeRef(_1);
    }
    _14934 = NOVALUE;

    /** 	op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14935 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 106);
    _1 = *(int *)_2;
    *(int *)_2 = _14935;
    if( _1 != _14935 ){
        DeRef(_1);
    }
    _14935 = NOVALUE;

    /** 	op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14936 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 123);
    _1 = *(int *)_2;
    *(int *)_2 = _14936;
    if( _1 != _14936 ){
        DeRef(_1);
    }
    _14936 = NOVALUE;

    /** 	op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14937 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 102);
    _1 = *(int *)_2;
    *(int *)_2 = _14937;
    if( _1 != _14937 ){
        DeRef(_1);
    }
    _14937 = NOVALUE;

    /** 	op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14938 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 119);
    _1 = *(int *)_2;
    *(int *)_2 = _14938;
    if( _1 != _14938 ){
        DeRef(_1);
    }
    _14938 = NOVALUE;

    /** 	op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14939 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 95);
    _1 = *(int *)_2;
    *(int *)_2 = _14939;
    if( _1 != _14939 ){
        DeRef(_1);
    }
    _14939 = NOVALUE;

    /** 	op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_14940);
    *((int *)(_2+16)) = _14940;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14941 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 161);
    _1 = *(int *)_2;
    *(int *)_2 = _14941;
    if( _1 != _14941 ){
        DeRef(_1);
    }
    _14941 = NOVALUE;

    /** 	op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_14940);
    *((int *)(_2+16)) = _14940;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14942 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 166);
    _1 = *(int *)_2;
    *(int *)_2 = _14942;
    if( _1 != _14942 ){
        DeRef(_1);
    }
    _14942 = NOVALUE;

    /** 	op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14943 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 74);
    _1 = *(int *)_2;
    *(int *)_2 = _14943;
    if( _1 != _14943 ){
        DeRef(_1);
    }
    _14943 = NOVALUE;

    /** 	op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14944 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 111);
    _1 = *(int *)_2;
    *(int *)_2 = _14944;
    if( _1 != _14944 ){
        DeRef(_1);
    }
    _14944 = NOVALUE;

    /** 	op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14945 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 112);
    _1 = *(int *)_2;
    *(int *)_2 = _14945;
    if( _1 != _14945 ){
        DeRef(_1);
    }
    _14945 = NOVALUE;

    /** 	op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14946 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 78);
    _1 = *(int *)_2;
    *(int *)_2 = _14946;
    if( _1 != _14946 ){
        DeRef(_1);
    }
    _14946 = NOVALUE;

    /** 	op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14947 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 177);
    _1 = *(int *)_2;
    *(int *)_2 = _14947;
    if( _1 != _14947 ){
        DeRef(_1);
    }
    _14947 = NOVALUE;

    /** 	op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14948 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 130);
    _1 = *(int *)_2;
    *(int *)_2 = _14948;
    if( _1 != _14948 ){
        DeRef(_1);
    }
    _14948 = NOVALUE;

    /** 	op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14949 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 131);
    _1 = *(int *)_2;
    *(int *)_2 = _14949;
    if( _1 != _14949 ){
        DeRef(_1);
    }
    _14949 = NOVALUE;

    /** 	op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14950 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _14950;
    if( _1 != _14950 ){
        DeRef(_1);
    }
    _14950 = NOVALUE;

    /** 	op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14951 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 116);
    _1 = *(int *)_2;
    *(int *)_2 = _14951;
    if( _1 != _14951 ){
        DeRef(_1);
    }
    _14951 = NOVALUE;

    /** 	op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14952 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _14952;
    if( _1 != _14952 ){
        DeRef(_1);
    }
    _14952 = NOVALUE;

    /** 	op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14953 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 159);
    _1 = *(int *)_2;
    *(int *)_2 = _14953;
    if( _1 != _14953 ){
        DeRef(_1);
    }
    _14953 = NOVALUE;

    /** 	op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14954 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 158);
    _1 = *(int *)_2;
    *(int *)_2 = _14954;
    if( _1 != _14954 ){
        DeRef(_1);
    }
    _14954 = NOVALUE;

    /** 	op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14955 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 110);
    _1 = *(int *)_2;
    *(int *)_2 = _14955;
    if( _1 != _14955 ){
        DeRef(_1);
    }
    _14955 = NOVALUE;

    /** 	op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14956 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 145);
    _1 = *(int *)_2;
    *(int *)_2 = _14956;
    if( _1 != _14956 ){
        DeRef(_1);
    }
    _14956 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14957 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 148);
    _1 = *(int *)_2;
    *(int *)_2 = _14957;
    if( _1 != _14957 ){
        DeRef(_1);
    }
    _14957 = NOVALUE;

    /** 	op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14958 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 155);
    _1 = *(int *)_2;
    *(int *)_2 = _14958;
    if( _1 != _14958 ){
        DeRef(_1);
    }
    _14958 = NOVALUE;

    /** 	op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14959 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 156);
    _1 = *(int *)_2;
    *(int *)_2 = _14959;
    if( _1 != _14959 ){
        DeRef(_1);
    }
    _14959 = NOVALUE;

    /** 	op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14960 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 187);
    _1 = *(int *)_2;
    *(int *)_2 = _14960;
    if( _1 != _14960 ){
        DeRef(_1);
    }
    _14960 = NOVALUE;

    /** 	op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14961 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _14961;
    if( _1 != _14961 ){
        DeRef(_1);
    }
    _14961 = NOVALUE;

    /** 	op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14962 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _14962;
    if( _1 != _14962 ){
        DeRef(_1);
    }
    _14962 = NOVALUE;

    /** 	op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14963 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 105);
    _1 = *(int *)_2;
    *(int *)_2 = _14963;
    if( _1 != _14963 ){
        DeRef(_1);
    }
    _14963 = NOVALUE;

    /** 	op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14964 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 122);
    _1 = *(int *)_2;
    *(int *)_2 = _14964;
    if( _1 != _14964 ){
        DeRef(_1);
    }
    _14964 = NOVALUE;

    /** 	op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14965 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _14965;
    if( _1 != _14965 ){
        DeRef(_1);
    }
    _14965 = NOVALUE;

    /** 	op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13283);
    *((int *)(_2+12)) = _13283;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14966 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 108);
    _1 = *(int *)_2;
    *(int *)_2 = _14966;
    if( _1 != _14966 ){
        DeRef(_1);
    }
    _14966 = NOVALUE;

    /** 	op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14967 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 37);
    _1 = *(int *)_2;
    *(int *)_2 = _14967;
    if( _1 != _14967 ){
        DeRef(_1);
    }
    _14967 = NOVALUE;

    /** 	op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14968 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 183);
    _1 = *(int *)_2;
    *(int *)_2 = _14968;
    if( _1 != _14968 ){
        DeRef(_1);
    }
    _14968 = NOVALUE;

    /** 	op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14969 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _14969;
    if( _1 != _14969 ){
        DeRef(_1);
    }
    _14969 = NOVALUE;

    /** 	op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14970 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _14970;
    if( _1 != _14970 ){
        DeRef(_1);
    }
    _14970 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14971 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 165);
    _1 = *(int *)_2;
    *(int *)_2 = _14971;
    if( _1 != _14971 ){
        DeRef(_1);
    }
    _14971 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14972 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 164);
    _1 = *(int *)_2;
    *(int *)_2 = _14972;
    if( _1 != _14972 ){
        DeRef(_1);
    }
    _14972 = NOVALUE;

    /** 	op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14973 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 163);
    _1 = *(int *)_2;
    *(int *)_2 = _14973;
    if( _1 != _14973 ){
        DeRef(_1);
    }
    _14973 = NOVALUE;

    /** 	op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14974 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 162);
    _1 = *(int *)_2;
    *(int *)_2 = _14974;
    if( _1 != _14974 ){
        DeRef(_1);
    }
    _14974 = NOVALUE;

    /** 	op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14975 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 182);
    _1 = *(int *)_2;
    *(int *)_2 = _14975;
    if( _1 != _14975 ){
        DeRef(_1);
    }
    _14975 = NOVALUE;

    /** 	op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14976 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 180);
    _1 = *(int *)_2;
    *(int *)_2 = _14976;
    if( _1 != _14976 ){
        DeRef(_1);
    }
    _14976 = NOVALUE;

    /** 	op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14977 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 179);
    _1 = *(int *)_2;
    *(int *)_2 = _14977;
    if( _1 != _14977 ){
        DeRef(_1);
    }
    _14977 = NOVALUE;

    /** 	op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14978 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 140);
    _1 = *(int *)_2;
    *(int *)_2 = _14978;
    if( _1 != _14978 ){
        DeRef(_1);
    }
    _14978 = NOVALUE;

    /** 	op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14979 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 139);
    _1 = *(int *)_2;
    *(int *)_2 = _14979;
    if( _1 != _14979 ){
        DeRef(_1);
    }
    _14979 = NOVALUE;

    /** 	op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14980 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 181);
    _1 = *(int *)_2;
    *(int *)_2 = _14980;
    if( _1 != _14980 ){
        DeRef(_1);
    }
    _14980 = NOVALUE;

    /** 	op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14981 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 127);
    _1 = *(int *)_2;
    *(int *)_2 = _14981;
    if( _1 != _14981 ){
        DeRef(_1);
    }
    _14981 = NOVALUE;

    /** 	op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14982 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 160);
    _1 = *(int *)_2;
    *(int *)_2 = _14982;
    if( _1 != _14982 ){
        DeRef(_1);
    }
    _14982 = NOVALUE;

    /** 	op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14983 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _14983;
    if( _1 != _14983 ){
        DeRef(_1);
    }
    _14983 = NOVALUE;

    /** 	op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14984 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 115);
    _1 = *(int *)_2;
    *(int *)_2 = _14984;
    if( _1 != _14984 ){
        DeRef(_1);
    }
    _14984 = NOVALUE;

    /** 	op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14985 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 93);
    _1 = *(int *)_2;
    *(int *)_2 = _14985;
    if( _1 != _14985 ){
        DeRef(_1);
    }
    _14985 = NOVALUE;

    /** 	op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14986 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 117);
    _1 = *(int *)_2;
    *(int *)_2 = _14986;
    if( _1 != _14986 ){
        DeRef(_1);
    }
    _14986 = NOVALUE;

    /** 	op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14987 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 128);
    _1 = *(int *)_2;
    *(int *)_2 = _14987;
    if( _1 != _14987 ){
        DeRef(_1);
    }
    _14987 = NOVALUE;

    /** 	op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14988 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 178);
    _1 = *(int *)_2;
    *(int *)_2 = _14988;
    if( _1 != _14988 ){
        DeRef(_1);
    }
    _14988 = NOVALUE;

    /** 	op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14989 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 138);
    _1 = *(int *)_2;
    *(int *)_2 = _14989;
    if( _1 != _14989 ){
        DeRef(_1);
    }
    _14989 = NOVALUE;

    /** 	op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14990 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 60);
    _1 = *(int *)_2;
    *(int *)_2 = _14990;
    if( _1 != _14990 ){
        DeRef(_1);
    }
    _14990 = NOVALUE;

    /** 	op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14991 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 72);
    _1 = *(int *)_2;
    *(int *)_2 = _14991;
    if( _1 != _14991 ){
        DeRef(_1);
    }
    _14991 = NOVALUE;

    /** 	op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14992 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 57);
    _1 = *(int *)_2;
    *(int *)_2 = _14992;
    if( _1 != _14992 ){
        DeRef(_1);
    }
    _14992 = NOVALUE;

    /** 	op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14993 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _14993;
    if( _1 != _14993 ){
        DeRef(_1);
    }
    _14993 = NOVALUE;

    /** 	op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14994 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _14994;
    if( _1 != _14994 ){
        DeRef(_1);
    }
    _14994 = NOVALUE;

    /** 	op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14995 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 151);
    _1 = *(int *)_2;
    *(int *)_2 = _14995;
    if( _1 != _14995 ){
        DeRef(_1);
    }
    _14995 = NOVALUE;

    /** 	op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14996 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 87);
    _1 = *(int *)_2;
    *(int *)_2 = _14996;
    if( _1 != _14996 ){
        DeRef(_1);
    }
    _14996 = NOVALUE;

    /** 	op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14997 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 88);
    _1 = *(int *)_2;
    *(int *)_2 = _14997;
    if( _1 != _14997 ){
        DeRef(_1);
    }
    _14997 = NOVALUE;

    /** 	op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14998 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 90);
    _1 = *(int *)_2;
    *(int *)_2 = _14998;
    if( _1 != _14998 ){
        DeRef(_1);
    }
    _14998 = NOVALUE;

    /** 	op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14999 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = _14999;
    if( _1 != _14999 ){
        DeRef(_1);
    }
    _14999 = NOVALUE;

    /** 	op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15000 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _15000;
    if( _1 != _15000 ){
        DeRef(_1);
    }
    _15000 = NOVALUE;

    /** 	op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15001 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 62);
    _1 = *(int *)_2;
    *(int *)_2 = _15001;
    if( _1 != _15001 ){
        DeRef(_1);
    }
    _15001 = NOVALUE;

    /** 	op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15002 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 71);
    _1 = *(int *)_2;
    *(int *)_2 = _15002;
    if( _1 != _15002 ){
        DeRef(_1);
    }
    _15002 = NOVALUE;

    /** 	op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15003 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 200);
    _1 = *(int *)_2;
    *(int *)_2 = _15003;
    if( _1 != _15003 ){
        DeRef(_1);
    }
    _15003 = NOVALUE;

    /** 	op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15004 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _15004;
    if( _1 != _15004 ){
        DeRef(_1);
    }
    _15004 = NOVALUE;

    /** 	op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 6;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12931);
    *((int *)(_2+16)) = _12931;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15005 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 201);
    _1 = *(int *)_2;
    *(int *)_2 = _15005;
    if( _1 != _15005 ){
        DeRef(_1);
    }
    _15005 = NOVALUE;

    /** 	op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15006 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _15006;
    if( _1 != _15006 ){
        DeRef(_1);
    }
    _15006 = NOVALUE;

    /** 	op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15007 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _15007;
    if( _1 != _15007 ){
        DeRef(_1);
    }
    _15007 = NOVALUE;

    /** 	op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15008 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _15008;
    if( _1 != _15008 ){
        DeRef(_1);
    }
    _15008 = NOVALUE;

    /** 	op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15009 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = _15009;
    if( _1 != _15009 ){
        DeRef(_1);
    }
    _15009 = NOVALUE;

    /** 	op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15010 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _15010;
    if( _1 != _15010 ){
        DeRef(_1);
    }
    _15010 = NOVALUE;

    /** 	op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15011 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 114);
    _1 = *(int *)_2;
    *(int *)_2 = _15011;
    if( _1 != _15011 ){
        DeRef(_1);
    }
    _15011 = NOVALUE;

    /** 	op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15012 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 92);
    _1 = *(int *)_2;
    *(int *)_2 = _15012;
    if( _1 != _15012 ){
        DeRef(_1);
    }
    _15012 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15013 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 85);
    _1 = *(int *)_2;
    *(int *)_2 = _15013;
    if( _1 != _15013 ){
        DeRef(_1);
    }
    _15013 = NOVALUE;

    /** 	op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _15014 = 6 - _12TRANSLATE_11319;
    _15015 = (_12TRANSLATE_11319 == 0);
    _15016 = 4 + _15015;
    if ((long)((unsigned long)_15016 + (unsigned long)HIGH_BITS) >= 0) 
    _15016 = NewDouble((double)_15016);
    _15015 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _15016;
    _15017 = MAKE_SEQ(_1);
    _15016 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _15014;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _15017;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15018 = MAKE_SEQ(_1);
    _15017 = NOVALUE;
    _15014 = NOVALUE;
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 134);
    _1 = *(int *)_2;
    *(int *)_2 = _15018;
    if( _1 != _15018 ){
        DeRef(_1);
    }
    _15018 = NOVALUE;

    /** 	op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15019 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 144);
    _1 = *(int *)_2;
    *(int *)_2 = _15019;
    if( _1 != _15019 ){
        DeRef(_1);
    }
    _15019 = NOVALUE;

    /** 	op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15020 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 142);
    _1 = *(int *)_2;
    *(int *)_2 = _15020;
    if( _1 != _15020 ){
        DeRef(_1);
    }
    _15020 = NOVALUE;

    /** 	op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15021 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 80);
    _1 = *(int *)_2;
    *(int *)_2 = _15021;
    if( _1 != _15021 ){
        DeRef(_1);
    }
    _15021 = NOVALUE;

    /** 	op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15022 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 75);
    _1 = *(int *)_2;
    *(int *)_2 = _15022;
    if( _1 != _15022 ){
        DeRef(_1);
    }
    _15022 = NOVALUE;

    /** 	op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13443);
    *((int *)(_2+16)) = _13443;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15023 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 190);
    _1 = *(int *)_2;
    *(int *)_2 = _15023;
    if( _1 != _15023 ){
        DeRef(_1);
    }
    _15023 = NOVALUE;

    /** 	op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15024 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = _15024;
    if( _1 != _15024 ){
        DeRef(_1);
    }
    _15024 = NOVALUE;

    /** 	op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15025 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _15025;
    if( _1 != _15025 ){
        DeRef(_1);
    }
    _15025 = NOVALUE;

    /** 	op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15026 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 58);
    _1 = *(int *)_2;
    *(int *)_2 = _15026;
    if( _1 != _15026 ){
        DeRef(_1);
    }
    _15026 = NOVALUE;

    /** 	op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13443);
    *((int *)(_2+12)) = _13443;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15027 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 185);
    _1 = *(int *)_2;
    *(int *)_2 = _15027;
    if( _1 != _15027 ){
        DeRef(_1);
    }
    _15027 = NOVALUE;

    /** 	op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13443);
    *((int *)(_2+12)) = _13443;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15028 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 193);
    _1 = *(int *)_2;
    *(int *)_2 = _15028;
    if( _1 != _15028 ){
        DeRef(_1);
    }
    _15028 = NOVALUE;

    /** 	op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13443);
    *((int *)(_2+12)) = _13443;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15029 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 192);
    _1 = *(int *)_2;
    *(int *)_2 = _15029;
    if( _1 != _15029 ){
        DeRef(_1);
    }
    _15029 = NOVALUE;

    /** 	op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13443);
    *((int *)(_2+12)) = _13443;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15030 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 202);
    _1 = *(int *)_2;
    *(int *)_2 = _15030;
    if( _1 != _15030 ){
        DeRef(_1);
    }
    _15030 = NOVALUE;

    /** 	op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15031 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 99);
    _1 = *(int *)_2;
    *(int *)_2 = _15031;
    if( _1 != _15031 ){
        DeRef(_1);
    }
    _15031 = NOVALUE;

    /** 	op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15032 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 154);
    _1 = *(int *)_2;
    *(int *)_2 = _15032;
    if( _1 != _15032 ){
        DeRef(_1);
    }
    _15032 = NOVALUE;

    /** 	op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15033 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 199);
    _1 = *(int *)_2;
    *(int *)_2 = _15033;
    if( _1 != _15033 ){
        DeRef(_1);
    }
    _15033 = NOVALUE;

    /** 	op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15034 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 82);
    _1 = *(int *)_2;
    *(int *)_2 = _15034;
    if( _1 != _15034 ){
        DeRef(_1);
    }
    _15034 = NOVALUE;

    /** 	op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15035 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 175);
    _1 = *(int *)_2;
    *(int *)_2 = _15035;
    if( _1 != _15035 ){
        DeRef(_1);
    }
    _15035 = NOVALUE;

    /** 	op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15036 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 174);
    _1 = *(int *)_2;
    *(int *)_2 = _15036;
    if( _1 != _15036 ){
        DeRef(_1);
    }
    _15036 = NOVALUE;

    /** 	op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15037 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 167);
    _1 = *(int *)_2;
    *(int *)_2 = _15037;
    if( _1 != _15037 ){
        DeRef(_1);
    }
    _15037 = NOVALUE;

    /** 	op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15038 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 172);
    _1 = *(int *)_2;
    *(int *)_2 = _15038;
    if( _1 != _15038 ){
        DeRef(_1);
    }
    _15038 = NOVALUE;

    /** 	op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15039 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 168);
    _1 = *(int *)_2;
    *(int *)_2 = _15039;
    if( _1 != _15039 ){
        DeRef(_1);
    }
    _15039 = NOVALUE;

    /** 	op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15040 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 170);
    _1 = *(int *)_2;
    *(int *)_2 = _15040;
    if( _1 != _15040 ){
        DeRef(_1);
    }
    _15040 = NOVALUE;

    /** 	op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15041 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 173);
    _1 = *(int *)_2;
    *(int *)_2 = _15041;
    if( _1 != _15041 ){
        DeRef(_1);
    }
    _15041 = NOVALUE;

    /** 	op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15042 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 171);
    _1 = *(int *)_2;
    *(int *)_2 = _15042;
    if( _1 != _15042 ){
        DeRef(_1);
    }
    _15042 = NOVALUE;

    /** 	op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15043 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 169);
    _1 = *(int *)_2;
    *(int *)_2 = _15043;
    if( _1 != _15043 ){
        DeRef(_1);
    }
    _15043 = NOVALUE;

    /** 	op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12902);
    *((int *)(_2+16)) = _12902;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15044 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 70);
    _1 = *(int *)_2;
    *(int *)_2 = _15044;
    if( _1 != _15044 ){
        DeRef(_1);
    }
    _15044 = NOVALUE;

    /** 	op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15045 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 64);
    _1 = *(int *)_2;
    *(int *)_2 = _15045;
    if( _1 != _15045 ){
        DeRef(_1);
    }
    _15045 = NOVALUE;

    /** 	op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15046 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 65);
    _1 = *(int *)_2;
    *(int *)_2 = _15046;
    if( _1 != _15046 ){
        DeRef(_1);
    }
    _15046 = NOVALUE;

    /** 	op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15047 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _15047;
    if( _1 != _15047 ){
        DeRef(_1);
    }
    _15047 = NOVALUE;

    /** 	op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15048 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 89);
    _1 = *(int *)_2;
    *(int *)_2 = _15048;
    if( _1 != _15048 ){
        DeRef(_1);
    }
    _15048 = NOVALUE;

    /** 	op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13283);
    *((int *)(_2+12)) = _13283;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15049 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _15049;
    if( _1 != _15049 ){
        DeRef(_1);
    }
    _15049 = NOVALUE;

    /** 	op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15050 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 152);
    _1 = *(int *)_2;
    *(int *)_2 = _15050;
    if( _1 != _15050 ){
        DeRef(_1);
    }
    _15050 = NOVALUE;

    /** 	op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13220);
    *((int *)(_2+16)) = _13220;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15051 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _15051;
    if( _1 != _15051 ){
        DeRef(_1);
    }
    _15051 = NOVALUE;

    /** 	op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15052 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 197);
    _1 = *(int *)_2;
    *(int *)_2 = _15052;
    if( _1 != _15052 ){
        DeRef(_1);
    }
    _15052 = NOVALUE;

    /** 	sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_26666;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13220);
    *((int *)(_2+12)) = _13220;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _SHORT_CIRCUIT_26666 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26666);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 146);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26666;
    DeRef(_1);

    /** 	op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26666);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 147);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26666;
    DeRef(_1);

    /** 	op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26666);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 141);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26666;
    DeRef(_1);

    /** 	op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26666);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 143);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26666;
    DeRef(_1);

    /** 	op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15054 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 101);
    _1 = *(int *)_2;
    *(int *)_2 = _15054;
    if( _1 != _15054 ){
        DeRef(_1);
    }
    _15054 = NOVALUE;

    /** 	op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15055 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 96);
    _1 = *(int *)_2;
    *(int *)_2 = _15055;
    if( _1 != _15055 ){
        DeRef(_1);
    }
    _15055 = NOVALUE;

    /** 	op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15056 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 97);
    _1 = *(int *)_2;
    *(int *)_2 = _15056;
    if( _1 != _15056 ){
        DeRef(_1);
    }
    _15056 = NOVALUE;

    /** 	op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15057 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 94);
    _1 = *(int *)_2;
    *(int *)_2 = _15057;
    if( _1 != _15057 ){
        DeRef(_1);
    }
    _15057 = NOVALUE;

    /** 	op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15058 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    _1 = *(int *)_2;
    *(int *)_2 = _15058;
    if( _1 != _15058 ){
        DeRef(_1);
    }
    _15058 = NOVALUE;

    /** 	op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15059 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 68);
    _1 = *(int *)_2;
    *(int *)_2 = _15059;
    if( _1 != _15059 ){
        DeRef(_1);
    }
    _15059 = NOVALUE;

    /** 	op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13283);
    *((int *)(_2+16)) = _13283;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15060 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _15060;
    if( _1 != _15060 ){
        DeRef(_1);
    }
    _15060 = NOVALUE;

    /** 	op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15061 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 135);
    _1 = *(int *)_2;
    *(int *)_2 = _15061;
    if( _1 != _15061 ){
        DeRef(_1);
    }
    _15061 = NOVALUE;

    /** 	op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15062 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 207);
    _1 = *(int *)_2;
    *(int *)_2 = _15062;
    if( _1 != _15062 ){
        DeRef(_1);
    }
    _15062 = NOVALUE;

    /** 	op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15063 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 208);
    _1 = *(int *)_2;
    *(int *)_2 = _15063;
    if( _1 != _15063 ){
        DeRef(_1);
    }
    _15063 = NOVALUE;

    /** 	op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15064 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 209);
    _1 = *(int *)_2;
    *(int *)_2 = _15064;
    if( _1 != _15064 ){
        DeRef(_1);
    }
    _15064 = NOVALUE;

    /** 	op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15065 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 195);
    _1 = *(int *)_2;
    *(int *)_2 = _15065;
    if( _1 != _15065 ){
        DeRef(_1);
    }
    _15065 = NOVALUE;

    /** 	op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15066 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 196);
    _1 = *(int *)_2;
    *(int *)_2 = _15066;
    if( _1 != _15066 ){
        DeRef(_1);
    }
    _15066 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15067 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _15067;
    if( _1 != _15067 ){
        DeRef(_1);
    }
    _15067 = NOVALUE;

    /** 	op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15068 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 157);
    _1 = *(int *)_2;
    *(int *)_2 = _15068;
    if( _1 != _15068 ){
        DeRef(_1);
    }
    _15068 = NOVALUE;

    /** 	op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15069 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 27);
    _1 = *(int *)_2;
    *(int *)_2 = _15069;
    if( _1 != _15069 ){
        DeRef(_1);
    }
    _15069 = NOVALUE;

    /** 	op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _15070 = (int)*(((s1_ptr)_2)->base + 27);
    Ref(_15070);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _64op_info_26268 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 203);
    _1 = *(int *)_2;
    *(int *)_2 = _15070;
    if( _1 != _15070 ){
        DeRef(_1);
    }
    _15070 = NOVALUE;

    /** end procedure*/
    DeRefDS(_SHORT_CIRCUIT_26666);
    return;
    ;
}


int _64op_size(int _pc_26709, int _code_26710)
{
    int _op_26713 = NOVALUE;
    int _info_26715 = NOVALUE;
    int _int_26717 = NOVALUE;
    int _15095 = NOVALUE;
    int _15092 = NOVALUE;
    int _15089 = NOVALUE;
    int _15086 = NOVALUE;
    int _15085 = NOVALUE;
    int _15084 = NOVALUE;
    int _15083 = NOVALUE;
    int _15082 = NOVALUE;
    int _15081 = NOVALUE;
    int _15079 = NOVALUE;
    int _15078 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer op = code[pc]*/
    _2 = (int)SEQ_PTR(_code_26710);
    _op_26713 = (int)*(((s1_ptr)_2)->base + _pc_26709);
    if (!IS_ATOM_INT(_op_26713))
    _op_26713 = (long)DBL_PTR(_op_26713)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_26715);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _info_26715 = (int)*(((s1_ptr)_2)->base + _op_26713);
    Ref(_info_26715);

    /** 	integer int = info[OP_SIZE_TYPE]*/
    _2 = (int)SEQ_PTR(_info_26715);
    _int_26717 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_26717))
    _int_26717 = (long)DBL_PTR(_int_26717)->dbl;

    /** 	if int = FIXED_SIZE then*/
    if (_int_26717 != 1)
    goto L1; // [29] 48

    /** 		int = info[OP_SIZE]*/
    _2 = (int)SEQ_PTR(_info_26715);
    _int_26717 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_26717))
    _int_26717 = (long)DBL_PTR(_int_26717)->dbl;

    /** 		return int*/
    DeRefDS(_code_26710);
    DeRefDS(_info_26715);
    return _int_26717;
    goto L2; // [45] 203
L1: 

    /** 		switch op do*/
    _0 = _op_26713;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				info = SymTab[code[pc+1]]*/
        _15078 = _pc_26709 + 1;
        _2 = (int)SEQ_PTR(_code_26710);
        _15079 = (int)*(((s1_ptr)_2)->base + _15078);
        DeRef(_info_26715);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_15079)){
            _info_26715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15079)->dbl));
        }
        else{
            _info_26715 = (int)*(((s1_ptr)_2)->base + _15079);
        }
        Ref(_info_26715);

        /** 				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (int)SEQ_PTR(_info_26715);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
            _15081 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
        }
        else{
            _15081 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
        }
        if (IS_ATOM_INT(_15081)) {
            _15082 = _15081 + 2;
            if ((long)((unsigned long)_15082 + (unsigned long)HIGH_BITS) >= 0) 
            _15082 = NewDouble((double)_15082);
        }
        else {
            _15082 = binary_op(PLUS, _15081, 2);
        }
        _15081 = NOVALUE;
        _2 = (int)SEQ_PTR(_info_26715);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _15083 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _15083 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        if (IS_ATOM_INT(_15083)) {
            _15084 = (_15083 != 27);
        }
        else {
            _15084 = binary_op(NOTEQ, _15083, 27);
        }
        _15083 = NOVALUE;
        if (IS_ATOM_INT(_15082) && IS_ATOM_INT(_15084)) {
            _15085 = _15082 + _15084;
            if ((long)((unsigned long)_15085 + (unsigned long)HIGH_BITS) >= 0) 
            _15085 = NewDouble((double)_15085);
        }
        else {
            _15085 = binary_op(PLUS, _15082, _15084);
        }
        DeRef(_15082);
        _15082 = NOVALUE;
        DeRef(_15084);
        _15084 = NOVALUE;
        DeRefDS(_code_26710);
        DeRefDS(_info_26715);
        _15078 = NOVALUE;
        _15079 = NOVALUE;
        return _15085;
        goto L3; // [111] 196

        /** 			case PROC_FORWARD then*/
        case 195:

        /** 				int = code[pc+2]*/
        _15086 = _pc_26709 + 2;
        _2 = (int)SEQ_PTR(_code_26710);
        _int_26717 = (int)*(((s1_ptr)_2)->base + _15086);
        if (!IS_ATOM_INT(_int_26717))
        _int_26717 = (long)DBL_PTR(_int_26717)->dbl;

        /** 				int += 3*/
        _int_26717 = _int_26717 + 3;
        goto L3; // [133] 196

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				int = code[pc+2]*/
        _15089 = _pc_26709 + 2;
        _2 = (int)SEQ_PTR(_code_26710);
        _int_26717 = (int)*(((s1_ptr)_2)->base + _15089);
        if (!IS_ATOM_INT(_int_26717))
        _int_26717 = (long)DBL_PTR(_int_26717)->dbl;

        /** 				int += 4*/
        _int_26717 = _int_26717 + 4;
        goto L3; // [155] 196

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				int = code[pc+1]*/
        _15092 = _pc_26709 + 1;
        _2 = (int)SEQ_PTR(_code_26710);
        _int_26717 = (int)*(((s1_ptr)_2)->base + _15092);
        if (!IS_ATOM_INT(_int_26717))
        _int_26717 = (long)DBL_PTR(_int_26717)->dbl;

        /** 				int += 3*/
        _int_26717 = _int_26717 + 3;
        goto L3; // [179] 196

        /** 			case else*/
        default:

        /** 				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_26713;
        _15095 = MAKE_SEQ(_1);
        _43InternalErr(269, _15095);
        _15095 = NOVALUE;
    ;}L3: 

    /** 		return int*/
    DeRefDS(_code_26710);
    DeRef(_info_26715);
    DeRef(_15078);
    _15078 = NOVALUE;
    _15079 = NOVALUE;
    DeRef(_15085);
    _15085 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15089);
    _15089 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    return _int_26717;
L2: 
    ;
}


int _64advance(int _pc_26761, int _code_26762)
{
    int _15096 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26761)) {
        _1 = (long)(DBL_PTR(_pc_26761)->dbl);
        DeRefDS(_pc_26761);
        _pc_26761 = _1;
    }

    /** 	pc += op_size( pc, code )*/
    RefDS(_code_26762);
    _15096 = _64op_size(_pc_26761, _code_26762);
    if (IS_ATOM_INT(_15096)) {
        _pc_26761 = _pc_26761 + _15096;
    }
    else {
        _pc_26761 = binary_op(PLUS, _pc_26761, _15096);
    }
    DeRef(_15096);
    _15096 = NOVALUE;
    if (!IS_ATOM_INT(_pc_26761)) {
        _1 = (long)(DBL_PTR(_pc_26761)->dbl);
        DeRefDS(_pc_26761);
        _pc_26761 = _1;
    }

    /** 	return pc*/
    DeRefDS(_code_26762);
    return _pc_26761;
    ;
}


void _64shift_switch(int _pc_26769, int _start_26770, int _amount_26771)
{
    int _addr_26772 = NOVALUE;
    int _jump_26804 = NOVALUE;
    int _15132 = NOVALUE;
    int _15131 = NOVALUE;
    int _15130 = NOVALUE;
    int _15129 = NOVALUE;
    int _15128 = NOVALUE;
    int _15127 = NOVALUE;
    int _15126 = NOVALUE;
    int _15125 = NOVALUE;
    int _15124 = NOVALUE;
    int _15123 = NOVALUE;
    int _15122 = NOVALUE;
    int _15120 = NOVALUE;
    int _15119 = NOVALUE;
    int _15118 = NOVALUE;
    int _15117 = NOVALUE;
    int _15116 = NOVALUE;
    int _15115 = NOVALUE;
    int _15114 = NOVALUE;
    int _15113 = NOVALUE;
    int _15111 = NOVALUE;
    int _15110 = NOVALUE;
    int _15109 = NOVALUE;
    int _15108 = NOVALUE;
    int _15107 = NOVALUE;
    int _15104 = NOVALUE;
    int _15102 = NOVALUE;
    int _15101 = NOVALUE;
    int _15100 = NOVALUE;
    int _15099 = NOVALUE;
    int _15098 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sequence( Code[pc+4] ) then*/
    _15098 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15099 = (int)*(((s1_ptr)_2)->base + _15098);
    _15100 = IS_SEQUENCE(_15099);
    _15099 = NOVALUE;
    if (_15100 == 0)
    {
        _15100 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _15100 = NOVALUE;
    }

    /** 		addr = Code[pc+4][2]*/
    _15101 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15102 = (int)*(((s1_ptr)_2)->base + _15101);
    _2 = (int)SEQ_PTR(_15102);
    _addr_26772 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_26772)){
        _addr_26772 = (long)DBL_PTR(_addr_26772)->dbl;
    }
    _15102 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** 		addr = Code[pc+4]*/
    _15104 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _addr_26772 = (int)*(((s1_ptr)_2)->base + _15104);
    if (!IS_ATOM_INT(_addr_26772)){
        _addr_26772 = (long)DBL_PTR(_addr_26772)->dbl;
    }
L2: 

    /** 	if start < addr then*/
    if (_start_26770 >= _addr_26772)
    goto L3; // [65] 137

    /** 		if sequence( Code[pc+4] ) then*/
    _15107 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15108 = (int)*(((s1_ptr)_2)->base + _15107);
    _15109 = IS_SEQUENCE(_15108);
    _15108 = NOVALUE;
    if (_15109 == 0)
    {
        _15109 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _15109 = NOVALUE;
    }

    /** 			Code[pc+4][2] += amount*/
    _15110 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _3 = (int)(_15110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _15113 = (int)*(((s1_ptr)_2)->base + 2);
    _15111 = NOVALUE;
    if (IS_ATOM_INT(_15113)) {
        _15114 = _15113 + _amount_26771;
        if ((long)((unsigned long)_15114 + (unsigned long)HIGH_BITS) >= 0) 
        _15114 = NewDouble((double)_15114);
    }
    else {
        _15114 = binary_op(PLUS, _15113, _amount_26771);
    }
    _15113 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15114;
    if( _1 != _15114 ){
        DeRef(_1);
    }
    _15114 = NOVALUE;
    _15111 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** 			Code[pc+4] += amount*/
    _15115 = _pc_26769 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15116 = (int)*(((s1_ptr)_2)->base + _15115);
    if (IS_ATOM_INT(_15116)) {
        _15117 = _15116 + _amount_26771;
        if ((long)((unsigned long)_15117 + (unsigned long)HIGH_BITS) >= 0) 
        _15117 = NewDouble((double)_15117);
    }
    else {
        _15117 = binary_op(PLUS, _15116, _amount_26771);
    }
    _15116 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _15115);
    _1 = *(int *)_2;
    *(int *)_2 = _15117;
    if( _1 != _15117 ){
        DeRef(_1);
    }
    _15117 = NOVALUE;
L5: 
L3: 

    /** 	sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _15118 = _pc_26769 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15119 = (int)*(((s1_ptr)_2)->base + _15118);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_15119)){
        _15120 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15119)->dbl));
    }
    else{
        _15120 = (int)*(((s1_ptr)_2)->base + _15119);
    }
    DeRef(_jump_26804);
    _2 = (int)SEQ_PTR(_15120);
    _jump_26804 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_26804);
    _15120 = NOVALUE;

    /** 	for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_26804)){
            _15122 = SEQ_PTR(_jump_26804)->length;
    }
    else {
        _15122 = 1;
    }
    {
        int _i_26813;
        _i_26813 = 1;
L6: 
        if (_i_26813 > _15122){
            goto L7; // [168] 223
        }

        /** 		if start > pc and start < pc + jump[i] then*/
        _15123 = (_start_26770 > _pc_26769);
        if (_15123 == 0) {
            goto L8; // [181] 216
        }
        _2 = (int)SEQ_PTR(_jump_26804);
        _15125 = (int)*(((s1_ptr)_2)->base + _i_26813);
        if (IS_ATOM_INT(_15125)) {
            _15126 = _pc_26769 + _15125;
            if ((long)((unsigned long)_15126 + (unsigned long)HIGH_BITS) >= 0) 
            _15126 = NewDouble((double)_15126);
        }
        else {
            _15126 = binary_op(PLUS, _pc_26769, _15125);
        }
        _15125 = NOVALUE;
        if (IS_ATOM_INT(_15126)) {
            _15127 = (_start_26770 < _15126);
        }
        else {
            _15127 = binary_op(LESS, _start_26770, _15126);
        }
        DeRef(_15126);
        _15126 = NOVALUE;
        if (_15127 == 0) {
            DeRef(_15127);
            _15127 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_15127) && DBL_PTR(_15127)->dbl == 0.0){
                DeRef(_15127);
                _15127 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_15127);
            _15127 = NOVALUE;
        }
        DeRef(_15127);
        _15127 = NOVALUE;

        /** 			jump[i] += amount*/
        _2 = (int)SEQ_PTR(_jump_26804);
        _15128 = (int)*(((s1_ptr)_2)->base + _i_26813);
        if (IS_ATOM_INT(_15128)) {
            _15129 = _15128 + _amount_26771;
            if ((long)((unsigned long)_15129 + (unsigned long)HIGH_BITS) >= 0) 
            _15129 = NewDouble((double)_15129);
        }
        else {
            _15129 = binary_op(PLUS, _15128, _amount_26771);
        }
        _15128 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_26804);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _jump_26804 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_26813);
        _1 = *(int *)_2;
        *(int *)_2 = _15129;
        if( _1 != _15129 ){
            DeRef(_1);
        }
        _15129 = NOVALUE;
L8: 

        /** 	end for*/
        _i_26813 = _i_26813 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** 	SymTab[Code[pc+3]][S_OBJ] = jump*/
    _15130 = _pc_26769 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15131 = (int)*(((s1_ptr)_2)->base + _15130);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_15131))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_15131)->dbl));
    else
    _3 = (int)(_15131 + ((s1_ptr)_2)->base);
    RefDS(_jump_26804);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_26804;
    DeRef(_1);
    _15132 = NOVALUE;

    /** end procedure*/
    DeRefDS(_jump_26804);
    DeRef(_15098);
    _15098 = NOVALUE;
    DeRef(_15101);
    _15101 = NOVALUE;
    DeRef(_15104);
    _15104 = NOVALUE;
    DeRef(_15107);
    _15107 = NOVALUE;
    DeRef(_15110);
    _15110 = NOVALUE;
    DeRef(_15115);
    _15115 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15123);
    _15123 = NOVALUE;
    _15130 = NOVALUE;
    _15131 = NOVALUE;
    return;
    ;
}


void _64shift_addr(int _pc_26832, int _amount_26833, int _start_26834, int _bound_26835)
{
    int _int_26836 = NOVALUE;
    int _15147 = NOVALUE;
    int _15144 = NOVALUE;
    int _15140 = NOVALUE;
    int _15135 = NOVALUE;
    int _15134 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_26832)) {
        _1 = (long)(DBL_PTR(_pc_26832)->dbl);
        DeRefDS(_pc_26832);
        _pc_26832 = _1;
    }

    /** 	if atom( Code[pc] ) then*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15134 = (int)*(((s1_ptr)_2)->base + _pc_26832);
    _15135 = IS_ATOM(_15134);
    _15134 = NOVALUE;
    if (_15135 == 0)
    {
        _15135 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _15135 = NOVALUE;
    }

    /** 		int = Code[pc]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _int_26836 = (int)*(((s1_ptr)_2)->base + _pc_26832);
    if (!IS_ATOM_INT(_int_26836)){
        _int_26836 = (long)DBL_PTR(_int_26836)->dbl;
    }

    /** 		if int >= start then*/
    if (_int_26836 < _start_26834)
    goto L2; // [35] 139

    /** 			if int < bound then*/
    if (_int_26836 >= _bound_26835)
    goto L3; // [41] 56

    /** 				Code[pc] = start*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_26832);
    _1 = *(int *)_2;
    *(int *)_2 = _start_26834;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** 				int += amount*/
    _int_26836 = _int_26836 + _amount_26833;

    /** 				Code[pc] = int*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_26832);
    _1 = *(int *)_2;
    *(int *)_2 = _int_26836;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** 		int = Code[pc][2]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _15140 = (int)*(((s1_ptr)_2)->base + _pc_26832);
    _2 = (int)SEQ_PTR(_15140);
    _int_26836 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_26836)){
        _int_26836 = (long)DBL_PTR(_int_26836)->dbl;
    }
    _15140 = NOVALUE;

    /** 		if int >= start then*/
    if (_int_26836 < _start_26834)
    goto L4; // [91] 138

    /** 			if int < bound then*/
    if (_int_26836 >= _bound_26835)
    goto L5; // [97] 117

    /** 				Code[pc][2] = start*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_26832 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _start_26834;
    DeRef(_1);
    _15144 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** 				int += amount*/
    _int_26836 = _int_26836 + _amount_26833;

    /** 				Code[pc][2] = int*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_26832 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _int_26836;
    DeRef(_1);
    _15147 = NOVALUE;
L6: 
L4: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _64shift(int _start_26869, int _amount_26870, int _bound_26871)
{
    int _int_26874 = NOVALUE;
    int _pc_26887 = NOVALUE;
    int _op_26888 = NOVALUE;
    int _finish_26889 = NOVALUE;
    int _len_26892 = NOVALUE;
    int _addrs_26903 = NOVALUE;
    int _15169 = NOVALUE;
    int _15165 = NOVALUE;
    int _15163 = NOVALUE;
    int _15161 = NOVALUE;
    int _15159 = NOVALUE;
    int _15155 = NOVALUE;
    int _15150 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_26869)) {
        _1 = (long)(DBL_PTR(_start_26869)->dbl);
        DeRefDS(_start_26869);
        _start_26869 = _1;
    }
    if (!IS_ATOM_INT(_amount_26870)) {
        _1 = (long)(DBL_PTR(_amount_26870)->dbl);
        DeRefDS(_amount_26870);
        _amount_26870 = _1;
    }
    if (!IS_ATOM_INT(_bound_26871)) {
        _1 = (long)(DBL_PTR(_bound_26871)->dbl);
        DeRefDS(_bound_26871);
        _bound_26871 = _1;
    }

    /** 	if amount = 0 then*/
    if (_amount_26870 != 0)
    goto L1; // [9] 19

    /** 		return*/
    return;
L1: 

    /** 	integer int*/

    /** 	for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_12LineTable_11772)){
            _15150 = SEQ_PTR(_12LineTable_11772)->length;
    }
    else {
        _15150 = 1;
    }
    {
        int _i_26876;
        _i_26876 = _15150;
L2: 
        if (_i_26876 < 1){
            goto L3; // [28] 84
        }

        /** 		int = LineTable[i]*/
        _2 = (int)SEQ_PTR(_12LineTable_11772);
        _int_26874 = (int)*(((s1_ptr)_2)->base + _i_26876);
        if (!IS_ATOM_INT(_int_26874)){
            _int_26874 = (long)DBL_PTR(_int_26874)->dbl;
        }

        /** 		if int > 0 then*/
        if (_int_26874 <= 0)
        goto L4; // [47] 77

        /** 			if int < start then*/
        if (_int_26874 >= _start_26869)
        goto L5; // [53] 62

        /** 				exit*/
        goto L3; // [59] 84
L5: 

        /** 			int += amount*/
        _int_26874 = _int_26874 + _amount_26870;

        /** 			LineTable[i] = int*/
        _2 = (int)SEQ_PTR(_12LineTable_11772);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _12LineTable_11772 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_26876);
        _1 = *(int *)_2;
        *(int *)_2 = _int_26874;
        DeRef(_1);
L4: 

        /** 	end for*/
        _i_26876 = _i_26876 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** 	integer pc = 1*/
    _pc_26887 = 1;

    /** 	integer op*/

    /** 	integer finish = start + amount - 1*/
    _15155 = _start_26869 + _amount_26870;
    if ((long)((unsigned long)_15155 + (unsigned long)HIGH_BITS) >= 0) 
    _15155 = NewDouble((double)_15155);
    if (IS_ATOM_INT(_15155)) {
        _finish_26889 = _15155 - 1;
    }
    else {
        _finish_26889 = NewDouble(DBL_PTR(_15155)->dbl - (double)1);
    }
    DeRef(_15155);
    _15155 = NOVALUE;
    if (!IS_ATOM_INT(_finish_26889)) {
        _1 = (long)(DBL_PTR(_finish_26889)->dbl);
        DeRefDS(_finish_26889);
        _finish_26889 = _1;
    }

    /** 	integer len = length( Code )*/
    if (IS_SEQUENCE(_12Code_11771)){
            _len_26892 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _len_26892 = 1;
    }

    /** 	while pc <= len do*/
L6: 
    if (_pc_26887 > _len_26892)
    goto L7; // [115] 251

    /** 		if pc < start or pc > finish then*/
    _15159 = (_pc_26887 < _start_26869);
    if (_15159 != 0) {
        goto L8; // [125] 138
    }
    _15161 = (_pc_26887 > _finish_26889);
    if (_15161 == 0)
    {
        DeRef(_15161);
        _15161 = NOVALUE;
        goto L9; // [134] 233
    }
    else{
        DeRef(_15161);
        _15161 = NOVALUE;
    }
L8: 

    /** 			op = Code[pc]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _op_26888 = (int)*(((s1_ptr)_2)->base + _pc_26887);
    if (!IS_ATOM_INT(_op_26888)){
        _op_26888 = (long)DBL_PTR(_op_26888)->dbl;
    }

    /** 			sequence addrs = op_info[op][OP_ADDR]*/
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _15163 = (int)*(((s1_ptr)_2)->base + _op_26888);
    DeRef(_addrs_26903);
    _2 = (int)SEQ_PTR(_15163);
    _addrs_26903 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_addrs_26903);
    _15163 = NOVALUE;

    /** 			for i = 1 to length( addrs ) do*/
    if (IS_SEQUENCE(_addrs_26903)){
            _15165 = SEQ_PTR(_addrs_26903)->length;
    }
    else {
        _15165 = 1;
    }
    {
        int _i_26907;
        _i_26907 = 1;
LA: 
        if (_i_26907 > _15165){
            goto LB; // [167] 232
        }

        /** 				switch op with fallthru do*/
        _0 = _op_26888;
        switch ( _0 ){ 

            /** 					case SWITCH then*/
            case 185:
            case 193:
            case 192:
            case 202:

            /** 						shift_switch( pc, start, amount )*/
            _64shift_switch(_pc_26887, _start_26869, _amount_26870);

            /** 						break*/
            goto LC; // [200] 225

            /** 					case else*/
            default:

            /** 						int = addrs[i]*/
            _2 = (int)SEQ_PTR(_addrs_26903);
            _int_26874 = (int)*(((s1_ptr)_2)->base + _i_26907);
            if (!IS_ATOM_INT(_int_26874))
            _int_26874 = (long)DBL_PTR(_int_26874)->dbl;

            /** 						shift_addr( pc + int, amount, start, bound )*/
            _15169 = _pc_26887 + _int_26874;
            if ((long)((unsigned long)_15169 + (unsigned long)HIGH_BITS) >= 0) 
            _15169 = NewDouble((double)_15169);
            _64shift_addr(_15169, _amount_26870, _start_26869, _bound_26871);
            _15169 = NOVALUE;
        ;}LC: 

        /** 			end for*/
        _i_26907 = _i_26907 + 1;
        goto LA; // [227] 174
LB: 
        ;
    }
L9: 
    DeRef(_addrs_26903);
    _addrs_26903 = NOVALUE;

    /** 		pc = advance( pc )*/
    RefDS(_12Code_11771);
    _pc_26887 = _64advance(_pc_26887, _12Code_11771);
    if (!IS_ATOM_INT(_pc_26887)) {
        _1 = (long)(DBL_PTR(_pc_26887)->dbl);
        DeRefDS(_pc_26887);
        _pc_26887 = _1;
    }

    /** 	end while*/
    goto L6; // [248] 115
L7: 

    /** 	shift_fwd_refs( start, amount )*/
    _29shift_fwd_refs(_start_26869, _amount_26870);

    /** 	move_last_pc( amount )*/
    _37move_last_pc(_amount_26870);

    /** end procedure*/
    DeRef(_15159);
    _15159 = NOVALUE;
    return;
    ;
}


void _64insert_code(int _code_26925, int _index_26926)
{
    int _15172 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_26926)) {
        _1 = (long)(DBL_PTR(_index_26926)->dbl);
        DeRefDS(_index_26926);
        _index_26926 = _1;
    }

    /** 	Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_26926;
        if (insert_pos <= 0) {
            Concat(&_12Code_11771,_code_26925,_12Code_11771);
        }
        else if (insert_pos > SEQ_PTR(_12Code_11771)->length){
            Concat(&_12Code_11771,_12Code_11771,_code_26925);
        }
        else if (IS_SEQUENCE(_code_26925)) {
            if( _12Code_11771 != _12Code_11771 || SEQ_PTR( _12Code_11771 )->ref != 1 ){
                DeRef( _12Code_11771 );
                RefDS( _12Code_11771 );
            }
            assign_space = Add_internal_space( _12Code_11771, insert_pos,((s1_ptr)SEQ_PTR(_code_26925))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_26925), _12Code_11771 == _12Code_11771 );
            _12Code_11771 = MAKE_SEQ( assign_space );
        }
        else {
            if( _12Code_11771 != _12Code_11771 && SEQ_PTR( _12Code_11771 )->ref != 1 ){
                _12Code_11771 = Insert( _12Code_11771, _code_26925, insert_pos);
            }
            else {
                DeRef( _12Code_11771 );
                RefDS( _12Code_11771 );
                _12Code_11771 = Insert( _12Code_11771, _code_26925, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_26925)){
            _15172 = SEQ_PTR(_code_26925)->length;
    }
    else {
        _15172 = 1;
    }
    _64shift(_index_26926, _15172, _index_26926);
    _15172 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_26925);
    return;
    ;
}


void _64replace_code(int _code_26933, int _start_26934, int _finish_26935)
{
    int _15177 = NOVALUE;
    int _15176 = NOVALUE;
    int _15175 = NOVALUE;
    int _15174 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_26934)) {
        _1 = (long)(DBL_PTR(_start_26934)->dbl);
        DeRefDS(_start_26934);
        _start_26934 = _1;
    }
    if (!IS_ATOM_INT(_finish_26935)) {
        _1 = (long)(DBL_PTR(_finish_26935)->dbl);
        DeRefDS(_finish_26935);
        _finish_26935 = _1;
    }

    /** 	Code = replace( Code, code, start, finish )*/
    {
        int p1 = _12Code_11771;
        int p2 = _code_26933;
        int p3 = _start_26934;
        int p4 = _finish_26935;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_12Code_11771;
        Replace( &replace_params );
    }

    /** 	shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_26933)){
            _15174 = SEQ_PTR(_code_26933)->length;
    }
    else {
        _15174 = 1;
    }
    _15175 = _finish_26935 - _start_26934;
    if ((long)((unsigned long)_15175 +(unsigned long) HIGH_BITS) >= 0){
        _15175 = NewDouble((double)_15175);
    }
    if (IS_ATOM_INT(_15175)) {
        _15176 = _15175 + 1;
        if (_15176 > MAXINT){
            _15176 = NewDouble((double)_15176);
        }
    }
    else
    _15176 = binary_op(PLUS, 1, _15175);
    DeRef(_15175);
    _15175 = NOVALUE;
    if (IS_ATOM_INT(_15176)) {
        _15177 = _15174 - _15176;
        if ((long)((unsigned long)_15177 +(unsigned long) HIGH_BITS) >= 0){
            _15177 = NewDouble((double)_15177);
        }
    }
    else {
        _15177 = NewDouble((double)_15174 - DBL_PTR(_15176)->dbl);
    }
    _15174 = NOVALUE;
    DeRef(_15176);
    _15176 = NOVALUE;
    _64shift(_start_26934, _15177, _finish_26935);
    _15177 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_26933);
    return;
    ;
}


int _64current_op(int _pc_26945, int _code_26946)
{
    int _15185 = NOVALUE;
    int _15184 = NOVALUE;
    int _15183 = NOVALUE;
    int _15182 = NOVALUE;
    int _15181 = NOVALUE;
    int _15179 = NOVALUE;
    int _15178 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26945)) {
        _1 = (long)(DBL_PTR(_pc_26945)->dbl);
        DeRefDS(_pc_26945);
        _pc_26945 = _1;
    }

    /** 	if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_26946)){
            _15178 = SEQ_PTR(_code_26946)->length;
    }
    else {
        _15178 = 1;
    }
    _15179 = (_pc_26945 > _15178);
    _15178 = NOVALUE;
    if (_15179 != 0) {
        goto L1; // [14] 27
    }
    _15181 = (_pc_26945 < 1);
    if (_15181 == 0)
    {
        DeRef(_15181);
        _15181 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_15181);
        _15181 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_code_26946);
    DeRef(_15179);
    _15179 = NOVALUE;
    return _5;
L2: 

    /** 	return code[pc..pc-1+op_size( pc, code )]*/
    _15182 = _pc_26945 - 1;
    if ((long)((unsigned long)_15182 +(unsigned long) HIGH_BITS) >= 0){
        _15182 = NewDouble((double)_15182);
    }
    RefDS(_code_26946);
    _15183 = _64op_size(_pc_26945, _code_26946);
    if (IS_ATOM_INT(_15182) && IS_ATOM_INT(_15183)) {
        _15184 = _15182 + _15183;
    }
    else {
        _15184 = binary_op(PLUS, _15182, _15183);
    }
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15183);
    _15183 = NOVALUE;
    rhs_slice_target = (object_ptr)&_15185;
    RHS_Slice(_code_26946, _pc_26945, _15184);
    DeRefDS(_code_26946);
    DeRef(_15179);
    _15179 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    return _15185;
    ;
}


int _64get_ops(int _pc_26960, int _offset_26961, int _num_ops_26962, int _code_26963)
{
    int _sign_26966 = NOVALUE;
    int _ops_26975 = NOVALUE;
    int _opx_26977 = NOVALUE;
    int _15202 = NOVALUE;
    int _15201 = NOVALUE;
    int _15197 = NOVALUE;
    int _15196 = NOVALUE;
    int _15195 = NOVALUE;
    int _15194 = NOVALUE;
    int _15193 = NOVALUE;
    int _15192 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26960)) {
        _1 = (long)(DBL_PTR(_pc_26960)->dbl);
        DeRefDS(_pc_26960);
        _pc_26960 = _1;
    }
    if (!IS_ATOM_INT(_offset_26961)) {
        _1 = (long)(DBL_PTR(_offset_26961)->dbl);
        DeRefDS(_offset_26961);
        _offset_26961 = _1;
    }
    if (!IS_ATOM_INT(_num_ops_26962)) {
        _1 = (long)(DBL_PTR(_num_ops_26962)->dbl);
        DeRefDS(_num_ops_26962);
        _num_ops_26962 = _1;
    }

    /** 	integer sign = offset >= 0*/
    _sign_26966 = (_offset_26961 >= 0);

    /** 	if not sign then*/
    if (_sign_26966 != 0)
    goto L1; // [17] 33

    /** 		offset = -offset*/
    _offset_26961 = - _offset_26961;

    /** 		sign = -1*/
    _sign_26966 = -1;
L1: 

    /** 	while offset do*/
L2: 
    if (_offset_26961 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** 		pc = advance( pc )*/
    RefDS(_12Code_11771);
    _pc_26960 = _64advance(_pc_26960, _12Code_11771);
    if (!IS_ATOM_INT(_pc_26960)) {
        _1 = (long)(DBL_PTR(_pc_26960)->dbl);
        DeRefDS(_pc_26960);
        _pc_26960 = _1;
    }

    /** 		offset -= sign*/
    _offset_26961 = _offset_26961 - _sign_26966;

    /** 	end while*/
    goto L2; // [60] 38
L3: 

    /** 	sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_26975);
    _ops_26975 = Repeat(0, _num_ops_26962);

    /** 	integer opx = 1*/
    _opx_26977 = 1;

    /** 	while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_26962 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_26963)){
            _15193 = SEQ_PTR(_code_26963)->length;
    }
    else {
        _15193 = 1;
    }
    _15194 = (_pc_26960 <= _15193);
    _15193 = NOVALUE;
    if (_15194 == 0)
    {
        DeRef(_15194);
        _15194 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_15194);
        _15194 = NOVALUE;
    }

    /** 		ops[opx] = current_op( pc )*/
    RefDS(_12Code_11771);
    _15195 = _64current_op(_pc_26960, _12Code_11771);
    _2 = (int)SEQ_PTR(_ops_26975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ops_26975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _opx_26977);
    _1 = *(int *)_2;
    *(int *)_2 = _15195;
    if( _1 != _15195 ){
        DeRef(_1);
    }
    _15195 = NOVALUE;

    /** 		pc += length( ops[opx] )*/
    _2 = (int)SEQ_PTR(_ops_26975);
    _15196 = (int)*(((s1_ptr)_2)->base + _opx_26977);
    if (IS_SEQUENCE(_15196)){
            _15197 = SEQ_PTR(_15196)->length;
    }
    else {
        _15197 = 1;
    }
    _15196 = NOVALUE;
    _pc_26960 = _pc_26960 + _15197;
    _15197 = NOVALUE;

    /** 		opx += 1*/
    _opx_26977 = _opx_26977 + 1;

    /** 		num_ops -= 1*/
    _num_ops_26962 = _num_ops_26962 - 1;

    /** 	end while*/
    goto L4; // [134] 79
L5: 

    /** 	if num_ops then*/
    if (_num_ops_26962 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** 		ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_26975)){
            _15201 = SEQ_PTR(_ops_26975)->length;
    }
    else {
        _15201 = 1;
    }
    _15202 = _15201 - _num_ops_26962;
    if ((long)((unsigned long)_15202 +(unsigned long) HIGH_BITS) >= 0){
        _15202 = NewDouble((double)_15202);
    }
    _15201 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_26975)->length;
        int size = (IS_ATOM_INT(_15202)) ? _15202 : (object)(DBL_PTR(_15202)->dbl);
        if (size <= 0){
            DeRef( _ops_26975 );
            _ops_26975 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_26975);
            DeRef(_ops_26975);
            _ops_26975 = _ops_26975;
        }
        else{
            Head(SEQ_PTR(_ops_26975),size+1,&_ops_26975);
        }
    }
    DeRef(_15202);
    _15202 = NOVALUE;
L6: 

    /** 	return ops*/
    DeRefDS(_code_26963);
    _15196 = NOVALUE;
    return _ops_26975;
    ;
}


int _64find_ops(int _pc_26995, int _op_26996, int _code_26997)
{
    int _ops_27000 = NOVALUE;
    int _found_op_27004 = NOVALUE;
    int _15211 = NOVALUE;
    int _15209 = NOVALUE;
    int _15207 = NOVALUE;
    int _15204 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26995)) {
        _1 = (long)(DBL_PTR(_pc_26995)->dbl);
        DeRefDS(_pc_26995);
        _pc_26995 = _1;
    }
    if (!IS_ATOM_INT(_op_26996)) {
        _1 = (long)(DBL_PTR(_op_26996)->dbl);
        DeRefDS(_op_26996);
        _op_26996 = _1;
    }

    /** 	sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_27000);
    _ops_27000 = _5;

    /** 	while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_26997)){
            _15204 = SEQ_PTR(_code_26997)->length;
    }
    else {
        _15204 = 1;
    }
    if (_pc_26995 > _15204)
    goto L2; // [22] 74

    /** 		sequence found_op = current_op( pc )*/
    RefDS(_12Code_11771);
    _0 = _found_op_27004;
    _found_op_27004 = _64current_op(_pc_26995, _12Code_11771);
    DeRef(_0);

    /** 		if found_op[1] = op then*/
    _2 = (int)SEQ_PTR(_found_op_27004);
    _15207 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15207, _op_26996)){
        _15207 = NOVALUE;
        goto L3; // [43] 58
    }
    _15207 = NOVALUE;

    /** 			ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_27004);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pc_26995;
    ((int *)_2)[2] = _found_op_27004;
    _15209 = MAKE_SEQ(_1);
    RefDS(_15209);
    Append(&_ops_27000, _ops_27000, _15209);
    DeRefDS(_15209);
    _15209 = NOVALUE;
L3: 

    /** 		pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_27004)){
            _15211 = SEQ_PTR(_found_op_27004)->length;
    }
    else {
        _15211 = 1;
    }
    _pc_26995 = _pc_26995 + _15211;
    _15211 = NOVALUE;
    DeRefDS(_found_op_27004);
    _found_op_27004 = NOVALUE;

    /** 	end while*/
    goto L1; // [71] 19
L2: 

    /** 	return ops*/
    DeRefDS(_code_26997);
    return _ops_27000;
    ;
}


int _64get_target_sym(int _opseq_27016)
{
    int _op_27020 = NOVALUE;
    int _info_27022 = NOVALUE;
    int _targets_27038 = NOVALUE;
    int _sub_27053 = NOVALUE;
    int _15243 = NOVALUE;
    int _15242 = NOVALUE;
    int _15241 = NOVALUE;
    int _15240 = NOVALUE;
    int _15239 = NOVALUE;
    int _15238 = NOVALUE;
    int _15237 = NOVALUE;
    int _15235 = NOVALUE;
    int _15231 = NOVALUE;
    int _15230 = NOVALUE;
    int _15229 = NOVALUE;
    int _15228 = NOVALUE;
    int _15226 = NOVALUE;
    int _15225 = NOVALUE;
    int _15224 = NOVALUE;
    int _15223 = NOVALUE;
    int _15220 = NOVALUE;
    int _15219 = NOVALUE;
    int _15217 = NOVALUE;
    int _15213 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_27016)){
            _15213 = SEQ_PTR(_opseq_27016)->length;
    }
    else {
        _15213 = 1;
    }
    if (_15213 != 0)
    goto L1; // [8] 18
    _15213 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_opseq_27016);
    DeRef(_info_27022);
    return 0;
L1: 

    /** 	integer op = opseq[1]*/
    _2 = (int)SEQ_PTR(_opseq_27016);
    _op_27020 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_27020))
    _op_27020 = (long)DBL_PTR(_op_27020)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27022);
    _2 = (int)SEQ_PTR(_64op_info_26268);
    _info_27022 = (int)*(((s1_ptr)_2)->base + _op_27020);
    Ref(_info_27022);

    /** 	if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_info_27022);
    _15217 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15217, 1)){
        _15217 = NOVALUE;
        goto L2; // [40] 157
    }
    _15217 = NOVALUE;

    /** 		switch length( info[OP_TARGET] ) do*/
    _2 = (int)SEQ_PTR(_info_27022);
    _15219 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_15219)){
            _15220 = SEQ_PTR(_15219)->length;
    }
    else {
        _15220 = 1;
    }
    _15219 = NOVALUE;
    _0 = _15220;
    _15220 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 0 then*/
        case 0:

        /** 				break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** 			case 1 then*/
        case 1:

        /** 				return opseq[info[OP_TARGET][1]+1]*/
        _2 = (int)SEQ_PTR(_info_27022);
        _15223 = (int)*(((s1_ptr)_2)->base + 4);
        _2 = (int)SEQ_PTR(_15223);
        _15224 = (int)*(((s1_ptr)_2)->base + 1);
        _15223 = NOVALUE;
        if (IS_ATOM_INT(_15224)) {
            _15225 = _15224 + 1;
        }
        else
        _15225 = binary_op(PLUS, 1, _15224);
        _15224 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27016);
        if (!IS_ATOM_INT(_15225)){
            _15226 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15225)->dbl));
        }
        else{
            _15226 = (int)*(((s1_ptr)_2)->base + _15225);
        }
        Ref(_15226);
        DeRefDS(_opseq_27016);
        DeRefDS(_info_27022);
        _15219 = NOVALUE;
        DeRef(_15225);
        _15225 = NOVALUE;
        return _15226;
        goto L3; // [94] 152

        /** 			case else*/
        default:

        /** 				sequence targets = info[OP_TARGET]*/
        DeRef(_targets_27038);
        _2 = (int)SEQ_PTR(_info_27022);
        _targets_27038 = (int)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_27038);

        /** 				for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_27038)){
                _15228 = SEQ_PTR(_targets_27038)->length;
        }
        else {
            _15228 = 1;
        }
        {
            int _i_27041;
            _i_27041 = 1;
L4: 
            if (_i_27041 > _15228){
                goto L5; // [113] 145
            }

            /** 					targets[i] = opseq[targets[i] + 1]*/
            _2 = (int)SEQ_PTR(_targets_27038);
            _15229 = (int)*(((s1_ptr)_2)->base + _i_27041);
            if (IS_ATOM_INT(_15229)) {
                _15230 = _15229 + 1;
            }
            else
            _15230 = binary_op(PLUS, 1, _15229);
            _15229 = NOVALUE;
            _2 = (int)SEQ_PTR(_opseq_27016);
            if (!IS_ATOM_INT(_15230)){
                _15231 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15230)->dbl));
            }
            else{
                _15231 = (int)*(((s1_ptr)_2)->base + _15230);
            }
            Ref(_15231);
            _2 = (int)SEQ_PTR(_targets_27038);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _targets_27038 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_27041);
            _1 = *(int *)_2;
            *(int *)_2 = _15231;
            if( _1 != _15231 ){
                DeRef(_1);
            }
            _15231 = NOVALUE;

            /** 				end for*/
            _i_27041 = _i_27041 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** 				return targets*/
        DeRefDS(_opseq_27016);
        DeRef(_info_27022);
        _15219 = NOVALUE;
        _15226 = NOVALUE;
        DeRef(_15225);
        _15225 = NOVALUE;
        DeRef(_15230);
        _15230 = NOVALUE;
        return _targets_27038;
    ;}L3: 
    DeRef(_targets_27038);
    _targets_27038 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** 		switch op do*/
    _0 = _op_27020;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				symtab_index sub = opseq[2]*/
        _2 = (int)SEQ_PTR(_opseq_27016);
        _sub_27053 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_27053)){
            _sub_27053 = (long)DBL_PTR(_sub_27053)->dbl;
        }

        /** 				if sym_token( sub ) = FUNC then*/
        _15235 = _52sym_token(_sub_27053);
        if (binary_op_a(NOTEQ, _15235, 501)){
            DeRef(_15235);
            _15235 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_15235);
        _15235 = NOVALUE;

        /** 					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27016)){
                _15237 = SEQ_PTR(_opseq_27016)->length;
        }
        else {
            _15237 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27016);
        _15238 = (int)*(((s1_ptr)_2)->base + _15237);
        Ref(_15238);
        DeRefDS(_opseq_27016);
        DeRef(_info_27022);
        _15219 = NOVALUE;
        _15226 = NOVALUE;
        DeRef(_15225);
        _15225 = NOVALUE;
        DeRef(_15230);
        _15230 = NOVALUE;
        return _15238;
L7: 
        goto L8; // [206] 252

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				return opseq[$]*/
        if (IS_SEQUENCE(_opseq_27016)){
                _15239 = SEQ_PTR(_opseq_27016)->length;
        }
        else {
            _15239 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_27016);
        _15240 = (int)*(((s1_ptr)_2)->base + _15239);
        Ref(_15240);
        DeRefDS(_opseq_27016);
        DeRef(_info_27022);
        _15219 = NOVALUE;
        _15226 = NOVALUE;
        DeRef(_15225);
        _15225 = NOVALUE;
        _15238 = NOVALUE;
        DeRef(_15230);
        _15230 = NOVALUE;
        return _15240;
        goto L8; // [225] 252

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				return opseq[opseq[2]+2]*/
        _2 = (int)SEQ_PTR(_opseq_27016);
        _15241 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_15241)) {
            _15242 = _15241 + 2;
        }
        else {
            _15242 = binary_op(PLUS, _15241, 2);
        }
        _15241 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_27016);
        if (!IS_ATOM_INT(_15242)){
            _15243 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15242)->dbl));
        }
        else{
            _15243 = (int)*(((s1_ptr)_2)->base + _15242);
        }
        Ref(_15243);
        DeRefDS(_opseq_27016);
        DeRef(_info_27022);
        _15219 = NOVALUE;
        _15226 = NOVALUE;
        DeRef(_15225);
        _15225 = NOVALUE;
        _15238 = NOVALUE;
        DeRef(_15230);
        _15230 = NOVALUE;
        _15240 = NOVALUE;
        DeRef(_15242);
        _15242 = NOVALUE;
        return _15243;
    ;}L8: 
L6: 

    /** 	return 0*/
    DeRefDS(_opseq_27016);
    DeRef(_info_27022);
    _15219 = NOVALUE;
    _15226 = NOVALUE;
    DeRef(_15225);
    _15225 = NOVALUE;
    _15238 = NOVALUE;
    DeRef(_15230);
    _15230 = NOVALUE;
    _15240 = NOVALUE;
    _15243 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    return 0;
    ;
}



// 0x7080BA44
