// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _8crash(int _fmt_407, int _data_408)
{
    int _msg_409 = NOVALUE;
    int _0, _1, _2;
    

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_409);
    _msg_409 = EPrintf(-9999999, _fmt_407, _data_408);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_409);

    /** end procedure*/
    DeRefDS(_fmt_407);
    DeRef(_data_408);
    DeRefDSi(_msg_409);
    return;
    ;
}


void _8crash_message(int _msg_413)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_413);

    /** end procedure*/
    DeRefDS(_msg_413);
    return;
    ;
}


void _8crash_file(int _file_path_416)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_416);

    /** end procedure*/
    DeRefDS(_file_path_416);
    return;
    ;
}


void _8warning_file(int _file_path_419)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_419);

    /** end procedure*/
    DeRef(_file_path_419);
    return;
    ;
}


void _8crash_routine(int _func_422)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_func_422)) {
        _1 = (long)(DBL_PTR(_func_422)->dbl);
        DeRefDS(_func_422);
        _func_422 = _1;
    }

    /** 	machine_proc(M_CRASH_ROUTINE, func)*/
    machine(66, _func_422);

    /** end procedure*/
    return;
    ;
}



// 0x1C76A100
