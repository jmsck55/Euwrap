// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    int _pause_msg_62860 = NOVALUE;
    int _opts_array_62870 = NOVALUE;
    int _opts_62873 = NOVALUE;
    int _opt_keys_62882 = NOVALUE;
    int _option_w_62884 = NOVALUE;
    int _key_62888 = NOVALUE;
    int _val_62890 = NOVALUE;
    int _31443 = NOVALUE;
    int _31441 = NOVALUE;
    int _31440 = NOVALUE;
    int _31439 = NOVALUE;
    int _31437 = NOVALUE;
    int _31436 = NOVALUE;
    int _31435 = NOVALUE;
    int _31434 = NOVALUE;
    int _31429 = NOVALUE;
    int _31426 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence pause_msg = GetMsgText(278, 0)*/
    RefDS(_21829);
    _0 = _pause_msg_62860;
    _pause_msg_62860 = _44GetMsgText(278, 0, _21829);
    DeRef(_0);

    /** 	Argv = expand_config_options(Argv)*/
    RefDS(_12Argv_11693);
    _0 = _39expand_config_options(_12Argv_11693);
    DeRefDS(_12Argv_11693);
    _12Argv_11693 = _0;

    /** 	Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_11693)){
            _12Argc_11692 = SEQ_PTR(_12Argv_11693)->length;
    }
    else {
        _12Argc_11692 = 1;
    }

    /** 	sequence opts_array = get_options()*/
    _0 = _opts_array_62870;
    _opts_array_62870 = _39get_options();
    DeRef(_0);

    /** 	m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 8;
    RefDS(_pause_msg_62860);
    *((int *)(_2+16)) = _pause_msg_62860;
    _31426 = MAKE_SEQ(_1);
    RefDS(_opts_array_62870);
    RefDS(_12Argv_11693);
    _0 = _opts_62873;
    _opts_62873 = _40cmd_parse(_opts_array_62870, _31426, _12Argv_11693);
    DeRef(_0);
    _31426 = NOVALUE;

    /** 	handle_common_options(opts)*/
    Ref(_opts_62873);
    _39handle_common_options(_opts_62873);

    /** 	sequence opt_keys = map:keys(opts)*/
    Ref(_opts_62873);
    _0 = _opt_keys_62882;
    _opt_keys_62882 = _32keys(_opts_62873, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_62884 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_62882)){
            _31429 = SEQ_PTR(_opt_keys_62882)->length;
    }
    else {
        _31429 = 1;
    }
    {
        int _idx_62886;
        _idx_62886 = 1;
L1: 
        if (_idx_62886 > _31429){
            goto L2; // [84] 188
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_62888);
        _2 = (int)SEQ_PTR(_opt_keys_62882);
        _key_62888 = (int)*(((s1_ptr)_2)->base + _idx_62886);
        Ref(_key_62888);

        /** 		object val = map:get(opts, key)*/
        Ref(_opts_62873);
        RefDS(_key_62888);
        _0 = _val_62890;
        _val_62890 = _32get(_opts_62873, _key_62888, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_62888, _31432);
        switch ( _1 ){ 

            /** 			case "coverage" then*/
            case 1:

            /** 				for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_62890)){
                    _31434 = SEQ_PTR(_val_62890)->length;
            }
            else {
                _31434 = 1;
            }
            {
                int _i_62896;
                _i_62896 = 1;
L3: 
                if (_i_62896 > _31434){
                    goto L4; // [123] 146
                }

                /** 					add_coverage( val[i] )*/
                _2 = (int)SEQ_PTR(_val_62890);
                _31435 = (int)*(((s1_ptr)_2)->base + _i_62896);
                Ref(_31435);
                _49add_coverage(_31435);
                _31435 = NOVALUE;

                /** 				end for*/
                _i_62896 = _i_62896 + 1;
                goto L3; // [141] 130
L4: 
                ;
            }
            goto L5; // [146] 179

            /** 			case "coverage-db" then*/
            case 2:

            /** 				coverage_db( val )*/
            Ref(_val_62890);
            _49coverage_db(_val_62890);
            goto L5; // [157] 179

            /** 			case "coverage-erase" then*/
            case 3:

            /** 				new_coverage_db()*/
            _49new_coverage_db();
            goto L5; // [167] 179

            /** 			case "coverage-exclude" then*/
            case 4:

            /** 				coverage_exclude( val )*/
            Ref(_val_62890);
            _49coverage_exclude(_val_62890);
        ;}L5: 
        DeRef(_key_62888);
        _key_62888 = NOVALUE;
        DeRef(_val_62890);
        _val_62890 = NOVALUE;

        /** 	end for*/
        _idx_62886 = _idx_62886 + 1;
        goto L1; // [183] 91
L2: 
        ;
    }

    /** 	if length(m:get(opts, cmdline:EXTRAS)) = 0 then*/
    Ref(_opts_62873);
    RefDS(_40EXTRAS_15167);
    _31436 = _32get(_opts_62873, _40EXTRAS_15167, 0);
    if (IS_SEQUENCE(_31436)){
            _31437 = SEQ_PTR(_31436)->length;
    }
    else {
        _31437 = 1;
    }
    DeRef(_31436);
    _31436 = NOVALUE;
    if (_31437 != 0)
    goto L6; // [201] 249

    /** 		show_banner()*/
    _39show_banner();

    /** 		ShowMsg(2, 249)*/
    RefDS(_21829);
    _44ShowMsg(2, 249, _21829, 1);

    /** 		if not batch_job and not test_only then*/
    _31439 = (_12batch_job_11695 == 0);
    if (_31439 == 0) {
        goto L7; // [224] 244
    }
    _31441 = (_12test_only_11694 == 0);
    if (_31441 == 0)
    {
        DeRef(_31441);
        _31441 = NOVALUE;
        goto L7; // [234] 244
    }
    else{
        DeRef(_31441);
        _31441 = NOVALUE;
    }

    /** 			maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_62860);
    _41maybe_any_key(_pause_msg_62860, 1);
L7: 

    /** 		abort(1)*/
    UserCleanup(1);
L6: 

    /** 	OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_31442);
    *((int *)(_2+4)) = _31442;
    _31443 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_11756, _12OpDefines_11756, _31443);
    DeRefDS(_31443);
    _31443 = NOVALUE;

    /** 	finalize_command_line(opts)*/
    Ref(_opts_62873);
    _39finalize_command_line(_opts_62873);

    /** end procedure*/
    DeRef(_pause_msg_62860);
    DeRef(_opts_array_62870);
    DeRef(_opts_62873);
    DeRef(_opt_keys_62882);
    _31436 = NOVALUE;
    DeRef(_31439);
    _31439 = NOVALUE;
    return;
    ;
}



// 0xA23F4CA1
