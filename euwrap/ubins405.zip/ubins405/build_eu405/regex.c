// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _50regex(int _o_21180)
{
    int _12262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _12262 = IS_SEQUENCE(_o_21180);
    DeRef(_o_21180);
    return _12262;
    ;
}


int _50new(int _pattern_21220, int _options_21221)
{
    int _12282 = NOVALUE;
    int _12281 = NOVALUE;
    int _12279 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12279 = 0;
    if (_12279 == 0)
    {
        _12279 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12279 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21221 = _21or_all(_options_21221);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21221);
    Ref(_pattern_21220);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21220;
    ((int *)_2)[2] = _options_21221;
    _12281 = MAKE_SEQ(_1);
    _12282 = machine(68, _12281);
    DeRefDS(_12281);
    _12281 = NOVALUE;
    DeRef(_pattern_21220);
    DeRef(_options_21221);
    return _12282;
    ;
}


int _50get_ovector_size(int _ex_21240, int _maxsize_21241)
{
    int _m_21242 = NOVALUE;
    int _12290 = NOVALUE;
    int _12287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21240);
    *((int *)(_2+4)) = _ex_21240;
    _12287 = MAKE_SEQ(_1);
    _m_21242 = machine(97, _12287);
    DeRefDS(_12287);
    _12287 = NOVALUE;
    if (!IS_ATOM_INT(_m_21242)) {
        _1 = (long)(DBL_PTR(_m_21242)->dbl);
        DeRefDS(_m_21242);
        _m_21242 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21242 <= 30)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21240);
    return 30;
L1: 

    /** 	return m+1*/
    _12290 = _m_21242 + 1;
    if (_12290 > MAXINT){
        _12290 = NewDouble((double)_12290);
    }
    DeRef(_ex_21240);
    return _12290;
    ;
}


int _50find(int _re_21250, int _haystack_21252, int _from_21253, int _options_21254, int _size_21255)
{
    int _12297 = NOVALUE;
    int _12296 = NOVALUE;
    int _12295 = NOVALUE;
    int _12292 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21255)) {
        _1 = (long)(DBL_PTR(_size_21255)->dbl);
        DeRefDS(_size_21255);
        _size_21255 = _1;
    }

    /** 	if sequence(options) then */
    _12292 = IS_SEQUENCE(_options_21254);
    if (_12292 == 0)
    {
        _12292 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12292 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21254);
    _0 = _options_21254;
    _options_21254 = _21or_all(_options_21254);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21255 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21255 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21252)){
            _12295 = SEQ_PTR(_haystack_21252)->length;
    }
    else {
        _12295 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21250);
    *((int *)(_2+4)) = _re_21250;
    Ref(_haystack_21252);
    *((int *)(_2+8)) = _haystack_21252;
    *((int *)(_2+12)) = _12295;
    Ref(_options_21254);
    *((int *)(_2+16)) = _options_21254;
    *((int *)(_2+20)) = _from_21253;
    *((int *)(_2+24)) = _size_21255;
    _12296 = MAKE_SEQ(_1);
    _12295 = NOVALUE;
    _12297 = machine(70, _12296);
    DeRefDS(_12296);
    _12296 = NOVALUE;
    DeRef(_re_21250);
    DeRef(_haystack_21252);
    DeRef(_options_21254);
    return _12297;
    ;
}


int _50has_match(int _re_21296, int _haystack_21298, int _from_21299, int _options_21300)
{
    int _12314 = NOVALUE;
    int _12313 = NOVALUE;
    int _12312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21296);
    _12312 = _50get_ovector_size(_re_21296, 30);
    Ref(_re_21296);
    Ref(_haystack_21298);
    _12313 = _50find(_re_21296, _haystack_21298, 1, 0, _12312);
    _12312 = NOVALUE;
    _12314 = IS_SEQUENCE(_12313);
    DeRef(_12313);
    _12313 = NOVALUE;
    DeRef(_re_21296);
    DeRef(_haystack_21298);
    return _12314;
    ;
}


int _50matches(int _re_21330, int _haystack_21332, int _from_21333, int _options_21334)
{
    int _str_offsets_21338 = NOVALUE;
    int _match_data_21340 = NOVALUE;
    int _tmp_21350 = NOVALUE;
    int _12351 = NOVALUE;
    int _12350 = NOVALUE;
    int _12349 = NOVALUE;
    int _12348 = NOVALUE;
    int _12347 = NOVALUE;
    int _12345 = NOVALUE;
    int _12344 = NOVALUE;
    int _12343 = NOVALUE;
    int _12342 = NOVALUE;
    int _12340 = NOVALUE;
    int _12339 = NOVALUE;
    int _12338 = NOVALUE;
    int _12337 = NOVALUE;
    int _12335 = NOVALUE;
    int _12334 = NOVALUE;
    int _12333 = NOVALUE;
    int _12330 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12330 = 0;
    if (_12330 == 0)
    {
        _12330 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12330 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21334 = _21or_all(0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21334)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21334;
             _str_offsets_21338 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21338 = binary_op(AND_BITS, 201326592, _options_21334);
    }
    if (!IS_ATOM_INT(_str_offsets_21338)) {
        _1 = (long)(DBL_PTR(_str_offsets_21338)->dbl);
        DeRefDS(_str_offsets_21338);
        _str_offsets_21338 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12333 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21334) && IS_ATOM_INT(_12333)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21334 & (unsigned long)_12333;
             _12334 = MAKE_UINT(tu);
        }
    }
    else {
        _12334 = binary_op(AND_BITS, _options_21334, _12333);
    }
    DeRef(_12333);
    _12333 = NOVALUE;
    Ref(_re_21330);
    _12335 = _50get_ovector_size(_re_21330, 30);
    Ref(_re_21330);
    Ref(_haystack_21332);
    _0 = _match_data_21340;
    _match_data_21340 = _50find(_re_21330, _haystack_21332, _from_21333, _12334, _12335);
    DeRef(_0);
    _12334 = NOVALUE;
    _12335 = NOVALUE;

    /** 	if atom(match_data) then */
    _12337 = IS_ATOM(_match_data_21340);
    if (_12337 == 0)
    {
        _12337 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12337 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21330);
    DeRef(_haystack_21332);
    DeRef(_options_21334);
    DeRef(_match_data_21340);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21340)){
            _12338 = SEQ_PTR(_match_data_21340)->length;
    }
    else {
        _12338 = 1;
    }
    {
        int _i_21348;
        _i_21348 = 1;
L3: 
        if (_i_21348 > _12338){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21340);
        _12339 = (int)*(((s1_ptr)_2)->base + _i_21348);
        _2 = (int)SEQ_PTR(_12339);
        _12340 = (int)*(((s1_ptr)_2)->base + 1);
        _12339 = NOVALUE;
        if (binary_op_a(NOTEQ, _12340, 0)){
            _12340 = NOVALUE;
            goto L5; // [87] 101
        }
        _12340 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21350);
        _tmp_21350 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21340);
        _12342 = (int)*(((s1_ptr)_2)->base + _i_21348);
        _2 = (int)SEQ_PTR(_12342);
        _12343 = (int)*(((s1_ptr)_2)->base + 1);
        _12342 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21340);
        _12344 = (int)*(((s1_ptr)_2)->base + _i_21348);
        _2 = (int)SEQ_PTR(_12344);
        _12345 = (int)*(((s1_ptr)_2)->base + 2);
        _12344 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21350;
        RHS_Slice(_haystack_21332, _12343, _12345);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21338 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21340);
        _12347 = (int)*(((s1_ptr)_2)->base + _i_21348);
        _2 = (int)SEQ_PTR(_12347);
        _12348 = (int)*(((s1_ptr)_2)->base + 1);
        _12347 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21340);
        _12349 = (int)*(((s1_ptr)_2)->base + _i_21348);
        _2 = (int)SEQ_PTR(_12349);
        _12350 = (int)*(((s1_ptr)_2)->base + 2);
        _12349 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21350);
        *((int *)(_2+4)) = _tmp_21350;
        Ref(_12348);
        *((int *)(_2+8)) = _12348;
        Ref(_12350);
        *((int *)(_2+12)) = _12350;
        _12351 = MAKE_SEQ(_1);
        _12350 = NOVALUE;
        _12348 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21340);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21340 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21348);
        _1 = *(int *)_2;
        *(int *)_2 = _12351;
        if( _1 != _12351 ){
            DeRef(_1);
        }
        _12351 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21350);
        _2 = (int)SEQ_PTR(_match_data_21340);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21340 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21348);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21350;
        DeRef(_1);
L8: 
        DeRef(_tmp_21350);
        _tmp_21350 = NOVALUE;

        /** 	end for*/
        _i_21348 = _i_21348 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21330);
    DeRef(_haystack_21332);
    DeRef(_options_21334);
    _12343 = NOVALUE;
    _12345 = NOVALUE;
    return _match_data_21340;
    ;
}



// 0x78A71DD1
