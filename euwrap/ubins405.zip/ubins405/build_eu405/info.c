// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _31version_major()
{
    int _6437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MAJ_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6437 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_6437);
    return _6437;
    ;
}


int _31version_minor()
{
    int _6438 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MIN_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6438 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6438);
    return _6438;
    ;
}


int _31version_patch()
{
    int _6439 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[PAT_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6439 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_6439);
    return _6439;
    ;
}


int _31version_node(int _full_11855)
{
    int _6446 = NOVALUE;
    int _6445 = NOVALUE;
    int _6444 = NOVALUE;
    int _6443 = NOVALUE;
    int _6442 = NOVALUE;
    int _6441 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6441 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6441)){
            _6442 = SEQ_PTR(_6441)->length;
    }
    else {
        _6442 = 1;
    }
    _6441 = NOVALUE;
    _6443 = (_6442 < 12);
    _6442 = NOVALUE;
    if (_6443 == 0)
    {
        DeRef(_6443);
        _6443 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6443);
        _6443 = NOVALUE;
    }
L1: 

    /** 		return version_info[NODE]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6444 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_6444);
    _6441 = NOVALUE;
    return _6444;
L2: 

    /** 	return version_info[NODE][1..12]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6445 = (int)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_6446;
    RHS_Slice(_6445, 1, 12);
    _6445 = NOVALUE;
    _6441 = NOVALUE;
    _6444 = NOVALUE;
    return _6446;
    ;
}


int _31version_date(int _full_11869)
{
    int _6455 = NOVALUE;
    int _6454 = NOVALUE;
    int _6453 = NOVALUE;
    int _6452 = NOVALUE;
    int _6451 = NOVALUE;
    int _6450 = NOVALUE;
    int _6448 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_11869 != 0) {
        _6448 = 1;
        goto L1; // [5] 15
    }
    _6448 = (_31is_developmental_11825 != 0);
L1: 
    if (_6448 != 0) {
        goto L2; // [15] 37
    }
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6450 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6450)){
            _6451 = SEQ_PTR(_6450)->length;
    }
    else {
        _6451 = 1;
    }
    _6450 = NOVALUE;
    _6452 = (_6451 < 10);
    _6451 = NOVALUE;
    if (_6452 == 0)
    {
        DeRef(_6452);
        _6452 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6452);
        _6452 = NOVALUE;
    }
L2: 

    /** 		return version_info[REVISION_DATE]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6453 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_6453);
    _6450 = NOVALUE;
    return _6453;
L3: 

    /** 	return version_info[REVISION_DATE][1..10]*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6454 = (int)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_6455;
    RHS_Slice(_6454, 1, 10);
    _6454 = NOVALUE;
    _6450 = NOVALUE;
    _6453 = NOVALUE;
    return _6455;
    ;
}


int _31version_string(int _full_11884)
{
    int _version_revision_inlined_version_revision_at_41_11893 = NOVALUE;
    int _6475 = NOVALUE;
    int _6474 = NOVALUE;
    int _6473 = NOVALUE;
    int _6472 = NOVALUE;
    int _6471 = NOVALUE;
    int _6470 = NOVALUE;
    int _6469 = NOVALUE;
    int _6468 = NOVALUE;
    int _6466 = NOVALUE;
    int _6465 = NOVALUE;
    int _6464 = NOVALUE;
    int _6463 = NOVALUE;
    int _6462 = NOVALUE;
    int _6461 = NOVALUE;
    int _6460 = NOVALUE;
    int _6459 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_31is_developmental_11825 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** 		return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6459 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6460 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6461 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6462 = (int)*(((s1_ptr)_2)->base + 4);

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_11893);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _version_revision_inlined_version_revision_at_41_11893 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_11893);
    _6463 = _31version_node(0);
    _6464 = _31version_date(_full_11884);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6459);
    *((int *)(_2+4)) = _6459;
    Ref(_6460);
    *((int *)(_2+8)) = _6460;
    Ref(_6461);
    *((int *)(_2+12)) = _6461;
    Ref(_6462);
    *((int *)(_2+16)) = _6462;
    Ref(_version_revision_inlined_version_revision_at_41_11893);
    *((int *)(_2+20)) = _version_revision_inlined_version_revision_at_41_11893;
    *((int *)(_2+24)) = _6463;
    *((int *)(_2+28)) = _6464;
    _6465 = MAKE_SEQ(_1);
    _6464 = NOVALUE;
    _6463 = NOVALUE;
    _6462 = NOVALUE;
    _6461 = NOVALUE;
    _6460 = NOVALUE;
    _6459 = NOVALUE;
    _6466 = EPrintf(-9999999, _6458, _6465);
    DeRefDS(_6465);
    _6465 = NOVALUE;
    return _6466;
    goto L3; // [77] 132
L2: 

    /** 		return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6468 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6469 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6470 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _6471 = (int)*(((s1_ptr)_2)->base + 4);
    _6472 = _31version_node(0);
    _6473 = _31version_date(_full_11884);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6468);
    *((int *)(_2+4)) = _6468;
    Ref(_6469);
    *((int *)(_2+8)) = _6469;
    Ref(_6470);
    *((int *)(_2+12)) = _6470;
    Ref(_6471);
    *((int *)(_2+16)) = _6471;
    *((int *)(_2+20)) = _6472;
    *((int *)(_2+24)) = _6473;
    _6474 = MAKE_SEQ(_1);
    _6473 = NOVALUE;
    _6472 = NOVALUE;
    _6471 = NOVALUE;
    _6470 = NOVALUE;
    _6469 = NOVALUE;
    _6468 = NOVALUE;
    _6475 = EPrintf(-9999999, _6467, _6474);
    DeRefDS(_6474);
    _6474 = NOVALUE;
    DeRef(_6466);
    _6466 = NOVALUE;
    return _6475;
L3: 
    ;
}


int _31euphoria_copyright()
{
    int _version_string_long_1__tmp_at2_11927 = NOVALUE;
    int _version_string_long_inlined_version_string_long_at_2_11926 = NOVALUE;
    int _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925 = NOVALUE;
    int _6485 = NOVALUE;
    int _6483 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/

    /** 	return version_string(full) & " for " & platform_name()*/
    _0 = _version_string_long_1__tmp_at2_11927;
    _version_string_long_1__tmp_at2_11927 = _31version_string(0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_6246);
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925 = _6246;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925;
        concat_list[1] = _6480;
        concat_list[2] = _version_string_long_1__tmp_at2_11927;
        Concat_N((object_ptr)&_version_string_long_inlined_version_string_long_at_2_11926, concat_list, 3);
    }
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11925 = NOVALUE;
    DeRef(_version_string_long_1__tmp_at2_11927);
    _version_string_long_1__tmp_at2_11927 = NOVALUE;
    Concat((object_ptr)&_6483, _6482, _version_string_long_inlined_version_string_long_at_2_11926);
    RefDS(_6484);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6483;
    ((int *)_2)[2] = _6484;
    _6485 = MAKE_SEQ(_1);
    _6483 = NOVALUE;
    return _6485;
    ;
}


int _31all_copyrights()
{
    int _pcre_copyright_inlined_pcre_copyright_at_5_11940 = NOVALUE;
    int _6490 = NOVALUE;
    int _6489 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _6489 = _31euphoria_copyright();

    /** 	return {*/
    RefDS(_6487);
    RefDS(_6486);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_5_11940);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6486;
    ((int *)_2)[2] = _6487;
    _pcre_copyright_inlined_pcre_copyright_at_5_11940 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_5_11940);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6489;
    ((int *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_5_11940;
    _6490 = MAKE_SEQ(_1);
    _6489 = NOVALUE;
    return _6490;
    ;
}



// 0x60B57A86
