// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _54find_file(int _fname_43925)
{
    int _23281 = NOVALUE;
    int _23280 = NOVALUE;
    int _23279 = NOVALUE;
    int _23278 = NOVALUE;
    int _23276 = NOVALUE;
    int _23275 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(inc_dirs) do*/
    _23275 = 4;
    {
        int _i_43927;
        _i_43927 = 1;
L1: 
        if (_i_43927 > 4){
            goto L2; // [10] 64
        }

        /** 		if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (int)SEQ_PTR(_54inc_dirs_43916);
        _23276 = (int)*(((s1_ptr)_2)->base + _i_43927);
        {
            int concat_list[3];

            concat_list[0] = _fname_43925;
            concat_list[1] = _23277;
            concat_list[2] = _23276;
            Concat_N((object_ptr)&_23278, concat_list, 3);
        }
        _23276 = NOVALUE;
        _23279 = _14file_exists(_23278);
        _23278 = NOVALUE;
        if (_23279 == 0) {
            DeRef(_23279);
            _23279 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23279) && DBL_PTR(_23279)->dbl == 0.0){
                DeRef(_23279);
                _23279 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23279);
            _23279 = NOVALUE;
        }
        DeRef(_23279);
        _23279 = NOVALUE;

        /** 			return inc_dirs[i] & "/" & fname*/
        _2 = (int)SEQ_PTR(_54inc_dirs_43916);
        _23280 = (int)*(((s1_ptr)_2)->base + _i_43927);
        {
            int concat_list[3];

            concat_list[0] = _fname_43925;
            concat_list[1] = _23277;
            concat_list[2] = _23280;
            Concat_N((object_ptr)&_23281, concat_list, 3);
        }
        _23280 = NOVALUE;
        DeRefDS(_fname_43925);
        return _23281;
L3: 

        /** 	end for*/
        _i_43927 = _i_43927 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_43925);
    DeRef(_23281);
    _23281 = NOVALUE;
    return 0;
    ;
}


int _54find_all_includes(int _fname_43939, int _includes_43940)
{
    int _lines_43941 = NOVALUE;
    int _m_43947 = NOVALUE;
    int _full_fname_43952 = NOVALUE;
    int _23294 = NOVALUE;
    int _23292 = NOVALUE;
    int _23290 = NOVALUE;
    int _23289 = NOVALUE;
    int _23287 = NOVALUE;
    int _23286 = NOVALUE;
    int _23284 = NOVALUE;
    int _23283 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence lines = read_lines(fname)*/
    RefDS(_fname_43939);
    _0 = _lines_43941;
    _lines_43941 = _17read_lines(_fname_43939);
    DeRef(_0);

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_43941)){
            _23283 = SEQ_PTR(_lines_43941)->length;
    }
    else {
        _23283 = 1;
    }
    {
        int _i_43945;
        _i_43945 = 1;
L1: 
        if (_i_43945 > _23283){
            goto L2; // [18] 113
        }

        /** 		object m = regex:matches(re_include, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_43941);
        _23284 = (int)*(((s1_ptr)_2)->base + _i_43945);
        Ref(_54re_include_43913);
        Ref(_23284);
        _0 = _m_43947;
        _m_43947 = _50matches(_54re_include_43913, _23284, 1, 0);
        DeRef(_0);
        _23284 = NOVALUE;

        /** 		if sequence(m) then*/
        _23286 = IS_SEQUENCE(_m_43947);
        if (_23286 == 0)
        {
            _23286 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23286 = NOVALUE;
        }

        /** 			object full_fname = find_file(m[3])*/
        _2 = (int)SEQ_PTR(_m_43947);
        _23287 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_23287);
        _0 = _full_fname_43952;
        _full_fname_43952 = _54find_file(_23287);
        DeRef(_0);
        _23287 = NOVALUE;

        /** 			if sequence(full_fname) then*/
        _23289 = IS_SEQUENCE(_full_fname_43952);
        if (_23289 == 0)
        {
            _23289 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23289 = NOVALUE;
        }

        /** 				if eu:find(full_fname, includes) = 0 then*/
        _23290 = find_from(_full_fname_43952, _includes_43940, 1);
        if (_23290 != 0)
        goto L5; // [73] 100

        /** 					includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_full_fname_43952);
        *((int *)(_2+4)) = _full_fname_43952;
        _23292 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_43940, _includes_43940, _23292);
        DeRefDS(_23292);
        _23292 = NOVALUE;

        /** 					includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_43940);
        DeRef(_23294);
        _23294 = _includes_43940;
        Ref(_full_fname_43952);
        _0 = _includes_43940;
        _includes_43940 = _54find_all_includes(_full_fname_43952, _23294);
        DeRefDS(_0);
        _23294 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_43952);
        _full_fname_43952 = NOVALUE;
        DeRef(_m_43947);
        _m_43947 = NOVALUE;

        /** 	end for*/
        _i_43945 = _i_43945 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** 	return includes*/
    DeRefDS(_fname_43939);
    DeRef(_lines_43941);
    return _includes_43940;
    ;
}


int _54quick_has_changed(int _fname_43966)
{
    int _d1_43967 = NOVALUE;
    int _all_files_43977 = NOVALUE;
    int _d2_43983 = NOVALUE;
    int _diff_2__tmp_at88_43993 = NOVALUE;
    int _diff_1__tmp_at88_43992 = NOVALUE;
    int _diff_inlined_diff_at_88_43991 = NOVALUE;
    int _23306 = NOVALUE;
    int _23304 = NOVALUE;
    int _23303 = NOVALUE;
    int _23301 = NOVALUE;
    int _23300 = NOVALUE;
    int _23298 = NOVALUE;
    int _23296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_43966);
    _23296 = _14filebase(_fname_43966);
    {
        int concat_list[3];

        concat_list[0] = _23297;
        concat_list[1] = _23296;
        concat_list[2] = _56output_dir_41360;
        Concat_N((object_ptr)&_23298, concat_list, 3);
    }
    DeRef(_23296);
    _23296 = NOVALUE;
    _0 = _d1_43967;
    _d1_43967 = _14file_timestamp(_23298);
    DeRef(_0);
    _23298 = NOVALUE;

    /** 	if atom(d1) then*/
    _23300 = IS_ATOM(_d1_43967);
    if (_23300 == 0)
    {
        _23300 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23300 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_fname_43966);
    DeRef(_d1_43967);
    DeRef(_all_files_43977);
    return 1;
L1: 

    /** 	sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_43966);
    RefDS(_21829);
    _23301 = _54find_all_includes(_fname_43966, _21829);
    RefDS(_fname_43966);
    Append(&_all_files_43977, _23301, _fname_43966);
    DeRef(_23301);
    _23301 = NOVALUE;

    /** 	for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_43977)){
            _23303 = SEQ_PTR(_all_files_43977)->length;
    }
    else {
        _23303 = 1;
    }
    {
        int _i_43981;
        _i_43981 = 1;
L2: 
        if (_i_43981 > _23303){
            goto L3; // [52] 123
        }

        /** 		object d2 = file_timestamp(all_files[i])*/
        _2 = (int)SEQ_PTR(_all_files_43977);
        _23304 = (int)*(((s1_ptr)_2)->base + _i_43981);
        Ref(_23304);
        _0 = _d2_43983;
        _d2_43983 = _14file_timestamp(_23304);
        DeRef(_0);
        _23304 = NOVALUE;

        /** 		if atom(d2) then*/
        _23306 = IS_ATOM(_d2_43983);
        if (_23306 == 0)
        {
            _23306 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23306 = NOVALUE;
        }

        /** 			return 1*/
        DeRef(_d2_43983);
        DeRefDS(_fname_43966);
        DeRef(_d1_43967);
        DeRefDS(_all_files_43977);
        return 1;
L4: 

        /** 		if datetime:diff(d1, d2) > 0 then*/

        /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_43983);
        _0 = _diff_1__tmp_at88_43992;
        _diff_1__tmp_at88_43992 = _15datetimeToSeconds(_d2_43983);
        DeRef(_0);
        Ref(_d1_43967);
        _0 = _diff_2__tmp_at88_43993;
        _diff_2__tmp_at88_43993 = _15datetimeToSeconds(_d1_43967);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_43991);
        if (IS_ATOM_INT(_diff_1__tmp_at88_43992) && IS_ATOM_INT(_diff_2__tmp_at88_43993)) {
            _diff_inlined_diff_at_88_43991 = _diff_1__tmp_at88_43992 - _diff_2__tmp_at88_43993;
            if ((long)((unsigned long)_diff_inlined_diff_at_88_43991 +(unsigned long) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_43991 = NewDouble((double)_diff_inlined_diff_at_88_43991);
            }
        }
        else {
            _diff_inlined_diff_at_88_43991 = binary_op(MINUS, _diff_1__tmp_at88_43992, _diff_2__tmp_at88_43993);
        }
        DeRef(_diff_1__tmp_at88_43992);
        _diff_1__tmp_at88_43992 = NOVALUE;
        DeRef(_diff_2__tmp_at88_43993);
        _diff_2__tmp_at88_43993 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_43991, 0)){
            goto L5; // [103] 114
        }

        /** 			return 1*/
        DeRef(_d2_43983);
        DeRefDS(_fname_43966);
        DeRef(_d1_43967);
        DeRef(_all_files_43977);
        return 1;
L5: 
        DeRef(_d2_43983);
        _d2_43983 = NOVALUE;

        /** 	end for*/
        _i_43981 = _i_43981 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_43966);
    DeRef(_d1_43967);
    DeRef(_all_files_43977);
    return 0;
    ;
}


void _54update_checksum(int _raw_data_44035)
{
    int _23314 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23314 = calc_hash(_raw_data_44035, -5);
    _0 = _54cfile_check_44019;
    if (IS_ATOM_INT(_54cfile_check_44019) && IS_ATOM_INT(_23314)) {
        {unsigned long tu;
             tu = (unsigned long)_54cfile_check_44019 ^ (unsigned long)_23314;
             _54cfile_check_44019 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_54cfile_check_44019)) {
            temp_d.dbl = (double)_54cfile_check_44019;
            _54cfile_check_44019 = Dxor_bits(&temp_d, DBL_PTR(_23314));
        }
        else {
            if (IS_ATOM_INT(_23314)) {
                temp_d.dbl = (double)_23314;
                _54cfile_check_44019 = Dxor_bits(DBL_PTR(_54cfile_check_44019), &temp_d);
            }
            else
            _54cfile_check_44019 = Dxor_bits(DBL_PTR(_54cfile_check_44019), DBL_PTR(_23314));
        }
    }
    DeRef(_0);
    DeRef(_23314);
    _23314 = NOVALUE;

    /** end procedure*/
    DeRef(_raw_data_44035);
    return;
    ;
}


void _54write_checksum(int _file_44040)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_44040)) {
        _1 = (long)(DBL_PTR(_file_44040)->dbl);
        DeRefDS(_file_44040);
        _file_44040 = _1;
    }

    /** 	printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_44040, _23316, _54cfile_check_44019);

    /** 	cfile_check = 0*/
    DeRef(_54cfile_check_44019);
    _54cfile_check_44019 = 0;

    /** end procedure*/
    return;
    ;
}


int _54adjust_for_command_line_passing(int _long_path_44088)
{
    int _slash_44089 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compiler_type = COMPILER_GCC then*/

    /** 	elsif compiler_type = COMPILER_WATCOM then*/

    /** 		slash = SLASH*/
    _slash_44089 = 47;

    /** 	ifdef UNIX then*/

    /** 		return long_path*/
    return _long_path_44088;
    ;
}


int _54adjust_for_build_file(int _long_path_44098)
{
    int _short_path_44099 = NOVALUE;
    int _23346 = NOVALUE;
    int _23345 = NOVALUE;
    int _23344 = NOVALUE;
    int _23343 = NOVALUE;
    int _23342 = NOVALUE;
    int _23341 = NOVALUE;
    int _0, _1, _2;
    

    /**     object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_44098);
    _0 = _short_path_44099;
    _short_path_44099 = _54adjust_for_command_line_passing(_long_path_44098);
    DeRef(_0);

    /**     if atom(short_path) then*/
    _23341 = IS_ATOM(_short_path_44099);
    if (_23341 == 0)
    {
        _23341 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23341 = NOVALUE;
    }

    /**     	return short_path*/
    DeRefDS(_long_path_44098);
    return _short_path_44099;
L1: 

    /** 	if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23342 = (0 == 1);
    if (_23342 == 0) {
        _23343 = 0;
        goto L2; // [32] 46
    }
    _23344 = (3 != 3);
    _23343 = (_23344 != 0);
L2: 
    if (_23343 == 0) {
        goto L3; // [46] 69
    }
    goto L3; // [53] 69

    /** 		return windows_to_mingw_path(short_path)*/
    Ref(_short_path_44099);
    _23346 = _54windows_to_mingw_path(_short_path_44099);
    DeRefDS(_long_path_44098);
    DeRef(_short_path_44099);
    DeRef(_23342);
    _23342 = NOVALUE;
    DeRef(_23344);
    _23344 = NOVALUE;
    return _23346;
    goto L4; // [66] 76
L3: 

    /** 		return short_path*/
    DeRefDS(_long_path_44098);
    DeRef(_23342);
    _23342 = NOVALUE;
    DeRef(_23344);
    _23344 = NOVALUE;
    DeRef(_23346);
    _23346 = NOVALUE;
    return _short_path_44099;
L4: 
    ;
}


int _54setup_build()
{
    int _c_exe_44114 = NOVALUE;
    int _c_flags_44115 = NOVALUE;
    int _l_exe_44116 = NOVALUE;
    int _l_flags_44117 = NOVALUE;
    int _obj_ext_44118 = NOVALUE;
    int _exe_ext_44119 = NOVALUE;
    int _l_flags_begin_44120 = NOVALUE;
    int _rc_comp_44121 = NOVALUE;
    int _l_names_44122 = NOVALUE;
    int _l_ext_44123 = NOVALUE;
    int _t_slash_44124 = NOVALUE;
    int _eudir_44144 = NOVALUE;
    int _locations_44169 = NOVALUE;
    int _compile_dir_44221 = NOVALUE;
    int _23485 = NOVALUE;
    int _23484 = NOVALUE;
    int _23483 = NOVALUE;
    int _23480 = NOVALUE;
    int _23479 = NOVALUE;
    int _23476 = NOVALUE;
    int _23475 = NOVALUE;
    int _23468 = NOVALUE;
    int _23467 = NOVALUE;
    int _23462 = NOVALUE;
    int _23461 = NOVALUE;
    int _23456 = NOVALUE;
    int _23455 = NOVALUE;
    int _23452 = NOVALUE;
    int _23451 = NOVALUE;
    int _23441 = NOVALUE;
    int _23440 = NOVALUE;
    int _23425 = NOVALUE;
    int _23424 = NOVALUE;
    int _23420 = NOVALUE;
    int _23418 = NOVALUE;
    int _23417 = NOVALUE;
    int _23416 = NOVALUE;
    int _23415 = NOVALUE;
    int _23403 = NOVALUE;
    int _23402 = NOVALUE;
    int _23399 = NOVALUE;
    int _23387 = NOVALUE;
    int _23385 = NOVALUE;
    int _23384 = NOVALUE;
    int _23383 = NOVALUE;
    int _23382 = NOVALUE;
    int _23381 = NOVALUE;
    int _23380 = NOVALUE;
    int _23379 = NOVALUE;
    int _23378 = NOVALUE;
    int _23377 = NOVALUE;
    int _23376 = NOVALUE;
    int _23371 = NOVALUE;
    int _23368 = NOVALUE;
    int _23367 = NOVALUE;
    int _23366 = NOVALUE;
    int _23363 = NOVALUE;
    int _23362 = NOVALUE;
    int _23361 = NOVALUE;
    int _23358 = NOVALUE;
    int _23354 = NOVALUE;
    int _23347 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence c_exe   = "", c_flags = "", l_exe   = "", l_flags = "", obj_ext = "",*/
    RefDS(_21829);
    DeRefi(_c_exe_44114);
    _c_exe_44114 = _21829;
    RefDS(_21829);
    DeRef(_c_flags_44115);
    _c_flags_44115 = _21829;
    RefDS(_21829);
    DeRefi(_l_exe_44116);
    _l_exe_44116 = _21829;
    RefDS(_21829);
    DeRefi(_l_flags_44117);
    _l_flags_44117 = _21829;
    RefDS(_21829);
    DeRefi(_obj_ext_44118);
    _obj_ext_44118 = _21829;

    /** 		exe_ext = "", l_flags_begin = "", rc_comp = "", l_names, l_ext, t_slash*/
    RefDS(_21829);
    DeRefi(_exe_ext_44119);
    _exe_ext_44119 = _21829;
    RefDS(_21829);
    DeRefi(_l_flags_begin_44120);
    _l_flags_begin_44120 = _21829;
    RefDS(_21829);
    DeRef(_rc_comp_44121);
    _rc_comp_44121 = _21829;

    /** 	if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_56user_library_41359)){
            _23347 = SEQ_PTR(_56user_library_41359)->length;
    }
    else {
        _23347 = 1;
    }
    if (_23347 != 0)
    goto L1; // [52] 347

    /** 		if debug_option then*/
    if (_56debug_option_41357 == 0)
    {
        goto L2; // [60] 72
    }
    else{
    }

    /** 			l_names = { "eudbg", "eu" }*/
    RefDS(_23350);
    RefDS(_23349);
    DeRef(_l_names_44122);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23349;
    ((int *)_2)[2] = _23350;
    _l_names_44122 = MAKE_SEQ(_1);
    goto L3; // [69] 79
L2: 

    /** 			l_names = { "eu", "eudbg" }*/
    RefDS(_23349);
    RefDS(_23350);
    DeRef(_l_names_44122);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23350;
    ((int *)_2)[2] = _23349;
    _l_names_44122 = MAKE_SEQ(_1);
L3: 

    /** 		if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_36TUNIX_14009 != 0) {
        goto L4; // [83] 98
    }
    _23354 = (0 == 1);
    if (_23354 == 0)
    {
        DeRef(_23354);
        _23354 = NOVALUE;
        goto L5; // [94] 115
    }
    else{
        DeRef(_23354);
        _23354 = NOVALUE;
    }
L4: 

    /** 			l_ext = "a"*/
    RefDS(_22067);
    DeRefi(_l_ext_44123);
    _l_ext_44123 = _22067;

    /** 			t_slash = "/"*/
    RefDS(_23277);
    DeRefi(_t_slash_44124);
    _t_slash_44124 = _23277;
    goto L6; // [112] 138
L5: 

    /** 		elsif TWINDOWS then*/
L6: 

    /** 		object eudir = get_eucompiledir()*/
    _0 = _eudir_44144;
    _eudir_44144 = _56get_eucompiledir();
    DeRef(_0);

    /** 		if not file_exists(eudir) then*/
    Ref(_eudir_44144);
    _23358 = _14file_exists(_eudir_44144);
    if (IS_ATOM_INT(_23358)) {
        if (_23358 != 0){
            DeRef(_23358);
            _23358 = NOVALUE;
            goto L7; // [149] 170
        }
    }
    else {
        if (DBL_PTR(_23358)->dbl != 0.0){
            DeRef(_23358);
            _23358 = NOVALUE;
            goto L7; // [149] 170
        }
    }
    DeRef(_23358);
    _23358 = NOVALUE;

    /** 			printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23361 = _56get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23361;
    _23362 = MAKE_SEQ(_1);
    _23361 = NOVALUE;
    EPrintf(2, _23360, _23362);
    DeRefDS(_23362);
    _23362 = NOVALUE;

    /** 			abort(1)*/
    UserCleanup(1);
L7: 

    /** 		for tk = 1 to length(l_names) label "translation kind" do*/
    _23363 = 2;
    {
        int _tk_44156;
        _tk_44156 = 1;
L8: 
        if (_tk_44156 > 2){
            goto L9; // [177] 346
        }

        /** 			user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (int)SEQ_PTR(_l_names_44122);
        _23366 = (int)*(((s1_ptr)_2)->base + _tk_44156);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        RefDSn(_t_slash_44124, 2);
        *((int *)(_2+4)) = _t_slash_44124;
        *((int *)(_2+8)) = _t_slash_44124;
        RefDS(_23366);
        *((int *)(_2+12)) = _23366;
        RefDS(_l_ext_44123);
        *((int *)(_2+16)) = _l_ext_44123;
        _23367 = MAKE_SEQ(_1);
        _23366 = NOVALUE;
        _23368 = EPrintf(-9999999, _23365, _23367);
        DeRefDS(_23367);
        _23367 = NOVALUE;
        if (IS_SEQUENCE(_eudir_44144) && IS_ATOM(_23368)) {
        }
        else if (IS_ATOM(_eudir_44144) && IS_SEQUENCE(_23368)) {
            Ref(_eudir_44144);
            Prepend(&_56user_library_41359, _23368, _eudir_44144);
        }
        else {
            Concat((object_ptr)&_56user_library_41359, _eudir_44144, _23368);
        }
        DeRefDS(_23368);
        _23368 = NOVALUE;

        /** 			if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_36TUNIX_14009 != 0) {
            goto LA; // [215] 230
        }
        _23371 = (0 == 1);
        if (_23371 == 0)
        {
            DeRef(_23371);
            _23371 = NOVALUE;
            goto LB; // [226] 321
        }
        else{
            DeRef(_23371);
            _23371 = NOVALUE;
        }
LA: 

        /** 				ifdef UNIX then*/

        /** 					sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23373);
        RefDS(_23372);
        DeRef(_locations_44169);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23372;
        ((int *)_2)[2] = _23373;
        _locations_44169 = MAKE_SEQ(_1);

        /** 					if match( "/share/euphoria", eudir ) then*/
        _23376 = e_match_from(_23375, _eudir_44144, 1);
        if (_23376 == 0)
        {
            _23376 = NOVALUE;
            goto LC; // [245] 320
        }
        else{
            _23376 = NOVALUE;
        }

        /** 						for i = 1 to length(locations) do*/
        _23377 = 2;
        {
            int _i_44177;
            _i_44177 = 1;
LD: 
            if (_i_44177 > 2){
                goto LE; // [253] 319
            }

            /** 							if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (int)SEQ_PTR(_locations_44169);
            _23378 = (int)*(((s1_ptr)_2)->base + _i_44177);
            _2 = (int)SEQ_PTR(_l_names_44122);
            _23379 = (int)*(((s1_ptr)_2)->base + _tk_44156);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_23379);
            *((int *)(_2+4)) = _23379;
            _23380 = MAKE_SEQ(_1);
            _23379 = NOVALUE;
            _23381 = EPrintf(-9999999, _23378, _23380);
            _23378 = NOVALUE;
            DeRefDS(_23380);
            _23380 = NOVALUE;
            _23382 = _14file_exists(_23381);
            _23381 = NOVALUE;
            if (_23382 == 0) {
                DeRef(_23382);
                _23382 = NOVALUE;
                goto LF; // [282] 312
            }
            else {
                if (!IS_ATOM_INT(_23382) && DBL_PTR(_23382)->dbl == 0.0){
                    DeRef(_23382);
                    _23382 = NOVALUE;
                    goto LF; // [282] 312
                }
                DeRef(_23382);
                _23382 = NOVALUE;
            }
            DeRef(_23382);
            _23382 = NOVALUE;

            /** 								user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (int)SEQ_PTR(_locations_44169);
            _23383 = (int)*(((s1_ptr)_2)->base + _i_44177);
            _2 = (int)SEQ_PTR(_l_names_44122);
            _23384 = (int)*(((s1_ptr)_2)->base + _tk_44156);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_23384);
            *((int *)(_2+4)) = _23384;
            _23385 = MAKE_SEQ(_1);
            _23384 = NOVALUE;
            DeRef(_56user_library_41359);
            _56user_library_41359 = EPrintf(-9999999, _23383, _23385);
            _23383 = NOVALUE;
            DeRefDS(_23385);
            _23385 = NOVALUE;

            /** 								exit "translation kind"*/
            DeRefDS(_locations_44169);
            _locations_44169 = NOVALUE;
            goto L9; // [309] 346
LF: 

            /** 						end for*/
            _i_44177 = _i_44177 + 1;
            goto LD; // [314] 260
LE: 
            ;
        }
LC: 
LB: 
        DeRef(_locations_44169);
        _locations_44169 = NOVALUE;

        /** 			if file_exists(user_library) then*/
        RefDS(_56user_library_41359);
        _23387 = _14file_exists(_56user_library_41359);
        if (_23387 == 0) {
            DeRef(_23387);
            _23387 = NOVALUE;
            goto L10; // [331] 339
        }
        else {
            if (!IS_ATOM_INT(_23387) && DBL_PTR(_23387)->dbl == 0.0){
                DeRef(_23387);
                _23387 = NOVALUE;
                goto L10; // [331] 339
            }
            DeRef(_23387);
            _23387 = NOVALUE;
        }
        DeRef(_23387);
        _23387 = NOVALUE;

        /** 				exit "translation kind"*/
        goto L9; // [336] 346
L10: 

        /** 		end for -- tk*/
        _tk_44156 = _tk_44156 + 1;
        goto L8; // [341] 184
L9: 
        ;
    }
L1: 
    DeRef(_eudir_44144);
    _eudir_44144 = NOVALUE;

    /** 	user_library = adjust_for_build_file(user_library)*/
    RefDS(_56user_library_41359);
    _0 = _54adjust_for_build_file(_56user_library_41359);
    DeRefDS(_56user_library_41359);
    _56user_library_41359 = _0;

    /** 	if TWINDOWS then*/

    /** 	elsif TOSX then*/

    /** 		if dll_option then*/
    if (_56dll_option_41347 == 0)
    {
        goto L11; // [447] 458
    }
    else{
    }

    /** 			exe_ext = ".so"*/
    RefDS(_23397);
    DeRefi(_exe_ext_44119);
    _exe_ext_44119 = _23397;
L11: 

    /** 	object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_44221;
    _compile_dir_44221 = _56get_eucompiledir();
    DeRef(_0);

    /** 	if not file_exists(compile_dir) then*/
    Ref(_compile_dir_44221);
    _23399 = _14file_exists(_compile_dir_44221);
    if (IS_ATOM_INT(_23399)) {
        if (_23399 != 0){
            DeRef(_23399);
            _23399 = NOVALUE;
            goto L12; // [470] 491
        }
    }
    else {
        if (DBL_PTR(_23399)->dbl != 0.0){
            DeRef(_23399);
            _23399 = NOVALUE;
            goto L12; // [470] 491
        }
    }
    DeRef(_23399);
    _23399 = NOVALUE;

    /** 		printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23402 = _56get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23402;
    _23403 = MAKE_SEQ(_1);
    _23402 = NOVALUE;
    EPrintf(2, _23401, _23403);
    DeRefDS(_23403);
    _23403 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L12: 

    /** 	switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			c_exe = "gcc"*/
        RefDS(_23406);
        DeRefi(_c_exe_44114);
        _c_exe_44114 = _23406;

        /** 			l_exe = "gcc"*/
        RefDS(_23406);
        DeRefi(_l_exe_44116);
        _l_exe_44116 = _23406;

        /** 			obj_ext = "o"*/
        RefDS(_23407);
        DeRefi(_obj_ext_44118);
        _obj_ext_44118 = _23407;

        /** 			if debug_option then*/
        if (_56debug_option_41357 == 0)
        {
            goto L13; // [529] 541
        }
        else{
        }

        /** 				c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23408);
        goto L14; // [538] 548
L13: 

        /** 				c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23410);
L14: 

        /** 			if dll_option then*/
        if (_56dll_option_41347 == 0)
        {
            goto L15; // [552] 562
        }
        else{
        }

        /** 				c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23412);
L15: 

        /** 			c_flags &= sprintf(" -c -w -fsigned-char -O2 -m32 -I%s -ffast-math",*/
        _23415 = _56get_eucompiledir();
        _23416 = _54adjust_for_build_file(_23415);
        _23415 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23416;
        _23417 = MAKE_SEQ(_1);
        _23416 = NOVALUE;
        _23418 = EPrintf(-9999999, _23414, _23417);
        DeRefDS(_23417);
        _23417 = NOVALUE;
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23418);
        DeRefDS(_23418);
        _23418 = NOVALUE;

        /** 			if TWINDOWS and mno_cygwin then*/
        if (0 == 0) {
            goto L16; // [587] 604
        }
        goto L16; // [594] 604

        /** 				c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23421);
L16: 

        /** 			l_flags = sprintf( "%s -m32 ", { adjust_for_build_file(user_library) })*/
        RefDS(_56user_library_41359);
        _23424 = _54adjust_for_build_file(_56user_library_41359);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23424;
        _23425 = MAKE_SEQ(_1);
        _23424 = NOVALUE;
        DeRefi(_l_flags_44117);
        _l_flags_44117 = EPrintf(-9999999, _23423, _23425);
        DeRefDS(_23425);
        _23425 = NOVALUE;

        /** 			if dll_option then*/
        if (_56dll_option_41347 == 0)
        {
            goto L17; // [624] 634
        }
        else{
        }

        /** 				l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23427);
L17: 

        /** 			if TLINUX then*/
        if (_36TLINUX_14007 == 0)
        {
            goto L18; // [638] 650
        }
        else{
        }

        /** 				l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23429);
        goto L19; // [647] 719
L18: 

        /** 			elsif TBSD then*/

        /** 			elsif TOSX then*/

        /** 			elsif TWINDOWS then*/
L19: 

        /** 			rc_comp = "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23440 = _14current_dir();
        _23441 = _54adjust_for_build_file(_23440);
        _23440 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23442;
            concat_list[1] = _23441;
            concat_list[2] = _23439;
            Concat_N((object_ptr)&_rc_comp_44121, concat_list, 3);
        }
        DeRef(_23441);
        _23441 = NOVALUE;
        goto L1A; // [734] 933

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			c_exe = "wcc386"*/
        RefDS(_23444);
        DeRefi(_c_exe_44114);
        _c_exe_44114 = _23444;

        /** 			l_exe = "wlink"*/
        RefDS(_23445);
        DeRefi(_l_exe_44116);
        _l_exe_44116 = _23445;

        /** 			obj_ext = "obj"*/
        RefDS(_23446);
        DeRefi(_obj_ext_44118);
        _obj_ext_44118 = _23446;

        /** 			if debug_option then*/
        if (_56debug_option_41357 == 0)
        {
            goto L1B; // [765] 782
        }
        else{
        }

        /** 				c_flags = " /d3"*/
        RefDS(_23447);
        DeRef(_c_flags_44115);
        _c_flags_44115 = _23447;

        /** 				l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_44120, _l_flags_begin_44120, _23448);
L1B: 

        /** 			l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _56total_stack_size_41361;
        _23451 = MAKE_SEQ(_1);
        _23452 = EPrintf(-9999999, _23450, _23451);
        DeRefDS(_23451);
        _23451 = NOVALUE;
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23452);
        DeRefDS(_23452);
        _23452 = NOVALUE;

        /** 			l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _56total_stack_size_41361;
        _23455 = MAKE_SEQ(_1);
        _23456 = EPrintf(-9999999, _23454, _23455);
        DeRefDS(_23455);
        _23455 = NOVALUE;
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23456);
        DeRefDS(_23456);
        _23456 = NOVALUE;

        /** 			l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23458);

        /** 			if dll_option then*/
        if (_56dll_option_41347 == 0)
        {
            goto L1C; // [824] 850
        }
        else{
        }

        /** 				c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_44221);
        _23461 = _54adjust_for_build_file(_compile_dir_44221);
        if (IS_SEQUENCE(_23460) && IS_ATOM(_23461)) {
            Ref(_23461);
            Append(&_23462, _23460, _23461);
        }
        else if (IS_ATOM(_23460) && IS_SEQUENCE(_23461)) {
        }
        else {
            Concat((object_ptr)&_23462, _23460, _23461);
        }
        DeRef(_23461);
        _23461 = NOVALUE;
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23462);
        DeRefDS(_23462);
        _23462 = NOVALUE;

        /** 				l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23464);
        goto L1D; // [847] 888
L1C: 

        /** 				c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_44221);
        _23467 = _54adjust_for_build_file(_compile_dir_44221);
        if (IS_SEQUENCE(_23466) && IS_ATOM(_23467)) {
            Ref(_23467);
            Append(&_23468, _23466, _23467);
        }
        else if (IS_ATOM(_23466) && IS_SEQUENCE(_23467)) {
        }
        else {
            Concat((object_ptr)&_23468, _23466, _23467);
        }
        DeRef(_23467);
        _23467 = NOVALUE;
        Concat((object_ptr)&_c_flags_44115, _c_flags_44115, _23468);
        DeRefDS(_23468);
        _23468 = NOVALUE;

        /** 				if con_option then*/
        if (_56con_option_41349 == 0)
        {
            goto L1E; // [868] 880
        }
        else{
        }

        /** 					l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_44117, _23470, _l_flags_44117);
        goto L1F; // [877] 887
L1E: 

        /** 					l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_44117, _23472, _l_flags_44117);
L1F: 
L1D: 

        /** 			l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56user_library_41359);
        *((int *)(_2+4)) = _56user_library_41359;
        _23475 = MAKE_SEQ(_1);
        _23476 = EPrintf(-9999999, _23474, _23475);
        DeRefDS(_23475);
        _23475 = NOVALUE;
        Concat((object_ptr)&_l_flags_44117, _l_flags_44117, _23476);
        DeRefDS(_23476);
        _23476 = NOVALUE;

        /** 			rc_comp = "wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23479 = _14current_dir();
        _23480 = _54adjust_for_build_file(_23479);
        _23479 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23481;
            concat_list[1] = _23480;
            concat_list[2] = _23478;
            Concat_N((object_ptr)&_rc_comp_44121, concat_list, 3);
        }
        DeRef(_23480);
        _23480 = NOVALUE;
        goto L1A; // [919] 933

        /** 		case else*/
        default:

        /** 			CompileErr(43)*/
        RefDS(_21829);
        _43CompileErr(43, _21829, 0);
    ;}L1A: 

    /** 	if length(cflags) then*/
    _23483 = 0;

    /** 	if length(lflags) then*/
    _23484 = 0;

    /** 	return { */
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_c_exe_44114);
    *((int *)(_2+4)) = _c_exe_44114;
    RefDS(_c_flags_44115);
    *((int *)(_2+8)) = _c_flags_44115;
    RefDS(_l_exe_44116);
    *((int *)(_2+12)) = _l_exe_44116;
    RefDS(_l_flags_44117);
    *((int *)(_2+16)) = _l_flags_44117;
    RefDS(_obj_ext_44118);
    *((int *)(_2+20)) = _obj_ext_44118;
    RefDS(_exe_ext_44119);
    *((int *)(_2+24)) = _exe_ext_44119;
    RefDS(_l_flags_begin_44120);
    *((int *)(_2+28)) = _l_flags_begin_44120;
    RefDS(_rc_comp_44121);
    *((int *)(_2+32)) = _rc_comp_44121;
    _23485 = MAKE_SEQ(_1);
    DeRefDSi(_c_exe_44114);
    DeRefDS(_c_flags_44115);
    DeRefDSi(_l_exe_44116);
    DeRefDSi(_l_flags_44117);
    DeRefDSi(_obj_ext_44118);
    DeRefDSi(_exe_ext_44119);
    DeRefDSi(_l_flags_begin_44120);
    DeRefDS(_rc_comp_44121);
    DeRef(_l_names_44122);
    DeRefi(_l_ext_44123);
    DeRefi(_t_slash_44124);
    DeRef(_compile_dir_44221);
    return _23485;
    ;
}


void _54ensure_exename(int _ext_44357)
{
    int _23492 = NOVALUE;
    int _23491 = NOVALUE;
    int _23490 = NOVALUE;
    int _23489 = NOVALUE;
    int _23487 = NOVALUE;
    int _23486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23486 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23486)){
            _23487 = SEQ_PTR(_23486)->length;
    }
    else {
        _23487 = 1;
    }
    _23486 = NOVALUE;
    if (_23487 != 0)
    goto L1; // [16] 67

    /** 		exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23489 = _14current_dir();
    {
        int concat_list[4];

        concat_list[0] = _ext_44357;
        concat_list[1] = _56file0_43185;
        concat_list[2] = 47;
        concat_list[3] = _23489;
        Concat_N((object_ptr)&_23490, concat_list, 4);
    }
    DeRef(_23489);
    _23489 = NOVALUE;
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23490;
    if( _1 != _23490 ){
        DeRef(_1);
    }
    _23490 = NOVALUE;

    /** 		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23491 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23491);
    _23492 = _54adjust_for_command_line_passing(_23491);
    _23491 = NOVALUE;
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _23492;
    if( _1 != _23492 ){
        DeRef(_1);
    }
    _23492 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDS(_ext_44357);
    _23486 = NOVALUE;
    return;
    ;
}


void _54write_objlink_file()
{
    int _settings_44375 = NOVALUE;
    int _fh_44377 = NOVALUE;
    int _s_44425 = NOVALUE;
    int _23541 = NOVALUE;
    int _23539 = NOVALUE;
    int _23538 = NOVALUE;
    int _23537 = NOVALUE;
    int _23536 = NOVALUE;
    int _23535 = NOVALUE;
    int _23534 = NOVALUE;
    int _23533 = NOVALUE;
    int _23532 = NOVALUE;
    int _23531 = NOVALUE;
    int _23530 = NOVALUE;
    int _23529 = NOVALUE;
    int _23528 = NOVALUE;
    int _23526 = NOVALUE;
    int _23525 = NOVALUE;
    int _23524 = NOVALUE;
    int _23523 = NOVALUE;
    int _23521 = NOVALUE;
    int _23520 = NOVALUE;
    int _23519 = NOVALUE;
    int _23518 = NOVALUE;
    int _23517 = NOVALUE;
    int _23516 = NOVALUE;
    int _23510 = NOVALUE;
    int _23509 = NOVALUE;
    int _23506 = NOVALUE;
    int _23505 = NOVALUE;
    int _23504 = NOVALUE;
    int _23503 = NOVALUE;
    int _23502 = NOVALUE;
    int _23500 = NOVALUE;
    int _23499 = NOVALUE;
    int _23498 = NOVALUE;
    int _23495 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44375;
    _settings_44375 = _54setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23494;
        concat_list[1] = _56file0_43185;
        concat_list[2] = _56output_dir_41360;
        Concat_N((object_ptr)&_23495, concat_list, 3);
    }
    _fh_44377 = EOpen(_23495, _23496, 0);
    DeRefDS(_23495);
    _23495 = NOVALUE;

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44375);
    _23498 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23498);
    _54ensure_exename(_23498);
    _23498 = NOVALUE;

    /** 	if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (int)SEQ_PTR(_settings_44375);
    _23499 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23499)){
            _23500 = SEQ_PTR(_23499)->length;
    }
    else {
        _23500 = 1;
    }
    _23499 = NOVALUE;
    if (_23500 <= 0)
    goto L1; // [43] 63

    /** 		puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (int)SEQ_PTR(_settings_44375);
    _23502 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23502) && IS_ATOM(_36HOSTNL_14020)) {
    }
    else if (IS_ATOM(_23502) && IS_SEQUENCE(_36HOSTNL_14020)) {
        Ref(_23502);
        Prepend(&_23503, _36HOSTNL_14020, _23502);
    }
    else {
        Concat((object_ptr)&_23503, _23502, _36HOSTNL_14020);
        _23502 = NOVALUE;
    }
    _23502 = NOVALUE;
    EPuts(_fh_44377, _23503); // DJP 
    DeRefDS(_23503);
    _23503 = NOVALUE;
L1: 

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23504 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23504 = 1;
    }
    {
        int _i_44393;
        _i_44393 = 1;
L2: 
        if (_i_44393 > _23504){
            goto L3; // [70] 132
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23505 = (int)*(((s1_ptr)_2)->base + _i_44393);
        _23506 = e_match_from(_22869, _23505, 1);
        _23505 = NOVALUE;
        if (_23506 == 0)
        {
            _23506 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23506 = NOVALUE;
        }

        /** 			if compiler_type = COMPILER_WATCOM then*/

        /** 			puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23509 = (int)*(((s1_ptr)_2)->base + _i_44393);
        Concat((object_ptr)&_23510, _23509, _36HOSTNL_14020);
        _23509 = NOVALUE;
        _23509 = NOVALUE;
        EPuts(_fh_44377, _23510); // DJP 
        DeRefDS(_23510);
        _23510 = NOVALUE;
L4: 

        /** 	end for*/
        _i_44393 = _i_44393 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 	puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (int)SEQ_PTR(_settings_44375);
    _23516 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23516) && IS_ATOM(_36HOSTNL_14020)) {
    }
    else if (IS_ATOM(_23516) && IS_SEQUENCE(_36HOSTNL_14020)) {
        Ref(_23516);
        Prepend(&_23517, _36HOSTNL_14020, _23516);
    }
    else {
        Concat((object_ptr)&_23517, _23516, _36HOSTNL_14020);
        _23516 = NOVALUE;
    }
    _23516 = NOVALUE;
    RefDS(_2965);
    _23518 = _18trim(_23517, _2965, 0);
    _23517 = NOVALUE;
    EPuts(_fh_44377, _23518); // DJP 
    DeRef(_23518);
    _23518 = NOVALUE;

    /** 	if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23519 = (0 == 2);
    if (_23519 == 0) {
        goto L5; // [194] 361
    }
    if (_56dll_option_41347 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44377, _36HOSTNL_14020); // DJP 

    /** 		object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23521 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    DeRef(_s_44425);
    _2 = (int)SEQ_PTR(_23521);
    _s_44425 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44425);
    _23521 = NOVALUE;

    /** 		while s do*/
L6: 
    if (_s_44425 <= 0) {
        if (_s_44425 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_44425) && DBL_PTR(_s_44425)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** 			if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23523 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23523 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    _2 = (int)SEQ_PTR(_23523);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _23524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _23524 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _23523 = NOVALUE;
    _23525 = find_from(_23524, _28RTN_TOKS_11302, 1);
    _23524 = NOVALUE;
    if (_23525 == 0)
    {
        _23525 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _23525 = NOVALUE;
    }

    /** 				if is_exported( s ) then*/
    Ref(_s_44425);
    _23526 = _56is_exported(_s_44425);
    if (_23526 == 0) {
        DeRef(_23526);
        _23526 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23526) && DBL_PTR(_23526)->dbl == 0.0){
            DeRef(_23526);
            _23526 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_23526);
        _23526 = NOVALUE;
    }
    DeRef(_23526);
    _23526 = NOVALUE;

    /** 					printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23528, _23527, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23529 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23529 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    _2 = (int)SEQ_PTR(_23529);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _23530 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _23530 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _23529 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23531 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23531 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    _2 = (int)SEQ_PTR(_23531);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _23532 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _23532 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _23531 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23533 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23533 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    _2 = (int)SEQ_PTR(_23533);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _23534 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _23534 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _23533 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23535 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23535 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    _2 = (int)SEQ_PTR(_23535);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _23536 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _23536 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _23535 = NOVALUE;
    if (IS_ATOM_INT(_23536)) {
        if (_23536 == (short)_23536)
        _23537 = _23536 * 4;
        else
        _23537 = NewDouble(_23536 * (double)4);
    }
    else {
        _23537 = binary_op(MULTIPLY, _23536, 4);
    }
    _23536 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23530);
    *((int *)(_2+4)) = _23530;
    Ref(_23532);
    *((int *)(_2+8)) = _23532;
    Ref(_23534);
    *((int *)(_2+12)) = _23534;
    *((int *)(_2+16)) = _23537;
    _23538 = MAKE_SEQ(_1);
    _23537 = NOVALUE;
    _23534 = NOVALUE;
    _23532 = NOVALUE;
    _23530 = NOVALUE;
    EPrintf(_fh_44377, _23528, _23538);
    DeRefDS(_23528);
    _23528 = NOVALUE;
    DeRefDS(_23538);
    _23538 = NOVALUE;
L9: 
L8: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_s_44425)){
        _23539 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44425)->dbl));
    }
    else{
        _23539 = (int)*(((s1_ptr)_2)->base + _s_44425);
    }
    DeRef(_s_44425);
    _2 = (int)SEQ_PTR(_23539);
    _s_44425 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44425);
    _23539 = NOVALUE;

    /** 		end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_44425);
    _s_44425 = NOVALUE;

    /** 	close(fh)*/
    EClose(_fh_44377);

    /** 	generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23541, _56file0_43185, _23494);
    RefDS(_23541);
    Append(&_56generated_files_41351, _56generated_files_41351, _23541);
    DeRefDS(_23541);
    _23541 = NOVALUE;

    /** end procedure*/
    DeRef(_settings_44375);
    _23499 = NOVALUE;
    DeRef(_23519);
    _23519 = NOVALUE;
    return;
    ;
}


void _54write_makefile_srcobj_list(int _fh_44474)
{
    int _23566 = NOVALUE;
    int _23565 = NOVALUE;
    int _23564 = NOVALUE;
    int _23563 = NOVALUE;
    int _23562 = NOVALUE;
    int _23560 = NOVALUE;
    int _23559 = NOVALUE;
    int _23558 = NOVALUE;
    int _23557 = NOVALUE;
    int _23556 = NOVALUE;
    int _23555 = NOVALUE;
    int _23554 = NOVALUE;
    int _23552 = NOVALUE;
    int _23551 = NOVALUE;
    int _23549 = NOVALUE;
    int _23548 = NOVALUE;
    int _23547 = NOVALUE;
    int _23546 = NOVALUE;
    int _23545 = NOVALUE;
    int _23544 = NOVALUE;
    int _0, _1, _2;
    

    /** 	printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_56file0_43185);
    _23544 = _18upper(_56file0_43185);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23544;
    _23545 = MAKE_SEQ(_1);
    _23544 = NOVALUE;
    EPrintf(_fh_44474, _23543, _23545);
    DeRefDS(_23545);
    _23545 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23546 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23546 = 1;
    }
    {
        int _i_44481;
        _i_44481 = 1;
L1: 
        if (_i_44481 > _23546){
            goto L2; // [26] 75
        }

        /** 		if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23547 = (int)*(((s1_ptr)_2)->base + _i_44481);
        if (IS_SEQUENCE(_23547)){
                _23548 = SEQ_PTR(_23547)->length;
        }
        else {
            _23548 = 1;
        }
        _2 = (int)SEQ_PTR(_23547);
        _23549 = (int)*(((s1_ptr)_2)->base + _23548);
        _23547 = NOVALUE;
        if (binary_op_a(NOTEQ, _23549, 99)){
            _23549 = NOVALUE;
            goto L3; // [48] 68
        }
        _23549 = NOVALUE;

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23551 = (int)*(((s1_ptr)_2)->base + _i_44481);
        Concat((object_ptr)&_23552, _23109, _23551);
        _23551 = NOVALUE;
        EPuts(_fh_44474, _23552); // DJP 
        DeRefDS(_23552);
        _23552 = NOVALUE;
L3: 

        /** 	end for*/
        _i_44481 = _i_44481 + 1;
        goto L1; // [70] 33
L2: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44474, _36HOSTNL_14020); // DJP 

    /** 	printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_56file0_43185);
    _23554 = _18upper(_56file0_43185);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23554;
    _23555 = MAKE_SEQ(_1);
    _23554 = NOVALUE;
    EPrintf(_fh_44474, _23553, _23555);
    DeRefDS(_23555);
    _23555 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23556 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23556 = 1;
    }
    {
        int _i_44500;
        _i_44500 = 1;
L4: 
        if (_i_44500 > _23556){
            goto L5; // [105] 151
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23557 = (int)*(((s1_ptr)_2)->base + _i_44500);
        _23558 = e_match_from(_22869, _23557, 1);
        _23557 = NOVALUE;
        if (_23558 == 0)
        {
            _23558 = NOVALUE;
            goto L6; // [125] 144
        }
        else{
            _23558 = NOVALUE;
        }

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23559 = (int)*(((s1_ptr)_2)->base + _i_44500);
        Concat((object_ptr)&_23560, _23109, _23559);
        _23559 = NOVALUE;
        EPuts(_fh_44474, _23560); // DJP 
        DeRefDS(_23560);
        _23560 = NOVALUE;
L6: 

        /** 	end for*/
        _i_44500 = _i_44500 + 1;
        goto L4; // [146] 112
L5: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44474, _36HOSTNL_14020); // DJP 

    /** 	printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_56file0_43185);
    _23562 = _18upper(_56file0_43185);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23562;
    _23563 = MAKE_SEQ(_1);
    _23562 = NOVALUE;
    EPrintf(_fh_44474, _23561, _23563);
    DeRefDS(_23563);
    _23563 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23564 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23564 = 1;
    }
    {
        int _i_44517;
        _i_44517 = 1;
L7: 
        if (_i_44517 > _23564){
            goto L8; // [181] 210
        }

        /** 		puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23565 = (int)*(((s1_ptr)_2)->base + _i_44517);
        Concat((object_ptr)&_23566, _23109, _23565);
        _23565 = NOVALUE;
        EPuts(_fh_44474, _23566); // DJP 
        DeRefDS(_23566);
        _23566 = NOVALUE;

        /** 	end for*/
        _i_44517 = _i_44517 + 1;
        goto L7; // [205] 188
L8: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44474, _36HOSTNL_14020); // DJP 

    /** end procedure*/
    return;
    ;
}


int _54windows_to_mingw_path(int _s_44526)
{
    int _23568 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** 	return search:find_replace('\\',s,'/')*/
    RefDS(_s_44526);
    _23568 = _20find_replace(92, _s_44526, 47, 0);
    DeRefDS(_s_44526);
    return _23568;
    ;
}


void _54write_makefile_full()
{
    int _settings_44531 = NOVALUE;
    int _fh_44534 = NOVALUE;
    int _23692 = NOVALUE;
    int _23690 = NOVALUE;
    int _23688 = NOVALUE;
    int _23687 = NOVALUE;
    int _23686 = NOVALUE;
    int _23685 = NOVALUE;
    int _23684 = NOVALUE;
    int _23682 = NOVALUE;
    int _23681 = NOVALUE;
    int _23679 = NOVALUE;
    int _23678 = NOVALUE;
    int _23677 = NOVALUE;
    int _23676 = NOVALUE;
    int _23674 = NOVALUE;
    int _23673 = NOVALUE;
    int _23671 = NOVALUE;
    int _23670 = NOVALUE;
    int _23668 = NOVALUE;
    int _23667 = NOVALUE;
    int _23666 = NOVALUE;
    int _23665 = NOVALUE;
    int _23664 = NOVALUE;
    int _23663 = NOVALUE;
    int _23662 = NOVALUE;
    int _23661 = NOVALUE;
    int _23659 = NOVALUE;
    int _23658 = NOVALUE;
    int _23657 = NOVALUE;
    int _23656 = NOVALUE;
    int _23655 = NOVALUE;
    int _23654 = NOVALUE;
    int _23653 = NOVALUE;
    int _23652 = NOVALUE;
    int _23651 = NOVALUE;
    int _23650 = NOVALUE;
    int _23649 = NOVALUE;
    int _23648 = NOVALUE;
    int _23647 = NOVALUE;
    int _23585 = NOVALUE;
    int _23584 = NOVALUE;
    int _23583 = NOVALUE;
    int _23581 = NOVALUE;
    int _23580 = NOVALUE;
    int _23579 = NOVALUE;
    int _23577 = NOVALUE;
    int _23576 = NOVALUE;
    int _23575 = NOVALUE;
    int _23572 = NOVALUE;
    int _23570 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44531;
    _settings_44531 = _54setup_build();
    DeRef(_0);

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44531);
    _23570 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23570);
    _54ensure_exename(_23570);
    _23570 = NOVALUE;

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23571;
        concat_list[1] = _56file0_43185;
        concat_list[2] = _56output_dir_41360;
        Concat_N((object_ptr)&_23572, concat_list, 3);
    }
    _fh_44534 = EOpen(_23572, _23496, 0);
    DeRefDS(_23572);
    _23572 = NOVALUE;

    /** 	printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23575, _23574, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_settings_44531);
    _23576 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23576);
    *((int *)(_2+4)) = _23576;
    _23577 = MAKE_SEQ(_1);
    _23576 = NOVALUE;
    EPrintf(_fh_44534, _23575, _23577);
    DeRefDS(_23575);
    _23575 = NOVALUE;
    DeRefDS(_23577);
    _23577 = NOVALUE;

    /** 	printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23579, _23578, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_settings_44531);
    _23580 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23580);
    *((int *)(_2+4)) = _23580;
    _23581 = MAKE_SEQ(_1);
    _23580 = NOVALUE;
    EPrintf(_fh_44534, _23579, _23581);
    DeRefDS(_23579);
    _23579 = NOVALUE;
    DeRefDS(_23581);
    _23581 = NOVALUE;

    /** 	printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23583, _23582, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_settings_44531);
    _23584 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23584);
    *((int *)(_2+4)) = _23584;
    _23585 = MAKE_SEQ(_1);
    _23584 = NOVALUE;
    EPrintf(_fh_44534, _23583, _23585);
    DeRefDS(_23583);
    _23583 = NOVALUE;
    DeRefDS(_23585);
    _23585 = NOVALUE;

    /** 	if compiler_type = COMPILER_GCC then*/

    /** 		write_objlink_file()*/
    _54write_objlink_file();

    /** 	write_makefile_srcobj_list(fh)*/
    _54write_makefile_srcobj_list(_fh_44534);

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 		printf(fh, "%s: $(%s_OBJECTS) %s %s" & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), user_library, rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23647, _23646, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23648 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23648);
    _23649 = _54adjust_for_build_file(_23648);
    _23648 = NOVALUE;
    RefDS(_56file0_43185);
    _23650 = _18upper(_56file0_43185);
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23651 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23649;
    *((int *)(_2+8)) = _23650;
    RefDS(_56user_library_41359);
    *((int *)(_2+12)) = _56user_library_41359;
    RefDS(_23651);
    *((int *)(_2+16)) = _23651;
    _23652 = MAKE_SEQ(_1);
    _23651 = NOVALUE;
    _23650 = NOVALUE;
    _23649 = NOVALUE;
    EPrintf(_fh_44534, _23647, _23652);
    DeRefDS(_23647);
    _23647 = NOVALUE;
    DeRefDS(_23652);
    _23652 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23653 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23653)){
            _23654 = SEQ_PTR(_23653)->length;
    }
    else {
        _23654 = 1;
    }
    _23653 = NOVALUE;
    if (_23654 == 0)
    {
        _23654 = NOVALUE;
        goto L1; // [635] 679
    }
    else{
        _23654 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44531);
    _23655 = (int)*(((s1_ptr)_2)->base + 8);
    {
        int concat_list[3];

        concat_list[0] = _36HOSTNL_14020;
        concat_list[1] = _23655;
        concat_list[2] = _23605;
        Concat_N((object_ptr)&_23656, concat_list, 3);
    }
    _23655 = NOVALUE;
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23657 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23658 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23658);
    RefDS(_23657);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23657;
    ((int *)_2)[2] = _23658;
    _23659 = MAKE_SEQ(_1);
    _23658 = NOVALUE;
    _23657 = NOVALUE;
    _17writef(_fh_44534, _23656, _23659, 0);
    _23656 = NOVALUE;
    _23659 = NOVALUE;
L1: 

    /** 		printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_23661, _23660, _36HOSTNL_14020);
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23662 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_56file0_43185);
    _23663 = _18upper(_56file0_43185);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23664 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23664)){
            _23665 = SEQ_PTR(_23664)->length;
    }
    else {
        _23665 = 1;
    }
    _23664 = NOVALUE;
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23666 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23666);
    RefDS(_21829);
    _23667 = _55iif(_23665, _23666, _21829);
    _23665 = NOVALUE;
    _23666 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23662);
    *((int *)(_2+4)) = _23662;
    *((int *)(_2+8)) = _23663;
    *((int *)(_2+12)) = _23667;
    _23668 = MAKE_SEQ(_1);
    _23667 = NOVALUE;
    _23663 = NOVALUE;
    _23662 = NOVALUE;
    EPrintf(_fh_44534, _23661, _23668);
    DeRefDS(_23661);
    _23661 = NOVALUE;
    DeRefDS(_23668);
    _23668 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 		printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23670, _23669, _36HOSTNL_14020);
    RefDS(_56file0_43185);
    RefDS(_56file0_43185);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _56file0_43185;
    ((int *)_2)[2] = _56file0_43185;
    _23671 = MAKE_SEQ(_1);
    EPrintf(_fh_44534, _23670, _23671);
    DeRefDS(_23670);
    _23670 = NOVALUE;
    DeRefDS(_23671);
    _23671 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 		printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23673, _23672, _36HOSTNL_14020);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_56file0_43185);
    *((int *)(_2+4)) = _56file0_43185;
    _23674 = MAKE_SEQ(_1);
    EPrintf(_fh_44534, _23673, _23674);
    DeRefDS(_23673);
    _23673 = NOVALUE;
    DeRefDS(_23674);
    _23674 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23676, _23675, _36HOSTNL_14020);
    RefDS(_56file0_43185);
    _23677 = _18upper(_56file0_43185);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23678 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23678);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23677;
    ((int *)_2)[2] = _23678;
    _23679 = MAKE_SEQ(_1);
    _23678 = NOVALUE;
    _23677 = NOVALUE;
    EPrintf(_fh_44534, _23676, _23679);
    DeRefDS(_23676);
    _23676 = NOVALUE;
    DeRefDS(_23679);
    _23679 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 		printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23681, _23680, _36HOSTNL_14020);
    RefDS(_56file0_43185);
    RefDS(_56file0_43185);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _56file0_43185;
    ((int *)_2)[2] = _56file0_43185;
    _23682 = MAKE_SEQ(_1);
    EPrintf(_fh_44534, _23681, _23682);
    DeRefDS(_23681);
    _23681 = NOVALUE;
    DeRefDS(_23682);
    _23682 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23684, _23683, _36HOSTNL_14020);
    RefDS(_56file0_43185);
    _23685 = _18upper(_56file0_43185);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23686 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23687 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23685;
    RefDS(_23686);
    *((int *)(_2+8)) = _23686;
    Ref(_23687);
    *((int *)(_2+12)) = _23687;
    _23688 = MAKE_SEQ(_1);
    _23687 = NOVALUE;
    _23686 = NOVALUE;
    _23685 = NOVALUE;
    EPrintf(_fh_44534, _23684, _23688);
    DeRefDS(_23684);
    _23684 = NOVALUE;
    DeRefDS(_23688);
    _23688 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 		puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_23690, _23689, _36HOSTNL_14020);
    EPuts(_fh_44534, _23690); // DJP 
    DeRefDS(_23690);
    _23690 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_23692, _23691, _36HOSTNL_14020);
    EPuts(_fh_44534, _23692); // DJP 
    DeRefDS(_23692);
    _23692 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44534, _36HOSTNL_14020); // DJP 

    /** 	close(fh)*/
    EClose(_fh_44534);

    /** end procedure*/
    DeRef(_settings_44531);
    _23653 = NOVALUE;
    _23664 = NOVALUE;
    return;
    ;
}


void _54write_makefile_partial()
{
    int _settings_44758 = NOVALUE;
    int _fh_44760 = NOVALUE;
    int _23694 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44758;
    _settings_44758 = _54setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23571;
        concat_list[1] = _56file0_43185;
        concat_list[2] = _56output_dir_41360;
        Concat_N((object_ptr)&_23694, concat_list, 3);
    }
    _fh_44760 = EOpen(_23694, _23496, 0);
    DeRefDS(_23694);
    _23694 = NOVALUE;

    /** 	write_makefile_srcobj_list(fh)*/
    _54write_makefile_srcobj_list(_fh_44760);

    /** 	close(fh)*/
    EClose(_fh_44760);

    /** end procedure*/
    DeRefDS(_settings_44758);
    return;
    ;
}


void _54build_direct(int _link_only_44767, int _the_file0_44768)
{
    int _cmd_44774 = NOVALUE;
    int _objs_44775 = NOVALUE;
    int _settings_44776 = NOVALUE;
    int _cwd_44778 = NOVALUE;
    int _status_44781 = NOVALUE;
    int _link_files_44810 = NOVALUE;
    int _pdone_44836 = NOVALUE;
    int _files_44882 = NOVALUE;
    int _31389 = NOVALUE;
    int _31388 = NOVALUE;
    int _31387 = NOVALUE;
    int _31386 = NOVALUE;
    int _31385 = NOVALUE;
    int _31383 = NOVALUE;
    int _23838 = NOVALUE;
    int _23837 = NOVALUE;
    int _23836 = NOVALUE;
    int _23835 = NOVALUE;
    int _23834 = NOVALUE;
    int _23833 = NOVALUE;
    int _23832 = NOVALUE;
    int _23830 = NOVALUE;
    int _23829 = NOVALUE;
    int _23828 = NOVALUE;
    int _23827 = NOVALUE;
    int _23823 = NOVALUE;
    int _23822 = NOVALUE;
    int _23821 = NOVALUE;
    int _23820 = NOVALUE;
    int _23819 = NOVALUE;
    int _23818 = NOVALUE;
    int _23817 = NOVALUE;
    int _23816 = NOVALUE;
    int _23815 = NOVALUE;
    int _23814 = NOVALUE;
    int _23813 = NOVALUE;
    int _23812 = NOVALUE;
    int _23811 = NOVALUE;
    int _23810 = NOVALUE;
    int _23809 = NOVALUE;
    int _23806 = NOVALUE;
    int _23805 = NOVALUE;
    int _23804 = NOVALUE;
    int _23803 = NOVALUE;
    int _23800 = NOVALUE;
    int _23798 = NOVALUE;
    int _23797 = NOVALUE;
    int _23796 = NOVALUE;
    int _23795 = NOVALUE;
    int _23794 = NOVALUE;
    int _23793 = NOVALUE;
    int _23790 = NOVALUE;
    int _23789 = NOVALUE;
    int _23785 = NOVALUE;
    int _23784 = NOVALUE;
    int _23783 = NOVALUE;
    int _23779 = NOVALUE;
    int _23778 = NOVALUE;
    int _23777 = NOVALUE;
    int _23776 = NOVALUE;
    int _23775 = NOVALUE;
    int _23774 = NOVALUE;
    int _23773 = NOVALUE;
    int _23772 = NOVALUE;
    int _23771 = NOVALUE;
    int _23770 = NOVALUE;
    int _23769 = NOVALUE;
    int _23768 = NOVALUE;
    int _23766 = NOVALUE;
    int _23765 = NOVALUE;
    int _23764 = NOVALUE;
    int _23763 = NOVALUE;
    int _23762 = NOVALUE;
    int _23760 = NOVALUE;
    int _23759 = NOVALUE;
    int _23758 = NOVALUE;
    int _23757 = NOVALUE;
    int _23756 = NOVALUE;
    int _23754 = NOVALUE;
    int _23752 = NOVALUE;
    int _23751 = NOVALUE;
    int _23750 = NOVALUE;
    int _23749 = NOVALUE;
    int _23747 = NOVALUE;
    int _23746 = NOVALUE;
    int _23745 = NOVALUE;
    int _23742 = NOVALUE;
    int _23741 = NOVALUE;
    int _23740 = NOVALUE;
    int _23739 = NOVALUE;
    int _23738 = NOVALUE;
    int _23737 = NOVALUE;
    int _23736 = NOVALUE;
    int _23735 = NOVALUE;
    int _23734 = NOVALUE;
    int _23733 = NOVALUE;
    int _23730 = NOVALUE;
    int _23729 = NOVALUE;
    int _23726 = NOVALUE;
    int _23724 = NOVALUE;
    int _23723 = NOVALUE;
    int _23722 = NOVALUE;
    int _23721 = NOVALUE;
    int _23718 = NOVALUE;
    int _23717 = NOVALUE;
    int _23716 = NOVALUE;
    int _23715 = NOVALUE;
    int _23713 = NOVALUE;
    int _23712 = NOVALUE;
    int _23711 = NOVALUE;
    int _23710 = NOVALUE;
    int _23709 = NOVALUE;
    int _23706 = NOVALUE;
    int _23700 = NOVALUE;
    int _23696 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_link_only_44767)) {
        _1 = (long)(DBL_PTR(_link_only_44767)->dbl);
        DeRefDS(_link_only_44767);
        _link_only_44767 = _1;
    }

    /** 	if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_44768)){
            _23696 = SEQ_PTR(_the_file0_44768)->length;
    }
    else {
        _23696 = 1;
    }
    if (_23696 == 0)
    {
        _23696 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _23696 = NOVALUE;
    }

    /** 		file0 = filebase(the_file0)*/
    RefDS(_the_file0_44768);
    _0 = _14filebase(_the_file0_44768);
    DeRef(_56file0_43185);
    _56file0_43185 = _0;
L1: 

    /** 	sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_21829);
    DeRef(_objs_44775);
    _objs_44775 = _21829;
    _0 = _settings_44776;
    _settings_44776 = _54setup_build();
    DeRef(_0);
    _0 = _cwd_44778;
    _cwd_44778 = _14current_dir();
    DeRef(_0);

    /** 	integer status*/

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44776);
    _23700 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23700);
    _54ensure_exename(_23700);
    _23700 = NOVALUE;

    /** 	if not link_only then*/
    if (_link_only_44767 != 0)
    goto L2; // [52] 120

    /** 		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 			case COMPILER_GCC then*/
        case 1:

        /** 				if not silent then*/
        if (_12silent_11798 != 0)
        goto L3; // [72] 119

        /** 					ShowMsg(1, 176, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23705);
        *((int *)(_2+4)) = _23705;
        _23706 = MAKE_SEQ(_1);
        _44ShowMsg(1, 176, _23706, 1);
        _23706 = NOVALUE;
        goto L3; // [88] 119

        /** 			case COMPILER_WATCOM then*/
        case 2:

        /** 				write_objlink_file()*/
        _54write_objlink_file();

        /** 				if not silent then*/
        if (_12silent_11798 != 0)
        goto L4; // [102] 118

        /** 					ShowMsg(1, 176, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23708);
        *((int *)(_2+4)) = _23708;
        _23709 = MAKE_SEQ(_1);
        _44ShowMsg(1, 176, _23709, 1);
        _23709 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _23710 = 1;
    if (_23710 == 0) {
        goto L5; // [127] 155
    }
    _23712 = 0;
    _23713 = (0 > 0);
    _23712 = NOVALUE;
    if (_23713 == 0)
    {
        DeRef(_23713);
        _23713 = NOVALUE;
        goto L5; // [141] 155
    }
    else{
        DeRef(_23713);
        _23713 = NOVALUE;
    }

    /** 		chdir(output_dir)*/
    RefDS(_56output_dir_41360);
    _31389 = _14chdir(_56output_dir_41360);
    DeRef(_31389);
    _31389 = NOVALUE;
L5: 

    /** 	sequence link_files = {}*/
    RefDS(_21829);
    DeRef(_link_files_44810);
    _link_files_44810 = _21829;

    /** 	if not link_only then*/
    if (_link_only_44767 != 0)
    goto L6; // [164] 468

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23715 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23715 = 1;
    }
    {
        int _i_44814;
        _i_44814 = 1;
L7: 
        if (_i_44814 > _23715){
            goto L8; // [174] 465
        }

        /** 			if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23716 = (int)*(((s1_ptr)_2)->base + _i_44814);
        if (IS_SEQUENCE(_23716)){
                _23717 = SEQ_PTR(_23716)->length;
        }
        else {
            _23717 = 1;
        }
        _2 = (int)SEQ_PTR(_23716);
        _23718 = (int)*(((s1_ptr)_2)->base + _23717);
        _23716 = NOVALUE;
        if (binary_op_a(NOTEQ, _23718, 99)){
            _23718 = NOVALUE;
            goto L9; // [196] 424
        }
        _23718 = NOVALUE;

        /** 				cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (int)SEQ_PTR(_settings_44776);
        _23721 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_settings_44776);
        _23722 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23723 = (int)*(((s1_ptr)_2)->base + _i_44814);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23721);
        *((int *)(_2+4)) = _23721;
        Ref(_23722);
        *((int *)(_2+8)) = _23722;
        RefDS(_23723);
        *((int *)(_2+12)) = _23723;
        _23724 = MAKE_SEQ(_1);
        _23723 = NOVALUE;
        _23722 = NOVALUE;
        _23721 = NOVALUE;
        DeRef(_cmd_44774);
        _cmd_44774 = EPrintf(-9999999, _23720, _23724);
        DeRefDS(_23724);
        _23724 = NOVALUE;

        /** 				link_files = append(link_files, generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23726 = (int)*(((s1_ptr)_2)->base + _i_44814);
        RefDS(_23726);
        Append(&_link_files_44810, _link_files_44810, _23726);
        _23726 = NOVALUE;

        /** 				if not silent then*/
        if (_12silent_11798 != 0)
        goto LA; // [242] 364

        /** 					atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_56generated_files_41351)){
                _23729 = SEQ_PTR(_56generated_files_41351)->length;
        }
        else {
            _23729 = 1;
        }
        _23730 = (_i_44814 % _23729) ? NewDouble((double)_i_44814 / _23729) : (_i_44814 / _23729);
        _23729 = NOVALUE;
        DeRef(_pdone_44836);
        if (IS_ATOM_INT(_23730)) {
            if (_23730 <= INT15 && _23730 >= -INT15)
            _pdone_44836 = 100 * _23730;
            else
            _pdone_44836 = NewDouble(100 * (double)_23730);
        }
        else {
            _pdone_44836 = NewDouble((double)100 * DBL_PTR(_23730)->dbl);
        }
        DeRef(_23730);
        _23730 = NOVALUE;

        /** 					if not verbose then*/
        if (_12verbose_11801 != 0)
        goto LB; // [264] 350

        /** 						if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _23733 = 0;
            goto LC; // [269] 287
        }
        _2 = (int)SEQ_PTR(_56outdated_files_41352);
        _23734 = (int)*(((s1_ptr)_2)->base + _i_44814);
        if (IS_ATOM_INT(_23734)) {
            _23735 = (_23734 == 0);
        }
        else {
            _23735 = binary_op(EQUALS, _23734, 0);
        }
        _23734 = NOVALUE;
        if (IS_ATOM_INT(_23735))
        _23733 = (_23735 != 0);
        else
        _23733 = DBL_PTR(_23735)->dbl != 0.0;
LC: 
        if (_23733 == 0) {
            goto LD; // [287] 328
        }
        _23737 = (0 == 0);
        if (_23737 == 0)
        {
            DeRef(_23737);
            _23737 = NOVALUE;
            goto LD; // [298] 328
        }
        else{
            DeRef(_23737);
            _23737 = NOVALUE;
        }

        /** 							ShowMsg(1, 325, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23738 = (int)*(((s1_ptr)_2)->base + _i_44814);
        RefDS(_23738);
        Ref(_pdone_44836);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44836;
        ((int *)_2)[2] = _23738;
        _23739 = MAKE_SEQ(_1);
        _23738 = NOVALUE;
        _44ShowMsg(1, 325, _23739, 1);
        _23739 = NOVALUE;

        /** 							continue*/
        DeRef(_pdone_44836);
        _pdone_44836 = NOVALUE;
        goto LE; // [323] 460
        goto LF; // [325] 363
LD: 

        /** 							ShowMsg(1, 163, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23740 = (int)*(((s1_ptr)_2)->base + _i_44814);
        RefDS(_23740);
        Ref(_pdone_44836);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44836;
        ((int *)_2)[2] = _23740;
        _23741 = MAKE_SEQ(_1);
        _23740 = NOVALUE;
        _44ShowMsg(1, 163, _23741, 1);
        _23741 = NOVALUE;
        goto LF; // [347] 363
LB: 

        /** 						ShowMsg(1, 163, { pdone, cmd })*/
        RefDS(_cmd_44774);
        Ref(_pdone_44836);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44836;
        ((int *)_2)[2] = _cmd_44774;
        _23742 = MAKE_SEQ(_1);
        _44ShowMsg(1, 163, _23742, 1);
        _23742 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_44836);
        _pdone_44836 = NOVALUE;

        /** 				status = system_exec(cmd, 0)*/
        _status_44781 = system_exec_call(_cmd_44774, 0);

        /** 				if status != 0 then*/
        if (_status_44781 == 0)
        goto L10; // [374] 458

        /** 					ShowMsg(2, 164, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23745 = (int)*(((s1_ptr)_2)->base + _i_44814);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23745);
        *((int *)(_2+4)) = _23745;
        _23746 = MAKE_SEQ(_1);
        _23745 = NOVALUE;
        _44ShowMsg(2, 164, _23746, 1);
        _23746 = NOVALUE;

        /** 					ShowMsg(2, 165, { status, cmd })*/
        RefDS(_cmd_44774);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _status_44781;
        ((int *)_2)[2] = _cmd_44774;
        _23747 = MAKE_SEQ(_1);
        _44ShowMsg(2, 165, _23747, 1);
        _23747 = NOVALUE;

        /** 					goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [421] 458
L9: 

        /** 			elsif match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23749 = (int)*(((s1_ptr)_2)->base + _i_44814);
        _23750 = e_match_from(_22869, _23749, 1);
        _23749 = NOVALUE;
        if (_23750 == 0)
        {
            _23750 = NOVALUE;
            goto L12; // [437] 457
        }
        else{
            _23750 = NOVALUE;
        }

        /** 				objs &= " " & generated_files[i]*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23751 = (int)*(((s1_ptr)_2)->base + _i_44814);
        Concat((object_ptr)&_23752, _23109, _23751);
        _23751 = NOVALUE;
        Concat((object_ptr)&_objs_44775, _objs_44775, _23752);
        DeRefDS(_23752);
        _23752 = NOVALUE;
L12: 
L10: 

        /** 		end for*/
LE: 
        _i_44814 = _i_44814 + 1;
        goto L7; // [460] 181
L8: 
        ;
    }
    goto L13; // [465] 527
L6: 

    /** 		object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_23754, _56file0_43185, _23297);
    _0 = _files_44882;
    _files_44882 = _17read_lines(_23754);
    DeRef(_0);
    _23754 = NOVALUE;

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44882)){
            _23756 = SEQ_PTR(_files_44882)->length;
    }
    else {
        _23756 = 1;
    }
    {
        int _i_44888;
        _i_44888 = 1;
L14: 
        if (_i_44888 > _23756){
            goto L15; // [485] 524
        }

        /** 			objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (int)SEQ_PTR(_files_44882);
        _23757 = (int)*(((s1_ptr)_2)->base + _i_44888);
        Ref(_23757);
        _23758 = _14filebase(_23757);
        _23757 = NOVALUE;
        _2 = (int)SEQ_PTR(_settings_44776);
        _23759 = (int)*(((s1_ptr)_2)->base + 5);
        {
            int concat_list[4];

            concat_list[0] = _23759;
            concat_list[1] = _22908;
            concat_list[2] = _23758;
            concat_list[3] = _23109;
            Concat_N((object_ptr)&_23760, concat_list, 4);
        }
        _23759 = NOVALUE;
        DeRef(_23758);
        _23758 = NOVALUE;
        Concat((object_ptr)&_objs_44775, _objs_44775, _23760);
        DeRefDS(_23760);
        _23760 = NOVALUE;

        /** 		end for*/
        _i_44888 = _i_44888 + 1;
        goto L14; // [519] 492
L15: 
        ;
    }
    DeRef(_files_44882);
    _files_44882 = NOVALUE;
L13: 

    /** 	if keep and not link_only and length(link_files) then*/
    if (_56keep_41354 == 0) {
        _23762 = 0;
        goto L16; // [531] 542
    }
    _23763 = (_link_only_44767 == 0);
    _23762 = (_23763 != 0);
L16: 
    if (_23762 == 0) {
        goto L17; // [542] 571
    }
    if (IS_SEQUENCE(_link_files_44810)){
            _23765 = SEQ_PTR(_link_files_44810)->length;
    }
    else {
        _23765 = 1;
    }
    if (_23765 == 0)
    {
        _23765 = NOVALUE;
        goto L17; // [550] 571
    }
    else{
        _23765 = NOVALUE;
    }

    /** 		write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_23766, _56file0_43185, _23297);
    RefDS(_link_files_44810);
    _31388 = _17write_lines(_23766, _link_files_44810);
    _23766 = NOVALUE;
    DeRef(_31388);
    _31388 = NOVALUE;
    goto L18; // [568] 595
L17: 

    /** 	elsif keep = 0 then*/
    if (_56keep_41354 != 0)
    goto L19; // [575] 594

    /** 		delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_23768, _56file0_43185, _23297);
    _31387 = _14delete_file(_23768);
    _23768 = NOVALUE;
    DeRef(_31387);
    _31387 = NOVALUE;
L19: 
L18: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23769 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23769)){
            _23770 = SEQ_PTR(_23769)->length;
    }
    else {
        _23770 = 1;
    }
    _23769 = NOVALUE;
    if (_23770 == 0) {
        _23771 = 0;
        goto L1A; // [608] 623
    }
    _2 = (int)SEQ_PTR(_settings_44776);
    _23772 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23772)){
            _23773 = SEQ_PTR(_23772)->length;
    }
    else {
        _23773 = 1;
    }
    _23772 = NOVALUE;
    _23771 = (_23773 != 0);
L1A: 
    if (_23771 == 0) {
        goto L1B; // [623] 724
    }
    _23775 = (0 == 1);
    if (_23775 == 0)
    {
        DeRef(_23775);
        _23775 = NOVALUE;
        goto L1B; // [634] 724
    }
    else{
        DeRef(_23775);
        _23775 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44776);
    _23776 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23777 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23778 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23778);
    RefDS(_23777);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23777;
    ((int *)_2)[2] = _23778;
    _23779 = MAKE_SEQ(_1);
    _23778 = NOVALUE;
    _23777 = NOVALUE;
    Ref(_23776);
    _0 = _cmd_44774;
    _cmd_44774 = _18format(_23776, _23779);
    DeRef(_0);
    _23776 = NOVALUE;
    _23779 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_44781 = system_exec_call(_cmd_44774, 0);

    /** 		if status != 0 then*/
    if (_status_44781 == 0)
    goto L1C; // [678] 723

    /** 			ShowMsg(2, 350, { rc_file[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23783 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_23783);
    *((int *)(_2+4)) = _23783;
    _23784 = MAKE_SEQ(_1);
    _23783 = NOVALUE;
    _44ShowMsg(2, 350, _23784, 1);
    _23784 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44774);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44781;
    ((int *)_2)[2] = _cmd_44774;
    _23785 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _23785, 1);
    _23785 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** 	switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (int)SEQ_PTR(_settings_44776);
        _23789 = (int)*(((s1_ptr)_2)->base + 3);
        RefDS(_56file0_43185);
        Ref(_23789);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23789;
        ((int *)_2)[2] = _56file0_43185;
        _23790 = MAKE_SEQ(_1);
        _23789 = NOVALUE;
        DeRef(_cmd_44774);
        _cmd_44774 = EPrintf(-9999999, _23788, _23790);
        DeRefDS(_23790);
        _23790 = NOVALUE;
        goto L1D; // [753] 828

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (int)SEQ_PTR(_settings_44776);
        _23793 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_54exe_name_44005);
        _23794 = (int)*(((s1_ptr)_2)->base + 11);
        Ref(_23794);
        _23795 = _54adjust_for_build_file(_23794);
        _23794 = NOVALUE;
        _2 = (int)SEQ_PTR(_54res_file_44017);
        _23796 = (int)*(((s1_ptr)_2)->base + 11);
        _2 = (int)SEQ_PTR(_settings_44776);
        _23797 = (int)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23793);
        *((int *)(_2+4)) = _23793;
        *((int *)(_2+8)) = _23795;
        RefDS(_objs_44775);
        *((int *)(_2+12)) = _objs_44775;
        RefDS(_23796);
        *((int *)(_2+16)) = _23796;
        Ref(_23797);
        *((int *)(_2+20)) = _23797;
        _23798 = MAKE_SEQ(_1);
        _23797 = NOVALUE;
        _23796 = NOVALUE;
        _23795 = NOVALUE;
        _23793 = NOVALUE;
        DeRef(_cmd_44774);
        _cmd_44774 = EPrintf(-9999999, _23792, _23798);
        DeRefDS(_23798);
        _23798 = NOVALUE;
        goto L1D; // [801] 828

        /** 		case else*/
        default:

        /** 			ShowMsg(2, 167, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        _23800 = MAKE_SEQ(_1);
        _44ShowMsg(2, 167, _23800, 1);
        _23800 = NOVALUE;

        /** 			goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** 	if not silent then*/
    if (_12silent_11798 != 0)
    goto L1E; // [832] 886

    /** 		if not verbose then*/
    if (_12verbose_11801 != 0)
    goto L1F; // [839] 870

    /** 			ShowMsg(1, 166, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23803 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23803);
    RefDS(_21829);
    _23804 = _14abbreviate_path(_23803, _21829);
    _23803 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23804;
    _23805 = MAKE_SEQ(_1);
    _23804 = NOVALUE;
    _44ShowMsg(1, 166, _23805, 1);
    _23805 = NOVALUE;
    goto L20; // [867] 885
L1F: 

    /** 			ShowMsg(1, 166, { cmd })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_cmd_44774);
    *((int *)(_2+4)) = _cmd_44774;
    _23806 = MAKE_SEQ(_1);
    _44ShowMsg(1, 166, _23806, 1);
    _23806 = NOVALUE;
L20: 
L1E: 

    /** 	status = system_exec(cmd, 0)*/
    _status_44781 = system_exec_call(_cmd_44774, 0);

    /** 	if status != 0 then*/
    if (_status_44781 == 0)
    goto L21; // [896] 939

    /** 		ShowMsg(2, 168, { exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23809 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23809);
    *((int *)(_2+4)) = _23809;
    _23810 = MAKE_SEQ(_1);
    _23809 = NOVALUE;
    _44ShowMsg(2, 168, _23810, 1);
    _23810 = NOVALUE;

    /** 		ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44774);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44781;
    ((int *)_2)[2] = _cmd_44774;
    _23811 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _23811, 1);
    _23811 = NOVALUE;

    /** 		goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23812 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23812)){
            _23813 = SEQ_PTR(_23812)->length;
    }
    else {
        _23813 = 1;
    }
    _23812 = NOVALUE;
    if (_23813 == 0) {
        _23814 = 0;
        goto L22; // [952] 967
    }
    _2 = (int)SEQ_PTR(_settings_44776);
    _23815 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23815)){
            _23816 = SEQ_PTR(_23815)->length;
    }
    else {
        _23816 = 1;
    }
    _23815 = NOVALUE;
    _23814 = (_23816 != 0);
L22: 
    if (_23814 == 0) {
        goto L23; // [967] 1086
    }
    _23818 = (0 == 2);
    if (_23818 == 0)
    {
        DeRef(_23818);
        _23818 = NOVALUE;
        goto L23; // [978] 1086
    }
    else{
        DeRef(_23818);
        _23818 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44776);
    _23819 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23820 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23821 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23822 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_23820);
    *((int *)(_2+4)) = _23820;
    RefDS(_23821);
    *((int *)(_2+8)) = _23821;
    Ref(_23822);
    *((int *)(_2+12)) = _23822;
    _23823 = MAKE_SEQ(_1);
    _23822 = NOVALUE;
    _23821 = NOVALUE;
    _23820 = NOVALUE;
    Ref(_23819);
    _0 = _cmd_44774;
    _cmd_44774 = _18format(_23819, _23823);
    DeRef(_0);
    _23819 = NOVALUE;
    _23823 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_44781 = system_exec_call(_cmd_44774, 0);

    /** 		if status != 0 then*/
    if (_status_44781 == 0)
    goto L24; // [1032] 1085

    /** 			ShowMsg(2, 187, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_54rc_file_44011);
    _23827 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_54exe_name_44005);
    _23828 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23828);
    RefDS(_23827);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23827;
    ((int *)_2)[2] = _23828;
    _23829 = MAKE_SEQ(_1);
    _23828 = NOVALUE;
    _23827 = NOVALUE;
    _44ShowMsg(2, 187, _23829, 1);
    _23829 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44774);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44781;
    ((int *)_2)[2] = _cmd_44774;
    _23830 = MAKE_SEQ(_1);
    _44ShowMsg(2, 169, _23830, 1);
    _23830 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** label "build_direct_cleanup"*/
G11:

    /** 	if keep = 0 then*/
    if (_56keep_41354 != 0)
    goto L25; // [1094] 1241

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_56generated_files_41351)){
            _23832 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _23832 = 1;
    }
    {
        int _i_45015;
        _i_45015 = 1;
L26: 
        if (_i_45015 > _23832){
            goto L27; // [1105] 1159
        }

        /** 			if verbose then*/
        if (_12verbose_11801 == 0)
        {
            goto L28; // [1116] 1138
        }
        else{
        }

        /** 				ShowMsg(1, 347, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23833 = (int)*(((s1_ptr)_2)->base + _i_45015);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23833);
        *((int *)(_2+4)) = _23833;
        _23834 = MAKE_SEQ(_1);
        _23833 = NOVALUE;
        _44ShowMsg(1, 347, _23834, 1);
        _23834 = NOVALUE;
L28: 

        /** 			delete_file(generated_files[i])*/
        _2 = (int)SEQ_PTR(_56generated_files_41351);
        _23835 = (int)*(((s1_ptr)_2)->base + _i_45015);
        RefDS(_23835);
        _31386 = _14delete_file(_23835);
        _23835 = NOVALUE;
        DeRef(_31386);
        _31386 = NOVALUE;

        /** 		end for*/
        _i_45015 = _i_45015 + 1;
        goto L26; // [1154] 1112
L27: 
        ;
    }

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23836 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23836)){
            _23837 = SEQ_PTR(_23836)->length;
    }
    else {
        _23837 = 1;
    }
    _23836 = NOVALUE;
    if (_23837 == 0)
    {
        _23837 = NOVALUE;
        goto L29; // [1172] 1192
    }
    else{
        _23837 = NOVALUE;
    }

    /** 			delete_file(res_file[D_ALTNAME])*/
    _2 = (int)SEQ_PTR(_54res_file_44017);
    _23838 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_23838);
    _31385 = _14delete_file(_23838);
    _23838 = NOVALUE;
    DeRef(_31385);
    _31385 = NOVALUE;
L29: 

    /** 		if remove_output_dir then*/
L25: 

    /** 	chdir(cwd)*/
    RefDS(_cwd_44778);
    _31383 = _14chdir(_cwd_44778);
    DeRef(_31383);
    _31383 = NOVALUE;

    /** end procedure*/
    DeRefDS(_the_file0_44768);
    DeRef(_cmd_44774);
    DeRef(_objs_44775);
    DeRef(_settings_44776);
    DeRefDS(_cwd_44778);
    DeRef(_link_files_44810);
    DeRef(_23763);
    _23763 = NOVALUE;
    DeRef(_23735);
    _23735 = NOVALUE;
    _23769 = NOVALUE;
    _23772 = NOVALUE;
    _23812 = NOVALUE;
    _23815 = NOVALUE;
    _23836 = NOVALUE;
    return;
    ;
}


void _54write_buildfile()
{
    int _make_command_45055 = NOVALUE;
    int _settings_45095 = NOVALUE;
    int _23865 = NOVALUE;
    int _23864 = NOVALUE;
    int _23860 = NOVALUE;
    int _23859 = NOVALUE;
    int _23858 = NOVALUE;
    int _23856 = NOVALUE;
    int _23855 = NOVALUE;
    int _23854 = NOVALUE;
    int _23853 = NOVALUE;
    int _23852 = NOVALUE;
    int _23851 = NOVALUE;
    int _23850 = NOVALUE;
    int _23849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch build_system_type do*/
    _0 = 3;
    switch ( _0 ){ 

        /** 		case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** 			write_makefile_full()*/
        _54write_makefile_full();

        /** 			if not silent then*/
        if (_12silent_11798 != 0)
        goto L1; // [22] 136

        /** 				sequence make_command*/

        /** 				if compiler_type = COMPILER_WATCOM then*/

        /** 					make_command = "make -f "*/
        RefDS(_23848);
        DeRefi(_make_command_45055);
        _make_command_45055 = _23848;

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23849 = _12cfile_count_11761 + 2;
        if ((long)((unsigned long)_23849 + (unsigned long)HIGH_BITS) >= 0) 
        _23849 = NewDouble((double)_23849);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23849;
        _23850 = MAKE_SEQ(_1);
        _23849 = NOVALUE;
        _44ShowMsg(1, 170, _23850, 1);
        _23850 = NOVALUE;

        /** 				if sequence(output_dir) and length(output_dir) > 0 then*/
        _23851 = 1;
        if (_23851 == 0) {
            goto L2; // [78] 118
        }
        _23853 = 0;
        _23854 = (0 > 0);
        _23853 = NOVALUE;
        if (_23854 == 0)
        {
            DeRef(_23854);
            _23854 = NOVALUE;
            goto L2; // [92] 118
        }
        else{
            DeRef(_23854);
            _23854 = NOVALUE;
        }

        /** 					ShowMsg(1, 174, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56output_dir_41360);
        *((int *)(_2+4)) = _56output_dir_41360;
        RefDS(_make_command_45055);
        *((int *)(_2+8)) = _make_command_45055;
        RefDS(_56file0_43185);
        *((int *)(_2+12)) = _56file0_43185;
        _23855 = MAKE_SEQ(_1);
        _44ShowMsg(1, 174, _23855, 1);
        _23855 = NOVALUE;
        goto L3; // [115] 135
L2: 

        /** 					ShowMsg(1, 172, { make_command, file0 })*/
        RefDS(_56file0_43185);
        RefDS(_make_command_45055);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _make_command_45055;
        ((int *)_2)[2] = _56file0_43185;
        _23856 = MAKE_SEQ(_1);
        _44ShowMsg(1, 172, _23856, 1);
        _23856 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_45055);
        _make_command_45055 = NOVALUE;
        goto L4; // [138] 263

        /** 		case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** 			write_makefile_partial()*/
        _54write_makefile_partial();

        /** 			if not silent then*/
        if (_12silent_11798 != 0)
        goto L4; // [152] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23858 = _12cfile_count_11761 + 2;
        if ((long)((unsigned long)_23858 + (unsigned long)HIGH_BITS) >= 0) 
        _23858 = NewDouble((double)_23858);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23858;
        _23859 = MAKE_SEQ(_1);
        _23858 = NOVALUE;
        _44ShowMsg(1, 170, _23859, 1);
        _23859 = NOVALUE;

        /** 				ShowMsg(1, 173, { file0 })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_56file0_43185);
        *((int *)(_2+4)) = _56file0_43185;
        _23860 = MAKE_SEQ(_1);
        _44ShowMsg(1, 173, _23860, 1);
        _23860 = NOVALUE;
        goto L4; // [188] 263

        /** 		case BUILD_DIRECT then*/
        case 3:

        /** 			build_direct()*/
        RefDS(_21829);
        _54build_direct(0, _21829);

        /** 			if not silent then*/
        if (_12silent_11798 != 0)
        goto L5; // [204] 215

        /** 				sequence settings = setup_build()*/
        _0 = _settings_45095;
        _settings_45095 = _54setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_45095);
        _settings_45095 = NOVALUE;
        goto L4; // [217] 263

        /** 		case BUILD_NONE then*/
        case 0:

        /** 			if not silent then*/
        if (_12silent_11798 != 0)
        goto L4; // [227] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23864 = _12cfile_count_11761 + 2;
        if ((long)((unsigned long)_23864 + (unsigned long)HIGH_BITS) >= 0) 
        _23864 = NewDouble((double)_23864);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23864;
        _23865 = MAKE_SEQ(_1);
        _23864 = NOVALUE;
        _44ShowMsg(1, 170, _23865, 1);
        _23865 = NOVALUE;
        goto L4; // [249] 263

        /** 		case else*/
        default:

        /** 			CompileErr(151)*/
        RefDS(_21829);
        _43CompileErr(151, _21829, 0);
    ;}L4: 

    /** end procedure*/
    return;
    ;
}



// 0x9F2D39E8
