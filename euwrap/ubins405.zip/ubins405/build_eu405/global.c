// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _12print_sym(int _s_11448)
{
    int _s_obj_11451 = NOVALUE;
    int _6297 = NOVALUE;
    int _6296 = NOVALUE;
    int _6292 = NOVALUE;
    int _6290 = NOVALUE;
    int _6289 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_11448)) {
        _1 = (long)(DBL_PTR(_s_11448)->dbl);
        DeRefDS(_s_11448);
        _s_11448 = _1;
    }

    /** 	printf(1,"[%d]:\n", {s} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _s_11448;
    _6289 = MAKE_SEQ(_1);
    EPrintf(1, _6288, _6289);
    DeRefDS(_6289);
    _6289 = NOVALUE;

    /** 	object s_obj = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _6290 = (int)*(((s1_ptr)_2)->base + _s_11448);
    DeRef(_s_obj_11451);
    _2 = (int)SEQ_PTR(_6290);
    _s_obj_11451 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_s_obj_11451);
    _6290 = NOVALUE;

    /** 	if equal(s_obj,NOVALUE) then */
    if (_s_obj_11451 == _12NOVALUE_11536)
    _6292 = 1;
    else if (IS_ATOM_INT(_s_obj_11451) && IS_ATOM_INT(_12NOVALUE_11536))
    _6292 = 0;
    else
    _6292 = (compare(_s_obj_11451, _12NOVALUE_11536) == 0);
    if (_6292 == 0)
    {
        _6292 = NOVALUE;
        goto L1; // [33] 44
    }
    else{
        _6292 = NOVALUE;
    }

    /** 		puts(1,"S_OBJ=>NOVALUE\n")*/
    EPuts(1, _6293); // DJP 
    goto L2; // [41] 55
L1: 

    /** 		puts(1,"S_OBJ=>")*/
    EPuts(1, _6294); // DJP 

    /** 		? s_obj		*/
    StdPrint(1, _s_obj_11451, 1);
L2: 

    /** 	puts(1,"S_MODE=>")*/
    EPuts(1, _6295); // DJP 

    /** 	switch SymTab[s][S_MODE] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _6296 = (int)*(((s1_ptr)_2)->base + _s_11448);
    _2 = (int)SEQ_PTR(_6296);
    _6297 = (int)*(((s1_ptr)_2)->base + 3);
    _6296 = NOVALUE;
    if (IS_SEQUENCE(_6297) ){
        goto L3; // [72] 120
    }
    if(!IS_ATOM_INT(_6297)){
        if( (DBL_PTR(_6297)->dbl != (double) ((int) DBL_PTR(_6297)->dbl) ) ){
            goto L3; // [72] 120
        }
        _0 = (int) DBL_PTR(_6297)->dbl;
    }
    else {
        _0 = _6297;
    };
    _6297 = NOVALUE;
    switch ( _0 ){ 

        /** 		case M_NORMAL then*/
        case 1:

        /** 			puts(1,"M_NORMAL")*/
        EPuts(1, _6300); // DJP 
        goto L3; // [86] 120

        /** 		case M_TEMP then*/
        case 3:

        /** 			puts(1,"M_TEMP")*/
        EPuts(1, _6301); // DJP 
        goto L3; // [97] 120

        /** 		case M_CONSTANT then*/
        case 2:

        /** 			puts(1,"M_CONSTANT")*/
        EPuts(1, _6302); // DJP 
        goto L3; // [108] 120

        /** 		case M_BLOCK then*/
        case 4:

        /** 			puts(1,"M_BLOCK")*/
        EPuts(1, _6303); // DJP 
    ;}L3: 

    /** 	puts(1,{10,10})*/
    EPuts(1, _154); // DJP 

    /** end procedure*/
    DeRef(_s_obj_11451);
    return;
    ;
}


int _12symtab_entry(int _x_11541)
{
    int _6323 = NOVALUE;
    int _6322 = NOVALUE;
    int _6321 = NOVALUE;
    int _6320 = NOVALUE;
    int _6319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(x) = SIZEOF_ROUTINE_ENTRY or*/
    if (IS_SEQUENCE(_x_11541)){
            _6319 = SEQ_PTR(_x_11541)->length;
    }
    else {
        _6319 = 1;
    }
    _6320 = (_6319 == _12SIZEOF_ROUTINE_ENTRY_11479);
    _6319 = NOVALUE;
    if (IS_SEQUENCE(_x_11541)){
            _6321 = SEQ_PTR(_x_11541)->length;
    }
    else {
        _6321 = 1;
    }
    _6322 = (_6321 == _12SIZEOF_VAR_ENTRY_11482);
    _6321 = NOVALUE;
    _6323 = (_6320 != 0 || _6322 != 0);
    _6320 = NOVALUE;
    _6322 = NOVALUE;
    DeRefDS(_x_11541);
    return _6323;
    ;
}


int _12symtab_index(int _x_11549)
{
    int _6332 = NOVALUE;
    int _6331 = NOVALUE;
    int _6330 = NOVALUE;
    int _6329 = NOVALUE;
    int _6328 = NOVALUE;
    int _6327 = NOVALUE;
    int _6325 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_11549)) {
        _1 = (long)(DBL_PTR(_x_11549)->dbl);
        DeRefDS(_x_11549);
        _x_11549 = _1;
    }

    /** 	if x = 0 then*/
    if (_x_11549 != 0)
    goto L1; // [5] 18

    /** 		return TRUE -- NULL value*/
    return _9TRUE_431;
L1: 

    /** 	if x < 0 or x > length(SymTab) then*/
    _6325 = (_x_11549 < 0);
    if (_6325 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_13SymTab_10636)){
            _6327 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _6327 = 1;
    }
    _6328 = (_x_11549 > _6327);
    _6327 = NOVALUE;
    if (_6328 == 0)
    {
        DeRef(_6328);
        _6328 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_6328);
        _6328 = NOVALUE;
    }
L2: 

    /** 		return FALSE*/
    DeRef(_6325);
    _6325 = NOVALUE;
    return _9FALSE_429;
L3: 

    /** 	return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _6329 = (int)*(((s1_ptr)_2)->base + _x_11549);
    if (IS_SEQUENCE(_6329)){
            _6330 = SEQ_PTR(_6329)->length;
    }
    else {
        _6330 = 1;
    }
    _6329 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12SIZEOF_VAR_ENTRY_11482;
    *((int *)(_2+8)) = _12SIZEOF_ROUTINE_ENTRY_11479;
    *((int *)(_2+12)) = _12SIZEOF_TEMP_ENTRY_11488;
    *((int *)(_2+16)) = _12SIZEOF_BLOCK_ENTRY_11485;
    _6331 = MAKE_SEQ(_1);
    _6332 = find_from(_6330, _6331, 1);
    _6330 = NOVALUE;
    DeRefDS(_6331);
    _6331 = NOVALUE;
    DeRef(_6325);
    _6325 = NOVALUE;
    _6329 = NOVALUE;
    return _6332;
    ;
}


int _12temp_index(int _x_11567)
{
    int _6336 = NOVALUE;
    int _6335 = NOVALUE;
    int _6334 = NOVALUE;
    int _6333 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_11567)) {
        _1 = (long)(DBL_PTR(_x_11567)->dbl);
        DeRefDS(_x_11567);
        _x_11567 = _1;
    }

    /** 	return x >= 0 and x <= length(SymTab)*/
    _6333 = (_x_11567 >= 0);
    if (IS_SEQUENCE(_13SymTab_10636)){
            _6334 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _6334 = 1;
    }
    _6335 = (_x_11567 <= _6334);
    _6334 = NOVALUE;
    _6336 = (_6333 != 0 && _6335 != 0);
    _6333 = NOVALUE;
    _6335 = NOVALUE;
    return _6336;
    ;
}


int _12token(int _t_11577)
{
    int _6380 = NOVALUE;
    int _6379 = NOVALUE;
    int _6378 = NOVALUE;
    int _6377 = NOVALUE;
    int _6376 = NOVALUE;
    int _6375 = NOVALUE;
    int _6374 = NOVALUE;
    int _6373 = NOVALUE;
    int _6372 = NOVALUE;
    int _6371 = NOVALUE;
    int _6369 = NOVALUE;
    int _6368 = NOVALUE;
    int _6367 = NOVALUE;
    int _6366 = NOVALUE;
    int _6365 = NOVALUE;
    int _6364 = NOVALUE;
    int _6363 = NOVALUE;
    int _6362 = NOVALUE;
    int _6361 = NOVALUE;
    int _6360 = NOVALUE;
    int _6359 = NOVALUE;
    int _6358 = NOVALUE;
    int _6357 = NOVALUE;
    int _6356 = NOVALUE;
    int _6355 = NOVALUE;
    int _6354 = NOVALUE;
    int _6353 = NOVALUE;
    int _6352 = NOVALUE;
    int _6351 = NOVALUE;
    int _6350 = NOVALUE;
    int _6349 = NOVALUE;
    int _6348 = NOVALUE;
    int _6347 = NOVALUE;
    int _6346 = NOVALUE;
    int _6345 = NOVALUE;
    int _6344 = NOVALUE;
    int _6343 = NOVALUE;
    int _6341 = NOVALUE;
    int _6340 = NOVALUE;
    int _6338 = NOVALUE;
    int _6337 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(t) then*/
    _6337 = IS_ATOM(_t_11577);
    if (_6337 == 0)
    {
        _6337 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6337 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_t_11577);
    return _9FALSE_429;
L1: 

    /** 	if length(t) != 2 then*/
    if (IS_SEQUENCE(_t_11577)){
            _6338 = SEQ_PTR(_t_11577)->length;
    }
    else {
        _6338 = 1;
    }
    if (_6338 == 2)
    goto L2; // [23] 36

    /** 		return FALSE*/
    DeRef(_t_11577);
    return _9FALSE_429;
L2: 

    /** 	if not integer(t[T_ID]) then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6340 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6340))
    _6341 = 1;
    else if (IS_ATOM_DBL(_6340))
    _6341 = IS_ATOM_INT(DoubleToInt(_6340));
    else
    _6341 = 0;
    _6340 = NOVALUE;
    if (_6341 != 0)
    goto L3; // [45] 57
    _6341 = NOVALUE;

    /** 		return FALSE*/
    DeRef(_t_11577);
    return _9FALSE_429;
L3: 

    /** 	if t[T_ID] = VARIABLE and (t[T_SYM] < 0 or symtab_index(t[T_SYM])) then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6343 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6343)) {
        _6344 = (_6343 == -100);
    }
    else {
        _6344 = binary_op(EQUALS, _6343, -100);
    }
    _6343 = NOVALUE;
    if (IS_ATOM_INT(_6344)) {
        if (_6344 == 0) {
            goto L4; // [69] 110
        }
    }
    else {
        if (DBL_PTR(_6344)->dbl == 0.0) {
            goto L4; // [69] 110
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6346 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6346)) {
        _6347 = (_6346 < 0);
    }
    else {
        _6347 = binary_op(LESS, _6346, 0);
    }
    _6346 = NOVALUE;
    if (IS_ATOM_INT(_6347)) {
        if (_6347 != 0) {
            DeRef(_6348);
            _6348 = 1;
            goto L5; // [81] 97
        }
    }
    else {
        if (DBL_PTR(_6347)->dbl != 0.0) {
            DeRef(_6348);
            _6348 = 1;
            goto L5; // [81] 97
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6349 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6349);
    _6350 = _12symtab_index(_6349);
    _6349 = NOVALUE;
    DeRef(_6348);
    if (IS_ATOM_INT(_6350))
    _6348 = (_6350 != 0);
    else
    _6348 = DBL_PTR(_6350)->dbl != 0.0;
L5: 
    if (_6348 == 0)
    {
        _6348 = NOVALUE;
        goto L4; // [98] 110
    }
    else{
        _6348 = NOVALUE;
    }

    /** 		return TRUE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    return _9TRUE_431;
L4: 

    /** 	if QUESTION_MARK <= t[T_ID] and t[T_ID] <= -1 then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6351 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6351)) {
        _6352 = (-31 <= _6351);
    }
    else {
        _6352 = binary_op(LESSEQ, -31, _6351);
    }
    _6351 = NOVALUE;
    if (IS_ATOM_INT(_6352)) {
        if (_6352 == 0) {
            goto L6; // [122] 147
        }
    }
    else {
        if (DBL_PTR(_6352)->dbl == 0.0) {
            goto L6; // [122] 147
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6354 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6354)) {
        _6355 = (_6354 <= -1);
    }
    else {
        _6355 = binary_op(LESSEQ, _6354, -1);
    }
    _6354 = NOVALUE;
    if (_6355 == 0) {
        DeRef(_6355);
        _6355 = NOVALUE;
        goto L6; // [135] 147
    }
    else {
        if (!IS_ATOM_INT(_6355) && DBL_PTR(_6355)->dbl == 0.0){
            DeRef(_6355);
            _6355 = NOVALUE;
            goto L6; // [135] 147
        }
        DeRef(_6355);
        _6355 = NOVALUE;
    }
    DeRef(_6355);
    _6355 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    return _9TRUE_431;
L6: 

    /** 	if t[T_ID] >= 1 and t[T_ID] <= MAX_OPCODE then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6356 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6356)) {
        _6357 = (_6356 >= 1);
    }
    else {
        _6357 = binary_op(GREATEREQ, _6356, 1);
    }
    _6356 = NOVALUE;
    if (IS_ATOM_INT(_6357)) {
        if (_6357 == 0) {
            goto L7; // [157] 184
        }
    }
    else {
        if (DBL_PTR(_6357)->dbl == 0.0) {
            goto L7; // [157] 184
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6359 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6359)) {
        _6360 = (_6359 <= 213);
    }
    else {
        _6360 = binary_op(LESSEQ, _6359, 213);
    }
    _6359 = NOVALUE;
    if (_6360 == 0) {
        DeRef(_6360);
        _6360 = NOVALUE;
        goto L7; // [172] 184
    }
    else {
        if (!IS_ATOM_INT(_6360) && DBL_PTR(_6360)->dbl == 0.0){
            DeRef(_6360);
            _6360 = NOVALUE;
            goto L7; // [172] 184
        }
        DeRef(_6360);
        _6360 = NOVALUE;
    }
    DeRef(_6360);
    _6360 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    DeRef(_6357);
    _6357 = NOVALUE;
    return _9TRUE_431;
L7: 

    /** 	if END <= t[T_ID] and t[T_ID] <=  ROUTINE then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6361 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6361)) {
        _6362 = (402 <= _6361);
    }
    else {
        _6362 = binary_op(LESSEQ, 402, _6361);
    }
    _6361 = NOVALUE;
    if (IS_ATOM_INT(_6362)) {
        if (_6362 == 0) {
            goto L8; // [196] 280
        }
    }
    else {
        if (DBL_PTR(_6362)->dbl == 0.0) {
            goto L8; // [196] 280
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6364 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6364)) {
        _6365 = (_6364 <= 432);
    }
    else {
        _6365 = binary_op(LESSEQ, _6364, 432);
    }
    _6364 = NOVALUE;
    if (_6365 == 0) {
        DeRef(_6365);
        _6365 = NOVALUE;
        goto L8; // [211] 280
    }
    else {
        if (!IS_ATOM_INT(_6365) && DBL_PTR(_6365)->dbl == 0.0){
            DeRef(_6365);
            _6365 = NOVALUE;
            goto L8; // [211] 280
        }
        DeRef(_6365);
        _6365 = NOVALUE;
    }
    DeRef(_6365);
    _6365 = NOVALUE;

    /** 		if t[T_ID] != IGNORED and t[T_ID] < 500 and symtab_index(t[T_SYM]) = 0 then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6366 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6366)) {
        _6367 = (_6366 != 509);
    }
    else {
        _6367 = binary_op(NOTEQ, _6366, 509);
    }
    _6366 = NOVALUE;
    if (IS_ATOM_INT(_6367)) {
        if (_6367 == 0) {
            DeRef(_6368);
            _6368 = 0;
            goto L9; // [226] 242
        }
    }
    else {
        if (DBL_PTR(_6367)->dbl == 0.0) {
            DeRef(_6368);
            _6368 = 0;
            goto L9; // [226] 242
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6369 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6369)) {
        _6371 = (_6369 < 500);
    }
    else {
        _6371 = binary_op(LESS, _6369, 500);
    }
    _6369 = NOVALUE;
    DeRef(_6368);
    if (IS_ATOM_INT(_6371))
    _6368 = (_6371 != 0);
    else
    _6368 = DBL_PTR(_6371)->dbl != 0.0;
L9: 
    if (_6368 == 0) {
        goto LA; // [242] 271
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6373 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6373);
    _6374 = _12symtab_index(_6373);
    _6373 = NOVALUE;
    if (IS_ATOM_INT(_6374)) {
        _6375 = (_6374 == 0);
    }
    else {
        _6375 = binary_op(EQUALS, _6374, 0);
    }
    DeRef(_6374);
    _6374 = NOVALUE;
    if (_6375 == 0) {
        DeRef(_6375);
        _6375 = NOVALUE;
        goto LA; // [259] 271
    }
    else {
        if (!IS_ATOM_INT(_6375) && DBL_PTR(_6375)->dbl == 0.0){
            DeRef(_6375);
            _6375 = NOVALUE;
            goto LA; // [259] 271
        }
        DeRef(_6375);
        _6375 = NOVALUE;
    }
    DeRef(_6375);
    _6375 = NOVALUE;

    /** 			return FALSE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    DeRef(_6357);
    _6357 = NOVALUE;
    DeRef(_6362);
    _6362 = NOVALUE;
    DeRef(_6367);
    _6367 = NOVALUE;
    DeRef(_6371);
    _6371 = NOVALUE;
    return _9FALSE_429;
LA: 

    /** 		return TRUE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    DeRef(_6357);
    _6357 = NOVALUE;
    DeRef(_6362);
    _6362 = NOVALUE;
    DeRef(_6367);
    _6367 = NOVALUE;
    DeRef(_6371);
    _6371 = NOVALUE;
    return _9TRUE_431;
L8: 

    /** 	if FUNC <= t[T_ID] and t[T_ID] <= NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_11577);
    _6376 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6376)) {
        _6377 = (501 <= _6376);
    }
    else {
        _6377 = binary_op(LESSEQ, 501, _6376);
    }
    _6376 = NOVALUE;
    if (IS_ATOM_INT(_6377)) {
        if (_6377 == 0) {
            goto LB; // [292] 319
        }
    }
    else {
        if (DBL_PTR(_6377)->dbl == 0.0) {
            goto LB; // [292] 319
        }
    }
    _2 = (int)SEQ_PTR(_t_11577);
    _6379 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6379)) {
        _6380 = (_6379 <= 523);
    }
    else {
        _6380 = binary_op(LESSEQ, _6379, 523);
    }
    _6379 = NOVALUE;
    if (_6380 == 0) {
        DeRef(_6380);
        _6380 = NOVALUE;
        goto LB; // [307] 319
    }
    else {
        if (!IS_ATOM_INT(_6380) && DBL_PTR(_6380)->dbl == 0.0){
            DeRef(_6380);
            _6380 = NOVALUE;
            goto LB; // [307] 319
        }
        DeRef(_6380);
        _6380 = NOVALUE;
    }
    DeRef(_6380);
    _6380 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    DeRef(_6357);
    _6357 = NOVALUE;
    DeRef(_6362);
    _6362 = NOVALUE;
    DeRef(_6367);
    _6367 = NOVALUE;
    DeRef(_6371);
    _6371 = NOVALUE;
    DeRef(_6377);
    _6377 = NOVALUE;
    return _9TRUE_431;
LB: 

    /** 	return FALSE*/
    DeRef(_t_11577);
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6347);
    _6347 = NOVALUE;
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    DeRef(_6357);
    _6357 = NOVALUE;
    DeRef(_6362);
    _6362 = NOVALUE;
    DeRef(_6367);
    _6367 = NOVALUE;
    DeRef(_6371);
    _6371 = NOVALUE;
    DeRef(_6377);
    _6377 = NOVALUE;
    return _9FALSE_429;
    ;
}


int _12sequence_of_tokens(int _x_11651)
{
    int _t_11652 = NOVALUE;
    int _6382 = NOVALUE;
    int _6381 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _6381 = IS_ATOM(_x_11651);
    if (_6381 == 0)
    {
        _6381 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6381 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_x_11651);
    DeRef(_t_11652);
    return _9FALSE_429;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_11651)){
            _6382 = SEQ_PTR(_x_11651)->length;
    }
    else {
        _6382 = 1;
    }
    {
        int _i_11657;
        _i_11657 = 1;
L2: 
        if (_i_11657 > _6382){
            goto L3; // [23] 48
        }

        /** 		type_i = i*/
        _12type_i_11332 = _i_11657;

        /** 		t = x[i]*/
        DeRef(_t_11652);
        _2 = (int)SEQ_PTR(_x_11651);
        _t_11652 = (int)*(((s1_ptr)_2)->base + _i_11657);
        Ref(_t_11652);

        /** 	end for*/
        _i_11657 = _i_11657 + 1;
        goto L2; // [43] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_x_11651);
    DeRef(_t_11652);
    return _9TRUE_431;
    ;
}


int _12sequence_of_opcodes(int _s_11663)
{
    int _oc_11664 = NOVALUE;
    int _6385 = NOVALUE;
    int _6384 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _6384 = IS_ATOM(_s_11663);
    if (_6384 == 0)
    {
        _6384 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6384 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_s_11663);
    return _9FALSE_429;
L1: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_11663)){
            _6385 = SEQ_PTR(_s_11663)->length;
    }
    else {
        _6385 = 1;
    }
    {
        int _i_11669;
        _i_11669 = 1;
L2: 
        if (_i_11669 > _6385){
            goto L3; // [23] 45
        }

        /** 		oc = s[i]*/
        _2 = (int)SEQ_PTR(_s_11663);
        _oc_11664 = (int)*(((s1_ptr)_2)->base + _i_11669);
        if (!IS_ATOM_INT(_oc_11664)){
            _oc_11664 = (long)DBL_PTR(_oc_11664)->dbl;
        }

        /** 	end for*/
        _i_11669 = _i_11669 + 1;
        goto L2; // [40] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_s_11663);
    return _9TRUE_431;
    ;
}


int _12file(int _f_11675)
{
    int _6389 = NOVALUE;
    int _6388 = NOVALUE;
    int _6387 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_11675)) {
        _1 = (long)(DBL_PTR(_f_11675)->dbl);
        DeRefDS(_f_11675);
        _f_11675 = _1;
    }

    /** 	return f >= -1 and f < 100 -- rough limit*/
    _6387 = (_f_11675 >= -1);
    _6388 = (_f_11675 < 100);
    _6389 = (_6387 != 0 && _6388 != 0);
    _6387 = NOVALUE;
    _6388 = NOVALUE;
    return _6389;
    ;
}


int _12symtab_pointer(int _x_62757)
{
    int _31350 = NOVALUE;
    int _31349 = NOVALUE;
    int _31348 = NOVALUE;
    int _31347 = NOVALUE;
    int _31346 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_62757)) {
        _1 = (long)(DBL_PTR(_x_62757)->dbl);
        DeRefDS(_x_62757);
        _x_62757 = _1;
    }

    /** 	return x = -1 or symtab_index(x) or forward_reference(x)*/
    _31346 = (_x_62757 == -1);
    _31347 = _12symtab_index(_x_62757);
    if (IS_ATOM_INT(_31347)) {
        _31348 = (_31346 != 0 || _31347 != 0);
    }
    else {
        _31348 = binary_op(OR, _31346, _31347);
    }
    _31346 = NOVALUE;
    DeRef(_31347);
    _31347 = NOVALUE;
    _31349 = _29forward_reference(_x_62757);
    if (IS_ATOM_INT(_31348) && IS_ATOM_INT(_31349)) {
        _31350 = (_31348 != 0 || _31349 != 0);
    }
    else {
        _31350 = binary_op(OR, _31348, _31349);
    }
    DeRef(_31348);
    _31348 = NOVALUE;
    DeRef(_31349);
    _31349 = NOVALUE;
    return _31350;
    ;
}



// 0x830690D0
