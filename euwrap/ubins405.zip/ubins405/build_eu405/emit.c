// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _37Push(int _x_50046)
{
    int _26160 = NOVALUE;
    int _26158 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_50046)) {
        _1 = (long)(DBL_PTR(_x_50046)->dbl);
        DeRefDS(_x_50046);
        _x_50046 = _1;
    }

    /** 	cgi += 1*/
    _37cgi_49807 = _37cgi_49807 + 1;

    /** 	if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_37cg_stack_49806)){
            _26158 = SEQ_PTR(_37cg_stack_49806)->length;
    }
    else {
        _26158 = 1;
    }
    if (_37cgi_49807 <= _26158)
    goto L1; // [20] 37

    /** 		cg_stack &= repeat(0, 400)*/
    _26160 = Repeat(0, 400);
    Concat((object_ptr)&_37cg_stack_49806, _37cg_stack_49806, _26160);
    DeRefDS(_26160);
    _26160 = NOVALUE;
L1: 

    /** 	cg_stack[cgi] = x*/
    _2 = (int)SEQ_PTR(_37cg_stack_49806);
    _2 = (int)(((s1_ptr)_2)->base + _37cgi_49807);
    _1 = *(int *)_2;
    *(int *)_2 = _x_50046;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


int _37Top()
{
    int _26162 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_37cg_stack_49806);
    _26162 = (int)*(((s1_ptr)_2)->base + _37cgi_49807);
    Ref(_26162);
    return _26162;
    ;
}


int _37Pop()
{
    int _t_50059 = NOVALUE;
    int _s_50065 = NOVALUE;
    int _26174 = NOVALUE;
    int _26172 = NOVALUE;
    int _26170 = NOVALUE;
    int _26167 = NOVALUE;
    int _26166 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_37cg_stack_49806);
    _t_50059 = (int)*(((s1_ptr)_2)->base + _37cgi_49807);
    if (!IS_ATOM_INT(_t_50059)){
        _t_50059 = (long)DBL_PTR(_t_50059)->dbl;
    }

    /** 	cgi -= 1*/
    _37cgi_49807 = _37cgi_49807 - 1;

    /** 	if t > 0 then*/
    if (_t_50059 <= 0)
    goto L1; // [23] 116

    /** 		symtab_index s = t -- for type checking*/
    _s_50065 = _t_50059;

    /** 		if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26166 = (int)*(((s1_ptr)_2)->base + _t_50059);
    _2 = (int)SEQ_PTR(_26166);
    _26167 = (int)*(((s1_ptr)_2)->base + 3);
    _26166 = NOVALUE;
    if (binary_op_a(NOTEQ, _26167, 3)){
        _26167 = NOVALUE;
        goto L2; // [50] 115
    }
    _26167 = NOVALUE;

    /** 			if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_12use_private_list_11796 != 0)
    goto L3; // [58] 82

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50059 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26170 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** 			elsif find(t, private_sym) = 0 then*/
    _26172 = find_from(_t_50059, _12private_sym_11795, 1);
    if (_26172 != 0)
    goto L5; // [91] 113

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50059 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26174 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** 	return t*/
    return _t_50059;
    ;
}


void _37TempKeep(int _x_50093)
{
    int _26181 = NOVALUE;
    int _26180 = NOVALUE;
    int _26179 = NOVALUE;
    int _26178 = NOVALUE;
    int _26177 = NOVALUE;
    int _26176 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50093)) {
        _1 = (long)(DBL_PTR(_x_50093)->dbl);
        DeRefDS(_x_50093);
        _x_50093 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26176 = (_x_50093 > 0);
    if (_26176 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26178 = (int)*(((s1_ptr)_2)->base + _x_50093);
    _2 = (int)SEQ_PTR(_26178);
    _26179 = (int)*(((s1_ptr)_2)->base + 3);
    _26178 = NOVALUE;
    if (IS_ATOM_INT(_26179)) {
        _26180 = (_26179 == 3);
    }
    else {
        _26180 = binary_op(EQUALS, _26179, 3);
    }
    _26179 = NOVALUE;
    if (_26180 == 0) {
        DeRef(_26180);
        _26180 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26180) && DBL_PTR(_26180)->dbl == 0.0){
            DeRef(_26180);
            _26180 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26180);
        _26180 = NOVALUE;
    }
    DeRef(_26180);
    _26180 = NOVALUE;

    /** 		SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50093 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26181 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26176);
    _26176 = NOVALUE;
    return;
    ;
}


void _37TempFree(int _x_50111)
{
    int _26187 = NOVALUE;
    int _26185 = NOVALUE;
    int _26184 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50111)) {
        _1 = (long)(DBL_PTR(_x_50111)->dbl);
        DeRefDS(_x_50111);
        _x_50111 = _1;
    }

    /** 	if x > 0 then*/
    if (_x_50111 <= 0)
    goto L1; // [5] 53

    /** 		if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26184 = (int)*(((s1_ptr)_2)->base + _x_50111);
    _2 = (int)SEQ_PTR(_26184);
    _26185 = (int)*(((s1_ptr)_2)->base + 3);
    _26184 = NOVALUE;
    if (binary_op_a(NOTEQ, _26185, 3)){
        _26185 = NOVALUE;
        goto L2; // [25] 52
    }
    _26185 = NOVALUE;

    /** 			SymTab[x][S_SCOPE] = FREE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50111 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26187 = NOVALUE;

    /** 			clear_temp( x )*/
    _37clear_temp(_x_50111);
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


void _37TempInteger(int _x_50130)
{
    int _26194 = NOVALUE;
    int _26193 = NOVALUE;
    int _26192 = NOVALUE;
    int _26191 = NOVALUE;
    int _26190 = NOVALUE;
    int _26189 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50130)) {
        _1 = (long)(DBL_PTR(_x_50130)->dbl);
        DeRefDS(_x_50130);
        _x_50130 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26189 = (_x_50130 > 0);
    if (_26189 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26191 = (int)*(((s1_ptr)_2)->base + _x_50130);
    _2 = (int)SEQ_PTR(_26191);
    _26192 = (int)*(((s1_ptr)_2)->base + 3);
    _26191 = NOVALUE;
    if (IS_ATOM_INT(_26192)) {
        _26193 = (_26192 == 3);
    }
    else {
        _26193 = binary_op(EQUALS, _26192, 3);
    }
    _26192 = NOVALUE;
    if (_26193 == 0) {
        DeRef(_26193);
        _26193 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26193) && DBL_PTR(_26193)->dbl == 0.0){
            DeRef(_26193);
            _26193 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26193);
        _26193 = NOVALUE;
    }
    DeRef(_26193);
    _26193 = NOVALUE;

    /** 		SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26194 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26189);
    _26189 = NOVALUE;
    return;
    ;
}


int _37LexName(int _t_50147, int _defname_50148)
{
    int _name_50150 = NOVALUE;
    int _26203 = NOVALUE;
    int _26201 = NOVALUE;
    int _26199 = NOVALUE;
    int _26198 = NOVALUE;
    int _26197 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_50147)) {
        _1 = (long)(DBL_PTR(_t_50147)->dbl);
        DeRefDS(_t_50147);
        _t_50147 = _1;
    }

    /** 	for i = 1 to length(token_name) do*/
    _26197 = 80;
    {
        int _i_50152;
        _i_50152 = 1;
L1: 
        if (_i_50152 > 80){
            goto L2; // [12] 82
        }

        /** 		if t = token_name[i][LEX_NUMBER] then*/
        _2 = (int)SEQ_PTR(_37token_name_49814);
        _26198 = (int)*(((s1_ptr)_2)->base + _i_50152);
        _2 = (int)SEQ_PTR(_26198);
        _26199 = (int)*(((s1_ptr)_2)->base + 1);
        _26198 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_50147, _26199)){
            _26199 = NOVALUE;
            goto L3; // [31] 75
        }
        _26199 = NOVALUE;

        /** 			name = token_name[i][LEX_NAME]*/
        _2 = (int)SEQ_PTR(_37token_name_49814);
        _26201 = (int)*(((s1_ptr)_2)->base + _i_50152);
        DeRef(_name_50150);
        _2 = (int)SEQ_PTR(_26201);
        _name_50150 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_name_50150);
        _26201 = NOVALUE;

        /** 			if not find(' ', name) then*/
        _26203 = find_from(32, _name_50150, 1);
        if (_26203 != 0)
        goto L4; // [56] 68
        _26203 = NOVALUE;

        /** 				name = "'" & name & "'"*/
        {
            int concat_list[3];

            concat_list[0] = _26205;
            concat_list[1] = _name_50150;
            concat_list[2] = _26205;
            Concat_N((object_ptr)&_name_50150, concat_list, 3);
        }
L4: 

        /** 			return name*/
        DeRefDS(_defname_50148);
        return _name_50150;
L3: 

        /** 	end for*/
        _i_50152 = _i_50152 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** 	return defname -- try to avoid this case*/
    DeRef(_name_50150);
    return _defname_50148;
    ;
}


void _37InitEmit()
{
    int _0, _1, _2;
    

    /** 	cg_stack = repeat(0, 400)*/
    DeRef(_37cg_stack_49806);
    _37cg_stack_49806 = Repeat(0, 400);

    /** 	cgi = 0*/
    _37cgi_49807 = 0;

    /** end procedure*/
    return;
    ;
}


int _37IsInteger(int _sym_50171)
{
    int _mode_50172 = NOVALUE;
    int _t_50174 = NOVALUE;
    int _pt_50175 = NOVALUE;
    int _26228 = NOVALUE;
    int _26227 = NOVALUE;
    int _26225 = NOVALUE;
    int _26224 = NOVALUE;
    int _26223 = NOVALUE;
    int _26221 = NOVALUE;
    int _26220 = NOVALUE;
    int _26219 = NOVALUE;
    int _26218 = NOVALUE;
    int _26216 = NOVALUE;
    int _26212 = NOVALUE;
    int _26209 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_50171)) {
        _1 = (long)(DBL_PTR(_sym_50171)->dbl);
        DeRefDS(_sym_50171);
        _sym_50171 = _1;
    }

    /** 	if sym < 1 then*/
    if (_sym_50171 >= 1)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26209 = (int)*(((s1_ptr)_2)->base + _sym_50171);
    _2 = (int)SEQ_PTR(_26209);
    _mode_50172 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_50172)){
        _mode_50172 = (long)DBL_PTR(_mode_50172)->dbl;
    }
    _26209 = NOVALUE;

    /** 	if mode = M_NORMAL then*/
    if (_mode_50172 != 1)
    goto L2; // [36] 136

    /** 		t = SymTab[sym][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26212 = (int)*(((s1_ptr)_2)->base + _sym_50171);
    _2 = (int)SEQ_PTR(_26212);
    _t_50174 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_50174)){
        _t_50174 = (long)DBL_PTR(_t_50174)->dbl;
    }
    _26212 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_50174 != _52integer_type_45737)
    goto L3; // [60] 73

    /** 			return TRUE*/
    return _9TRUE_431;
L3: 

    /** 		if t > 0 then*/
    if (_t_50174 <= 0)
    goto L4; // [75] 215

    /** 			pt = SymTab[t][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26216 = (int)*(((s1_ptr)_2)->base + _t_50174);
    _2 = (int)SEQ_PTR(_26216);
    _pt_50175 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_50175)){
        _pt_50175 = (long)DBL_PTR(_pt_50175)->dbl;
    }
    _26216 = NOVALUE;

    /** 			if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_50175 == 0) {
        goto L4; // [97] 215
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26219 = (int)*(((s1_ptr)_2)->base + _pt_50175);
    _2 = (int)SEQ_PTR(_26219);
    _26220 = (int)*(((s1_ptr)_2)->base + 15);
    _26219 = NOVALUE;
    if (IS_ATOM_INT(_26220)) {
        _26221 = (_26220 == _52integer_type_45737);
    }
    else {
        _26221 = binary_op(EQUALS, _26220, _52integer_type_45737);
    }
    _26220 = NOVALUE;
    if (_26221 == 0) {
        DeRef(_26221);
        _26221 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26221) && DBL_PTR(_26221)->dbl == 0.0){
            DeRef(_26221);
            _26221 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26221);
        _26221 = NOVALUE;
    }
    DeRef(_26221);
    _26221 = NOVALUE;

    /** 				return TRUE   -- usertype(integer x)*/
    return _9TRUE_431;
    goto L4; // [133] 215
L2: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_50172 != 2)
    goto L5; // [140] 176

    /** 		if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26223 = (int)*(((s1_ptr)_2)->base + _sym_50171);
    _2 = (int)SEQ_PTR(_26223);
    _26224 = (int)*(((s1_ptr)_2)->base + 1);
    _26223 = NOVALUE;
    if (IS_ATOM_INT(_26224))
    _26225 = 1;
    else if (IS_ATOM_DBL(_26224))
    _26225 = IS_ATOM_INT(DoubleToInt(_26224));
    else
    _26225 = 0;
    _26224 = NOVALUE;
    if (_26225 == 0)
    {
        _26225 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26225 = NOVALUE;
    }

    /** 			return TRUE*/
    return _9TRUE_431;
    goto L4; // [173] 215
L5: 

    /** 	elsif mode = M_TEMP then*/
    if (_mode_50172 != 3)
    goto L6; // [180] 214

    /** 		if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26227 = (int)*(((s1_ptr)_2)->base + _sym_50171);
    _2 = (int)SEQ_PTR(_26227);
    _26228 = (int)*(((s1_ptr)_2)->base + 5);
    _26227 = NOVALUE;
    if (binary_op_a(NOTEQ, _26228, 1)){
        _26228 = NOVALUE;
        goto L7; // [200] 213
    }
    _26228 = NOVALUE;

    /** 			return TRUE*/
    return _9TRUE_431;
L7: 
L6: 
L4: 

    /** 	return FALSE*/
    return _9FALSE_429;
    ;
}


void _37emit(int _val_50232)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_50232)) {
        _1 = (long)(DBL_PTR(_val_50232)->dbl);
        DeRefDS(_val_50232);
        _val_50232 = _1;
    }

    /** 	Code = append(Code, val)*/
    Append(&_12Code_11771, _12Code_11771, _val_50232);

    /** end procedure*/
    return;
    ;
}


void _37emit_opnd(int _opnd_50239)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_50239)) {
        _1 = (long)(DBL_PTR(_opnd_50239)->dbl);
        DeRefDS(_opnd_50239);
        _opnd_50239 = _1;
    }

    /** 		Push(opnd)*/
    _37Push(_opnd_50239);

    /** 		previous_op = -1  -- N.B.*/
    _12previous_op_11781 = -1;

    /** end procedure*/
    return;
    ;
}


void _37emit_addr(int _x_50243)
{
    int _0, _1, _2;
    

    /** 		Code = append(Code, x)*/
    Ref(_x_50243);
    Append(&_12Code_11771, _12Code_11771, _x_50243);

    /** end procedure*/
    DeRef(_x_50243);
    return;
    ;
}


void _37emit_opcode(int _op_50249)
{
    int _0, _1, _2;
    

    /** 	Code = append(Code, op)*/
    Append(&_12Code_11771, _12Code_11771, _op_50249);

    /** end procedure*/
    return;
    ;
}


void _37emit_temp(int _tempsym_50283, int _referenced_50284)
{
    int _26259 = NOVALUE;
    int _26258 = NOVALUE;
    int _26257 = NOVALUE;
    int _26256 = NOVALUE;
    int _26255 = NOVALUE;
    int _26254 = NOVALUE;
    int _26253 = NOVALUE;
    int _26252 = NOVALUE;
    int _26251 = NOVALUE;
    int _26250 = NOVALUE;
    int _26249 = NOVALUE;
    int _26248 = NOVALUE;
    int _26247 = NOVALUE;
    int _26246 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_referenced_50284)) {
        _1 = (long)(DBL_PTR(_referenced_50284)->dbl);
        DeRefDS(_referenced_50284);
        _referenced_50284 = _1;
    }

    /** 	if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_12TRANSLATE_11319 != 0)
    goto L1; // [7] 129

    /** 		if sequence(tempsym) then*/
    _26246 = IS_SEQUENCE(_tempsym_50283);
    if (_26246 == 0)
    {
        _26246 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26246 = NOVALUE;
    }

    /** 			for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_50283)){
            _26247 = SEQ_PTR(_tempsym_50283)->length;
    }
    else {
        _26247 = 1;
    }
    {
        int _i_50291;
        _i_50291 = 1;
L3: 
        if (_i_50291 > _26247){
            goto L4; // [23] 50
        }

        /** 				emit_temp( tempsym[i], referenced )*/
        _2 = (int)SEQ_PTR(_tempsym_50283);
        _26248 = (int)*(((s1_ptr)_2)->base + _i_50291);
        DeRef(_26249);
        _26249 = _referenced_50284;
        Ref(_26248);
        _37emit_temp(_26248, _26249);
        _26248 = NOVALUE;
        _26249 = NOVALUE;

        /** 			end for*/
        _i_50291 = _i_50291 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** 		elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_50283)) {
        _26250 = (_tempsym_50283 > 0);
    }
    else {
        _26250 = binary_op(GREATER, _tempsym_50283, 0);
    }
    if (IS_ATOM_INT(_26250)) {
        if (_26250 == 0) {
            DeRef(_26251);
            _26251 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26250)->dbl == 0.0) {
            DeRef(_26251);
            _26251 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_50283);
    _26252 = _52sym_mode(_tempsym_50283);
    if (IS_ATOM_INT(_26252)) {
        _26253 = (_26252 == 3);
    }
    else {
        _26253 = binary_op(EQUALS, _26252, 3);
    }
    DeRef(_26252);
    _26252 = NOVALUE;
    DeRef(_26251);
    if (IS_ATOM_INT(_26253))
    _26251 = (_26253 != 0);
    else
    _26251 = DBL_PTR(_26253)->dbl != 0.0;
L6: 
    if (_26251 == 0) {
        _26254 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_50283);
    _26255 = _37IsInteger(_tempsym_50283);
    if (IS_ATOM_INT(_26255)) {
        _26256 = (_26255 == 0);
    }
    else {
        _26256 = unary_op(NOT, _26255);
    }
    DeRef(_26255);
    _26255 = NOVALUE;
    if (IS_ATOM_INT(_26256))
    _26254 = (_26256 != 0);
    else
    _26254 = DBL_PTR(_26256)->dbl != 0.0;
L7: 
    if (_26254 == 0) {
        goto L8; // [92] 127
    }
    _26258 = find_from(_tempsym_50283, _37emitted_temps_50279, 1);
    _26259 = (_26258 == 0);
    _26258 = NOVALUE;
    if (_26259 == 0)
    {
        DeRef(_26259);
        _26259 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26259);
        _26259 = NOVALUE;
    }

    /** 			emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_37emitted_temps_50279) && IS_ATOM(_tempsym_50283)) {
        Ref(_tempsym_50283);
        Append(&_37emitted_temps_50279, _37emitted_temps_50279, _tempsym_50283);
    }
    else if (IS_ATOM(_37emitted_temps_50279) && IS_SEQUENCE(_tempsym_50283)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temps_50279, _37emitted_temps_50279, _tempsym_50283);
    }

    /** 			emitted_temp_referenced &= referenced*/
    Append(&_37emitted_temp_referenced_50280, _37emitted_temp_referenced_50280, _referenced_50284);
L8: 
L5: 
L1: 

    /** end procedure*/
    DeRef(_tempsym_50283);
    DeRef(_26250);
    _26250 = NOVALUE;
    DeRef(_26256);
    _26256 = NOVALUE;
    DeRef(_26253);
    _26253 = NOVALUE;
    return;
    ;
}


void _37flush_temps(int _except_for_50313)
{
    int _refs_50316 = NOVALUE;
    int _novalues_50317 = NOVALUE;
    int _sym_50322 = NOVALUE;
    int _26274 = NOVALUE;
    int _26273 = NOVALUE;
    int _26272 = NOVALUE;
    int _26271 = NOVALUE;
    int _26269 = NOVALUE;
    int _26265 = NOVALUE;
    int _26264 = NOVALUE;
    int _26262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** 		return*/
    DeRefDS(_except_for_50313);
    DeRef(_refs_50316);
    DeRefi(_novalues_50317);
    return;
L1: 

    /** 	sequence*/

    /** 		refs = {},*/
    RefDS(_21829);
    DeRef(_refs_50316);
    _refs_50316 = _21829;

    /** 		novalues = {}*/
    RefDS(_21829);
    DeRefi(_novalues_50317);
    _novalues_50317 = _21829;

    /** 	derefs = {}*/
    RefDS(_21829);
    DeRefi(_37derefs_50310);
    _37derefs_50310 = _21829;

    /** 	for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_37emitted_temps_50279)){
            _26262 = SEQ_PTR(_37emitted_temps_50279)->length;
    }
    else {
        _26262 = 1;
    }
    {
        int _i_50319;
        _i_50319 = 1;
L2: 
        if (_i_50319 > _26262){
            goto L3; // [46] 119
        }

        /** 		symtab_index sym = emitted_temps[i]*/
        _2 = (int)SEQ_PTR(_37emitted_temps_50279);
        _sym_50322 = (int)*(((s1_ptr)_2)->base + _i_50319);
        if (!IS_ATOM_INT(_sym_50322)){
            _sym_50322 = (long)DBL_PTR(_sym_50322)->dbl;
        }

        /** 		if find( sym, except_for ) then*/
        _26264 = find_from(_sym_50322, _except_for_50313, 1);
        if (_26264 == 0)
        {
            _26264 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26264 = NOVALUE;
        }

        /** 			continue*/
        goto L5; // [77] 114
L4: 

        /** 		if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (int)SEQ_PTR(_37emitted_temp_referenced_50280);
        _26265 = (int)*(((s1_ptr)_2)->base + _i_50319);
        if (binary_op_a(NOTEQ, _26265, 1)){
            _26265 = NOVALUE;
            goto L6; // [88] 103
        }
        _26265 = NOVALUE;

        /** 			derefs &= sym*/
        Append(&_37derefs_50310, _37derefs_50310, _sym_50322);
        goto L7; // [100] 110
L6: 

        /** 			novalues &= sym*/
        Append(&_novalues_50317, _novalues_50317, _sym_50322);
L7: 

        /** 	end for*/
L5: 
        _i_50319 = _i_50319 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** 	if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_50313)){
            _26269 = SEQ_PTR(_except_for_50313)->length;
    }
    else {
        _26269 = 1;
    }
    if (_26269 != 0)
    goto L8; // [124] 132
    _26269 = NOVALUE;

    /** 		clear_last()*/
    _37clear_last();
L8: 

    /** 	for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_37derefs_50310)){
            _26271 = SEQ_PTR(_37derefs_50310)->length;
    }
    else {
        _26271 = 1;
    }
    {
        int _i_50337;
        _i_50337 = 1;
L9: 
        if (_i_50337 > _26271){
            goto LA; // [139] 171
        }

        /** 		emit( DEREF_TEMP )*/
        _37emit(208);

        /** 		emit( derefs[i] )*/
        _2 = (int)SEQ_PTR(_37derefs_50310);
        _26272 = (int)*(((s1_ptr)_2)->base + _i_50337);
        _37emit(_26272);
        _26272 = NOVALUE;

        /** 	end for*/
        _i_50337 = _i_50337 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** 	for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_50317)){
            _26273 = SEQ_PTR(_novalues_50317)->length;
    }
    else {
        _26273 = 1;
    }
    {
        int _i_50342;
        _i_50342 = 1;
LB: 
        if (_i_50342 > _26273){
            goto LC; // [176] 206
        }

        /** 		emit( NOVALUE_TEMP )*/
        _37emit(209);

        /** 		emit( novalues[i] )*/
        _2 = (int)SEQ_PTR(_novalues_50317);
        _26274 = (int)*(((s1_ptr)_2)->base + _i_50342);
        _37emit(_26274);
        _26274 = NOVALUE;

        /** 	end for*/
        _i_50342 = _i_50342 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** 	emitted_temps = {}*/
    RefDS(_21829);
    DeRef(_37emitted_temps_50279);
    _37emitted_temps_50279 = _21829;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_21829);
    DeRef(_37emitted_temp_referenced_50280);
    _37emitted_temp_referenced_50280 = _21829;

    /** end procedure*/
    DeRefDS(_except_for_50313);
    DeRef(_refs_50316);
    DeRefi(_novalues_50317);
    return;
    ;
}


void _37flush_temp(int _temp_50349)
{
    int _except_for_50350 = NOVALUE;
    int _ix_50351 = NOVALUE;
    int _26276 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_50349)) {
        _1 = (long)(DBL_PTR(_temp_50349)->dbl);
        DeRefDS(_temp_50349);
        _temp_50349 = _1;
    }

    /** 	sequence except_for = emitted_temps*/
    RefDS(_37emitted_temps_50279);
    DeRef(_except_for_50350);
    _except_for_50350 = _37emitted_temps_50279;

    /** 	integer ix = find( temp, emitted_temps )*/
    _ix_50351 = find_from(_temp_50349, _37emitted_temps_50279, 1);

    /** 	if ix then*/
    if (_ix_50351 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** 		flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_50350);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50351)) ? _ix_50351 : (long)(DBL_PTR(_ix_50351)->dbl);
        int stop = (IS_ATOM_INT(_ix_50351)) ? _ix_50351 : (long)(DBL_PTR(_ix_50351)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_except_for_50350);
            DeRef(_26276);
            _26276 = _except_for_50350;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_50350), start, &_26276 );
            }
            else Tail(SEQ_PTR(_except_for_50350), stop+1, &_26276);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_50350), start, &_26276);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26276);
            _26276 = _1;
        }
    }
    _37flush_temps(_26276);
    _26276 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_except_for_50350);
    return;
    ;
}


void _37check_for_temps()
{
    int _26283 = NOVALUE;
    int _26282 = NOVALUE;
    int _26281 = NOVALUE;
    int _26280 = NOVALUE;
    int _26278 = NOVALUE;
    int _26277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_12TRANSLATE_11319 != 0) {
        _26277 = 1;
        goto L1; // [5] 19
    }
    _26278 = (_37last_op_50685 < 1);
    _26277 = (_26278 != 0);
L1: 
    if (_26277 != 0) {
        goto L2; // [19] 34
    }
    _26280 = (_37last_pc_50686 < 1);
    if (_26280 == 0)
    {
        DeRef(_26280);
        _26280 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26280);
        _26280 = NOVALUE;
    }
L2: 

    /** 		return*/
    DeRef(_26278);
    _26278 = NOVALUE;
    return;
L3: 

    /** 	emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_12Code_11771);
    _26281 = _64current_op(_37last_pc_50686, _12Code_11771);
    _26282 = _64get_target_sym(_26281);
    _26281 = NOVALUE;
    _2 = (int)SEQ_PTR(_37op_temp_ref_50501);
    _26283 = (int)*(((s1_ptr)_2)->base + _37last_op_50685);
    _37emit_temp(_26282, _26283);
    _26282 = NOVALUE;
    _26283 = NOVALUE;

    /** end procedure*/
    DeRef(_26278);
    _26278 = NOVALUE;
    return;
    ;
}


void _37clear_temp(int _tempsym_50376)
{
    int _ix_50377 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_50376)) {
        _1 = (long)(DBL_PTR(_tempsym_50376)->dbl);
        DeRefDS(_tempsym_50376);
        _tempsym_50376 = _1;
    }

    /** 	integer ix = find( tempsym, emitted_temps )*/
    _ix_50377 = find_from(_tempsym_50376, _37emitted_temps_50279, 1);

    /** 	if ix then*/
    if (_ix_50377 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_37emitted_temps_50279);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50377)) ? _ix_50377 : (long)(DBL_PTR(_ix_50377)->dbl);
        int stop = (IS_ATOM_INT(_ix_50377)) ? _ix_50377 : (long)(DBL_PTR(_ix_50377)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_37emitted_temps_50279), start, &_37emitted_temps_50279 );
            }
            else Tail(SEQ_PTR(_37emitted_temps_50279), stop+1, &_37emitted_temps_50279);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_37emitted_temps_50279), start, &_37emitted_temps_50279);
        }
        else {
            assign_slice_seq = &assign_space;
            _37emitted_temps_50279 = Remove_elements(start, stop, (SEQ_PTR(_37emitted_temps_50279)->ref == 1));
        }
    }

    /** 		emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_37emitted_temp_referenced_50280);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50377)) ? _ix_50377 : (long)(DBL_PTR(_ix_50377)->dbl);
        int stop = (IS_ATOM_INT(_ix_50377)) ? _ix_50377 : (long)(DBL_PTR(_ix_50377)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_37emitted_temp_referenced_50280), start, &_37emitted_temp_referenced_50280 );
            }
            else Tail(SEQ_PTR(_37emitted_temp_referenced_50280), stop+1, &_37emitted_temp_referenced_50280);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_37emitted_temp_referenced_50280), start, &_37emitted_temp_referenced_50280);
        }
        else {
            assign_slice_seq = &assign_space;
            _37emitted_temp_referenced_50280 = Remove_elements(start, stop, (SEQ_PTR(_37emitted_temp_referenced_50280)->ref == 1));
        }
    }
L1: 

    /** end procedure*/
    return;
    ;
}


int _37pop_temps()
{
    int _new_emitted_50384 = NOVALUE;
    int _new_referenced_50385 = NOVALUE;
    int _26287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_emitted  = emitted_temps*/
    RefDS(_37emitted_temps_50279);
    DeRef(_new_emitted_50384);
    _new_emitted_50384 = _37emitted_temps_50279;

    /** 	sequence new_referenced = emitted_temp_referenced*/
    RefDS(_37emitted_temp_referenced_50280);
    DeRef(_new_referenced_50385);
    _new_referenced_50385 = _37emitted_temp_referenced_50280;

    /** 	emitted_temps  = {}*/
    RefDS(_21829);
    DeRefDS(_37emitted_temps_50279);
    _37emitted_temps_50279 = _21829;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_21829);
    DeRefDS(_37emitted_temp_referenced_50280);
    _37emitted_temp_referenced_50280 = _21829;

    /** 	return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_50385);
    RefDS(_new_emitted_50384);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _new_emitted_50384;
    ((int *)_2)[2] = _new_referenced_50385;
    _26287 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_50384);
    DeRefDS(_new_referenced_50385);
    return _26287;
    ;
}


int _37get_temps(int _add_to_50389)
{
    int _26292 = NOVALUE;
    int _26291 = NOVALUE;
    int _26290 = NOVALUE;
    int _26289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	add_to[1] &= emitted_temps*/
    _2 = (int)SEQ_PTR(_add_to_50389);
    _26289 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26289) && IS_ATOM(_37emitted_temps_50279)) {
    }
    else if (IS_ATOM(_26289) && IS_SEQUENCE(_37emitted_temps_50279)) {
        Ref(_26289);
        Prepend(&_26290, _37emitted_temps_50279, _26289);
    }
    else {
        Concat((object_ptr)&_26290, _26289, _37emitted_temps_50279);
        _26289 = NOVALUE;
    }
    _26289 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50389);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50389 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26290;
    if( _1 != _26290 ){
        DeRef(_1);
    }
    _26290 = NOVALUE;

    /** 	add_to[2] &= emitted_temp_referenced*/
    _2 = (int)SEQ_PTR(_add_to_50389);
    _26291 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26291) && IS_ATOM(_37emitted_temp_referenced_50280)) {
    }
    else if (IS_ATOM(_26291) && IS_SEQUENCE(_37emitted_temp_referenced_50280)) {
        Ref(_26291);
        Prepend(&_26292, _37emitted_temp_referenced_50280, _26291);
    }
    else {
        Concat((object_ptr)&_26292, _26291, _37emitted_temp_referenced_50280);
        _26291 = NOVALUE;
    }
    _26291 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50389);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50389 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _26292;
    if( _1 != _26292 ){
        DeRef(_1);
    }
    _26292 = NOVALUE;

    /** 	return add_to*/
    return _add_to_50389;
    ;
}


void _37push_temps(int _temps_50397)
{
    int _26295 = NOVALUE;
    int _26293 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emitted_temps &= temps[1]*/
    _2 = (int)SEQ_PTR(_temps_50397);
    _26293 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_37emitted_temps_50279) && IS_ATOM(_26293)) {
        Ref(_26293);
        Append(&_37emitted_temps_50279, _37emitted_temps_50279, _26293);
    }
    else if (IS_ATOM(_37emitted_temps_50279) && IS_SEQUENCE(_26293)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temps_50279, _37emitted_temps_50279, _26293);
    }
    _26293 = NOVALUE;

    /** 	emitted_temp_referenced &= temps[2]*/
    _2 = (int)SEQ_PTR(_temps_50397);
    _26295 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_37emitted_temp_referenced_50280) && IS_ATOM(_26295)) {
        Ref(_26295);
        Append(&_37emitted_temp_referenced_50280, _37emitted_temp_referenced_50280, _26295);
    }
    else if (IS_ATOM(_37emitted_temp_referenced_50280) && IS_SEQUENCE(_26295)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temp_referenced_50280, _37emitted_temp_referenced_50280, _26295);
    }
    _26295 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** end procedure*/
    DeRefDS(_temps_50397);
    return;
    ;
}


void _37backpatch(int _index_50404, int _val_50405)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_50404)) {
        _1 = (long)(DBL_PTR(_index_50404)->dbl);
        DeRefDS(_index_50404);
        _index_50404 = _1;
    }
    if (!IS_ATOM_INT(_val_50405)) {
        _1 = (long)(DBL_PTR(_val_50405)->dbl);
        DeRefDS(_val_50405);
        _val_50405 = _1;
    }

    /** 		Code[index] = val*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_50404);
    _1 = *(int *)_2;
    *(int *)_2 = _val_50405;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


void _37cont11ii(int _op_50586, int _ii_50588)
{
    int _t_50589 = NOVALUE;
    int _source_50590 = NOVALUE;
    int _c_50591 = NOVALUE;
    int _26304 = NOVALUE;
    int _26303 = NOVALUE;
    int _26301 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_opcode(op)*/
    _37emit_opcode(_op_50586);

    /** 	source = Pop()*/
    _source_50590 = _37Pop();
    if (!IS_ATOM_INT(_source_50590)) {
        _1 = (long)(DBL_PTR(_source_50590)->dbl);
        DeRefDS(_source_50590);
        _source_50590 = _1;
    }

    /** 	emit_addr(source)*/
    _37emit_addr(_source_50590);

    /** 	assignable = TRUE*/
    _37assignable_49809 = _9TRUE_431;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_37op_result_50407);
    _t_50589 = (int)*(((s1_ptr)_2)->base + _op_50586);

    /** 	if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26301 = (_t_50589 == 1);
    if (_26301 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_50588 == 0) {
        _26303 = 0;
        goto L2; // [47] 59
    }
    _26304 = _37IsInteger(_source_50590);
    if (IS_ATOM_INT(_26304))
    _26303 = (_26304 != 0);
    else
    _26303 = DBL_PTR(_26304)->dbl != 0.0;
L2: 
    if (_26303 == 0)
    {
        _26303 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26303 = NOVALUE;
    }
L1: 

    /** 		c = NewTempSym()*/
    _c_50591 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_50591)) {
        _1 = (long)(DBL_PTR(_c_50591)->dbl);
        DeRefDS(_c_50591);
        _c_50591 = _1;
    }

    /** 		TempInteger(c)*/
    _37TempInteger(_c_50591);
    goto L4; // [77] 95
L3: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_50591 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_50591)) {
        _1 = (long)(DBL_PTR(_c_50591)->dbl);
        DeRefDS(_c_50591);
        _c_50591 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _37emit_temp(_c_50591, 1);
L4: 

    /** 	Push(c)*/
    _37Push(_c_50591);

    /** 	emit_addr(c)*/
    _37emit_addr(_c_50591);

    /** end procedure*/
    DeRef(_26301);
    _26301 = NOVALUE;
    DeRef(_26304);
    _26304 = NOVALUE;
    return;
    ;
}


void _37cont21d(int _op_50608, int _a_50609, int _b_50610, int _ii_50612)
{
    int _c_50613 = NOVALUE;
    int _t_50614 = NOVALUE;
    int _26314 = NOVALUE;
    int _26313 = NOVALUE;
    int _26312 = NOVALUE;
    int _26311 = NOVALUE;
    int _26309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	assignable = TRUE*/
    _37assignable_49809 = _9TRUE_431;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_37op_result_50407);
    _t_50614 = (int)*(((s1_ptr)_2)->base + _op_50608);

    /** 	if op = C_FUNC then*/
    if (_op_50608 != 133)
    goto L1; // [26] 38

    /** 		emit_addr(CurrentSub)*/
    _37emit_addr(_12CurrentSub_11690);
L1: 

    /** 	if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26309 = (_t_50614 == 1);
    if (_26309 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_50612 == 0) {
        _26311 = 0;
        goto L3; // [50] 62
    }
    _26312 = _37IsInteger(_a_50609);
    if (IS_ATOM_INT(_26312))
    _26311 = (_26312 != 0);
    else
    _26311 = DBL_PTR(_26312)->dbl != 0.0;
L3: 
    if (_26311 == 0) {
        DeRef(_26313);
        _26313 = 0;
        goto L4; // [62] 74
    }
    _26314 = _37IsInteger(_b_50610);
    if (IS_ATOM_INT(_26314))
    _26313 = (_26314 != 0);
    else
    _26313 = DBL_PTR(_26314)->dbl != 0.0;
L4: 
    if (_26313 == 0)
    {
        _26313 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26313 = NOVALUE;
    }
L2: 

    /** 		c = NewTempSym()*/
    _c_50613 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_50613)) {
        _1 = (long)(DBL_PTR(_c_50613)->dbl);
        DeRefDS(_c_50613);
        _c_50613 = _1;
    }

    /** 		TempInteger(c)*/
    _37TempInteger(_c_50613);
    goto L6; // [92] 110
L5: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_50613 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_50613)) {
        _1 = (long)(DBL_PTR(_c_50613)->dbl);
        DeRefDS(_c_50613);
        _c_50613 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _37emit_temp(_c_50613, 1);
L6: 

    /** 	Push(c)*/
    _37Push(_c_50613);

    /** 	emit_addr(c)*/
    _37emit_addr(_c_50613);

    /** end procedure*/
    DeRef(_26309);
    _26309 = NOVALUE;
    DeRef(_26312);
    _26312 = NOVALUE;
    DeRef(_26314);
    _26314 = NOVALUE;
    return;
    ;
}


void _37cont21ii(int _op_50636, int _ii_50638)
{
    int _a_50639 = NOVALUE;
    int _b_50640 = NOVALUE;
    int _0, _1, _2;
    

    /** 	b = Pop()*/
    _b_50640 = _37Pop();
    if (!IS_ATOM_INT(_b_50640)) {
        _1 = (long)(DBL_PTR(_b_50640)->dbl);
        DeRefDS(_b_50640);
        _b_50640 = _1;
    }

    /** 	emit_opcode(op)*/
    _37emit_opcode(_op_50636);

    /** 	a = Pop()*/
    _a_50639 = _37Pop();
    if (!IS_ATOM_INT(_a_50639)) {
        _1 = (long)(DBL_PTR(_a_50639)->dbl);
        DeRefDS(_a_50639);
        _a_50639 = _1;
    }

    /** 	emit_addr(a)*/
    _37emit_addr(_a_50639);

    /** 	emit_addr(b)*/
    _37emit_addr(_b_50640);

    /** 	cont21d(op, a, b, ii)*/
    _37cont21d(_op_50636, _a_50639, _b_50640, _ii_50638);

    /** end procedure*/
    return;
    ;
}


int _37good_string(int _elements_50645)
{
    int _obj_50646 = NOVALUE;
    int _ep_50648 = NOVALUE;
    int _e_50650 = NOVALUE;
    int _element_vals_50651 = NOVALUE;
    int _26337 = NOVALUE;
    int _26336 = NOVALUE;
    int _26335 = NOVALUE;
    int _26334 = NOVALUE;
    int _26333 = NOVALUE;
    int _26332 = NOVALUE;
    int _26331 = NOVALUE;
    int _26330 = NOVALUE;
    int _26329 = NOVALUE;
    int _26328 = NOVALUE;
    int _26327 = NOVALUE;
    int _26325 = NOVALUE;
    int _26322 = NOVALUE;
    int _26321 = NOVALUE;
    int _26320 = NOVALUE;
    int _26319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence element_vals*/

    /** 	if TRANSLATE and length(elements) > 10000 then*/
    if (_12TRANSLATE_11319 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_50645)){
            _26320 = SEQ_PTR(_elements_50645)->length;
    }
    else {
        _26320 = 1;
    }
    _26321 = (_26320 > 10000);
    _26320 = NOVALUE;
    if (_26321 == 0)
    {
        DeRef(_26321);
        _26321 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26321);
        _26321 = NOVALUE;
    }

    /** 		return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_50645);
    DeRef(_obj_50646);
    DeRef(_element_vals_50651);
    return -1;
L1: 

    /** 	element_vals = {}*/
    RefDS(_21829);
    DeRef(_element_vals_50651);
    _element_vals_50651 = _21829;

    /** 	for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_50645)){
            _26322 = SEQ_PTR(_elements_50645)->length;
    }
    else {
        _26322 = 1;
    }
    {
        int _i_50658;
        _i_50658 = 1;
L2: 
        if (_i_50658 > _26322){
            goto L3; // [43] 183
        }

        /** 		ep = elements[i]*/
        _2 = (int)SEQ_PTR(_elements_50645);
        _ep_50648 = (int)*(((s1_ptr)_2)->base + _i_50658);
        if (!IS_ATOM_INT(_ep_50648)){
            _ep_50648 = (long)DBL_PTR(_ep_50648)->dbl;
        }

        /** 		if ep < 1 then*/
        if (_ep_50648 >= 1)
        goto L4; // [60] 71

        /** 			return -1*/
        DeRefDS(_elements_50645);
        DeRef(_obj_50646);
        DeRef(_element_vals_50651);
        return -1;
L4: 

        /** 		e = ep*/
        _e_50650 = _ep_50648;

        /** 		obj = SymTab[e][S_OBJ]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26325 = (int)*(((s1_ptr)_2)->base + _e_50650);
        DeRef(_obj_50646);
        _2 = (int)SEQ_PTR(_26325);
        _obj_50646 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_50646);
        _26325 = NOVALUE;

        /** 		if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26327 = (int)*(((s1_ptr)_2)->base + _e_50650);
        _2 = (int)SEQ_PTR(_26327);
        _26328 = (int)*(((s1_ptr)_2)->base + 3);
        _26327 = NOVALUE;
        if (IS_ATOM_INT(_26328)) {
            _26329 = (_26328 == 2);
        }
        else {
            _26329 = binary_op(EQUALS, _26328, 2);
        }
        _26328 = NOVALUE;
        if (IS_ATOM_INT(_26329)) {
            if (_26329 == 0) {
                DeRef(_26330);
                _26330 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26329)->dbl == 0.0) {
                DeRef(_26330);
                _26330 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_50646))
        _26331 = 1;
        else if (IS_ATOM_DBL(_obj_50646))
        _26331 = IS_ATOM_INT(DoubleToInt(_obj_50646));
        else
        _26331 = 0;
        DeRef(_26330);
        _26330 = (_26331 != 0);
L5: 
        if (_26330 == 0) {
            goto L6; // [123] 169
        }
        _26333 = (_12TRANSLATE_11319 == 0);
        if (_26333 != 0) {
            DeRef(_26334);
            _26334 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_50646)) {
            _26335 = (_obj_50646 >= 1);
        }
        else {
            _26335 = binary_op(GREATEREQ, _obj_50646, 1);
        }
        if (IS_ATOM_INT(_26335)) {
            if (_26335 == 0) {
                DeRef(_26336);
                _26336 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26335)->dbl == 0.0) {
                DeRef(_26336);
                _26336 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_50646)) {
            _26337 = (_obj_50646 <= 255);
        }
        else {
            _26337 = binary_op(LESSEQ, _obj_50646, 255);
        }
        DeRef(_26336);
        if (IS_ATOM_INT(_26337))
        _26336 = (_26337 != 0);
        else
        _26336 = DBL_PTR(_26337)->dbl != 0.0;
L8: 
        DeRef(_26334);
        _26334 = (_26336 != 0);
L7: 
        if (_26334 == 0)
        {
            _26334 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26334 = NOVALUE;
        }

        /** 			element_vals = prepend(element_vals, obj)*/
        Ref(_obj_50646);
        Prepend(&_element_vals_50651, _element_vals_50651, _obj_50646);
        goto L9; // [166] 176
L6: 

        /** 			return -1*/
        DeRefDS(_elements_50645);
        DeRef(_obj_50646);
        DeRef(_element_vals_50651);
        DeRef(_26333);
        _26333 = NOVALUE;
        DeRef(_26329);
        _26329 = NOVALUE;
        DeRef(_26335);
        _26335 = NOVALUE;
        DeRef(_26337);
        _26337 = NOVALUE;
        return -1;
L9: 

        /** 	end for*/
        _i_50658 = _i_50658 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** 	return element_vals*/
    DeRefDS(_elements_50645);
    DeRef(_obj_50646);
    DeRef(_26333);
    _26333 = NOVALUE;
    DeRef(_26329);
    _26329 = NOVALUE;
    DeRef(_26335);
    _26335 = NOVALUE;
    DeRef(_26337);
    _26337 = NOVALUE;
    return _element_vals_50651;
    ;
}


int _37Last_op()
{
    int _0, _1, _2;
    

    /** 	return last_op*/
    return _37last_op_50685;
    ;
}


int _37Last_pc()
{
    int _0, _1, _2;
    

    /** 	return last_pc*/
    return _37last_pc_50686;
    ;
}


void _37move_last_pc(int _amount_50693)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_50693)) {
        _1 = (long)(DBL_PTR(_amount_50693)->dbl);
        DeRefDS(_amount_50693);
        _amount_50693 = _1;
    }

    /** 	if last_pc > 0 then*/
    if (_37last_pc_50686 <= 0)
    goto L1; // [7] 20

    /** 		last_pc += amount*/
    _37last_pc_50686 = _37last_pc_50686 + _amount_50693;
L1: 

    /** end procedure*/
    return;
    ;
}


void _37clear_last()
{
    int _0, _1, _2;
    

    /** 	last_op = 0*/
    _37last_op_50685 = 0;

    /** 	last_pc = 0*/
    _37last_pc_50686 = 0;

    /** end procedure*/
    return;
    ;
}


void _37clear_op()
{
    int _0, _1, _2;
    

    /** 	previous_op = -1*/
    _12previous_op_11781 = -1;

    /** 	assignable = FALSE*/
    _37assignable_49809 = _9FALSE_429;

    /** end procedure*/
    return;
    ;
}


void _37inlined_function()
{
    int _0, _1, _2;
    

    /** 	previous_op = PROC*/
    _12previous_op_11781 = 27;

    /** 	assignable = TRUE*/
    _37assignable_49809 = _9TRUE_431;

    /** 	inlined = TRUE*/
    _37inlined_50704 = _9TRUE_431;

    /** end procedure*/
    return;
    ;
}


void _37add_inline_target(int _pc_50715)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_50715)) {
        _1 = (long)(DBL_PTR(_pc_50715)->dbl);
        DeRefDS(_pc_50715);
        _pc_50715 = _1;
    }

    /** 	inlined_targets &= pc*/
    Append(&_37inlined_targets_50712, _37inlined_targets_50712, _pc_50715);

    /** end procedure*/
    return;
    ;
}


void _37clear_inline_targets()
{
    int _0, _1, _2;
    

    /** 	inlined_targets = {}*/
    RefDS(_21829);
    DeRefi(_37inlined_targets_50712);
    _37inlined_targets_50712 = _21829;

    /** end procedure*/
    return;
    ;
}


void _37emit_inline(int _code_50721)
{
    int _0, _1, _2;
    

    /** 	last_pc = 0*/
    _37last_pc_50686 = 0;

    /** 	last_op = 0*/
    _37last_op_50685 = 0;

    /** 	Code &= code*/
    Concat((object_ptr)&_12Code_11771, _12Code_11771, _code_50721);

    /** end procedure*/
    DeRefDS(_code_50721);
    return;
    ;
}


void _37emit_op(int _op_50726)
{
    int _a_50728 = NOVALUE;
    int _b_50729 = NOVALUE;
    int _c_50730 = NOVALUE;
    int _d_50731 = NOVALUE;
    int _source_50732 = NOVALUE;
    int _target_50733 = NOVALUE;
    int _subsym_50734 = NOVALUE;
    int _lhs_var_50736 = NOVALUE;
    int _ib_50737 = NOVALUE;
    int _ic_50738 = NOVALUE;
    int _n_50739 = NOVALUE;
    int _obj_50740 = NOVALUE;
    int _elements_50741 = NOVALUE;
    int _element_vals_50742 = NOVALUE;
    int _last_pc_backup_50743 = NOVALUE;
    int _last_op_backup_50744 = NOVALUE;
    int _temp_50753 = NOVALUE;
    int _real_op_51041 = NOVALUE;
    int _ref_51048 = NOVALUE;
    int _paths_51078 = NOVALUE;
    int _if_code_51158 = NOVALUE;
    int _if_code_51197 = NOVALUE;
    int _Top_inlined_Top_at_5195_51764 = NOVALUE;
    int _element_51835 = NOVALUE;
    int _Top_inlined_Top_at_6750_51982 = NOVALUE;
    int _31379 = NOVALUE;
    int _31378 = NOVALUE;
    int _26918 = NOVALUE;
    int _26914 = NOVALUE;
    int _26911 = NOVALUE;
    int _26909 = NOVALUE;
    int _26903 = NOVALUE;
    int _26902 = NOVALUE;
    int _26901 = NOVALUE;
    int _26899 = NOVALUE;
    int _26897 = NOVALUE;
    int _26896 = NOVALUE;
    int _26895 = NOVALUE;
    int _26894 = NOVALUE;
    int _26893 = NOVALUE;
    int _26892 = NOVALUE;
    int _26891 = NOVALUE;
    int _26890 = NOVALUE;
    int _26889 = NOVALUE;
    int _26888 = NOVALUE;
    int _26887 = NOVALUE;
    int _26885 = NOVALUE;
    int _26884 = NOVALUE;
    int _26883 = NOVALUE;
    int _26881 = NOVALUE;
    int _26880 = NOVALUE;
    int _26879 = NOVALUE;
    int _26878 = NOVALUE;
    int _26877 = NOVALUE;
    int _26876 = NOVALUE;
    int _26875 = NOVALUE;
    int _26874 = NOVALUE;
    int _26873 = NOVALUE;
    int _26870 = NOVALUE;
    int _26867 = NOVALUE;
    int _26866 = NOVALUE;
    int _26865 = NOVALUE;
    int _26864 = NOVALUE;
    int _26862 = NOVALUE;
    int _26860 = NOVALUE;
    int _26848 = NOVALUE;
    int _26840 = NOVALUE;
    int _26837 = NOVALUE;
    int _26836 = NOVALUE;
    int _26835 = NOVALUE;
    int _26834 = NOVALUE;
    int _26831 = NOVALUE;
    int _26830 = NOVALUE;
    int _26829 = NOVALUE;
    int _26828 = NOVALUE;
    int _26827 = NOVALUE;
    int _26826 = NOVALUE;
    int _26825 = NOVALUE;
    int _26824 = NOVALUE;
    int _26823 = NOVALUE;
    int _26822 = NOVALUE;
    int _26821 = NOVALUE;
    int _26819 = NOVALUE;
    int _26815 = NOVALUE;
    int _26814 = NOVALUE;
    int _26813 = NOVALUE;
    int _26812 = NOVALUE;
    int _26811 = NOVALUE;
    int _26810 = NOVALUE;
    int _26809 = NOVALUE;
    int _26808 = NOVALUE;
    int _26807 = NOVALUE;
    int _26806 = NOVALUE;
    int _26805 = NOVALUE;
    int _26803 = NOVALUE;
    int _26798 = NOVALUE;
    int _26797 = NOVALUE;
    int _26795 = NOVALUE;
    int _26794 = NOVALUE;
    int _26793 = NOVALUE;
    int _26791 = NOVALUE;
    int _26788 = NOVALUE;
    int _26784 = NOVALUE;
    int _26781 = NOVALUE;
    int _26780 = NOVALUE;
    int _26779 = NOVALUE;
    int _26778 = NOVALUE;
    int _26777 = NOVALUE;
    int _26776 = NOVALUE;
    int _26774 = NOVALUE;
    int _26773 = NOVALUE;
    int _26771 = NOVALUE;
    int _26770 = NOVALUE;
    int _26769 = NOVALUE;
    int _26768 = NOVALUE;
    int _26767 = NOVALUE;
    int _26766 = NOVALUE;
    int _26765 = NOVALUE;
    int _26764 = NOVALUE;
    int _26763 = NOVALUE;
    int _26762 = NOVALUE;
    int _26760 = NOVALUE;
    int _26759 = NOVALUE;
    int _26758 = NOVALUE;
    int _26757 = NOVALUE;
    int _26756 = NOVALUE;
    int _26755 = NOVALUE;
    int _26754 = NOVALUE;
    int _26753 = NOVALUE;
    int _26752 = NOVALUE;
    int _26751 = NOVALUE;
    int _26750 = NOVALUE;
    int _26749 = NOVALUE;
    int _26748 = NOVALUE;
    int _26747 = NOVALUE;
    int _26746 = NOVALUE;
    int _26744 = NOVALUE;
    int _26741 = NOVALUE;
    int _26740 = NOVALUE;
    int _26739 = NOVALUE;
    int _26738 = NOVALUE;
    int _26737 = NOVALUE;
    int _26736 = NOVALUE;
    int _26735 = NOVALUE;
    int _26734 = NOVALUE;
    int _26733 = NOVALUE;
    int _26732 = NOVALUE;
    int _26731 = NOVALUE;
    int _26730 = NOVALUE;
    int _26729 = NOVALUE;
    int _26728 = NOVALUE;
    int _26727 = NOVALUE;
    int _26725 = NOVALUE;
    int _26721 = NOVALUE;
    int _26718 = NOVALUE;
    int _26716 = NOVALUE;
    int _26715 = NOVALUE;
    int _26713 = NOVALUE;
    int _26712 = NOVALUE;
    int _26711 = NOVALUE;
    int _26710 = NOVALUE;
    int _26709 = NOVALUE;
    int _26708 = NOVALUE;
    int _26707 = NOVALUE;
    int _26706 = NOVALUE;
    int _26705 = NOVALUE;
    int _26704 = NOVALUE;
    int _26703 = NOVALUE;
    int _26702 = NOVALUE;
    int _26701 = NOVALUE;
    int _26700 = NOVALUE;
    int _26699 = NOVALUE;
    int _26698 = NOVALUE;
    int _26697 = NOVALUE;
    int _26696 = NOVALUE;
    int _26695 = NOVALUE;
    int _26693 = NOVALUE;
    int _26691 = NOVALUE;
    int _26690 = NOVALUE;
    int _26688 = NOVALUE;
    int _26678 = NOVALUE;
    int _26677 = NOVALUE;
    int _26676 = NOVALUE;
    int _26675 = NOVALUE;
    int _26674 = NOVALUE;
    int _26673 = NOVALUE;
    int _26672 = NOVALUE;
    int _26671 = NOVALUE;
    int _26670 = NOVALUE;
    int _26669 = NOVALUE;
    int _26668 = NOVALUE;
    int _26667 = NOVALUE;
    int _26666 = NOVALUE;
    int _26665 = NOVALUE;
    int _26664 = NOVALUE;
    int _26663 = NOVALUE;
    int _26662 = NOVALUE;
    int _26661 = NOVALUE;
    int _26660 = NOVALUE;
    int _26659 = NOVALUE;
    int _26658 = NOVALUE;
    int _26657 = NOVALUE;
    int _26656 = NOVALUE;
    int _26655 = NOVALUE;
    int _26649 = NOVALUE;
    int _26648 = NOVALUE;
    int _26645 = NOVALUE;
    int _26642 = NOVALUE;
    int _26641 = NOVALUE;
    int _26640 = NOVALUE;
    int _26639 = NOVALUE;
    int _26638 = NOVALUE;
    int _26637 = NOVALUE;
    int _26636 = NOVALUE;
    int _26635 = NOVALUE;
    int _26634 = NOVALUE;
    int _26633 = NOVALUE;
    int _26631 = NOVALUE;
    int _26630 = NOVALUE;
    int _26629 = NOVALUE;
    int _26627 = NOVALUE;
    int _26625 = NOVALUE;
    int _26624 = NOVALUE;
    int _26623 = NOVALUE;
    int _26622 = NOVALUE;
    int _26621 = NOVALUE;
    int _26620 = NOVALUE;
    int _26619 = NOVALUE;
    int _26618 = NOVALUE;
    int _26617 = NOVALUE;
    int _26616 = NOVALUE;
    int _26614 = NOVALUE;
    int _26613 = NOVALUE;
    int _26611 = NOVALUE;
    int _26610 = NOVALUE;
    int _26609 = NOVALUE;
    int _26608 = NOVALUE;
    int _26607 = NOVALUE;
    int _26605 = NOVALUE;
    int _26604 = NOVALUE;
    int _26603 = NOVALUE;
    int _26602 = NOVALUE;
    int _26601 = NOVALUE;
    int _26600 = NOVALUE;
    int _26599 = NOVALUE;
    int _26598 = NOVALUE;
    int _26596 = NOVALUE;
    int _26595 = NOVALUE;
    int _26594 = NOVALUE;
    int _26593 = NOVALUE;
    int _26592 = NOVALUE;
    int _26590 = NOVALUE;
    int _26589 = NOVALUE;
    int _26587 = NOVALUE;
    int _26586 = NOVALUE;
    int _26585 = NOVALUE;
    int _26584 = NOVALUE;
    int _26583 = NOVALUE;
    int _26581 = NOVALUE;
    int _26579 = NOVALUE;
    int _26577 = NOVALUE;
    int _26576 = NOVALUE;
    int _26574 = NOVALUE;
    int _26573 = NOVALUE;
    int _26572 = NOVALUE;
    int _26571 = NOVALUE;
    int _26570 = NOVALUE;
    int _26569 = NOVALUE;
    int _26568 = NOVALUE;
    int _26567 = NOVALUE;
    int _26566 = NOVALUE;
    int _26565 = NOVALUE;
    int _26564 = NOVALUE;
    int _26563 = NOVALUE;
    int _26562 = NOVALUE;
    int _26561 = NOVALUE;
    int _26560 = NOVALUE;
    int _26559 = NOVALUE;
    int _26558 = NOVALUE;
    int _26555 = NOVALUE;
    int _26554 = NOVALUE;
    int _26552 = NOVALUE;
    int _26551 = NOVALUE;
    int _26550 = NOVALUE;
    int _26549 = NOVALUE;
    int _26548 = NOVALUE;
    int _26546 = NOVALUE;
    int _26544 = NOVALUE;
    int _26543 = NOVALUE;
    int _26542 = NOVALUE;
    int _26541 = NOVALUE;
    int _26540 = NOVALUE;
    int _26539 = NOVALUE;
    int _26538 = NOVALUE;
    int _26537 = NOVALUE;
    int _26536 = NOVALUE;
    int _26533 = NOVALUE;
    int _26532 = NOVALUE;
    int _26530 = NOVALUE;
    int _26529 = NOVALUE;
    int _26528 = NOVALUE;
    int _26527 = NOVALUE;
    int _26526 = NOVALUE;
    int _26523 = NOVALUE;
    int _26522 = NOVALUE;
    int _26521 = NOVALUE;
    int _26520 = NOVALUE;
    int _26519 = NOVALUE;
    int _26518 = NOVALUE;
    int _26517 = NOVALUE;
    int _26512 = NOVALUE;
    int _26511 = NOVALUE;
    int _26510 = NOVALUE;
    int _26508 = NOVALUE;
    int _26507 = NOVALUE;
    int _26505 = NOVALUE;
    int _26504 = NOVALUE;
    int _26499 = NOVALUE;
    int _26498 = NOVALUE;
    int _26497 = NOVALUE;
    int _26496 = NOVALUE;
    int _26495 = NOVALUE;
    int _26489 = NOVALUE;
    int _26488 = NOVALUE;
    int _26486 = NOVALUE;
    int _26485 = NOVALUE;
    int _26484 = NOVALUE;
    int _26483 = NOVALUE;
    int _26482 = NOVALUE;
    int _26481 = NOVALUE;
    int _26479 = NOVALUE;
    int _26478 = NOVALUE;
    int _26477 = NOVALUE;
    int _26476 = NOVALUE;
    int _26475 = NOVALUE;
    int _26474 = NOVALUE;
    int _26473 = NOVALUE;
    int _26472 = NOVALUE;
    int _26471 = NOVALUE;
    int _26470 = NOVALUE;
    int _26469 = NOVALUE;
    int _26468 = NOVALUE;
    int _26467 = NOVALUE;
    int _26466 = NOVALUE;
    int _26464 = NOVALUE;
    int _26463 = NOVALUE;
    int _26462 = NOVALUE;
    int _26461 = NOVALUE;
    int _26458 = NOVALUE;
    int _26457 = NOVALUE;
    int _26456 = NOVALUE;
    int _26455 = NOVALUE;
    int _26453 = NOVALUE;
    int _26452 = NOVALUE;
    int _26451 = NOVALUE;
    int _26450 = NOVALUE;
    int _26448 = NOVALUE;
    int _26447 = NOVALUE;
    int _26446 = NOVALUE;
    int _26445 = NOVALUE;
    int _26444 = NOVALUE;
    int _26443 = NOVALUE;
    int _26442 = NOVALUE;
    int _26441 = NOVALUE;
    int _26440 = NOVALUE;
    int _26439 = NOVALUE;
    int _26438 = NOVALUE;
    int _26437 = NOVALUE;
    int _26436 = NOVALUE;
    int _26435 = NOVALUE;
    int _26433 = NOVALUE;
    int _26432 = NOVALUE;
    int _26431 = NOVALUE;
    int _26430 = NOVALUE;
    int _26429 = NOVALUE;
    int _26427 = NOVALUE;
    int _26426 = NOVALUE;
    int _26425 = NOVALUE;
    int _26424 = NOVALUE;
    int _26423 = NOVALUE;
    int _26419 = NOVALUE;
    int _26418 = NOVALUE;
    int _26417 = NOVALUE;
    int _26416 = NOVALUE;
    int _26415 = NOVALUE;
    int _26413 = NOVALUE;
    int _26412 = NOVALUE;
    int _26411 = NOVALUE;
    int _26410 = NOVALUE;
    int _26409 = NOVALUE;
    int _26408 = NOVALUE;
    int _26407 = NOVALUE;
    int _26406 = NOVALUE;
    int _26405 = NOVALUE;
    int _26404 = NOVALUE;
    int _26403 = NOVALUE;
    int _26402 = NOVALUE;
    int _26401 = NOVALUE;
    int _26400 = NOVALUE;
    int _26399 = NOVALUE;
    int _26398 = NOVALUE;
    int _26397 = NOVALUE;
    int _26396 = NOVALUE;
    int _26394 = NOVALUE;
    int _26393 = NOVALUE;
    int _26392 = NOVALUE;
    int _26391 = NOVALUE;
    int _26390 = NOVALUE;
    int _26389 = NOVALUE;
    int _26388 = NOVALUE;
    int _26387 = NOVALUE;
    int _26386 = NOVALUE;
    int _26384 = NOVALUE;
    int _26383 = NOVALUE;
    int _26382 = NOVALUE;
    int _26380 = NOVALUE;
    int _26379 = NOVALUE;
    int _26377 = NOVALUE;
    int _26375 = NOVALUE;
    int _26374 = NOVALUE;
    int _26373 = NOVALUE;
    int _26372 = NOVALUE;
    int _26371 = NOVALUE;
    int _26370 = NOVALUE;
    int _26366 = NOVALUE;
    int _26365 = NOVALUE;
    int _26364 = NOVALUE;
    int _26362 = NOVALUE;
    int _26361 = NOVALUE;
    int _26360 = NOVALUE;
    int _26359 = NOVALUE;
    int _26358 = NOVALUE;
    int _26357 = NOVALUE;
    int _26356 = NOVALUE;
    int _26355 = NOVALUE;
    int _26354 = NOVALUE;
    int _26353 = NOVALUE;
    int _26352 = NOVALUE;
    int _26351 = NOVALUE;
    int _26350 = NOVALUE;
    int _26349 = NOVALUE;
    int _26348 = NOVALUE;
    int _26343 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_50726)) {
        _1 = (long)(DBL_PTR(_op_50726)->dbl);
        DeRefDS(_op_50726);
        _op_50726 = _1;
    }

    /** 	integer ib, ic, n*/

    /** 	object obj*/

    /** 	sequence elements*/

    /** 	object element_vals*/

    /** 	check_for_temps()*/
    _37check_for_temps();

    /** 	integer last_pc_backup = last_pc*/
    _last_pc_backup_50743 = _37last_pc_50686;

    /** 	integer last_op_backup = last_op*/
    _last_op_backup_50744 = _37last_op_50685;

    /** 	last_op = op*/
    _37last_op_50685 = _op_50726;

    /** 	last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _26343 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _26343 = 1;
    }
    _37last_pc_50686 = _26343 + 1;
    _26343 = NOVALUE;

    /** 	switch op label "EMIT" do*/
    _0 = _op_50726;
    switch ( _0 ){ 

        /** 	case ASSIGN then*/
        case 18:

        /** 		sequence temp = {}*/
        RefDS(_21829);
        DeRef(_temp_50753);
        _temp_50753 = _21829;

        /** 		if not TRANSLATE and*/
        _26348 = (_12TRANSLATE_11319 == 0);
        if (_26348 == 0) {
            goto L1; // [70] 202
        }
        _26350 = (_12previous_op_11781 == 92);
        if (_26350 != 0) {
            DeRef(_26351);
            _26351 = 1;
            goto L2; // [82] 98
        }
        _26352 = (_12previous_op_11781 == 25);
        _26351 = (_26352 != 0);
L2: 
        if (_26351 == 0)
        {
            _26351 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26351 = NOVALUE;
        }

        /** 			while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_12Code_11771)){
                _26353 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26353 = 1;
        }
        _26354 = _26353 - 1;
        _26353 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26355 = (int)*(((s1_ptr)_2)->base + _26354);
        if (IS_ATOM_INT(_26355)) {
            _26356 = (_26355 == 208);
        }
        else {
            _26356 = binary_op(EQUALS, _26355, 208);
        }
        _26355 = NOVALUE;
        if (IS_ATOM_INT(_26356)) {
            if (_26356 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26356)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _26358 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26358 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26359 = (int)*(((s1_ptr)_2)->base + _26358);
        _26360 = find_from(_26359, _37derefs_50310, 1);
        _26359 = NOVALUE;
        if (_26360 == 0)
        {
            _26360 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26360 = NOVALUE;
        }

        /** 				temp &= Code[$]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26361 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26361 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26362 = (int)*(((s1_ptr)_2)->base + _26361);
        if (IS_SEQUENCE(_temp_50753) && IS_ATOM(_26362)) {
            Ref(_26362);
            Append(&_temp_50753, _temp_50753, _26362);
        }
        else if (IS_ATOM(_temp_50753) && IS_SEQUENCE(_26362)) {
        }
        else {
            Concat((object_ptr)&_temp_50753, _temp_50753, _26362);
        }
        _26362 = NOVALUE;

        /** 				Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26364 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26364 = 1;
        }
        _26365 = _26364 - 1;
        _26364 = NOVALUE;
        if (IS_SEQUENCE(_12Code_11771)){
                _26366 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26366 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_11771);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26365)) ? _26365 : (long)(DBL_PTR(_26365)->dbl);
            int stop = (IS_ATOM_INT(_26366)) ? _26366 : (long)(DBL_PTR(_26366)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_11771), start, &_12Code_11771 );
                }
                else Tail(SEQ_PTR(_12Code_11771), stop+1, &_12Code_11771);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_11771), start, &_12Code_11771);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_11771 = Remove_elements(start, stop, (SEQ_PTR(_12Code_11771)->ref == 1));
            }
        }
        _26365 = NOVALUE;
        _26366 = NOVALUE;

        /** 				emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_50753);
        _37emit_temp(_temp_50753, 1);

        /** 			end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** 		source = Pop()*/
        _source_50732 = _37Pop();
        if (!IS_ATOM_INT(_source_50732)) {
            _1 = (long)(DBL_PTR(_source_50732)->dbl);
            DeRefDS(_source_50732);
            _source_50732 = _1;
        }

        /** 		target = Pop()*/
        _target_50733 = _37Pop();
        if (!IS_ATOM_INT(_target_50733)) {
            _1 = (long)(DBL_PTR(_target_50733)->dbl);
            DeRefDS(_target_50733);
            _target_50733 = _1;
        }

        /** 		if assignable then*/
        if (_37assignable_49809 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** 			if inlined then*/
        if (_37inlined_50704 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** 				inlined = 0*/
        _37inlined_50704 = 0;

        /** 				if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_37inlined_targets_50712)){
                _26370 = SEQ_PTR(_37inlined_targets_50712)->length;
        }
        else {
            _26370 = 1;
        }
        if (_26370 == 0)
        {
            _26370 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26370 = NOVALUE;
        }

        /** 					for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_37inlined_targets_50712)){
                _26371 = SEQ_PTR(_37inlined_targets_50712)->length;
        }
        else {
            _26371 = 1;
        }
        {
            int _i_50796;
            _i_50796 = 1;
L8: 
            if (_i_50796 > _26371){
                goto L9; // [252] 280
            }

            /** 						Code[inlined_targets[i]] = target*/
            _2 = (int)SEQ_PTR(_37inlined_targets_50712);
            _26372 = (int)*(((s1_ptr)_2)->base + _i_50796);
            _2 = (int)SEQ_PTR(_12Code_11771);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _12Code_11771 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _26372);
            _1 = *(int *)_2;
            *(int *)_2 = _target_50733;
            DeRef(_1);

            /** 					end for*/
            _i_50796 = _i_50796 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** 					clear_inline_targets()*/

        /** 	inlined_targets = {}*/
        RefDS(_21829);
        DeRefi(_37inlined_targets_50712);
        _37inlined_targets_50712 = _21829;

        /** end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** 				assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 				clear_last()*/

        /** 	last_op = 0*/
        _37last_op_50685 = 0;

        /** 	last_pc = 0*/
        _37last_pc_50686 = 0;

        /** end procedure*/
        goto LB; // [316] 319
LB: 

        /** 				break "EMIT"*/
        DeRef(_temp_50753);
        _temp_50753 = NOVALUE;
        goto LC; // [323] 7412
L6: 

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26373 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26373 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26374 = (int)*(((s1_ptr)_2)->base + _26373);
        Ref(_26374);
        _37clear_temp(_26374);
        _26374 = NOVALUE;

        /** 			Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26375 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26375 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_11771);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26375)) ? _26375 : (long)(DBL_PTR(_26375)->dbl);
            int stop = (IS_ATOM_INT(_26375)) ? _26375 : (long)(DBL_PTR(_26375)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_11771), start, &_12Code_11771 );
                }
                else Tail(SEQ_PTR(_12Code_11771), stop+1, &_12Code_11771);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_11771), start, &_12Code_11771);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_11771 = Remove_elements(start, stop, (SEQ_PTR(_12Code_11771)->ref == 1));
            }
        }
        _26375 = NOVALUE;
        _26375 = NOVALUE;

        /** 			op = previous_op -- keep same previous op*/
        _op_50726 = _12previous_op_11781;

        /** 			if IsInteger(target) then*/
        _26377 = _37IsInteger(_target_50733);
        if (_26377 == 0) {
            DeRef(_26377);
            _26377 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26377) && DBL_PTR(_26377)->dbl == 0.0){
                DeRef(_26377);
                _26377 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26377);
            _26377 = NOVALUE;
        }
        DeRef(_26377);
        _26377 = NOVALUE;

        /** 				if previous_op = RHS_SUBS then*/
        if (_12previous_op_11781 != 25)
        goto LE; // [381] 412

        /** 					op = RHS_SUBS_I*/
        _op_50726 = 114;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26379 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26379 = 1;
        }
        _26380 = _26379 - 2;
        _26379 = NOVALUE;
        _37backpatch(_26380, 114);
        _26380 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** 				elsif previous_op = PLUS1 then*/
        if (_12previous_op_11781 != 93)
        goto L10; // [418] 449

        /** 					op = PLUS1_I*/
        _op_50726 = 117;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26382 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26382 = 1;
        }
        _26383 = _26382 - 2;
        _26382 = NOVALUE;
        _37backpatch(_26383, 117);
        _26383 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** 				elsif previous_op = PLUS or previous_op = MINUS then*/
        _26384 = (_12previous_op_11781 == 11);
        if (_26384 != 0) {
            goto L11; // [459] 476
        }
        _26386 = (_12previous_op_11781 == 10);
        if (_26386 == 0)
        {
            DeRef(_26386);
            _26386 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26386);
            _26386 = NOVALUE;
        }
L11: 

        /** 					if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26387 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26387 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26388 = (int)*(((s1_ptr)_2)->base + _26387);
        Ref(_26388);
        _26389 = _37IsInteger(_26388);
        _26388 = NOVALUE;
        if (IS_ATOM_INT(_26389)) {
            if (_26389 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26389)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _26391 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26391 = 1;
        }
        _26392 = _26391 - 1;
        _26391 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26393 = (int)*(((s1_ptr)_2)->base + _26392);
        Ref(_26393);
        _26394 = _37IsInteger(_26393);
        _26393 = NOVALUE;
        if (_26394 == 0) {
            DeRef(_26394);
            _26394 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26394) && DBL_PTR(_26394)->dbl == 0.0){
                DeRef(_26394);
                _26394 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26394);
            _26394 = NOVALUE;
        }
        DeRef(_26394);
        _26394 = NOVALUE;

        /** 						if previous_op = PLUS then*/
        if (_12previous_op_11781 != 11)
        goto L13; // [522] 538

        /** 							op = PLUS_I*/
        _op_50726 = 115;
        goto L14; // [535] 548
L13: 

        /** 							op = MINUS_I*/
        _op_50726 = 116;
L14: 

        /** 						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26396 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26396 = 1;
        }
        _26397 = _26396 - 2;
        _26396 = NOVALUE;
        _37backpatch(_26397, _op_50726);
        _26397 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** 					if IsInteger(source) then*/
        _26398 = _37IsInteger(_source_50732);
        if (_26398 == 0) {
            DeRef(_26398);
            _26398 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26398) && DBL_PTR(_26398)->dbl == 0.0){
                DeRef(_26398);
                _26398 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26398);
            _26398 = NOVALUE;
        }
        DeRef(_26398);
        _26398 = NOVALUE;

        /** 						op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_50726 = 113;
L15: 
LF: 
LD: 

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto L16; // [598] 743
L5: 

        /** 			if IsInteger(source) and IsInteger(target) then*/
        _26399 = _37IsInteger(_source_50732);
        if (IS_ATOM_INT(_26399)) {
            if (_26399 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26399)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26401 = _37IsInteger(_target_50733);
        if (_26401 == 0) {
            DeRef(_26401);
            _26401 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26401) && DBL_PTR(_26401)->dbl == 0.0){
                DeRef(_26401);
                _26401 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26401);
            _26401 = NOVALUE;
        }
        DeRef(_26401);
        _26401 = NOVALUE;

        /** 				op = ASSIGN_I*/
        _op_50726 = 113;
L17: 

        /** 			if source > 0 and target > 0 and*/
        _26402 = (_source_50732 > 0);
        if (_26402 == 0) {
            _26403 = 0;
            goto L18; // [635] 647
        }
        _26404 = (_target_50733 > 0);
        _26403 = (_26404 != 0);
L18: 
        if (_26403 == 0) {
            _26405 = 0;
            goto L19; // [647] 673
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26406 = (int)*(((s1_ptr)_2)->base + _source_50732);
        _2 = (int)SEQ_PTR(_26406);
        _26407 = (int)*(((s1_ptr)_2)->base + 3);
        _26406 = NOVALUE;
        if (IS_ATOM_INT(_26407)) {
            _26408 = (_26407 == 2);
        }
        else {
            _26408 = binary_op(EQUALS, _26407, 2);
        }
        _26407 = NOVALUE;
        if (IS_ATOM_INT(_26408))
        _26405 = (_26408 != 0);
        else
        _26405 = DBL_PTR(_26408)->dbl != 0.0;
L19: 
        if (_26405 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26410 = (int)*(((s1_ptr)_2)->base + _target_50733);
        _2 = (int)SEQ_PTR(_26410);
        _26411 = (int)*(((s1_ptr)_2)->base + 3);
        _26410 = NOVALUE;
        if (IS_ATOM_INT(_26411)) {
            _26412 = (_26411 == 2);
        }
        else {
            _26412 = binary_op(EQUALS, _26411, 2);
        }
        _26411 = NOVALUE;
        if (_26412 == 0) {
            DeRef(_26412);
            _26412 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26412) && DBL_PTR(_26412)->dbl == 0.0){
                DeRef(_26412);
                _26412 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26412);
            _26412 = NOVALUE;
        }
        DeRef(_26412);
        _26412 = NOVALUE;

        /** 				SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_target_50733 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26415 = (int)*(((s1_ptr)_2)->base + _source_50732);
        _2 = (int)SEQ_PTR(_26415);
        _26416 = (int)*(((s1_ptr)_2)->base + 1);
        _26415 = NOVALUE;
        Ref(_26416);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _26416;
        if( _1 != _26416 ){
            DeRef(_1);
        }
        _26416 = NOVALUE;
        _26413 = NOVALUE;
L1A: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(source)*/
        _37emit_addr(_source_50732);

        /** 			last_op = op*/
        _37last_op_50685 = _op_50726;
L16: 

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		emit_addr(target)*/
        _37emit_addr(_target_50733);

        /** 		if length(temp) then*/
        if (IS_SEQUENCE(_temp_50753)){
                _26417 = SEQ_PTR(_temp_50753)->length;
        }
        else {
            _26417 = 1;
        }
        if (_26417 == 0)
        {
            _26417 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26417 = NOVALUE;
        }

        /** 			for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_50753)){
                _26418 = SEQ_PTR(_temp_50753)->length;
        }
        else {
            _26418 = 1;
        }
        {
            int _i_50899;
            _i_50899 = 1;
L1C: 
            if (_i_50899 > _26418){
                goto L1D; // [768] 791
            }

            /** 				flush_temp( temp[i] )*/
            _2 = (int)SEQ_PTR(_temp_50753);
            _26419 = (int)*(((s1_ptr)_2)->base + _i_50899);
            Ref(_26419);
            _37flush_temp(_26419);
            _26419 = NOVALUE;

            /** 			end for*/
            _i_50899 = _i_50899 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_50753);
        _temp_50753 = NOVALUE;
        goto LC; // [794] 7412

        /** 	case RHS_SUBS then*/
        case 25:

        /** 		b = Pop() -- subscript*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		target = NewTempSym() -- target*/
        _target_50733 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_target_50733)) {
            _1 = (long)(DBL_PTR(_target_50733)->dbl);
            DeRefDS(_target_50733);
            _target_50733 = _1;
        }

        /** 		if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26423 = (_c_50730 < 0);
        if (_26423 != 0) {
            _26424 = 1;
            goto L1E; // [828] 851
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26425 = (int)*(((s1_ptr)_2)->base + _c_50730);
        if (IS_SEQUENCE(_26425)){
                _26426 = SEQ_PTR(_26425)->length;
        }
        else {
            _26426 = 1;
        }
        _26425 = NOVALUE;
        _26427 = (_26426 < 15);
        _26426 = NOVALUE;
        _26424 = (_26427 != 0);
L1E: 
        if (_26424 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26429 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26429);
        _26430 = (int)*(((s1_ptr)_2)->base + 15);
        _26429 = NOVALUE;
        if (IS_ATOM_INT(_26430)) {
            _26431 = (_26430 < 0);
        }
        else {
            _26431 = binary_op(LESS, _26430, 0);
        }
        _26430 = NOVALUE;
        if (_26431 == 0) {
            DeRef(_26431);
            _26431 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26431) && DBL_PTR(_26431)->dbl == 0.0){
                DeRef(_26431);
                _26431 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26431);
            _26431 = NOVALUE;
        }
        DeRef(_26431);
        _26431 = NOVALUE;
L1F: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_50726 = 92;
        goto L21; // [885] 1049
L20: 

        /** 		elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26432 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26432);
        _26433 = (int)*(((s1_ptr)_2)->base + 3);
        _26432 = NOVALUE;
        if (binary_op_a(NOTEQ, _26433, 1)){
            _26433 = NOVALUE;
            goto L22; // [904] 991
        }
        _26433 = NOVALUE;

        /** 			if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26435 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26435);
        _26436 = (int)*(((s1_ptr)_2)->base + 15);
        _26435 = NOVALUE;
        if (IS_ATOM_INT(_26436)) {
            _26437 = (_26436 != _52sequence_type_45735);
        }
        else {
            _26437 = binary_op(NOTEQ, _26436, _52sequence_type_45735);
        }
        _26436 = NOVALUE;
        if (IS_ATOM_INT(_26437)) {
            if (_26437 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26437)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26439 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26439);
        _26440 = (int)*(((s1_ptr)_2)->base + 15);
        _26439 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_26440)){
            _26441 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26440)->dbl));
        }
        else{
            _26441 = (int)*(((s1_ptr)_2)->base + _26440);
        }
        _2 = (int)SEQ_PTR(_26441);
        _26442 = (int)*(((s1_ptr)_2)->base + 2);
        _26441 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_26442)){
            _26443 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26442)->dbl));
        }
        else{
            _26443 = (int)*(((s1_ptr)_2)->base + _26442);
        }
        _2 = (int)SEQ_PTR(_26443);
        _26444 = (int)*(((s1_ptr)_2)->base + 15);
        _26443 = NOVALUE;
        if (IS_ATOM_INT(_26444)) {
            _26445 = (_26444 != _52sequence_type_45735);
        }
        else {
            _26445 = binary_op(NOTEQ, _26444, _52sequence_type_45735);
        }
        _26444 = NOVALUE;
        if (_26445 == 0) {
            DeRef(_26445);
            _26445 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26445) && DBL_PTR(_26445)->dbl == 0.0){
                DeRef(_26445);
                _26445 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26445);
            _26445 = NOVALUE;
        }
        DeRef(_26445);
        _26445 = NOVALUE;

        /** 				op = RHS_SUBS_CHECK*/
        _op_50726 = 92;
        goto L21; // [988] 1049
L22: 

        /** 		elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26446 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26446);
        _26447 = (int)*(((s1_ptr)_2)->base + 3);
        _26446 = NOVALUE;
        if (IS_ATOM_INT(_26447)) {
            _26448 = (_26447 != 2);
        }
        else {
            _26448 = binary_op(NOTEQ, _26447, 2);
        }
        _26447 = NOVALUE;
        if (IS_ATOM_INT(_26448)) {
            if (_26448 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26448)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26450 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26450);
        _26451 = (int)*(((s1_ptr)_2)->base + 1);
        _26450 = NOVALUE;
        _26452 = IS_SEQUENCE(_26451);
        _26451 = NOVALUE;
        _26453 = (_26452 == 0);
        _26452 = NOVALUE;
        if (_26453 == 0)
        {
            DeRef(_26453);
            _26453 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26453);
            _26453 = NOVALUE;
        }
L23: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_50726 = 92;
L24: 
L21: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		Push(target)*/
        _37Push(_target_50733);

        /** 		emit_addr(target)*/
        _37emit_addr(_target_50733);

        /** 		emit_temp(target, NEW_REFERENCE)*/
        _37emit_temp(_target_50733, 1);

        /** 		current_sequence = append(current_sequence, target)*/
        Append(&_37current_sequence_49799, _37current_sequence_49799, _target_50733);

        /** 		flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26455 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26455 = 1;
        }
        _26456 = _26455 - 2;
        _26455 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26457 = (int)*(((s1_ptr)_2)->base + _26456);
        Ref(_26457);
        _37flush_temp(_26457);
        _26457 = NOVALUE;
        goto LC; // [1113] 7412

        /** 	case PROC then -- procedure, function and type calls*/
        case 27:

        /** 		assignable = FALSE -- assume for now*/
        _37assignable_49809 = _9FALSE_429;

        /** 		subsym = op_info1*/
        _subsym_50734 = _37op_info1_49791;

        /** 		n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26458 = (int)*(((s1_ptr)_2)->base + _subsym_50734);
        _2 = (int)SEQ_PTR(_26458);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
            _n_50739 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
        }
        else{
            _n_50739 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
        }
        if (!IS_ATOM_INT(_n_50739)){
            _n_50739 = (long)DBL_PTR(_n_50739)->dbl;
        }
        _26458 = NOVALUE;

        /** 		if subsym = CurrentSub then*/
        if (_subsym_50734 != _12CurrentSub_11690)
        goto L25; // [1155] 1340

        /** 			for i = cgi-n+1 to cgi do*/
        _26461 = _37cgi_49807 - _n_50739;
        if ((long)((unsigned long)_26461 +(unsigned long) HIGH_BITS) >= 0){
            _26461 = NewDouble((double)_26461);
        }
        if (IS_ATOM_INT(_26461)) {
            _26462 = _26461 + 1;
            if (_26462 > MAXINT){
                _26462 = NewDouble((double)_26462);
            }
        }
        else
        _26462 = binary_op(PLUS, 1, _26461);
        DeRef(_26461);
        _26461 = NOVALUE;
        _26463 = _37cgi_49807;
        {
            int _i_50985;
            Ref(_26462);
            _i_50985 = _26462;
L26: 
            if (binary_op_a(GREATER, _i_50985, _26463)){
                goto L27; // [1176] 1339
            }

            /** 				if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26464 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26464 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            if (binary_op_a(LESSEQ, _26464, 0)){
                _26464 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26464 = NOVALUE;

            /** 					if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26466 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26466 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!IS_ATOM_INT(_26466)){
                _26467 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26466)->dbl));
            }
            else{
                _26467 = (int)*(((s1_ptr)_2)->base + _26466);
            }
            _2 = (int)SEQ_PTR(_26467);
            _26468 = (int)*(((s1_ptr)_2)->base + 4);
            _26467 = NOVALUE;
            if (IS_ATOM_INT(_26468)) {
                _26469 = (_26468 == 3);
            }
            else {
                _26469 = binary_op(EQUALS, _26468, 3);
            }
            _26468 = NOVALUE;
            if (IS_ATOM_INT(_26469)) {
                if (_26469 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26469)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26471 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26471 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!IS_ATOM_INT(_26471)){
                _26472 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26471)->dbl));
            }
            else{
                _26472 = (int)*(((s1_ptr)_2)->base + _26471);
            }
            _2 = (int)SEQ_PTR(_26472);
            _26473 = (int)*(((s1_ptr)_2)->base + 16);
            _26472 = NOVALUE;
            if (IS_ATOM_INT(_26473) && IS_ATOM_INT(_i_50985)) {
                _26474 = (_26473 < _i_50985);
            }
            else {
                _26474 = binary_op(LESS, _26473, _i_50985);
            }
            _26473 = NOVALUE;
            if (_26474 == 0) {
                DeRef(_26474);
                _26474 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26474) && DBL_PTR(_26474)->dbl == 0.0){
                    DeRef(_26474);
                    _26474 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26474);
                _26474 = NOVALUE;
            }
            DeRef(_26474);
            _26474 = NOVALUE;

            /** 						emit_opcode(ASSIGN)*/
            _37emit_opcode(18);

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26475 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26475 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            Ref(_26475);
            _37emit_addr(_26475);
            _26475 = NOVALUE;

            /** 						cg_stack[i] = NewTempSym()*/
            _26476 = _52NewTempSym(0);
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_50985);
            _1 = *(int *)_2;
            *(int *)_2 = _26476;
            if( _1 != _26476 ){
                DeRef(_1);
            }
            _26476 = NOVALUE;

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26477 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26477 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            Ref(_26477);
            _37emit_addr(_26477);
            _26477 = NOVALUE;

            /** 						check_for_temps()*/
            _37check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** 					elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26478 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26478 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            Ref(_26478);
            _26479 = _52sym_mode(_26478);
            _26478 = NOVALUE;
            if (binary_op_a(NOTEQ, _26479, 3)){
                DeRef(_26479);
                _26479 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26479);
            _26479 = NOVALUE;

            /** 						emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_50985)){
                _26481 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50985)->dbl));
            }
            else{
                _26481 = (int)*(((s1_ptr)_2)->base + _i_50985);
            }
            Ref(_26481);
            _37emit_temp(_26481, 1);
            _26481 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** 			end for*/
            _0 = _i_50985;
            if (IS_ATOM_INT(_i_50985)) {
                _i_50985 = _i_50985 + 1;
                if ((long)((unsigned long)_i_50985 +(unsigned long) HIGH_BITS) >= 0){
                    _i_50985 = NewDouble((double)_i_50985);
                }
            }
            else {
                _i_50985 = binary_op_a(PLUS, _i_50985, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_50985);
        }
L25: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(subsym)*/
        _37emit_addr(_subsym_50734);

        /** 		for i = cgi-n+1 to cgi do*/
        _26482 = _37cgi_49807 - _n_50739;
        if ((long)((unsigned long)_26482 +(unsigned long) HIGH_BITS) >= 0){
            _26482 = NewDouble((double)_26482);
        }
        if (IS_ATOM_INT(_26482)) {
            _26483 = _26482 + 1;
            if (_26483 > MAXINT){
                _26483 = NewDouble((double)_26483);
            }
        }
        else
        _26483 = binary_op(PLUS, 1, _26482);
        DeRef(_26482);
        _26482 = NOVALUE;
        _26484 = _37cgi_49807;
        {
            int _i_51020;
            Ref(_26483);
            _i_51020 = _26483;
L2C: 
            if (binary_op_a(GREATER, _i_51020, _26484)){
                goto L2D; // [1367] 1404
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_51020)){
                _26485 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51020)->dbl));
            }
            else{
                _26485 = (int)*(((s1_ptr)_2)->base + _i_51020);
            }
            Ref(_26485);
            _37emit_addr(_26485);
            _26485 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_51020)){
                _26486 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51020)->dbl));
            }
            else{
                _26486 = (int)*(((s1_ptr)_2)->base + _i_51020);
            }
            Ref(_26486);
            _37emit_temp(_26486, 1);
            _26486 = NOVALUE;

            /** 		end for*/
            _0 = _i_51020;
            if (IS_ATOM_INT(_i_51020)) {
                _i_51020 = _i_51020 + 1;
                if ((long)((unsigned long)_i_51020 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51020 = NewDouble((double)_i_51020);
                }
            }
            else {
                _i_51020 = binary_op_a(PLUS, _i_51020, 1);
            }
            DeRef(_0);
            goto L2C; // [1399] 1374
L2D: 
            ;
            DeRef(_i_51020);
        }

        /** 		cgi -= n*/
        _37cgi_49807 = _37cgi_49807 - _n_50739;

        /** 		if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26488 = (int)*(((s1_ptr)_2)->base + _subsym_50734);
        _2 = (int)SEQ_PTR(_26488);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _26489 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _26489 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _26488 = NOVALUE;
        if (binary_op_a(EQUALS, _26489, 27)){
            _26489 = NOVALUE;
            goto LC; // [1428] 7412
        }
        _26489 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);

        /** 			Push(c)*/
        _37Push(_c_50730);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);
        goto LC; // [1464] 7412

        /** 	case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 		assignable = FALSE -- assume for now*/
        _37assignable_49809 = _9FALSE_429;

        /** 		integer real_op*/

        /** 		if op = PROC_FORWARD then*/
        if (_op_50726 != 195)
        goto L2E; // [1485] 1501

        /** 			real_op = PROC*/
        _real_op_51041 = 27;
        goto L2F; // [1498] 1511
L2E: 

        /** 			real_op = FUNC*/
        _real_op_51041 = 501;
L2F: 

        /** 		integer ref*/

        /** 		ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_51048 = _29new_forward_reference(_real_op_51041, _37op_info1_49791, _real_op_51041);
        if (!IS_ATOM_INT(_ref_51048)) {
            _1 = (long)(DBL_PTR(_ref_51048)->dbl);
            DeRefDS(_ref_51048);
            _ref_51048 = _1;
        }

        /** 		n = Pop() -- number of known args*/
        _n_50739 = _37Pop();
        if (!IS_ATOM_INT(_n_50739)) {
            _1 = (long)(DBL_PTR(_n_50739)->dbl);
            DeRefDS(_n_50739);
            _n_50739 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(ref)*/
        _37emit_addr(_ref_51048);

        /** 		emit_addr( n ) -- this changes to be the "next" instruction*/
        _37emit_addr(_n_50739);

        /** 		for i = cgi-n+1 to cgi do*/
        _26495 = _37cgi_49807 - _n_50739;
        if ((long)((unsigned long)_26495 +(unsigned long) HIGH_BITS) >= 0){
            _26495 = NewDouble((double)_26495);
        }
        if (IS_ATOM_INT(_26495)) {
            _26496 = _26495 + 1;
            if (_26496 > MAXINT){
                _26496 = NewDouble((double)_26496);
            }
        }
        else
        _26496 = binary_op(PLUS, 1, _26495);
        DeRef(_26495);
        _26495 = NOVALUE;
        _26497 = _37cgi_49807;
        {
            int _i_51053;
            Ref(_26496);
            _i_51053 = _26496;
L30: 
            if (binary_op_a(GREATER, _i_51053, _26497)){
                goto L31; // [1566] 1603
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_51053)){
                _26498 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51053)->dbl));
            }
            else{
                _26498 = (int)*(((s1_ptr)_2)->base + _i_51053);
            }
            Ref(_26498);
            _37emit_addr(_26498);
            _26498 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_49806);
            if (!IS_ATOM_INT(_i_51053)){
                _26499 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51053)->dbl));
            }
            else{
                _26499 = (int)*(((s1_ptr)_2)->base + _i_51053);
            }
            Ref(_26499);
            _37emit_temp(_26499, 1);
            _26499 = NOVALUE;

            /** 		end for*/
            _0 = _i_51053;
            if (IS_ATOM_INT(_i_51053)) {
                _i_51053 = _i_51053 + 1;
                if ((long)((unsigned long)_i_51053 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51053 = NewDouble((double)_i_51053);
                }
            }
            else {
                _i_51053 = binary_op_a(PLUS, _i_51053, 1);
            }
            DeRef(_0);
            goto L30; // [1598] 1573
L31: 
            ;
            DeRef(_i_51053);
        }

        /** 		cgi -= n*/
        _37cgi_49807 = _37cgi_49807 - _n_50739;

        /** 		if op != PROC_FORWARD then*/
        if (_op_50726 == 195)
        goto L32; // [1615] 1651

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			Push(c)*/
        _37Push(_c_50730);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);
L32: 
        goto LC; // [1653] 7412

        /** 	case WARNING then*/
        case 506:

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 	    a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26504 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26504);
        _26505 = (int)*(((s1_ptr)_2)->base + 1);
        _26504 = NOVALUE;
        Ref(_26505);
        RefDS(_21829);
        _43Warning(_26505, 64, _21829);
        _26505 = NOVALUE;
        goto LC; // [1694] 7412

        /** 	case INCLUDE_PATHS then*/
        case 507:

        /** 		sequence paths*/

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 	    a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 	    emit_opcode(RIGHT_BRACE_N)*/
        _37emit_opcode(31);

        /** 	    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26507 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26507);
        _26508 = (int)*(((s1_ptr)_2)->base + 1);
        _26507 = NOVALUE;
        Ref(_26508);
        _0 = _paths_51078;
        _paths_51078 = _38Include_paths(_26508);
        DeRef(_0);
        _26508 = NOVALUE;

        /** 	    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_51078)){
                _26510 = SEQ_PTR(_paths_51078)->length;
        }
        else {
            _26510 = 1;
        }
        _37emit(_26510);
        _26510 = NOVALUE;

        /** 	    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_51078)){
                _26511 = SEQ_PTR(_paths_51078)->length;
        }
        else {
            _26511 = 1;
        }
        {
            int _i_51090;
            _i_51090 = _26511;
L33: 
            if (_i_51090 < 1){
                goto L34; // [1756] 1787
            }

            /** 	        c = NewStringSym(paths[i])*/
            _2 = (int)SEQ_PTR(_paths_51078);
            _26512 = (int)*(((s1_ptr)_2)->base + _i_51090);
            Ref(_26512);
            _c_50730 = _52NewStringSym(_26512);
            _26512 = NOVALUE;
            if (!IS_ATOM_INT(_c_50730)) {
                _1 = (long)(DBL_PTR(_c_50730)->dbl);
                DeRefDS(_c_50730);
                _c_50730 = _1;
            }

            /** 	        emit_addr(c)*/
            _37emit_addr(_c_50730);

            /** 	    end for*/
            _i_51090 = _i_51090 + -1;
            goto L33; // [1782] 1763
L34: 
            ;
        }

        /** 	    b = NewTempSym()*/
        _b_50729 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_temp(b, NEW_REFERENCE)*/
        _37emit_temp(_b_50729, 1);

        /** 	    Push(b)*/
        _37Push(_b_50729);

        /** 	    emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		last_op = RIGHT_BRACE_N*/
        _37last_op_50685 = 31;

        /** 		op = last_op*/
        _op_50726 = 31;
        DeRef(_paths_51078);
        _paths_51078 = NOVALUE;
        goto LC; // [1829] 7412

        /** 	case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		if op = UPDATE_GLOBALS then*/
        if (_op_50726 != 89)
        goto LC; // [1901] 7412

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [1916] 7412

        /** 	case IF, WHILE then*/
        case 20:
        case 47:

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		if previous_op >= LESS and previous_op <= NOT then*/
        _26517 = (_12previous_op_11781 >= 1);
        if (_26517 == 0) {
            goto L35; // [1948] 2240
        }
        _26519 = (_12previous_op_11781 <= 7);
        if (_26519 == 0)
        {
            DeRef(_26519);
            _26519 = NOVALUE;
            goto L35; // [1961] 2240
        }
        else{
            DeRef(_26519);
            _26519 = NOVALUE;
        }

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26520 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26520 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26521 = (int)*(((s1_ptr)_2)->base + _26520);
        Ref(_26521);
        _37clear_temp(_26521);
        _26521 = NOVALUE;

        /** 			Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26522 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26522 = 1;
        }
        _26523 = _26522 - 1;
        _26522 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_11771;
        RHS_Slice(_12Code_11771, 1, _26523);

        /** 			if previous_op = NOT then*/
        if (_12previous_op_11781 != 7)
        goto L36; // [2002] 2082

        /** 				op = NOT_IFW*/
        _op_50726 = 108;

        /** 				backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26526 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26526 = 1;
        }
        _26527 = _26526 - 1;
        _26526 = NOVALUE;
        _37backpatch(_26527, 108);
        _26527 = NOVALUE;

        /** 				sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26528 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26528 = 1;
        }
        _26529 = _26528 - 1;
        _26528 = NOVALUE;
        if (IS_SEQUENCE(_12Code_11771)){
                _26530 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26530 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51158;
        RHS_Slice(_12Code_11771, _26529, _26530);

        /** 				Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26532 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26532 = 1;
        }
        _26533 = _26532 - 2;
        _26532 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_11771;
        RHS_Slice(_12Code_11771, 1, _26533);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_12Code_11771, _12Code_11771, _if_code_51158);
        DeRefDS(_if_code_51158);
        _if_code_51158 = NOVALUE;
        goto L37; // [2079] 2227
L36: 

        /** 				if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26536 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26536 = 1;
        }
        _26537 = _26536 - 1;
        _26536 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26538 = (int)*(((s1_ptr)_2)->base + _26537);
        Ref(_26538);
        _26539 = _37IsInteger(_26538);
        _26538 = NOVALUE;
        if (IS_ATOM_INT(_26539)) {
            if (_26539 == 0) {
                goto L38; // [2101] 2143
            }
        }
        else {
            if (DBL_PTR(_26539)->dbl == 0.0) {
                goto L38; // [2101] 2143
            }
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _26541 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26541 = 1;
        }
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26542 = (int)*(((s1_ptr)_2)->base + _26541);
        Ref(_26542);
        _26543 = _37IsInteger(_26542);
        _26542 = NOVALUE;
        if (_26543 == 0) {
            DeRef(_26543);
            _26543 = NOVALUE;
            goto L38; // [2119] 2143
        }
        else {
            if (!IS_ATOM_INT(_26543) && DBL_PTR(_26543)->dbl == 0.0){
                DeRef(_26543);
                _26543 = NOVALUE;
                goto L38; // [2119] 2143
            }
            DeRef(_26543);
            _26543 = NOVALUE;
        }
        DeRef(_26543);
        _26543 = NOVALUE;

        /** 					op = previous_op + LESS_IFW_I - LESS*/
        _26544 = _12previous_op_11781 + 119;
        if ((long)((unsigned long)_26544 + (unsigned long)HIGH_BITS) >= 0) 
        _26544 = NewDouble((double)_26544);
        if (IS_ATOM_INT(_26544)) {
            _op_50726 = _26544 - 1;
        }
        else {
            _op_50726 = NewDouble(DBL_PTR(_26544)->dbl - (double)1);
        }
        DeRef(_26544);
        _26544 = NOVALUE;
        if (!IS_ATOM_INT(_op_50726)) {
            _1 = (long)(DBL_PTR(_op_50726)->dbl);
            DeRefDS(_op_50726);
            _op_50726 = _1;
        }
        goto L39; // [2140] 2162
L38: 

        /** 					op = previous_op + LESS_IFW - LESS*/
        _26546 = _12previous_op_11781 + 102;
        if ((long)((unsigned long)_26546 + (unsigned long)HIGH_BITS) >= 0) 
        _26546 = NewDouble((double)_26546);
        if (IS_ATOM_INT(_26546)) {
            _op_50726 = _26546 - 1;
        }
        else {
            _op_50726 = NewDouble(DBL_PTR(_26546)->dbl - (double)1);
        }
        DeRef(_26546);
        _26546 = NOVALUE;
        if (!IS_ATOM_INT(_op_50726)) {
            _1 = (long)(DBL_PTR(_op_50726)->dbl);
            DeRefDS(_op_50726);
            _op_50726 = _1;
        }
L39: 

        /** 				backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26548 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26548 = 1;
        }
        _26549 = _26548 - 2;
        _26548 = NOVALUE;
        _37backpatch(_26549, _op_50726);
        _26549 = NOVALUE;

        /** 				sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26550 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26550 = 1;
        }
        _26551 = _26550 - 2;
        _26550 = NOVALUE;
        if (IS_SEQUENCE(_12Code_11771)){
                _26552 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26552 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51197;
        RHS_Slice(_12Code_11771, _26551, _26552);

        /** 				Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26554 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26554 = 1;
        }
        _26555 = _26554 - 3;
        _26554 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_11771;
        RHS_Slice(_12Code_11771, 1, _26555);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_12Code_11771, _12Code_11771, _if_code_51197);
        DeRefDS(_if_code_51197);
        _if_code_51197 = NOVALUE;
L37: 

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;

        /** 			last_op = op*/
        _37last_op_50685 = _op_50726;
        goto LC; // [2237] 7412
L35: 

        /** 		elsif op = WHILE and*/
        _26558 = (_op_50726 == 47);
        if (_26558 == 0) {
            _26559 = 0;
            goto L3A; // [2248] 2260
        }
        _26560 = (_a_50728 > 0);
        _26559 = (_26560 != 0);
L3A: 
        if (_26559 == 0) {
            _26561 = 0;
            goto L3B; // [2260] 2286
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26562 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26562);
        _26563 = (int)*(((s1_ptr)_2)->base + 3);
        _26562 = NOVALUE;
        if (IS_ATOM_INT(_26563)) {
            _26564 = (_26563 == 2);
        }
        else {
            _26564 = binary_op(EQUALS, _26563, 2);
        }
        _26563 = NOVALUE;
        if (IS_ATOM_INT(_26564))
        _26561 = (_26564 != 0);
        else
        _26561 = DBL_PTR(_26564)->dbl != 0.0;
L3B: 
        if (_26561 == 0) {
            _26565 = 0;
            goto L3C; // [2286] 2309
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26566 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26566);
        _26567 = (int)*(((s1_ptr)_2)->base + 1);
        _26566 = NOVALUE;
        if (IS_ATOM_INT(_26567))
        _26568 = 1;
        else if (IS_ATOM_DBL(_26567))
        _26568 = IS_ATOM_INT(DoubleToInt(_26567));
        else
        _26568 = 0;
        _26567 = NOVALUE;
        _26565 = (_26568 != 0);
L3C: 
        if (_26565 == 0) {
            goto L3D; // [2309] 2358
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26570 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26570);
        _26571 = (int)*(((s1_ptr)_2)->base + 1);
        _26570 = NOVALUE;
        if (_26571 == 0)
        _26572 = 1;
        else if (IS_ATOM_INT(_26571) && IS_ATOM_INT(0))
        _26572 = 0;
        else
        _26572 = (compare(_26571, 0) == 0);
        _26571 = NOVALUE;
        _26573 = (_26572 == 0);
        _26572 = NOVALUE;
        if (_26573 == 0)
        {
            DeRef(_26573);
            _26573 = NOVALUE;
            goto L3D; // [2333] 2358
        }
        else{
            DeRef(_26573);
            _26573 = NOVALUE;
        }

        /** 			optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _37optimized_while_49793 = _9TRUE_431;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;
        goto LC; // [2355] 7412
L3D: 

        /** 			flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _a_50728;
        _26574 = MAKE_SEQ(_1);
        _37flush_temps(_26574);
        _26574 = NOVALUE;

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);
        goto LC; // [2378] 7412

        /** 	case INTEGER_CHECK then*/
        case 96:

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		if previous_op = ASSIGN then*/
        if (_12previous_op_11781 != 18)
        goto L3E; // [2397] 2456

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26576 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26576 = 1;
        }
        _26577 = _26576 - 1;
        _26576 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _c_50730 = (int)*(((s1_ptr)_2)->base + _26577);
        if (!IS_ATOM_INT(_c_50730)){
            _c_50730 = (long)DBL_PTR(_c_50730)->dbl;
        }

        /** 			if not IsInteger(c) then*/
        _26579 = _37IsInteger(_c_50730);
        if (IS_ATOM_INT(_26579)) {
            if (_26579 != 0){
                DeRef(_26579);
                _26579 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        else {
            if (DBL_PTR(_26579)->dbl != 0.0){
                DeRef(_26579);
                _26579 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        DeRef(_26579);
        _26579 = NOVALUE;

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);
        goto L40; // [2439] 2513
L3F: 

        /** 				last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto L40; // [2453] 2513
L3E: 

        /** 		elsif previous_op = -1 or*/
        _26581 = (_12previous_op_11781 == -1);
        if (_26581 != 0) {
            goto L41; // [2464] 2487
        }
        _2 = (int)SEQ_PTR(_37op_result_50407);
        _26583 = (int)*(((s1_ptr)_2)->base + _12previous_op_11781);
        _26584 = (_26583 != 1);
        _26583 = NOVALUE;
        if (_26584 == 0)
        {
            DeRef(_26584);
            _26584 = NOVALUE;
            goto L42; // [2483] 2502
        }
        else{
            DeRef(_26584);
            _26584 = NOVALUE;
        }
L41: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);
        goto L40; // [2499] 2513
L42: 

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
L40: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26585 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26585 = 1;
        }
        _26586 = _26585 - 1;
        _26585 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26587 = (int)*(((s1_ptr)_2)->base + _26586);
        Ref(_26587);
        _37clear_temp(_26587);
        _26587 = NOVALUE;
        goto LC; // [2531] 7412

        /** 	case SEQUENCE_CHECK then*/
        case 97:

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		if previous_op = ASSIGN then*/
        if (_12previous_op_11781 != 18)
        goto L43; // [2550] 2677

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26589 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26589 = 1;
        }
        _26590 = _26589 - 1;
        _26589 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _c_50730 = (int)*(((s1_ptr)_2)->base + _26590);
        if (!IS_ATOM_INT(_c_50730)){
            _c_50730 = (long)DBL_PTR(_c_50730)->dbl;
        }

        /** 			if c < 1 or*/
        _26592 = (_c_50730 < 1);
        if (_26592 != 0) {
            _26593 = 1;
            goto L44; // [2577] 2603
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26594 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26594);
        _26595 = (int)*(((s1_ptr)_2)->base + 3);
        _26594 = NOVALUE;
        if (IS_ATOM_INT(_26595)) {
            _26596 = (_26595 != 2);
        }
        else {
            _26596 = binary_op(NOTEQ, _26595, 2);
        }
        _26595 = NOVALUE;
        if (IS_ATOM_INT(_26596))
        _26593 = (_26596 != 0);
        else
        _26593 = DBL_PTR(_26596)->dbl != 0.0;
L44: 
        if (_26593 != 0) {
            goto L45; // [2603] 2630
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26598 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26598);
        _26599 = (int)*(((s1_ptr)_2)->base + 1);
        _26598 = NOVALUE;
        _26600 = IS_SEQUENCE(_26599);
        _26599 = NOVALUE;
        _26601 = (_26600 == 0);
        _26600 = NOVALUE;
        if (_26601 == 0)
        {
            DeRef(_26601);
            _26601 = NOVALUE;
            goto L46; // [2626] 2663
        }
        else{
            DeRef(_26601);
            _26601 = NOVALUE;
        }
L45: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);

        /** 				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26602 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26602 = 1;
        }
        _26603 = _26602 - 1;
        _26602 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26604 = (int)*(((s1_ptr)_2)->base + _26603);
        Ref(_26604);
        _37clear_temp(_26604);
        _26604 = NOVALUE;
        goto LC; // [2660] 7412
L46: 

        /** 				last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [2674] 7412
L43: 

        /** 		elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26605 = (_12previous_op_11781 == -1);
        if (_26605 != 0) {
            goto L47; // [2685] 2708
        }
        _2 = (int)SEQ_PTR(_37op_result_50407);
        _26607 = (int)*(((s1_ptr)_2)->base + _12previous_op_11781);
        _26608 = (_26607 != 2);
        _26607 = NOVALUE;
        if (_26608 == 0)
        {
            DeRef(_26608);
            _26608 = NOVALUE;
            goto L48; // [2704] 2741
        }
        else{
            DeRef(_26608);
            _26608 = NOVALUE;
        }
L47: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);

        /** 			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26609 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26609 = 1;
        }
        _26610 = _26609 - 1;
        _26609 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26611 = (int)*(((s1_ptr)_2)->base + _26610);
        Ref(_26611);
        _37clear_temp(_26611);
        _26611 = NOVALUE;
        goto LC; // [2738] 7412
L48: 

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [2752] 7412

        /** 	case ATOM_CHECK then*/
        case 101:

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		if previous_op = ASSIGN then*/
        if (_12previous_op_11781 != 18)
        goto L49; // [2771] 2970

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26613 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26613 = 1;
        }
        _26614 = _26613 - 1;
        _26613 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _c_50730 = (int)*(((s1_ptr)_2)->base + _26614);
        if (!IS_ATOM_INT(_c_50730)){
            _c_50730 = (long)DBL_PTR(_c_50730)->dbl;
        }

        /** 			if c > 1*/
        _26616 = (_c_50730 > 1);
        if (_26616 == 0) {
            goto L4A; // [2798] 2919
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26618 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26618);
        _26619 = (int)*(((s1_ptr)_2)->base + 3);
        _26618 = NOVALUE;
        if (IS_ATOM_INT(_26619)) {
            _26620 = (_26619 == 2);
        }
        else {
            _26620 = binary_op(EQUALS, _26619, 2);
        }
        _26619 = NOVALUE;
        if (_26620 == 0) {
            DeRef(_26620);
            _26620 = NOVALUE;
            goto L4A; // [2821] 2919
        }
        else {
            if (!IS_ATOM_INT(_26620) && DBL_PTR(_26620)->dbl == 0.0){
                DeRef(_26620);
                _26620 = NOVALUE;
                goto L4A; // [2821] 2919
            }
            DeRef(_26620);
            _26620 = NOVALUE;
        }
        DeRef(_26620);
        _26620 = NOVALUE;

        /** 				if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26621 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26621);
        _26622 = (int)*(((s1_ptr)_2)->base + 1);
        _26621 = NOVALUE;
        _26623 = IS_SEQUENCE(_26622);
        _26622 = NOVALUE;
        if (_26623 == 0)
        {
            _26623 = NOVALUE;
            goto L4B; // [2841] 2870
        }
        else{
            _26623 = NOVALUE;
        }

        /** 					ThisLine = ExprLine*/
        RefDS(_30ExprLine_55734);
        DeRef(_43ThisLine_48158);
        _43ThisLine_48158 = _30ExprLine_55734;

        /** 					bp = expr_bp*/
        _43bp_48162 = _30expr_bp_55735;

        /** 					CompileErr( 346 )*/
        RefDS(_21829);
        _43CompileErr(346, _21829, 0);
        goto L4C; // [2867] 3049
L4B: 

        /** 				elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26624 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26624);
        _26625 = (int)*(((s1_ptr)_2)->base + 1);
        _26624 = NOVALUE;
        if (binary_op_a(NOTEQ, _26625, _12NOVALUE_11536)){
            _26625 = NOVALUE;
            goto L4D; // [2886] 2905
        }
        _26625 = NOVALUE;

        /** 					emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 					emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);
        goto L4C; // [2902] 3049
L4D: 

        /** 					last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 					last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto L4C; // [2916] 3049
L4A: 

        /** 			elsif c < 1 */
        _26627 = (_c_50730 < 1);
        if (_26627 != 0) {
            goto L4E; // [2925] 2941
        }
        _26629 = _37IsInteger(_c_50730);
        if (IS_ATOM_INT(_26629)) {
            _26630 = (_26629 == 0);
        }
        else {
            _26630 = unary_op(NOT, _26629);
        }
        DeRef(_26629);
        _26629 = NOVALUE;
        if (_26630 == 0) {
            DeRef(_26630);
            _26630 = NOVALUE;
            goto L4F; // [2937] 2956
        }
        else {
            if (!IS_ATOM_INT(_26630) && DBL_PTR(_26630)->dbl == 0.0){
                DeRef(_26630);
                _26630 = NOVALUE;
                goto L4F; // [2937] 2956
            }
            DeRef(_26630);
            _26630 = NOVALUE;
        }
        DeRef(_26630);
        _26630 = NOVALUE;
L4E: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);
        goto L4C; // [2953] 3049
L4F: 

        /** 				last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto L4C; // [2967] 3049
L49: 

        /** 		elsif previous_op = -1 or*/
        _26631 = (_12previous_op_11781 == -1);
        if (_26631 != 0) {
            goto L50; // [2978] 3023
        }
        _2 = (int)SEQ_PTR(_37op_result_50407);
        _26633 = (int)*(((s1_ptr)_2)->base + _12previous_op_11781);
        _26634 = (_26633 != 1);
        _26633 = NOVALUE;
        if (_26634 == 0) {
            DeRef(_26635);
            _26635 = 0;
            goto L51; // [2996] 3018
        }
        _2 = (int)SEQ_PTR(_37op_result_50407);
        _26636 = (int)*(((s1_ptr)_2)->base + _12previous_op_11781);
        _26637 = (_26636 != 3);
        _26636 = NOVALUE;
        _26635 = (_26637 != 0);
L51: 
        if (_26635 == 0)
        {
            _26635 = NOVALUE;
            goto L52; // [3019] 3038
        }
        else{
            _26635 = NOVALUE;
        }
L50: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_49791);
        goto L4C; // [3035] 3049
L52: 

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
L4C: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26638 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26638 = 1;
        }
        _26639 = _26638 - 1;
        _26638 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26640 = (int)*(((s1_ptr)_2)->base + _26639);
        Ref(_26640);
        _37clear_temp(_26640);
        _26640 = NOVALUE;
        goto LC; // [3067] 7412

        /** 	case RIGHT_BRACE_N then*/
        case 31:

        /** 		n = op_info1*/
        _n_50739 = _37op_info1_49791;

        /** 		elements = {}*/
        RefDS(_21829);
        DeRef(_elements_50741);
        _elements_50741 = _21829;

        /** 		for i = 1 to n do*/
        _26641 = _n_50739;
        {
            int _i_51377;
            _i_51377 = 1;
L53: 
            if (_i_51377 > _26641){
                goto L54; // [3092] 3115
            }

            /** 			elements = append(elements, Pop())*/
            _26642 = _37Pop();
            Ref(_26642);
            Append(&_elements_50741, _elements_50741, _26642);
            DeRef(_26642);
            _26642 = NOVALUE;

            /** 		end for*/
            _i_51377 = _i_51377 + 1;
            goto L53; // [3110] 3099
L54: 
            ;
        }

        /** 		element_vals = good_string(elements)*/
        RefDS(_elements_50741);
        _0 = _element_vals_50742;
        _element_vals_50742 = _37good_string(_elements_50741);
        DeRef(_0);

        /** 		if sequence(element_vals) then*/
        _26645 = IS_SEQUENCE(_element_vals_50742);
        if (_26645 == 0)
        {
            _26645 = NOVALUE;
            goto L55; // [3126] 3157
        }
        else{
            _26645 = NOVALUE;
        }

        /** 			c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_50742);
        _c_50730 = _52NewStringSym(_element_vals_50742);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 			last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto L56; // [3154] 3248
L55: 

        /** 			if n = 2 then*/
        if (_n_50739 != 2)
        goto L57; // [3159] 3182

        /** 				emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _37emit_opcode(85);

        /** 				last_op = RIGHT_BRACE_2*/
        _37last_op_50685 = 85;
        goto L58; // [3179] 3193
L57: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 				emit(n)*/
        _37emit(_n_50739);
L58: 

        /** 			for i = 1 to n do*/
        _26648 = _n_50739;
        {
            int _i_51394;
            _i_51394 = 1;
L59: 
            if (_i_51394 > _26648){
                goto L5A; // [3198] 3221
            }

            /** 				emit_addr(elements[i])*/
            _2 = (int)SEQ_PTR(_elements_50741);
            _26649 = (int)*(((s1_ptr)_2)->base + _i_51394);
            Ref(_26649);
            _37emit_addr(_26649);
            _26649 = NOVALUE;

            /** 			end for*/
            _i_51394 = _i_51394 + 1;
            goto L59; // [3216] 3205
L5A: 
            ;
        }

        /** 			c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;
L56: 

        /** 		Push(c)*/
        _37Push(_c_50730);
        goto LC; // [3253] 7412

        /** 	case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** 		b = Pop() -- rhs value*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop() -- subscript*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		if op = ASSIGN_SUBS then*/
        if (_op_50726 != 16)
        goto L5B; // [3288] 3480

        /** 			if (previous_op != LHS_SUBS) and*/
        _26655 = (_12previous_op_11781 != 95);
        if (_26655 == 0) {
            _26656 = 0;
            goto L5C; // [3302] 3314
        }
        _26657 = (_c_50730 > 0);
        _26656 = (_26657 != 0);
L5C: 
        if (_26656 == 0) {
            goto L5D; // [3314] 3452
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26659 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26659);
        _26660 = (int)*(((s1_ptr)_2)->base + 3);
        _26659 = NOVALUE;
        if (IS_ATOM_INT(_26660)) {
            _26661 = (_26660 != 1);
        }
        else {
            _26661 = binary_op(NOTEQ, _26660, 1);
        }
        _26660 = NOVALUE;
        if (IS_ATOM_INT(_26661)) {
            if (_26661 != 0) {
                DeRef(_26662);
                _26662 = 1;
                goto L5E; // [3336] 3436
            }
        }
        else {
            if (DBL_PTR(_26661)->dbl != 0.0) {
                DeRef(_26662);
                _26662 = 1;
                goto L5E; // [3336] 3436
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26663 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26663);
        _26664 = (int)*(((s1_ptr)_2)->base + 15);
        _26663 = NOVALUE;
        if (IS_ATOM_INT(_26664)) {
            _26665 = (_26664 != _52sequence_type_45735);
        }
        else {
            _26665 = binary_op(NOTEQ, _26664, _52sequence_type_45735);
        }
        _26664 = NOVALUE;
        if (IS_ATOM_INT(_26665)) {
            if (_26665 == 0) {
                DeRef(_26666);
                _26666 = 0;
                goto L5F; // [3358] 3432
            }
        }
        else {
            if (DBL_PTR(_26665)->dbl == 0.0) {
                DeRef(_26666);
                _26666 = 0;
                goto L5F; // [3358] 3432
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26667 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26667);
        _26668 = (int)*(((s1_ptr)_2)->base + 15);
        _26667 = NOVALUE;
        if (IS_ATOM_INT(_26668)) {
            _26669 = (_26668 > 0);
        }
        else {
            _26669 = binary_op(GREATER, _26668, 0);
        }
        _26668 = NOVALUE;
        if (IS_ATOM_INT(_26669)) {
            if (_26669 == 0) {
                DeRef(_26670);
                _26670 = 0;
                goto L60; // [3378] 3428
            }
        }
        else {
            if (DBL_PTR(_26669)->dbl == 0.0) {
                DeRef(_26670);
                _26670 = 0;
                goto L60; // [3378] 3428
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26671 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26671);
        _26672 = (int)*(((s1_ptr)_2)->base + 15);
        _26671 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_26672)){
            _26673 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26672)->dbl));
        }
        else{
            _26673 = (int)*(((s1_ptr)_2)->base + _26672);
        }
        _2 = (int)SEQ_PTR(_26673);
        _26674 = (int)*(((s1_ptr)_2)->base + 2);
        _26673 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_26674)){
            _26675 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26674)->dbl));
        }
        else{
            _26675 = (int)*(((s1_ptr)_2)->base + _26674);
        }
        _2 = (int)SEQ_PTR(_26675);
        _26676 = (int)*(((s1_ptr)_2)->base + 15);
        _26675 = NOVALUE;
        if (IS_ATOM_INT(_26676)) {
            _26677 = (_26676 != _52sequence_type_45735);
        }
        else {
            _26677 = binary_op(NOTEQ, _26676, _52sequence_type_45735);
        }
        _26676 = NOVALUE;
        DeRef(_26670);
        if (IS_ATOM_INT(_26677))
        _26670 = (_26677 != 0);
        else
        _26670 = DBL_PTR(_26677)->dbl != 0.0;
L60: 
        DeRef(_26666);
        _26666 = (_26670 != 0);
L5F: 
        DeRef(_26662);
        _26662 = (_26666 != 0);
L5E: 
        if (_26662 == 0)
        {
            _26662 = NOVALUE;
            goto L5D; // [3437] 3452
        }
        else{
            _26662 = NOVALUE;
        }

        /** 				op = ASSIGN_SUBS_CHECK*/
        _op_50726 = 84;
        goto L61; // [3449] 3472
L5D: 

        /** 				if IsInteger(b) then*/
        _26678 = _37IsInteger(_b_50729);
        if (_26678 == 0) {
            DeRef(_26678);
            _26678 = NOVALUE;
            goto L62; // [3458] 3471
        }
        else {
            if (!IS_ATOM_INT(_26678) && DBL_PTR(_26678)->dbl == 0.0){
                DeRef(_26678);
                _26678 = NOVALUE;
                goto L62; // [3458] 3471
            }
            DeRef(_26678);
            _26678 = NOVALUE;
        }
        DeRef(_26678);
        _26678 = NOVALUE;

        /** 					op = ASSIGN_SUBS_I*/
        _op_50726 = 118;
L62: 
L61: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);
        goto L63; // [3477] 3506
L5B: 

        /** 		elsif op = PASSIGN_SUBS then*/
        if (_op_50726 != 162)
        goto L64; // [3484] 3498

        /** 			emit_opcode(PASSIGN_SUBS) -- always*/
        _37emit_opcode(162);
        goto L63; // [3495] 3506
L64: 

        /** 			emit_opcode(ASSIGN_SUBS) -- always*/
        _37emit_opcode(16);
L63: 

        /** 		emit_addr(c) -- sequence*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(a) -- subscript*/
        _37emit_addr(_a_50728);

        /** 		emit_addr(b) -- rhs value*/
        _37emit_addr(_b_50729);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [3528] 7412

        /** 	case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** 		a = Pop() -- subs*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		lhs_var = Pop() -- sequence*/
        _lhs_var_50736 = _37Pop();
        if (!IS_ATOM_INT(_lhs_var_50736)) {
            _1 = (long)(DBL_PTR(_lhs_var_50736)->dbl);
            DeRefDS(_lhs_var_50736);
            _lhs_var_50736 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(lhs_var)*/
        _37emit_addr(_lhs_var_50736);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		if op = LHS_SUBS then*/
        if (_op_50726 != 95)
        goto L65; // [3571] 3602

        /** 			TempKeep(lhs_var) -- should be lhs_target_temp*/
        _37TempKeep(_lhs_var_50736);

        /** 			emit_addr(lhs_target_temp)*/
        _37emit_addr(_37lhs_target_temp_49805);

        /** 			Push(lhs_target_temp)*/
        _37Push(_37lhs_target_temp_49805);

        /** 			emit_addr(0) -- place holder*/
        _37emit_addr(0);
        goto L66; // [3599] 3656
L65: 

        /** 			lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _52NewTempSym(0);
        _37lhs_target_temp_49805 = _0;
        if (!IS_ATOM_INT(_37lhs_target_temp_49805)) {
            _1 = (long)(DBL_PTR(_37lhs_target_temp_49805)->dbl);
            DeRefDS(_37lhs_target_temp_49805);
            _37lhs_target_temp_49805 = _1;
        }

        /** 			emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _37emit_addr(_37lhs_target_temp_49805);

        /** 			emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _37emit_temp(_37lhs_target_temp_49805, 1);

        /** 			Push(lhs_target_temp)*/
        _37Push(_37lhs_target_temp_49805);

        /** 			lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _52NewTempSym(0);
        _37lhs_subs1_copy_temp_49804 = _0;
        if (!IS_ATOM_INT(_37lhs_subs1_copy_temp_49804)) {
            _1 = (long)(DBL_PTR(_37lhs_subs1_copy_temp_49804)->dbl);
            DeRefDS(_37lhs_subs1_copy_temp_49804);
            _37lhs_subs1_copy_temp_49804 = _1;
        }

        /** 			emit_addr(lhs_subs1_copy_temp)*/
        _37emit_addr(_37lhs_subs1_copy_temp_49804);

        /** 			emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _37emit_temp(_37lhs_subs1_copy_temp_49804, 1);
L66: 

        /** 		current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_37current_sequence_49799, _37current_sequence_49799, _37lhs_target_temp_49805);

        /** 		assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [3673] 7412

        /** 	case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:

        /** 		cont11ii(op, TRUE)*/
        _37cont11ii(_op_50726, _9TRUE_431);
        goto LC; // [3707] 7412

        /** 	case UMINUS then*/
        case 12:

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if a > 0 then*/
        if (_a_50728 <= 0)
        goto L67; // [3722] 3968

        /** 			obj = SymTab[a][S_OBJ]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26688 = (int)*(((s1_ptr)_2)->base + _a_50728);
        DeRef(_obj_50740);
        _2 = (int)SEQ_PTR(_26688);
        _obj_50740 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_50740);
        _26688 = NOVALUE;

        /** 			if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26690 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26690);
        _26691 = (int)*(((s1_ptr)_2)->base + 3);
        _26690 = NOVALUE;
        if (binary_op_a(NOTEQ, _26691, 2)){
            _26691 = NOVALUE;
            goto L68; // [3756] 3880
        }
        _26691 = NOVALUE;

        /** 				if integer(obj) then*/
        if (IS_ATOM_INT(_obj_50740))
        _26693 = 1;
        else if (IS_ATOM_DBL(_obj_50740))
        _26693 = IS_ATOM_INT(DoubleToInt(_obj_50740));
        else
        _26693 = 0;
        if (_26693 == 0)
        {
            _26693 = NOVALUE;
            goto L69; // [3765] 3819
        }
        else{
            _26693 = NOVALUE;
        }

        /** 					if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_50740, -1073741824)){
            goto L6A; // [3772] 3793
        }

        /** 						Push(NewDoubleSym(-MININT))*/
        if ((unsigned long)-1073741824 == 0xC0000000)
        _26695 = (int)NewDouble((double)-0xC0000000);
        else
        _26695 = - -1073741824;
        _26696 = _52NewDoubleSym(_26695);
        _26695 = NOVALUE;
        _37Push(_26696);
        _26696 = NOVALUE;
        goto L6B; // [3790] 3806
L6A: 

        /** 						Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_50740)) {
            if ((unsigned long)_obj_50740 == 0xC0000000)
            _26697 = (int)NewDouble((double)-0xC0000000);
            else
            _26697 = - _obj_50740;
        }
        else {
            _26697 = unary_op(UMINUS, _obj_50740);
        }
        _26698 = _52NewIntSym(_26697);
        _26697 = NOVALUE;
        _37Push(_26698);
        _26698 = NOVALUE;
L6B: 

        /** 					last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;

        /** 					last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;
        goto LC; // [3816] 7412
L69: 

        /** 				elsif atom(obj) and obj != NOVALUE then*/
        _26699 = IS_ATOM(_obj_50740);
        if (_26699 == 0) {
            goto L6C; // [3824] 3863
        }
        if (IS_ATOM_INT(_obj_50740) && IS_ATOM_INT(_12NOVALUE_11536)) {
            _26701 = (_obj_50740 != _12NOVALUE_11536);
        }
        else {
            _26701 = binary_op(NOTEQ, _obj_50740, _12NOVALUE_11536);
        }
        if (_26701 == 0) {
            DeRef(_26701);
            _26701 = NOVALUE;
            goto L6C; // [3835] 3863
        }
        else {
            if (!IS_ATOM_INT(_26701) && DBL_PTR(_26701)->dbl == 0.0){
                DeRef(_26701);
                _26701 = NOVALUE;
                goto L6C; // [3835] 3863
            }
            DeRef(_26701);
            _26701 = NOVALUE;
        }
        DeRef(_26701);
        _26701 = NOVALUE;

        /** 					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_50740)) {
            if ((unsigned long)_obj_50740 == 0xC0000000)
            _26702 = (int)NewDouble((double)-0xC0000000);
            else
            _26702 = - _obj_50740;
        }
        else {
            _26702 = unary_op(UMINUS, _obj_50740);
        }
        _26703 = _52NewDoubleSym(_26702);
        _26702 = NOVALUE;
        _37Push(_26703);
        _26703 = NOVALUE;

        /** 					last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;

        /** 					last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;
        goto LC; // [3860] 7412
L6C: 

        /** 					Push(a)*/
        _37Push(_a_50728);

        /** 					cont11ii(op, FALSE)*/
        _37cont11ii(_op_50726, _9FALSE_429);
        goto LC; // [3877] 7412
L68: 

        /** 			elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_12TRANSLATE_11319 == 0) {
            _26704 = 0;
            goto L6D; // [3884] 3910
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26705 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26705);
        _26706 = (int)*(((s1_ptr)_2)->base + 3);
        _26705 = NOVALUE;
        if (IS_ATOM_INT(_26706)) {
            _26707 = (_26706 == 3);
        }
        else {
            _26707 = binary_op(EQUALS, _26706, 3);
        }
        _26706 = NOVALUE;
        if (IS_ATOM_INT(_26707))
        _26704 = (_26707 != 0);
        else
        _26704 = DBL_PTR(_26707)->dbl != 0.0;
L6D: 
        if (_26704 == 0) {
            goto L6E; // [3910] 3951
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26709 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26709);
        _26710 = (int)*(((s1_ptr)_2)->base + 36);
        _26709 = NOVALUE;
        if (IS_ATOM_INT(_26710)) {
            _26711 = (_26710 == 2);
        }
        else {
            _26711 = binary_op(EQUALS, _26710, 2);
        }
        _26710 = NOVALUE;
        if (_26711 == 0) {
            DeRef(_26711);
            _26711 = NOVALUE;
            goto L6E; // [3933] 3951
        }
        else {
            if (!IS_ATOM_INT(_26711) && DBL_PTR(_26711)->dbl == 0.0){
                DeRef(_26711);
                _26711 = NOVALUE;
                goto L6E; // [3933] 3951
            }
            DeRef(_26711);
            _26711 = NOVALUE;
        }
        DeRef(_26711);
        _26711 = NOVALUE;

        /** 				Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_50740)) {
            if ((unsigned long)_obj_50740 == 0xC0000000)
            _26712 = (int)NewDouble((double)-0xC0000000);
            else
            _26712 = - _obj_50740;
        }
        else {
            _26712 = unary_op(UMINUS, _obj_50740);
        }
        _26713 = _52NewDoubleSym(_26712);
        _26712 = NOVALUE;
        _37Push(_26713);
        _26713 = NOVALUE;
        goto LC; // [3948] 7412
L6E: 

        /** 				Push(a)*/
        _37Push(_a_50728);

        /** 				cont11ii(op, FALSE)*/
        _37cont11ii(_op_50726, _9FALSE_429);
        goto LC; // [3965] 7412
L67: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			cont11ii(op, FALSE)*/
        _37cont11ii(_op_50726, _9FALSE_429);
        goto LC; // [3982] 7412

        /** 	case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** 		cont11ii(op, FALSE)*/
        _37cont11ii(_op_50726, _9FALSE_429);
        goto LC; // [4014] 7412

        /** 	case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** 		cont11ii(op, FALSE)*/
        _37cont11ii(_op_50726, _9FALSE_429);
        goto LC; // [4034] 7412

        /** 	case ROUTINE_ID then*/
        case 134:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		source = Pop()*/
        _source_50732 = _37Pop();
        if (!IS_ATOM_INT(_source_50732)) {
            _1 = (long)(DBL_PTR(_source_50732)->dbl);
            DeRefDS(_source_50732);
            _source_50732 = _1;
        }

        /** 		if TRANSLATE then*/
        if (_12TRANSLATE_11319 == 0)
        {
            goto L6F; // [4056] 4100
        }
        else{
        }

        /** 			emit_addr(num_routines-1)*/
        _26715 = _12num_routines_11691 - 1;
        if ((long)((unsigned long)_26715 +(unsigned long) HIGH_BITS) >= 0){
            _26715 = NewDouble((double)_26715);
        }
        _37emit_addr(_26715);
        _26715 = NOVALUE;

        /** 			last_routine_id = num_routines*/
        _37last_routine_id_49796 = _12num_routines_11691;

        /** 			last_max_params = max_params*/
        _37last_max_params_49798 = _37max_params_49797;

        /** 			MarkTargets(source, S_RI_TARGET)*/
        _31379 = _52MarkTargets(_source_50732, 53);
        DeRef(_31379);
        _31379 = NOVALUE;
        goto L70; // [4097] 4137
L6F: 

        /** 			emit_addr(CurrentSub)*/
        _37emit_addr(_12CurrentSub_11690);

        /** 			emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_13SymTab_10636)){
                _26716 = SEQ_PTR(_13SymTab_10636)->length;
        }
        else {
            _26716 = 1;
        }
        _37emit_addr(_26716);
        _26716 = NOVALUE;

        /** 			if BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto L71; // [4121] 4136
        }
        else{
        }

        /** 				MarkTargets(source, S_NREFS)*/
        _31378 = _52MarkTargets(_source_50732, 12);
        DeRef(_31378);
        _31378 = NOVALUE;
L71: 
L70: 

        /** 		emit_addr(source)*/
        _37emit_addr(_source_50732);

        /** 		emit_addr(current_file_no)  -- necessary at top level*/
        _37emit_addr(_12current_file_no_11682);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempInteger(c) -- result will always be an integer*/
        _37TempInteger(_c_50730);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);
        goto LC; // [4179] 7412

        /** 	case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(Pop())*/
        _26718 = _37Pop();
        _37emit_addr(_26718);
        _26718 = NOVALUE;

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [4225] 7412

        /** 	case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26721 = _37Pop();
        _37emit_addr(_26721);
        _26721 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		if op = C_PROC then*/
        if (_op_50726 != 132)
        goto L72; // [4280] 4292

        /** 			emit_addr(CurrentSub)*/
        _37emit_addr(_12CurrentSub_11690);
L72: 

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [4299] 7412

        /** 	case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** 		cont21ii(op, TRUE)  -- both integer args => integer result*/
        _37cont21ii(_op_50726, _9TRUE_431);
        goto LC; // [4337] 7412

        /** 	case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if b < 1 or a < 1 then*/
        _26725 = (_b_50729 < 1);
        if (_26725 != 0) {
            goto L73; // [4363] 4376
        }
        _26727 = (_a_50728 < 1);
        if (_26727 == 0)
        {
            DeRef(_26727);
            _26727 = NOVALUE;
            goto L74; // [4372] 4397
        }
        else{
            DeRef(_26727);
            _26727 = NOVALUE;
        }
L73: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [4394] 7412
L74: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26728 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26728);
        _26729 = (int)*(((s1_ptr)_2)->base + 3);
        _26728 = NOVALUE;
        if (IS_ATOM_INT(_26729)) {
            _26730 = (_26729 == 2);
        }
        else {
            _26730 = binary_op(EQUALS, _26729, 2);
        }
        _26729 = NOVALUE;
        if (IS_ATOM_INT(_26730)) {
            if (_26730 == 0) {
                goto L75; // [4417] 4478
            }
        }
        else {
            if (DBL_PTR(_26730)->dbl == 0.0) {
                goto L75; // [4417] 4478
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26732 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26732);
        _26733 = (int)*(((s1_ptr)_2)->base + 1);
        _26732 = NOVALUE;
        if (_26733 == 1)
        _26734 = 1;
        else if (IS_ATOM_INT(_26733) && IS_ATOM_INT(1))
        _26734 = 0;
        else
        _26734 = (compare(_26733, 1) == 0);
        _26733 = NOVALUE;
        if (_26734 == 0)
        {
            _26734 = NOVALUE;
            goto L75; // [4438] 4478
        }
        else{
            _26734 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_50726 = 93;

        /** 			emit_opcode(op)*/
        _37emit_opcode(93);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(93, _a_50728, _b_50729, _9FALSE_429);
        goto LC; // [4475] 7412
L75: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26735 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26735);
        _26736 = (int)*(((s1_ptr)_2)->base + 3);
        _26735 = NOVALUE;
        if (IS_ATOM_INT(_26736)) {
            _26737 = (_26736 == 2);
        }
        else {
            _26737 = binary_op(EQUALS, _26736, 2);
        }
        _26736 = NOVALUE;
        if (IS_ATOM_INT(_26737)) {
            if (_26737 == 0) {
                goto L76; // [4498] 4559
            }
        }
        else {
            if (DBL_PTR(_26737)->dbl == 0.0) {
                goto L76; // [4498] 4559
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26739 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26739);
        _26740 = (int)*(((s1_ptr)_2)->base + 1);
        _26739 = NOVALUE;
        if (_26740 == 1)
        _26741 = 1;
        else if (IS_ATOM_INT(_26740) && IS_ATOM_INT(1))
        _26741 = 0;
        else
        _26741 = (compare(_26740, 1) == 0);
        _26740 = NOVALUE;
        if (_26741 == 0)
        {
            _26741 = NOVALUE;
            goto L76; // [4519] 4559
        }
        else{
            _26741 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_50726 = 93;

        /** 			emit_opcode(op)*/
        _37emit_opcode(93);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(93, _a_50728, _b_50729, _9FALSE_429);
        goto LC; // [4556] 7412
L76: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [4578] 7412

        /** 	case rw:MULTIPLY then*/
        case 13:

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if a < 1 or b < 1 then*/
        _26744 = (_a_50728 < 1);
        if (_26744 != 0) {
            goto L77; // [4604] 4617
        }
        _26746 = (_b_50729 < 1);
        if (_26746 == 0)
        {
            DeRef(_26746);
            _26746 = NOVALUE;
            goto L78; // [4613] 4638
        }
        else{
            DeRef(_26746);
            _26746 = NOVALUE;
        }
L77: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [4635] 7412
L78: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26747 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26747);
        _26748 = (int)*(((s1_ptr)_2)->base + 3);
        _26747 = NOVALUE;
        if (IS_ATOM_INT(_26748)) {
            _26749 = (_26748 == 2);
        }
        else {
            _26749 = binary_op(EQUALS, _26748, 2);
        }
        _26748 = NOVALUE;
        if (IS_ATOM_INT(_26749)) {
            if (_26749 == 0) {
                goto L79; // [4658] 4719
            }
        }
        else {
            if (DBL_PTR(_26749)->dbl == 0.0) {
                goto L79; // [4658] 4719
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26751 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26751);
        _26752 = (int)*(((s1_ptr)_2)->base + 1);
        _26751 = NOVALUE;
        if (_26752 == 2)
        _26753 = 1;
        else if (IS_ATOM_INT(_26752) && IS_ATOM_INT(2))
        _26753 = 0;
        else
        _26753 = (compare(_26752, 2) == 0);
        _26752 = NOVALUE;
        if (_26753 == 0)
        {
            _26753 = NOVALUE;
            goto L79; // [4679] 4719
        }
        else{
            _26753 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_50726 = 11;

        /** 			emit_opcode(op)*/
        _37emit_opcode(11);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(11, _a_50728, _b_50729, _9FALSE_429);
        goto LC; // [4716] 7412
L79: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26754 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26754);
        _26755 = (int)*(((s1_ptr)_2)->base + 3);
        _26754 = NOVALUE;
        if (IS_ATOM_INT(_26755)) {
            _26756 = (_26755 == 2);
        }
        else {
            _26756 = binary_op(EQUALS, _26755, 2);
        }
        _26755 = NOVALUE;
        if (IS_ATOM_INT(_26756)) {
            if (_26756 == 0) {
                goto L7A; // [4739] 4800
            }
        }
        else {
            if (DBL_PTR(_26756)->dbl == 0.0) {
                goto L7A; // [4739] 4800
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26758 = (int)*(((s1_ptr)_2)->base + _a_50728);
        _2 = (int)SEQ_PTR(_26758);
        _26759 = (int)*(((s1_ptr)_2)->base + 1);
        _26758 = NOVALUE;
        if (_26759 == 2)
        _26760 = 1;
        else if (IS_ATOM_INT(_26759) && IS_ATOM_INT(2))
        _26760 = 0;
        else
        _26760 = (compare(_26759, 2) == 0);
        _26759 = NOVALUE;
        if (_26760 == 0)
        {
            _26760 = NOVALUE;
            goto L7A; // [4760] 4800
        }
        else{
            _26760 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_50726 = 11;

        /** 			emit_opcode(op)*/
        _37emit_opcode(11);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(11, _a_50728, _b_50729, _9FALSE_429);
        goto LC; // [4797] 7412
L7A: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [4819] 7412

        /** 	case rw:DIVIDE then*/
        case 14:

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26762 = (_b_50729 > 0);
        if (_26762 == 0) {
            _26763 = 0;
            goto L7B; // [4838] 4864
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26764 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26764);
        _26765 = (int)*(((s1_ptr)_2)->base + 3);
        _26764 = NOVALUE;
        if (IS_ATOM_INT(_26765)) {
            _26766 = (_26765 == 2);
        }
        else {
            _26766 = binary_op(EQUALS, _26765, 2);
        }
        _26765 = NOVALUE;
        if (IS_ATOM_INT(_26766))
        _26763 = (_26766 != 0);
        else
        _26763 = DBL_PTR(_26766)->dbl != 0.0;
L7B: 
        if (_26763 == 0) {
            goto L7C; // [4864] 4935
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26768 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26768);
        _26769 = (int)*(((s1_ptr)_2)->base + 1);
        _26768 = NOVALUE;
        if (_26769 == 2)
        _26770 = 1;
        else if (IS_ATOM_INT(_26769) && IS_ATOM_INT(2))
        _26770 = 0;
        else
        _26770 = (compare(_26769, 2) == 0);
        _26769 = NOVALUE;
        if (_26770 == 0)
        {
            _26770 = NOVALUE;
            goto L7C; // [4885] 4935
        }
        else{
            _26770 = NOVALUE;
        }

        /** 			op = DIV2*/
        _op_50726 = 98;

        /** 			emit_opcode(op)*/
        _37emit_opcode(98);

        /** 			emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _26771 = _37Pop();
        _37emit_addr(_26771);
        _26771 = NOVALUE;

        /** 			a = 0*/
        _a_50728 = 0;

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _37cont21d(98, 0, _b_50729, _9FALSE_429);
        goto LC; // [4932] 7412
L7C: 

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [4949] 7412

        /** 	case FLOOR then*/
        case 83:

        /** 		if previous_op = rw:DIVIDE then*/
        if (_12previous_op_11781 != 14)
        goto L7D; // [4959] 5007

        /** 			op = FLOOR_DIV*/
        _op_50726 = 63;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26773 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26773 = 1;
        }
        _26774 = _26773 - 3;
        _26773 = NOVALUE;
        _37backpatch(_26774, 63);
        _26774 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 			last_op = op*/
        _37last_op_50685 = 63;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [5004] 7412
L7D: 

        /** 		elsif previous_op = DIV2 then*/
        if (_12previous_op_11781 != 98)
        goto L7E; // [5013] 5100

        /** 			op = FLOOR_DIV2*/
        _op_50726 = 66;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26776 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26776 = 1;
        }
        _26777 = _26776 - 3;
        _26776 = NOVALUE;
        _37backpatch(_26777, 66);
        _26777 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 			if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_12Code_11771)){
                _26778 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _26778 = 1;
        }
        _26779 = _26778 - 2;
        _26778 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _26780 = (int)*(((s1_ptr)_2)->base + _26779);
        Ref(_26780);
        _26781 = _37IsInteger(_26780);
        _26780 = NOVALUE;
        if (_26781 == 0) {
            DeRef(_26781);
            _26781 = NOVALUE;
            goto L7F; // [5067] 5087
        }
        else {
            if (!IS_ATOM_INT(_26781) && DBL_PTR(_26781)->dbl == 0.0){
                DeRef(_26781);
                _26781 = NOVALUE;
                goto L7F; // [5067] 5087
            }
            DeRef(_26781);
            _26781 = NOVALUE;
        }
        DeRef(_26781);
        _26781 = NOVALUE;

        /** 				TempInteger(Top()) --mark temp as integer type*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5195_51764);
        _2 = (int)SEQ_PTR(_37cg_stack_49806);
        _Top_inlined_Top_at_5195_51764 = (int)*(((s1_ptr)_2)->base + _37cgi_49807);
        Ref(_Top_inlined_Top_at_5195_51764);
        Ref(_Top_inlined_Top_at_5195_51764);
        _37TempInteger(_Top_inlined_Top_at_5195_51764);
L7F: 

        /** 			last_op = op*/
        _37last_op_50685 = _op_50726;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [5097] 7412
L7E: 

        /** 			cont11ii(op, TRUE)*/
        _37cont11ii(_op_50726, _9TRUE_431);
        goto LC; // [5109] 7412

        /** 	case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** 		cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [5153] 7412

        /** 	case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_50730);

        /** 		b = Pop()  -- remove SC1's temp*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;

        /** 		last_op = last_op_backup*/
        _37last_op_50685 = _last_op_backup_50744;

        /** 		last_pc = last_pc_backup*/
        _37last_pc_50686 = _last_pc_backup_50743;
        goto LC; // [5200] 7412

        /** 	case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(Pop())*/
        _26784 = _37Pop();
        _37emit_addr(_26784);
        _26784 = NOVALUE;

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_50730);

        /** 		emit_addr(c) -- target*/
        _37emit_addr(_c_50730);

        /** 		TempInteger(c)*/
        _37TempInteger(_c_50730);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [5255] 7412

        /** 	case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26788 = _37Pop();
        _37emit_addr(_26788);
        _26788 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [5309] 7412

        /** 	case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26791 = _37Pop();
        _37emit_addr(_26791);
        _26791 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		if op = FIND or op = FIND_FROM or op = OPEN then*/
        _26793 = (_op_50726 == 77);
        if (_26793 != 0) {
            _26794 = 1;
            goto L80; // [5384] 5398
        }
        _26795 = (_op_50726 == 176);
        _26794 = (_26795 != 0);
L80: 
        if (_26794 != 0) {
            goto L81; // [5398] 5413
        }
        _26797 = (_op_50726 == 37);
        if (_26797 == 0)
        {
            DeRef(_26797);
            _26797 = NOVALUE;
            goto L82; // [5409] 5421
        }
        else{
            DeRef(_26797);
            _26797 = NOVALUE;
        }
L81: 

        /** 			TempInteger( c )*/
        _37TempInteger(_c_50730);
        goto L83; // [5418] 5428
L82: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);
L83: 

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);
        goto LC; // [5445] 7412

        /** 	case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** 		n = op_info1  -- number of items to concatenate*/
        _n_50739 = _37op_info1_49791;

        /** 		emit_opcode(CONCAT_N)*/
        _37emit_opcode(157);

        /** 		emit(n)*/
        _37emit(_n_50739);

        /** 		for i = 1 to n do*/
        _26798 = _n_50739;
        {
            int _i_51832;
            _i_51832 = 1;
L84: 
            if (_i_51832 > _26798){
                goto L85; // [5475] 5503
            }

            /** 			symtab_index element = Pop()*/
            _element_51835 = _37Pop();
            if (!IS_ATOM_INT(_element_51835)) {
                _1 = (long)(DBL_PTR(_element_51835)->dbl);
                DeRefDS(_element_51835);
                _element_51835 = _1;
            }

            /** 			emit_addr( element )  -- reverse order*/
            _37emit_addr(_element_51835);

            /** 		end for*/
            _i_51832 = _i_51832 + 1;
            goto L84; // [5498] 5482
L85: 
            ;
        }

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		Push(c)*/
        _37Push(_c_50730);
        goto LC; // [5534] 7412

        /** 	case FOR then*/
        case 21:

        /** 		c = Pop() -- increment*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_50730);

        /** 		ic = IsInteger(c)*/
        _ic_50738 = _37IsInteger(_c_50730);
        if (!IS_ATOM_INT(_ic_50738)) {
            _1 = (long)(DBL_PTR(_ic_50738)->dbl);
            DeRefDS(_ic_50738);
            _ic_50738 = _1;
        }

        /** 		if c < 1 or*/
        _26803 = (_c_50730 < 1);
        if (_26803 != 0) {
            goto L86; // [5566] 5645
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26805 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26805);
        _26806 = (int)*(((s1_ptr)_2)->base + 3);
        _26805 = NOVALUE;
        if (IS_ATOM_INT(_26806)) {
            _26807 = (_26806 == 1);
        }
        else {
            _26807 = binary_op(EQUALS, _26806, 1);
        }
        _26806 = NOVALUE;
        if (IS_ATOM_INT(_26807)) {
            if (_26807 == 0) {
                DeRef(_26808);
                _26808 = 0;
                goto L87; // [5588] 5614
            }
        }
        else {
            if (DBL_PTR(_26807)->dbl == 0.0) {
                DeRef(_26808);
                _26808 = 0;
                goto L87; // [5588] 5614
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26809 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26809);
        _26810 = (int)*(((s1_ptr)_2)->base + 4);
        _26809 = NOVALUE;
        if (IS_ATOM_INT(_26810)) {
            _26811 = (_26810 != 2);
        }
        else {
            _26811 = binary_op(NOTEQ, _26810, 2);
        }
        _26810 = NOVALUE;
        DeRef(_26808);
        if (IS_ATOM_INT(_26811))
        _26808 = (_26811 != 0);
        else
        _26808 = DBL_PTR(_26811)->dbl != 0.0;
L87: 
        if (_26808 == 0) {
            DeRef(_26812);
            _26812 = 0;
            goto L88; // [5614] 5640
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26813 = (int)*(((s1_ptr)_2)->base + _c_50730);
        _2 = (int)SEQ_PTR(_26813);
        _26814 = (int)*(((s1_ptr)_2)->base + 4);
        _26813 = NOVALUE;
        if (IS_ATOM_INT(_26814)) {
            _26815 = (_26814 != 4);
        }
        else {
            _26815 = binary_op(NOTEQ, _26814, 4);
        }
        _26814 = NOVALUE;
        if (IS_ATOM_INT(_26815))
        _26812 = (_26815 != 0);
        else
        _26812 = DBL_PTR(_26815)->dbl != 0.0;
L88: 
        if (_26812 == 0)
        {
            _26812 = NOVALUE;
            goto L89; // [5641] 5682
        }
        else{
            _26812 = NOVALUE;
        }
L86: 

        /** 			emit_opcode(ASSIGN)*/
        _37emit_opcode(18);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 			c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			if ic then*/
        if (_ic_50738 == 0)
        {
            goto L8A; // [5667] 5676
        }
        else{
        }

        /** 				TempInteger( c )*/
        _37TempInteger(_c_50730);
L8A: 

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);
L89: 

        /** 		b = Pop() -- limit*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_50729);

        /** 		ib = IsInteger(b)*/
        _ib_50737 = _37IsInteger(_b_50729);
        if (!IS_ATOM_INT(_ib_50737)) {
            _1 = (long)(DBL_PTR(_ib_50737)->dbl);
            DeRefDS(_ib_50737);
            _ib_50737 = _1;
        }

        /** 		if b < 1 or*/
        _26819 = (_b_50729 < 1);
        if (_26819 != 0) {
            goto L8B; // [5708] 5787
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26821 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26821);
        _26822 = (int)*(((s1_ptr)_2)->base + 3);
        _26821 = NOVALUE;
        if (IS_ATOM_INT(_26822)) {
            _26823 = (_26822 == 1);
        }
        else {
            _26823 = binary_op(EQUALS, _26822, 1);
        }
        _26822 = NOVALUE;
        if (IS_ATOM_INT(_26823)) {
            if (_26823 == 0) {
                DeRef(_26824);
                _26824 = 0;
                goto L8C; // [5730] 5756
            }
        }
        else {
            if (DBL_PTR(_26823)->dbl == 0.0) {
                DeRef(_26824);
                _26824 = 0;
                goto L8C; // [5730] 5756
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26825 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26825);
        _26826 = (int)*(((s1_ptr)_2)->base + 4);
        _26825 = NOVALUE;
        if (IS_ATOM_INT(_26826)) {
            _26827 = (_26826 != 2);
        }
        else {
            _26827 = binary_op(NOTEQ, _26826, 2);
        }
        _26826 = NOVALUE;
        DeRef(_26824);
        if (IS_ATOM_INT(_26827))
        _26824 = (_26827 != 0);
        else
        _26824 = DBL_PTR(_26827)->dbl != 0.0;
L8C: 
        if (_26824 == 0) {
            DeRef(_26828);
            _26828 = 0;
            goto L8D; // [5756] 5782
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26829 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26829);
        _26830 = (int)*(((s1_ptr)_2)->base + 4);
        _26829 = NOVALUE;
        if (IS_ATOM_INT(_26830)) {
            _26831 = (_26830 != 4);
        }
        else {
            _26831 = binary_op(NOTEQ, _26830, 4);
        }
        _26830 = NOVALUE;
        if (IS_ATOM_INT(_26831))
        _26828 = (_26831 != 0);
        else
        _26828 = DBL_PTR(_26831)->dbl != 0.0;
L8D: 
        if (_26828 == 0)
        {
            _26828 = NOVALUE;
            goto L8E; // [5783] 5824
        }
        else{
            _26828 = NOVALUE;
        }
L8B: 

        /** 			emit_opcode(ASSIGN)*/
        _37emit_opcode(18);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 			b = NewTempSym()*/
        _b_50729 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 			if ib then*/
        if (_ib_50737 == 0)
        {
            goto L8F; // [5809] 5818
        }
        else{
        }

        /** 				TempInteger( b )*/
        _37TempInteger(_b_50729);
L8F: 

        /** 			emit_addr(b)*/
        _37emit_addr(_b_50729);
L8E: 

        /** 		a = Pop() -- initial value*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if IsInteger(a) and ib and ic then*/
        _26834 = _37IsInteger(_a_50728);
        if (IS_ATOM_INT(_26834)) {
            if (_26834 == 0) {
                DeRef(_26835);
                _26835 = 0;
                goto L90; // [5837] 5845
            }
        }
        else {
            if (DBL_PTR(_26834)->dbl == 0.0) {
                DeRef(_26835);
                _26835 = 0;
                goto L90; // [5837] 5845
            }
        }
        DeRef(_26835);
        _26835 = (_ib_50737 != 0);
L90: 
        if (_26835 == 0) {
            goto L91; // [5845] 5884
        }
        if (_ic_50738 == 0)
        {
            goto L91; // [5850] 5884
        }
        else{
        }

        /** 			SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_37op_info1_49791 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _52integer_type_45737;
        DeRef(_1);
        _26837 = NOVALUE;

        /** 			op = FOR_I*/
        _op_50726 = 125;
        goto L92; // [5881] 5894
L91: 

        /** 			op = FOR*/
        _op_50726 = 21;
L92: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		emit_addr(CurrentSub) -- in case recursion check is needed*/
        _37emit_addr(_12CurrentSub_11690);

        /** 		Push(b)*/
        _37Push(_b_50729);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [5938] 7412

        /** 	case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** 		emit_opcode(op) -- will be patched at runtime*/
        _37emit_opcode(_op_50726);

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		emit_addr(op_info2) -- address of top of loop*/
        _37emit_addr(_37op_info2_49792);

        /** 		emit_addr(Pop())    -- limit*/
        _26840 = _37Pop();
        _37emit_addr(_26840);
        _26840 = NOVALUE;

        /** 		emit_addr(op_info1) -- loop var*/
        _37emit_addr(_37op_info1_49791);

        /** 		emit_addr(a)        -- increment - not always used -*/
        _37emit_addr(_a_50728);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [5992] 7412

        /** 	case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** 		b = Pop()      -- rhs value, keep on stack*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_50729);

        /** 		a = Pop()      -- subscript, keep on stack*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		TempKeep(a)*/
        _37TempKeep(_a_50728);

        /** 		c = Pop()      -- lhs sequence, keep on stack*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_50730);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		d = NewTempSym()*/
        _d_50731 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_d_50731)) {
            _1 = (long)(DBL_PTR(_d_50731)->dbl);
            DeRefDS(_d_50731);
            _d_50731 = _1;
        }

        /** 		emit_addr(d)   -- place to store result*/
        _37emit_addr(_d_50731);

        /** 		emit_temp( d, NEW_REFERENCE )*/
        _37emit_temp(_d_50731, 1);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		Push(a)*/
        _37Push(_a_50728);

        /** 		Push(d)*/
        _37Push(_d_50731);

        /** 		Push(b)*/
        _37Push(_b_50729);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6097] 7412

        /** 	case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop() -- rhs value*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop() -- 2nd subs*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		c = Pop() -- 1st subs*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		emit_addr(Pop()) -- sequence*/
        _26848 = _37Pop();
        _37emit_addr(_26848);
        _26848 = NOVALUE;

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6161] 7412

        /** 	case REPLACE then*/
        case 201:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop()  -- source*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop()  -- replacement*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		c = Pop()  -- start of replaced slice*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		d = Pop()  -- end of replaced slice*/
        _d_50731 = _37Pop();
        if (!IS_ATOM_INT(_d_50731)) {
            _1 = (long)(DBL_PTR(_d_50731)->dbl);
            DeRefDS(_d_50731);
            _d_50731 = _1;
        }

        /** 		emit_addr(d)*/
        _37emit_addr(_d_50731);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)     -- place to store result*/
        _37emit_addr(_c_50730);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;
        goto LC; // [6251] 7412

        /** 	case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop()        -- rhs value not used*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_50729);

        /** 		a = Pop()        -- 2nd subs*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		TempKeep(a)*/
        _37TempKeep(_a_50728);

        /** 		c = Pop()        -- 1st subs*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_50730);

        /** 		d = Pop()*/
        _d_50731 = _37Pop();
        if (!IS_ATOM_INT(_d_50731)) {
            _1 = (long)(DBL_PTR(_d_50731)->dbl);
            DeRefDS(_d_50731);
            _d_50731 = _1;
        }

        /** 		TempKeep(d)      -- sequence*/
        _37TempKeep(_d_50731);

        /** 		emit_addr(d)*/
        _37emit_addr(_d_50731);

        /** 		Push(d)*/
        _37Push(_d_50731);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		Push(a)*/
        _37Push(_a_50728);

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)     -- place to store result*/
        _37emit_addr(_c_50730);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);

        /** 		Push(b)*/
        _37Push(_b_50729);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6378] 7412

        /** 	case CALL_PROC then*/
        case 136:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26860 = _37Pop();
        _37emit_addr(_26860);
        _26860 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6416] 7412

        /** 	case CALL_FUNC then*/
        case 137:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26862 = _37Pop();
        _37emit_addr(_26862);
        _26862 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_50729);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);
        goto LC; // [6478] 7412

        /** 	case EXIT_BLOCK then*/
        case 206:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr( Pop() )*/
        _26864 = _37Pop();
        _37emit_addr(_26864);
        _26864 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6504] 7412

        /** 	case RETURNP then*/
        case 29:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(CurrentSub)*/
        _37emit_addr(_12CurrentSub_11690);

        /** 		emit_addr(top_block())*/
        _26865 = _65top_block(0);
        _37emit_addr(_26865);
        _26865 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6538] 7412

        /** 	case RETURNF then*/
        case 28:

        /** 		clear_temp( Top() )*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_6750_51982);
        _2 = (int)SEQ_PTR(_37cg_stack_49806);
        _Top_inlined_Top_at_6750_51982 = (int)*(((s1_ptr)_2)->base + _37cgi_49807);
        Ref(_Top_inlined_Top_at_6750_51982);
        Ref(_Top_inlined_Top_at_6750_51982);
        _37clear_temp(_Top_inlined_Top_at_6750_51982);

        /** 		flush_temps()*/
        RefDS(_21829);
        _37flush_temps(_21829);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(CurrentSub)*/
        _37emit_addr(_12CurrentSub_11690);

        /** 		emit_addr(Least_block())*/
        _26866 = _65Least_block();
        _37emit_addr(_26866);
        _26866 = NOVALUE;

        /** 		emit_addr(Pop())*/
        _26867 = _37Pop();
        _37emit_addr(_26867);
        _26867 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6600] 7412

        /** 	case RETURNT then*/
        case 34:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6618] 7412

        /** 	case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;

        /** 		if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_50726 != 79)
        goto L93; // [6660] 6672

        /** 			TempInteger(c)*/
        _37TempInteger(_c_50730);
        goto L94; // [6669] 6679
L93: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_50730, 1);
L94: 

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);
        goto LC; // [6689] 7412

        /** 	case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(Pop())*/
        _26870 = _37Pop();
        _37emit_addr(_26870);
        _26870 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6721] 7412

        /** 	case POWER then*/
        case 72:

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26873 = (_b_50729 > 0);
        if (_26873 == 0) {
            _26874 = 0;
            goto L95; // [6747] 6773
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26875 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26875);
        _26876 = (int)*(((s1_ptr)_2)->base + 3);
        _26875 = NOVALUE;
        if (IS_ATOM_INT(_26876)) {
            _26877 = (_26876 == 2);
        }
        else {
            _26877 = binary_op(EQUALS, _26876, 2);
        }
        _26876 = NOVALUE;
        if (IS_ATOM_INT(_26877))
        _26874 = (_26877 != 0);
        else
        _26874 = DBL_PTR(_26877)->dbl != 0.0;
L95: 
        if (_26874 == 0) {
            goto L96; // [6773] 6830
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _26879 = (int)*(((s1_ptr)_2)->base + _b_50729);
        _2 = (int)SEQ_PTR(_26879);
        _26880 = (int)*(((s1_ptr)_2)->base + 1);
        _26879 = NOVALUE;
        if (_26880 == 2)
        _26881 = 1;
        else if (IS_ATOM_INT(_26880) && IS_ATOM_INT(2))
        _26881 = 0;
        else
        _26881 = (compare(_26880, 2) == 0);
        _26880 = NOVALUE;
        if (_26881 == 0)
        {
            _26881 = NOVALUE;
            goto L96; // [6794] 6830
        }
        else{
            _26881 = NOVALUE;
        }

        /** 			op = rw:MULTIPLY*/
        _op_50726 = 13;

        /** 			emit_opcode(op)*/
        _37emit_opcode(13);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(13, _a_50728, _b_50729, _9FALSE_429);
        goto LC; // [6827] 7412
L96: 

        /** 			Push(a)*/
        _37Push(_a_50728);

        /** 			Push(b)*/
        _37Push(_b_50729);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_50726, _9FALSE_429);
        goto LC; // [6849] 7412

        /** 	case TYPE_CHECK then*/
        case 65:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [6874] 7412

        /** 	case DOLLAR then*/
        case -22:

        /** 		if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26883 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26883 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_49799);
        _26884 = (int)*(((s1_ptr)_2)->base + _26883);
        if (IS_ATOM_INT(_26884)) {
            _26885 = (_26884 < 0);
        }
        else {
            _26885 = binary_op(LESS, _26884, 0);
        }
        _26884 = NOVALUE;
        if (IS_ATOM_INT(_26885)) {
            if (_26885 != 0) {
                goto L97; // [6895] 6931
            }
        }
        else {
            if (DBL_PTR(_26885)->dbl != 0.0) {
                goto L97; // [6895] 6931
            }
        }
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26887 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26887 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_49799);
        _26888 = (int)*(((s1_ptr)_2)->base + _26887);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_26888)){
            _26889 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26888)->dbl));
        }
        else{
            _26889 = (int)*(((s1_ptr)_2)->base + _26888);
        }
        _2 = (int)SEQ_PTR(_26889);
        _26890 = (int)*(((s1_ptr)_2)->base + 4);
        _26889 = NOVALUE;
        if (IS_ATOM_INT(_26890)) {
            _26891 = (_26890 == 9);
        }
        else {
            _26891 = binary_op(EQUALS, _26890, 9);
        }
        _26890 = NOVALUE;
        if (_26891 == 0) {
            DeRef(_26891);
            _26891 = NOVALUE;
            goto L98; // [6927] 7001
        }
        else {
            if (!IS_ATOM_INT(_26891) && DBL_PTR(_26891)->dbl == 0.0){
                DeRef(_26891);
                _26891 = NOVALUE;
                goto L98; // [6927] 7001
            }
            DeRef(_26891);
            _26891 = NOVALUE;
        }
        DeRef(_26891);
        _26891 = NOVALUE;
L97: 

        /** 			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_37lhs_ptr_49801 == 0) {
            goto L99; // [6935] 6964
        }
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26893 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26893 = 1;
        }
        _26894 = (_26893 == 1);
        _26893 = NOVALUE;
        if (_26894 == 0)
        {
            DeRef(_26894);
            _26894 = NOVALUE;
            goto L99; // [6949] 6964
        }
        else{
            DeRef(_26894);
            _26894 = NOVALUE;
        }

        /** 				c = PLENGTH*/
        _c_50730 = 160;
        goto L9A; // [6961] 6974
L99: 

        /** 				c = LENGTH*/
        _c_50730 = 42;
L9A: 

        /** 			c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26895 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26895 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_49799);
        _26896 = (int)*(((s1_ptr)_2)->base + _26895);
        Ref(_26896);
        _26897 = _29new_forward_reference(-100, _26896, _c_50730);
        _26896 = NOVALUE;
        if (IS_ATOM_INT(_26897)) {
            if ((unsigned long)_26897 == 0xC0000000)
            _c_50730 = (int)NewDouble((double)-0xC0000000);
            else
            _c_50730 = - _26897;
        }
        else {
            _c_50730 = unary_op(UMINUS, _26897);
        }
        DeRef(_26897);
        _26897 = NOVALUE;
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }
        goto L9B; // [6998] 7015
L98: 

        /** 			c = current_sequence[$]*/
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26899 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26899 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_49799);
        _c_50730 = (int)*(((s1_ptr)_2)->base + _26899);
        if (!IS_ATOM_INT(_c_50730)){
            _c_50730 = (long)DBL_PTR(_c_50730)->dbl;
        }
L9B: 

        /** 		if lhs_ptr and length(current_sequence) = 1 then*/
        if (_37lhs_ptr_49801 == 0) {
            goto L9C; // [7019] 7046
        }
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _26902 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _26902 = 1;
        }
        _26903 = (_26902 == 1);
        _26902 = NOVALUE;
        if (_26903 == 0)
        {
            DeRef(_26903);
            _26903 = NOVALUE;
            goto L9C; // [7033] 7046
        }
        else{
            DeRef(_26903);
            _26903 = NOVALUE;
        }

        /** 			emit_opcode(PLENGTH)*/
        _37emit_opcode(160);
        goto L9D; // [7043] 7054
L9C: 

        /** 			emit_opcode(LENGTH)*/
        _37emit_opcode(42);
L9D: 

        /** 		emit_addr( c )*/
        _37emit_addr(_c_50730);

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		TempInteger(c)*/
        _37TempInteger(_c_50730);

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		assignable = FALSE -- it wouldn't be assigned anyway*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [7089] 7412

        /** 	case TASK_SELF then*/
        case 170:

        /** 		c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_50730);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 		assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;
        goto LC; // [7125] 7412

        /** 	case SWITCH then*/
        case 185:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_50726);

        /** 		c = Pop()*/
        _c_50730 = _37Pop();
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 		b = Pop()*/
        _b_50729 = _37Pop();
        if (!IS_ATOM_INT(_b_50729)) {
            _1 = (long)(DBL_PTR(_b_50729)->dbl);
            DeRefDS(_b_50729);
            _b_50729 = _1;
        }

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		emit_addr( a ) -- Switch Expr*/
        _37emit_addr(_a_50728);

        /** 		emit_addr( b ) -- Case values*/
        _37emit_addr(_b_50729);

        /** 		emit_addr( c ) -- Jump table*/
        _37emit_addr(_c_50730);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [7179] 7412

        /** 	case CASE then*/
        case 186:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_50726);

        /** 		emit( cg_stack[cgi] )  -- the case index*/
        _2 = (int)SEQ_PTR(_37cg_stack_49806);
        _26909 = (int)*(((s1_ptr)_2)->base + _37cgi_49807);
        Ref(_26909);
        _37emit(_26909);
        _26909 = NOVALUE;

        /** 		cgi -= 1*/
        _37cgi_49807 = _37cgi_49807 - 1;
        goto LC; // [7211] 7412

        /** 	case PLATFORM then*/
        case 155:

        /** 		if BIND and shroud_only then*/
        if (_12BIND_11322 == 0) {
            goto L9E; // [7221] 7269
        }
        if (_12shroud_only_11680 == 0)
        {
            goto L9E; // [7228] 7269
        }
        else{
        }

        /** 			c = NewTempSym()*/
        _c_50730 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_50730)) {
            _1 = (long)(DBL_PTR(_c_50730)->dbl);
            DeRefDS(_c_50730);
            _c_50730 = _1;
        }

        /** 			TempInteger(c)*/
        _37TempInteger(_c_50730);

        /** 			Push(c)*/
        _37Push(_c_50730);

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_50730);

        /** 			assignable = TRUE*/
        _37assignable_49809 = _9TRUE_431;
        goto LC; // [7266] 7412
L9E: 

        /** 			n = host_platform()*/
        _n_50739 = _36host_platform();
        if (!IS_ATOM_INT(_n_50739)) {
            _1 = (long)(DBL_PTR(_n_50739)->dbl);
            DeRefDS(_n_50739);
            _n_50739 = _1;
        }

        /** 			Push(NewIntSym(n))*/
        _26914 = _52NewIntSym(_n_50739);
        _37Push(_26914);
        _26914 = NOVALUE;

        /** 			assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [7293] 7412

        /** 	case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [7325] 7412

        /** 	case TRACE then*/
        case 64:

        /** 		a = Pop()*/
        _a_50728 = _37Pop();
        if (!IS_ATOM_INT(_a_50728)) {
            _1 = (long)(DBL_PTR(_a_50728)->dbl);
            DeRefDS(_a_50728);
            _a_50728 = _1;
        }

        /** 		if OpTrace then*/
        if (_12OpTrace_11752 == 0)
        {
            goto L9F; // [7342] 7388
        }
        else{
        }

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_50726);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_50728);

        /** 			if TRANSLATE then*/
        if (_12TRANSLATE_11319 == 0)
        {
            goto LA0; // [7359] 7387
        }
        else{
        }

        /** 				if not trace_called then*/
        if (_37trace_called_49794 != 0)
        goto LA1; // [7366] 7377

        /** 					Warning(217,0)*/
        RefDS(_21829);
        _43Warning(217, 0, _21829);
LA1: 

        /** 				trace_called = TRUE*/
        _37trace_called_49794 = _9TRUE_431;
LA0: 
L9F: 

        /** 		assignable = FALSE*/
        _37assignable_49809 = _9FALSE_429;
        goto LC; // [7395] 7412

        /** 	case else*/
        default:

        /** 		InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_50726;
        _26918 = MAKE_SEQ(_1);
        _43InternalErr(259, _26918);
        _26918 = NOVALUE;
    ;}LC: 

    /** 	previous_op = op*/
    _12previous_op_11781 = _op_50726;

    /** 	inlined = 0*/
    _37inlined_50704 = 0;

    /** end procedure*/
    DeRef(_obj_50740);
    DeRef(_elements_50741);
    DeRef(_element_vals_50742);
    DeRef(_26725);
    _26725 = NOVALUE;
    DeRef(_26392);
    _26392 = NOVALUE;
    DeRef(_26402);
    _26402 = NOVALUE;
    DeRef(_26517);
    _26517 = NOVALUE;
    _26442 = NOVALUE;
    DeRef(_26762);
    _26762 = NOVALUE;
    DeRef(_26793);
    _26793 = NOVALUE;
    DeRef(_26831);
    _26831 = NOVALUE;
    DeRef(_26483);
    _26483 = NOVALUE;
    DeRef(_26581);
    _26581 = NOVALUE;
    DeRef(_26437);
    _26437 = NOVALUE;
    _26466 = NOVALUE;
    DeRef(_26631);
    _26631 = NOVALUE;
    DeRef(_26661);
    _26661 = NOVALUE;
    DeRef(_26766);
    _26766 = NOVALUE;
    DeRef(_26815);
    _26815 = NOVALUE;
    DeRef(_26873);
    _26873 = NOVALUE;
    DeRef(_26427);
    _26427 = NOVALUE;
    DeRef(_26462);
    _26462 = NOVALUE;
    DeRef(_26610);
    _26610 = NOVALUE;
    DeRef(_26350);
    _26350 = NOVALUE;
    DeRef(_26399);
    _26399 = NOVALUE;
    DeRef(_26529);
    _26529 = NOVALUE;
    DeRef(_26756);
    _26756 = NOVALUE;
    DeRef(_26707);
    _26707 = NOVALUE;
    DeRef(_26819);
    _26819 = NOVALUE;
    DeRef(_26352);
    _26352 = NOVALUE;
    DeRef(_26655);
    _26655 = NOVALUE;
    DeRef(_26586);
    _26586 = NOVALUE;
    DeRef(_26877);
    _26877 = NOVALUE;
    DeRef(_26523);
    _26523 = NOVALUE;
    DeRef(_26356);
    _26356 = NOVALUE;
    _26425 = NOVALUE;
    DeRef(_26539);
    _26539 = NOVALUE;
    DeRef(_26634);
    _26634 = NOVALUE;
    DeRef(_26827);
    _26827 = NOVALUE;
    DeRef(_26885);
    _26885 = NOVALUE;
    _26888 = NOVALUE;
    DeRef(_26834);
    _26834 = NOVALUE;
    DeRef(_26354);
    _26354 = NOVALUE;
    _26440 = NOVALUE;
    DeRef(_26560);
    _26560 = NOVALUE;
    DeRef(_26590);
    _26590 = NOVALUE;
    DeRef(_26749);
    _26749 = NOVALUE;
    DeRef(_26803);
    _26803 = NOVALUE;
    DeRef(_26348);
    _26348 = NOVALUE;
    DeRef(_26616);
    _26616 = NOVALUE;
    DeRef(_26665);
    _26665 = NOVALUE;
    DeRef(_26823);
    _26823 = NOVALUE;
    DeRef(_26577);
    _26577 = NOVALUE;
    DeRef(_26592);
    _26592 = NOVALUE;
    DeRef(_26669);
    _26669 = NOVALUE;
    _26674 = NOVALUE;
    DeRef(_26779);
    _26779 = NOVALUE;
    DeRef(_26807);
    _26807 = NOVALUE;
    DeRef(_26389);
    _26389 = NOVALUE;
    _26471 = NOVALUE;
    DeRef(_26555);
    _26555 = NOVALUE;
    DeRef(_26558);
    _26558 = NOVALUE;
    DeRef(_26603);
    _26603 = NOVALUE;
    DeRef(_26605);
    _26605 = NOVALUE;
    DeRef(_26614);
    _26614 = NOVALUE;
    DeRef(_26627);
    _26627 = NOVALUE;
    DeRef(_26637);
    _26637 = NOVALUE;
    DeRef(_26639);
    _26639 = NOVALUE;
    _26672 = NOVALUE;
    DeRef(_26811);
    _26811 = NOVALUE;
    DeRef(_26423);
    _26423 = NOVALUE;
    DeRef(_26448);
    _26448 = NOVALUE;
    DeRef(_26537);
    _26537 = NOVALUE;
    DeRef(_26564);
    _26564 = NOVALUE;
    DeRef(_26533);
    _26533 = NOVALUE;
    DeRef(_26596);
    _26596 = NOVALUE;
    DeRef(_26730);
    _26730 = NOVALUE;
    DeRef(_26795);
    _26795 = NOVALUE;
    DeRef(_26469);
    _26469 = NOVALUE;
    DeRef(_26551);
    _26551 = NOVALUE;
    _26372 = NOVALUE;
    DeRef(_26408);
    _26408 = NOVALUE;
    DeRef(_26496);
    _26496 = NOVALUE;
    DeRef(_26657);
    _26657 = NOVALUE;
    DeRef(_26677);
    _26677 = NOVALUE;
    DeRef(_26744);
    _26744 = NOVALUE;
    DeRef(_26384);
    _26384 = NOVALUE;
    DeRef(_26404);
    _26404 = NOVALUE;
    DeRef(_26456);
    _26456 = NOVALUE;
    DeRef(_26737);
    _26737 = NOVALUE;
    return;
    ;
}


void _37emit_assign_op(int _op_52133)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_52133)) {
        _1 = (long)(DBL_PTR(_op_52133)->dbl);
        DeRefDS(_op_52133);
        _op_52133 = _1;
    }

    /** 	if op = PLUS_EQUALS then*/
    if (_op_52133 != 515)
    goto L1; // [7] 21

    /** 		emit_op(PLUS)*/
    _37emit_op(11);
    goto L2; // [18] 86
L1: 

    /** 	elsif op = MINUS_EQUALS then*/
    if (_op_52133 != 516)
    goto L3; // [25] 39

    /** 		emit_op(MINUS)*/
    _37emit_op(10);
    goto L2; // [36] 86
L3: 

    /** 	elsif op = MULTIPLY_EQUALS then*/
    if (_op_52133 != 517)
    goto L4; // [43] 55

    /** 		emit_op(rw:MULTIPLY)*/
    _37emit_op(13);
    goto L2; // [52] 86
L4: 

    /** 	elsif op = DIVIDE_EQUALS then*/
    if (_op_52133 != 518)
    goto L5; // [59] 71

    /** 		emit_op(rw:DIVIDE)*/
    _37emit_op(14);
    goto L2; // [68] 86
L5: 

    /** 	elsif op = CONCAT_EQUALS then*/
    if (_op_52133 != 519)
    goto L6; // [75] 85

    /** 		emit_op(rw:CONCAT)*/
    _37emit_op(15);
L6: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _37StartSourceLine(int _sl_52153, int _dup_ok_52154, int _emit_coverage_52155)
{
    int _line_span_52158 = NOVALUE;
    int _26940 = NOVALUE;
    int _26938 = NOVALUE;
    int _26937 = NOVALUE;
    int _26936 = NOVALUE;
    int _26935 = NOVALUE;
    int _26934 = NOVALUE;
    int _26932 = NOVALUE;
    int _26929 = NOVALUE;
    int _26927 = NOVALUE;
    int _26926 = NOVALUE;
    int _26925 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sl_52153)) {
        _1 = (long)(DBL_PTR(_sl_52153)->dbl);
        DeRefDS(_sl_52153);
        _sl_52153 = _1;
    }
    if (!IS_ATOM_INT(_dup_ok_52154)) {
        _1 = (long)(DBL_PTR(_dup_ok_52154)->dbl);
        DeRefDS(_dup_ok_52154);
        _dup_ok_52154 = _1;
    }
    if (!IS_ATOM_INT(_emit_coverage_52155)) {
        _1 = (long)(DBL_PTR(_emit_coverage_52155)->dbl);
        DeRefDS(_emit_coverage_52155);
        _emit_coverage_52155 = _1;
    }

    /** 	if gline_number = LastLineNumber then*/
    if (_12gline_number_11687 != _60LastLineNumber_23568)
    goto L1; // [13] 66

    /** 		if length(LineTable) then*/
    if (IS_SEQUENCE(_12LineTable_11772)){
            _26925 = SEQ_PTR(_12LineTable_11772)->length;
    }
    else {
        _26925 = 1;
    }
    if (_26925 == 0)
    {
        _26925 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _26925 = NOVALUE;
    }

    /** 			if dup_ok then*/
    if (_dup_ok_52154 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** 				emit_op( STARTLINE )*/
    _37emit_op(58);

    /** 				emit_addr( gline_number )*/
    _37emit_addr(_12gline_number_11687);
L3: 

    /** 			return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** 			sl = FALSE -- top-level new statement to execute on same line*/
    _sl_52153 = _9FALSE_429;
L4: 
L1: 

    /** 	LastLineNumber = gline_number*/
    _60LastLineNumber_23568 = _12gline_number_11687;

    /** 	line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26926 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_26926);
    if (!IS_ATOM_INT(_12S_FIRSTLINE_11394)){
        _26927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRSTLINE_11394)->dbl));
    }
    else{
        _26927 = (int)*(((s1_ptr)_2)->base + _12S_FIRSTLINE_11394);
    }
    _26926 = NOVALUE;
    if (IS_ATOM_INT(_26927)) {
        _line_span_52158 = _12gline_number_11687 - _26927;
    }
    else {
        _line_span_52158 = binary_op(MINUS, _12gline_number_11687, _26927);
    }
    _26927 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_52158)) {
        _1 = (long)(DBL_PTR(_line_span_52158)->dbl);
        DeRefDS(_line_span_52158);
        _line_span_52158 = _1;
    }

    /** 	while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_12LineTable_11772)){
            _26929 = SEQ_PTR(_12LineTable_11772)->length;
    }
    else {
        _26929 = 1;
    }
    if (_26929 >= _line_span_52158)
    goto L6; // [109] 128

    /** 		LineTable = append(LineTable, -1) -- filler*/
    Append(&_12LineTable_11772, _12LineTable_11772, -1);

    /** 	end while*/
    goto L5; // [125] 104
L6: 

    /** 	LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_12Code_11771)){
            _26932 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _26932 = 1;
    }
    Append(&_12LineTable_11772, _12LineTable_11772, _26932);
    _26932 = NOVALUE;

    /** 	if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_52153 == 0) {
        goto L7; // [145] 190
    }
    if (_12TRANSLATE_11319 != 0) {
        DeRef(_26935);
        _26935 = 1;
        goto L8; // [151] 171
    }
    if (_12OpTrace_11752 != 0) {
        _26936 = 1;
        goto L9; // [157] 167
    }
    _26936 = (_12OpProfileStatement_11754 != 0);
L9: 
    DeRef(_26935);
    _26935 = (_26936 != 0);
L8: 
    if (_26935 == 0)
    {
        _26935 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _26935 = NOVALUE;
    }

    /** 		emit_op(STARTLINE)*/
    _37emit_op(58);

    /** 		emit_addr(gline_number)*/
    _37emit_addr(_12gline_number_11687);
L7: 

    /** 	if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_52153 == 0) {
        _26937 = 0;
        goto LA; // [192] 206
    }
    _26938 = (_emit_coverage_52155 == 2);
    _26937 = (_26938 != 0);
LA: 
    if (_26937 != 0) {
        goto LB; // [206] 221
    }
    _26940 = (_emit_coverage_52155 == 3);
    if (_26940 == 0)
    {
        DeRef(_26940);
        _26940 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_26940);
        _26940 = NOVALUE;
    }
LB: 

    /** 		include_line( gline_number )*/
    _49include_line(_12gline_number_11687);
LC: 

    /** end procedure*/
    DeRef(_26938);
    _26938 = NOVALUE;
    return;
    ;
}


int _37has_forward_params(int _sym_52212)
{
    int _26946 = NOVALUE;
    int _26945 = NOVALUE;
    int _26944 = NOVALUE;
    int _26943 = NOVALUE;
    int _26942 = NOVALUE;
    int _26941 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_52212)) {
        _1 = (long)(DBL_PTR(_sym_52212)->dbl);
        DeRefDS(_sym_52212);
        _sym_52212 = _1;
    }

    /** 	for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _26941 = (int)*(((s1_ptr)_2)->base + _sym_52212);
    _2 = (int)SEQ_PTR(_26941);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _26942 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _26942 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _26941 = NOVALUE;
    if (IS_ATOM_INT(_26942)) {
        _26943 = _26942 - 1;
        if ((long)((unsigned long)_26943 +(unsigned long) HIGH_BITS) >= 0){
            _26943 = NewDouble((double)_26943);
        }
    }
    else {
        _26943 = binary_op(MINUS, _26942, 1);
    }
    _26942 = NOVALUE;
    if (IS_ATOM_INT(_26943)) {
        _26944 = _37cgi_49807 - _26943;
        if ((long)((unsigned long)_26944 +(unsigned long) HIGH_BITS) >= 0){
            _26944 = NewDouble((double)_26944);
        }
    }
    else {
        _26944 = binary_op(MINUS, _37cgi_49807, _26943);
    }
    DeRef(_26943);
    _26943 = NOVALUE;
    _26945 = _37cgi_49807;
    {
        int _i_52214;
        Ref(_26944);
        _i_52214 = _26944;
L1: 
        if (binary_op_a(GREATER, _i_52214, _26945)){
            goto L2; // [32] 65
        }

        /** 		if cg_stack[i] < 0 then*/
        _2 = (int)SEQ_PTR(_37cg_stack_49806);
        if (!IS_ATOM_INT(_i_52214)){
            _26946 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_52214)->dbl));
        }
        else{
            _26946 = (int)*(((s1_ptr)_2)->base + _i_52214);
        }
        if (binary_op_a(GREATEREQ, _26946, 0)){
            _26946 = NOVALUE;
            goto L3; // [47] 58
        }
        _26946 = NOVALUE;

        /** 			return 1*/
        DeRef(_i_52214);
        DeRef(_26944);
        _26944 = NOVALUE;
        return 1;
L3: 

        /** 	end for*/
        _0 = _i_52214;
        if (IS_ATOM_INT(_i_52214)) {
            _i_52214 = _i_52214 + 1;
            if ((long)((unsigned long)_i_52214 +(unsigned long) HIGH_BITS) >= 0){
                _i_52214 = NewDouble((double)_i_52214);
            }
        }
        else {
            _i_52214 = binary_op_a(PLUS, _i_52214, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_52214);
    }

    /** 	return 0*/
    DeRef(_26944);
    _26944 = NOVALUE;
    return 0;
    ;
}



// 0x85A3EEA3
