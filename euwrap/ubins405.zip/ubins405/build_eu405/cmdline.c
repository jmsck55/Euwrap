// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _40local_abort(int _lvl_15181)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186 = NOVALUE;
    int _8239 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_40pause_msg_15178)){
            _8239 = SEQ_PTR(_40pause_msg_15178)->length;
    }
    else {
        _8239 = 1;
    }
    if (_8239 == 0)
    goto L1; // [10] 45

    /** 		console:maybe_any_key(pause_msg, 1)*/

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_40pause_msg_15178);
    _41any_key(_40pause_msg_15178, 1);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15186 = NOVALUE;
L1: 

    /** 	abort(lvl)*/
    UserCleanup(_lvl_15181);

    /** end procedure*/
    return;
    ;
}


int _40standardize_opts(int _opts_15189, int _auto_help_switches_15190)
{
    int _lExtras_15191 = NOVALUE;
    int _opt_15195 = NOVALUE;
    int _updated_15197 = NOVALUE;
    int _msg_inlined_crash_at_178_15229 = NOVALUE;
    int _msg_inlined_crash_at_354_15260 = NOVALUE;
    int _msg_inlined_crash_at_410_15269 = NOVALUE;
    int _msg_inlined_crash_at_460_15278 = NOVALUE;
    int _msg_inlined_crash_at_510_15287 = NOVALUE;
    int _msg_inlined_crash_at_560_15296 = NOVALUE;
    int _opt_15330 = NOVALUE;
    int _msg_inlined_crash_at_878_15349 = NOVALUE;
    int _data_inlined_crash_at_875_15348 = NOVALUE;
    int _msg_inlined_crash_at_967_15367 = NOVALUE;
    int _data_inlined_crash_at_964_15366 = NOVALUE;
    int _has_h_15368 = NOVALUE;
    int _has_help_15369 = NOVALUE;
    int _has_question_15370 = NOVALUE;
    int _appended_opts_15390 = NOVALUE;
    int _8416 = NOVALUE;
    int _8415 = NOVALUE;
    int _8413 = NOVALUE;
    int _8412 = NOVALUE;
    int _8411 = NOVALUE;
    int _8410 = NOVALUE;
    int _8409 = NOVALUE;
    int _8408 = NOVALUE;
    int _8407 = NOVALUE;
    int _8406 = NOVALUE;
    int _8405 = NOVALUE;
    int _8404 = NOVALUE;
    int _8403 = NOVALUE;
    int _8402 = NOVALUE;
    int _8400 = NOVALUE;
    int _8399 = NOVALUE;
    int _8398 = NOVALUE;
    int _8397 = NOVALUE;
    int _8396 = NOVALUE;
    int _8395 = NOVALUE;
    int _8394 = NOVALUE;
    int _8393 = NOVALUE;
    int _8392 = NOVALUE;
    int _8391 = NOVALUE;
    int _8390 = NOVALUE;
    int _8389 = NOVALUE;
    int _8387 = NOVALUE;
    int _8385 = NOVALUE;
    int _8384 = NOVALUE;
    int _8383 = NOVALUE;
    int _8382 = NOVALUE;
    int _8380 = NOVALUE;
    int _8378 = NOVALUE;
    int _8375 = NOVALUE;
    int _8372 = NOVALUE;
    int _8369 = NOVALUE;
    int _8367 = NOVALUE;
    int _8366 = NOVALUE;
    int _8365 = NOVALUE;
    int _8364 = NOVALUE;
    int _8362 = NOVALUE;
    int _8361 = NOVALUE;
    int _8360 = NOVALUE;
    int _8358 = NOVALUE;
    int _8357 = NOVALUE;
    int _8356 = NOVALUE;
    int _8354 = NOVALUE;
    int _8353 = NOVALUE;
    int _8352 = NOVALUE;
    int _8351 = NOVALUE;
    int _8350 = NOVALUE;
    int _8348 = NOVALUE;
    int _8347 = NOVALUE;
    int _8346 = NOVALUE;
    int _8345 = NOVALUE;
    int _8344 = NOVALUE;
    int _8343 = NOVALUE;
    int _8342 = NOVALUE;
    int _8341 = NOVALUE;
    int _8340 = NOVALUE;
    int _8339 = NOVALUE;
    int _8337 = NOVALUE;
    int _8336 = NOVALUE;
    int _8335 = NOVALUE;
    int _8334 = NOVALUE;
    int _8333 = NOVALUE;
    int _8332 = NOVALUE;
    int _8331 = NOVALUE;
    int _8330 = NOVALUE;
    int _8328 = NOVALUE;
    int _8327 = NOVALUE;
    int _8326 = NOVALUE;
    int _8325 = NOVALUE;
    int _8324 = NOVALUE;
    int _8323 = NOVALUE;
    int _8322 = NOVALUE;
    int _8321 = NOVALUE;
    int _8320 = NOVALUE;
    int _8319 = NOVALUE;
    int _8318 = NOVALUE;
    int _8317 = NOVALUE;
    int _8316 = NOVALUE;
    int _8315 = NOVALUE;
    int _8314 = NOVALUE;
    int _8312 = NOVALUE;
    int _8310 = NOVALUE;
    int _8309 = NOVALUE;
    int _8308 = NOVALUE;
    int _8307 = NOVALUE;
    int _8305 = NOVALUE;
    int _8304 = NOVALUE;
    int _8303 = NOVALUE;
    int _8302 = NOVALUE;
    int _8300 = NOVALUE;
    int _8299 = NOVALUE;
    int _8298 = NOVALUE;
    int _8297 = NOVALUE;
    int _8295 = NOVALUE;
    int _8294 = NOVALUE;
    int _8293 = NOVALUE;
    int _8292 = NOVALUE;
    int _8290 = NOVALUE;
    int _8289 = NOVALUE;
    int _8288 = NOVALUE;
    int _8287 = NOVALUE;
    int _8284 = NOVALUE;
    int _8283 = NOVALUE;
    int _8282 = NOVALUE;
    int _8281 = NOVALUE;
    int _8280 = NOVALUE;
    int _8279 = NOVALUE;
    int _8278 = NOVALUE;
    int _8277 = NOVALUE;
    int _8275 = NOVALUE;
    int _8274 = NOVALUE;
    int _8273 = NOVALUE;
    int _8272 = NOVALUE;
    int _8271 = NOVALUE;
    int _8270 = NOVALUE;
    int _8269 = NOVALUE;
    int _8268 = NOVALUE;
    int _8265 = NOVALUE;
    int _8264 = NOVALUE;
    int _8263 = NOVALUE;
    int _8262 = NOVALUE;
    int _8261 = NOVALUE;
    int _8260 = NOVALUE;
    int _8259 = NOVALUE;
    int _8258 = NOVALUE;
    int _8257 = NOVALUE;
    int _8256 = NOVALUE;
    int _8255 = NOVALUE;
    int _8254 = NOVALUE;
    int _8253 = NOVALUE;
    int _8252 = NOVALUE;
    int _8251 = NOVALUE;
    int _8250 = NOVALUE;
    int _8249 = NOVALUE;
    int _8247 = NOVALUE;
    int _8246 = NOVALUE;
    int _8245 = NOVALUE;
    int _8243 = NOVALUE;
    int _8241 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_15191 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15189)){
            _8241 = SEQ_PTR(_opts_15189)->length;
    }
    else {
        _8241 = 1;
    }
    {
        int _i_15193;
        _i_15193 = 1;
L1: 
        if (_i_15193 > _8241){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_15195);
        _2 = (int)SEQ_PTR(_opts_15189);
        _opt_15195 = (int)*(((s1_ptr)_2)->base + _i_15193);
        Ref(_opt_15195);

        /** 		integer updated = 0*/
        _updated_15197 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_15195)){
                _8243 = SEQ_PTR(_opt_15195)->length;
        }
        else {
            _8243 = 1;
        }
        if (_8243 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_15195)){
                _8245 = SEQ_PTR(_opt_15195)->length;
        }
        else {
            _8245 = 1;
        }
        _8246 = 6 - _8245;
        _8245 = NOVALUE;
        _8247 = Repeat(-1, _8246);
        _8246 = NOVALUE;
        Concat((object_ptr)&_opt_15195, _opt_15195, _8247);
        DeRefDS(_8247);
        _8247 = NOVALUE;

        /** 			updated = 1*/
        _updated_15197 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8249 = (int)*(((s1_ptr)_2)->base + 1);
        _8250 = IS_SEQUENCE(_8249);
        _8249 = NOVALUE;
        if (_8250 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_15195);
        _8252 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_8252)){
                _8253 = SEQ_PTR(_8252)->length;
        }
        else {
            _8253 = 1;
        }
        _8252 = NOVALUE;
        _8254 = (_8253 == 0);
        _8253 = NOVALUE;
        if (_8254 == 0)
        {
            DeRef(_8254);
            _8254 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_8254);
            _8254 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8255 = (int)*(((s1_ptr)_2)->base + 2);
        _8256 = IS_SEQUENCE(_8255);
        _8255 = NOVALUE;
        if (_8256 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_15195);
        _8258 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_8258)){
                _8259 = SEQ_PTR(_8258)->length;
        }
        else {
            _8259 = 1;
        }
        _8258 = NOVALUE;
        _8260 = (_8259 == 0);
        _8259 = NOVALUE;
        if (_8260 == 0)
        {
            DeRef(_8260);
            _8260 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_8260);
            _8260 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8261 = (int)*(((s1_ptr)_2)->base + 2);
        _8262 = IS_ATOM(_8261);
        _8261 = NOVALUE;
        if (_8262 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_15195);
        _8264 = (int)*(((s1_ptr)_2)->base + 1);
        _8265 = IS_ATOM(_8264);
        _8264 = NOVALUE;
        if (_8265 == 0)
        {
            _8265 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _8265 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_15191 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_15229);
        _msg_inlined_crash_at_178_15229 = EPrintf(-9999999, _8267, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_15229);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_15229);
        _msg_inlined_crash_at_178_15229 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_15191 = _i_15193;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8268 = (int)*(((s1_ptr)_2)->base + 6);
        _8269 = IS_ATOM(_8268);
        _8268 = NOVALUE;
        if (_8269 == 0)
        {
            _8269 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _8269 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_40EXTRAS_15167);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _40EXTRAS_15167;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_15197 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8270 = (int)*(((s1_ptr)_2)->base + 3);
        _8271 = IS_ATOM(_8270);
        _8270 = NOVALUE;
        if (_8271 == 0)
        {
            _8271 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _8271 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8272 = (int)*(((s1_ptr)_2)->base + 4);
        _8273 = IS_ATOM(_8272);
        _8272 = NOVALUE;
        if (_8273 == 0)
        {
            _8273 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _8273 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8274 = (int)*(((s1_ptr)_2)->base + 4);
        if (_8274 == 112)
        _8275 = 1;
        else if (IS_ATOM_INT(_8274) && IS_ATOM_INT(112))
        _8275 = 0;
        else
        _8275 = (compare(_8274, 112) == 0);
        _8274 = NOVALUE;
        if (_8275 == 0)
        {
            _8275 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _8275 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_8276);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _8276;
        _8277 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8277;
        if( _1 != _8277 ){
            DeRef(_1);
        }
        _8277 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_15197 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8278 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_8278)){
                _8279 = SEQ_PTR(_8278)->length;
        }
        else {
            _8279 = 1;
        }
        _8278 = NOVALUE;
        {
            int _j_15248;
            _j_15248 = 1;
L10: 
            if (_j_15248 > _8279){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_15195);
            _8280 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_8280);
            _8281 = (int)*(((s1_ptr)_2)->base + _j_15248);
            _8280 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_15195);
            _8282 = (int)*(((s1_ptr)_2)->base + 4);
            _8283 = _j_15248 + 1;
            _8284 = find_from(_8281, _8282, _8283);
            _8281 = NOVALUE;
            _8282 = NOVALUE;
            _8283 = NOVALUE;
            if (_8284 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_15260);
            _msg_inlined_crash_at_354_15260 = EPrintf(-9999999, _8286, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_15260);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_15260);
            _msg_inlined_crash_at_354_15260 = NOVALUE;
L12: 

            /** 			end for*/
            _j_15248 = _j_15248 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8287 = (int)*(((s1_ptr)_2)->base + 4);
        _8288 = find_from(112, _8287, 1);
        _8287 = NOVALUE;
        if (_8288 == 0)
        {
            _8288 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _8288 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8289 = (int)*(((s1_ptr)_2)->base + 4);
        _8290 = find_from(110, _8289, 1);
        _8289 = NOVALUE;
        if (_8290 == 0)
        {
            _8290 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _8290 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_15269);
        _msg_inlined_crash_at_410_15269 = EPrintf(-9999999, _8291, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_15269);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_15269);
        _msg_inlined_crash_at_410_15269 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8292 = (int)*(((s1_ptr)_2)->base + 4);
        _8293 = find_from(99, _8292, 1);
        _8292 = NOVALUE;
        if (_8293 == 0)
        {
            _8293 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _8293 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8294 = (int)*(((s1_ptr)_2)->base + 4);
        _8295 = find_from(105, _8294, 1);
        _8294 = NOVALUE;
        if (_8295 == 0)
        {
            _8295 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _8295 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_15278);
        _msg_inlined_crash_at_460_15278 = EPrintf(-9999999, _8296, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_15278);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_15278);
        _msg_inlined_crash_at_460_15278 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8297 = (int)*(((s1_ptr)_2)->base + 4);
        _8298 = find_from(109, _8297, 1);
        _8297 = NOVALUE;
        if (_8298 == 0)
        {
            _8298 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _8298 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8299 = (int)*(((s1_ptr)_2)->base + 4);
        _8300 = find_from(111, _8299, 1);
        _8299 = NOVALUE;
        if (_8300 == 0)
        {
            _8300 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _8300 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_15287);
        _msg_inlined_crash_at_510_15287 = EPrintf(-9999999, _8301, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_15287);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_15287);
        _msg_inlined_crash_at_510_15287 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8302 = (int)*(((s1_ptr)_2)->base + 4);
        _8303 = find_from(49, _8302, 1);
        _8302 = NOVALUE;
        if (_8303 == 0)
        {
            _8303 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _8303 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8304 = (int)*(((s1_ptr)_2)->base + 4);
        _8305 = find_from(42, _8304, 1);
        _8304 = NOVALUE;
        if (_8305 == 0)
        {
            _8305 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _8305 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_15296);
        _msg_inlined_crash_at_560_15296 = EPrintf(-9999999, _8306, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_15296);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_15296);
        _msg_inlined_crash_at_560_15296 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8307 = (int)*(((s1_ptr)_2)->base + 5);
        _8308 = IS_SEQUENCE(_8307);
        _8307 = NOVALUE;
        if (_8308 == 0)
        {
            _8308 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _8308 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8309 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_8309))
        _8310 = 1;
        else if (IS_ATOM_DBL(_8309))
        _8310 = IS_ATOM_INT(DoubleToInt(_8309));
        else
        _8310 = 0;
        _8309 = NOVALUE;
        if (_8310 != 0)
        goto L22; // [617] 634
        _8310 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8312 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _8312, 0)){
            _8312 = NOVALUE;
            goto L23; // [640] 656
        }
        _8312 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8314 = (int)*(((s1_ptr)_2)->base + 6);
        _8315 = IS_SEQUENCE(_8314);
        _8314 = NOVALUE;
        if (_8315 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_15195);
        _8317 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_8317)){
                _8318 = SEQ_PTR(_8317)->length;
        }
        else {
            _8318 = 1;
        }
        _8317 = NOVALUE;
        _8319 = (_8318 == 0);
        _8318 = NOVALUE;
        if (_8319 == 0)
        {
            DeRef(_8319);
            _8319 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_8319);
            _8319 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15197 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8320 = (int)*(((s1_ptr)_2)->base + 6);
        _8321 = IS_ATOM(_8320);
        _8320 = NOVALUE;
        if (_8321 == 0)
        {
            _8321 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _8321 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8322 = (int)*(((s1_ptr)_2)->base + 2);
        _8323 = IS_SEQUENCE(_8322);
        _8322 = NOVALUE;
        if (_8323 == 0)
        {
            _8323 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _8323 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8324 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_8324);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8324;
        if( _1 != _8324 ){
            DeRef(_1);
        }
        _8324 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8325 = (int)*(((s1_ptr)_2)->base + 1);
        _8326 = IS_SEQUENCE(_8325);
        _8325 = NOVALUE;
        if (_8326 == 0)
        {
            _8326 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _8326 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_15195);
        _8327 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_8327);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8327;
        if( _1 != _8327 ){
            DeRef(_1);
        }
        _8327 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_40EXTRAS_15167);
        _2 = (int)SEQ_PTR(_opt_15195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _40EXTRAS_15167;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_15197 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_15197 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_15195);
        _2 = (int)SEQ_PTR(_opts_15189);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15189 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15193);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_15195;
        DeRef(_1);
L29: 
        DeRef(_opt_15195);
        _opt_15195 = NOVALUE;

        /** 	end for*/
        _i_15193 = _i_15193 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15189)){
            _8328 = SEQ_PTR(_opts_15189)->length;
    }
    else {
        _8328 = 1;
    }
    {
        int _i_15328;
        _i_15328 = 1;
L2A: 
        if (_i_15328 > _8328){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_15330);
        _2 = (int)SEQ_PTR(_opts_15189);
        _opt_15330 = (int)*(((s1_ptr)_2)->base + _i_15328);
        Ref(_opt_15330);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15330);
        _8330 = (int)*(((s1_ptr)_2)->base + 1);
        _8331 = IS_SEQUENCE(_8330);
        _8330 = NOVALUE;
        if (_8331 == 0)
        {
            _8331 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _8331 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8332 = _i_15328 + 1;
        if (IS_SEQUENCE(_opts_15189)){
                _8333 = SEQ_PTR(_opts_15189)->length;
        }
        else {
            _8333 = 1;
        }
        {
            int _j_15336;
            _j_15336 = _8332;
L2D: 
            if (_j_15336 > _8333){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15330);
            _8334 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_15189);
            _8335 = (int)*(((s1_ptr)_2)->base + _j_15336);
            _2 = (int)SEQ_PTR(_8335);
            _8336 = (int)*(((s1_ptr)_2)->base + 1);
            _8335 = NOVALUE;
            if (_8334 == _8336)
            _8337 = 1;
            else if (IS_ATOM_INT(_8334) && IS_ATOM_INT(_8336))
            _8337 = 0;
            else
            _8337 = (compare(_8334, _8336) == 0);
            _8334 = NOVALUE;
            _8336 = NOVALUE;
            if (_8337 == 0)
            {
                _8337 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _8337 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15330);
            _8339 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8339);
            *((int *)(_2+4)) = _8339;
            _8340 = MAKE_SEQ(_1);
            _8339 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_15348);
            _data_inlined_crash_at_875_15348 = _8340;
            _8340 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_15349);
            _msg_inlined_crash_at_878_15349 = EPrintf(-9999999, _8338, _data_inlined_crash_at_875_15348);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_15349);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_15348);
            _data_inlined_crash_at_875_15348 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_15349);
            _msg_inlined_crash_at_878_15349 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_15336 = _j_15336 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15330);
        _8341 = (int)*(((s1_ptr)_2)->base + 2);
        _8342 = IS_SEQUENCE(_8341);
        _8341 = NOVALUE;
        if (_8342 == 0)
        {
            _8342 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _8342 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8343 = _i_15328 + 1;
        if (IS_SEQUENCE(_opts_15189)){
                _8344 = SEQ_PTR(_opts_15189)->length;
        }
        else {
            _8344 = 1;
        }
        {
            int _j_15354;
            _j_15354 = _8343;
L32: 
            if (_j_15354 > _8344){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15330);
            _8345 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_15189);
            _8346 = (int)*(((s1_ptr)_2)->base + _j_15354);
            _2 = (int)SEQ_PTR(_8346);
            _8347 = (int)*(((s1_ptr)_2)->base + 2);
            _8346 = NOVALUE;
            if (_8345 == _8347)
            _8348 = 1;
            else if (IS_ATOM_INT(_8345) && IS_ATOM_INT(_8347))
            _8348 = 0;
            else
            _8348 = (compare(_8345, _8347) == 0);
            _8345 = NOVALUE;
            _8347 = NOVALUE;
            if (_8348 == 0)
            {
                _8348 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _8348 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15330);
            _8350 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8350);
            *((int *)(_2+4)) = _8350;
            _8351 = MAKE_SEQ(_1);
            _8350 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_15366);
            _data_inlined_crash_at_964_15366 = _8351;
            _8351 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_15367);
            _msg_inlined_crash_at_967_15367 = EPrintf(-9999999, _8349, _data_inlined_crash_at_964_15366);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_15367);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_15366);
            _data_inlined_crash_at_964_15366 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_15367);
            _msg_inlined_crash_at_967_15367 = NOVALUE;
L34: 

            /** 			end for*/
            _j_15354 = _j_15354 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_15330);
        _opt_15330 = NOVALUE;

        /** 	end for*/
        _i_15328 = _i_15328 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_15368 = 0;
    _has_help_15369 = 0;
    _has_question_15370 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15189)){
            _8352 = SEQ_PTR(_opts_15189)->length;
    }
    else {
        _8352 = 1;
    }
    {
        int _i_15372;
        _i_15372 = 1;
L36: 
        if (_i_15372 > _8352){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8353 = (int)*(((s1_ptr)_2)->base + _i_15372);
        _2 = (int)SEQ_PTR(_8353);
        _8354 = (int)*(((s1_ptr)_2)->base + 1);
        _8353 = NOVALUE;
        if (_8354 == _8355)
        _8356 = 1;
        else if (IS_ATOM_INT(_8354) && IS_ATOM_INT(_8355))
        _8356 = 0;
        else
        _8356 = (compare(_8354, _8355) == 0);
        _8354 = NOVALUE;
        if (_8356 == 0)
        {
            _8356 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _8356 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_15368 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8357 = (int)*(((s1_ptr)_2)->base + _i_15372);
        _2 = (int)SEQ_PTR(_8357);
        _8358 = (int)*(((s1_ptr)_2)->base + 1);
        _8357 = NOVALUE;
        if (_8358 == _8359)
        _8360 = 1;
        else if (IS_ATOM_INT(_8358) && IS_ATOM_INT(_8359))
        _8360 = 0;
        else
        _8360 = (compare(_8358, _8359) == 0);
        _8358 = NOVALUE;
        if (_8360 == 0)
        {
            _8360 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _8360 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_15370 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8361 = (int)*(((s1_ptr)_2)->base + _i_15372);
        _2 = (int)SEQ_PTR(_8361);
        _8362 = (int)*(((s1_ptr)_2)->base + 2);
        _8361 = NOVALUE;
        if (_8362 == _8363)
        _8364 = 1;
        else if (IS_ATOM_INT(_8362) && IS_ATOM_INT(_8363))
        _8364 = 0;
        else
        _8364 = (compare(_8362, _8363) == 0);
        _8362 = NOVALUE;
        if (_8364 == 0)
        {
            _8364 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _8364 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_15369 = 1;
L3B: 

        /** 	end for*/
        _i_15372 = _i_15372 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_15190 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_15390 = 0;

    /** 		if not has_h and not has_help then*/
    _8365 = (_has_h_15368 == 0);
    if (_8365 == 0) {
        goto L3D; // [1121] 1154
    }
    _8367 = (_has_help_15369 == 0);
    if (_8367 == 0)
    {
        DeRef(_8367);
        _8367 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_8367);
        _8367 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8355);
    *((int *)(_2+4)) = _8355;
    RefDS(_8363);
    *((int *)(_2+8)) = _8363;
    RefDS(_8368);
    *((int *)(_2+12)) = _8368;
    RefDS(_8355);
    *((int *)(_2+16)) = _8355;
    *((int *)(_2+20)) = -1;
    _8369 = MAKE_SEQ(_1);
    RefDS(_8369);
    Append(&_opts_15189, _opts_15189, _8369);
    DeRefDS(_8369);
    _8369 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15390 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_15368 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8355);
    *((int *)(_2+4)) = _8355;
    *((int *)(_2+8)) = 0;
    RefDS(_8368);
    *((int *)(_2+12)) = _8368;
    RefDS(_8355);
    *((int *)(_2+16)) = _8355;
    *((int *)(_2+20)) = -1;
    _8372 = MAKE_SEQ(_1);
    RefDS(_8372);
    Append(&_opts_15189, _opts_15189, _8372);
    DeRefDS(_8372);
    _8372 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15390 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_15369 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_8363);
    *((int *)(_2+8)) = _8363;
    RefDS(_8368);
    *((int *)(_2+12)) = _8368;
    RefDS(_8355);
    *((int *)(_2+16)) = _8355;
    *((int *)(_2+20)) = -1;
    _8375 = MAKE_SEQ(_1);
    RefDS(_8375);
    Append(&_opts_15189, _opts_15189, _8375);
    DeRefDS(_8375);
    _8375 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15390 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_15370 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8359);
    *((int *)(_2+4)) = _8359;
    *((int *)(_2+8)) = 0;
    RefDS(_8368);
    *((int *)(_2+12)) = _8368;
    RefDS(_8355);
    *((int *)(_2+16)) = _8355;
    *((int *)(_2+20)) = -1;
    _8378 = MAKE_SEQ(_1);
    RefDS(_8378);
    Append(&_opts_15189, _opts_15189, _8378);
    DeRefDS(_8378);
    _8378 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15390 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_15390 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_15189);
    DeRef(_8380);
    _8380 = _opts_15189;
    _0 = _opts_15189;
    _opts_15189 = _40standardize_opts(_8380, 0);
    DeRefDS(_0);
    _8380 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15189)){
            _8382 = SEQ_PTR(_opts_15189)->length;
    }
    else {
        _8382 = 1;
    }
    {
        int _i_15414;
        _i_15414 = 1;
L43: 
        if (_i_15414 > _8382){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8383 = (int)*(((s1_ptr)_2)->base + _i_15414);
        _2 = (int)SEQ_PTR(_8383);
        _8384 = (int)*(((s1_ptr)_2)->base + 4);
        _8383 = NOVALUE;
        _8385 = find_from(112, _8384, 1);
        _8384 = NOVALUE;
        if (_8385 != 0)
        goto L45; // [1280] 1303
        _8385 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_15189);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15189 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15414 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8389 = (int)*(((s1_ptr)_2)->base + 4);
        _8387 = NOVALUE;
        if (IS_SEQUENCE(_8389) && IS_ATOM(110)) {
            Append(&_8390, _8389, 110);
        }
        else if (IS_ATOM(_8389) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_8390, _8389, 110);
            _8389 = NOVALUE;
        }
        _8389 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8390;
        if( _1 != _8390 ){
            DeRef(_1);
        }
        _8390 = NOVALUE;
        _8387 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8391 = (int)*(((s1_ptr)_2)->base + _i_15414);
        _2 = (int)SEQ_PTR(_8391);
        _8392 = (int)*(((s1_ptr)_2)->base + 4);
        _8391 = NOVALUE;
        _8393 = find_from(42, _8392, 1);
        _8392 = NOVALUE;
        _8394 = (_8393 == 0);
        _8393 = NOVALUE;
        if (_8394 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_15189);
        _8396 = (int)*(((s1_ptr)_2)->base + _i_15414);
        _2 = (int)SEQ_PTR(_8396);
        _8397 = (int)*(((s1_ptr)_2)->base + 4);
        _8396 = NOVALUE;
        _8398 = find_from(49, _8397, 1);
        _8397 = NOVALUE;
        _8399 = (_8398 == 0);
        _8398 = NOVALUE;
        if (_8399 == 0)
        {
            DeRef(_8399);
            _8399 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_8399);
            _8399 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_15189);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15189 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15414 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8402 = (int)*(((s1_ptr)_2)->base + 4);
        _8400 = NOVALUE;
        if (IS_SEQUENCE(_8402) && IS_ATOM(49)) {
            Append(&_8403, _8402, 49);
        }
        else if (IS_ATOM(_8402) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8403, _8402, 49);
            _8402 = NOVALUE;
        }
        _8402 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8403;
        if( _1 != _8403 ){
            DeRef(_1);
        }
        _8403 = NOVALUE;
        _8400 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15189);
        _8404 = (int)*(((s1_ptr)_2)->base + _i_15414);
        _2 = (int)SEQ_PTR(_8404);
        _8405 = (int)*(((s1_ptr)_2)->base + 4);
        _8404 = NOVALUE;
        _8406 = find_from(99, _8405, 1);
        _8405 = NOVALUE;
        _8407 = (_8406 == 0);
        _8406 = NOVALUE;
        if (_8407 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_15189);
        _8409 = (int)*(((s1_ptr)_2)->base + _i_15414);
        _2 = (int)SEQ_PTR(_8409);
        _8410 = (int)*(((s1_ptr)_2)->base + 4);
        _8409 = NOVALUE;
        _8411 = find_from(105, _8410, 1);
        _8410 = NOVALUE;
        _8412 = (_8411 == 0);
        _8411 = NOVALUE;
        if (_8412 == 0)
        {
            DeRef(_8412);
            _8412 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_8412);
            _8412 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_15189);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15189 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15414 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8415 = (int)*(((s1_ptr)_2)->base + 4);
        _8413 = NOVALUE;
        if (IS_SEQUENCE(_8415) && IS_ATOM(105)) {
            Append(&_8416, _8415, 105);
        }
        else if (IS_ATOM(_8415) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8416, _8415, 105);
            _8415 = NOVALUE;
        }
        _8415 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8416;
        if( _1 != _8416 ){
            DeRef(_1);
        }
        _8416 = NOVALUE;
        _8413 = NOVALUE;
L47: 

        /** 	end for*/
        _i_15414 = _i_15414 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _8252 = NOVALUE;
    _8258 = NOVALUE;
    _8278 = NOVALUE;
    _8317 = NOVALUE;
    DeRef(_8332);
    _8332 = NOVALUE;
    DeRef(_8343);
    _8343 = NOVALUE;
    DeRef(_8365);
    _8365 = NOVALUE;
    DeRef(_8394);
    _8394 = NOVALUE;
    DeRef(_8407);
    _8407 = NOVALUE;
    return _opts_15189;
    ;
}


void _40local_help(int _opts_15455, int _add_help_rid_15456, int _cmds_15457, int _std_15459, int _parse_options_15460)
{
    int _pad_size_15461 = NOVALUE;
    int _this_size_15462 = NOVALUE;
    int _cmd_15463 = NOVALUE;
    int _param_name_15464 = NOVALUE;
    int _has_param_15465 = NOVALUE;
    int _is_mandatory_15466 = NOVALUE;
    int _extras_mandatory_15467 = NOVALUE;
    int _extras_opt_15468 = NOVALUE;
    int _auto_help_15469 = NOVALUE;
    int _po_15470 = NOVALUE;
    int _msg_inlined_crash_at_94_15489 = NOVALUE;
    int _8606 = NOVALUE;
    int _8605 = NOVALUE;
    int _8604 = NOVALUE;
    int _8603 = NOVALUE;
    int _8601 = NOVALUE;
    int _8600 = NOVALUE;
    int _8599 = NOVALUE;
    int _8598 = NOVALUE;
    int _8597 = NOVALUE;
    int _8595 = NOVALUE;
    int _8593 = NOVALUE;
    int _8591 = NOVALUE;
    int _8589 = NOVALUE;
    int _8588 = NOVALUE;
    int _8587 = NOVALUE;
    int _8585 = NOVALUE;
    int _8584 = NOVALUE;
    int _8583 = NOVALUE;
    int _8580 = NOVALUE;
    int _8579 = NOVALUE;
    int _8578 = NOVALUE;
    int _8576 = NOVALUE;
    int _8575 = NOVALUE;
    int _8574 = NOVALUE;
    int _8572 = NOVALUE;
    int _8571 = NOVALUE;
    int _8570 = NOVALUE;
    int _8569 = NOVALUE;
    int _8568 = NOVALUE;
    int _8567 = NOVALUE;
    int _8566 = NOVALUE;
    int _8565 = NOVALUE;
    int _8562 = NOVALUE;
    int _8558 = NOVALUE;
    int _8555 = NOVALUE;
    int _8554 = NOVALUE;
    int _8553 = NOVALUE;
    int _8547 = NOVALUE;
    int _8546 = NOVALUE;
    int _8545 = NOVALUE;
    int _8544 = NOVALUE;
    int _8540 = NOVALUE;
    int _8537 = NOVALUE;
    int _8536 = NOVALUE;
    int _8535 = NOVALUE;
    int _8532 = NOVALUE;
    int _8531 = NOVALUE;
    int _8530 = NOVALUE;
    int _8528 = NOVALUE;
    int _8527 = NOVALUE;
    int _8526 = NOVALUE;
    int _8524 = NOVALUE;
    int _8523 = NOVALUE;
    int _8522 = NOVALUE;
    int _8521 = NOVALUE;
    int _8520 = NOVALUE;
    int _8519 = NOVALUE;
    int _8516 = NOVALUE;
    int _8515 = NOVALUE;
    int _8514 = NOVALUE;
    int _8511 = NOVALUE;
    int _8510 = NOVALUE;
    int _8509 = NOVALUE;
    int _8508 = NOVALUE;
    int _8507 = NOVALUE;
    int _8506 = NOVALUE;
    int _8505 = NOVALUE;
    int _8504 = NOVALUE;
    int _8503 = NOVALUE;
    int _8502 = NOVALUE;
    int _8501 = NOVALUE;
    int _8500 = NOVALUE;
    int _8495 = NOVALUE;
    int _8494 = NOVALUE;
    int _8492 = NOVALUE;
    int _8491 = NOVALUE;
    int _8490 = NOVALUE;
    int _8489 = NOVALUE;
    int _8488 = NOVALUE;
    int _8487 = NOVALUE;
    int _8485 = NOVALUE;
    int _8484 = NOVALUE;
    int _8483 = NOVALUE;
    int _8479 = NOVALUE;
    int _8478 = NOVALUE;
    int _8476 = NOVALUE;
    int _8475 = NOVALUE;
    int _8474 = NOVALUE;
    int _8473 = NOVALUE;
    int _8472 = NOVALUE;
    int _8471 = NOVALUE;
    int _8470 = NOVALUE;
    int _8467 = NOVALUE;
    int _8466 = NOVALUE;
    int _8465 = NOVALUE;
    int _8463 = NOVALUE;
    int _8462 = NOVALUE;
    int _8461 = NOVALUE;
    int _8460 = NOVALUE;
    int _8459 = NOVALUE;
    int _8458 = NOVALUE;
    int _8457 = NOVALUE;
    int _8454 = NOVALUE;
    int _8453 = NOVALUE;
    int _8452 = NOVALUE;
    int _8450 = NOVALUE;
    int _8449 = NOVALUE;
    int _8448 = NOVALUE;
    int _8447 = NOVALUE;
    int _8446 = NOVALUE;
    int _8445 = NOVALUE;
    int _8444 = NOVALUE;
    int _8443 = NOVALUE;
    int _8442 = NOVALUE;
    int _8441 = NOVALUE;
    int _8440 = NOVALUE;
    int _8439 = NOVALUE;
    int _8438 = NOVALUE;
    int _8437 = NOVALUE;
    int _8436 = NOVALUE;
    int _8435 = NOVALUE;
    int _8434 = NOVALUE;
    int _8433 = NOVALUE;
    int _8425 = NOVALUE;
    int _8422 = NOVALUE;
    int _8420 = NOVALUE;
    int _8418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_15467 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_15468 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_15469 = 1;

    /** 	integer po = 1*/
    _po_15470 = 1;

    /** 	if atom(parse_options) then*/
    _8418 = IS_ATOM(_parse_options_15460);
    if (_8418 == 0)
    {
        _8418 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8418 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15460;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_15460);
    *((int *)(_2+4)) = _parse_options_15460;
    _parse_options_15460 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15460)){
            _8420 = SEQ_PTR(_parse_options_15460)->length;
    }
    else {
        _8420 = 1;
    }
    if (_po_15470 > _8420)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15460);
    _8422 = (int)*(((s1_ptr)_2)->base + _po_15470);
    if (IS_SEQUENCE(_8422) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8422)){
        if( (DBL_PTR(_8422)->dbl != (double) ((int) DBL_PTR(_8422)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_8422)->dbl;
    }
    else {
        _0 = _8422;
    };
    _8422 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15460)){
                _8425 = SEQ_PTR(_parse_options_15460)->length;
        }
        else {
            _8425 = 1;
        }
        if (_po_15470 >= _8425)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_15470 = _po_15470 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15456);
        _2 = (int)SEQ_PTR(_parse_options_15460);
        _add_help_rid_15456 = (int)*(((s1_ptr)_2)->base + _po_15470);
        Ref(_add_help_rid_15456);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_15489);
        _msg_inlined_crash_at_94_15489 = EPrintf(-9999999, _8429, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_15489);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_15489);
        _msg_inlined_crash_at_94_15489 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15469 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_15470 = _po_15470 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_15459 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15455);
    _0 = _opts_15455;
    _opts_15455 = _40standardize_opts(_opts_15455, _auto_help_15469);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_15461 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15455)){
            _8433 = SEQ_PTR(_opts_15455)->length;
    }
    else {
        _8433 = 1;
    }
    {
        int _i_15497;
        _i_15497 = 1;
L9: 
        if (_i_15497 > _8433){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_15462 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_15464);
        _param_name_15464 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8434 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8434);
        _8435 = (int)*(((s1_ptr)_2)->base + 1);
        _8434 = NOVALUE;
        _8436 = IS_ATOM(_8435);
        _8435 = NOVALUE;
        if (_8436 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_15455);
        _8438 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8438);
        _8439 = (int)*(((s1_ptr)_2)->base + 2);
        _8438 = NOVALUE;
        _8440 = IS_ATOM(_8439);
        _8439 = NOVALUE;
        if (_8440 == 0)
        {
            _8440 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _8440 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_15468 = _i_15497;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8441 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8441);
        _8442 = (int)*(((s1_ptr)_2)->base + 4);
        _8441 = NOVALUE;
        _8443 = find_from(109, _8442, 1);
        _8442 = NOVALUE;
        if (_8443 == 0)
        {
            _8443 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _8443 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_15467 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8444 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8444);
        _8445 = (int)*(((s1_ptr)_2)->base + 1);
        _8444 = NOVALUE;
        _8446 = IS_SEQUENCE(_8445);
        _8445 = NOVALUE;
        if (_8446 == 0)
        {
            _8446 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _8446 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8447 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8447);
        _8448 = (int)*(((s1_ptr)_2)->base + 1);
        _8447 = NOVALUE;
        if (IS_SEQUENCE(_8448)){
                _8449 = SEQ_PTR(_8448)->length;
        }
        else {
            _8449 = 1;
        }
        _8448 = NOVALUE;
        _8450 = _8449 + 1;
        _8449 = NOVALUE;
        _this_size_15462 = _this_size_15462 + _8450;
        _8450 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8452 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8452);
        _8453 = (int)*(((s1_ptr)_2)->base + 4);
        _8452 = NOVALUE;
        _8454 = find_from(109, _8453, 1);
        _8453 = NOVALUE;
        if (_8454 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15462 = _this_size_15462 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8457 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8457);
        _8458 = (int)*(((s1_ptr)_2)->base + 2);
        _8457 = NOVALUE;
        _8459 = IS_SEQUENCE(_8458);
        _8458 = NOVALUE;
        if (_8459 == 0)
        {
            _8459 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _8459 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8460 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8460);
        _8461 = (int)*(((s1_ptr)_2)->base + 2);
        _8460 = NOVALUE;
        if (IS_SEQUENCE(_8461)){
                _8462 = SEQ_PTR(_8461)->length;
        }
        else {
            _8462 = 1;
        }
        _8461 = NOVALUE;
        _8463 = _8462 + 2;
        _8462 = NOVALUE;
        _this_size_15462 = _this_size_15462 + _8463;
        _8463 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8465 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8465);
        _8466 = (int)*(((s1_ptr)_2)->base + 4);
        _8465 = NOVALUE;
        _8467 = find_from(109, _8466, 1);
        _8466 = NOVALUE;
        if (_8467 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15462 = _this_size_15462 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8470 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8470);
        _8471 = (int)*(((s1_ptr)_2)->base + 1);
        _8470 = NOVALUE;
        _8472 = IS_SEQUENCE(_8471);
        _8471 = NOVALUE;
        if (_8472 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_15455);
        _8474 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8474);
        _8475 = (int)*(((s1_ptr)_2)->base + 2);
        _8474 = NOVALUE;
        _8476 = IS_SEQUENCE(_8475);
        _8475 = NOVALUE;
        if (_8476 == 0)
        {
            _8476 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _8476 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_15462 = _this_size_15462 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8478 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8478);
        _8479 = (int)*(((s1_ptr)_2)->base + 4);
        _8478 = NOVALUE;
        _has_param_15465 = find_from(112, _8479, 1);
        _8479 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15465 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_15462 = _this_size_15462 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8483 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8483);
        _8484 = (int)*(((s1_ptr)_2)->base + 4);
        _8483 = NOVALUE;
        if (IS_SEQUENCE(_8484)){
                _8485 = SEQ_PTR(_8484)->length;
        }
        else {
            _8485 = 1;
        }
        _8484 = NOVALUE;
        if (_has_param_15465 >= _8485)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8487 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8487);
        _8488 = (int)*(((s1_ptr)_2)->base + 4);
        _8487 = NOVALUE;
        _2 = (int)SEQ_PTR(_8488);
        _8489 = (int)*(((s1_ptr)_2)->base + _has_param_15465);
        _8488 = NOVALUE;
        _8490 = IS_SEQUENCE(_8489);
        _8489 = NOVALUE;
        if (_8490 == 0)
        {
            _8490 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _8490 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8491 = (int)*(((s1_ptr)_2)->base + _i_15497);
        _2 = (int)SEQ_PTR(_8491);
        _8492 = (int)*(((s1_ptr)_2)->base + 4);
        _8491 = NOVALUE;
        DeRef(_param_name_15464);
        _2 = (int)SEQ_PTR(_8492);
        _param_name_15464 = (int)*(((s1_ptr)_2)->base + _has_param_15465);
        Ref(_param_name_15464);
        _8492 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_8276);
        DeRef(_param_name_15464);
        _param_name_15464 = _8276;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_8276);
        DeRef(_param_name_15464);
        _param_name_15464 = _8276;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_15464)){
                _8494 = SEQ_PTR(_param_name_15464)->length;
        }
        else {
            _8494 = 1;
        }
        _8495 = 2 + _8494;
        _8494 = NOVALUE;
        _this_size_15462 = _this_size_15462 + _8495;
        _8495 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_15461 >= _this_size_15462)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_15461 = _this_size_15462;
L16: 

        /** 	end for*/
LC: 
        _i_15497 = _i_15497 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_15461 = _pad_size_15461 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_15457);
    _8500 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8500);
    *((int *)(_2+4)) = _8500;
    _8501 = MAKE_SEQ(_1);
    _8500 = NOVALUE;
    EPrintf(1, _8499, _8501);
    DeRefDS(_8501);
    _8501 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15455)){
            _8502 = SEQ_PTR(_opts_15455)->length;
    }
    else {
        _8502 = 1;
    }
    {
        int _i_15581;
        _i_15581 = 1;
L17: 
        if (_i_15581 > _8502){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8503 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8503);
        _8504 = (int)*(((s1_ptr)_2)->base + 1);
        _8503 = NOVALUE;
        _8505 = IS_ATOM(_8504);
        _8504 = NOVALUE;
        if (_8505 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_15455);
        _8507 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8507);
        _8508 = (int)*(((s1_ptr)_2)->base + 2);
        _8507 = NOVALUE;
        _8509 = IS_ATOM(_8508);
        _8508 = NOVALUE;
        if (_8509 == 0)
        {
            _8509 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _8509 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8510 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8510);
        _8511 = (int)*(((s1_ptr)_2)->base + 4);
        _8510 = NOVALUE;
        _has_param_15465 = find_from(112, _8511, 1);
        _8511 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15465 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8514 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8514);
        _8515 = (int)*(((s1_ptr)_2)->base + 4);
        _8514 = NOVALUE;
        if (IS_SEQUENCE(_8515)){
                _8516 = SEQ_PTR(_8515)->length;
        }
        else {
            _8516 = 1;
        }
        _8515 = NOVALUE;
        if (_has_param_15465 >= _8516)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_15465 = _has_param_15465 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8519 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8519);
        _8520 = (int)*(((s1_ptr)_2)->base + 4);
        _8519 = NOVALUE;
        _2 = (int)SEQ_PTR(_8520);
        _8521 = (int)*(((s1_ptr)_2)->base + _has_param_15465);
        _8520 = NOVALUE;
        _8522 = IS_SEQUENCE(_8521);
        _8521 = NOVALUE;
        if (_8522 == 0)
        {
            _8522 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _8522 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8523 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8523);
        _8524 = (int)*(((s1_ptr)_2)->base + 4);
        _8523 = NOVALUE;
        DeRef(_param_name_15464);
        _2 = (int)SEQ_PTR(_8524);
        _param_name_15464 = (int)*(((s1_ptr)_2)->base + _has_param_15465);
        Ref(_param_name_15464);
        _8524 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_8276);
        DeRef(_param_name_15464);
        _param_name_15464 = _8276;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_8276);
        DeRef(_param_name_15464);
        _param_name_15464 = _8276;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8526 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8526);
        _8527 = (int)*(((s1_ptr)_2)->base + 4);
        _8526 = NOVALUE;
        _8528 = find_from(109, _8527, 1);
        _8527 = NOVALUE;
        _is_mandatory_15466 = (_8528 != 0);
        _8528 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_15463);
        _cmd_15463 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8530 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8530);
        _8531 = (int)*(((s1_ptr)_2)->base + 1);
        _8530 = NOVALUE;
        _8532 = IS_SEQUENCE(_8531);
        _8531 = NOVALUE;
        if (_8532 == 0)
        {
            _8532 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _8532 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15466 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_15463, _cmd_15463, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8535 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8535);
        _8536 = (int)*(((s1_ptr)_2)->base + 1);
        _8535 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_8536)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_8536)) {
            Prepend(&_8537, _8536, 45);
        }
        else {
            Concat((object_ptr)&_8537, 45, _8536);
        }
        _8536 = NOVALUE;
        Concat((object_ptr)&_cmd_15463, _cmd_15463, _8537);
        DeRefDS(_8537);
        _8537 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15465 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_8540, _param_name_15464, 32);
        Concat((object_ptr)&_cmd_15463, _cmd_15463, _8540);
        DeRefDS(_8540);
        _8540 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15466 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_15463, _cmd_15463, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8544 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8544);
        _8545 = (int)*(((s1_ptr)_2)->base + 2);
        _8544 = NOVALUE;
        _8546 = IS_SEQUENCE(_8545);
        _8545 = NOVALUE;
        if (_8546 == 0)
        {
            _8546 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _8546 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_15463)){
                _8547 = SEQ_PTR(_cmd_15463)->length;
        }
        else {
            _8547 = 1;
        }
        if (_8547 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_15463, _cmd_15463, _8549);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15466 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_15463, _cmd_15463, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8553 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8553);
        _8554 = (int)*(((s1_ptr)_2)->base + 2);
        _8553 = NOVALUE;
        if (IS_SEQUENCE(_7525) && IS_ATOM(_8554)) {
            Ref(_8554);
            Append(&_8555, _7525, _8554);
        }
        else if (IS_ATOM(_7525) && IS_SEQUENCE(_8554)) {
        }
        else {
            Concat((object_ptr)&_8555, _7525, _8554);
        }
        _8554 = NOVALUE;
        Concat((object_ptr)&_cmd_15463, _cmd_15463, _8555);
        DeRefDS(_8555);
        _8555 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15465 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_8558, _param_name_15464, 61);
        Concat((object_ptr)&_cmd_15463, _cmd_15463, _8558);
        DeRefDS(_8558);
        _8558 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15466 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_15463, _cmd_15463, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_15463)){
                _8562 = SEQ_PTR(_cmd_15463)->length;
        }
        else {
            _8562 = 1;
        }
        if (_8562 <= _pad_size_15461)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_15463;
            concat_list[2] = _8564;
            Concat_N((object_ptr)&_8565, concat_list, 3);
        }
        EPuts(1, _8565); // DJP 
        DeRefDS(_8565);
        _8565 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _8566 = _pad_size_15461 + 3;
        _8567 = Repeat(32, _8566);
        _8566 = NOVALUE;
        EPuts(1, _8567); // DJP 
        DeRefDS(_8567);
        _8567 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_15463);
        _8568 = _24pad_tail(_cmd_15463, _pad_size_15461, 32);
        if (IS_SEQUENCE(_8564) && IS_ATOM(_8568)) {
            Ref(_8568);
            Append(&_8569, _8564, _8568);
        }
        else if (IS_ATOM(_8564) && IS_SEQUENCE(_8568)) {
        }
        else {
            Concat((object_ptr)&_8569, _8564, _8568);
        }
        DeRef(_8568);
        _8568 = NOVALUE;
        EPuts(1, _8569); // DJP 
        DeRefDS(_8569);
        _8569 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_15455);
        _8570 = (int)*(((s1_ptr)_2)->base + _i_15581);
        _2 = (int)SEQ_PTR(_8570);
        _8571 = (int)*(((s1_ptr)_2)->base + 3);
        _8570 = NOVALUE;
        if (IS_SEQUENCE(_8571) && IS_ATOM(10)) {
            Append(&_8572, _8571, 10);
        }
        else if (IS_ATOM(_8571) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_8572, _8571, 10);
            _8571 = NOVALUE;
        }
        _8571 = NOVALUE;
        EPuts(1, _8572); // DJP 
        DeRefDS(_8572);
        _8572 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_15581 = _i_15581 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_15467 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15455);
    _8574 = (int)*(((s1_ptr)_2)->base + _extras_opt_15468);
    _2 = (int)SEQ_PTR(_8574);
    _8575 = (int)*(((s1_ptr)_2)->base + 3);
    _8574 = NOVALUE;
    if (IS_SEQUENCE(_8575)){
            _8576 = SEQ_PTR(_8575)->length;
    }
    else {
        _8576 = 1;
    }
    _8575 = NOVALUE;
    if (_8576 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15455);
    _8578 = (int)*(((s1_ptr)_2)->base + _extras_opt_15468);
    _2 = (int)SEQ_PTR(_8578);
    _8579 = (int)*(((s1_ptr)_2)->base + 3);
    _8578 = NOVALUE;
    if (IS_SEQUENCE(_3934) && IS_ATOM(_8579)) {
        Ref(_8579);
        Append(&_8580, _3934, _8579);
    }
    else if (IS_ATOM(_3934) && IS_SEQUENCE(_8579)) {
    }
    else {
        Concat((object_ptr)&_8580, _3934, _8579);
    }
    _8579 = NOVALUE;
    EPuts(1, _8580); // DJP 
    DeRefDS(_8580);
    _8580 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8581); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_15468 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15455);
    _8583 = (int)*(((s1_ptr)_2)->base + _extras_opt_15468);
    _2 = (int)SEQ_PTR(_8583);
    _8584 = (int)*(((s1_ptr)_2)->base + 3);
    _8583 = NOVALUE;
    if (IS_SEQUENCE(_8584)){
            _8585 = SEQ_PTR(_8584)->length;
    }
    else {
        _8585 = 1;
    }
    _8584 = NOVALUE;
    if (_8585 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15455);
    _8587 = (int)*(((s1_ptr)_2)->base + _extras_opt_15468);
    _2 = (int)SEQ_PTR(_8587);
    _8588 = (int)*(((s1_ptr)_2)->base + 3);
    _8587 = NOVALUE;
    if (IS_SEQUENCE(_3934) && IS_ATOM(_8588)) {
        Ref(_8588);
        Append(&_8589, _3934, _8588);
    }
    else if (IS_ATOM(_3934) && IS_SEQUENCE(_8588)) {
    }
    else {
        Concat((object_ptr)&_8589, _3934, _8588);
    }
    _8588 = NOVALUE;
    EPuts(1, _8589); // DJP 
    DeRefDS(_8589);
    _8589 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8590); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _8591 = IS_ATOM(_add_help_rid_15456);
    if (_8591 == 0)
    {
        _8591 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _8591 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_15456, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3934); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_15456].addr;
    (*(int (*)())_0)(
                         );

    /** 			puts(1, "\n")*/
    EPuts(1, _3934); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_15456)){
            _8593 = SEQ_PTR(_add_help_rid_15456)->length;
    }
    else {
        _8593 = 1;
    }
    if (_8593 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _3934); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_15456);
    _8595 = _9t_display(_add_help_rid_15456);
    if (_8595 == 0) {
        DeRef(_8595);
        _8595 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_8595) && DBL_PTR(_8595)->dbl == 0.0){
            DeRef(_8595);
            _8595 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_8595);
        _8595 = NOVALUE;
    }
    DeRef(_8595);
    _8595 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_15456;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_15456);
    *((int *)(_2+4)) = _add_help_rid_15456;
    _add_help_rid_15456 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_15456)){
            _8597 = SEQ_PTR(_add_help_rid_15456)->length;
    }
    else {
        _8597 = 1;
    }
    {
        int _i_15706;
        _i_15706 = 1;
L34: 
        if (_i_15706 > _8597){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_15456);
        _8598 = (int)*(((s1_ptr)_2)->base + _i_15706);
        EPuts(1, _8598); // DJP 
        _8598 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_15456);
        _8599 = (int)*(((s1_ptr)_2)->base + _i_15706);
        if (IS_SEQUENCE(_8599)){
                _8600 = SEQ_PTR(_8599)->length;
        }
        else {
            _8600 = 1;
        }
        _8599 = NOVALUE;
        _8601 = (_8600 == 0);
        _8600 = NOVALUE;
        if (_8601 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_15456);
        _8603 = (int)*(((s1_ptr)_2)->base + _i_15706);
        if (IS_SEQUENCE(_8603)){
                _8604 = SEQ_PTR(_8603)->length;
        }
        else {
            _8604 = 1;
        }
        _2 = (int)SEQ_PTR(_8603);
        _8605 = (int)*(((s1_ptr)_2)->base + _8604);
        _8603 = NOVALUE;
        if (IS_ATOM_INT(_8605)) {
            _8606 = (_8605 != 10);
        }
        else {
            _8606 = binary_op(NOTEQ, _8605, 10);
        }
        _8605 = NOVALUE;
        if (_8606 == 0) {
            DeRef(_8606);
            _8606 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_8606) && DBL_PTR(_8606)->dbl == 0.0){
                DeRef(_8606);
                _8606 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_8606);
            _8606 = NOVALUE;
        }
        DeRef(_8606);
        _8606 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_15706 = _i_15706 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3934); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_15455);
    DeRef(_add_help_rid_15456);
    DeRefDS(_cmds_15457);
    DeRef(_parse_options_15460);
    DeRef(_cmd_15463);
    DeRef(_param_name_15464);
    _8448 = NOVALUE;
    _8461 = NOVALUE;
    _8484 = NOVALUE;
    _8515 = NOVALUE;
    _8575 = NOVALUE;
    _8584 = NOVALUE;
    _8599 = NOVALUE;
    DeRef(_8601);
    _8601 = NOVALUE;
    return;
    ;
}


int _40find_opt(int _opts_15727, int _opt_style_15728, int _cmd_text_15729)
{
    int _opt_name_15730 = NOVALUE;
    int _opt_param_15731 = NOVALUE;
    int _param_found_15732 = NOVALUE;
    int _reversed_15733 = NOVALUE;
    int _8708 = NOVALUE;
    int _8706 = NOVALUE;
    int _8705 = NOVALUE;
    int _8703 = NOVALUE;
    int _8702 = NOVALUE;
    int _8701 = NOVALUE;
    int _8700 = NOVALUE;
    int _8699 = NOVALUE;
    int _8696 = NOVALUE;
    int _8695 = NOVALUE;
    int _8694 = NOVALUE;
    int _8692 = NOVALUE;
    int _8691 = NOVALUE;
    int _8690 = NOVALUE;
    int _8689 = NOVALUE;
    int _8687 = NOVALUE;
    int _8686 = NOVALUE;
    int _8685 = NOVALUE;
    int _8684 = NOVALUE;
    int _8683 = NOVALUE;
    int _8682 = NOVALUE;
    int _8681 = NOVALUE;
    int _8680 = NOVALUE;
    int _8679 = NOVALUE;
    int _8678 = NOVALUE;
    int _8677 = NOVALUE;
    int _8676 = NOVALUE;
    int _8670 = NOVALUE;
    int _8669 = NOVALUE;
    int _8668 = NOVALUE;
    int _8660 = NOVALUE;
    int _8659 = NOVALUE;
    int _8657 = NOVALUE;
    int _8655 = NOVALUE;
    int _8654 = NOVALUE;
    int _8652 = NOVALUE;
    int _8651 = NOVALUE;
    int _8650 = NOVALUE;
    int _8649 = NOVALUE;
    int _8648 = NOVALUE;
    int _8646 = NOVALUE;
    int _8645 = NOVALUE;
    int _8643 = NOVALUE;
    int _8641 = NOVALUE;
    int _8640 = NOVALUE;
    int _8638 = NOVALUE;
    int _8637 = NOVALUE;
    int _8636 = NOVALUE;
    int _8635 = NOVALUE;
    int _8633 = NOVALUE;
    int _8632 = NOVALUE;
    int _8629 = NOVALUE;
    int _8627 = NOVALUE;
    int _8626 = NOVALUE;
    int _8624 = NOVALUE;
    int _8622 = NOVALUE;
    int _8620 = NOVALUE;
    int _8619 = NOVALUE;
    int _8617 = NOVALUE;
    int _8616 = NOVALUE;
    int _8615 = NOVALUE;
    int _8614 = NOVALUE;
    int _8613 = NOVALUE;
    int _8611 = NOVALUE;
    int _8610 = NOVALUE;
    int _8608 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_15732 = 0;

    /** 	integer reversed = 0*/
    _reversed_15733 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8608 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8608 = 1;
    }
    if (_8608 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_15729);
    _8610 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8610)) {
        _8611 = (_8610 == 39);
    }
    else {
        _8611 = binary_op(EQUALS, _8610, 39);
    }
    _8610 = NOVALUE;
    if (IS_ATOM_INT(_8611)) {
        if (_8611 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8611)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_15729);
    _8613 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8613)) {
        _8614 = (_8613 == 34);
    }
    else {
        _8614 = binary_op(EQUALS, _8613, 34);
    }
    _8613 = NOVALUE;
    if (_8614 == 0) {
        DeRef(_8614);
        _8614 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8614) && DBL_PTR(_8614)->dbl == 0.0){
            DeRef(_8614);
            _8614 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8614);
        _8614 = NOVALUE;
    }
    DeRef(_8614);
    _8614 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8615 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8615 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_15729);
    _8616 = (int)*(((s1_ptr)_2)->base + _8615);
    _2 = (int)SEQ_PTR(_cmd_text_15729);
    _8617 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8616, _8617)){
        _8616 = NOVALUE;
        _8617 = NOVALUE;
        goto L4; // [64] 83
    }
    _8616 = NOVALUE;
    _8617 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8619 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8619 = 1;
    }
    _8620 = _8619 - 1;
    _8619 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_15729;
    RHS_Slice(_cmd_text_15729, 2, _8620);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8622 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8622 = 1;
    }
    if (_8622 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_15729);
    _8624 = (int)*(((s1_ptr)_2)->base + 1);
    _8626 = find_from(_8624, _8625, 1);
    _8624 = NOVALUE;
    if (_8626 == 0)
    {
        _8626 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8626 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_15733 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8627 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8627 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_15729;
    RHS_Slice(_cmd_text_15729, 2, _8627);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8629 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8629 = 1;
    }
    if (_8629 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_8631);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _8631;
    _8632 = MAKE_SEQ(_1);
    DeRefDS(_opts_15727);
    DeRefDS(_opt_style_15728);
    DeRef(_cmd_text_15729);
    DeRef(_opt_name_15730);
    DeRef(_opt_param_15731);
    DeRef(_8620);
    _8620 = NOVALUE;
    DeRef(_8611);
    _8611 = NOVALUE;
    return _8632;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8633 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8633 = 1;
    }
    DeRef(_opt_name_15730);
    _opt_name_15730 = Repeat(32, _8633);
    _8633 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_15731);
    _opt_param_15731 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_15729)){
            _8635 = SEQ_PTR(_cmd_text_15729)->length;
    }
    else {
        _8635 = 1;
    }
    {
        int _i_15768;
        _i_15768 = 1;
L8: 
        if (_i_15768 > _8635){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_15729);
        _8636 = (int)*(((s1_ptr)_2)->base + _i_15768);
        _8637 = find_from(_8636, _3162, 1);
        _8636 = NOVALUE;
        if (_8637 == 0)
        {
            _8637 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8637 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _8638 = _i_15768 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_15730;
        RHS_Slice(_opt_name_15730, 1, _8638);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _8640 = _i_15768 + 1;
        if (IS_SEQUENCE(_cmd_text_15729)){
                _8641 = SEQ_PTR(_cmd_text_15729)->length;
        }
        else {
            _8641 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_15731;
        RHS_Slice(_cmd_text_15729, _8640, _8641);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_15731)){
                _8643 = SEQ_PTR(_opt_param_15731)->length;
        }
        else {
            _8643 = 1;
        }
        if (_8643 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_15731);
        _8645 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8645)) {
            _8646 = (_8645 == 39);
        }
        else {
            _8646 = binary_op(EQUALS, _8645, 39);
        }
        _8645 = NOVALUE;
        if (IS_ATOM_INT(_8646)) {
            if (_8646 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8646)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_15731);
        _8648 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8648)) {
            _8649 = (_8648 == 34);
        }
        else {
            _8649 = binary_op(EQUALS, _8648, 34);
        }
        _8648 = NOVALUE;
        if (_8649 == 0) {
            DeRef(_8649);
            _8649 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8649) && DBL_PTR(_8649)->dbl == 0.0){
                DeRef(_8649);
                _8649 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8649);
            _8649 = NOVALUE;
        }
        DeRef(_8649);
        _8649 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_15731)){
                _8650 = SEQ_PTR(_opt_param_15731)->length;
        }
        else {
            _8650 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_15731);
        _8651 = (int)*(((s1_ptr)_2)->base + _8650);
        _2 = (int)SEQ_PTR(_opt_param_15731);
        _8652 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8651, _8652)){
            _8651 = NOVALUE;
            _8652 = NOVALUE;
            goto LE; // [259] 278
        }
        _8651 = NOVALUE;
        _8652 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_15731)){
                _8654 = SEQ_PTR(_opt_param_15731)->length;
        }
        else {
            _8654 = 1;
        }
        _8655 = _8654 - 1;
        _8654 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_15731;
        RHS_Slice(_opt_param_15731, 2, _8655);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_15731)){
                _8657 = SEQ_PTR(_opt_param_15731)->length;
        }
        else {
            _8657 = 1;
        }
        if (_8657 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_15732 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_15729);
        _8659 = (int)*(((s1_ptr)_2)->base + _i_15768);
        Ref(_8659);
        _2 = (int)SEQ_PTR(_opt_name_15730);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_15730 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15768);
        _1 = *(int *)_2;
        *(int *)_2 = _8659;
        if( _1 != _8659 ){
            DeRef(_1);
        }
        _8659 = NOVALUE;
LF: 

        /** 	end for*/
        _i_15768 = _i_15768 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_15732 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_15731);
    _8660 = _18lower(_opt_param_15731);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8661);
    *((int *)(_2+4)) = _8661;
    RefDS(_8662);
    *((int *)(_2+8)) = _8662;
    RefDS(_8663);
    *((int *)(_2+12)) = _8663;
    RefDS(_8664);
    *((int *)(_2+16)) = _8664;
    RefDS(_8665);
    *((int *)(_2+20)) = _8665;
    RefDS(_8666);
    *((int *)(_2+24)) = _8666;
    RefDS(_8667);
    *((int *)(_2+28)) = _8667;
    _8668 = MAKE_SEQ(_1);
    _8669 = find_from(_8660, _8668, 1);
    DeRef(_8660);
    _8660 = NOVALUE;
    DeRefDS(_8668);
    _8668 = NOVALUE;
    if (_8669 == 0)
    {
        _8669 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _8669 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_15731);
    _opt_param_15731 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_15731);
    _8670 = _18lower(_opt_param_15731);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8671);
    *((int *)(_2+4)) = _8671;
    RefDS(_8672);
    *((int *)(_2+8)) = _8672;
    RefDS(_8673);
    *((int *)(_2+12)) = _8673;
    RefDS(_8674);
    *((int *)(_2+16)) = _8674;
    RefDS(_8675);
    *((int *)(_2+20)) = _8675;
    RefDS(_485);
    *((int *)(_2+24)) = _485;
    _8676 = MAKE_SEQ(_1);
    _8677 = find_from(_8670, _8676, 1);
    DeRef(_8670);
    _8670 = NOVALUE;
    DeRefDS(_8676);
    _8676 = NOVALUE;
    if (_8677 == 0)
    {
        _8677 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _8677 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_15731);
    _opt_param_15731 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15727)){
            _8678 = SEQ_PTR(_opts_15727)->length;
    }
    else {
        _8678 = 1;
    }
    {
        int _i_15822;
        _i_15822 = 1;
L14: 
        if (_i_15822 > _8678){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15727);
        _8679 = (int)*(((s1_ptr)_2)->base + _i_15822);
        _2 = (int)SEQ_PTR(_8679);
        _8680 = (int)*(((s1_ptr)_2)->base + 4);
        _8679 = NOVALUE;
        _8681 = find_from(105, _8680, 1);
        _8680 = NOVALUE;
        if (_8681 == 0)
        {
            _8681 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _8681 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_15730);
        _8682 = _18lower(_opt_name_15730);
        _2 = (int)SEQ_PTR(_opts_15727);
        _8683 = (int)*(((s1_ptr)_2)->base + _i_15822);
        _2 = (int)SEQ_PTR(_opt_style_15728);
        _8684 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8683);
        if (!IS_ATOM_INT(_8684)){
            _8685 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8684)->dbl));
        }
        else{
            _8685 = (int)*(((s1_ptr)_2)->base + _8684);
        }
        _8683 = NOVALUE;
        Ref(_8685);
        _8686 = _18lower(_8685);
        _8685 = NOVALUE;
        if (_8682 == _8686)
        _8687 = 1;
        else if (IS_ATOM_INT(_8682) && IS_ATOM_INT(_8686))
        _8687 = 0;
        else
        _8687 = (compare(_8682, _8686) == 0);
        DeRef(_8682);
        _8682 = NOVALUE;
        DeRef(_8686);
        _8686 = NOVALUE;
        if (_8687 != 0)
        goto L17; // [444] 482
        _8687 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_15727);
        _8689 = (int)*(((s1_ptr)_2)->base + _i_15822);
        _2 = (int)SEQ_PTR(_opt_style_15728);
        _8690 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8689);
        if (!IS_ATOM_INT(_8690)){
            _8691 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8690)->dbl));
        }
        else{
            _8691 = (int)*(((s1_ptr)_2)->base + _8690);
        }
        _8689 = NOVALUE;
        if (_opt_name_15730 == _8691)
        _8692 = 1;
        else if (IS_ATOM_INT(_opt_name_15730) && IS_ATOM_INT(_8691))
        _8692 = 0;
        else
        _8692 = (compare(_opt_name_15730, _8691) == 0);
        _8691 = NOVALUE;
        if (_8692 != 0)
        goto L19; // [473] 481
        _8692 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15727);
        _8694 = (int)*(((s1_ptr)_2)->base + _i_15822);
        _2 = (int)SEQ_PTR(_8694);
        _8695 = (int)*(((s1_ptr)_2)->base + 4);
        _8694 = NOVALUE;
        _8696 = find_from(112, _8695, 1);
        _8695 = NOVALUE;
        if (_8696 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_15732 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_8698);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _8698;
        _8699 = MAKE_SEQ(_1);
        DeRefDS(_opts_15727);
        DeRefDS(_opt_style_15728);
        DeRef(_cmd_text_15729);
        DeRef(_opt_name_15730);
        DeRef(_opt_param_15731);
        DeRef(_8620);
        _8620 = NOVALUE;
        DeRef(_8611);
        _8611 = NOVALUE;
        DeRef(_8632);
        _8632 = NOVALUE;
        DeRef(_8638);
        _8638 = NOVALUE;
        DeRef(_8640);
        _8640 = NOVALUE;
        DeRef(_8655);
        _8655 = NOVALUE;
        DeRef(_8646);
        _8646 = NOVALUE;
        _8690 = NOVALUE;
        _8684 = NOVALUE;
        return _8699;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_15732 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15822;
        RefDS(_opt_name_15730);
        *((int *)(_2+8)) = _opt_name_15730;
        *((int *)(_2+12)) = _reversed_15733;
        Ref(_opt_param_15731);
        *((int *)(_2+16)) = _opt_param_15731;
        _8700 = MAKE_SEQ(_1);
        DeRefDS(_opts_15727);
        DeRefDS(_opt_style_15728);
        DeRef(_cmd_text_15729);
        DeRefDS(_opt_name_15730);
        DeRef(_opt_param_15731);
        DeRef(_8620);
        _8620 = NOVALUE;
        DeRef(_8611);
        _8611 = NOVALUE;
        DeRef(_8632);
        _8632 = NOVALUE;
        DeRef(_8638);
        _8638 = NOVALUE;
        DeRef(_8640);
        _8640 = NOVALUE;
        DeRef(_8655);
        _8655 = NOVALUE;
        DeRef(_8646);
        _8646 = NOVALUE;
        DeRef(_8699);
        _8699 = NOVALUE;
        _8690 = NOVALUE;
        _8684 = NOVALUE;
        return _8700;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15727);
        _8701 = (int)*(((s1_ptr)_2)->base + _i_15822);
        _2 = (int)SEQ_PTR(_8701);
        _8702 = (int)*(((s1_ptr)_2)->base + 4);
        _8701 = NOVALUE;
        _8703 = find_from(112, _8702, 1);
        _8702 = NOVALUE;
        if (_8703 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15822;
        RefDS(_opt_name_15730);
        *((int *)(_2+8)) = _opt_name_15730;
        *((int *)(_2+12)) = _reversed_15733;
        *((int *)(_2+16)) = 1;
        _8705 = MAKE_SEQ(_1);
        DeRefDS(_opts_15727);
        DeRefDS(_opt_style_15728);
        DeRef(_cmd_text_15729);
        DeRefDS(_opt_name_15730);
        DeRef(_opt_param_15731);
        DeRef(_8620);
        _8620 = NOVALUE;
        DeRef(_8611);
        _8611 = NOVALUE;
        DeRef(_8632);
        _8632 = NOVALUE;
        DeRef(_8638);
        _8638 = NOVALUE;
        DeRef(_8640);
        _8640 = NOVALUE;
        DeRef(_8655);
        _8655 = NOVALUE;
        DeRef(_8646);
        _8646 = NOVALUE;
        DeRef(_8699);
        _8699 = NOVALUE;
        _8690 = NOVALUE;
        _8684 = NOVALUE;
        DeRef(_8700);
        _8700 = NOVALUE;
        return _8705;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15822;
        RefDS(_opt_name_15730);
        *((int *)(_2+8)) = _opt_name_15730;
        *((int *)(_2+12)) = _reversed_15733;
        _8706 = MAKE_SEQ(_1);
        DeRefDS(_opts_15727);
        DeRefDS(_opt_style_15728);
        DeRef(_cmd_text_15729);
        DeRefDS(_opt_name_15730);
        DeRef(_opt_param_15731);
        DeRef(_8620);
        _8620 = NOVALUE;
        DeRef(_8611);
        _8611 = NOVALUE;
        DeRef(_8632);
        _8632 = NOVALUE;
        DeRef(_8638);
        _8638 = NOVALUE;
        DeRef(_8640);
        _8640 = NOVALUE;
        DeRef(_8655);
        _8655 = NOVALUE;
        DeRef(_8646);
        _8646 = NOVALUE;
        DeRef(_8699);
        _8699 = NOVALUE;
        _8690 = NOVALUE;
        _8684 = NOVALUE;
        DeRef(_8700);
        _8700 = NOVALUE;
        DeRef(_8705);
        _8705 = NOVALUE;
        return _8706;
L1D: 

        /** 	end for*/
L18: 
        _i_15822 = _i_15822 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_8707);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _8707;
    _8708 = MAKE_SEQ(_1);
    DeRefDS(_opts_15727);
    DeRefDS(_opt_style_15728);
    DeRef(_cmd_text_15729);
    DeRef(_opt_name_15730);
    DeRef(_opt_param_15731);
    DeRef(_8620);
    _8620 = NOVALUE;
    DeRef(_8611);
    _8611 = NOVALUE;
    DeRef(_8632);
    _8632 = NOVALUE;
    DeRef(_8638);
    _8638 = NOVALUE;
    DeRef(_8640);
    _8640 = NOVALUE;
    DeRef(_8655);
    _8655 = NOVALUE;
    DeRef(_8646);
    _8646 = NOVALUE;
    DeRef(_8699);
    _8699 = NOVALUE;
    _8690 = NOVALUE;
    _8684 = NOVALUE;
    DeRef(_8700);
    _8700 = NOVALUE;
    DeRef(_8705);
    _8705 = NOVALUE;
    DeRef(_8706);
    _8706 = NOVALUE;
    return _8708;
    ;
}


int _40cmd_parse(int _opts_15865, int _parse_options_15866, int _cmds_15867)
{
    int _arg_idx_15869 = NOVALUE;
    int _opts_done_15870 = NOVALUE;
    int _cmd_15871 = NOVALUE;
    int _param_15872 = NOVALUE;
    int _find_result_15873 = NOVALUE;
    int _type__15874 = NOVALUE;
    int _from__15875 = NOVALUE;
    int _help_opts_15876 = NOVALUE;
    int _call_count_15877 = NOVALUE;
    int _add_help_rid_15878 = NOVALUE;
    int _validation_15879 = NOVALUE;
    int _has_extra_15880 = NOVALUE;
    int _use_at_15881 = NOVALUE;
    int _auto_help_15882 = NOVALUE;
    int _help_on_error_15883 = NOVALUE;
    int _po_15884 = NOVALUE;
    int _msg_inlined_crash_at_107_15902 = NOVALUE;
    int _msg_inlined_crash_at_237_15919 = NOVALUE;
    int _msg_inlined_crash_at_275_15926 = NOVALUE;
    int _fmt_inlined_crash_at_272_15925 = NOVALUE;
    int _parsed_opts_15931 = NOVALUE;
    int _at_cmds_15978 = NOVALUE;
    int _j_15979 = NOVALUE;
    int _cmdex_16064 = NOVALUE;
    int _opt_16128 = NOVALUE;
    int _map_add_operation_16131 = NOVALUE;
    int _pos_16171 = NOVALUE;
    int _ver_pos_16218 = NOVALUE;
    int _msg_inlined_crash_at_2040_16236 = NOVALUE;
    int _fmt_inlined_crash_at_2037_16235 = NOVALUE;
    int _8991 = NOVALUE;
    int _8990 = NOVALUE;
    int _8989 = NOVALUE;
    int _8986 = NOVALUE;
    int _8985 = NOVALUE;
    int _8984 = NOVALUE;
    int _8981 = NOVALUE;
    int _8980 = NOVALUE;
    int _8979 = NOVALUE;
    int _8978 = NOVALUE;
    int _8977 = NOVALUE;
    int _8976 = NOVALUE;
    int _8975 = NOVALUE;
    int _8974 = NOVALUE;
    int _8973 = NOVALUE;
    int _8972 = NOVALUE;
    int _8971 = NOVALUE;
    int _8970 = NOVALUE;
    int _8969 = NOVALUE;
    int _8968 = NOVALUE;
    int _8967 = NOVALUE;
    int _8966 = NOVALUE;
    int _8963 = NOVALUE;
    int _8962 = NOVALUE;
    int _8961 = NOVALUE;
    int _8958 = NOVALUE;
    int _8957 = NOVALUE;
    int _8955 = NOVALUE;
    int _8954 = NOVALUE;
    int _8953 = NOVALUE;
    int _8952 = NOVALUE;
    int _8951 = NOVALUE;
    int _8950 = NOVALUE;
    int _8949 = NOVALUE;
    int _8948 = NOVALUE;
    int _8946 = NOVALUE;
    int _8945 = NOVALUE;
    int _8943 = NOVALUE;
    int _8942 = NOVALUE;
    int _8941 = NOVALUE;
    int _8940 = NOVALUE;
    int _8939 = NOVALUE;
    int _8938 = NOVALUE;
    int _8937 = NOVALUE;
    int _8936 = NOVALUE;
    int _8934 = NOVALUE;
    int _8933 = NOVALUE;
    int _8932 = NOVALUE;
    int _8930 = NOVALUE;
    int _8928 = NOVALUE;
    int _8927 = NOVALUE;
    int _8926 = NOVALUE;
    int _8925 = NOVALUE;
    int _8924 = NOVALUE;
    int _8923 = NOVALUE;
    int _8922 = NOVALUE;
    int _8921 = NOVALUE;
    int _8920 = NOVALUE;
    int _8917 = NOVALUE;
    int _8914 = NOVALUE;
    int _8913 = NOVALUE;
    int _8911 = NOVALUE;
    int _8910 = NOVALUE;
    int _8909 = NOVALUE;
    int _8908 = NOVALUE;
    int _8907 = NOVALUE;
    int _8906 = NOVALUE;
    int _8905 = NOVALUE;
    int _8903 = NOVALUE;
    int _8902 = NOVALUE;
    int _8901 = NOVALUE;
    int _8900 = NOVALUE;
    int _8897 = NOVALUE;
    int _8894 = NOVALUE;
    int _8892 = NOVALUE;
    int _8891 = NOVALUE;
    int _8889 = NOVALUE;
    int _8888 = NOVALUE;
    int _8887 = NOVALUE;
    int _8885 = NOVALUE;
    int _8884 = NOVALUE;
    int _8883 = NOVALUE;
    int _8881 = NOVALUE;
    int _8879 = NOVALUE;
    int _8877 = NOVALUE;
    int _8875 = NOVALUE;
    int _8874 = NOVALUE;
    int _8873 = NOVALUE;
    int _8872 = NOVALUE;
    int _8871 = NOVALUE;
    int _8867 = NOVALUE;
    int _8865 = NOVALUE;
    int _8864 = NOVALUE;
    int _8863 = NOVALUE;
    int _8862 = NOVALUE;
    int _8861 = NOVALUE;
    int _8860 = NOVALUE;
    int _8858 = NOVALUE;
    int _8857 = NOVALUE;
    int _8856 = NOVALUE;
    int _8855 = NOVALUE;
    int _8854 = NOVALUE;
    int _8853 = NOVALUE;
    int _8852 = NOVALUE;
    int _8848 = NOVALUE;
    int _8847 = NOVALUE;
    int _8844 = NOVALUE;
    int _8843 = NOVALUE;
    int _8842 = NOVALUE;
    int _8841 = NOVALUE;
    int _8840 = NOVALUE;
    int _8839 = NOVALUE;
    int _8838 = NOVALUE;
    int _8837 = NOVALUE;
    int _8836 = NOVALUE;
    int _8835 = NOVALUE;
    int _8834 = NOVALUE;
    int _8833 = NOVALUE;
    int _8832 = NOVALUE;
    int _8831 = NOVALUE;
    int _8830 = NOVALUE;
    int _8829 = NOVALUE;
    int _8828 = NOVALUE;
    int _8827 = NOVALUE;
    int _8826 = NOVALUE;
    int _8825 = NOVALUE;
    int _8824 = NOVALUE;
    int _8823 = NOVALUE;
    int _8822 = NOVALUE;
    int _8821 = NOVALUE;
    int _8820 = NOVALUE;
    int _8819 = NOVALUE;
    int _8818 = NOVALUE;
    int _8817 = NOVALUE;
    int _8816 = NOVALUE;
    int _8815 = NOVALUE;
    int _8814 = NOVALUE;
    int _8813 = NOVALUE;
    int _8810 = NOVALUE;
    int _8809 = NOVALUE;
    int _8808 = NOVALUE;
    int _8807 = NOVALUE;
    int _8806 = NOVALUE;
    int _8804 = NOVALUE;
    int _8803 = NOVALUE;
    int _8800 = NOVALUE;
    int _8799 = NOVALUE;
    int _8798 = NOVALUE;
    int _8797 = NOVALUE;
    int _8796 = NOVALUE;
    int _8794 = NOVALUE;
    int _8793 = NOVALUE;
    int _8792 = NOVALUE;
    int _8791 = NOVALUE;
    int _8788 = NOVALUE;
    int _8786 = NOVALUE;
    int _8785 = NOVALUE;
    int _8784 = NOVALUE;
    int _8782 = NOVALUE;
    int _8780 = NOVALUE;
    int _8779 = NOVALUE;
    int _8776 = NOVALUE;
    int _8774 = NOVALUE;
    int _8773 = NOVALUE;
    int _8772 = NOVALUE;
    int _8771 = NOVALUE;
    int _8770 = NOVALUE;
    int _8769 = NOVALUE;
    int _8768 = NOVALUE;
    int _8767 = NOVALUE;
    int _8766 = NOVALUE;
    int _8765 = NOVALUE;
    int _8763 = NOVALUE;
    int _8759 = NOVALUE;
    int _8757 = NOVALUE;
    int _8756 = NOVALUE;
    int _8755 = NOVALUE;
    int _8752 = NOVALUE;
    int _8751 = NOVALUE;
    int _8750 = NOVALUE;
    int _8748 = NOVALUE;
    int _8747 = NOVALUE;
    int _8746 = NOVALUE;
    int _8745 = NOVALUE;
    int _8744 = NOVALUE;
    int _8742 = NOVALUE;
    int _8741 = NOVALUE;
    int _8740 = NOVALUE;
    int _8739 = NOVALUE;
    int _8738 = NOVALUE;
    int _8737 = NOVALUE;
    int _8736 = NOVALUE;
    int _8735 = NOVALUE;
    int _8734 = NOVALUE;
    int _8731 = NOVALUE;
    int _8728 = NOVALUE;
    int _8727 = NOVALUE;
    int _8721 = NOVALUE;
    int _8717 = NOVALUE;
    int _8714 = NOVALUE;
    int _8712 = NOVALUE;
    int _8710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    DeRef(_add_help_rid_15878);
    _add_help_rid_15878 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_15879 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_15880 = 0;

    /** 	integer use_at = 1*/
    _use_at_15881 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_15882 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_15883 = 1;

    /** 	integer po = 1*/
    _po_15884 = 1;

    /** 	if atom(parse_options) then*/
    _8710 = 0;
    if (_8710 == 0)
    {
        _8710 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _8710 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15866;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_parse_options_15866);
    *((int *)(_2+4)) = _parse_options_15866;
    _parse_options_15866 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15866)){
            _8712 = SEQ_PTR(_parse_options_15866)->length;
    }
    else {
        _8712 = 1;
    }
    if (_po_15884 > _8712)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15866);
    _8714 = (int)*(((s1_ptr)_2)->base + _po_15884);
    if (IS_SEQUENCE(_8714) ){
        goto L4; // [73] 261
    }
    if(!IS_ATOM_INT(_8714)){
        if( (DBL_PTR(_8714)->dbl != (double) ((int) DBL_PTR(_8714)->dbl) ) ){
            goto L4; // [73] 261
        }
        _0 = (int) DBL_PTR(_8714)->dbl;
    }
    else {
        _0 = _8714;
    };
    _8714 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15866)){
                _8717 = SEQ_PTR(_parse_options_15866)->length;
        }
        else {
            _8717 = 1;
        }
        if (_po_15884 >= _8717)
        goto L5; // [87] 106

        /** 					po += 1*/
        _po_15884 = _po_15884 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15878);
        _2 = (int)SEQ_PTR(_parse_options_15866);
        _add_help_rid_15878 = (int)*(((s1_ptr)_2)->base + _po_15884);
        Ref(_add_help_rid_15878);
        goto L6; // [103] 297
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_15902);
        _msg_inlined_crash_at_107_15902 = EPrintf(-9999999, _8429, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_15902);

        /** end procedure*/
        goto L7; // [121] 124
L7: 
        DeRefi(_msg_inlined_crash_at_107_15902);
        _msg_inlined_crash_at_107_15902 = NOVALUE;
        goto L6; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15882 = 0;
        goto L6; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_15883 = 0;
        goto L6; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_15879 = 2;
        goto L6; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_15879 = 3;
        goto L6; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_15879 = 4;
        goto L6; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_15881 = 0;
        goto L6; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_15881 = 1;
        goto L6; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15866)){
                _8721 = SEQ_PTR(_parse_options_15866)->length;
        }
        else {
            _8721 = 1;
        }
        if (_po_15884 >= _8721)
        goto L8; // [215] 236

        /** 					po += 1*/
        _po_15884 = _po_15884 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_40pause_msg_15178);
        _2 = (int)SEQ_PTR(_parse_options_15866);
        _40pause_msg_15178 = (int)*(((s1_ptr)_2)->base + _po_15884);
        Ref(_40pause_msg_15178);
        goto L6; // [233] 297
L8: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_15919);
        _msg_inlined_crash_at_237_15919 = EPrintf(-9999999, _8725, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_15919);

        /** end procedure*/
        goto L9; // [251] 254
L9: 
        DeRefi(_msg_inlined_crash_at_237_15919);
        _msg_inlined_crash_at_237_15919 = NOVALUE;
        goto L6; // [257] 297

        /** 			case else*/
        default:
L4: 

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_15866);
        _8727 = (int)*(((s1_ptr)_2)->base + _po_15884);
        _8728 = EPrintf(-9999999, _8726, _8727);
        _8727 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_15925);
        _fmt_inlined_crash_at_272_15925 = _8728;
        _8728 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_15926);
        _msg_inlined_crash_at_275_15926 = EPrintf(-9999999, _fmt_inlined_crash_at_272_15925, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_15926);

        /** end procedure*/
        goto LA; // [291] 294
LA: 
        DeRefi(_fmt_inlined_crash_at_272_15925);
        _fmt_inlined_crash_at_272_15925 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_15926);
        _msg_inlined_crash_at_275_15926 = NOVALUE;
    ;}L6: 

    /** 		po += 1*/
    _po_15884 = _po_15884 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15865);
    _0 = _opts_15865;
    _opts_15865 = _40standardize_opts(_opts_15865, _auto_help_15882);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_15865)){
            _8731 = SEQ_PTR(_opts_15865)->length;
    }
    else {
        _8731 = 1;
    }
    DeRef(_call_count_15877);
    _call_count_15877 = Repeat(0, _8731);
    _8731 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_15931;
    _parsed_opts_15931 = _32new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_15931);
    RefDS(_40EXTRAS_15167);
    RefDS(_5);
    _32put(_parsed_opts_15931, _40EXTRAS_15167, _5, 1, 23);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_15876);
    _help_opts_15876 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15865)){
            _8734 = SEQ_PTR(_opts_15865)->length;
    }
    else {
        _8734 = 1;
    }
    {
        int _i_15934;
        _i_15934 = 1;
LB: 
        if (_i_15934 > _8734){
            goto LC; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8735 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8735);
        _8736 = (int)*(((s1_ptr)_2)->base + 4);
        _8735 = NOVALUE;
        _8737 = find_from(104, _8736, 1);
        _8736 = NOVALUE;
        if (_8737 == 0)
        {
            _8737 = NOVALUE;
            goto LD; // [379] 510
        }
        else{
            _8737 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8738 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8738);
        _8739 = (int)*(((s1_ptr)_2)->base + 1);
        _8738 = NOVALUE;
        _8740 = IS_SEQUENCE(_8739);
        _8739 = NOVALUE;
        if (_8740 == 0)
        {
            _8740 = NOVALUE;
            goto LE; // [395] 413
        }
        else{
            _8740 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8741 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8741);
        _8742 = (int)*(((s1_ptr)_2)->base + 1);
        _8741 = NOVALUE;
        Ref(_8742);
        Append(&_help_opts_15876, _help_opts_15876, _8742);
        _8742 = NOVALUE;
LE: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8744 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8744);
        _8745 = (int)*(((s1_ptr)_2)->base + 2);
        _8744 = NOVALUE;
        _8746 = IS_SEQUENCE(_8745);
        _8745 = NOVALUE;
        if (_8746 == 0)
        {
            _8746 = NOVALUE;
            goto LF; // [426] 444
        }
        else{
            _8746 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8747 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8747);
        _8748 = (int)*(((s1_ptr)_2)->base + 2);
        _8747 = NOVALUE;
        Ref(_8748);
        Append(&_help_opts_15876, _help_opts_15876, _8748);
        _8748 = NOVALUE;
LF: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8750 = (int)*(((s1_ptr)_2)->base + _i_15934);
        _2 = (int)SEQ_PTR(_8750);
        _8751 = (int)*(((s1_ptr)_2)->base + 4);
        _8750 = NOVALUE;
        _8752 = find_from(105, _8751, 1);
        _8751 = NOVALUE;
        if (_8752 == 0)
        {
            _8752 = NOVALUE;
            goto L10; // [459] 509
        }
        else{
            _8752 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_15876);
        _0 = _help_opts_15876;
        _help_opts_15876 = _18lower(_help_opts_15876);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_15876)){
                _arg_idx_15869 = SEQ_PTR(_help_opts_15876)->length;
        }
        else {
            _arg_idx_15869 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _8755 = _arg_idx_15869;
        {
            int _j_15961;
            _j_15961 = 1;
L11: 
            if (_j_15961 > _8755){
                goto L12; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_15876);
            _8756 = (int)*(((s1_ptr)_2)->base + _j_15961);
            Ref(_8756);
            _8757 = _18upper(_8756);
            _8756 = NOVALUE;
            Ref(_8757);
            Append(&_help_opts_15876, _help_opts_15876, _8757);
            DeRef(_8757);
            _8757 = NOVALUE;

            /** 				end for*/
            _j_15961 = _j_15961 + 1;
            goto L11; // [503] 487
L12: 
            ;
        }
L10: 
LD: 

        /** 	end for*/
        _i_15934 = _i_15934 + 1;
        goto LB; // [512] 364
LC: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_15869 = 2;

    /** 	opts_done = 0*/
    _opts_done_15870 = 0;

    /** 	while arg_idx < length(cmds) do*/
L13: 
    if (IS_SEQUENCE(_cmds_15867)){
            _8759 = SEQ_PTR(_cmds_15867)->length;
    }
    else {
        _8759 = 1;
    }
    if (_arg_idx_15869 >= _8759)
    goto L14; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_15869 = _arg_idx_15869 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_15871);
    _2 = (int)SEQ_PTR(_cmds_15867);
    _cmd_15871 = (int)*(((s1_ptr)_2)->base + _arg_idx_15869);
    Ref(_cmd_15871);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8763 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8763 = 1;
    }
    if (_8763 != 0)
    goto L15; // [558] 567

    /** 			continue*/
    goto L13; // [564] 532
L15: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_15871);
    _8765 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8765)) {
        _8766 = (_8765 == 64);
    }
    else {
        _8766 = binary_op(EQUALS, _8765, 64);
    }
    _8765 = NOVALUE;
    if (IS_ATOM_INT(_8766)) {
        if (_8766 == 0) {
            goto L16; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_8766)->dbl == 0.0) {
            goto L16; // [577] 1095
        }
    }
    if (_use_at_15881 == 0)
    {
        goto L16; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8768 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8768 = 1;
    }
    _8769 = (_8768 > 2);
    _8768 = NOVALUE;
    if (_8769 == 0) {
        goto L17; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_15871);
    _8771 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8771)) {
        _8772 = (_8771 == 64);
    }
    else {
        _8772 = binary_op(EQUALS, _8771, 64);
    }
    _8771 = NOVALUE;
    if (_8772 == 0) {
        DeRef(_8772);
        _8772 = NOVALUE;
        goto L17; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_8772) && DBL_PTR(_8772)->dbl == 0.0){
            DeRef(_8772);
            _8772 = NOVALUE;
            goto L17; // [611] 660
        }
        DeRef(_8772);
        _8772 = NOVALUE;
    }
    DeRef(_8772);
    _8772 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8773 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8773 = 1;
    }
    rhs_slice_target = (object_ptr)&_8774;
    RHS_Slice(_cmd_15871, 3, _8773);
    _0 = _at_cmds_15978;
    _at_cmds_15978 = _17read_lines(_8774);
    DeRef(_0);
    _8774 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_15978 == -1)
    _8776 = 1;
    else if (IS_ATOM_INT(_at_cmds_15978) && IS_ATOM_INT(-1))
    _8776 = 0;
    else
    _8776 = (compare(_at_cmds_15978, -1) == 0);
    if (_8776 == 0)
    {
        _8776 = NOVALUE;
        goto L18; // [634] 738
    }
    else{
        _8776 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_15867);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_15869)) ? _arg_idx_15869 : (long)(DBL_PTR(_arg_idx_15869)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_15869)) ? _arg_idx_15869 : (long)(DBL_PTR(_arg_idx_15869)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_15867), start, &_cmds_15867 );
            }
            else Tail(SEQ_PTR(_cmds_15867), stop+1, &_cmds_15867);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_15867), start, &_cmds_15867);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_15867 = Remove_elements(start, stop, (SEQ_PTR(_cmds_15867)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_15869 = _arg_idx_15869 - 1;

    /** 					continue*/
    DeRef(_at_cmds_15978);
    _at_cmds_15978 = NOVALUE;
    goto L13; // [654] 532
    goto L18; // [657] 738
L17: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8779 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8779 = 1;
    }
    rhs_slice_target = (object_ptr)&_8780;
    RHS_Slice(_cmd_15871, 2, _8779);
    _0 = _at_cmds_15978;
    _at_cmds_15978 = _17read_lines(_8780);
    DeRef(_0);
    _8780 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_15978 == -1)
    _8782 = 1;
    else if (IS_ATOM_INT(_at_cmds_15978) && IS_ATOM_INT(-1))
    _8782 = 0;
    else
    _8782 = (compare(_at_cmds_15978, -1) == 0);
    if (_8782 == 0)
    {
        _8782 = NOVALUE;
        goto L19; // [680] 737
    }
    else{
        _8782 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8784 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8784 = 1;
    }
    rhs_slice_target = (object_ptr)&_8785;
    RHS_Slice(_cmd_15871, 2, _8784);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8785;
    _8786 = MAKE_SEQ(_1);
    _8785 = NOVALUE;
    EPrintf(2, _8783, _8786);
    DeRefDS(_8786);
    _8786 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_15883 == 0)
    {
        goto L1A; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15865);
    Ref(_add_help_rid_15878);
    RefDS(_cmds_15867);
    Ref(_parse_options_15866);
    _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
    goto L1B; // [715] 731
L1A: 

    /** 					elsif auto_help then*/
    if (_auto_help_15882 == 0)
    {
        goto L1C; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _8787, _5);
L1C: 
L1B: 

    /** 					local_abort(1)*/
    _40local_abort(1);
L19: 
L18: 

    /** 			j = 0*/
    _j_15979 = 0;

    /** 			while j < length(at_cmds) do*/
L1D: 
    if (IS_SEQUENCE(_at_cmds_15978)){
            _8788 = SEQ_PTR(_at_cmds_15978)->length;
    }
    else {
        _8788 = 1;
    }
    if (_j_15979 >= _8788)
    goto L1E; // [753] 1074

    /** 				j += 1*/
    _j_15979 = _j_15979 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8791 = (int)*(((s1_ptr)_2)->base + _j_15979);
    Ref(_8791);
    RefDS(_2965);
    _8792 = _18trim(_8791, _2965, 0);
    _8791 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_15978 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_15979);
    _1 = *(int *)_2;
    *(int *)_2 = _8792;
    if( _1 != _8792 ){
        DeRef(_1);
    }
    _8792 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8793 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8793)){
            _8794 = SEQ_PTR(_8793)->length;
    }
    else {
        _8794 = 1;
    }
    _8793 = NOVALUE;
    if (_8794 != 0)
    goto L1F; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8796 = _j_15979 - 1;
    rhs_slice_target = (object_ptr)&_8797;
    RHS_Slice(_at_cmds_15978, 1, _8796);
    _8798 = _j_15979 + 1;
    if (_8798 > MAXINT){
        _8798 = NewDouble((double)_8798);
    }
    if (IS_SEQUENCE(_at_cmds_15978)){
            _8799 = SEQ_PTR(_at_cmds_15978)->length;
    }
    else {
        _8799 = 1;
    }
    rhs_slice_target = (object_ptr)&_8800;
    RHS_Slice(_at_cmds_15978, _8798, _8799);
    Concat((object_ptr)&_at_cmds_15978, _8797, _8800);
    DeRefDS(_8797);
    _8797 = NOVALUE;
    DeRef(_8797);
    _8797 = NOVALUE;
    DeRefDS(_8800);
    _8800 = NOVALUE;

    /** 					j -= 1*/
    _j_15979 = _j_15979 - 1;
    goto L1D; // [825] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8803 = (int)*(((s1_ptr)_2)->base + _j_15979);
    _2 = (int)SEQ_PTR(_8803);
    _8804 = (int)*(((s1_ptr)_2)->base + 1);
    _8803 = NOVALUE;
    if (binary_op_a(NOTEQ, _8804, 35)){
        _8804 = NOVALUE;
        goto L20; // [838] 878
    }
    _8804 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8806 = _j_15979 - 1;
    rhs_slice_target = (object_ptr)&_8807;
    RHS_Slice(_at_cmds_15978, 1, _8806);
    _8808 = _j_15979 + 1;
    if (_8808 > MAXINT){
        _8808 = NewDouble((double)_8808);
    }
    if (IS_SEQUENCE(_at_cmds_15978)){
            _8809 = SEQ_PTR(_at_cmds_15978)->length;
    }
    else {
        _8809 = 1;
    }
    rhs_slice_target = (object_ptr)&_8810;
    RHS_Slice(_at_cmds_15978, _8808, _8809);
    Concat((object_ptr)&_at_cmds_15978, _8807, _8810);
    DeRefDS(_8807);
    _8807 = NOVALUE;
    DeRef(_8807);
    _8807 = NOVALUE;
    DeRefDS(_8810);
    _8810 = NOVALUE;

    /** 					j -= 1*/
    _j_15979 = _j_15979 - 1;
    goto L1D; // [875] 748
L20: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8813 = (int)*(((s1_ptr)_2)->base + _j_15979);
    _2 = (int)SEQ_PTR(_8813);
    _8814 = (int)*(((s1_ptr)_2)->base + 1);
    _8813 = NOVALUE;
    if (IS_ATOM_INT(_8814)) {
        _8815 = (_8814 == 34);
    }
    else {
        _8815 = binary_op(EQUALS, _8814, 34);
    }
    _8814 = NOVALUE;
    if (IS_ATOM_INT(_8815)) {
        if (_8815 == 0) {
            DeRef(_8816);
            _8816 = 0;
            goto L21; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_8815)->dbl == 0.0) {
            DeRef(_8816);
            _8816 = 0;
            goto L21; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8817 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8817)){
            _8818 = SEQ_PTR(_8817)->length;
    }
    else {
        _8818 = 1;
    }
    _2 = (int)SEQ_PTR(_8817);
    _8819 = (int)*(((s1_ptr)_2)->base + _8818);
    _8817 = NOVALUE;
    if (IS_ATOM_INT(_8819)) {
        _8820 = (_8819 == 34);
    }
    else {
        _8820 = binary_op(EQUALS, _8819, 34);
    }
    _8819 = NOVALUE;
    DeRef(_8816);
    if (IS_ATOM_INT(_8820))
    _8816 = (_8820 != 0);
    else
    _8816 = DBL_PTR(_8820)->dbl != 0.0;
L21: 
    if (_8816 == 0) {
        goto L22; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8822 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8822)){
            _8823 = SEQ_PTR(_8822)->length;
    }
    else {
        _8823 = 1;
    }
    _8822 = NOVALUE;
    _8824 = (_8823 >= 2);
    _8823 = NOVALUE;
    if (_8824 == 0)
    {
        DeRef(_8824);
        _8824 = NOVALUE;
        goto L22; // [931] 959
    }
    else{
        DeRef(_8824);
        _8824 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8825 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8825)){
            _8826 = SEQ_PTR(_8825)->length;
    }
    else {
        _8826 = 1;
    }
    _8827 = _8826 - 1;
    _8826 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8828;
    RHS_Slice(_8825, 2, _8827);
    _8825 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_15978 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_15979);
    _1 = *(int *)_2;
    *(int *)_2 = _8828;
    if( _1 != _8828 ){
        DeRef(_1);
    }
    _8828 = NOVALUE;
    goto L1D; // [956] 748
L22: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8829 = (int)*(((s1_ptr)_2)->base + _j_15979);
    _2 = (int)SEQ_PTR(_8829);
    _8830 = (int)*(((s1_ptr)_2)->base + 1);
    _8829 = NOVALUE;
    if (IS_ATOM_INT(_8830)) {
        _8831 = (_8830 == 39);
    }
    else {
        _8831 = binary_op(EQUALS, _8830, 39);
    }
    _8830 = NOVALUE;
    if (IS_ATOM_INT(_8831)) {
        if (_8831 == 0) {
            DeRef(_8832);
            _8832 = 0;
            goto L23; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_8831)->dbl == 0.0) {
            DeRef(_8832);
            _8832 = 0;
            goto L23; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8833 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8833)){
            _8834 = SEQ_PTR(_8833)->length;
    }
    else {
        _8834 = 1;
    }
    _2 = (int)SEQ_PTR(_8833);
    _8835 = (int)*(((s1_ptr)_2)->base + _8834);
    _8833 = NOVALUE;
    if (IS_ATOM_INT(_8835)) {
        _8836 = (_8835 == 39);
    }
    else {
        _8836 = binary_op(EQUALS, _8835, 39);
    }
    _8835 = NOVALUE;
    DeRef(_8832);
    if (IS_ATOM_INT(_8836))
    _8832 = (_8836 != 0);
    else
    _8832 = DBL_PTR(_8836)->dbl != 0.0;
L23: 
    if (_8832 == 0) {
        goto L24; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8838 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8838)){
            _8839 = SEQ_PTR(_8838)->length;
    }
    else {
        _8839 = 1;
    }
    _8838 = NOVALUE;
    _8840 = (_8839 >= 2);
    _8839 = NOVALUE;
    if (_8840 == 0)
    {
        DeRef(_8840);
        _8840 = NOVALUE;
        goto L24; // [1012] 1066
    }
    else{
        DeRef(_8840);
        _8840 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_15978);
    _8841 = (int)*(((s1_ptr)_2)->base + _j_15979);
    if (IS_SEQUENCE(_8841)){
            _8842 = SEQ_PTR(_8841)->length;
    }
    else {
        _8842 = 1;
    }
    _8843 = _8842 - 1;
    _8842 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8844;
    RHS_Slice(_8841, 2, _8843);
    _8841 = NOVALUE;
    _0 = _cmdex_16064;
    _cmdex_16064 = _24split(_8844, 32, 1, 0);
    DeRef(_0);
    _8844 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_15978;
        int p2 = _cmdex_16064;
        int p3 = _j_15979;
        int p4 = _j_15979;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_15978;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_16064)){
            _8847 = SEQ_PTR(_cmdex_16064)->length;
    }
    else {
        _8847 = 1;
    }
    _8848 = _j_15979 + _8847;
    if ((long)((unsigned long)_8848 + (unsigned long)HIGH_BITS) >= 0) 
    _8848 = NewDouble((double)_8848);
    _8847 = NOVALUE;
    if (IS_ATOM_INT(_8848)) {
        _j_15979 = _8848 - 1;
    }
    else {
        _j_15979 = NewDouble(DBL_PTR(_8848)->dbl - (double)1);
    }
    DeRef(_8848);
    _8848 = NOVALUE;
    if (!IS_ATOM_INT(_j_15979)) {
        _1 = (long)(DBL_PTR(_j_15979)->dbl);
        DeRefDS(_j_15979);
        _j_15979 = _1;
    }
L24: 
    DeRef(_cmdex_16064);
    _cmdex_16064 = NOVALUE;

    /** 			end while*/
    goto L1D; // [1071] 748
L1E: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_15867;
        int p2 = _at_cmds_15978;
        int p3 = _arg_idx_15869;
        int p4 = _arg_idx_15869;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_15867;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_15869 = _arg_idx_15869 - 1;

    /** 			continue*/
    DeRef(_at_cmds_15978);
    _at_cmds_15978 = NOVALUE;
    goto L13; // [1092] 532
L16: 
    DeRef(_at_cmds_15978);
    _at_cmds_15978 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_15870 != 0) {
        _8852 = 1;
        goto L25; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_15871);
    _8853 = (int)*(((s1_ptr)_2)->base + 1);
    _8854 = find_from(_8853, _3CMD_SWITCHES_1251, 1);
    _8853 = NOVALUE;
    _8855 = (_8854 == 0);
    _8854 = NOVALUE;
    _8852 = (_8855 != 0);
L25: 
    if (_8852 != 0) {
        DeRef(_8856);
        _8856 = 1;
        goto L26; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_15871)){
            _8857 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8857 = 1;
    }
    _8858 = (_8857 == 1);
    _8857 = NOVALUE;
    _8856 = (_8858 != 0);
L26: 
    if (_8856 == 0)
    {
        _8856 = NOVALUE;
        goto L27; // [1135] 1215
    }
    else{
        _8856 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_15931);
    RefDS(_40EXTRAS_15167);
    RefDS(_cmd_15871);
    _32put(_parsed_opts_15931, _40EXTRAS_15167, _cmd_15871, 6, 23);

    /** 			has_extra = 1*/
    _has_extra_15880 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_15879 != 4)
    goto L13; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _8860 = _arg_idx_15869 + 1;
    if (_8860 > MAXINT){
        _8860 = NewDouble((double)_8860);
    }
    if (IS_SEQUENCE(_cmds_15867)){
            _8861 = SEQ_PTR(_cmds_15867)->length;
    }
    else {
        _8861 = 1;
    }
    {
        int _i_16087;
        Ref(_8860);
        _i_16087 = _8860;
L28: 
        if (binary_op_a(GREATER, _i_16087, _8861)){
            goto L29; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_15867);
        if (!IS_ATOM_INT(_i_16087)){
            _8862 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_16087)->dbl));
        }
        else{
            _8862 = (int)*(((s1_ptr)_2)->base + _i_16087);
        }
        Ref(_parsed_opts_15931);
        RefDS(_40EXTRAS_15167);
        Ref(_8862);
        _32put(_parsed_opts_15931, _40EXTRAS_15167, _8862, 6, 23);
        _8862 = NOVALUE;

        /** 				end for*/
        _0 = _i_16087;
        if (IS_ATOM_INT(_i_16087)) {
            _i_16087 = _i_16087 + 1;
            if ((long)((unsigned long)_i_16087 +(unsigned long) HIGH_BITS) >= 0){
                _i_16087 = NewDouble((double)_i_16087);
            }
        }
        else {
            _i_16087 = binary_op_a(PLUS, _i_16087, 1);
        }
        DeRef(_0);
        goto L28; // [1197] 1178
L29: 
        ;
        DeRef(_i_16087);
    }

    /** 				exit*/
    goto L14; // [1204] 2072
    goto L2A; // [1206] 1214

    /** 				continue*/
    goto L13; // [1211] 532
L2A: 
L27: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_15871 == _7525)
    _8863 = 1;
    else if (IS_ATOM_INT(_cmd_15871) && IS_ATOM_INT(_7525))
    _8863 = 0;
    else
    _8863 = (compare(_cmd_15871, _7525) == 0);
    if (_8863 == 0)
    {
        _8863 = NOVALUE;
        goto L2B; // [1221] 1234
    }
    else{
        _8863 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_15870 = 1;

    /** 			continue*/
    goto L13; // [1231] 532
L2B: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_8864;
    RHS_Slice(_cmd_15871, 1, 2);
    if (_8864 == _7525)
    _8865 = 1;
    else if (IS_ATOM_INT(_8864) && IS_ATOM_INT(_7525))
    _8865 = 0;
    else
    _8865 = (compare(_8864, _7525) == 0);
    DeRefDS(_8864);
    _8864 = NOVALUE;
    if (_8865 == 0)
    {
        _8865 = NOVALUE;
        goto L2C; // [1245] 1262
    }
    else{
        _8865 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_7525);
    DeRef(_type__15874);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _7525;
    _type__15874 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__15875 = 3;
    goto L2D; // [1259] 1298
L2C: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_15871);
    _8867 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8867, 45)){
        _8867 = NOVALUE;
        goto L2E; // [1268] 1286
    }
    _8867 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_485);
    DeRef(_type__15874);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _485;
    _type__15874 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__15875 = 2;
    goto L2D; // [1283] 1298
L2E: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_5008);
    DeRef(_type__15874);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _5008;
    _type__15874 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__15875 = 2;
L2D: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8871 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8871 = 1;
    }
    rhs_slice_target = (object_ptr)&_8872;
    RHS_Slice(_cmd_15871, _from__15875, _8871);
    _8873 = find_from(_8872, _help_opts_15876, 1);
    DeRefDS(_8872);
    _8872 = NOVALUE;
    if (_8873 == 0)
    {
        _8873 = NOVALUE;
        goto L2F; // [1315] 1335
    }
    else{
        _8873 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15865);
    Ref(_add_help_rid_15878);
    RefDS(_cmds_15867);
    Ref(_parse_options_15866);
    _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _40local_abort(0);
L2F: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_15871)){
            _8874 = SEQ_PTR(_cmd_15871)->length;
    }
    else {
        _8874 = 1;
    }
    rhs_slice_target = (object_ptr)&_8875;
    RHS_Slice(_cmd_15871, _from__15875, _8874);
    RefDS(_opts_15865);
    RefDS(_type__15874);
    _0 = _find_result_15873;
    _find_result_15873 = _40find_opt(_opts_15865, _type__15874, _8875);
    DeRef(_0);
    _8875 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8877 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _8877, 0)){
        _8877 = NOVALUE;
        goto L30; // [1361] 1370
    }
    _8877 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L13; // [1367] 532
L30: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8879 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8879, 0)){
        _8879 = NOVALUE;
        goto L31; // [1376] 1471
    }
    _8879 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _8881 = (_validation_15879 == 2);
    if (_8881 != 0) {
        goto L32; // [1386] 1411
    }
    _8883 = (_validation_15879 == 4);
    if (_8883 == 0) {
        DeRef(_8884);
        _8884 = 0;
        goto L33; // [1394] 1406
    }
    _8885 = (_has_extra_15880 == 0);
    _8884 = (_8885 != 0);
L33: 
    if (_8884 == 0)
    {
        _8884 = NOVALUE;
        goto L13; // [1407] 532
    }
    else{
        _8884 = NOVALUE;
    }
L32: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8887 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8887);
    RefDS(_cmd_15871);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_15871;
    ((int *)_2)[2] = _8887;
    _8888 = MAKE_SEQ(_1);
    _8887 = NOVALUE;
    EPrintf(1, _8886, _8888);
    DeRefDS(_8888);
    _8888 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_15883 == 0)
    {
        goto L34; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15865);
    Ref(_add_help_rid_15878);
    RefDS(_cmds_15867);
    Ref(_parse_options_15866);
    _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
    goto L35; // [1444] 1460
L34: 

    /** 				elsif auto_help then*/
    if (_auto_help_15882 == 0)
    {
        goto L36; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _8787, _5);
L36: 
L35: 

    /** 				local_abort(1)*/
    _40local_abort(1);

    /** 			continue*/
    goto L13; // [1468] 532
L31: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8889 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_16128);
    _2 = (int)SEQ_PTR(_opts_15865);
    if (!IS_ATOM_INT(_8889)){
        _opt_16128 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8889)->dbl));
    }
    else{
        _opt_16128 = (int)*(((s1_ptr)_2)->base + _8889);
    }
    Ref(_opt_16128);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_16131 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8891 = (int)*(((s1_ptr)_2)->base + 4);
    _8892 = find_from(112, _8891, 1);
    _8891 = NOVALUE;
    if (_8892 == 0)
    goto L37; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_16131 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_15873)){
            _8894 = SEQ_PTR(_find_result_15873)->length;
    }
    else {
        _8894 = 1;
    }
    if (_8894 >= 4)
    goto L38; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_15869 = _arg_idx_15869 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_15867)){
            _8897 = SEQ_PTR(_cmds_15867)->length;
    }
    else {
        _8897 = 1;
    }
    if (_arg_idx_15869 > _8897)
    goto L39; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_15872);
    _2 = (int)SEQ_PTR(_cmds_15867);
    _param_15872 = (int)*(((s1_ptr)_2)->base + _arg_idx_15869);
    Ref(_param_15872);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_15872)){
            _8900 = SEQ_PTR(_param_15872)->length;
    }
    else {
        _8900 = 1;
    }
    _8901 = (_8900 == 2);
    _8900 = NOVALUE;
    if (_8901 == 0) {
        goto L3A; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_15872);
    _8903 = (int)*(((s1_ptr)_2)->base + 1);
    _8905 = find_from(_8903, _8904, 1);
    _8903 = NOVALUE;
    if (_8905 == 0)
    {
        _8905 = NOVALUE;
        goto L3A; // [1561] 1579
    }
    else{
        _8905 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_15872);
    _param_15872 = _5;
    goto L3A; // [1570] 1579
L39: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_15872);
    _param_15872 = _5;
L3A: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_15872)){
            _8906 = SEQ_PTR(_param_15872)->length;
    }
    else {
        _8906 = 1;
    }
    _8907 = (_8906 == 0);
    _8906 = NOVALUE;
    if (_8907 == 0) {
        goto L3B; // [1590] 1684
    }
    _8909 = (_validation_15879 == 2);
    if (_8909 != 0) {
        DeRef(_8910);
        _8910 = 1;
        goto L3C; // [1598] 1610
    }
    _8911 = (_validation_15879 == 4);
    _8910 = (_8911 != 0);
L3C: 
    if (_8910 == 0)
    {
        _8910 = NOVALUE;
        goto L3B; // [1611] 1684
    }
    else{
        _8910 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8913 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8913);
    *((int *)(_2+4)) = _8913;
    _8914 = MAKE_SEQ(_1);
    _8913 = NOVALUE;
    EPrintf(1, _8912, _8914);
    DeRefDS(_8914);
    _8914 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_15883 == 0)
    {
        goto L3D; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15865);
    Ref(_add_help_rid_15878);
    RefDS(_cmds_15867);
    Ref(_parse_options_15866);
    _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
    goto L3E; // [1642] 1658
L3D: 

    /** 					elsif auto_help then*/
    if (_auto_help_15882 == 0)
    {
        goto L3F; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8787, _5);
L3F: 
L3E: 

    /** 					local_abort(1)*/
    _40local_abort(1);
    goto L3B; // [1664] 1684
L38: 

    /** 				param = find_result[4]*/
    DeRef(_param_15872);
    _2 = (int)SEQ_PTR(_find_result_15873);
    _param_15872 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15872);
    goto L3B; // [1674] 1684
L37: 

    /** 			param = find_result[4]*/
    DeRef(_param_15872);
    _2 = (int)SEQ_PTR(_find_result_15873);
    _param_15872 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15872);
L3B: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8917 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _8917, 0)){
        _8917 = NOVALUE;
        goto L40; // [1690] 1763
    }
    _8917 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _pos_16171 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_16171))
    _pos_16171 = (long)DBL_PTR(_pos_16171)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_15877);
    _8920 = (int)*(((s1_ptr)_2)->base + _pos_16171);
    if (IS_ATOM_INT(_8920)) {
        _8921 = _8920 + 1;
        if (_8921 > MAXINT){
            _8921 = NewDouble((double)_8921);
        }
    }
    else
    _8921 = binary_op(PLUS, 1, _8920);
    _8920 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_15877);
    _2 = (int)(((s1_ptr)_2)->base + _pos_16171);
    _1 = *(int *)_2;
    *(int *)_2 = _8921;
    if( _1 != _8921 ){
        DeRef(_1);
    }
    _8921 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8922 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8923 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_15877);
    _8924 = (int)*(((s1_ptr)_2)->base + _pos_16171);
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8925 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8923);
    *((int *)(_2+4)) = _8923;
    Ref(_8924);
    *((int *)(_2+8)) = _8924;
    Ref(_param_15872);
    *((int *)(_2+12)) = _param_15872;
    Ref(_8925);
    *((int *)(_2+16)) = _8925;
    _8926 = MAKE_SEQ(_1);
    _8925 = NOVALUE;
    _8924 = NOVALUE;
    _8923 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8926;
    _8927 = MAKE_SEQ(_1);
    _8926 = NOVALUE;
    _1 = (int)SEQ_PTR(_8927);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_8922].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_8928);
    _8928 = _1;
    DeRefDS(_8927);
    _8927 = NOVALUE;
    if (binary_op_a(NOTEQ, _8928, 0)){
        DeRef(_8928);
        _8928 = NOVALUE;
        goto L41; // [1749] 1762
    }
    DeRef(_8928);
    _8928 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_16128);
    _opt_16128 = NOVALUE;
    goto L13; // [1759] 532
L41: 
L40: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8930 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _8930, 1)){
        _8930 = NOVALUE;
        goto L42; // [1771] 1788
    }
    _8930 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8932 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15931);
    Ref(_8932);
    _32remove(_parsed_opts_15931, _8932);
    _8932 = NOVALUE;
    goto L43; // [1785] 1965
L42: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8933 = (int)*(((s1_ptr)_2)->base + 4);
    _8934 = find_from(42, _8933, 1);
    _8933 = NOVALUE;
    if (_8934 != 0)
    goto L44; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8936 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15931);
    Ref(_8936);
    _8937 = _32has(_parsed_opts_15931, _8936);
    _8936 = NOVALUE;
    if (IS_ATOM_INT(_8937)) {
        if (_8937 == 0) {
            goto L45; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_8937)->dbl == 0.0) {
            goto L45; // [1814] 1925
        }
    }
    _8939 = (_validation_15879 == 2);
    if (_8939 != 0) {
        DeRef(_8940);
        _8940 = 1;
        goto L46; // [1822] 1834
    }
    _8941 = (_validation_15879 == 4);
    _8940 = (_8941 != 0);
L46: 
    if (_8940 == 0)
    {
        _8940 = NOVALUE;
        goto L45; // [1835] 1925
    }
    else{
        _8940 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8942 = (int)*(((s1_ptr)_2)->base + 4);
    _8943 = find_from(112, _8942, 1);
    _8942 = NOVALUE;
    if (_8943 != 0) {
        goto L47; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_16128);
    _8945 = (int)*(((s1_ptr)_2)->base + 4);
    _8946 = find_from(49, _8945, 1);
    _8945 = NOVALUE;
    if (_8946 == 0)
    {
        _8946 = NOVALUE;
        goto L48; // [1863] 1964
    }
    else{
        _8946 = NOVALUE;
    }
L47: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15873);
    _8948 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8948);
    *((int *)(_2+4)) = _8948;
    _8949 = MAKE_SEQ(_1);
    _8948 = NOVALUE;
    EPrintf(1, _8947, _8949);
    DeRefDS(_8949);
    _8949 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_15883 == 0)
    {
        goto L49; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15865);
    Ref(_add_help_rid_15878);
    RefDS(_cmds_15867);
    Ref(_parse_options_15866);
    _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
    goto L4A; // [1900] 1916
L49: 

    /** 						elsif auto_help then*/
    if (_auto_help_15882 == 0)
    {
        goto L4B; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8787, _5);
L4B: 
L4A: 

    /** 						local_abort(1)*/
    _40local_abort(1);
    goto L48; // [1922] 1964
L45: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8950 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15931);
    Ref(_8950);
    Ref(_param_15872);
    _32put(_parsed_opts_15931, _8950, _param_15872, 1, 23);
    _8950 = NOVALUE;
    goto L48; // [1943] 1964
L44: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8951 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15931);
    Ref(_8951);
    Ref(_param_15872);
    _32put(_parsed_opts_15931, _8951, _param_15872, _map_add_operation_16131, 23);
    _8951 = NOVALUE;
L48: 
L43: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8952 = (int)*(((s1_ptr)_2)->base + 4);
    _8953 = find_from(118, _8952, 1);
    _8952 = NOVALUE;
    if (_8953 == 0)
    {
        _8953 = NOVALUE;
        goto L4C; // [1976] 2063
    }
    else{
        _8953 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8954 = (int)*(((s1_ptr)_2)->base + 4);
    _8955 = find_from(118, _8954, 1);
    _8954 = NOVALUE;
    _ver_pos_16218 = _8955 + 1;
    _8955 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8957 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_8957)){
            _8958 = SEQ_PTR(_8957)->length;
    }
    else {
        _8958 = 1;
    }
    _8957 = NOVALUE;
    if (_8958 < _ver_pos_16218)
    goto L4D; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_16128);
    _8961 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_8961);
    _8962 = (int)*(((s1_ptr)_2)->base + _ver_pos_16218);
    _8961 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8962);
    *((int *)(_2+4)) = _8962;
    _8963 = MAKE_SEQ(_1);
    _8962 = NOVALUE;
    EPrintf(1, _8960, _8963);
    DeRefDS(_8963);
    _8963 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4E; // [2029] 2062
L4D: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_8966, _8964, _8965);
    DeRefi(_fmt_inlined_crash_at_2037_16235);
    _fmt_inlined_crash_at_2037_16235 = _8966;
    _8966 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_16236);
    _msg_inlined_crash_at_2040_16236 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_16235, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_16236);

    /** end procedure*/
    goto L4F; // [2056] 2059
L4F: 
    DeRefi(_fmt_inlined_crash_at_2037_16235);
    _fmt_inlined_crash_at_2037_16235 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_16236);
    _msg_inlined_crash_at_2040_16236 = NOVALUE;
L4E: 
L4C: 
    DeRef(_opt_16128);
    _opt_16128 = NOVALUE;

    /** 	end while*/
    goto L13; // [2069] 532
L14: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15865)){
            _8967 = SEQ_PTR(_opts_15865)->length;
    }
    else {
        _8967 = 1;
    }
    {
        int _i_16238;
        _i_16238 = 1;
L50: 
        if (_i_16238 > _8967){
            goto L51; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8968 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8968);
        _8969 = (int)*(((s1_ptr)_2)->base + 4);
        _8968 = NOVALUE;
        _8970 = find_from(109, _8969, 1);
        _8969 = NOVALUE;
        if (_8970 == 0)
        {
            _8970 = NOVALUE;
            goto L52; // [2099] 2285
        }
        else{
            _8970 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8971 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8971);
        _8972 = (int)*(((s1_ptr)_2)->base + 1);
        _8971 = NOVALUE;
        _8973 = IS_ATOM(_8972);
        _8972 = NOVALUE;
        if (_8973 == 0) {
            goto L53; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_15865);
        _8975 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8975);
        _8976 = (int)*(((s1_ptr)_2)->base + 2);
        _8975 = NOVALUE;
        _8977 = IS_ATOM(_8976);
        _8976 = NOVALUE;
        if (_8977 == 0)
        {
            _8977 = NOVALUE;
            goto L53; // [2131] 2206
        }
        else{
            _8977 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8978 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8978);
        _8979 = (int)*(((s1_ptr)_2)->base + 6);
        _8978 = NOVALUE;
        Ref(_parsed_opts_15931);
        Ref(_8979);
        _8980 = _32get(_parsed_opts_15931, _8979, 0);
        _8979 = NOVALUE;
        if (IS_SEQUENCE(_8980)){
                _8981 = SEQ_PTR(_8980)->length;
        }
        else {
            _8981 = 1;
        }
        DeRef(_8980);
        _8980 = NOVALUE;
        if (_8981 != 0)
        goto L54; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _8983); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_15883 == 0)
        {
            goto L55; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15865);
        Ref(_add_help_rid_15878);
        RefDS(_cmds_15867);
        Ref(_parse_options_15866);
        _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
        goto L56; // [2181] 2197
L55: 

        /** 					elsif auto_help then*/
        if (_auto_help_15882 == 0)
        {
            goto L57; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8787, _5);
L57: 
L56: 

        /** 					local_abort(1)*/
        _40local_abort(1);
        goto L54; // [2203] 2284
L53: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8984 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8984);
        _8985 = (int)*(((s1_ptr)_2)->base + 6);
        _8984 = NOVALUE;
        Ref(_parsed_opts_15931);
        Ref(_8985);
        _8986 = _32has(_parsed_opts_15931, _8985);
        _8985 = NOVALUE;
        if (IS_ATOM_INT(_8986)) {
            if (_8986 != 0){
                DeRef(_8986);
                _8986 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_8986)->dbl != 0.0){
                DeRef(_8986);
                _8986 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        DeRef(_8986);
        _8986 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_15865);
        _8989 = (int)*(((s1_ptr)_2)->base + _i_16238);
        _2 = (int)SEQ_PTR(_8989);
        _8990 = (int)*(((s1_ptr)_2)->base + 6);
        _8989 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_8990);
        *((int *)(_2+4)) = _8990;
        _8991 = MAKE_SEQ(_1);
        _8990 = NOVALUE;
        EPrintf(1, _8988, _8991);
        DeRefDS(_8991);
        _8991 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_15883 == 0)
        {
            goto L59; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15865);
        Ref(_add_help_rid_15878);
        RefDS(_cmds_15867);
        Ref(_parse_options_15866);
        _40local_help(_opts_15865, _add_help_rid_15878, _cmds_15867, 1, _parse_options_15866);
        goto L5A; // [2261] 2277
L59: 

        /** 					elsif auto_help then*/
        if (_auto_help_15882 == 0)
        {
            goto L5B; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8787, _5);
L5B: 
L5A: 

        /** 					local_abort(1)*/
        _40local_abort(1);
L58: 
L54: 
L52: 

        /** 	end for*/
        _i_16238 = _i_16238 + 1;
        goto L50; // [2287] 2084
L51: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_15865);
    DeRef(_parse_options_15866);
    DeRefDS(_cmds_15867);
    DeRef(_cmd_15871);
    DeRef(_param_15872);
    DeRef(_find_result_15873);
    DeRef(_type__15874);
    DeRef(_help_opts_15876);
    DeRef(_call_count_15877);
    DeRef(_add_help_rid_15878);
    DeRef(_8911);
    _8911 = NOVALUE;
    DeRef(_8796);
    _8796 = NOVALUE;
    DeRef(_8843);
    _8843 = NOVALUE;
    DeRef(_8907);
    _8907 = NOVALUE;
    DeRef(_8909);
    _8909 = NOVALUE;
    DeRef(_8798);
    _8798 = NOVALUE;
    _8889 = NOVALUE;
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8901);
    _8901 = NOVALUE;
    _8922 = NOVALUE;
    DeRef(_8885);
    _8885 = NOVALUE;
    _8822 = NOVALUE;
    DeRef(_8806);
    _8806 = NOVALUE;
    DeRef(_8820);
    _8820 = NOVALUE;
    DeRef(_8937);
    _8937 = NOVALUE;
    DeRef(_8808);
    _8808 = NOVALUE;
    _8957 = NOVALUE;
    DeRef(_8766);
    _8766 = NOVALUE;
    _8980 = NOVALUE;
    DeRef(_8769);
    _8769 = NOVALUE;
    DeRef(_8883);
    _8883 = NOVALUE;
    DeRef(_8831);
    _8831 = NOVALUE;
    DeRef(_8881);
    _8881 = NOVALUE;
    _8838 = NOVALUE;
    DeRef(_8858);
    _8858 = NOVALUE;
    DeRef(_8860);
    _8860 = NOVALUE;
    DeRef(_8827);
    _8827 = NOVALUE;
    DeRef(_8855);
    _8855 = NOVALUE;
    DeRef(_8939);
    _8939 = NOVALUE;
    _8793 = NOVALUE;
    DeRef(_8941);
    _8941 = NOVALUE;
    DeRef(_8836);
    _8836 = NOVALUE;
    return _parsed_opts_15931;
    ;
}


int _40build_commandline(int _cmds_16275)
{
    int _8995 = NOVALUE;
    int _8994 = NOVALUE;
    int _8992 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_3338);
    RefDS(_3338);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3338;
    ((int *)_2)[2] = _3338;
    _8992 = MAKE_SEQ(_1);
    RefDS(_cmds_16275);
    RefDS(_8993);
    _8994 = _18quote(_cmds_16275, _8992, 92, _8993);
    _8992 = NOVALUE;
    RefDS(_8993);
    _8995 = _24flatten(_8994, _8993);
    _8994 = NOVALUE;
    DeRefDS(_cmds_16275);
    return _8995;
    ;
}



// 0xED92E915
