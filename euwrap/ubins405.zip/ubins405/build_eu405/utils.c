// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _55iif(int _test_21560, int _ifTrue_21561, int _ifFalse_21562)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_21560 == 0)
    {
        goto L1; // [3] 13
    }
    else{
    }

    /** 		return ifTrue*/
    DeRefDS(_ifFalse_21562);
    return _ifTrue_21561;
L1: 

    /** 	return ifFalse*/
    DeRef(_ifTrue_21561);
    return _ifFalse_21562;
    ;
}



// 0x7E6A2B1F
