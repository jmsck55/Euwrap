// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _45get_text(int _MsgNum_19763, int _LocalQuals_19764, int _DBBase_19765)
{
    int _db_res_19767 = NOVALUE;
    int _lMsgText_19768 = NOVALUE;
    int _dbname_19769 = NOVALUE;
    int _11040 = NOVALUE;
    int _11038 = NOVALUE;
    int _11036 = NOVALUE;
    int _11035 = NOVALUE;
    int _11034 = NOVALUE;
    int _11032 = NOVALUE;
    int _11031 = NOVALUE;
    int _11030 = NOVALUE;
    int _11024 = NOVALUE;
    int _11023 = NOVALUE;
    int _11022 = NOVALUE;
    int _11015 = NOVALUE;
    int _11012 = NOVALUE;
    int _11010 = NOVALUE;
    int _11008 = NOVALUE;
    int _11007 = NOVALUE;
    int _11006 = NOVALUE;
    int _11005 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db_res = -1*/
    _db_res_19767 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_19768);
    _lMsgText_19768 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_19764);
    _11005 = _9string(_LocalQuals_19764);
    if (IS_ATOM_INT(_11005)) {
        if (_11005 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11005)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_19764)){
            _11007 = SEQ_PTR(_LocalQuals_19764)->length;
    }
    else {
        _11007 = 1;
    }
    _11008 = (_11007 > 0);
    _11007 = NOVALUE;
    if (_11008 == 0)
    {
        DeRef(_11008);
        _11008 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11008);
        _11008 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_19764;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_19764);
    *((int *)(_2+4)) = _LocalQuals_19764;
    _LocalQuals_19764 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19764)){
            _11010 = SEQ_PTR(_LocalQuals_19764)->length;
    }
    else {
        _11010 = 1;
    }
    {
        int _i_19778;
        _i_19778 = 1;
L2: 
        if (_i_19778 > _11010){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_19764);
        _11012 = (int)*(((s1_ptr)_2)->base + _i_19778);
        {
            int concat_list[4];

            concat_list[0] = _11013;
            concat_list[1] = _11012;
            concat_list[2] = _11011;
            concat_list[3] = _DBBase_19765;
            Concat_N((object_ptr)&_dbname_19769, concat_list, 4);
        }
        _11012 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_19769);
        RefDS(_5);
        RefDS(_5);
        _11015 = _14locate_file(_dbname_19769, _5, _5);
        _db_res_19767 = _48db_select(_11015, 3);
        _11015 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_19767)) {
            _1 = (long)(DBL_PTR(_db_res_19767)->dbl);
            DeRefDS(_db_res_19767);
            _db_res_19767 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_19767 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11018);
        _db_res_19767 = _48db_select_table(_11018);
        if (!IS_ATOM_INT(_db_res_19767)) {
            _1 = (long)(DBL_PTR(_db_res_19767)->dbl);
            DeRefDS(_db_res_19767);
            _db_res_19767 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_19767 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_48current_table_name_17057);
        _0 = _lMsgText_19768;
        _lMsgText_19768 = _48db_fetch_record(_MsgNum_19763, _48current_table_name_17057);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11022 = IS_SEQUENCE(_lMsgText_19768);
        if (_11022 == 0)
        {
            _11022 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11022 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_19778 = _i_19778 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11023 = IS_ATOM(_lMsgText_19768);
    if (_11023 == 0)
    {
        _11023 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11023 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11024, _DBBase_19765, _11013);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_19769;
    _dbname_19769 = _14locate_file(_11024, _5, _5);
    DeRef(_0);
    _11024 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_19769);
    _db_res_19767 = _48db_select(_dbname_19769, 3);
    if (!IS_ATOM_INT(_db_res_19767)) {
        _1 = (long)(DBL_PTR(_db_res_19767)->dbl);
        DeRefDS(_db_res_19767);
        _db_res_19767 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_19767 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11018);
    _db_res_19767 = _48db_select_table(_11018);
    if (!IS_ATOM_INT(_db_res_19767)) {
        _1 = (long)(DBL_PTR(_db_res_19767)->dbl);
        DeRefDS(_db_res_19767);
        _db_res_19767 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_19767 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19764)){
            _11030 = SEQ_PTR(_LocalQuals_19764)->length;
    }
    else {
        _11030 = 1;
    }
    {
        int _i_19807;
        _i_19807 = 1;
LA: 
        if (_i_19807 > _11030){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_19764);
        _11031 = (int)*(((s1_ptr)_2)->base + _i_19807);
        Ref(_11031);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11031;
        ((int *)_2)[2] = _MsgNum_19763;
        _11032 = MAKE_SEQ(_1);
        _11031 = NOVALUE;
        RefDS(_48current_table_name_17057);
        _0 = _lMsgText_19768;
        _lMsgText_19768 = _48db_fetch_record(_11032, _48current_table_name_17057);
        DeRef(_0);
        _11032 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11034 = IS_SEQUENCE(_lMsgText_19768);
        if (_11034 == 0)
        {
            _11034 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11034 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_19807 = _i_19807 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11035 = IS_ATOM(_lMsgText_19768);
    if (_11035 == 0)
    {
        _11035 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11035 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_19763;
    _11036 = MAKE_SEQ(_1);
    RefDS(_48current_table_name_17057);
    _0 = _lMsgText_19768;
    _lMsgText_19768 = _48db_fetch_record(_11036, _48current_table_name_17057);
    DeRef(_0);
    _11036 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11038 = IS_ATOM(_lMsgText_19768);
    if (_11038 == 0)
    {
        _11038 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11038 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_48current_table_name_17057);
    _0 = _lMsgText_19768;
    _lMsgText_19768 = _48db_fetch_record(_MsgNum_19763, _48current_table_name_17057);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11040 = IS_ATOM(_lMsgText_19768);
    if (_11040 == 0)
    {
        _11040 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11040 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_19764);
    DeRefDS(_DBBase_19765);
    DeRef(_lMsgText_19768);
    DeRef(_dbname_19769);
    DeRef(_11005);
    _11005 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_19764);
    DeRefDS(_DBBase_19765);
    DeRef(_dbname_19769);
    DeRef(_11005);
    _11005 = NOVALUE;
    return _lMsgText_19768;
L10: 
    ;
}



// 0xC8B4040E
