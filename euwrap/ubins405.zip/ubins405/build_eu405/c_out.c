// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _53c_putc(int _c_45148)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_45148)) {
        _1 = (long)(DBL_PTR(_c_45148)->dbl);
        DeRefDS(_c_45148);
        _c_45148 = _1;
    }

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c)*/
    EPuts(_53c_code_45138, _c_45148); // DJP 

    /** 		update_checksum( c )*/
    _54update_checksum(_c_45148);
L1: 

    /** end procedure*/
    return;
    ;
}


void _53c_hputs(int _c_source_45153)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		puts(c_h, c_source)    */
    EPuts(_53c_h_45139, _c_source_45153); // DJP 
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45153);
    return;
    ;
}


void _53c_puts(int _c_source_45157)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c_source)*/
    EPuts(_53c_code_45138, _c_source_45157); // DJP 

    /** 		update_checksum( c_source )*/
    RefDS(_c_source_45157);
    _54update_checksum(_c_source_45157);
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45157);
    return;
    ;
}


void _53c_hprintf(int _format_45162, int _value_45163)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_45163)) {
        _1 = (long)(DBL_PTR(_value_45163)->dbl);
        DeRefDS(_value_45163);
        _value_45163 = _1;
    }

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		printf(c_h, format, value)*/
    EPrintf(_53c_h_45139, _format_45162, _value_45163);
L1: 

    /** end procedure*/
    DeRefDS(_format_45162);
    return;
    ;
}


void _53c_printf(int _format_45167, int _value_45168)
{
    int _text_45170 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** 		sequence text = sprintf( format, value )*/
    DeRefi(_text_45170);
    _text_45170 = EPrintf(-9999999, _format_45167, _value_45168);

    /** 		puts(c_code, text)*/
    EPuts(_53c_code_45138, _text_45170); // DJP 

    /** 		update_checksum( text )*/
    RefDS(_text_45170);
    _54update_checksum(_text_45170);
L1: 
    DeRefi(_text_45170);
    _text_45170 = NOVALUE;

    /** end procedure*/
    DeRefDS(_format_45167);
    DeRef(_value_45168);
    return;
    ;
}


void _53c_printf8(int _value_45181)
{
    int _buff_45182 = NOVALUE;
    int _neg_45183 = NOVALUE;
    int _p_45184 = NOVALUE;
    int _23897 = NOVALUE;
    int _23896 = NOVALUE;
    int _23894 = NOVALUE;
    int _23893 = NOVALUE;
    int _23891 = NOVALUE;
    int _23890 = NOVALUE;
    int _23888 = NOVALUE;
    int _23887 = NOVALUE;
    int _23885 = NOVALUE;
    int _23883 = NOVALUE;
    int _23881 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** 		neg = 0*/
    _neg_45183 = 0;

    /** 		buff = sprintf("%.16e", value)*/
    DeRef(_buff_45182);
    _buff_45182 = EPrintf(-9999999, _23879, _value_45181);

    /** 		if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_45182)){
            _23881 = SEQ_PTR(_buff_45182)->length;
    }
    else {
        _23881 = 1;
    }
    if (_23881 >= 10)
    goto L2; // [24] 174

    /** 			p = 1*/
    _p_45184 = 1;

    /** 			while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_45182)){
            _23883 = SEQ_PTR(_buff_45182)->length;
    }
    else {
        _23883 = 1;
    }
    if (_p_45184 > _23883)
    goto L4; // [41] 173

    /** 				if buff[p] = '-' then*/
    _2 = (int)SEQ_PTR(_buff_45182);
    _23885 = (int)*(((s1_ptr)_2)->base + _p_45184);
    if (binary_op_a(NOTEQ, _23885, 45)){
        _23885 = NOVALUE;
        goto L5; // [51] 63
    }
    _23885 = NOVALUE;

    /** 					neg = 1*/
    _neg_45183 = 1;
    goto L6; // [60] 162
L5: 

    /** 				elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (int)SEQ_PTR(_buff_45182);
    _23887 = (int)*(((s1_ptr)_2)->base + _p_45184);
    if (IS_ATOM_INT(_23887)) {
        _23888 = (_23887 == 105);
    }
    else {
        _23888 = binary_op(EQUALS, _23887, 105);
    }
    _23887 = NOVALUE;
    if (IS_ATOM_INT(_23888)) {
        if (_23888 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_23888)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (int)SEQ_PTR(_buff_45182);
    _23890 = (int)*(((s1_ptr)_2)->base + _p_45184);
    if (IS_ATOM_INT(_23890)) {
        _23891 = (_23890 == 73);
    }
    else {
        _23891 = binary_op(EQUALS, _23890, 73);
    }
    _23890 = NOVALUE;
    if (_23891 == 0) {
        DeRef(_23891);
        _23891 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_23891) && DBL_PTR(_23891)->dbl == 0.0){
            DeRef(_23891);
            _23891 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_23891);
        _23891 = NOVALUE;
    }
    DeRef(_23891);
    _23891 = NOVALUE;
L7: 

    /** 					buff = CREATE_INF*/
    RefDS(_53CREATE_INF_45173);
    DeRef(_buff_45182);
    _buff_45182 = _53CREATE_INF_45173;

    /** 					if neg then*/
    if (_neg_45183 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** 						buff = prepend(buff, '-')*/
    Prepend(&_buff_45182, _buff_45182, 45);

    /** 					exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** 				elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (int)SEQ_PTR(_buff_45182);
    _23893 = (int)*(((s1_ptr)_2)->base + _p_45184);
    if (IS_ATOM_INT(_23893)) {
        _23894 = (_23893 == 110);
    }
    else {
        _23894 = binary_op(EQUALS, _23893, 110);
    }
    _23893 = NOVALUE;
    if (IS_ATOM_INT(_23894)) {
        if (_23894 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_23894)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (int)SEQ_PTR(_buff_45182);
    _23896 = (int)*(((s1_ptr)_2)->base + _p_45184);
    if (IS_ATOM_INT(_23896)) {
        _23897 = (_23896 == 78);
    }
    else {
        _23897 = binary_op(EQUALS, _23896, 78);
    }
    _23896 = NOVALUE;
    if (_23897 == 0) {
        DeRef(_23897);
        _23897 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_23897) && DBL_PTR(_23897)->dbl == 0.0){
            DeRef(_23897);
            _23897 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_23897);
        _23897 = NOVALUE;
    }
    DeRef(_23897);
    _23897 = NOVALUE;
L9: 

    /** 					ifdef UNIX then*/

    /** 						buff = CREATE_NAN1*/
    RefDS(_53CREATE_NAN1_45175);
    DeRef(_buff_45182);
    _buff_45182 = _53CREATE_NAN1_45175;

    /** 						if neg then*/
    if (_neg_45183 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** 							buff = prepend(buff, '-')*/
    Prepend(&_buff_45182, _buff_45182, 45);
LB: 
LA: 
L6: 

    /** 				p += 1*/
    _p_45184 = _p_45184 + 1;

    /** 			end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** 		puts(c_code, buff)*/
    EPuts(_53c_code_45138, _buff_45182); // DJP 
L1: 

    /** end procedure*/
    DeRef(_value_45181);
    DeRef(_buff_45182);
    DeRef(_23888);
    _23888 = NOVALUE;
    DeRef(_23894);
    _23894 = NOVALUE;
    return;
    ;
}


void _53adjust_indent_before(int _stmt_45220)
{
    int _i_45221 = NOVALUE;
    int _lb_45223 = NOVALUE;
    int _rb_45224 = NOVALUE;
    int _23912 = NOVALUE;
    int _23910 = NOVALUE;
    int _23908 = NOVALUE;
    int _23902 = NOVALUE;
    int _23901 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lb = FALSE*/
    _lb_45223 = _9FALSE_429;

    /** 	rb = FALSE*/
    _rb_45224 = _9FALSE_429;

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45220)){
            _23901 = SEQ_PTR(_stmt_45220)->length;
    }
    else {
        _23901 = 1;
    }
    {
        int _p_45228;
        _p_45228 = 1;
L1: 
        if (_p_45228 > _23901){
            goto L2; // [22] 102
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45220);
        _23902 = (int)*(((s1_ptr)_2)->base + _p_45228);
        if (IS_SEQUENCE(_23902) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_23902)){
            if( (DBL_PTR(_23902)->dbl != (double) ((int) DBL_PTR(_23902)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (int) DBL_PTR(_23902)->dbl;
        }
        else {
            _0 = _23902;
        };
        _23902 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** 			case  '}' then*/
            case 125:

            /** 				rb = TRUE*/
            _rb_45224 = _9TRUE_431;

            /** 				if lb then*/
            if (_lb_45223 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** 					exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** 			case '{' then*/
            case 123:

            /** 				lb = TRUE*/
            _lb_45223 = _9TRUE_431;

            /** 				if rb then */
            if (_rb_45224 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** 					exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** 	end for*/
        _p_45228 = _p_45228 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** 	if rb then*/
    if (_rb_45224 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** 		if not lb then*/
    if (_lb_45223 != 0)
    goto L6; // [109] 121

    /** 			indent -= 4*/
    _53indent_45214 = _53indent_45214 - 4;
L6: 
L5: 

    /** 	i = indent + temp_indent*/
    _i_45221 = _53indent_45214 + _53temp_indent_45215;

    /** 	while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_53big_blanks_45216)){
            _23908 = SEQ_PTR(_53big_blanks_45216)->length;
    }
    else {
        _23908 = 1;
    }
    if (_i_45221 < _23908)
    goto L8; // [140] 163

    /** 		c_puts(big_blanks)*/
    RefDS(_53big_blanks_45216);
    _53c_puts(_53big_blanks_45216);

    /** 		i -= length(big_blanks)*/
    if (IS_SEQUENCE(_53big_blanks_45216)){
            _23910 = SEQ_PTR(_53big_blanks_45216)->length;
    }
    else {
        _23910 = 1;
    }
    _i_45221 = _i_45221 - _23910;
    _23910 = NOVALUE;

    /** 	end while*/
    goto L7; // [160] 137
L8: 

    /** 	c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_23912;
    RHS_Slice(_53big_blanks_45216, 1, _i_45221);
    _53c_puts(_23912);
    _23912 = NOVALUE;

    /** 	temp_indent = 0    */
    _53temp_indent_45215 = 0;

    /** end procedure*/
    DeRefDS(_stmt_45220);
    return;
    ;
}


void _53adjust_indent_after(int _stmt_45253)
{
    int _23933 = NOVALUE;
    int _23932 = NOVALUE;
    int _23930 = NOVALUE;
    int _23928 = NOVALUE;
    int _23927 = NOVALUE;
    int _23924 = NOVALUE;
    int _23922 = NOVALUE;
    int _23921 = NOVALUE;
    int _23918 = NOVALUE;
    int _23914 = NOVALUE;
    int _23913 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45253)){
            _23913 = SEQ_PTR(_stmt_45253)->length;
    }
    else {
        _23913 = 1;
    }
    {
        int _p_45255;
        _p_45255 = 1;
L1: 
        if (_p_45255 > _23913){
            goto L2; // [8] 61
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45253);
        _23914 = (int)*(((s1_ptr)_2)->base + _p_45255);
        if (IS_SEQUENCE(_23914) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_23914)){
            if( (DBL_PTR(_23914)->dbl != (double) ((int) DBL_PTR(_23914)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (int) DBL_PTR(_23914)->dbl;
        }
        else {
            _0 = _23914;
        };
        _23914 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** 			case '{' then*/
            case 123:

            /** 				indent += 4*/
            _53indent_45214 = _53indent_45214 + 4;

            /** 				return*/
            DeRefDS(_stmt_45253);
            return;
        ;}L3: 

        /** 	end for*/
        _p_45255 = _p_45255 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** 	if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_45253)){
            _23918 = SEQ_PTR(_stmt_45253)->length;
    }
    else {
        _23918 = 1;
    }
    if (_23918 >= 3)
    goto L4; // [66] 76

    /** 		return*/
    DeRefDS(_stmt_45253);
    return;
L4: 

    /** 	if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_23921;
    RHS_Slice(_stmt_45253, 1, 3);
    if (_23920 == _23921)
    _23922 = 1;
    else if (IS_ATOM_INT(_23920) && IS_ATOM_INT(_23921))
    _23922 = 0;
    else
    _23922 = (compare(_23920, _23921) == 0);
    DeRefDS(_23921);
    _23921 = NOVALUE;
    if (_23922 != 0)
    goto L5; // [87] 96
    _23922 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45253);
    return;
L5: 

    /** 	if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_45253)){
            _23924 = SEQ_PTR(_stmt_45253)->length;
    }
    else {
        _23924 = 1;
    }
    if (_23924 >= 5)
    goto L6; // [101] 111

    /** 		return*/
    DeRefDS(_stmt_45253);
    return;
L6: 

    /** 	if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_23927;
    RHS_Slice(_stmt_45253, 1, 4);
    if (_23926 == _23927)
    _23928 = 1;
    else if (IS_ATOM_INT(_23926) && IS_ATOM_INT(_23927))
    _23928 = 0;
    else
    _23928 = (compare(_23926, _23927) == 0);
    DeRefDS(_23927);
    _23927 = NOVALUE;
    if (_23928 != 0)
    goto L7; // [122] 131
    _23928 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45253);
    return;
L7: 

    /** 	if not find(stmt[5], {" \n"}) then*/
    _2 = (int)SEQ_PTR(_stmt_45253);
    _23930 = (int)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_23931);
    *((int *)(_2+4)) = _23931;
    _23932 = MAKE_SEQ(_1);
    _23933 = find_from(_23930, _23932, 1);
    _23930 = NOVALUE;
    DeRefDS(_23932);
    _23932 = NOVALUE;
    if (_23933 != 0)
    goto L8; // [146] 155
    _23933 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45253);
    return;
L8: 

    /** 	temp_indent = 4*/
    _53temp_indent_45215 = 4;

    /** end procedure*/
    DeRefDS(_stmt_45253);
    return;
    ;
}



// 0x1FCA358B
