Copyright (c) 2020 James J. Cook

Compiled bins from Euphoria v4.0.5
