#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int _112;
int _138;
int _139;
int _141;
int _144;
int _148;
int _149;
int _150;
int _151;
int _152;

int _2MAX_ADDR;
int _2LOW_ADDR;
int _2mem;
int _2check_calls;
int _3always_linked_list;
int _3SIGN_MASK;
int _3SIGN_FLAG;
int _3DOUBLE_FLAG;
int _3INT_FLAG;
int _3UINT_FLAG;
int _3FLOAT_FLAG;
int _3CSTRING;
int _3CBYTES;
int _1high_address;
int _1data;
int _1free_list;


struct routine_list _00[] = {
  {"allocate", (int (*)())_2allocate, 7, -2, 1, 1},
  {"free", (int (*)())_2free, 8, -2, 1, 1},
  {"allocate_low", (int (*)())_2allocate_low, 9, -2, 1, 1},
  {"free_low", (int (*)())_2free_low, 10, -2, 1, 1},
  {"dos_interrupt", (int (*)())_2dos_interrupt, 11, -2, 2, 1},
  {"int_to_bytes", (int (*)())_2int_to_bytes, 12, -2, 1, 1},
  {"bytes_to_int", (int (*)())_2bytes_to_int, 13, -2, 1, 1},
  {"int_to_bits", (int (*)())_2int_to_bits, 14, -2, 2, 1},
  {"bits_to_int", (int (*)())_2bits_to_int, 15, -2, 1, 1},
  {"set_rand", (int (*)())_2set_rand, 16, -2, 1, 1},
  {"use_vesa", (int (*)())_2use_vesa, 17, -2, 1, 1},
  {"crash_message", (int (*)())_2crash_message, 18, -2, 1, 1},
  {"crash_file", (int (*)())_2crash_file, 19, -2, 1, 1},
  {"crash_routine", (int (*)())_2crash_routine, 20, -2, 1, 1},
  {"tick_rate", (int (*)())_2tick_rate, 21, -2, 1, 1},
  {"get_vector", (int (*)())_2get_vector, 22, -2, 1, 1},
  {"set_vector", (int (*)())_2set_vector, 23, -2, 2, 1},
  {"lock_memory", (int (*)())_2lock_memory, 24, -2, 2, 1},
  {"atom_to_float64", (int (*)())_2atom_to_float64, 25, -2, 1, 1},
  {"atom_to_float32", (int (*)())_2atom_to_float32, 26, -2, 1, 1},
  {"float64_to_atom", (int (*)())_2float64_to_atom, 27, -2, 1, 1},
  {"float32_to_atom", (int (*)())_2float32_to_atom, 28, -2, 1, 1},
  {"allocate_string", (int (*)())_2allocate_string, 29, -2, 1, 1},
  {"register_block", (int (*)())_2register_block, 30, -2, 2, 1},
  {"unregister_block", (int (*)())_2unregister_block, 31, -2, 1, 1},
  {"check_all_blocks", (int (*)())_2check_all_blocks, 32, -2, 0, 1},
  {"set_return_linked_list", (int (*)())_3set_return_linked_list, 33, -3, 1, 1},
  {"get_return_linked_list", (int (*)())_3get_return_linked_list, 34, -3, 0, 1},
  {"peek_string", (int (*)())_3peek_string, 35, -3, 1, 1},
  {"mystring", (int (*)())_3mystring, 36, -3, 1, 1},
  {"myarray", (int (*)())_3myarray, 37, -3, 1, 1},
  {"sequence_to_linked_list", (int (*)())_3sequence_to_linked_list, 38, -3, 1, 1},
  {"free_linked_list", (int (*)())_3free_linked_list, 39, -3, 1, 1},
  {"linked_list_to_sequence", (int (*)())_3linked_list_to_sequence, 40, -3, 1, 1},
  {"get_version", (int (*)())_1get_version, 41, -1, 0, 1},
  {"binary_search", (int (*)())_1binary_search, 42, 1, 2, 0},
  {"init", (int (*)())_1init, 43, -1, 0, 1},
  {"get_high_address", (int (*)())_1get_high_address, 44, -1, 0, 1},
  {"set_high_address", (int (*)())_1set_high_address, 45, 1, 1, 0},
  {"get_address", (int (*)())_1get_address, 46, 1, 2, 0},
  {"register_data", (int (*)())_1register_data, 47, 1, 1, 0},
  {"retval", (int (*)())_1retval, 48, 1, 1, 0},
  {"length_of_data", (int (*)())_1length_of_data, 49, -1, 0, 1},
  {"is_free", (int (*)())_1is_free, 50, -1, 1, 1},
  {"access_free_list", (int (*)())_1access_free_list, 51, -1, 0, 1},
  {"generic_free", (int (*)())_1generic_free, 52, -1, 2, 1},
  {"delete_linked_list", (int (*)())_1delete_linked_list, 53, -1, 1, 1},
  {"free_linked_lists", (int (*)())_1free_linked_lists, 54, -1, 3, 1},
  {"register_linked_list", (int (*)())_1register_linked_list, 55, -1, 2, 1},
  {"new_linked_list", (int (*)())_1new_linked_list, 56, -1, 2, 1},
  {"store_linked_list", (int (*)())_1store_linked_list, 57, -1, 3, 1},
  {"access_linked_list", (int (*)())_1access_linked_list, 58, -1, 1, 1},
  {"at_linked_list", (int (*)())_1at_linked_list, 59, -1, 2, 1},
  {"free_linked_list_dll", (int (*)())_1free_linked_list_dll, 60, -1, 2, 1},
  {"length_linked_list", (int (*)())_1length_linked_list, 61, -1, 1, 1},
  {"store_at_linked_list", (int (*)())_1store_at_linked_list, 62, -1, 4, 1},
  {"eu_repeat", (int (*)())_1eu_repeat, 63, -1, 2, 1},
  {"eu_mem_set", (int (*)())_1eu_mem_set, 64, -1, 4, 1},
  {"eu_mem_copy", (int (*)())_1eu_mem_copy, 65, -1, 5, 1},
  {"eu_add", (int (*)())_1eu_add, 66, -1, 2, 1},
  {"eu_subtract", (int (*)())_1eu_subtract, 67, -1, 2, 1},
  {"eu_multiply", (int (*)())_1eu_multiply, 68, -1, 2, 1},
  {"eu_divide", (int (*)())_1eu_divide, 69, -1, 2, 1},
  {"eu_negate", (int (*)())_1eu_negate, 70, -1, 1, 1},
  {"eu_not", (int (*)())_1eu_not, 71, -1, 1, 1},
  {"eu_equals", (int (*)())_1eu_equals, 72, -1, 2, 1},
  {"eu_and", (int (*)())_1eu_and, 73, -1, 2, 1},
  {"eu_or", (int (*)())_1eu_or, 74, -1, 2, 1},
  {"eu_xor", (int (*)())_1eu_xor, 75, -1, 2, 1},
  {"eu_question_mark", (int (*)())_1eu_question_mark, 76, -1, 1, 1},
  {"eu_abort", (int (*)())_1eu_abort, 77, -1, 1, 1},
  {"eu_and_bits", (int (*)())_1eu_and_bits, 78, -1, 2, 1},
  {"eu_append", (int (*)())_1eu_append, 79, -1, 2, 1},
  {"eu_arctan", (int (*)())_1eu_arctan, 80, -1, 1, 1},
  {"eu_atom", (int (*)())_1eu_atom, 81, -1, 1, 1},
  {"eu_c_func", (int (*)())_1eu_c_func, 82, -1, 2, 1},
  {"eu_c_proc", (int (*)())_1eu_c_proc, 83, -1, 2, 1},
  {"eu_call", (int (*)())_1eu_call, 84, -1, 2, 1},
  {"eu_clear_screen", (int (*)())_1eu_clear_screen, 85, -1, 0, 1},
  {"eu_close", (int (*)())_1eu_close, 86, -1, 1, 1},
  {"eu_command_line", (int (*)())_1eu_command_line, 87, -1, 0, 1},
  {"eu_compare", (int (*)())_1eu_compare, 88, -1, 2, 1},
  {"eu_concat", (int (*)())_1eu_concat, 89, -1, 2, 1},
  {"eu_cos", (int (*)())_1eu_cos, 90, -1, 1, 1},
  {"eu_date", (int (*)())_1eu_date, 91, -1, 0, 1},
  {"eu_equal", (int (*)())_1eu_equal, 92, -1, 2, 1},
  {"eu_find_from", (int (*)())_1eu_find_from, 93, -1, 3, 1},
  {"eu_floor", (int (*)())_1eu_floor, 94, -1, 1, 1},
  {"eu_integer_division", (int (*)())_1eu_integer_division, 95, -1, 2, 1},
  {"eu_get_key", (int (*)())_1eu_get_key, 96, -1, 0, 1},
  {"eu_getc", (int (*)())_1eu_getc, 97, -1, 1, 1},
  {"eu_getenv", (int (*)())_1eu_getenv, 98, -1, 1, 1},
  {"eu_gets", (int (*)())_1eu_gets, 99, -1, 1, 1},
  {"eu_integer", (int (*)())_1eu_integer, 100, -1, 1, 1},
  {"eu_length", (int (*)())_1eu_length, 101, -1, 1, 1},
  {"eu_log", (int (*)())_1eu_log, 102, -1, 1, 1},
  {"eu_machine_func", (int (*)())_1eu_machine_func, 103, -1, 2, 1},
  {"eu_machine_proc", (int (*)())_1eu_machine_proc, 104, -1, 2, 1},
  {"eu_match_from", (int (*)())_1eu_match_from, 105, -1, 3, 1},
  {"eu_not_bits", (int (*)())_1eu_not_bits, 106, -1, 1, 1},
  {"eu_object", (int (*)())_1eu_object, 107, -1, 1, 1},
  {"eu_open", (int (*)())_1eu_open, 108, -1, 2, 1},
  {"eu_open_str", (int (*)())_1eu_open_str, 109, -1, 3, 1},
  {"eu_or_bits", (int (*)())_1eu_or_bits, 110, -1, 2, 1},
  {"eu_peek", (int (*)())_1eu_peek, 111, -1, 1, 1},
  {"eu_peek4s", (int (*)())_1eu_peek4s, 112, -1, 1, 1},
  {"eu_peek4u", (int (*)())_1eu_peek4u, 113, -1, 1, 1},
  {"eu_platform", (int (*)())_1eu_platform, 114, -1, 0, 1},
  {"eu_poke", (int (*)())_1eu_poke, 115, -1, 2, 1},
  {"eu_poke4", (int (*)())_1eu_poke4, 116, -1, 2, 1},
  {"eu_position", (int (*)())_1eu_position, 117, -1, 2, 1},
  {"eu_power", (int (*)())_1eu_power, 118, -1, 2, 1},
  {"eu_prepend", (int (*)())_1eu_prepend, 119, -1, 2, 1},
  {"eu_print", (int (*)())_1eu_print, 120, -1, 2, 1},
  {"eu_printf", (int (*)())_1eu_printf, 121, -1, 3, 1},
  {"eu_puts", (int (*)())_1eu_puts, 122, -1, 2, 1},
  {"eu_rand", (int (*)())_1eu_rand, 123, -1, 1, 1},
  {"eu_remainder", (int (*)())_1eu_remainder, 124, -1, 2, 1},
  {"eu_sequence", (int (*)())_1eu_sequence, 125, -1, 1, 1},
  {"eu_sin", (int (*)())_1eu_sin, 126, -1, 1, 1},
  {"eu_sprintf", (int (*)())_1eu_sprintf, 127, -1, 2, 1},
  {"eu_sqrt", (int (*)())_1eu_sqrt, 128, -1, 1, 1},
  {"eu_subscript", (int (*)())_1eu_subscript, 129, -1, 3, 1},
  {"eu_system", (int (*)())_1eu_system, 130, -1, 2, 1},
  {"eu_system_exec", (int (*)())_1eu_system_exec, 131, -1, 2, 1},
  {"eu_tan", (int (*)())_1eu_tan, 132, -1, 1, 1},
  {"eu_time", (int (*)())_1eu_time, 133, -1, 0, 1},
  {"eu_xor_bits", (int (*)())_1eu_xor_bits, 134, -1, 2, 1},
  {"eu_call_func_std", (int (*)())_1eu_call_func_std, 135, -1, 2, 1},
  {"eu_call_func_val", (int (*)())_1eu_call_func_val, 136, -1, 2, 1},
  {"eu_call_func", (int (*)())_1eu_call_func, 137, -1, 2, 1},
  {"eu_call_proc", (int (*)())_1eu_call_proc, 138, -1, 2, 1},
  {"eu_routine_id", (int (*)())_1eu_routine_id, 139, -1, 1, 1},
  {"eu_routine_id_str", (int (*)())_1eu_routine_id_str, 140, -1, 2, 1},
  {"", 0, 999999999, 0, 0, 0}
};

struct ns_list _01[] = {
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern double sqrt();
    _112 = NewString("");
    _139 = NewDouble((double)-2.1474836480000000e+09);
    _138 = NewDouble((double)2.1474836480000000e+09);
    _144 = NewDouble((double)2.1474836470000000e+09);
    _141 = NewDouble((double)4.2949672950000000e+09);
    _152 = NewDouble((double)3.4896609280000000e+09);
    _151 = NewDouble((double)2.9527900160000000e+09);
    _150 = NewDouble((double)2.6843545600000000e+09);
    _149 = NewDouble((double)2.4159191040000000e+09);
    _148 = NewDouble((double)4.0265318400000000e+09);
}
