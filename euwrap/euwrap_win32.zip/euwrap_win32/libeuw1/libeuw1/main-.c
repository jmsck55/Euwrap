// Euphoria To C version 3.1.1
#include <time.h>
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int Argc;
char **Argv;
unsigned default_heap;
__declspec(dllimport) unsigned __stdcall GetProcessHeap(void);
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
int total_stack_size = 262144;

int __stdcall _CRT_INIT (int, int, void *);


void EuInit()
{
    int _24 = 0;
    int _0, _1, _2;
    
    
    Argc = 0;
    default_heap = GetProcessHeap();
    eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)CLK_TCK);
    init_literal();
    _24 = power(2, 32);
    if (IS_ATOM_INT(_24)) {
        _2MAX_ADDR = _24 - 1;
        if ((long)((unsigned long)_2MAX_ADDR +(unsigned long) HIGH_BITS) >= 0)
            _2MAX_ADDR = NewDouble((double)_2MAX_ADDR);
    }
    else {
        _2MAX_ADDR = NewDouble(DBL_PTR(_24)->dbl - (double)1);
    }
    DeRef1(_24);
    _24 = 1048576;
    _2LOW_ADDR = 1048575;

    // mem = allocate(4)
    _0 = _2allocate(4);
    DeRef1(_2mem);
    _2mem = _0;

    // check_calls = 1
    _2check_calls = 1;
    RefDS(_304);
    _6PI = _304;
    _6PI_HALF = NewDouble(DBL_PTR(_6PI)->dbl / DBL_PTR(_305)->dbl);

    // if platform() = LINUX then

    //     SLASH='\\'
    _4SLASH = 92;
L1:

    // my_dir = DEFAULT  -- it's better not to use routine_id() here,
    _4my_dir = -2;
    RefDS(_422);
    _7DIGITS = _422;
    Concat((object_ptr)&_7HEX_DIGITS, _7DIGITS, (s1_ptr)_423);
    Concat((object_ptr)&_7START_NUMERIC, _7DIGITS, (s1_ptr)_425);
    RefDS(_441);
    _7ESCAPE_CHARS = _441;
    RefDS(_442);
    _7ESCAPED_CHARS = _442;

    // if platform() = LINUX then

    //     BLUE  = 1
    _8BLUE = 1;

    //     CYAN =  3
    _8CYAN = 3;

    //     RED   = 4
    _8RED = 4;

    //     BROWN = 6
    _8BROWN = 6;

    //     BRIGHT_BLUE = 9
    _8BRIGHT_BLUE = 9;

    //     BRIGHT_CYAN = 11
    _8BRIGHT_CYAN = 11;

    //     BRIGHT_RED = 12
    _8BRIGHT_RED = 12;

    //     YELLOW = 14
    _8YELLOW = 14;
L2:
    _10TO_LOWER = 32;

    // if platform() = LINUX then

    //     SLASH_CHAR = "\\/"
    RefDS(_1169);
    DeRef1(_11SLASH_CHAR);
    _11SLASH_CHAR = _1169;
L3:

    // current_db = -1
    _11current_db = -1;

    // current_table = -1
    DeRef1(_11current_table);
    _11current_table = -1;

    // db_names = {}
    RefDS(_202);
    DeRef1(_11db_names);
    _11db_names = _202;

    // db_file_nums = {}
    RefDS(_202);
    DeRef1(_11db_file_nums);
    _11db_file_nums = _202;

    // db_lock_methods = {}
    RefDS(_202);
    DeRef1(_11db_lock_methods);
    _11db_lock_methods = _202;

    // db_fatal_id = routine_id("default_fatal") -- you can set it to your own handler
    _11db_fatal_id = CRoutineId(148, 11, _1173);

    // mem0 = allocate(4)
    _0 = _2allocate(4);
    DeRef1(_11mem0);
    _11mem0 = _0;

    // mem1 = mem0 + 1
    DeRef1(_11mem1);
    if (IS_ATOM_INT(_11mem0)) {
        _11mem1 = _11mem0 + 1;
        if (_11mem1 > MAXINT)
            _11mem1 = NewDouble((double)_11mem1);
    }
    else
        _11mem1 = binary_op(PLUS, 1, _11mem0);

    // mem2 = mem0 + 2
    DeRef1(_11mem2);
    if (IS_ATOM_INT(_11mem0)) {
        _11mem2 = _11mem0 + 2;
        if ((long)((unsigned long)_11mem2 + (unsigned long)HIGH_BITS) >= 0) 
            _11mem2 = NewDouble((double)_11mem2);
    }
    else {
        _11mem2 = NewDouble(DBL_PTR(_11mem0)->dbl + (double)2);
    }

    // mem3 = mem0 + 3
    DeRef1(_11mem3);
    if (IS_ATOM_INT(_11mem0)) {
        _11mem3 = _11mem0 + 3;
        if ((long)((unsigned long)_11mem3 + (unsigned long)HIGH_BITS) >= 0) 
            _11mem3 = NewDouble((double)_11mem3);
    }
    else {
        _11mem3 = NewDouble(DBL_PTR(_11mem0)->dbl + (double)3);
    }
    DeRef1(_24);
    _24 = 32768;
    _11MIN2B = - 32768;
    _24 = 32768;
    _11MAX2B = 32767;
    _24 = 8388608;
    _11MIN3B = - 8388608;
    _24 = 8388608;
    _11MAX3B = 8388607;
    _24 = power(2, 31);
    if (IS_ATOM_INT(_24)) {
        if (_24 == 0xC0000000)
            _11MIN4B = (int)NewDouble((double)-0xC0000000);
        else
            _11MIN4B = - _24;
    }
    else {
        _11MIN4B = unary_op(UMINUS, _24);
    }

    // memseq = {mem0, 4}
    DeRef1(_11memseq);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11mem0;
    Ref(_11mem0);
    ((int *)_2)[2] = 4;
    _11memseq = MAKE_SEQ(_1);

    // always_linked_list = 0
    _12always_linked_list = 0;
    RefDS(_2015);
    _12SIGN_MASK = _2015;
    RefDS(_2005);
    _12SIGN_FLAG = _2005;
    RefDS(_2016);
    _12DOUBLE_FLAG = _2016;
    RefDS(_2017);
    _12INT_FLAG = _2017;
    RefDS(_2018);
    _12UINT_FLAG = _2018;
    RefDS(_2019);
    _12FLOAT_FLAG = _2019;
    RefDS(_2008);
    _12CSTRING = _2008;
    RefDS(_12SIGN_FLAG);
    _12CBYTES = _12SIGN_FLAG;

    // init()
    _1init();
    ;
}

int __stdcall LibMain(int hDLL, int Reason, void *Reserved)
{
    if (Reason == 1)
        EuInit();
    return 1;
}
