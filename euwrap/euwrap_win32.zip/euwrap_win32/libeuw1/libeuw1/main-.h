extern int _152;
extern int _187;
extern int _189;
extern int _198;
extern int _202;
extern int _216;
extern int _218;
extern int _221;
extern int _230;
extern int _258;
extern int _272;
extern int _280;
extern int _304;
extern int _305;
extern int _315;
extern int _395;
extern int _396;
extern int _422;
extern int _423;
extern int _425;
extern int _439;
extern int _441;
extern int _442;
extern int _562;
extern int _573;
extern int _711;
extern int _967;
extern int _1027;
extern int _1168;
extern int _1169;
extern int _1170;
extern int _1173;
extern int _1188;
extern int _1306;
extern int _1312;
extern int _1313;
extern int _1317;
extern int _1320;
extern int _1324;
extern int _1329;
extern int _1330;
extern int _1337;
extern int _1341;
extern int _1354;
extern int _1355;
extern int _1357;
extern int _1358;
extern int _1359;
extern int _1361;
extern int _1367;
extern int _1373;
extern int _1376;
extern int _1383;
extern int _1390;
extern int _1393;
extern int _1397;
extern int _1500;
extern int _1506;
extern int _1670;
extern int _1673;
extern int _1692;
extern int _1757;
extern int _1806;
extern int _1896;
extern int _1910;
extern int _1918;
extern int _1921;
extern int _1926;
extern int _1927;
extern int _1930;
extern int _1933;
extern int _1934;
extern int _1976;
extern int _2005;
extern int _2006;
extern int _2008;
extern int _2011;
extern int _2015;
extern int _2016;
extern int _2017;
extern int _2018;
extern int _2019;
extern int Argc;
extern char **Argv;
extern unsigned long *peek4_addr;
extern unsigned char *poke_addr;
extern unsigned long *poke4_addr;
extern struct d temp_d;
extern double temp_dbl;
extern char *stack_base;
extern int total_stack_size;
extern int _2MAX_ADDR;
extern int _2LOW_ADDR;
extern int _2mem;
extern int _2check_calls;
extern int _6pretty_end_col;
extern int _6pretty_chars;
extern int _6pretty_start_col;
extern int _6pretty_level;
extern int _6pretty_file;
extern int _6pretty_ascii;
extern int _6pretty_indent;
extern int _6pretty_ascii_min;
extern int _6pretty_ascii_max;
extern int _6pretty_line_count;
extern int _6pretty_line_max;
extern int _6pretty_dots;
extern int _6pretty_fp_format;
extern int _6pretty_int_format;
extern int _6pretty_line;
extern int _6PI;
extern int _6PI_HALF;
extern int _4SLASH;
extern int _4my_dir;
extern int _7DIGITS;
extern int _7HEX_DIGITS;
extern int _7START_NUMERIC;
extern int _7input_file;
extern int _7input_string;
extern int _7string_next;
extern int _7ch;
extern int _7ESCAPE_CHARS;
extern int _7ESCAPED_CHARS;
extern int _8BLUE;
extern int _8CYAN;
extern int _8RED;
extern int _8BROWN;
extern int _8BRIGHT_BLUE;
extern int _8BRIGHT_CYAN;
extern int _8BRIGHT_RED;
extern int _8YELLOW;
extern int _9fn;
extern int _9error_code;
extern int _9numXPixels;
extern int _9numYPixels;
extern int _9bitCount;
extern int _9numRowBytes;
extern int _9startXPixel;
extern int _9startYPixel;
extern int _9endYPixel;
extern int _10TO_LOWER;
extern int _11current_db;
extern int _11current_table;
extern int _11db_names;
extern int _11db_file_nums;
extern int _11db_lock_methods;
extern int _11current_lock;
extern int _11SLASH_CHAR;
extern int _11key_pointers;
extern int _11db_fatal_id;
extern int _11mem0;
extern int _11mem1;
extern int _11mem2;
extern int _11mem3;
extern int _11MIN2B;
extern int _11MAX2B;
extern int _11MIN3B;
extern int _11MAX3B;
extern int _11MIN4B;
extern int _11memseq;
extern int _12always_linked_list;
extern int _12SIGN_MASK;
extern int _12SIGN_FLAG;
extern int _12DOUBLE_FLAG;
extern int _12INT_FLAG;
extern int _12UINT_FLAG;
extern int _12FLOAT_FLAG;
extern int _12CSTRING;
extern int _12CBYTES;
extern int _1high_address;
extern int _1data;
extern int _1free_list;

extern struct routine_list _00[];
int __stdcall
_2allocate(int);
int __stdcall
_2free(int);
int __stdcall
_2allocate_low(int);
int __stdcall
_2free_low(int);
int __stdcall
_2dos_interrupt(int, int);
int __stdcall
_2int_to_bytes(int);
int __stdcall
_2bytes_to_int(int);
int __stdcall
_2int_to_bits(int, int);
int __stdcall
_2bits_to_int(int);
int __stdcall
_2set_rand(int);
int __stdcall
_2use_vesa(int);
int __stdcall
_2crash_message(int);
int __stdcall
_2crash_file(int);
int __stdcall
_2crash_routine(int);
int __stdcall
_2tick_rate(int);
int __stdcall
_2get_vector(int);
int __stdcall
_2set_vector(int, int);
int __stdcall
_2lock_memory(int, int);
int __stdcall
_2atom_to_float64(int);
int __stdcall
_2atom_to_float32(int);
int __stdcall
_2float64_to_atom(int);
int __stdcall
_2float32_to_atom(int);
int __stdcall
_2allocate_string(int);
int __stdcall
_2register_block(int, int);
int __stdcall
_2unregister_block(int);
int __stdcall
_2check_all_blocks();
int __stdcall
_3open_dll(int);
int __stdcall
_3define_c_var(int, int);
int __stdcall
_3define_c_proc(int, int, int);
int __stdcall
_3define_c_func(int, int, int, int);
int __stdcall
_3call_back(int);
int __stdcall
_3free_console();
int __stdcall
_5sort(int);
int __stdcall
_5custom_sort(int, int);
int __stdcall
_6instance();
int __stdcall
_6sleep(int);
int __stdcall
_6reverse(int);
int __stdcall
_6sprint(int);
int _6pretty_out(int);
int _6cut_line(int);
int _6indent();
int _6show(int);
int _6rPrint(int);
int __stdcall
_6pretty_print(int, int, int);
int __stdcall
_6arccos(int);
int __stdcall
_6arcsin(int);
int __stdcall
_4seek(int, int);
int __stdcall
_4where(int);
int __stdcall
_4flush(int);
int __stdcall
_4lock_file(int, int, int);
int __stdcall
_4unlock_file(int, int);
int __stdcall
_4dir(int);
int __stdcall
_4current_dir();
int __stdcall
_4chdir(int);
int __stdcall
_4allow_break(int);
int __stdcall
_4check_break();
int _4default_dir(int);
int __stdcall
_4walk_dir(int, int, int);
int __stdcall
_7wait_key();
int _7get_ch();
int _7skip_blanks();
int _7escape_char(int);
int _7get_qchar();
int _7get_string();
int _7get_number();
int _7Get();
int __stdcall
_7get(int);
int __stdcall
_7value(int);
int __stdcall
_7prompt_number(int, int);
int __stdcall
_7prompt_string(int);
int __stdcall
_7get_bytes(int, int);
int __stdcall
_8draw_line(int, int);
int __stdcall
_8polygon(int, int, int);
int __stdcall
_8ellipse(int, int, int, int);
int __stdcall
_8graphics_mode(int);
int __stdcall
_8video_config();
int __stdcall
_8cursor(int);
int __stdcall
_8get_position();
int __stdcall
_8text_rows(int);
int __stdcall
_8wrap(int);
int __stdcall
_8scroll(int, int, int);
int __stdcall
_8text_color(int);
int __stdcall
_8bk_color(int);
int __stdcall
_8palette(int, int);
int __stdcall
_8all_palette(int);
int __stdcall
_8sound(int);
int _9get_word();
int _9get_dword();
int _9get_c_block(int);
int _9get_rgb(int);
int _9get_rgb_block(int, int);
int _9row_bytes(int, int);
int _9unpack(int, int, int, int);
int __stdcall
_9read_bitmap(int);
int __stdcall
_9display_image(int, int);
int __stdcall
_9save_image(int, int);
int __stdcall
_9get_display_page();
int __stdcall
_9set_display_page(int);
int __stdcall
_9get_active_page();
int __stdcall
_9set_active_page(int);
int __stdcall
_9get_screen_char(int, int);
int __stdcall
_9put_screen_char(int, int, int);
int __stdcall
_9display_text_image(int, int);
int __stdcall
_9save_text_image(int, int);
int _9putBmpFileHeader(int);
int _9putOneRowImage(int, int, int);
int _9putImage();
int __stdcall
_9get_all_palette();
int _9putColorTable(int, int);
int __stdcall
_9save_screen(int, int);
int _9putImage1(int);
int __stdcall
_9save_bitmap(int, int);
int __stdcall
_10lower(int);
int __stdcall
_10upper(int);
int _10qmatch(int, int);
int __stdcall
_10wildcard_match(int, int);
int __stdcall
_10wildcard_file(int, int);
int _11default_fatal(int);
int _11fatal(int);
int _11get1();
int _11get4();
int _11get_string();
int _11decompress(int);
int _11compress(int);
int _11put1(int);
int _11put4(int);
int _11putn(int);
int _11safe_seek(int);
int __stdcall
_11db_dump(int, int);
int __stdcall
_11check_free_list();
int _11db_allocate(int);
int _11db_free(int);
int __stdcall
_11db_create(int, int);
int __stdcall
_11db_open(int, int);
int __stdcall
_11db_select(int);
int __stdcall
_11db_close();
int _11table_find(int);
int __stdcall
_11db_select_table(int);
int __stdcall
_11db_create_table(int);
int __stdcall
_11db_delete_table(int);
int __stdcall
_11db_rename_table(int, int);
int __stdcall
_11db_table_list();
int _11key_value(int);
int __stdcall
_11db_find_key(int);
int __stdcall
_11db_insert(int, int);
int __stdcall
_11db_delete_record(int);
int __stdcall
_11db_replace_data(int, int);
int __stdcall
_11db_table_size();
int __stdcall
_11db_record_data(int);
int __stdcall
_11db_record_key(int);
int _11name_only(int);
int _11delete_whitespace(int);
int __stdcall
_11db_compress();
int __stdcall
_12set_return_linked_list(int);
int __stdcall
_12get_return_linked_list();
int __stdcall
_12peek_string(int);
int __stdcall
_12mystring(int);
int __stdcall
_12myarray(int);
int __stdcall
_12sequence_to_linked_list(int);
int __stdcall
_12free_linked_list(int);
int __stdcall
_12linked_list_to_sequence(int);
int __stdcall
_1get_version();
int _1binary_search(int, int);
int __stdcall
_1init();
int __stdcall
_1get_high_address();
int _1set_high_address(int);
int _1get_address(int, int);
int _1register_data(int);
int _1retval(int);
int __stdcall
_1length_of_data();
int __stdcall
_1is_free(int);
int __stdcall
_1access_free_list();
int __stdcall
_1generic_free(int, int);
int __stdcall
_1delete_linked_list(int);
int __stdcall
_1free_linked_lists(int, int, int);
int __stdcall
_1register_linked_list(int, int);
int __stdcall
_1new_linked_list(int, int);
int __stdcall
_1store_linked_list(int, int, int);
int __stdcall
_1access_linked_list(int);
int __stdcall
_1at_linked_list(int, int);
int __stdcall
_1free_linked_list_dll(int, int);
int __stdcall
_1length_linked_list(int);
int __stdcall
_1store_at_linked_list(int, int, int, int);
int __stdcall
_1eu_repeat(int, int);
int __stdcall
_1eu_mem_set(int, int, int, int);
int __stdcall
_1eu_mem_copy(int, int, int, int, int);
int __stdcall
_1eu_add(int, int);
int __stdcall
_1eu_subtract(int, int);
int __stdcall
_1eu_multiply(int, int);
int __stdcall
_1eu_divide(int, int);
int __stdcall
_1eu_negate(int);
int __stdcall
_1eu_not(int);
int __stdcall
_1eu_equals(int, int);
int __stdcall
_1eu_and(int, int);
int __stdcall
_1eu_or(int, int);
int __stdcall
_1eu_xor(int, int);
int __stdcall
_1eu_question_mark(int);
int __stdcall
_1eu_abort(int);
int __stdcall
_1eu_and_bits(int, int);
int __stdcall
_1eu_append(int, int);
int __stdcall
_1eu_arctan(int);
int __stdcall
_1eu_atom(int);
int __stdcall
_1eu_c_func(int, int);
int __stdcall
_1eu_c_proc(int, int);
int __stdcall
_1eu_call(int, int);
int __stdcall
_1eu_clear_screen();
int __stdcall
_1eu_close(int);
int __stdcall
_1eu_command_line();
int __stdcall
_1eu_compare(int, int);
int __stdcall
_1eu_concat(int, int);
int __stdcall
_1eu_cos(int);
int __stdcall
_1eu_date();
int __stdcall
_1eu_equal(int, int);
int __stdcall
_1eu_find_from(int, int, int);
int __stdcall
_1eu_floor(int);
int __stdcall
_1eu_integer_division(int, int);
int __stdcall
_1eu_get_key();
int __stdcall
_1eu_getc(int);
int __stdcall
_1eu_getenv(int);
int __stdcall
_1eu_gets(int);
int __stdcall
_1eu_integer(int);
int __stdcall
_1eu_length(int);
int __stdcall
_1eu_log(int);
int __stdcall
_1eu_machine_func(int, int);
int __stdcall
_1eu_machine_proc(int, int);
int __stdcall
_1eu_match_from(int, int, int);
int __stdcall
_1eu_not_bits(int);
int __stdcall
_1eu_object(int);
int __stdcall
_1eu_open(int, int);
int __stdcall
_1eu_open_str(int, int, int);
int __stdcall
_1eu_or_bits(int, int);
int __stdcall
_1eu_peek(int);
int __stdcall
_1eu_peek4s(int);
int __stdcall
_1eu_peek4u(int);
int __stdcall
_1eu_platform();
int __stdcall
_1eu_poke(int, int);
int __stdcall
_1eu_poke4(int, int);
int __stdcall
_1eu_position(int, int);
int __stdcall
_1eu_power(int, int);
int __stdcall
_1eu_prepend(int, int);
int __stdcall
_1eu_print(int, int);
int __stdcall
_1eu_printf(int, int, int);
int __stdcall
_1eu_puts(int, int);
int __stdcall
_1eu_rand(int);
int __stdcall
_1eu_remainder(int, int);
int __stdcall
_1eu_sequence(int);
int __stdcall
_1eu_sin(int);
int __stdcall
_1eu_sprintf(int, int);
int __stdcall
_1eu_sqrt(int);
int __stdcall
_1eu_subscript(int, int, int);
int __stdcall
_1eu_system(int, int);
int __stdcall
_1eu_system_exec(int, int);
int __stdcall
_1eu_tan(int);
int __stdcall
_1eu_time();
int __stdcall
_1eu_xor_bits(int, int);
int __stdcall
_1eu_allocate(int);
int __stdcall
_1eu_free(int);
int __stdcall
_1eu_int_to_bytes(int);
int __stdcall
_1eu_bytes_to_int(int);
int __stdcall
_1eu_int_to_bits(int, int);
int __stdcall
_1eu_bits_to_int(int);
int __stdcall
_1eu_set_rand(int);
int __stdcall
_1eu_crash_message(int);
int __stdcall
_1eu_crash_file(int);
int __stdcall
_1eu_atom_to_float64(int);
int __stdcall
_1eu_atom_to_float32(int);
int __stdcall
_1eu_float64_to_atom(int);
int __stdcall
_1eu_float32_to_atom(int);
int __stdcall
_1eu_allocate_string(int);
int __stdcall
_1eu_open_dll(int);
int __stdcall
_1eu_define_c_var(int, int);
int __stdcall
_1eu_define_c_proc(int, int, int);
int __stdcall
_1eu_define_c_func(int, int, int, int);
int __stdcall
_1eu_call_back(int);
int __stdcall
_1eu_free_console();
int __stdcall
_1eu_seek(int, int);
int __stdcall
_1eu_where(int);
int __stdcall
_1eu_flush(int);
int __stdcall
_1eu_lock_file(int, int, int);
int __stdcall
_1eu_unlock_file(int, int);
int __stdcall
_1eu_dir(int);
int __stdcall
_1eu_current_dir();
int __stdcall
_1eu_chdir(int);
int __stdcall
_1eu_allow_break(int);
int __stdcall
_1eu_check_break();
int __stdcall
_1eu_wait_key();
int __stdcall
_1eu_get(int);
int __stdcall
_1eu_value(int);
int __stdcall
_1eu_prompt_number(int, int);
int __stdcall
_1eu_prompt_string(int);
int __stdcall
_1eu_get_bytes(int, int);
int __stdcall
_1eu_video_config();
int __stdcall
_1eu_cursor(int);
int __stdcall
_1eu_get_position();
int __stdcall
_1eu_text_rows(int);
int __stdcall
_1eu_wrap(int);
int __stdcall
_1eu_scroll(int, int, int);
int __stdcall
_1eu_text_color(int);
int __stdcall
_1eu_bk_color(int);
int __stdcall
_1eu_read_bitmap(int);
int __stdcall
_1eu_get_screen_char(int, int);
int __stdcall
_1eu_put_screen_char(int, int, int);
int __stdcall
_1eu_display_text_image(int, int);
int __stdcall
_1eu_save_text_image(int, int);
int __stdcall
_1eu_save_bitmap(int, int);
int __stdcall
_1eu_instance();
int __stdcall
_1eu_sleep(int);
int __stdcall
_1eu_reverse(int);
int __stdcall
_1eu_sprint(int);
int __stdcall
_1eu_pretty_print(int, int, int);
int __stdcall
_1eu_arccos(int);
int __stdcall
_1eu_arcsin(int);
int __stdcall
_1eu_sort(int);
int __stdcall
_1eu_lower(int);
int __stdcall
_1eu_upper(int);
int __stdcall
_1eu_wildcard_match(int, int);
int __stdcall
_1eu_wildcard_file(int, int);
int __stdcall
_1eudb_dump(int, int);
int __stdcall
_1eudb_create(int, int);
int __stdcall
_1eudb_open(int, int);
int __stdcall
_1eudb_select(int);
int __stdcall
_1eudb_close();
int __stdcall
_1eudb_select_table(int);
int __stdcall
_1eudb_create_table(int);
int __stdcall
_1eudb_delete_table(int);
int __stdcall
_1eudb_rename_table(int, int);
int __stdcall
_1eudb_table_list();
int __stdcall
_1eudb_find_key(int);
int __stdcall
_1eudb_insert(int, int);
int __stdcall
_1eudb_delete_record(int);
int __stdcall
_1eudb_replace_data(int, int);
int __stdcall
_1eudb_table_size();
int __stdcall
_1eudb_record_data(int);
int __stdcall
_1eudb_record_key(int);
int __stdcall
_1eudb_compress();
int __stdcall
_1eu_call_func_std(int, int);
int __stdcall
_1eu_call_func_val(int, int);
int __stdcall
_1eu_call_func(int, int);
int __stdcall
_1eu_call_proc(int, int);
int __stdcall
_1eu_routine_id(int);
int __stdcall
_1eu_routine_id_str(int, int);
extern struct ns_list _01[];
extern int TraceOn;
extern object_ptr rhs_slice_target;
extern s1_ptr *assign_slice_seq;
extern object last_r_file_no;
extern void *last_r_file_ptr;
extern int in_from_keyb;
extern void *xstdin;
extern struct tcb *tcb;
extern int current_task;
extern void *winInstance;

