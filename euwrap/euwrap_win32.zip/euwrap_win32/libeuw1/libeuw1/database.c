// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int _11default_fatal(int _msg)
{
    int _1171 = 0;
    int _0, _1, _2;
    

    //     puts(SCREEN, "Fatal Database Error: " & msg & '\n')
    {
        int concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _msg;
        concat_list[2] = _1170;
        Concat_N((object_ptr)&_1171, concat_list, 3);
    }
    EPuts(1, _1171);

    //     ?1/0 -- to see call stack
    DeRefDS(_1171);
    RTFatal("divide by 0");
    StdPrint(1, _1171, 1);

    // end procedure
    DeRefDS(_msg);
    DeRef(_1171);
    return 0;
    ;
}


int _11fatal(int _msg)
{
    int _1175 = 0;
    int _0, _1, _2;
    

    //     call_proc(db_fatal_id, {msg})
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg);
    *((int *)(_2+4)) = _msg;
    _1175 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1175);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_11db_fatal_id].addr;
    Ref(*(int *)(_2+4));
    if (_00[_11db_fatal_id].convention) {
        (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4)
                             );
    }
    else {
        (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
    }

    // end procedure
    DeRefDSi(_msg);
    DeRefDS(_1175);
    return 0;
    ;
}


int _11get1()
{
    int _1176;
    int _0, _1, _2;
    

    //     return getc(current_db)
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1176 = wingetch();
        }
        else
            _1176 = getc(last_r_file_ptr);
    }
    else
        _1176 = getc(last_r_file_ptr);
    return _1176;
    ;
}


int _11get4()
{
    int _1181 = 0;
    int _0, _1, _2;
    

    //     poke(mem0, getc(current_db))
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1181 = wingetch();
        }
        else
            _1181 = getc(last_r_file_ptr);
    }
    else
        _1181 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_11mem0))
        poke_addr = (unsigned char *)_11mem0;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_11mem0)->dbl);
    *poke_addr = (unsigned char)_1181;

    //     poke(mem1, getc(current_db))
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1181 = wingetch();
        }
        else
            _1181 = getc(last_r_file_ptr);
    }
    else
        _1181 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_11mem1))
        poke_addr = (unsigned char *)_11mem1;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_11mem1)->dbl);
    *poke_addr = (unsigned char)_1181;

    //     poke(mem2, getc(current_db))
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1181 = wingetch();
        }
        else
            _1181 = getc(last_r_file_ptr);
    }
    else
        _1181 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_11mem2))
        poke_addr = (unsigned char *)_11mem2;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_11mem2)->dbl);
    *poke_addr = (unsigned char)_1181;

    //     poke(mem3, getc(current_db))
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1181 = wingetch();
        }
        else
            _1181 = getc(last_r_file_ptr);
    }
    else
        _1181 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_11mem3))
        poke_addr = (unsigned char *)_11mem3;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_11mem3)->dbl);
    *poke_addr = (unsigned char)_1181;

    //     return peek4u(mem0)
    if (IS_ATOM_INT(_11mem0)) {
        _1181 = *(unsigned long *)_11mem0;
        if ((unsigned)_1181 > (unsigned)MAXINT)
            _1181 = NewDouble((double)(unsigned long)_1181);
    }
    else {
        _1181 = *(unsigned long *)(unsigned long)(DBL_PTR(_11mem0)->dbl);
        if ((unsigned)_1181 > (unsigned)MAXINT)
            _1181 = NewDouble((double)(unsigned long)_1181);
    }
    return _1181;
    ;
}


int _11get_string()
{
    int _s = 0;
    int _c;
    int _0, _1, _2;
    

    //     s = ""
    RefDS(_202);
    _s = _202;

    //     while TRUE do
L1:

    // 	c = getc(current_db)
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c = wingetch();
        }
        else
            _c = getc(last_r_file_ptr);
    }
    else
        _c = getc(last_r_file_ptr);

    // 	if c = -1 then
    if (_c != -1)
        goto L2;

    // 	    fatal("string is missing 0 terminator")
    RefDS(_1188);
    _11fatal(_1188);
    goto L3;
L2:

    // 	elsif c = 0 then
    if (_c != 0)
        goto L4;

    // 	    exit
    goto L5;
L4:
L3:

    // 	s &= c
    Append(&_s, _s, _c);

    //     end while
    goto L1;
L5:

    //     return s
    return _s;
    ;
}


int _11decompress(int _c)
{
    int _s = 0;
    int _len;
    int _1245 = 0;
    int _1246 = 0;
    int _1244;
    int _1243;
    int _1215 = 0;
    int _1209;
    int _1234;
    int _1235 = 0;
    int _0, _1, _2;
    

    //     if c = 0 then
    if (_c != 0)
        goto L1;

    // 	c = getc(current_db)
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c = wingetch();
        }
        else
            _c = getc(last_r_file_ptr);
    }
    else
        _c = getc(last_r_file_ptr);

    // 	if c < I2B then
    if (_c >= 249)
        goto L2;

    // 	    return c + MIN1B
    _1209 = _c + -9;
    return _1209;
L2:
L1:

    //     if c = I2B then
    if (_c != 249)
        goto L3;

    // 	return getc(current_db) + 
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1209 = wingetch();
        }
        else
            _1209 = getc(last_r_file_ptr);
    }
    else
        _1209 = getc(last_r_file_ptr);
    DeRef(_1215);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1215 = wingetch();
        }
        else
            _1215 = getc(last_r_file_ptr);
    }
    else
        _1215 = getc(last_r_file_ptr);
    _1215 = 256 * _1215;
    _1215 = _1209 + _1215;
    _1215 = _1215 + _11MIN2B;
    if ((long)((unsigned long)_1215 + (unsigned long)HIGH_BITS) >= 0) 
        _1215 = NewDouble((double)_1215);
    DeRef(_s);
    DeRef(_1245);
    DeRef(_1246);
    DeRef(_1235);
    return _1215;
    goto L4;
L3:

    //     elsif c = I3B then
    if (_c != 250)
        goto L5;

    // 	return getc(current_db) + 
    DeRef(_1215);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1215 = wingetch();
        }
        else
            _1215 = getc(last_r_file_ptr);
    }
    else
        _1215 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1209 = wingetch();
        }
        else
            _1209 = getc(last_r_file_ptr);
    }
    else
        _1209 = getc(last_r_file_ptr);
    _1209 = 256 * _1209;
    _1209 = _1215 + _1209;
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1215 = wingetch();
        }
        else
            _1215 = getc(last_r_file_ptr);
    }
    else
        _1215 = getc(last_r_file_ptr);
    _1215 = 65536 * _1215;
    _1215 = _1209 + _1215;
    _1215 = _1215 + _11MIN3B;
    if ((long)((unsigned long)_1215 + (unsigned long)HIGH_BITS) >= 0) 
        _1215 = NewDouble((double)_1215);
    DeRef(_s);
    DeRef(_1245);
    DeRef(_1246);
    DeRef(_1235);
    return _1215;
    goto L4;
L5:

    //     elsif c = I4B then
    if (_c != 251)
        goto L6;

    // 	return get4() + MIN4B
    _0 = _1215;
    _1215 = _11get4();
    DeRef(_0);
    _0 = _1215;
    if (IS_ATOM_INT(_1215) && IS_ATOM_INT(_11MIN4B)) {
        _1215 = _1215 + _11MIN4B;
        if ((long)((unsigned long)_1215 + (unsigned long)HIGH_BITS) >= 0) 
            _1215 = NewDouble((double)_1215);
    }
    else {
        if (IS_ATOM_INT(_1215)) {
            _1215 = NewDouble((double)_1215 + DBL_PTR(_11MIN4B)->dbl);
        }
        else {
            if (IS_ATOM_INT(_11MIN4B)) {
                _1215 = NewDouble(DBL_PTR(_1215)->dbl + (double)_11MIN4B);
            }
            else
                _1215 = NewDouble(DBL_PTR(_1215)->dbl + DBL_PTR(_11MIN4B)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_s);
    DeRef(_1245);
    DeRef(_1246);
    DeRef(_1235);
    return _1215;
    goto L4;
L6:

    //     elsif c = F4B then
    if (_c != 252)
        goto L7;

    // 	return float32_to_atom({getc(current_db), getc(current_db), 
    DeRef(_1215);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1215 = wingetch();
        }
        else
            _1215 = getc(last_r_file_ptr);
    }
    else
        _1215 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1209 = wingetch();
        }
        else
            _1209 = getc(last_r_file_ptr);
    }
    else
        _1209 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1234 = wingetch();
        }
        else
            _1234 = getc(last_r_file_ptr);
    }
    else
        _1234 = getc(last_r_file_ptr);
    DeRef(_1235);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1235 = wingetch();
        }
        else
            _1235 = getc(last_r_file_ptr);
    }
    else
        _1235 = getc(last_r_file_ptr);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1215;
    *((int *)(_2+8)) = _1209;
    *((int *)(_2+12)) = _1234;
    *((int *)(_2+16)) = _1235;
    _1235 = MAKE_SEQ(_1);
    RefDS(_1235);
    _0 = _1235;
    _1235 = _2float32_to_atom(_1235);
    DeRefDSi(_0);
    DeRef(_s);
    DeRef(_1245);
    DeRef(_1246);
    return _1235;
    goto L4;
L7:

    //     elsif c = F8B then
    if (_c != 253)
        goto L8;

    // 	return float64_to_atom({getc(current_db), getc(current_db),
    DeRef(_1235);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1235 = wingetch();
        }
        else
            _1235 = getc(last_r_file_ptr);
    }
    else
        _1235 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1234 = wingetch();
        }
        else
            _1234 = getc(last_r_file_ptr);
    }
    else
        _1234 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1209 = wingetch();
        }
        else
            _1209 = getc(last_r_file_ptr);
    }
    else
        _1209 = getc(last_r_file_ptr);
    DeRef(_1215);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1215 = wingetch();
        }
        else
            _1215 = getc(last_r_file_ptr);
    }
    else
        _1215 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1243 = wingetch();
        }
        else
            _1243 = getc(last_r_file_ptr);
    }
    else
        _1243 = getc(last_r_file_ptr);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1244 = wingetch();
        }
        else
            _1244 = getc(last_r_file_ptr);
    }
    else
        _1244 = getc(last_r_file_ptr);
    DeRef(_1245);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1245 = wingetch();
        }
        else
            _1245 = getc(last_r_file_ptr);
    }
    else
        _1245 = getc(last_r_file_ptr);
    DeRef(_1246);
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1246 = wingetch();
        }
        else
            _1246 = getc(last_r_file_ptr);
    }
    else
        _1246 = getc(last_r_file_ptr);
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1235;
    *((int *)(_2+8)) = _1234;
    *((int *)(_2+12)) = _1209;
    *((int *)(_2+16)) = _1215;
    *((int *)(_2+20)) = _1243;
    *((int *)(_2+24)) = _1244;
    *((int *)(_2+28)) = _1245;
    *((int *)(_2+32)) = _1246;
    _1246 = MAKE_SEQ(_1);
    RefDS(_1246);
    _0 = _1246;
    _1246 = _2float64_to_atom(_1246);
    DeRefDSi(_0);
    DeRef(_s);
    return _1246;
    goto L4;
L8:

    // 	if c = S1B then
    if (_c != 254)
        goto L9;

    // 	    len = getc(current_db)
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _len = wingetch();
        }
        else
            _len = getc(last_r_file_ptr);
    }
    else
        _len = getc(last_r_file_ptr);
    goto LA;
L9:

    // 	    len = get4()
    _len = _11get4();
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }
LA:

    // 	s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 	for i = 1 to len do
    DeRef(_1246);
    _1246 = _len;
    { int _i;
        _i = 1;
LB:
        if (_i > _1246)
            goto LC;

        // 	    c = getc(current_db)
        if (_11current_db != last_r_file_no) {
            last_r_file_ptr = which_file(_11current_db, EF_READ);
            last_r_file_no = _11current_db;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c = wingetch();
            }
            else
                _c = getc(last_r_file_ptr);
        }
        else
            _c = getc(last_r_file_ptr);

        // 	    if c < I2B then
        if (_c >= 249)
            goto LD;

        // 		s[i] = c + MIN1B
        DeRef(_1245);
        _1245 = _c + -9;
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _1245;
        DeRef(_1);
        goto LE;
LD:

        // 		s[i] = decompress(c)
        DeRef(_1245);
        _1245 = _c;
        _1245 = _11decompress(_1245);
        Ref(_1245);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _1245;
        DeRef(_1);
LE:

        // 	end for
        _i = _i + 1;
        goto LB;
LC:
        ;
    }

    // 	return s
    DeRef(_1245);
    DeRef(_1246);
    DeRef(_1215);
    DeRef(_1235);
    return _s;
L4:
    ;
}


int _11compress(int _x)
{
    int _x4 = 0;
    int _s = 0;
    int _1262 = 0;
    int _1279 = 0;
    int _1259 = 0;
    int _0, _1, _2;
    

    //     if integer(x) then
    if (IS_ATOM_INT(_x))
        _1259 = 1;
    else if (IS_ATOM_DBL(_x))
        _1259 = IS_ATOM_INT(DoubleToInt(_x));
    else
        _1259 = 0;
    if (_1259 == 0)
        goto L1;

    // 	if x >= MIN1B and x <= MAX1B then
    if (IS_ATOM_INT(_x)) {
        _1259 = (_x >= -9);
    }
    else {
        _1259 = binary_op(GREATEREQ, _x, -9);
    }
    if (IS_ATOM_INT(_1259)) {
        if (_1259 == 0) {
            goto L2;
        }
    }
    else {
        if (DBL_PTR(_1259)->dbl == 0.0) {
            goto L2;
        }
    }
    if (IS_ATOM_INT(_x)) {
        _1262 = (_x <= 239);
    }
    else {
        _1262 = binary_op(LESSEQ, _x, 239);
    }
L3:
    if (_1262 == 0) {
        goto L2;
    }
    else {
        if (!IS_ATOM_INT(_1262) && DBL_PTR(_1262)->dbl == 0.0)
            goto L2;
    }

    // 	    return {x - MIN1B}
    DeRef(_1262);
    if (IS_ATOM_INT(_x)) {
        _1262 = _x - -9;
        if ((long)((unsigned long)_1262 +(unsigned long) HIGH_BITS) >= 0)
            _1262 = NewDouble((double)_1262);
    }
    else {
        _1262 = binary_op(MINUS, _x, -9);
    }
    _0 = _1262;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_1262);
    *((int *)(_2+4)) = _1262;
    _1262 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_s);
    DeRef(_1279);
    DeRef(_1259);
    return _1262;
    goto L4;
L2:

    // 	elsif x >= MIN2B and x <= MAX2B then
    DeRef(_1262);
    if (IS_ATOM_INT(_x)) {
        _1262 = (_x >= _11MIN2B);
    }
    else {
        _1262 = binary_op(GREATEREQ, _x, _11MIN2B);
    }
    if (IS_ATOM_INT(_1262)) {
        if (_1262 == 0) {
            goto L5;
        }
    }
    else {
        if (DBL_PTR(_1262)->dbl == 0.0) {
            goto L5;
        }
    }
    DeRef(_1259);
    if (IS_ATOM_INT(_x)) {
        _1259 = (_x <= 32767);
    }
    else {
        _1259 = binary_op(LESSEQ, _x, 32767);
    }
L6:
    if (_1259 == 0) {
        goto L5;
    }
    else {
        if (!IS_ATOM_INT(_1259) && DBL_PTR(_1259)->dbl == 0.0)
            goto L5;
    }

    // 	    x -= MIN2B
    _0 = _x;
    if (IS_ATOM_INT(_x)) {
        _x = _x - _11MIN2B;
        if ((long)((unsigned long)_x +(unsigned long) HIGH_BITS) >= 0)
            _x = NewDouble((double)_x);
    }
    else {
        _x = binary_op(MINUS, _x, _11MIN2B);
    }
    DeRef(_0);

    // 	    return {I2B, and_bits(x, #FF), floor(x / #100)}
    DeRef(_1259);
    if (IS_ATOM_INT(_x)) {
        _1259 = (_x & 255);
    }
    else {
        _1259 = binary_op(AND_BITS, _x, 255);
    }
    DeRef(_1262);
    if (IS_ATOM_INT(_x)) {
        if (256 > 0 && _x >= 0) {
            _1262 = _x / 256;
        }
        else {
            temp_dbl = floor((double)_x / (double)256);
            if (_x != MININT)
                _1262 = (long)temp_dbl;
            else
                _1262 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x, 256);
        _1262 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _0 = _1262;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    Ref(_1259);
    *((int *)(_2+8)) = _1259;
    Ref(_1262);
    *((int *)(_2+12)) = _1262;
    _1262 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_s);
    DeRef(_1279);
    DeRef(_1259);
    return _1262;
    goto L4;
L5:

    // 	elsif x >= MIN3B and x <= MAX3B then
    DeRef(_1262);
    if (IS_ATOM_INT(_x)) {
        _1262 = (_x >= _11MIN3B);
    }
    else {
        _1262 = binary_op(GREATEREQ, _x, _11MIN3B);
    }
    if (IS_ATOM_INT(_1262)) {
        if (_1262 == 0) {
            goto L7;
        }
    }
    else {
        if (DBL_PTR(_1262)->dbl == 0.0) {
            goto L7;
        }
    }
    DeRef(_1259);
    if (IS_ATOM_INT(_x)) {
        _1259 = (_x <= 8388607);
    }
    else {
        _1259 = binary_op(LESSEQ, _x, 8388607);
    }
L8:
    if (_1259 == 0) {
        goto L7;
    }
    else {
        if (!IS_ATOM_INT(_1259) && DBL_PTR(_1259)->dbl == 0.0)
            goto L7;
    }

    // 	    x -= MIN3B
    _0 = _x;
    if (IS_ATOM_INT(_x)) {
        _x = _x - _11MIN3B;
        if ((long)((unsigned long)_x +(unsigned long) HIGH_BITS) >= 0)
            _x = NewDouble((double)_x);
    }
    else {
        _x = binary_op(MINUS, _x, _11MIN3B);
    }
    DeRef(_0);

    // 	    return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}
    DeRef(_1259);
    if (IS_ATOM_INT(_x)) {
        _1259 = (_x & 255);
    }
    else {
        _1259 = binary_op(AND_BITS, _x, 255);
    }
    DeRef(_1262);
    if (IS_ATOM_INT(_x)) {
        if (256 > 0 && _x >= 0) {
            _1262 = _x / 256;
        }
        else {
            temp_dbl = floor((double)_x / (double)256);
            if (_x != MININT)
                _1262 = (long)temp_dbl;
            else
                _1262 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x, 256);
        _1262 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _0 = _1262;
    if (IS_ATOM_INT(_1262)) {
        _1262 = (_1262 & 255);
    }
    else {
        _1262 = binary_op(AND_BITS, _1262, 255);
    }
    DeRef(_0);
    DeRef(_1279);
    if (IS_ATOM_INT(_x)) {
        if (65536 > 0 && _x >= 0) {
            _1279 = _x / 65536;
        }
        else {
            temp_dbl = floor((double)_x / (double)65536);
            if (_x != MININT)
                _1279 = (long)temp_dbl;
            else
                _1279 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x, 65536);
        _1279 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _0 = _1279;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    Ref(_1259);
    *((int *)(_2+8)) = _1259;
    Ref(_1262);
    *((int *)(_2+12)) = _1262;
    Ref(_1279);
    *((int *)(_2+16)) = _1279;
    _1279 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_s);
    DeRef(_1262);
    DeRef(_1259);
    return _1279;
    goto L4;
L7:

    // 	    return I4B & int_to_bytes(x-MIN4B)    
    DeRef(_1279);
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_11MIN4B)) {
        _1279 = _x - _11MIN4B;
        if ((long)((unsigned long)_1279 +(unsigned long) HIGH_BITS) >= 0)
            _1279 = NewDouble((double)_1279);
    }
    else {
        _1279 = binary_op(MINUS, _x, _11MIN4B);
    }
    Ref(_1279);
    _0 = _1279;
    _1279 = _2int_to_bytes(_1279);
    DeRef(_0);
    Prepend(&_1279, _1279, 251);
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_s);
    DeRef(_1262);
    DeRef(_1259);
    return _1279;
L9:
    goto L4;
L1:

    //     elsif atom(x) then
    DeRef(_1279);
    _1279 = IS_ATOM(_x);
    if (_1279 == 0)
        goto LA;

    // 	x4 = atom_to_float32(x)
    Ref(_x);
    _0 = _x4;
    _x4 = _2atom_to_float32(_x);
    DeRefi(_0);

    // 	if x = float32_to_atom(x4) then
    RefDS(_x4);
    _1279 = _2float32_to_atom(_x4);
    if (binary_op_a(NOTEQ, _x, _1279))
        goto LB;

    // 	    return F4B & x4
    Prepend(&_1279, _x4, 252);
    DeRef(_x);
    DeRefDSi(_x4);
    DeRef(_s);
    DeRef(_1262);
    DeRef(_1259);
    return _1279;
    goto L4;
LB:

    // 	    return F8B & atom_to_float64(x)
    Ref(_x);
    _0 = _1279;
    _1279 = _2atom_to_float64(_x);
    DeRef(_0);
    Prepend(&_1279, _1279, 253);
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_s);
    DeRef(_1262);
    DeRef(_1259);
    return _1279;
LC:
    goto L4;
LA:

    // 	if length(x) <= 255 then
    DeRef(_1279);
    _1279 = SEQ_PTR(_x)->length;
    if (_1279 > 255)
        goto LD;

    // 	    s = {S1B, length(x)}
    _1279 = SEQ_PTR(_x)->length;
    DeRef(_s);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _1279;
    _s = MAKE_SEQ(_1);
    goto LE;
LD:

    // 	    s = S4B & int_to_bytes(length(x))
    DeRef(_1279);
    _1279 = SEQ_PTR(_x)->length;
    _1279 = _2int_to_bytes(_1279);
    Prepend(&_s, _1279, 255);
LE:

    // 	for i = 1 to length(x) do
    DeRef(_1279);
    _1279 = SEQ_PTR(_x)->length;
    { int _i;
        _i = 1;
LF:
        if (_i > _1279)
            goto L10;

        // 	    s &= compress(x[i])
        DeRef(_1262);
        _2 = (int)SEQ_PTR(_x);
        _1262 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1262);
        Ref(_1262);
        _0 = _1262;
        _1262 = _11compress(_1262);
        DeRef(_0);
        Concat((object_ptr)&_s, _s, (s1_ptr)_1262);

        // 	end for
        _i = _i + 1;
        goto LF;
L10:
        ;
    }

    // 	return s
    DeRef(_x);
    DeRefi(_x4);
    DeRef(_1262);
    DeRef(_1279);
    DeRef(_1259);
    return _s;
L4:
    ;
}


int _11put1(int _x)
{
    int _0, _1, _2;
    

    //     puts(current_db, x)
    EPuts(_11current_db, _x);

    // end procedure
    return 0;
    ;
}


int _11put4(int _x)
{
    int _1303 = 0;
    int _0, _1, _2;
    

    //     poke4(mem0, x) -- faster than doing divides etc.
    if (IS_ATOM_INT(_11mem0))
        poke4_addr = (unsigned long *)_11mem0;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11mem0)->dbl);
    if (IS_ATOM_INT(_x)) {
        *poke4_addr = (unsigned long)_x;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x)->dbl;
    }

    //     puts(current_db, peek(memseq))
    _1 = (int)SEQ_PTR(_11memseq);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1303 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }
    EPuts(_11current_db, _1303);

    // end procedure
    DeRef(_x);
    DeRefDSi(_1303);
    return 0;
    ;
}


int _11putn(int _s)
{
    int _0, _1, _2;
    

    //     puts(current_db, s)
    EPuts(_11current_db, _s);

    // end procedure
    DeRefDS(_s);
    return 0;
    ;
}


int _11safe_seek(int _pos)
{
    int _1304 = 0;
    int _0, _1, _2;
    

    //     if seek(current_db, pos) != 0 then
    Ref(_pos);
    _1304 = _4seek(_11current_db, _pos);
    if (_1304 == 0)
        goto L1;

    // 	fatal(sprintf("seek to position %d failed!\n", pos))
    _1304 = EPrintf(-9999999, _1306, _pos);
    RefDS(_1304);
    _11fatal(_1304);
L1:

    // end procedure
    DeRef(_pos);
    DeRef(_1304);
    return 0;
    ;
}


int __stdcall
_11db_dump(int _fn, int _low_level_too)
{
    int _magic;
    int _minor;
    int _major;
    int _tables = 0;
    int _ntables = 0;
    int _tname = 0;
    int _trecords = 0;
    int _t_header = 0;
    int _tnrecs = 0;
    int _key_ptr = 0;
    int _data_ptr = 0;
    int _size = 0;
    int _addr = 0;
    int _tindex = 0;
    int _key = 0;
    int _data = 0;
    int _c;
    int _n;
    int _tblocks;
    int _a = 0;
    int _1342 = 0;
    int _1348 = 0;
    int _1333 = 0;
    int _1308 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }
    if (!IS_ATOM_INT(_low_level_too)) {
        _1 = (long)(DBL_PTR(_low_level_too)->dbl);
        DeRefDS(_low_level_too);
        _low_level_too = _1;
    }

    //     if low_level_too then
    if (_low_level_too == 0)
        goto L1;

    // 	safe_seek(0)
    _11safe_seek(0);

    // 	a = 0
    _a = 0;

    // 	while TRUE do
L2:

    // 	    c = getc(current_db)
    if (_11current_db != last_r_file_no) {
        last_r_file_ptr = which_file(_11current_db, EF_READ);
        last_r_file_no = _11current_db;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c = wingetch();
        }
        else
            _c = getc(last_r_file_ptr);
    }
    else
        _c = getc(last_r_file_ptr);

    // 	    if c = -1 then
    if (_c != -1)
        goto L3;

    // 		exit
    goto L4;
L3:

    // 	    if remainder(a, 10) = 0 then
    DeRef(_1308);
    if (IS_ATOM_INT(_a)) {
        _1308 = (_a % 10);
    }
    else {
        temp_d.dbl = (double)10;
        _1308 = Dremainder(DBL_PTR(_a), &temp_d);
    }
    if (binary_op_a(NOTEQ, _1308, 0))
        goto L5;

    // 		printf(SCREEN, "\n%d: ", a)
    EPrintf(1, _1312, _a);
L5:

    // 	    printf(SCREEN, "%d, ", c)
    EPrintf(1, _1313, _c);

    // 	    a += 1
    _0 = _a;
    if (IS_ATOM_INT(_a)) {
        _a = _a + 1;
        if (_a > MAXINT)
            _a = NewDouble((double)_a);
    }
    else
        _a = binary_op(PLUS, 1, _a);
    DeRef(_0);

    // 	end while
    goto L2;
L4:
L1:

    //     puts(fn, '\n')
    EPuts(_fn, 10);

    //     safe_seek(0)
    _11safe_seek(0);

    //     magic = get1()
    _magic = _11get1();

    //     if magic != DB_MAGIC then
    if (_magic == 77)
        goto L6;

    // 	puts(fn, "This is not a Euphoria Database file\n")
    EPuts(_fn, _1317);

    // 	return
    DeRef(_tables);
    DeRef(_ntables);
    DeRef(_tname);
    DeRef(_trecords);
    DeRef(_t_header);
    DeRef(_tnrecs);
    DeRef(_key_ptr);
    DeRef(_data_ptr);
    DeRef(_size);
    DeRef(_addr);
    DeRef(_tindex);
    DeRef(_key);
    DeRef(_data);
    DeRef(_a);
    DeRef(_1342);
    DeRef(_1348);
    DeRef(_1333);
    DeRef(_1308);
    return 0;
L6:

    //     major = get1()
    _major = _11get1();

    //     minor = get1()
    _minor = _11get1();

    //     printf(fn, "Euphoria Database System Version %d.%d\n\n", {major, minor})
    DeRef(_1308);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _major;
    ((int *)_2)[2] = _minor;
    _1308 = MAKE_SEQ(_1);
    EPrintf(_fn, _1320, _1308);

    //     tables = get4()
    _0 = _tables;
    _tables = _11get4();
    DeRef(_0);

    //     safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    //     ntables = get4()
    _0 = _ntables;
    _ntables = _11get4();
    DeRef(_0);

    //     printf(fn, "The \"%s\" database has %d table", 
    DeRefDSi(_1308);
    _1308 = find(_11current_db, _11db_file_nums);
    _2 = (int)SEQ_PTR(_11db_names);
    _1308 = (int)*(((s1_ptr)_2)->base + _1308);
    Ref(_1308);
    _0 = _1308;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1308;
    Ref(_1308);
    ((int *)_2)[2] = _ntables;
    Ref(_ntables);
    _1308 = MAKE_SEQ(_1);
    DeRef(_0);
    EPrintf(_fn, _1324, _1308);

    //     if ntables = 1 then
    if (binary_op_a(NOTEQ, _ntables, 1))
        goto L7;

    // 	puts(fn, "\n")
    EPuts(_fn, _1329);
    goto L8;
L7:

    // 	puts(fn, "s\n")
    EPuts(_fn, _1330);
L8:

    //     t_header = where(current_db)
    _0 = _t_header;
    _t_header = _4where(_11current_db);
    DeRef(_0);

    //     for t = 1 to ntables do
    Ref(_ntables);
    DeRef(_1308);
    _1308 = _ntables;
    { int _t;
        _t = 1;
L9:
        if (binary_op_a(GREATER, _t, _1308))
            goto LA;

        // 	tname = get4()
        _0 = _tname;
        _tname = _11get4();
        DeRef(_0);

        // 	tnrecs = get4() -- ignore
        _0 = _tnrecs;
        _tnrecs = _11get4();
        DeRef(_0);

        // 	tblocks = get4()
        _tblocks = _11get4();
        if (!IS_ATOM_INT(_tblocks)) {
            _1 = (long)(DBL_PTR(_tblocks)->dbl);
            DeRefDS(_tblocks);
            _tblocks = _1;
        }

        // 	tindex = get4()
        _0 = _tindex;
        _tindex = _11get4();
        DeRef(_0);

        // 	safe_seek(tname)
        Ref(_tname);
        _11safe_seek(_tname);

        // 	printf(fn, "\ntable \"%s\":\n", {get_string()})
        _0 = _1333;
        _1333 = _11get_string();
        DeRef(_0);
        _0 = _1333;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_1333);
        *((int *)(_2+4)) = _1333;
        _1333 = MAKE_SEQ(_1);
        DeRefDSi(_0);
        EPrintf(_fn, _1337, _1333);

        // 	for b = 1 to tblocks do
        DeRefDS(_1333);
        _1333 = _tblocks;
        { int _b;
            _b = 1;
LB:
            if (_b > _1333)
                goto LC;

            // 	    printf(fn, "\nblock #%d\n\n", b)
            EPrintf(_fn, _1341, _b);

            // 	    safe_seek(tindex+(b-1)*8)
            DeRef(_1342);
            _1342 = _b - 1;
            if (_1342 == (short)_1342)
                _1342 = _1342 * 8;
            else
                _1342 = NewDouble(_1342 * (double)8);
            _0 = _1342;
            if (IS_ATOM_INT(_tindex) && IS_ATOM_INT(_1342)) {
                _1342 = _tindex + _1342;
                if ((long)((unsigned long)_1342 + (unsigned long)HIGH_BITS) >= 0) 
                    _1342 = NewDouble((double)_1342);
            }
            else {
                if (IS_ATOM_INT(_tindex)) {
                    _1342 = NewDouble((double)_tindex + DBL_PTR(_1342)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_1342)) {
                        _1342 = NewDouble(DBL_PTR(_tindex)->dbl + (double)_1342);
                    }
                    else
                        _1342 = NewDouble(DBL_PTR(_tindex)->dbl + DBL_PTR(_1342)->dbl);
                }
            }
            DeRef(_0);
            Ref(_1342);
            _11safe_seek(_1342);

            // 	    tnrecs = get4()
            _0 = _tnrecs;
            _tnrecs = _11get4();
            DeRef(_0);

            // 	    trecords = get4()
            _0 = _trecords;
            _trecords = _11get4();
            DeRef(_0);

            // 	    for r = 1 to tnrecs do
            Ref(_tnrecs);
            DeRef(_1342);
            _1342 = _tnrecs;
            { int _r;
                _r = 1;
LD:
                if (binary_op_a(GREATER, _r, _1342))
                    goto LE;

                // 		safe_seek(trecords+(r-1)*4)
                DeRef(_1348);
                if (IS_ATOM_INT(_r)) {
                    _1348 = _r - 1;
                    if ((long)((unsigned long)_1348 +(unsigned long) HIGH_BITS) >= 0)
                        _1348 = NewDouble((double)_1348);
                }
                else {
                    _1348 = NewDouble(DBL_PTR(_r)->dbl - (double)1);
                }
                _0 = _1348;
                if (IS_ATOM_INT(_1348)) {
                    if (_1348 == (short)_1348)
                        _1348 = _1348 * 4;
                    else
                        _1348 = NewDouble(_1348 * (double)4);
                }
                else {
                    _1348 = NewDouble(DBL_PTR(_1348)->dbl * (double)4);
                }
                DeRef(_0);
                _0 = _1348;
                if (IS_ATOM_INT(_trecords) && IS_ATOM_INT(_1348)) {
                    _1348 = _trecords + _1348;
                    if ((long)((unsigned long)_1348 + (unsigned long)HIGH_BITS) >= 0) 
                        _1348 = NewDouble((double)_1348);
                }
                else {
                    if (IS_ATOM_INT(_trecords)) {
                        _1348 = NewDouble((double)_trecords + DBL_PTR(_1348)->dbl);
                    }
                    else {
                        if (IS_ATOM_INT(_1348)) {
                            _1348 = NewDouble(DBL_PTR(_trecords)->dbl + (double)_1348);
                        }
                        else
                            _1348 = NewDouble(DBL_PTR(_trecords)->dbl + DBL_PTR(_1348)->dbl);
                    }
                }
                DeRef(_0);
                Ref(_1348);
                _11safe_seek(_1348);

                // 		key_ptr = get4()
                _0 = _key_ptr;
                _key_ptr = _11get4();
                DeRef(_0);

                // 		safe_seek(key_ptr)
                Ref(_key_ptr);
                _11safe_seek(_key_ptr);

                // 		data_ptr = get4()
                _0 = _data_ptr;
                _data_ptr = _11get4();
                DeRef(_0);

                // 		key = decompress(0)
                _0 = _key;
                _key = _11decompress(0);
                DeRef(_0);

                // 		puts(fn, "  key: ")
                EPuts(_fn, _1354);

                // 		pretty_print(fn, key, {1, 2, 8})
                Ref(_key);
                RefDS(_1355);
                _6pretty_print(_fn, _key, _1355);

                // 		puts(fn, '\n')
                EPuts(_fn, 10);

                // 		safe_seek(data_ptr)
                Ref(_data_ptr);
                _11safe_seek(_data_ptr);

                // 		data = decompress(0)
                _0 = _data;
                _data = _11decompress(0);
                DeRef(_0);

                // 		puts(fn, "  data: ")
                EPuts(_fn, _1357);

                // 		pretty_print(fn, data, {1, 2, 9})
                Ref(_data);
                RefDS(_1358);
                _6pretty_print(_fn, _data, _1358);

                // 		puts(fn, "\n\n")
                EPuts(_fn, _1359);

                // 	    end for
                _0 = _r;
                if (IS_ATOM_INT(_r)) {
                    _r = _r + 1;
                    if ((long)((unsigned long)_r +(unsigned long) HIGH_BITS) >= 0) 
                        _r = NewDouble((double)_r);
                }
                else {
                    _r = binary_op_a(PLUS, _r, 1);
                }
                DeRef(_0);
                goto LD;
LE:
                ;
                DeRef(_r);
            }

            // 	end for
            _b = _b + 1;
            goto LB;
LC:
            ;
        }

        // 	t_header += SIZEOF_TABLE_HEADER
        _0 = _t_header;
        if (IS_ATOM_INT(_t_header)) {
            _t_header = _t_header + 16;
            if ((long)((unsigned long)_t_header + (unsigned long)HIGH_BITS) >= 0) 
                _t_header = NewDouble((double)_t_header);
        }
        else {
            _t_header = NewDouble(DBL_PTR(_t_header)->dbl + (double)16);
        }
        DeRef(_0);

        // 	safe_seek(t_header)
        Ref(_t_header);
        _11safe_seek(_t_header);

        //     end for
        _0 = _t;
        if (IS_ATOM_INT(_t)) {
            _t = _t + 1;
            if ((long)((unsigned long)_t +(unsigned long) HIGH_BITS) >= 0) 
                _t = NewDouble((double)_t);
        }
        else {
            _t = binary_op_a(PLUS, _t, 1);
        }
        DeRef(_0);
        goto L9;
LA:
        ;
        DeRef(_t);
    }

    //     puts(fn, "List of free blocks:\n")
    EPuts(_fn, _1361);

    //     safe_seek(FREE_COUNT)
    _11safe_seek(7);

    //     n = get4()
    _n = _11get4();
    if (!IS_ATOM_INT(_n)) {
        _1 = (long)(DBL_PTR(_n)->dbl);
        DeRefDS(_n);
        _n = _1;
    }

    //     safe_seek(get4())
    _0 = _1348;
    _1348 = _11get4();
    DeRef(_0);
    Ref(_1348);
    _11safe_seek(_1348);

    //     for i = 1 to n do
    DeRef(_1348);
    _1348 = _n;
    { int _i;
        _i = 1;
LF:
        if (_i > _1348)
            goto L10;

        // 	addr = get4()
        _0 = _addr;
        _addr = _11get4();
        DeRef(_0);

        // 	size = get4()
        _0 = _size;
        _size = _11get4();
        DeRef(_0);

        // 	printf(fn, "%d: %d bytes\n", {addr, size})
        DeRef(_1342);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _addr;
        Ref(_addr);
        ((int *)_2)[2] = _size;
        Ref(_size);
        _1342 = MAKE_SEQ(_1);
        EPrintf(_fn, _1367, _1342);

        //     end for
        _i = _i + 1;
        goto LF;
L10:
        ;
    }

    // end procedure
    DeRef(_tables);
    DeRef(_ntables);
    DeRef(_tname);
    DeRef(_trecords);
    DeRef(_t_header);
    DeRef(_tnrecs);
    DeRef(_key_ptr);
    DeRef(_data_ptr);
    DeRef(_size);
    DeRef(_addr);
    DeRef(_tindex);
    DeRef(_key);
    DeRef(_data);
    DeRef(_a);
    DeRef(_1342);
    DeRef(_1348);
    DeRef(_1333);
    DeRef(_1308);
    return 0;
    ;
}


int __stdcall
_11check_free_list()
{
    int _free_count = 0;
    int _free_list = 0;
    int _addr = 0;
    int _size = 0;
    int _free_list_space = 0;
    int _max = 0;
    int _1369 = 0;
    int _1381 = 0;
    int _0, _1, _2;
    

    //     safe_seek(-1)
    _11safe_seek(-1);

    //     max = where(current_db)
    _max = _4where(_11current_db);

    //     safe_seek(FREE_COUNT)
    _11safe_seek(7);

    //     free_count = get4()
    _free_count = _11get4();

    //     if free_count > max/13 then
    if (IS_ATOM_INT(_max)) {
        _1369 = (_max % 13) ? NewDouble((double)_max / 13) : (_max / 13);
    }
    else {
        _1369 = NewDouble(DBL_PTR(_max)->dbl / (double)13);
    }
    if (binary_op_a(LESSEQ, _free_count, _1369))
        goto L1;

    // 	fatal("free count is too high")
    RefDS(_1373);
    _11fatal(_1373);
L1:

    //     free_list = get4()
    _0 = _free_list;
    _free_list = _11get4();
    DeRef(_0);

    //     if free_list > max then
    if (binary_op_a(LESSEQ, _free_list, _max))
        goto L2;

    // 	fatal("bad free list pointer")
    RefDS(_1376);
    _11fatal(_1376);
L2:

    //     safe_seek(free_list-4)
    DeRef(_1369);
    if (IS_ATOM_INT(_free_list)) {
        _1369 = _free_list - 4;
        if ((long)((unsigned long)_1369 +(unsigned long) HIGH_BITS) >= 0)
            _1369 = NewDouble((double)_1369);
    }
    else {
        _1369 = NewDouble(DBL_PTR(_free_list)->dbl - (double)4);
    }
    Ref(_1369);
    _11safe_seek(_1369);

    //     free_list_space = get4()
    _0 = _free_list_space;
    _free_list_space = _11get4();
    DeRef(_0);

    //     if free_list_space > max or free_list_space < INIT_FREE * 8 then
    DeRef(_1369);
    if (IS_ATOM_INT(_free_list_space) && IS_ATOM_INT(_max)) {
        _1369 = (_free_list_space > _max);
    }
    else {
        if (IS_ATOM_INT(_free_list_space)) {
            _1369 = ((double)_free_list_space > DBL_PTR(_max)->dbl);
        }
        else {
            if (IS_ATOM_INT(_max)) {
                _1369 = (DBL_PTR(_free_list_space)->dbl > (double)_max);
            }
            else
                _1369 = (DBL_PTR(_free_list_space)->dbl > DBL_PTR(_max)->dbl);
        }
    }
    if (_1369 != 0) {
        goto L3;
    }
    DeRef(_1381);
    _1381 = 40;
    if (IS_ATOM_INT(_free_list_space)) {
        _1381 = (_free_list_space < 40);
    }
    else {
        _1381 = (DBL_PTR(_free_list_space)->dbl < (double)40);
    }
L4:
    if (_1381 == 0)
        goto L5;
L3:

    // 	fatal("free list space is bad")  
    RefDS(_1383);
    _11fatal(_1383);
L5:

    //     for i = 1 to free_count do
    Ref(_free_count);
    DeRef(_1381);
    _1381 = _free_count;
    { int _i;
        _i = 1;
L6:
        if (binary_op_a(GREATER, _i, _1381))
            goto L7;

        // 	safe_seek(free_list+(i-1)*8)
        DeRef(_1369);
        if (IS_ATOM_INT(_i)) {
            _1369 = _i - 1;
            if ((long)((unsigned long)_1369 +(unsigned long) HIGH_BITS) >= 0)
                _1369 = NewDouble((double)_1369);
        }
        else {
            _1369 = NewDouble(DBL_PTR(_i)->dbl - (double)1);
        }
        _0 = _1369;
        if (IS_ATOM_INT(_1369)) {
            if (_1369 == (short)_1369)
                _1369 = _1369 * 8;
            else
                _1369 = NewDouble(_1369 * (double)8);
        }
        else {
            _1369 = NewDouble(DBL_PTR(_1369)->dbl * (double)8);
        }
        DeRef(_0);
        _0 = _1369;
        if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1369)) {
            _1369 = _free_list + _1369;
            if ((long)((unsigned long)_1369 + (unsigned long)HIGH_BITS) >= 0) 
                _1369 = NewDouble((double)_1369);
        }
        else {
            if (IS_ATOM_INT(_free_list)) {
                _1369 = NewDouble((double)_free_list + DBL_PTR(_1369)->dbl);
            }
            else {
                if (IS_ATOM_INT(_1369)) {
                    _1369 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1369);
                }
                else
                    _1369 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1369)->dbl);
            }
        }
        DeRef(_0);
        Ref(_1369);
        _11safe_seek(_1369);

        // 	addr = get4()
        _0 = _addr;
        _addr = _11get4();
        DeRef(_0);

        // 	if addr > max then
        if (binary_op_a(LESSEQ, _addr, _max))
            goto L8;

        // 	    fatal("bad block address")
        RefDS(_1390);
        _11fatal(_1390);
L8:

        // 	size = get4()
        _0 = _size;
        _size = _11get4();
        DeRef(_0);

        // 	if size > max then
        if (binary_op_a(LESSEQ, _size, _max))
            goto L9;

        // 	    fatal("block size too big")
        RefDS(_1393);
        _11fatal(_1393);
L9:

        // 	safe_seek(addr-4)
        DeRef(_1369);
        if (IS_ATOM_INT(_addr)) {
            _1369 = _addr - 4;
            if ((long)((unsigned long)_1369 +(unsigned long) HIGH_BITS) >= 0)
                _1369 = NewDouble((double)_1369);
        }
        else {
            _1369 = NewDouble(DBL_PTR(_addr)->dbl - (double)4);
        }
        Ref(_1369);
        _11safe_seek(_1369);

        // 	if get4() > size then
        _0 = _1369;
        _1369 = _11get4();
        DeRef(_0);
        if (binary_op_a(LESSEQ, _1369, _size))
            goto LA;

        // 	    fatal("bad size in front of free block")
        RefDS(_1397);
        _11fatal(_1397);
LA:

        //     end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L6;
L7:
        ;
        DeRef(_i);
    }

    // end procedure
    DeRef(_free_count);
    DeRef(_free_list);
    DeRef(_addr);
    DeRef(_size);
    DeRef(_free_list_space);
    DeRef(_max);
    DeRef(_1369);
    DeRef(_1381);
    return 0;
    ;
}


int _11db_allocate(int _n)
{
    int _free_list = 0;
    int _size = 0;
    int _size_ptr = 0;
    int _addr = 0;
    int _free_count;
    int _remaining = 0;
    int _1403 = 0;
    int _1398;
    int _0, _1, _2;
    

    //     safe_seek(FREE_COUNT)
    _11safe_seek(7);

    //     free_count = get4()
    _free_count = _11get4();
    if (!IS_ATOM_INT(_free_count)) {
        _1 = (long)(DBL_PTR(_free_count)->dbl);
        DeRefDS(_free_count);
        _free_count = _1;
    }

    //     if free_count > 0 then
    if (_free_count <= 0)
        goto L1;

    // 	free_list = get4()
    _free_list = _11get4();

    // 	safe_seek(free_list)
    Ref(_free_list);
    _11safe_seek(_free_list);

    // 	size_ptr = free_list + 4
    if (IS_ATOM_INT(_free_list)) {
        _size_ptr = _free_list + 4;
        if ((long)((unsigned long)_size_ptr + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr = NewDouble((double)_size_ptr);
    }
    else {
        _size_ptr = NewDouble(DBL_PTR(_free_list)->dbl + (double)4);
    }

    // 	for i = 1 to free_count do
    _1398 = _free_count;
    { int _i;
        _i = 1;
L2:
        if (_i > _1398)
            goto L3;

        // 	    addr = get4()
        _0 = _addr;
        _addr = _11get4();
        DeRef(_0);

        // 	    size = get4()
        _0 = _size;
        _size = _11get4();
        DeRef(_0);

        // 	    if size >= n+4 then
        DeRef(_1403);
        if (IS_ATOM_INT(_n)) {
            _1403 = _n + 4;
            if ((long)((unsigned long)_1403 + (unsigned long)HIGH_BITS) >= 0) 
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_n)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size, _1403))
            goto L4;

        // 		if size >= n+16 then 
        DeRef(_1403);
        if (IS_ATOM_INT(_n)) {
            _1403 = _n + 16;
            if ((long)((unsigned long)_1403 + (unsigned long)HIGH_BITS) >= 0) 
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_n)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size, _1403))
            goto L5;

        // 		    safe_seek(addr-4)
        DeRef(_1403);
        if (IS_ATOM_INT(_addr)) {
            _1403 = _addr - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_addr)->dbl - (double)4);
        }
        Ref(_1403);
        _11safe_seek(_1403);

        // 		    put4(size-n-4) -- shrink the block
        DeRef(_1403);
        if (IS_ATOM_INT(_size) && IS_ATOM_INT(_n)) {
            _1403 = _size - _n;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            if (IS_ATOM_INT(_size)) {
                _1403 = NewDouble((double)_size - DBL_PTR(_n)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n)) {
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - (double)_n);
                }
                else
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - DBL_PTR(_n)->dbl);
            }
        }
        _0 = _1403;
        if (IS_ATOM_INT(_1403)) {
            _1403 = _1403 - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_1403)->dbl - (double)4);
        }
        DeRef(_0);
        Ref(_1403);
        _11put4(_1403);

        // 		    safe_seek(size_ptr)
        Ref(_size_ptr);
        _11safe_seek(_size_ptr);

        // 		    put4(size-n-4) -- update size on free list too
        DeRef(_1403);
        if (IS_ATOM_INT(_size) && IS_ATOM_INT(_n)) {
            _1403 = _size - _n;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            if (IS_ATOM_INT(_size)) {
                _1403 = NewDouble((double)_size - DBL_PTR(_n)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n)) {
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - (double)_n);
                }
                else
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - DBL_PTR(_n)->dbl);
            }
        }
        _0 = _1403;
        if (IS_ATOM_INT(_1403)) {
            _1403 = _1403 - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_1403)->dbl - (double)4);
        }
        DeRef(_0);
        Ref(_1403);
        _11put4(_1403);

        // 		    addr += size-n-4
        DeRef(_1403);
        if (IS_ATOM_INT(_size) && IS_ATOM_INT(_n)) {
            _1403 = _size - _n;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            if (IS_ATOM_INT(_size)) {
                _1403 = NewDouble((double)_size - DBL_PTR(_n)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n)) {
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - (double)_n);
                }
                else
                    _1403 = NewDouble(DBL_PTR(_size)->dbl - DBL_PTR(_n)->dbl);
            }
        }
        _0 = _1403;
        if (IS_ATOM_INT(_1403)) {
            _1403 = _1403 - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_1403)->dbl - (double)4);
        }
        DeRef(_0);
        _0 = _addr;
        if (IS_ATOM_INT(_addr) && IS_ATOM_INT(_1403)) {
            _addr = _addr + _1403;
            if ((long)((unsigned long)_addr + (unsigned long)HIGH_BITS) >= 0) 
                _addr = NewDouble((double)_addr);
        }
        else {
            if (IS_ATOM_INT(_addr)) {
                _addr = NewDouble((double)_addr + DBL_PTR(_1403)->dbl);
            }
            else {
                if (IS_ATOM_INT(_1403)) {
                    _addr = NewDouble(DBL_PTR(_addr)->dbl + (double)_1403);
                }
                else
                    _addr = NewDouble(DBL_PTR(_addr)->dbl + DBL_PTR(_1403)->dbl);
            }
        }
        DeRef(_0);

        // 		    safe_seek(addr-4)
        DeRef(_1403);
        if (IS_ATOM_INT(_addr)) {
            _1403 = _addr - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_addr)->dbl - (double)4);
        }
        Ref(_1403);
        _11safe_seek(_1403);

        // 		    put4(n+4)
        DeRef(_1403);
        if (IS_ATOM_INT(_n)) {
            _1403 = _n + 4;
            if ((long)((unsigned long)_1403 + (unsigned long)HIGH_BITS) >= 0) 
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_n)->dbl + (double)4);
        }
        Ref(_1403);
        _11put4(_1403);
        goto L6;
L5:

        // 		    remaining = get_bytes(current_db, (free_count-i) * 8)
        DeRef(_1403);
        _1403 = _free_count - _i;
        if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
            _1403 = NewDouble((double)_1403);
        _0 = _1403;
        if (IS_ATOM_INT(_1403)) {
            if (_1403 == (short)_1403)
                _1403 = _1403 * 8;
            else
                _1403 = NewDouble(_1403 * (double)8);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_1403)->dbl * (double)8);
        }
        DeRef(_0);
        Ref(_1403);
        _0 = _remaining;
        _remaining = _7get_bytes(_11current_db, _1403);
        DeRefi(_0);

        // 		    safe_seek(free_list+8*(i-1))
        DeRef(_1403);
        _1403 = _i - 1;
        if (_1403 <= INT15)
            _1403 = 8 * _1403;
        else
            _1403 = NewDouble(8 * (double)_1403);
        _0 = _1403;
        if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1403)) {
            _1403 = _free_list + _1403;
            if ((long)((unsigned long)_1403 + (unsigned long)HIGH_BITS) >= 0) 
                _1403 = NewDouble((double)_1403);
        }
        else {
            if (IS_ATOM_INT(_free_list)) {
                _1403 = NewDouble((double)_free_list + DBL_PTR(_1403)->dbl);
            }
            else {
                if (IS_ATOM_INT(_1403)) {
                    _1403 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1403);
                }
                else
                    _1403 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1403)->dbl);
            }
        }
        DeRef(_0);
        Ref(_1403);
        _11safe_seek(_1403);

        // 		    putn(remaining)
        RefDS(_remaining);
        _11putn(_remaining);

        // 		    safe_seek(FREE_COUNT)
        _11safe_seek(7);

        // 		    put4(free_count-1)
        DeRef(_1403);
        _1403 = _free_count - 1;
        if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
            _1403 = NewDouble((double)_1403);
        Ref(_1403);
        _11put4(_1403);

        // 		    safe_seek(addr-4)
        DeRef(_1403);
        if (IS_ATOM_INT(_addr)) {
            _1403 = _addr - 4;
            if ((long)((unsigned long)_1403 +(unsigned long) HIGH_BITS) >= 0)
                _1403 = NewDouble((double)_1403);
        }
        else {
            _1403 = NewDouble(DBL_PTR(_addr)->dbl - (double)4);
        }
        Ref(_1403);
        _11safe_seek(_1403);

        // 		    put4(size) -- in case size was not updated by db_free()
        Ref(_size);
        _11put4(_size);
L6:

        // 		return addr
        DeRef(_n);
        DeRef(_free_list);
        DeRef(_size);
        DeRef(_size_ptr);
        DeRefi(_remaining);
        DeRef(_1403);
        return _addr;
L4:

        // 	    size_ptr += 8
        _0 = _size_ptr;
        if (IS_ATOM_INT(_size_ptr)) {
            _size_ptr = _size_ptr + 8;
            if ((long)((unsigned long)_size_ptr + (unsigned long)HIGH_BITS) >= 0) 
                _size_ptr = NewDouble((double)_size_ptr);
        }
        else {
            _size_ptr = NewDouble(DBL_PTR(_size_ptr)->dbl + (double)8);
        }
        DeRef(_0);

        // 	end for
        _i = _i + 1;
        goto L2;
L3:
        ;
    }
L1:

    //     safe_seek(-1) -- end of file
    _11safe_seek(-1);

    //     put4(n+4)
    DeRef(_1403);
    if (IS_ATOM_INT(_n)) {
        _1403 = _n + 4;
        if ((long)((unsigned long)_1403 + (unsigned long)HIGH_BITS) >= 0) 
            _1403 = NewDouble((double)_1403);
    }
    else {
        _1403 = NewDouble(DBL_PTR(_n)->dbl + (double)4);
    }
    Ref(_1403);
    _11put4(_1403);

    //     return where(current_db)
    _0 = _1403;
    _1403 = _4where(_11current_db);
    DeRef(_0);
    DeRef(_n);
    DeRef(_free_list);
    DeRef(_size);
    DeRef(_size_ptr);
    DeRef(_addr);
    DeRefi(_remaining);
    return _1403;
    ;
}


int _11db_free(int _p)
{
    int _psize = 0;
    int _i = 0;
    int _size = 0;
    int _addr = 0;
    int _free_list = 0;
    int _free_list_space = 0;
    int _new_space = 0;
    int _to_be_freed = 0;
    int _prev_addr = 0;
    int _prev_size = 0;
    int _free_count;
    int _remaining = 0;
    int _1457 = 0;
    int _1430 = 0;
    int _0, _1, _2;
    

    //     safe_seek(p-4)
    if (IS_ATOM_INT(_p)) {
        _1430 = _p - 4;
        if ((long)((unsigned long)_1430 +(unsigned long) HIGH_BITS) >= 0)
            _1430 = NewDouble((double)_1430);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_p)->dbl - (double)4);
    }
    Ref(_1430);
    _11safe_seek(_1430);

    //     psize = get4()
    _psize = _11get4();

    //     safe_seek(FREE_COUNT)
    _11safe_seek(7);

    //     free_count = get4()
    _free_count = _11get4();
    if (!IS_ATOM_INT(_free_count)) {
        _1 = (long)(DBL_PTR(_free_count)->dbl);
        DeRefDS(_free_count);
        _free_count = _1;
    }

    //     free_list = get4()
    _free_list = _11get4();

    //     safe_seek(free_list-4)
    DeRef(_1430);
    if (IS_ATOM_INT(_free_list)) {
        _1430 = _free_list - 4;
        if ((long)((unsigned long)_1430 +(unsigned long) HIGH_BITS) >= 0)
            _1430 = NewDouble((double)_1430);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_free_list)->dbl - (double)4);
    }
    Ref(_1430);
    _11safe_seek(_1430);

    //     free_list_space = get4()-4
    _0 = _1430;
    _1430 = _11get4();
    DeRef(_0);
    if (IS_ATOM_INT(_1430)) {
        _free_list_space = _1430 - 4;
        if ((long)((unsigned long)_free_list_space +(unsigned long) HIGH_BITS) >= 0)
            _free_list_space = NewDouble((double)_free_list_space);
    }
    else {
        _free_list_space = NewDouble(DBL_PTR(_1430)->dbl - (double)4);
    }

    //     if free_list_space < 8 * (free_count+1) then
    DeRef(_1430);
    _1430 = _free_count + 1;
    if (_1430 > MAXINT)
        _1430 = NewDouble((double)_1430);
    _0 = _1430;
    if (IS_ATOM_INT(_1430)) {
        if (_1430 <= INT15 && _1430 >= -INT15)
            _1430 = 8 * _1430;
        else
            _1430 = NewDouble(8 * (double)_1430);
    }
    else {
        _1430 = NewDouble((double)8 * DBL_PTR(_1430)->dbl);
    }
    DeRef(_0);
    if (binary_op_a(GREATEREQ, _free_list_space, _1430))
        goto L1;

    // 	new_space = floor(free_list_space * 3 / 2)
    DeRef(_1430);
    if (IS_ATOM_INT(_free_list_space)) {
        if (_free_list_space == (short)_free_list_space)
            _1430 = _free_list_space * 3;
        else
            _1430 = NewDouble(_free_list_space * (double)3);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_free_list_space)->dbl * (double)3);
    }
    if (IS_ATOM_INT(_1430)) {
        _new_space = _1430 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1430, 2);
        _new_space = unary_op(FLOOR, _1);
        DeRef(_1);
    }

    // 	to_be_freed = free_list
    Ref(_free_list);
    _to_be_freed = _free_list;

    // 	free_list = db_allocate(new_space)
    Ref(_new_space);
    _0 = _free_list;
    _free_list = _11db_allocate(_new_space);
    DeRef(_0);

    // 	safe_seek(free_list-4)
    DeRef(_1430);
    if (IS_ATOM_INT(_free_list)) {
        _1430 = _free_list - 4;
        if ((long)((unsigned long)_1430 +(unsigned long) HIGH_BITS) >= 0)
            _1430 = NewDouble((double)_1430);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_free_list)->dbl - (double)4);
    }
    Ref(_1430);
    _11safe_seek(_1430);

    // 	safe_seek(FREE_COUNT)
    _11safe_seek(7);

    // 	free_count = get4() -- db_allocate may have changed it
    _free_count = _11get4();
    if (!IS_ATOM_INT(_free_count)) {
        _1 = (long)(DBL_PTR(_free_count)->dbl);
        DeRefDS(_free_count);
        _free_count = _1;
    }

    // 	safe_seek(FREE_LIST)
    _11safe_seek(11);

    // 	put4(free_list)
    Ref(_free_list);
    _11put4(_free_list);

    // 	safe_seek(to_be_freed)
    Ref(_to_be_freed);
    _11safe_seek(_to_be_freed);

    // 	remaining = get_bytes(current_db, 8*free_count)
    DeRef(_1430);
    if (_free_count <= INT15 && _free_count >= -INT15)
        _1430 = 8 * _free_count;
    else
        _1430 = NewDouble(8 * (double)_free_count);
    Ref(_1430);
    _remaining = _7get_bytes(_11current_db, _1430);

    // 	safe_seek(free_list)
    Ref(_free_list);
    _11safe_seek(_free_list);

    // 	putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	putn(repeat(0, new_space-length(remaining)))
    DeRef(_1430);
    _1430 = SEQ_PTR(_remaining)->length;
    if (IS_ATOM_INT(_new_space)) {
        _1430 = _new_space - _1430;
    }
    else {
        _1430 = NewDouble(DBL_PTR(_new_space)->dbl - (double)_1430);
    }
    _0 = _1430;
    _1430 = Repeat(0, _1430);
    DeRef(_0);
    RefDS(_1430);
    _11putn(_1430);

    // 	safe_seek(free_list)
    Ref(_free_list);
    _11safe_seek(_free_list);
    goto L2;
L1:

    // 	new_space = 0
    DeRef(_new_space);
    _new_space = 0;
L2:

    //     i = 1
    DeRef(_i);
    _i = 1;

    //     prev_addr = 0
    DeRef(_prev_addr);
    _prev_addr = 0;

    //     prev_size = 0
    DeRef(_prev_size);
    _prev_size = 0;

    //     while i <= free_count do
L3:
    if (binary_op_a(GREATER, _i, _free_count))
        goto L4;

    // 	addr = get4()
    _0 = _addr;
    _addr = _11get4();
    DeRef(_0);

    // 	size = get4()
    _0 = _size;
    _size = _11get4();
    DeRef(_0);

    // 	if p < addr then
    if (binary_op_a(GREATEREQ, _p, _addr))
        goto L5;

    // 	    exit 
    goto L4;
L5:

    // 	prev_addr = addr
    Ref(_addr);
    DeRef(_prev_addr);
    _prev_addr = _addr;

    // 	prev_size = size
    Ref(_size);
    DeRef(_prev_size);
    _prev_size = _size;

    // 	i += 1
    _0 = _i;
    if (IS_ATOM_INT(_i)) {
        _i = _i + 1;
        if (_i > MAXINT)
            _i = NewDouble((double)_i);
    }
    else
        _i = binary_op(PLUS, 1, _i);
    DeRef(_0);

    //     end while
    goto L3;
L4:

    //     if i > 1 and prev_addr + prev_size = p then
    DeRef(_1430);
    if (IS_ATOM_INT(_i)) {
        _1430 = (_i > 1);
    }
    else {
        _1430 = (DBL_PTR(_i)->dbl > (double)1);
    }
    if (_1430 == 0) {
        goto L6;
    }
    DeRef(_1457);
    if (IS_ATOM_INT(_prev_addr) && IS_ATOM_INT(_prev_size)) {
        _1457 = _prev_addr + _prev_size;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_prev_addr)) {
            _1457 = NewDouble((double)_prev_addr + DBL_PTR(_prev_size)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size)) {
                _1457 = NewDouble(DBL_PTR(_prev_addr)->dbl + (double)_prev_size);
            }
            else
                _1457 = NewDouble(DBL_PTR(_prev_addr)->dbl + DBL_PTR(_prev_size)->dbl);
        }
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457) && IS_ATOM_INT(_p)) {
        _1457 = (_1457 == _p);
    }
    else {
        if (IS_ATOM_INT(_1457)) {
            _1457 = ((double)_1457 == DBL_PTR(_p)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p)) {
                _1457 = (DBL_PTR(_1457)->dbl == (double)_p);
            }
            else
                _1457 = (DBL_PTR(_1457)->dbl == DBL_PTR(_p)->dbl);
        }
    }
    DeRef(_0);
L7:
    if (_1457 == 0)
        goto L6;

    // 	safe_seek(free_list+(i-2)*8+4)
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = _i - 2;
        if ((long)((unsigned long)_1457 +(unsigned long) HIGH_BITS) >= 0)
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_i)->dbl - (double)2);
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        if (_1457 == (short)_1457)
            _1457 = _1457 * 8;
        else
            _1457 = NewDouble(_1457 * (double)8);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl * (double)8);
    }
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1457)) {
        _1457 = _free_list + _1457;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1457 = NewDouble((double)_free_list + DBL_PTR(_1457)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1457)) {
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1457);
            }
            else
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1457)->dbl);
        }
    }
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        _1457 = _1457 + 4;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl + (double)4);
    }
    DeRef(_0);
    Ref(_1457);
    _11safe_seek(_1457);

    // 	if i < free_count and p + psize = addr then
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = (_i < _free_count);
    }
    else {
        _1457 = (DBL_PTR(_i)->dbl < (double)_free_count);
    }
    if (_1457 == 0) {
        goto L8;
    }
    DeRef(_1430);
    if (IS_ATOM_INT(_p) && IS_ATOM_INT(_psize)) {
        _1430 = _p + _psize;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_p)) {
            _1430 = NewDouble((double)_p + DBL_PTR(_psize)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize)) {
                _1430 = NewDouble(DBL_PTR(_p)->dbl + (double)_psize);
            }
            else
                _1430 = NewDouble(DBL_PTR(_p)->dbl + DBL_PTR(_psize)->dbl);
        }
    }
    _0 = _1430;
    if (IS_ATOM_INT(_1430) && IS_ATOM_INT(_addr)) {
        _1430 = (_1430 == _addr);
    }
    else {
        if (IS_ATOM_INT(_1430)) {
            _1430 = ((double)_1430 == DBL_PTR(_addr)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr)) {
                _1430 = (DBL_PTR(_1430)->dbl == (double)_addr);
            }
            else
                _1430 = (DBL_PTR(_1430)->dbl == DBL_PTR(_addr)->dbl);
        }
    }
    DeRef(_0);
L9:
    if (_1430 == 0)
        goto L8;

    // 	    put4(prev_size+psize+size) -- update size on free list (only)
    DeRef(_1430);
    if (IS_ATOM_INT(_prev_size) && IS_ATOM_INT(_psize)) {
        _1430 = _prev_size + _psize;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_prev_size)) {
            _1430 = NewDouble((double)_prev_size + DBL_PTR(_psize)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize)) {
                _1430 = NewDouble(DBL_PTR(_prev_size)->dbl + (double)_psize);
            }
            else
                _1430 = NewDouble(DBL_PTR(_prev_size)->dbl + DBL_PTR(_psize)->dbl);
        }
    }
    _0 = _1430;
    if (IS_ATOM_INT(_1430) && IS_ATOM_INT(_size)) {
        _1430 = _1430 + _size;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_1430)) {
            _1430 = NewDouble((double)_1430 + DBL_PTR(_size)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size)) {
                _1430 = NewDouble(DBL_PTR(_1430)->dbl + (double)_size);
            }
            else
                _1430 = NewDouble(DBL_PTR(_1430)->dbl + DBL_PTR(_size)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1430);
    _11put4(_1430);

    // 	    safe_seek(free_list+i*8)
    DeRef(_1430);
    if (IS_ATOM_INT(_i)) {
        if (_i == (short)_i)
            _1430 = _i * 8;
        else
            _1430 = NewDouble(_i * (double)8);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_i)->dbl * (double)8);
    }
    _0 = _1430;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1430)) {
        _1430 = _free_list + _1430;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1430 = NewDouble((double)_free_list + DBL_PTR(_1430)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1430)) {
                _1430 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1430);
            }
            else
                _1430 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1430)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1430);
    _11safe_seek(_1430);

    // 	    remaining = get_bytes(current_db, (free_count-i)*8)
    DeRef(_1430);
    if (IS_ATOM_INT(_i)) {
        _1430 = _free_count - _i;
        if ((long)((unsigned long)_1430 +(unsigned long) HIGH_BITS) >= 0)
            _1430 = NewDouble((double)_1430);
    }
    else {
        _1430 = NewDouble((double)_free_count - DBL_PTR(_i)->dbl);
    }
    _0 = _1430;
    if (IS_ATOM_INT(_1430)) {
        if (_1430 == (short)_1430)
            _1430 = _1430 * 8;
        else
            _1430 = NewDouble(_1430 * (double)8);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_1430)->dbl * (double)8);
    }
    DeRef(_0);
    Ref(_1430);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1430);
    DeRefi(_0);

    // 	    safe_seek(free_list+(i-1)*8)
    DeRef(_1430);
    if (IS_ATOM_INT(_i)) {
        _1430 = _i - 1;
        if ((long)((unsigned long)_1430 +(unsigned long) HIGH_BITS) >= 0)
            _1430 = NewDouble((double)_1430);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_i)->dbl - (double)1);
    }
    _0 = _1430;
    if (IS_ATOM_INT(_1430)) {
        if (_1430 == (short)_1430)
            _1430 = _1430 * 8;
        else
            _1430 = NewDouble(_1430 * (double)8);
    }
    else {
        _1430 = NewDouble(DBL_PTR(_1430)->dbl * (double)8);
    }
    DeRef(_0);
    _0 = _1430;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1430)) {
        _1430 = _free_list + _1430;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1430 = NewDouble((double)_free_list + DBL_PTR(_1430)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1430)) {
                _1430 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1430);
            }
            else
                _1430 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1430)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1430);
    _11safe_seek(_1430);

    // 	    putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	    free_count -= 1
    _free_count = _free_count - 1;

    // 	    safe_seek(FREE_COUNT)
    _11safe_seek(7);

    // 	    put4(free_count)
    _11put4(_free_count);
    goto LA;
L8:

    // 	    put4(prev_size+psize) -- increase previous size on free list (only)
    DeRef(_1430);
    if (IS_ATOM_INT(_prev_size) && IS_ATOM_INT(_psize)) {
        _1430 = _prev_size + _psize;
        if ((long)((unsigned long)_1430 + (unsigned long)HIGH_BITS) >= 0) 
            _1430 = NewDouble((double)_1430);
    }
    else {
        if (IS_ATOM_INT(_prev_size)) {
            _1430 = NewDouble((double)_prev_size + DBL_PTR(_psize)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize)) {
                _1430 = NewDouble(DBL_PTR(_prev_size)->dbl + (double)_psize);
            }
            else
                _1430 = NewDouble(DBL_PTR(_prev_size)->dbl + DBL_PTR(_psize)->dbl);
        }
    }
    Ref(_1430);
    _11put4(_1430);
LB:
    goto LA;
L6:

    //     elsif i < free_count and p + psize = addr then
    DeRef(_1430);
    if (IS_ATOM_INT(_i)) {
        _1430 = (_i < _free_count);
    }
    else {
        _1430 = (DBL_PTR(_i)->dbl < (double)_free_count);
    }
    if (_1430 == 0) {
        goto LC;
    }
    DeRef(_1457);
    if (IS_ATOM_INT(_p) && IS_ATOM_INT(_psize)) {
        _1457 = _p + _psize;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_p)) {
            _1457 = NewDouble((double)_p + DBL_PTR(_psize)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize)) {
                _1457 = NewDouble(DBL_PTR(_p)->dbl + (double)_psize);
            }
            else
                _1457 = NewDouble(DBL_PTR(_p)->dbl + DBL_PTR(_psize)->dbl);
        }
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457) && IS_ATOM_INT(_addr)) {
        _1457 = (_1457 == _addr);
    }
    else {
        if (IS_ATOM_INT(_1457)) {
            _1457 = ((double)_1457 == DBL_PTR(_addr)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr)) {
                _1457 = (DBL_PTR(_1457)->dbl == (double)_addr);
            }
            else
                _1457 = (DBL_PTR(_1457)->dbl == DBL_PTR(_addr)->dbl);
        }
    }
    DeRef(_0);
LD:
    if (_1457 == 0)
        goto LC;

    // 	safe_seek(free_list+(i-1)*8)
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = _i - 1;
        if ((long)((unsigned long)_1457 +(unsigned long) HIGH_BITS) >= 0)
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_i)->dbl - (double)1);
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        if (_1457 == (short)_1457)
            _1457 = _1457 * 8;
        else
            _1457 = NewDouble(_1457 * (double)8);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl * (double)8);
    }
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1457)) {
        _1457 = _free_list + _1457;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1457 = NewDouble((double)_free_list + DBL_PTR(_1457)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1457)) {
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1457);
            }
            else
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1457)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1457);
    _11safe_seek(_1457);

    // 	put4(p)
    Ref(_p);
    _11put4(_p);

    // 	put4(psize+size)
    DeRef(_1457);
    if (IS_ATOM_INT(_psize) && IS_ATOM_INT(_size)) {
        _1457 = _psize + _size;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_psize)) {
            _1457 = NewDouble((double)_psize + DBL_PTR(_size)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size)) {
                _1457 = NewDouble(DBL_PTR(_psize)->dbl + (double)_size);
            }
            else
                _1457 = NewDouble(DBL_PTR(_psize)->dbl + DBL_PTR(_size)->dbl);
        }
    }
    Ref(_1457);
    _11put4(_1457);
    goto LA;
LC:

    // 	safe_seek(free_list+(i-1)*8)
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = _i - 1;
        if ((long)((unsigned long)_1457 +(unsigned long) HIGH_BITS) >= 0)
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_i)->dbl - (double)1);
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        if (_1457 == (short)_1457)
            _1457 = _1457 * 8;
        else
            _1457 = NewDouble(_1457 * (double)8);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl * (double)8);
    }
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1457)) {
        _1457 = _free_list + _1457;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1457 = NewDouble((double)_free_list + DBL_PTR(_1457)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1457)) {
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1457);
            }
            else
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1457)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1457);
    _11safe_seek(_1457);

    // 	remaining = get_bytes(current_db, (free_count-i+1)*8)
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = _free_count - _i;
        if ((long)((unsigned long)_1457 +(unsigned long) HIGH_BITS) >= 0)
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble((double)_free_count - DBL_PTR(_i)->dbl);
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        _1457 = _1457 + 1;
        if (_1457 > MAXINT)
            _1457 = NewDouble((double)_1457);
    }
    else
        _1457 = binary_op(PLUS, 1, _1457);
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        if (_1457 == (short)_1457)
            _1457 = _1457 * 8;
        else
            _1457 = NewDouble(_1457 * (double)8);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl * (double)8);
    }
    DeRef(_0);
    Ref(_1457);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1457);
    DeRefi(_0);

    // 	free_count += 1
    _free_count = _free_count + 1;

    // 	safe_seek(FREE_COUNT)
    _11safe_seek(7);

    // 	put4(free_count)
    _11put4(_free_count);

    // 	safe_seek(free_list+(i-1)*8)
    DeRef(_1457);
    if (IS_ATOM_INT(_i)) {
        _1457 = _i - 1;
        if ((long)((unsigned long)_1457 +(unsigned long) HIGH_BITS) >= 0)
            _1457 = NewDouble((double)_1457);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_i)->dbl - (double)1);
    }
    _0 = _1457;
    if (IS_ATOM_INT(_1457)) {
        if (_1457 == (short)_1457)
            _1457 = _1457 * 8;
        else
            _1457 = NewDouble(_1457 * (double)8);
    }
    else {
        _1457 = NewDouble(DBL_PTR(_1457)->dbl * (double)8);
    }
    DeRef(_0);
    _0 = _1457;
    if (IS_ATOM_INT(_free_list) && IS_ATOM_INT(_1457)) {
        _1457 = _free_list + _1457;
        if ((long)((unsigned long)_1457 + (unsigned long)HIGH_BITS) >= 0) 
            _1457 = NewDouble((double)_1457);
    }
    else {
        if (IS_ATOM_INT(_free_list)) {
            _1457 = NewDouble((double)_free_list + DBL_PTR(_1457)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1457)) {
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + (double)_1457);
            }
            else
                _1457 = NewDouble(DBL_PTR(_free_list)->dbl + DBL_PTR(_1457)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1457);
    _11safe_seek(_1457);

    // 	put4(p)
    Ref(_p);
    _11put4(_p);

    // 	put4(psize)
    Ref(_psize);
    _11put4(_psize);

    // 	putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);
LA:

    //     if new_space then
    if (_new_space == 0) {
        goto LE;
    }
    else {
        if (!IS_ATOM_INT(_new_space) && DBL_PTR(_new_space)->dbl == 0.0)
            goto LE;
    }

    // 	db_free(to_be_freed) -- free the old space
    Ref(_to_be_freed);
    _11db_free(_to_be_freed);
LE:

    // end procedure
    DeRef(_p);
    DeRef(_psize);
    DeRef(_i);
    DeRef(_size);
    DeRef(_addr);
    DeRef(_free_list);
    DeRef(_free_list_space);
    DeRef(_new_space);
    DeRef(_to_be_freed);
    DeRef(_prev_addr);
    DeRef(_prev_size);
    DeRefi(_remaining);
    DeRef(_1457);
    DeRef(_1430);
    return 0;
    ;
}


