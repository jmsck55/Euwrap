// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_9save_bitmap(int _palette_n_image, int _file_name)
{
    int _color = 0;
    int _image = 0;
    int _numColors;
    int _1076 = 0;
    int _0, _1, _2;
    

    //     error_code = BMP_SUCCESS
    _9error_code = 0;

    //     fn = open(file_name, "wb")
    _9fn = EOpen(_file_name, _1027);

    //     if fn = -1 then
    if (_9fn != -1)
        goto L1;

    // 	return BMP_OPEN_FAILED
    DeRefDS(_palette_n_image);
    DeRefDS(_file_name);
    return 1;
L1:

    //     color = palette_n_image[1]
    DeRef(_color);
    _2 = (int)SEQ_PTR(_palette_n_image);
    _color = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_color);

    //     image = palette_n_image[2]
    DeRef(_image);
    _2 = (int)SEQ_PTR(_palette_n_image);
    _image = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_image);

    //     numYPixels = length(image)
    _9numYPixels = SEQ_PTR(_image)->length;

    //     numXPixels = length(image[1])   -- assume the same length with each row
    DeRef(_1076);
    _2 = (int)SEQ_PTR(_image);
    _1076 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1076);
    _9numXPixels = SEQ_PTR(_1076)->length;

    //     numColors = length(color)
    _numColors = SEQ_PTR(_color)->length;

    //     putBmpFileHeader(numColors)
    _9putBmpFileHeader(_numColors);

    //     if error_code = BMP_SUCCESS then
    if (_9error_code != 0)
        goto L2;

    // 	putColorTable(numColors, color) 
    RefDS(_color);
    _9putColorTable(_numColors, _color);

    // 	putImage1(image)
    RefDS(_image);
    _9putImage1(_image);
L2:

    //     close(fn)
    EClose(_9fn);

    //     return error_code
    DeRefDS(_palette_n_image);
    DeRefDS(_file_name);
    DeRef(_color);
    DeRef(_image);
    DeRef(_1076);
    return _9error_code;
    ;
}


