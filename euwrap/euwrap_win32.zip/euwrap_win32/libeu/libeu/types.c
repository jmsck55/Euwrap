// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _7char_test(int _test_data_480, int _char_set_481)
{
    int _lChr_482 = NOVALUE;
    int _275 = NOVALUE;
    int _274 = NOVALUE;
    int _273 = NOVALUE;
    int _272 = NOVALUE;
    int _271 = NOVALUE;
    int _270 = NOVALUE;
    int _269 = NOVALUE;
    int _268 = NOVALUE;
    int _267 = NOVALUE;
    int _266 = NOVALUE;
    int _265 = NOVALUE;
    int _262 = NOVALUE;
    int _261 = NOVALUE;
    int _260 = NOVALUE;
    int _259 = NOVALUE;
    int _257 = NOVALUE;
    int _255 = NOVALUE;
    int _254 = NOVALUE;
    int _253 = NOVALUE;
    int _252 = NOVALUE;
    int _251 = NOVALUE;
    int _250 = NOVALUE;
    int _249 = NOVALUE;
    int _248 = NOVALUE;
    int _247 = NOVALUE;
    int _246 = NOVALUE;
    int _245 = NOVALUE;
    int _244 = NOVALUE;
    int _243 = NOVALUE;
    int _242 = NOVALUE;
    int _241 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(test_data) then*/
    if (IS_ATOM_INT(_test_data_480))
    _241 = 1;
    else if (IS_ATOM_DBL(_test_data_480))
    _241 = IS_ATOM_INT(DoubleToInt(_test_data_480));
    else
    _241 = 0;
    if (_241 == 0)
    {
        _241 = NOVALUE;
        goto L1; // [8] 115
    }
    else{
        _241 = NOVALUE;
    }

    /** 		if sequence(char_set[1]) then*/
    _2 = (int)SEQ_PTR(_char_set_481);
    _242 = (int)*(((s1_ptr)_2)->base + 1);
    _243 = IS_SEQUENCE(_242);
    _242 = NOVALUE;
    if (_243 == 0)
    {
        _243 = NOVALUE;
        goto L2; // [20] 96
    }
    else{
        _243 = NOVALUE;
    }

    /** 			for j = 1 to length(char_set) do*/
    if (IS_SEQUENCE(_char_set_481)){
            _244 = SEQ_PTR(_char_set_481)->length;
    }
    else {
        _244 = 1;
    }
    {
        int _j_489;
        _j_489 = 1;
L3: 
        if (_j_489 > _244){
            goto L4; // [28] 85
        }

        /** 				if test_data >= char_set[j][1] and test_data <= char_set[j][2] then */
        _2 = (int)SEQ_PTR(_char_set_481);
        _245 = (int)*(((s1_ptr)_2)->base + _j_489);
        _2 = (int)SEQ_PTR(_245);
        _246 = (int)*(((s1_ptr)_2)->base + 1);
        _245 = NOVALUE;
        if (IS_ATOM_INT(_test_data_480) && IS_ATOM_INT(_246)) {
            _247 = (_test_data_480 >= _246);
        }
        else {
            _247 = binary_op(GREATEREQ, _test_data_480, _246);
        }
        _246 = NOVALUE;
        if (IS_ATOM_INT(_247)) {
            if (_247 == 0) {
                goto L5; // [49] 78
            }
        }
        else {
            if (DBL_PTR(_247)->dbl == 0.0) {
                goto L5; // [49] 78
            }
        }
        _2 = (int)SEQ_PTR(_char_set_481);
        _249 = (int)*(((s1_ptr)_2)->base + _j_489);
        _2 = (int)SEQ_PTR(_249);
        _250 = (int)*(((s1_ptr)_2)->base + 2);
        _249 = NOVALUE;
        if (IS_ATOM_INT(_test_data_480) && IS_ATOM_INT(_250)) {
            _251 = (_test_data_480 <= _250);
        }
        else {
            _251 = binary_op(LESSEQ, _test_data_480, _250);
        }
        _250 = NOVALUE;
        if (_251 == 0) {
            DeRef(_251);
            _251 = NOVALUE;
            goto L5; // [66] 78
        }
        else {
            if (!IS_ATOM_INT(_251) && DBL_PTR(_251)->dbl == 0.0){
                DeRef(_251);
                _251 = NOVALUE;
                goto L5; // [66] 78
            }
            DeRef(_251);
            _251 = NOVALUE;
        }
        DeRef(_251);
        _251 = NOVALUE;

        /** 					return TRUE */
        DeRef(_test_data_480);
        DeRefDS(_char_set_481);
        DeRef(_247);
        _247 = NOVALUE;
        return _7TRUE_445;
L5: 

        /** 			end for*/
        _j_489 = _j_489 + 1;
        goto L3; // [80] 35
L4: 
        ;
    }

    /** 			return FALSE*/
    DeRef(_test_data_480);
    DeRefDS(_char_set_481);
    DeRef(_247);
    _247 = NOVALUE;
    return _7FALSE_443;
    goto L6; // [93] 328
L2: 

    /** 			return find(test_data, char_set) > 0*/
    _252 = find_from(_test_data_480, _char_set_481, 1);
    _253 = (_252 > 0);
    _252 = NOVALUE;
    DeRef(_test_data_480);
    DeRefDS(_char_set_481);
    DeRef(_247);
    _247 = NOVALUE;
    return _253;
    goto L6; // [112] 328
L1: 

    /** 	elsif sequence(test_data) then*/
    _254 = IS_SEQUENCE(_test_data_480);
    if (_254 == 0)
    {
        _254 = NOVALUE;
        goto L7; // [120] 319
    }
    else{
        _254 = NOVALUE;
    }

    /** 		if length(test_data) = 0 then */
    if (IS_SEQUENCE(_test_data_480)){
            _255 = SEQ_PTR(_test_data_480)->length;
    }
    else {
        _255 = 1;
    }
    if (_255 != 0)
    goto L8; // [128] 141

    /** 			return FALSE */
    DeRef(_test_data_480);
    DeRefDS(_char_set_481);
    DeRef(_253);
    _253 = NOVALUE;
    DeRef(_247);
    _247 = NOVALUE;
    return _7FALSE_443;
L8: 

    /** 		for i = 1 to length(test_data) label "NXTCHR" do*/
    if (IS_SEQUENCE(_test_data_480)){
            _257 = SEQ_PTR(_test_data_480)->length;
    }
    else {
        _257 = 1;
    }
    {
        int _i_508;
        _i_508 = 1;
L9: 
        if (_i_508 > _257){
            goto LA; // [146] 308
        }

        /** 			if sequence(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_480);
        _259 = (int)*(((s1_ptr)_2)->base + _i_508);
        _260 = IS_SEQUENCE(_259);
        _259 = NOVALUE;
        if (_260 == 0)
        {
            _260 = NOVALUE;
            goto LB; // [162] 174
        }
        else{
            _260 = NOVALUE;
        }

        /** 				return FALSE*/
        DeRef(_test_data_480);
        DeRefDS(_char_set_481);
        DeRef(_253);
        _253 = NOVALUE;
        DeRef(_247);
        _247 = NOVALUE;
        return _7FALSE_443;
LB: 

        /** 			if not integer(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_480);
        _261 = (int)*(((s1_ptr)_2)->base + _i_508);
        if (IS_ATOM_INT(_261))
        _262 = 1;
        else if (IS_ATOM_DBL(_261))
        _262 = IS_ATOM_INT(DoubleToInt(_261));
        else
        _262 = 0;
        _261 = NOVALUE;
        if (_262 != 0)
        goto LC; // [183] 195
        _262 = NOVALUE;

        /** 				return FALSE*/
        DeRef(_test_data_480);
        DeRefDS(_char_set_481);
        DeRef(_253);
        _253 = NOVALUE;
        DeRef(_247);
        _247 = NOVALUE;
        return _7FALSE_443;
LC: 

        /** 			lChr = test_data[i]*/
        _2 = (int)SEQ_PTR(_test_data_480);
        _lChr_482 = (int)*(((s1_ptr)_2)->base + _i_508);
        if (!IS_ATOM_INT(_lChr_482)){
            _lChr_482 = (long)DBL_PTR(_lChr_482)->dbl;
        }

        /** 			if sequence(char_set[1]) then*/
        _2 = (int)SEQ_PTR(_char_set_481);
        _265 = (int)*(((s1_ptr)_2)->base + 1);
        _266 = IS_SEQUENCE(_265);
        _265 = NOVALUE;
        if (_266 == 0)
        {
            _266 = NOVALUE;
            goto LD; // [212] 276
        }
        else{
            _266 = NOVALUE;
        }

        /** 				for j = 1 to length(char_set) do*/
        if (IS_SEQUENCE(_char_set_481)){
                _267 = SEQ_PTR(_char_set_481)->length;
        }
        else {
            _267 = 1;
        }
        {
            int _j_523;
            _j_523 = 1;
LE: 
            if (_j_523 > _267){
                goto LF; // [220] 273
            }

            /** 					if lChr >= char_set[j][1] and lChr <= char_set[j][2] then*/
            _2 = (int)SEQ_PTR(_char_set_481);
            _268 = (int)*(((s1_ptr)_2)->base + _j_523);
            _2 = (int)SEQ_PTR(_268);
            _269 = (int)*(((s1_ptr)_2)->base + 1);
            _268 = NOVALUE;
            if (IS_ATOM_INT(_269)) {
                _270 = (_lChr_482 >= _269);
            }
            else {
                _270 = binary_op(GREATEREQ, _lChr_482, _269);
            }
            _269 = NOVALUE;
            if (IS_ATOM_INT(_270)) {
                if (_270 == 0) {
                    goto L10; // [241] 266
                }
            }
            else {
                if (DBL_PTR(_270)->dbl == 0.0) {
                    goto L10; // [241] 266
                }
            }
            _2 = (int)SEQ_PTR(_char_set_481);
            _272 = (int)*(((s1_ptr)_2)->base + _j_523);
            _2 = (int)SEQ_PTR(_272);
            _273 = (int)*(((s1_ptr)_2)->base + 2);
            _272 = NOVALUE;
            if (IS_ATOM_INT(_273)) {
                _274 = (_lChr_482 <= _273);
            }
            else {
                _274 = binary_op(LESSEQ, _lChr_482, _273);
            }
            _273 = NOVALUE;
            if (_274 == 0) {
                DeRef(_274);
                _274 = NOVALUE;
                goto L10; // [258] 266
            }
            else {
                if (!IS_ATOM_INT(_274) && DBL_PTR(_274)->dbl == 0.0){
                    DeRef(_274);
                    _274 = NOVALUE;
                    goto L10; // [258] 266
                }
                DeRef(_274);
                _274 = NOVALUE;
            }
            DeRef(_274);
            _274 = NOVALUE;

            /** 						continue "NXTCHR" */
            goto L11; // [263] 303
L10: 

            /** 				end for*/
            _j_523 = _j_523 + 1;
            goto LE; // [268] 227
LF: 
            ;
        }
        goto L12; // [273] 293
LD: 

        /** 				if find(lChr, char_set) > 0 then*/
        _275 = find_from(_lChr_482, _char_set_481, 1);
        if (_275 <= 0)
        goto L13; // [283] 292

        /** 					continue "NXTCHR"*/
        goto L11; // [289] 303
L13: 
L12: 

        /** 			return FALSE*/
        DeRef(_test_data_480);
        DeRefDS(_char_set_481);
        DeRef(_253);
        _253 = NOVALUE;
        DeRef(_247);
        _247 = NOVALUE;
        DeRef(_270);
        _270 = NOVALUE;
        return _7FALSE_443;

        /** 		end for*/
L11: 
        _i_508 = _i_508 + 1;
        goto L9; // [303] 153
LA: 
        ;
    }

    /** 		return TRUE*/
    DeRef(_test_data_480);
    DeRefDS(_char_set_481);
    DeRef(_253);
    _253 = NOVALUE;
    DeRef(_247);
    _247 = NOVALUE;
    DeRef(_270);
    _270 = NOVALUE;
    return _7TRUE_445;
    goto L6; // [316] 328
L7: 

    /** 		return FALSE*/
    DeRef(_test_data_480);
    DeRefDS(_char_set_481);
    DeRef(_253);
    _253 = NOVALUE;
    DeRef(_247);
    _247 = NOVALUE;
    DeRef(_270);
    _270 = NOVALUE;
    return _7FALSE_443;
L6: 
    ;
}


void  __stdcall _7set_default_charsets()
{
    int _343 = NOVALUE;
    int _341 = NOVALUE;
    int _340 = NOVALUE;
    int _338 = NOVALUE;
    int _335 = NOVALUE;
    int _334 = NOVALUE;
    int _333 = NOVALUE;
    int _332 = NOVALUE;
    int _329 = NOVALUE;
    int _327 = NOVALUE;
    int _316 = NOVALUE;
    int _309 = NOVALUE;
    int _306 = NOVALUE;
    int _299 = NOVALUE;
    int _295 = NOVALUE;
    int _294 = NOVALUE;
    int _293 = NOVALUE;
    int _290 = NOVALUE;
    int _286 = NOVALUE;
    int _278 = NOVALUE;
    int _277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Defined_Sets = repeat(0, CS_LAST - CS_FIRST - 1)*/
    _277 = 20;
    _278 = 19;
    _277 = NOVALUE;
    DeRef(_7Defined_Sets_538);
    _7Defined_Sets_538 = Repeat(0, 19);
    _278 = NOVALUE;

    /** 	Defined_Sets[CS_Alphabetic	] = {{'a', 'z'}, {'A', 'Z'}}*/
    RefDS(_285);
    RefDS(_282);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _282;
    ((int *)_2)[2] = _285;
    _286 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 12);
    *(int *)_2 = _286;
    if( _1 != _286 ){
    }
    _286 = NOVALUE;

    /** 	Defined_Sets[CS_Alphanumeric] = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_289);
    *((int *)(_2+4)) = _289;
    RefDS(_282);
    *((int *)(_2+8)) = _282;
    RefDS(_285);
    *((int *)(_2+12)) = _285;
    _290 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _290;
    if( _1 != _290 ){
        DeRef(_1);
    }
    _290 = NOVALUE;

    /** 	Defined_Sets[CS_Identifier]   = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}, {'_', '_'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_289);
    *((int *)(_2+4)) = _289;
    RefDS(_282);
    *((int *)(_2+8)) = _282;
    RefDS(_285);
    *((int *)(_2+12)) = _285;
    RefDS(_292);
    *((int *)(_2+16)) = _292;
    _293 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _293;
    if( _1 != _293 ){
        DeRef(_1);
    }
    _293 = NOVALUE;

    /** 	Defined_Sets[CS_Uppercase 	] = {{'A', 'Z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_285);
    *((int *)(_2+4)) = _285;
    _294 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _294;
    if( _1 != _294 ){
        DeRef(_1);
    }
    _294 = NOVALUE;

    /** 	Defined_Sets[CS_Lowercase 	] = {{'a', 'z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_282);
    *((int *)(_2+4)) = _282;
    _295 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _295;
    if( _1 != _295 ){
        DeRef(_1);
    }
    _295 = NOVALUE;

    /** 	Defined_Sets[CS_Printable 	] = {{' ', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_298);
    *((int *)(_2+4)) = _298;
    _299 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _299;
    if( _1 != _299 ){
        DeRef(_1);
    }
    _299 = NOVALUE;

    /** 	Defined_Sets[CS_Displayable ] = {{' ', '~'}, "  ", "\t\t", "\n\n", "\r\r", {8,8}, {7,7} }*/
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_298);
    *((int *)(_2+4)) = _298;
    RefDS(_300);
    *((int *)(_2+8)) = _300;
    RefDS(_301);
    *((int *)(_2+12)) = _301;
    RefDS(_302);
    *((int *)(_2+16)) = _302;
    RefDS(_303);
    *((int *)(_2+20)) = _303;
    RefDS(_304);
    *((int *)(_2+24)) = _304;
    RefDS(_305);
    *((int *)(_2+28)) = _305;
    _306 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _306;
    if( _1 != _306 ){
        DeRef(_1);
    }
    _306 = NOVALUE;

    /** 	Defined_Sets[CS_Whitespace 	] = " \t\n\r" & 11 & 160*/
    {
        int concat_list[3];

        concat_list[0] = 160;
        concat_list[1] = 11;
        concat_list[2] = _307;
        Concat_N((object_ptr)&_309, concat_list, 3);
    }
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _309;
    if( _1 != _309 ){
        DeRef(_1);
    }
    _309 = NOVALUE;

    /** 	Defined_Sets[CS_Consonant 	] = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"*/
    RefDS(_310);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _310;
    DeRef(_1);

    /** 	Defined_Sets[CS_Vowel 		] = "aeiouAEIOU"*/
    RefDS(_311);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _311;
    DeRef(_1);

    /** 	Defined_Sets[CS_Hexadecimal ] = {{'0', '9'}, {'A', 'F'},{'a', 'f'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_289);
    *((int *)(_2+4)) = _289;
    RefDS(_313);
    *((int *)(_2+8)) = _313;
    RefDS(_315);
    *((int *)(_2+12)) = _315;
    _316 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _316;
    if( _1 != _316 ){
        DeRef(_1);
    }
    _316 = NOVALUE;

    /** 	Defined_Sets[CS_Punctuation ] = {{' ', '/'}, {':', '?'}, {'[', '`'}, {'{', '~'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_318);
    *((int *)(_2+4)) = _318;
    RefDS(_321);
    *((int *)(_2+8)) = _321;
    RefDS(_324);
    *((int *)(_2+12)) = _324;
    RefDS(_326);
    *((int *)(_2+16)) = _326;
    _327 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _327;
    if( _1 != _327 ){
        DeRef(_1);
    }
    _327 = NOVALUE;

    /** 	Defined_Sets[CS_Control 	] = {{0, 31}, {127, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 31;
    _329 = MAKE_SEQ(_1);
    RefDS(_331);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _329;
    ((int *)_2)[2] = _331;
    _332 = MAKE_SEQ(_1);
    _329 = NOVALUE;
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _332;
    if( _1 != _332 ){
        DeRef(_1);
    }
    _332 = NOVALUE;

    /** 	Defined_Sets[CS_ASCII 		] = {{0, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 127;
    _333 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _333;
    _334 = MAKE_SEQ(_1);
    _333 = NOVALUE;
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _334;
    if( _1 != _334 ){
        DeRef(_1);
    }
    _334 = NOVALUE;

    /** 	Defined_Sets[CS_Digit 		] = {{'0', '9'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_289);
    *((int *)(_2+4)) = _289;
    _335 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _335;
    if( _1 != _335 ){
        DeRef(_1);
    }
    _335 = NOVALUE;

    /** 	Defined_Sets[CS_Graphic 	] = {{'!', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_337);
    *((int *)(_2+4)) = _337;
    _338 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _338;
    if( _1 != _338 ){
        DeRef(_1);
    }
    _338 = NOVALUE;

    /** 	Defined_Sets[CS_Bytes	 	] = {{0, 255}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 255;
    _340 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _340;
    _341 = MAKE_SEQ(_1);
    _340 = NOVALUE;
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _341;
    if( _1 != _341 ){
        DeRef(_1);
    }
    _341 = NOVALUE;

    /** 	Defined_Sets[CS_SpecWord 	] = "_"*/
    RefDS(_342);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _342;
    DeRef(_1);

    /** 	Defined_Sets[CS_Boolean     ] = {TRUE,FALSE}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _7TRUE_445;
    ((int *)_2)[2] = _7FALSE_443;
    _343 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _343;
    if( _1 != _343 ){
        DeRef(_1);
    }
    _343 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _7get_charsets()
{
    int _result__610 = NOVALUE;
    int _347 = NOVALUE;
    int _346 = NOVALUE;
    int _345 = NOVALUE;
    int _344 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_ = {}*/
    RefDS(_5);
    DeRef(_result__610);
    _result__610 = _5;

    /** 	for i = CS_FIRST + 1 to CS_LAST - 1 do*/
    _344 = 1;
    _345 = 19;
    {
        int _i_612;
        _i_612 = 1;
L1: 
        if (_i_612 > 19){
            goto L2; // [18] 48
        }

        /** 		result_ = append(result_, {i, Defined_Sets[i]} )*/
        _2 = (int)SEQ_PTR(_7Defined_Sets_538);
        _346 = (int)*(((s1_ptr)_2)->base + _i_612);
        Ref(_346);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_612;
        ((int *)_2)[2] = _346;
        _347 = MAKE_SEQ(_1);
        _346 = NOVALUE;
        RefDS(_347);
        Append(&_result__610, _result__610, _347);
        DeRefDS(_347);
        _347 = NOVALUE;

        /** 	end for*/
        _i_612 = _i_612 + 1;
        goto L1; // [43] 25
L2: 
        ;
    }

    /** 	return result_*/
    DeRef(_344);
    _344 = NOVALUE;
    DeRef(_345);
    _345 = NOVALUE;
    return _result__610;
    ;
}


void  __stdcall _7set_charsets(int _charset_list_620)
{
    int _370 = NOVALUE;
    int _369 = NOVALUE;
    int _368 = NOVALUE;
    int _367 = NOVALUE;
    int _366 = NOVALUE;
    int _365 = NOVALUE;
    int _364 = NOVALUE;
    int _363 = NOVALUE;
    int _362 = NOVALUE;
    int _361 = NOVALUE;
    int _360 = NOVALUE;
    int _359 = NOVALUE;
    int _358 = NOVALUE;
    int _357 = NOVALUE;
    int _356 = NOVALUE;
    int _355 = NOVALUE;
    int _354 = NOVALUE;
    int _353 = NOVALUE;
    int _352 = NOVALUE;
    int _351 = NOVALUE;
    int _350 = NOVALUE;
    int _349 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(charset_list) do*/
    if (IS_SEQUENCE(_charset_list_620)){
            _349 = SEQ_PTR(_charset_list_620)->length;
    }
    else {
        _349 = 1;
    }
    {
        int _i_622;
        _i_622 = 1;
L1: 
        if (_i_622 > _349){
            goto L2; // [8] 129
        }

        /** 		if sequence(charset_list[i]) and length(charset_list[i]) = 2 then*/
        _2 = (int)SEQ_PTR(_charset_list_620);
        _350 = (int)*(((s1_ptr)_2)->base + _i_622);
        _351 = IS_SEQUENCE(_350);
        _350 = NOVALUE;
        if (_351 == 0) {
            goto L3; // [24] 122
        }
        _2 = (int)SEQ_PTR(_charset_list_620);
        _353 = (int)*(((s1_ptr)_2)->base + _i_622);
        if (IS_SEQUENCE(_353)){
                _354 = SEQ_PTR(_353)->length;
        }
        else {
            _354 = 1;
        }
        _353 = NOVALUE;
        _355 = (_354 == 2);
        _354 = NOVALUE;
        if (_355 == 0)
        {
            DeRef(_355);
            _355 = NOVALUE;
            goto L3; // [40] 122
        }
        else{
            DeRef(_355);
            _355 = NOVALUE;
        }

        /** 			if integer(charset_list[i][1]) and charset_list[i][1] > CS_FIRST and charset_list[i][1] < CS_LAST then*/
        _2 = (int)SEQ_PTR(_charset_list_620);
        _356 = (int)*(((s1_ptr)_2)->base + _i_622);
        _2 = (int)SEQ_PTR(_356);
        _357 = (int)*(((s1_ptr)_2)->base + 1);
        _356 = NOVALUE;
        if (IS_ATOM_INT(_357))
        _358 = 1;
        else if (IS_ATOM_DBL(_357))
        _358 = IS_ATOM_INT(DoubleToInt(_357));
        else
        _358 = 0;
        _357 = NOVALUE;
        if (_358 == 0) {
            _359 = 0;
            goto L4; // [56] 76
        }
        _2 = (int)SEQ_PTR(_charset_list_620);
        _360 = (int)*(((s1_ptr)_2)->base + _i_622);
        _2 = (int)SEQ_PTR(_360);
        _361 = (int)*(((s1_ptr)_2)->base + 1);
        _360 = NOVALUE;
        if (IS_ATOM_INT(_361)) {
            _362 = (_361 > 0);
        }
        else {
            _362 = binary_op(GREATER, _361, 0);
        }
        _361 = NOVALUE;
        if (IS_ATOM_INT(_362))
        _359 = (_362 != 0);
        else
        _359 = DBL_PTR(_362)->dbl != 0.0;
L4: 
        if (_359 == 0) {
            goto L5; // [76] 121
        }
        _2 = (int)SEQ_PTR(_charset_list_620);
        _364 = (int)*(((s1_ptr)_2)->base + _i_622);
        _2 = (int)SEQ_PTR(_364);
        _365 = (int)*(((s1_ptr)_2)->base + 1);
        _364 = NOVALUE;
        if (IS_ATOM_INT(_365)) {
            _366 = (_365 < 20);
        }
        else {
            _366 = binary_op(LESS, _365, 20);
        }
        _365 = NOVALUE;
        if (_366 == 0) {
            DeRef(_366);
            _366 = NOVALUE;
            goto L5; // [93] 121
        }
        else {
            if (!IS_ATOM_INT(_366) && DBL_PTR(_366)->dbl == 0.0){
                DeRef(_366);
                _366 = NOVALUE;
                goto L5; // [93] 121
            }
            DeRef(_366);
            _366 = NOVALUE;
        }
        DeRef(_366);
        _366 = NOVALUE;

        /** 				Defined_Sets[charset_list[i][1]] = charset_list[i][2]*/
        _2 = (int)SEQ_PTR(_charset_list_620);
        _367 = (int)*(((s1_ptr)_2)->base + _i_622);
        _2 = (int)SEQ_PTR(_367);
        _368 = (int)*(((s1_ptr)_2)->base + 1);
        _367 = NOVALUE;
        _2 = (int)SEQ_PTR(_charset_list_620);
        _369 = (int)*(((s1_ptr)_2)->base + _i_622);
        _2 = (int)SEQ_PTR(_369);
        _370 = (int)*(((s1_ptr)_2)->base + 2);
        _369 = NOVALUE;
        Ref(_370);
        _2 = (int)SEQ_PTR(_7Defined_Sets_538);
        if (!IS_ATOM_INT(_368))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_368)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _368);
        _1 = *(int *)_2;
        *(int *)_2 = _370;
        if( _1 != _370 ){
            DeRef(_1);
        }
        _370 = NOVALUE;
L5: 
L3: 

        /** 	end for*/
        _i_622 = _i_622 + 1;
        goto L1; // [124] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_charset_list_620);
    _353 = NOVALUE;
    _368 = NOVALUE;
    DeRef(_362);
    _362 = NOVALUE;
    return;
    ;
}


int  __stdcall _7boolean(int _test_data_649)
{
    int _373 = NOVALUE;
    int _372 = NOVALUE;
    int _371 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(test_data,{1,0}) != 0*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _371 = MAKE_SEQ(_1);
    _372 = find_from(_test_data_649, _371, 1);
    DeRefDS(_371);
    _371 = NOVALUE;
    _373 = (_372 != 0);
    _372 = NOVALUE;
    DeRef(_test_data_649);
    return _373;
    ;
}


int  __stdcall _7t_boolean(int _test_data_655)
{
    int _375 = NOVALUE;
    int _374 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Boolean])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _374 = (int)*(((s1_ptr)_2)->base + 19);
    Ref(_test_data_655);
    Ref(_374);
    _375 = _7char_test(_test_data_655, _374);
    _374 = NOVALUE;
    DeRef(_test_data_655);
    return _375;
    ;
}


int  __stdcall _7t_alnum(int _test_data_660)
{
    int _377 = NOVALUE;
    int _376 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphanumeric])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _376 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_test_data_660);
    Ref(_376);
    _377 = _7char_test(_test_data_660, _376);
    _376 = NOVALUE;
    DeRef(_test_data_660);
    return _377;
    ;
}


int  __stdcall _7t_identifier(int _test_data_665)
{
    int _387 = NOVALUE;
    int _386 = NOVALUE;
    int _385 = NOVALUE;
    int _384 = NOVALUE;
    int _383 = NOVALUE;
    int _382 = NOVALUE;
    int _381 = NOVALUE;
    int _380 = NOVALUE;
    int _379 = NOVALUE;
    int _378 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if t_digit(test_data) then*/
    Ref(_test_data_665);
    _378 = _7t_digit(_test_data_665);
    if (_378 == 0) {
        DeRef(_378);
        _378 = NOVALUE;
        goto L1; // [7] 19
    }
    else {
        if (!IS_ATOM_INT(_378) && DBL_PTR(_378)->dbl == 0.0){
            DeRef(_378);
            _378 = NOVALUE;
            goto L1; // [7] 19
        }
        DeRef(_378);
        _378 = NOVALUE;
    }
    DeRef(_378);
    _378 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_665);
    return 0;
    goto L2; // [16] 63
L1: 

    /** 	elsif sequence(test_data) and length(test_data) > 0 and t_digit(test_data[1]) then*/
    _379 = IS_SEQUENCE(_test_data_665);
    if (_379 == 0) {
        _380 = 0;
        goto L3; // [24] 39
    }
    if (IS_SEQUENCE(_test_data_665)){
            _381 = SEQ_PTR(_test_data_665)->length;
    }
    else {
        _381 = 1;
    }
    _382 = (_381 > 0);
    _381 = NOVALUE;
    _380 = (_382 != 0);
L3: 
    if (_380 == 0) {
        goto L4; // [39] 62
    }
    _2 = (int)SEQ_PTR(_test_data_665);
    _384 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_384);
    _385 = _7t_digit(_384);
    _384 = NOVALUE;
    if (_385 == 0) {
        DeRef(_385);
        _385 = NOVALUE;
        goto L4; // [52] 62
    }
    else {
        if (!IS_ATOM_INT(_385) && DBL_PTR(_385)->dbl == 0.0){
            DeRef(_385);
            _385 = NOVALUE;
            goto L4; // [52] 62
        }
        DeRef(_385);
        _385 = NOVALUE;
    }
    DeRef(_385);
    _385 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_665);
    DeRef(_382);
    _382 = NOVALUE;
    return 0;
L4: 
L2: 

    /** 	return char_test(test_data, Defined_Sets[CS_Identifier])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _386 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_test_data_665);
    Ref(_386);
    _387 = _7char_test(_test_data_665, _386);
    _386 = NOVALUE;
    DeRef(_test_data_665);
    DeRef(_382);
    _382 = NOVALUE;
    return _387;
    ;
}


int  __stdcall _7t_alpha(int _test_data_682)
{
    int _389 = NOVALUE;
    int _388 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphabetic])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _388 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_test_data_682);
    Ref(_388);
    _389 = _7char_test(_test_data_682, _388);
    _388 = NOVALUE;
    DeRef(_test_data_682);
    return _389;
    ;
}


int  __stdcall _7t_ascii(int _test_data_687)
{
    int _391 = NOVALUE;
    int _390 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_ASCII])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _390 = (int)*(((s1_ptr)_2)->base + 13);
    Ref(_test_data_687);
    Ref(_390);
    _391 = _7char_test(_test_data_687, _390);
    _390 = NOVALUE;
    DeRef(_test_data_687);
    return _391;
    ;
}


int  __stdcall _7t_cntrl(int _test_data_692)
{
    int _393 = NOVALUE;
    int _392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Control])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _392 = (int)*(((s1_ptr)_2)->base + 14);
    Ref(_test_data_692);
    Ref(_392);
    _393 = _7char_test(_test_data_692, _392);
    _392 = NOVALUE;
    DeRef(_test_data_692);
    return _393;
    ;
}


int  __stdcall _7t_digit(int _test_data_697)
{
    int _395 = NOVALUE;
    int _394 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Digit])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _394 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_test_data_697);
    Ref(_394);
    _395 = _7char_test(_test_data_697, _394);
    _394 = NOVALUE;
    DeRef(_test_data_697);
    return _395;
    ;
}


int  __stdcall _7t_graph(int _test_data_702)
{
    int _397 = NOVALUE;
    int _396 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Graphic])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _396 = (int)*(((s1_ptr)_2)->base + 16);
    Ref(_test_data_702);
    Ref(_396);
    _397 = _7char_test(_test_data_702, _396);
    _396 = NOVALUE;
    DeRef(_test_data_702);
    return _397;
    ;
}


int  __stdcall _7t_specword(int _test_data_707)
{
    int _399 = NOVALUE;
    int _398 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_SpecWord])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _398 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_test_data_707);
    Ref(_398);
    _399 = _7char_test(_test_data_707, _398);
    _398 = NOVALUE;
    DeRef(_test_data_707);
    return _399;
    ;
}


int  __stdcall _7t_bytearray(int _test_data_712)
{
    int _401 = NOVALUE;
    int _400 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Bytes])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _400 = (int)*(((s1_ptr)_2)->base + 17);
    Ref(_test_data_712);
    Ref(_400);
    _401 = _7char_test(_test_data_712, _400);
    _400 = NOVALUE;
    DeRef(_test_data_712);
    return _401;
    ;
}


int  __stdcall _7t_lower(int _test_data_717)
{
    int _403 = NOVALUE;
    int _402 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Lowercase])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _402 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_test_data_717);
    Ref(_402);
    _403 = _7char_test(_test_data_717, _402);
    _402 = NOVALUE;
    DeRef(_test_data_717);
    return _403;
    ;
}


int  __stdcall _7t_print(int _test_data_722)
{
    int _405 = NOVALUE;
    int _404 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Printable])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _404 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_test_data_722);
    Ref(_404);
    _405 = _7char_test(_test_data_722, _404);
    _404 = NOVALUE;
    DeRef(_test_data_722);
    return _405;
    ;
}


int  __stdcall _7t_display(int _test_data_727)
{
    int _407 = NOVALUE;
    int _406 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Displayable])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _406 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_test_data_727);
    Ref(_406);
    _407 = _7char_test(_test_data_727, _406);
    _406 = NOVALUE;
    DeRef(_test_data_727);
    return _407;
    ;
}


int  __stdcall _7t_punct(int _test_data_732)
{
    int _409 = NOVALUE;
    int _408 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Punctuation])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _408 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_test_data_732);
    Ref(_408);
    _409 = _7char_test(_test_data_732, _408);
    _408 = NOVALUE;
    DeRef(_test_data_732);
    return _409;
    ;
}


int  __stdcall _7t_space(int _test_data_737)
{
    int _411 = NOVALUE;
    int _410 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Whitespace])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _410 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_test_data_737);
    Ref(_410);
    _411 = _7char_test(_test_data_737, _410);
    _410 = NOVALUE;
    DeRef(_test_data_737);
    return _411;
    ;
}


int  __stdcall _7t_upper(int _test_data_742)
{
    int _413 = NOVALUE;
    int _412 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Uppercase])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _412 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_test_data_742);
    Ref(_412);
    _413 = _7char_test(_test_data_742, _412);
    _412 = NOVALUE;
    DeRef(_test_data_742);
    return _413;
    ;
}


int  __stdcall _7t_xdigit(int _test_data_747)
{
    int _415 = NOVALUE;
    int _414 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Hexadecimal])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _414 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_test_data_747);
    Ref(_414);
    _415 = _7char_test(_test_data_747, _414);
    _414 = NOVALUE;
    DeRef(_test_data_747);
    return _415;
    ;
}


int  __stdcall _7t_vowel(int _test_data_752)
{
    int _417 = NOVALUE;
    int _416 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Vowel])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _416 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_test_data_752);
    Ref(_416);
    _417 = _7char_test(_test_data_752, _416);
    _416 = NOVALUE;
    DeRef(_test_data_752);
    return _417;
    ;
}


int  __stdcall _7t_consonant(int _test_data_757)
{
    int _419 = NOVALUE;
    int _418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Consonant])*/
    _2 = (int)SEQ_PTR(_7Defined_Sets_538);
    _418 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_test_data_757);
    Ref(_418);
    _419 = _7char_test(_test_data_757, _418);
    _418 = NOVALUE;
    DeRef(_test_data_757);
    return _419;
    ;
}


int  __stdcall _7integer_array(int _x_762)
{
    int _424 = NOVALUE;
    int _423 = NOVALUE;
    int _422 = NOVALUE;
    int _420 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _420 = IS_SEQUENCE(_x_762);
    if (_420 != 0)
    goto L1; // [6] 16
    _420 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_762);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_762)){
            _422 = SEQ_PTR(_x_762)->length;
    }
    else {
        _422 = 1;
    }
    {
        int _i_767;
        _i_767 = 1;
L2: 
        if (_i_767 > _422){
            goto L3; // [21] 54
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_762);
        _423 = (int)*(((s1_ptr)_2)->base + _i_767);
        if (IS_ATOM_INT(_423))
        _424 = 1;
        else if (IS_ATOM_DBL(_423))
        _424 = IS_ATOM_INT(DoubleToInt(_423));
        else
        _424 = 0;
        _423 = NOVALUE;
        if (_424 != 0)
        goto L4; // [37] 47
        _424 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_762);
        return 0;
L4: 

        /** 	end for*/
        _i_767 = _i_767 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_762);
    return 1;
    ;
}


int  __stdcall _7t_text(int _x_775)
{
    int _432 = NOVALUE;
    int _430 = NOVALUE;
    int _429 = NOVALUE;
    int _428 = NOVALUE;
    int _426 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _426 = IS_SEQUENCE(_x_775);
    if (_426 != 0)
    goto L1; // [6] 16
    _426 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_775);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_775)){
            _428 = SEQ_PTR(_x_775)->length;
    }
    else {
        _428 = 1;
    }
    {
        int _i_780;
        _i_780 = 1;
L2: 
        if (_i_780 > _428){
            goto L3; // [21] 71
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_775);
        _429 = (int)*(((s1_ptr)_2)->base + _i_780);
        if (IS_ATOM_INT(_429))
        _430 = 1;
        else if (IS_ATOM_DBL(_429))
        _430 = IS_ATOM_INT(DoubleToInt(_429));
        else
        _430 = 0;
        _429 = NOVALUE;
        if (_430 != 0)
        goto L4; // [37] 47
        _430 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_775);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_775);
        _432 = (int)*(((s1_ptr)_2)->base + _i_780);
        if (binary_op_a(GREATEREQ, _432, 0)){
            _432 = NOVALUE;
            goto L5; // [53] 64
        }
        _432 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_775);
        return 0;
L5: 

        /** 	end for*/
        _i_780 = _i_780 + 1;
        goto L2; // [66] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_775);
    return 1;
    ;
}


int  __stdcall _7number_array(int _x_791)
{
    int _438 = NOVALUE;
    int _437 = NOVALUE;
    int _436 = NOVALUE;
    int _434 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _434 = IS_SEQUENCE(_x_791);
    if (_434 != 0)
    goto L1; // [6] 16
    _434 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_791);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_791)){
            _436 = SEQ_PTR(_x_791)->length;
    }
    else {
        _436 = 1;
    }
    {
        int _i_796;
        _i_796 = 1;
L2: 
        if (_i_796 > _436){
            goto L3; // [21] 54
        }

        /** 		if not atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_791);
        _437 = (int)*(((s1_ptr)_2)->base + _i_796);
        _438 = IS_ATOM(_437);
        _437 = NOVALUE;
        if (_438 != 0)
        goto L4; // [37] 47
        _438 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_791);
        return 0;
L4: 

        /** 	end for*/
        _i_796 = _i_796 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_791);
    return 1;
    ;
}


int  __stdcall _7sequence_array(int _x_804)
{
    int _444 = NOVALUE;
    int _443 = NOVALUE;
    int _442 = NOVALUE;
    int _440 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _440 = IS_SEQUENCE(_x_804);
    if (_440 != 0)
    goto L1; // [6] 16
    _440 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_804);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_804)){
            _442 = SEQ_PTR(_x_804)->length;
    }
    else {
        _442 = 1;
    }
    {
        int _i_809;
        _i_809 = 1;
L2: 
        if (_i_809 > _442){
            goto L3; // [21] 54
        }

        /** 		if not sequence(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_804);
        _443 = (int)*(((s1_ptr)_2)->base + _i_809);
        _444 = IS_SEQUENCE(_443);
        _443 = NOVALUE;
        if (_444 != 0)
        goto L4; // [37] 47
        _444 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_804);
        return 0;
L4: 

        /** 	end for*/
        _i_809 = _i_809 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_804);
    return 1;
    ;
}


int  __stdcall _7ascii_string(int _x_817)
{
    int _454 = NOVALUE;
    int _452 = NOVALUE;
    int _450 = NOVALUE;
    int _449 = NOVALUE;
    int _448 = NOVALUE;
    int _446 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _446 = IS_SEQUENCE(_x_817);
    if (_446 != 0)
    goto L1; // [6] 16
    _446 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_817);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_817)){
            _448 = SEQ_PTR(_x_817)->length;
    }
    else {
        _448 = 1;
    }
    {
        int _i_822;
        _i_822 = 1;
L2: 
        if (_i_822 > _448){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_817);
        _449 = (int)*(((s1_ptr)_2)->base + _i_822);
        if (IS_ATOM_INT(_449))
        _450 = 1;
        else if (IS_ATOM_DBL(_449))
        _450 = IS_ATOM_INT(DoubleToInt(_449));
        else
        _450 = 0;
        _449 = NOVALUE;
        if (_450 != 0)
        goto L4; // [37] 47
        _450 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_817);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_817);
        _452 = (int)*(((s1_ptr)_2)->base + _i_822);
        if (binary_op_a(GREATEREQ, _452, 0)){
            _452 = NOVALUE;
            goto L5; // [53] 64
        }
        _452 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_817);
        return 0;
L5: 

        /** 		if x[i] > 127 then*/
        _2 = (int)SEQ_PTR(_x_817);
        _454 = (int)*(((s1_ptr)_2)->base + _i_822);
        if (binary_op_a(LESSEQ, _454, 127)){
            _454 = NOVALUE;
            goto L6; // [70] 81
        }
        _454 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_817);
        return 0;
L6: 

        /** 	end for*/
        _i_822 = _i_822 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_817);
    return 1;
    ;
}


int  __stdcall _7string(int _x_836)
{
    int _464 = NOVALUE;
    int _462 = NOVALUE;
    int _460 = NOVALUE;
    int _459 = NOVALUE;
    int _458 = NOVALUE;
    int _456 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _456 = IS_SEQUENCE(_x_836);
    if (_456 != 0)
    goto L1; // [6] 16
    _456 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_836);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_836)){
            _458 = SEQ_PTR(_x_836)->length;
    }
    else {
        _458 = 1;
    }
    {
        int _i_841;
        _i_841 = 1;
L2: 
        if (_i_841 > _458){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_836);
        _459 = (int)*(((s1_ptr)_2)->base + _i_841);
        if (IS_ATOM_INT(_459))
        _460 = 1;
        else if (IS_ATOM_DBL(_459))
        _460 = IS_ATOM_INT(DoubleToInt(_459));
        else
        _460 = 0;
        _459 = NOVALUE;
        if (_460 != 0)
        goto L4; // [37] 47
        _460 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_836);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_836);
        _462 = (int)*(((s1_ptr)_2)->base + _i_841);
        if (binary_op_a(GREATEREQ, _462, 0)){
            _462 = NOVALUE;
            goto L5; // [53] 64
        }
        _462 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_836);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_836);
        _464 = (int)*(((s1_ptr)_2)->base + _i_841);
        if (binary_op_a(LESSEQ, _464, 255)){
            _464 = NOVALUE;
            goto L6; // [70] 81
        }
        _464 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_836);
        return 0;
L6: 

        /** 	end for*/
        _i_841 = _i_841 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_836);
    return 1;
    ;
}


int  __stdcall _7cstring(int _x_855)
{
    int _474 = NOVALUE;
    int _472 = NOVALUE;
    int _470 = NOVALUE;
    int _469 = NOVALUE;
    int _468 = NOVALUE;
    int _466 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _466 = IS_SEQUENCE(_x_855);
    if (_466 != 0)
    goto L1; // [6] 16
    _466 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_855);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_855)){
            _468 = SEQ_PTR(_x_855)->length;
    }
    else {
        _468 = 1;
    }
    {
        int _i_860;
        _i_860 = 1;
L2: 
        if (_i_860 > _468){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_855);
        _469 = (int)*(((s1_ptr)_2)->base + _i_860);
        if (IS_ATOM_INT(_469))
        _470 = 1;
        else if (IS_ATOM_DBL(_469))
        _470 = IS_ATOM_INT(DoubleToInt(_469));
        else
        _470 = 0;
        _469 = NOVALUE;
        if (_470 != 0)
        goto L4; // [37] 47
        _470 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_855);
        return 0;
L4: 

        /** 		if x[i] <= 0 then*/
        _2 = (int)SEQ_PTR(_x_855);
        _472 = (int)*(((s1_ptr)_2)->base + _i_860);
        if (binary_op_a(GREATER, _472, 0)){
            _472 = NOVALUE;
            goto L5; // [53] 64
        }
        _472 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_855);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_855);
        _474 = (int)*(((s1_ptr)_2)->base + _i_860);
        if (binary_op_a(LESSEQ, _474, 255)){
            _474 = NOVALUE;
            goto L6; // [70] 81
        }
        _474 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_855);
        return 0;
L6: 

        /** 	end for*/
        _i_860 = _i_860 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_855);
    return 1;
    ;
}



// 0x7FCEB451
