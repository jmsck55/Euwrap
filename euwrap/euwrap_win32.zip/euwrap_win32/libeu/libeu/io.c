// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _18get_bytes(int _fn_2477, int _n_2478)
{
    int _s_2479 = NOVALUE;
    int _c_2480 = NOVALUE;
    int _first_2481 = NOVALUE;
    int _last_2482 = NOVALUE;
    int _1190 = NOVALUE;
    int _1187 = NOVALUE;
    int _1185 = NOVALUE;
    int _1184 = NOVALUE;
    int _1183 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_2477)) {
        _1 = (long)(DBL_PTR(_fn_2477)->dbl);
        DeRefDS(_fn_2477);
        _fn_2477 = _1;
    }
    if (!IS_ATOM_INT(_n_2478)) {
        _1 = (long)(DBL_PTR(_n_2478)->dbl);
        DeRefDS(_n_2478);
        _n_2478 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_2478 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2479);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_2477 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_2477, EF_READ);
        last_r_file_no = _fn_2477;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_2480 = getKBchar();
        }
        else
        _c_2480 = getc(last_r_file_ptr);
    }
    else
    _c_2480 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_2480 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2479);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_2479);
    _s_2479 = Repeat(_c_2480, _n_2478);

    /** 	last = 1*/
    _last_2482 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_2482 >= _n_2478)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_2481 = _last_2482 + 1;

    /** 		last  = last+CHUNK*/
    _last_2482 = _last_2482 + 100;

    /** 		if last > n then*/
    if (_last_2482 <= _n_2478)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_2482 = _n_2478;
L5: 

    /** 		for i = first to last do*/
    _1183 = _last_2482;
    {
        int _i_2496;
        _i_2496 = _first_2481;
L6: 
        if (_i_2496 > _1183){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_2477 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_2477, EF_READ);
            last_r_file_no = _fn_2477;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _1184 = getKBchar();
            }
            else
            _1184 = getc(last_r_file_ptr);
        }
        else
        _1184 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_2479);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_2479 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2496);
        *(int *)_2 = _1184;
        if( _1 != _1184 ){
        }
        _1184 = NOVALUE;

        /** 		end for*/
        _i_2496 = _i_2496 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_2479);
    _1185 = (int)*(((s1_ptr)_2)->base + _last_2482);
    if (_1185 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_2479);
    _1187 = (int)*(((s1_ptr)_2)->base + _last_2482);
    if (_1187 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_2482 = _last_2482 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_1190;
    RHS_Slice(_s_2479, 1, _last_2482);
    DeRefDSi(_s_2479);
    _1185 = NOVALUE;
    _1187 = NOVALUE;
    return _1190;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _1185 = NOVALUE;
    _1187 = NOVALUE;
    DeRef(_1190);
    _1190 = NOVALUE;
    return _s_2479;
    ;
}


int  __stdcall _18get_integer32(int _fh_2517)
{
    int _1199 = NOVALUE;
    int _1198 = NOVALUE;
    int _1197 = NOVALUE;
    int _1196 = NOVALUE;
    int _1195 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2517)) {
        _1 = (long)(DBL_PTR(_fh_2517)->dbl);
        DeRefDS(_fh_2517);
        _fh_2517 = _1;
    }

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2517 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2517, EF_READ);
        last_r_file_no = _fh_2517;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1195 = getKBchar();
        }
        else
        _1195 = getc(last_r_file_ptr);
    }
    else
    _1195 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2507)){
        poke_addr = (unsigned char *)_18mem0_2507;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
    }
    *poke_addr = (unsigned char)_1195;
    _1195 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2517 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2517, EF_READ);
        last_r_file_no = _fh_2517;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1196 = getKBchar();
        }
        else
        _1196 = getc(last_r_file_ptr);
    }
    else
    _1196 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2508)){
        poke_addr = (unsigned char *)_18mem1_2508;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2508)->dbl);
    }
    *poke_addr = (unsigned char)_1196;
    _1196 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_2517 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2517, EF_READ);
        last_r_file_no = _fh_2517;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1197 = getKBchar();
        }
        else
        _1197 = getc(last_r_file_ptr);
    }
    else
    _1197 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem2_2509)){
        poke_addr = (unsigned char *)_18mem2_2509;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem2_2509)->dbl);
    }
    *poke_addr = (unsigned char)_1197;
    _1197 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_2517 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2517, EF_READ);
        last_r_file_no = _fh_2517;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1198 = getKBchar();
        }
        else
        _1198 = getc(last_r_file_ptr);
    }
    else
    _1198 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem3_2510)){
        poke_addr = (unsigned char *)_18mem3_2510;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem3_2510)->dbl);
    }
    *poke_addr = (unsigned char)_1198;
    _1198 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2507)) {
        _1199 = *(unsigned long *)_18mem0_2507;
        if ((unsigned)_1199 > (unsigned)MAXINT)
        _1199 = NewDouble((double)(unsigned long)_1199);
    }
    else {
        _1199 = *(unsigned long *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
        if ((unsigned)_1199 > (unsigned)MAXINT)
        _1199 = NewDouble((double)(unsigned long)_1199);
    }
    return _1199;
    ;
}


int  __stdcall _18get_integer16(int _fh_2525)
{
    int _1202 = NOVALUE;
    int _1201 = NOVALUE;
    int _1200 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2525)) {
        _1 = (long)(DBL_PTR(_fh_2525)->dbl);
        DeRefDS(_fh_2525);
        _fh_2525 = _1;
    }

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2525 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2525, EF_READ);
        last_r_file_no = _fh_2525;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1200 = getKBchar();
        }
        else
        _1200 = getc(last_r_file_ptr);
    }
    else
    _1200 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2507)){
        poke_addr = (unsigned char *)_18mem0_2507;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
    }
    *poke_addr = (unsigned char)_1200;
    _1200 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2525 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2525, EF_READ);
        last_r_file_no = _fh_2525;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _1201 = getKBchar();
        }
        else
        _1201 = getc(last_r_file_ptr);
    }
    else
    _1201 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2508)){
        poke_addr = (unsigned char *)_18mem1_2508;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2508)->dbl);
    }
    *poke_addr = (unsigned char)_1201;
    _1201 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2507)) {
        _1202 = *(unsigned short *)_18mem0_2507;
    }
    else {
        _1202 = *(unsigned short *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
    }
    return _1202;
    ;
}


void  __stdcall _18put_integer32(int _fh_2531, int _val_2532)
{
    int _1204 = NOVALUE;
    int _1203 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2531)) {
        _1 = (long)(DBL_PTR(_fh_2531)->dbl);
        DeRefDS(_fh_2531);
        _fh_2531 = _1;
    }

    /** 	poke4(mem0, val)*/
    if (IS_ATOM_INT(_18mem0_2507)){
        poke4_addr = (unsigned long *)_18mem0_2507;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
    }
    if (IS_ATOM_INT(_val_2532)) {
        *poke4_addr = (unsigned long)_val_2532;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_val_2532)->dbl;
    }

    /** 	puts(fh, peek({mem0,4}))*/
    Ref(_18mem0_2507);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _18mem0_2507;
    ((int *)_2)[2] = 4;
    _1203 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1203);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1204 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1203);
    _1203 = NOVALUE;
    EPuts(_fh_2531, _1204); // DJP 
    DeRefDS(_1204);
    _1204 = NOVALUE;

    /** end procedure*/
    DeRef(_val_2532);
    return;
    ;
}


void  __stdcall _18put_integer16(int _fh_2537, int _val_2538)
{
    int _1206 = NOVALUE;
    int _1205 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2537)) {
        _1 = (long)(DBL_PTR(_fh_2537)->dbl);
        DeRefDS(_fh_2537);
        _fh_2537 = _1;
    }

    /** 	poke2(mem0, val)*/
    if (IS_ATOM_INT(_18mem0_2507)){
        poke2_addr = (unsigned short *)_18mem0_2507;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_18mem0_2507)->dbl);
    }
    if (IS_ATOM_INT(_val_2538)) {
        *poke2_addr = (unsigned short)_val_2538;
    }
    else {
        *poke_addr = (signed char)DBL_PTR(_val_2538)->dbl;
    }

    /** 	puts(fh, peek({mem0,2}))*/
    Ref(_18mem0_2507);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _18mem0_2507;
    ((int *)_2)[2] = 2;
    _1205 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1205);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1206 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1205);
    _1205 = NOVALUE;
    EPuts(_fh_2537, _1206); // DJP 
    DeRefDS(_1206);
    _1206 = NOVALUE;

    /** end procedure*/
    DeRef(_val_2538);
    return;
    ;
}


int  __stdcall _18get_dstring(int _fh_2543, int _delim_2544)
{
    int _s_2545 = NOVALUE;
    int _c_2546 = NOVALUE;
    int _i_2547 = NOVALUE;
    int _1216 = NOVALUE;
    int _1212 = NOVALUE;
    int _1210 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2543)) {
        _1 = (long)(DBL_PTR(_fh_2543)->dbl);
        DeRefDS(_fh_2543);
        _fh_2543 = _1;
    }
    if (!IS_ATOM_INT(_delim_2544)) {
        _1 = (long)(DBL_PTR(_delim_2544)->dbl);
        DeRefDS(_delim_2544);
        _delim_2544 = _1;
    }

    /** 	s = repeat(-1, 256)*/
    DeRefi(_s_2545);
    _s_2545 = Repeat(-1, 256);

    /** 	i = 0*/
    _i_2547 = 0;

    /** 	while c != delim with entry do*/
    goto L1; // [18] 73
L2: 
    if (_c_2546 == _delim_2544)
    goto L3; // [23] 83

    /** 		i += 1*/
    _i_2547 = _i_2547 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_2545)){
            _1210 = SEQ_PTR(_s_2545)->length;
    }
    else {
        _1210 = 1;
    }
    if (_i_2547 <= _1210)
    goto L4; // [38] 53

    /** 			s &= repeat(-1, 256)*/
    _1212 = Repeat(-1, 256);
    Concat((object_ptr)&_s_2545, _s_2545, _1212);
    DeRefDS(_1212);
    _1212 = NOVALUE;
L4: 

    /** 		if c = -1 then*/
    if (_c_2546 != -1)
    goto L5; // [55] 64

    /** 			exit*/
    goto L3; // [61] 83
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_2545);
    _2 = (int)(((s1_ptr)_2)->base + _i_2547);
    *(int *)_2 = _c_2546;

    /** 	  entry*/
L1: 

    /** 		c = getc(fh)*/
    if (_fh_2543 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2543, EF_READ);
        last_r_file_no = _fh_2543;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_2546 = getKBchar();
        }
        else
        _c_2546 = getc(last_r_file_ptr);
    }
    else
    _c_2546 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [80] 21
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_1216;
    RHS_Slice(_s_2545, 1, _i_2547);
    DeRefDSi(_s_2545);
    return _1216;
    ;
}


int  __stdcall _18file_number(int _f_2565)
{
    int _1219 = NOVALUE;
    int _1218 = NOVALUE;
    int _1217 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(f) and f >= 0 then*/
    if (IS_ATOM_INT(_f_2565))
    _1217 = 1;
    else if (IS_ATOM_DBL(_f_2565))
    _1217 = IS_ATOM_INT(DoubleToInt(_f_2565));
    else
    _1217 = 0;
    if (_1217 == 0) {
        goto L1; // [6] 27
    }
    if (IS_ATOM_INT(_f_2565)) {
        _1219 = (_f_2565 >= 0);
    }
    else {
        _1219 = binary_op(GREATEREQ, _f_2565, 0);
    }
    if (_1219 == 0) {
        DeRef(_1219);
        _1219 = NOVALUE;
        goto L1; // [15] 27
    }
    else {
        if (!IS_ATOM_INT(_1219) && DBL_PTR(_1219)->dbl == 0.0){
            DeRef(_1219);
            _1219 = NOVALUE;
            goto L1; // [15] 27
        }
        DeRef(_1219);
        _1219 = NOVALUE;
    }
    DeRef(_1219);
    _1219 = NOVALUE;

    /** 		return 1*/
    DeRef(_f_2565);
    return 1;
    goto L2; // [24] 34
L1: 

    /** 		return 0*/
    DeRef(_f_2565);
    return 0;
L2: 
    ;
}


int  __stdcall _18file_position(int _p_2573)
{
    int _1222 = NOVALUE;
    int _1221 = NOVALUE;
    int _1220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(p) and p >= -1 then*/
    _1220 = IS_ATOM(_p_2573);
    if (_1220 == 0) {
        goto L1; // [6] 27
    }
    if (IS_ATOM_INT(_p_2573)) {
        _1222 = (_p_2573 >= -1);
    }
    else {
        _1222 = binary_op(GREATEREQ, _p_2573, -1);
    }
    if (_1222 == 0) {
        DeRef(_1222);
        _1222 = NOVALUE;
        goto L1; // [15] 27
    }
    else {
        if (!IS_ATOM_INT(_1222) && DBL_PTR(_1222)->dbl == 0.0){
            DeRef(_1222);
            _1222 = NOVALUE;
            goto L1; // [15] 27
        }
        DeRef(_1222);
        _1222 = NOVALUE;
    }
    DeRef(_1222);
    _1222 = NOVALUE;

    /** 		return 1*/
    DeRef(_p_2573);
    return 1;
    goto L2; // [24] 34
L1: 

    /** 		return 0*/
    DeRef(_p_2573);
    return 0;
L2: 
    ;
}


int  __stdcall _18lock_type(int _t_2581)
{
    int _1227 = NOVALUE;
    int _1226 = NOVALUE;
    int _1225 = NOVALUE;
    int _1224 = NOVALUE;
    int _1223 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(t) and (t = LOCK_SHARED or t = LOCK_EXCLUSIVE) then*/
    if (IS_ATOM_INT(_t_2581))
    _1223 = 1;
    else if (IS_ATOM_DBL(_t_2581))
    _1223 = IS_ATOM_INT(DoubleToInt(_t_2581));
    else
    _1223 = 0;
    if (_1223 == 0) {
        goto L1; // [6] 39
    }
    if (IS_ATOM_INT(_t_2581)) {
        _1225 = (_t_2581 == 1);
    }
    else {
        _1225 = binary_op(EQUALS, _t_2581, 1);
    }
    if (IS_ATOM_INT(_1225)) {
        if (_1225 != 0) {
            _1226 = 1;
            goto L2; // [14] 26
        }
    }
    else {
        if (DBL_PTR(_1225)->dbl != 0.0) {
            _1226 = 1;
            goto L2; // [14] 26
        }
    }
    if (IS_ATOM_INT(_t_2581)) {
        _1227 = (_t_2581 == 2);
    }
    else {
        _1227 = binary_op(EQUALS, _t_2581, 2);
    }
    DeRef(_1226);
    if (IS_ATOM_INT(_1227))
    _1226 = (_1227 != 0);
    else
    _1226 = DBL_PTR(_1227)->dbl != 0.0;
L2: 
    if (_1226 == 0)
    {
        _1226 = NOVALUE;
        goto L1; // [27] 39
    }
    else{
        _1226 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_t_2581);
    DeRef(_1225);
    _1225 = NOVALUE;
    DeRef(_1227);
    _1227 = NOVALUE;
    return 1;
    goto L3; // [36] 46
L1: 

    /** 		return 0*/
    DeRef(_t_2581);
    DeRef(_1225);
    _1225 = NOVALUE;
    DeRef(_1227);
    _1227 = NOVALUE;
    return 0;
L3: 
    ;
}


int  __stdcall _18byte_range(int _r_2591)
{
    int _1246 = NOVALUE;
    int _1245 = NOVALUE;
    int _1244 = NOVALUE;
    int _1243 = NOVALUE;
    int _1242 = NOVALUE;
    int _1240 = NOVALUE;
    int _1239 = NOVALUE;
    int _1237 = NOVALUE;
    int _1236 = NOVALUE;
    int _1235 = NOVALUE;
    int _1234 = NOVALUE;
    int _1233 = NOVALUE;
    int _1231 = NOVALUE;
    int _1229 = NOVALUE;
    int _1228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(r) then*/
    _1228 = IS_ATOM(_r_2591);
    if (_1228 == 0)
    {
        _1228 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1228 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_r_2591);
    return 0;
L1: 

    /** 	if length(r) = 0 then*/
    if (IS_SEQUENCE(_r_2591)){
            _1229 = SEQ_PTR(_r_2591)->length;
    }
    else {
        _1229 = 1;
    }
    if (_1229 != 0)
    goto L2; // [21] 32

    /** 		return 1*/
    DeRef(_r_2591);
    return 1;
L2: 

    /** 	if length(r) != 2 then*/
    if (IS_SEQUENCE(_r_2591)){
            _1231 = SEQ_PTR(_r_2591)->length;
    }
    else {
        _1231 = 1;
    }
    if (_1231 == 2)
    goto L3; // [37] 48

    /** 		return 0*/
    DeRef(_r_2591);
    return 0;
L3: 

    /** 	if not (atom(r[1]) and atom(r[2])) then*/
    _2 = (int)SEQ_PTR(_r_2591);
    _1233 = (int)*(((s1_ptr)_2)->base + 1);
    _1234 = IS_ATOM(_1233);
    _1233 = NOVALUE;
    if (_1234 == 0) {
        DeRef(_1235);
        _1235 = 0;
        goto L4; // [57] 72
    }
    _2 = (int)SEQ_PTR(_r_2591);
    _1236 = (int)*(((s1_ptr)_2)->base + 2);
    _1237 = IS_ATOM(_1236);
    _1236 = NOVALUE;
    _1235 = (_1237 != 0);
L4: 
    if (_1235 != 0)
    goto L5; // [72] 82
    _1235 = NOVALUE;

    /** 		return 0*/
    DeRef(_r_2591);
    return 0;
L5: 

    /** 	if r[1] < 0 or r[2] < 0 then*/
    _2 = (int)SEQ_PTR(_r_2591);
    _1239 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1239)) {
        _1240 = (_1239 < 0);
    }
    else {
        _1240 = binary_op(LESS, _1239, 0);
    }
    _1239 = NOVALUE;
    if (IS_ATOM_INT(_1240)) {
        if (_1240 != 0) {
            goto L6; // [92] 109
        }
    }
    else {
        if (DBL_PTR(_1240)->dbl != 0.0) {
            goto L6; // [92] 109
        }
    }
    _2 = (int)SEQ_PTR(_r_2591);
    _1242 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1242)) {
        _1243 = (_1242 < 0);
    }
    else {
        _1243 = binary_op(LESS, _1242, 0);
    }
    _1242 = NOVALUE;
    if (_1243 == 0) {
        DeRef(_1243);
        _1243 = NOVALUE;
        goto L7; // [105] 116
    }
    else {
        if (!IS_ATOM_INT(_1243) && DBL_PTR(_1243)->dbl == 0.0){
            DeRef(_1243);
            _1243 = NOVALUE;
            goto L7; // [105] 116
        }
        DeRef(_1243);
        _1243 = NOVALUE;
    }
    DeRef(_1243);
    _1243 = NOVALUE;
L6: 

    /** 		return 0*/
    DeRef(_r_2591);
    DeRef(_1240);
    _1240 = NOVALUE;
    return 0;
L7: 

    /** 	return r[1] <= r[2]*/
    _2 = (int)SEQ_PTR(_r_2591);
    _1244 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_r_2591);
    _1245 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1244) && IS_ATOM_INT(_1245)) {
        _1246 = (_1244 <= _1245);
    }
    else {
        _1246 = binary_op(LESSEQ, _1244, _1245);
    }
    _1244 = NOVALUE;
    _1245 = NOVALUE;
    DeRef(_r_2591);
    DeRef(_1240);
    _1240 = NOVALUE;
    return _1246;
    ;
}


int  __stdcall _18seek(int _fn_2618, int _pos_2619)
{
    int _1248 = NOVALUE;
    int _1247 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_2619);
    Ref(_fn_2618);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2618;
    ((int *)_2)[2] = _pos_2619;
    _1247 = MAKE_SEQ(_1);
    _1248 = machine(19, _1247);
    DeRefDS(_1247);
    _1247 = NOVALUE;
    DeRef(_fn_2618);
    DeRef(_pos_2619);
    return _1248;
    ;
}


int  __stdcall _18where(int _fn_2624)
{
    int _1249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _1249 = machine(20, _fn_2624);
    DeRef(_fn_2624);
    return _1249;
    ;
}


void  __stdcall _18flush(int _fn_2628)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_FLUSH, fn)*/
    machine(60, _fn_2628);

    /** end procedure*/
    DeRef(_fn_2628);
    return;
    ;
}


int  __stdcall _18lock_file(int _fn_2631, int _t_2632, int _r_2633)
{
    int _1251 = NOVALUE;
    int _1250 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_2631);
    *((int *)(_2+4)) = _fn_2631;
    Ref(_t_2632);
    *((int *)(_2+8)) = _t_2632;
    Ref(_r_2633);
    *((int *)(_2+12)) = _r_2633;
    _1250 = MAKE_SEQ(_1);
    _1251 = machine(61, _1250);
    DeRefDS(_1250);
    _1250 = NOVALUE;
    DeRef(_fn_2631);
    DeRef(_t_2632);
    DeRef(_r_2633);
    return _1251;
    ;
}


void  __stdcall _18unlock_file(int _fn_2638, int _r_2639)
{
    int _1252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    Ref(_r_2639);
    Ref(_fn_2638);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2638;
    ((int *)_2)[2] = _r_2639;
    _1252 = MAKE_SEQ(_1);
    machine(62, _1252);
    DeRefDS(_1252);
    _1252 = NOVALUE;

    /** end procedure*/
    DeRef(_fn_2638);
    DeRef(_r_2639);
    return;
    ;
}


int  __stdcall _18read_lines(int _file_2643)
{
    int _fn_2644 = NOVALUE;
    int _ret_2645 = NOVALUE;
    int _y_2646 = NOVALUE;
    int _1272 = NOVALUE;
    int _1271 = NOVALUE;
    int _1270 = NOVALUE;
    int _1269 = NOVALUE;
    int _1264 = NOVALUE;
    int _1263 = NOVALUE;
    int _1261 = NOVALUE;
    int _1260 = NOVALUE;
    int _1259 = NOVALUE;
    int _1254 = NOVALUE;
    int _1253 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1253 = IS_SEQUENCE(_file_2643);
    if (_1253 == 0)
    {
        _1253 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _1253 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_2643)){
            _1254 = SEQ_PTR(_file_2643)->length;
    }
    else {
        _1254 = 1;
    }
    if (_1254 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_2644);
    _fn_2644 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_2644);
    _fn_2644 = EOpen(_file_2643, _1256, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_2643);
    DeRef(_fn_2644);
    _fn_2644 = _file_2643;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2644, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_2643);
    DeRef(_fn_2644);
    DeRef(_ret_2645);
    DeRefi(_y_2646);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_2645);
    _ret_2645 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 125
L6: 
    _1259 = IS_SEQUENCE(_y_2646);
    if (_1259 == 0)
    {
        _1259 = NOVALUE;
        goto L7; // [71] 135
    }
    else{
        _1259 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_2646)){
            _1260 = SEQ_PTR(_y_2646)->length;
    }
    else {
        _1260 = 1;
    }
    _2 = (int)SEQ_PTR(_y_2646);
    _1261 = (int)*(((s1_ptr)_2)->base + _1260);
    if (_1261 != 10)
    goto L8; // [83] 104

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_2646)){
            _1263 = SEQ_PTR(_y_2646)->length;
    }
    else {
        _1263 = 1;
    }
    _1264 = _1263 - 1;
    _1263 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_2646;
    RHS_Slice(_y_2646, 1, _1264);

    /** 			ifdef UNIX then*/
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_2646);
    Append(&_ret_2645, _ret_2645, _y_2646);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_2644, 0)){
        goto L9; // [112] 122
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
L9: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_2646);
    _y_2646 = EGets(_fn_2644);

    /** 	end while*/
    goto L6; // [132] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _1269 = IS_SEQUENCE(_file_2643);
    if (_1269 == 0) {
        goto LA; // [140] 160
    }
    if (IS_SEQUENCE(_file_2643)){
            _1271 = SEQ_PTR(_file_2643)->length;
    }
    else {
        _1271 = 1;
    }
    _1272 = (_1271 != 0);
    _1271 = NOVALUE;
    if (_1272 == 0)
    {
        DeRef(_1272);
        _1272 = NOVALUE;
        goto LA; // [152] 160
    }
    else{
        DeRef(_1272);
        _1272 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2644))
    EClose(_fn_2644);
    else
    EClose((int)DBL_PTR(_fn_2644)->dbl);
LA: 

    /** 	return ret*/
    DeRef(_file_2643);
    DeRef(_fn_2644);
    DeRefi(_y_2646);
    _1261 = NOVALUE;
    DeRef(_1264);
    _1264 = NOVALUE;
    return _ret_2645;
    ;
}


int  __stdcall _18process_lines(int _file_2678, int _proc_2679, int _user_data_2680)
{
    int _fh_2681 = NOVALUE;
    int _aLine_2682 = NOVALUE;
    int _res_2683 = NOVALUE;
    int _line_no_2684 = NOVALUE;
    int _1295 = NOVALUE;
    int _1294 = NOVALUE;
    int _1293 = NOVALUE;
    int _1292 = NOVALUE;
    int _1289 = NOVALUE;
    int _1287 = NOVALUE;
    int _1285 = NOVALUE;
    int _1284 = NOVALUE;
    int _1282 = NOVALUE;
    int _1281 = NOVALUE;
    int _1280 = NOVALUE;
    int _1278 = NOVALUE;
    int _1274 = NOVALUE;
    int _1273 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_2679)) {
        _1 = (long)(DBL_PTR(_proc_2679)->dbl);
        DeRefDS(_proc_2679);
        _proc_2679 = _1;
    }

    /** 	integer line_no = 0*/
    _line_no_2684 = 0;

    /** 	res = 0*/
    DeRef(_res_2683);
    _res_2683 = 0;

    /** 	if sequence(file) then*/
    _1273 = IS_SEQUENCE(_file_2678);
    if (_1273 == 0)
    {
        _1273 = NOVALUE;
        goto L1; // [18] 49
    }
    else{
        _1273 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_2678)){
            _1274 = SEQ_PTR(_file_2678)->length;
    }
    else {
        _1274 = 1;
    }
    if (_1274 != 0)
    goto L2; // [26] 38

    /** 			fh = 0*/
    _fh_2681 = 0;
    goto L3; // [35] 57
L2: 

    /** 			fh = open(file, "r")*/
    _fh_2681 = EOpen(_file_2678, _1256, 0);
    goto L3; // [46] 57
L1: 

    /** 		fh = file*/
    Ref(_file_2678);
    _fh_2681 = _file_2678;
    if (!IS_ATOM_INT(_fh_2681)) {
        _1 = (long)(DBL_PTR(_fh_2681)->dbl);
        DeRefDS(_fh_2681);
        _fh_2681 = _1;
    }
L3: 

    /** 	if fh < 0 then */
    if (_fh_2681 >= 0)
    goto L4; // [61] 159

    /** 		return -1 */
    DeRef(_file_2678);
    DeRef(_user_data_2680);
    DeRefi(_aLine_2682);
    DeRef(_res_2683);
    return -1;

    /** 	while sequence(aLine) with entry do*/
    goto L4; // [74] 159
L5: 
    _1278 = IS_SEQUENCE(_aLine_2682);
    if (_1278 == 0)
    {
        _1278 = NOVALUE;
        goto L6; // [82] 169
    }
    else{
        _1278 = NOVALUE;
    }

    /** 		line_no += 1*/
    _line_no_2684 = _line_no_2684 + 1;

    /** 		if length(aLine) then*/
    if (IS_SEQUENCE(_aLine_2682)){
            _1280 = SEQ_PTR(_aLine_2682)->length;
    }
    else {
        _1280 = 1;
    }
    if (_1280 == 0)
    {
        _1280 = NOVALUE;
        goto L7; // [96] 130
    }
    else{
        _1280 = NOVALUE;
    }

    /** 			if aLine[$] = '\n' then*/
    if (IS_SEQUENCE(_aLine_2682)){
            _1281 = SEQ_PTR(_aLine_2682)->length;
    }
    else {
        _1281 = 1;
    }
    _2 = (int)SEQ_PTR(_aLine_2682);
    _1282 = (int)*(((s1_ptr)_2)->base + _1281);
    if (_1282 != 10)
    goto L8; // [108] 129

    /** 				aLine = aLine[1 .. $-1]*/
    if (IS_SEQUENCE(_aLine_2682)){
            _1284 = SEQ_PTR(_aLine_2682)->length;
    }
    else {
        _1284 = 1;
    }
    _1285 = _1284 - 1;
    _1284 = NOVALUE;
    rhs_slice_target = (object_ptr)&_aLine_2682;
    RHS_Slice(_aLine_2682, 1, _1285);

    /** 				ifdef UNIX then*/
L8: 
L7: 

    /** 		res = call_func(proc, {aLine, line_no, user_data})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_aLine_2682);
    *((int *)(_2+4)) = _aLine_2682;
    *((int *)(_2+8)) = _line_no_2684;
    Ref(_user_data_2680);
    *((int *)(_2+12)) = _user_data_2680;
    _1287 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1287);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_proc_2679].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    if (_00[_proc_2679].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12)
                             );
    }
    DeRef(_res_2683);
    _res_2683 = _1;
    DeRefDS(_1287);
    _1287 = NOVALUE;

    /** 		if not equal(res, 0) then*/
    if (_res_2683 == 0)
    _1289 = 1;
    else if (IS_ATOM_INT(_res_2683) && IS_ATOM_INT(0))
    _1289 = 0;
    else
    _1289 = (compare(_res_2683, 0) == 0);
    if (_1289 != 0)
    goto L9; // [148] 156
    _1289 = NOVALUE;

    /** 			exit*/
    goto L6; // [153] 169
L9: 

    /** 	entry*/
L4: 

    /** 		aLine = gets(fh)*/
    DeRefi(_aLine_2682);
    _aLine_2682 = EGets(_fh_2681);

    /** 	end while*/
    goto L5; // [166] 77
L6: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _1292 = IS_SEQUENCE(_file_2678);
    if (_1292 == 0) {
        goto LA; // [174] 194
    }
    if (IS_SEQUENCE(_file_2678)){
            _1294 = SEQ_PTR(_file_2678)->length;
    }
    else {
        _1294 = 1;
    }
    _1295 = (_1294 != 0);
    _1294 = NOVALUE;
    if (_1295 == 0)
    {
        DeRef(_1295);
        _1295 = NOVALUE;
        goto LA; // [186] 194
    }
    else{
        DeRef(_1295);
        _1295 = NOVALUE;
    }

    /** 		close(fh)*/
    EClose(_fh_2681);
LA: 

    /** 	return res*/
    DeRef(_file_2678);
    DeRef(_user_data_2680);
    DeRefi(_aLine_2682);
    _1282 = NOVALUE;
    DeRef(_1285);
    _1285 = NOVALUE;
    return _res_2683;
    ;
}


int  __stdcall _18write_lines(int _file_2720, int _lines_2721)
{
    int _fn_2722 = NOVALUE;
    int _1302 = NOVALUE;
    int _1301 = NOVALUE;
    int _1300 = NOVALUE;
    int _1296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1296 = IS_SEQUENCE(_file_2720);
    if (_1296 == 0)
    {
        _1296 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _1296 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_2722);
    _fn_2722 = EOpen(_file_2720, _1297, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_2720);
    DeRef(_fn_2722);
    _fn_2722 = _file_2720;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2722, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_2720);
    DeRefDS(_lines_2721);
    DeRef(_fn_2722);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_2721)){
            _1300 = SEQ_PTR(_lines_2721)->length;
    }
    else {
        _1300 = 1;
    }
    {
        int _i_2731;
        _i_2731 = 1;
L4: 
        if (_i_2731 > _1300){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_2721);
        _1301 = (int)*(((s1_ptr)_2)->base + _i_2731);
        EPuts(_fn_2722, _1301); // DJP 
        _1301 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_2722, 10); // DJP 

        /** 	end for*/
        _i_2731 = _i_2731 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _1302 = IS_SEQUENCE(_file_2720);
    if (_1302 == 0)
    {
        _1302 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _1302 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2722))
    EClose(_fn_2722);
    else
    EClose((int)DBL_PTR(_fn_2722)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_2720);
    DeRefDS(_lines_2721);
    DeRef(_fn_2722);
    return 1;
    ;
}


int  __stdcall _18append_lines(int _file_2738, int _lines_2739)
{
    int _fn_2740 = NOVALUE;
    int _1307 = NOVALUE;
    int _1306 = NOVALUE;
    int _0, _1, _2;
    

    /**   	fn = open(file, "a")*/
    _fn_2740 = EOpen(_file_2738, _1303, 0);

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2740 >= 0)
    goto L1; // [14] 23
    DeRefDS(_file_2738);
    DeRefDS(_lines_2739);
    return -1;
L1: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_2739)){
            _1306 = SEQ_PTR(_lines_2739)->length;
    }
    else {
        _1306 = 1;
    }
    {
        int _i_2746;
        _i_2746 = 1;
L2: 
        if (_i_2746 > _1306){
            goto L3; // [28] 56
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_2739);
        _1307 = (int)*(((s1_ptr)_2)->base + _i_2746);
        EPuts(_fn_2740, _1307); // DJP 
        _1307 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_2740, 10); // DJP 

        /** 	end for*/
        _i_2746 = _i_2746 + 1;
        goto L2; // [51] 35
L3: 
        ;
    }

    /** 	close(fn)*/
    EClose(_fn_2740);

    /** 	return 1*/
    DeRefDS(_file_2738);
    DeRefDS(_lines_2739);
    return 1;
    ;
}


int  __stdcall _18read_file(int _file_2755, int _as_text_2756)
{
    int _fn_2757 = NOVALUE;
    int _len_2758 = NOVALUE;
    int _ret_2759 = NOVALUE;
    int _seek_1__tmp_at43_2769 = NOVALUE;
    int _seek_inlined_seek_at_43_2768 = NOVALUE;
    int _where_inlined_where_at_58_2771 = NOVALUE;
    int _seek_1__tmp_at67_2774 = NOVALUE;
    int _seek_inlined_seek_at_67_2773 = NOVALUE;
    int _1331 = NOVALUE;
    int _1330 = NOVALUE;
    int _1328 = NOVALUE;
    int _1323 = NOVALUE;
    int _1316 = NOVALUE;
    int _1315 = NOVALUE;
    int _1314 = NOVALUE;
    int _1313 = NOVALUE;
    int _1308 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_as_text_2756)) {
        _1 = (long)(DBL_PTR(_as_text_2756)->dbl);
        DeRefDS(_as_text_2756);
        _as_text_2756 = _1;
    }

    /** 	if sequence(file) then*/
    _1308 = IS_SEQUENCE(_file_2755);
    if (_1308 == 0)
    {
        _1308 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _1308 = NOVALUE;
    }

    /** 		fn = open(file, "rb")*/
    _fn_2757 = EOpen(_file_2755, _1309, 0);
    goto L2; // [18] 29
L1: 

    /** 		fn = file*/
    Ref(_file_2755);
    _fn_2757 = _file_2755;
    if (!IS_ATOM_INT(_fn_2757)) {
        _1 = (long)(DBL_PTR(_fn_2757)->dbl);
        DeRefDS(_fn_2757);
        _fn_2757 = _1;
    }
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2757 >= 0)
    goto L3; // [33] 42
    DeRef(_file_2755);
    DeRef(_ret_2759);
    return -1;
L3: 

    /** 	seek(fn, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at43_2769);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2757;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at43_2769 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_43_2768 = machine(19, _seek_1__tmp_at43_2769);
    DeRefi(_seek_1__tmp_at43_2769);
    _seek_1__tmp_at43_2769 = NOVALUE;

    /** 	len = where(fn)*/

    /** 	return machine_func(M_WHERE, fn)*/
    _len_2758 = machine(20, _fn_2757);

    /** 	seek(fn, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at67_2774);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2757;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at67_2774 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_67_2773 = machine(19, _seek_1__tmp_at67_2774);
    DeRefi(_seek_1__tmp_at67_2774);
    _seek_1__tmp_at67_2774 = NOVALUE;

    /** 	ret = repeat(0, len)*/
    DeRef(_ret_2759);
    _ret_2759 = Repeat(0, _len_2758);

    /** 	for i = 1 to len do*/
    _1313 = _len_2758;
    {
        int _i_2777;
        _i_2777 = 1;
L4: 
        if (_i_2777 > _1313){
            goto L5; // [92] 115
        }

        /** 		ret[i] = getc(fn)*/
        if (_fn_2757 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_2757, EF_READ);
            last_r_file_no = _fn_2757;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _1314 = getKBchar();
            }
            else
            _1314 = getc(last_r_file_ptr);
        }
        else
        _1314 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_ret_2759);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_2759 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2777);
        _1 = *(int *)_2;
        *(int *)_2 = _1314;
        if( _1 != _1314 ){
            DeRef(_1);
        }
        _1314 = NOVALUE;

        /** 	end for*/
        _i_2777 = _i_2777 + 1;
        goto L4; // [110] 99
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _1315 = IS_SEQUENCE(_file_2755);
    if (_1315 == 0)
    {
        _1315 = NOVALUE;
        goto L6; // [120] 128
    }
    else{
        _1315 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_2757);
L6: 

    /** 	ifdef WINDOWS then*/

    /** 		for i = len to 1 by -1 do*/
    {
        int _i_2783;
        _i_2783 = _len_2758;
L7: 
        if (_i_2783 < 1){
            goto L8; // [132] 175
        }

        /** 			if ret[i] != -1 then*/
        _2 = (int)SEQ_PTR(_ret_2759);
        _1316 = (int)*(((s1_ptr)_2)->base + _i_2783);
        if (binary_op_a(EQUALS, _1316, -1)){
            _1316 = NOVALUE;
            goto L9; // [145] 168
        }
        _1316 = NOVALUE;

        /** 				if i != len then*/
        if (_i_2783 == _len_2758)
        goto L8; // [151] 175

        /** 					ret = ret[1 .. i]*/
        rhs_slice_target = (object_ptr)&_ret_2759;
        RHS_Slice(_ret_2759, 1, _i_2783);

        /** 				exit*/
        goto L8; // [165] 175
L9: 

        /** 		end for*/
        _i_2783 = _i_2783 + -1;
        goto L7; // [170] 139
L8: 
        ;
    }

    /** 	if as_text = BINARY_MODE then*/
    if (_as_text_2756 != 1)
    goto LA; // [177] 188

    /** 		return ret*/
    DeRef(_file_2755);
    return _ret_2759;
LA: 

    /** 	fn = find(26, ret) -- Any Ctrl-Z found?*/
    _fn_2757 = find_from(26, _ret_2759, 1);

    /** 	if fn then*/
    if (_fn_2757 == 0)
    {
        goto LB; // [197] 212
    }
    else{
    }

    /** 		ret = ret[1 .. fn - 1]*/
    _1323 = _fn_2757 - 1;
    rhs_slice_target = (object_ptr)&_ret_2759;
    RHS_Slice(_ret_2759, 1, _1323);
LB: 

    /** 	ret = search:match_replace({13,10}, ret, {10})*/
    RefDS(_1325);
    RefDS(_ret_2759);
    RefDS(_1326);
    _0 = _ret_2759;
    _ret_2759 = _9match_replace(_1325, _ret_2759, _1326, 0);
    DeRefDS(_0);

    /** 	if length(ret) > 0 then*/
    if (IS_SEQUENCE(_ret_2759)){
            _1328 = SEQ_PTR(_ret_2759)->length;
    }
    else {
        _1328 = 1;
    }
    if (_1328 <= 0)
    goto LC; // [228] 255

    /** 		if ret[$] != 10 then*/
    if (IS_SEQUENCE(_ret_2759)){
            _1330 = SEQ_PTR(_ret_2759)->length;
    }
    else {
        _1330 = 1;
    }
    _2 = (int)SEQ_PTR(_ret_2759);
    _1331 = (int)*(((s1_ptr)_2)->base + _1330);
    if (binary_op_a(EQUALS, _1331, 10)){
        _1331 = NOVALUE;
        goto LD; // [241] 263
    }
    _1331 = NOVALUE;

    /** 			ret &= 10*/
    Append(&_ret_2759, _ret_2759, 10);
    goto LD; // [252] 263
LC: 

    /** 		ret = {10}*/
    RefDS(_1326);
    DeRef(_ret_2759);
    _ret_2759 = _1326;
LD: 

    /** 	return ret*/
    DeRef(_file_2755);
    DeRef(_1323);
    _1323 = NOVALUE;
    return _ret_2759;
    ;
}


int  __stdcall _18write_file(int _file_2811, int _data_2812, int _as_text_2813)
{
    int _fn_2814 = NOVALUE;
    int _1357 = NOVALUE;
    int _1351 = NOVALUE;
    int _1341 = NOVALUE;
    int _1340 = NOVALUE;
    int _1338 = NOVALUE;
    int _1336 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_as_text_2813)) {
        _1 = (long)(DBL_PTR(_as_text_2813)->dbl);
        DeRefDS(_as_text_2813);
        _as_text_2813 = _1;
    }

    /** 	if as_text != BINARY_MODE then*/
    if (_as_text_2813 == 1)
    goto L1; // [7] 146

    /** 		fn = find(26, data)*/
    _fn_2814 = find_from(26, _data_2812, 1);

    /** 		if fn then*/
    if (_fn_2814 == 0)
    {
        goto L2; // [20] 35
    }
    else{
    }

    /** 			data = data[1 .. fn-1]*/
    _1336 = _fn_2814 - 1;
    rhs_slice_target = (object_ptr)&_data_2812;
    RHS_Slice(_data_2812, 1, _1336);
L2: 

    /** 		if length(data) > 0 then*/
    if (IS_SEQUENCE(_data_2812)){
            _1338 = SEQ_PTR(_data_2812)->length;
    }
    else {
        _1338 = 1;
    }
    if (_1338 <= 0)
    goto L3; // [40] 67

    /** 			if data[$] != 10 then*/
    if (IS_SEQUENCE(_data_2812)){
            _1340 = SEQ_PTR(_data_2812)->length;
    }
    else {
        _1340 = 1;
    }
    _2 = (int)SEQ_PTR(_data_2812);
    _1341 = (int)*(((s1_ptr)_2)->base + _1340);
    if (binary_op_a(EQUALS, _1341, 10)){
        _1341 = NOVALUE;
        goto L4; // [53] 75
    }
    _1341 = NOVALUE;

    /** 				data &= 10*/
    Append(&_data_2812, _data_2812, 10);
    goto L4; // [64] 75
L3: 

    /** 			data = {10}*/
    RefDS(_1326);
    DeRefDS(_data_2812);
    _data_2812 = _1326;
L4: 

    /** 		if as_text = TEXT_MODE then*/
    if (_as_text_2813 != 2)
    goto L5; // [77] 95

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1325);
    RefDS(_data_2812);
    RefDS(_1326);
    _0 = _data_2812;
    _data_2812 = _9match_replace(_1325, _data_2812, _1326, 0);
    DeRefDS(_0);
    goto L6; // [92] 145
L5: 

    /** 		elsif as_text = UNIX_TEXT then*/
    if (_as_text_2813 != 3)
    goto L7; // [97] 115

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1325);
    RefDS(_data_2812);
    RefDS(_1326);
    _0 = _data_2812;
    _data_2812 = _9match_replace(_1325, _data_2812, _1326, 0);
    DeRefDS(_0);
    goto L6; // [112] 145
L7: 

    /** 		elsif as_text = DOS_TEXT then*/
    if (_as_text_2813 != 4)
    goto L8; // [117] 144

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1325);
    RefDS(_data_2812);
    RefDS(_1326);
    _0 = _data_2812;
    _data_2812 = _9match_replace(_1325, _data_2812, _1326, 0);
    DeRefDS(_0);

    /** 			data = search:match_replace({10}, data, {13,10})*/
    RefDS(_1326);
    RefDS(_data_2812);
    RefDS(_1325);
    _0 = _data_2812;
    _data_2812 = _9match_replace(_1326, _data_2812, _1325, 0);
    DeRefDS(_0);
L8: 
L6: 
L1: 

    /** 	if sequence(file) then*/
    _1351 = IS_SEQUENCE(_file_2811);
    if (_1351 == 0)
    {
        _1351 = NOVALUE;
        goto L9; // [151] 181
    }
    else{
        _1351 = NOVALUE;
    }

    /** 		if as_text = TEXT_MODE then*/
    if (_as_text_2813 != 2)
    goto LA; // [156] 170

    /** 			fn = open(file, "w")*/
    _fn_2814 = EOpen(_file_2811, _1297, 0);
    goto LB; // [167] 189
LA: 

    /** 			fn = open(file, "wb")*/
    _fn_2814 = EOpen(_file_2811, _1354, 0);
    goto LB; // [178] 189
L9: 

    /** 		fn = file*/
    Ref(_file_2811);
    _fn_2814 = _file_2811;
    if (!IS_ATOM_INT(_fn_2814)) {
        _1 = (long)(DBL_PTR(_fn_2814)->dbl);
        DeRefDS(_fn_2814);
        _fn_2814 = _1;
    }
LB: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2814 >= 0)
    goto LC; // [193] 202
    DeRef(_file_2811);
    DeRefDS(_data_2812);
    DeRef(_1336);
    _1336 = NOVALUE;
    return -1;
LC: 

    /** 	puts(fn, data)*/
    EPuts(_fn_2814, _data_2812); // DJP 

    /** 	if sequence(file) then*/
    _1357 = IS_SEQUENCE(_file_2811);
    if (_1357 == 0)
    {
        _1357 = NOVALUE;
        goto LD; // [212] 220
    }
    else{
        _1357 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_2814);
LD: 

    /** 	return 1*/
    DeRef(_file_2811);
    DeRefDS(_data_2812);
    DeRef(_1336);
    _1336 = NOVALUE;
    return 1;
    ;
}


void  __stdcall _18writef(int _fm_2855, int _data_2856, int _fn_2857, int _data_not_string_2858)
{
    int _real_fn_2859 = NOVALUE;
    int _close_fn_2860 = NOVALUE;
    int _out_style_2861 = NOVALUE;
    int _ts_2864 = NOVALUE;
    int _msg_inlined_crash_at_163_2889 = NOVALUE;
    int _data_inlined_crash_at_160_2888 = NOVALUE;
    int _1377 = NOVALUE;
    int _1375 = NOVALUE;
    int _1374 = NOVALUE;
    int _1373 = NOVALUE;
    int _1367 = NOVALUE;
    int _1366 = NOVALUE;
    int _1365 = NOVALUE;
    int _1364 = NOVALUE;
    int _1363 = NOVALUE;
    int _1362 = NOVALUE;
    int _1360 = NOVALUE;
    int _1359 = NOVALUE;
    int _1358 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_2859 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_2860 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_1297);
    DeRefi(_out_style_2861);
    _out_style_2861 = _1297;

    /** 	if integer(fm) then*/
    if (IS_ATOM_INT(_fm_2855))
    _1358 = 1;
    else if (IS_ATOM_DBL(_fm_2855))
    _1358 = IS_ATOM_INT(DoubleToInt(_fm_2855));
    else
    _1358 = 0;
    if (_1358 == 0)
    {
        _1358 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _1358 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    Ref(_fm_2855);
    DeRef(_ts_2864);
    _ts_2864 = _fm_2855;

    /** 		fm = data*/
    Ref(_data_2856);
    DeRef(_fm_2855);
    _fm_2855 = _data_2856;

    /** 		data = fn*/
    Ref(_fn_2857);
    DeRef(_data_2856);
    _data_2856 = _fn_2857;

    /** 		fn = ts*/
    Ref(_ts_2864);
    DeRef(_fn_2857);
    _fn_2857 = _ts_2864;
L1: 
    DeRef(_ts_2864);
    _ts_2864 = NOVALUE;

    /** 	if sequence(fn) then*/
    _1359 = IS_SEQUENCE(_fn_2857);
    if (_1359 == 0)
    {
        _1359 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _1359 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_2857)){
            _1360 = SEQ_PTR(_fn_2857)->length;
    }
    else {
        _1360 = 1;
    }
    if (_1360 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_2857);
    _1362 = (int)*(((s1_ptr)_2)->base + 1);
    _1363 = IS_SEQUENCE(_1362);
    _1362 = NOVALUE;
    if (_1363 == 0)
    {
        _1363 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _1363 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_2857);
    _1364 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1364 == 97)
    _1365 = 1;
    else if (IS_ATOM_INT(_1364) && IS_ATOM_INT(97))
    _1365 = 0;
    else
    _1365 = (compare(_1364, 97) == 0);
    _1364 = NOVALUE;
    if (_1365 == 0)
    {
        _1365 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _1365 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_1303);
    DeRefi(_out_style_2861);
    _out_style_2861 = _1303;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_2857);
    _1366 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1366 == _1303)
    _1367 = 1;
    else if (IS_ATOM_INT(_1366) && IS_ATOM_INT(_1303))
    _1367 = 0;
    else
    _1367 = (compare(_1366, _1303) == 0);
    _1366 = NOVALUE;
    if (_1367 != 0)
    goto L7; // [113] 126
    _1367 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_1297);
    DeRefi(_out_style_2861);
    _out_style_2861 = _1297;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_1303);
    DeRefi(_out_style_2861);
    _out_style_2861 = _1303;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_2857;
    _2 = (int)SEQ_PTR(_fn_2857);
    _fn_2857 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_2857);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_2859 = EOpen(_fn_2857, _out_style_2861, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_2859 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_2857);
    *((int *)(_2+4)) = _fn_2857;
    _1373 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_2888);
    _data_inlined_crash_at_160_2888 = _1373;
    _1373 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_2889);
    _msg_inlined_crash_at_163_2889 = EPrintf(-9999999, _1372, _data_inlined_crash_at_160_2888);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_2889);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_2888);
    _data_inlined_crash_at_160_2888 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_2889);
    _msg_inlined_crash_at_163_2889 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_2860 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_2857);
    _real_fn_2859 = _fn_2857;
    if (!IS_ATOM_INT(_real_fn_2859)) {
        _1 = (long)(DBL_PTR(_real_fn_2859)->dbl);
        DeRefDS(_real_fn_2859);
        _real_fn_2859 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_2858 == 0)
    _1374 = 1;
    else if (IS_ATOM_INT(_data_not_string_2858) && IS_ATOM_INT(0))
    _1374 = 0;
    else
    _1374 = (compare(_data_not_string_2858, 0) == 0);
    if (_1374 == 0)
    {
        _1374 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _1374 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_2856);
    _1375 = _7t_display(_data_2856);
    if (_1375 == 0) {
        DeRef(_1375);
        _1375 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_1375) && DBL_PTR(_1375)->dbl == 0.0){
            DeRef(_1375);
            _1375 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_1375);
        _1375 = NOVALUE;
    }
    DeRef(_1375);
    _1375 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_2856;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_2856);
    *((int *)(_2+4)) = _data_2856;
    _data_2856 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_2855);
    Ref(_data_2856);
    _1377 = _6format(_fm_2855, _data_2856);
    EPuts(_real_fn_2859, _1377); // DJP 
    DeRef(_1377);
    _1377 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_2860 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_2859);
LD: 

    /** end procedure*/
    DeRef(_fm_2855);
    DeRef(_data_2856);
    DeRef(_fn_2857);
    DeRef(_data_not_string_2858);
    DeRefi(_out_style_2861);
    return;
    ;
}


void  __stdcall _18writefln(int _fm_2901, int _data_2902, int _fn_2903, int _data_not_string_2904)
{
    int _1380 = NOVALUE;
    int _1379 = NOVALUE;
    int _1378 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(fm) then*/
    if (IS_ATOM_INT(_fm_2901))
    _1378 = 1;
    else if (IS_ATOM_DBL(_fm_2901))
    _1378 = IS_ATOM_INT(DoubleToInt(_fm_2901));
    else
    _1378 = 0;
    if (_1378 == 0)
    {
        _1378 = NOVALUE;
        goto L1; // [6] 24
    }
    else{
        _1378 = NOVALUE;
    }

    /** 		writef(data & '\n', fn, fm, data_not_string)*/
    if (IS_SEQUENCE(_data_2902) && IS_ATOM(10)) {
        Append(&_1379, _data_2902, 10);
    }
    else if (IS_ATOM(_data_2902) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_1379, _data_2902, 10);
    }
    Ref(_fn_2903);
    Ref(_fm_2901);
    Ref(_data_not_string_2904);
    _18writef(_1379, _fn_2903, _fm_2901, _data_not_string_2904);
    _1379 = NOVALUE;
    goto L2; // [21] 37
L1: 

    /** 		writef(fm & '\n', data, fn, data_not_string)*/
    if (IS_SEQUENCE(_fm_2901) && IS_ATOM(10)) {
        Append(&_1380, _fm_2901, 10);
    }
    else if (IS_ATOM(_fm_2901) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_1380, _fm_2901, 10);
    }
    Ref(_data_2902);
    Ref(_fn_2903);
    Ref(_data_not_string_2904);
    _18writef(_1380, _data_2902, _fn_2903, _data_not_string_2904);
    _1380 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_fm_2901);
    DeRef(_data_2902);
    DeRef(_fn_2903);
    DeRef(_data_not_string_2904);
    return;
    ;
}



// 0x68888EC2
