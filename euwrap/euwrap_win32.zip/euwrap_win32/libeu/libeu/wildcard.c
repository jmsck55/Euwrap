// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _25qmatch(int _p_6992, int _s_6993)
{
    int _k_6994 = NOVALUE;
    int _3732 = NOVALUE;
    int _3731 = NOVALUE;
    int _3730 = NOVALUE;
    int _3729 = NOVALUE;
    int _3728 = NOVALUE;
    int _3727 = NOVALUE;
    int _3726 = NOVALUE;
    int _3725 = NOVALUE;
    int _3724 = NOVALUE;
    int _3723 = NOVALUE;
    int _3722 = NOVALUE;
    int _3721 = NOVALUE;
    int _3719 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find('?', p) then*/
    _3719 = find_from(63, _p_6992, 1);
    if (_3719 != 0)
    goto L1; // [12] 27
    _3719 = NOVALUE;

    /** 		return match(p, s) -- fast*/
    _3721 = e_match_from(_p_6992, _s_6993, 1);
    DeRefDS(_p_6992);
    DeRefDS(_s_6993);
    return _3721;
L1: 

    /** 	for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_6993)){
            _3722 = SEQ_PTR(_s_6993)->length;
    }
    else {
        _3722 = 1;
    }
    if (IS_SEQUENCE(_p_6992)){
            _3723 = SEQ_PTR(_p_6992)->length;
    }
    else {
        _3723 = 1;
    }
    _3724 = _3722 - _3723;
    _3722 = NOVALUE;
    _3723 = NOVALUE;
    _3725 = _3724 + 1;
    _3724 = NOVALUE;
    {
        int _i_7000;
        _i_7000 = 1;
L2: 
        if (_i_7000 > _3725){
            goto L3; // [43] 142
        }

        /** 		k = i*/
        _k_6994 = _i_7000;

        /** 		for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_6992)){
                _3726 = SEQ_PTR(_p_6992)->length;
        }
        else {
            _3726 = 1;
        }
        {
            int _j_7006;
            _j_7006 = 1;
L4: 
            if (_j_7006 > _3726){
                goto L5; // [62] 122
            }

            /** 			if p[j] != s[k] and p[j] != '?' then*/
            _2 = (int)SEQ_PTR(_p_6992);
            _3727 = (int)*(((s1_ptr)_2)->base + _j_7006);
            _2 = (int)SEQ_PTR(_s_6993);
            _3728 = (int)*(((s1_ptr)_2)->base + _k_6994);
            if (IS_ATOM_INT(_3727) && IS_ATOM_INT(_3728)) {
                _3729 = (_3727 != _3728);
            }
            else {
                _3729 = binary_op(NOTEQ, _3727, _3728);
            }
            _3727 = NOVALUE;
            _3728 = NOVALUE;
            if (IS_ATOM_INT(_3729)) {
                if (_3729 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_3729)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (int)SEQ_PTR(_p_6992);
            _3731 = (int)*(((s1_ptr)_2)->base + _j_7006);
            if (IS_ATOM_INT(_3731)) {
                _3732 = (_3731 != 63);
            }
            else {
                _3732 = binary_op(NOTEQ, _3731, 63);
            }
            _3731 = NOVALUE;
            if (_3732 == 0) {
                DeRef(_3732);
                _3732 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_3732) && DBL_PTR(_3732)->dbl == 0.0){
                    DeRef(_3732);
                    _3732 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_3732);
                _3732 = NOVALUE;
            }
            DeRef(_3732);
            _3732 = NOVALUE;

            /** 				k = 0*/
            _k_6994 = 0;

            /** 				exit*/
            goto L5; // [106] 122
L6: 

            /** 			k += 1*/
            _k_6994 = _k_6994 + 1;

            /** 		end for*/
            _j_7006 = _j_7006 + 1;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** 		if k != 0 then*/
        if (_k_6994 == 0)
        goto L7; // [124] 135

        /** 			return i*/
        DeRefDS(_p_6992);
        DeRefDS(_s_6993);
        DeRef(_3725);
        _3725 = NOVALUE;
        DeRef(_3729);
        _3729 = NOVALUE;
        return _i_7000;
L7: 

        /** 	end for*/
        _i_7000 = _i_7000 + 1;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_p_6992);
    DeRefDS(_s_6993);
    DeRef(_3725);
    _3725 = NOVALUE;
    DeRef(_3729);
    _3729 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _25is_match(int _pattern_7021, int _string_7022)
{
    int _p_7023 = NOVALUE;
    int _f_7024 = NOVALUE;
    int _t_7025 = NOVALUE;
    int _match_string_7026 = NOVALUE;
    int _3774 = NOVALUE;
    int _3773 = NOVALUE;
    int _3771 = NOVALUE;
    int _3767 = NOVALUE;
    int _3766 = NOVALUE;
    int _3765 = NOVALUE;
    int _3762 = NOVALUE;
    int _3761 = NOVALUE;
    int _3758 = NOVALUE;
    int _3755 = NOVALUE;
    int _3753 = NOVALUE;
    int _3751 = NOVALUE;
    int _3749 = NOVALUE;
    int _3746 = NOVALUE;
    int _3744 = NOVALUE;
    int _3742 = NOVALUE;
    int _3741 = NOVALUE;
    int _3740 = NOVALUE;
    int _3739 = NOVALUE;
    int _3737 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pattern = pattern & END_MARKER*/
    Append(&_pattern_7021, _pattern_7021, -1);

    /** 	string = string & END_MARKER*/
    Append(&_string_7022, _string_7022, -1);

    /** 	p = 1*/
    _p_7023 = 1;

    /** 	f = 1*/
    _f_7024 = 1;

    /** 	while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_7022)){
            _3737 = SEQ_PTR(_string_7022)->length;
    }
    else {
        _3737 = 1;
    }
    if (_f_7024 > _3737)
    goto L2; // [35] 288

    /** 		if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3739 = (int)*(((s1_ptr)_2)->base + _p_7023);
    _2 = (int)SEQ_PTR(_string_7022);
    _3740 = (int)*(((s1_ptr)_2)->base + _f_7024);
    Ref(_3740);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3740;
    ((int *)_2)[2] = 63;
    _3741 = MAKE_SEQ(_1);
    _3740 = NOVALUE;
    _3742 = find_from(_3739, _3741, 1);
    _3739 = NOVALUE;
    DeRefDS(_3741);
    _3741 = NOVALUE;
    if (_3742 != 0)
    goto L3; // [58] 248
    _3742 = NOVALUE;

    /** 			if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3744 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(NOTEQ, _3744, 42)){
        _3744 = NOVALUE;
        goto L4; // [67] 240
    }
    _3744 = NOVALUE;

    /** 				while pattern[p] = '*' do*/
L5: 
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3746 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(NOTEQ, _3746, 42)){
        _3746 = NOVALUE;
        goto L6; // [80] 95
    }
    _3746 = NOVALUE;

    /** 					p += 1*/
    _p_7023 = _p_7023 + 1;

    /** 				end while*/
    goto L5; // [92] 76
L6: 

    /** 				if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3749 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(NOTEQ, _3749, -1)){
        _3749 = NOVALUE;
        goto L7; // [101] 112
    }
    _3749 = NOVALUE;

    /** 					return 1*/
    DeRefDS(_pattern_7021);
    DeRefDS(_string_7022);
    DeRef(_match_string_7026);
    return 1;
L7: 

    /** 				match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_7026);
    _match_string_7026 = _5;

    /** 				while pattern[p] != '*' do*/
L8: 
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3751 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(EQUALS, _3751, 42)){
        _3751 = NOVALUE;
        goto L9; // [128] 168
    }
    _3751 = NOVALUE;

    /** 					match_string = match_string & pattern[p]*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3753 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (IS_SEQUENCE(_match_string_7026) && IS_ATOM(_3753)) {
        Ref(_3753);
        Append(&_match_string_7026, _match_string_7026, _3753);
    }
    else if (IS_ATOM(_match_string_7026) && IS_SEQUENCE(_3753)) {
    }
    else {
        Concat((object_ptr)&_match_string_7026, _match_string_7026, _3753);
    }
    _3753 = NOVALUE;

    /** 					if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3755 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(NOTEQ, _3755, -1)){
        _3755 = NOVALUE;
        goto LA; // [148] 157
    }
    _3755 = NOVALUE;

    /** 						exit*/
    goto L9; // [154] 168
LA: 

    /** 					p += 1*/
    _p_7023 = _p_7023 + 1;

    /** 				end while*/
    goto L8; // [165] 124
L9: 

    /** 				if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_7021);
    _3758 = (int)*(((s1_ptr)_2)->base + _p_7023);
    if (binary_op_a(NOTEQ, _3758, 42)){
        _3758 = NOVALUE;
        goto LB; // [174] 185
    }
    _3758 = NOVALUE;

    /** 					p -= 1*/
    _p_7023 = _p_7023 - 1;
LB: 

    /** 				t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_7022)){
            _3761 = SEQ_PTR(_string_7022)->length;
    }
    else {
        _3761 = 1;
    }
    rhs_slice_target = (object_ptr)&_3762;
    RHS_Slice(_string_7022, _f_7024, _3761);
    RefDS(_match_string_7026);
    _t_7025 = _25qmatch(_match_string_7026, _3762);
    _3762 = NOVALUE;
    if (!IS_ATOM_INT(_t_7025)) {
        _1 = (long)(DBL_PTR(_t_7025)->dbl);
        DeRefDS(_t_7025);
        _t_7025 = _1;
    }

    /** 				if t = 0 then*/
    if (_t_7025 != 0)
    goto LC; // [204] 217

    /** 					return 0*/
    DeRefDS(_pattern_7021);
    DeRefDS(_string_7022);
    DeRefDS(_match_string_7026);
    return 0;
    goto LD; // [214] 247
LC: 

    /** 					f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_7026)){
            _3765 = SEQ_PTR(_match_string_7026)->length;
    }
    else {
        _3765 = 1;
    }
    _3766 = _t_7025 + _3765;
    if ((long)((unsigned long)_3766 + (unsigned long)HIGH_BITS) >= 0) 
    _3766 = NewDouble((double)_3766);
    _3765 = NOVALUE;
    if (IS_ATOM_INT(_3766)) {
        _3767 = _3766 - 2;
        if ((long)((unsigned long)_3767 +(unsigned long) HIGH_BITS) >= 0){
            _3767 = NewDouble((double)_3767);
        }
    }
    else {
        _3767 = NewDouble(DBL_PTR(_3766)->dbl - (double)2);
    }
    DeRef(_3766);
    _3766 = NOVALUE;
    if (IS_ATOM_INT(_3767)) {
        _f_7024 = _f_7024 + _3767;
    }
    else {
        _f_7024 = NewDouble((double)_f_7024 + DBL_PTR(_3767)->dbl);
    }
    DeRef(_3767);
    _3767 = NOVALUE;
    if (!IS_ATOM_INT(_f_7024)) {
        _1 = (long)(DBL_PTR(_f_7024)->dbl);
        DeRefDS(_f_7024);
        _f_7024 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** 				return 0*/
    DeRefDS(_pattern_7021);
    DeRefDS(_string_7022);
    DeRef(_match_string_7026);
    return 0;
LD: 
L3: 

    /** 		p += 1*/
    _p_7023 = _p_7023 + 1;

    /** 		f += 1*/
    _f_7024 = _f_7024 + 1;

    /** 		if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_7021)){
            _3771 = SEQ_PTR(_pattern_7021)->length;
    }
    else {
        _3771 = 1;
    }
    if (_p_7023 <= _3771)
    goto L1; // [265] 32

    /** 			return f > length(string) */
    if (IS_SEQUENCE(_string_7022)){
            _3773 = SEQ_PTR(_string_7022)->length;
    }
    else {
        _3773 = 1;
    }
    _3774 = (_f_7024 > _3773);
    _3773 = NOVALUE;
    DeRefDS(_pattern_7021);
    DeRefDS(_string_7022);
    DeRef(_match_string_7026);
    return _3774;

    /** 	end while*/
    goto L1; // [285] 32
L2: 

    /** 	return 0*/
    DeRefDS(_pattern_7021);
    DeRefDS(_string_7022);
    DeRef(_match_string_7026);
    DeRef(_3774);
    _3774 = NOVALUE;
    return 0;
    ;
}



// 0x3F08347B
