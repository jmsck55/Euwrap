// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _1set_return_linked_list(int _i_24304)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_24304)) {
        _1 = (long)(DBL_PTR(_i_24304)->dbl);
        DeRefDS(_i_24304);
        _i_24304 = _1;
    }

    /** 	always_linked_list = i*/
    _58always_linked_list_23970 = _i_24304;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _58always_linked_list_23970;
    ;
}


int  __stdcall _1get_version()
{
    int _0, _1, _2;
    

    /** 	return VERSION*/
    return 3;
    ;
}


void  __stdcall _1init()
{
    int _0, _1, _2;
    

    /** 	high_address = 0*/
    _1high_address_24312 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef(_1data_24313);
    _1data_24313 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef(_1free_list_24314);
    _1free_list_24314 = _5;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1get_high_address()
{
    int _0, _1, _2;
    

    /** 	return high_address*/
    return _1high_address_24312;
    ;
}


int _1set_high_address(int _ma_24322)
{
    int _13437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_24322)) {
        if (65536 > 0 && _ma_24322 >= 0) {
            _1high_address_24312 = _ma_24322 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_24322 / (double)65536);
            _1high_address_24312 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_24322, 65536);
        _1high_address_24312 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_24312)) {
        _1 = (long)(DBL_PTR(_1high_address_24312)->dbl);
        DeRefDS(_1high_address_24312);
        _1high_address_24312 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    if (IS_ATOM_INT(_ma_24322)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_24322 & (unsigned long)65535;
             _13437 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _13437 = Dand_bits(DBL_PTR(_ma_24322), &temp_d);
    }
    DeRef(_ma_24322);
    return _13437;
    ;
}


int _1get_address(int _low_24327, int _high_24328)
{
    int _13439 = NOVALUE;
    int _13438 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24327)) {
        _1 = (long)(DBL_PTR(_low_24327)->dbl);
        DeRefDS(_low_24327);
        _low_24327 = _1;
    }
    if (!IS_ATOM_INT(_high_24328)) {
        _1 = (long)(DBL_PTR(_high_24328)->dbl);
        DeRefDS(_high_24328);
        _high_24328 = _1;
    }

    /** 	return high * #00010000 + low*/
    _13438 = NewDouble(_high_24328 * (double)65536);
    if (IS_ATOM_INT(_13438)) {
        _13439 = _13438 + _low_24327;
        if ((long)((unsigned long)_13439 + (unsigned long)HIGH_BITS) >= 0) 
        _13439 = NewDouble((double)_13439);
    }
    else {
        _13439 = NewDouble(DBL_PTR(_13438)->dbl + (double)_low_24327);
    }
    DeRef(_13438);
    _13438 = NOVALUE;
    return _13439;
    ;
}


int _1register_data(int _ob_24333)
{
    int _i_24334 = NOVALUE;
    int _ret_24335 = NOVALUE;
    int _a_24336 = NOVALUE;
    int _s_24337 = NOVALUE;
    int _13451 = NOVALUE;
    int _13448 = NOVALUE;
    int _13446 = NOVALUE;
    int _13445 = NOVALUE;
    int _13444 = NOVALUE;
    int _13442 = NOVALUE;
    int _13440 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_24314)){
            _13440 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13440 = 1;
    }
    if (_13440 == 0)
    {
        _13440 = NOVALUE;
        goto L1; // [8] 106
    }
    else{
        _13440 = NOVALUE;
    }

    /** 		ret = free_list[1]*/
    _2 = (int)SEQ_PTR(_1free_list_24314);
    _ret_24335 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_ret_24335))
    _ret_24335 = (long)DBL_PTR(_ret_24335)->dbl;

    /** 		free_list = free_list[2..length(free_list)]*/
    if (IS_SEQUENCE(_1free_list_24314)){
            _13442 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13442 = 1;
    }
    rhs_slice_target = (object_ptr)&_1free_list_24314;
    RHS_Slice(_1free_list_24314, 2, _13442);

    /** 		if integer(ob) then*/
    if (IS_ATOM_INT(_ob_24333))
    _13444 = 1;
    else if (IS_ATOM_DBL(_ob_24333))
    _13444 = IS_ATOM_INT(DoubleToInt(_ob_24333));
    else
    _13444 = 0;
    if (_13444 == 0)
    {
        _13444 = NOVALUE;
        goto L2; // [38] 59
    }
    else{
        _13444 = NOVALUE;
    }

    /** 			i = ob*/
    Ref(_ob_24333);
    _i_24334 = _ob_24333;
    if (!IS_ATOM_INT(_i_24334)) {
        _1 = (long)(DBL_PTR(_i_24334)->dbl);
        DeRefDS(_i_24334);
        _i_24334 = _1;
    }

    /** 			data[ret] = i*/
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_24335);
    _1 = *(int *)_2;
    *(int *)_2 = _i_24334;
    DeRef(_1);
    goto L3; // [56] 99
L2: 

    /** 		elsif atom(ob) then*/
    _13445 = IS_ATOM(_ob_24333);
    if (_13445 == 0)
    {
        _13445 = NOVALUE;
        goto L4; // [64] 83
    }
    else{
        _13445 = NOVALUE;
    }

    /** 			a = ob*/
    Ref(_ob_24333);
    DeRef(_a_24336);
    _a_24336 = _ob_24333;

    /** 			data[ret] = a*/
    Ref(_a_24336);
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_24335);
    _1 = *(int *)_2;
    *(int *)_2 = _a_24336;
    DeRef(_1);
    goto L3; // [80] 99
L4: 

    /** 			s = ob*/
    Ref(_ob_24333);
    DeRef(_s_24337);
    _s_24337 = _ob_24333;

    /** 			data[ret] = s*/
    RefDS(_s_24337);
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_24335);
    _1 = *(int *)_2;
    *(int *)_2 = _s_24337;
    DeRef(_1);
L3: 

    /** 		return ret*/
    DeRef(_ob_24333);
    DeRef(_a_24336);
    DeRef(_s_24337);
    return _ret_24335;
L1: 

    /** 	if integer(ob) then*/
    if (IS_ATOM_INT(_ob_24333))
    _13446 = 1;
    else if (IS_ATOM_DBL(_ob_24333))
    _13446 = IS_ATOM_INT(DoubleToInt(_ob_24333));
    else
    _13446 = 0;
    if (_13446 == 0)
    {
        _13446 = NOVALUE;
        goto L5; // [111] 132
    }
    else{
        _13446 = NOVALUE;
    }

    /** 		i = ob*/
    Ref(_ob_24333);
    _i_24334 = _ob_24333;
    if (!IS_ATOM_INT(_i_24334)) {
        _1 = (long)(DBL_PTR(_i_24334)->dbl);
        DeRefDS(_i_24334);
        _i_24334 = _1;
    }

    /** 		data = append(data, i)*/
    Append(&_1data_24313, _1data_24313, _i_24334);
    goto L6; // [129] 172
L5: 

    /** 	elsif atom(ob) then*/
    _13448 = IS_ATOM(_ob_24333);
    if (_13448 == 0)
    {
        _13448 = NOVALUE;
        goto L7; // [137] 156
    }
    else{
        _13448 = NOVALUE;
    }

    /** 		a = ob*/
    Ref(_ob_24333);
    DeRef(_a_24336);
    _a_24336 = _ob_24333;

    /** 		data = append(data, a)*/
    Ref(_a_24336);
    Append(&_1data_24313, _1data_24313, _a_24336);
    goto L6; // [153] 172
L7: 

    /** 		s = ob*/
    Ref(_ob_24333);
    DeRef(_s_24337);
    _s_24337 = _ob_24333;

    /** 		data = append(data, s)*/
    RefDS(_s_24337);
    Append(&_1data_24313, _1data_24313, _s_24337);
L6: 

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_24313)){
            _13451 = SEQ_PTR(_1data_24313)->length;
    }
    else {
        _13451 = 1;
    }
    DeRef(_ob_24333);
    DeRef(_a_24336);
    DeRef(_s_24337);
    return _13451;
    ;
}


int _1retval(int _ob_24359)
{
    int _13452 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return register_data(ob)*/
    Ref(_ob_24359);
    _13452 = _1register_data(_ob_24359);
    DeRef(_ob_24359);
    return _13452;
    ;
}


int  __stdcall _1length_of_data()
{
    int _13453 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_24313)){
            _13453 = SEQ_PTR(_1data_24313)->length;
    }
    else {
        _13453 = 1;
    }
    return _13453;
    ;
}


int  __stdcall _1is_free(int _id_24366)
{
    int _13455 = NOVALUE;
    int _13454 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24366)) {
        _1 = (long)(DBL_PTR(_id_24366)->dbl);
        DeRefDS(_id_24366);
        _id_24366 = _1;
    }

    /** 	return find(id, free_list) and 1 -- boolean*/
    _13454 = find_from(_id_24366, _1free_list_24314, 1);
    _13455 = (_13454 != 0 && 1 != 0);
    _13454 = NOVALUE;
    return _13455;
    ;
}


int  __stdcall _1access_free_list()
{
    int _set_high_address_inlined_set_high_address_at_41_24379 = NOVALUE;
    int _ma_24371 = NOVALUE;
    int _13458 = NOVALUE;
    int _13457 = NOVALUE;
    int _13456 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = 0*/
    DeRef(_ma_24371);
    _ma_24371 = 0;

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_24314)){
            _13456 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13456 = 1;
    }
    if (_13456 == 0)
    {
        _13456 = NOVALUE;
        goto L1; // [13] 40
    }
    else{
        _13456 = NOVALUE;
    }

    /** 		ma = allocate(length(free_list) * 4)*/
    if (IS_SEQUENCE(_1free_list_24314)){
            _13457 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13457 = 1;
    }
    if (_13457 == (short)_13457)
    _13458 = _13457 * 4;
    else
    _13458 = NewDouble(_13457 * (double)4);
    _13457 = NOVALUE;
    _ma_24371 = _14allocate(_13458, 0);
    _13458 = NOVALUE;

    /** 		poke4(ma, free_list)*/
    if (IS_ATOM_INT(_ma_24371)){
        poke4_addr = (unsigned long *)_ma_24371;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24371)->dbl);
    }
    _1 = (int)SEQ_PTR(_1free_list_24314);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
L1: 

    /** 	return set_high_address(ma)*/

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_24371)) {
        if (65536 > 0 && _ma_24371 >= 0) {
            _1high_address_24312 = _ma_24371 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_24371 / (double)65536);
            _1high_address_24312 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_24371, 65536);
        _1high_address_24312 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_24312)) {
        _1 = (long)(DBL_PTR(_1high_address_24312)->dbl);
        DeRefDS(_1high_address_24312);
        _1high_address_24312 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_41_24379);
    if (IS_ATOM_INT(_ma_24371)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_24371 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_41_24379 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _set_high_address_inlined_set_high_address_at_41_24379 = Dand_bits(DBL_PTR(_ma_24371), &temp_d);
    }
    DeRef(_ma_24371);
    return _set_high_address_inlined_set_high_address_at_41_24379;
    ;
}


void  __stdcall _1generic_free(int _low_24382, int _high_24383)
{
    int _ma_24384 = NOVALUE;
    int _get_address_1__tmp_at6_24387 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24386 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24382)) {
        _1 = (long)(DBL_PTR(_low_24382)->dbl);
        DeRefDS(_low_24382);
        _low_24382 = _1;
    }
    if (!IS_ATOM_INT(_high_24383)) {
        _1 = (long)(DBL_PTR(_high_24383)->dbl);
        DeRefDS(_high_24383);
        _high_24383 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24387);
    _get_address_1__tmp_at6_24387 = NewDouble(_high_24383 * (double)65536);
    DeRef(_ma_24384);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24387)) {
        _ma_24384 = _get_address_1__tmp_at6_24387 + _low_24382;
        if ((long)((unsigned long)_ma_24384 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_24384 = NewDouble((double)_ma_24384);
    }
    else {
        _ma_24384 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24387)->dbl + (double)_low_24382);
    }
    DeRef(_get_address_1__tmp_at6_24387);
    _get_address_1__tmp_at6_24387 = NOVALUE;

    /** 	if ma then*/
    if (_ma_24384 == 0) {
        goto L1; // [22] 31
    }
    else {
        if (!IS_ATOM_INT(_ma_24384) && DBL_PTR(_ma_24384)->dbl == 0.0){
            goto L1; // [22] 31
        }
    }

    /** 		free(ma)*/
    Ref(_ma_24384);
    _14free(_ma_24384);
L1: 

    /** end procedure*/
    DeRef(_ma_24384);
    return;
    ;
}


void  __stdcall _1delete_linked_list(int _id_24392)
{
    int _pos_24393 = NOVALUE;
    int _13478 = NOVALUE;
    int _13477 = NOVALUE;
    int _13475 = NOVALUE;
    int _13474 = NOVALUE;
    int _13472 = NOVALUE;
    int _13471 = NOVALUE;
    int _13470 = NOVALUE;
    int _13469 = NOVALUE;
    int _13467 = NOVALUE;
    int _13466 = NOVALUE;
    int _13465 = NOVALUE;
    int _13464 = NOVALUE;
    int _13463 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24392)) {
        _1 = (long)(DBL_PTR(_id_24392)->dbl);
        DeRefDS(_id_24392);
        _id_24392 = _1;
    }

    /** 	pos = binary_search(id, free_list)*/
    RefDS(_1free_list_24314);
    _pos_24393 = _9binary_search(_id_24392, _1free_list_24314, 1, 0);
    if (!IS_ATOM_INT(_pos_24393)) {
        _1 = (long)(DBL_PTR(_pos_24393)->dbl);
        DeRefDS(_pos_24393);
        _pos_24393 = _1;
    }

    /** 	if pos < 0 then -- if not in free_list, insert*/
    if (_pos_24393 >= 0)
    goto L1; // [18] 152

    /** 		data[id] = {}*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_24392);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 		pos = -pos*/
    _pos_24393 = - _pos_24393;

    /** 		free_list = free_list[1..pos-1] & {id} & free_list[pos..$]*/
    _13463 = _pos_24393 - 1;
    rhs_slice_target = (object_ptr)&_13464;
    RHS_Slice(_1free_list_24314, 1, _13463);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _id_24392;
    _13465 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_1free_list_24314)){
            _13466 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13466 = 1;
    }
    rhs_slice_target = (object_ptr)&_13467;
    RHS_Slice(_1free_list_24314, _pos_24393, _13466);
    {
        int concat_list[3];

        concat_list[0] = _13467;
        concat_list[1] = _13465;
        concat_list[2] = _13464;
        Concat_N((object_ptr)&_1free_list_24314, concat_list, 3);
    }
    DeRefDS(_13467);
    _13467 = NOVALUE;
    DeRefDS(_13465);
    _13465 = NOVALUE;
    DeRefDS(_13464);
    _13464 = NOVALUE;

    /** 		for i = length(free_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_1free_list_24314)){
            _13469 = SEQ_PTR(_1free_list_24314)->length;
    }
    else {
        _13469 = 1;
    }
    {
        int _i_24406;
        _i_24406 = _13469;
L2: 
        if (_i_24406 < 1){
            goto L3; // [77] 151
        }

        /** 			if free_list[$] = length(data) then*/
        if (IS_SEQUENCE(_1free_list_24314)){
                _13470 = SEQ_PTR(_1free_list_24314)->length;
        }
        else {
            _13470 = 1;
        }
        _2 = (int)SEQ_PTR(_1free_list_24314);
        _13471 = (int)*(((s1_ptr)_2)->base + _13470);
        if (IS_SEQUENCE(_1data_24313)){
                _13472 = SEQ_PTR(_1data_24313)->length;
        }
        else {
            _13472 = 1;
        }
        if (binary_op_a(NOTEQ, _13471, _13472)){
            _13471 = NOVALUE;
            _13472 = NOVALUE;
            goto L3; // [100] 151
        }
        _13471 = NOVALUE;
        _13472 = NOVALUE;

        /** 				data = data[1..$-1]*/
        if (IS_SEQUENCE(_1data_24313)){
                _13474 = SEQ_PTR(_1data_24313)->length;
        }
        else {
            _13474 = 1;
        }
        _13475 = _13474 - 1;
        _13474 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1data_24313;
        RHS_Slice(_1data_24313, 1, _13475);

        /** 				free_list = free_list[1..$-1]*/
        if (IS_SEQUENCE(_1free_list_24314)){
                _13477 = SEQ_PTR(_1free_list_24314)->length;
        }
        else {
            _13477 = 1;
        }
        _13478 = _13477 - 1;
        _13477 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1free_list_24314;
        RHS_Slice(_1free_list_24314, 1, _13478);
        goto L4; // [136] 144

        /** 				exit*/
        goto L3; // [141] 151
L4: 

        /** 		end for*/
        _i_24406 = _i_24406 + -1;
        goto L2; // [146] 84
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_13463);
    _13463 = NOVALUE;
    DeRef(_13475);
    _13475 = NOVALUE;
    DeRef(_13478);
    _13478 = NOVALUE;
    return;
    ;
}


void  __stdcall _1free_linked_lists(int _low_24422, int _high_24423, int _len_24424)
{
    int _array_24425 = NOVALUE;
    int _ma_24426 = NOVALUE;
    int _get_address_1__tmp_at8_24429 = NOVALUE;
    int _get_address_inlined_get_address_at_8_24428 = NOVALUE;
    int _13483 = NOVALUE;
    int _13482 = NOVALUE;
    int _13480 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24422)) {
        _1 = (long)(DBL_PTR(_low_24422)->dbl);
        DeRefDS(_low_24422);
        _low_24422 = _1;
    }
    if (!IS_ATOM_INT(_high_24423)) {
        _1 = (long)(DBL_PTR(_high_24423)->dbl);
        DeRefDS(_high_24423);
        _high_24423 = _1;
    }
    if (!IS_ATOM_INT(_len_24424)) {
        _1 = (long)(DBL_PTR(_len_24424)->dbl);
        DeRefDS(_len_24424);
        _len_24424 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_24429);
    _get_address_1__tmp_at8_24429 = NewDouble(_high_24423 * (double)65536);
    DeRef(_ma_24426);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_24429)) {
        _ma_24426 = _get_address_1__tmp_at8_24429 + _low_24422;
        if ((long)((unsigned long)_ma_24426 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_24426 = NewDouble((double)_ma_24426);
    }
    else {
        _ma_24426 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_24429)->dbl + (double)_low_24422);
    }
    DeRef(_get_address_1__tmp_at8_24429);
    _get_address_1__tmp_at8_24429 = NOVALUE;

    /** 	array = peek4u({ma, len})*/
    Ref(_ma_24426);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ma_24426;
    ((int *)_2)[2] = _len_24424;
    _13480 = MAKE_SEQ(_1);
    DeRef(_array_24425);
    _1 = (int)SEQ_PTR(_13480);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _array_24425 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13480);
    _13480 = NOVALUE;

    /** 	for i = 1 to length(array) do*/
    if (IS_SEQUENCE(_array_24425)){
            _13482 = SEQ_PTR(_array_24425)->length;
    }
    else {
        _13482 = 1;
    }
    {
        int _i_24433;
        _i_24433 = 1;
L1: 
        if (_i_24433 > _13482){
            goto L2; // [38] 61
        }

        /** 		delete_linked_list(array[i])*/
        _2 = (int)SEQ_PTR(_array_24425);
        _13483 = (int)*(((s1_ptr)_2)->base + _i_24433);
        Ref(_13483);
        _1delete_linked_list(_13483);
        _13483 = NOVALUE;

        /** 	end for*/
        _i_24433 = _i_24433 + 1;
        goto L1; // [56] 45
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_array_24425);
    DeRef(_ma_24426);
    return;
    ;
}


int  __stdcall _1register_linked_list(int _low_24438, int _high_24439)
{
    int _get_address_1__tmp_at6_24443 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24442 = NOVALUE;
    int _13485 = NOVALUE;
    int _13484 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24438)) {
        _1 = (long)(DBL_PTR(_low_24438)->dbl);
        DeRefDS(_low_24438);
        _low_24438 = _1;
    }
    if (!IS_ATOM_INT(_high_24439)) {
        _1 = (long)(DBL_PTR(_high_24439)->dbl);
        DeRefDS(_high_24439);
        _high_24439 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24443);
    _get_address_1__tmp_at6_24443 = NewDouble(_high_24439 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24442);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24443)) {
        _get_address_inlined_get_address_at_6_24442 = _get_address_1__tmp_at6_24443 + _low_24438;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24442 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24442 = NewDouble((double)_get_address_inlined_get_address_at_6_24442);
    }
    else {
        _get_address_inlined_get_address_at_6_24442 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24443)->dbl + (double)_low_24438);
    }
    DeRef(_get_address_1__tmp_at6_24443);
    _get_address_1__tmp_at6_24443 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24442);
    _13484 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_6_24442);
    _13485 = _1register_data(_13484);
    _13484 = NOVALUE;
    return _13485;
    ;
}


int  __stdcall _1new_linked_list(int _low_24448, int _high_24449)
{
    int _get_address_1__tmp_at6_24453 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24452 = NOVALUE;
    int _13487 = NOVALUE;
    int _13486 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24448)) {
        _1 = (long)(DBL_PTR(_low_24448)->dbl);
        DeRefDS(_low_24448);
        _low_24448 = _1;
    }
    if (!IS_ATOM_INT(_high_24449)) {
        _1 = (long)(DBL_PTR(_high_24449)->dbl);
        DeRefDS(_high_24449);
        _high_24449 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24453);
    _get_address_1__tmp_at6_24453 = NewDouble(_high_24449 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24452);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24453)) {
        _get_address_inlined_get_address_at_6_24452 = _get_address_1__tmp_at6_24453 + _low_24448;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24452 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24452 = NewDouble((double)_get_address_inlined_get_address_at_6_24452);
    }
    else {
        _get_address_inlined_get_address_at_6_24452 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24453)->dbl + (double)_low_24448);
    }
    DeRef(_get_address_1__tmp_at6_24453);
    _get_address_1__tmp_at6_24453 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24452);
    _13486 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_6_24452);
    _13487 = _1register_data(_13486);
    _13486 = NOVALUE;
    return _13487;
    ;
}


void  __stdcall _1store_linked_list(int _id_24458, int _low_24459, int _high_24460)
{
    int _get_address_1__tmp_at10_24464 = NOVALUE;
    int _get_address_inlined_get_address_at_10_24463 = NOVALUE;
    int _13488 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24458)) {
        _1 = (long)(DBL_PTR(_id_24458)->dbl);
        DeRefDS(_id_24458);
        _id_24458 = _1;
    }
    if (!IS_ATOM_INT(_low_24459)) {
        _1 = (long)(DBL_PTR(_low_24459)->dbl);
        DeRefDS(_low_24459);
        _low_24459 = _1;
    }
    if (!IS_ATOM_INT(_high_24460)) {
        _1 = (long)(DBL_PTR(_high_24460)->dbl);
        DeRefDS(_high_24460);
        _high_24460 = _1;
    }

    /** 	data[id] = linked_list_to_sequence(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_24464);
    _get_address_1__tmp_at10_24464 = NewDouble(_high_24460 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_24463);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_24464)) {
        _get_address_inlined_get_address_at_10_24463 = _get_address_1__tmp_at10_24464 + _low_24459;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_24463 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_24463 = NewDouble((double)_get_address_inlined_get_address_at_10_24463);
    }
    else {
        _get_address_inlined_get_address_at_10_24463 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_24464)->dbl + (double)_low_24459);
    }
    DeRef(_get_address_1__tmp_at10_24464);
    _get_address_1__tmp_at10_24464 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_10_24463);
    _13488 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_10_24463);
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_24458);
    _1 = *(int *)_2;
    *(int *)_2 = _13488;
    if( _1 != _13488 ){
        DeRef(_1);
    }
    _13488 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1access_linked_list(int _id_24468)
{
    int _set_high_address_inlined_set_high_address_at_18_24474 = NOVALUE;
    int _ma_inlined_set_high_address_at_15_24473 = NOVALUE;
    int _13490 = NOVALUE;
    int _13489 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24468)) {
        _1 = (long)(DBL_PTR(_id_24468)->dbl);
        DeRefDS(_id_24468);
        _id_24468 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13489 = (int)*(((s1_ptr)_2)->base + _id_24468);
    Ref(_13489);
    _13490 = _58sequence_to_linked_list(_13489);
    _13489 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_15_24473);
    _ma_inlined_set_high_address_at_15_24473 = _13490;
    _13490 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_24473)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_15_24473 >= 0) {
            _1high_address_24312 = _ma_inlined_set_high_address_at_15_24473 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_15_24473 / (double)65536);
            _1high_address_24312 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_15_24473, 65536);
        _1high_address_24312 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_24312)) {
        _1 = (long)(DBL_PTR(_1high_address_24312)->dbl);
        DeRefDS(_1high_address_24312);
        _1high_address_24312 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_18_24474);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_24473)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_15_24473 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_18_24474 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_18_24474 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_15_24473, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_15_24473);
    _ma_inlined_set_high_address_at_15_24473 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_18_24474;
    ;
}


int  __stdcall _1at_linked_list(int _id_24477, int _index_24478)
{
    int _set_high_address_inlined_set_high_address_at_24_24485 = NOVALUE;
    int _ma_inlined_set_high_address_at_21_24484 = NOVALUE;
    int _13493 = NOVALUE;
    int _13492 = NOVALUE;
    int _13491 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24477)) {
        _1 = (long)(DBL_PTR(_id_24477)->dbl);
        DeRefDS(_id_24477);
        _id_24477 = _1;
    }
    if (!IS_ATOM_INT(_index_24478)) {
        _1 = (long)(DBL_PTR(_index_24478)->dbl);
        DeRefDS(_index_24478);
        _index_24478 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id][index]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13491 = (int)*(((s1_ptr)_2)->base + _id_24477);
    _2 = (int)SEQ_PTR(_13491);
    _13492 = (int)*(((s1_ptr)_2)->base + _index_24478);
    _13491 = NOVALUE;
    Ref(_13492);
    _13493 = _58sequence_to_linked_list(_13492);
    _13492 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_21_24484);
    _ma_inlined_set_high_address_at_21_24484 = _13493;
    _13493 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_24484)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_21_24484 >= 0) {
            _1high_address_24312 = _ma_inlined_set_high_address_at_21_24484 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_21_24484 / (double)65536);
            _1high_address_24312 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_21_24484, 65536);
        _1high_address_24312 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_24312)) {
        _1 = (long)(DBL_PTR(_1high_address_24312)->dbl);
        DeRefDS(_1high_address_24312);
        _1high_address_24312 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_24_24485);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_24484)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_21_24484 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_24_24485 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_24_24485 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_21_24484, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_21_24484);
    _ma_inlined_set_high_address_at_21_24484 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_24_24485;
    ;
}


void  __stdcall _1free_linked_list_dll(int _low_24488, int _high_24489)
{
    int _get_address_1__tmp_at6_24493 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24492 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24488)) {
        _1 = (long)(DBL_PTR(_low_24488)->dbl);
        DeRefDS(_low_24488);
        _low_24488 = _1;
    }
    if (!IS_ATOM_INT(_high_24489)) {
        _1 = (long)(DBL_PTR(_high_24489)->dbl);
        DeRefDS(_high_24489);
        _high_24489 = _1;
    }

    /** 	free_linked_list(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24493);
    _get_address_1__tmp_at6_24493 = NewDouble(_high_24489 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24492);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24493)) {
        _get_address_inlined_get_address_at_6_24492 = _get_address_1__tmp_at6_24493 + _low_24488;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24492 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24492 = NewDouble((double)_get_address_inlined_get_address_at_6_24492);
    }
    else {
        _get_address_inlined_get_address_at_6_24492 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24493)->dbl + (double)_low_24488);
    }
    DeRef(_get_address_1__tmp_at6_24493);
    _get_address_1__tmp_at6_24493 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24492);
    _58free_linked_list(_get_address_inlined_get_address_at_6_24492);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1length_linked_list(int _id_24496)
{
    int _13497 = NOVALUE;
    int _13496 = NOVALUE;
    int _13495 = NOVALUE;
    int _13494 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24496)) {
        _1 = (long)(DBL_PTR(_id_24496)->dbl);
        DeRefDS(_id_24496);
        _id_24496 = _1;
    }

    /** 	if atom(data[id]) then*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13494 = (int)*(((s1_ptr)_2)->base + _id_24496);
    _13495 = IS_ATOM(_13494);
    _13494 = NOVALUE;
    if (_13495 == 0)
    {
        _13495 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _13495 = NOVALUE;
    }

    /** 		return -1*/
    return -1;
L1: 

    /** 	return length(data[id])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13496 = (int)*(((s1_ptr)_2)->base + _id_24496);
    if (IS_SEQUENCE(_13496)){
            _13497 = SEQ_PTR(_13496)->length;
    }
    else {
        _13497 = 1;
    }
    _13496 = NOVALUE;
    _13496 = NOVALUE;
    return _13497;
    ;
}


void  __stdcall _1store_at_linked_list(int _id_24504, int _index_24505, int _low_24506, int _high_24507)
{
    int _get_address_1__tmp_at17_24513 = NOVALUE;
    int _get_address_inlined_get_address_at_17_24512 = NOVALUE;
    int _13500 = NOVALUE;
    int _13498 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id_24504)) {
        _1 = (long)(DBL_PTR(_id_24504)->dbl);
        DeRefDS(_id_24504);
        _id_24504 = _1;
    }
    if (!IS_ATOM_INT(_index_24505)) {
        _1 = (long)(DBL_PTR(_index_24505)->dbl);
        DeRefDS(_index_24505);
        _index_24505 = _1;
    }
    if (!IS_ATOM_INT(_low_24506)) {
        _1 = (long)(DBL_PTR(_low_24506)->dbl);
        DeRefDS(_low_24506);
        _low_24506 = _1;
    }
    if (!IS_ATOM_INT(_high_24507)) {
        _1 = (long)(DBL_PTR(_high_24507)->dbl);
        DeRefDS(_high_24507);
        _high_24507 = _1;
    }

    /** 	data[id][index] = linked_list_to_sequence(get_address(low, high))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_24313 = MAKE_SEQ(_2);
    }
    _3 = (int)(_id_24504 + ((s1_ptr)_2)->base);

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at17_24513);
    _get_address_1__tmp_at17_24513 = NewDouble(_high_24507 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_17_24512);
    if (IS_ATOM_INT(_get_address_1__tmp_at17_24513)) {
        _get_address_inlined_get_address_at_17_24512 = _get_address_1__tmp_at17_24513 + _low_24506;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_17_24512 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_17_24512 = NewDouble((double)_get_address_inlined_get_address_at_17_24512);
    }
    else {
        _get_address_inlined_get_address_at_17_24512 = NewDouble(DBL_PTR(_get_address_1__tmp_at17_24513)->dbl + (double)_low_24506);
    }
    DeRef(_get_address_1__tmp_at17_24513);
    _get_address_1__tmp_at17_24513 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_17_24512);
    _13500 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_17_24512);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_24505);
    _1 = *(int *)_2;
    *(int *)_2 = _13500;
    if( _1 != _13500 ){
        DeRef(_1);
    }
    _13500 = NOVALUE;
    _13498 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_repeat(int _id_24517, int _len_24518)
{
    int _retval_inlined_retval_at_19_24523 = NOVALUE;
    int _ob_inlined_retval_at_16_24522 = NOVALUE;
    int _13502 = NOVALUE;
    int _13501 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24517)) {
        _1 = (long)(DBL_PTR(_id_24517)->dbl);
        DeRefDS(_id_24517);
        _id_24517 = _1;
    }
    if (!IS_ATOM_INT(_len_24518)) {
        _1 = (long)(DBL_PTR(_len_24518)->dbl);
        DeRefDS(_len_24518);
        _len_24518 = _1;
    }

    /** 	return retval(repeat(data[id], len))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13501 = (int)*(((s1_ptr)_2)->base + _id_24517);
    _13502 = Repeat(_13501, _len_24518);
    _13501 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24522);
    _ob_inlined_retval_at_16_24522 = _13502;
    _13502 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_24522);
    _0 = _retval_inlined_retval_at_19_24523;
    _retval_inlined_retval_at_19_24523 = _1register_data(_ob_inlined_retval_at_16_24522);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24522);
    _ob_inlined_retval_at_16_24522 = NOVALUE;
    return _retval_inlined_retval_at_19_24523;
    ;
}


void  __stdcall _1eu_mem_set(int _low_24526, int _high_24527, int _byte_val_24528, int _how_many_24529)
{
    int _get_address_1__tmp_at10_24532 = NOVALUE;
    int _get_address_inlined_get_address_at_10_24531 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24526)) {
        _1 = (long)(DBL_PTR(_low_24526)->dbl);
        DeRefDS(_low_24526);
        _low_24526 = _1;
    }
    if (!IS_ATOM_INT(_high_24527)) {
        _1 = (long)(DBL_PTR(_high_24527)->dbl);
        DeRefDS(_high_24527);
        _high_24527 = _1;
    }
    if (!IS_ATOM_INT(_byte_val_24528)) {
        _1 = (long)(DBL_PTR(_byte_val_24528)->dbl);
        DeRefDS(_byte_val_24528);
        _byte_val_24528 = _1;
    }
    if (!IS_ATOM_INT(_how_many_24529)) {
        _1 = (long)(DBL_PTR(_how_many_24529)->dbl);
        DeRefDS(_how_many_24529);
        _how_many_24529 = _1;
    }

    /** 	mem_set(get_address(low, high), byte_val, how_many)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_24532);
    _get_address_1__tmp_at10_24532 = NewDouble(_high_24527 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_24531);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_24532)) {
        _get_address_inlined_get_address_at_10_24531 = _get_address_1__tmp_at10_24532 + _low_24526;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_24531 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_24531 = NewDouble((double)_get_address_inlined_get_address_at_10_24531);
    }
    else {
        _get_address_inlined_get_address_at_10_24531 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_24532)->dbl + (double)_low_24526);
    }
    DeRef(_get_address_1__tmp_at10_24532);
    _get_address_1__tmp_at10_24532 = NOVALUE;
    memory_set(_get_address_inlined_get_address_at_10_24531, _byte_val_24528, _how_many_24529);

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_mem_copy(int _dstlow_24535, int _dsthigh_24536, int _srclow_24537, int _srchigh_24538, int _len_24539)
{
    int _get_address_1__tmp_at12_24542 = NOVALUE;
    int _get_address_inlined_get_address_at_12_24541 = NOVALUE;
    int _get_address_1__tmp_at25_24545 = NOVALUE;
    int _get_address_inlined_get_address_at_25_24544 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow_24535)) {
        _1 = (long)(DBL_PTR(_dstlow_24535)->dbl);
        DeRefDS(_dstlow_24535);
        _dstlow_24535 = _1;
    }
    if (!IS_ATOM_INT(_dsthigh_24536)) {
        _1 = (long)(DBL_PTR(_dsthigh_24536)->dbl);
        DeRefDS(_dsthigh_24536);
        _dsthigh_24536 = _1;
    }
    if (!IS_ATOM_INT(_srclow_24537)) {
        _1 = (long)(DBL_PTR(_srclow_24537)->dbl);
        DeRefDS(_srclow_24537);
        _srclow_24537 = _1;
    }
    if (!IS_ATOM_INT(_srchigh_24538)) {
        _1 = (long)(DBL_PTR(_srchigh_24538)->dbl);
        DeRefDS(_srchigh_24538);
        _srchigh_24538 = _1;
    }
    if (!IS_ATOM_INT(_len_24539)) {
        _1 = (long)(DBL_PTR(_len_24539)->dbl);
        DeRefDS(_len_24539);
        _len_24539 = _1;
    }

    /** 	mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at12_24542);
    _get_address_1__tmp_at12_24542 = NewDouble(_dsthigh_24536 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_12_24541);
    if (IS_ATOM_INT(_get_address_1__tmp_at12_24542)) {
        _get_address_inlined_get_address_at_12_24541 = _get_address_1__tmp_at12_24542 + _dstlow_24535;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_12_24541 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_12_24541 = NewDouble((double)_get_address_inlined_get_address_at_12_24541);
    }
    else {
        _get_address_inlined_get_address_at_12_24541 = NewDouble(DBL_PTR(_get_address_1__tmp_at12_24542)->dbl + (double)_dstlow_24535);
    }
    DeRef(_get_address_1__tmp_at12_24542);
    _get_address_1__tmp_at12_24542 = NOVALUE;

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at25_24545);
    _get_address_1__tmp_at25_24545 = NewDouble(_srchigh_24538 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_25_24544);
    if (IS_ATOM_INT(_get_address_1__tmp_at25_24545)) {
        _get_address_inlined_get_address_at_25_24544 = _get_address_1__tmp_at25_24545 + _srclow_24537;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_25_24544 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_25_24544 = NewDouble((double)_get_address_inlined_get_address_at_25_24544);
    }
    else {
        _get_address_inlined_get_address_at_25_24544 = NewDouble(DBL_PTR(_get_address_1__tmp_at25_24545)->dbl + (double)_srclow_24537);
    }
    DeRef(_get_address_1__tmp_at25_24545);
    _get_address_1__tmp_at25_24545 = NOVALUE;
    memory_copy(_get_address_inlined_get_address_at_12_24541, _get_address_inlined_get_address_at_25_24544, _len_24539);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_add(int _id1_24548, int _id2_24549)
{
    int _retval_inlined_retval_at_25_24555 = NOVALUE;
    int _ob_inlined_retval_at_22_24554 = NOVALUE;
    int _13505 = NOVALUE;
    int _13504 = NOVALUE;
    int _13503 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24548)) {
        _1 = (long)(DBL_PTR(_id1_24548)->dbl);
        DeRefDS(_id1_24548);
        _id1_24548 = _1;
    }
    if (!IS_ATOM_INT(_id2_24549)) {
        _1 = (long)(DBL_PTR(_id2_24549)->dbl);
        DeRefDS(_id2_24549);
        _id2_24549 = _1;
    }

    /** 	return retval(data[id1] + data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13503 = (int)*(((s1_ptr)_2)->base + _id1_24548);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13504 = (int)*(((s1_ptr)_2)->base + _id2_24549);
    if (IS_ATOM_INT(_13503) && IS_ATOM_INT(_13504)) {
        _13505 = _13503 + _13504;
        if ((long)((unsigned long)_13505 + (unsigned long)HIGH_BITS) >= 0) 
        _13505 = NewDouble((double)_13505);
    }
    else {
        _13505 = binary_op(PLUS, _13503, _13504);
    }
    _13503 = NOVALUE;
    _13504 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24554);
    _ob_inlined_retval_at_22_24554 = _13505;
    _13505 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24554);
    _0 = _retval_inlined_retval_at_25_24555;
    _retval_inlined_retval_at_25_24555 = _1register_data(_ob_inlined_retval_at_22_24554);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24554);
    _ob_inlined_retval_at_22_24554 = NOVALUE;
    return _retval_inlined_retval_at_25_24555;
    ;
}


int  __stdcall _1eu_subtract(int _id1_24558, int _id2_24559)
{
    int _retval_inlined_retval_at_25_24565 = NOVALUE;
    int _ob_inlined_retval_at_22_24564 = NOVALUE;
    int _13508 = NOVALUE;
    int _13507 = NOVALUE;
    int _13506 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24558)) {
        _1 = (long)(DBL_PTR(_id1_24558)->dbl);
        DeRefDS(_id1_24558);
        _id1_24558 = _1;
    }
    if (!IS_ATOM_INT(_id2_24559)) {
        _1 = (long)(DBL_PTR(_id2_24559)->dbl);
        DeRefDS(_id2_24559);
        _id2_24559 = _1;
    }

    /** 	return retval(data[id1] - data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13506 = (int)*(((s1_ptr)_2)->base + _id1_24558);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13507 = (int)*(((s1_ptr)_2)->base + _id2_24559);
    if (IS_ATOM_INT(_13506) && IS_ATOM_INT(_13507)) {
        _13508 = _13506 - _13507;
        if ((long)((unsigned long)_13508 +(unsigned long) HIGH_BITS) >= 0){
            _13508 = NewDouble((double)_13508);
        }
    }
    else {
        _13508 = binary_op(MINUS, _13506, _13507);
    }
    _13506 = NOVALUE;
    _13507 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24564);
    _ob_inlined_retval_at_22_24564 = _13508;
    _13508 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24564);
    _0 = _retval_inlined_retval_at_25_24565;
    _retval_inlined_retval_at_25_24565 = _1register_data(_ob_inlined_retval_at_22_24564);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24564);
    _ob_inlined_retval_at_22_24564 = NOVALUE;
    return _retval_inlined_retval_at_25_24565;
    ;
}


int  __stdcall _1eu_multiply(int _id1_24568, int _id2_24569)
{
    int _retval_inlined_retval_at_25_24575 = NOVALUE;
    int _ob_inlined_retval_at_22_24574 = NOVALUE;
    int _13511 = NOVALUE;
    int _13510 = NOVALUE;
    int _13509 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24568)) {
        _1 = (long)(DBL_PTR(_id1_24568)->dbl);
        DeRefDS(_id1_24568);
        _id1_24568 = _1;
    }
    if (!IS_ATOM_INT(_id2_24569)) {
        _1 = (long)(DBL_PTR(_id2_24569)->dbl);
        DeRefDS(_id2_24569);
        _id2_24569 = _1;
    }

    /** 	return retval(data[id1] * data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13509 = (int)*(((s1_ptr)_2)->base + _id1_24568);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13510 = (int)*(((s1_ptr)_2)->base + _id2_24569);
    if (IS_ATOM_INT(_13509) && IS_ATOM_INT(_13510)) {
        if (_13509 == (short)_13509 && _13510 <= INT15 && _13510 >= -INT15)
        _13511 = _13509 * _13510;
        else
        _13511 = NewDouble(_13509 * (double)_13510);
    }
    else {
        _13511 = binary_op(MULTIPLY, _13509, _13510);
    }
    _13509 = NOVALUE;
    _13510 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24574);
    _ob_inlined_retval_at_22_24574 = _13511;
    _13511 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24574);
    _0 = _retval_inlined_retval_at_25_24575;
    _retval_inlined_retval_at_25_24575 = _1register_data(_ob_inlined_retval_at_22_24574);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24574);
    _ob_inlined_retval_at_22_24574 = NOVALUE;
    return _retval_inlined_retval_at_25_24575;
    ;
}


int  __stdcall _1eu_divide(int _id1_24578, int _id2_24579)
{
    int _retval_inlined_retval_at_25_24585 = NOVALUE;
    int _ob_inlined_retval_at_22_24584 = NOVALUE;
    int _13514 = NOVALUE;
    int _13513 = NOVALUE;
    int _13512 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24578)) {
        _1 = (long)(DBL_PTR(_id1_24578)->dbl);
        DeRefDS(_id1_24578);
        _id1_24578 = _1;
    }
    if (!IS_ATOM_INT(_id2_24579)) {
        _1 = (long)(DBL_PTR(_id2_24579)->dbl);
        DeRefDS(_id2_24579);
        _id2_24579 = _1;
    }

    /** 	return retval(data[id1] / data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13512 = (int)*(((s1_ptr)_2)->base + _id1_24578);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13513 = (int)*(((s1_ptr)_2)->base + _id2_24579);
    if (IS_ATOM_INT(_13512) && IS_ATOM_INT(_13513)) {
        _13514 = (_13512 % _13513) ? NewDouble((double)_13512 / _13513) : (_13512 / _13513);
    }
    else {
        _13514 = binary_op(DIVIDE, _13512, _13513);
    }
    _13512 = NOVALUE;
    _13513 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24584);
    _ob_inlined_retval_at_22_24584 = _13514;
    _13514 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24584);
    _0 = _retval_inlined_retval_at_25_24585;
    _retval_inlined_retval_at_25_24585 = _1register_data(_ob_inlined_retval_at_22_24584);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24584);
    _ob_inlined_retval_at_22_24584 = NOVALUE;
    return _retval_inlined_retval_at_25_24585;
    ;
}


int  __stdcall _1eu_negate(int _id_24588)
{
    int _retval_inlined_retval_at_16_24593 = NOVALUE;
    int _ob_inlined_retval_at_13_24592 = NOVALUE;
    int _13516 = NOVALUE;
    int _13515 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24588)) {
        _1 = (long)(DBL_PTR(_id_24588)->dbl);
        DeRefDS(_id_24588);
        _id_24588 = _1;
    }

    /** 	return retval(-data[id])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13515 = (int)*(((s1_ptr)_2)->base + _id_24588);
    if (IS_ATOM_INT(_13515)) {
        if ((unsigned long)_13515 == 0xC0000000)
        _13516 = (int)NewDouble((double)-0xC0000000);
        else
        _13516 = - _13515;
    }
    else {
        _13516 = unary_op(UMINUS, _13515);
    }
    _13515 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24592);
    _ob_inlined_retval_at_13_24592 = _13516;
    _13516 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24592);
    _0 = _retval_inlined_retval_at_16_24593;
    _retval_inlined_retval_at_16_24593 = _1register_data(_ob_inlined_retval_at_13_24592);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24592);
    _ob_inlined_retval_at_13_24592 = NOVALUE;
    return _retval_inlined_retval_at_16_24593;
    ;
}


int  __stdcall _1eu_not(int _id_24596)
{
    int _retval_inlined_retval_at_16_24601 = NOVALUE;
    int _ob_inlined_retval_at_13_24600 = NOVALUE;
    int _13518 = NOVALUE;
    int _13517 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24596)) {
        _1 = (long)(DBL_PTR(_id_24596)->dbl);
        DeRefDS(_id_24596);
        _id_24596 = _1;
    }

    /** 	return retval(not data[id])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13517 = (int)*(((s1_ptr)_2)->base + _id_24596);
    if (IS_ATOM_INT(_13517)) {
        _13518 = (_13517 == 0);
    }
    else {
        _13518 = unary_op(NOT, _13517);
    }
    _13517 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24600);
    _ob_inlined_retval_at_13_24600 = _13518;
    _13518 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24600);
    _0 = _retval_inlined_retval_at_16_24601;
    _retval_inlined_retval_at_16_24601 = _1register_data(_ob_inlined_retval_at_13_24600);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24600);
    _ob_inlined_retval_at_13_24600 = NOVALUE;
    return _retval_inlined_retval_at_16_24601;
    ;
}


int  __stdcall _1eu_equals(int _id1_24604, int _id2_24605)
{
    int _retval_inlined_retval_at_25_24611 = NOVALUE;
    int _ob_inlined_retval_at_22_24610 = NOVALUE;
    int _13521 = NOVALUE;
    int _13520 = NOVALUE;
    int _13519 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24604)) {
        _1 = (long)(DBL_PTR(_id1_24604)->dbl);
        DeRefDS(_id1_24604);
        _id1_24604 = _1;
    }
    if (!IS_ATOM_INT(_id2_24605)) {
        _1 = (long)(DBL_PTR(_id2_24605)->dbl);
        DeRefDS(_id2_24605);
        _id2_24605 = _1;
    }

    /** 	return retval(data[id1] = data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13519 = (int)*(((s1_ptr)_2)->base + _id1_24604);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13520 = (int)*(((s1_ptr)_2)->base + _id2_24605);
    if (IS_ATOM_INT(_13519) && IS_ATOM_INT(_13520)) {
        _13521 = (_13519 == _13520);
    }
    else {
        _13521 = binary_op(EQUALS, _13519, _13520);
    }
    _13519 = NOVALUE;
    _13520 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24610);
    _ob_inlined_retval_at_22_24610 = _13521;
    _13521 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24610);
    _0 = _retval_inlined_retval_at_25_24611;
    _retval_inlined_retval_at_25_24611 = _1register_data(_ob_inlined_retval_at_22_24610);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24610);
    _ob_inlined_retval_at_22_24610 = NOVALUE;
    return _retval_inlined_retval_at_25_24611;
    ;
}


int  __stdcall _1eu_and(int _id1_24614, int _id2_24615)
{
    int _retval_inlined_retval_at_25_24621 = NOVALUE;
    int _ob_inlined_retval_at_22_24620 = NOVALUE;
    int _13524 = NOVALUE;
    int _13523 = NOVALUE;
    int _13522 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24614)) {
        _1 = (long)(DBL_PTR(_id1_24614)->dbl);
        DeRefDS(_id1_24614);
        _id1_24614 = _1;
    }
    if (!IS_ATOM_INT(_id2_24615)) {
        _1 = (long)(DBL_PTR(_id2_24615)->dbl);
        DeRefDS(_id2_24615);
        _id2_24615 = _1;
    }

    /** 	return retval(data[id1] and data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13522 = (int)*(((s1_ptr)_2)->base + _id1_24614);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13523 = (int)*(((s1_ptr)_2)->base + _id2_24615);
    if (IS_ATOM_INT(_13522) && IS_ATOM_INT(_13523)) {
        _13524 = (_13522 != 0 && _13523 != 0);
    }
    else {
        _13524 = binary_op(AND, _13522, _13523);
    }
    _13522 = NOVALUE;
    _13523 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24620);
    _ob_inlined_retval_at_22_24620 = _13524;
    _13524 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24620);
    _0 = _retval_inlined_retval_at_25_24621;
    _retval_inlined_retval_at_25_24621 = _1register_data(_ob_inlined_retval_at_22_24620);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24620);
    _ob_inlined_retval_at_22_24620 = NOVALUE;
    return _retval_inlined_retval_at_25_24621;
    ;
}


int  __stdcall _1eu_or(int _id1_24624, int _id2_24625)
{
    int _retval_inlined_retval_at_25_24631 = NOVALUE;
    int _ob_inlined_retval_at_22_24630 = NOVALUE;
    int _13527 = NOVALUE;
    int _13526 = NOVALUE;
    int _13525 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24624)) {
        _1 = (long)(DBL_PTR(_id1_24624)->dbl);
        DeRefDS(_id1_24624);
        _id1_24624 = _1;
    }
    if (!IS_ATOM_INT(_id2_24625)) {
        _1 = (long)(DBL_PTR(_id2_24625)->dbl);
        DeRefDS(_id2_24625);
        _id2_24625 = _1;
    }

    /** 	return retval(data[id1] or data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13525 = (int)*(((s1_ptr)_2)->base + _id1_24624);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13526 = (int)*(((s1_ptr)_2)->base + _id2_24625);
    if (IS_ATOM_INT(_13525) && IS_ATOM_INT(_13526)) {
        _13527 = (_13525 != 0 || _13526 != 0);
    }
    else {
        _13527 = binary_op(OR, _13525, _13526);
    }
    _13525 = NOVALUE;
    _13526 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24630);
    _ob_inlined_retval_at_22_24630 = _13527;
    _13527 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24630);
    _0 = _retval_inlined_retval_at_25_24631;
    _retval_inlined_retval_at_25_24631 = _1register_data(_ob_inlined_retval_at_22_24630);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24630);
    _ob_inlined_retval_at_22_24630 = NOVALUE;
    return _retval_inlined_retval_at_25_24631;
    ;
}


int  __stdcall _1eu_xor(int _id1_24634, int _id2_24635)
{
    int _retval_inlined_retval_at_25_24641 = NOVALUE;
    int _ob_inlined_retval_at_22_24640 = NOVALUE;
    int _13530 = NOVALUE;
    int _13529 = NOVALUE;
    int _13528 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24634)) {
        _1 = (long)(DBL_PTR(_id1_24634)->dbl);
        DeRefDS(_id1_24634);
        _id1_24634 = _1;
    }
    if (!IS_ATOM_INT(_id2_24635)) {
        _1 = (long)(DBL_PTR(_id2_24635)->dbl);
        DeRefDS(_id2_24635);
        _id2_24635 = _1;
    }

    /** 	return retval(data[id1] xor data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13528 = (int)*(((s1_ptr)_2)->base + _id1_24634);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13529 = (int)*(((s1_ptr)_2)->base + _id2_24635);
    if (IS_ATOM_INT(_13528) && IS_ATOM_INT(_13529)) {
        _13530 = ((_13528 != 0) != (_13529 != 0));
    }
    else {
        _13530 = binary_op(XOR, _13528, _13529);
    }
    _13528 = NOVALUE;
    _13529 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24640);
    _ob_inlined_retval_at_22_24640 = _13530;
    _13530 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24640);
    _0 = _retval_inlined_retval_at_25_24641;
    _retval_inlined_retval_at_25_24641 = _1register_data(_ob_inlined_retval_at_22_24640);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24640);
    _ob_inlined_retval_at_22_24640 = NOVALUE;
    return _retval_inlined_retval_at_25_24641;
    ;
}


void  __stdcall _1eu_question_mark(int _id_24644)
{
    int _13531 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24644)) {
        _1 = (long)(DBL_PTR(_id_24644)->dbl);
        DeRefDS(_id_24644);
        _id_24644 = _1;
    }

    /** 	? data[id]*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13531 = (int)*(((s1_ptr)_2)->base + _id_24644);
    StdPrint(1, _13531, 1);
    _13531 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_abort(int _ret_24648)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_24648)) {
        _1 = (long)(DBL_PTR(_ret_24648)->dbl);
        DeRefDS(_ret_24648);
        _ret_24648 = _1;
    }

    /** 	abort(ret)*/
    UserCleanup(_ret_24648);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_and_bits(int _id1_24651, int _id2_24652)
{
    int _retval_inlined_retval_at_25_24658 = NOVALUE;
    int _ob_inlined_retval_at_22_24657 = NOVALUE;
    int _13534 = NOVALUE;
    int _13533 = NOVALUE;
    int _13532 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24651)) {
        _1 = (long)(DBL_PTR(_id1_24651)->dbl);
        DeRefDS(_id1_24651);
        _id1_24651 = _1;
    }
    if (!IS_ATOM_INT(_id2_24652)) {
        _1 = (long)(DBL_PTR(_id2_24652)->dbl);
        DeRefDS(_id2_24652);
        _id2_24652 = _1;
    }

    /** 	return retval(and_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13532 = (int)*(((s1_ptr)_2)->base + _id1_24651);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13533 = (int)*(((s1_ptr)_2)->base + _id2_24652);
    if (IS_ATOM_INT(_13532) && IS_ATOM_INT(_13533)) {
        {unsigned long tu;
             tu = (unsigned long)_13532 & (unsigned long)_13533;
             _13534 = MAKE_UINT(tu);
        }
    }
    else {
        _13534 = binary_op(AND_BITS, _13532, _13533);
    }
    _13532 = NOVALUE;
    _13533 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24657);
    _ob_inlined_retval_at_22_24657 = _13534;
    _13534 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24657);
    _0 = _retval_inlined_retval_at_25_24658;
    _retval_inlined_retval_at_25_24658 = _1register_data(_ob_inlined_retval_at_22_24657);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24657);
    _ob_inlined_retval_at_22_24657 = NOVALUE;
    return _retval_inlined_retval_at_25_24658;
    ;
}


int  __stdcall _1eu_append(int _id1_24661, int _id2_24662)
{
    int _retval_inlined_retval_at_25_24668 = NOVALUE;
    int _ob_inlined_retval_at_22_24667 = NOVALUE;
    int _13537 = NOVALUE;
    int _13536 = NOVALUE;
    int _13535 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24661)) {
        _1 = (long)(DBL_PTR(_id1_24661)->dbl);
        DeRefDS(_id1_24661);
        _id1_24661 = _1;
    }
    if (!IS_ATOM_INT(_id2_24662)) {
        _1 = (long)(DBL_PTR(_id2_24662)->dbl);
        DeRefDS(_id2_24662);
        _id2_24662 = _1;
    }

    /** 	return retval(append(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13535 = (int)*(((s1_ptr)_2)->base + _id1_24661);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13536 = (int)*(((s1_ptr)_2)->base + _id2_24662);
    Ref(_13536);
    Append(&_13537, _13535, _13536);
    _13535 = NOVALUE;
    _13536 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24667);
    _ob_inlined_retval_at_22_24667 = _13537;
    _13537 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24667);
    _0 = _retval_inlined_retval_at_25_24668;
    _retval_inlined_retval_at_25_24668 = _1register_data(_ob_inlined_retval_at_22_24667);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24667);
    _ob_inlined_retval_at_22_24667 = NOVALUE;
    return _retval_inlined_retval_at_25_24668;
    ;
}


int  __stdcall _1eu_arctan(int _id_24671)
{
    int _retval_inlined_retval_at_16_24676 = NOVALUE;
    int _ob_inlined_retval_at_13_24675 = NOVALUE;
    int _13539 = NOVALUE;
    int _13538 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24671)) {
        _1 = (long)(DBL_PTR(_id_24671)->dbl);
        DeRefDS(_id_24671);
        _id_24671 = _1;
    }

    /** 	return retval(arctan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13538 = (int)*(((s1_ptr)_2)->base + _id_24671);
    if (IS_ATOM_INT(_13538))
    _13539 = e_arctan(_13538);
    else
    _13539 = unary_op(ARCTAN, _13538);
    _13538 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24675);
    _ob_inlined_retval_at_13_24675 = _13539;
    _13539 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24675);
    _0 = _retval_inlined_retval_at_16_24676;
    _retval_inlined_retval_at_16_24676 = _1register_data(_ob_inlined_retval_at_13_24675);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24675);
    _ob_inlined_retval_at_13_24675 = NOVALUE;
    return _retval_inlined_retval_at_16_24676;
    ;
}


int  __stdcall _1eu_atom(int _id_24679)
{
    int _13541 = NOVALUE;
    int _13540 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24679)) {
        _1 = (long)(DBL_PTR(_id_24679)->dbl);
        DeRefDS(_id_24679);
        _id_24679 = _1;
    }

    /** 	return atom(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13540 = (int)*(((s1_ptr)_2)->base + _id_24679);
    _13541 = IS_ATOM(_13540);
    _13540 = NOVALUE;
    return _13541;
    ;
}


int  __stdcall _1eu_c_func(int _rid_24684, int _id1_24685)
{
    int _retval_inlined_retval_at_20_24690 = NOVALUE;
    int _ob_inlined_retval_at_17_24689 = NOVALUE;
    int _13543 = NOVALUE;
    int _13542 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24684)) {
        _1 = (long)(DBL_PTR(_rid_24684)->dbl);
        DeRefDS(_rid_24684);
        _rid_24684 = _1;
    }
    if (!IS_ATOM_INT(_id1_24685)) {
        _1 = (long)(DBL_PTR(_id1_24685)->dbl);
        DeRefDS(_id1_24685);
        _id1_24685 = _1;
    }

    /** 	return retval(c_func(rid, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13542 = (int)*(((s1_ptr)_2)->base + _id1_24685);
    _13543 = call_c(1, _rid_24684, _13542);
    _13542 = NOVALUE;
    DeRef(_ob_inlined_retval_at_17_24689);
    _ob_inlined_retval_at_17_24689 = _13543;
    _13543 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_17_24689);
    _0 = _retval_inlined_retval_at_20_24690;
    _retval_inlined_retval_at_20_24690 = _1register_data(_ob_inlined_retval_at_17_24689);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_17_24689);
    _ob_inlined_retval_at_17_24689 = NOVALUE;
    return _retval_inlined_retval_at_20_24690;
    ;
}


void  __stdcall _1eu_c_proc(int _rid_24693, int _id1_24694)
{
    int _13544 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24693)) {
        _1 = (long)(DBL_PTR(_rid_24693)->dbl);
        DeRefDS(_rid_24693);
        _rid_24693 = _1;
    }
    if (!IS_ATOM_INT(_id1_24694)) {
        _1 = (long)(DBL_PTR(_id1_24694)->dbl);
        DeRefDS(_id1_24694);
        _id1_24694 = _1;
    }

    /** 	c_proc(rid, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13544 = (int)*(((s1_ptr)_2)->base + _id1_24694);
    call_c(0, _rid_24693, _13544);
    _13544 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_call(int _low_24698, int _high_24699)
{
    int _get_address_1__tmp_at6_24702 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24701 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24698)) {
        _1 = (long)(DBL_PTR(_low_24698)->dbl);
        DeRefDS(_low_24698);
        _low_24698 = _1;
    }
    if (!IS_ATOM_INT(_high_24699)) {
        _1 = (long)(DBL_PTR(_high_24699)->dbl);
        DeRefDS(_high_24699);
        _high_24699 = _1;
    }

    /** 	call(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24702);
    _get_address_1__tmp_at6_24702 = NewDouble(_high_24699 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24701);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24702)) {
        _get_address_inlined_get_address_at_6_24701 = _get_address_1__tmp_at6_24702 + _low_24698;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24701 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24701 = NewDouble((double)_get_address_inlined_get_address_at_6_24701);
    }
    else {
        _get_address_inlined_get_address_at_6_24701 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24702)->dbl + (double)_low_24698);
    }
    DeRef(_get_address_1__tmp_at6_24702);
    _get_address_1__tmp_at6_24702 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_24701))
    _0 = (int)_get_address_inlined_get_address_at_6_24701;
    else
    _0 = (int)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_24701)->dbl);
    (*(void(*)())_0)();

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_clear_screen()
{
    int _0, _1, _2;
    

    /** 	clear_screen()*/
    ClearScreen();

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_close(int _fn_id_24707)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24707)) {
        _1 = (long)(DBL_PTR(_fn_id_24707)->dbl);
        DeRefDS(_fn_id_24707);
        _fn_id_24707 = _1;
    }

    /** 	close(fn_id)*/
    EClose(_fn_id_24707);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_command_line()
{
    int _retval_inlined_retval_at_7_24713 = NOVALUE;
    int _ob_inlined_retval_at_4_24712 = NOVALUE;
    int _13545 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(command_line())*/
    _13545 = Command_Line();
    DeRef(_ob_inlined_retval_at_4_24712);
    _ob_inlined_retval_at_4_24712 = _13545;
    _13545 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_24712);
    _0 = _retval_inlined_retval_at_7_24713;
    _retval_inlined_retval_at_7_24713 = _1register_data(_ob_inlined_retval_at_4_24712);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_24712);
    _ob_inlined_retval_at_4_24712 = NOVALUE;
    return _retval_inlined_retval_at_7_24713;
    ;
}


int  __stdcall _1eu_compare(int _id1_24716, int _id2_24717)
{
    int _13548 = NOVALUE;
    int _13547 = NOVALUE;
    int _13546 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24716)) {
        _1 = (long)(DBL_PTR(_id1_24716)->dbl);
        DeRefDS(_id1_24716);
        _id1_24716 = _1;
    }
    if (!IS_ATOM_INT(_id2_24717)) {
        _1 = (long)(DBL_PTR(_id2_24717)->dbl);
        DeRefDS(_id2_24717);
        _id2_24717 = _1;
    }

    /** 	return compare(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13546 = (int)*(((s1_ptr)_2)->base + _id1_24716);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13547 = (int)*(((s1_ptr)_2)->base + _id2_24717);
    if (IS_ATOM_INT(_13546) && IS_ATOM_INT(_13547)){
        _13548 = (_13546 < _13547) ? -1 : (_13546 > _13547);
    }
    else{
        _13548 = compare(_13546, _13547);
    }
    _13546 = NOVALUE;
    _13547 = NOVALUE;
    return _13548;
    ;
}


int  __stdcall _1eu_concat(int _id1_24723, int _id2_24724)
{
    int _retval_inlined_retval_at_25_24730 = NOVALUE;
    int _ob_inlined_retval_at_22_24729 = NOVALUE;
    int _13551 = NOVALUE;
    int _13550 = NOVALUE;
    int _13549 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24723)) {
        _1 = (long)(DBL_PTR(_id1_24723)->dbl);
        DeRefDS(_id1_24723);
        _id1_24723 = _1;
    }
    if (!IS_ATOM_INT(_id2_24724)) {
        _1 = (long)(DBL_PTR(_id2_24724)->dbl);
        DeRefDS(_id2_24724);
        _id2_24724 = _1;
    }

    /** 	return retval(data[id1] & data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13549 = (int)*(((s1_ptr)_2)->base + _id1_24723);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13550 = (int)*(((s1_ptr)_2)->base + _id2_24724);
    if (IS_SEQUENCE(_13549) && IS_ATOM(_13550)) {
        Ref(_13550);
        Append(&_13551, _13549, _13550);
    }
    else if (IS_ATOM(_13549) && IS_SEQUENCE(_13550)) {
        Ref(_13549);
        Prepend(&_13551, _13550, _13549);
    }
    else {
        Concat((object_ptr)&_13551, _13549, _13550);
        _13549 = NOVALUE;
    }
    _13549 = NOVALUE;
    _13550 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24729);
    _ob_inlined_retval_at_22_24729 = _13551;
    _13551 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24729);
    _0 = _retval_inlined_retval_at_25_24730;
    _retval_inlined_retval_at_25_24730 = _1register_data(_ob_inlined_retval_at_22_24729);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24729);
    _ob_inlined_retval_at_22_24729 = NOVALUE;
    return _retval_inlined_retval_at_25_24730;
    ;
}


int  __stdcall _1eu_cos(int _id_24733)
{
    int _retval_inlined_retval_at_16_24738 = NOVALUE;
    int _ob_inlined_retval_at_13_24737 = NOVALUE;
    int _13553 = NOVALUE;
    int _13552 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24733)) {
        _1 = (long)(DBL_PTR(_id_24733)->dbl);
        DeRefDS(_id_24733);
        _id_24733 = _1;
    }

    /** 	return retval(cos(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13552 = (int)*(((s1_ptr)_2)->base + _id_24733);
    if (IS_ATOM_INT(_13552))
    _13553 = e_cos(_13552);
    else
    _13553 = unary_op(COS, _13552);
    _13552 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24737);
    _ob_inlined_retval_at_13_24737 = _13553;
    _13553 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24737);
    _0 = _retval_inlined_retval_at_16_24738;
    _retval_inlined_retval_at_16_24738 = _1register_data(_ob_inlined_retval_at_13_24737);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24737);
    _ob_inlined_retval_at_13_24737 = NOVALUE;
    return _retval_inlined_retval_at_16_24738;
    ;
}


int  __stdcall _1eu_date()
{
    int _retval_inlined_retval_at_7_24744 = NOVALUE;
    int _ob_inlined_retval_at_4_24743 = NOVALUE;
    int _13554 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(date())*/
    _13554 = Date();
    DeRefi(_ob_inlined_retval_at_4_24743);
    _ob_inlined_retval_at_4_24743 = _13554;
    _13554 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_24743);
    _0 = _retval_inlined_retval_at_7_24744;
    _retval_inlined_retval_at_7_24744 = _1register_data(_ob_inlined_retval_at_4_24743);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_4_24743);
    _ob_inlined_retval_at_4_24743 = NOVALUE;
    return _retval_inlined_retval_at_7_24744;
    ;
}


int  __stdcall _1eu_equal(int _id1_24747, int _id2_24748)
{
    int _13557 = NOVALUE;
    int _13556 = NOVALUE;
    int _13555 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24747)) {
        _1 = (long)(DBL_PTR(_id1_24747)->dbl);
        DeRefDS(_id1_24747);
        _id1_24747 = _1;
    }
    if (!IS_ATOM_INT(_id2_24748)) {
        _1 = (long)(DBL_PTR(_id2_24748)->dbl);
        DeRefDS(_id2_24748);
        _id2_24748 = _1;
    }

    /** 	return equal(data[id1], data[id2]) -- boolean, returns 0 or 1*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13555 = (int)*(((s1_ptr)_2)->base + _id1_24747);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13556 = (int)*(((s1_ptr)_2)->base + _id2_24748);
    if (_13555 == _13556)
    _13557 = 1;
    else if (IS_ATOM_INT(_13555) && IS_ATOM_INT(_13556))
    _13557 = 0;
    else
    _13557 = (compare(_13555, _13556) == 0);
    _13555 = NOVALUE;
    _13556 = NOVALUE;
    return _13557;
    ;
}


int  __stdcall _1eu_find_from(int _id1_24754, int _id2_24755, int _start_24756)
{
    int _13560 = NOVALUE;
    int _13559 = NOVALUE;
    int _13558 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24754)) {
        _1 = (long)(DBL_PTR(_id1_24754)->dbl);
        DeRefDS(_id1_24754);
        _id1_24754 = _1;
    }
    if (!IS_ATOM_INT(_id2_24755)) {
        _1 = (long)(DBL_PTR(_id2_24755)->dbl);
        DeRefDS(_id2_24755);
        _id2_24755 = _1;
    }
    if (!IS_ATOM_INT(_start_24756)) {
        _1 = (long)(DBL_PTR(_start_24756)->dbl);
        DeRefDS(_start_24756);
        _start_24756 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13558 = (int)*(((s1_ptr)_2)->base + _id1_24754);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13559 = (int)*(((s1_ptr)_2)->base + _id2_24755);
    _13560 = find_from(_13558, _13559, _start_24756);
    _13558 = NOVALUE;
    _13559 = NOVALUE;
    return _13560;
    ;
}


int  __stdcall _1eu_find(int _id1_24762, int _id2_24763, int _start_24764)
{
    int _13563 = NOVALUE;
    int _13562 = NOVALUE;
    int _13561 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24762)) {
        _1 = (long)(DBL_PTR(_id1_24762)->dbl);
        DeRefDS(_id1_24762);
        _id1_24762 = _1;
    }
    if (!IS_ATOM_INT(_id2_24763)) {
        _1 = (long)(DBL_PTR(_id2_24763)->dbl);
        DeRefDS(_id2_24763);
        _id2_24763 = _1;
    }
    if (!IS_ATOM_INT(_start_24764)) {
        _1 = (long)(DBL_PTR(_start_24764)->dbl);
        DeRefDS(_start_24764);
        _start_24764 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13561 = (int)*(((s1_ptr)_2)->base + _id1_24762);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13562 = (int)*(((s1_ptr)_2)->base + _id2_24763);
    _13563 = find_from(_13561, _13562, _start_24764);
    _13561 = NOVALUE;
    _13562 = NOVALUE;
    return _13563;
    ;
}


int  __stdcall _1eu_floor(int _id1_24770)
{
    int _retval_inlined_retval_at_16_24775 = NOVALUE;
    int _ob_inlined_retval_at_13_24774 = NOVALUE;
    int _13565 = NOVALUE;
    int _13564 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24770)) {
        _1 = (long)(DBL_PTR(_id1_24770)->dbl);
        DeRefDS(_id1_24770);
        _id1_24770 = _1;
    }

    /** 	return retval(floor(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13564 = (int)*(((s1_ptr)_2)->base + _id1_24770);
    if (IS_ATOM_INT(_13564))
    _13565 = e_floor(_13564);
    else
    _13565 = unary_op(FLOOR, _13564);
    _13564 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24774);
    _ob_inlined_retval_at_13_24774 = _13565;
    _13565 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24774);
    _0 = _retval_inlined_retval_at_16_24775;
    _retval_inlined_retval_at_16_24775 = _1register_data(_ob_inlined_retval_at_13_24774);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24774);
    _ob_inlined_retval_at_13_24774 = NOVALUE;
    return _retval_inlined_retval_at_16_24775;
    ;
}


int  __stdcall _1eu_integer_division(int _id1_24778, int _id2_24779)
{
    int _retval_inlined_retval_at_25_24785 = NOVALUE;
    int _ob_inlined_retval_at_22_24784 = NOVALUE;
    int _13568 = NOVALUE;
    int _13567 = NOVALUE;
    int _13566 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24778)) {
        _1 = (long)(DBL_PTR(_id1_24778)->dbl);
        DeRefDS(_id1_24778);
        _id1_24778 = _1;
    }
    if (!IS_ATOM_INT(_id2_24779)) {
        _1 = (long)(DBL_PTR(_id2_24779)->dbl);
        DeRefDS(_id2_24779);
        _id2_24779 = _1;
    }

    /** 	return retval(floor(data[id1] / data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13566 = (int)*(((s1_ptr)_2)->base + _id1_24778);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13567 = (int)*(((s1_ptr)_2)->base + _id2_24779);
    if (IS_ATOM_INT(_13566) && IS_ATOM_INT(_13567)) {
        if (_13567 > 0 && _13566 >= 0) {
            _13568 = _13566 / _13567;
        }
        else {
            temp_dbl = floor((double)_13566 / (double)_13567);
            if (_13566 != MININT)
            _13568 = (long)temp_dbl;
            else
            _13568 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _13566, _13567);
        _13568 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _13566 = NOVALUE;
    _13567 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24784);
    _ob_inlined_retval_at_22_24784 = _13568;
    _13568 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24784);
    _0 = _retval_inlined_retval_at_25_24785;
    _retval_inlined_retval_at_25_24785 = _1register_data(_ob_inlined_retval_at_22_24784);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24784);
    _ob_inlined_retval_at_22_24784 = NOVALUE;
    return _retval_inlined_retval_at_25_24785;
    ;
}


int  __stdcall _1eu_get_key()
{
    int _13569 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return get_key() -- returns an integer*/
    show_console();
    _13569 = get_key(0);
    return _13569;
    ;
}


int  __stdcall _1eu_getc(int _fn_id_24791)
{
    int _13570 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24791)) {
        _1 = (long)(DBL_PTR(_fn_id_24791)->dbl);
        DeRefDS(_fn_id_24791);
        _fn_id_24791 = _1;
    }

    /** 	return getc(fn_id) -- returns a character or byte*/
    if (_fn_id_24791 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id_24791, EF_READ);
        last_r_file_no = _fn_id_24791;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _13570 = getKBchar();
        }
        else
        _13570 = getc(last_r_file_ptr);
    }
    else
    _13570 = getc(last_r_file_ptr);
    return _13570;
    ;
}


int  __stdcall _1eu_getenv(int _id1_24795)
{
    int _retval_inlined_retval_at_16_24800 = NOVALUE;
    int _ob_inlined_retval_at_13_24799 = NOVALUE;
    int _13572 = NOVALUE;
    int _13571 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24795)) {
        _1 = (long)(DBL_PTR(_id1_24795)->dbl);
        DeRefDS(_id1_24795);
        _id1_24795 = _1;
    }

    /** 	return retval(getenv(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13571 = (int)*(((s1_ptr)_2)->base + _id1_24795);
    _13572 = EGetEnv(_13571);
    _13571 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_13_24799);
    _ob_inlined_retval_at_13_24799 = _13572;
    _13572 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24799);
    _0 = _retval_inlined_retval_at_16_24800;
    _retval_inlined_retval_at_16_24800 = _1register_data(_ob_inlined_retval_at_13_24799);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_13_24799);
    _ob_inlined_retval_at_13_24799 = NOVALUE;
    return _retval_inlined_retval_at_16_24800;
    ;
}


int  __stdcall _1eu_gets(int _fn_id_24803)
{
    int _retval_inlined_retval_at_10_24807 = NOVALUE;
    int _ob_inlined_retval_at_7_24806 = NOVALUE;
    int _13573 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24803)) {
        _1 = (long)(DBL_PTR(_fn_id_24803)->dbl);
        DeRefDS(_fn_id_24803);
        _fn_id_24803 = _1;
    }

    /** 	return retval(gets(fn_id))*/
    _13573 = EGets(_fn_id_24803);
    DeRefi(_ob_inlined_retval_at_7_24806);
    _ob_inlined_retval_at_7_24806 = _13573;
    _13573 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_7_24806);
    _0 = _retval_inlined_retval_at_10_24807;
    _retval_inlined_retval_at_10_24807 = _1register_data(_ob_inlined_retval_at_7_24806);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_7_24806);
    _ob_inlined_retval_at_7_24806 = NOVALUE;
    return _retval_inlined_retval_at_10_24807;
    ;
}


int  __stdcall _1eu_integer(int _id_24810)
{
    int _13575 = NOVALUE;
    int _13574 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24810)) {
        _1 = (long)(DBL_PTR(_id_24810)->dbl);
        DeRefDS(_id_24810);
        _id_24810 = _1;
    }

    /** 	return integer(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13574 = (int)*(((s1_ptr)_2)->base + _id_24810);
    if (IS_ATOM_INT(_13574))
    _13575 = 1;
    else if (IS_ATOM_DBL(_13574))
    _13575 = IS_ATOM_INT(DoubleToInt(_13574));
    else
    _13575 = 0;
    _13574 = NOVALUE;
    return _13575;
    ;
}


int  __stdcall _1eu_length(int _id_24815)
{
    int _13577 = NOVALUE;
    int _13576 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24815)) {
        _1 = (long)(DBL_PTR(_id_24815)->dbl);
        DeRefDS(_id_24815);
        _id_24815 = _1;
    }

    /** 	return length(data[id]) -- small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13576 = (int)*(((s1_ptr)_2)->base + _id_24815);
    if (IS_SEQUENCE(_13576)){
            _13577 = SEQ_PTR(_13576)->length;
    }
    else {
        _13577 = 1;
    }
    _13576 = NOVALUE;
    _13576 = NOVALUE;
    return _13577;
    ;
}


int  __stdcall _1eu_log(int _id_24820)
{
    int _retval_inlined_retval_at_16_24825 = NOVALUE;
    int _ob_inlined_retval_at_13_24824 = NOVALUE;
    int _13579 = NOVALUE;
    int _13578 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24820)) {
        _1 = (long)(DBL_PTR(_id_24820)->dbl);
        DeRefDS(_id_24820);
        _id_24820 = _1;
    }

    /** 	return retval(log(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13578 = (int)*(((s1_ptr)_2)->base + _id_24820);
    if (IS_ATOM_INT(_13578))
    _13579 = e_log(_13578);
    else
    _13579 = unary_op(LOG, _13578);
    _13578 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24824);
    _ob_inlined_retval_at_13_24824 = _13579;
    _13579 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24824);
    _0 = _retval_inlined_retval_at_16_24825;
    _retval_inlined_retval_at_16_24825 = _1register_data(_ob_inlined_retval_at_13_24824);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24824);
    _ob_inlined_retval_at_13_24824 = NOVALUE;
    return _retval_inlined_retval_at_16_24825;
    ;
}


int  __stdcall _1eu_machine_func(int _machine_id_24828, int _id1_24829)
{
    int _retval_inlined_retval_at_19_24834 = NOVALUE;
    int _ob_inlined_retval_at_16_24833 = NOVALUE;
    int _13581 = NOVALUE;
    int _13580 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_24828)) {
        _1 = (long)(DBL_PTR(_machine_id_24828)->dbl);
        DeRefDS(_machine_id_24828);
        _machine_id_24828 = _1;
    }
    if (!IS_ATOM_INT(_id1_24829)) {
        _1 = (long)(DBL_PTR(_id1_24829)->dbl);
        DeRefDS(_id1_24829);
        _id1_24829 = _1;
    }

    /** 	return retval(machine_func(machine_id, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13580 = (int)*(((s1_ptr)_2)->base + _id1_24829);
    _13581 = machine(_machine_id_24828, _13580);
    _13580 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24833);
    _ob_inlined_retval_at_16_24833 = _13581;
    _13581 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_24833);
    _0 = _retval_inlined_retval_at_19_24834;
    _retval_inlined_retval_at_19_24834 = _1register_data(_ob_inlined_retval_at_16_24833);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24833);
    _ob_inlined_retval_at_16_24833 = NOVALUE;
    return _retval_inlined_retval_at_19_24834;
    ;
}


void  __stdcall _1eu_machine_proc(int _machine_id_24837, int _id1_24838)
{
    int _13582 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_24837)) {
        _1 = (long)(DBL_PTR(_machine_id_24837)->dbl);
        DeRefDS(_machine_id_24837);
        _machine_id_24837 = _1;
    }
    if (!IS_ATOM_INT(_id1_24838)) {
        _1 = (long)(DBL_PTR(_id1_24838)->dbl);
        DeRefDS(_id1_24838);
        _id1_24838 = _1;
    }

    /** 	machine_proc(machine_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13582 = (int)*(((s1_ptr)_2)->base + _id1_24838);
    machine(_machine_id_24837, _13582);
    _13582 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_match_from(int _id1_24842, int _id2_24843, int _start_24844)
{
    int _13585 = NOVALUE;
    int _13584 = NOVALUE;
    int _13583 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24842)) {
        _1 = (long)(DBL_PTR(_id1_24842)->dbl);
        DeRefDS(_id1_24842);
        _id1_24842 = _1;
    }
    if (!IS_ATOM_INT(_id2_24843)) {
        _1 = (long)(DBL_PTR(_id2_24843)->dbl);
        DeRefDS(_id2_24843);
        _id2_24843 = _1;
    }
    if (!IS_ATOM_INT(_start_24844)) {
        _1 = (long)(DBL_PTR(_start_24844)->dbl);
        DeRefDS(_start_24844);
        _start_24844 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13583 = (int)*(((s1_ptr)_2)->base + _id1_24842);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13584 = (int)*(((s1_ptr)_2)->base + _id2_24843);
    _13585 = e_match_from(_13583, _13584, _start_24844);
    _13583 = NOVALUE;
    _13584 = NOVALUE;
    return _13585;
    ;
}


int  __stdcall _1eu_match(int _id1_24850, int _id2_24851, int _start_24852)
{
    int _13588 = NOVALUE;
    int _13587 = NOVALUE;
    int _13586 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24850)) {
        _1 = (long)(DBL_PTR(_id1_24850)->dbl);
        DeRefDS(_id1_24850);
        _id1_24850 = _1;
    }
    if (!IS_ATOM_INT(_id2_24851)) {
        _1 = (long)(DBL_PTR(_id2_24851)->dbl);
        DeRefDS(_id2_24851);
        _id2_24851 = _1;
    }
    if (!IS_ATOM_INT(_start_24852)) {
        _1 = (long)(DBL_PTR(_start_24852)->dbl);
        DeRefDS(_start_24852);
        _start_24852 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13586 = (int)*(((s1_ptr)_2)->base + _id1_24850);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13587 = (int)*(((s1_ptr)_2)->base + _id2_24851);
    _13588 = e_match_from(_13586, _13587, _start_24852);
    _13586 = NOVALUE;
    _13587 = NOVALUE;
    return _13588;
    ;
}


int  __stdcall _1eu_not_bits(int _id1_24858)
{
    int _retval_inlined_retval_at_16_24863 = NOVALUE;
    int _ob_inlined_retval_at_13_24862 = NOVALUE;
    int _13590 = NOVALUE;
    int _13589 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24858)) {
        _1 = (long)(DBL_PTR(_id1_24858)->dbl);
        DeRefDS(_id1_24858);
        _id1_24858 = _1;
    }

    /** 	return retval(not_bits(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13589 = (int)*(((s1_ptr)_2)->base + _id1_24858);
    if (IS_ATOM_INT(_13589))
    _13590 = not_bits(_13589);
    else
    _13590 = unary_op(NOT_BITS, _13589);
    _13589 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24862);
    _ob_inlined_retval_at_13_24862 = _13590;
    _13590 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24862);
    _0 = _retval_inlined_retval_at_16_24863;
    _retval_inlined_retval_at_16_24863 = _1register_data(_ob_inlined_retval_at_13_24862);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24862);
    _ob_inlined_retval_at_13_24862 = NOVALUE;
    return _retval_inlined_retval_at_16_24863;
    ;
}


int  __stdcall _1eu_object(int _id_24866)
{
    int _13592 = NOVALUE;
    int _13591 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24866)) {
        _1 = (long)(DBL_PTR(_id_24866)->dbl);
        DeRefDS(_id_24866);
        _id_24866 = _1;
    }

    /** 	return not find(id, free_list)*/
    _13591 = find_from(_id_24866, _1free_list_24314, 1);
    _13592 = (_13591 == 0);
    _13591 = NOVALUE;
    return _13592;
    ;
}


int  __stdcall _1eu_open(int _id1_24871, int _id2_24872)
{
    int _13595 = NOVALUE;
    int _13594 = NOVALUE;
    int _13593 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24871)) {
        _1 = (long)(DBL_PTR(_id1_24871)->dbl);
        DeRefDS(_id1_24871);
        _id1_24871 = _1;
    }
    if (!IS_ATOM_INT(_id2_24872)) {
        _1 = (long)(DBL_PTR(_id2_24872)->dbl);
        DeRefDS(_id2_24872);
        _id2_24872 = _1;
    }

    /** 	return open(data[id1], data[id2]) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13593 = (int)*(((s1_ptr)_2)->base + _id1_24871);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13594 = (int)*(((s1_ptr)_2)->base + _id2_24872);
    _13595 = EOpen(_13593, _13594, 0);
    _13593 = NOVALUE;
    _13594 = NOVALUE;
    return _13595;
    ;
}


int  __stdcall _1eu_open_str(int _low_24878, int _high_24879, int _did_24880)
{
    int _get_address_1__tmp_at8_24883 = NOVALUE;
    int _get_address_inlined_get_address_at_8_24882 = NOVALUE;
    int _13598 = NOVALUE;
    int _13597 = NOVALUE;
    int _13596 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24878)) {
        _1 = (long)(DBL_PTR(_low_24878)->dbl);
        DeRefDS(_low_24878);
        _low_24878 = _1;
    }
    if (!IS_ATOM_INT(_high_24879)) {
        _1 = (long)(DBL_PTR(_high_24879)->dbl);
        DeRefDS(_high_24879);
        _high_24879 = _1;
    }
    if (!IS_ATOM_INT(_did_24880)) {
        _1 = (long)(DBL_PTR(_did_24880)->dbl);
        DeRefDS(_did_24880);
        _did_24880 = _1;
    }

    /** 	return open(peek_string(get_address(low, high)), data[did])*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_24883);
    _get_address_1__tmp_at8_24883 = NewDouble(_high_24879 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_8_24882);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_24883)) {
        _get_address_inlined_get_address_at_8_24882 = _get_address_1__tmp_at8_24883 + _low_24878;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_8_24882 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_8_24882 = NewDouble((double)_get_address_inlined_get_address_at_8_24882);
    }
    else {
        _get_address_inlined_get_address_at_8_24882 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_24883)->dbl + (double)_low_24878);
    }
    DeRef(_get_address_1__tmp_at8_24883);
    _get_address_1__tmp_at8_24883 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_8_24882)) {
        _13596 =  NewString((char *)_get_address_inlined_get_address_at_8_24882);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_8_24882)) {
        _13596 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_8_24882)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_8_24882);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13596 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _2 = (int)SEQ_PTR(_1data_24313);
    _13597 = (int)*(((s1_ptr)_2)->base + _did_24880);
    _13598 = EOpen(_13596, _13597, 0);
    DeRef(_13596);
    _13596 = NOVALUE;
    _13597 = NOVALUE;
    return _13598;
    ;
}


int  __stdcall _1eu_or_bits(int _id1_24889, int _id2_24890)
{
    int _retval_inlined_retval_at_25_24896 = NOVALUE;
    int _ob_inlined_retval_at_22_24895 = NOVALUE;
    int _13601 = NOVALUE;
    int _13600 = NOVALUE;
    int _13599 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24889)) {
        _1 = (long)(DBL_PTR(_id1_24889)->dbl);
        DeRefDS(_id1_24889);
        _id1_24889 = _1;
    }
    if (!IS_ATOM_INT(_id2_24890)) {
        _1 = (long)(DBL_PTR(_id2_24890)->dbl);
        DeRefDS(_id2_24890);
        _id2_24890 = _1;
    }

    /** 	return retval(or_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13599 = (int)*(((s1_ptr)_2)->base + _id1_24889);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13600 = (int)*(((s1_ptr)_2)->base + _id2_24890);
    if (IS_ATOM_INT(_13599) && IS_ATOM_INT(_13600)) {
        {unsigned long tu;
             tu = (unsigned long)_13599 | (unsigned long)_13600;
             _13601 = MAKE_UINT(tu);
        }
    }
    else {
        _13601 = binary_op(OR_BITS, _13599, _13600);
    }
    _13599 = NOVALUE;
    _13600 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24895);
    _ob_inlined_retval_at_22_24895 = _13601;
    _13601 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24895);
    _0 = _retval_inlined_retval_at_25_24896;
    _retval_inlined_retval_at_25_24896 = _1register_data(_ob_inlined_retval_at_22_24895);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24895);
    _ob_inlined_retval_at_22_24895 = NOVALUE;
    return _retval_inlined_retval_at_25_24896;
    ;
}


int  __stdcall _1eu_peek(int _id1_24899)
{
    int _retval_inlined_retval_at_16_24904 = NOVALUE;
    int _ob_inlined_retval_at_13_24903 = NOVALUE;
    int _13603 = NOVALUE;
    int _13602 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24899)) {
        _1 = (long)(DBL_PTR(_id1_24899)->dbl);
        DeRefDS(_id1_24899);
        _id1_24899 = _1;
    }

    /** 	return retval(peek(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13602 = (int)*(((s1_ptr)_2)->base + _id1_24899);
    if (IS_ATOM_INT(_13602)) {
        _13603 = *(unsigned char *)_13602;
    }
    else if (IS_ATOM(_13602)) {
        _13603 = *(unsigned char *)(unsigned long)(DBL_PTR(_13602)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13602);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13603 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13602 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24903);
    _ob_inlined_retval_at_13_24903 = _13603;
    _13603 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24903);
    _0 = _retval_inlined_retval_at_16_24904;
    _retval_inlined_retval_at_16_24904 = _1register_data(_ob_inlined_retval_at_13_24903);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24903);
    _ob_inlined_retval_at_13_24903 = NOVALUE;
    return _retval_inlined_retval_at_16_24904;
    ;
}


int  __stdcall _1eu_peek4s(int _id1_24907)
{
    int _retval_inlined_retval_at_16_24912 = NOVALUE;
    int _ob_inlined_retval_at_13_24911 = NOVALUE;
    int _13605 = NOVALUE;
    int _13604 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24907)) {
        _1 = (long)(DBL_PTR(_id1_24907)->dbl);
        DeRefDS(_id1_24907);
        _id1_24907 = _1;
    }

    /** 	return retval(peek4s(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13604 = (int)*(((s1_ptr)_2)->base + _id1_24907);
    if (IS_ATOM_INT(_13604)) {
        _13605 = *(unsigned long *)_13604;
        if (_13605 < MININT || _13605 > MAXINT)
        _13605 = NewDouble((double)(long)_13605);
    }
    else if (IS_ATOM(_13604)) {
        _13605 = *(unsigned long *)(unsigned long)(DBL_PTR(_13604)->dbl);
        if (_13605 < MININT || _13605 > MAXINT)
        _13605 = NewDouble((double)(long)_13605);
    }
    else {
        _1 = (int)SEQ_PTR(_13604);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13605 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13604 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24911);
    _ob_inlined_retval_at_13_24911 = _13605;
    _13605 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24911);
    _0 = _retval_inlined_retval_at_16_24912;
    _retval_inlined_retval_at_16_24912 = _1register_data(_ob_inlined_retval_at_13_24911);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24911);
    _ob_inlined_retval_at_13_24911 = NOVALUE;
    return _retval_inlined_retval_at_16_24912;
    ;
}


int  __stdcall _1eu_peek4u(int _id1_24915)
{
    int _retval_inlined_retval_at_16_24920 = NOVALUE;
    int _ob_inlined_retval_at_13_24919 = NOVALUE;
    int _13607 = NOVALUE;
    int _13606 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24915)) {
        _1 = (long)(DBL_PTR(_id1_24915)->dbl);
        DeRefDS(_id1_24915);
        _id1_24915 = _1;
    }

    /** 	return retval(peek4u(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13606 = (int)*(((s1_ptr)_2)->base + _id1_24915);
    if (IS_ATOM_INT(_13606)) {
        _13607 = *(unsigned long *)_13606;
        if ((unsigned)_13607 > (unsigned)MAXINT)
        _13607 = NewDouble((double)(unsigned long)_13607);
    }
    else if (IS_ATOM(_13606)) {
        _13607 = *(unsigned long *)(unsigned long)(DBL_PTR(_13606)->dbl);
        if ((unsigned)_13607 > (unsigned)MAXINT)
        _13607 = NewDouble((double)(unsigned long)_13607);
    }
    else {
        _1 = (int)SEQ_PTR(_13606);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13607 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13606 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24919);
    _ob_inlined_retval_at_13_24919 = _13607;
    _13607 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24919);
    _0 = _retval_inlined_retval_at_16_24920;
    _retval_inlined_retval_at_16_24920 = _1register_data(_ob_inlined_retval_at_13_24919);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24919);
    _ob_inlined_retval_at_13_24919 = NOVALUE;
    return _retval_inlined_retval_at_16_24920;
    ;
}


int  __stdcall _1eu_platform()
{
    int _0, _1, _2;
    

    /** 	return platform() -- returns an integer*/
    return 2;
    ;
}


void  __stdcall _1eu_poke(int _id1_24925, int _id2_24926)
{
    int _13609 = NOVALUE;
    int _13608 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24925)) {
        _1 = (long)(DBL_PTR(_id1_24925)->dbl);
        DeRefDS(_id1_24925);
        _id1_24925 = _1;
    }
    if (!IS_ATOM_INT(_id2_24926)) {
        _1 = (long)(DBL_PTR(_id2_24926)->dbl);
        DeRefDS(_id2_24926);
        _id2_24926 = _1;
    }

    /** 	poke(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13608 = (int)*(((s1_ptr)_2)->base + _id1_24925);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13609 = (int)*(((s1_ptr)_2)->base + _id2_24926);
    if (IS_ATOM_INT(_13608)){
        poke_addr = (unsigned char *)_13608;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13608)->dbl);
    }
    if (IS_ATOM_INT(_13609)) {
        *poke_addr = (unsigned char)_13609;
    }
    else if (IS_ATOM(_13609)) {
        *poke_addr = (signed char)DBL_PTR(_13609)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13609);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13608 = NOVALUE;
    _13609 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_poke4(int _id1_24931, int _id2_24932)
{
    int _13611 = NOVALUE;
    int _13610 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24931)) {
        _1 = (long)(DBL_PTR(_id1_24931)->dbl);
        DeRefDS(_id1_24931);
        _id1_24931 = _1;
    }
    if (!IS_ATOM_INT(_id2_24932)) {
        _1 = (long)(DBL_PTR(_id2_24932)->dbl);
        DeRefDS(_id2_24932);
        _id2_24932 = _1;
    }

    /** 	poke4(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13610 = (int)*(((s1_ptr)_2)->base + _id1_24931);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13611 = (int)*(((s1_ptr)_2)->base + _id2_24932);
    if (IS_ATOM_INT(_13610)){
        poke4_addr = (unsigned long *)_13610;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13610)->dbl);
    }
    if (IS_ATOM_INT(_13611)) {
        *poke4_addr = (unsigned long)_13611;
    }
    else if (IS_ATOM(_13611)) {
        *poke4_addr = (unsigned long)DBL_PTR(_13611)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13611);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13610 = NOVALUE;
    _13611 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_position(int _row_24937, int _column_24938)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_row_24937)) {
        _1 = (long)(DBL_PTR(_row_24937)->dbl);
        DeRefDS(_row_24937);
        _row_24937 = _1;
    }
    if (!IS_ATOM_INT(_column_24938)) {
        _1 = (long)(DBL_PTR(_column_24938)->dbl);
        DeRefDS(_column_24938);
        _column_24938 = _1;
    }

    /** 	position(row, column)*/
    Position(_row_24937, _column_24938);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_power(int _id1_24941, int _id2_24942)
{
    int _retval_inlined_retval_at_25_24948 = NOVALUE;
    int _ob_inlined_retval_at_22_24947 = NOVALUE;
    int _13614 = NOVALUE;
    int _13613 = NOVALUE;
    int _13612 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24941)) {
        _1 = (long)(DBL_PTR(_id1_24941)->dbl);
        DeRefDS(_id1_24941);
        _id1_24941 = _1;
    }
    if (!IS_ATOM_INT(_id2_24942)) {
        _1 = (long)(DBL_PTR(_id2_24942)->dbl);
        DeRefDS(_id2_24942);
        _id2_24942 = _1;
    }

    /** 	return retval(power(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13612 = (int)*(((s1_ptr)_2)->base + _id1_24941);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13613 = (int)*(((s1_ptr)_2)->base + _id2_24942);
    if (IS_ATOM_INT(_13612) && IS_ATOM_INT(_13613)) {
        _13614 = power(_13612, _13613);
    }
    else {
        _13614 = binary_op(POWER, _13612, _13613);
    }
    _13612 = NOVALUE;
    _13613 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24947);
    _ob_inlined_retval_at_22_24947 = _13614;
    _13614 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24947);
    _0 = _retval_inlined_retval_at_25_24948;
    _retval_inlined_retval_at_25_24948 = _1register_data(_ob_inlined_retval_at_22_24947);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24947);
    _ob_inlined_retval_at_22_24947 = NOVALUE;
    return _retval_inlined_retval_at_25_24948;
    ;
}


int  __stdcall _1eu_prepend(int _id1_24951, int _id2_24952)
{
    int _retval_inlined_retval_at_25_24958 = NOVALUE;
    int _ob_inlined_retval_at_22_24957 = NOVALUE;
    int _13617 = NOVALUE;
    int _13616 = NOVALUE;
    int _13615 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24951)) {
        _1 = (long)(DBL_PTR(_id1_24951)->dbl);
        DeRefDS(_id1_24951);
        _id1_24951 = _1;
    }
    if (!IS_ATOM_INT(_id2_24952)) {
        _1 = (long)(DBL_PTR(_id2_24952)->dbl);
        DeRefDS(_id2_24952);
        _id2_24952 = _1;
    }

    /** 	return retval(prepend(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13615 = (int)*(((s1_ptr)_2)->base + _id1_24951);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13616 = (int)*(((s1_ptr)_2)->base + _id2_24952);
    Ref(_13616);
    Prepend(&_13617, _13615, _13616);
    _13615 = NOVALUE;
    _13616 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24957);
    _ob_inlined_retval_at_22_24957 = _13617;
    _13617 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24957);
    _0 = _retval_inlined_retval_at_25_24958;
    _retval_inlined_retval_at_25_24958 = _1register_data(_ob_inlined_retval_at_22_24957);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24957);
    _ob_inlined_retval_at_22_24957 = NOVALUE;
    return _retval_inlined_retval_at_25_24958;
    ;
}


void  __stdcall _1eu_print(int _fn_id_24961, int _id1_24962)
{
    int _13618 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24961)) {
        _1 = (long)(DBL_PTR(_fn_id_24961)->dbl);
        DeRefDS(_fn_id_24961);
        _fn_id_24961 = _1;
    }
    if (!IS_ATOM_INT(_id1_24962)) {
        _1 = (long)(DBL_PTR(_id1_24962)->dbl);
        DeRefDS(_id1_24962);
        _id1_24962 = _1;
    }

    /** 	print(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13618 = (int)*(((s1_ptr)_2)->base + _id1_24962);
    StdPrint(_fn_id_24961, _13618, 0);
    _13618 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_printf(int _fn_id_24966, int _id1_24967, int _id2_24968)
{
    int _13620 = NOVALUE;
    int _13619 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24966)) {
        _1 = (long)(DBL_PTR(_fn_id_24966)->dbl);
        DeRefDS(_fn_id_24966);
        _fn_id_24966 = _1;
    }
    if (!IS_ATOM_INT(_id1_24967)) {
        _1 = (long)(DBL_PTR(_id1_24967)->dbl);
        DeRefDS(_id1_24967);
        _id1_24967 = _1;
    }
    if (!IS_ATOM_INT(_id2_24968)) {
        _1 = (long)(DBL_PTR(_id2_24968)->dbl);
        DeRefDS(_id2_24968);
        _id2_24968 = _1;
    }

    /** 	printf(fn_id, data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13619 = (int)*(((s1_ptr)_2)->base + _id1_24967);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13620 = (int)*(((s1_ptr)_2)->base + _id2_24968);
    EPrintf(_fn_id_24966, _13619, _13620);
    _13619 = NOVALUE;
    _13620 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void  __stdcall _1eu_puts(int _fn_id_24973, int _id1_24974)
{
    int _13621 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24973)) {
        _1 = (long)(DBL_PTR(_fn_id_24973)->dbl);
        DeRefDS(_fn_id_24973);
        _fn_id_24973 = _1;
    }
    if (!IS_ATOM_INT(_id1_24974)) {
        _1 = (long)(DBL_PTR(_id1_24974)->dbl);
        DeRefDS(_id1_24974);
        _id1_24974 = _1;
    }

    /** 	puts(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13621 = (int)*(((s1_ptr)_2)->base + _id1_24974);
    EPuts(_fn_id_24973, _13621); // DJP 
    _13621 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_rand(int _id1_24978)
{
    int _retval_inlined_retval_at_16_24983 = NOVALUE;
    int _ob_inlined_retval_at_13_24982 = NOVALUE;
    int _13623 = NOVALUE;
    int _13622 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24978)) {
        _1 = (long)(DBL_PTR(_id1_24978)->dbl);
        DeRefDS(_id1_24978);
        _id1_24978 = _1;
    }

    /** 	return retval(rand(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13622 = (int)*(((s1_ptr)_2)->base + _id1_24978);
    if (IS_ATOM_INT(_13622)) {
        _13623 = good_rand() % ((unsigned)_13622) + 1;
    }
    else {
        _13623 = unary_op(RAND, _13622);
    }
    _13622 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24982);
    _ob_inlined_retval_at_13_24982 = _13623;
    _13623 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24982);
    _0 = _retval_inlined_retval_at_16_24983;
    _retval_inlined_retval_at_16_24983 = _1register_data(_ob_inlined_retval_at_13_24982);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24982);
    _ob_inlined_retval_at_13_24982 = NOVALUE;
    return _retval_inlined_retval_at_16_24983;
    ;
}


int  __stdcall _1eu_remainder(int _id1_24986, int _id2_24987)
{
    int _retval_inlined_retval_at_25_24993 = NOVALUE;
    int _ob_inlined_retval_at_22_24992 = NOVALUE;
    int _13626 = NOVALUE;
    int _13625 = NOVALUE;
    int _13624 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24986)) {
        _1 = (long)(DBL_PTR(_id1_24986)->dbl);
        DeRefDS(_id1_24986);
        _id1_24986 = _1;
    }
    if (!IS_ATOM_INT(_id2_24987)) {
        _1 = (long)(DBL_PTR(_id2_24987)->dbl);
        DeRefDS(_id2_24987);
        _id2_24987 = _1;
    }

    /** 	return retval(remainder(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13624 = (int)*(((s1_ptr)_2)->base + _id1_24986);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13625 = (int)*(((s1_ptr)_2)->base + _id2_24987);
    if (IS_ATOM_INT(_13624) && IS_ATOM_INT(_13625)) {
        _13626 = (_13624 % _13625);
    }
    else {
        _13626 = binary_op(REMAINDER, _13624, _13625);
    }
    _13624 = NOVALUE;
    _13625 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24992);
    _ob_inlined_retval_at_22_24992 = _13626;
    _13626 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24992);
    _0 = _retval_inlined_retval_at_25_24993;
    _retval_inlined_retval_at_25_24993 = _1register_data(_ob_inlined_retval_at_22_24992);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24992);
    _ob_inlined_retval_at_22_24992 = NOVALUE;
    return _retval_inlined_retval_at_25_24993;
    ;
}


int  __stdcall _1eu_sequence(int _id_24996)
{
    int _13628 = NOVALUE;
    int _13627 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24996)) {
        _1 = (long)(DBL_PTR(_id_24996)->dbl);
        DeRefDS(_id_24996);
        _id_24996 = _1;
    }

    /** 	return sequence(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13627 = (int)*(((s1_ptr)_2)->base + _id_24996);
    _13628 = IS_SEQUENCE(_13627);
    _13627 = NOVALUE;
    return _13628;
    ;
}


int  __stdcall _1eu_sin(int _id_25001)
{
    int _retval_inlined_retval_at_16_25006 = NOVALUE;
    int _ob_inlined_retval_at_13_25005 = NOVALUE;
    int _13630 = NOVALUE;
    int _13629 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_25001)) {
        _1 = (long)(DBL_PTR(_id_25001)->dbl);
        DeRefDS(_id_25001);
        _id_25001 = _1;
    }

    /** 	return retval(sin(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13629 = (int)*(((s1_ptr)_2)->base + _id_25001);
    if (IS_ATOM_INT(_13629))
    _13630 = e_sin(_13629);
    else
    _13630 = unary_op(SIN, _13629);
    _13629 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25005);
    _ob_inlined_retval_at_13_25005 = _13630;
    _13630 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25005);
    _0 = _retval_inlined_retval_at_16_25006;
    _retval_inlined_retval_at_16_25006 = _1register_data(_ob_inlined_retval_at_13_25005);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25005);
    _ob_inlined_retval_at_13_25005 = NOVALUE;
    return _retval_inlined_retval_at_16_25006;
    ;
}


int  __stdcall _1eu_sprintf(int _id1_25009, int _id2_25010)
{
    int _retval_inlined_retval_at_25_25016 = NOVALUE;
    int _ob_inlined_retval_at_22_25015 = NOVALUE;
    int _13633 = NOVALUE;
    int _13632 = NOVALUE;
    int _13631 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_25009)) {
        _1 = (long)(DBL_PTR(_id1_25009)->dbl);
        DeRefDS(_id1_25009);
        _id1_25009 = _1;
    }
    if (!IS_ATOM_INT(_id2_25010)) {
        _1 = (long)(DBL_PTR(_id2_25010)->dbl);
        DeRefDS(_id2_25010);
        _id2_25010 = _1;
    }

    /** 	return retval(sprintf(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13631 = (int)*(((s1_ptr)_2)->base + _id1_25009);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13632 = (int)*(((s1_ptr)_2)->base + _id2_25010);
    _13633 = EPrintf(-9999999, _13631, _13632);
    _13631 = NOVALUE;
    _13632 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_22_25015);
    _ob_inlined_retval_at_22_25015 = _13633;
    _13633 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_25015);
    _0 = _retval_inlined_retval_at_25_25016;
    _retval_inlined_retval_at_25_25016 = _1register_data(_ob_inlined_retval_at_22_25015);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_22_25015);
    _ob_inlined_retval_at_22_25015 = NOVALUE;
    return _retval_inlined_retval_at_25_25016;
    ;
}


int  __stdcall _1eu_sqrt(int _id_25019)
{
    int _retval_inlined_retval_at_16_25024 = NOVALUE;
    int _ob_inlined_retval_at_13_25023 = NOVALUE;
    int _13635 = NOVALUE;
    int _13634 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_25019)) {
        _1 = (long)(DBL_PTR(_id_25019)->dbl);
        DeRefDS(_id_25019);
        _id_25019 = _1;
    }

    /** 	return retval(sqrt(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13634 = (int)*(((s1_ptr)_2)->base + _id_25019);
    if (IS_ATOM_INT(_13634))
    _13635 = e_sqrt(_13634);
    else
    _13635 = unary_op(SQRT, _13634);
    _13634 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25023);
    _ob_inlined_retval_at_13_25023 = _13635;
    _13635 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25023);
    _0 = _retval_inlined_retval_at_16_25024;
    _retval_inlined_retval_at_16_25024 = _1register_data(_ob_inlined_retval_at_13_25023);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25023);
    _ob_inlined_retval_at_13_25023 = NOVALUE;
    return _retval_inlined_retval_at_16_25024;
    ;
}


int  __stdcall _1eu_subscript(int _id_25027, int _start_25028, int _stop_25029)
{
    int _retval_inlined_retval_at_22_25034 = NOVALUE;
    int _ob_inlined_retval_at_19_25033 = NOVALUE;
    int _13637 = NOVALUE;
    int _13636 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_25027)) {
        _1 = (long)(DBL_PTR(_id_25027)->dbl);
        DeRefDS(_id_25027);
        _id_25027 = _1;
    }
    if (!IS_ATOM_INT(_start_25028)) {
        _1 = (long)(DBL_PTR(_start_25028)->dbl);
        DeRefDS(_start_25028);
        _start_25028 = _1;
    }
    if (!IS_ATOM_INT(_stop_25029)) {
        _1 = (long)(DBL_PTR(_stop_25029)->dbl);
        DeRefDS(_stop_25029);
        _stop_25029 = _1;
    }

    /** 	return retval(data[id][start..stop])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13636 = (int)*(((s1_ptr)_2)->base + _id_25027);
    rhs_slice_target = (object_ptr)&_13637;
    RHS_Slice(_13636, _start_25028, _stop_25029);
    _13636 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_25033);
    _ob_inlined_retval_at_19_25033 = _13637;
    _13637 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_25033);
    _0 = _retval_inlined_retval_at_22_25034;
    _retval_inlined_retval_at_22_25034 = _1register_data(_ob_inlined_retval_at_19_25033);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_25033);
    _ob_inlined_retval_at_19_25033 = NOVALUE;
    return _retval_inlined_retval_at_22_25034;
    ;
}


void  __stdcall _1eu_system(int _id1_25037, int _mode_25038)
{
    int _13638 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_25037)) {
        _1 = (long)(DBL_PTR(_id1_25037)->dbl);
        DeRefDS(_id1_25037);
        _id1_25037 = _1;
    }
    if (!IS_ATOM_INT(_mode_25038)) {
        _1 = (long)(DBL_PTR(_mode_25038)->dbl);
        DeRefDS(_mode_25038);
        _mode_25038 = _1;
    }

    /** 	system(data[id1], mode)*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13638 = (int)*(((s1_ptr)_2)->base + _id1_25037);
    system_call(_13638, _mode_25038);
    _13638 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_system_exec(int _id1_25042, int _mode_25043)
{
    int _13640 = NOVALUE;
    int _13639 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_25042)) {
        _1 = (long)(DBL_PTR(_id1_25042)->dbl);
        DeRefDS(_id1_25042);
        _id1_25042 = _1;
    }
    if (!IS_ATOM_INT(_mode_25043)) {
        _1 = (long)(DBL_PTR(_mode_25043)->dbl);
        DeRefDS(_mode_25043);
        _mode_25043 = _1;
    }

    /** 	return system_exec(data[id1], mode) -- returns the exit code from the called process.*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13639 = (int)*(((s1_ptr)_2)->base + _id1_25042);
    _13640 = system_exec_call(_13639, _mode_25043);
    _13639 = NOVALUE;
    return _13640;
    ;
}


int  __stdcall _1eu_tan(int _id_25048)
{
    int _retval_inlined_retval_at_16_25053 = NOVALUE;
    int _ob_inlined_retval_at_13_25052 = NOVALUE;
    int _13642 = NOVALUE;
    int _13641 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_25048)) {
        _1 = (long)(DBL_PTR(_id_25048)->dbl);
        DeRefDS(_id_25048);
        _id_25048 = _1;
    }

    /** 	return retval(tan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13641 = (int)*(((s1_ptr)_2)->base + _id_25048);
    if (IS_ATOM_INT(_13641))
    _13642 = e_tan(_13641);
    else
    _13642 = unary_op(TAN, _13641);
    _13641 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25052);
    _ob_inlined_retval_at_13_25052 = _13642;
    _13642 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25052);
    _0 = _retval_inlined_retval_at_16_25053;
    _retval_inlined_retval_at_16_25053 = _1register_data(_ob_inlined_retval_at_13_25052);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25052);
    _ob_inlined_retval_at_13_25052 = NOVALUE;
    return _retval_inlined_retval_at_16_25053;
    ;
}


int  __stdcall _1eu_time()
{
    int _retval_inlined_retval_at_7_25059 = NOVALUE;
    int _ob_inlined_retval_at_4_25058 = NOVALUE;
    int _13643 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(time())*/
    _13643 = NewDouble(current_time());
    DeRef(_ob_inlined_retval_at_4_25058);
    _ob_inlined_retval_at_4_25058 = _13643;
    _13643 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_25058);
    _0 = _retval_inlined_retval_at_7_25059;
    _retval_inlined_retval_at_7_25059 = _1register_data(_ob_inlined_retval_at_4_25058);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_25058);
    _ob_inlined_retval_at_4_25058 = NOVALUE;
    return _retval_inlined_retval_at_7_25059;
    ;
}


int  __stdcall _1eu_xor_bits(int _id1_25062, int _id2_25063)
{
    int _retval_inlined_retval_at_25_25069 = NOVALUE;
    int _ob_inlined_retval_at_22_25068 = NOVALUE;
    int _13646 = NOVALUE;
    int _13645 = NOVALUE;
    int _13644 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_25062)) {
        _1 = (long)(DBL_PTR(_id1_25062)->dbl);
        DeRefDS(_id1_25062);
        _id1_25062 = _1;
    }
    if (!IS_ATOM_INT(_id2_25063)) {
        _1 = (long)(DBL_PTR(_id2_25063)->dbl);
        DeRefDS(_id2_25063);
        _id2_25063 = _1;
    }

    /** 	return retval(xor_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13644 = (int)*(((s1_ptr)_2)->base + _id1_25062);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13645 = (int)*(((s1_ptr)_2)->base + _id2_25063);
    if (IS_ATOM_INT(_13644) && IS_ATOM_INT(_13645)) {
        {unsigned long tu;
             tu = (unsigned long)_13644 ^ (unsigned long)_13645;
             _13646 = MAKE_UINT(tu);
        }
    }
    else {
        _13646 = binary_op(XOR_BITS, _13644, _13645);
    }
    _13644 = NOVALUE;
    _13645 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_25068);
    _ob_inlined_retval_at_22_25068 = _13646;
    _13646 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_25068);
    _0 = _retval_inlined_retval_at_25_25069;
    _retval_inlined_retval_at_25_25069 = _1register_data(_ob_inlined_retval_at_22_25068);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_25068);
    _ob_inlined_retval_at_22_25068 = NOVALUE;
    return _retval_inlined_retval_at_25_25069;
    ;
}


int  __stdcall _1eu_hash(int _did_25072, int _algorithm_25073)
{
    int _retval_inlined_retval_at_19_25078 = NOVALUE;
    int _ob_inlined_retval_at_16_25077 = NOVALUE;
    int _13648 = NOVALUE;
    int _13647 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25072)) {
        _1 = (long)(DBL_PTR(_did_25072)->dbl);
        DeRefDS(_did_25072);
        _did_25072 = _1;
    }
    if (!IS_ATOM_INT(_algorithm_25073)) {
        _1 = (long)(DBL_PTR(_algorithm_25073)->dbl);
        DeRefDS(_algorithm_25073);
        _algorithm_25073 = _1;
    }

    /** 	return retval(hash(data[did], algorithm))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13647 = (int)*(((s1_ptr)_2)->base + _did_25072);
    _13648 = calc_hash(_13647, _algorithm_25073);
    _13647 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_25077);
    _ob_inlined_retval_at_16_25077 = _13648;
    _13648 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_25077);
    _0 = _retval_inlined_retval_at_19_25078;
    _retval_inlined_retval_at_19_25078 = _1register_data(_ob_inlined_retval_at_16_25077);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_25077);
    _ob_inlined_retval_at_16_25077 = NOVALUE;
    return _retval_inlined_retval_at_19_25078;
    ;
}


int  __stdcall _1eu_head(int _did_25081, int _len_25082)
{
    int _retval_inlined_retval_at_19_25087 = NOVALUE;
    int _ob_inlined_retval_at_16_25086 = NOVALUE;
    int _13650 = NOVALUE;
    int _13649 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25081)) {
        _1 = (long)(DBL_PTR(_did_25081)->dbl);
        DeRefDS(_did_25081);
        _did_25081 = _1;
    }
    if (!IS_ATOM_INT(_len_25082)) {
        _1 = (long)(DBL_PTR(_len_25082)->dbl);
        DeRefDS(_len_25082);
        _len_25082 = _1;
    }

    /** 	return retval(head(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13649 = (int)*(((s1_ptr)_2)->base + _did_25081);
    {
        int len = SEQ_PTR(_13649)->length;
        int size = (IS_ATOM_INT(_len_25082)) ? _len_25082 : (long)(DBL_PTR(_len_25082)->dbl);
        if (size <= 0) _13650 = MAKE_SEQ(NewS1(0));
        else if (len <= size) {
            RefDS(_13649);
            DeRef(_13650);
            _13650 = _13649;
        }
        else Head(SEQ_PTR(_13649),size+1,&_13650);
    }
    _13649 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_25086);
    _ob_inlined_retval_at_16_25086 = _13650;
    _13650 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_25086);
    _0 = _retval_inlined_retval_at_19_25087;
    _retval_inlined_retval_at_19_25087 = _1register_data(_ob_inlined_retval_at_16_25086);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_25086);
    _ob_inlined_retval_at_16_25086 = NOVALUE;
    return _retval_inlined_retval_at_19_25087;
    ;
}


int  __stdcall _1eu_include_paths(int _convert_25090)
{
    int _retval_inlined_retval_at_13_25097 = NOVALUE;
    int _ob_inlined_retval_at_10_25096 = NOVALUE;
    int _13654 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_convert_25090)) {
        _1 = (long)(DBL_PTR(_convert_25090)->dbl);
        DeRefDS(_convert_25090);
        _convert_25090 = _1;
    }

    /** 	return retval(include_paths(convert))*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13653);
    *((int *)(_2+4)) = _13653;
    RefDS(_13652);
    *((int *)(_2+8)) = _13652;
    RefDS(_13651);
    *((int *)(_2+12)) = _13651;
    _13654 = MAKE_SEQ(_1);
    DeRef(_ob_inlined_retval_at_10_25096);
    _ob_inlined_retval_at_10_25096 = _13654;
    _13654 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_10_25096);
    _0 = _retval_inlined_retval_at_13_25097;
    _retval_inlined_retval_at_13_25097 = _1register_data(_ob_inlined_retval_at_10_25096);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_10_25096);
    _ob_inlined_retval_at_10_25096 = NOVALUE;
    return _retval_inlined_retval_at_13_25097;
    ;
}


int  __stdcall _1eu_insert(int _did1_25100, int _did2_25101, int _index_25102)
{
    int _retval_inlined_retval_at_28_25108 = NOVALUE;
    int _ob_inlined_retval_at_25_25107 = NOVALUE;
    int _13657 = NOVALUE;
    int _13656 = NOVALUE;
    int _13655 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_25100)) {
        _1 = (long)(DBL_PTR(_did1_25100)->dbl);
        DeRefDS(_did1_25100);
        _did1_25100 = _1;
    }
    if (!IS_ATOM_INT(_did2_25101)) {
        _1 = (long)(DBL_PTR(_did2_25101)->dbl);
        DeRefDS(_did2_25101);
        _did2_25101 = _1;
    }
    if (!IS_ATOM_INT(_index_25102)) {
        _1 = (long)(DBL_PTR(_index_25102)->dbl);
        DeRefDS(_index_25102);
        _index_25102 = _1;
    }

    /** 	return retval(insert(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13655 = (int)*(((s1_ptr)_2)->base + _did1_25100);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13656 = (int)*(((s1_ptr)_2)->base + _did2_25101);
    {
        s1_ptr assign_space;
        insert_pos = _index_25102;
        if (insert_pos <= 0){
            Prepend(&_13657,_13655,_13656);
        }
        else if (insert_pos > SEQ_PTR(_13655)->length) {
            Ref( _13656 );
            Append(&_13657,_13655,_13656);
        }
        else {
            Ref( _13656 );
            RefDS( _13655 );
            _13657 = Insert(_13655,_13656,insert_pos);
        }
    }
    _13655 = NOVALUE;
    _13656 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_25107);
    _ob_inlined_retval_at_25_25107 = _13657;
    _13657 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_25107);
    _0 = _retval_inlined_retval_at_28_25108;
    _retval_inlined_retval_at_28_25108 = _1register_data(_ob_inlined_retval_at_25_25107);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_25107);
    _ob_inlined_retval_at_25_25107 = NOVALUE;
    return _retval_inlined_retval_at_28_25108;
    ;
}


int  __stdcall _1eu_peek2s(int _did_25111)
{
    int _retval_inlined_retval_at_16_25116 = NOVALUE;
    int _ob_inlined_retval_at_13_25115 = NOVALUE;
    int _13659 = NOVALUE;
    int _13658 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25111)) {
        _1 = (long)(DBL_PTR(_did_25111)->dbl);
        DeRefDS(_did_25111);
        _did_25111 = _1;
    }

    /** 	return retval(peek2s(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13658 = (int)*(((s1_ptr)_2)->base + _did_25111);
    if (IS_ATOM_INT(_13658)) {
        _13659 = *(signed short *)_13658;
    }
    else if (IS_ATOM(_13658)) {
        _13659 = *(signed short *)(unsigned long)(DBL_PTR(_13658)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13658);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13659 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13658 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25115);
    _ob_inlined_retval_at_13_25115 = _13659;
    _13659 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25115);
    _0 = _retval_inlined_retval_at_16_25116;
    _retval_inlined_retval_at_16_25116 = _1register_data(_ob_inlined_retval_at_13_25115);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25115);
    _ob_inlined_retval_at_13_25115 = NOVALUE;
    return _retval_inlined_retval_at_16_25116;
    ;
}


int  __stdcall _1eu_peek2u(int _did_25119)
{
    int _retval_inlined_retval_at_16_25124 = NOVALUE;
    int _ob_inlined_retval_at_13_25123 = NOVALUE;
    int _13661 = NOVALUE;
    int _13660 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25119)) {
        _1 = (long)(DBL_PTR(_did_25119)->dbl);
        DeRefDS(_did_25119);
        _did_25119 = _1;
    }

    /** 	return retval(peek2u(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13660 = (int)*(((s1_ptr)_2)->base + _did_25119);
    if (IS_ATOM_INT(_13660)) {
        _13661 = *(unsigned short *)_13660;
    }
    else if (IS_ATOM(_13660)) {
        _13661 = *(unsigned short *)(unsigned long)(DBL_PTR(_13660)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13660);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13661 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13660 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25123);
    _ob_inlined_retval_at_13_25123 = _13661;
    _13661 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25123);
    _0 = _retval_inlined_retval_at_16_25124;
    _retval_inlined_retval_at_16_25124 = _1register_data(_ob_inlined_retval_at_13_25123);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25123);
    _ob_inlined_retval_at_13_25123 = NOVALUE;
    return _retval_inlined_retval_at_16_25124;
    ;
}


int  __stdcall _1eu_peek_string(int _did_25127)
{
    int _retval_inlined_retval_at_16_25132 = NOVALUE;
    int _ob_inlined_retval_at_13_25131 = NOVALUE;
    int _13663 = NOVALUE;
    int _13662 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25127)) {
        _1 = (long)(DBL_PTR(_did_25127)->dbl);
        DeRefDS(_did_25127);
        _did_25127 = _1;
    }

    /** 	return retval(peek_string(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13662 = (int)*(((s1_ptr)_2)->base + _did_25127);
    if (IS_ATOM_INT(_13662)) {
        _13663 =  NewString((char *)_13662);
    }
    else if (IS_ATOM(_13662)) {
        _13663 = NewString((char *)(unsigned long)(DBL_PTR(_13662)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_13662);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13663 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13662 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25131);
    _ob_inlined_retval_at_13_25131 = _13663;
    _13663 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25131);
    _0 = _retval_inlined_retval_at_16_25132;
    _retval_inlined_retval_at_16_25132 = _1register_data(_ob_inlined_retval_at_13_25131);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25131);
    _ob_inlined_retval_at_13_25131 = NOVALUE;
    return _retval_inlined_retval_at_16_25132;
    ;
}


int  __stdcall _1eu_peeks(int _did_25135)
{
    int _retval_inlined_retval_at_16_25140 = NOVALUE;
    int _ob_inlined_retval_at_13_25139 = NOVALUE;
    int _13665 = NOVALUE;
    int _13664 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25135)) {
        _1 = (long)(DBL_PTR(_did_25135)->dbl);
        DeRefDS(_did_25135);
        _did_25135 = _1;
    }

    /** 	return retval(peeks(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13664 = (int)*(((s1_ptr)_2)->base + _did_25135);
    if (IS_ATOM_INT(_13664)) {
        _13665 = *(signed char *)_13664;
    }
    else if (IS_ATOM(_13664)) {
        _13665 = *(signed char *)(unsigned long)(DBL_PTR(_13664)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13664);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13665 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(signed char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13664 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_25139);
    _ob_inlined_retval_at_13_25139 = _13665;
    _13665 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_25139);
    _0 = _retval_inlined_retval_at_16_25140;
    _retval_inlined_retval_at_16_25140 = _1register_data(_ob_inlined_retval_at_13_25139);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_25139);
    _ob_inlined_retval_at_13_25139 = NOVALUE;
    return _retval_inlined_retval_at_16_25140;
    ;
}


void  __stdcall _1eu_poke2(int _did1_25143, int _did2_25144)
{
    int _13667 = NOVALUE;
    int _13666 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_25143)) {
        _1 = (long)(DBL_PTR(_did1_25143)->dbl);
        DeRefDS(_did1_25143);
        _did1_25143 = _1;
    }
    if (!IS_ATOM_INT(_did2_25144)) {
        _1 = (long)(DBL_PTR(_did2_25144)->dbl);
        DeRefDS(_did2_25144);
        _did2_25144 = _1;
    }

    /** 	poke2(data[did1], data[did2])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13666 = (int)*(((s1_ptr)_2)->base + _did1_25143);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13667 = (int)*(((s1_ptr)_2)->base + _did2_25144);
    if (IS_ATOM_INT(_13666)){
        poke2_addr = (unsigned short *)_13666;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_13666)->dbl);
    }
    if (IS_ATOM_INT(_13667)) {
        *poke2_addr = (unsigned short)_13667;
    }
    else if (IS_ATOM(_13667)) {
        *poke_addr = (signed char)DBL_PTR(_13667)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13667);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke2_addr++ = (unsigned short)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13666 = NOVALUE;
    _13667 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_remove(int _did_25149, int _start_25150, int _stop_25151)
{
    int _retval_inlined_retval_at_22_25156 = NOVALUE;
    int _ob_inlined_retval_at_19_25155 = NOVALUE;
    int _13669 = NOVALUE;
    int _13668 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25149)) {
        _1 = (long)(DBL_PTR(_did_25149)->dbl);
        DeRefDS(_did_25149);
        _did_25149 = _1;
    }
    if (!IS_ATOM_INT(_start_25150)) {
        _1 = (long)(DBL_PTR(_start_25150)->dbl);
        DeRefDS(_start_25150);
        _start_25150 = _1;
    }
    if (!IS_ATOM_INT(_stop_25151)) {
        _1 = (long)(DBL_PTR(_stop_25151)->dbl);
        DeRefDS(_stop_25151);
        _stop_25151 = _1;
    }

    /** 	return retval(remove(data[did], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13668 = (int)*(((s1_ptr)_2)->base + _did_25149);
    {
        s1_ptr assign_space = SEQ_PTR(_13668);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_start_25150)) ? _start_25150 : (long)(DBL_PTR(_start_25150)->dbl);
        int stop = (IS_ATOM_INT(_stop_25151)) ? _stop_25151 : (long)(DBL_PTR(_stop_25151)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_13668);
            DeRef(_13669);
            _13669 = _13668;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_13668), start, &_13669 );
            }
            else Tail(SEQ_PTR(_13668), stop+1, &_13669);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_13668), start, &_13669);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_13669);
            _13669 = _1;
        }
    }
    _13668 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_25155);
    _ob_inlined_retval_at_19_25155 = _13669;
    _13669 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_25155);
    _0 = _retval_inlined_retval_at_22_25156;
    _retval_inlined_retval_at_22_25156 = _1register_data(_ob_inlined_retval_at_19_25155);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_25155);
    _ob_inlined_retval_at_19_25155 = NOVALUE;
    return _retval_inlined_retval_at_22_25156;
    ;
}


int  __stdcall _1eu_replace(int _did1_25159, int _did2_25160, int _start_25161, int _stop_25162)
{
    int _retval_inlined_retval_at_31_25168 = NOVALUE;
    int _ob_inlined_retval_at_28_25167 = NOVALUE;
    int _13672 = NOVALUE;
    int _13671 = NOVALUE;
    int _13670 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_25159)) {
        _1 = (long)(DBL_PTR(_did1_25159)->dbl);
        DeRefDS(_did1_25159);
        _did1_25159 = _1;
    }
    if (!IS_ATOM_INT(_did2_25160)) {
        _1 = (long)(DBL_PTR(_did2_25160)->dbl);
        DeRefDS(_did2_25160);
        _did2_25160 = _1;
    }
    if (!IS_ATOM_INT(_start_25161)) {
        _1 = (long)(DBL_PTR(_start_25161)->dbl);
        DeRefDS(_start_25161);
        _start_25161 = _1;
    }
    if (!IS_ATOM_INT(_stop_25162)) {
        _1 = (long)(DBL_PTR(_stop_25162)->dbl);
        DeRefDS(_stop_25162);
        _stop_25162 = _1;
    }

    /** 	return retval(replace(data[did1], data[did2], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13670 = (int)*(((s1_ptr)_2)->base + _did1_25159);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13671 = (int)*(((s1_ptr)_2)->base + _did2_25160);
    {
        int p1 = _13670;
        int p2 = _13671;
        int p3 = _start_25161;
        int p4 = _stop_25162;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_13672;
        Replace( &replace_params );
    }
    _13670 = NOVALUE;
    _13671 = NOVALUE;
    DeRef(_ob_inlined_retval_at_28_25167);
    _ob_inlined_retval_at_28_25167 = _13672;
    _13672 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_28_25167);
    _0 = _retval_inlined_retval_at_31_25168;
    _retval_inlined_retval_at_31_25168 = _1register_data(_ob_inlined_retval_at_28_25167);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_28_25167);
    _ob_inlined_retval_at_28_25167 = NOVALUE;
    return _retval_inlined_retval_at_31_25168;
    ;
}


int  __stdcall _1eu_splice(int _did1_25171, int _did2_25172, int _index_25173)
{
    int _retval_inlined_retval_at_28_25179 = NOVALUE;
    int _ob_inlined_retval_at_25_25178 = NOVALUE;
    int _13675 = NOVALUE;
    int _13674 = NOVALUE;
    int _13673 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_25171)) {
        _1 = (long)(DBL_PTR(_did1_25171)->dbl);
        DeRefDS(_did1_25171);
        _did1_25171 = _1;
    }
    if (!IS_ATOM_INT(_did2_25172)) {
        _1 = (long)(DBL_PTR(_did2_25172)->dbl);
        DeRefDS(_did2_25172);
        _did2_25172 = _1;
    }
    if (!IS_ATOM_INT(_index_25173)) {
        _1 = (long)(DBL_PTR(_index_25173)->dbl);
        DeRefDS(_index_25173);
        _index_25173 = _1;
    }

    /** 	return retval(splice(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13673 = (int)*(((s1_ptr)_2)->base + _did1_25171);
    _2 = (int)SEQ_PTR(_1data_24313);
    _13674 = (int)*(((s1_ptr)_2)->base + _did2_25172);
    {
        s1_ptr assign_space;
        insert_pos = _index_25173;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_13674)) {
                Concat(&_13675,_13674,_13673);
            }
            else{
                Prepend(&_13675,_13673,_13674);
            }
        }
        else if (insert_pos > SEQ_PTR(_13673)->length){
            if (IS_SEQUENCE(_13674)) {
                Concat(&_13675,_13673,_13674);
            }
            else{
                Append(&_13675,_13673,_13674);
            }
        }
        else if (IS_SEQUENCE(_13674)) {
            if( _13675 != _13673 || SEQ_PTR( _13673 )->ref != 1 ){
                DeRef( _13675 );
                RefDS( _13673 );
            }
            assign_space = Add_internal_space( _13673, insert_pos,((s1_ptr)SEQ_PTR(_13674))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_13674), _13673 == _13675 );
            _13675 = MAKE_SEQ( assign_space );
        }
        else {
            if( _13675 != _13673 && SEQ_PTR( _13673 )->ref != 1 ){
                _13675 = Insert( _13673, _13674, insert_pos);
            }
            else {
                DeRef( _13675 );
                RefDS( _13673 );
                _13675 = Insert( _13673, _13674, insert_pos);
            }
        }
    }
    _13673 = NOVALUE;
    _13674 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_25178);
    _ob_inlined_retval_at_25_25178 = _13675;
    _13675 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_25178);
    _0 = _retval_inlined_retval_at_28_25179;
    _retval_inlined_retval_at_28_25179 = _1register_data(_ob_inlined_retval_at_25_25178);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_25178);
    _ob_inlined_retval_at_25_25178 = NOVALUE;
    return _retval_inlined_retval_at_28_25179;
    ;
}


int  __stdcall _1eu_tail(int _did_25182, int _len_25183)
{
    int _retval_inlined_retval_at_19_25188 = NOVALUE;
    int _ob_inlined_retval_at_16_25187 = NOVALUE;
    int _13677 = NOVALUE;
    int _13676 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25182)) {
        _1 = (long)(DBL_PTR(_did_25182)->dbl);
        DeRefDS(_did_25182);
        _did_25182 = _1;
    }
    if (!IS_ATOM_INT(_len_25183)) {
        _1 = (long)(DBL_PTR(_len_25183)->dbl);
        DeRefDS(_len_25183);
        _len_25183 = _1;
    }

    /** 	return retval(tail(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13676 = (int)*(((s1_ptr)_2)->base + _did_25182);
    {
        int len = SEQ_PTR(_13676)->length;
        int size = (IS_ATOM_INT(_len_25183)) ? _len_25183 : (long)(DBL_PTR(_len_25183)->dbl);
        if (size <= 0) {
            DeRef(_13677);
            _13677 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_13676);
            DeRef(_13677);
            _13677 = _13676;
        }
        else Tail(SEQ_PTR(_13676), len-size+1, &_13677);
    }
    _13676 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_25187);
    _ob_inlined_retval_at_16_25187 = _13677;
    _13677 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_25187);
    _0 = _retval_inlined_retval_at_19_25188;
    _retval_inlined_retval_at_19_25188 = _1register_data(_ob_inlined_retval_at_16_25187);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_25187);
    _ob_inlined_retval_at_16_25187 = NOVALUE;
    return _retval_inlined_retval_at_19_25188;
    ;
}


int  __stdcall _1eu_call_func_std(int _rid_25191, int _did_25192)
{
    int _retval_inlined_retval_at_19_25197 = NOVALUE;
    int _ob_inlined_retval_at_16_25196 = NOVALUE;
    int _13679 = NOVALUE;
    int _13678 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_25191)) {
        _1 = (long)(DBL_PTR(_rid_25191)->dbl);
        DeRefDS(_rid_25191);
        _rid_25191 = _1;
    }
    if (!IS_ATOM_INT(_did_25192)) {
        _1 = (long)(DBL_PTR(_did_25192)->dbl);
        DeRefDS(_did_25192);
        _did_25192 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13678 = (int)*(((s1_ptr)_2)->base + _did_25192);
    _1 = (int)SEQ_PTR(_13678);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_25191].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_rid_25191].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }
    _13679 = _1;
    _13678 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_25196);
    _ob_inlined_retval_at_16_25196 = _13679;
    _13679 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_25196);
    _0 = _retval_inlined_retval_at_19_25197;
    _retval_inlined_retval_at_19_25197 = _1register_data(_ob_inlined_retval_at_16_25196);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_25196);
    _ob_inlined_retval_at_16_25196 = NOVALUE;
    return _retval_inlined_retval_at_19_25197;
    ;
}


int  __stdcall _1eu_call_func_val(int _rid_25200, int _did_25201)
{
    int _retval_inlined_retval_at_19_25206 = NOVALUE;
    int _ob_inlined_retval_at_16_25205 = NOVALUE;
    int _13681 = NOVALUE;
    int _13680 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_25200)) {
        _1 = (long)(DBL_PTR(_rid_25200)->dbl);
        DeRefDS(_rid_25200);
        _rid_25200 = _1;
    }
    if (!IS_ATOM_INT(_did_25201)) {
        _1 = (long)(DBL_PTR(_did_25201)->dbl);
        DeRefDS(_did_25201);
        _did_25201 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13680 = (int)*(((s1_ptr)_2)->base + _did_25201);
    _1 = (int)SEQ_PTR(_13680);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_25200].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_rid_25200].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }
    _13681 = _1;
    _13680 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_25205);
    _ob_inlined_retval_at_16_25205 = _13681;
    _13681 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_25205);
    _0 = _retval_inlined_retval_at_19_25206;
    _retval_inlined_retval_at_19_25206 = _1register_data(_ob_inlined_retval_at_16_25205);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_25205);
    _ob_inlined_retval_at_16_25205 = NOVALUE;
    return _retval_inlined_retval_at_19_25206;
    ;
}


int  __stdcall _1eu_call_func(int _rid_25209, int _did_25210)
{
    int _i_25211 = NOVALUE;
    int _13682 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_25209)) {
        _1 = (long)(DBL_PTR(_rid_25209)->dbl);
        DeRefDS(_rid_25209);
        _rid_25209 = _1;
    }
    if (!IS_ATOM_INT(_did_25210)) {
        _1 = (long)(DBL_PTR(_did_25210)->dbl);
        DeRefDS(_did_25210);
        _did_25210 = _1;
    }

    /** 	i = call_func(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13682 = (int)*(((s1_ptr)_2)->base + _did_25210);
    _1 = (int)SEQ_PTR(_13682);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_25209].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_rid_25209].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }
    _i_25211 = _1;
    _13682 = NOVALUE;
    if (!IS_ATOM_INT(_i_25211)) {
        _1 = (long)(DBL_PTR(_i_25211)->dbl);
        DeRefDS(_i_25211);
        _i_25211 = _1;
    }

    /** 	return i*/
    return _i_25211;
    ;
}


void  __stdcall _1eu_call_proc(int _rid_25216, int _did_25217)
{
    int _13684 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_25216)) {
        _1 = (long)(DBL_PTR(_rid_25216)->dbl);
        DeRefDS(_rid_25216);
        _rid_25216 = _1;
    }
    if (!IS_ATOM_INT(_did_25217)) {
        _1 = (long)(DBL_PTR(_did_25217)->dbl);
        DeRefDS(_did_25217);
        _did_25217 = _1;
    }

    /** 	call_proc(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13684 = (int)*(((s1_ptr)_2)->base + _did_25217);
    _1 = (int)SEQ_PTR(_13684);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_25216].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_rid_25216].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }
    _13684 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _1eu_routine_id(int _did_25221)
{
    int _13686 = NOVALUE;
    int _13685 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_25221)) {
        _1 = (long)(DBL_PTR(_did_25221)->dbl);
        DeRefDS(_did_25221);
        _did_25221 = _1;
    }

    /** 	return routine_id(data[did]) -- this is the only time it uses a string*/
    _2 = (int)SEQ_PTR(_1data_24313);
    _13685 = (int)*(((s1_ptr)_2)->base + _did_25221);
    _13686 = CRoutineId(964, 1, _13685);
    _13685 = NOVALUE;
    return _13686;
    ;
}


int  __stdcall _1eu_routine_id_str(int _low_25226, int _high_25227)
{
    int _get_address_1__tmp_at6_25230 = NOVALUE;
    int _get_address_inlined_get_address_at_6_25229 = NOVALUE;
    int _13688 = NOVALUE;
    int _13687 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_25226)) {
        _1 = (long)(DBL_PTR(_low_25226)->dbl);
        DeRefDS(_low_25226);
        _low_25226 = _1;
    }
    if (!IS_ATOM_INT(_high_25227)) {
        _1 = (long)(DBL_PTR(_high_25227)->dbl);
        DeRefDS(_high_25227);
        _high_25227 = _1;
    }

    /** 	return routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_25230);
    _get_address_1__tmp_at6_25230 = NewDouble(_high_25227 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_25229);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_25230)) {
        _get_address_inlined_get_address_at_6_25229 = _get_address_1__tmp_at6_25230 + _low_25226;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_25229 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_25229 = NewDouble((double)_get_address_inlined_get_address_at_6_25229);
    }
    else {
        _get_address_inlined_get_address_at_6_25229 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_25230)->dbl + (double)_low_25226);
    }
    DeRef(_get_address_1__tmp_at6_25230);
    _get_address_1__tmp_at6_25230 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_25229)) {
        _13687 =  NewString((char *)_get_address_inlined_get_address_at_6_25229);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_6_25229)) {
        _13687 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_25229)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_6_25229);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13687 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13688 = CRoutineId(965, 1, _13687);
    DeRef(_13687);
    _13687 = NOVALUE;
    return _13688;
    ;
}



// 0xCCE28D23
