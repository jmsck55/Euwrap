// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _12time()
{
    int _ptra_3417 = NOVALUE;
    int _valhi_3418 = NOVALUE;
    int _vallow_3419 = NOVALUE;
    int _deltahi_3420 = NOVALUE;
    int _deltalow_3421 = NOVALUE;
    int _1687 = NOVALUE;
    int _1685 = NOVALUE;
    int _1684 = NOVALUE;
    int _1683 = NOVALUE;
    int _1680 = NOVALUE;
    int _1675 = NOVALUE;
    int _1673 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		atom ptra, valhi, vallow, deltahi, deltalow*/

    /** 		deltahi = 27111902*/
    _deltahi_3420 = 27111902;

    /** 		deltalow = 3577643008*/
    RefDS(_1671);
    DeRef(_deltalow_3421);
    _deltalow_3421 = _1671;

    /** 		ptra = machine:allocate(8)*/
    _0 = _ptra_3417;
    _ptra_3417 = _14allocate(8, 0);
    DeRef(_0);

    /** 		c_proc(time_, {ptra})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ptra_3417);
    *((int *)(_2+4)) = _ptra_3417;
    _1673 = MAKE_SEQ(_1);
    call_c(0, _12time__3404, _1673);
    DeRefDS(_1673);
    _1673 = NOVALUE;

    /** 		vallow = peek4u(ptra)*/
    DeRef(_vallow_3419);
    if (IS_ATOM_INT(_ptra_3417)) {
        _vallow_3419 = *(unsigned long *)_ptra_3417;
        if ((unsigned)_vallow_3419 > (unsigned)MAXINT)
        _vallow_3419 = NewDouble((double)(unsigned long)_vallow_3419);
    }
    else {
        _vallow_3419 = *(unsigned long *)(unsigned long)(DBL_PTR(_ptra_3417)->dbl);
        if ((unsigned)_vallow_3419 > (unsigned)MAXINT)
        _vallow_3419 = NewDouble((double)(unsigned long)_vallow_3419);
    }

    /** 		valhi = peek4u(ptra+4)*/
    if (IS_ATOM_INT(_ptra_3417)) {
        _1675 = _ptra_3417 + 4;
        if ((long)((unsigned long)_1675 + (unsigned long)HIGH_BITS) >= 0) 
        _1675 = NewDouble((double)_1675);
    }
    else {
        _1675 = NewDouble(DBL_PTR(_ptra_3417)->dbl + (double)4);
    }
    DeRef(_valhi_3418);
    if (IS_ATOM_INT(_1675)) {
        _valhi_3418 = *(unsigned long *)_1675;
        if ((unsigned)_valhi_3418 > (unsigned)MAXINT)
        _valhi_3418 = NewDouble((double)(unsigned long)_valhi_3418);
    }
    else {
        _valhi_3418 = *(unsigned long *)(unsigned long)(DBL_PTR(_1675)->dbl);
        if ((unsigned)_valhi_3418 > (unsigned)MAXINT)
        _valhi_3418 = NewDouble((double)(unsigned long)_valhi_3418);
    }
    DeRef(_1675);
    _1675 = NOVALUE;

    /** 		machine:free(ptra)*/
    Ref(_ptra_3417);
    _14free(_ptra_3417);

    /** 		vallow -= deltalow*/
    _0 = _vallow_3419;
    if (IS_ATOM_INT(_vallow_3419)) {
        _vallow_3419 = NewDouble((double)_vallow_3419 - DBL_PTR(_deltalow_3421)->dbl);
    }
    else {
        _vallow_3419 = NewDouble(DBL_PTR(_vallow_3419)->dbl - DBL_PTR(_deltalow_3421)->dbl);
    }
    DeRef(_0);

    /** 		valhi -= deltahi*/
    _0 = _valhi_3418;
    if (IS_ATOM_INT(_valhi_3418)) {
        _valhi_3418 = _valhi_3418 - 27111902;
        if ((long)((unsigned long)_valhi_3418 +(unsigned long) HIGH_BITS) >= 0){
            _valhi_3418 = NewDouble((double)_valhi_3418);
        }
    }
    else {
        _valhi_3418 = NewDouble(DBL_PTR(_valhi_3418)->dbl - (double)27111902);
    }
    DeRef(_0);

    /** 		if vallow < 0 then*/
    if (binary_op_a(GREATEREQ, _vallow_3419, 0)){
        goto L1; // [67] 88
    }

    /** 			vallow += power(2, 32)*/
    _1680 = power(2, 32);
    _0 = _vallow_3419;
    if (IS_ATOM_INT(_1680)) {
        _vallow_3419 = NewDouble(DBL_PTR(_vallow_3419)->dbl + (double)_1680);
    }
    else
    _vallow_3419 = NewDouble(DBL_PTR(_vallow_3419)->dbl + DBL_PTR(_1680)->dbl);
    DeRefDS(_0);
    DeRef(_1680);
    _1680 = NOVALUE;

    /** 			valhi -= 1*/
    _0 = _valhi_3418;
    if (IS_ATOM_INT(_valhi_3418)) {
        _valhi_3418 = _valhi_3418 - 1;
        if ((long)((unsigned long)_valhi_3418 +(unsigned long) HIGH_BITS) >= 0){
            _valhi_3418 = NewDouble((double)_valhi_3418);
        }
    }
    else {
        _valhi_3418 = NewDouble(DBL_PTR(_valhi_3418)->dbl - (double)1);
    }
    DeRef(_0);
L1: 

    /** 		return floor(((valhi * power(2,32)) + vallow) / 10000000)*/
    _1683 = power(2, 32);
    if (IS_ATOM_INT(_valhi_3418) && IS_ATOM_INT(_1683)) {
        if (_valhi_3418 == (short)_valhi_3418 && _1683 <= INT15 && _1683 >= -INT15)
        _1684 = _valhi_3418 * _1683;
        else
        _1684 = NewDouble(_valhi_3418 * (double)_1683);
    }
    else {
        if (IS_ATOM_INT(_valhi_3418)) {
            _1684 = NewDouble((double)_valhi_3418 * DBL_PTR(_1683)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1683)) {
                _1684 = NewDouble(DBL_PTR(_valhi_3418)->dbl * (double)_1683);
            }
            else
            _1684 = NewDouble(DBL_PTR(_valhi_3418)->dbl * DBL_PTR(_1683)->dbl);
        }
    }
    DeRef(_1683);
    _1683 = NOVALUE;
    if (IS_ATOM_INT(_1684) && IS_ATOM_INT(_vallow_3419)) {
        _1685 = _1684 + _vallow_3419;
        if ((long)((unsigned long)_1685 + (unsigned long)HIGH_BITS) >= 0) 
        _1685 = NewDouble((double)_1685);
    }
    else {
        if (IS_ATOM_INT(_1684)) {
            _1685 = NewDouble((double)_1684 + DBL_PTR(_vallow_3419)->dbl);
        }
        else {
            if (IS_ATOM_INT(_vallow_3419)) {
                _1685 = NewDouble(DBL_PTR(_1684)->dbl + (double)_vallow_3419);
            }
            else
            _1685 = NewDouble(DBL_PTR(_1684)->dbl + DBL_PTR(_vallow_3419)->dbl);
        }
    }
    DeRef(_1684);
    _1684 = NOVALUE;
    if (IS_ATOM_INT(_1685)) {
        if (10000000 > 0 && _1685 >= 0) {
            _1687 = _1685 / 10000000;
        }
        else {
            temp_dbl = floor((double)_1685 / (double)10000000);
            if (_1685 != MININT)
            _1687 = (long)temp_dbl;
            else
            _1687 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _1685, 10000000);
        _1687 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_1685);
    _1685 = NOVALUE;
    DeRef(_ptra_3417);
    DeRef(_valhi_3418);
    DeRef(_vallow_3419);
    DeRef(_deltalow_3421);
    return _1687;
    ;
}


int _12gmtime(int _time_3443)
{
    int _ret_3444 = NOVALUE;
    int _timep_3445 = NOVALUE;
    int _tm_p_3446 = NOVALUE;
    int _n_3447 = NOVALUE;
    int _1693 = NOVALUE;
    int _1692 = NOVALUE;
    int _1689 = NOVALUE;
    int _0, _1, _2;
    

    /** 	timep = machine:allocate(4)*/
    _0 = _timep_3445;
    _timep_3445 = _14allocate(4, 0);
    DeRef(_0);

    /** 	poke4(timep, time)*/
    if (IS_ATOM_INT(_timep_3445)){
        poke4_addr = (unsigned long *)_timep_3445;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_timep_3445)->dbl);
    }
    if (IS_ATOM_INT(_time_3443)) {
        *poke4_addr = (unsigned long)_time_3443;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_time_3443)->dbl;
    }

    /** 	tm_p = c_func(gmtime_, {timep})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_timep_3445);
    *((int *)(_2+4)) = _timep_3445;
    _1689 = MAKE_SEQ(_1);
    DeRef(_tm_p_3446);
    _tm_p_3446 = call_c(1, _12gmtime__3399, _1689);
    DeRefDS(_1689);
    _1689 = NOVALUE;

    /** 	machine:free(timep)*/
    Ref(_timep_3445);
    _14free(_timep_3445);

    /** 	ret = repeat(0, 9)*/
    DeRef(_ret_3444);
    _ret_3444 = Repeat(0, 9);

    /** 	n = 0*/
    _n_3447 = 0;

    /** 	for i = 1 to 9 do*/
    {
        int _i_3453;
        _i_3453 = 1;
L1: 
        if (_i_3453 > 9){
            goto L2; // [44] 77
        }

        /** 		ret[i] = peek4s(tm_p+n)*/
        if (IS_ATOM_INT(_tm_p_3446)) {
            _1692 = _tm_p_3446 + _n_3447;
            if ((long)((unsigned long)_1692 + (unsigned long)HIGH_BITS) >= 0) 
            _1692 = NewDouble((double)_1692);
        }
        else {
            _1692 = NewDouble(DBL_PTR(_tm_p_3446)->dbl + (double)_n_3447);
        }
        if (IS_ATOM_INT(_1692)) {
            _1693 = *(unsigned long *)_1692;
            if (_1693 < MININT || _1693 > MAXINT)
            _1693 = NewDouble((double)(long)_1693);
        }
        else {
            _1693 = *(unsigned long *)(unsigned long)(DBL_PTR(_1692)->dbl);
            if (_1693 < MININT || _1693 > MAXINT)
            _1693 = NewDouble((double)(long)_1693);
        }
        DeRef(_1692);
        _1692 = NOVALUE;
        _2 = (int)SEQ_PTR(_ret_3444);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_3444 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3453);
        _1 = *(int *)_2;
        *(int *)_2 = _1693;
        if( _1 != _1693 ){
            DeRef(_1);
        }
        _1693 = NOVALUE;

        /** 		n = n + 4*/
        _n_3447 = _n_3447 + 4;

        /** 	end for*/
        _i_3453 = _i_3453 + 1;
        goto L1; // [72] 51
L2: 
        ;
    }

    /** 	return ret*/
    DeRef(_time_3443);
    DeRef(_timep_3445);
    DeRef(_tm_p_3446);
    return _ret_3444;
    ;
}


int _12tolower(int _x_3470)
{
    int _1706 = NOVALUE;
    int _1705 = NOVALUE;
    int _1704 = NOVALUE;
    int _1703 = NOVALUE;
    int _1702 = NOVALUE;
    int _1701 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return x + (x >= 'A' and x <= 'Z') * ('a' - 'A')*/
    _1701 = binary_op(GREATEREQ, _x_3470, 65);
    _1702 = binary_op(LESSEQ, _x_3470, 90);
    _1703 = binary_op(AND, _1701, _1702);
    DeRefDS(_1701);
    _1701 = NOVALUE;
    DeRefDS(_1702);
    _1702 = NOVALUE;
    _1704 = 32;
    _1705 = binary_op(MULTIPLY, _1703, 32);
    DeRefDS(_1703);
    _1703 = NOVALUE;
    _1704 = NOVALUE;
    _1706 = binary_op(PLUS, _x_3470, _1705);
    DeRefDS(_1705);
    _1705 = NOVALUE;
    DeRefDS(_x_3470);
    return _1706;
    ;
}


int _12isLeap(int _year_3479)
{
    int _ly_3480 = NOVALUE;
    int _1724 = NOVALUE;
    int _1723 = NOVALUE;
    int _1722 = NOVALUE;
    int _1721 = NOVALUE;
    int _1720 = NOVALUE;
    int _1719 = NOVALUE;
    int _1718 = NOVALUE;
    int _1717 = NOVALUE;
    int _1716 = NOVALUE;
    int _1713 = NOVALUE;
    int _1711 = NOVALUE;
    int _1710 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3479)) {
        _1 = (long)(DBL_PTR(_year_3479)->dbl);
        DeRefDS(_year_3479);
        _year_3479 = _1;
    }

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _1710 = MAKE_SEQ(_1);
    _1711 = binary_op(REMAINDER, _year_3479, _1710);
    DeRefDS(_1710);
    _1710 = NOVALUE;
    DeRefi(_ly_3480);
    _ly_3480 = binary_op(EQUALS, _1711, 0);
    DeRefDS(_1711);
    _1711 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_3480);
    _1713 = (int)*(((s1_ptr)_2)->base + 1);
    if (_1713 != 0)
    goto L1; // [29] 37
    _1713 = NOVALUE;
    DeRefDSi(_ly_3480);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_3479 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_3480);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_3480);
    _1716 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_3480);
    _1717 = (int)*(((s1_ptr)_2)->base + 2);
    _1718 = _1716 - _1717;
    if ((long)((unsigned long)_1718 +(unsigned long) HIGH_BITS) >= 0){
        _1718 = NewDouble((double)_1718);
    }
    _1716 = NOVALUE;
    _1717 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3480);
    _1719 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1718)) {
        _1720 = _1718 + _1719;
        if ((long)((unsigned long)_1720 + (unsigned long)HIGH_BITS) >= 0) 
        _1720 = NewDouble((double)_1720);
    }
    else {
        _1720 = NewDouble(DBL_PTR(_1718)->dbl + (double)_1719);
    }
    DeRef(_1718);
    _1718 = NOVALUE;
    _1719 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3480);
    _1721 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1720)) {
        _1722 = _1720 - _1721;
        if ((long)((unsigned long)_1722 +(unsigned long) HIGH_BITS) >= 0){
            _1722 = NewDouble((double)_1722);
        }
    }
    else {
        _1722 = NewDouble(DBL_PTR(_1720)->dbl - (double)_1721);
    }
    DeRef(_1720);
    _1720 = NOVALUE;
    _1721 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3480);
    _1723 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1722)) {
        _1724 = _1722 + _1723;
        if ((long)((unsigned long)_1724 + (unsigned long)HIGH_BITS) >= 0) 
        _1724 = NewDouble((double)_1724);
    }
    else {
        _1724 = NewDouble(DBL_PTR(_1722)->dbl + (double)_1723);
    }
    DeRef(_1722);
    _1722 = NOVALUE;
    _1723 = NOVALUE;
    DeRefDSi(_ly_3480);
    return _1724;
L3: 
    ;
}


int _12daysInMonth(int _year_3504, int _month_3505)
{
    int _1732 = NOVALUE;
    int _1731 = NOVALUE;
    int _1730 = NOVALUE;
    int _1729 = NOVALUE;
    int _1727 = NOVALUE;
    int _1726 = NOVALUE;
    int _1725 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3504)) {
        _1 = (long)(DBL_PTR(_year_3504)->dbl);
        DeRefDS(_year_3504);
        _year_3504 = _1;
    }
    if (!IS_ATOM_INT(_month_3505)) {
        _1 = (long)(DBL_PTR(_month_3505)->dbl);
        DeRefDS(_month_3505);
        _month_3505 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1725 = (_year_3504 == 1752);
    if (_1725 == 0) {
        goto L1; // [11] 32
    }
    _1727 = (_month_3505 == 9);
    if (_1727 == 0)
    {
        DeRef(_1727);
        _1727 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1727);
        _1727 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_1725);
    _1725 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_3505 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_12DaysPerMonth_3461);
    _1729 = (int)*(((s1_ptr)_2)->base + _month_3505);
    Ref(_1729);
    DeRef(_1725);
    _1725 = NOVALUE;
    return _1729;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_12DaysPerMonth_3461);
    _1730 = (int)*(((s1_ptr)_2)->base + _month_3505);
    _1731 = _12isLeap(_year_3504);
    if (IS_ATOM_INT(_1730) && IS_ATOM_INT(_1731)) {
        _1732 = _1730 + _1731;
        if ((long)((unsigned long)_1732 + (unsigned long)HIGH_BITS) >= 0) 
        _1732 = NewDouble((double)_1732);
    }
    else {
        _1732 = binary_op(PLUS, _1730, _1731);
    }
    _1730 = NOVALUE;
    DeRef(_1731);
    _1731 = NOVALUE;
    DeRef(_1725);
    _1725 = NOVALUE;
    _1729 = NOVALUE;
    return _1732;
L2: 
    ;
}


int _12julianDayOfYear(int _ymd_3528)
{
    int _year_3529 = NOVALUE;
    int _month_3530 = NOVALUE;
    int _day_3531 = NOVALUE;
    int _d_3532 = NOVALUE;
    int _1748 = NOVALUE;
    int _1747 = NOVALUE;
    int _1746 = NOVALUE;
    int _1743 = NOVALUE;
    int _1742 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3528);
    _year_3529 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3529)){
        _year_3529 = (long)DBL_PTR(_year_3529)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_3528);
    _month_3530 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_3530)){
        _month_3530 = (long)DBL_PTR(_month_3530)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_3528);
    _day_3531 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_3531)){
        _day_3531 = (long)DBL_PTR(_day_3531)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_3530 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_3528);
    return _day_3531;
L1: 

    /** 	d = 0*/
    _d_3532 = 0;

    /** 	for i = 1 to month - 1 do*/
    _1742 = _month_3530 - 1;
    if ((long)((unsigned long)_1742 +(unsigned long) HIGH_BITS) >= 0){
        _1742 = NewDouble((double)_1742);
    }
    {
        int _i_3539;
        _i_3539 = 1;
L2: 
        if (binary_op_a(GREATER, _i_3539, _1742)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_3539);
        _1743 = _12daysInMonth(_year_3529, _i_3539);
        if (IS_ATOM_INT(_1743)) {
            _d_3532 = _d_3532 + _1743;
        }
        else {
            _d_3532 = binary_op(PLUS, _d_3532, _1743);
        }
        DeRef(_1743);
        _1743 = NOVALUE;
        if (!IS_ATOM_INT(_d_3532)) {
            _1 = (long)(DBL_PTR(_d_3532)->dbl);
            DeRefDS(_d_3532);
            _d_3532 = _1;
        }

        /** 	end for*/
        _0 = _i_3539;
        if (IS_ATOM_INT(_i_3539)) {
            _i_3539 = _i_3539 + 1;
            if ((long)((unsigned long)_i_3539 +(unsigned long) HIGH_BITS) >= 0){
                _i_3539 = NewDouble((double)_i_3539);
            }
        }
        else {
            _i_3539 = binary_op_a(PLUS, _i_3539, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_3539);
    }

    /** 	d += day*/
    _d_3532 = _d_3532 + _day_3531;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1746 = (_year_3529 == 1752);
    if (_1746 == 0) {
        goto L4; // [86] 128
    }
    _1748 = (_month_3530 == 9);
    if (_1748 == 0)
    {
        DeRef(_1748);
        _1748 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1748);
        _1748 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_3531 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_3532 = _d_3532 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_3531 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_3528);
    DeRef(_1742);
    _1742 = NOVALUE;
    DeRef(_1746);
    _1746 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_3528);
    DeRef(_1742);
    _1742 = NOVALUE;
    DeRef(_1746);
    _1746 = NOVALUE;
    return _d_3532;
    ;
}


int _12julianDay(int _ymd_3555)
{
    int _year_3556 = NOVALUE;
    int _j_3557 = NOVALUE;
    int _greg00_3558 = NOVALUE;
    int _1777 = NOVALUE;
    int _1774 = NOVALUE;
    int _1771 = NOVALUE;
    int _1770 = NOVALUE;
    int _1769 = NOVALUE;
    int _1768 = NOVALUE;
    int _1767 = NOVALUE;
    int _1766 = NOVALUE;
    int _1765 = NOVALUE;
    int _1764 = NOVALUE;
    int _1762 = NOVALUE;
    int _1761 = NOVALUE;
    int _1760 = NOVALUE;
    int _1759 = NOVALUE;
    int _1758 = NOVALUE;
    int _1757 = NOVALUE;
    int _1756 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3555);
    _year_3556 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3556)){
        _year_3556 = (long)DBL_PTR(_year_3556)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_3555);
    _j_3557 = _12julianDayOfYear(_ymd_3555);
    if (!IS_ATOM_INT(_j_3557)) {
        _1 = (long)(DBL_PTR(_j_3557)->dbl);
        DeRefDS(_j_3557);
        _j_3557 = _1;
    }

    /** 	year  -= 1*/
    _year_3556 = _year_3556 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_3558 = _year_3556 - 1700;

    /** 	j += (*/
    if (_year_3556 <= INT15 && _year_3556 >= -INT15)
    _1756 = 365 * _year_3556;
    else
    _1756 = NewDouble(365 * (double)_year_3556);
    if (4 > 0 && _year_3556 >= 0) {
        _1757 = _year_3556 / 4;
    }
    else {
        temp_dbl = floor((double)_year_3556 / (double)4);
        _1757 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_1756)) {
        _1758 = _1756 + _1757;
        if ((long)((unsigned long)_1758 + (unsigned long)HIGH_BITS) >= 0) 
        _1758 = NewDouble((double)_1758);
    }
    else {
        _1758 = NewDouble(DBL_PTR(_1756)->dbl + (double)_1757);
    }
    DeRef(_1756);
    _1756 = NOVALUE;
    _1757 = NOVALUE;
    _1759 = (_greg00_3558 > 0);
    if (100 > 0 && _greg00_3558 >= 0) {
        _1760 = _greg00_3558 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_3558 / (double)100);
        _1760 = (long)temp_dbl;
    }
    _1761 = - _1760;
    _1762 = (_greg00_3558 % 400) ? NewDouble((double)_greg00_3558 / 400) : (_greg00_3558 / 400);
    if (IS_ATOM_INT(_1762)) {
        _1764 = NewDouble((double)_1762 + DBL_PTR(_1763)->dbl);
    }
    else {
        _1764 = NewDouble(DBL_PTR(_1762)->dbl + DBL_PTR(_1763)->dbl);
    }
    DeRef(_1762);
    _1762 = NOVALUE;
    _1765 = unary_op(FLOOR, _1764);
    DeRefDS(_1764);
    _1764 = NOVALUE;
    if (IS_ATOM_INT(_1765)) {
        _1766 = _1761 + _1765;
        if ((long)((unsigned long)_1766 + (unsigned long)HIGH_BITS) >= 0) 
        _1766 = NewDouble((double)_1766);
    }
    else {
        _1766 = NewDouble((double)_1761 + DBL_PTR(_1765)->dbl);
    }
    _1761 = NOVALUE;
    DeRef(_1765);
    _1765 = NOVALUE;
    if (IS_ATOM_INT(_1766)) {
        if (_1766 <= INT15 && _1766 >= -INT15)
        _1767 = _1759 * _1766;
        else
        _1767 = NewDouble(_1759 * (double)_1766);
    }
    else {
        _1767 = NewDouble((double)_1759 * DBL_PTR(_1766)->dbl);
    }
    _1759 = NOVALUE;
    DeRef(_1766);
    _1766 = NOVALUE;
    if (IS_ATOM_INT(_1758) && IS_ATOM_INT(_1767)) {
        _1768 = _1758 + _1767;
        if ((long)((unsigned long)_1768 + (unsigned long)HIGH_BITS) >= 0) 
        _1768 = NewDouble((double)_1768);
    }
    else {
        if (IS_ATOM_INT(_1758)) {
            _1768 = NewDouble((double)_1758 + DBL_PTR(_1767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1767)) {
                _1768 = NewDouble(DBL_PTR(_1758)->dbl + (double)_1767);
            }
            else
            _1768 = NewDouble(DBL_PTR(_1758)->dbl + DBL_PTR(_1767)->dbl);
        }
    }
    DeRef(_1758);
    _1758 = NOVALUE;
    DeRef(_1767);
    _1767 = NOVALUE;
    _1769 = (_year_3556 >= 1752);
    _1770 = 11 * _1769;
    _1769 = NOVALUE;
    if (IS_ATOM_INT(_1768)) {
        _1771 = _1768 - _1770;
        if ((long)((unsigned long)_1771 +(unsigned long) HIGH_BITS) >= 0){
            _1771 = NewDouble((double)_1771);
        }
    }
    else {
        _1771 = NewDouble(DBL_PTR(_1768)->dbl - (double)_1770);
    }
    DeRef(_1768);
    _1768 = NOVALUE;
    _1770 = NOVALUE;
    if (IS_ATOM_INT(_1771)) {
        _j_3557 = _j_3557 + _1771;
    }
    else {
        _j_3557 = NewDouble((double)_j_3557 + DBL_PTR(_1771)->dbl);
    }
    DeRef(_1771);
    _1771 = NOVALUE;
    if (!IS_ATOM_INT(_j_3557)) {
        _1 = (long)(DBL_PTR(_j_3557)->dbl);
        DeRefDS(_j_3557);
        _j_3557 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_3556 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_3556 >= 0) {
        _1774 = _year_3556 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_3556 / (double)3200);
        _1774 = (long)temp_dbl;
    }
    _j_3557 = _j_3557 - _1774;
    _1774 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_3556 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_3556 >= 0) {
        _1777 = _year_3556 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_3556 / (double)80000);
        _1777 = (long)temp_dbl;
    }
    _j_3557 = _j_3557 + _1777;
    _1777 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_3555);
    DeRef(_1760);
    _1760 = NOVALUE;
    return _j_3557;
    ;
}


int _12julianDate(int _j_3590)
{
    int _year_3591 = NOVALUE;
    int _doy_3592 = NOVALUE;
    int _daysInYear_1__tmp_at83_3614 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_83_3613 = NOVALUE;
    int _daysInYear_1__tmp_at126_3619 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_126_3618 = NOVALUE;
    int _daysInYear_1__tmp_at159_3623 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_159_3622 = NOVALUE;
    int _1810 = NOVALUE;
    int _1809 = NOVALUE;
    int _1808 = NOVALUE;
    int _1807 = NOVALUE;
    int _1805 = NOVALUE;
    int _1803 = NOVALUE;
    int _1802 = NOVALUE;
    int _1801 = NOVALUE;
    int _1799 = NOVALUE;
    int _1791 = NOVALUE;
    int _1790 = NOVALUE;
    int _1789 = NOVALUE;
    int _1787 = NOVALUE;
    int _1786 = NOVALUE;
    int _1784 = NOVALUE;
    int _1782 = NOVALUE;
    int _1781 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if j >= 0 then*/
    if (_j_3590 < 0)
    goto L1; // [5] 26

    /** 		year = floor(j / (12 * 30.43687604)) + 1*/
    _1781 = NewDouble((double)12 * DBL_PTR(_1780)->dbl);
    _2 = binary_op(DIVIDE, _j_3590, _1781);
    _1782 = unary_op(FLOOR, _2);
    DeRef(_2);
    DeRefDS(_1781);
    _1781 = NOVALUE;
    if (IS_ATOM_INT(_1782)) {
        _year_3591 = _1782 + 1;
    }
    else
    { // coercing _year_3591 to an integer 1
        _year_3591 = 1+(long)(DBL_PTR(_1782)->dbl);
        if( !IS_ATOM_INT(_year_3591) ){
            _year_3591 = (object)DBL_PTR(_year_3591)->dbl;
        }
    }
    DeRef(_1782);
    _1782 = NOVALUE;
    goto L2; // [23] 43
L1: 

    /** 		year = -floor(-j / 365.25) + 1*/
    if ((unsigned long)_j_3590 == 0xC0000000)
    _1784 = (int)NewDouble((double)-0xC0000000);
    else
    _1784 = - _j_3590;
    _2 = binary_op(DIVIDE, _1784, _1785);
    _1786 = unary_op(FLOOR, _2);
    DeRef(_2);
    DeRef(_1784);
    _1784 = NOVALUE;
    if (IS_ATOM_INT(_1786)) {
        if ((unsigned long)_1786 == 0xC0000000)
        _1787 = (int)NewDouble((double)-0xC0000000);
        else
        _1787 = - _1786;
    }
    else {
        _1787 = unary_op(UMINUS, _1786);
    }
    DeRef(_1786);
    _1786 = NOVALUE;
    if (IS_ATOM_INT(_1787)) {
        _year_3591 = _1787 + 1;
    }
    else
    { // coercing _year_3591 to an integer 1
        _year_3591 = 1+(long)(DBL_PTR(_1787)->dbl);
        if( !IS_ATOM_INT(_year_3591) ){
            _year_3591 = (object)DBL_PTR(_year_3591)->dbl;
        }
    }
    DeRef(_1787);
    _1787 = NOVALUE;
L2: 

    /** 	doy = j - (julianDay({year, 1, 1}) - 1) -- = j - last day of prev year*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3591;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 1;
    _1789 = MAKE_SEQ(_1);
    _1790 = _12julianDay(_1789);
    _1789 = NOVALUE;
    if (IS_ATOM_INT(_1790)) {
        _1791 = _1790 - 1;
        if ((long)((unsigned long)_1791 +(unsigned long) HIGH_BITS) >= 0){
            _1791 = NewDouble((double)_1791);
        }
    }
    else {
        _1791 = binary_op(MINUS, _1790, 1);
    }
    DeRef(_1790);
    _1790 = NOVALUE;
    if (IS_ATOM_INT(_1791)) {
        _doy_3592 = _j_3590 - _1791;
    }
    else {
        _doy_3592 = binary_op(MINUS, _j_3590, _1791);
    }
    DeRef(_1791);
    _1791 = NOVALUE;
    if (!IS_ATOM_INT(_doy_3592)) {
        _1 = (long)(DBL_PTR(_doy_3592)->dbl);
        DeRefDS(_doy_3592);
        _doy_3592 = _1;
    }

    /** 	while doy <= 0 do -- we guessed too high for the year*/
L3: 
    if (_doy_3592 > 0)
    goto L4; // [72] 122

    /** 		year -= 1*/
    _year_3591 = _year_3591 - 1;

    /** 		doy += daysInYear(year)*/

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3591 != 1752)
    goto L5; // [86] 98

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_83_3613);
    _daysInYear_inlined_daysInYear_at_83_3613 = 355;
    goto L6; // [95] 109
L5: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at83_3614;
    _daysInYear_1__tmp_at83_3614 = _12isLeap(_year_3591);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_83_3613);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at83_3614)) {
        _daysInYear_inlined_daysInYear_at_83_3613 = 365 + _daysInYear_1__tmp_at83_3614;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_83_3613 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_83_3613 = NewDouble((double)_daysInYear_inlined_daysInYear_at_83_3613);
    }
    else {
        _daysInYear_inlined_daysInYear_at_83_3613 = binary_op(PLUS, 365, _daysInYear_1__tmp_at83_3614);
    }
L6: 
    DeRef(_daysInYear_1__tmp_at83_3614);
    _daysInYear_1__tmp_at83_3614 = NOVALUE;
    if (IS_ATOM_INT(_daysInYear_inlined_daysInYear_at_83_3613)) {
        _doy_3592 = _doy_3592 + _daysInYear_inlined_daysInYear_at_83_3613;
    }
    else {
        _doy_3592 = binary_op(PLUS, _doy_3592, _daysInYear_inlined_daysInYear_at_83_3613);
    }
    if (!IS_ATOM_INT(_doy_3592)) {
        _1 = (long)(DBL_PTR(_doy_3592)->dbl);
        DeRefDS(_doy_3592);
        _doy_3592 = _1;
    }

    /** 	end while*/
    goto L3; // [119] 72
L4: 

    /** 	while doy > daysInYear(year) do -- we guessed too low*/
L7: 

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3591 != 1752)
    goto L8; // [129] 141

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_126_3618);
    _daysInYear_inlined_daysInYear_at_126_3618 = 355;
    goto L9; // [138] 152
L8: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at126_3619;
    _daysInYear_1__tmp_at126_3619 = _12isLeap(_year_3591);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_126_3618);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at126_3619)) {
        _daysInYear_inlined_daysInYear_at_126_3618 = 365 + _daysInYear_1__tmp_at126_3619;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_126_3618 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_126_3618 = NewDouble((double)_daysInYear_inlined_daysInYear_at_126_3618);
    }
    else {
        _daysInYear_inlined_daysInYear_at_126_3618 = binary_op(PLUS, 365, _daysInYear_1__tmp_at126_3619);
    }
L9: 
    DeRef(_daysInYear_1__tmp_at126_3619);
    _daysInYear_1__tmp_at126_3619 = NOVALUE;
    if (binary_op_a(LESSEQ, _doy_3592, _daysInYear_inlined_daysInYear_at_126_3618)){
        goto LA; // [154] 204
    }

    /** 		doy -= daysInYear(year)*/

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3591 != 1752)
    goto LB; // [162] 174

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_159_3622);
    _daysInYear_inlined_daysInYear_at_159_3622 = 355;
    goto LC; // [171] 185
LB: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at159_3623;
    _daysInYear_1__tmp_at159_3623 = _12isLeap(_year_3591);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_159_3622);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at159_3623)) {
        _daysInYear_inlined_daysInYear_at_159_3622 = 365 + _daysInYear_1__tmp_at159_3623;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_159_3622 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_159_3622 = NewDouble((double)_daysInYear_inlined_daysInYear_at_159_3622);
    }
    else {
        _daysInYear_inlined_daysInYear_at_159_3622 = binary_op(PLUS, 365, _daysInYear_1__tmp_at159_3623);
    }
LC: 
    DeRef(_daysInYear_1__tmp_at159_3623);
    _daysInYear_1__tmp_at159_3623 = NOVALUE;
    if (IS_ATOM_INT(_daysInYear_inlined_daysInYear_at_159_3622)) {
        _doy_3592 = _doy_3592 - _daysInYear_inlined_daysInYear_at_159_3622;
    }
    else {
        _doy_3592 = binary_op(MINUS, _doy_3592, _daysInYear_inlined_daysInYear_at_159_3622);
    }
    if (!IS_ATOM_INT(_doy_3592)) {
        _1 = (long)(DBL_PTR(_doy_3592)->dbl);
        DeRefDS(_doy_3592);
        _doy_3592 = _1;
    }

    /** 		year += 1*/
    _year_3591 = _year_3591 + 1;

    /** 	end while*/
    goto L7; // [201] 127
LA: 

    /** 	if doy <= daysInMonth(year, 1) then*/
    _1799 = _12daysInMonth(_year_3591, 1);
    if (binary_op_a(GREATER, _doy_3592, _1799)){
        DeRef(_1799);
        _1799 = NOVALUE;
        goto LD; // [211] 228
    }
    DeRef(_1799);
    _1799 = NOVALUE;

    /** 		return {year, 1, doy}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3591;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _doy_3592;
    _1801 = MAKE_SEQ(_1);
    return _1801;
LD: 

    /** 	for month = 2 to 12 do*/
    {
        int _month_3631;
        _month_3631 = 2;
LE: 
        if (_month_3631 > 12){
            goto LF; // [230] 285
        }

        /** 		doy -= daysInMonth(year, month-1)*/
        _1802 = _month_3631 - 1;
        _1803 = _12daysInMonth(_year_3591, _1802);
        _1802 = NOVALUE;
        if (IS_ATOM_INT(_1803)) {
            _doy_3592 = _doy_3592 - _1803;
        }
        else {
            _doy_3592 = binary_op(MINUS, _doy_3592, _1803);
        }
        DeRef(_1803);
        _1803 = NOVALUE;
        if (!IS_ATOM_INT(_doy_3592)) {
            _1 = (long)(DBL_PTR(_doy_3592)->dbl);
            DeRefDS(_doy_3592);
            _doy_3592 = _1;
        }

        /** 		if doy <= daysInMonth(year, month) then*/
        _1805 = _12daysInMonth(_year_3591, _month_3631);
        if (binary_op_a(GREATER, _doy_3592, _1805)){
            DeRef(_1805);
            _1805 = NOVALUE;
            goto L10; // [261] 278
        }
        DeRef(_1805);
        _1805 = NOVALUE;

        /** 			return {year, month, doy}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _year_3591;
        *((int *)(_2+8)) = _month_3631;
        *((int *)(_2+12)) = _doy_3592;
        _1807 = MAKE_SEQ(_1);
        DeRef(_1801);
        _1801 = NOVALUE;
        return _1807;
L10: 

        /** 	end for*/
        _month_3631 = _month_3631 + 1;
        goto LE; // [280] 237
LF: 
        ;
    }

    /** 	return {year+1, 1, doy-31}*/
    _1808 = _year_3591 + 1;
    if (_1808 > MAXINT){
        _1808 = NewDouble((double)_1808);
    }
    _1809 = _doy_3592 - 31;
    if ((long)((unsigned long)_1809 +(unsigned long) HIGH_BITS) >= 0){
        _1809 = NewDouble((double)_1809);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1808;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _1809;
    _1810 = MAKE_SEQ(_1);
    _1809 = NOVALUE;
    _1808 = NOVALUE;
    DeRef(_1801);
    _1801 = NOVALUE;
    DeRef(_1807);
    _1807 = NOVALUE;
    return _1810;
    ;
}


int _12datetimeToSeconds(int _dt_3644)
{
    int _1820 = NOVALUE;
    int _1819 = NOVALUE;
    int _1818 = NOVALUE;
    int _1817 = NOVALUE;
    int _1816 = NOVALUE;
    int _1815 = NOVALUE;
    int _1814 = NOVALUE;
    int _1813 = NOVALUE;
    int _1812 = NOVALUE;
    int _1811 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_3644);
    _1811 = _12julianDay(_dt_3644);
    if (IS_ATOM_INT(_1811)) {
        _1812 = NewDouble(_1811 * (double)86400);
    }
    else {
        _1812 = binary_op(MULTIPLY, _1811, 86400);
    }
    DeRef(_1811);
    _1811 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3644);
    _1813 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1813)) {
        if (_1813 == (short)_1813)
        _1814 = _1813 * 60;
        else
        _1814 = NewDouble(_1813 * (double)60);
    }
    else {
        _1814 = binary_op(MULTIPLY, _1813, 60);
    }
    _1813 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3644);
    _1815 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1814) && IS_ATOM_INT(_1815)) {
        _1816 = _1814 + _1815;
        if ((long)((unsigned long)_1816 + (unsigned long)HIGH_BITS) >= 0) 
        _1816 = NewDouble((double)_1816);
    }
    else {
        _1816 = binary_op(PLUS, _1814, _1815);
    }
    DeRef(_1814);
    _1814 = NOVALUE;
    _1815 = NOVALUE;
    if (IS_ATOM_INT(_1816)) {
        if (_1816 == (short)_1816)
        _1817 = _1816 * 60;
        else
        _1817 = NewDouble(_1816 * (double)60);
    }
    else {
        _1817 = binary_op(MULTIPLY, _1816, 60);
    }
    DeRef(_1816);
    _1816 = NOVALUE;
    if (IS_ATOM_INT(_1812) && IS_ATOM_INT(_1817)) {
        _1818 = _1812 + _1817;
        if ((long)((unsigned long)_1818 + (unsigned long)HIGH_BITS) >= 0) 
        _1818 = NewDouble((double)_1818);
    }
    else {
        _1818 = binary_op(PLUS, _1812, _1817);
    }
    DeRef(_1812);
    _1812 = NOVALUE;
    DeRef(_1817);
    _1817 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3644);
    _1819 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1818) && IS_ATOM_INT(_1819)) {
        _1820 = _1818 + _1819;
        if ((long)((unsigned long)_1820 + (unsigned long)HIGH_BITS) >= 0) 
        _1820 = NewDouble((double)_1820);
    }
    else {
        _1820 = binary_op(PLUS, _1818, _1819);
    }
    DeRef(_1818);
    _1818 = NOVALUE;
    _1819 = NOVALUE;
    DeRef(_dt_3644);
    return _1820;
    ;
}


int _12secondsToDateTime(int _seconds_3657)
{
    int _days_3658 = NOVALUE;
    int _minutes_3659 = NOVALUE;
    int _hours_3660 = NOVALUE;
    int _1832 = NOVALUE;
    int _1831 = NOVALUE;
    int _1830 = NOVALUE;
    int _1828 = NOVALUE;
    int _1825 = NOVALUE;
    int _0, _1, _2;
    

    /** 	days = floor(seconds / DayLengthInSeconds)*/
    if (IS_ATOM_INT(_seconds_3657)) {
        if (86400 > 0 && _seconds_3657 >= 0) {
            _days_3658 = _seconds_3657 / 86400;
        }
        else {
            temp_dbl = floor((double)_seconds_3657 / (double)86400);
            _days_3658 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3657, 86400);
        _days_3658 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_days_3658)) {
        _1 = (long)(DBL_PTR(_days_3658)->dbl);
        DeRefDS(_days_3658);
        _days_3658 = _1;
    }

    /** 	seconds = remainder(seconds, DayLengthInSeconds)*/
    _0 = _seconds_3657;
    if (IS_ATOM_INT(_seconds_3657)) {
        _seconds_3657 = (_seconds_3657 % 86400);
    }
    else {
        temp_d.dbl = (double)86400;
        _seconds_3657 = Dremainder(DBL_PTR(_seconds_3657), &temp_d);
    }
    DeRef(_0);

    /** 		hours = floor( seconds / 3600 )*/
    if (IS_ATOM_INT(_seconds_3657)) {
        if (3600 > 0 && _seconds_3657 >= 0) {
            _hours_3660 = _seconds_3657 / 3600;
        }
        else {
            temp_dbl = floor((double)_seconds_3657 / (double)3600);
            _hours_3660 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3657, 3600);
        _hours_3660 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_hours_3660)) {
        _1 = (long)(DBL_PTR(_hours_3660)->dbl);
        DeRefDS(_hours_3660);
        _hours_3660 = _1;
    }

    /** 		seconds -= hours * 3600*/
    if (_hours_3660 == (short)_hours_3660)
    _1825 = _hours_3660 * 3600;
    else
    _1825 = NewDouble(_hours_3660 * (double)3600);
    _0 = _seconds_3657;
    if (IS_ATOM_INT(_seconds_3657) && IS_ATOM_INT(_1825)) {
        _seconds_3657 = _seconds_3657 - _1825;
        if ((long)((unsigned long)_seconds_3657 +(unsigned long) HIGH_BITS) >= 0){
            _seconds_3657 = NewDouble((double)_seconds_3657);
        }
    }
    else {
        if (IS_ATOM_INT(_seconds_3657)) {
            _seconds_3657 = NewDouble((double)_seconds_3657 - DBL_PTR(_1825)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1825)) {
                _seconds_3657 = NewDouble(DBL_PTR(_seconds_3657)->dbl - (double)_1825);
            }
            else
            _seconds_3657 = NewDouble(DBL_PTR(_seconds_3657)->dbl - DBL_PTR(_1825)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1825);
    _1825 = NOVALUE;

    /** 		minutes = floor( seconds / 60 )*/
    if (IS_ATOM_INT(_seconds_3657)) {
        if (60 > 0 && _seconds_3657 >= 0) {
            _minutes_3659 = _seconds_3657 / 60;
        }
        else {
            temp_dbl = floor((double)_seconds_3657 / (double)60);
            _minutes_3659 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3657, 60);
        _minutes_3659 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_minutes_3659)) {
        _1 = (long)(DBL_PTR(_minutes_3659)->dbl);
        DeRefDS(_minutes_3659);
        _minutes_3659 = _1;
    }

    /** 		seconds -= minutes* 60*/
    if (_minutes_3659 == (short)_minutes_3659)
    _1828 = _minutes_3659 * 60;
    else
    _1828 = NewDouble(_minutes_3659 * (double)60);
    _0 = _seconds_3657;
    if (IS_ATOM_INT(_seconds_3657) && IS_ATOM_INT(_1828)) {
        _seconds_3657 = _seconds_3657 - _1828;
        if ((long)((unsigned long)_seconds_3657 +(unsigned long) HIGH_BITS) >= 0){
            _seconds_3657 = NewDouble((double)_seconds_3657);
        }
    }
    else {
        if (IS_ATOM_INT(_seconds_3657)) {
            _seconds_3657 = NewDouble((double)_seconds_3657 - DBL_PTR(_1828)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1828)) {
                _seconds_3657 = NewDouble(DBL_PTR(_seconds_3657)->dbl - (double)_1828);
            }
            else
            _seconds_3657 = NewDouble(DBL_PTR(_seconds_3657)->dbl - DBL_PTR(_1828)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1828);
    _1828 = NOVALUE;

    /** 	return julianDate(days) & {hours, minutes, seconds}*/
    _1830 = _12julianDate(_days_3658);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _hours_3660;
    *((int *)(_2+8)) = _minutes_3659;
    Ref(_seconds_3657);
    *((int *)(_2+12)) = _seconds_3657;
    _1831 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_1830) && IS_ATOM(_1831)) {
    }
    else if (IS_ATOM(_1830) && IS_SEQUENCE(_1831)) {
        Ref(_1830);
        Prepend(&_1832, _1831, _1830);
    }
    else {
        Concat((object_ptr)&_1832, _1830, _1831);
        DeRef(_1830);
        _1830 = NOVALUE;
    }
    DeRef(_1830);
    _1830 = NOVALUE;
    DeRefDS(_1831);
    _1831 = NOVALUE;
    DeRef(_seconds_3657);
    return _1832;
    ;
}


int  __stdcall _12datetime(int _o_3738)
{
    int _1925 = NOVALUE;
    int _1923 = NOVALUE;
    int _1920 = NOVALUE;
    int _1918 = NOVALUE;
    int _1915 = NOVALUE;
    int _1913 = NOVALUE;
    int _1911 = NOVALUE;
    int _1910 = NOVALUE;
    int _1909 = NOVALUE;
    int _1908 = NOVALUE;
    int _1906 = NOVALUE;
    int _1904 = NOVALUE;
    int _1902 = NOVALUE;
    int _1900 = NOVALUE;
    int _1899 = NOVALUE;
    int _1898 = NOVALUE;
    int _1896 = NOVALUE;
    int _1895 = NOVALUE;
    int _1893 = NOVALUE;
    int _1892 = NOVALUE;
    int _1890 = NOVALUE;
    int _1889 = NOVALUE;
    int _1887 = NOVALUE;
    int _1886 = NOVALUE;
    int _1884 = NOVALUE;
    int _1883 = NOVALUE;
    int _1881 = NOVALUE;
    int _1880 = NOVALUE;
    int _1878 = NOVALUE;
    int _1877 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(o) then return 0 end if*/
    _1877 = IS_ATOM(_o_3738);
    if (_1877 == 0)
    {
        _1877 = NOVALUE;
        goto L1; // [6] 14
    }
    else{
        _1877 = NOVALUE;
    }
    DeRef(_o_3738);
    return 0;
L1: 

    /** 	if length(o) != 6 then return 0 end if*/
    if (IS_SEQUENCE(_o_3738)){
            _1878 = SEQ_PTR(_o_3738)->length;
    }
    else {
        _1878 = 1;
    }
    if (_1878 == 6)
    goto L2; // [19] 28
    DeRef(_o_3738);
    return 0;
L2: 

    /** 	if not integer(o[YEAR]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1880 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1880))
    _1881 = 1;
    else if (IS_ATOM_DBL(_1880))
    _1881 = IS_ATOM_INT(DoubleToInt(_1880));
    else
    _1881 = 0;
    _1880 = NOVALUE;
    if (_1881 != 0)
    goto L3; // [37] 45
    _1881 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L3: 

    /** 	if not integer(o[MONTH]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1883 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1883))
    _1884 = 1;
    else if (IS_ATOM_DBL(_1883))
    _1884 = IS_ATOM_INT(DoubleToInt(_1883));
    else
    _1884 = 0;
    _1883 = NOVALUE;
    if (_1884 != 0)
    goto L4; // [54] 62
    _1884 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L4: 

    /** 	if not integer(o[DAY]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1886 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1886))
    _1887 = 1;
    else if (IS_ATOM_DBL(_1886))
    _1887 = IS_ATOM_INT(DoubleToInt(_1886));
    else
    _1887 = 0;
    _1886 = NOVALUE;
    if (_1887 != 0)
    goto L5; // [71] 79
    _1887 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L5: 

    /** 	if not integer(o[HOUR]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1889 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1889))
    _1890 = 1;
    else if (IS_ATOM_DBL(_1889))
    _1890 = IS_ATOM_INT(DoubleToInt(_1889));
    else
    _1890 = 0;
    _1889 = NOVALUE;
    if (_1890 != 0)
    goto L6; // [88] 96
    _1890 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L6: 

    /** 	if not integer(o[MINUTE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1892 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1892))
    _1893 = 1;
    else if (IS_ATOM_DBL(_1892))
    _1893 = IS_ATOM_INT(DoubleToInt(_1892));
    else
    _1893 = 0;
    _1892 = NOVALUE;
    if (_1893 != 0)
    goto L7; // [105] 113
    _1893 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L7: 

    /** 	if not atom(o[SECOND]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1895 = (int)*(((s1_ptr)_2)->base + 6);
    _1896 = IS_ATOM(_1895);
    _1895 = NOVALUE;
    if (_1896 != 0)
    goto L8; // [122] 130
    _1896 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L8: 

    /** 	if not equal(o[1..3], {0,0,0}) then*/
    rhs_slice_target = (object_ptr)&_1898;
    RHS_Slice(_o_3738, 1, 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _1899 = MAKE_SEQ(_1);
    if (_1898 == _1899)
    _1900 = 1;
    else if (IS_ATOM_INT(_1898) && IS_ATOM_INT(_1899))
    _1900 = 0;
    else
    _1900 = (compare(_1898, _1899) == 0);
    DeRefDS(_1898);
    _1898 = NOVALUE;
    DeRefDS(_1899);
    _1899 = NOVALUE;
    if (_1900 != 0)
    goto L9; // [147] 224
    _1900 = NOVALUE;

    /** 		if o[MONTH] < 1 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1902 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _1902, 1)){
        _1902 = NOVALUE;
        goto LA; // [156] 165
    }
    _1902 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LA: 

    /** 		if o[MONTH] > 12 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1904 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _1904, 12)){
        _1904 = NOVALUE;
        goto LB; // [171] 180
    }
    _1904 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LB: 

    /** 		if o[DAY] < 1 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1906 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _1906, 1)){
        _1906 = NOVALUE;
        goto LC; // [186] 195
    }
    _1906 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LC: 

    /** 		if o[DAY] > daysInMonth(o[YEAR],o[MONTH]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1908 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_o_3738);
    _1909 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_o_3738);
    _1910 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1909);
    Ref(_1910);
    _1911 = _12daysInMonth(_1909, _1910);
    _1909 = NOVALUE;
    _1910 = NOVALUE;
    if (binary_op_a(LESSEQ, _1908, _1911)){
        _1908 = NOVALUE;
        DeRef(_1911);
        _1911 = NOVALUE;
        goto LD; // [214] 223
    }
    _1908 = NOVALUE;
    DeRef(_1911);
    _1911 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LD: 
L9: 

    /** 	if o[HOUR] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1913 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(GREATEREQ, _1913, 0)){
        _1913 = NOVALUE;
        goto LE; // [230] 239
    }
    _1913 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LE: 

    /** 	if o[HOUR] > 23 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1915 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(LESSEQ, _1915, 23)){
        _1915 = NOVALUE;
        goto LF; // [245] 254
    }
    _1915 = NOVALUE;
    DeRef(_o_3738);
    return 0;
LF: 

    /** 	if o[MINUTE] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1918 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(GREATEREQ, _1918, 0)){
        _1918 = NOVALUE;
        goto L10; // [260] 269
    }
    _1918 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L10: 

    /** 	if o[MINUTE] > 59 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1920 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _1920, 59)){
        _1920 = NOVALUE;
        goto L11; // [275] 284
    }
    _1920 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L11: 

    /** 	if o[SECOND] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1923 = (int)*(((s1_ptr)_2)->base + 6);
    if (binary_op_a(GREATEREQ, _1923, 0)){
        _1923 = NOVALUE;
        goto L12; // [290] 299
    }
    _1923 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L12: 

    /** 	if o[SECOND] >= 60 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3738);
    _1925 = (int)*(((s1_ptr)_2)->base + 6);
    if (binary_op_a(LESS, _1925, 60)){
        _1925 = NOVALUE;
        goto L13; // [305] 314
    }
    _1925 = NOVALUE;
    DeRef(_o_3738);
    return 0;
L13: 

    /** 	return 1*/
    DeRef(_o_3738);
    return 1;
    ;
}


int  __stdcall _12from_date(int _src_3810)
{
    int _1935 = NOVALUE;
    int _1934 = NOVALUE;
    int _1933 = NOVALUE;
    int _1932 = NOVALUE;
    int _1931 = NOVALUE;
    int _1930 = NOVALUE;
    int _1929 = NOVALUE;
    int _1927 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_3810);
    _1927 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1927)) {
        _1929 = _1927 + 1900;
        if ((long)((unsigned long)_1929 + (unsigned long)HIGH_BITS) >= 0) 
        _1929 = NewDouble((double)_1929);
    }
    else {
        _1929 = binary_op(PLUS, _1927, 1900);
    }
    _1927 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_3810);
    _1930 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_3810);
    _1931 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_3810);
    _1932 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_3810);
    _1933 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_3810);
    _1934 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1929;
    Ref(_1930);
    *((int *)(_2+8)) = _1930;
    Ref(_1931);
    *((int *)(_2+12)) = _1931;
    Ref(_1932);
    *((int *)(_2+16)) = _1932;
    Ref(_1933);
    *((int *)(_2+20)) = _1933;
    Ref(_1934);
    *((int *)(_2+24)) = _1934;
    _1935 = MAKE_SEQ(_1);
    _1934 = NOVALUE;
    _1933 = NOVALUE;
    _1932 = NOVALUE;
    _1931 = NOVALUE;
    _1930 = NOVALUE;
    _1929 = NOVALUE;
    DeRefDS(_src_3810);
    return _1935;
    ;
}


int  __stdcall _12now()
{
    int _1937 = NOVALUE;
    int _1936 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return from_date(date())*/
    _1936 = Date();
    _1937 = _12from_date(_1936);
    _1936 = NOVALUE;
    return _1937;
    ;
}


int  __stdcall _12now_gmt()
{
    int _t1_3826 = NOVALUE;
    int _1948 = NOVALUE;
    int _1947 = NOVALUE;
    int _1946 = NOVALUE;
    int _1945 = NOVALUE;
    int _1944 = NOVALUE;
    int _1943 = NOVALUE;
    int _1942 = NOVALUE;
    int _1941 = NOVALUE;
    int _1940 = NOVALUE;
    int _1938 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence t1 = gmtime(time())*/
    _1938 = _12time();
    _0 = _t1_3826;
    _t1_3826 = _12gmtime(_1938);
    DeRef(_0);
    _1938 = NOVALUE;

    /** 	return { */
    _2 = (int)SEQ_PTR(_t1_3826);
    _1940 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1940)) {
        _1941 = _1940 + 1900;
        if ((long)((unsigned long)_1941 + (unsigned long)HIGH_BITS) >= 0) 
        _1941 = NewDouble((double)_1941);
    }
    else {
        _1941 = binary_op(PLUS, _1940, 1900);
    }
    _1940 = NOVALUE;
    _2 = (int)SEQ_PTR(_t1_3826);
    _1942 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1942)) {
        _1943 = _1942 + 1;
        if (_1943 > MAXINT){
            _1943 = NewDouble((double)_1943);
        }
    }
    else
    _1943 = binary_op(PLUS, 1, _1942);
    _1942 = NOVALUE;
    _2 = (int)SEQ_PTR(_t1_3826);
    _1944 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_t1_3826);
    _1945 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_t1_3826);
    _1946 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_t1_3826);
    _1947 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1941;
    *((int *)(_2+8)) = _1943;
    Ref(_1944);
    *((int *)(_2+12)) = _1944;
    Ref(_1945);
    *((int *)(_2+16)) = _1945;
    Ref(_1946);
    *((int *)(_2+20)) = _1946;
    Ref(_1947);
    *((int *)(_2+24)) = _1947;
    _1948 = MAKE_SEQ(_1);
    _1947 = NOVALUE;
    _1946 = NOVALUE;
    _1945 = NOVALUE;
    _1944 = NOVALUE;
    _1943 = NOVALUE;
    _1941 = NOVALUE;
    DeRefDS(_t1_3826);
    return _1948;
    ;
}


int  __stdcall _12new(int _year_3840, int _month_3841, int _day_3842, int _hour_3843, int _minute_3844, int _second_3845)
{
    int _d_3846 = NOVALUE;
    int _now_1__tmp_at41_3853 = NOVALUE;
    int _now_inlined_now_at_41_3852 = NOVALUE;
    int _1951 = NOVALUE;
    int _1950 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3840)) {
        _1 = (long)(DBL_PTR(_year_3840)->dbl);
        DeRefDS(_year_3840);
        _year_3840 = _1;
    }
    if (!IS_ATOM_INT(_month_3841)) {
        _1 = (long)(DBL_PTR(_month_3841)->dbl);
        DeRefDS(_month_3841);
        _month_3841 = _1;
    }
    if (!IS_ATOM_INT(_day_3842)) {
        _1 = (long)(DBL_PTR(_day_3842)->dbl);
        DeRefDS(_day_3842);
        _day_3842 = _1;
    }
    if (!IS_ATOM_INT(_hour_3843)) {
        _1 = (long)(DBL_PTR(_hour_3843)->dbl);
        DeRefDS(_hour_3843);
        _hour_3843 = _1;
    }
    if (!IS_ATOM_INT(_minute_3844)) {
        _1 = (long)(DBL_PTR(_minute_3844)->dbl);
        DeRefDS(_minute_3844);
        _minute_3844 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_3846;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3840;
    *((int *)(_2+8)) = _month_3841;
    *((int *)(_2+12)) = _day_3842;
    *((int *)(_2+16)) = _hour_3843;
    *((int *)(_2+20)) = _minute_3844;
    Ref(_second_3845);
    *((int *)(_2+24)) = _second_3845;
    _d_3846 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _1950 = MAKE_SEQ(_1);
    if (_d_3846 == _1950)
    _1951 = 1;
    else if (IS_ATOM_INT(_d_3846) && IS_ATOM_INT(_1950))
    _1951 = 0;
    else
    _1951 = (compare(_d_3846, _1950) == 0);
    DeRefDS(_1950);
    _1950 = NOVALUE;
    if (_1951 == 0)
    {
        _1951 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1951 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_3853);
    _now_1__tmp_at41_3853 = Date();
    RefDS(_now_1__tmp_at41_3853);
    _0 = _now_inlined_now_at_41_3852;
    _now_inlined_now_at_41_3852 = _12from_date(_now_1__tmp_at41_3853);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_3853);
    _now_1__tmp_at41_3853 = NOVALUE;
    DeRef(_second_3845);
    DeRef(_d_3846);
    return _now_inlined_now_at_41_3852;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_3845);
    return _d_3846;
L2: 
    ;
}


int  __stdcall _12new_time(int _hour_3857, int _minute_3858, int _second_3859)
{
    int _1952 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_hour_3857)) {
        _1 = (long)(DBL_PTR(_hour_3857)->dbl);
        DeRefDS(_hour_3857);
        _hour_3857 = _1;
    }
    if (!IS_ATOM_INT(_minute_3858)) {
        _1 = (long)(DBL_PTR(_minute_3858)->dbl);
        DeRefDS(_minute_3858);
        _minute_3858 = _1;
    }

    /** 	return new(0, 0, 0, hour, minute, second)*/
    Ref(_second_3859);
    _1952 = _12new(0, 0, 0, _hour_3857, _minute_3858, _second_3859);
    DeRef(_second_3859);
    return _1952;
    ;
}


int  __stdcall _12weeks_day(int _dt_3863)
{
    int _1958 = NOVALUE;
    int _1957 = NOVALUE;
    int _1956 = NOVALUE;
    int _1954 = NOVALUE;
    int _1953 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
    Ref(_dt_3863);
    _1953 = _12julianDay(_dt_3863);
    if (IS_ATOM_INT(_1953)) {
        _1954 = _1953 - 1;
        if ((long)((unsigned long)_1954 +(unsigned long) HIGH_BITS) >= 0){
            _1954 = NewDouble((double)_1954);
        }
    }
    else {
        _1954 = binary_op(MINUS, _1953, 1);
    }
    DeRef(_1953);
    _1953 = NOVALUE;
    if (IS_ATOM_INT(_1954)) {
        _1956 = _1954 + 4094;
        if ((long)((unsigned long)_1956 + (unsigned long)HIGH_BITS) >= 0) 
        _1956 = NewDouble((double)_1956);
    }
    else {
        _1956 = binary_op(PLUS, _1954, 4094);
    }
    DeRef(_1954);
    _1954 = NOVALUE;
    if (IS_ATOM_INT(_1956)) {
        _1957 = (_1956 % 7);
    }
    else {
        _1957 = binary_op(REMAINDER, _1956, 7);
    }
    DeRef(_1956);
    _1956 = NOVALUE;
    if (IS_ATOM_INT(_1957)) {
        _1958 = _1957 + 1;
        if (_1958 > MAXINT){
            _1958 = NewDouble((double)_1958);
        }
    }
    else
    _1958 = binary_op(PLUS, 1, _1957);
    DeRef(_1957);
    _1957 = NOVALUE;
    DeRef(_dt_3863);
    return _1958;
    ;
}


int  __stdcall _12years_day(int _dt_3872)
{
    int _1963 = NOVALUE;
    int _1962 = NOVALUE;
    int _1961 = NOVALUE;
    int _1960 = NOVALUE;
    int _1959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDayOfYear({dt[YEAR], dt[MONTH], dt[DAY]})*/
    _2 = (int)SEQ_PTR(_dt_3872);
    _1959 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_dt_3872);
    _1960 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_dt_3872);
    _1961 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_1959);
    *((int *)(_2+4)) = _1959;
    Ref(_1960);
    *((int *)(_2+8)) = _1960;
    Ref(_1961);
    *((int *)(_2+12)) = _1961;
    _1962 = MAKE_SEQ(_1);
    _1961 = NOVALUE;
    _1960 = NOVALUE;
    _1959 = NOVALUE;
    _1963 = _12julianDayOfYear(_1962);
    _1962 = NOVALUE;
    DeRef(_dt_3872);
    return _1963;
    ;
}


int  __stdcall _12is_leap_year(int _dt_3880)
{
    int _1965 = NOVALUE;
    int _1964 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return isLeap(dt[YEAR])*/
    _2 = (int)SEQ_PTR(_dt_3880);
    _1964 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1964);
    _1965 = _12isLeap(_1964);
    _1964 = NOVALUE;
    DeRef(_dt_3880);
    return _1965;
    ;
}


int  __stdcall _12days_in_month(int _dt_3885)
{
    int _1968 = NOVALUE;
    int _1967 = NOVALUE;
    int _1966 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return daysInMonth(dt[YEAR], dt[MONTH])*/
    _2 = (int)SEQ_PTR(_dt_3885);
    _1966 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_dt_3885);
    _1967 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1966);
    Ref(_1967);
    _1968 = _12daysInMonth(_1966, _1967);
    _1966 = NOVALUE;
    _1967 = NOVALUE;
    DeRef(_dt_3885);
    return _1968;
    ;
}


int  __stdcall _12days_in_year(int _dt_3891)
{
    int _daysInYear_1__tmp_at9_3896 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_9_3895 = NOVALUE;
    int _year_inlined_daysInYear_at_6_3894 = NOVALUE;
    int _1969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return daysInYear(dt[YEAR])*/
    _2 = (int)SEQ_PTR(_dt_3891);
    _1969 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1969);
    DeRef(_year_inlined_daysInYear_at_6_3894);
    _year_inlined_daysInYear_at_6_3894 = _1969;
    _1969 = NOVALUE;
    if (!IS_ATOM_INT(_year_inlined_daysInYear_at_6_3894)) {
        _1 = (long)(DBL_PTR(_year_inlined_daysInYear_at_6_3894)->dbl);
        DeRefDS(_year_inlined_daysInYear_at_6_3894);
        _year_inlined_daysInYear_at_6_3894 = _1;
    }

    /** 	if year = Gregorian_Reformation then*/
    if (_year_inlined_daysInYear_at_6_3894 != 1752)
    goto L1; // [14] 26

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_9_3895);
    _daysInYear_inlined_daysInYear_at_9_3895 = 355;
    goto L2; // [23] 37
L1: 

    /** 	return 365 + isLeap(year)*/
    Ref(_year_inlined_daysInYear_at_6_3894);
    _0 = _daysInYear_1__tmp_at9_3896;
    _daysInYear_1__tmp_at9_3896 = _12isLeap(_year_inlined_daysInYear_at_6_3894);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_9_3895);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at9_3896)) {
        _daysInYear_inlined_daysInYear_at_9_3895 = 365 + _daysInYear_1__tmp_at9_3896;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_9_3895 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_9_3895 = NewDouble((double)_daysInYear_inlined_daysInYear_at_9_3895);
    }
    else {
        _daysInYear_inlined_daysInYear_at_9_3895 = binary_op(PLUS, 365, _daysInYear_1__tmp_at9_3896);
    }
L2: 
    DeRef(_year_inlined_daysInYear_at_6_3894);
    _year_inlined_daysInYear_at_6_3894 = NOVALUE;
    DeRef(_daysInYear_1__tmp_at9_3896);
    _daysInYear_1__tmp_at9_3896 = NOVALUE;
    DeRef(_dt_3891);
    return _daysInYear_inlined_daysInYear_at_9_3895;
    ;
}


int  __stdcall _12to_unix(int _dt_3899)
{
    int _1971 = NOVALUE;
    int _1970 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetimeToSeconds(dt) - EPOCH_1970*/
    Ref(_dt_3899);
    _1970 = _12datetimeToSeconds(_dt_3899);
    _1971 = binary_op(MINUS, _1970, _12EPOCH_1970_3464);
    DeRef(_1970);
    _1970 = NOVALUE;
    DeRef(_dt_3899);
    return _1971;
    ;
}


int  __stdcall _12from_unix(int _unix_3904)
{
    int _1973 = NOVALUE;
    int _1972 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return secondsToDateTime(EPOCH_1970 + unix)*/
    if (IS_ATOM_INT(_unix_3904)) {
        _1972 = NewDouble(DBL_PTR(_12EPOCH_1970_3464)->dbl + (double)_unix_3904);
    }
    else
    _1972 = NewDouble(DBL_PTR(_12EPOCH_1970_3464)->dbl + DBL_PTR(_unix_3904)->dbl);
    _1973 = _12secondsToDateTime(_1972);
    _1972 = NOVALUE;
    DeRef(_unix_3904);
    return _1973;
    ;
}


int  __stdcall _12format(int _d_3909, int _pattern_3910)
{
    int _in_fmt_3912 = NOVALUE;
    int _ch_3913 = NOVALUE;
    int _tmp_3914 = NOVALUE;
    int _res_3915 = NOVALUE;
    int _weeks_day_4__tmp_at67_3931 = NOVALUE;
    int _weeks_day_3__tmp_at67_3930 = NOVALUE;
    int _weeks_day_2__tmp_at67_3929 = NOVALUE;
    int _weeks_day_1__tmp_at67_3928 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_67_3927 = NOVALUE;
    int _weeks_day_4__tmp_at113_3941 = NOVALUE;
    int _weeks_day_3__tmp_at113_3940 = NOVALUE;
    int _weeks_day_2__tmp_at113_3939 = NOVALUE;
    int _weeks_day_1__tmp_at113_3938 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_113_3937 = NOVALUE;
    int _to_unix_1__tmp_at584_4046 = NOVALUE;
    int _to_unix_inlined_to_unix_at_584_4045 = NOVALUE;
    int _weeks_day_4__tmp_at639_4063 = NOVALUE;
    int _weeks_day_3__tmp_at639_4062 = NOVALUE;
    int _weeks_day_2__tmp_at639_4061 = NOVALUE;
    int _weeks_day_1__tmp_at639_4060 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_639_4059 = NOVALUE;
    int _weeks_day_4__tmp_at681_4074 = NOVALUE;
    int _weeks_day_3__tmp_at681_4073 = NOVALUE;
    int _weeks_day_2__tmp_at681_4072 = NOVALUE;
    int _weeks_day_1__tmp_at681_4071 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_681_4070 = NOVALUE;
    int _weeks_day_4__tmp_at730_4086 = NOVALUE;
    int _weeks_day_3__tmp_at730_4085 = NOVALUE;
    int _weeks_day_2__tmp_at730_4084 = NOVALUE;
    int _weeks_day_1__tmp_at730_4083 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_730_4082 = NOVALUE;
    int _2096 = NOVALUE;
    int _2095 = NOVALUE;
    int _2090 = NOVALUE;
    int _2089 = NOVALUE;
    int _2088 = NOVALUE;
    int _2087 = NOVALUE;
    int _2085 = NOVALUE;
    int _2081 = NOVALUE;
    int _2080 = NOVALUE;
    int _2076 = NOVALUE;
    int _2075 = NOVALUE;
    int _2068 = NOVALUE;
    int _2067 = NOVALUE;
    int _2063 = NOVALUE;
    int _2059 = NOVALUE;
    int _2058 = NOVALUE;
    int _2056 = NOVALUE;
    int _2055 = NOVALUE;
    int _2053 = NOVALUE;
    int _2049 = NOVALUE;
    int _2047 = NOVALUE;
    int _2045 = NOVALUE;
    int _2041 = NOVALUE;
    int _2040 = NOVALUE;
    int _2036 = NOVALUE;
    int _2035 = NOVALUE;
    int _2031 = NOVALUE;
    int _2023 = NOVALUE;
    int _2022 = NOVALUE;
    int _2018 = NOVALUE;
    int _2017 = NOVALUE;
    int _2013 = NOVALUE;
    int _2005 = NOVALUE;
    int _2004 = NOVALUE;
    int _2001 = NOVALUE;
    int _2000 = NOVALUE;
    int _1997 = NOVALUE;
    int _1996 = NOVALUE;
    int _1995 = NOVALUE;
    int _1991 = NOVALUE;
    int _1990 = NOVALUE;
    int _1987 = NOVALUE;
    int _1986 = NOVALUE;
    int _1983 = NOVALUE;
    int _1980 = NOVALUE;
    int _1975 = NOVALUE;
    int _0, _1, _2;
    

    /** 	in_fmt = 0*/
    _in_fmt_3912 = 0;

    /** 	res = ""*/
    RefDS(_5);
    DeRef(_res_3915);
    _res_3915 = _5;

    /** 	for i = 1 to length(pattern) do*/
    if (IS_SEQUENCE(_pattern_3910)){
            _1975 = SEQ_PTR(_pattern_3910)->length;
    }
    else {
        _1975 = 1;
    }
    {
        int _i_3917;
        _i_3917 = 1;
L1: 
        if (_i_3917 > _1975){
            goto L2; // [20] 869
        }

        /** 		ch = pattern[i]*/
        _2 = (int)SEQ_PTR(_pattern_3910);
        _ch_3913 = (int)*(((s1_ptr)_2)->base + _i_3917);
        if (!IS_ATOM_INT(_ch_3913))
        _ch_3913 = (long)DBL_PTR(_ch_3913)->dbl;

        /** 		if in_fmt then*/
        if (_in_fmt_3912 == 0)
        {
            goto L3; // [35] 841
        }
        else{
        }

        /** 			in_fmt = 0*/
        _in_fmt_3912 = 0;

        /** 			if ch = '%' then*/
        if (_ch_3913 != 37)
        goto L4; // [45] 58

        /** 				res &= '%'*/
        Append(&_res_3915, _res_3915, 37);
        goto L5; // [55] 862
L4: 

        /** 			elsif ch = 'a' then*/
        if (_ch_3913 != 97)
        goto L6; // [60] 104

        /** 				res &= day_abbrs[weeks_day(d)]*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3909);
        _0 = _weeks_day_1__tmp_at67_3928;
        _weeks_day_1__tmp_at67_3928 = _12julianDay(_d_3909);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at67_3929);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at67_3928)) {
            _weeks_day_2__tmp_at67_3929 = _weeks_day_1__tmp_at67_3928 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at67_3929 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at67_3929 = NewDouble((double)_weeks_day_2__tmp_at67_3929);
            }
        }
        else {
            _weeks_day_2__tmp_at67_3929 = binary_op(MINUS, _weeks_day_1__tmp_at67_3928, 1);
        }
        DeRef(_weeks_day_3__tmp_at67_3930);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at67_3929)) {
            _weeks_day_3__tmp_at67_3930 = _weeks_day_2__tmp_at67_3929 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at67_3930 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at67_3930 = NewDouble((double)_weeks_day_3__tmp_at67_3930);
        }
        else {
            _weeks_day_3__tmp_at67_3930 = binary_op(PLUS, _weeks_day_2__tmp_at67_3929, 4094);
        }
        DeRef(_weeks_day_4__tmp_at67_3931);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at67_3930)) {
            _weeks_day_4__tmp_at67_3931 = (_weeks_day_3__tmp_at67_3930 % 7);
        }
        else {
            _weeks_day_4__tmp_at67_3931 = binary_op(REMAINDER, _weeks_day_3__tmp_at67_3930, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_67_3927);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at67_3931)) {
            _weeks_day_inlined_weeks_day_at_67_3927 = _weeks_day_4__tmp_at67_3931 + 1;
            if (_weeks_day_inlined_weeks_day_at_67_3927 > MAXINT){
                _weeks_day_inlined_weeks_day_at_67_3927 = NewDouble((double)_weeks_day_inlined_weeks_day_at_67_3927);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_67_3927 = binary_op(PLUS, 1, _weeks_day_4__tmp_at67_3931);
        DeRef(_weeks_day_1__tmp_at67_3928);
        _weeks_day_1__tmp_at67_3928 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at67_3929);
        _weeks_day_2__tmp_at67_3929 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at67_3930);
        _weeks_day_3__tmp_at67_3930 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at67_3931);
        _weeks_day_4__tmp_at67_3931 = NOVALUE;
        _2 = (int)SEQ_PTR(_12day_abbrs_3709);
        if (!IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_67_3927)){
            _1980 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_weeks_day_inlined_weeks_day_at_67_3927)->dbl));
        }
        else{
            _1980 = (int)*(((s1_ptr)_2)->base + _weeks_day_inlined_weeks_day_at_67_3927);
        }
        Concat((object_ptr)&_res_3915, _res_3915, _1980);
        _1980 = NOVALUE;
        goto L5; // [101] 862
L6: 

        /** 			elsif ch = 'A' then*/
        if (_ch_3913 != 65)
        goto L7; // [106] 150

        /** 				res &= day_names[weeks_day(d)]*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3909);
        _0 = _weeks_day_1__tmp_at113_3938;
        _weeks_day_1__tmp_at113_3938 = _12julianDay(_d_3909);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at113_3939);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at113_3938)) {
            _weeks_day_2__tmp_at113_3939 = _weeks_day_1__tmp_at113_3938 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at113_3939 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at113_3939 = NewDouble((double)_weeks_day_2__tmp_at113_3939);
            }
        }
        else {
            _weeks_day_2__tmp_at113_3939 = binary_op(MINUS, _weeks_day_1__tmp_at113_3938, 1);
        }
        DeRef(_weeks_day_3__tmp_at113_3940);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at113_3939)) {
            _weeks_day_3__tmp_at113_3940 = _weeks_day_2__tmp_at113_3939 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at113_3940 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at113_3940 = NewDouble((double)_weeks_day_3__tmp_at113_3940);
        }
        else {
            _weeks_day_3__tmp_at113_3940 = binary_op(PLUS, _weeks_day_2__tmp_at113_3939, 4094);
        }
        DeRef(_weeks_day_4__tmp_at113_3941);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at113_3940)) {
            _weeks_day_4__tmp_at113_3941 = (_weeks_day_3__tmp_at113_3940 % 7);
        }
        else {
            _weeks_day_4__tmp_at113_3941 = binary_op(REMAINDER, _weeks_day_3__tmp_at113_3940, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_113_3937);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at113_3941)) {
            _weeks_day_inlined_weeks_day_at_113_3937 = _weeks_day_4__tmp_at113_3941 + 1;
            if (_weeks_day_inlined_weeks_day_at_113_3937 > MAXINT){
                _weeks_day_inlined_weeks_day_at_113_3937 = NewDouble((double)_weeks_day_inlined_weeks_day_at_113_3937);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_113_3937 = binary_op(PLUS, 1, _weeks_day_4__tmp_at113_3941);
        DeRef(_weeks_day_1__tmp_at113_3938);
        _weeks_day_1__tmp_at113_3938 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at113_3939);
        _weeks_day_2__tmp_at113_3939 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at113_3940);
        _weeks_day_3__tmp_at113_3940 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at113_3941);
        _weeks_day_4__tmp_at113_3941 = NOVALUE;
        _2 = (int)SEQ_PTR(_12day_names_3700);
        if (!IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_113_3937)){
            _1983 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_weeks_day_inlined_weeks_day_at_113_3937)->dbl));
        }
        else{
            _1983 = (int)*(((s1_ptr)_2)->base + _weeks_day_inlined_weeks_day_at_113_3937);
        }
        Concat((object_ptr)&_res_3915, _res_3915, _1983);
        _1983 = NOVALUE;
        goto L5; // [147] 862
L7: 

        /** 			elsif ch = 'b' then*/
        if (_ch_3913 != 98)
        goto L8; // [152] 175

        /** 				res &= month_abbrs[d[MONTH]]*/
        _2 = (int)SEQ_PTR(_d_3909);
        _1986 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_12month_abbrs_3687);
        if (!IS_ATOM_INT(_1986)){
            _1987 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1986)->dbl));
        }
        else{
            _1987 = (int)*(((s1_ptr)_2)->base + _1986);
        }
        Concat((object_ptr)&_res_3915, _res_3915, _1987);
        _1987 = NOVALUE;
        goto L5; // [172] 862
L8: 

        /** 			elsif ch = 'B' then*/
        if (_ch_3913 != 66)
        goto L9; // [177] 200

        /** 				res &= month_names[d[MONTH]]*/
        _2 = (int)SEQ_PTR(_d_3909);
        _1990 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_12month_names_3673);
        if (!IS_ATOM_INT(_1990)){
            _1991 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1990)->dbl));
        }
        else{
            _1991 = (int)*(((s1_ptr)_2)->base + _1990);
        }
        Concat((object_ptr)&_res_3915, _res_3915, _1991);
        _1991 = NOVALUE;
        goto L5; // [197] 862
L9: 

        /** 			elsif ch = 'C' then*/
        if (_ch_3913 != 67)
        goto LA; // [202] 227

        /** 				res &= sprintf("%02d", d[YEAR] / 100)*/
        _2 = (int)SEQ_PTR(_d_3909);
        _1995 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_1995)) {
            _1996 = (_1995 % 100) ? NewDouble((double)_1995 / 100) : (_1995 / 100);
        }
        else {
            _1996 = binary_op(DIVIDE, _1995, 100);
        }
        _1995 = NOVALUE;
        _1997 = EPrintf(-9999999, _1994, _1996);
        DeRef(_1996);
        _1996 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _1997);
        DeRefDS(_1997);
        _1997 = NOVALUE;
        goto L5; // [224] 862
LA: 

        /** 			elsif ch = 'd' then*/
        if (_ch_3913 != 100)
        goto LB; // [229] 250

        /** 				res &= sprintf("%02d", d[DAY])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2000 = (int)*(((s1_ptr)_2)->base + 3);
        _2001 = EPrintf(-9999999, _1994, _2000);
        _2000 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2001);
        DeRefDS(_2001);
        _2001 = NOVALUE;
        goto L5; // [247] 862
LB: 

        /** 			elsif ch = 'H' then*/
        if (_ch_3913 != 72)
        goto LC; // [252] 273

        /** 				res &= sprintf("%02d", d[HOUR])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2004 = (int)*(((s1_ptr)_2)->base + 4);
        _2005 = EPrintf(-9999999, _1994, _2004);
        _2004 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2005);
        DeRefDS(_2005);
        _2005 = NOVALUE;
        goto L5; // [270] 862
LC: 

        /** 			elsif ch = 'I' then*/
        if (_ch_3913 != 73)
        goto LD; // [275] 328

        /** 				tmp = d[HOUR]*/
        _2 = (int)SEQ_PTR(_d_3909);
        _tmp_3914 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_tmp_3914)){
            _tmp_3914 = (long)DBL_PTR(_tmp_3914)->dbl;
        }

        /** 				if tmp > 12 then*/
        if (_tmp_3914 <= 12)
        goto LE; // [289] 302

        /** 					tmp -= 12*/
        _tmp_3914 = _tmp_3914 - 12;
        goto LF; // [299] 315
LE: 

        /** 				elsif tmp = 0 then*/
        if (_tmp_3914 != 0)
        goto L10; // [304] 314

        /** 					tmp = 12*/
        _tmp_3914 = 12;
L10: 
LF: 

        /** 				res &= sprintf("%02d", tmp)*/
        _2013 = EPrintf(-9999999, _1994, _tmp_3914);
        Concat((object_ptr)&_res_3915, _res_3915, _2013);
        DeRefDS(_2013);
        _2013 = NOVALUE;
        goto L5; // [325] 862
LD: 

        /** 			elsif ch = 'j' then*/
        if (_ch_3913 != 106)
        goto L11; // [330] 351

        /** 				res &= sprintf("%d", julianDayOfYear(d))*/
        Ref(_d_3909);
        _2017 = _12julianDayOfYear(_d_3909);
        _2018 = EPrintf(-9999999, _919, _2017);
        DeRef(_2017);
        _2017 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2018);
        DeRefDS(_2018);
        _2018 = NOVALUE;
        goto L5; // [348] 862
L11: 

        /** 			elsif ch = 'k' then*/
        if (_ch_3913 != 107)
        goto L12; // [353] 374

        /** 				res &= sprintf("%d", d[HOUR])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2022 = (int)*(((s1_ptr)_2)->base + 4);
        _2023 = EPrintf(-9999999, _919, _2022);
        _2022 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2023);
        DeRefDS(_2023);
        _2023 = NOVALUE;
        goto L5; // [371] 862
L12: 

        /** 			elsif ch = 'l' then*/
        if (_ch_3913 != 108)
        goto L13; // [376] 429

        /** 				tmp = d[HOUR]*/
        _2 = (int)SEQ_PTR(_d_3909);
        _tmp_3914 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_tmp_3914)){
            _tmp_3914 = (long)DBL_PTR(_tmp_3914)->dbl;
        }

        /** 				if tmp > 12 then*/
        if (_tmp_3914 <= 12)
        goto L14; // [390] 403

        /** 					tmp -= 12*/
        _tmp_3914 = _tmp_3914 - 12;
        goto L15; // [400] 416
L14: 

        /** 				elsif tmp = 0 then*/
        if (_tmp_3914 != 0)
        goto L16; // [405] 415

        /** 					tmp = 12*/
        _tmp_3914 = 12;
L16: 
L15: 

        /** 				res &= sprintf("%d", tmp)*/
        _2031 = EPrintf(-9999999, _919, _tmp_3914);
        Concat((object_ptr)&_res_3915, _res_3915, _2031);
        DeRefDS(_2031);
        _2031 = NOVALUE;
        goto L5; // [426] 862
L13: 

        /** 			elsif ch = 'm' then*/
        if (_ch_3913 != 109)
        goto L17; // [431] 452

        /** 				res &= sprintf("%02d", d[MONTH])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2035 = (int)*(((s1_ptr)_2)->base + 2);
        _2036 = EPrintf(-9999999, _1994, _2035);
        _2035 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2036);
        DeRefDS(_2036);
        _2036 = NOVALUE;
        goto L5; // [449] 862
L17: 

        /** 			elsif ch = 'M' then*/
        if (_ch_3913 != 77)
        goto L18; // [454] 475

        /** 				res &= sprintf("%02d", d[MINUTE])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2040 = (int)*(((s1_ptr)_2)->base + 5);
        _2041 = EPrintf(-9999999, _1994, _2040);
        _2040 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2041);
        DeRefDS(_2041);
        _2041 = NOVALUE;
        goto L5; // [472] 862
L18: 

        /** 			elsif ch = 'p' then*/
        if (_ch_3913 != 112)
        goto L19; // [477] 522

        /** 				if d[HOUR] <= 12 then*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2045 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(GREATER, _2045, 12)){
            _2045 = NOVALUE;
            goto L1A; // [487] 506
        }
        _2045 = NOVALUE;

        /** 					res &= ampm[1]*/
        _2 = (int)SEQ_PTR(_12ampm_3718);
        _2047 = (int)*(((s1_ptr)_2)->base + 1);
        Concat((object_ptr)&_res_3915, _res_3915, _2047);
        _2047 = NOVALUE;
        goto L5; // [503] 862
L1A: 

        /** 					res &= ampm[2]*/
        _2 = (int)SEQ_PTR(_12ampm_3718);
        _2049 = (int)*(((s1_ptr)_2)->base + 2);
        Concat((object_ptr)&_res_3915, _res_3915, _2049);
        _2049 = NOVALUE;
        goto L5; // [519] 862
L19: 

        /** 			elsif ch = 'P' then*/
        if (_ch_3913 != 80)
        goto L1B; // [524] 577

        /** 				if d[HOUR] <= 12 then*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2053 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(GREATER, _2053, 12)){
            _2053 = NOVALUE;
            goto L1C; // [534] 557
        }
        _2053 = NOVALUE;

        /** 					res &= tolower(ampm[1])*/
        _2 = (int)SEQ_PTR(_12ampm_3718);
        _2055 = (int)*(((s1_ptr)_2)->base + 1);
        RefDS(_2055);
        _2056 = _12tolower(_2055);
        _2055 = NOVALUE;
        if (IS_SEQUENCE(_res_3915) && IS_ATOM(_2056)) {
            Ref(_2056);
            Append(&_res_3915, _res_3915, _2056);
        }
        else if (IS_ATOM(_res_3915) && IS_SEQUENCE(_2056)) {
        }
        else {
            Concat((object_ptr)&_res_3915, _res_3915, _2056);
        }
        DeRef(_2056);
        _2056 = NOVALUE;
        goto L5; // [554] 862
L1C: 

        /** 					res &= tolower(ampm[2])*/
        _2 = (int)SEQ_PTR(_12ampm_3718);
        _2058 = (int)*(((s1_ptr)_2)->base + 2);
        RefDS(_2058);
        _2059 = _12tolower(_2058);
        _2058 = NOVALUE;
        if (IS_SEQUENCE(_res_3915) && IS_ATOM(_2059)) {
            Ref(_2059);
            Append(&_res_3915, _res_3915, _2059);
        }
        else if (IS_ATOM(_res_3915) && IS_SEQUENCE(_2059)) {
        }
        else {
            Concat((object_ptr)&_res_3915, _res_3915, _2059);
        }
        DeRef(_2059);
        _2059 = NOVALUE;
        goto L5; // [574] 862
L1B: 

        /** 			elsif ch = 's' then*/
        if (_ch_3913 != 115)
        goto L1D; // [579] 609

        /** 				res &= sprintf("%d", to_unix(d))*/

        /** 	return datetimeToSeconds(dt) - EPOCH_1970*/
        Ref(_d_3909);
        _0 = _to_unix_1__tmp_at584_4046;
        _to_unix_1__tmp_at584_4046 = _12datetimeToSeconds(_d_3909);
        DeRef(_0);
        DeRef(_to_unix_inlined_to_unix_at_584_4045);
        _to_unix_inlined_to_unix_at_584_4045 = binary_op(MINUS, _to_unix_1__tmp_at584_4046, _12EPOCH_1970_3464);
        DeRef(_to_unix_1__tmp_at584_4046);
        _to_unix_1__tmp_at584_4046 = NOVALUE;
        _2063 = EPrintf(-9999999, _919, _to_unix_inlined_to_unix_at_584_4045);
        Concat((object_ptr)&_res_3915, _res_3915, _2063);
        DeRefDS(_2063);
        _2063 = NOVALUE;
        goto L5; // [606] 862
L1D: 

        /** 			elsif ch = 'S' then*/
        if (_ch_3913 != 83)
        goto L1E; // [611] 632

        /** 				res &= sprintf("%02d", d[SECOND])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2067 = (int)*(((s1_ptr)_2)->base + 6);
        _2068 = EPrintf(-9999999, _1994, _2067);
        _2067 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2068);
        DeRefDS(_2068);
        _2068 = NOVALUE;
        goto L5; // [629] 862
L1E: 

        /** 			elsif ch = 'u' then*/
        if (_ch_3913 != 117)
        goto L1F; // [634] 723

        /** 				tmp = weeks_day(d)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3909);
        _0 = _weeks_day_1__tmp_at639_4060;
        _weeks_day_1__tmp_at639_4060 = _12julianDay(_d_3909);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at639_4061);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at639_4060)) {
            _weeks_day_2__tmp_at639_4061 = _weeks_day_1__tmp_at639_4060 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at639_4061 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at639_4061 = NewDouble((double)_weeks_day_2__tmp_at639_4061);
            }
        }
        else {
            _weeks_day_2__tmp_at639_4061 = binary_op(MINUS, _weeks_day_1__tmp_at639_4060, 1);
        }
        DeRef(_weeks_day_3__tmp_at639_4062);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at639_4061)) {
            _weeks_day_3__tmp_at639_4062 = _weeks_day_2__tmp_at639_4061 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at639_4062 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at639_4062 = NewDouble((double)_weeks_day_3__tmp_at639_4062);
        }
        else {
            _weeks_day_3__tmp_at639_4062 = binary_op(PLUS, _weeks_day_2__tmp_at639_4061, 4094);
        }
        DeRef(_weeks_day_4__tmp_at639_4063);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at639_4062)) {
            _weeks_day_4__tmp_at639_4063 = (_weeks_day_3__tmp_at639_4062 % 7);
        }
        else {
            _weeks_day_4__tmp_at639_4063 = binary_op(REMAINDER, _weeks_day_3__tmp_at639_4062, 7);
        }
        if (IS_ATOM_INT(_weeks_day_4__tmp_at639_4063)) {
            _tmp_3914 = _weeks_day_4__tmp_at639_4063 + 1;
        }
        else
        { // coercing _tmp_3914 to an integer 1
            _tmp_3914 = binary_op(PLUS, 1, _weeks_day_4__tmp_at639_4063);
            if( !IS_ATOM_INT(_tmp_3914) ){
                _tmp_3914 = (object)DBL_PTR(_tmp_3914)->dbl;
            }
        }
        DeRef(_weeks_day_1__tmp_at639_4060);
        _weeks_day_1__tmp_at639_4060 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at639_4061);
        _weeks_day_2__tmp_at639_4061 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at639_4062);
        _weeks_day_3__tmp_at639_4062 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at639_4063);
        _weeks_day_4__tmp_at639_4063 = NOVALUE;

        /** 				if tmp = 1 then*/
        if (_tmp_3914 != 1)
        goto L20; // [667] 680

        /** 					res &= "7" -- Sunday*/
        Concat((object_ptr)&_res_3915, _res_3915, _2073);
        goto L5; // [677] 862
L20: 

        /** 					res &= sprintf("%d", weeks_day(d) - 1)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3909);
        _0 = _weeks_day_1__tmp_at681_4071;
        _weeks_day_1__tmp_at681_4071 = _12julianDay(_d_3909);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at681_4072);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at681_4071)) {
            _weeks_day_2__tmp_at681_4072 = _weeks_day_1__tmp_at681_4071 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at681_4072 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at681_4072 = NewDouble((double)_weeks_day_2__tmp_at681_4072);
            }
        }
        else {
            _weeks_day_2__tmp_at681_4072 = binary_op(MINUS, _weeks_day_1__tmp_at681_4071, 1);
        }
        DeRef(_weeks_day_3__tmp_at681_4073);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at681_4072)) {
            _weeks_day_3__tmp_at681_4073 = _weeks_day_2__tmp_at681_4072 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at681_4073 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at681_4073 = NewDouble((double)_weeks_day_3__tmp_at681_4073);
        }
        else {
            _weeks_day_3__tmp_at681_4073 = binary_op(PLUS, _weeks_day_2__tmp_at681_4072, 4094);
        }
        DeRef(_weeks_day_4__tmp_at681_4074);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at681_4073)) {
            _weeks_day_4__tmp_at681_4074 = (_weeks_day_3__tmp_at681_4073 % 7);
        }
        else {
            _weeks_day_4__tmp_at681_4074 = binary_op(REMAINDER, _weeks_day_3__tmp_at681_4073, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_681_4070);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at681_4074)) {
            _weeks_day_inlined_weeks_day_at_681_4070 = _weeks_day_4__tmp_at681_4074 + 1;
            if (_weeks_day_inlined_weeks_day_at_681_4070 > MAXINT){
                _weeks_day_inlined_weeks_day_at_681_4070 = NewDouble((double)_weeks_day_inlined_weeks_day_at_681_4070);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_681_4070 = binary_op(PLUS, 1, _weeks_day_4__tmp_at681_4074);
        DeRef(_weeks_day_1__tmp_at681_4071);
        _weeks_day_1__tmp_at681_4071 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at681_4072);
        _weeks_day_2__tmp_at681_4072 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at681_4073);
        _weeks_day_3__tmp_at681_4073 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at681_4074);
        _weeks_day_4__tmp_at681_4074 = NOVALUE;
        if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_681_4070)) {
            _2075 = _weeks_day_inlined_weeks_day_at_681_4070 - 1;
            if ((long)((unsigned long)_2075 +(unsigned long) HIGH_BITS) >= 0){
                _2075 = NewDouble((double)_2075);
            }
        }
        else {
            _2075 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_681_4070, 1);
        }
        _2076 = EPrintf(-9999999, _919, _2075);
        DeRef(_2075);
        _2075 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2076);
        DeRefDS(_2076);
        _2076 = NOVALUE;
        goto L5; // [720] 862
L1F: 

        /** 			elsif ch = 'w' then*/
        if (_ch_3913 != 119)
        goto L21; // [725] 771

        /** 				res &= sprintf("%d", weeks_day(d) - 1)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3909);
        _0 = _weeks_day_1__tmp_at730_4083;
        _weeks_day_1__tmp_at730_4083 = _12julianDay(_d_3909);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at730_4084);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at730_4083)) {
            _weeks_day_2__tmp_at730_4084 = _weeks_day_1__tmp_at730_4083 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at730_4084 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at730_4084 = NewDouble((double)_weeks_day_2__tmp_at730_4084);
            }
        }
        else {
            _weeks_day_2__tmp_at730_4084 = binary_op(MINUS, _weeks_day_1__tmp_at730_4083, 1);
        }
        DeRef(_weeks_day_3__tmp_at730_4085);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at730_4084)) {
            _weeks_day_3__tmp_at730_4085 = _weeks_day_2__tmp_at730_4084 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at730_4085 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at730_4085 = NewDouble((double)_weeks_day_3__tmp_at730_4085);
        }
        else {
            _weeks_day_3__tmp_at730_4085 = binary_op(PLUS, _weeks_day_2__tmp_at730_4084, 4094);
        }
        DeRef(_weeks_day_4__tmp_at730_4086);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at730_4085)) {
            _weeks_day_4__tmp_at730_4086 = (_weeks_day_3__tmp_at730_4085 % 7);
        }
        else {
            _weeks_day_4__tmp_at730_4086 = binary_op(REMAINDER, _weeks_day_3__tmp_at730_4085, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_730_4082);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at730_4086)) {
            _weeks_day_inlined_weeks_day_at_730_4082 = _weeks_day_4__tmp_at730_4086 + 1;
            if (_weeks_day_inlined_weeks_day_at_730_4082 > MAXINT){
                _weeks_day_inlined_weeks_day_at_730_4082 = NewDouble((double)_weeks_day_inlined_weeks_day_at_730_4082);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_730_4082 = binary_op(PLUS, 1, _weeks_day_4__tmp_at730_4086);
        DeRef(_weeks_day_1__tmp_at730_4083);
        _weeks_day_1__tmp_at730_4083 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at730_4084);
        _weeks_day_2__tmp_at730_4084 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at730_4085);
        _weeks_day_3__tmp_at730_4085 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at730_4086);
        _weeks_day_4__tmp_at730_4086 = NOVALUE;
        if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_730_4082)) {
            _2080 = _weeks_day_inlined_weeks_day_at_730_4082 - 1;
            if ((long)((unsigned long)_2080 +(unsigned long) HIGH_BITS) >= 0){
                _2080 = NewDouble((double)_2080);
            }
        }
        else {
            _2080 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_730_4082, 1);
        }
        _2081 = EPrintf(-9999999, _919, _2080);
        DeRef(_2080);
        _2080 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2081);
        DeRefDS(_2081);
        _2081 = NOVALUE;
        goto L5; // [768] 862
L21: 

        /** 			elsif ch = 'y' then*/
        if (_ch_3913 != 121)
        goto L22; // [773] 814

        /** 			   tmp = floor(d[YEAR] / 100)*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2085 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2085)) {
            if (100 > 0 && _2085 >= 0) {
                _tmp_3914 = _2085 / 100;
            }
            else {
                temp_dbl = floor((double)_2085 / (double)100);
                _tmp_3914 = (long)temp_dbl;
            }
        }
        else {
            _2 = binary_op(DIVIDE, _2085, 100);
            _tmp_3914 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _2085 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_3914)) {
            _1 = (long)(DBL_PTR(_tmp_3914)->dbl);
            DeRefDS(_tmp_3914);
            _tmp_3914 = _1;
        }

        /** 			   res &= sprintf("%02d", d[YEAR] - (tmp * 100))*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2087 = (int)*(((s1_ptr)_2)->base + 1);
        if (_tmp_3914 == (short)_tmp_3914)
        _2088 = _tmp_3914 * 100;
        else
        _2088 = NewDouble(_tmp_3914 * (double)100);
        if (IS_ATOM_INT(_2087) && IS_ATOM_INT(_2088)) {
            _2089 = _2087 - _2088;
            if ((long)((unsigned long)_2089 +(unsigned long) HIGH_BITS) >= 0){
                _2089 = NewDouble((double)_2089);
            }
        }
        else {
            _2089 = binary_op(MINUS, _2087, _2088);
        }
        _2087 = NOVALUE;
        DeRef(_2088);
        _2088 = NOVALUE;
        _2090 = EPrintf(-9999999, _1994, _2089);
        DeRef(_2089);
        _2089 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2090);
        DeRefDS(_2090);
        _2090 = NOVALUE;
        goto L5; // [811] 862
L22: 

        /** 			elsif ch = 'Y' then*/
        if (_ch_3913 != 89)
        goto L5; // [816] 862

        /** 				res &= sprintf("%04d", d[YEAR])*/
        _2 = (int)SEQ_PTR(_d_3909);
        _2095 = (int)*(((s1_ptr)_2)->base + 1);
        _2096 = EPrintf(-9999999, _2094, _2095);
        _2095 = NOVALUE;
        Concat((object_ptr)&_res_3915, _res_3915, _2096);
        DeRefDS(_2096);
        _2096 = NOVALUE;
        goto L5; // [834] 862
        goto L5; // [838] 862
L3: 

        /** 		elsif ch = '%' then*/
        if (_ch_3913 != 37)
        goto L23; // [843] 855

        /** 			in_fmt = 1*/
        _in_fmt_3912 = 1;
        goto L5; // [852] 862
L23: 

        /** 			res &= ch*/
        Append(&_res_3915, _res_3915, _ch_3913);
L5: 

        /** 	end for*/
        _i_3917 = _i_3917 + 1;
        goto L1; // [864] 27
L2: 
        ;
    }

    /** 	return res*/
    DeRef(_d_3909);
    DeRefDS(_pattern_3910);
    _1986 = NOVALUE;
    _1990 = NOVALUE;
    return _res_3915;
    ;
}


int  __stdcall _12parse(int _val_4118, int _fmt_4119, int _yylower_4120)
{
    int _fpos_4122 = NOVALUE;
    int _spos_4123 = NOVALUE;
    int _maxlen_4124 = NOVALUE;
    int _rpos_4125 = NOVALUE;
    int _res_4126 = NOVALUE;
    int _got_4147 = NOVALUE;
    int _epos_4148 = NOVALUE;
    int _value_inlined_value_at_335_4175 = NOVALUE;
    int _st_inlined_value_at_332_4174 = NOVALUE;
    int _century_4182 = NOVALUE;
    int _year_4186 = NOVALUE;
    int _2159 = NOVALUE;
    int _2158 = NOVALUE;
    int _2157 = NOVALUE;
    int _2156 = NOVALUE;
    int _2155 = NOVALUE;
    int _2154 = NOVALUE;
    int _2153 = NOVALUE;
    int _2151 = NOVALUE;
    int _2150 = NOVALUE;
    int _2148 = NOVALUE;
    int _2146 = NOVALUE;
    int _2144 = NOVALUE;
    int _2142 = NOVALUE;
    int _2140 = NOVALUE;
    int _2139 = NOVALUE;
    int _2137 = NOVALUE;
    int _2136 = NOVALUE;
    int _2134 = NOVALUE;
    int _2133 = NOVALUE;
    int _2131 = NOVALUE;
    int _2129 = NOVALUE;
    int _2128 = NOVALUE;
    int _2127 = NOVALUE;
    int _2125 = NOVALUE;
    int _2122 = NOVALUE;
    int _2121 = NOVALUE;
    int _2120 = NOVALUE;
    int _2119 = NOVALUE;
    int _2118 = NOVALUE;
    int _2117 = NOVALUE;
    int _2116 = NOVALUE;
    int _2113 = NOVALUE;
    int _2112 = NOVALUE;
    int _2110 = NOVALUE;
    int _2107 = NOVALUE;
    int _2104 = NOVALUE;
    int _2102 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_yylower_4120)) {
        _1 = (long)(DBL_PTR(_yylower_4120)->dbl);
        DeRefDS(_yylower_4120);
        _yylower_4120 = _1;
    }

    /** 	integer fpos = 1, spos = 1, maxlen, rpos */
    _fpos_4122 = 1;
    _spos_4123 = 1;

    /** 	sequence res = {0,0,0,0,0,0}*/
    _0 = _res_4126;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _res_4126 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	while fpos <= length(fmt) do*/
L1: 
    if (IS_SEQUENCE(_fmt_4119)){
            _2102 = SEQ_PTR(_fmt_4119)->length;
    }
    else {
        _2102 = 1;
    }
    if (_fpos_4122 > _2102)
    goto L2; // [34] 482

    /** 		if fmt[fpos] = '%' then*/
    _2 = (int)SEQ_PTR(_fmt_4119);
    _2104 = (int)*(((s1_ptr)_2)->base + _fpos_4122);
    if (binary_op_a(NOTEQ, _2104, 37)){
        _2104 = NOVALUE;
        goto L3; // [44] 471
    }
    _2104 = NOVALUE;

    /** 			fpos += 1*/
    _fpos_4122 = _fpos_4122 + 1;

    /** 			switch fmt[fpos] do*/
    _2 = (int)SEQ_PTR(_fmt_4119);
    _2107 = (int)*(((s1_ptr)_2)->base + _fpos_4122);
    if (IS_SEQUENCE(_2107) ){
        goto L4; // [60] 179
    }
    if(!IS_ATOM_INT(_2107)){
        if( (DBL_PTR(_2107)->dbl != (double) ((int) DBL_PTR(_2107)->dbl) ) ){
            goto L4; // [60] 179
        }
        _0 = (int) DBL_PTR(_2107)->dbl;
    }
    else {
        _0 = _2107;
    };
    _2107 = NOVALUE;
    switch ( _0 ){ 

        /** 				case 'Y' then*/
        case 89:

        /** 					rpos = 1*/
        _rpos_4125 = 1;

        /** 					maxlen = 4*/
        _maxlen_4124 = 4;
        goto L5; // [79] 187

        /** 				case 'y' then*/
        case 121:

        /** 					rpos = 1*/
        _rpos_4125 = 1;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [95] 187

        /** 				case 'm' then*/
        case 109:

        /** 					rpos = 2*/
        _rpos_4125 = 2;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [111] 187

        /** 				case 'd' then*/
        case 100:

        /** 					rpos = 3*/
        _rpos_4125 = 3;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [127] 187

        /** 				case 'H' then*/
        case 72:

        /** 					rpos = 4*/
        _rpos_4125 = 4;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [143] 187

        /** 				case 'M' then*/
        case 77:

        /** 					rpos = 5*/
        _rpos_4125 = 5;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [159] 187

        /** 				case 'S' then*/
        case 83:

        /** 					rpos = 6*/
        _rpos_4125 = 6;

        /** 					maxlen = 2*/
        _maxlen_4124 = 2;
        goto L5; // [175] 187

        /** 				case else*/
        default:
L4: 

        /** 					rpos = 0*/
        _rpos_4125 = 0;
    ;}L5: 

    /** 			if rpos then*/
    if (_rpos_4125 == 0)
    {
        goto L6; // [191] 468
    }
    else{
    }

    /** 				sequence got*/

    /** 				integer epos*/

    /** 				while spos <= length(val) do*/
L7: 
    if (IS_SEQUENCE(_val_4118)){
            _2110 = SEQ_PTR(_val_4118)->length;
    }
    else {
        _2110 = 1;
    }
    if (_spos_4123 > _2110)
    goto L8; // [206] 239

    /** 					if types:t_digit(val[spos]) then*/
    _2 = (int)SEQ_PTR(_val_4118);
    _2112 = (int)*(((s1_ptr)_2)->base + _spos_4123);
    Ref(_2112);
    _2113 = _7t_digit(_2112);
    _2112 = NOVALUE;
    if (_2113 == 0) {
        DeRef(_2113);
        _2113 = NOVALUE;
        goto L9; // [220] 228
    }
    else {
        if (!IS_ATOM_INT(_2113) && DBL_PTR(_2113)->dbl == 0.0){
            DeRef(_2113);
            _2113 = NOVALUE;
            goto L9; // [220] 228
        }
        DeRef(_2113);
        _2113 = NOVALUE;
    }
    DeRef(_2113);
    _2113 = NOVALUE;

    /** 						exit*/
    goto L8; // [225] 239
L9: 

    /** 					spos += 1*/
    _spos_4123 = _spos_4123 + 1;

    /** 				end while*/
    goto L7; // [236] 203
L8: 

    /** 				epos = spos + 1*/
    _epos_4148 = _spos_4123 + 1;

    /** 				while epos <= length(val) and epos < spos + maxlen do*/
LA: 
    if (IS_SEQUENCE(_val_4118)){
            _2116 = SEQ_PTR(_val_4118)->length;
    }
    else {
        _2116 = 1;
    }
    _2117 = (_epos_4148 <= _2116);
    _2116 = NOVALUE;
    if (_2117 == 0) {
        goto LB; // [257] 304
    }
    _2119 = _spos_4123 + _maxlen_4124;
    if ((long)((unsigned long)_2119 + (unsigned long)HIGH_BITS) >= 0) 
    _2119 = NewDouble((double)_2119);
    if (IS_ATOM_INT(_2119)) {
        _2120 = (_epos_4148 < _2119);
    }
    else {
        _2120 = ((double)_epos_4148 < DBL_PTR(_2119)->dbl);
    }
    DeRef(_2119);
    _2119 = NOVALUE;
    if (_2120 == 0)
    {
        DeRef(_2120);
        _2120 = NOVALUE;
        goto LB; // [272] 304
    }
    else{
        DeRef(_2120);
        _2120 = NOVALUE;
    }

    /** 					if not types:t_digit(val[epos]) then*/
    _2 = (int)SEQ_PTR(_val_4118);
    _2121 = (int)*(((s1_ptr)_2)->base + _epos_4148);
    Ref(_2121);
    _2122 = _7t_digit(_2121);
    _2121 = NOVALUE;
    if (IS_ATOM_INT(_2122)) {
        if (_2122 != 0){
            DeRef(_2122);
            _2122 = NOVALUE;
            goto LC; // [285] 293
        }
    }
    else {
        if (DBL_PTR(_2122)->dbl != 0.0){
            DeRef(_2122);
            _2122 = NOVALUE;
            goto LC; // [285] 293
        }
    }
    DeRef(_2122);
    _2122 = NOVALUE;

    /** 						exit*/
    goto LB; // [290] 304
LC: 

    /** 					epos += 1*/
    _epos_4148 = _epos_4148 + 1;

    /** 				end while*/
    goto LA; // [301] 250
LB: 

    /** 				if spos > length(val) then*/
    if (IS_SEQUENCE(_val_4118)){
            _2125 = SEQ_PTR(_val_4118)->length;
    }
    else {
        _2125 = 1;
    }
    if (_spos_4123 <= _2125)
    goto LD; // [309] 320

    /** 					return -1*/
    DeRef(_got_4147);
    DeRefDS(_val_4118);
    DeRefDS(_fmt_4119);
    DeRef(_res_4126);
    DeRef(_2117);
    _2117 = NOVALUE;
    return -1;
LD: 

    /** 				got = stdget:value(val[spos .. epos-1], , stdget:GET_LONG_ANSWER)*/
    _2127 = _epos_4148 - 1;
    rhs_slice_target = (object_ptr)&_2128;
    RHS_Slice(_val_4118, _spos_4123, _2127);
    DeRef(_st_inlined_value_at_332_4174);
    _st_inlined_value_at_332_4174 = _2128;
    _2128 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3335)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3335)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3335);
        _17GET_LONG_ANSWER_3335 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_332_4174);
    _0 = _got_4147;
    _got_4147 = _17get_value(_st_inlined_value_at_332_4174, 1, _17GET_LONG_ANSWER_3335);
    DeRef(_0);
    DeRef(_st_inlined_value_at_332_4174);
    _st_inlined_value_at_332_4174 = NOVALUE;

    /** 				if got[1] != stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_got_4147);
    _2129 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _2129, 0)){
        _2129 = NOVALUE;
        goto LE; // [359] 370
    }
    _2129 = NOVALUE;

    /** 					return -1*/
    DeRefDS(_got_4147);
    DeRefDS(_val_4118);
    DeRefDS(_fmt_4119);
    DeRef(_res_4126);
    DeRef(_2117);
    _2117 = NOVALUE;
    DeRef(_2127);
    _2127 = NOVALUE;
    return -1;
LE: 

    /** 				if fmt[fpos] = 'y' then*/
    _2 = (int)SEQ_PTR(_fmt_4119);
    _2131 = (int)*(((s1_ptr)_2)->base + _fpos_4122);
    if (binary_op_a(NOTEQ, _2131, 121)){
        _2131 = NOVALUE;
        goto LF; // [376] 450
    }
    _2131 = NOVALUE;

    /** 					integer century = floor(date_now[YEAR] / 100) * 100*/
    _2 = (int)SEQ_PTR(_12date_now_4112);
    _2133 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2133)) {
        if (100 > 0 && _2133 >= 0) {
            _2134 = _2133 / 100;
        }
        else {
            temp_dbl = floor((double)_2133 / (double)100);
            if (_2133 != MININT)
            _2134 = (long)temp_dbl;
            else
            _2134 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _2133, 100);
        _2134 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _2133 = NOVALUE;
    if (IS_ATOM_INT(_2134)) {
        _century_4182 = _2134 * 100;
    }
    else {
        _century_4182 = binary_op(MULTIPLY, _2134, 100);
    }
    DeRef(_2134);
    _2134 = NOVALUE;
    if (!IS_ATOM_INT(_century_4182)) {
        _1 = (long)(DBL_PTR(_century_4182)->dbl);
        DeRefDS(_century_4182);
        _century_4182 = _1;
    }

    /** 					integer year = got[2] + (century - 100)*/
    _2 = (int)SEQ_PTR(_got_4147);
    _2136 = (int)*(((s1_ptr)_2)->base + 2);
    _2137 = _century_4182 - 100;
    if ((long)((unsigned long)_2137 +(unsigned long) HIGH_BITS) >= 0){
        _2137 = NewDouble((double)_2137);
    }
    if (IS_ATOM_INT(_2136) && IS_ATOM_INT(_2137)) {
        _year_4186 = _2136 + _2137;
    }
    else {
        _year_4186 = binary_op(PLUS, _2136, _2137);
    }
    _2136 = NOVALUE;
    DeRef(_2137);
    _2137 = NOVALUE;
    if (!IS_ATOM_INT(_year_4186)) {
        _1 = (long)(DBL_PTR(_year_4186)->dbl);
        DeRefDS(_year_4186);
        _year_4186 = _1;
    }

    /** 					if year < (date_now[YEAR] + yylower) then*/
    _2 = (int)SEQ_PTR(_12date_now_4112);
    _2139 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2139)) {
        _2140 = _2139 + _yylower_4120;
        if ((long)((unsigned long)_2140 + (unsigned long)HIGH_BITS) >= 0) 
        _2140 = NewDouble((double)_2140);
    }
    else {
        _2140 = binary_op(PLUS, _2139, _yylower_4120);
    }
    _2139 = NOVALUE;
    if (binary_op_a(GREATEREQ, _year_4186, _2140)){
        DeRef(_2140);
        _2140 = NOVALUE;
        goto L10; // [426] 443
    }
    DeRef(_2140);
    _2140 = NOVALUE;

    /** 						year = got[2] + century*/
    _2 = (int)SEQ_PTR(_got_4147);
    _2142 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_2142)) {
        _year_4186 = _2142 + _century_4182;
    }
    else {
        _year_4186 = binary_op(PLUS, _2142, _century_4182);
    }
    _2142 = NOVALUE;
    if (!IS_ATOM_INT(_year_4186)) {
        _1 = (long)(DBL_PTR(_year_4186)->dbl);
        DeRefDS(_year_4186);
        _year_4186 = _1;
    }
L10: 

    /** 					got[2] = year*/
    _2 = (int)SEQ_PTR(_got_4147);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _got_4147 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _year_4186;
    DeRef(_1);
LF: 

    /** 				res[rpos] = got[2]*/
    _2 = (int)SEQ_PTR(_got_4147);
    _2144 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_2144);
    _2 = (int)SEQ_PTR(_res_4126);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _res_4126 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _rpos_4125);
    _1 = *(int *)_2;
    *(int *)_2 = _2144;
    if( _1 != _2144 ){
        DeRef(_1);
    }
    _2144 = NOVALUE;

    /** 				spos = epos*/
    _spos_4123 = _epos_4148;
L6: 
    DeRef(_got_4147);
    _got_4147 = NOVALUE;
L3: 

    /** 		fpos += 1*/
    _fpos_4122 = _fpos_4122 + 1;

    /** 	end while*/
    goto L1; // [479] 31
L2: 

    /** 	if not datetime(res) then*/
    RefDS(_res_4126);
    _2146 = _12datetime(_res_4126);
    if (IS_ATOM_INT(_2146)) {
        if (_2146 != 0){
            DeRef(_2146);
            _2146 = NOVALUE;
            goto L11; // [488] 498
        }
    }
    else {
        if (DBL_PTR(_2146)->dbl != 0.0){
            DeRef(_2146);
            _2146 = NOVALUE;
            goto L11; // [488] 498
        }
    }
    DeRef(_2146);
    _2146 = NOVALUE;

    /** 		return -1*/
    DeRefDS(_val_4118);
    DeRefDS(_fmt_4119);
    DeRefDS(_res_4126);
    DeRef(_2117);
    _2117 = NOVALUE;
    DeRef(_2127);
    _2127 = NOVALUE;
    return -1;
L11: 

    /** 	while spos <= length(val) do*/
L12: 
    if (IS_SEQUENCE(_val_4118)){
            _2148 = SEQ_PTR(_val_4118)->length;
    }
    else {
        _2148 = 1;
    }
    if (_spos_4123 > _2148)
    goto L13; // [506] 541

    /** 		if types:t_digit(val[spos]) then*/
    _2 = (int)SEQ_PTR(_val_4118);
    _2150 = (int)*(((s1_ptr)_2)->base + _spos_4123);
    Ref(_2150);
    _2151 = _7t_digit(_2150);
    _2150 = NOVALUE;
    if (_2151 == 0) {
        DeRef(_2151);
        _2151 = NOVALUE;
        goto L14; // [520] 530
    }
    else {
        if (!IS_ATOM_INT(_2151) && DBL_PTR(_2151)->dbl == 0.0){
            DeRef(_2151);
            _2151 = NOVALUE;
            goto L14; // [520] 530
        }
        DeRef(_2151);
        _2151 = NOVALUE;
    }
    DeRef(_2151);
    _2151 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_val_4118);
    DeRefDS(_fmt_4119);
    DeRef(_res_4126);
    DeRef(_2117);
    _2117 = NOVALUE;
    DeRef(_2127);
    _2127 = NOVALUE;
    return -1;
L14: 

    /** 		spos += 1*/
    _spos_4123 = _spos_4123 + 1;

    /** 	end while*/
    goto L12; // [538] 503
L13: 

    /** 	return new(res[1], res[2], res[3], res[4], res[5], res[6])*/
    _2 = (int)SEQ_PTR(_res_4126);
    _2153 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_res_4126);
    _2154 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_res_4126);
    _2155 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_res_4126);
    _2156 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_res_4126);
    _2157 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_res_4126);
    _2158 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_2153);
    Ref(_2154);
    Ref(_2155);
    Ref(_2156);
    Ref(_2157);
    Ref(_2158);
    _2159 = _12new(_2153, _2154, _2155, _2156, _2157, _2158);
    _2153 = NOVALUE;
    _2154 = NOVALUE;
    _2155 = NOVALUE;
    _2156 = NOVALUE;
    _2157 = NOVALUE;
    _2158 = NOVALUE;
    DeRefDS(_val_4118);
    DeRefDS(_fmt_4119);
    DeRefDS(_res_4126);
    DeRef(_2117);
    _2117 = NOVALUE;
    DeRef(_2127);
    _2127 = NOVALUE;
    return _2159;
    ;
}


int  __stdcall _12add(int _dt_4217, int _qty_4218, int _interval_4219)
{
    int _inc_4220 = NOVALUE;
    int _2205 = NOVALUE;
    int _2204 = NOVALUE;
    int _2203 = NOVALUE;
    int _2200 = NOVALUE;
    int _2198 = NOVALUE;
    int _2197 = NOVALUE;
    int _2196 = NOVALUE;
    int _2195 = NOVALUE;
    int _2194 = NOVALUE;
    int _2193 = NOVALUE;
    int _2192 = NOVALUE;
    int _2191 = NOVALUE;
    int _2190 = NOVALUE;
    int _2189 = NOVALUE;
    int _2187 = NOVALUE;
    int _2186 = NOVALUE;
    int _2185 = NOVALUE;
    int _2184 = NOVALUE;
    int _2183 = NOVALUE;
    int _2182 = NOVALUE;
    int _2181 = NOVALUE;
    int _2180 = NOVALUE;
    int _2179 = NOVALUE;
    int _2178 = NOVALUE;
    int _2177 = NOVALUE;
    int _2176 = NOVALUE;
    int _2175 = NOVALUE;
    int _2174 = NOVALUE;
    int _2173 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_interval_4219)) {
        _1 = (long)(DBL_PTR(_interval_4219)->dbl);
        DeRefDS(_interval_4219);
        _interval_4219 = _1;
    }

    /** 	if interval = SECONDS then*/
    if (_interval_4219 != 7)
    goto L1; // [5] 12
    goto L2; // [9] 340
L1: 

    /** 	elsif interval = MINUTES then*/
    if (_interval_4219 != 6)
    goto L3; // [14] 27

    /** 		qty *= 60*/
    _0 = _qty_4218;
    if (IS_ATOM_INT(_qty_4218)) {
        if (_qty_4218 == (short)_qty_4218)
        _qty_4218 = _qty_4218 * 60;
        else
        _qty_4218 = NewDouble(_qty_4218 * (double)60);
    }
    else {
        _qty_4218 = binary_op(MULTIPLY, _qty_4218, 60);
    }
    DeRef(_0);
    goto L2; // [24] 340
L3: 

    /** 	elsif interval = HOURS then*/
    if (_interval_4219 != 5)
    goto L4; // [29] 42

    /** 		qty *= 3600*/
    _0 = _qty_4218;
    if (IS_ATOM_INT(_qty_4218)) {
        if (_qty_4218 == (short)_qty_4218)
        _qty_4218 = _qty_4218 * 3600;
        else
        _qty_4218 = NewDouble(_qty_4218 * (double)3600);
    }
    else {
        _qty_4218 = binary_op(MULTIPLY, _qty_4218, 3600);
    }
    DeRef(_0);
    goto L2; // [39] 340
L4: 

    /** 	elsif interval = DAYS then*/
    if (_interval_4219 != 4)
    goto L5; // [44] 57

    /** 		qty *= 86400*/
    _0 = _qty_4218;
    if (IS_ATOM_INT(_qty_4218)) {
        _qty_4218 = NewDouble(_qty_4218 * (double)86400);
    }
    else {
        _qty_4218 = binary_op(MULTIPLY, _qty_4218, 86400);
    }
    DeRef(_0);
    goto L2; // [54] 340
L5: 

    /** 	elsif interval = WEEKS then*/
    if (_interval_4219 != 3)
    goto L6; // [59] 72

    /** 		qty *= 604800*/
    _0 = _qty_4218;
    if (IS_ATOM_INT(_qty_4218)) {
        _qty_4218 = NewDouble(_qty_4218 * (double)604800);
    }
    else {
        _qty_4218 = binary_op(MULTIPLY, _qty_4218, 604800);
    }
    DeRef(_0);
    goto L2; // [69] 340
L6: 

    /** 	elsif interval = MONTHS then*/
    if (_interval_4219 != 2)
    goto L7; // [74] 238

    /** 		if qty > 0 then*/
    if (binary_op_a(LESSEQ, _qty_4218, 0)){
        goto L8; // [80] 92
    }

    /** 			inc = 1*/
    _inc_4220 = 1;
    goto L9; // [89] 103
L8: 

    /** 			inc = -1*/
    _inc_4220 = -1;

    /** 			qty = -(qty)*/
    _0 = _qty_4218;
    if (IS_ATOM_INT(_qty_4218)) {
        if ((unsigned long)_qty_4218 == 0xC0000000)
        _qty_4218 = (int)NewDouble((double)-0xC0000000);
        else
        _qty_4218 = - _qty_4218;
    }
    else {
        _qty_4218 = unary_op(UMINUS, _qty_4218);
    }
    DeRef(_0);
L9: 

    /** 		for i = 1 to qty do*/
    Ref(_qty_4218);
    DeRef(_2173);
    _2173 = _qty_4218;
    {
        int _i_4243;
        _i_4243 = 1;
LA: 
        if (binary_op_a(GREATER, _i_4243, _2173)){
            goto LB; // [108] 229
        }

        /** 			if inc = 1 and dt[MONTH] = 12 then*/
        _2174 = (_inc_4220 == 1);
        if (_2174 == 0) {
            goto LC; // [123] 162
        }
        _2 = (int)SEQ_PTR(_dt_4217);
        _2176 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2176)) {
            _2177 = (_2176 == 12);
        }
        else {
            _2177 = binary_op(EQUALS, _2176, 12);
        }
        _2176 = NOVALUE;
        if (_2177 == 0) {
            DeRef(_2177);
            _2177 = NOVALUE;
            goto LC; // [136] 162
        }
        else {
            if (!IS_ATOM_INT(_2177) && DBL_PTR(_2177)->dbl == 0.0){
                DeRef(_2177);
                _2177 = NOVALUE;
                goto LC; // [136] 162
            }
            DeRef(_2177);
            _2177 = NOVALUE;
        }
        DeRef(_2177);
        _2177 = NOVALUE;

        /** 				dt[MONTH] = 1*/
        _2 = (int)SEQ_PTR(_dt_4217);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4217 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);

        /** 				dt[YEAR] += 1*/
        _2 = (int)SEQ_PTR(_dt_4217);
        _2178 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2178)) {
            _2179 = _2178 + 1;
            if (_2179 > MAXINT){
                _2179 = NewDouble((double)_2179);
            }
        }
        else
        _2179 = binary_op(PLUS, 1, _2178);
        _2178 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4217);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4217 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _2179;
        if( _1 != _2179 ){
            DeRef(_1);
        }
        _2179 = NOVALUE;
        goto LD; // [159] 222
LC: 

        /** 			elsif inc = -1 and dt[MONTH] = 1 then*/
        _2180 = (_inc_4220 == -1);
        if (_2180 == 0) {
            goto LE; // [168] 207
        }
        _2 = (int)SEQ_PTR(_dt_4217);
        _2182 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2182)) {
            _2183 = (_2182 == 1);
        }
        else {
            _2183 = binary_op(EQUALS, _2182, 1);
        }
        _2182 = NOVALUE;
        if (_2183 == 0) {
            DeRef(_2183);
            _2183 = NOVALUE;
            goto LE; // [181] 207
        }
        else {
            if (!IS_ATOM_INT(_2183) && DBL_PTR(_2183)->dbl == 0.0){
                DeRef(_2183);
                _2183 = NOVALUE;
                goto LE; // [181] 207
            }
            DeRef(_2183);
            _2183 = NOVALUE;
        }
        DeRef(_2183);
        _2183 = NOVALUE;

        /** 				dt[MONTH] = 12*/
        _2 = (int)SEQ_PTR(_dt_4217);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4217 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 12;
        DeRef(_1);

        /** 				dt[YEAR] -= 1*/
        _2 = (int)SEQ_PTR(_dt_4217);
        _2184 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2184)) {
            _2185 = _2184 - 1;
            if ((long)((unsigned long)_2185 +(unsigned long) HIGH_BITS) >= 0){
                _2185 = NewDouble((double)_2185);
            }
        }
        else {
            _2185 = binary_op(MINUS, _2184, 1);
        }
        _2184 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4217);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4217 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _2185;
        if( _1 != _2185 ){
            DeRef(_1);
        }
        _2185 = NOVALUE;
        goto LD; // [204] 222
LE: 

        /** 				dt[MONTH] += inc*/
        _2 = (int)SEQ_PTR(_dt_4217);
        _2186 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2186)) {
            _2187 = _2186 + _inc_4220;
            if ((long)((unsigned long)_2187 + (unsigned long)HIGH_BITS) >= 0) 
            _2187 = NewDouble((double)_2187);
        }
        else {
            _2187 = binary_op(PLUS, _2186, _inc_4220);
        }
        _2186 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4217);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4217 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _2187;
        if( _1 != _2187 ){
            DeRef(_1);
        }
        _2187 = NOVALUE;
LD: 

        /** 		end for*/
        _0 = _i_4243;
        if (IS_ATOM_INT(_i_4243)) {
            _i_4243 = _i_4243 + 1;
            if ((long)((unsigned long)_i_4243 +(unsigned long) HIGH_BITS) >= 0){
                _i_4243 = NewDouble((double)_i_4243);
            }
        }
        else {
            _i_4243 = binary_op_a(PLUS, _i_4243, 1);
        }
        DeRef(_0);
        goto LA; // [224] 115
LB: 
        ;
        DeRef(_i_4243);
    }

    /** 		return dt*/
    DeRef(_qty_4218);
    DeRef(_2174);
    _2174 = NOVALUE;
    DeRef(_2180);
    _2180 = NOVALUE;
    return _dt_4217;
    goto L2; // [235] 340
L7: 

    /** 	elsif interval = YEARS then*/
    if (_interval_4219 != 1)
    goto LF; // [240] 326

    /** 		dt[YEAR] += qty*/
    _2 = (int)SEQ_PTR(_dt_4217);
    _2189 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2189) && IS_ATOM_INT(_qty_4218)) {
        _2190 = _2189 + _qty_4218;
        if ((long)((unsigned long)_2190 + (unsigned long)HIGH_BITS) >= 0) 
        _2190 = NewDouble((double)_2190);
    }
    else {
        _2190 = binary_op(PLUS, _2189, _qty_4218);
    }
    _2189 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_4217);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4217 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _2190;
    if( _1 != _2190 ){
        DeRef(_1);
    }
    _2190 = NOVALUE;

    /** 		if isLeap(dt[YEAR]) = 0 and dt[MONTH] = 2 and dt[DAY] = 29 then*/
    _2 = (int)SEQ_PTR(_dt_4217);
    _2191 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2191);
    _2192 = _12isLeap(_2191);
    _2191 = NOVALUE;
    if (IS_ATOM_INT(_2192)) {
        _2193 = (_2192 == 0);
    }
    else {
        _2193 = binary_op(EQUALS, _2192, 0);
    }
    DeRef(_2192);
    _2192 = NOVALUE;
    if (IS_ATOM_INT(_2193)) {
        if (_2193 == 0) {
            DeRef(_2194);
            _2194 = 0;
            goto L10; // [272] 288
        }
    }
    else {
        if (DBL_PTR(_2193)->dbl == 0.0) {
            DeRef(_2194);
            _2194 = 0;
            goto L10; // [272] 288
        }
    }
    _2 = (int)SEQ_PTR(_dt_4217);
    _2195 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_2195)) {
        _2196 = (_2195 == 2);
    }
    else {
        _2196 = binary_op(EQUALS, _2195, 2);
    }
    _2195 = NOVALUE;
    DeRef(_2194);
    if (IS_ATOM_INT(_2196))
    _2194 = (_2196 != 0);
    else
    _2194 = DBL_PTR(_2196)->dbl != 0.0;
L10: 
    if (_2194 == 0) {
        goto L11; // [288] 317
    }
    _2 = (int)SEQ_PTR(_dt_4217);
    _2198 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_2198)) {
        _2200 = (_2198 == 29);
    }
    else {
        _2200 = binary_op(EQUALS, _2198, 29);
    }
    _2198 = NOVALUE;
    if (_2200 == 0) {
        DeRef(_2200);
        _2200 = NOVALUE;
        goto L11; // [301] 317
    }
    else {
        if (!IS_ATOM_INT(_2200) && DBL_PTR(_2200)->dbl == 0.0){
            DeRef(_2200);
            _2200 = NOVALUE;
            goto L11; // [301] 317
        }
        DeRef(_2200);
        _2200 = NOVALUE;
    }
    DeRef(_2200);
    _2200 = NOVALUE;

    /** 			dt[MONTH] = 3*/
    _2 = (int)SEQ_PTR(_dt_4217);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4217 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 			dt[DAY] = 1*/
    _2 = (int)SEQ_PTR(_dt_4217);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4217 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L11: 

    /** 		return dt*/
    DeRef(_qty_4218);
    DeRef(_2174);
    _2174 = NOVALUE;
    DeRef(_2180);
    _2180 = NOVALUE;
    DeRef(_2193);
    _2193 = NOVALUE;
    DeRef(_2196);
    _2196 = NOVALUE;
    return _dt_4217;
    goto L2; // [323] 340
LF: 

    /** 	elsif interval = DATE then*/
    if (_interval_4219 != 8)
    goto L12; // [328] 339

    /** 		qty = datetimeToSeconds(qty)*/
    Ref(_qty_4218);
    _0 = _qty_4218;
    _qty_4218 = _12datetimeToSeconds(_qty_4218);
    DeRef(_0);
L12: 
L2: 

    /** 	return secondsToDateTime(datetimeToSeconds(dt) + qty)*/
    Ref(_dt_4217);
    _2203 = _12datetimeToSeconds(_dt_4217);
    if (IS_ATOM_INT(_2203) && IS_ATOM_INT(_qty_4218)) {
        _2204 = _2203 + _qty_4218;
        if ((long)((unsigned long)_2204 + (unsigned long)HIGH_BITS) >= 0) 
        _2204 = NewDouble((double)_2204);
    }
    else {
        _2204 = binary_op(PLUS, _2203, _qty_4218);
    }
    DeRef(_2203);
    _2203 = NOVALUE;
    _2205 = _12secondsToDateTime(_2204);
    _2204 = NOVALUE;
    DeRef(_dt_4217);
    DeRef(_qty_4218);
    DeRef(_2174);
    _2174 = NOVALUE;
    DeRef(_2180);
    _2180 = NOVALUE;
    DeRef(_2193);
    _2193 = NOVALUE;
    DeRef(_2196);
    _2196 = NOVALUE;
    return _2205;
    ;
}


int  __stdcall _12subtract(int _dt_4285, int _qty_4286, int _interval_4287)
{
    int _2207 = NOVALUE;
    int _2206 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_interval_4287)) {
        _1 = (long)(DBL_PTR(_interval_4287)->dbl);
        DeRefDS(_interval_4287);
        _interval_4287 = _1;
    }

    /** 	return add(dt, -(qty), interval)*/
    if (IS_ATOM_INT(_qty_4286)) {
        if ((unsigned long)_qty_4286 == 0xC0000000)
        _2206 = (int)NewDouble((double)-0xC0000000);
        else
        _2206 = - _qty_4286;
    }
    else {
        _2206 = unary_op(UMINUS, _qty_4286);
    }
    Ref(_dt_4285);
    _2207 = _12add(_dt_4285, _2206, _interval_4287);
    _2206 = NOVALUE;
    DeRef(_dt_4285);
    DeRef(_qty_4286);
    return _2207;
    ;
}


int  __stdcall _12diff(int _dt1_4292, int _dt2_4293)
{
    int _2210 = NOVALUE;
    int _2209 = NOVALUE;
    int _2208 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_dt2_4293);
    _2208 = _12datetimeToSeconds(_dt2_4293);
    Ref(_dt1_4292);
    _2209 = _12datetimeToSeconds(_dt1_4292);
    if (IS_ATOM_INT(_2208) && IS_ATOM_INT(_2209)) {
        _2210 = _2208 - _2209;
        if ((long)((unsigned long)_2210 +(unsigned long) HIGH_BITS) >= 0){
            _2210 = NewDouble((double)_2210);
        }
    }
    else {
        _2210 = binary_op(MINUS, _2208, _2209);
    }
    DeRef(_2208);
    _2208 = NOVALUE;
    DeRef(_2209);
    _2209 = NOVALUE;
    DeRef(_dt1_4292);
    DeRef(_dt2_4293);
    return _2210;
    ;
}



// 0x94AD2FC2
