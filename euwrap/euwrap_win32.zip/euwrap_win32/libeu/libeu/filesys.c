// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _11find_first_wildcard(int _name_7153, int _from_7154)
{
    int _asterisk_at_7155 = NOVALUE;
    int _question_at_7157 = NOVALUE;
    int _first_wildcard_at_7159 = NOVALUE;
    int _3817 = NOVALUE;
    int _3816 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_7155 = find_from(42, _name_7153, 1);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_7157 = find_from(63, _name_7153, 1);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_7159 = _asterisk_at_7155;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_7155 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_7157 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_7157 == 0) {
        goto L3; // [37] 55
    }
    _3817 = (_question_at_7157 < _asterisk_at_7155);
    if (_3817 == 0)
    {
        DeRef(_3817);
        _3817 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3817);
        _3817 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_7159 = _question_at_7157;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_7153);
    return _first_wildcard_at_7159;
    ;
}


int  __stdcall _11dir(int _name_7167)
{
    int _3818 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    _3818 = machine(22, _name_7167);
    DeRefDS(_name_7167);
    return _3818;
    ;
}


int  __stdcall _11current_dir()
{
    int _3820 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _3820 = machine(23, 0);
    return _3820;
    ;
}


int  __stdcall _11chdir(int _newdir_7175)
{
    int _3821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _3821 = machine(63, _newdir_7175);
    DeRefDS(_newdir_7175);
    return _3821;
    ;
}


int _11default_dir(int _path_7179)
{
    int _d_7180 = NOVALUE;
    int _dir_inlined_dir_at_4_7182 = NOVALUE;
    int _3823 = NOVALUE;
    int _3822 = NOVALUE;
    int _0, _1, _2;
    

    /** 	d = dir(path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_d_7180);
    _d_7180 = machine(22, _path_7179);

    /** 	if atom(d) then*/
    _3822 = IS_ATOM(_d_7180);
    if (_3822 == 0)
    {
        _3822 = NOVALUE;
        goto L1; // [19] 31
    }
    else{
        _3822 = NOVALUE;
    }

    /** 		return d*/
    DeRefDS(_path_7179);
    return _d_7180;
    goto L2; // [28] 43
L1: 

    /** 		return stdsort:sort(d)*/
    Ref(_d_7180);
    _3823 = _24sort(_d_7180, 1);
    DeRefDS(_path_7179);
    DeRef(_d_7180);
    return _3823;
L2: 
    ;
}


int  __stdcall _11walk_dir(int _path_name_7191, int _your_function_7192, int _scan_subdirs_7193, int _dir_source_7194)
{
    int _d_7195 = NOVALUE;
    int _abort_now_7196 = NOVALUE;
    int _orig_func_7197 = NOVALUE;
    int _user_data_7198 = NOVALUE;
    int _source_orig_func_7200 = NOVALUE;
    int _source_user_data_7201 = NOVALUE;
    int _3869 = NOVALUE;
    int _3868 = NOVALUE;
    int _3867 = NOVALUE;
    int _3866 = NOVALUE;
    int _3865 = NOVALUE;
    int _3863 = NOVALUE;
    int _3862 = NOVALUE;
    int _3861 = NOVALUE;
    int _3860 = NOVALUE;
    int _3859 = NOVALUE;
    int _3858 = NOVALUE;
    int _3857 = NOVALUE;
    int _3855 = NOVALUE;
    int _3853 = NOVALUE;
    int _3852 = NOVALUE;
    int _3851 = NOVALUE;
    int _3849 = NOVALUE;
    int _3848 = NOVALUE;
    int _3847 = NOVALUE;
    int _3843 = NOVALUE;
    int _3841 = NOVALUE;
    int _3837 = NOVALUE;
    int _3835 = NOVALUE;
    int _3834 = NOVALUE;
    int _3832 = NOVALUE;
    int _3829 = NOVALUE;
    int _3826 = NOVALUE;
    int _3825 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_scan_subdirs_7193)) {
        _1 = (long)(DBL_PTR(_scan_subdirs_7193)->dbl);
        DeRefDS(_scan_subdirs_7193);
        _scan_subdirs_7193 = _1;
    }

    /** 	sequence user_data = {path_name, 0}*/
    RefDS(_path_name_7191);
    DeRef(_user_data_7198);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _path_name_7191;
    ((int *)_2)[2] = 0;
    _user_data_7198 = MAKE_SEQ(_1);

    /** 	orig_func = your_function*/
    Ref(_your_function_7192);
    DeRef(_orig_func_7197);
    _orig_func_7197 = _your_function_7192;

    /** 	if sequence(your_function) then*/
    _3825 = IS_SEQUENCE(_your_function_7192);
    if (_3825 == 0)
    {
        _3825 = NOVALUE;
        goto L1; // [21] 41
    }
    else{
        _3825 = NOVALUE;
    }

    /** 		user_data = append(user_data, your_function[2])*/
    _2 = (int)SEQ_PTR(_your_function_7192);
    _3826 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_3826);
    Append(&_user_data_7198, _user_data_7198, _3826);
    _3826 = NOVALUE;

    /** 		your_function = your_function[1]*/
    _0 = _your_function_7192;
    _2 = (int)SEQ_PTR(_your_function_7192);
    _your_function_7192 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_your_function_7192);
    DeRef(_0);
L1: 

    /** 	source_orig_func = dir_source*/
    Ref(_dir_source_7194);
    DeRef(_source_orig_func_7200);
    _source_orig_func_7200 = _dir_source_7194;

    /** 	if sequence(dir_source) then*/
    _3829 = IS_SEQUENCE(_dir_source_7194);
    if (_3829 == 0)
    {
        _3829 = NOVALUE;
        goto L2; // [51] 67
    }
    else{
        _3829 = NOVALUE;
    }

    /** 		source_user_data = dir_source[2]*/
    DeRef(_source_user_data_7201);
    _2 = (int)SEQ_PTR(_dir_source_7194);
    _source_user_data_7201 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_source_user_data_7201);

    /** 		dir_source = dir_source[1]*/
    _0 = _dir_source_7194;
    _2 = (int)SEQ_PTR(_dir_source_7194);
    _dir_source_7194 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_dir_source_7194);
    DeRef(_0);
L2: 

    /** 	if not equal(dir_source, types:NO_ROUTINE_ID) then*/
    if (_dir_source_7194 == -99999)
    _3832 = 1;
    else if (IS_ATOM_INT(_dir_source_7194) && IS_ATOM_INT(-99999))
    _3832 = 0;
    else
    _3832 = (compare(_dir_source_7194, -99999) == 0);
    if (_3832 != 0)
    goto L3; // [73] 113
    _3832 = NOVALUE;

    /** 		if atom(source_orig_func) then*/
    _3834 = IS_ATOM(_source_orig_func_7200);
    if (_3834 == 0)
    {
        _3834 = NOVALUE;
        goto L4; // [81] 97
    }
    else{
        _3834 = NOVALUE;
    }

    /** 			d = call_func(dir_source, {path_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_path_name_7191);
    *((int *)(_2+4)) = _path_name_7191;
    _3835 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3835);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_dir_source_7194].addr;
    Ref(*(int *)(_2+4));
    if (_00[_dir_source_7194].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
    }
    DeRef(_d_7195);
    _d_7195 = _1;
    DeRefDS(_3835);
    _3835 = NOVALUE;
    goto L5; // [94] 143
L4: 

    /** 			d = call_func(dir_source, {path_name, source_user_data})*/
    Ref(_source_user_data_7201);
    RefDS(_path_name_7191);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _path_name_7191;
    ((int *)_2)[2] = _source_user_data_7201;
    _3837 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3837);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_dir_source_7194].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    if (_00[_dir_source_7194].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
    }
    DeRef(_d_7195);
    _d_7195 = _1;
    DeRefDS(_3837);
    _3837 = NOVALUE;
    goto L5; // [110] 143
L3: 

    /** 	elsif my_dir = DEFAULT_DIR_SOURCE then*/

    /** 		d = default_dir(path_name)*/
    RefDS(_path_name_7191);
    _0 = _d_7195;
    _d_7195 = _11default_dir(_path_name_7191);
    DeRef(_0);
    goto L5; // [127] 143

    /** 		d = call_func(my_dir, {path_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_path_name_7191);
    *((int *)(_2+4)) = _path_name_7191;
    _3841 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3841);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[-2].addr;
    Ref(*(int *)(_2+4));
    if (_00[-2].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
    }
    DeRef(_d_7195);
    _d_7195 = _1;
    DeRefDS(_3841);
    _3841 = NOVALUE;
L5: 

    /** 	if atom(d) then*/
    _3843 = IS_ATOM(_d_7195);
    if (_3843 == 0)
    {
        _3843 = NOVALUE;
        goto L6; // [150] 160
    }
    else{
        _3843 = NOVALUE;
    }

    /** 		return W_BAD_PATH*/
    DeRefDS(_path_name_7191);
    DeRef(_your_function_7192);
    DeRef(_dir_source_7194);
    DeRef(_d_7195);
    DeRef(_abort_now_7196);
    DeRef(_orig_func_7197);
    DeRef(_user_data_7198);
    DeRef(_source_orig_func_7200);
    DeRef(_source_user_data_7201);
    return -1;
L6: 

    /** 	ifdef not UNIX then*/

    /** 		path_name = match_replace('/', path_name, '\\')*/
    RefDS(_path_name_7191);
    _0 = _path_name_7191;
    _path_name_7191 = _9match_replace(47, _path_name_7191, 92, 0);
    DeRefDS(_0);

    /** 	path_name = text:trim_tail(path_name, {' ', SLASH, '\n'})*/
    RefDS(_path_name_7191);
    RefDS(_3845);
    _0 = _path_name_7191;
    _path_name_7191 = _6trim_tail(_path_name_7191, _3845, 0);
    DeRefDS(_0);

    /** 	user_data[1] = path_name*/
    RefDS(_path_name_7191);
    _2 = (int)SEQ_PTR(_user_data_7198);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _path_name_7191;
    DeRef(_1);

    /** 	for i = 1 to length(d) do*/
    if (IS_SEQUENCE(_d_7195)){
            _3847 = SEQ_PTR(_d_7195)->length;
    }
    else {
        _3847 = 1;
    }
    {
        int _i_7235;
        _i_7235 = 1;
L7: 
        if (_i_7235 > _3847){
            goto L8; // [194] 349
        }

        /** 		if eu:find(d[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_d_7195);
        _3848 = (int)*(((s1_ptr)_2)->base + _i_7235);
        _2 = (int)SEQ_PTR(_3848);
        _3849 = (int)*(((s1_ptr)_2)->base + 1);
        _3848 = NOVALUE;
        RefDS(_3850);
        RefDS(_3819);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _3819;
        ((int *)_2)[2] = _3850;
        _3851 = MAKE_SEQ(_1);
        _3852 = find_from(_3849, _3851, 1);
        _3849 = NOVALUE;
        DeRefDS(_3851);
        _3851 = NOVALUE;
        if (_3852 == 0)
        {
            _3852 = NOVALUE;
            goto L9; // [220] 228
        }
        else{
            _3852 = NOVALUE;
        }

        /** 			continue*/
        goto LA; // [225] 344
L9: 

        /** 		user_data[2] = d[i]*/
        _2 = (int)SEQ_PTR(_d_7195);
        _3853 = (int)*(((s1_ptr)_2)->base + _i_7235);
        Ref(_3853);
        _2 = (int)SEQ_PTR(_user_data_7198);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _3853;
        if( _1 != _3853 ){
            DeRef(_1);
        }
        _3853 = NOVALUE;

        /** 		abort_now = call_func(your_function, user_data)*/
        _1 = (int)SEQ_PTR(_user_data_7198);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_your_function_7192].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                         );
                }
                break;
            case 1:
                Ref(*(int *)(_2+4));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                if (_00[_your_function_7192].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                break;
        }
        DeRef(_abort_now_7196);
        _abort_now_7196 = _1;

        /** 		if not equal(abort_now, 0) then*/
        if (_abort_now_7196 == 0)
        _3855 = 1;
        else if (IS_ATOM_INT(_abort_now_7196) && IS_ATOM_INT(0))
        _3855 = 0;
        else
        _3855 = (compare(_abort_now_7196, 0) == 0);
        if (_3855 != 0)
        goto LB; // [250] 260
        _3855 = NOVALUE;

        /** 			return abort_now*/
        DeRefDS(_path_name_7191);
        DeRef(_your_function_7192);
        DeRef(_dir_source_7194);
        DeRef(_d_7195);
        DeRef(_orig_func_7197);
        DeRefDS(_user_data_7198);
        DeRef(_source_orig_func_7200);
        DeRef(_source_user_data_7201);
        return _abort_now_7196;
LB: 

        /** 		if eu:find('d', d[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_d_7195);
        _3857 = (int)*(((s1_ptr)_2)->base + _i_7235);
        _2 = (int)SEQ_PTR(_3857);
        _3858 = (int)*(((s1_ptr)_2)->base + 2);
        _3857 = NOVALUE;
        _3859 = find_from(100, _3858, 1);
        _3858 = NOVALUE;
        if (_3859 == 0)
        {
            _3859 = NOVALUE;
            goto LC; // [275] 342
        }
        else{
            _3859 = NOVALUE;
        }

        /** 			if scan_subdirs then*/
        if (_scan_subdirs_7193 == 0)
        {
            goto LD; // [280] 341
        }
        else{
        }

        /** 				abort_now = walk_dir(path_name & SLASH & d[i][D_NAME],*/
        _2 = (int)SEQ_PTR(_d_7195);
        _3860 = (int)*(((s1_ptr)_2)->base + _i_7235);
        _2 = (int)SEQ_PTR(_3860);
        _3861 = (int)*(((s1_ptr)_2)->base + 1);
        _3860 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _3861;
            concat_list[1] = 92;
            concat_list[2] = _path_name_7191;
            Concat_N((object_ptr)&_3862, concat_list, 3);
        }
        _3861 = NOVALUE;
        DeRef(_3863);
        _3863 = _scan_subdirs_7193;
        Ref(_orig_func_7197);
        Ref(_source_orig_func_7200);
        _0 = _abort_now_7196;
        _abort_now_7196 = _11walk_dir(_3862, _orig_func_7197, _3863, _source_orig_func_7200);
        DeRef(_0);
        _3862 = NOVALUE;
        _3863 = NOVALUE;

        /** 				if not equal(abort_now, 0) and */
        if (_abort_now_7196 == 0)
        _3865 = 1;
        else if (IS_ATOM_INT(_abort_now_7196) && IS_ATOM_INT(0))
        _3865 = 0;
        else
        _3865 = (compare(_abort_now_7196, 0) == 0);
        _3866 = (_3865 == 0);
        _3865 = NOVALUE;
        if (_3866 == 0) {
            goto LE; // [318] 340
        }
        if (_abort_now_7196 == -1)
        _3868 = 1;
        else if (IS_ATOM_INT(_abort_now_7196) && IS_ATOM_INT(-1))
        _3868 = 0;
        else
        _3868 = (compare(_abort_now_7196, -1) == 0);
        _3869 = (_3868 == 0);
        _3868 = NOVALUE;
        if (_3869 == 0)
        {
            DeRef(_3869);
            _3869 = NOVALUE;
            goto LE; // [330] 340
        }
        else{
            DeRef(_3869);
            _3869 = NOVALUE;
        }

        /** 					return abort_now*/
        DeRefDS(_path_name_7191);
        DeRef(_your_function_7192);
        DeRef(_dir_source_7194);
        DeRef(_d_7195);
        DeRef(_orig_func_7197);
        DeRef(_user_data_7198);
        DeRef(_source_orig_func_7200);
        DeRef(_source_user_data_7201);
        DeRef(_3866);
        _3866 = NOVALUE;
        return _abort_now_7196;
LE: 
LD: 
LC: 

        /** 	end for*/
LA: 
        _i_7235 = _i_7235 + 1;
        goto L7; // [344] 201
L8: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_path_name_7191);
    DeRef(_your_function_7192);
    DeRef(_dir_source_7194);
    DeRef(_d_7195);
    DeRef(_abort_now_7196);
    DeRef(_orig_func_7197);
    DeRef(_user_data_7198);
    DeRef(_source_orig_func_7200);
    DeRef(_source_user_data_7201);
    DeRef(_3866);
    _3866 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _11create_directory(int _name_7266, int _mode_7267, int _mkparent_7269)
{
    int _pname_7270 = NOVALUE;
    int _ret_7271 = NOVALUE;
    int _pos_7272 = NOVALUE;
    int _3889 = NOVALUE;
    int _3886 = NOVALUE;
    int _3885 = NOVALUE;
    int _3884 = NOVALUE;
    int _3883 = NOVALUE;
    int _3880 = NOVALUE;
    int _3877 = NOVALUE;
    int _3876 = NOVALUE;
    int _3874 = NOVALUE;
    int _3873 = NOVALUE;
    int _3871 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mode_7267)) {
        _1 = (long)(DBL_PTR(_mode_7267)->dbl);
        DeRefDS(_mode_7267);
        _mode_7267 = _1;
    }
    if (!IS_ATOM_INT(_mkparent_7269)) {
        _1 = (long)(DBL_PTR(_mkparent_7269)->dbl);
        DeRefDS(_mkparent_7269);
        _mkparent_7269 = _1;
    }

    /** 	if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_7266)){
            _3871 = SEQ_PTR(_name_7266)->length;
    }
    else {
        _3871 = 1;
    }
    if (_3871 != 0)
    goto L1; // [12] 23

    /** 		return 0 -- failed*/
    DeRefDS(_name_7266);
    DeRef(_pname_7270);
    DeRef(_ret_7271);
    return 0;
L1: 

    /** 	if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_7266)){
            _3873 = SEQ_PTR(_name_7266)->length;
    }
    else {
        _3873 = 1;
    }
    _2 = (int)SEQ_PTR(_name_7266);
    _3874 = (int)*(((s1_ptr)_2)->base + _3873);
    if (binary_op_a(NOTEQ, _3874, 92)){
        _3874 = NOVALUE;
        goto L2; // [32] 51
    }
    _3874 = NOVALUE;

    /** 		name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_7266)){
            _3876 = SEQ_PTR(_name_7266)->length;
    }
    else {
        _3876 = 1;
    }
    _3877 = _3876 - 1;
    _3876 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_7266;
    RHS_Slice(_name_7266, 1, _3877);
L2: 

    /** 	if mkparent != 0 then*/
    if (_mkparent_7269 == 0)
    goto L3; // [53] 101

    /** 		pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_7266)){
            _3880 = SEQ_PTR(_name_7266)->length;
    }
    else {
        _3880 = 1;
    }
    RefDS(_name_7266);
    _pos_7272 = _9rfind(92, _name_7266, _3880);
    _3880 = NOVALUE;
    if (!IS_ATOM_INT(_pos_7272)) {
        _1 = (long)(DBL_PTR(_pos_7272)->dbl);
        DeRefDS(_pos_7272);
        _pos_7272 = _1;
    }

    /** 		if pos != 0 then*/
    if (_pos_7272 == 0)
    goto L4; // [72] 100

    /** 			ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3883 = _pos_7272 - 1;
    rhs_slice_target = (object_ptr)&_3884;
    RHS_Slice(_name_7266, 1, _3883);
    DeRef(_3885);
    _3885 = _mode_7267;
    DeRef(_3886);
    _3886 = _mkparent_7269;
    _0 = _ret_7271;
    _ret_7271 = _11create_directory(_3884, _3885, _3886);
    DeRef(_0);
    _3884 = NOVALUE;
    _3885 = NOVALUE;
    _3886 = NOVALUE;
L4: 
L3: 

    /** 	pname = machine:allocate_string(name)*/
    RefDS(_name_7266);
    _0 = _pname_7270;
    _pname_7270 = _14allocate_string(_name_7266, 0);
    DeRef(_0);

    /** 	ifdef UNIX then*/

    /** 		ret = c_func(xCreateDirectory, {pname, 0})*/
    Ref(_pname_7270);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pname_7270;
    ((int *)_2)[2] = 0;
    _3889 = MAKE_SEQ(_1);
    DeRef(_ret_7271);
    _ret_7271 = call_c(1, _11xCreateDirectory_7106, _3889);
    DeRefDS(_3889);
    _3889 = NOVALUE;

    /** 		mode = mode -- get rid of not used warning*/
    _mode_7267 = _mode_7267;

    /** 	return ret*/
    DeRefDS(_name_7266);
    DeRef(_pname_7270);
    DeRef(_3877);
    _3877 = NOVALUE;
    DeRef(_3883);
    _3883 = NOVALUE;
    return _ret_7271;
    ;
}


int  __stdcall _11create_file(int _name_7299)
{
    int _fh_7300 = NOVALUE;
    int _ret_7302 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fh = open(name, "wb")*/
    _fh_7300 = EOpen(_name_7299, _1354, 0);

    /** 	integer ret = (fh != -1)*/
    _ret_7302 = (_fh_7300 != -1);

    /** 	if ret then*/
    if (_ret_7302 == 0)
    {
        goto L1; // [18] 26
    }
    else{
    }

    /** 		close(fh)*/
    EClose(_fh_7300);
L1: 

    /** 	return ret*/
    DeRefDS(_name_7299);
    return _ret_7302;
    ;
}


int  __stdcall _11delete_file(int _name_7307)
{
    int _pfilename_7308 = NOVALUE;
    int _success_7310 = NOVALUE;
    int _3894 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_7307);
    _0 = _pfilename_7308;
    _pfilename_7308 = _14allocate_string(_name_7307, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_7308);
    *((int *)(_2+4)) = _pfilename_7308;
    _3894 = MAKE_SEQ(_1);
    _success_7310 = call_c(1, _11xDeleteFile_7102, _3894);
    DeRefDS(_3894);
    _3894 = NOVALUE;
    if (!IS_ATOM_INT(_success_7310)) {
        _1 = (long)(DBL_PTR(_success_7310)->dbl);
        DeRefDS(_success_7310);
        _success_7310 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_7308);
    _14free(_pfilename_7308);

    /** 	return success*/
    DeRefDS(_name_7307);
    DeRef(_pfilename_7308);
    return _success_7310;
    ;
}


int  __stdcall _11curdir(int _drive_id_7315)
{
    int _lCurDir_7316 = NOVALUE;
    int _lOrigDir_7317 = NOVALUE;
    int _lDrive_7318 = NOVALUE;
    int _current_dir_inlined_current_dir_at_25_7323 = NOVALUE;
    int _chdir_inlined_chdir_at_55_7326 = NOVALUE;
    int _current_dir_inlined_current_dir_at_77_7329 = NOVALUE;
    int _chdir_inlined_chdir_at_109_7336 = NOVALUE;
    int _newdir_inlined_chdir_at_106_7335 = NOVALUE;
    int _3902 = NOVALUE;
    int _3901 = NOVALUE;
    int _3900 = NOVALUE;
    int _3898 = NOVALUE;
    int _3896 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_7315)) {
        _1 = (long)(DBL_PTR(_drive_id_7315)->dbl);
        DeRefDS(_drive_id_7315);
        _drive_id_7315 = _1;
    }

    /** 	ifdef not LINUX then*/

    /** 	    sequence lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_7317);
    _lOrigDir_7317 = _5;

    /** 	    sequence lDrive*/

    /** 	    if t_alpha(drive_id) then*/
    _3896 = _7t_alpha(_drive_id_7315);
    if (_3896 == 0) {
        DeRef(_3896);
        _3896 = NOVALUE;
        goto L1; // [20] 75
    }
    else {
        if (!IS_ATOM_INT(_3896) && DBL_PTR(_3896)->dbl == 0.0){
            DeRef(_3896);
            _3896 = NOVALUE;
            goto L1; // [20] 75
        }
        DeRef(_3896);
        _3896 = NOVALUE;
    }
    DeRef(_3896);
    _3896 = NOVALUE;

    /** 		    lOrigDir =  current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefDSi(_lOrigDir_7317);
    _lOrigDir_7317 = machine(23, 0);

    /** 		    lDrive = "  "*/
    RefDS(_300);
    DeRefi(_lDrive_7318);
    _lDrive_7318 = _300;

    /** 		    lDrive[1] = drive_id*/
    _2 = (int)SEQ_PTR(_lDrive_7318);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_7318 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _drive_id_7315;

    /** 		    lDrive[2] = ':'*/
    _2 = (int)SEQ_PTR(_lDrive_7318);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lDrive_7318 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = 58;

    /** 		    if chdir(lDrive) = 0 then*/

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_55_7326 = machine(63, _lDrive_7318);
    if (_chdir_inlined_chdir_at_55_7326 != 0)
    goto L2; // [62] 74

    /** 		    	lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_7317);
    _lOrigDir_7317 = _5;
L2: 
L1: 

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_7316);
    _lCurDir_7316 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 		if length(lOrigDir) > 0 then*/
    if (IS_SEQUENCE(_lOrigDir_7317)){
            _3898 = SEQ_PTR(_lOrigDir_7317)->length;
    }
    else {
        _3898 = 1;
    }
    if (_3898 <= 0)
    goto L3; // [95] 121

    /** 	    	chdir(lOrigDir[1..2])*/
    rhs_slice_target = (object_ptr)&_3900;
    RHS_Slice(_lOrigDir_7317, 1, 2);
    DeRefi(_newdir_inlined_chdir_at_106_7335);
    _newdir_inlined_chdir_at_106_7335 = _3900;
    _3900 = NOVALUE;

    /** 	return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_109_7336 = machine(63, _newdir_inlined_chdir_at_106_7335);
    DeRefi(_newdir_inlined_chdir_at_106_7335);
    _newdir_inlined_chdir_at_106_7335 = NOVALUE;
L3: 

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_7316)){
            _3901 = SEQ_PTR(_lCurDir_7316)->length;
    }
    else {
        _3901 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_7316);
    _3902 = (int)*(((s1_ptr)_2)->base + _3901);
    if (_3902 == 92)
    goto L4; // [130] 141

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_7316, _lCurDir_7316, 92);
L4: 

    /** 	return lCurDir*/
    DeRefi(_lOrigDir_7317);
    DeRefi(_lDrive_7318);
    _3902 = NOVALUE;
    return _lCurDir_7316;
    ;
}


int  __stdcall _11init_curdir()
{
    int _0, _1, _2;
    

    /** 	return InitCurDir*/
    RefDS(_11InitCurDir_7342);
    return _11InitCurDir_7342;
    ;
}


int  __stdcall _11clear_directory(int _path_7348, int _recurse_7349)
{
    int _files_7350 = NOVALUE;
    int _ret_7351 = NOVALUE;
    int _dir_inlined_dir_at_89_7372 = NOVALUE;
    int _cnt_7397 = NOVALUE;
    int _3946 = NOVALUE;
    int _3945 = NOVALUE;
    int _3944 = NOVALUE;
    int _3943 = NOVALUE;
    int _3939 = NOVALUE;
    int _3938 = NOVALUE;
    int _3937 = NOVALUE;
    int _3936 = NOVALUE;
    int _3935 = NOVALUE;
    int _3934 = NOVALUE;
    int _3933 = NOVALUE;
    int _3932 = NOVALUE;
    int _3929 = NOVALUE;
    int _3928 = NOVALUE;
    int _3927 = NOVALUE;
    int _3925 = NOVALUE;
    int _3924 = NOVALUE;
    int _3923 = NOVALUE;
    int _3921 = NOVALUE;
    int _3920 = NOVALUE;
    int _3918 = NOVALUE;
    int _3916 = NOVALUE;
    int _3914 = NOVALUE;
    int _3912 = NOVALUE;
    int _3911 = NOVALUE;
    int _3909 = NOVALUE;
    int _3908 = NOVALUE;
    int _3906 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recurse_7349)) {
        _1 = (long)(DBL_PTR(_recurse_7349)->dbl);
        DeRefDS(_recurse_7349);
        _recurse_7349 = _1;
    }

    /** 	if length(path) > 0 then*/
    if (IS_SEQUENCE(_path_7348)){
            _3906 = SEQ_PTR(_path_7348)->length;
    }
    else {
        _3906 = 1;
    }
    if (_3906 <= 0)
    goto L1; // [10] 43

    /** 		if path[$] = SLASH then*/
    if (IS_SEQUENCE(_path_7348)){
            _3908 = SEQ_PTR(_path_7348)->length;
    }
    else {
        _3908 = 1;
    }
    _2 = (int)SEQ_PTR(_path_7348);
    _3909 = (int)*(((s1_ptr)_2)->base + _3908);
    if (binary_op_a(NOTEQ, _3909, 92)){
        _3909 = NOVALUE;
        goto L2; // [23] 42
    }
    _3909 = NOVALUE;

    /** 			path = path[1 .. $-1]*/
    if (IS_SEQUENCE(_path_7348)){
            _3911 = SEQ_PTR(_path_7348)->length;
    }
    else {
        _3911 = 1;
    }
    _3912 = _3911 - 1;
    _3911 = NOVALUE;
    rhs_slice_target = (object_ptr)&_path_7348;
    RHS_Slice(_path_7348, 1, _3912);
L2: 
L1: 

    /** 	if length(path) = 0 then*/
    if (IS_SEQUENCE(_path_7348)){
            _3914 = SEQ_PTR(_path_7348)->length;
    }
    else {
        _3914 = 1;
    }
    if (_3914 != 0)
    goto L3; // [48] 59

    /** 		return 0 -- Nothing specified to clear. Not safe to assume anything.*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(path) = 2 then*/
    if (IS_SEQUENCE(_path_7348)){
            _3916 = SEQ_PTR(_path_7348)->length;
    }
    else {
        _3916 = 1;
    }
    if (_3916 != 2)
    goto L4; // [66] 88

    /** 			if path[2] = ':' then*/
    _2 = (int)SEQ_PTR(_path_7348);
    _3918 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3918, 58)){
        _3918 = NOVALUE;
        goto L5; // [76] 87
    }
    _3918 = NOVALUE;

    /** 				return 0 -- nothing specified to delete*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L5: 
L4: 

    /** 	files = dir(path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_files_7350);
    _files_7350 = machine(22, _path_7348);

    /** 	if atom(files) then*/
    _3920 = IS_ATOM(_files_7350);
    if (_3920 == 0)
    {
        _3920 = NOVALUE;
        goto L6; // [104] 114
    }
    else{
        _3920 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L6: 

    /** 	ifdef WINDOWS then*/

    /** 		if length( files ) < 3 then*/
    if (IS_SEQUENCE(_files_7350)){
            _3921 = SEQ_PTR(_files_7350)->length;
    }
    else {
        _3921 = 1;
    }
    if (_3921 >= 3)
    goto L7; // [121] 132

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L7: 

    /** 		if not equal(files[1][D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_files_7350);
    _3923 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3923);
    _3924 = (int)*(((s1_ptr)_2)->base + 1);
    _3923 = NOVALUE;
    if (_3924 == _3819)
    _3925 = 1;
    else if (IS_ATOM_INT(_3924) && IS_ATOM_INT(_3819))
    _3925 = 0;
    else
    _3925 = (compare(_3924, _3819) == 0);
    _3924 = NOVALUE;
    if (_3925 != 0)
    goto L8; // [146] 156
    _3925 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L8: 

    /** 		if not eu:find('d', files[1][D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_files_7350);
    _3927 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3927);
    _3928 = (int)*(((s1_ptr)_2)->base + 2);
    _3927 = NOVALUE;
    _3929 = find_from(100, _3928, 1);
    _3928 = NOVALUE;
    if (_3929 != 0)
    goto L9; // [171] 181
    _3929 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return 0;
L9: 

    /** 	ret = 1*/
    _ret_7351 = 1;

    /** 	path &= SLASH*/
    Append(&_path_7348, _path_7348, 92);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 3 to length(files) do*/
    if (IS_SEQUENCE(_files_7350)){
            _3932 = SEQ_PTR(_files_7350)->length;
    }
    else {
        _3932 = 1;
    }
    {
        int _i_7390;
        _i_7390 = 3;
LA: 
        if (_i_7390 > _3932){
            goto LB; // [199] 328
        }

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_7350);
        _3933 = (int)*(((s1_ptr)_2)->base + _i_7390);
        _2 = (int)SEQ_PTR(_3933);
        _3934 = (int)*(((s1_ptr)_2)->base + 2);
        _3933 = NOVALUE;
        _3935 = find_from(100, _3934, 1);
        _3934 = NOVALUE;
        if (_3935 == 0)
        {
            _3935 = NOVALUE;
            goto LC; // [221] 285
        }
        else{
            _3935 = NOVALUE;
        }

        /** 				if recurse then*/
        if (_recurse_7349 == 0)
        {
            goto LD; // [226] 323
        }
        else{
        }

        /** 					integer cnt = clear_directory(path & files[i][D_NAME], recurse)*/
        _2 = (int)SEQ_PTR(_files_7350);
        _3936 = (int)*(((s1_ptr)_2)->base + _i_7390);
        _2 = (int)SEQ_PTR(_3936);
        _3937 = (int)*(((s1_ptr)_2)->base + 1);
        _3936 = NOVALUE;
        if (IS_SEQUENCE(_path_7348) && IS_ATOM(_3937)) {
            Ref(_3937);
            Append(&_3938, _path_7348, _3937);
        }
        else if (IS_ATOM(_path_7348) && IS_SEQUENCE(_3937)) {
        }
        else {
            Concat((object_ptr)&_3938, _path_7348, _3937);
        }
        _3937 = NOVALUE;
        DeRef(_3939);
        _3939 = _recurse_7349;
        _cnt_7397 = _11clear_directory(_3938, _3939);
        _3938 = NOVALUE;
        _3939 = NOVALUE;
        if (!IS_ATOM_INT(_cnt_7397)) {
            _1 = (long)(DBL_PTR(_cnt_7397)->dbl);
            DeRefDS(_cnt_7397);
            _cnt_7397 = _1;
        }

        /** 					if cnt = 0 then*/
        if (_cnt_7397 != 0)
        goto LE; // [255] 266

        /** 						return 0*/
        DeRefDS(_path_7348);
        DeRef(_files_7350);
        DeRef(_3912);
        _3912 = NOVALUE;
        return 0;
LE: 

        /** 					ret += cnt*/
        _ret_7351 = _ret_7351 + _cnt_7397;
        goto LF; // [274] 321

        /** 					continue*/
        goto LD; // [279] 323
        goto LF; // [282] 321
LC: 

        /** 				if delete_file(path & files[i][D_NAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_files_7350);
        _3943 = (int)*(((s1_ptr)_2)->base + _i_7390);
        _2 = (int)SEQ_PTR(_3943);
        _3944 = (int)*(((s1_ptr)_2)->base + 1);
        _3943 = NOVALUE;
        if (IS_SEQUENCE(_path_7348) && IS_ATOM(_3944)) {
            Ref(_3944);
            Append(&_3945, _path_7348, _3944);
        }
        else if (IS_ATOM(_path_7348) && IS_SEQUENCE(_3944)) {
        }
        else {
            Concat((object_ptr)&_3945, _path_7348, _3944);
        }
        _3944 = NOVALUE;
        _3946 = _11delete_file(_3945);
        _3945 = NOVALUE;
        if (binary_op_a(NOTEQ, _3946, 0)){
            DeRef(_3946);
            _3946 = NOVALUE;
            goto L10; // [303] 314
        }
        DeRef(_3946);
        _3946 = NOVALUE;

        /** 					return 0*/
        DeRefDS(_path_7348);
        DeRef(_files_7350);
        DeRef(_3912);
        _3912 = NOVALUE;
        return 0;
L10: 

        /** 				ret += 1*/
        _ret_7351 = _ret_7351 + 1;
LF: 

        /** 		end for*/
LD: 
        _i_7390 = _i_7390 + 1;
        goto LA; // [323] 206
LB: 
        ;
    }

    /** 	return ret*/
    DeRefDS(_path_7348);
    DeRef(_files_7350);
    DeRef(_3912);
    _3912 = NOVALUE;
    return _ret_7351;
    ;
}


int  __stdcall _11remove_directory(int _dir_name_7417, int _force_7418)
{
    int _pname_7419 = NOVALUE;
    int _ret_7420 = NOVALUE;
    int _files_7421 = NOVALUE;
    int _D_NAME_7422 = NOVALUE;
    int _D_ATTRIBUTES_7423 = NOVALUE;
    int _dir_inlined_dir_at_97_7444 = NOVALUE;
    int _3993 = NOVALUE;
    int _3989 = NOVALUE;
    int _3988 = NOVALUE;
    int _3987 = NOVALUE;
    int _3985 = NOVALUE;
    int _3984 = NOVALUE;
    int _3983 = NOVALUE;
    int _3982 = NOVALUE;
    int _3981 = NOVALUE;
    int _3980 = NOVALUE;
    int _3979 = NOVALUE;
    int _3978 = NOVALUE;
    int _3974 = NOVALUE;
    int _3972 = NOVALUE;
    int _3971 = NOVALUE;
    int _3970 = NOVALUE;
    int _3968 = NOVALUE;
    int _3967 = NOVALUE;
    int _3966 = NOVALUE;
    int _3964 = NOVALUE;
    int _3963 = NOVALUE;
    int _3961 = NOVALUE;
    int _3959 = NOVALUE;
    int _3957 = NOVALUE;
    int _3955 = NOVALUE;
    int _3954 = NOVALUE;
    int _3952 = NOVALUE;
    int _3951 = NOVALUE;
    int _3949 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_force_7418)) {
        _1 = (long)(DBL_PTR(_force_7418)->dbl);
        DeRefDS(_force_7418);
        _force_7418 = _1;
    }

    /** 	integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_7422 = 1;
    _D_ATTRIBUTES_7423 = 2;

    /**  	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_7417)){
            _3949 = SEQ_PTR(_dir_name_7417)->length;
    }
    else {
        _3949 = 1;
    }
    if (_3949 <= 0)
    goto L1; // [18] 51

    /** 		if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_7417)){
            _3951 = SEQ_PTR(_dir_name_7417)->length;
    }
    else {
        _3951 = 1;
    }
    _2 = (int)SEQ_PTR(_dir_name_7417);
    _3952 = (int)*(((s1_ptr)_2)->base + _3951);
    if (binary_op_a(NOTEQ, _3952, 92)){
        _3952 = NOVALUE;
        goto L2; // [31] 50
    }
    _3952 = NOVALUE;

    /** 			dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_7417)){
            _3954 = SEQ_PTR(_dir_name_7417)->length;
    }
    else {
        _3954 = 1;
    }
    _3955 = _3954 - 1;
    _3954 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_7417;
    RHS_Slice(_dir_name_7417, 1, _3955);
L2: 
L1: 

    /** 	if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_7417)){
            _3957 = SEQ_PTR(_dir_name_7417)->length;
    }
    else {
        _3957 = 1;
    }
    if (_3957 != 0)
    goto L3; // [56] 67

    /** 		return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(dir_name) = 2 then*/
    if (IS_SEQUENCE(_dir_name_7417)){
            _3959 = SEQ_PTR(_dir_name_7417)->length;
    }
    else {
        _3959 = 1;
    }
    if (_3959 != 2)
    goto L4; // [74] 96

    /** 			if dir_name[2] = ':' then*/
    _2 = (int)SEQ_PTR(_dir_name_7417);
    _3961 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3961, 58)){
        _3961 = NOVALUE;
        goto L5; // [84] 95
    }
    _3961 = NOVALUE;

    /** 				return 0 -- nothing specified to delete*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L5: 
L4: 

    /** 	files = dir(dir_name)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_files_7421);
    _files_7421 = machine(22, _dir_name_7417);

    /** 	if atom(files) then*/
    _3963 = IS_ATOM(_files_7421);
    if (_3963 == 0)
    {
        _3963 = NOVALUE;
        goto L6; // [112] 122
    }
    else{
        _3963 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L6: 

    /** 	if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_7421)){
            _3964 = SEQ_PTR(_files_7421)->length;
    }
    else {
        _3964 = 1;
    }
    if (_3964 >= 2)
    goto L7; // [127] 138

    /** 		return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L7: 

    /** 	ifdef WINDOWS then*/

    /** 		if not equal(files[1][D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_files_7421);
    _3966 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3966);
    _3967 = (int)*(((s1_ptr)_2)->base + _D_NAME_7422);
    _3966 = NOVALUE;
    if (_3967 == _3819)
    _3968 = 1;
    else if (IS_ATOM_INT(_3967) && IS_ATOM_INT(_3819))
    _3968 = 0;
    else
    _3968 = (compare(_3967, _3819) == 0);
    _3967 = NOVALUE;
    if (_3968 != 0)
    goto L8; // [154] 164
    _3968 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L8: 

    /** 		if not eu:find('d', files[1][D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_files_7421);
    _3970 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3970);
    _3971 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_7423);
    _3970 = NOVALUE;
    _3972 = find_from(100, _3971, 1);
    _3971 = NOVALUE;
    if (_3972 != 0)
    goto L9; // [179] 189
    _3972 = NOVALUE;

    /** 			return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
L9: 

    /** 		if length(files) > 2 then*/
    if (IS_SEQUENCE(_files_7421)){
            _3974 = SEQ_PTR(_files_7421)->length;
    }
    else {
        _3974 = 1;
    }
    if (_3974 <= 2)
    goto LA; // [194] 211

    /** 			if not force then*/
    if (_force_7418 != 0)
    goto LB; // [200] 210

    /** 				return 0 -- Directory is not already emptied.*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_ret_7420);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return 0;
LB: 
LA: 

    /** 	dir_name &= SLASH*/
    Append(&_dir_name_7417, _dir_name_7417, 92);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 3 to length(files) do*/
    if (IS_SEQUENCE(_files_7421)){
            _3978 = SEQ_PTR(_files_7421)->length;
    }
    else {
        _3978 = 1;
    }
    {
        int _i_7467;
        _i_7467 = 3;
LC: 
        if (_i_7467 > _3978){
            goto LD; // [224] 316
        }

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_7421);
        _3979 = (int)*(((s1_ptr)_2)->base + _i_7467);
        _2 = (int)SEQ_PTR(_3979);
        _3980 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_7423);
        _3979 = NOVALUE;
        _3981 = find_from(100, _3980, 1);
        _3980 = NOVALUE;
        if (_3981 == 0)
        {
            _3981 = NOVALUE;
            goto LE; // [246] 276
        }
        else{
            _3981 = NOVALUE;
        }

        /** 				ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (int)SEQ_PTR(_files_7421);
        _3982 = (int)*(((s1_ptr)_2)->base + _i_7467);
        _2 = (int)SEQ_PTR(_3982);
        _3983 = (int)*(((s1_ptr)_2)->base + _D_NAME_7422);
        _3982 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 92;
            concat_list[1] = _3983;
            concat_list[2] = _dir_name_7417;
            Concat_N((object_ptr)&_3984, concat_list, 3);
        }
        _3983 = NOVALUE;
        DeRef(_3985);
        _3985 = _force_7418;
        _0 = _ret_7420;
        _ret_7420 = _11remove_directory(_3984, _3985);
        DeRef(_0);
        _3984 = NOVALUE;
        _3985 = NOVALUE;
        goto LF; // [273] 295
LE: 

        /** 				ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (int)SEQ_PTR(_files_7421);
        _3987 = (int)*(((s1_ptr)_2)->base + _i_7467);
        _2 = (int)SEQ_PTR(_3987);
        _3988 = (int)*(((s1_ptr)_2)->base + _D_NAME_7422);
        _3987 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_7417) && IS_ATOM(_3988)) {
            Ref(_3988);
            Append(&_3989, _dir_name_7417, _3988);
        }
        else if (IS_ATOM(_dir_name_7417) && IS_SEQUENCE(_3988)) {
        }
        else {
            Concat((object_ptr)&_3989, _dir_name_7417, _3988);
        }
        _3988 = NOVALUE;
        _0 = _ret_7420;
        _ret_7420 = _11delete_file(_3989);
        DeRef(_0);
        _3989 = NOVALUE;
LF: 

        /** 			if not ret then*/
        if (IS_ATOM_INT(_ret_7420)) {
            if (_ret_7420 != 0){
                goto L10; // [299] 309
            }
        }
        else {
            if (DBL_PTR(_ret_7420)->dbl != 0.0){
                goto L10; // [299] 309
            }
        }

        /** 				return 0*/
        DeRefDS(_dir_name_7417);
        DeRef(_pname_7419);
        DeRef(_ret_7420);
        DeRef(_files_7421);
        DeRef(_3955);
        _3955 = NOVALUE;
        return 0;
L10: 

        /** 		end for*/
        _i_7467 = _i_7467 + 1;
        goto LC; // [311] 231
LD: 
        ;
    }

    /** 	pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_7417);
    _0 = _pname_7419;
    _pname_7419 = _14allocate_string(_dir_name_7417, 0);
    DeRef(_0);

    /** 	ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pname_7419);
    *((int *)(_2+4)) = _pname_7419;
    _3993 = MAKE_SEQ(_1);
    DeRef(_ret_7420);
    _ret_7420 = call_c(1, _11xRemoveDirectory_7113, _3993);
    DeRefDS(_3993);
    _3993 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 	machine:free(pname)*/
    Ref(_pname_7419);
    _14free(_pname_7419);

    /** 	return ret*/
    DeRefDS(_dir_name_7417);
    DeRef(_pname_7419);
    DeRef(_files_7421);
    DeRef(_3955);
    _3955 = NOVALUE;
    return _ret_7420;
    ;
}


int  __stdcall _11pathinfo(int _path_7495, int _std_slash_7496)
{
    int _slash_7497 = NOVALUE;
    int _period_7498 = NOVALUE;
    int _ch_7499 = NOVALUE;
    int _dir_name_7500 = NOVALUE;
    int _file_name_7501 = NOVALUE;
    int _file_ext_7502 = NOVALUE;
    int _file_full_7503 = NOVALUE;
    int _drive_id_7504 = NOVALUE;
    int _from_slash_7544 = NOVALUE;
    int _4027 = NOVALUE;
    int _4020 = NOVALUE;
    int _4019 = NOVALUE;
    int _4016 = NOVALUE;
    int _4015 = NOVALUE;
    int _4013 = NOVALUE;
    int _4012 = NOVALUE;
    int _4009 = NOVALUE;
    int _4008 = NOVALUE;
    int _4006 = NOVALUE;
    int _4002 = NOVALUE;
    int _4000 = NOVALUE;
    int _3999 = NOVALUE;
    int _3998 = NOVALUE;
    int _3997 = NOVALUE;
    int _3995 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_std_slash_7496)) {
        _1 = (long)(DBL_PTR(_std_slash_7496)->dbl);
        DeRefDS(_std_slash_7496);
        _std_slash_7496 = _1;
    }

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_7500);
    _dir_name_7500 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_7501);
    _file_name_7501 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_7502);
    _file_ext_7502 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_7503);
    _file_full_7503 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_7504);
    _drive_id_7504 = _5;

    /** 	slash = 0*/
    _slash_7497 = 0;

    /** 	period = 0*/
    _period_7498 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7495)){
            _3995 = SEQ_PTR(_path_7495)->length;
    }
    else {
        _3995 = 1;
    }
    {
        int _i_7506;
        _i_7506 = _3995;
L1: 
        if (_i_7506 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_7495);
        _ch_7499 = (int)*(((s1_ptr)_2)->base + _i_7506);
        if (!IS_ATOM_INT(_ch_7499))
        _ch_7499 = (long)DBL_PTR(_ch_7499)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _3997 = (_period_7498 == 0);
        if (_3997 == 0) {
            goto L3; // [74] 94
        }
        _3999 = (_ch_7499 == 46);
        if (_3999 == 0)
        {
            DeRef(_3999);
            _3999 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3999);
            _3999 = NOVALUE;
        }

        /** 			period = i*/
        _period_7498 = _i_7506;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _4000 = find_from(_ch_7499, _11SLASHES_7130, 1);
        if (_4000 == 0)
        {
            _4000 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _4000 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_7497 = _i_7506;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_7506 = _i_7506 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_7497 <= 0)
    goto L6; // [124] 181

    /** 		dir_name = path[1..slash-1]*/
    _4002 = _slash_7497 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_7500;
    RHS_Slice(_path_7495, 1, _4002);

    /** 		ifdef not UNIX then*/

    /** 			ch = eu:find(':', dir_name)*/
    _ch_7499 = find_from(58, _dir_name_7500, 1);

    /** 			if ch != 0 then*/
    if (_ch_7499 == 0)
    goto L7; // [150] 180

    /** 				drive_id = dir_name[1..ch-1]*/
    _4006 = _ch_7499 - 1;
    rhs_slice_target = (object_ptr)&_drive_id_7504;
    RHS_Slice(_dir_name_7500, 1, _4006);

    /** 				dir_name = dir_name[ch+1..$]*/
    _4008 = _ch_7499 + 1;
    if (IS_SEQUENCE(_dir_name_7500)){
            _4009 = SEQ_PTR(_dir_name_7500)->length;
    }
    else {
        _4009 = 1;
    }
    rhs_slice_target = (object_ptr)&_dir_name_7500;
    RHS_Slice(_dir_name_7500, _4008, _4009);
L7: 
L6: 

    /** 	if period > 0 then*/
    if (_period_7498 <= 0)
    goto L8; // [183] 227

    /** 		file_name = path[slash+1..period-1]*/
    _4012 = _slash_7497 + 1;
    if (_4012 > MAXINT){
        _4012 = NewDouble((double)_4012);
    }
    _4013 = _period_7498 - 1;
    rhs_slice_target = (object_ptr)&_file_name_7501;
    RHS_Slice(_path_7495, _4012, _4013);

    /** 		file_ext = path[period+1..$]*/
    _4015 = _period_7498 + 1;
    if (_4015 > MAXINT){
        _4015 = NewDouble((double)_4015);
    }
    if (IS_SEQUENCE(_path_7495)){
            _4016 = SEQ_PTR(_path_7495)->length;
    }
    else {
        _4016 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_7502;
    RHS_Slice(_path_7495, _4015, _4016);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_7502;
        concat_list[1] = 46;
        concat_list[2] = _file_name_7501;
        Concat_N((object_ptr)&_file_full_7503, concat_list, 3);
    }
    goto L9; // [224] 249
L8: 

    /** 		file_name = path[slash+1..$]*/
    _4019 = _slash_7497 + 1;
    if (_4019 > MAXINT){
        _4019 = NewDouble((double)_4019);
    }
    if (IS_SEQUENCE(_path_7495)){
            _4020 = SEQ_PTR(_path_7495)->length;
    }
    else {
        _4020 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_7501;
    RHS_Slice(_path_7495, _4019, _4020);

    /** 		file_full = file_name*/
    RefDS(_file_name_7501);
    DeRef(_file_full_7503);
    _file_full_7503 = _file_name_7501;
L9: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_7496 == 0)
    goto LA; // [251] 317

    /** 		if std_slash < 0 then*/
    if (_std_slash_7496 >= 0)
    goto LB; // [257] 293

    /** 			std_slash = SLASH*/
    _std_slash_7496 = 92;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "/"*/
    RefDS(_3806);
    DeRefi(_from_slash_7544);
    _from_slash_7544 = _3806;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_7544);
    RefDS(_dir_name_7500);
    _0 = _dir_name_7500;
    _dir_name_7500 = _9match_replace(_from_slash_7544, _dir_name_7500, 92, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_7544);
    _from_slash_7544 = NOVALUE;
    goto LC; // [290] 316
LB: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_910);
    RefDS(_dir_name_7500);
    _0 = _dir_name_7500;
    _dir_name_7500 = _9match_replace(_910, _dir_name_7500, _std_slash_7496, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3806);
    RefDS(_dir_name_7500);
    _0 = _dir_name_7500;
    _dir_name_7500 = _9match_replace(_3806, _dir_name_7500, _std_slash_7496, 0);
    DeRefDS(_0);
LC: 
LA: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_7500);
    *((int *)(_2+4)) = _dir_name_7500;
    RefDS(_file_full_7503);
    *((int *)(_2+8)) = _file_full_7503;
    RefDS(_file_name_7501);
    *((int *)(_2+12)) = _file_name_7501;
    RefDS(_file_ext_7502);
    *((int *)(_2+16)) = _file_ext_7502;
    RefDS(_drive_id_7504);
    *((int *)(_2+20)) = _drive_id_7504;
    _4027 = MAKE_SEQ(_1);
    DeRefDS(_path_7495);
    DeRefDS(_dir_name_7500);
    DeRefDS(_file_name_7501);
    DeRefDS(_file_ext_7502);
    DeRefDS(_file_full_7503);
    DeRefDS(_drive_id_7504);
    DeRef(_3997);
    _3997 = NOVALUE;
    DeRef(_4002);
    _4002 = NOVALUE;
    DeRef(_4006);
    _4006 = NOVALUE;
    DeRef(_4008);
    _4008 = NOVALUE;
    DeRef(_4012);
    _4012 = NOVALUE;
    DeRef(_4013);
    _4013 = NOVALUE;
    DeRef(_4015);
    _4015 = NOVALUE;
    DeRef(_4019);
    _4019 = NOVALUE;
    return _4027;
    ;
}


int  __stdcall _11dirname(int _path_7552, int _pcd_7553)
{
    int _data_7554 = NOVALUE;
    int _4032 = NOVALUE;
    int _4030 = NOVALUE;
    int _4029 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pcd_7553)) {
        _1 = (long)(DBL_PTR(_pcd_7553)->dbl);
        DeRefDS(_pcd_7553);
        _pcd_7553 = _1;
    }

    /** 	data = pathinfo(path)*/
    RefDS(_path_7552);
    _0 = _data_7554;
    _data_7554 = _11pathinfo(_path_7552, 0);
    DeRef(_0);

    /** 	if pcd then*/
    if (_pcd_7553 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** 		if length(data[1]) = 0 then*/
    _2 = (int)SEQ_PTR(_data_7554);
    _4029 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_4029)){
            _4030 = SEQ_PTR(_4029)->length;
    }
    else {
        _4030 = 1;
    }
    _4029 = NOVALUE;
    if (_4030 != 0)
    goto L2; // [28] 39

    /** 			return "."*/
    RefDS(_3819);
    DeRefDS(_path_7552);
    DeRefDS(_data_7554);
    _4029 = NOVALUE;
    return _3819;
L2: 
L1: 

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_7554);
    _4032 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4032);
    DeRefDS(_path_7552);
    DeRefDS(_data_7554);
    _4029 = NOVALUE;
    return _4032;
    ;
}


int  __stdcall _11pathname(int _path_7564)
{
    int _data_7565 = NOVALUE;
    int _stop_7566 = NOVALUE;
    int _4037 = NOVALUE;
    int _4036 = NOVALUE;
    int _4034 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = canonical_path(path)*/
    RefDS(_path_7564);
    _0 = _data_7565;
    _data_7565 = _11canonical_path(_path_7564, 0, 0);
    DeRef(_0);

    /** 	stop = search:rfind(SLASH, data)*/
    if (IS_SEQUENCE(_data_7565)){
            _4034 = SEQ_PTR(_data_7565)->length;
    }
    else {
        _4034 = 1;
    }
    RefDS(_data_7565);
    _stop_7566 = _9rfind(92, _data_7565, _4034);
    _4034 = NOVALUE;
    if (!IS_ATOM_INT(_stop_7566)) {
        _1 = (long)(DBL_PTR(_stop_7566)->dbl);
        DeRefDS(_stop_7566);
        _stop_7566 = _1;
    }

    /** 	return data[1 .. stop - 1]*/
    _4036 = _stop_7566 - 1;
    rhs_slice_target = (object_ptr)&_4037;
    RHS_Slice(_data_7565, 1, _4036);
    DeRefDS(_path_7564);
    DeRefDS(_data_7565);
    _4036 = NOVALUE;
    return _4037;
    ;
}


int  __stdcall _11filename(int _path_7575)
{
    int _data_7576 = NOVALUE;
    int _4039 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7575);
    _0 = _data_7576;
    _data_7576 = _11pathinfo(_path_7575, 0);
    DeRef(_0);

    /** 	return data[2]*/
    _2 = (int)SEQ_PTR(_data_7576);
    _4039 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_4039);
    DeRefDS(_path_7575);
    DeRefDS(_data_7576);
    return _4039;
    ;
}


int  __stdcall _11filebase(int _path_7581)
{
    int _data_7582 = NOVALUE;
    int _4041 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7581);
    _0 = _data_7582;
    _data_7582 = _11pathinfo(_path_7581, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_7582);
    _4041 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_4041);
    DeRefDS(_path_7581);
    DeRefDS(_data_7582);
    return _4041;
    ;
}


int  __stdcall _11fileext(int _path_7587)
{
    int _data_7588 = NOVALUE;
    int _4043 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7587);
    _0 = _data_7588;
    _data_7588 = _11pathinfo(_path_7587, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_7588);
    _4043 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_4043);
    DeRefDS(_path_7587);
    DeRefDS(_data_7588);
    return _4043;
    ;
}


int  __stdcall _11driveid(int _path_7593)
{
    int _data_7594 = NOVALUE;
    int _4045 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7593);
    _0 = _data_7594;
    _data_7594 = _11pathinfo(_path_7593, 0);
    DeRef(_0);

    /** 	return data[5]*/
    _2 = (int)SEQ_PTR(_data_7594);
    _4045 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_4045);
    DeRefDS(_path_7593);
    DeRefDS(_data_7594);
    return _4045;
    ;
}


int  __stdcall _11defaultext(int _path_7599, int _defext_7600)
{
    int _4058 = NOVALUE;
    int _4055 = NOVALUE;
    int _4053 = NOVALUE;
    int _4052 = NOVALUE;
    int _4051 = NOVALUE;
    int _4049 = NOVALUE;
    int _4048 = NOVALUE;
    int _4046 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    if (IS_SEQUENCE(_defext_7600)){
            _4046 = SEQ_PTR(_defext_7600)->length;
    }
    else {
        _4046 = 1;
    }
    if (_4046 != 0)
    goto L1; // [10] 21

    /** 		return path*/
    DeRefDS(_defext_7600);
    return _path_7599;
L1: 

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7599)){
            _4048 = SEQ_PTR(_path_7599)->length;
    }
    else {
        _4048 = 1;
    }
    {
        int _i_7605;
        _i_7605 = _4048;
L2: 
        if (_i_7605 < 1){
            goto L3; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_7599);
        _4049 = (int)*(((s1_ptr)_2)->base + _i_7605);
        if (binary_op_a(NOTEQ, _4049, 46)){
            _4049 = NOVALUE;
            goto L4; // [39] 50
        }
        _4049 = NOVALUE;

        /** 			return path*/
        DeRefDS(_defext_7600);
        return _path_7599;
L4: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_7599);
        _4051 = (int)*(((s1_ptr)_2)->base + _i_7605);
        _4052 = find_from(_4051, _11SLASHES_7130, 1);
        _4051 = NOVALUE;
        if (_4052 == 0)
        {
            _4052 = NOVALUE;
            goto L5; // [61] 88
        }
        else{
            _4052 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_7599)){
                _4053 = SEQ_PTR(_path_7599)->length;
        }
        else {
            _4053 = 1;
        }
        if (_i_7605 != _4053)
        goto L3; // [69] 95

        /** 				return path*/
        DeRefDS(_defext_7600);
        return _path_7599;
        goto L6; // [79] 87

        /** 				exit*/
        goto L3; // [84] 95
L6: 
L5: 

        /** 	end for*/
        _i_7605 = _i_7605 + -1;
        goto L2; // [90] 33
L3: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_7600);
    _4055 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4055, 46)){
        _4055 = NOVALUE;
        goto L7; // [101] 112
    }
    _4055 = NOVALUE;

    /** 		path &= '.'*/
    Append(&_path_7599, _path_7599, 46);
L7: 

    /** 	return path & defext*/
    Concat((object_ptr)&_4058, _path_7599, _defext_7600);
    DeRefDS(_path_7599);
    DeRefDS(_defext_7600);
    return _4058;
    ;
}


int  __stdcall _11absolute_path(int _filename_7624)
{
    int _4070 = NOVALUE;
    int _4069 = NOVALUE;
    int _4067 = NOVALUE;
    int _4065 = NOVALUE;
    int _4063 = NOVALUE;
    int _4062 = NOVALUE;
    int _4061 = NOVALUE;
    int _4059 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_7624)){
            _4059 = SEQ_PTR(_filename_7624)->length;
    }
    else {
        _4059 = 1;
    }
    if (_4059 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_7624);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_7624);
    _4061 = (int)*(((s1_ptr)_2)->base + 1);
    _4062 = find_from(_4061, _11SLASHES_7130, 1);
    _4061 = NOVALUE;
    if (_4062 == 0)
    {
        _4062 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _4062 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_7624);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 1 then*/
    if (IS_SEQUENCE(_filename_7624)){
            _4063 = SEQ_PTR(_filename_7624)->length;
    }
    else {
        _4063 = 1;
    }
    if (_4063 != 1)
    goto L3; // [47] 58

    /** 			return 0*/
    DeRefDS(_filename_7624);
    return 0;
L3: 

    /** 		if filename[2] != ':' then*/
    _2 = (int)SEQ_PTR(_filename_7624);
    _4065 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _4065, 58)){
        _4065 = NOVALUE;
        goto L4; // [64] 75
    }
    _4065 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_filename_7624);
    return 0;
L4: 

    /** 		if length(filename) < 3 then*/
    if (IS_SEQUENCE(_filename_7624)){
            _4067 = SEQ_PTR(_filename_7624)->length;
    }
    else {
        _4067 = 1;
    }
    if (_4067 >= 3)
    goto L5; // [80] 91

    /** 			return 0*/
    DeRefDS(_filename_7624);
    return 0;
L5: 

    /** 		if eu:find(filename[3], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_7624);
    _4069 = (int)*(((s1_ptr)_2)->base + 3);
    _4070 = find_from(_4069, _11SLASHES_7130, 1);
    _4069 = NOVALUE;
    if (_4070 == 0)
    {
        _4070 = NOVALUE;
        goto L6; // [102] 112
    }
    else{
        _4070 = NOVALUE;
    }

    /** 			return 1*/
    DeRefDS(_filename_7624);
    return 1;
L6: 

    /** 	return 0*/
    DeRefDS(_filename_7624);
    return 0;
    ;
}


int  __stdcall _11case_flagset_type(int _x_7656)
{
    int _4079 = NOVALUE;
    int _4078 = NOVALUE;
    int _4077 = NOVALUE;
    int _4076 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_7656)) {
        _1 = (long)(DBL_PTR(_x_7656)->dbl);
        DeRefDS(_x_7656);
        _x_7656 = _1;
    }

    /** 	return x >= AS_IS and x < 2*TO_SHORT*/
    _4076 = (_x_7656 >= 0);
    _4077 = 8;
    _4078 = (_x_7656 < 8);
    _4077 = NOVALUE;
    _4079 = (_4076 != 0 && _4078 != 0);
    _4076 = NOVALUE;
    _4078 = NOVALUE;
    return _4079;
    ;
}


int  __stdcall _11canonical_path(int _path_in_7663, int _directory_given_7664, int _case_flags_7665)
{
    int _lPath_7666 = NOVALUE;
    int _lPosA_7667 = NOVALUE;
    int _lPosB_7668 = NOVALUE;
    int _lLevel_7669 = NOVALUE;
    int _lHome_7670 = NOVALUE;
    int _lDrive_7671 = NOVALUE;
    int _current_dir_inlined_current_dir_at_300_7731 = NOVALUE;
    int _driveid_inlined_driveid_at_307_7734 = NOVALUE;
    int _data_inlined_driveid_at_307_7733 = NOVALUE;
    int _wildcard_suffix_7736 = NOVALUE;
    int _first_wildcard_at_7737 = NOVALUE;
    int _last_slash_7740 = NOVALUE;
    int _sl_7812 = NOVALUE;
    int _short_name_7815 = NOVALUE;
    int _correct_name_7818 = NOVALUE;
    int _lower_name_7821 = NOVALUE;
    int _part_7837 = NOVALUE;
    int _list_7841 = NOVALUE;
    int _dir_inlined_dir_at_867_7845 = NOVALUE;
    int _name_inlined_dir_at_864_7844 = NOVALUE;
    int _supplied_name_7846 = NOVALUE;
    int _read_name_7865 = NOVALUE;
    int _read_name_7890 = NOVALUE;
    int _4291 = NOVALUE;
    int _4288 = NOVALUE;
    int _4284 = NOVALUE;
    int _4283 = NOVALUE;
    int _4281 = NOVALUE;
    int _4280 = NOVALUE;
    int _4279 = NOVALUE;
    int _4278 = NOVALUE;
    int _4277 = NOVALUE;
    int _4275 = NOVALUE;
    int _4274 = NOVALUE;
    int _4273 = NOVALUE;
    int _4272 = NOVALUE;
    int _4271 = NOVALUE;
    int _4270 = NOVALUE;
    int _4269 = NOVALUE;
    int _4268 = NOVALUE;
    int _4266 = NOVALUE;
    int _4265 = NOVALUE;
    int _4264 = NOVALUE;
    int _4263 = NOVALUE;
    int _4262 = NOVALUE;
    int _4261 = NOVALUE;
    int _4260 = NOVALUE;
    int _4259 = NOVALUE;
    int _4258 = NOVALUE;
    int _4256 = NOVALUE;
    int _4255 = NOVALUE;
    int _4254 = NOVALUE;
    int _4253 = NOVALUE;
    int _4252 = NOVALUE;
    int _4251 = NOVALUE;
    int _4250 = NOVALUE;
    int _4249 = NOVALUE;
    int _4248 = NOVALUE;
    int _4247 = NOVALUE;
    int _4246 = NOVALUE;
    int _4245 = NOVALUE;
    int _4244 = NOVALUE;
    int _4243 = NOVALUE;
    int _4242 = NOVALUE;
    int _4240 = NOVALUE;
    int _4239 = NOVALUE;
    int _4238 = NOVALUE;
    int _4237 = NOVALUE;
    int _4236 = NOVALUE;
    int _4234 = NOVALUE;
    int _4233 = NOVALUE;
    int _4232 = NOVALUE;
    int _4231 = NOVALUE;
    int _4230 = NOVALUE;
    int _4229 = NOVALUE;
    int _4228 = NOVALUE;
    int _4227 = NOVALUE;
    int _4226 = NOVALUE;
    int _4225 = NOVALUE;
    int _4224 = NOVALUE;
    int _4223 = NOVALUE;
    int _4222 = NOVALUE;
    int _4220 = NOVALUE;
    int _4219 = NOVALUE;
    int _4217 = NOVALUE;
    int _4216 = NOVALUE;
    int _4215 = NOVALUE;
    int _4214 = NOVALUE;
    int _4213 = NOVALUE;
    int _4211 = NOVALUE;
    int _4210 = NOVALUE;
    int _4209 = NOVALUE;
    int _4208 = NOVALUE;
    int _4207 = NOVALUE;
    int _4206 = NOVALUE;
    int _4204 = NOVALUE;
    int _4203 = NOVALUE;
    int _4201 = NOVALUE;
    int _4200 = NOVALUE;
    int _4198 = NOVALUE;
    int _4197 = NOVALUE;
    int _4196 = NOVALUE;
    int _4194 = NOVALUE;
    int _4193 = NOVALUE;
    int _4191 = NOVALUE;
    int _4189 = NOVALUE;
    int _4187 = NOVALUE;
    int _4180 = NOVALUE;
    int _4177 = NOVALUE;
    int _4176 = NOVALUE;
    int _4175 = NOVALUE;
    int _4174 = NOVALUE;
    int _4168 = NOVALUE;
    int _4164 = NOVALUE;
    int _4163 = NOVALUE;
    int _4162 = NOVALUE;
    int _4161 = NOVALUE;
    int _4160 = NOVALUE;
    int _4158 = NOVALUE;
    int _4155 = NOVALUE;
    int _4154 = NOVALUE;
    int _4153 = NOVALUE;
    int _4152 = NOVALUE;
    int _4151 = NOVALUE;
    int _4150 = NOVALUE;
    int _4148 = NOVALUE;
    int _4147 = NOVALUE;
    int _4145 = NOVALUE;
    int _4143 = NOVALUE;
    int _4142 = NOVALUE;
    int _4141 = NOVALUE;
    int _4139 = NOVALUE;
    int _4138 = NOVALUE;
    int _4137 = NOVALUE;
    int _4136 = NOVALUE;
    int _4134 = NOVALUE;
    int _4132 = NOVALUE;
    int _4127 = NOVALUE;
    int _4125 = NOVALUE;
    int _4124 = NOVALUE;
    int _4123 = NOVALUE;
    int _4122 = NOVALUE;
    int _4121 = NOVALUE;
    int _4119 = NOVALUE;
    int _4118 = NOVALUE;
    int _4116 = NOVALUE;
    int _4115 = NOVALUE;
    int _4114 = NOVALUE;
    int _4113 = NOVALUE;
    int _4112 = NOVALUE;
    int _4111 = NOVALUE;
    int _4110 = NOVALUE;
    int _4107 = NOVALUE;
    int _4106 = NOVALUE;
    int _4104 = NOVALUE;
    int _4102 = NOVALUE;
    int _4100 = NOVALUE;
    int _4097 = NOVALUE;
    int _4096 = NOVALUE;
    int _4095 = NOVALUE;
    int _4094 = NOVALUE;
    int _4093 = NOVALUE;
    int _4091 = NOVALUE;
    int _4090 = NOVALUE;
    int _4089 = NOVALUE;
    int _4088 = NOVALUE;
    int _4087 = NOVALUE;
    int _4086 = NOVALUE;
    int _4085 = NOVALUE;
    int _4084 = NOVALUE;
    int _4083 = NOVALUE;
    int _4082 = NOVALUE;
    int _4081 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_directory_given_7664)) {
        _1 = (long)(DBL_PTR(_directory_given_7664)->dbl);
        DeRefDS(_directory_given_7664);
        _directory_given_7664 = _1;
    }
    if (!IS_ATOM_INT(_case_flags_7665)) {
        _1 = (long)(DBL_PTR(_case_flags_7665)->dbl);
        DeRefDS(_case_flags_7665);
        _case_flags_7665 = _1;
    }

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_7666);
    _lPath_7666 = _5;

    /**     integer lPosA = -1*/
    _lPosA_7667 = -1;

    /**     integer lPosB = -1*/
    _lPosB_7668 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_7669);
    _lLevel_7669 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_7663);
    DeRefDS(_path_in_7663);
    _path_in_7663 = _path_in_7663;

    /** 	ifdef UNIX then*/

    /** 	    sequence lDrive*/

    /** 	    lPath = match_replace("/", path_in, SLASH)*/
    RefDS(_3806);
    RefDS(_path_in_7663);
    _0 = _lPath_7666;
    _lPath_7666 = _9match_replace(_3806, _path_in_7663, 92, 0);
    DeRefDS(_0);

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4081 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4081 = 1;
    }
    _4082 = (_4081 > 2);
    _4081 = NOVALUE;
    if (_4082 == 0) {
        _4083 = 0;
        goto L1; // [62] 78
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4084 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4084)) {
        _4085 = (_4084 == 34);
    }
    else {
        _4085 = binary_op(EQUALS, _4084, 34);
    }
    _4084 = NOVALUE;
    if (IS_ATOM_INT(_4085))
    _4083 = (_4085 != 0);
    else
    _4083 = DBL_PTR(_4085)->dbl != 0.0;
L1: 
    if (_4083 == 0) {
        DeRef(_4086);
        _4086 = 0;
        goto L2; // [78] 97
    }
    if (IS_SEQUENCE(_lPath_7666)){
            _4087 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4087 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4088 = (int)*(((s1_ptr)_2)->base + _4087);
    if (IS_ATOM_INT(_4088)) {
        _4089 = (_4088 == 34);
    }
    else {
        _4089 = binary_op(EQUALS, _4088, 34);
    }
    _4088 = NOVALUE;
    if (IS_ATOM_INT(_4089))
    _4086 = (_4089 != 0);
    else
    _4086 = DBL_PTR(_4089)->dbl != 0.0;
L2: 
    if (_4086 == 0)
    {
        _4086 = NOVALUE;
        goto L3; // [97] 115
    }
    else{
        _4086 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4090 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4090 = 1;
    }
    _4091 = _4090 - 1;
    _4090 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_7666;
    RHS_Slice(_lPath_7666, 2, _4091);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4093 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4093 = 1;
    }
    _4094 = (_4093 > 0);
    _4093 = NOVALUE;
    if (_4094 == 0) {
        DeRef(_4095);
        _4095 = 0;
        goto L4; // [124] 140
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4096 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4096)) {
        _4097 = (_4096 == 126);
    }
    else {
        _4097 = binary_op(EQUALS, _4096, 126);
    }
    _4096 = NOVALUE;
    if (IS_ATOM_INT(_4097))
    _4095 = (_4097 != 0);
    else
    _4095 = DBL_PTR(_4097)->dbl != 0.0;
L4: 
    if (_4095 == 0)
    {
        _4095 = NOVALUE;
        goto L5; // [140] 249
    }
    else{
        _4095 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRef(_lHome_7670);
    _lHome_7670 = EGetEnv(_4098);

    /** 		ifdef WINDOWS then*/

    /** 			if atom(lHome) then*/
    _4100 = IS_ATOM(_lHome_7670);
    if (_4100 == 0)
    {
        _4100 = NOVALUE;
        goto L6; // [155] 171
    }
    else{
        _4100 = NOVALUE;
    }

    /** 				lHome = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4102 = EGetEnv(_4101);
    _4104 = EGetEnv(_4103);
    if (IS_SEQUENCE(_4102) && IS_ATOM(_4104)) {
        Ref(_4104);
        Append(&_lHome_7670, _4102, _4104);
    }
    else if (IS_ATOM(_4102) && IS_SEQUENCE(_4104)) {
        Ref(_4102);
        Prepend(&_lHome_7670, _4104, _4102);
    }
    else {
        Concat((object_ptr)&_lHome_7670, _4102, _4104);
        DeRef(_4102);
        _4102 = NOVALUE;
    }
    DeRef(_4102);
    _4102 = NOVALUE;
    DeRef(_4104);
    _4104 = NOVALUE;
L6: 

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_7670)){
            _4106 = SEQ_PTR(_lHome_7670)->length;
    }
    else {
        _4106 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_7670);
    _4107 = (int)*(((s1_ptr)_2)->base + _4106);
    if (binary_op_a(EQUALS, _4107, 92)){
        _4107 = NOVALUE;
        goto L7; // [180] 191
    }
    _4107 = NOVALUE;

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_7670) && IS_ATOM(92)) {
        Append(&_lHome_7670, _lHome_7670, 92);
    }
    else if (IS_ATOM(_lHome_7670) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_lHome_7670, _lHome_7670, 92);
    }
L7: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4110 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4110 = 1;
    }
    _4111 = (_4110 > 1);
    _4110 = NOVALUE;
    if (_4111 == 0) {
        goto L8; // [200] 233
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4113 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4113)) {
        _4114 = (_4113 == 92);
    }
    else {
        _4114 = binary_op(EQUALS, _4113, 92);
    }
    _4113 = NOVALUE;
    if (_4114 == 0) {
        DeRef(_4114);
        _4114 = NOVALUE;
        goto L8; // [213] 233
    }
    else {
        if (!IS_ATOM_INT(_4114) && DBL_PTR(_4114)->dbl == 0.0){
            DeRef(_4114);
            _4114 = NOVALUE;
            goto L8; // [213] 233
        }
        DeRef(_4114);
        _4114 = NOVALUE;
    }
    DeRef(_4114);
    _4114 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4115 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4115 = 1;
    }
    rhs_slice_target = (object_ptr)&_4116;
    RHS_Slice(_lPath_7666, 3, _4115);
    if (IS_SEQUENCE(_lHome_7670) && IS_ATOM(_4116)) {
    }
    else if (IS_ATOM(_lHome_7670) && IS_SEQUENCE(_4116)) {
        Ref(_lHome_7670);
        Prepend(&_lPath_7666, _4116, _lHome_7670);
    }
    else {
        Concat((object_ptr)&_lPath_7666, _lHome_7670, _4116);
    }
    DeRefDS(_4116);
    _4116 = NOVALUE;
    goto L9; // [230] 248
L8: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4118 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4118 = 1;
    }
    rhs_slice_target = (object_ptr)&_4119;
    RHS_Slice(_lPath_7666, 2, _4118);
    if (IS_SEQUENCE(_lHome_7670) && IS_ATOM(_4119)) {
    }
    else if (IS_ATOM(_lHome_7670) && IS_SEQUENCE(_4119)) {
        Ref(_lHome_7670);
        Prepend(&_lPath_7666, _4119, _lHome_7670);
    }
    else {
        Concat((object_ptr)&_lPath_7666, _lHome_7670, _4119);
    }
    DeRefDS(_4119);
    _4119 = NOVALUE;
L9: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	    if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4121 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4121 = 1;
    }
    _4122 = (_4121 > 1);
    _4121 = NOVALUE;
    if (_4122 == 0) {
        DeRef(_4123);
        _4123 = 0;
        goto LA; // [260] 276
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4124 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4124)) {
        _4125 = (_4124 == 58);
    }
    else {
        _4125 = binary_op(EQUALS, _4124, 58);
    }
    _4124 = NOVALUE;
    if (IS_ATOM_INT(_4125))
    _4123 = (_4125 != 0);
    else
    _4123 = DBL_PTR(_4125)->dbl != 0.0;
LA: 
    if (_4123 == 0)
    {
        _4123 = NOVALUE;
        goto LB; // [276] 299
    }
    else{
        _4123 = NOVALUE;
    }

    /** 			lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_7671;
    RHS_Slice(_lPath_7666, 1, 2);

    /** 			lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4127 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4127 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_7666;
    RHS_Slice(_lPath_7666, 3, _4127);
    goto LC; // [296] 333
LB: 

    /** 			lDrive = driveid(current_dir()) & ':'*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_300_7731);
    _current_dir_inlined_current_dir_at_300_7731 = machine(23, 0);

    /** 	data = pathinfo(path)*/
    RefDS(_current_dir_inlined_current_dir_at_300_7731);
    _0 = _data_inlined_driveid_at_307_7733;
    _data_inlined_driveid_at_307_7733 = _11pathinfo(_current_dir_inlined_current_dir_at_300_7731, 0);
    DeRef(_0);

    /** 	return data[5]*/
    DeRef(_driveid_inlined_driveid_at_307_7734);
    _2 = (int)SEQ_PTR(_data_inlined_driveid_at_307_7733);
    _driveid_inlined_driveid_at_307_7734 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_driveid_inlined_driveid_at_307_7734);
    DeRef(_data_inlined_driveid_at_307_7733);
    _data_inlined_driveid_at_307_7733 = NOVALUE;
    if (IS_SEQUENCE(_driveid_inlined_driveid_at_307_7734) && IS_ATOM(58)) {
        Append(&_lDrive_7671, _driveid_inlined_driveid_at_307_7734, 58);
    }
    else if (IS_ATOM(_driveid_inlined_driveid_at_307_7734) && IS_SEQUENCE(58)) {
    }
    else {
        Concat((object_ptr)&_lDrive_7671, _driveid_inlined_driveid_at_307_7734, 58);
    }
LC: 

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_7666);
    _first_wildcard_at_7737 = _11find_first_wildcard(_lPath_7666, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_7737)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_7737)->dbl);
        DeRefDS(_first_wildcard_at_7737);
        _first_wildcard_at_7737 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_7737 == 0)
    {
        goto LD; // [346] 407
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_7666);
    _last_slash_7740 = _9rfind(92, _lPath_7666, _first_wildcard_at_7737);
    if (!IS_ATOM_INT(_last_slash_7740)) {
        _1 = (long)(DBL_PTR(_last_slash_7740)->dbl);
        DeRefDS(_last_slash_7740);
        _last_slash_7740 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_7740 == 0)
    {
        goto LE; // [361] 387
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4132 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4132 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_7736;
    RHS_Slice(_lPath_7666, _last_slash_7740, _4132);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4134 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4134 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7666);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_7740)) ? _last_slash_7740 : (long)(DBL_PTR(_last_slash_7740)->dbl);
        int stop = (IS_ATOM_INT(_4134)) ? _4134 : (long)(DBL_PTR(_4134)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7666), start, &_lPath_7666 );
            }
            else Tail(SEQ_PTR(_lPath_7666), stop+1, &_lPath_7666);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7666), start, &_lPath_7666);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7666 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7666)->ref == 1));
        }
    }
    _4134 = NOVALUE;
    goto LF; // [384] 402
LE: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_7666);
    DeRef(_wildcard_suffix_7736);
    _wildcard_suffix_7736 = _lPath_7666;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_7666);
    _lPath_7666 = _5;
LF: 
    goto L10; // [404] 415
LD: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_7736);
    _wildcard_suffix_7736 = _5;
L10: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4136 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4136 = 1;
    }
    _4137 = (_4136 == 0);
    _4136 = NOVALUE;
    if (_4137 != 0) {
        DeRef(_4138);
        _4138 = 1;
        goto L11; // [424] 444
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4139 = (int)*(((s1_ptr)_2)->base + 1);
    _4141 = find_from(_4139, _4140, 1);
    _4139 = NOVALUE;
    _4142 = (_4141 == 0);
    _4141 = NOVALUE;
    _4138 = (_4142 != 0);
L11: 
    if (_4138 == 0)
    {
        _4138 = NOVALUE;
        goto L12; // [444] 545
    }
    else{
        _4138 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_7671)){
            _4143 = SEQ_PTR(_lDrive_7671)->length;
    }
    else {
        _4143 = 1;
    }
    if (_4143 != 0)
    goto L13; // [456] 473

    /** 				lPath = curdir() & lPath*/
    _4145 = _11curdir(0);
    if (IS_SEQUENCE(_4145) && IS_ATOM(_lPath_7666)) {
    }
    else if (IS_ATOM(_4145) && IS_SEQUENCE(_lPath_7666)) {
        Ref(_4145);
        Prepend(&_lPath_7666, _lPath_7666, _4145);
    }
    else {
        Concat((object_ptr)&_lPath_7666, _4145, _lPath_7666);
        DeRef(_4145);
        _4145 = NOVALUE;
    }
    DeRef(_4145);
    _4145 = NOVALUE;
    goto L14; // [470] 488
L13: 

    /** 				lPath = curdir(lDrive[1]) & lPath*/
    _2 = (int)SEQ_PTR(_lDrive_7671);
    _4147 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4147);
    _4148 = _11curdir(_4147);
    _4147 = NOVALUE;
    if (IS_SEQUENCE(_4148) && IS_ATOM(_lPath_7666)) {
    }
    else if (IS_ATOM(_4148) && IS_SEQUENCE(_lPath_7666)) {
        Ref(_4148);
        Prepend(&_lPath_7666, _lPath_7666, _4148);
    }
    else {
        Concat((object_ptr)&_lPath_7666, _4148, _lPath_7666);
        DeRef(_4148);
        _4148 = NOVALUE;
    }
    DeRef(_4148);
    _4148 = NOVALUE;
L14: 

    /** 			if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4150 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4150 = 1;
    }
    _4151 = (_4150 > 1);
    _4150 = NOVALUE;
    if (_4151 == 0) {
        DeRef(_4152);
        _4152 = 0;
        goto L15; // [497] 513
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4153 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4153)) {
        _4154 = (_4153 == 58);
    }
    else {
        _4154 = binary_op(EQUALS, _4153, 58);
    }
    _4153 = NOVALUE;
    if (IS_ATOM_INT(_4154))
    _4152 = (_4154 != 0);
    else
    _4152 = DBL_PTR(_4154)->dbl != 0.0;
L15: 
    if (_4152 == 0)
    {
        _4152 = NOVALUE;
        goto L16; // [513] 544
    }
    else{
        _4152 = NOVALUE;
    }

    /** 				if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_7671)){
            _4155 = SEQ_PTR(_lDrive_7671)->length;
    }
    else {
        _4155 = 1;
    }
    if (_4155 != 0)
    goto L17; // [521] 533

    /** 					lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_7671;
    RHS_Slice(_lPath_7666, 1, 2);
L17: 

    /** 				lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4158 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4158 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_7666;
    RHS_Slice(_lPath_7666, 3, _4158);
L16: 
L12: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _4160 = (_directory_given_7664 != 0);
    if (_4160 == 0) {
        DeRef(_4161);
        _4161 = 0;
        goto L18; // [551] 570
    }
    if (IS_SEQUENCE(_lPath_7666)){
            _4162 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4162 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4163 = (int)*(((s1_ptr)_2)->base + _4162);
    if (IS_ATOM_INT(_4163)) {
        _4164 = (_4163 != 92);
    }
    else {
        _4164 = binary_op(NOTEQ, _4163, 92);
    }
    _4163 = NOVALUE;
    if (IS_ATOM_INT(_4164))
    _4161 = (_4164 != 0);
    else
    _4161 = DBL_PTR(_4164)->dbl != 0.0;
L18: 
    if (_4161 == 0)
    {
        _4161 = NOVALUE;
        goto L19; // [570] 580
    }
    else{
        _4161 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_7666, _lPath_7666, 92);
L19: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = 46;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_7669, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_7667 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1A; // [595] 616
L1B: 
    if (_lPosA_7667 == 0)
    goto L1C; // [598] 628

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _4168 = _lPosA_7667 + 1;
    if (_4168 > MAXINT){
        _4168 = NewDouble((double)_4168);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7666);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_7667)) ? _lPosA_7667 : (long)(DBL_PTR(_lPosA_7667)->dbl);
        int stop = (IS_ATOM_INT(_4168)) ? _4168 : (long)(DBL_PTR(_4168)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7666), start, &_lPath_7666 );
            }
            else Tail(SEQ_PTR(_lPath_7666), stop+1, &_lPath_7666);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7666), start, &_lPath_7666);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7666 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7666)->ref == 1));
        }
    }
    DeRef(_4168);
    _4168 = NOVALUE;

    /** 	  entry*/
L1A: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_7667 = e_match_from(_lLevel_7669, _lPath_7666, _lPosA_7667);

    /** 	end while*/
    goto L1B; // [625] 598
L1C: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = _3850;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_7669, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_7668 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L1D; // [643] 721
L1E: 
    if (_lPosA_7667 == 0)
    goto L1F; // [646] 733

    /** 		lPosB = lPosA-1*/
    _lPosB_7668 = _lPosA_7667 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L20: 
    _4174 = (_lPosB_7668 > 0);
    if (_4174 == 0) {
        DeRef(_4175);
        _4175 = 0;
        goto L21; // [665] 681
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4176 = (int)*(((s1_ptr)_2)->base + _lPosB_7668);
    if (IS_ATOM_INT(_4176)) {
        _4177 = (_4176 != 92);
    }
    else {
        _4177 = binary_op(NOTEQ, _4176, 92);
    }
    _4176 = NOVALUE;
    if (IS_ATOM_INT(_4177))
    _4175 = (_4177 != 0);
    else
    _4175 = DBL_PTR(_4177)->dbl != 0.0;
L21: 
    if (_4175 == 0)
    {
        _4175 = NOVALUE;
        goto L22; // [681] 695
    }
    else{
        _4175 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_7668 = _lPosB_7668 - 1;

    /** 		end while*/
    goto L20; // [692] 661
L22: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_7668 > 0)
    goto L23; // [697] 707

    /** 			lPosB = 1*/
    _lPosB_7668 = 1;
L23: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _4180 = _lPosA_7667 + 2;
    if ((long)((unsigned long)_4180 + (unsigned long)HIGH_BITS) >= 0) 
    _4180 = NewDouble((double)_4180);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7666);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_7668)) ? _lPosB_7668 : (long)(DBL_PTR(_lPosB_7668)->dbl);
        int stop = (IS_ATOM_INT(_4180)) ? _4180 : (long)(DBL_PTR(_4180)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7666), start, &_lPath_7666 );
            }
            else Tail(SEQ_PTR(_lPath_7666), stop+1, &_lPath_7666);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7666), start, &_lPath_7666);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7666 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7666)->ref == 1));
        }
    }
    DeRef(_4180);
    _4180 = NOVALUE;

    /** 	  entry*/
L1D: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_7667 = e_match_from(_lLevel_7669, _lPath_7666, _lPosB_7668);

    /** 	end while*/
    goto L1E; // [730] 646
L1F: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_7665 != 1)
    goto L24; // [735] 750

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_7666);
    _0 = _lPath_7666;
    _lPath_7666 = _6lower(_lPath_7666);
    DeRefDS(_0);
    goto L25; // [747] 1355
L24: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_7665 == 0)
    goto L26; // [752] 1352

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_7666);
    _0 = _sl_7812;
    _sl_7812 = _9find_all(92, _lPath_7666, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_7665;
         _4187 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4187)) {
        _short_name_7815 = (_4187 == 4);
    }
    else {
        _short_name_7815 = (DBL_PTR(_4187)->dbl == (double)4);
    }
    DeRef(_4187);
    _4187 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_7665 & (unsigned long)2;
         _4189 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4189)) {
        _correct_name_7818 = (_4189 == 2);
    }
    else {
        _correct_name_7818 = (DBL_PTR(_4189)->dbl == (double)2);
    }
    DeRef(_4189);
    _4189 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_7665;
         _4191 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4191)) {
        _lower_name_7821 = (_4191 == 1);
    }
    else {
        _lower_name_7821 = (DBL_PTR(_4191)->dbl == (double)1);
    }
    DeRef(_4191);
    _4191 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4193 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4193 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7666);
    _4194 = (int)*(((s1_ptr)_2)->base + _4193);
    if (binary_op_a(EQUALS, _4194, 92)){
        _4194 = NOVALUE;
        goto L27; // [805] 827
    }
    _4194 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_7666)){
            _4196 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4196 = 1;
    }
    _4197 = _4196 + 1;
    _4196 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4197;
    _4198 = MAKE_SEQ(_1);
    _4197 = NOVALUE;
    Concat((object_ptr)&_sl_7812, _sl_7812, _4198);
    DeRefDS(_4198);
    _4198 = NOVALUE;
L27: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_7812)){
            _4200 = SEQ_PTR(_sl_7812)->length;
    }
    else {
        _4200 = 1;
    }
    _4201 = _4200 - 1;
    _4200 = NOVALUE;
    {
        int _i_7833;
        _i_7833 = _4201;
L28: 
        if (_i_7833 < 1){
            goto L29; // [836] 1317
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_7812);
        _4203 = (int)*(((s1_ptr)_2)->base + _i_7833);
        if (IS_ATOM_INT(_4203)) {
            _4204 = _4203 - 1;
        }
        else {
            _4204 = binary_op(MINUS, _4203, 1);
        }
        _4203 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_7837;
        RHS_Slice(_lPath_7666, 1, _4204);

        /** 			object list = dir( part & SLASH )*/
        Append(&_4206, _part_7837, 92);
        DeRef(_name_inlined_dir_at_864_7844);
        _name_inlined_dir_at_864_7844 = _4206;
        _4206 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return machine_func(M_DIR, name)*/
        DeRef(_list_7841);
        _list_7841 = machine(22, _name_inlined_dir_at_864_7844);
        DeRef(_name_inlined_dir_at_864_7844);
        _name_inlined_dir_at_864_7844 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_7812);
        _4207 = (int)*(((s1_ptr)_2)->base + _i_7833);
        if (IS_ATOM_INT(_4207)) {
            _4208 = _4207 + 1;
            if (_4208 > MAXINT){
                _4208 = NewDouble((double)_4208);
            }
        }
        else
        _4208 = binary_op(PLUS, 1, _4207);
        _4207 = NOVALUE;
        _4209 = _i_7833 + 1;
        _2 = (int)SEQ_PTR(_sl_7812);
        _4210 = (int)*(((s1_ptr)_2)->base + _4209);
        if (IS_ATOM_INT(_4210)) {
            _4211 = _4210 - 1;
        }
        else {
            _4211 = binary_op(MINUS, _4210, 1);
        }
        _4210 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_7846;
        RHS_Slice(_lPath_7666, _4208, _4211);

        /** 			if atom(list) then*/
        _4213 = IS_ATOM(_list_7841);
        if (_4213 == 0)
        {
            _4213 = NOVALUE;
            goto L2A; // [912] 950
        }
        else{
            _4213 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_7821 == 0)
        {
            goto L2B; // [917] 943
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7812);
        _4214 = (int)*(((s1_ptr)_2)->base + _i_7833);
        if (IS_SEQUENCE(_lPath_7666)){
                _4215 = SEQ_PTR(_lPath_7666)->length;
        }
        else {
            _4215 = 1;
        }
        rhs_slice_target = (object_ptr)&_4216;
        RHS_Slice(_lPath_7666, _4214, _4215);
        _4217 = _6lower(_4216);
        _4216 = NOVALUE;
        if (IS_SEQUENCE(_part_7837) && IS_ATOM(_4217)) {
            Ref(_4217);
            Append(&_lPath_7666, _part_7837, _4217);
        }
        else if (IS_ATOM(_part_7837) && IS_SEQUENCE(_4217)) {
        }
        else {
            Concat((object_ptr)&_lPath_7666, _part_7837, _4217);
        }
        DeRef(_4217);
        _4217 = NOVALUE;
L2B: 

        /** 				continue*/
        DeRef(_part_7837);
        _part_7837 = NOVALUE;
        DeRef(_list_7841);
        _list_7841 = NOVALUE;
        DeRef(_supplied_name_7846);
        _supplied_name_7846 = NOVALUE;
        goto L2C; // [947] 1312
L2A: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7841)){
                _4219 = SEQ_PTR(_list_7841)->length;
        }
        else {
            _4219 = 1;
        }
        {
            int _j_7863;
            _j_7863 = 1;
L2D: 
            if (_j_7863 > _4219){
                goto L2E; // [955] 1080
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7841);
            _4220 = (int)*(((s1_ptr)_2)->base + _j_7863);
            DeRef(_read_name_7865);
            _2 = (int)SEQ_PTR(_4220);
            _read_name_7865 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7865);
            _4220 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_7865 == _supplied_name_7846)
            _4222 = 1;
            else if (IS_ATOM_INT(_read_name_7865) && IS_ATOM_INT(_supplied_name_7846))
            _4222 = 0;
            else
            _4222 = (compare(_read_name_7865, _supplied_name_7846) == 0);
            if (_4222 == 0)
            {
                _4222 = NOVALUE;
                goto L2F; // [980] 1071
            }
            else{
                _4222 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7815 == 0) {
                goto L30; // [985] 1062
            }
            _2 = (int)SEQ_PTR(_list_7841);
            _4224 = (int)*(((s1_ptr)_2)->base + _j_7863);
            _2 = (int)SEQ_PTR(_4224);
            _4225 = (int)*(((s1_ptr)_2)->base + 11);
            _4224 = NOVALUE;
            _4226 = IS_SEQUENCE(_4225);
            _4225 = NOVALUE;
            if (_4226 == 0)
            {
                _4226 = NOVALUE;
                goto L30; // [1001] 1062
            }
            else{
                _4226 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7812);
            _4227 = (int)*(((s1_ptr)_2)->base + _i_7833);
            rhs_slice_target = (object_ptr)&_4228;
            RHS_Slice(_lPath_7666, 1, _4227);
            _2 = (int)SEQ_PTR(_list_7841);
            _4229 = (int)*(((s1_ptr)_2)->base + _j_7863);
            _2 = (int)SEQ_PTR(_4229);
            _4230 = (int)*(((s1_ptr)_2)->base + 11);
            _4229 = NOVALUE;
            _4231 = _i_7833 + 1;
            _2 = (int)SEQ_PTR(_sl_7812);
            _4232 = (int)*(((s1_ptr)_2)->base + _4231);
            if (IS_SEQUENCE(_lPath_7666)){
                    _4233 = SEQ_PTR(_lPath_7666)->length;
            }
            else {
                _4233 = 1;
            }
            rhs_slice_target = (object_ptr)&_4234;
            RHS_Slice(_lPath_7666, _4232, _4233);
            {
                int concat_list[3];

                concat_list[0] = _4234;
                concat_list[1] = _4230;
                concat_list[2] = _4228;
                Concat_N((object_ptr)&_lPath_7666, concat_list, 3);
            }
            DeRefDS(_4234);
            _4234 = NOVALUE;
            _4230 = NOVALUE;
            DeRefDS(_4228);
            _4228 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7812)){
                    _4236 = SEQ_PTR(_sl_7812)->length;
            }
            else {
                _4236 = 1;
            }
            if (IS_SEQUENCE(_lPath_7666)){
                    _4237 = SEQ_PTR(_lPath_7666)->length;
            }
            else {
                _4237 = 1;
            }
            _4238 = _4237 + 1;
            _4237 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7812);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7812 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4236);
            _1 = *(int *)_2;
            *(int *)_2 = _4238;
            if( _1 != _4238 ){
                DeRef(_1);
            }
            _4238 = NOVALUE;
L30: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7865);
            _read_name_7865 = NOVALUE;
            DeRef(_part_7837);
            _part_7837 = NOVALUE;
            DeRef(_list_7841);
            _list_7841 = NOVALUE;
            DeRef(_supplied_name_7846);
            _supplied_name_7846 = NOVALUE;
            goto L2C; // [1068] 1312
L2F: 
            DeRef(_read_name_7865);
            _read_name_7865 = NOVALUE;

            /** 			end for*/
            _j_7863 = _j_7863 + 1;
            goto L2D; // [1075] 962
L2E: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7841)){
                _4239 = SEQ_PTR(_list_7841)->length;
        }
        else {
            _4239 = 1;
        }
        {
            int _j_7888;
            _j_7888 = 1;
L31: 
            if (_j_7888 > _4239){
                goto L32; // [1085] 1257
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7841);
            _4240 = (int)*(((s1_ptr)_2)->base + _j_7888);
            DeRef(_read_name_7890);
            _2 = (int)SEQ_PTR(_4240);
            _read_name_7890 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7890);
            _4240 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_7890);
            _4242 = _6lower(_read_name_7890);
            RefDS(_supplied_name_7846);
            _4243 = _6lower(_supplied_name_7846);
            if (_4242 == _4243)
            _4244 = 1;
            else if (IS_ATOM_INT(_4242) && IS_ATOM_INT(_4243))
            _4244 = 0;
            else
            _4244 = (compare(_4242, _4243) == 0);
            DeRef(_4242);
            _4242 = NOVALUE;
            DeRef(_4243);
            _4243 = NOVALUE;
            if (_4244 == 0)
            {
                _4244 = NOVALUE;
                goto L33; // [1118] 1248
            }
            else{
                _4244 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7815 == 0) {
                goto L34; // [1123] 1200
            }
            _2 = (int)SEQ_PTR(_list_7841);
            _4246 = (int)*(((s1_ptr)_2)->base + _j_7888);
            _2 = (int)SEQ_PTR(_4246);
            _4247 = (int)*(((s1_ptr)_2)->base + 11);
            _4246 = NOVALUE;
            _4248 = IS_SEQUENCE(_4247);
            _4247 = NOVALUE;
            if (_4248 == 0)
            {
                _4248 = NOVALUE;
                goto L34; // [1139] 1200
            }
            else{
                _4248 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7812);
            _4249 = (int)*(((s1_ptr)_2)->base + _i_7833);
            rhs_slice_target = (object_ptr)&_4250;
            RHS_Slice(_lPath_7666, 1, _4249);
            _2 = (int)SEQ_PTR(_list_7841);
            _4251 = (int)*(((s1_ptr)_2)->base + _j_7888);
            _2 = (int)SEQ_PTR(_4251);
            _4252 = (int)*(((s1_ptr)_2)->base + 11);
            _4251 = NOVALUE;
            _4253 = _i_7833 + 1;
            _2 = (int)SEQ_PTR(_sl_7812);
            _4254 = (int)*(((s1_ptr)_2)->base + _4253);
            if (IS_SEQUENCE(_lPath_7666)){
                    _4255 = SEQ_PTR(_lPath_7666)->length;
            }
            else {
                _4255 = 1;
            }
            rhs_slice_target = (object_ptr)&_4256;
            RHS_Slice(_lPath_7666, _4254, _4255);
            {
                int concat_list[3];

                concat_list[0] = _4256;
                concat_list[1] = _4252;
                concat_list[2] = _4250;
                Concat_N((object_ptr)&_lPath_7666, concat_list, 3);
            }
            DeRefDS(_4256);
            _4256 = NOVALUE;
            _4252 = NOVALUE;
            DeRefDS(_4250);
            _4250 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7812)){
                    _4258 = SEQ_PTR(_sl_7812)->length;
            }
            else {
                _4258 = 1;
            }
            if (IS_SEQUENCE(_lPath_7666)){
                    _4259 = SEQ_PTR(_lPath_7666)->length;
            }
            else {
                _4259 = 1;
            }
            _4260 = _4259 + 1;
            _4259 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7812);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7812 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4258);
            _1 = *(int *)_2;
            *(int *)_2 = _4260;
            if( _1 != _4260 ){
                DeRef(_1);
            }
            _4260 = NOVALUE;
L34: 

            /** 					if correct_name then*/
            if (_correct_name_7818 == 0)
            {
                goto L35; // [1202] 1239
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7812);
            _4261 = (int)*(((s1_ptr)_2)->base + _i_7833);
            rhs_slice_target = (object_ptr)&_4262;
            RHS_Slice(_lPath_7666, 1, _4261);
            _4263 = _i_7833 + 1;
            _2 = (int)SEQ_PTR(_sl_7812);
            _4264 = (int)*(((s1_ptr)_2)->base + _4263);
            if (IS_SEQUENCE(_lPath_7666)){
                    _4265 = SEQ_PTR(_lPath_7666)->length;
            }
            else {
                _4265 = 1;
            }
            rhs_slice_target = (object_ptr)&_4266;
            RHS_Slice(_lPath_7666, _4264, _4265);
            {
                int concat_list[3];

                concat_list[0] = _4266;
                concat_list[1] = _read_name_7890;
                concat_list[2] = _4262;
                Concat_N((object_ptr)&_lPath_7666, concat_list, 3);
            }
            DeRefDS(_4266);
            _4266 = NOVALUE;
            DeRefDS(_4262);
            _4262 = NOVALUE;
L35: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7890);
            _read_name_7890 = NOVALUE;
            DeRef(_part_7837);
            _part_7837 = NOVALUE;
            DeRef(_list_7841);
            _list_7841 = NOVALUE;
            DeRef(_supplied_name_7846);
            _supplied_name_7846 = NOVALUE;
            goto L2C; // [1245] 1312
L33: 
            DeRef(_read_name_7890);
            _read_name_7890 = NOVALUE;

            /** 			end for*/
            _j_7888 = _j_7888 + 1;
            goto L31; // [1252] 1092
L32: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_7665;
             _4268 = MAKE_UINT(tu);
        }
        if (_4268 == 0) {
            DeRef(_4268);
            _4268 = NOVALUE;
            goto L36; // [1263] 1302
        }
        else {
            if (!IS_ATOM_INT(_4268) && DBL_PTR(_4268)->dbl == 0.0){
                DeRef(_4268);
                _4268 = NOVALUE;
                goto L36; // [1263] 1302
            }
            DeRef(_4268);
            _4268 = NOVALUE;
        }
        DeRef(_4268);
        _4268 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7812);
        _4269 = (int)*(((s1_ptr)_2)->base + _i_7833);
        if (IS_ATOM_INT(_4269)) {
            _4270 = _4269 - 1;
        }
        else {
            _4270 = binary_op(MINUS, _4269, 1);
        }
        _4269 = NOVALUE;
        rhs_slice_target = (object_ptr)&_4271;
        RHS_Slice(_lPath_7666, 1, _4270);
        _2 = (int)SEQ_PTR(_sl_7812);
        _4272 = (int)*(((s1_ptr)_2)->base + _i_7833);
        if (IS_SEQUENCE(_lPath_7666)){
                _4273 = SEQ_PTR(_lPath_7666)->length;
        }
        else {
            _4273 = 1;
        }
        rhs_slice_target = (object_ptr)&_4274;
        RHS_Slice(_lPath_7666, _4272, _4273);
        _4275 = _6lower(_4274);
        _4274 = NOVALUE;
        if (IS_SEQUENCE(_4271) && IS_ATOM(_4275)) {
            Ref(_4275);
            Append(&_lPath_7666, _4271, _4275);
        }
        else if (IS_ATOM(_4271) && IS_SEQUENCE(_4275)) {
        }
        else {
            Concat((object_ptr)&_lPath_7666, _4271, _4275);
            DeRefDS(_4271);
            _4271 = NOVALUE;
        }
        DeRef(_4271);
        _4271 = NOVALUE;
        DeRef(_4275);
        _4275 = NOVALUE;
L36: 

        /** 			exit*/
        DeRef(_part_7837);
        _part_7837 = NOVALUE;
        DeRef(_list_7841);
        _list_7841 = NOVALUE;
        DeRef(_supplied_name_7846);
        _supplied_name_7846 = NOVALUE;
        goto L29; // [1306] 1317

        /** 		end for*/
L2C: 
        _i_7833 = _i_7833 + -1;
        goto L28; // [1312] 843
L29: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _4277 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4277)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_7665 & (unsigned long)_4277;
             _4278 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_7665;
        _4278 = Dand_bits(&temp_d, DBL_PTR(_4277));
    }
    DeRef(_4277);
    _4277 = NOVALUE;
    if (IS_ATOM_INT(_4278)) {
        _4279 = (_4278 == 1);
    }
    else {
        _4279 = (DBL_PTR(_4278)->dbl == (double)1);
    }
    DeRef(_4278);
    _4278 = NOVALUE;
    if (_4279 == 0) {
        goto L37; // [1331] 1351
    }
    if (IS_SEQUENCE(_lPath_7666)){
            _4281 = SEQ_PTR(_lPath_7666)->length;
    }
    else {
        _4281 = 1;
    }
    if (_4281 == 0)
    {
        _4281 = NOVALUE;
        goto L37; // [1339] 1351
    }
    else{
        _4281 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_7666);
    _0 = _lPath_7666;
    _lPath_7666 = _6lower(_lPath_7666);
    DeRefDS(_0);
L37: 
L26: 
    DeRef(_sl_7812);
    _sl_7812 = NOVALUE;
L25: 

    /** 	ifdef WINDOWS then*/

    /** 		if and_bits(CORRECT,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)2 & (unsigned long)_case_flags_7665;
         _4283 = MAKE_UINT(tu);
    }
    if (_4283 == 0) {
        DeRef(_4283);
        _4283 = NOVALUE;
        goto L38; // [1363] 1405
    }
    else {
        if (!IS_ATOM_INT(_4283) && DBL_PTR(_4283)->dbl == 0.0){
            DeRef(_4283);
            _4283 = NOVALUE;
            goto L38; // [1363] 1405
        }
        DeRef(_4283);
        _4283 = NOVALUE;
    }
    DeRef(_4283);
    _4283 = NOVALUE;

    /** 			if or_bits(system_drive_case,'A') = 'a' then*/
    if (IS_ATOM_INT(_11system_drive_case_7649)) {
        {unsigned long tu;
             tu = (unsigned long)_11system_drive_case_7649 | (unsigned long)65;
             _4284 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65;
        _4284 = Dor_bits(DBL_PTR(_11system_drive_case_7649), &temp_d);
    }
    if (binary_op_a(NOTEQ, _4284, 97)){
        DeRef(_4284);
        _4284 = NOVALUE;
        goto L39; // [1374] 1391
    }
    DeRef(_4284);
    _4284 = NOVALUE;

    /** 				lDrive = lower(lDrive)*/
    RefDS(_lDrive_7671);
    _0 = _lDrive_7671;
    _lDrive_7671 = _6lower(_lDrive_7671);
    DeRefDS(_0);
    goto L3A; // [1388] 1426
L39: 

    /** 				lDrive = upper(lDrive)*/
    RefDS(_lDrive_7671);
    _0 = _lDrive_7671;
    _lDrive_7671 = _6upper(_lDrive_7671);
    DeRefDS(_0);
    goto L3A; // [1402] 1426
L38: 

    /** 		elsif and_bits(TO_LOWER,case_flags) then*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_7665;
         _4288 = MAKE_UINT(tu);
    }
    if (_4288 == 0) {
        DeRef(_4288);
        _4288 = NOVALUE;
        goto L3B; // [1411] 1425
    }
    else {
        if (!IS_ATOM_INT(_4288) && DBL_PTR(_4288)->dbl == 0.0){
            DeRef(_4288);
            _4288 = NOVALUE;
            goto L3B; // [1411] 1425
        }
        DeRef(_4288);
        _4288 = NOVALUE;
    }
    DeRef(_4288);
    _4288 = NOVALUE;

    /** 			lDrive = lower(lDrive)*/
    RefDS(_lDrive_7671);
    _0 = _lDrive_7671;
    _lDrive_7671 = _6lower(_lDrive_7671);
    DeRefDS(_0);
L3B: 
L3A: 

    /** 		lPath = lDrive & lPath*/
    Concat((object_ptr)&_lPath_7666, _lDrive_7671, _lPath_7666);

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_4291, _lPath_7666, _wildcard_suffix_7736);
    DeRefDS(_path_in_7663);
    DeRefDS(_lPath_7666);
    DeRefi(_lLevel_7669);
    DeRef(_lHome_7670);
    DeRefDS(_lDrive_7671);
    DeRefDS(_wildcard_suffix_7736);
    DeRef(_4089);
    _4089 = NOVALUE;
    DeRef(_4209);
    _4209 = NOVALUE;
    DeRef(_4125);
    _4125 = NOVALUE;
    DeRef(_4164);
    _4164 = NOVALUE;
    _4261 = NOVALUE;
    _4264 = NOVALUE;
    _4214 = NOVALUE;
    DeRef(_4160);
    _4160 = NOVALUE;
    _4232 = NOVALUE;
    DeRef(_4177);
    _4177 = NOVALUE;
    DeRef(_4174);
    _4174 = NOVALUE;
    DeRef(_4204);
    _4204 = NOVALUE;
    DeRef(_4231);
    _4231 = NOVALUE;
    _4249 = NOVALUE;
    _4254 = NOVALUE;
    DeRef(_4082);
    _4082 = NOVALUE;
    DeRef(_4091);
    _4091 = NOVALUE;
    DeRef(_4151);
    _4151 = NOVALUE;
    DeRef(_4154);
    _4154 = NOVALUE;
    DeRef(_4263);
    _4263 = NOVALUE;
    DeRef(_4097);
    _4097 = NOVALUE;
    DeRef(_4208);
    _4208 = NOVALUE;
    _4272 = NOVALUE;
    DeRef(_4137);
    _4137 = NOVALUE;
    DeRef(_4142);
    _4142 = NOVALUE;
    DeRef(_4201);
    _4201 = NOVALUE;
    DeRef(_4094);
    _4094 = NOVALUE;
    DeRef(_4211);
    _4211 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    DeRef(_4122);
    _4122 = NOVALUE;
    DeRef(_4253);
    _4253 = NOVALUE;
    _4227 = NOVALUE;
    DeRef(_4085);
    _4085 = NOVALUE;
    DeRef(_4111);
    _4111 = NOVALUE;
    DeRef(_4270);
    _4270 = NOVALUE;
    return _4291;
    ;
}


int  __stdcall _11abbreviate_path(int _orig_path_7966, int _base_paths_7967)
{
    int _expanded_path_7968 = NOVALUE;
    int _lowered_expanded_path_7978 = NOVALUE;
    int _fs_case_inlined_fs_case_at_249_25243 = NOVALUE;
    int _s_inlined_fs_case_at_246_25242 = NOVALUE;
    int _4337 = NOVALUE;
    int _4336 = NOVALUE;
    int _4333 = NOVALUE;
    int _4332 = NOVALUE;
    int _4331 = NOVALUE;
    int _4330 = NOVALUE;
    int _4329 = NOVALUE;
    int _4327 = NOVALUE;
    int _4326 = NOVALUE;
    int _4325 = NOVALUE;
    int _4324 = NOVALUE;
    int _4323 = NOVALUE;
    int _4322 = NOVALUE;
    int _4321 = NOVALUE;
    int _4320 = NOVALUE;
    int _4319 = NOVALUE;
    int _4316 = NOVALUE;
    int _4315 = NOVALUE;
    int _4313 = NOVALUE;
    int _4312 = NOVALUE;
    int _4311 = NOVALUE;
    int _4310 = NOVALUE;
    int _4309 = NOVALUE;
    int _4308 = NOVALUE;
    int _4307 = NOVALUE;
    int _4306 = NOVALUE;
    int _4305 = NOVALUE;
    int _4304 = NOVALUE;
    int _4303 = NOVALUE;
    int _4302 = NOVALUE;
    int _4301 = NOVALUE;
    int _4298 = NOVALUE;
    int _4297 = NOVALUE;
    int _4296 = NOVALUE;
    int _4294 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_7966);
    _0 = _expanded_path_7968;
    _expanded_path_7968 = _11canonical_path(_orig_path_7966, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _4294 = _11curdir(0);
    Ref(_4294);
    Append(&_base_paths_7967, _base_paths_7967, _4294);
    DeRef(_4294);
    _4294 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_7967)){
            _4296 = SEQ_PTR(_base_paths_7967)->length;
    }
    else {
        _4296 = 1;
    }
    {
        int _i_7973;
        _i_7973 = 1;
L1: 
        if (_i_7973 > _4296){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_7967);
        _4297 = (int)*(((s1_ptr)_2)->base + _i_7973);
        Ref(_4297);
        _4298 = _11canonical_path(_4297, 1, 0);
        _4297 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_7967);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_7967 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_7973);
        _1 = *(int *)_2;
        *(int *)_2 = _4298;
        if( _1 != _4298 ){
            DeRef(_1);
        }
        _4298 = NOVALUE;

        /** 	end for*/
        _i_7973 = _i_7973 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/

    /** 	ifdef WINDOWS then*/

    /** 		return lower(s)*/
    RefDS(_base_paths_7967);
    _0 = _base_paths_7967;
    _base_paths_7967 = _6lower(_base_paths_7967);
    DeRefDS(_0);

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return lower(s)*/
    RefDS(_expanded_path_7968);
    _0 = _lowered_expanded_path_7978;
    _lowered_expanded_path_7978 = _6lower(_expanded_path_7968);
    DeRef(_0);

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_7967)){
            _4301 = SEQ_PTR(_base_paths_7967)->length;
    }
    else {
        _4301 = 1;
    }
    {
        int _i_7981;
        _i_7981 = 1;
L3: 
        if (_i_7981 > _4301){
            goto L4; // [91] 145
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_7967);
        _4302 = (int)*(((s1_ptr)_2)->base + _i_7981);
        Ref(_4302);
        RefDS(_lowered_expanded_path_7978);
        _4303 = _9begins(_4302, _lowered_expanded_path_7978);
        _4302 = NOVALUE;
        if (_4303 == 0) {
            DeRef(_4303);
            _4303 = NOVALUE;
            goto L5; // [109] 138
        }
        else {
            if (!IS_ATOM_INT(_4303) && DBL_PTR(_4303)->dbl == 0.0){
                DeRef(_4303);
                _4303 = NOVALUE;
                goto L5; // [109] 138
            }
            DeRef(_4303);
            _4303 = NOVALUE;
        }
        DeRef(_4303);
        _4303 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_7967);
        _4304 = (int)*(((s1_ptr)_2)->base + _i_7981);
        if (IS_SEQUENCE(_4304)){
                _4305 = SEQ_PTR(_4304)->length;
        }
        else {
            _4305 = 1;
        }
        _4304 = NOVALUE;
        _4306 = _4305 + 1;
        _4305 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_7968)){
                _4307 = SEQ_PTR(_expanded_path_7968)->length;
        }
        else {
            _4307 = 1;
        }
        rhs_slice_target = (object_ptr)&_4308;
        RHS_Slice(_expanded_path_7968, _4306, _4307);
        DeRefDS(_orig_path_7966);
        DeRefDS(_base_paths_7967);
        DeRefDS(_expanded_path_7968);
        DeRefDS(_lowered_expanded_path_7978);
        _4304 = NOVALUE;
        _4306 = NOVALUE;
        return _4308;
L5: 

        /** 	end for*/
        _i_7981 = _i_7981 + 1;
        goto L3; // [140] 98
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 		if not equal(base_paths[$][1], lowered_expanded_path[1]) then*/
    if (IS_SEQUENCE(_base_paths_7967)){
            _4309 = SEQ_PTR(_base_paths_7967)->length;
    }
    else {
        _4309 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_7967);
    _4310 = (int)*(((s1_ptr)_2)->base + _4309);
    _2 = (int)SEQ_PTR(_4310);
    _4311 = (int)*(((s1_ptr)_2)->base + 1);
    _4310 = NOVALUE;
    _2 = (int)SEQ_PTR(_lowered_expanded_path_7978);
    _4312 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4311 == _4312)
    _4313 = 1;
    else if (IS_ATOM_INT(_4311) && IS_ATOM_INT(_4312))
    _4313 = 0;
    else
    _4313 = (compare(_4311, _4312) == 0);
    _4311 = NOVALUE;
    _4312 = NOVALUE;
    if (_4313 != 0)
    goto L6; // [168] 178
    _4313 = NOVALUE;

    /** 			return orig_path*/
    DeRefDS(_base_paths_7967);
    DeRef(_expanded_path_7968);
    DeRefDS(_lowered_expanded_path_7978);
    _4304 = NOVALUE;
    DeRef(_4306);
    _4306 = NOVALUE;
    DeRef(_4308);
    _4308 = NOVALUE;
    return _orig_path_7966;
L6: 

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_7967)){
            _4315 = SEQ_PTR(_base_paths_7967)->length;
    }
    else {
        _4315 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_7967);
    _4316 = (int)*(((s1_ptr)_2)->base + _4315);
    Ref(_4316);
    _0 = _base_paths_7967;
    _base_paths_7967 = _23split(_4316, 92, 0, 0);
    DeRefDS(_0);
    _4316 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_7968);
    _0 = _expanded_path_7968;
    _expanded_path_7968 = _23split(_expanded_path_7968, 92, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_7978);
    _lowered_expanded_path_7978 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_7968)){
            _4319 = SEQ_PTR(_expanded_path_7968)->length;
    }
    else {
        _4319 = 1;
    }
    if (IS_SEQUENCE(_base_paths_7967)){
            _4320 = SEQ_PTR(_base_paths_7967)->length;
    }
    else {
        _4320 = 1;
    }
    _4321 = _4320 - 1;
    _4320 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4319;
    ((int *)_2)[2] = _4321;
    _4322 = MAKE_SEQ(_1);
    _4321 = NOVALUE;
    _4319 = NOVALUE;
    _4323 = _20min(_4322);
    _4322 = NOVALUE;
    {
        int _i_8003;
        _i_8003 = 1;
L7: 
        if (binary_op_a(GREATER, _i_8003, _4323)){
            goto L8; // [234] 342
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_7968);
        if (!IS_ATOM_INT(_i_8003)){
            _4324 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8003)->dbl));
        }
        else{
            _4324 = (int)*(((s1_ptr)_2)->base + _i_8003);
        }
        Ref(_4324);
        DeRef(_s_inlined_fs_case_at_246_25242);
        _s_inlined_fs_case_at_246_25242 = _4324;
        _4324 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return lower(s)*/
        Ref(_s_inlined_fs_case_at_246_25242);
        _0 = _fs_case_inlined_fs_case_at_249_25243;
        _fs_case_inlined_fs_case_at_249_25243 = _6lower(_s_inlined_fs_case_at_246_25242);
        DeRef(_0);
        DeRef(_s_inlined_fs_case_at_246_25242);
        _s_inlined_fs_case_at_246_25242 = NOVALUE;
        Ref(_fs_case_inlined_fs_case_at_249_25243);
        DeRef(_4325);
        _4325 = _fs_case_inlined_fs_case_at_249_25243;
        _2 = (int)SEQ_PTR(_base_paths_7967);
        if (!IS_ATOM_INT(_i_8003)){
            _4326 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8003)->dbl));
        }
        else{
            _4326 = (int)*(((s1_ptr)_2)->base + _i_8003);
        }
        if (_4325 == _4326)
        _4327 = 1;
        else if (IS_ATOM_INT(_4325) && IS_ATOM_INT(_4326))
        _4327 = 0;
        else
        _4327 = (compare(_4325, _4326) == 0);
        _4325 = NOVALUE;
        _4326 = NOVALUE;
        if (_4327 != 0)
        goto L9; // [274] 335
        _4327 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_7967)){
                _4329 = SEQ_PTR(_base_paths_7967)->length;
        }
        else {
            _4329 = 1;
        }
        if (IS_ATOM_INT(_i_8003)) {
            _4330 = _4329 - _i_8003;
        }
        else {
            _4330 = NewDouble((double)_4329 - DBL_PTR(_i_8003)->dbl);
        }
        _4329 = NOVALUE;
        _4331 = Repeat(_3850, _4330);
        DeRef(_4330);
        _4330 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_7968)){
                _4332 = SEQ_PTR(_expanded_path_7968)->length;
        }
        else {
            _4332 = 1;
        }
        rhs_slice_target = (object_ptr)&_4333;
        RHS_Slice(_expanded_path_7968, _i_8003, _4332);
        Concat((object_ptr)&_expanded_path_7968, _4331, _4333);
        DeRefDS(_4331);
        _4331 = NOVALUE;
        DeRef(_4331);
        _4331 = NOVALUE;
        DeRefDS(_4333);
        _4333 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_7968);
        _0 = _expanded_path_7968;
        _expanded_path_7968 = _23join(_expanded_path_7968, 92);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_7968)){
                _4336 = SEQ_PTR(_expanded_path_7968)->length;
        }
        else {
            _4336 = 1;
        }
        if (IS_SEQUENCE(_orig_path_7966)){
                _4337 = SEQ_PTR(_orig_path_7966)->length;
        }
        else {
            _4337 = 1;
        }
        if (_4336 >= _4337)
        goto L8; // [319] 342

        /** 		  		return expanded_path*/
        DeRef(_i_8003);
        DeRefDS(_orig_path_7966);
        DeRefDS(_base_paths_7967);
        DeRef(_lowered_expanded_path_7978);
        _4304 = NOVALUE;
        DeRef(_4306);
        _4306 = NOVALUE;
        DeRef(_4308);
        _4308 = NOVALUE;
        DeRef(_4323);
        _4323 = NOVALUE;
        return _expanded_path_7968;

        /** 			exit*/
        goto L8; // [332] 342
L9: 

        /** 	end for*/
        _0 = _i_8003;
        if (IS_ATOM_INT(_i_8003)) {
            _i_8003 = _i_8003 + 1;
            if ((long)((unsigned long)_i_8003 +(unsigned long) HIGH_BITS) >= 0){
                _i_8003 = NewDouble((double)_i_8003);
            }
        }
        else {
            _i_8003 = binary_op_a(PLUS, _i_8003, 1);
        }
        DeRef(_0);
        goto L7; // [337] 241
L8: 
        ;
        DeRef(_i_8003);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_7967);
    DeRef(_expanded_path_7968);
    DeRef(_lowered_expanded_path_7978);
    _4304 = NOVALUE;
    DeRef(_4306);
    _4306 = NOVALUE;
    DeRef(_4308);
    _4308 = NOVALUE;
    DeRef(_4323);
    _4323 = NOVALUE;
    return _orig_path_7966;
    ;
}


int  __stdcall _11split_path(int _fname_8028)
{
    int _4339 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:split(fname, SLASH, 1)*/
    RefDS(_fname_8028);
    _4339 = _23split(_fname_8028, 92, 1, 0);
    DeRefDS(_fname_8028);
    return _4339;
    ;
}


int  __stdcall _11join_path(int _path_elements_8032)
{
    int _fname_8033 = NOVALUE;
    int _elem_8037 = NOVALUE;
    int _4353 = NOVALUE;
    int _4352 = NOVALUE;
    int _4351 = NOVALUE;
    int _4350 = NOVALUE;
    int _4349 = NOVALUE;
    int _4348 = NOVALUE;
    int _4346 = NOVALUE;
    int _4345 = NOVALUE;
    int _4343 = NOVALUE;
    int _4342 = NOVALUE;
    int _4340 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fname = ""*/
    RefDS(_5);
    DeRef(_fname_8033);
    _fname_8033 = _5;

    /** 	for i = 1 to length(path_elements) do*/
    if (IS_SEQUENCE(_path_elements_8032)){
            _4340 = SEQ_PTR(_path_elements_8032)->length;
    }
    else {
        _4340 = 1;
    }
    {
        int _i_8035;
        _i_8035 = 1;
L1: 
        if (_i_8035 > _4340){
            goto L2; // [15] 117
        }

        /** 		sequence elem = path_elements[i]*/
        DeRef(_elem_8037);
        _2 = (int)SEQ_PTR(_path_elements_8032);
        _elem_8037 = (int)*(((s1_ptr)_2)->base + _i_8035);
        Ref(_elem_8037);

        /** 		if elem[$] = SLASH then*/
        if (IS_SEQUENCE(_elem_8037)){
                _4342 = SEQ_PTR(_elem_8037)->length;
        }
        else {
            _4342 = 1;
        }
        _2 = (int)SEQ_PTR(_elem_8037);
        _4343 = (int)*(((s1_ptr)_2)->base + _4342);
        if (binary_op_a(NOTEQ, _4343, 92)){
            _4343 = NOVALUE;
            goto L3; // [39] 58
        }
        _4343 = NOVALUE;

        /** 			elem = elem[1..$ - 1]*/
        if (IS_SEQUENCE(_elem_8037)){
                _4345 = SEQ_PTR(_elem_8037)->length;
        }
        else {
            _4345 = 1;
        }
        _4346 = _4345 - 1;
        _4345 = NOVALUE;
        rhs_slice_target = (object_ptr)&_elem_8037;
        RHS_Slice(_elem_8037, 1, _4346);
L3: 

        /** 		if length(elem) and elem[1] != SLASH then*/
        if (IS_SEQUENCE(_elem_8037)){
                _4348 = SEQ_PTR(_elem_8037)->length;
        }
        else {
            _4348 = 1;
        }
        if (_4348 == 0) {
            goto L4; // [63] 102
        }
        _2 = (int)SEQ_PTR(_elem_8037);
        _4350 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_4350)) {
            _4351 = (_4350 != 92);
        }
        else {
            _4351 = binary_op(NOTEQ, _4350, 92);
        }
        _4350 = NOVALUE;
        if (_4351 == 0) {
            DeRef(_4351);
            _4351 = NOVALUE;
            goto L4; // [76] 102
        }
        else {
            if (!IS_ATOM_INT(_4351) && DBL_PTR(_4351)->dbl == 0.0){
                DeRef(_4351);
                _4351 = NOVALUE;
                goto L4; // [76] 102
            }
            DeRef(_4351);
            _4351 = NOVALUE;
        }
        DeRef(_4351);
        _4351 = NOVALUE;

        /** 			ifdef WINDOWS then*/

        /** 				if elem[$] != ':' then*/
        if (IS_SEQUENCE(_elem_8037)){
                _4352 = SEQ_PTR(_elem_8037)->length;
        }
        else {
            _4352 = 1;
        }
        _2 = (int)SEQ_PTR(_elem_8037);
        _4353 = (int)*(((s1_ptr)_2)->base + _4352);
        if (binary_op_a(EQUALS, _4353, 58)){
            _4353 = NOVALUE;
            goto L5; // [90] 101
        }
        _4353 = NOVALUE;

        /** 					elem = SLASH & elem*/
        Prepend(&_elem_8037, _elem_8037, 92);
L5: 
L4: 

        /** 		fname &= elem*/
        Concat((object_ptr)&_fname_8033, _fname_8033, _elem_8037);
        DeRefDS(_elem_8037);
        _elem_8037 = NOVALUE;

        /** 	end for*/
        _i_8035 = _i_8035 + 1;
        goto L1; // [112] 22
L2: 
        ;
    }

    /** 	return fname*/
    DeRefDS(_path_elements_8032);
    DeRef(_4346);
    _4346 = NOVALUE;
    return _fname_8033;
    ;
}


int  __stdcall _11file_type(int _filename_8063)
{
    int _dirfil_8064 = NOVALUE;
    int _dir_inlined_dir_at_64_8077 = NOVALUE;
    int _4378 = NOVALUE;
    int _4377 = NOVALUE;
    int _4376 = NOVALUE;
    int _4375 = NOVALUE;
    int _4374 = NOVALUE;
    int _4372 = NOVALUE;
    int _4371 = NOVALUE;
    int _4370 = NOVALUE;
    int _4369 = NOVALUE;
    int _4368 = NOVALUE;
    int _4367 = NOVALUE;
    int _4366 = NOVALUE;
    int _4364 = NOVALUE;
    int _4363 = NOVALUE;
    int _4362 = NOVALUE;
    int _4361 = NOVALUE;
    int _4360 = NOVALUE;
    int _4359 = NOVALUE;
    int _4357 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _4357 = find_from(42, _filename_8063, 1);
    if (_4357 != 0) {
        goto L1; // [10] 24
    }
    _4359 = find_from(63, _filename_8063, 1);
    if (_4359 == 0)
    {
        _4359 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _4359 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_8063);
    DeRef(_dirfil_8064);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 		if length(filename) = 2 and filename[2] = ':' then*/
    if (IS_SEQUENCE(_filename_8063)){
            _4360 = SEQ_PTR(_filename_8063)->length;
    }
    else {
        _4360 = 1;
    }
    _4361 = (_4360 == 2);
    _4360 = NOVALUE;
    if (_4361 == 0) {
        goto L3; // [40] 63
    }
    _2 = (int)SEQ_PTR(_filename_8063);
    _4363 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4363)) {
        _4364 = (_4363 == 58);
    }
    else {
        _4364 = binary_op(EQUALS, _4363, 58);
    }
    _4363 = NOVALUE;
    if (_4364 == 0) {
        DeRef(_4364);
        _4364 = NOVALUE;
        goto L3; // [53] 63
    }
    else {
        if (!IS_ATOM_INT(_4364) && DBL_PTR(_4364)->dbl == 0.0){
            DeRef(_4364);
            _4364 = NOVALUE;
            goto L3; // [53] 63
        }
        DeRef(_4364);
        _4364 = NOVALUE;
    }
    DeRef(_4364);
    _4364 = NOVALUE;

    /** 			filename &= "\\"*/
    Concat((object_ptr)&_filename_8063, _filename_8063, _910);
L3: 

    /** 	dirfil = dir(filename)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_dirfil_8064);
    _dirfil_8064 = machine(22, _filename_8063);

    /** 	if sequence(dirfil) then*/
    _4366 = IS_SEQUENCE(_dirfil_8064);
    if (_4366 == 0)
    {
        _4366 = NOVALUE;
        goto L4; // [79] 163
    }
    else{
        _4366 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_8064)){
            _4367 = SEQ_PTR(_dirfil_8064)->length;
    }
    else {
        _4367 = 1;
    }
    _4368 = (_4367 > 1);
    _4367 = NOVALUE;
    if (_4368 != 0) {
        _4369 = 1;
        goto L5; // [91] 112
    }
    _2 = (int)SEQ_PTR(_dirfil_8064);
    _4370 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4370);
    _4371 = (int)*(((s1_ptr)_2)->base + 2);
    _4370 = NOVALUE;
    _4372 = find_from(100, _4371, 1);
    _4371 = NOVALUE;
    _4369 = (_4372 != 0);
L5: 
    if (_4369 != 0) {
        goto L6; // [112] 144
    }
    if (IS_SEQUENCE(_filename_8063)){
            _4374 = SEQ_PTR(_filename_8063)->length;
    }
    else {
        _4374 = 1;
    }
    _4375 = (_4374 == 3);
    _4374 = NOVALUE;
    if (_4375 == 0) {
        DeRef(_4376);
        _4376 = 0;
        goto L7; // [123] 139
    }
    _2 = (int)SEQ_PTR(_filename_8063);
    _4377 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4377)) {
        _4378 = (_4377 == 58);
    }
    else {
        _4378 = binary_op(EQUALS, _4377, 58);
    }
    _4377 = NOVALUE;
    if (IS_ATOM_INT(_4378))
    _4376 = (_4378 != 0);
    else
    _4376 = DBL_PTR(_4378)->dbl != 0.0;
L7: 
    if (_4376 == 0)
    {
        _4376 = NOVALUE;
        goto L8; // [140] 153
    }
    else{
        _4376 = NOVALUE;
    }
L6: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_8063);
    DeRef(_dirfil_8064);
    DeRef(_4361);
    _4361 = NOVALUE;
    DeRef(_4368);
    _4368 = NOVALUE;
    DeRef(_4375);
    _4375 = NOVALUE;
    DeRef(_4378);
    _4378 = NOVALUE;
    return 2;
    goto L9; // [150] 170
L8: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_8063);
    DeRef(_dirfil_8064);
    DeRef(_4361);
    _4361 = NOVALUE;
    DeRef(_4368);
    _4368 = NOVALUE;
    DeRef(_4375);
    _4375 = NOVALUE;
    DeRef(_4378);
    _4378 = NOVALUE;
    return 1;
    goto L9; // [160] 170
L4: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_8063);
    DeRef(_dirfil_8064);
    DeRef(_4361);
    _4361 = NOVALUE;
    DeRef(_4368);
    _4368 = NOVALUE;
    DeRef(_4375);
    _4375 = NOVALUE;
    DeRef(_4378);
    _4378 = NOVALUE;
    return 0;
L9: 
    ;
}


int  __stdcall _11file_exists(int _name_8111)
{
    int _pName_8114 = NOVALUE;
    int _r_8117 = NOVALUE;
    int _4383 = NOVALUE;
    int _4381 = NOVALUE;
    int _4379 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _4379 = IS_ATOM(_name_8111);
    if (_4379 == 0)
    {
        _4379 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _4379 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_8111);
    DeRef(_pName_8114);
    DeRef(_r_8117);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = allocate_string(name)*/
    Ref(_name_8111);
    _0 = _pName_8114;
    _pName_8114 = _14allocate_string(_name_8111, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pName_8114);
    *((int *)(_2+4)) = _pName_8114;
    _4381 = MAKE_SEQ(_1);
    DeRef(_r_8117);
    _r_8117 = call_c(1, _11xGetFileAttributes_7117, _4381);
    DeRefDS(_4381);
    _4381 = NOVALUE;

    /** 		free(pName)*/
    Ref(_pName_8114);
    _14free(_pName_8114);

    /** 		return r > 0*/
    if (IS_ATOM_INT(_r_8117)) {
        _4383 = (_r_8117 > 0);
    }
    else {
        _4383 = (DBL_PTR(_r_8117)->dbl > (double)0);
    }
    DeRef(_name_8111);
    DeRef(_pName_8114);
    DeRef(_r_8117);
    return _4383;
    ;
}


int  __stdcall _11file_timestamp(int _fname_8124)
{
    int _d_8125 = NOVALUE;
    int _dir_inlined_dir_at_4_8127 = NOVALUE;
    int _4397 = NOVALUE;
    int _4396 = NOVALUE;
    int _4395 = NOVALUE;
    int _4394 = NOVALUE;
    int _4393 = NOVALUE;
    int _4392 = NOVALUE;
    int _4391 = NOVALUE;
    int _4390 = NOVALUE;
    int _4389 = NOVALUE;
    int _4388 = NOVALUE;
    int _4387 = NOVALUE;
    int _4386 = NOVALUE;
    int _4385 = NOVALUE;
    int _4384 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_d_8125);
    _d_8125 = machine(22, _fname_8124);

    /** 	if atom(d) then return -1 end if*/
    _4384 = IS_ATOM(_d_8125);
    if (_4384 == 0)
    {
        _4384 = NOVALUE;
        goto L1; // [19] 27
    }
    else{
        _4384 = NOVALUE;
    }
    DeRefDS(_fname_8124);
    DeRef(_d_8125);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_8125);
    _4385 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4385);
    _4386 = (int)*(((s1_ptr)_2)->base + 4);
    _4385 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8125);
    _4387 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4387);
    _4388 = (int)*(((s1_ptr)_2)->base + 5);
    _4387 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8125);
    _4389 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4389);
    _4390 = (int)*(((s1_ptr)_2)->base + 6);
    _4389 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8125);
    _4391 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4391);
    _4392 = (int)*(((s1_ptr)_2)->base + 7);
    _4391 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8125);
    _4393 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4393);
    _4394 = (int)*(((s1_ptr)_2)->base + 8);
    _4393 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_8125);
    _4395 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4395);
    _4396 = (int)*(((s1_ptr)_2)->base + 9);
    _4395 = NOVALUE;
    Ref(_4386);
    Ref(_4388);
    Ref(_4390);
    Ref(_4392);
    Ref(_4394);
    Ref(_4396);
    _4397 = _12new(_4386, _4388, _4390, _4392, _4394, _4396);
    _4386 = NOVALUE;
    _4388 = NOVALUE;
    _4390 = NOVALUE;
    _4392 = NOVALUE;
    _4394 = NOVALUE;
    _4396 = NOVALUE;
    DeRefDS(_fname_8124);
    DeRef(_d_8125);
    return _4397;
    ;
}


int  __stdcall _11copy_file(int _src_8145, int _dest_8146, int _overwrite_8147)
{
    int _info_8158 = NOVALUE;
    int _psrc_8162 = NOVALUE;
    int _pdest_8165 = NOVALUE;
    int _success_8168 = NOVALUE;
    int _4413 = NOVALUE;
    int _4411 = NOVALUE;
    int _4410 = NOVALUE;
    int _4406 = NOVALUE;
    int _4402 = NOVALUE;
    int _4401 = NOVALUE;
    int _4399 = NOVALUE;
    int _4398 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_8147)) {
        _1 = (long)(DBL_PTR(_overwrite_8147)->dbl);
        DeRefDS(_overwrite_8147);
        _overwrite_8147 = _1;
    }

    /** 	if length(dest) then*/
    if (IS_SEQUENCE(_dest_8146)){
            _4398 = SEQ_PTR(_dest_8146)->length;
    }
    else {
        _4398 = 1;
    }
    if (_4398 == 0)
    {
        _4398 = NOVALUE;
        goto L1; // [12] 68
    }
    else{
        _4398 = NOVALUE;
    }

    /** 		if file_type( dest ) = FILETYPE_DIRECTORY then*/
    RefDS(_dest_8146);
    _4399 = _11file_type(_dest_8146);
    if (binary_op_a(NOTEQ, _4399, 2)){
        DeRef(_4399);
        _4399 = NOVALUE;
        goto L2; // [21] 65
    }
    DeRef(_4399);
    _4399 = NOVALUE;

    /** 			if dest[$] != SLASH then*/
    if (IS_SEQUENCE(_dest_8146)){
            _4401 = SEQ_PTR(_dest_8146)->length;
    }
    else {
        _4401 = 1;
    }
    _2 = (int)SEQ_PTR(_dest_8146);
    _4402 = (int)*(((s1_ptr)_2)->base + _4401);
    if (binary_op_a(EQUALS, _4402, 92)){
        _4402 = NOVALUE;
        goto L3; // [34] 45
    }
    _4402 = NOVALUE;

    /** 				dest &= SLASH*/
    Append(&_dest_8146, _dest_8146, 92);
L3: 

    /** 			sequence info = pathinfo( src )*/
    RefDS(_src_8145);
    _0 = _info_8158;
    _info_8158 = _11pathinfo(_src_8145, 0);
    DeRef(_0);

    /** 			dest &= info[PATH_FILENAME]*/
    _2 = (int)SEQ_PTR(_info_8158);
    _4406 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_dest_8146) && IS_ATOM(_4406)) {
        Ref(_4406);
        Append(&_dest_8146, _dest_8146, _4406);
    }
    else if (IS_ATOM(_dest_8146) && IS_SEQUENCE(_4406)) {
    }
    else {
        Concat((object_ptr)&_dest_8146, _dest_8146, _4406);
    }
    _4406 = NOVALUE;
L2: 
    DeRef(_info_8158);
    _info_8158 = NOVALUE;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom psrc = allocate_string(src)*/
    RefDS(_src_8145);
    _0 = _psrc_8162;
    _psrc_8162 = _14allocate_string(_src_8145, 0);
    DeRef(_0);

    /** 		atom pdest = allocate_string(dest)*/
    RefDS(_dest_8146);
    _0 = _pdest_8165;
    _pdest_8165 = _14allocate_string(_dest_8146, 0);
    DeRef(_0);

    /** 		integer success = c_func(xCopyFile, {psrc, pdest, not overwrite})*/
    _4410 = (_overwrite_8147 == 0);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_psrc_8162);
    *((int *)(_2+4)) = _psrc_8162;
    Ref(_pdest_8165);
    *((int *)(_2+8)) = _pdest_8165;
    *((int *)(_2+12)) = _4410;
    _4411 = MAKE_SEQ(_1);
    _4410 = NOVALUE;
    _success_8168 = call_c(1, _11xCopyFile_7093, _4411);
    DeRefDS(_4411);
    _4411 = NOVALUE;
    if (!IS_ATOM_INT(_success_8168)) {
        _1 = (long)(DBL_PTR(_success_8168)->dbl);
        DeRefDS(_success_8168);
        _success_8168 = _1;
    }

    /** 		free({pdest, psrc})*/
    Ref(_psrc_8162);
    Ref(_pdest_8165);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pdest_8165;
    ((int *)_2)[2] = _psrc_8162;
    _4413 = MAKE_SEQ(_1);
    _14free(_4413);
    _4413 = NOVALUE;

    /** 	return success*/
    DeRefDS(_src_8145);
    DeRefDS(_dest_8146);
    DeRef(_psrc_8162);
    DeRef(_pdest_8165);
    return _success_8168;
    ;
}


int  __stdcall _11rename_file(int _old_name_8176, int _new_name_8177, int _overwrite_8178)
{
    int _psrc_8179 = NOVALUE;
    int _pdest_8180 = NOVALUE;
    int _ret_8181 = NOVALUE;
    int _tempfile_8182 = NOVALUE;
    int _4428 = NOVALUE;
    int _4425 = NOVALUE;
    int _4423 = NOVALUE;
    int _4421 = NOVALUE;
    int _4416 = NOVALUE;
    int _4415 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_8178)) {
        _1 = (long)(DBL_PTR(_overwrite_8178)->dbl);
        DeRefDS(_overwrite_8178);
        _overwrite_8178 = _1;
    }

    /** 	sequence tempfile = ""*/
    RefDS(_5);
    DeRef(_tempfile_8182);
    _tempfile_8182 = _5;

    /** 	if not overwrite then*/
    if (_overwrite_8178 != 0)
    goto L1; // [16] 38

    /** 		if file_exists(new_name) then*/
    RefDS(_new_name_8177);
    _4415 = _11file_exists(_new_name_8177);
    if (_4415 == 0) {
        DeRef(_4415);
        _4415 = NOVALUE;
        goto L2; // [25] 68
    }
    else {
        if (!IS_ATOM_INT(_4415) && DBL_PTR(_4415)->dbl == 0.0){
            DeRef(_4415);
            _4415 = NOVALUE;
            goto L2; // [25] 68
        }
        DeRef(_4415);
        _4415 = NOVALUE;
    }
    DeRef(_4415);
    _4415 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_old_name_8176);
    DeRefDS(_new_name_8177);
    DeRef(_psrc_8179);
    DeRef(_pdest_8180);
    DeRef(_ret_8181);
    DeRefDS(_tempfile_8182);
    return 0;
    goto L2; // [35] 68
L1: 

    /** 		if file_exists(new_name) then*/
    RefDS(_new_name_8177);
    _4416 = _11file_exists(_new_name_8177);
    if (_4416 == 0) {
        DeRef(_4416);
        _4416 = NOVALUE;
        goto L3; // [44] 67
    }
    else {
        if (!IS_ATOM_INT(_4416) && DBL_PTR(_4416)->dbl == 0.0){
            DeRef(_4416);
            _4416 = NOVALUE;
            goto L3; // [44] 67
        }
        DeRef(_4416);
        _4416 = NOVALUE;
    }
    DeRef(_4416);
    _4416 = NOVALUE;

    /** 			tempfile = temp_file(new_name)*/
    RefDS(_new_name_8177);
    RefDS(_5);
    RefDS(_4644);
    _0 = _tempfile_8182;
    _tempfile_8182 = _11temp_file(_new_name_8177, _5, _4644, 0);
    DeRef(_0);

    /** 			ret = move_file(new_name, tempfile)*/
    RefDS(_new_name_8177);
    RefDS(_tempfile_8182);
    _0 = _ret_8181;
    _ret_8181 = _11move_file(_new_name_8177, _tempfile_8182, 0);
    DeRef(_0);
L3: 
L2: 

    /** 	psrc = machine:allocate_string(old_name)*/
    RefDS(_old_name_8176);
    _0 = _psrc_8179;
    _psrc_8179 = _14allocate_string(_old_name_8176, 0);
    DeRef(_0);

    /** 	pdest = machine:allocate_string(new_name)*/
    RefDS(_new_name_8177);
    _0 = _pdest_8180;
    _pdest_8180 = _14allocate_string(_new_name_8177, 0);
    DeRef(_0);

    /** 	ret = c_func(xMoveFile, {psrc, pdest})*/
    Ref(_pdest_8180);
    Ref(_psrc_8179);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrc_8179;
    ((int *)_2)[2] = _pdest_8180;
    _4421 = MAKE_SEQ(_1);
    DeRef(_ret_8181);
    _ret_8181 = call_c(1, _11xMoveFile_7098, _4421);
    DeRefDS(_4421);
    _4421 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 	machine:free({pdest, psrc})*/
    Ref(_psrc_8179);
    Ref(_pdest_8180);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pdest_8180;
    ((int *)_2)[2] = _psrc_8179;
    _4423 = MAKE_SEQ(_1);
    _14free(_4423);
    _4423 = NOVALUE;

    /** 	if overwrite then*/
    if (_overwrite_8178 == 0)
    {
        goto L4; // [108] 142
    }
    else{
    }

    /** 		if not ret then*/
    if (IS_ATOM_INT(_ret_8181)) {
        if (_ret_8181 != 0){
            goto L5; // [113] 135
        }
    }
    else {
        if (DBL_PTR(_ret_8181)->dbl != 0.0){
            goto L5; // [113] 135
        }
    }

    /** 			if length(tempfile) > 0 then*/
    if (IS_SEQUENCE(_tempfile_8182)){
            _4425 = SEQ_PTR(_tempfile_8182)->length;
    }
    else {
        _4425 = 1;
    }
    if (_4425 <= 0)
    goto L6; // [121] 134

    /** 				ret = move_file(tempfile, new_name)*/
    RefDS(_tempfile_8182);
    RefDS(_new_name_8177);
    _0 = _ret_8181;
    _ret_8181 = _11move_file(_tempfile_8182, _new_name_8177, 0);
    DeRef(_0);
L6: 
L5: 

    /** 		delete_file(tempfile)*/
    RefDS(_tempfile_8182);
    _4428 = _11delete_file(_tempfile_8182);
L4: 

    /** 	return ret*/
    DeRefDS(_old_name_8176);
    DeRefDS(_new_name_8177);
    DeRef(_psrc_8179);
    DeRef(_pdest_8180);
    DeRef(_tempfile_8182);
    DeRef(_4428);
    _4428 = NOVALUE;
    return _ret_8181;
    ;
}


int  __stdcall _11move_file(int _src_8210, int _dest_8211, int _overwrite_8212)
{
    int _psrc_8213 = NOVALUE;
    int _pdest_8214 = NOVALUE;
    int _ret_8215 = NOVALUE;
    int _tempfile_8216 = NOVALUE;
    int _4444 = NOVALUE;
    int _4443 = NOVALUE;
    int _4442 = NOVALUE;
    int _4440 = NOVALUE;
    int _4438 = NOVALUE;
    int _4437 = NOVALUE;
    int _4432 = NOVALUE;
    int _4429 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_8212)) {
        _1 = (long)(DBL_PTR(_overwrite_8212)->dbl);
        DeRefDS(_overwrite_8212);
        _overwrite_8212 = _1;
    }

    /** 	atom psrc = 0, pdest = 0, ret*/
    DeRef(_psrc_8213);
    _psrc_8213 = 0;
    DeRef(_pdest_8214);
    _pdest_8214 = 0;

    /** 	sequence tempfile = ""*/
    RefDS(_5);
    DeRef(_tempfile_8216);
    _tempfile_8216 = _5;

    /** 	if not file_exists(src) then*/
    RefDS(_src_8210);
    _4429 = _11file_exists(_src_8210);
    if (IS_ATOM_INT(_4429)) {
        if (_4429 != 0){
            DeRef(_4429);
            _4429 = NOVALUE;
            goto L1; // [28] 38
        }
    }
    else {
        if (DBL_PTR(_4429)->dbl != 0.0){
            DeRef(_4429);
            _4429 = NOVALUE;
            goto L1; // [28] 38
        }
    }
    DeRef(_4429);
    _4429 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_src_8210);
    DeRefDS(_dest_8211);
    DeRef(_ret_8215);
    DeRefDS(_tempfile_8216);
    return 0;
L1: 

    /** 	if not overwrite then*/
    if (_overwrite_8212 != 0)
    goto L2; // [40] 60

    /** 		if file_exists( dest ) then*/
    RefDS(_dest_8211);
    _4432 = _11file_exists(_dest_8211);
    if (_4432 == 0) {
        DeRef(_4432);
        _4432 = NOVALUE;
        goto L3; // [49] 59
    }
    else {
        if (!IS_ATOM_INT(_4432) && DBL_PTR(_4432)->dbl == 0.0){
            DeRef(_4432);
            _4432 = NOVALUE;
            goto L3; // [49] 59
        }
        DeRef(_4432);
        _4432 = NOVALUE;
    }
    DeRef(_4432);
    _4432 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_src_8210);
    DeRefDS(_dest_8211);
    DeRef(_psrc_8213);
    DeRef(_pdest_8214);
    DeRef(_ret_8215);
    DeRef(_tempfile_8216);
    return 0;
L3: 
L2: 

    /** 	ifdef UNIX then*/

    /** 	ifdef LINUX then*/

    /** 	ifdef UNIX then*/

    /** 		psrc  = machine:allocate_string(src)*/
    RefDS(_src_8210);
    _0 = _psrc_8213;
    _psrc_8213 = _14allocate_string(_src_8210, 0);
    DeRef(_0);

    /** 		pdest = machine:allocate_string(dest)*/
    RefDS(_dest_8211);
    _0 = _pdest_8214;
    _pdest_8214 = _14allocate_string(_dest_8211, 0);
    DeRef(_0);

    /** 	if overwrite then*/
    if (_overwrite_8212 == 0)
    {
        goto L4; // [82] 105
    }
    else{
    }

    /** 		tempfile = temp_file(dest)*/
    RefDS(_dest_8211);
    RefDS(_5);
    RefDS(_4644);
    _0 = _tempfile_8216;
    _tempfile_8216 = _11temp_file(_dest_8211, _5, _4644, 0);
    DeRef(_0);

    /** 		move_file(dest, tempfile)*/
    RefDS(_dest_8211);
    RefDS(_tempfile_8216);
    _4437 = _11move_file(_dest_8211, _tempfile_8216, 0);
L4: 

    /** 	ret = c_func(xMoveFile, {psrc, pdest})*/
    Ref(_pdest_8214);
    Ref(_psrc_8213);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrc_8213;
    ((int *)_2)[2] = _pdest_8214;
    _4438 = MAKE_SEQ(_1);
    DeRef(_ret_8215);
    _ret_8215 = call_c(1, _11xMoveFile_7098, _4438);
    DeRefDS(_4438);
    _4438 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 	machine:free({pdest, psrc})*/
    Ref(_psrc_8213);
    Ref(_pdest_8214);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pdest_8214;
    ((int *)_2)[2] = _psrc_8213;
    _4440 = MAKE_SEQ(_1);
    _14free(_4440);
    _4440 = NOVALUE;

    /** 	if overwrite then*/
    if (_overwrite_8212 == 0)
    {
        goto L5; // [131] 158
    }
    else{
    }

    /** 		if not ret then*/
    if (IS_ATOM_INT(_ret_8215)) {
        if (_ret_8215 != 0){
            goto L6; // [136] 151
        }
    }
    else {
        if (DBL_PTR(_ret_8215)->dbl != 0.0){
            goto L6; // [136] 151
        }
    }

    /** 			move_file(tempfile, dest)*/
    RefDS(_dest_8211);
    DeRef(_4442);
    _4442 = _dest_8211;
    RefDS(_tempfile_8216);
    _4443 = _11move_file(_tempfile_8216, _4442, 0);
    _4442 = NOVALUE;
L6: 

    /** 		delete_file(tempfile)*/
    RefDS(_tempfile_8216);
    _4444 = _11delete_file(_tempfile_8216);
L5: 

    /** 	return ret*/
    DeRefDS(_src_8210);
    DeRefDS(_dest_8211);
    DeRef(_psrc_8213);
    DeRef(_pdest_8214);
    DeRef(_tempfile_8216);
    DeRef(_4437);
    _4437 = NOVALUE;
    DeRef(_4443);
    _4443 = NOVALUE;
    DeRef(_4444);
    _4444 = NOVALUE;
    return _ret_8215;
    ;
}


int  __stdcall _11file_length(int _filename_8242)
{
    int _list_8243 = NOVALUE;
    int _dir_inlined_dir_at_4_8245 = NOVALUE;
    int _4450 = NOVALUE;
    int _4449 = NOVALUE;
    int _4448 = NOVALUE;
    int _4447 = NOVALUE;
    int _4445 = NOVALUE;
    int _0, _1, _2;
    

    /** 	list = dir(filename)*/

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func(M_DIR, name)*/
    DeRef(_list_8243);
    _list_8243 = machine(22, _filename_8242);

    /** 	if atom(list) or length(list) = 0 then*/
    _4445 = IS_ATOM(_list_8243);
    if (_4445 != 0) {
        goto L1; // [19] 35
    }
    if (IS_SEQUENCE(_list_8243)){
            _4447 = SEQ_PTR(_list_8243)->length;
    }
    else {
        _4447 = 1;
    }
    _4448 = (_4447 == 0);
    _4447 = NOVALUE;
    if (_4448 == 0)
    {
        DeRef(_4448);
        _4448 = NOVALUE;
        goto L2; // [31] 42
    }
    else{
        DeRef(_4448);
        _4448 = NOVALUE;
    }
L1: 

    /** 		return -1*/
    DeRefDS(_filename_8242);
    DeRef(_list_8243);
    return -1;
L2: 

    /** 	return list[1][D_SIZE]*/
    _2 = (int)SEQ_PTR(_list_8243);
    _4449 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4449);
    _4450 = (int)*(((s1_ptr)_2)->base + 3);
    _4449 = NOVALUE;
    Ref(_4450);
    DeRefDS(_filename_8242);
    DeRef(_list_8243);
    return _4450;
    ;
}


int  __stdcall _11locate_file(int _filename_8255, int _search_list_8256, int _subdir_8257)
{
    int _extra_paths_8258 = NOVALUE;
    int _this_path_8259 = NOVALUE;
    int _4532 = NOVALUE;
    int _4531 = NOVALUE;
    int _4529 = NOVALUE;
    int _4527 = NOVALUE;
    int _4525 = NOVALUE;
    int _4524 = NOVALUE;
    int _4523 = NOVALUE;
    int _4521 = NOVALUE;
    int _4520 = NOVALUE;
    int _4519 = NOVALUE;
    int _4517 = NOVALUE;
    int _4516 = NOVALUE;
    int _4515 = NOVALUE;
    int _4512 = NOVALUE;
    int _4511 = NOVALUE;
    int _4509 = NOVALUE;
    int _4507 = NOVALUE;
    int _4506 = NOVALUE;
    int _4503 = NOVALUE;
    int _4498 = NOVALUE;
    int _4494 = NOVALUE;
    int _4487 = NOVALUE;
    int _4484 = NOVALUE;
    int _4481 = NOVALUE;
    int _4480 = NOVALUE;
    int _4476 = NOVALUE;
    int _4473 = NOVALUE;
    int _4471 = NOVALUE;
    int _4467 = NOVALUE;
    int _4465 = NOVALUE;
    int _4464 = NOVALUE;
    int _4462 = NOVALUE;
    int _4461 = NOVALUE;
    int _4458 = NOVALUE;
    int _4457 = NOVALUE;
    int _4454 = NOVALUE;
    int _4452 = NOVALUE;
    int _4451 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_8255);
    _4451 = _11absolute_path(_filename_8255);
    if (_4451 == 0) {
        DeRef(_4451);
        _4451 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_4451) && DBL_PTR(_4451)->dbl == 0.0){
            DeRef(_4451);
            _4451 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_4451);
        _4451 = NOVALUE;
    }
    DeRef(_4451);
    _4451 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_8256);
    DeRefDS(_subdir_8257);
    DeRef(_extra_paths_8258);
    DeRef(_this_path_8259);
    return _filename_8255;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_8256)){
            _4452 = SEQ_PTR(_search_list_8256)->length;
    }
    else {
        _4452 = 1;
    }
    if (_4452 != 0)
    goto L2; // [28] 277

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_4454, _3819, 92);
    RefDS(_4454);
    Append(&_search_list_8256, _search_list_8256, _4454);
    DeRefDS(_4454);
    _4454 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_8258);
    _extra_paths_8258 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_8258);
    _4457 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_4457);
    _4458 = _11dirname(_4457, 0);
    _4457 = NOVALUE;
    _0 = _extra_paths_8258;
    _extra_paths_8258 = _11canonical_path(_4458, 1, 0);
    DeRefDS(_0);
    _4458 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_8258);
    Append(&_search_list_8256, _search_list_8256, _extra_paths_8258);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4461 = EGetEnv(_4101);
    _4462 = EGetEnv(_4103);
    if (IS_SEQUENCE(_4461) && IS_ATOM(_4462)) {
        Ref(_4462);
        Append(&_extra_paths_8258, _4461, _4462);
    }
    else if (IS_ATOM(_4461) && IS_SEQUENCE(_4462)) {
        Ref(_4461);
        Prepend(&_extra_paths_8258, _4462, _4461);
    }
    else {
        Concat((object_ptr)&_extra_paths_8258, _4461, _4462);
        DeRef(_4461);
        _4461 = NOVALUE;
    }
    DeRef(_4461);
    _4461 = NOVALUE;
    DeRef(_4462);
    _4462 = NOVALUE;

    /** 		if sequence(extra_paths) then*/
    _4464 = 1;
    if (_4464 == 0)
    {
        _4464 = NOVALUE;
        goto L3; // [88] 102
    }
    else{
        _4464 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    Append(&_4465, _extra_paths_8258, 92);
    RefDS(_4465);
    Append(&_search_list_8256, _search_list_8256, _4465);
    DeRefDS(_4465);
    _4465 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_4467, _3850, 92);
    RefDS(_4467);
    Append(&_search_list_8256, _search_list_8256, _4467);
    DeRefDS(_4467);
    _4467 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_8258);
    _extra_paths_8258 = EGetEnv(_4469);

    /** 		if sequence(extra_paths) then*/
    _4471 = IS_SEQUENCE(_extra_paths_8258);
    if (_4471 == 0)
    {
        _4471 = NOVALUE;
        goto L4; // [122] 152
    }
    else{
        _4471 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4472;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8258;
        Concat_N((object_ptr)&_4473, concat_list, 4);
    }
    RefDS(_4473);
    Append(&_search_list_8256, _search_list_8256, _4473);
    DeRefDS(_4473);
    _4473 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4475;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8258;
        Concat_N((object_ptr)&_4476, concat_list, 4);
    }
    RefDS(_4476);
    Append(&_search_list_8256, _search_list_8256, _4476);
    DeRefDS(_4476);
    _4476 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_8258);
    _extra_paths_8258 = EGetEnv(_4478);

    /** 		if sequence(extra_paths) then*/
    _4480 = IS_SEQUENCE(_extra_paths_8258);
    if (_4480 == 0)
    {
        _4480 = NOVALUE;
        goto L5; // [162] 202
    }
    else{
        _4480 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_8258) && IS_ATOM(92)) {
        Append(&_4481, _extra_paths_8258, 92);
    }
    else if (IS_ATOM(_extra_paths_8258) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_4481, _extra_paths_8258, 92);
    }
    RefDS(_4481);
    Append(&_search_list_8256, _search_list_8256, _4481);
    DeRefDS(_4481);
    _4481 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4483;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8258;
        Concat_N((object_ptr)&_4484, concat_list, 4);
    }
    RefDS(_4484);
    Append(&_search_list_8256, _search_list_8256, _4484);
    DeRefDS(_4484);
    _4484 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4486;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8258;
        Concat_N((object_ptr)&_4487, concat_list, 4);
    }
    RefDS(_4487);
    Append(&_search_list_8256, _search_list_8256, _4487);
    DeRefDS(_4487);
    _4487 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_4493);
    *((int *)(_2+4)) = _4493;
    RefDS(_4492);
    *((int *)(_2+8)) = _4492;
    RefDS(_4491);
    *((int *)(_2+12)) = _4491;
    _4494 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_8256, _search_list_8256, _4494);
    DeRefDS(_4494);
    _4494 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_8258);
    _extra_paths_8258 = EGetEnv(_4496);

    /** 		if sequence(extra_paths) then*/
    _4498 = IS_SEQUENCE(_extra_paths_8258);
    if (_4498 == 0)
    {
        _4498 = NOVALUE;
        goto L6; // [226] 245
    }
    else{
        _4498 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8258);
    _0 = _extra_paths_8258;
    _extra_paths_8258 = _23split(_extra_paths_8258, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8256) && IS_ATOM(_extra_paths_8258)) {
        Ref(_extra_paths_8258);
        Append(&_search_list_8256, _search_list_8256, _extra_paths_8258);
    }
    else if (IS_ATOM(_search_list_8256) && IS_SEQUENCE(_extra_paths_8258)) {
    }
    else {
        Concat((object_ptr)&_search_list_8256, _search_list_8256, _extra_paths_8258);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_8258);
    _extra_paths_8258 = EGetEnv(_4501);

    /** 		if sequence(extra_paths) then*/
    _4503 = IS_SEQUENCE(_extra_paths_8258);
    if (_4503 == 0)
    {
        _4503 = NOVALUE;
        goto L7; // [255] 302
    }
    else{
        _4503 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8258);
    _0 = _extra_paths_8258;
    _extra_paths_8258 = _23split(_extra_paths_8258, 59, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8256) && IS_ATOM(_extra_paths_8258)) {
        Ref(_extra_paths_8258);
        Append(&_search_list_8256, _search_list_8256, _extra_paths_8258);
    }
    else if (IS_ATOM(_search_list_8256) && IS_SEQUENCE(_extra_paths_8258)) {
    }
    else {
        Concat((object_ptr)&_search_list_8256, _search_list_8256, _extra_paths_8258);
    }
    goto L7; // [274] 302
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_8256);
    _4506 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4506))
    _4507 = 1;
    else if (IS_ATOM_DBL(_4506))
    _4507 = IS_ATOM_INT(DoubleToInt(_4506));
    else
    _4507 = 0;
    _4506 = NOVALUE;
    if (_4507 == 0)
    {
        _4507 = NOVALUE;
        goto L8; // [286] 301
    }
    else{
        _4507 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_8256);
    _0 = _search_list_8256;
    _search_list_8256 = _23split(_search_list_8256, 59, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_8257)){
            _4509 = SEQ_PTR(_subdir_8257)->length;
    }
    else {
        _4509 = 1;
    }
    if (_4509 <= 0)
    goto L9; // [307] 332

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_8257)){
            _4511 = SEQ_PTR(_subdir_8257)->length;
    }
    else {
        _4511 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_8257);
    _4512 = (int)*(((s1_ptr)_2)->base + _4511);
    if (binary_op_a(EQUALS, _4512, 92)){
        _4512 = NOVALUE;
        goto LA; // [320] 331
    }
    _4512 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_8257, _subdir_8257, 92);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_8256)){
            _4515 = SEQ_PTR(_search_list_8256)->length;
    }
    else {
        _4515 = 1;
    }
    {
        int _i_8336;
        _i_8336 = 1;
LB: 
        if (_i_8336 > _4515){
            goto LC; // [337] 460
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_8256);
        _4516 = (int)*(((s1_ptr)_2)->base + _i_8336);
        if (IS_SEQUENCE(_4516)){
                _4517 = SEQ_PTR(_4516)->length;
        }
        else {
            _4517 = 1;
        }
        _4516 = NOVALUE;
        if (_4517 != 0)
        goto LD; // [353] 362

        /** 			continue*/
        goto LE; // [359] 455
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_8256);
        _4519 = (int)*(((s1_ptr)_2)->base + _i_8336);
        if (IS_SEQUENCE(_4519)){
                _4520 = SEQ_PTR(_4519)->length;
        }
        else {
            _4520 = 1;
        }
        _2 = (int)SEQ_PTR(_4519);
        _4521 = (int)*(((s1_ptr)_2)->base + _4520);
        _4519 = NOVALUE;
        if (binary_op_a(EQUALS, _4521, 92)){
            _4521 = NOVALUE;
            goto LF; // [375] 394
        }
        _4521 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_8256);
        _4523 = (int)*(((s1_ptr)_2)->base + _i_8336);
        if (IS_SEQUENCE(_4523) && IS_ATOM(92)) {
            Append(&_4524, _4523, 92);
        }
        else if (IS_ATOM(_4523) && IS_SEQUENCE(92)) {
        }
        else {
            Concat((object_ptr)&_4524, _4523, 92);
            _4523 = NOVALUE;
        }
        _4523 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_8256);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_8256 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8336);
        _1 = *(int *)_2;
        *(int *)_2 = _4524;
        if( _1 != _4524 ){
            DeRef(_1);
        }
        _4524 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_8257)){
                _4525 = SEQ_PTR(_subdir_8257)->length;
        }
        else {
            _4525 = 1;
        }
        if (_4525 <= 0)
        goto L10; // [399] 418

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_8256);
        _4527 = (int)*(((s1_ptr)_2)->base + _i_8336);
        {
            int concat_list[3];

            concat_list[0] = _filename_8255;
            concat_list[1] = _subdir_8257;
            concat_list[2] = _4527;
            Concat_N((object_ptr)&_this_path_8259, concat_list, 3);
        }
        _4527 = NOVALUE;
        goto L11; // [415] 429
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_8256);
        _4529 = (int)*(((s1_ptr)_2)->base + _i_8336);
        if (IS_SEQUENCE(_4529) && IS_ATOM(_filename_8255)) {
        }
        else if (IS_ATOM(_4529) && IS_SEQUENCE(_filename_8255)) {
            Ref(_4529);
            Prepend(&_this_path_8259, _filename_8255, _4529);
        }
        else {
            Concat((object_ptr)&_this_path_8259, _4529, _filename_8255);
            _4529 = NOVALUE;
        }
        _4529 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_8259);
        _4531 = _11file_exists(_this_path_8259);
        if (_4531 == 0) {
            DeRef(_4531);
            _4531 = NOVALUE;
            goto L12; // [437] 453
        }
        else {
            if (!IS_ATOM_INT(_4531) && DBL_PTR(_4531)->dbl == 0.0){
                DeRef(_4531);
                _4531 = NOVALUE;
                goto L12; // [437] 453
            }
            DeRef(_4531);
            _4531 = NOVALUE;
        }
        DeRef(_4531);
        _4531 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_8259);
        _4532 = _11canonical_path(_this_path_8259, 0, 0);
        DeRefDS(_filename_8255);
        DeRefDS(_search_list_8256);
        DeRefDS(_subdir_8257);
        DeRef(_extra_paths_8258);
        DeRefDS(_this_path_8259);
        _4516 = NOVALUE;
        return _4532;
L12: 

        /** 	end for*/
LE: 
        _i_8336 = _i_8336 + 1;
        goto LB; // [455] 344
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_8256);
    DeRefDS(_subdir_8257);
    DeRef(_extra_paths_8258);
    DeRef(_this_path_8259);
    _4516 = NOVALUE;
    DeRef(_4532);
    _4532 = NOVALUE;
    return _filename_8255;
    ;
}


int  __stdcall _11disk_metrics(int _disk_path_8362)
{
    int _result_8363 = NOVALUE;
    int _path_addr_8365 = NOVALUE;
    int _metric_addr_8366 = NOVALUE;
    int _4545 = NOVALUE;
    int _4543 = NOVALUE;
    int _4542 = NOVALUE;
    int _4541 = NOVALUE;
    int _4540 = NOVALUE;
    int _4539 = NOVALUE;
    int _4538 = NOVALUE;
    int _4537 = NOVALUE;
    int _4534 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence result = {0, 0, 0, 0} */
    _0 = _result_8363;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _result_8363 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	atom path_addr = 0*/
    DeRef(_path_addr_8365);
    _path_addr_8365 = 0;

    /** 	atom metric_addr = 0*/
    DeRef(_metric_addr_8366);
    _metric_addr_8366 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		if sequence(disk_path) then */
    _4534 = IS_SEQUENCE(_disk_path_8362);
    if (_4534 == 0)
    {
        _4534 = NOVALUE;
        goto L1; // [27] 40
    }
    else{
        _4534 = NOVALUE;
    }

    /** 			path_addr = allocate_string(disk_path) */
    Ref(_disk_path_8362);
    _path_addr_8365 = _14allocate_string(_disk_path_8362, 0);
    goto L2; // [37] 46
L1: 

    /** 			path_addr = 0 */
    DeRef(_path_addr_8365);
    _path_addr_8365 = 0;
L2: 

    /** 		metric_addr = allocate(16) */
    _0 = _metric_addr_8366;
    _metric_addr_8366 = _14allocate(16, 0);
    DeRef(_0);

    /** 		if c_func(xGetDiskFreeSpace, {path_addr, */
    if (IS_ATOM_INT(_metric_addr_8366)) {
        _4537 = _metric_addr_8366 + 0;
        if ((long)((unsigned long)_4537 + (unsigned long)HIGH_BITS) >= 0) 
        _4537 = NewDouble((double)_4537);
    }
    else {
        _4537 = NewDouble(DBL_PTR(_metric_addr_8366)->dbl + (double)0);
    }
    if (IS_ATOM_INT(_metric_addr_8366)) {
        _4538 = _metric_addr_8366 + 4;
        if ((long)((unsigned long)_4538 + (unsigned long)HIGH_BITS) >= 0) 
        _4538 = NewDouble((double)_4538);
    }
    else {
        _4538 = NewDouble(DBL_PTR(_metric_addr_8366)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_metric_addr_8366)) {
        _4539 = _metric_addr_8366 + 8;
        if ((long)((unsigned long)_4539 + (unsigned long)HIGH_BITS) >= 0) 
        _4539 = NewDouble((double)_4539);
    }
    else {
        _4539 = NewDouble(DBL_PTR(_metric_addr_8366)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_metric_addr_8366)) {
        _4540 = _metric_addr_8366 + 12;
        if ((long)((unsigned long)_4540 + (unsigned long)HIGH_BITS) >= 0) 
        _4540 = NewDouble((double)_4540);
    }
    else {
        _4540 = NewDouble(DBL_PTR(_metric_addr_8366)->dbl + (double)12);
    }
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_path_addr_8365);
    *((int *)(_2+4)) = _path_addr_8365;
    *((int *)(_2+8)) = _4537;
    *((int *)(_2+12)) = _4538;
    *((int *)(_2+16)) = _4539;
    *((int *)(_2+20)) = _4540;
    _4541 = MAKE_SEQ(_1);
    _4540 = NOVALUE;
    _4539 = NOVALUE;
    _4538 = NOVALUE;
    _4537 = NOVALUE;
    _4542 = call_c(1, _11xGetDiskFreeSpace_7121, _4541);
    DeRefDS(_4541);
    _4541 = NOVALUE;
    if (_4542 == 0) {
        DeRef(_4542);
        _4542 = NOVALUE;
        goto L3; // [86] 101
    }
    else {
        if (!IS_ATOM_INT(_4542) && DBL_PTR(_4542)->dbl == 0.0){
            DeRef(_4542);
            _4542 = NOVALUE;
            goto L3; // [86] 101
        }
        DeRef(_4542);
        _4542 = NOVALUE;
    }
    DeRef(_4542);
    _4542 = NOVALUE;

    /** 			result = peek4s({metric_addr, 4}) */
    Ref(_metric_addr_8366);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _metric_addr_8366;
    ((int *)_2)[2] = 4;
    _4543 = MAKE_SEQ(_1);
    DeRef(_result_8363);
    _1 = (int)SEQ_PTR(_4543);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _result_8363 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
        _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4543);
    _4543 = NOVALUE;
L3: 

    /** 		free({path_addr, metric_addr}) */
    Ref(_metric_addr_8366);
    Ref(_path_addr_8365);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _path_addr_8365;
    ((int *)_2)[2] = _metric_addr_8366;
    _4545 = MAKE_SEQ(_1);
    _14free(_4545);
    _4545 = NOVALUE;

    /** 	return result */
    DeRef(_disk_path_8362);
    DeRef(_path_addr_8365);
    DeRef(_metric_addr_8366);
    return _result_8363;
    ;
}


int  __stdcall _11disk_size(int _disk_path_8388)
{
    int _disk_size_8389 = NOVALUE;
    int _result_8391 = NOVALUE;
    int _bytes_per_cluster_8392 = NOVALUE;
    int _4558 = NOVALUE;
    int _4557 = NOVALUE;
    int _4556 = NOVALUE;
    int _4555 = NOVALUE;
    int _4554 = NOVALUE;
    int _4553 = NOVALUE;
    int _4552 = NOVALUE;
    int _4550 = NOVALUE;
    int _4549 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence disk_size = {0,0,0, disk_path}*/
    _0 = _disk_size_8389;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    Ref(_disk_path_8388);
    *((int *)(_2+16)) = _disk_path_8388;
    _disk_size_8389 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		sequence result */

    /** 		atom bytes_per_cluster*/

    /** 		result = disk_metrics(disk_path) */
    Ref(_disk_path_8388);
    _0 = _result_8391;
    _result_8391 = _11disk_metrics(_disk_path_8388);
    DeRef(_0);

    /** 		bytes_per_cluster = result[BYTES_PER_SECTOR] * result[SECTORS_PER_CLUSTER]*/
    _2 = (int)SEQ_PTR(_result_8391);
    _4549 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_result_8391);
    _4550 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_bytes_per_cluster_8392);
    if (IS_ATOM_INT(_4549) && IS_ATOM_INT(_4550)) {
        if (_4549 == (short)_4549 && _4550 <= INT15 && _4550 >= -INT15)
        _bytes_per_cluster_8392 = _4549 * _4550;
        else
        _bytes_per_cluster_8392 = NewDouble(_4549 * (double)_4550);
    }
    else {
        _bytes_per_cluster_8392 = binary_op(MULTIPLY, _4549, _4550);
    }
    _4549 = NOVALUE;
    _4550 = NOVALUE;

    /** 		disk_size[TOTAL_BYTES] = bytes_per_cluster * result[TOTAL_NUMBER_OF_CLUSTERS] */
    _2 = (int)SEQ_PTR(_result_8391);
    _4552 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_bytes_per_cluster_8392) && IS_ATOM_INT(_4552)) {
        if (_bytes_per_cluster_8392 == (short)_bytes_per_cluster_8392 && _4552 <= INT15 && _4552 >= -INT15)
        _4553 = _bytes_per_cluster_8392 * _4552;
        else
        _4553 = NewDouble(_bytes_per_cluster_8392 * (double)_4552);
    }
    else {
        _4553 = binary_op(MULTIPLY, _bytes_per_cluster_8392, _4552);
    }
    _4552 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8389);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8389 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4553;
    if( _1 != _4553 ){
        DeRef(_1);
    }
    _4553 = NOVALUE;

    /** 		disk_size[FREE_BYTES]  = bytes_per_cluster * result[NUMBER_OF_FREE_CLUSTERS] */
    _2 = (int)SEQ_PTR(_result_8391);
    _4554 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_bytes_per_cluster_8392) && IS_ATOM_INT(_4554)) {
        if (_bytes_per_cluster_8392 == (short)_bytes_per_cluster_8392 && _4554 <= INT15 && _4554 >= -INT15)
        _4555 = _bytes_per_cluster_8392 * _4554;
        else
        _4555 = NewDouble(_bytes_per_cluster_8392 * (double)_4554);
    }
    else {
        _4555 = binary_op(MULTIPLY, _bytes_per_cluster_8392, _4554);
    }
    _4554 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8389);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8389 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4555;
    if( _1 != _4555 ){
        DeRef(_1);
    }
    _4555 = NOVALUE;

    /** 		disk_size[USED_BYTES]  = disk_size[TOTAL_BYTES] - disk_size[FREE_BYTES] */
    _2 = (int)SEQ_PTR(_disk_size_8389);
    _4556 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_disk_size_8389);
    _4557 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4556) && IS_ATOM_INT(_4557)) {
        _4558 = _4556 - _4557;
        if ((long)((unsigned long)_4558 +(unsigned long) HIGH_BITS) >= 0){
            _4558 = NewDouble((double)_4558);
        }
    }
    else {
        _4558 = binary_op(MINUS, _4556, _4557);
    }
    _4556 = NOVALUE;
    _4557 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8389);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8389 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4558;
    if( _1 != _4558 ){
        DeRef(_1);
    }
    _4558 = NOVALUE;

    /** 	return disk_size */
    DeRef(_disk_path_8388);
    DeRefDS(_result_8391);
    DeRef(_bytes_per_cluster_8392);
    return _disk_size_8389;
    ;
}


int _11count_files(int _orig_path_8413, int _dir_info_8414, int _inst_8415)
{
    int _pos_8416 = NOVALUE;
    int _ext_8417 = NOVALUE;
    int _fileext_inlined_fileext_at_223_8460 = NOVALUE;
    int _data_inlined_fileext_at_223_8459 = NOVALUE;
    int _path_inlined_fileext_at_220_8458 = NOVALUE;
    int _4628 = NOVALUE;
    int _4627 = NOVALUE;
    int _4626 = NOVALUE;
    int _4624 = NOVALUE;
    int _4623 = NOVALUE;
    int _4622 = NOVALUE;
    int _4621 = NOVALUE;
    int _4619 = NOVALUE;
    int _4618 = NOVALUE;
    int _4616 = NOVALUE;
    int _4615 = NOVALUE;
    int _4614 = NOVALUE;
    int _4613 = NOVALUE;
    int _4612 = NOVALUE;
    int _4611 = NOVALUE;
    int _4610 = NOVALUE;
    int _4608 = NOVALUE;
    int _4607 = NOVALUE;
    int _4605 = NOVALUE;
    int _4604 = NOVALUE;
    int _4603 = NOVALUE;
    int _4602 = NOVALUE;
    int _4601 = NOVALUE;
    int _4600 = NOVALUE;
    int _4599 = NOVALUE;
    int _4598 = NOVALUE;
    int _4597 = NOVALUE;
    int _4596 = NOVALUE;
    int _4595 = NOVALUE;
    int _4594 = NOVALUE;
    int _4593 = NOVALUE;
    int _4592 = NOVALUE;
    int _4590 = NOVALUE;
    int _4589 = NOVALUE;
    int _4588 = NOVALUE;
    int _4587 = NOVALUE;
    int _4585 = NOVALUE;
    int _4584 = NOVALUE;
    int _4583 = NOVALUE;
    int _4582 = NOVALUE;
    int _4581 = NOVALUE;
    int _4580 = NOVALUE;
    int _4579 = NOVALUE;
    int _4577 = NOVALUE;
    int _4576 = NOVALUE;
    int _4575 = NOVALUE;
    int _4574 = NOVALUE;
    int _4573 = NOVALUE;
    int _4572 = NOVALUE;
    int _4569 = NOVALUE;
    int _4568 = NOVALUE;
    int _4567 = NOVALUE;
    int _4566 = NOVALUE;
    int _4565 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_8416 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_8413);
    DeRefDS(_orig_path_8413);
    _orig_path_8413 = _orig_path_8413;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4565 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4565 == _3819)
    _4566 = 1;
    else if (IS_ATOM_INT(_4565) && IS_ATOM_INT(_3819))
    _4566 = 0;
    else
    _4566 = (compare(_4565, _3819) == 0);
    _4565 = NOVALUE;
    if (_4566 == 0)
    {
        _4566 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _4566 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8413);
    DeRefDS(_dir_info_8414);
    DeRefDS(_inst_8415);
    DeRef(_ext_8417);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4567 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4567 == _3850)
    _4568 = 1;
    else if (IS_ATOM_INT(_4567) && IS_ATOM_INT(_3850))
    _4568 = 0;
    else
    _4568 = (compare(_4567, _3850) == 0);
    _4567 = NOVALUE;
    if (_4568 == 0)
    {
        _4568 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _4568 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8413);
    DeRefDS(_dir_info_8414);
    DeRefDS(_inst_8415);
    DeRef(_ext_8417);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4569 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _4569, 0)){
        _4569 = NOVALUE;
        goto L3; // [65] 112
    }
    _4569 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4572 = (int)*(((s1_ptr)_2)->base + 2);
    _4573 = find_from(104, _4572, 1);
    _4572 = NOVALUE;
    if (_4573 == 0)
    {
        _4573 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _4573 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8413);
    DeRefDS(_dir_info_8414);
    DeRefDS(_inst_8415);
    DeRef(_ext_8417);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4574 = (int)*(((s1_ptr)_2)->base + 2);
    _4575 = find_from(115, _4574, 1);
    _4574 = NOVALUE;
    if (_4575 == 0)
    {
        _4575 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _4575 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8413);
    DeRefDS(_dir_info_8414);
    DeRefDS(_inst_8415);
    DeRef(_ext_8417);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4576 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4576))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4576)->dbl));
    else
    _3 = (int)(_4576 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4579 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4580 = (int)*(((s1_ptr)_2)->base + 3);
    _4577 = NOVALUE;
    if (IS_ATOM_INT(_4580) && IS_ATOM_INT(_4579)) {
        _4581 = _4580 + _4579;
        if ((long)((unsigned long)_4581 + (unsigned long)HIGH_BITS) >= 0) 
        _4581 = NewDouble((double)_4581);
    }
    else {
        _4581 = binary_op(PLUS, _4580, _4579);
    }
    _4580 = NOVALUE;
    _4579 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4581;
    if( _1 != _4581 ){
        DeRef(_1);
    }
    _4581 = NOVALUE;
    _4577 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4582 = (int)*(((s1_ptr)_2)->base + 2);
    _4583 = find_from(100, _4582, 1);
    _4582 = NOVALUE;
    if (_4583 == 0)
    {
        _4583 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _4583 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4584 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4584))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4584)->dbl));
    else
    _3 = (int)(_4584 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4587 = (int)*(((s1_ptr)_2)->base + 1);
    _4585 = NOVALUE;
    if (IS_ATOM_INT(_4587)) {
        _4588 = _4587 + 1;
        if (_4588 > MAXINT){
            _4588 = NewDouble((double)_4588);
        }
    }
    else
    _4588 = binary_op(PLUS, 1, _4587);
    _4587 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4588;
    if( _1 != _4588 ){
        DeRef(_1);
    }
    _4588 = NOVALUE;
    _4585 = NOVALUE;
    goto L7; // [180] 464
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4589 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4589))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4589)->dbl));
    else
    _3 = (int)(_4589 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4592 = (int)*(((s1_ptr)_2)->base + 2);
    _4590 = NOVALUE;
    if (IS_ATOM_INT(_4592)) {
        _4593 = _4592 + 1;
        if (_4593 > MAXINT){
            _4593 = NewDouble((double)_4593);
        }
    }
    else
    _4593 = binary_op(PLUS, 1, _4592);
    _4592 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4593;
    if( _1 != _4593 ){
        DeRef(_1);
    }
    _4593 = NOVALUE;
    _4590 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(lower(dir_info[D_NAME]))*/
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4594 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4594);
    _4595 = _6lower(_4594);
    _4594 = NOVALUE;
    DeRef(_path_inlined_fileext_at_220_8458);
    _path_inlined_fileext_at_220_8458 = _4595;
    _4595 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_220_8458);
    _0 = _data_inlined_fileext_at_223_8459;
    _data_inlined_fileext_at_223_8459 = _11pathinfo(_path_inlined_fileext_at_220_8458, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_8417);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_223_8459);
    _ext_8417 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_8417);
    DeRef(_path_inlined_fileext_at_220_8458);
    _path_inlined_fileext_at_220_8458 = NOVALUE;
    DeRef(_data_inlined_fileext_at_223_8459);
    _data_inlined_fileext_at_223_8459 = NOVALUE;

    /** 		pos = 0*/
    _pos_8416 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4596 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!IS_ATOM_INT(_4596)){
        _4597 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4596)->dbl));
    }
    else{
        _4597 = (int)*(((s1_ptr)_2)->base + _4596);
    }
    _2 = (int)SEQ_PTR(_4597);
    _4598 = (int)*(((s1_ptr)_2)->base + 4);
    _4597 = NOVALUE;
    if (IS_SEQUENCE(_4598)){
            _4599 = SEQ_PTR(_4598)->length;
    }
    else {
        _4599 = 1;
    }
    _4598 = NOVALUE;
    {
        int _i_8462;
        _i_8462 = 1;
L8: 
        if (_i_8462 > _4599){
            goto L9; // [269] 326
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_8415);
        _4600 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_11file_counters_8410);
        if (!IS_ATOM_INT(_4600)){
            _4601 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4600)->dbl));
        }
        else{
            _4601 = (int)*(((s1_ptr)_2)->base + _4600);
        }
        _2 = (int)SEQ_PTR(_4601);
        _4602 = (int)*(((s1_ptr)_2)->base + 4);
        _4601 = NOVALUE;
        _2 = (int)SEQ_PTR(_4602);
        _4603 = (int)*(((s1_ptr)_2)->base + _i_8462);
        _4602 = NOVALUE;
        _2 = (int)SEQ_PTR(_4603);
        _4604 = (int)*(((s1_ptr)_2)->base + 1);
        _4603 = NOVALUE;
        if (_4604 == _ext_8417)
        _4605 = 1;
        else if (IS_ATOM_INT(_4604) && IS_ATOM_INT(_ext_8417))
        _4605 = 0;
        else
        _4605 = (compare(_4604, _ext_8417) == 0);
        _4604 = NOVALUE;
        if (_4605 == 0)
        {
            _4605 = NOVALUE;
            goto LA; // [306] 319
        }
        else{
            _4605 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_8416 = _i_8462;

        /** 				exit*/
        goto L9; // [316] 326
LA: 

        /** 		end for*/
        _i_8462 = _i_8462 + 1;
        goto L8; // [321] 276
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_8416 != 0)
    goto LB; // [328] 389

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4607 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4607))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4607)->dbl));
    else
    _3 = (int)(_4607 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_8417);
    *((int *)(_2+4)) = _ext_8417;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _4610 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4610;
    _4611 = MAKE_SEQ(_1);
    _4610 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4612 = (int)*(((s1_ptr)_2)->base + 4);
    _4608 = NOVALUE;
    if (IS_SEQUENCE(_4612) && IS_ATOM(_4611)) {
    }
    else if (IS_ATOM(_4612) && IS_SEQUENCE(_4611)) {
        Ref(_4612);
        Prepend(&_4613, _4611, _4612);
    }
    else {
        Concat((object_ptr)&_4613, _4612, _4611);
        _4612 = NOVALUE;
    }
    _4612 = NOVALUE;
    DeRefDS(_4611);
    _4611 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4613;
    if( _1 != _4613 ){
        DeRef(_1);
    }
    _4613 = NOVALUE;
    _4608 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4614 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!IS_ATOM_INT(_4614)){
        _4615 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4614)->dbl));
    }
    else{
        _4615 = (int)*(((s1_ptr)_2)->base + _4614);
    }
    _2 = (int)SEQ_PTR(_4615);
    _4616 = (int)*(((s1_ptr)_2)->base + 4);
    _4615 = NOVALUE;
    if (IS_SEQUENCE(_4616)){
            _pos_8416 = SEQ_PTR(_4616)->length;
    }
    else {
        _pos_8416 = 1;
    }
    _4616 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4618 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4618))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4618)->dbl));
    else
    _3 = (int)(_4618 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4619 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8416 + ((s1_ptr)_2)->base);
    _4619 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4621 = (int)*(((s1_ptr)_2)->base + 2);
    _4619 = NOVALUE;
    if (IS_ATOM_INT(_4621)) {
        _4622 = _4621 + 1;
        if (_4622 > MAXINT){
            _4622 = NewDouble((double)_4622);
        }
    }
    else
    _4622 = binary_op(PLUS, 1, _4621);
    _4621 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4622;
    if( _1 != _4622 ){
        DeRef(_1);
    }
    _4622 = NOVALUE;
    _4619 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8415);
    _4623 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8410 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4623))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4623)->dbl));
    else
    _3 = (int)(_4623 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4624 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8416 + ((s1_ptr)_2)->base);
    _4624 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_8414);
    _4626 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4627 = (int)*(((s1_ptr)_2)->base + 3);
    _4624 = NOVALUE;
    if (IS_ATOM_INT(_4627) && IS_ATOM_INT(_4626)) {
        _4628 = _4627 + _4626;
        if ((long)((unsigned long)_4628 + (unsigned long)HIGH_BITS) >= 0) 
        _4628 = NewDouble((double)_4628);
    }
    else {
        _4628 = binary_op(PLUS, _4627, _4626);
    }
    _4627 = NOVALUE;
    _4626 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4628;
    if( _1 != _4628 ){
        DeRef(_1);
    }
    _4628 = NOVALUE;
    _4624 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_8413);
    DeRefDS(_dir_info_8414);
    DeRefDS(_inst_8415);
    DeRef(_ext_8417);
    _4576 = NOVALUE;
    _4584 = NOVALUE;
    _4589 = NOVALUE;
    _4596 = NOVALUE;
    _4598 = NOVALUE;
    _4600 = NOVALUE;
    _4607 = NOVALUE;
    _4614 = NOVALUE;
    _4616 = NOVALUE;
    _4618 = NOVALUE;
    _4623 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _11dir_size(int _dir_path_8500, int _count_all_8501)
{
    int _fc_8502 = NOVALUE;
    int _4643 = NOVALUE;
    int _4642 = NOVALUE;
    int _4640 = NOVALUE;
    int _4639 = NOVALUE;
    int _4637 = NOVALUE;
    int _4636 = NOVALUE;
    int _4635 = NOVALUE;
    int _4634 = NOVALUE;
    int _4633 = NOVALUE;
    int _4632 = NOVALUE;
    int _4629 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_all_8501)) {
        _1 = (long)(DBL_PTR(_count_all_8501)->dbl);
        DeRefDS(_count_all_8501);
        _count_all_8501 = _1;
    }

    /** 	file_counters = append(file_counters, {0,0,0,{}})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    RefDS(_5);
    *((int *)(_2+16)) = _5;
    _4629 = MAKE_SEQ(_1);
    RefDS(_4629);
    Append(&_11file_counters_8410, _11file_counters_8410, _4629);
    DeRefDS(_4629);
    _4629 = NOVALUE;

    /** 	walk_dir(dir_path, {routine_id("count_files"), {count_all, length(file_counters)}}, 0)*/
    _4632 = CRoutineId(360, 11, _4631);
    if (IS_SEQUENCE(_11file_counters_8410)){
            _4633 = SEQ_PTR(_11file_counters_8410)->length;
    }
    else {
        _4633 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _count_all_8501;
    ((int *)_2)[2] = _4633;
    _4634 = MAKE_SEQ(_1);
    _4633 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4632;
    ((int *)_2)[2] = _4634;
    _4635 = MAKE_SEQ(_1);
    _4634 = NOVALUE;
    _4632 = NOVALUE;
    RefDS(_dir_path_8500);
    _4636 = _11walk_dir(_dir_path_8500, _4635, 0, -99999);
    _4635 = NOVALUE;

    /** 	fc = file_counters[$]*/
    if (IS_SEQUENCE(_11file_counters_8410)){
            _4637 = SEQ_PTR(_11file_counters_8410)->length;
    }
    else {
        _4637 = 1;
    }
    DeRef(_fc_8502);
    _2 = (int)SEQ_PTR(_11file_counters_8410);
    _fc_8502 = (int)*(((s1_ptr)_2)->base + _4637);
    RefDS(_fc_8502);

    /** 	file_counters = file_counters[1 .. $-1]*/
    if (IS_SEQUENCE(_11file_counters_8410)){
            _4639 = SEQ_PTR(_11file_counters_8410)->length;
    }
    else {
        _4639 = 1;
    }
    _4640 = _4639 - 1;
    _4639 = NOVALUE;
    rhs_slice_target = (object_ptr)&_11file_counters_8410;
    RHS_Slice(_11file_counters_8410, 1, _4640);

    /** 	fc[COUNT_TYPES] = stdsort:sort(fc[COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_fc_8502);
    _4642 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_4642);
    _4643 = _24sort(_4642, 1);
    _4642 = NOVALUE;
    _2 = (int)SEQ_PTR(_fc_8502);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _fc_8502 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4643;
    if( _1 != _4643 ){
        DeRef(_1);
    }
    _4643 = NOVALUE;

    /** 	return fc*/
    DeRefDS(_dir_path_8500);
    _4640 = NOVALUE;
    DeRef(_4636);
    _4636 = NOVALUE;
    return _fc_8502;
    ;
}


int  __stdcall _11temp_file(int _temp_location_8520, int _temp_prefix_8521, int _temp_extn_8522, int _reserve_temp_8524)
{
    int _randname_8525 = NOVALUE;
    int _envtmp_8529 = NOVALUE;
    int _tdir_8548 = NOVALUE;
    int _4682 = NOVALUE;
    int _4680 = NOVALUE;
    int _4678 = NOVALUE;
    int _4676 = NOVALUE;
    int _4674 = NOVALUE;
    int _4673 = NOVALUE;
    int _4672 = NOVALUE;
    int _4668 = NOVALUE;
    int _4667 = NOVALUE;
    int _4666 = NOVALUE;
    int _4665 = NOVALUE;
    int _4662 = NOVALUE;
    int _4661 = NOVALUE;
    int _4660 = NOVALUE;
    int _4655 = NOVALUE;
    int _4652 = NOVALUE;
    int _4649 = NOVALUE;
    int _4645 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_reserve_temp_8524)) {
        _1 = (long)(DBL_PTR(_reserve_temp_8524)->dbl);
        DeRefDS(_reserve_temp_8524);
        _reserve_temp_8524 = _1;
    }

    /** 	if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_8520)){
            _4645 = SEQ_PTR(_temp_location_8520)->length;
    }
    else {
        _4645 = 1;
    }
    if (_4645 != 0)
    goto L1; // [14] 67

    /** 		object envtmp*/

    /** 		envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_8529);
    _envtmp_8529 = EGetEnv(_4647);

    /** 		if atom(envtmp) then*/
    _4649 = IS_ATOM(_envtmp_8529);
    if (_4649 == 0)
    {
        _4649 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _4649 = NOVALUE;
    }

    /** 			envtmp = getenv("TMP")*/
    DeRefi(_envtmp_8529);
    _envtmp_8529 = EGetEnv(_4650);
L2: 

    /** 		ifdef WINDOWS then			*/

    /** 			if atom(envtmp) then*/
    _4652 = IS_ATOM(_envtmp_8529);
    if (_4652 == 0)
    {
        _4652 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _4652 = NOVALUE;
    }

    /** 				envtmp = "C:\\temp\\"*/
    RefDS(_4653);
    DeRefi(_envtmp_8529);
    _envtmp_8529 = _4653;
L3: 

    /** 		temp_location = envtmp*/
    Ref(_envtmp_8529);
    DeRefDS(_temp_location_8520);
    _temp_location_8520 = _envtmp_8529;
    DeRefi(_envtmp_8529);
    _envtmp_8529 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** 		switch file_type(temp_location) do*/
    RefDS(_temp_location_8520);
    _4655 = _11file_type(_temp_location_8520);
    if (IS_SEQUENCE(_4655) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_4655)){
        if( (DBL_PTR(_4655)->dbl != (double) ((int) DBL_PTR(_4655)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (int) DBL_PTR(_4655)->dbl;
    }
    else {
        _0 = _4655;
    };
    DeRef(_4655);
    _4655 = NOVALUE;
    switch ( _0 ){ 

        /** 			case FILETYPE_FILE then*/
        case 1:

        /** 				temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_8520);
        _0 = _temp_location_8520;
        _temp_location_8520 = _11dirname(_temp_location_8520, 1);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** 			case FILETYPE_DIRECTORY then*/
        case 2:

        /** 				temp_location = temp_location*/
        RefDS(_temp_location_8520);
        DeRefDS(_temp_location_8520);
        _temp_location_8520 = _temp_location_8520;
        goto L6; // [104] 160

        /** 			case FILETYPE_NOT_FOUND then*/
        case 0:

        /** 				object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_8520);
        _0 = _tdir_8548;
        _tdir_8548 = _11dirname(_temp_location_8520, 1);
        DeRef(_0);

        /** 				if file_exists(tdir) then*/
        Ref(_tdir_8548);
        _4660 = _11file_exists(_tdir_8548);
        if (_4660 == 0) {
            DeRef(_4660);
            _4660 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_4660) && DBL_PTR(_4660)->dbl == 0.0){
                DeRef(_4660);
                _4660 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_4660);
            _4660 = NOVALUE;
        }
        DeRef(_4660);
        _4660 = NOVALUE;

        /** 					temp_location = tdir*/
        Ref(_tdir_8548);
        DeRefDS(_temp_location_8520);
        _temp_location_8520 = _tdir_8548;
        goto L8; // [133] 144
L7: 

        /** 					temp_location = "."*/
        RefDS(_3819);
        DeRefDS(_temp_location_8520);
        _temp_location_8520 = _3819;
L8: 
        DeRef(_tdir_8548);
        _tdir_8548 = NOVALUE;
        goto L6; // [146] 160

        /** 			case else*/
        default:
L5: 

        /** 				temp_location = "."*/
        RefDS(_3819);
        DeRefDS(_temp_location_8520);
        _temp_location_8520 = _3819;
    ;}L6: 
L4: 

    /** 	if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_8520)){
            _4661 = SEQ_PTR(_temp_location_8520)->length;
    }
    else {
        _4661 = 1;
    }
    _2 = (int)SEQ_PTR(_temp_location_8520);
    _4662 = (int)*(((s1_ptr)_2)->base + _4661);
    if (binary_op_a(EQUALS, _4662, 92)){
        _4662 = NOVALUE;
        goto L9; // [170] 181
    }
    _4662 = NOVALUE;

    /** 		temp_location &= SLASH*/
    Append(&_temp_location_8520, _temp_location_8520, 92);
L9: 

    /** 	if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_8522)){
            _4665 = SEQ_PTR(_temp_extn_8522)->length;
    }
    else {
        _4665 = 1;
    }
    if (_4665 == 0) {
        goto LA; // [186] 209
    }
    _2 = (int)SEQ_PTR(_temp_extn_8522);
    _4667 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4667)) {
        _4668 = (_4667 != 46);
    }
    else {
        _4668 = binary_op(NOTEQ, _4667, 46);
    }
    _4667 = NOVALUE;
    if (_4668 == 0) {
        DeRef(_4668);
        _4668 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_4668) && DBL_PTR(_4668)->dbl == 0.0){
            DeRef(_4668);
            _4668 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_4668);
        _4668 = NOVALUE;
    }
    DeRef(_4668);
    _4668 = NOVALUE;

    /** 		temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_8522, _temp_extn_8522, 46);
LA: 

    /** 	while 1 do*/
LB: 

    /** 		randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _4672 = good_rand() % ((unsigned)1000000) + 1;
    _4673 = _4672 - 1;
    _4672 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_temp_location_8520);
    *((int *)(_2+4)) = _temp_location_8520;
    RefDS(_temp_prefix_8521);
    *((int *)(_2+8)) = _temp_prefix_8521;
    *((int *)(_2+12)) = _4673;
    RefDS(_temp_extn_8522);
    *((int *)(_2+16)) = _temp_extn_8522;
    _4674 = MAKE_SEQ(_1);
    _4673 = NOVALUE;
    DeRefi(_randname_8525);
    _randname_8525 = EPrintf(-9999999, _4670, _4674);
    DeRefDS(_4674);
    _4674 = NOVALUE;

    /** 		if not file_exists( randname ) then*/
    RefDS(_randname_8525);
    _4676 = _11file_exists(_randname_8525);
    if (IS_ATOM_INT(_4676)) {
        if (_4676 != 0){
            DeRef(_4676);
            _4676 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_4676)->dbl != 0.0){
            DeRef(_4676);
            _4676 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_4676);
    _4676 = NOVALUE;

    /** 			exit*/
    goto LC; // [245] 253

    /** 	end while*/
    goto LB; // [250] 214
LC: 

    /** 	if reserve_temp then*/
    if (_reserve_temp_8524 == 0)
    {
        goto LD; // [255] 298
    }
    else{
    }

    /** 		if not file_exists(temp_location) then*/
    RefDS(_temp_location_8520);
    _4678 = _11file_exists(_temp_location_8520);
    if (IS_ATOM_INT(_4678)) {
        if (_4678 != 0){
            DeRef(_4678);
            _4678 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_4678)->dbl != 0.0){
            DeRef(_4678);
            _4678 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_4678);
    _4678 = NOVALUE;

    /** 			if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_8520);
    _4680 = _11create_directory(_temp_location_8520, 448, 1);
    if (binary_op_a(NOTEQ, _4680, 0)){
        DeRef(_4680);
        _4680 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_4680);
    _4680 = NOVALUE;

    /** 				return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_8520);
    DeRefDS(_temp_prefix_8521);
    DeRefDS(_temp_extn_8522);
    DeRefi(_randname_8525);
    return _5;
LF: 
LE: 

    /** 		io:write_file(randname, "")*/
    RefDS(_randname_8525);
    RefDS(_5);
    _4682 = _18write_file(_randname_8525, _5, 1);
LD: 

    /** 	return randname*/
    DeRefDS(_temp_location_8520);
    DeRefDS(_temp_prefix_8521);
    DeRefDS(_temp_extn_8522);
    DeRef(_4682);
    _4682 = NOVALUE;
    return _randname_8525;
    ;
}


int  __stdcall _11checksum(int _filename_8585, int _size_8586, int _usename_8587, int _return_text_8588)
{
    int _fn_8589 = NOVALUE;
    int _cs_8590 = NOVALUE;
    int _hits_8591 = NOVALUE;
    int _ix_8592 = NOVALUE;
    int _jx_8593 = NOVALUE;
    int _fx_8594 = NOVALUE;
    int _data_8595 = NOVALUE;
    int _nhit_8596 = NOVALUE;
    int _nmiss_8597 = NOVALUE;
    int _cs_text_8669 = NOVALUE;
    int _4742 = NOVALUE;
    int _4740 = NOVALUE;
    int _4739 = NOVALUE;
    int _4737 = NOVALUE;
    int _4735 = NOVALUE;
    int _4734 = NOVALUE;
    int _4733 = NOVALUE;
    int _4732 = NOVALUE;
    int _4731 = NOVALUE;
    int _4729 = NOVALUE;
    int _4727 = NOVALUE;
    int _4725 = NOVALUE;
    int _4724 = NOVALUE;
    int _4723 = NOVALUE;
    int _4722 = NOVALUE;
    int _4721 = NOVALUE;
    int _4720 = NOVALUE;
    int _4719 = NOVALUE;
    int _4717 = NOVALUE;
    int _4714 = NOVALUE;
    int _4712 = NOVALUE;
    int _4711 = NOVALUE;
    int _4710 = NOVALUE;
    int _4709 = NOVALUE;
    int _4708 = NOVALUE;
    int _4705 = NOVALUE;
    int _4704 = NOVALUE;
    int _4703 = NOVALUE;
    int _4702 = NOVALUE;
    int _4700 = NOVALUE;
    int _4697 = NOVALUE;
    int _4695 = NOVALUE;
    int _4691 = NOVALUE;
    int _4690 = NOVALUE;
    int _4689 = NOVALUE;
    int _4688 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_8586)) {
        _1 = (long)(DBL_PTR(_size_8586)->dbl);
        DeRefDS(_size_8586);
        _size_8586 = _1;
    }
    if (!IS_ATOM_INT(_usename_8587)) {
        _1 = (long)(DBL_PTR(_usename_8587)->dbl);
        DeRefDS(_usename_8587);
        _usename_8587 = _1;
    }
    if (!IS_ATOM_INT(_return_text_8588)) {
        _1 = (long)(DBL_PTR(_return_text_8588)->dbl);
        DeRefDS(_return_text_8588);
        _return_text_8588 = _1;
    }

    /** 	if size <= 0 then*/
    if (_size_8586 > 0)
    goto L1; // [11] 22

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_filename_8585);
    DeRef(_cs_8590);
    DeRef(_hits_8591);
    DeRef(_jx_8593);
    DeRef(_fx_8594);
    DeRefi(_data_8595);
    return _5;
L1: 

    /** 	fn = open(filename, "rb")*/
    _fn_8589 = EOpen(_filename_8585, _1309, 0);

    /** 	if fn = -1 then*/
    if (_fn_8589 != -1)
    goto L2; // [31] 42

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_filename_8585);
    DeRef(_cs_8590);
    DeRef(_hits_8591);
    DeRef(_jx_8593);
    DeRef(_fx_8594);
    DeRefi(_data_8595);
    return _5;
L2: 

    /** 	jx = file_length(filename)*/
    RefDS(_filename_8585);
    _0 = _jx_8593;
    _jx_8593 = _11file_length(_filename_8585);
    DeRef(_0);

    /** 	cs = repeat(jx, size)*/
    DeRef(_cs_8590);
    _cs_8590 = Repeat(_jx_8593, _size_8586);

    /** 	for i = 1 to size do*/
    _4688 = _size_8586;
    {
        int _i_8606;
        _i_8606 = 1;
L3: 
        if (_i_8606 > _4688){
            goto L4; // [59] 91
        }

        /** 		cs[i] = hash(i + size, cs[i])*/
        _4689 = _i_8606 + _size_8586;
        if ((long)((unsigned long)_4689 + (unsigned long)HIGH_BITS) >= 0) 
        _4689 = NewDouble((double)_4689);
        _2 = (int)SEQ_PTR(_cs_8590);
        _4690 = (int)*(((s1_ptr)_2)->base + _i_8606);
        _4691 = calc_hash(_4689, _4690);
        DeRef(_4689);
        _4689 = NOVALUE;
        _4690 = NOVALUE;
        _2 = (int)SEQ_PTR(_cs_8590);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _cs_8590 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8606);
        _1 = *(int *)_2;
        *(int *)_2 = _4691;
        if( _1 != _4691 ){
            DeRef(_1);
        }
        _4691 = NOVALUE;

        /** 	end for*/
        _i_8606 = _i_8606 + 1;
        goto L3; // [86] 66
L4: 
        ;
    }

    /** 	if usename != 0 then*/
    if (_usename_8587 == 0)
    goto L5; // [93] 214

    /** 		nhit = 0*/
    _nhit_8596 = 0;

    /** 		nmiss = 0*/
    _nmiss_8597 = 0;

    /** 		hits = {0,0}*/
    DeRef(_hits_8591);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _hits_8591 = MAKE_SEQ(_1);

    /** 		fx = hash(filename, stdhash:HSIEH32) -- Get a hash value for the whole name.*/
    DeRef(_fx_8594);
    _fx_8594 = calc_hash(_filename_8585, -5);

    /** 		while find(0, hits) do*/
L6: 
    _4695 = find_from(0, _hits_8591, 1);
    if (_4695 == 0)
    {
        _4695 = NOVALUE;
        goto L7; // [129] 213
    }
    else{
        _4695 = NOVALUE;
    }

    /** 			nhit += 1*/
    _nhit_8596 = _nhit_8596 + 1;

    /** 			if nhit > length(filename) then*/
    if (IS_SEQUENCE(_filename_8585)){
            _4697 = SEQ_PTR(_filename_8585)->length;
    }
    else {
        _4697 = 1;
    }
    if (_nhit_8596 <= _4697)
    goto L8; // [143] 159

    /** 				nhit = 1*/
    _nhit_8596 = 1;

    /** 				hits[1] = 1*/
    _2 = (int)SEQ_PTR(_hits_8591);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L8: 

    /** 			nmiss += 1*/
    _nmiss_8597 = _nmiss_8597 + 1;

    /** 			if nmiss > length(cs) then*/
    if (IS_SEQUENCE(_cs_8590)){
            _4700 = SEQ_PTR(_cs_8590)->length;
    }
    else {
        _4700 = 1;
    }
    if (_nmiss_8597 <= _4700)
    goto L9; // [170] 186

    /** 				nmiss = 1*/
    _nmiss_8597 = 1;

    /** 				hits[2] = 1*/
    _2 = (int)SEQ_PTR(_hits_8591);
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L9: 

    /** 			cs[nmiss] = hash(filename[nhit], xor_bits(fx, cs[nmiss]))*/
    _2 = (int)SEQ_PTR(_filename_8585);
    _4702 = (int)*(((s1_ptr)_2)->base + _nhit_8596);
    _2 = (int)SEQ_PTR(_cs_8590);
    _4703 = (int)*(((s1_ptr)_2)->base + _nmiss_8597);
    if (IS_ATOM_INT(_fx_8594) && IS_ATOM_INT(_4703)) {
        {unsigned long tu;
             tu = (unsigned long)_fx_8594 ^ (unsigned long)_4703;
             _4704 = MAKE_UINT(tu);
        }
    }
    else {
        _4704 = binary_op(XOR_BITS, _fx_8594, _4703);
    }
    _4703 = NOVALUE;
    _4705 = calc_hash(_4702, _4704);
    _4702 = NOVALUE;
    DeRef(_4704);
    _4704 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8597);
    _1 = *(int *)_2;
    *(int *)_2 = _4705;
    if( _1 != _4705 ){
        DeRef(_1);
    }
    _4705 = NOVALUE;

    /** 		end while -- repeat until every bucket and every character has been used.*/
    goto L6; // [210] 124
L7: 
L5: 

    /** 	hits = repeat(0, size)*/
    DeRef(_hits_8591);
    _hits_8591 = Repeat(0, _size_8586);

    /** 	if jx != 0 then*/
    if (binary_op_a(EQUALS, _jx_8593, 0)){
        goto LA; // [222] 458
    }

    /** 		data = repeat(0, remainder( hash(jx * jx / size , stdhash:HSIEH32), 8) + 7)*/
    if (IS_ATOM_INT(_jx_8593) && IS_ATOM_INT(_jx_8593)) {
        if (_jx_8593 == (short)_jx_8593 && _jx_8593 <= INT15 && _jx_8593 >= -INT15)
        _4708 = _jx_8593 * _jx_8593;
        else
        _4708 = NewDouble(_jx_8593 * (double)_jx_8593);
    }
    else {
        if (IS_ATOM_INT(_jx_8593)) {
            _4708 = NewDouble((double)_jx_8593 * DBL_PTR(_jx_8593)->dbl);
        }
        else {
            if (IS_ATOM_INT(_jx_8593)) {
                _4708 = NewDouble(DBL_PTR(_jx_8593)->dbl * (double)_jx_8593);
            }
            else
            _4708 = NewDouble(DBL_PTR(_jx_8593)->dbl * DBL_PTR(_jx_8593)->dbl);
        }
    }
    if (IS_ATOM_INT(_4708)) {
        _4709 = (_4708 % _size_8586) ? NewDouble((double)_4708 / _size_8586) : (_4708 / _size_8586);
    }
    else {
        _4709 = NewDouble(DBL_PTR(_4708)->dbl / (double)_size_8586);
    }
    DeRef(_4708);
    _4708 = NOVALUE;
    _4710 = calc_hash(_4709, -5);
    DeRef(_4709);
    _4709 = NOVALUE;
    if (IS_ATOM_INT(_4710)) {
        _4711 = (_4710 % 8);
    }
    else {
        temp_d.dbl = (double)8;
        _4711 = Dremainder(DBL_PTR(_4710), &temp_d);
    }
    DeRef(_4710);
    _4710 = NOVALUE;
    if (IS_ATOM_INT(_4711)) {
        _4712 = _4711 + 7;
    }
    else {
        _4712 = NewDouble(DBL_PTR(_4711)->dbl + (double)7);
    }
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRefi(_data_8595);
    _data_8595 = Repeat(0, _4712);
    DeRef(_4712);
    _4712 = NOVALUE;

    /** 		while data[1] != -1 with entry do*/
    goto LB; // [254] 316
LC: 
    _2 = (int)SEQ_PTR(_data_8595);
    _4714 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4714 == -1)
    goto LD; // [261] 349

    /** 			jx = hash(jx, data)*/
    _0 = _jx_8593;
    _jx_8593 = calc_hash(_jx_8593, _data_8595);
    DeRef(_0);

    /** 			ix = remainder(jx, size) + 1*/
    if (IS_ATOM_INT(_jx_8593)) {
        _4717 = (_jx_8593 % _size_8586);
    }
    else {
        temp_d.dbl = (double)_size_8586;
        _4717 = Dremainder(DBL_PTR(_jx_8593), &temp_d);
    }
    if (IS_ATOM_INT(_4717)) {
        _ix_8592 = _4717 + 1;
    }
    else
    { // coercing _ix_8592 to an integer 1
        _ix_8592 = 1+(long)(DBL_PTR(_4717)->dbl);
        if( !IS_ATOM_INT(_ix_8592) ){
            _ix_8592 = (object)DBL_PTR(_ix_8592)->dbl;
        }
    }
    DeRef(_4717);
    _4717 = NOVALUE;

    /** 			cs[ix] = xor_bits(cs[ix], hash(data, stdhash:HSIEH32))*/
    _2 = (int)SEQ_PTR(_cs_8590);
    _4719 = (int)*(((s1_ptr)_2)->base + _ix_8592);
    _4720 = calc_hash(_data_8595, -5);
    if (IS_ATOM_INT(_4719) && IS_ATOM_INT(_4720)) {
        {unsigned long tu;
             tu = (unsigned long)_4719 ^ (unsigned long)_4720;
             _4721 = MAKE_UINT(tu);
        }
    }
    else {
        _4721 = binary_op(XOR_BITS, _4719, _4720);
    }
    _4719 = NOVALUE;
    DeRef(_4720);
    _4720 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ix_8592);
    _1 = *(int *)_2;
    *(int *)_2 = _4721;
    if( _1 != _4721 ){
        DeRef(_1);
    }
    _4721 = NOVALUE;

    /** 			hits[ix] += 1*/
    _2 = (int)SEQ_PTR(_hits_8591);
    _4722 = (int)*(((s1_ptr)_2)->base + _ix_8592);
    if (IS_ATOM_INT(_4722)) {
        _4723 = _4722 + 1;
        if (_4723 > MAXINT){
            _4723 = NewDouble((double)_4723);
        }
    }
    else
    _4723 = binary_op(PLUS, 1, _4722);
    _4722 = NOVALUE;
    _2 = (int)SEQ_PTR(_hits_8591);
    _2 = (int)(((s1_ptr)_2)->base + _ix_8592);
    _1 = *(int *)_2;
    *(int *)_2 = _4723;
    if( _1 != _4723 ){
        DeRef(_1);
    }
    _4723 = NOVALUE;

    /** 		entry*/
LB: 

    /** 			for i = 1 to length(data) do*/
    if (IS_SEQUENCE(_data_8595)){
            _4724 = SEQ_PTR(_data_8595)->length;
    }
    else {
        _4724 = 1;
    }
    {
        int _i_8650;
        _i_8650 = 1;
LE: 
        if (_i_8650 > _4724){
            goto LF; // [321] 344
        }

        /** 				data[i] = getc(fn)*/
        if (_fn_8589 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_8589, EF_READ);
            last_r_file_no = _fn_8589;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4725 = getKBchar();
            }
            else
            _4725 = getc(last_r_file_ptr);
        }
        else
        _4725 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_data_8595);
        _2 = (int)(((s1_ptr)_2)->base + _i_8650);
        *(int *)_2 = _4725;
        if( _1 != _4725 ){
        }
        _4725 = NOVALUE;

        /** 			end for*/
        _i_8650 = _i_8650 + 1;
        goto LE; // [339] 328
LF: 
        ;
    }

    /** 		end while*/
    goto LC; // [346] 257
LD: 

    /** 		nhit = 0*/
    _nhit_8596 = 0;

    /** 		while nmiss with entry do*/
    goto L10; // [356] 445
L11: 
    if (_nmiss_8597 == 0)
    {
        goto L12; // [361] 457
    }
    else{
    }

    /** 			while 1 do*/
L13: 

    /** 				nhit += 1*/
    _nhit_8596 = _nhit_8596 + 1;

    /** 				if nhit > length(hits) then*/
    if (IS_SEQUENCE(_hits_8591)){
            _4727 = SEQ_PTR(_hits_8591)->length;
    }
    else {
        _4727 = 1;
    }
    if (_nhit_8596 <= _4727)
    goto L14; // [380] 390

    /** 					nhit = 1*/
    _nhit_8596 = 1;
L14: 

    /** 				if hits[nhit] != 0 then*/
    _2 = (int)SEQ_PTR(_hits_8591);
    _4729 = (int)*(((s1_ptr)_2)->base + _nhit_8596);
    if (binary_op_a(EQUALS, _4729, 0)){
        _4729 = NOVALUE;
        goto L13; // [396] 369
    }
    _4729 = NOVALUE;

    /** 					exit*/
    goto L15; // [402] 410

    /** 			end while*/
    goto L13; // [407] 369
L15: 

    /** 			cs[nmiss] = hash(cs[nmiss], cs[nhit])*/
    _2 = (int)SEQ_PTR(_cs_8590);
    _4731 = (int)*(((s1_ptr)_2)->base + _nmiss_8597);
    _2 = (int)SEQ_PTR(_cs_8590);
    _4732 = (int)*(((s1_ptr)_2)->base + _nhit_8596);
    _4733 = calc_hash(_4731, _4732);
    _4731 = NOVALUE;
    _4732 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8597);
    _1 = *(int *)_2;
    *(int *)_2 = _4733;
    if( _1 != _4733 ){
        DeRef(_1);
    }
    _4733 = NOVALUE;

    /** 			hits[nmiss] += 1*/
    _2 = (int)SEQ_PTR(_hits_8591);
    _4734 = (int)*(((s1_ptr)_2)->base + _nmiss_8597);
    if (IS_ATOM_INT(_4734)) {
        _4735 = _4734 + 1;
        if (_4735 > MAXINT){
            _4735 = NewDouble((double)_4735);
        }
    }
    else
    _4735 = binary_op(PLUS, 1, _4734);
    _4734 = NOVALUE;
    _2 = (int)SEQ_PTR(_hits_8591);
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8597);
    _1 = *(int *)_2;
    *(int *)_2 = _4735;
    if( _1 != _4735 ){
        DeRef(_1);
    }
    _4735 = NOVALUE;

    /** 		entry*/
L10: 

    /** 			nmiss = find(0, hits)	*/
    _nmiss_8597 = find_from(0, _hits_8591, 1);

    /** 		end while*/
    goto L11; // [454] 359
L12: 
LA: 

    /** 	close(fn)*/
    EClose(_fn_8589);

    /** 	if return_text then*/
    if (_return_text_8588 == 0)
    {
        goto L16; // [464] 535
    }
    else{
    }

    /** 		sequence cs_text = ""*/
    RefDS(_5);
    DeRef(_cs_text_8669);
    _cs_text_8669 = _5;

    /** 		for i = 1 to length(cs) do*/
    if (IS_SEQUENCE(_cs_8590)){
            _4737 = SEQ_PTR(_cs_8590)->length;
    }
    else {
        _4737 = 1;
    }
    {
        int _i_8671;
        _i_8671 = 1;
L17: 
        if (_i_8671 > _4737){
            goto L18; // [479] 524
        }

        /** 			cs_text &= text:format("[:08X]", cs[i])*/
        _2 = (int)SEQ_PTR(_cs_8590);
        _4739 = (int)*(((s1_ptr)_2)->base + _i_8671);
        RefDS(_4738);
        Ref(_4739);
        _4740 = _6format(_4738, _4739);
        _4739 = NOVALUE;
        if (IS_SEQUENCE(_cs_text_8669) && IS_ATOM(_4740)) {
            Ref(_4740);
            Append(&_cs_text_8669, _cs_text_8669, _4740);
        }
        else if (IS_ATOM(_cs_text_8669) && IS_SEQUENCE(_4740)) {
        }
        else {
            Concat((object_ptr)&_cs_text_8669, _cs_text_8669, _4740);
        }
        DeRef(_4740);
        _4740 = NOVALUE;

        /** 			if i != length(cs) then*/
        if (IS_SEQUENCE(_cs_8590)){
                _4742 = SEQ_PTR(_cs_8590)->length;
        }
        else {
            _4742 = 1;
        }
        if (_i_8671 == _4742)
        goto L19; // [506] 517

        /** 				cs_text &= ' '*/
        Append(&_cs_text_8669, _cs_text_8669, 32);
L19: 

        /** 		end for*/
        _i_8671 = _i_8671 + 1;
        goto L17; // [519] 486
L18: 
        ;
    }

    /** 		return cs_text*/
    DeRefDS(_filename_8585);
    DeRef(_cs_8590);
    DeRef(_hits_8591);
    DeRef(_jx_8593);
    DeRef(_fx_8594);
    DeRefi(_data_8595);
    _4714 = NOVALUE;
    return _cs_text_8669;
    DeRefDS(_cs_text_8669);
    _cs_text_8669 = NOVALUE;
    goto L1A; // [532] 542
L16: 

    /** 		return cs*/
    DeRefDS(_filename_8585);
    DeRef(_hits_8591);
    DeRef(_jx_8593);
    DeRef(_fx_8594);
    DeRefi(_data_8595);
    _4714 = NOVALUE;
    return _cs_8590;
L1A: 
    ;
}



// 0x0E94CDDC
