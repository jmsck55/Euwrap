// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _24sort(int _x_5112, int _order_5113)
{
    int _gap_5114 = NOVALUE;
    int _j_5115 = NOVALUE;
    int _first_5116 = NOVALUE;
    int _last_5117 = NOVALUE;
    int _tempi_5118 = NOVALUE;
    int _tempj_5119 = NOVALUE;
    int _2628 = NOVALUE;
    int _2624 = NOVALUE;
    int _2621 = NOVALUE;
    int _2617 = NOVALUE;
    int _2614 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_5113)) {
        _1 = (long)(DBL_PTR(_order_5113)->dbl);
        DeRefDS(_order_5113);
        _order_5113 = _1;
    }

    /** 	if order >= 0 then*/
    if (_order_5113 < 0)
    goto L1; // [7] 19

    /** 		order = -1*/
    _order_5113 = -1;
    goto L2; // [16] 25
L1: 

    /** 		order = 1*/
    _order_5113 = 1;
L2: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5112)){
            _last_5117 = SEQ_PTR(_x_5112)->length;
    }
    else {
        _last_5117 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5117 >= 0) {
        _2614 = _last_5117 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5117 / (double)10);
        _2614 = (long)temp_dbl;
    }
    _gap_5114 = _2614 + 1;
    _2614 = NOVALUE;

    /** 	while 1 do*/
L3: 

    /** 		first = gap + 1*/
    _first_5116 = _gap_5114 + 1;

    /** 		for i = first to last do*/
    _2617 = _last_5117;
    {
        int _i_5129;
        _i_5129 = _first_5116;
L4: 
        if (_i_5129 > _2617){
            goto L5; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5118);
        _2 = (int)SEQ_PTR(_x_5112);
        _tempi_5118 = (int)*(((s1_ptr)_2)->base + _i_5129);
        Ref(_tempi_5118);

        /** 			j = i - gap*/
        _j_5115 = _i_5129 - _gap_5114;

        /** 			while 1 do*/
L6: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5119);
        _2 = (int)SEQ_PTR(_x_5112);
        _tempj_5119 = (int)*(((s1_ptr)_2)->base + _j_5115);
        Ref(_tempj_5119);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_5118) && IS_ATOM_INT(_tempj_5119)){
            _2621 = (_tempi_5118 < _tempj_5119) ? -1 : (_tempi_5118 > _tempj_5119);
        }
        else{
            _2621 = compare(_tempi_5118, _tempj_5119);
        }
        if (_2621 == _order_5113)
        goto L7; // [92] 107

        /** 					j += gap*/
        _j_5115 = _j_5115 + _gap_5114;

        /** 					exit*/
        goto L8; // [104] 139
L7: 

        /** 				x[j+gap] = tempj*/
        _2624 = _j_5115 + _gap_5114;
        Ref(_tempj_5119);
        _2 = (int)SEQ_PTR(_x_5112);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5112 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2624);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5119;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5115 > _gap_5114)
        goto L9; // [119] 128

        /** 					exit*/
        goto L8; // [125] 139
L9: 

        /** 				j -= gap*/
        _j_5115 = _j_5115 - _gap_5114;

        /** 			end while*/
        goto L6; // [136] 80
L8: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5118);
        _2 = (int)SEQ_PTR(_x_5112);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5112 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5115);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5118;
        DeRef(_1);

        /** 		end for*/
        _i_5129 = _i_5129 + 1;
        goto L4; // [147] 63
L5: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5114 != 1)
    goto LA; // [154] 167

    /** 			return x*/
    DeRef(_tempi_5118);
    DeRef(_tempj_5119);
    DeRef(_2624);
    _2624 = NOVALUE;
    return _x_5112;
    goto L3; // [164] 45
LA: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5114 >= 0) {
        _2628 = _gap_5114 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5114 / (double)7);
        _2628 = (long)temp_dbl;
    }
    _gap_5114 = _2628 + 1;
    _2628 = NOVALUE;

    /** 	end while*/
    goto L3; // [180] 45
    ;
}


int  __stdcall _24custom_sort(int _custom_compare_5150, int _x_5151, int _data_5152, int _order_5153)
{
    int _gap_5154 = NOVALUE;
    int _j_5155 = NOVALUE;
    int _first_5156 = NOVALUE;
    int _last_5157 = NOVALUE;
    int _tempi_5158 = NOVALUE;
    int _tempj_5159 = NOVALUE;
    int _result_5160 = NOVALUE;
    int _args_5161 = NOVALUE;
    int _2656 = NOVALUE;
    int _2652 = NOVALUE;
    int _2649 = NOVALUE;
    int _2647 = NOVALUE;
    int _2646 = NOVALUE;
    int _2641 = NOVALUE;
    int _2638 = NOVALUE;
    int _2635 = NOVALUE;
    int _2634 = NOVALUE;
    int _2632 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_custom_compare_5150)) {
        _1 = (long)(DBL_PTR(_custom_compare_5150)->dbl);
        DeRefDS(_custom_compare_5150);
        _custom_compare_5150 = _1;
    }
    if (!IS_ATOM_INT(_order_5153)) {
        _1 = (long)(DBL_PTR(_order_5153)->dbl);
        DeRefDS(_order_5153);
        _order_5153 = _1;
    }

    /** 	sequence args = {0, 0}*/
    DeRef(_args_5161);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_5161 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/
    if (_order_5153 < 0)
    goto L1; // [15] 27

    /** 		order = -1*/
    _order_5153 = -1;
    goto L2; // [24] 33
L1: 

    /** 		order = 1*/
    _order_5153 = 1;
L2: 

    /** 	if atom(data) then*/
    _2632 = IS_ATOM(_data_5152);
    if (_2632 == 0)
    {
        _2632 = NOVALUE;
        goto L3; // [38] 50
    }
    else{
        _2632 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_5161) && IS_ATOM(_data_5152)) {
        Ref(_data_5152);
        Append(&_args_5161, _args_5161, _data_5152);
    }
    else if (IS_ATOM(_args_5161) && IS_SEQUENCE(_data_5152)) {
    }
    else {
        Concat((object_ptr)&_args_5161, _args_5161, _data_5152);
    }
    goto L4; // [47] 70
L3: 

    /** 	elsif length(data) then*/
    if (IS_SEQUENCE(_data_5152)){
            _2634 = SEQ_PTR(_data_5152)->length;
    }
    else {
        _2634 = 1;
    }
    if (_2634 == 0)
    {
        _2634 = NOVALUE;
        goto L5; // [55] 69
    }
    else{
        _2634 = NOVALUE;
    }

    /** 		args = append(args, data[1])*/
    _2 = (int)SEQ_PTR(_data_5152);
    _2635 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2635);
    Append(&_args_5161, _args_5161, _2635);
    _2635 = NOVALUE;
L5: 
L4: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5151)){
            _last_5157 = SEQ_PTR(_x_5151)->length;
    }
    else {
        _last_5157 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5157 >= 0) {
        _2638 = _last_5157 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5157 / (double)10);
        _2638 = (long)temp_dbl;
    }
    _gap_5154 = _2638 + 1;
    _2638 = NOVALUE;

    /** 	while 1 do*/
L6: 

    /** 		first = gap + 1*/
    _first_5156 = _gap_5154 + 1;

    /** 		for i = first to last do*/
    _2641 = _last_5157;
    {
        int _i_5179;
        _i_5179 = _first_5156;
L7: 
        if (_i_5179 > _2641){
            goto L8; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5158);
        _2 = (int)SEQ_PTR(_x_5151);
        _tempi_5158 = (int)*(((s1_ptr)_2)->base + _i_5179);
        Ref(_tempi_5158);

        /** 			args[1] = tempi*/
        Ref(_tempi_5158);
        _2 = (int)SEQ_PTR(_args_5161);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5158;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_5155 = _i_5179 - _gap_5154;

        /** 			while 1 do*/
L9: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5159);
        _2 = (int)SEQ_PTR(_x_5151);
        _tempj_5159 = (int)*(((s1_ptr)_2)->base + _j_5155);
        Ref(_tempj_5159);

        /** 				args[2] = tempj*/
        Ref(_tempj_5159);
        _2 = (int)SEQ_PTR(_args_5161);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5159;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_5161);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_5150].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                         );
                }
                break;
            case 1:
                Ref(*(int *)(_2+4));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                if (_00[_custom_compare_5150].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                break;
        }
        DeRef(_result_5160);
        _result_5160 = _1;

        /** 				if sequence(result) then*/
        _2646 = IS_SEQUENCE(_result_5160);
        if (_2646 == 0)
        {
            _2646 = NOVALUE;
            goto LA; // [154] 174
        }
        else{
            _2646 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_5160);
        _2647 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_2647);
        _2 = (int)SEQ_PTR(_args_5161);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _2647;
        if( _1 != _2647 ){
            DeRef(_1);
        }
        _2647 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_5160;
        _2 = (int)SEQ_PTR(_result_5160);
        _result_5160 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_5160);
        DeRef(_0);
LA: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_5160) && IS_ATOM_INT(0)){
            _2649 = (_result_5160 < 0) ? -1 : (_result_5160 > 0);
        }
        else{
            _2649 = compare(_result_5160, 0);
        }
        if (_2649 == _order_5153)
        goto LB; // [180] 195

        /** 					j += gap*/
        _j_5155 = _j_5155 + _gap_5154;

        /** 					exit*/
        goto LC; // [192] 227
LB: 

        /** 				x[j+gap] = tempj*/
        _2652 = _j_5155 + _gap_5154;
        Ref(_tempj_5159);
        _2 = (int)SEQ_PTR(_x_5151);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5151 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2652);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5159;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5155 > _gap_5154)
        goto LD; // [207] 216

        /** 					exit*/
        goto LC; // [213] 227
LD: 

        /** 				j -= gap*/
        _j_5155 = _j_5155 - _gap_5154;

        /** 			end while*/
        goto L9; // [224] 131
LC: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5158);
        _2 = (int)SEQ_PTR(_x_5151);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5151 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5155);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5158;
        DeRef(_1);

        /** 		end for*/
        _i_5179 = _i_5179 + 1;
        goto L7; // [235] 108
L8: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5154 != 1)
    goto LE; // [242] 255

    /** 			return x*/
    DeRef(_data_5152);
    DeRef(_tempi_5158);
    DeRef(_tempj_5159);
    DeRef(_result_5160);
    DeRef(_args_5161);
    DeRef(_2652);
    _2652 = NOVALUE;
    return _x_5151;
    goto L6; // [252] 90
LE: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5154 >= 0) {
        _2656 = _gap_5154 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5154 / (double)7);
        _2656 = (long)temp_dbl;
    }
    _gap_5154 = _2656 + 1;
    _2656 = NOVALUE;

    /** 	end while*/
    goto L6; // [268] 90
    ;
}


int _24column_compare(int _a_5205, int _b_5206, int _cols_5207)
{
    int _sign_5208 = NOVALUE;
    int _column_5209 = NOVALUE;
    int _2679 = NOVALUE;
    int _2677 = NOVALUE;
    int _2676 = NOVALUE;
    int _2675 = NOVALUE;
    int _2674 = NOVALUE;
    int _2673 = NOVALUE;
    int _2672 = NOVALUE;
    int _2670 = NOVALUE;
    int _2669 = NOVALUE;
    int _2668 = NOVALUE;
    int _2666 = NOVALUE;
    int _2664 = NOVALUE;
    int _2661 = NOVALUE;
    int _2659 = NOVALUE;
    int _2658 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_5207)){
            _2658 = SEQ_PTR(_cols_5207)->length;
    }
    else {
        _2658 = 1;
    }
    {
        int _i_5211;
        _i_5211 = 1;
L1: 
        if (_i_5211 > _2658){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_5207);
        _2659 = (int)*(((s1_ptr)_2)->base + _i_5211);
        if (binary_op_a(GREATEREQ, _2659, 0)){
            _2659 = NOVALUE;
            goto L3; // [19] 42
        }
        _2659 = NOVALUE;

        /** 			sign = -1*/
        _sign_5208 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5207);
        _2661 = (int)*(((s1_ptr)_2)->base + _i_5211);
        if (IS_ATOM_INT(_2661)) {
            if ((unsigned long)_2661 == 0xC0000000)
            _column_5209 = (int)NewDouble((double)-0xC0000000);
            else
            _column_5209 = - _2661;
        }
        else {
            _column_5209 = unary_op(UMINUS, _2661);
        }
        _2661 = NOVALUE;
        if (!IS_ATOM_INT(_column_5209)) {
            _1 = (long)(DBL_PTR(_column_5209)->dbl);
            DeRefDS(_column_5209);
            _column_5209 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_5208 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5207);
        _column_5209 = (int)*(((s1_ptr)_2)->base + _i_5211);
        if (!IS_ATOM_INT(_column_5209)){
            _column_5209 = (long)DBL_PTR(_column_5209)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_5205)){
                _2664 = SEQ_PTR(_a_5205)->length;
        }
        else {
            _2664 = 1;
        }
        if (_column_5209 > _2664)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5206)){
                _2666 = SEQ_PTR(_b_5206)->length;
        }
        else {
            _2666 = 1;
        }
        if (_column_5209 > _2666)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_5205);
        _2668 = (int)*(((s1_ptr)_2)->base + _column_5209);
        _2 = (int)SEQ_PTR(_b_5206);
        _2669 = (int)*(((s1_ptr)_2)->base + _column_5209);
        if (_2668 == _2669)
        _2670 = 1;
        else if (IS_ATOM_INT(_2668) && IS_ATOM_INT(_2669))
        _2670 = 0;
        else
        _2670 = (compare(_2668, _2669) == 0);
        _2668 = NOVALUE;
        _2669 = NOVALUE;
        if (_2670 != 0)
        goto L7; // [90] 169
        _2670 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_5205);
        _2672 = (int)*(((s1_ptr)_2)->base + _column_5209);
        _2 = (int)SEQ_PTR(_b_5206);
        _2673 = (int)*(((s1_ptr)_2)->base + _column_5209);
        if (IS_ATOM_INT(_2672) && IS_ATOM_INT(_2673)){
            _2674 = (_2672 < _2673) ? -1 : (_2672 > _2673);
        }
        else{
            _2674 = compare(_2672, _2673);
        }
        _2672 = NOVALUE;
        _2673 = NOVALUE;
        if (_sign_5208 == (short)_sign_5208)
        _2675 = _sign_5208 * _2674;
        else
        _2675 = NewDouble(_sign_5208 * (double)_2674);
        _2674 = NOVALUE;
        DeRef(_a_5205);
        DeRef(_b_5206);
        DeRef(_cols_5207);
        return _2675;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_5208 == (short)_sign_5208)
        _2676 = _sign_5208 * -1;
        else
        _2676 = NewDouble(_sign_5208 * (double)-1);
        DeRef(_a_5205);
        DeRef(_b_5206);
        DeRef(_cols_5207);
        DeRef(_2675);
        _2675 = NOVALUE;
        return _2676;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5206)){
                _2677 = SEQ_PTR(_b_5206)->length;
        }
        else {
            _2677 = 1;
        }
        if (_column_5209 > _2677)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _2679 = _sign_5208 * 1;
        DeRef(_a_5205);
        DeRef(_b_5206);
        DeRef(_cols_5207);
        DeRef(_2675);
        _2675 = NOVALUE;
        DeRef(_2676);
        _2676 = NOVALUE;
        return _2679;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_5205);
        DeRef(_b_5206);
        DeRef(_cols_5207);
        DeRef(_2675);
        _2675 = NOVALUE;
        DeRef(_2676);
        _2676 = NOVALUE;
        DeRef(_2679);
        _2679 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_5211 = _i_5211 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_5205);
    DeRef(_b_5206);
    DeRef(_cols_5207);
    DeRef(_2675);
    _2675 = NOVALUE;
    DeRef(_2676);
    _2676 = NOVALUE;
    DeRef(_2679);
    _2679 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _24sort_columns(int _x_5245, int _column_list_5246)
{
    int _2683 = NOVALUE;
    int _2682 = NOVALUE;
    int _2681 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return custom_sort(routine_id("column_compare"), x, {column_list})*/
    _2681 = CRoutineId(275, 24, _2680);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_column_list_5246);
    *((int *)(_2+4)) = _column_list_5246;
    _2682 = MAKE_SEQ(_1);
    RefDS(_x_5245);
    _2683 = _24custom_sort(_2681, _x_5245, _2682, 1);
    _2681 = NOVALUE;
    _2682 = NOVALUE;
    DeRefDS(_x_5245);
    DeRefDS(_column_list_5246);
    return _2683;
    ;
}


int  __stdcall _24merge(int _a_5253, int _b_5254, int _compfunc_5255, int _userdata_5256)
{
    int _al_5257 = NOVALUE;
    int _bl_5258 = NOVALUE;
    int _n_5259 = NOVALUE;
    int _r_5260 = NOVALUE;
    int _s_5261 = NOVALUE;
    int _2727 = NOVALUE;
    int _2726 = NOVALUE;
    int _2725 = NOVALUE;
    int _2723 = NOVALUE;
    int _2722 = NOVALUE;
    int _2721 = NOVALUE;
    int _2720 = NOVALUE;
    int _2718 = NOVALUE;
    int _2715 = NOVALUE;
    int _2713 = NOVALUE;
    int _2710 = NOVALUE;
    int _2709 = NOVALUE;
    int _2708 = NOVALUE;
    int _2707 = NOVALUE;
    int _2706 = NOVALUE;
    int _2705 = NOVALUE;
    int _2704 = NOVALUE;
    int _2701 = NOVALUE;
    int _2699 = NOVALUE;
    int _2696 = NOVALUE;
    int _2695 = NOVALUE;
    int _2694 = NOVALUE;
    int _2693 = NOVALUE;
    int _2692 = NOVALUE;
    int _2691 = NOVALUE;
    int _2690 = NOVALUE;
    int _2689 = NOVALUE;
    int _2686 = NOVALUE;
    int _2685 = NOVALUE;
    int _2684 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_compfunc_5255)) {
        _1 = (long)(DBL_PTR(_compfunc_5255)->dbl);
        DeRefDS(_compfunc_5255);
        _compfunc_5255 = _1;
    }

    /** 	al = 1*/
    _al_5257 = 1;

    /** 	bl = 1*/
    _bl_5258 = 1;

    /** 	n = 1*/
    _n_5259 = 1;

    /** 	s = repeat(0, length(a) + length(b))*/
    if (IS_SEQUENCE(_a_5253)){
            _2684 = SEQ_PTR(_a_5253)->length;
    }
    else {
        _2684 = 1;
    }
    if (IS_SEQUENCE(_b_5254)){
            _2685 = SEQ_PTR(_b_5254)->length;
    }
    else {
        _2685 = 1;
    }
    _2686 = _2684 + _2685;
    _2684 = NOVALUE;
    _2685 = NOVALUE;
    DeRef(_s_5261);
    _s_5261 = Repeat(0, _2686);
    _2686 = NOVALUE;

    /** 	if compfunc >= 0 then*/
    if (_compfunc_5255 < 0)
    goto L1; // [40] 149

    /** 		while al <= length(a) and bl <= length(b) do*/
L2: 
    if (IS_SEQUENCE(_a_5253)){
            _2689 = SEQ_PTR(_a_5253)->length;
    }
    else {
        _2689 = 1;
    }
    _2690 = (_al_5257 <= _2689);
    _2689 = NOVALUE;
    if (_2690 == 0) {
        goto L3; // [56] 244
    }
    if (IS_SEQUENCE(_b_5254)){
            _2692 = SEQ_PTR(_b_5254)->length;
    }
    else {
        _2692 = 1;
    }
    _2693 = (_bl_5258 <= _2692);
    _2692 = NOVALUE;
    if (_2693 == 0)
    {
        DeRef(_2693);
        _2693 = NOVALUE;
        goto L3; // [68] 244
    }
    else{
        DeRef(_2693);
        _2693 = NOVALUE;
    }

    /** 			r = call_func(compfunc,{a[al], b[bl], userdata})*/
    _2 = (int)SEQ_PTR(_a_5253);
    _2694 = (int)*(((s1_ptr)_2)->base + _al_5257);
    _2 = (int)SEQ_PTR(_b_5254);
    _2695 = (int)*(((s1_ptr)_2)->base + _bl_5258);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_2694);
    *((int *)(_2+4)) = _2694;
    Ref(_2695);
    *((int *)(_2+8)) = _2695;
    Ref(_userdata_5256);
    *((int *)(_2+12)) = _userdata_5256;
    _2696 = MAKE_SEQ(_1);
    _2695 = NOVALUE;
    _2694 = NOVALUE;
    _1 = (int)SEQ_PTR(_2696);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_compfunc_5255].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    if (_00[_compfunc_5255].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12)
                             );
    }
    _r_5260 = _1;
    DeRefDS(_2696);
    _2696 = NOVALUE;
    if (!IS_ATOM_INT(_r_5260)) {
        _1 = (long)(DBL_PTR(_r_5260)->dbl);
        DeRefDS(_r_5260);
        _r_5260 = _1;
    }

    /** 			if r <= 0 then*/
    if (_r_5260 > 0)
    goto L4; // [95] 118

    /** 				s[n] = a[al]*/
    _2 = (int)SEQ_PTR(_a_5253);
    _2699 = (int)*(((s1_ptr)_2)->base + _al_5257);
    Ref(_2699);
    _2 = (int)SEQ_PTR(_s_5261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5259);
    _1 = *(int *)_2;
    *(int *)_2 = _2699;
    if( _1 != _2699 ){
        DeRef(_1);
    }
    _2699 = NOVALUE;

    /** 				al += 1*/
    _al_5257 = _al_5257 + 1;
    goto L5; // [115] 135
L4: 

    /** 				s[n] = b[bl]*/
    _2 = (int)SEQ_PTR(_b_5254);
    _2701 = (int)*(((s1_ptr)_2)->base + _bl_5258);
    Ref(_2701);
    _2 = (int)SEQ_PTR(_s_5261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5259);
    _1 = *(int *)_2;
    *(int *)_2 = _2701;
    if( _1 != _2701 ){
        DeRef(_1);
    }
    _2701 = NOVALUE;

    /** 				bl += 1*/
    _bl_5258 = _bl_5258 + 1;
L5: 

    /** 			n += 1*/
    _n_5259 = _n_5259 + 1;

    /** 		end while*/
    goto L2; // [143] 49
    goto L3; // [146] 244
L1: 

    /** 		while al <= length(a) and bl <= length(b) do*/
L6: 
    if (IS_SEQUENCE(_a_5253)){
            _2704 = SEQ_PTR(_a_5253)->length;
    }
    else {
        _2704 = 1;
    }
    _2705 = (_al_5257 <= _2704);
    _2704 = NOVALUE;
    if (_2705 == 0) {
        goto L7; // [161] 243
    }
    if (IS_SEQUENCE(_b_5254)){
            _2707 = SEQ_PTR(_b_5254)->length;
    }
    else {
        _2707 = 1;
    }
    _2708 = (_bl_5258 <= _2707);
    _2707 = NOVALUE;
    if (_2708 == 0)
    {
        DeRef(_2708);
        _2708 = NOVALUE;
        goto L7; // [173] 243
    }
    else{
        DeRef(_2708);
        _2708 = NOVALUE;
    }

    /** 			r = compare(a[al], b[bl])*/
    _2 = (int)SEQ_PTR(_a_5253);
    _2709 = (int)*(((s1_ptr)_2)->base + _al_5257);
    _2 = (int)SEQ_PTR(_b_5254);
    _2710 = (int)*(((s1_ptr)_2)->base + _bl_5258);
    if (IS_ATOM_INT(_2709) && IS_ATOM_INT(_2710)){
        _r_5260 = (_2709 < _2710) ? -1 : (_2709 > _2710);
    }
    else{
        _r_5260 = compare(_2709, _2710);
    }
    _2709 = NOVALUE;
    _2710 = NOVALUE;

    /** 			if r <= 0 then*/
    if (_r_5260 > 0)
    goto L8; // [192] 215

    /** 				s[n] = a[al]*/
    _2 = (int)SEQ_PTR(_a_5253);
    _2713 = (int)*(((s1_ptr)_2)->base + _al_5257);
    Ref(_2713);
    _2 = (int)SEQ_PTR(_s_5261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5259);
    _1 = *(int *)_2;
    *(int *)_2 = _2713;
    if( _1 != _2713 ){
        DeRef(_1);
    }
    _2713 = NOVALUE;

    /** 				al += 1*/
    _al_5257 = _al_5257 + 1;
    goto L9; // [212] 232
L8: 

    /** 				s[n] = b[bl]*/
    _2 = (int)SEQ_PTR(_b_5254);
    _2715 = (int)*(((s1_ptr)_2)->base + _bl_5258);
    Ref(_2715);
    _2 = (int)SEQ_PTR(_s_5261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5259);
    _1 = *(int *)_2;
    *(int *)_2 = _2715;
    if( _1 != _2715 ){
        DeRef(_1);
    }
    _2715 = NOVALUE;

    /** 				bl += 1*/
    _bl_5258 = _bl_5258 + 1;
L9: 

    /** 			n += 1*/
    _n_5259 = _n_5259 + 1;

    /** 		end while*/
    goto L6; // [240] 154
L7: 
L3: 

    /** 	if al > length(a) then*/
    if (IS_SEQUENCE(_a_5253)){
            _2718 = SEQ_PTR(_a_5253)->length;
    }
    else {
        _2718 = 1;
    }
    if (_al_5257 <= _2718)
    goto LA; // [249] 274

    /** 		s[n .. $] = b[bl .. $]*/
    if (IS_SEQUENCE(_s_5261)){
            _2720 = SEQ_PTR(_s_5261)->length;
    }
    else {
        _2720 = 1;
    }
    if (IS_SEQUENCE(_b_5254)){
            _2721 = SEQ_PTR(_b_5254)->length;
    }
    else {
        _2721 = 1;
    }
    rhs_slice_target = (object_ptr)&_2722;
    RHS_Slice(_b_5254, _bl_5258, _2721);
    assign_slice_seq = (s1_ptr *)&_s_5261;
    AssignSlice(_n_5259, _2720, _2722);
    _2720 = NOVALUE;
    DeRefDS(_2722);
    _2722 = NOVALUE;
    goto LB; // [271] 303
LA: 

    /** 	elsif bl > length(b) then*/
    if (IS_SEQUENCE(_b_5254)){
            _2723 = SEQ_PTR(_b_5254)->length;
    }
    else {
        _2723 = 1;
    }
    if (_bl_5258 <= _2723)
    goto LC; // [279] 302

    /** 		s[n .. $] = a[al .. $]*/
    if (IS_SEQUENCE(_s_5261)){
            _2725 = SEQ_PTR(_s_5261)->length;
    }
    else {
        _2725 = 1;
    }
    if (IS_SEQUENCE(_a_5253)){
            _2726 = SEQ_PTR(_a_5253)->length;
    }
    else {
        _2726 = 1;
    }
    rhs_slice_target = (object_ptr)&_2727;
    RHS_Slice(_a_5253, _al_5257, _2726);
    assign_slice_seq = (s1_ptr *)&_s_5261;
    AssignSlice(_n_5259, _2725, _2727);
    _2725 = NOVALUE;
    DeRefDS(_2727);
    _2727 = NOVALUE;
LC: 
LB: 

    /** 	return s*/
    DeRefDS(_a_5253);
    DeRefDS(_b_5254);
    DeRef(_userdata_5256);
    DeRef(_2690);
    _2690 = NOVALUE;
    DeRef(_2705);
    _2705 = NOVALUE;
    return _s_5261;
    ;
}


int  __stdcall _24insertion_sort(int _s_5318, int _e_5319, int _compfunc_5320, int _userdata_5321)
{
    int _key_5322 = NOVALUE;
    int _a_5323 = NOVALUE;
    int _2771 = NOVALUE;
    int _2770 = NOVALUE;
    int _2769 = NOVALUE;
    int _2768 = NOVALUE;
    int _2767 = NOVALUE;
    int _2766 = NOVALUE;
    int _2762 = NOVALUE;
    int _2761 = NOVALUE;
    int _2760 = NOVALUE;
    int _2759 = NOVALUE;
    int _2757 = NOVALUE;
    int _2756 = NOVALUE;
    int _2755 = NOVALUE;
    int _2754 = NOVALUE;
    int _2753 = NOVALUE;
    int _2752 = NOVALUE;
    int _2751 = NOVALUE;
    int _2747 = NOVALUE;
    int _2746 = NOVALUE;
    int _2745 = NOVALUE;
    int _2742 = NOVALUE;
    int _2740 = NOVALUE;
    int _2739 = NOVALUE;
    int _2738 = NOVALUE;
    int _2737 = NOVALUE;
    int _2736 = NOVALUE;
    int _2735 = NOVALUE;
    int _2734 = NOVALUE;
    int _2733 = NOVALUE;
    int _2732 = NOVALUE;
    int _2730 = NOVALUE;
    int _2728 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_compfunc_5320)) {
        _1 = (long)(DBL_PTR(_compfunc_5320)->dbl);
        DeRefDS(_compfunc_5320);
        _compfunc_5320 = _1;
    }

    /** 	if atom(e) then*/
    _2728 = IS_ATOM(_e_5319);
    if (_2728 == 0)
    {
        _2728 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _2728 = NOVALUE;
    }

    /** 		s &= e*/
    if (IS_SEQUENCE(_s_5318) && IS_ATOM(_e_5319)) {
        Ref(_e_5319);
        Append(&_s_5318, _s_5318, _e_5319);
    }
    else if (IS_ATOM(_s_5318) && IS_SEQUENCE(_e_5319)) {
    }
    else {
        Concat((object_ptr)&_s_5318, _s_5318, _e_5319);
    }
    goto L2; // [19] 78
L1: 

    /** 	elsif length(e) > 1 then*/
    if (IS_SEQUENCE(_e_5319)){
            _2730 = SEQ_PTR(_e_5319)->length;
    }
    else {
        _2730 = 1;
    }
    if (_2730 <= 1)
    goto L3; // [27] 77

    /** 		return merge(insertion_sort(s,,compfunc, userdata), insertion_sort(e,,compfunc, userdata), compfunc, userdata)*/
    RefDS(_s_5318);
    DeRef(_2732);
    _2732 = _s_5318;
    DeRef(_2733);
    _2733 = _compfunc_5320;
    Ref(_userdata_5321);
    DeRef(_2734);
    _2734 = _userdata_5321;
    RefDS(_5);
    _2735 = _24insertion_sort(_2732, _5, _2733, _2734);
    _2732 = NOVALUE;
    _2733 = NOVALUE;
    _2734 = NOVALUE;
    Ref(_e_5319);
    DeRef(_2736);
    _2736 = _e_5319;
    DeRef(_2737);
    _2737 = _compfunc_5320;
    Ref(_userdata_5321);
    DeRef(_2738);
    _2738 = _userdata_5321;
    RefDS(_5);
    _2739 = _24insertion_sort(_2736, _5, _2737, _2738);
    _2736 = NOVALUE;
    _2737 = NOVALUE;
    _2738 = NOVALUE;
    Ref(_userdata_5321);
    _2740 = _24merge(_2735, _2739, _compfunc_5320, _userdata_5321);
    _2735 = NOVALUE;
    _2739 = NOVALUE;
    DeRefDS(_s_5318);
    DeRef(_e_5319);
    DeRef(_userdata_5321);
    DeRef(_key_5322);
    return _2740;
L3: 
L2: 

    /** 	if compfunc = -1 then*/
    if (_compfunc_5320 != -1)
    goto L4; // [80] 225

    /** 		for j = 2 to length(s) label "outer" do*/
    if (IS_SEQUENCE(_s_5318)){
            _2742 = SEQ_PTR(_s_5318)->length;
    }
    else {
        _2742 = 1;
    }
    {
        int _j_5342;
        _j_5342 = 2;
L5: 
        if (_j_5342 > _2742){
            goto L6; // [89] 222
        }

        /** 			key = s[j]*/
        DeRef(_key_5322);
        _2 = (int)SEQ_PTR(_s_5318);
        _key_5322 = (int)*(((s1_ptr)_2)->base + _j_5342);
        Ref(_key_5322);

        /** 			for i = j - 1 to 1 by -1 do*/
        _2745 = _j_5342 - 1;
        {
            int _i_5347;
            _i_5347 = _2745;
L7: 
            if (_i_5347 < 1){
                goto L8; // [108] 187
            }

            /** 				if compare(s[i], key) <= 0 then*/
            _2 = (int)SEQ_PTR(_s_5318);
            _2746 = (int)*(((s1_ptr)_2)->base + _i_5347);
            if (IS_ATOM_INT(_2746) && IS_ATOM_INT(_key_5322)){
                _2747 = (_2746 < _key_5322) ? -1 : (_2746 > _key_5322);
            }
            else{
                _2747 = compare(_2746, _key_5322);
            }
            _2746 = NOVALUE;
            if (_2747 > 0)
            goto L9; // [125] 173

            /** 					a = i+1*/
            _a_5323 = _i_5347 + 1;

            /** 					if a != j then*/
            if (_a_5323 == _j_5342)
            goto LA; // [137] 217

            /** 						s[a+1 .. j] = s[a .. j-1]*/
            _2751 = _a_5323 + 1;
            _2752 = _j_5342 - 1;
            rhs_slice_target = (object_ptr)&_2753;
            RHS_Slice(_s_5318, _a_5323, _2752);
            assign_slice_seq = (s1_ptr *)&_s_5318;
            AssignSlice(_2751, _j_5342, _2753);
            _2751 = NOVALUE;
            DeRefDS(_2753);
            _2753 = NOVALUE;

            /** 						s[a] = key*/
            Ref(_key_5322);
            _2 = (int)SEQ_PTR(_s_5318);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_5318 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _a_5323);
            _1 = *(int *)_2;
            *(int *)_2 = _key_5322;
            DeRef(_1);

            /** 					continue "outer"*/
            goto LA; // [170] 217
L9: 

            /** 				a = i*/
            _a_5323 = _i_5347;

            /** 			end for*/
            _i_5347 = _i_5347 + -1;
            goto L7; // [182] 115
L8: 
            ;
        }

        /** 			s[a+1 .. j] = s[a .. j-1]*/
        _2754 = _a_5323 + 1;
        if (_2754 > MAXINT){
            _2754 = NewDouble((double)_2754);
        }
        _2755 = _j_5342 - 1;
        rhs_slice_target = (object_ptr)&_2756;
        RHS_Slice(_s_5318, _a_5323, _2755);
        assign_slice_seq = (s1_ptr *)&_s_5318;
        AssignSlice(_2754, _j_5342, _2756);
        DeRef(_2754);
        _2754 = NOVALUE;
        DeRefDS(_2756);
        _2756 = NOVALUE;

        /** 			s[a] = key*/
        Ref(_key_5322);
        _2 = (int)SEQ_PTR(_s_5318);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_5318 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5323);
        _1 = *(int *)_2;
        *(int *)_2 = _key_5322;
        DeRef(_1);

        /** 		end for*/
LA: 
        _j_5342 = _j_5342 + 1;
        goto L5; // [217] 96
L6: 
        ;
    }
    goto LB; // [222] 370
L4: 

    /** 		for j = 2 to length(s) label "outer" do*/
    if (IS_SEQUENCE(_s_5318)){
            _2757 = SEQ_PTR(_s_5318)->length;
    }
    else {
        _2757 = 1;
    }
    {
        int _j_5364;
        _j_5364 = 2;
LC: 
        if (_j_5364 > _2757){
            goto LD; // [230] 369
        }

        /** 			key = s[j]*/
        DeRef(_key_5322);
        _2 = (int)SEQ_PTR(_s_5318);
        _key_5322 = (int)*(((s1_ptr)_2)->base + _j_5364);
        Ref(_key_5322);

        /** 			for i = j - 1 to 1 by -1 do*/
        _2759 = _j_5364 - 1;
        {
            int _i_5368;
            _i_5368 = _2759;
LE: 
            if (_i_5368 < 1){
                goto LF; // [249] 334
            }

            /** 				if call_func(compfunc,{s[i], key, userdata}) <= 0 then*/
            _2 = (int)SEQ_PTR(_s_5318);
            _2760 = (int)*(((s1_ptr)_2)->base + _i_5368);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_2760);
            *((int *)(_2+4)) = _2760;
            Ref(_key_5322);
            *((int *)(_2+8)) = _key_5322;
            Ref(_userdata_5321);
            *((int *)(_2+12)) = _userdata_5321;
            _2761 = MAKE_SEQ(_1);
            _2760 = NOVALUE;
            _1 = (int)SEQ_PTR(_2761);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_compfunc_5320].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_compfunc_5320].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            DeRef(_2762);
            _2762 = _1;
            DeRefDS(_2761);
            _2761 = NOVALUE;
            if (binary_op_a(GREATER, _2762, 0)){
                DeRef(_2762);
                _2762 = NOVALUE;
                goto L10; // [272] 320
            }
            DeRef(_2762);
            _2762 = NOVALUE;

            /** 					a = i+1*/
            _a_5323 = _i_5368 + 1;

            /** 					if a != j then*/
            if (_a_5323 == _j_5364)
            goto L11; // [284] 364

            /** 						s[a+1 .. j] = s[a .. j-1]*/
            _2766 = _a_5323 + 1;
            _2767 = _j_5364 - 1;
            rhs_slice_target = (object_ptr)&_2768;
            RHS_Slice(_s_5318, _a_5323, _2767);
            assign_slice_seq = (s1_ptr *)&_s_5318;
            AssignSlice(_2766, _j_5364, _2768);
            _2766 = NOVALUE;
            DeRefDS(_2768);
            _2768 = NOVALUE;

            /** 						s[a] = key*/
            Ref(_key_5322);
            _2 = (int)SEQ_PTR(_s_5318);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_5318 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _a_5323);
            _1 = *(int *)_2;
            *(int *)_2 = _key_5322;
            DeRef(_1);

            /** 					continue "outer"*/
            goto L11; // [317] 364
L10: 

            /** 				a = i*/
            _a_5323 = _i_5368;

            /** 			end for*/
            _i_5368 = _i_5368 + -1;
            goto LE; // [329] 256
LF: 
            ;
        }

        /** 			s[a+1 .. j] = s[a .. j-1]*/
        _2769 = _a_5323 + 1;
        if (_2769 > MAXINT){
            _2769 = NewDouble((double)_2769);
        }
        _2770 = _j_5364 - 1;
        rhs_slice_target = (object_ptr)&_2771;
        RHS_Slice(_s_5318, _a_5323, _2770);
        assign_slice_seq = (s1_ptr *)&_s_5318;
        AssignSlice(_2769, _j_5364, _2771);
        DeRef(_2769);
        _2769 = NOVALUE;
        DeRefDS(_2771);
        _2771 = NOVALUE;

        /** 			s[a] = key*/
        Ref(_key_5322);
        _2 = (int)SEQ_PTR(_s_5318);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_5318 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5323);
        _1 = *(int *)_2;
        *(int *)_2 = _key_5322;
        DeRef(_1);

        /** 		end for*/
L11: 
        _j_5364 = _j_5364 + 1;
        goto LC; // [364] 237
LD: 
        ;
    }
LB: 

    /** 	return s*/
    DeRef(_e_5319);
    DeRef(_userdata_5321);
    DeRef(_key_5322);
    DeRef(_2745);
    _2745 = NOVALUE;
    DeRef(_2759);
    _2759 = NOVALUE;
    DeRef(_2740);
    _2740 = NOVALUE;
    DeRef(_2752);
    _2752 = NOVALUE;
    DeRef(_2755);
    _2755 = NOVALUE;
    DeRef(_2767);
    _2767 = NOVALUE;
    DeRef(_2770);
    _2770 = NOVALUE;
    return _s_5318;
    ;
}



// 0xB7F34E4B
