// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _42lcid(int _x_20093)
{
    int _11294 = NOVALUE;
    int _11293 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return find(x, lcid_hex) != 0*/
    _11293 = find_from(_x_20093, _42lcid_hex_19673, 1);
    _11294 = (_11293 != 0);
    _11293 = NOVALUE;
    DeRef(_x_20093);
    return _11294;
    ;
}


int  __stdcall _42get_lcid(int _name_20098)
{
    int _i_20099 = NOVALUE;
    int _11298 = NOVALUE;
    int _0, _1, _2;
    

    /** 		integer i = find(name, lcid_string)*/
    _i_20099 = find_from(_name_20098, _42lcid_string_19881, 1);

    /** 		if not i then*/
    if (_i_20099 != 0)
    goto L1; // [14] 25

    /** 			i = length(lcid_hex) -- get LOCALE_INVARIANT/C locale*/
    _i_20099 = 208;
L1: 

    /** 		return lcid_hex[i]*/
    _2 = (int)SEQ_PTR(_42lcid_hex_19673);
    _11298 = (int)*(((s1_ptr)_2)->base + _i_20099);
    DeRefDS(_name_20098);
    return _11298;
    ;
}



// 0xFEBBA276
