// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _23binop_ok(int _a_5392, int _b_5393)
{
    int _2781 = NOVALUE;
    int _2780 = NOVALUE;
    int _2779 = NOVALUE;
    int _2778 = NOVALUE;
    int _2776 = NOVALUE;
    int _2775 = NOVALUE;
    int _2774 = NOVALUE;
    int _2772 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) or atom(b) then*/
    _2772 = IS_ATOM(_a_5392);
    if (_2772 != 0) {
        goto L1; // [6] 18
    }
    _2774 = IS_ATOM(_b_5393);
    if (_2774 == 0)
    {
        _2774 = NOVALUE;
        goto L2; // [14] 25
    }
    else{
        _2774 = NOVALUE;
    }
L1: 

    /** 		return 1*/
    DeRef(_a_5392);
    DeRef(_b_5393);
    return 1;
L2: 

    /** 	if length(a) != length(b) then*/
    if (IS_SEQUENCE(_a_5392)){
            _2775 = SEQ_PTR(_a_5392)->length;
    }
    else {
        _2775 = 1;
    }
    if (IS_SEQUENCE(_b_5393)){
            _2776 = SEQ_PTR(_b_5393)->length;
    }
    else {
        _2776 = 1;
    }
    if (_2775 == _2776)
    goto L3; // [33] 44

    /** 		return 0*/
    DeRef(_a_5392);
    DeRef(_b_5393);
    return 0;
L3: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5392)){
            _2778 = SEQ_PTR(_a_5392)->length;
    }
    else {
        _2778 = 1;
    }
    {
        int _i_5403;
        _i_5403 = 1;
L4: 
        if (_i_5403 > _2778){
            goto L5; // [49] 88
        }

        /** 		if not binop_ok(a[i], b[i]) then*/
        _2 = (int)SEQ_PTR(_a_5392);
        _2779 = (int)*(((s1_ptr)_2)->base + _i_5403);
        _2 = (int)SEQ_PTR(_b_5393);
        _2780 = (int)*(((s1_ptr)_2)->base + _i_5403);
        Ref(_2779);
        Ref(_2780);
        _2781 = _23binop_ok(_2779, _2780);
        _2779 = NOVALUE;
        _2780 = NOVALUE;
        if (IS_ATOM_INT(_2781)) {
            if (_2781 != 0){
                DeRef(_2781);
                _2781 = NOVALUE;
                goto L6; // [71] 81
            }
        }
        else {
            if (DBL_PTR(_2781)->dbl != 0.0){
                DeRef(_2781);
                _2781 = NOVALUE;
                goto L6; // [71] 81
            }
        }
        DeRef(_2781);
        _2781 = NOVALUE;

        /** 			return 0*/
        DeRef(_a_5392);
        DeRef(_b_5393);
        return 0;
L6: 

        /** 	end for*/
        _i_5403 = _i_5403 + 1;
        goto L4; // [83] 56
L5: 
        ;
    }

    /** 	return 1*/
    DeRef(_a_5392);
    DeRef(_b_5393);
    return 1;
    ;
}


int  __stdcall _23fetch(int _source_5412, int _indexes_5413)
{
    int _x_5414 = NOVALUE;
    int _2793 = NOVALUE;
    int _2792 = NOVALUE;
    int _2791 = NOVALUE;
    int _2790 = NOVALUE;
    int _2789 = NOVALUE;
    int _2787 = NOVALUE;
    int _2785 = NOVALUE;
    int _2784 = NOVALUE;
    int _2783 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i=1 to length(indexes)-1 do*/
    if (IS_SEQUENCE(_indexes_5413)){
            _2783 = SEQ_PTR(_indexes_5413)->length;
    }
    else {
        _2783 = 1;
    }
    _2784 = _2783 - 1;
    _2783 = NOVALUE;
    {
        int _i_5416;
        _i_5416 = 1;
L1: 
        if (_i_5416 > _2784){
            goto L2; // [14] 40
        }

        /** 		source = source[indexes[i]]*/
        _2 = (int)SEQ_PTR(_indexes_5413);
        _2785 = (int)*(((s1_ptr)_2)->base + _i_5416);
        _0 = _source_5412;
        _2 = (int)SEQ_PTR(_source_5412);
        if (!IS_ATOM_INT(_2785)){
            _source_5412 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_2785)->dbl));
        }
        else{
            _source_5412 = (int)*(((s1_ptr)_2)->base + _2785);
        }
        Ref(_source_5412);
        DeRefDS(_0);

        /** 	end for*/
        _i_5416 = _i_5416 + 1;
        goto L1; // [35] 21
L2: 
        ;
    }

    /** 	x = indexes[$]*/
    if (IS_SEQUENCE(_indexes_5413)){
            _2787 = SEQ_PTR(_indexes_5413)->length;
    }
    else {
        _2787 = 1;
    }
    DeRef(_x_5414);
    _2 = (int)SEQ_PTR(_indexes_5413);
    _x_5414 = (int)*(((s1_ptr)_2)->base + _2787);
    Ref(_x_5414);

    /** 	if atom(x) then*/
    _2789 = IS_ATOM(_x_5414);
    if (_2789 == 0)
    {
        _2789 = NOVALUE;
        goto L3; // [54] 70
    }
    else{
        _2789 = NOVALUE;
    }

    /** 		return source[x]*/
    _2 = (int)SEQ_PTR(_source_5412);
    if (!IS_ATOM_INT(_x_5414)){
        _2790 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_x_5414)->dbl));
    }
    else{
        _2790 = (int)*(((s1_ptr)_2)->base + _x_5414);
    }
    Ref(_2790);
    DeRefDS(_source_5412);
    DeRefDS(_indexes_5413);
    DeRef(_x_5414);
    DeRef(_2784);
    _2784 = NOVALUE;
    _2785 = NOVALUE;
    return _2790;
    goto L4; // [67] 90
L3: 

    /** 		return source[x[1]..x[2]]*/
    _2 = (int)SEQ_PTR(_x_5414);
    _2791 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_5414);
    _2792 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_2793;
    RHS_Slice(_source_5412, _2791, _2792);
    DeRefDS(_source_5412);
    DeRefDS(_indexes_5413);
    DeRef(_x_5414);
    DeRef(_2784);
    _2784 = NOVALUE;
    _2785 = NOVALUE;
    _2790 = NOVALUE;
    _2791 = NOVALUE;
    _2792 = NOVALUE;
    return _2793;
L4: 
    ;
}


int  __stdcall _23store(int _target_5432, int _indexes_5433, int _x_5434)
{
    int _partials_5435 = NOVALUE;
    int _result_5436 = NOVALUE;
    int _branch_5437 = NOVALUE;
    int _last_idx_5438 = NOVALUE;
    int _2811 = NOVALUE;
    int _2810 = NOVALUE;
    int _2808 = NOVALUE;
    int _2807 = NOVALUE;
    int _2805 = NOVALUE;
    int _2804 = NOVALUE;
    int _2803 = NOVALUE;
    int _2801 = NOVALUE;
    int _2799 = NOVALUE;
    int _2798 = NOVALUE;
    int _2797 = NOVALUE;
    int _2795 = NOVALUE;
    int _2794 = NOVALUE;
    int _0, _1, _2;
    

    /** 	partials = repeat(target,length(indexes)-1)*/
    if (IS_SEQUENCE(_indexes_5433)){
            _2794 = SEQ_PTR(_indexes_5433)->length;
    }
    else {
        _2794 = 1;
    }
    _2795 = _2794 - 1;
    _2794 = NOVALUE;
    DeRef(_partials_5435);
    _partials_5435 = Repeat(_target_5432, _2795);
    _2795 = NOVALUE;

    /** 	branch = target*/
    RefDS(_target_5432);
    DeRef(_branch_5437);
    _branch_5437 = _target_5432;

    /** 	for i=1 to length(indexes)-1 do*/
    if (IS_SEQUENCE(_indexes_5433)){
            _2797 = SEQ_PTR(_indexes_5433)->length;
    }
    else {
        _2797 = 1;
    }
    _2798 = _2797 - 1;
    _2797 = NOVALUE;
    {
        int _i_5443;
        _i_5443 = 1;
L1: 
        if (_i_5443 > _2798){
            goto L2; // [34] 66
        }

        /** 		branch=branch[indexes[i]]*/
        _2 = (int)SEQ_PTR(_indexes_5433);
        _2799 = (int)*(((s1_ptr)_2)->base + _i_5443);
        _0 = _branch_5437;
        _2 = (int)SEQ_PTR(_branch_5437);
        if (!IS_ATOM_INT(_2799)){
            _branch_5437 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_2799)->dbl));
        }
        else{
            _branch_5437 = (int)*(((s1_ptr)_2)->base + _2799);
        }
        Ref(_branch_5437);
        DeRef(_0);

        /** 		partials[i]=branch*/
        RefDS(_branch_5437);
        _2 = (int)SEQ_PTR(_partials_5435);
        _2 = (int)(((s1_ptr)_2)->base + _i_5443);
        _1 = *(int *)_2;
        *(int *)_2 = _branch_5437;
        DeRef(_1);

        /** 	end for*/
        _i_5443 = _i_5443 + 1;
        goto L1; // [61] 41
L2: 
        ;
    }

    /** 	last_idx = indexes[$]*/
    if (IS_SEQUENCE(_indexes_5433)){
            _2801 = SEQ_PTR(_indexes_5433)->length;
    }
    else {
        _2801 = 1;
    }
    DeRef(_last_idx_5438);
    _2 = (int)SEQ_PTR(_indexes_5433);
    _last_idx_5438 = (int)*(((s1_ptr)_2)->base + _2801);
    Ref(_last_idx_5438);

    /** 	if atom(last_idx) then*/
    _2803 = IS_ATOM(_last_idx_5438);
    if (_2803 == 0)
    {
        _2803 = NOVALUE;
        goto L3; // [80] 92
    }
    else{
        _2803 = NOVALUE;
    }

    /** 		branch[last_idx]=x*/
    Ref(_x_5434);
    _2 = (int)SEQ_PTR(_branch_5437);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _branch_5437 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_last_idx_5438))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_last_idx_5438)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _last_idx_5438);
    _1 = *(int *)_2;
    *(int *)_2 = _x_5434;
    DeRef(_1);
    goto L4; // [89] 108
L3: 

    /** 		branch[last_idx[1]..last_idx[2]]=x*/
    _2 = (int)SEQ_PTR(_last_idx_5438);
    _2804 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_last_idx_5438);
    _2805 = (int)*(((s1_ptr)_2)->base + 2);
    assign_slice_seq = (s1_ptr *)&_branch_5437;
    AssignSlice(_2804, _2805, _x_5434);
    _2804 = NOVALUE;
    _2805 = NOVALUE;
L4: 

    /** 	partials = prepend(partials,0) -- avoids computing temp=i+1 a few times*/
    Prepend(&_partials_5435, _partials_5435, 0);

    /** 	for i=length(indexes)-1 to 2 by -1 do*/
    if (IS_SEQUENCE(_indexes_5433)){
            _2807 = SEQ_PTR(_indexes_5433)->length;
    }
    else {
        _2807 = 1;
    }
    _2808 = _2807 - 1;
    _2807 = NOVALUE;
    {
        int _i_5457;
        _i_5457 = _2808;
L5: 
        if (_i_5457 < 2){
            goto L6; // [123] 162
        }

        /** 		result = partials[i]*/
        DeRef(_result_5436);
        _2 = (int)SEQ_PTR(_partials_5435);
        _result_5436 = (int)*(((s1_ptr)_2)->base + _i_5457);
        Ref(_result_5436);

        /** 		result[indexes[i]] = branch*/
        _2 = (int)SEQ_PTR(_indexes_5433);
        _2810 = (int)*(((s1_ptr)_2)->base + _i_5457);
        RefDS(_branch_5437);
        _2 = (int)SEQ_PTR(_result_5436);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_5436 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_2810))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_2810)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _2810);
        _1 = *(int *)_2;
        *(int *)_2 = _branch_5437;
        DeRef(_1);

        /** 		branch = result*/
        RefDS(_result_5436);
        DeRefDS(_branch_5437);
        _branch_5437 = _result_5436;

        /** 	end for*/
        _i_5457 = _i_5457 + -1;
        goto L5; // [157] 130
L6: 
        ;
    }

    /** 	target[indexes[1]] = branch*/
    _2 = (int)SEQ_PTR(_indexes_5433);
    _2811 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_branch_5437);
    _2 = (int)SEQ_PTR(_target_5432);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _target_5432 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_2811))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_2811)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _2811);
    _1 = *(int *)_2;
    *(int *)_2 = _branch_5437;
    DeRef(_1);

    /** 	return target*/
    DeRefDS(_indexes_5433);
    DeRef(_x_5434);
    DeRef(_partials_5435);
    DeRef(_result_5436);
    DeRefDS(_branch_5437);
    DeRef(_last_idx_5438);
    DeRef(_2798);
    _2798 = NOVALUE;
    _2799 = NOVALUE;
    DeRef(_2808);
    _2808 = NOVALUE;
    _2810 = NOVALUE;
    _2811 = NOVALUE;
    return _target_5432;
    ;
}


int  __stdcall _23valid_index(int _st_5465, int _x_5466)
{
    int _2816 = NOVALUE;
    int _2815 = NOVALUE;
    int _2812 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(x) then*/
    _2812 = IS_ATOM(_x_5466);
    if (_2812 != 0)
    goto L1; // [8] 18
    _2812 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_st_5465);
    DeRef(_x_5466);
    return 0;
L1: 

    /** 	if x < 1 then*/
    if (binary_op_a(GREATEREQ, _x_5466, 1)){
        goto L2; // [20] 31
    }

    /** 		return 0*/
    DeRefDS(_st_5465);
    DeRef(_x_5466);
    return 0;
L2: 

    /** 	if floor(x) > length(st) then*/
    if (IS_ATOM_INT(_x_5466))
    _2815 = e_floor(_x_5466);
    else
    _2815 = unary_op(FLOOR, _x_5466);
    if (IS_SEQUENCE(_st_5465)){
            _2816 = SEQ_PTR(_st_5465)->length;
    }
    else {
        _2816 = 1;
    }
    if (binary_op_a(LESSEQ, _2815, _2816)){
        DeRef(_2815);
        _2815 = NOVALUE;
        _2816 = NOVALUE;
        goto L3; // [39] 50
    }
    DeRef(_2815);
    _2815 = NOVALUE;
    _2816 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_st_5465);
    DeRef(_x_5466);
    return 0;
L3: 

    /** 	return 1*/
    DeRefDS(_st_5465);
    DeRef(_x_5466);
    return 1;
    ;
}


int  __stdcall _23rotate(int _source_5478, int _shift_5479, int _start_5480, int _stop_5481)
{
    int _shifted_5483 = NOVALUE;
    int _len_5484 = NOVALUE;
    int _lSize_5485 = NOVALUE;
    int _msg_inlined_crash_at_60_5498 = NOVALUE;
    int _msg_inlined_crash_at_91_5504 = NOVALUE;
    int _2844 = NOVALUE;
    int _2843 = NOVALUE;
    int _2842 = NOVALUE;
    int _2841 = NOVALUE;
    int _2840 = NOVALUE;
    int _2838 = NOVALUE;
    int _2837 = NOVALUE;
    int _2831 = NOVALUE;
    int _2828 = NOVALUE;
    int _2825 = NOVALUE;
    int _2824 = NOVALUE;
    int _2822 = NOVALUE;
    int _2821 = NOVALUE;
    int _2820 = NOVALUE;
    int _2819 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_5479)) {
        _1 = (long)(DBL_PTR(_shift_5479)->dbl);
        DeRefDS(_shift_5479);
        _shift_5479 = _1;
    }
    if (!IS_ATOM_INT(_start_5480)) {
        _1 = (long)(DBL_PTR(_start_5480)->dbl);
        DeRefDS(_start_5480);
        _start_5480 = _1;
    }
    if (!IS_ATOM_INT(_stop_5481)) {
        _1 = (long)(DBL_PTR(_stop_5481)->dbl);
        DeRefDS(_stop_5481);
        _stop_5481 = _1;
    }

    /** 	if start >= stop or length(source)=0 or not shift then*/
    _2819 = (_start_5480 >= _stop_5481);
    if (_2819 != 0) {
        _2820 = 1;
        goto L1; // [15] 30
    }
    if (IS_SEQUENCE(_source_5478)){
            _2821 = SEQ_PTR(_source_5478)->length;
    }
    else {
        _2821 = 1;
    }
    _2822 = (_2821 == 0);
    _2821 = NOVALUE;
    _2820 = (_2822 != 0);
L1: 
    if (_2820 != 0) {
        goto L2; // [30] 42
    }
    _2824 = (_shift_5479 == 0);
    if (_2824 == 0)
    {
        DeRef(_2824);
        _2824 = NOVALUE;
        goto L3; // [38] 49
    }
    else{
        DeRef(_2824);
        _2824 = NOVALUE;
    }
L2: 

    /** 		return source*/
    DeRef(_shifted_5483);
    DeRef(_2819);
    _2819 = NOVALUE;
    DeRef(_2822);
    _2822 = NOVALUE;
    return _source_5478;
L3: 

    /** 	if not valid_index(source, start) then*/
    RefDS(_source_5478);
    _2825 = _23valid_index(_source_5478, _start_5480);
    if (IS_ATOM_INT(_2825)) {
        if (_2825 != 0){
            DeRef(_2825);
            _2825 = NOVALUE;
            goto L4; // [56] 80
        }
    }
    else {
        if (DBL_PTR(_2825)->dbl != 0.0){
            DeRef(_2825);
            _2825 = NOVALUE;
            goto L4; // [56] 80
        }
    }
    DeRef(_2825);
    _2825 = NOVALUE;

    /** 		error:crash("sequence:rotate(): invalid 'start' parameter %d", start)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_60_5498);
    _msg_inlined_crash_at_60_5498 = EPrintf(-9999999, _2827, _start_5480);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_60_5498);

    /** end procedure*/
    goto L5; // [74] 77
L5: 
    DeRefi(_msg_inlined_crash_at_60_5498);
    _msg_inlined_crash_at_60_5498 = NOVALUE;
L4: 

    /** 	if not valid_index(source, stop) then*/
    RefDS(_source_5478);
    _2828 = _23valid_index(_source_5478, _stop_5481);
    if (IS_ATOM_INT(_2828)) {
        if (_2828 != 0){
            DeRef(_2828);
            _2828 = NOVALUE;
            goto L6; // [87] 111
        }
    }
    else {
        if (DBL_PTR(_2828)->dbl != 0.0){
            DeRef(_2828);
            _2828 = NOVALUE;
            goto L6; // [87] 111
        }
    }
    DeRef(_2828);
    _2828 = NOVALUE;

    /** 		error:crash("sequence:rotate(): invalid 'stop' parameter %d", stop)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_91_5504);
    _msg_inlined_crash_at_91_5504 = EPrintf(-9999999, _2830, _stop_5481);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_91_5504);

    /** end procedure*/
    goto L7; // [105] 108
L7: 
    DeRefi(_msg_inlined_crash_at_91_5504);
    _msg_inlined_crash_at_91_5504 = NOVALUE;
L6: 

    /** 	len = stop - start + 1*/
    _2831 = _stop_5481 - _start_5480;
    if ((long)((unsigned long)_2831 +(unsigned long) HIGH_BITS) >= 0){
        _2831 = NewDouble((double)_2831);
    }
    if (IS_ATOM_INT(_2831)) {
        _len_5484 = _2831 + 1;
    }
    else
    { // coercing _len_5484 to an integer 1
        _len_5484 = 1+(long)(DBL_PTR(_2831)->dbl);
        if( !IS_ATOM_INT(_len_5484) ){
            _len_5484 = (object)DBL_PTR(_len_5484)->dbl;
        }
    }
    DeRef(_2831);
    _2831 = NOVALUE;

    /** 	lSize = remainder(shift, len)*/
    _lSize_5485 = (_shift_5479 % _len_5484);

    /** 	if lSize = 0 then*/
    if (_lSize_5485 != 0)
    goto L8; // [129] 140

    /** 		return source*/
    DeRef(_shifted_5483);
    DeRef(_2819);
    _2819 = NOVALUE;
    DeRef(_2822);
    _2822 = NOVALUE;
    return _source_5478;
L8: 

    /** 	if lSize < 0 then -- convert right shift to left shift*/
    if (_lSize_5485 >= 0)
    goto L9; // [142] 153

    /** 		lSize += len*/
    _lSize_5485 = _lSize_5485 + _len_5484;
L9: 

    /** 	shifted = source[start .. start + lSize-1]*/
    _2837 = _start_5480 + _lSize_5485;
    if ((long)((unsigned long)_2837 + (unsigned long)HIGH_BITS) >= 0) 
    _2837 = NewDouble((double)_2837);
    if (IS_ATOM_INT(_2837)) {
        _2838 = _2837 - 1;
    }
    else {
        _2838 = NewDouble(DBL_PTR(_2837)->dbl - (double)1);
    }
    DeRef(_2837);
    _2837 = NOVALUE;
    rhs_slice_target = (object_ptr)&_shifted_5483;
    RHS_Slice(_source_5478, _start_5480, _2838);

    /** 	source[start .. stop - lSize] = source[start + lSize .. stop]*/
    _2840 = _stop_5481 - _lSize_5485;
    if ((long)((unsigned long)_2840 +(unsigned long) HIGH_BITS) >= 0){
        _2840 = NewDouble((double)_2840);
    }
    _2841 = _start_5480 + _lSize_5485;
    rhs_slice_target = (object_ptr)&_2842;
    RHS_Slice(_source_5478, _2841, _stop_5481);
    assign_slice_seq = (s1_ptr *)&_source_5478;
    AssignSlice(_start_5480, _2840, _2842);
    DeRef(_2840);
    _2840 = NOVALUE;
    DeRefDS(_2842);
    _2842 = NOVALUE;

    /** 	source[stop - lSize + 1.. stop] = shifted*/
    _2843 = _stop_5481 - _lSize_5485;
    if ((long)((unsigned long)_2843 +(unsigned long) HIGH_BITS) >= 0){
        _2843 = NewDouble((double)_2843);
    }
    if (IS_ATOM_INT(_2843)) {
        _2844 = _2843 + 1;
    }
    else
    _2844 = binary_op(PLUS, 1, _2843);
    DeRef(_2843);
    _2843 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_source_5478;
    AssignSlice(_2844, _stop_5481, _shifted_5483);
    DeRef(_2844);
    _2844 = NOVALUE;

    /** 	return source*/
    DeRefDS(_shifted_5483);
    DeRef(_2819);
    _2819 = NOVALUE;
    DeRef(_2822);
    _2822 = NOVALUE;
    DeRef(_2838);
    _2838 = NOVALUE;
    _2841 = NOVALUE;
    return _source_5478;
    ;
}


int  __stdcall _23columnize(int _source_5523, int _cols_5524, int _defval_5525)
{
    int _result_5526 = NOVALUE;
    int _collist_5527 = NOVALUE;
    int _col_5553 = NOVALUE;
    int _2875 = NOVALUE;
    int _2874 = NOVALUE;
    int _2873 = NOVALUE;
    int _2872 = NOVALUE;
    int _2871 = NOVALUE;
    int _2870 = NOVALUE;
    int _2869 = NOVALUE;
    int _2868 = NOVALUE;
    int _2867 = NOVALUE;
    int _2866 = NOVALUE;
    int _2865 = NOVALUE;
    int _2863 = NOVALUE;
    int _2862 = NOVALUE;
    int _2861 = NOVALUE;
    int _2859 = NOVALUE;
    int _2857 = NOVALUE;
    int _2855 = NOVALUE;
    int _2853 = NOVALUE;
    int _2851 = NOVALUE;
    int _2850 = NOVALUE;
    int _2849 = NOVALUE;
    int _2847 = NOVALUE;
    int _2845 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(cols) then*/
    _2845 = IS_SEQUENCE(_cols_5524);
    if (_2845 == 0)
    {
        _2845 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _2845 = NOVALUE;
    }

    /** 		collist = cols*/
    Ref(_cols_5524);
    DeRef(_collist_5527);
    _collist_5527 = _cols_5524;
    goto L2; // [18] 28
L1: 

    /** 		collist = {cols}*/
    _0 = _collist_5527;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_cols_5524);
    *((int *)(_2+4)) = _cols_5524;
    _collist_5527 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if length(collist) = 0 then*/
    if (IS_SEQUENCE(_collist_5527)){
            _2847 = SEQ_PTR(_collist_5527)->length;
    }
    else {
        _2847 = 1;
    }
    if (_2847 != 0)
    goto L3; // [35] 112

    /** 		cols = 0*/
    DeRef(_cols_5524);
    _cols_5524 = 0;

    /** 		for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5523)){
            _2849 = SEQ_PTR(_source_5523)->length;
    }
    else {
        _2849 = 1;
    }
    {
        int _i_5536;
        _i_5536 = 1;
L4: 
        if (_i_5536 > _2849){
            goto L5; // [49] 86
        }

        /** 			if cols < length(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5523);
        _2850 = (int)*(((s1_ptr)_2)->base + _i_5536);
        if (IS_SEQUENCE(_2850)){
                _2851 = SEQ_PTR(_2850)->length;
        }
        else {
            _2851 = 1;
        }
        _2850 = NOVALUE;
        if (binary_op_a(GREATEREQ, _cols_5524, _2851)){
            _2851 = NOVALUE;
            goto L6; // [65] 79
        }
        _2851 = NOVALUE;

        /** 				cols = length(source[i])*/
        _2 = (int)SEQ_PTR(_source_5523);
        _2853 = (int)*(((s1_ptr)_2)->base + _i_5536);
        DeRef(_cols_5524);
        if (IS_SEQUENCE(_2853)){
                _cols_5524 = SEQ_PTR(_2853)->length;
        }
        else {
            _cols_5524 = 1;
        }
        _2853 = NOVALUE;
L6: 

        /** 		end for*/
        _i_5536 = _i_5536 + 1;
        goto L4; // [81] 56
L5: 
        ;
    }

    /** 		for i = 1 to cols do*/
    Ref(_cols_5524);
    DeRef(_2855);
    _2855 = _cols_5524;
    {
        int _i_5545;
        _i_5545 = 1;
L7: 
        if (binary_op_a(GREATER, _i_5545, _2855)){
            goto L8; // [91] 111
        }

        /** 			collist &= i*/
        Ref(_i_5545);
        Append(&_collist_5527, _collist_5527, _i_5545);

        /** 		end for*/
        _0 = _i_5545;
        if (IS_ATOM_INT(_i_5545)) {
            _i_5545 = _i_5545 + 1;
            if ((long)((unsigned long)_i_5545 +(unsigned long) HIGH_BITS) >= 0){
                _i_5545 = NewDouble((double)_i_5545);
            }
        }
        else {
            _i_5545 = binary_op_a(PLUS, _i_5545, 1);
        }
        DeRef(_0);
        goto L7; // [106] 98
L8: 
        ;
        DeRef(_i_5545);
    }
L3: 

    /** 	result = repeat({}, length(collist))*/
    if (IS_SEQUENCE(_collist_5527)){
            _2857 = SEQ_PTR(_collist_5527)->length;
    }
    else {
        _2857 = 1;
    }
    DeRef(_result_5526);
    _result_5526 = Repeat(_5, _2857);
    _2857 = NOVALUE;

    /** 	for i = 1 to length(collist) do*/
    if (IS_SEQUENCE(_collist_5527)){
            _2859 = SEQ_PTR(_collist_5527)->length;
    }
    else {
        _2859 = 1;
    }
    {
        int _i_5551;
        _i_5551 = 1;
L9: 
        if (_i_5551 > _2859){
            goto LA; // [126] 254
        }

        /** 		integer col = collist[i]*/
        _2 = (int)SEQ_PTR(_collist_5527);
        _col_5553 = (int)*(((s1_ptr)_2)->base + _i_5551);
        if (!IS_ATOM_INT(_col_5553))
        _col_5553 = (long)DBL_PTR(_col_5553)->dbl;

        /** 		for j = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5523)){
                _2861 = SEQ_PTR(_source_5523)->length;
        }
        else {
            _2861 = 1;
        }
        {
            int _j_5556;
            _j_5556 = 1;
LB: 
            if (_j_5556 > _2861){
                goto LC; // [144] 245
            }

            /** 			if length(source[j]) < col then*/
            _2 = (int)SEQ_PTR(_source_5523);
            _2862 = (int)*(((s1_ptr)_2)->base + _j_5556);
            if (IS_SEQUENCE(_2862)){
                    _2863 = SEQ_PTR(_2862)->length;
            }
            else {
                _2863 = 1;
            }
            _2862 = NOVALUE;
            if (_2863 >= _col_5553)
            goto LD; // [160] 181

            /** 				result[i] = append(result[i], defval)*/
            _2 = (int)SEQ_PTR(_result_5526);
            _2865 = (int)*(((s1_ptr)_2)->base + _i_5551);
            Ref(_defval_5525);
            Append(&_2866, _2865, _defval_5525);
            _2865 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5526);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5526 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5551);
            _1 = *(int *)_2;
            *(int *)_2 = _2866;
            if( _1 != _2866 ){
                DeRefDS(_1);
            }
            _2866 = NOVALUE;
            goto LE; // [178] 238
LD: 

            /** 				if atom(source[j]) then*/
            _2 = (int)SEQ_PTR(_source_5523);
            _2867 = (int)*(((s1_ptr)_2)->base + _j_5556);
            _2868 = IS_ATOM(_2867);
            _2867 = NOVALUE;
            if (_2868 == 0)
            {
                _2868 = NOVALUE;
                goto LF; // [190] 214
            }
            else{
                _2868 = NOVALUE;
            }

            /** 					result[i] = append(result[i], source[j])*/
            _2 = (int)SEQ_PTR(_result_5526);
            _2869 = (int)*(((s1_ptr)_2)->base + _i_5551);
            _2 = (int)SEQ_PTR(_source_5523);
            _2870 = (int)*(((s1_ptr)_2)->base + _j_5556);
            Ref(_2870);
            Append(&_2871, _2869, _2870);
            _2869 = NOVALUE;
            _2870 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5526);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5526 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5551);
            _1 = *(int *)_2;
            *(int *)_2 = _2871;
            if( _1 != _2871 ){
                DeRefDS(_1);
            }
            _2871 = NOVALUE;
            goto L10; // [211] 237
LF: 

            /** 					result[i] = append(result[i], source[j][col])*/
            _2 = (int)SEQ_PTR(_result_5526);
            _2872 = (int)*(((s1_ptr)_2)->base + _i_5551);
            _2 = (int)SEQ_PTR(_source_5523);
            _2873 = (int)*(((s1_ptr)_2)->base + _j_5556);
            _2 = (int)SEQ_PTR(_2873);
            _2874 = (int)*(((s1_ptr)_2)->base + _col_5553);
            _2873 = NOVALUE;
            Ref(_2874);
            Append(&_2875, _2872, _2874);
            _2872 = NOVALUE;
            _2874 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5526);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5526 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5551);
            _1 = *(int *)_2;
            *(int *)_2 = _2875;
            if( _1 != _2875 ){
                DeRefDS(_1);
            }
            _2875 = NOVALUE;
L10: 
LE: 

            /** 		end for*/
            _j_5556 = _j_5556 + 1;
            goto LB; // [240] 151
LC: 
            ;
        }

        /** 	end for*/
        _i_5551 = _i_5551 + 1;
        goto L9; // [249] 133
LA: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_5523);
    DeRef(_cols_5524);
    DeRef(_defval_5525);
    DeRef(_collist_5527);
    _2850 = NOVALUE;
    _2853 = NOVALUE;
    _2862 = NOVALUE;
    return _result_5526;
    ;
}


int  __stdcall _23apply(int _source_5578, int _rid_5579, int _userdata_5580)
{
    int _2879 = NOVALUE;
    int _2878 = NOVALUE;
    int _2877 = NOVALUE;
    int _2876 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_5579)) {
        _1 = (long)(DBL_PTR(_rid_5579)->dbl);
        DeRefDS(_rid_5579);
        _rid_5579 = _1;
    }

    /** 	for a = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5578)){
            _2876 = SEQ_PTR(_source_5578)->length;
    }
    else {
        _2876 = 1;
    }
    {
        int _a_5582;
        _a_5582 = 1;
L1: 
        if (_a_5582 > _2876){
            goto L2; // [10] 42
        }

        /** 		source[a] = call_func(rid, {source[a], userdata})*/
        _2 = (int)SEQ_PTR(_source_5578);
        _2877 = (int)*(((s1_ptr)_2)->base + _a_5582);
        Ref(_userdata_5580);
        Ref(_2877);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _2877;
        ((int *)_2)[2] = _userdata_5580;
        _2878 = MAKE_SEQ(_1);
        _2877 = NOVALUE;
        _1 = (int)SEQ_PTR(_2878);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_rid_5579].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        if (_00[_rid_5579].convention) {
            _1 = (*(int (__stdcall *)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
        }
        else {
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
        }
        DeRef(_2879);
        _2879 = _1;
        DeRefDS(_2878);
        _2878 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_5578);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5578 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5582);
        _1 = *(int *)_2;
        *(int *)_2 = _2879;
        if( _1 != _2879 ){
            DeRef(_1);
        }
        _2879 = NOVALUE;

        /** 	end for*/
        _a_5582 = _a_5582 + 1;
        goto L1; // [37] 17
L2: 
        ;
    }

    /** 	return source*/
    DeRef(_userdata_5580);
    return _source_5578;
    ;
}


int  __stdcall _23mapping(int _source_arg_5589, int _from_set_5590, int _to_set_5591, int _one_level_5592)
{
    int _pos_5593 = NOVALUE;
    int _2901 = NOVALUE;
    int _2900 = NOVALUE;
    int _2899 = NOVALUE;
    int _2898 = NOVALUE;
    int _2897 = NOVALUE;
    int _2896 = NOVALUE;
    int _2895 = NOVALUE;
    int _2894 = NOVALUE;
    int _2893 = NOVALUE;
    int _2891 = NOVALUE;
    int _2889 = NOVALUE;
    int _2888 = NOVALUE;
    int _2887 = NOVALUE;
    int _2885 = NOVALUE;
    int _2884 = NOVALUE;
    int _2883 = NOVALUE;
    int _2882 = NOVALUE;
    int _2880 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_one_level_5592)) {
        _1 = (long)(DBL_PTR(_one_level_5592)->dbl);
        DeRefDS(_one_level_5592);
        _one_level_5592 = _1;
    }

    /** 	if atom(source_arg) then*/
    _2880 = IS_ATOM(_source_arg_5589);
    if (_2880 == 0)
    {
        _2880 = NOVALUE;
        goto L1; // [12] 53
    }
    else{
        _2880 = NOVALUE;
    }

    /** 		pos = find(source_arg, from_set)*/
    _pos_5593 = find_from(_source_arg_5589, _from_set_5590, 1);

    /** 		if pos >= 1  and pos <= length(to_set) then*/
    _2882 = (_pos_5593 >= 1);
    if (_2882 == 0) {
        goto L2; // [28] 161
    }
    if (IS_SEQUENCE(_to_set_5591)){
            _2884 = SEQ_PTR(_to_set_5591)->length;
    }
    else {
        _2884 = 1;
    }
    _2885 = (_pos_5593 <= _2884);
    _2884 = NOVALUE;
    if (_2885 == 0)
    {
        DeRef(_2885);
        _2885 = NOVALUE;
        goto L2; // [40] 161
    }
    else{
        DeRef(_2885);
        _2885 = NOVALUE;
    }

    /** 			source_arg = to_set[pos]*/
    DeRef(_source_arg_5589);
    _2 = (int)SEQ_PTR(_to_set_5591);
    _source_arg_5589 = (int)*(((s1_ptr)_2)->base + _pos_5593);
    Ref(_source_arg_5589);
    goto L2; // [50] 161
L1: 

    /** 		for i = 1 to length(source_arg) do*/
    if (IS_SEQUENCE(_source_arg_5589)){
            _2887 = SEQ_PTR(_source_arg_5589)->length;
    }
    else {
        _2887 = 1;
    }
    {
        int _i_5605;
        _i_5605 = 1;
L3: 
        if (_i_5605 > _2887){
            goto L4; // [58] 160
        }

        /** 			if atom(source_arg[i]) or one_level then*/
        _2 = (int)SEQ_PTR(_source_arg_5589);
        _2888 = (int)*(((s1_ptr)_2)->base + _i_5605);
        _2889 = IS_ATOM(_2888);
        _2888 = NOVALUE;
        if (_2889 != 0) {
            goto L5; // [74] 83
        }
        if (_one_level_5592 == 0)
        {
            goto L6; // [79] 129
        }
        else{
        }
L5: 

        /** 				pos = find(source_arg[i], from_set)*/
        _2 = (int)SEQ_PTR(_source_arg_5589);
        _2891 = (int)*(((s1_ptr)_2)->base + _i_5605);
        _pos_5593 = find_from(_2891, _from_set_5590, 1);
        _2891 = NOVALUE;

        /** 				if pos >= 1  and pos <= length(to_set) then*/
        _2893 = (_pos_5593 >= 1);
        if (_2893 == 0) {
            goto L7; // [100] 153
        }
        if (IS_SEQUENCE(_to_set_5591)){
                _2895 = SEQ_PTR(_to_set_5591)->length;
        }
        else {
            _2895 = 1;
        }
        _2896 = (_pos_5593 <= _2895);
        _2895 = NOVALUE;
        if (_2896 == 0)
        {
            DeRef(_2896);
            _2896 = NOVALUE;
            goto L7; // [112] 153
        }
        else{
            DeRef(_2896);
            _2896 = NOVALUE;
        }

        /** 					source_arg[i] = to_set[pos]*/
        _2 = (int)SEQ_PTR(_to_set_5591);
        _2897 = (int)*(((s1_ptr)_2)->base + _pos_5593);
        Ref(_2897);
        _2 = (int)SEQ_PTR(_source_arg_5589);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_arg_5589 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5605);
        _1 = *(int *)_2;
        *(int *)_2 = _2897;
        if( _1 != _2897 ){
            DeRef(_1);
        }
        _2897 = NOVALUE;
        goto L7; // [126] 153
L6: 

        /** 				source_arg[i] = mapping(source_arg[i], from_set, to_set)*/
        _2 = (int)SEQ_PTR(_source_arg_5589);
        _2898 = (int)*(((s1_ptr)_2)->base + _i_5605);
        RefDS(_from_set_5590);
        DeRef(_2899);
        _2899 = _from_set_5590;
        RefDS(_to_set_5591);
        DeRef(_2900);
        _2900 = _to_set_5591;
        Ref(_2898);
        _2901 = _23mapping(_2898, _2899, _2900, 0);
        _2898 = NOVALUE;
        _2899 = NOVALUE;
        _2900 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_arg_5589);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_arg_5589 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5605);
        _1 = *(int *)_2;
        *(int *)_2 = _2901;
        if( _1 != _2901 ){
            DeRef(_1);
        }
        _2901 = NOVALUE;
L7: 

        /** 		end for*/
        _i_5605 = _i_5605 + 1;
        goto L3; // [155] 65
L4: 
        ;
    }
L2: 

    /** 	return source_arg*/
    DeRefDS(_from_set_5590);
    DeRefDS(_to_set_5591);
    DeRef(_2882);
    _2882 = NOVALUE;
    DeRef(_2893);
    _2893 = NOVALUE;
    return _source_arg_5589;
    ;
}


int  __stdcall _23reverse(int _target_5626, int _pFrom_5627, int _pTo_5628)
{
    int _uppr_5629 = NOVALUE;
    int _n_5630 = NOVALUE;
    int _lLimit_5631 = NOVALUE;
    int _t_5632 = NOVALUE;
    int _2916 = NOVALUE;
    int _2915 = NOVALUE;
    int _2914 = NOVALUE;
    int _2912 = NOVALUE;
    int _2911 = NOVALUE;
    int _2909 = NOVALUE;
    int _2907 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pFrom_5627)) {
        _1 = (long)(DBL_PTR(_pFrom_5627)->dbl);
        DeRefDS(_pFrom_5627);
        _pFrom_5627 = _1;
    }
    if (!IS_ATOM_INT(_pTo_5628)) {
        _1 = (long)(DBL_PTR(_pTo_5628)->dbl);
        DeRefDS(_pTo_5628);
        _pTo_5628 = _1;
    }

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_5626)){
            _n_5630 = SEQ_PTR(_target_5626)->length;
    }
    else {
        _n_5630 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_5630 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_5632);
    return _target_5626;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_5627 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_5627 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_5628 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_5628 = _n_5630 + _pTo_5628;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _2907 = (_pTo_5628 < _pFrom_5627);
    if (_2907 != 0) {
        goto L4; // [54] 67
    }
    _2909 = (_pFrom_5627 >= _n_5630);
    if (_2909 == 0)
    {
        DeRef(_2909);
        _2909 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2909);
        _2909 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_5632);
    DeRef(_2907);
    _2907 = NOVALUE;
    return _target_5626;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_5628 <= _n_5630)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_5628 = _n_5630;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _2911 = _pFrom_5627 + _pTo_5628;
    if ((long)((unsigned long)_2911 + (unsigned long)HIGH_BITS) >= 0) 
    _2911 = NewDouble((double)_2911);
    if (IS_ATOM_INT(_2911)) {
        _2912 = _2911 - 1;
        if ((long)((unsigned long)_2912 +(unsigned long) HIGH_BITS) >= 0){
            _2912 = NewDouble((double)_2912);
        }
    }
    else {
        _2912 = NewDouble(DBL_PTR(_2911)->dbl - (double)1);
    }
    DeRef(_2911);
    _2911 = NOVALUE;
    if (IS_ATOM_INT(_2912)) {
        _lLimit_5631 = _2912 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2912, 2);
        _lLimit_5631 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2912);
    _2912 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_5631)) {
        _1 = (long)(DBL_PTR(_lLimit_5631)->dbl);
        DeRefDS(_lLimit_5631);
        _lLimit_5631 = _1;
    }

    /** 	t = target*/
    Ref(_target_5626);
    DeRef(_t_5632);
    _t_5632 = _target_5626;

    /** 	uppr = pTo*/
    _uppr_5629 = _pTo_5628;

    /** 	for lowr = pFrom to lLimit do*/
    _2914 = _lLimit_5631;
    {
        int _lowr_5651;
        _lowr_5651 = _pFrom_5627;
L7: 
        if (_lowr_5651 > _2914){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_5626);
        _2915 = (int)*(((s1_ptr)_2)->base + _lowr_5651);
        Ref(_2915);
        _2 = (int)SEQ_PTR(_t_5632);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5632 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_5629);
        _1 = *(int *)_2;
        *(int *)_2 = _2915;
        if( _1 != _2915 ){
            DeRef(_1);
        }
        _2915 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_5626);
        _2916 = (int)*(((s1_ptr)_2)->base + _uppr_5629);
        Ref(_2916);
        _2 = (int)SEQ_PTR(_t_5632);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5632 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_5651);
        _1 = *(int *)_2;
        *(int *)_2 = _2916;
        if( _1 != _2916 ){
            DeRef(_1);
        }
        _2916 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_5629 = _uppr_5629 - 1;

        /** 	end for*/
        _lowr_5651 = _lowr_5651 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_5626);
    DeRef(_2907);
    _2907 = NOVALUE;
    return _t_5632;
    ;
}


int  __stdcall _23shuffle(int _seq_5658)
{
    int _fromIdx_5662 = NOVALUE;
    int _swapValue_5664 = NOVALUE;
    int _2921 = NOVALUE;
    int _2918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for toIdx = length(seq) to 2 by -1 do*/
    if (IS_SEQUENCE(_seq_5658)){
            _2918 = SEQ_PTR(_seq_5658)->length;
    }
    else {
        _2918 = 1;
    }
    {
        int _toIdx_5660;
        _toIdx_5660 = _2918;
L1: 
        if (_toIdx_5660 < 2){
            goto L2; // [6] 49
        }

        /** 		integer fromIdx = rand(toIdx)*/
        _fromIdx_5662 = good_rand() % ((unsigned)_toIdx_5660) + 1;

        /** 		object swapValue = seq[fromIdx]*/
        DeRef(_swapValue_5664);
        _2 = (int)SEQ_PTR(_seq_5658);
        _swapValue_5664 = (int)*(((s1_ptr)_2)->base + _fromIdx_5662);
        Ref(_swapValue_5664);

        /** 		seq[fromIdx] = seq[toIdx]*/
        _2 = (int)SEQ_PTR(_seq_5658);
        _2921 = (int)*(((s1_ptr)_2)->base + _toIdx_5660);
        Ref(_2921);
        _2 = (int)SEQ_PTR(_seq_5658);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_5658 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _fromIdx_5662);
        _1 = *(int *)_2;
        *(int *)_2 = _2921;
        if( _1 != _2921 ){
            DeRef(_1);
        }
        _2921 = NOVALUE;

        /** 		seq[toIdx] = swapValue*/
        Ref(_swapValue_5664);
        _2 = (int)SEQ_PTR(_seq_5658);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_5658 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _toIdx_5660);
        _1 = *(int *)_2;
        *(int *)_2 = _swapValue_5664;
        DeRef(_1);
        DeRef(_swapValue_5664);
        _swapValue_5664 = NOVALUE;

        /** 	end for*/
        _toIdx_5660 = _toIdx_5660 + -1;
        goto L1; // [44] 13
L2: 
        ;
    }

    /** 	return seq*/
    return _seq_5658;
    ;
}


int  __stdcall _23series(int _start_5669, int _increment_5670, int _count_5671, int _op_5672)
{
    int _result_5673 = NOVALUE;
    int _2932 = NOVALUE;
    int _2929 = NOVALUE;
    int _2923 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_5671)) {
        _1 = (long)(DBL_PTR(_count_5671)->dbl);
        DeRefDS(_count_5671);
        _count_5671 = _1;
    }
    if (!IS_ATOM_INT(_op_5672)) {
        _1 = (long)(DBL_PTR(_op_5672)->dbl);
        DeRefDS(_op_5672);
        _op_5672 = _1;
    }

    /** 	if count < 0 then*/
    if (_count_5671 >= 0)
    goto L1; // [7] 18

    /** 		return 0*/
    DeRef(_start_5669);
    DeRef(_increment_5670);
    DeRef(_result_5673);
    return 0;
L1: 

    /** 	if not binop_ok(start, increment) then*/
    Ref(_start_5669);
    Ref(_increment_5670);
    _2923 = _23binop_ok(_start_5669, _increment_5670);
    if (IS_ATOM_INT(_2923)) {
        if (_2923 != 0){
            DeRef(_2923);
            _2923 = NOVALUE;
            goto L2; // [25] 35
        }
    }
    else {
        if (DBL_PTR(_2923)->dbl != 0.0){
            DeRef(_2923);
            _2923 = NOVALUE;
            goto L2; // [25] 35
        }
    }
    DeRef(_2923);
    _2923 = NOVALUE;

    /** 		return 0*/
    DeRef(_start_5669);
    DeRef(_increment_5670);
    DeRef(_result_5673);
    return 0;
L2: 

    /** 	if count = 0 then*/
    if (_count_5671 != 0)
    goto L3; // [37] 48

    /** 		return {}*/
    RefDS(_5);
    DeRef(_start_5669);
    DeRef(_increment_5670);
    DeRef(_result_5673);
    return _5;
L3: 

    /** 	result = repeat(0, count )*/
    DeRef(_result_5673);
    _result_5673 = Repeat(0, _count_5671);

    /** 	result[1] = start*/
    Ref(_start_5669);
    _2 = (int)SEQ_PTR(_result_5673);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_5673 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _start_5669;

    /** 	switch op do*/
    _0 = _op_5672;
    switch ( _0 ){ 

        /** 		case '+' then*/
        case 43:

        /** 			for i = 2 to count  do*/
        _2929 = _count_5671;
        {
            int _i_5686;
            _i_5686 = 2;
L4: 
            if (_i_5686 > _2929){
                goto L5; // [76] 102
            }

            /** 				start += increment*/
            _0 = _start_5669;
            if (IS_ATOM_INT(_start_5669) && IS_ATOM_INT(_increment_5670)) {
                _start_5669 = _start_5669 + _increment_5670;
                if ((long)((unsigned long)_start_5669 + (unsigned long)HIGH_BITS) >= 0) 
                _start_5669 = NewDouble((double)_start_5669);
            }
            else {
                _start_5669 = binary_op(PLUS, _start_5669, _increment_5670);
            }
            DeRef(_0);

            /** 				result[i] = start*/
            Ref(_start_5669);
            _2 = (int)SEQ_PTR(_result_5673);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5673 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5686);
            _1 = *(int *)_2;
            *(int *)_2 = _start_5669;
            DeRef(_1);

            /** 			end for*/
            _i_5686 = _i_5686 + 1;
            goto L4; // [97] 83
L5: 
            ;
        }
        goto L6; // [102] 152

        /** 		case '*' then*/
        case 42:

        /** 			for i = 2 to count do*/
        _2932 = _count_5671;
        {
            int _i_5692;
            _i_5692 = 2;
L7: 
            if (_i_5692 > _2932){
                goto L8; // [113] 139
            }

            /** 				start *= increment*/
            _0 = _start_5669;
            if (IS_ATOM_INT(_start_5669) && IS_ATOM_INT(_increment_5670)) {
                if (_start_5669 == (short)_start_5669 && _increment_5670 <= INT15 && _increment_5670 >= -INT15)
                _start_5669 = _start_5669 * _increment_5670;
                else
                _start_5669 = NewDouble(_start_5669 * (double)_increment_5670);
            }
            else {
                _start_5669 = binary_op(MULTIPLY, _start_5669, _increment_5670);
            }
            DeRef(_0);

            /** 				result[i] = start*/
            Ref(_start_5669);
            _2 = (int)SEQ_PTR(_result_5673);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5673 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5692);
            _1 = *(int *)_2;
            *(int *)_2 = _start_5669;
            DeRef(_1);

            /** 			end for*/
            _i_5692 = _i_5692 + 1;
            goto L7; // [134] 120
L8: 
            ;
        }
        goto L6; // [139] 152

        /** 		case else*/
        default:

        /** 			return 0*/
        DeRef(_start_5669);
        DeRef(_increment_5670);
        DeRef(_result_5673);
        return 0;
    ;}L6: 

    /** 	return result*/
    DeRef(_start_5669);
    DeRef(_increment_5670);
    return _result_5673;
    ;
}


int  __stdcall _23repeat_pattern(int _pattern_5698, int _count_5699)
{
    int _ls_5700 = NOVALUE;
    int _result_5701 = NOVALUE;
    int _2941 = NOVALUE;
    int _2940 = NOVALUE;
    int _2939 = NOVALUE;
    int _2938 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_5699)) {
        _1 = (long)(DBL_PTR(_count_5699)->dbl);
        DeRefDS(_count_5699);
        _count_5699 = _1;
    }

    /** 	if count<=0 then*/
    if (_count_5699 > 0)
    goto L1; // [5] 16

    /** 		return {}*/
    RefDS(_5);
    DeRef(_pattern_5698);
    DeRef(_result_5701);
    return _5;
L1: 

    /** 	ls = length(pattern)*/
    if (IS_SEQUENCE(_pattern_5698)){
            _ls_5700 = SEQ_PTR(_pattern_5698)->length;
    }
    else {
        _ls_5700 = 1;
    }

    /** 	count *= ls*/
    _count_5699 = _count_5699 * _ls_5700;

    /** 	result=repeat(0,count)*/
    DeRef(_result_5701);
    _result_5701 = Repeat(0, _count_5699);

    /** 	for i=1 to count by ls do*/
    _2938 = _ls_5700;
    _2939 = _count_5699;
    {
        int _i_5708;
        _i_5708 = 1;
L2: 
        if (_i_5708 > _2939){
            goto L3; // [43] 72
        }

        /** 		result[i..i+ls-1] = pattern*/
        _2940 = _i_5708 + _ls_5700;
        if ((long)((unsigned long)_2940 + (unsigned long)HIGH_BITS) >= 0) 
        _2940 = NewDouble((double)_2940);
        if (IS_ATOM_INT(_2940)) {
            _2941 = _2940 - 1;
        }
        else {
            _2941 = NewDouble(DBL_PTR(_2940)->dbl - (double)1);
        }
        DeRef(_2940);
        _2940 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_result_5701;
        AssignSlice(_i_5708, _2941, _pattern_5698);
        DeRef(_2941);
        _2941 = NOVALUE;

        /** 	end for*/
        _i_5708 = _i_5708 + _2938;
        goto L2; // [67] 50
L3: 
        ;
    }

    /** 	return result*/
    DeRef(_pattern_5698);
    return _result_5701;
    ;
}


int  __stdcall _23pad_head(int _target_5715, int _size_5716, int _ch_5717)
{
    int _2947 = NOVALUE;
    int _2946 = NOVALUE;
    int _2945 = NOVALUE;
    int _2944 = NOVALUE;
    int _2942 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_5716)) {
        _1 = (long)(DBL_PTR(_size_5716)->dbl);
        DeRefDS(_size_5716);
        _size_5716 = _1;
    }

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_5715)){
            _2942 = SEQ_PTR(_target_5715)->length;
    }
    else {
        _2942 = 1;
    }
    if (_size_5716 > _2942)
    goto L1; // [8] 19

    /** 		return target*/
    DeRef(_ch_5717);
    return _target_5715;
L1: 

    /** 	return repeat(ch, size - length(target)) & target*/
    if (IS_SEQUENCE(_target_5715)){
            _2944 = SEQ_PTR(_target_5715)->length;
    }
    else {
        _2944 = 1;
    }
    _2945 = _size_5716 - _2944;
    _2944 = NOVALUE;
    _2946 = Repeat(_ch_5717, _2945);
    _2945 = NOVALUE;
    if (IS_SEQUENCE(_2946) && IS_ATOM(_target_5715)) {
        Ref(_target_5715);
        Append(&_2947, _2946, _target_5715);
    }
    else if (IS_ATOM(_2946) && IS_SEQUENCE(_target_5715)) {
    }
    else {
        Concat((object_ptr)&_2947, _2946, _target_5715);
        DeRefDS(_2946);
        _2946 = NOVALUE;
    }
    DeRef(_2946);
    _2946 = NOVALUE;
    DeRef(_target_5715);
    DeRef(_ch_5717);
    return _2947;
    ;
}


int  __stdcall _23pad_tail(int _target_5727, int _size_5728, int _ch_5729)
{
    int _2953 = NOVALUE;
    int _2952 = NOVALUE;
    int _2951 = NOVALUE;
    int _2950 = NOVALUE;
    int _2948 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_5728)) {
        _1 = (long)(DBL_PTR(_size_5728)->dbl);
        DeRefDS(_size_5728);
        _size_5728 = _1;
    }

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_5727)){
            _2948 = SEQ_PTR(_target_5727)->length;
    }
    else {
        _2948 = 1;
    }
    if (_size_5728 > _2948)
    goto L1; // [8] 19

    /** 		return target*/
    DeRef(_ch_5729);
    return _target_5727;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_5727)){
            _2950 = SEQ_PTR(_target_5727)->length;
    }
    else {
        _2950 = 1;
    }
    _2951 = _size_5728 - _2950;
    _2950 = NOVALUE;
    _2952 = Repeat(_ch_5729, _2951);
    _2951 = NOVALUE;
    if (IS_SEQUENCE(_target_5727) && IS_ATOM(_2952)) {
    }
    else if (IS_ATOM(_target_5727) && IS_SEQUENCE(_2952)) {
        Ref(_target_5727);
        Prepend(&_2953, _2952, _target_5727);
    }
    else {
        Concat((object_ptr)&_2953, _target_5727, _2952);
    }
    DeRefDS(_2952);
    _2952 = NOVALUE;
    DeRef(_target_5727);
    DeRef(_ch_5729);
    return _2953;
    ;
}


int  __stdcall _23add_item(int _needle_5739, int _haystack_5740, int _pOrder_5741)
{
    int _msg_inlined_crash_at_108_5759 = NOVALUE;
    int _2962 = NOVALUE;
    int _2961 = NOVALUE;
    int _2960 = NOVALUE;
    int _2959 = NOVALUE;
    int _2958 = NOVALUE;
    int _2957 = NOVALUE;
    int _2954 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pOrder_5741)) {
        _1 = (long)(DBL_PTR(_pOrder_5741)->dbl);
        DeRefDS(_pOrder_5741);
        _pOrder_5741 = _1;
    }

    /** 	if find(needle, haystack) then*/
    _2954 = find_from(_needle_5739, _haystack_5740, 1);
    if (_2954 == 0)
    {
        _2954 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _2954 = NOVALUE;
    }

    /** 		return haystack*/
    DeRef(_needle_5739);
    return _haystack_5740;
L1: 

    /** 	switch pOrder do*/
    _0 = _pOrder_5741;
    switch ( _0 ){ 

        /** 		case ADD_PREPEND then*/
        case 1:

        /** 			return prepend(haystack, needle)*/
        Ref(_needle_5739);
        Prepend(&_2957, _haystack_5740, _needle_5739);
        DeRef(_needle_5739);
        DeRefDS(_haystack_5740);
        return _2957;
        goto L2; // [43] 128

        /** 		case ADD_APPEND then*/
        case 2:

        /** 			return append(haystack, needle)*/
        Ref(_needle_5739);
        Append(&_2958, _haystack_5740, _needle_5739);
        DeRef(_needle_5739);
        DeRefDS(_haystack_5740);
        DeRef(_2957);
        _2957 = NOVALUE;
        return _2958;
        goto L2; // [59] 128

        /** 		case ADD_SORT_UP then*/
        case 3:

        /** 			return stdsort:sort(append(haystack, needle))*/
        Ref(_needle_5739);
        Append(&_2959, _haystack_5740, _needle_5739);
        _2960 = _24sort(_2959, 1);
        _2959 = NOVALUE;
        DeRef(_needle_5739);
        DeRefDS(_haystack_5740);
        DeRef(_2957);
        _2957 = NOVALUE;
        DeRef(_2958);
        _2958 = NOVALUE;
        return _2960;
        goto L2; // [80] 128

        /** 		case ADD_SORT_DOWN then*/
        case 4:

        /** 			return stdsort:sort(append(haystack, needle), stdsort:DESCENDING)*/
        Ref(_needle_5739);
        Append(&_2961, _haystack_5740, _needle_5739);
        _2962 = _24sort(_2961, -1);
        _2961 = NOVALUE;
        DeRef(_needle_5739);
        DeRefDS(_haystack_5740);
        DeRef(_2957);
        _2957 = NOVALUE;
        DeRef(_2958);
        _2958 = NOVALUE;
        DeRef(_2960);
        _2960 = NOVALUE;
        return _2962;
        goto L2; // [101] 128

        /** 		case else*/
        default:

        /** 			error:crash("sequence.e:add_item() invalid Order argument '%d'", pOrder)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_108_5759);
        _msg_inlined_crash_at_108_5759 = EPrintf(-9999999, _2963, _pOrder_5741);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_108_5759);

        /** end procedure*/
        goto L3; // [122] 125
L3: 
        DeRefi(_msg_inlined_crash_at_108_5759);
        _msg_inlined_crash_at_108_5759 = NOVALUE;
    ;}L2: 

    /** 	return haystack*/
    DeRef(_needle_5739);
    DeRef(_2957);
    _2957 = NOVALUE;
    DeRef(_2958);
    _2958 = NOVALUE;
    DeRef(_2960);
    _2960 = NOVALUE;
    DeRef(_2962);
    _2962 = NOVALUE;
    return _haystack_5740;
    ;
}


int  __stdcall _23remove_item(int _needle_5762, int _haystack_5763)
{
    int _lIdx_5764 = NOVALUE;
    int _2979 = NOVALUE;
    int _2978 = NOVALUE;
    int _2977 = NOVALUE;
    int _2976 = NOVALUE;
    int _2975 = NOVALUE;
    int _2974 = NOVALUE;
    int _2973 = NOVALUE;
    int _2972 = NOVALUE;
    int _2971 = NOVALUE;
    int _2969 = NOVALUE;
    int _2968 = NOVALUE;
    int _2967 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lIdx = find(needle, haystack)*/
    _lIdx_5764 = find_from(_needle_5762, _haystack_5763, 1);

    /** 	if not lIdx then*/
    if (_lIdx_5764 != 0)
    goto L1; // [12] 22

    /** 		return haystack*/
    DeRef(_needle_5762);
    return _haystack_5763;
L1: 

    /** 	if lIdx = 1 then*/
    if (_lIdx_5764 != 1)
    goto L2; // [24] 45

    /** 		return haystack[2 .. $]*/
    if (IS_SEQUENCE(_haystack_5763)){
            _2967 = SEQ_PTR(_haystack_5763)->length;
    }
    else {
        _2967 = 1;
    }
    rhs_slice_target = (object_ptr)&_2968;
    RHS_Slice(_haystack_5763, 2, _2967);
    DeRef(_needle_5762);
    DeRefDS(_haystack_5763);
    return _2968;
    goto L3; // [42] 107
L2: 

    /** 	elsif lIdx = length(haystack) then*/
    if (IS_SEQUENCE(_haystack_5763)){
            _2969 = SEQ_PTR(_haystack_5763)->length;
    }
    else {
        _2969 = 1;
    }
    if (_lIdx_5764 != _2969)
    goto L4; // [50] 75

    /** 		return haystack[1 .. $-1]*/
    if (IS_SEQUENCE(_haystack_5763)){
            _2971 = SEQ_PTR(_haystack_5763)->length;
    }
    else {
        _2971 = 1;
    }
    _2972 = _2971 - 1;
    _2971 = NOVALUE;
    rhs_slice_target = (object_ptr)&_2973;
    RHS_Slice(_haystack_5763, 1, _2972);
    DeRef(_needle_5762);
    DeRefDS(_haystack_5763);
    DeRef(_2968);
    _2968 = NOVALUE;
    _2972 = NOVALUE;
    return _2973;
    goto L3; // [72] 107
L4: 

    /** 		return haystack[1 .. lIdx - 1] & haystack[lIdx + 1 .. $]*/
    _2974 = _lIdx_5764 - 1;
    rhs_slice_target = (object_ptr)&_2975;
    RHS_Slice(_haystack_5763, 1, _2974);
    _2976 = _lIdx_5764 + 1;
    if (_2976 > MAXINT){
        _2976 = NewDouble((double)_2976);
    }
    if (IS_SEQUENCE(_haystack_5763)){
            _2977 = SEQ_PTR(_haystack_5763)->length;
    }
    else {
        _2977 = 1;
    }
    rhs_slice_target = (object_ptr)&_2978;
    RHS_Slice(_haystack_5763, _2976, _2977);
    Concat((object_ptr)&_2979, _2975, _2978);
    DeRefDS(_2975);
    _2975 = NOVALUE;
    DeRef(_2975);
    _2975 = NOVALUE;
    DeRefDS(_2978);
    _2978 = NOVALUE;
    DeRef(_needle_5762);
    DeRefDS(_haystack_5763);
    DeRef(_2968);
    _2968 = NOVALUE;
    DeRef(_2972);
    _2972 = NOVALUE;
    DeRef(_2973);
    _2973 = NOVALUE;
    _2974 = NOVALUE;
    DeRef(_2976);
    _2976 = NOVALUE;
    return _2979;
L3: 
    ;
}


int  __stdcall _23mid(int _source_5787, int _start_5788, int _len_5789)
{
    int _msg_inlined_crash_at_45_5804 = NOVALUE;
    int _data_inlined_crash_at_42_5803 = NOVALUE;
    int _3003 = NOVALUE;
    int _3002 = NOVALUE;
    int _3001 = NOVALUE;
    int _3000 = NOVALUE;
    int _2999 = NOVALUE;
    int _2997 = NOVALUE;
    int _2996 = NOVALUE;
    int _2995 = NOVALUE;
    int _2993 = NOVALUE;
    int _2991 = NOVALUE;
    int _2990 = NOVALUE;
    int _2989 = NOVALUE;
    int _2988 = NOVALUE;
    int _2987 = NOVALUE;
    int _2986 = NOVALUE;
    int _2985 = NOVALUE;
    int _2981 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if len<0 then*/
    if (binary_op_a(GREATEREQ, _len_5789, 0)){
        goto L1; // [5] 66
    }

    /** 		len += length(source)*/
    if (IS_SEQUENCE(_source_5787)){
            _2981 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2981 = 1;
    }
    _0 = _len_5789;
    if (IS_ATOM_INT(_len_5789)) {
        _len_5789 = _len_5789 + _2981;
        if ((long)((unsigned long)_len_5789 + (unsigned long)HIGH_BITS) >= 0) 
        _len_5789 = NewDouble((double)_len_5789);
    }
    else {
        _len_5789 = NewDouble(DBL_PTR(_len_5789)->dbl + (double)_2981);
    }
    DeRef(_0);
    _2981 = NOVALUE;

    /** 		if len<0 then*/
    if (binary_op_a(GREATEREQ, _len_5789, 0)){
        goto L2; // [20] 65
    }

    /** 			error:crash("mid(): len was %d and should be greater than %d.",*/
    if (IS_SEQUENCE(_source_5787)){
            _2985 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2985 = 1;
    }
    if (IS_ATOM_INT(_len_5789)) {
        _2986 = _len_5789 - _2985;
        if ((long)((unsigned long)_2986 +(unsigned long) HIGH_BITS) >= 0){
            _2986 = NewDouble((double)_2986);
        }
    }
    else {
        _2986 = NewDouble(DBL_PTR(_len_5789)->dbl - (double)_2985);
    }
    _2985 = NOVALUE;
    if (IS_SEQUENCE(_source_5787)){
            _2987 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2987 = 1;
    }
    _2988 = - _2987;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _2986;
    ((int *)_2)[2] = _2988;
    _2989 = MAKE_SEQ(_1);
    _2988 = NOVALUE;
    _2986 = NOVALUE;
    DeRef(_data_inlined_crash_at_42_5803);
    _data_inlined_crash_at_42_5803 = _2989;
    _2989 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_45_5804);
    _msg_inlined_crash_at_45_5804 = EPrintf(-9999999, _2984, _data_inlined_crash_at_42_5803);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_45_5804);

    /** end procedure*/
    goto L3; // [59] 62
L3: 
    DeRef(_data_inlined_crash_at_42_5803);
    _data_inlined_crash_at_42_5803 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_45_5804);
    _msg_inlined_crash_at_45_5804 = NOVALUE;
L2: 
L1: 

    /** 	if start > length(source) or len=0 then*/
    if (IS_SEQUENCE(_source_5787)){
            _2990 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2990 = 1;
    }
    if (IS_ATOM_INT(_start_5788)) {
        _2991 = (_start_5788 > _2990);
    }
    else {
        _2991 = (DBL_PTR(_start_5788)->dbl > (double)_2990);
    }
    _2990 = NOVALUE;
    if (_2991 != 0) {
        goto L4; // [75] 88
    }
    if (IS_ATOM_INT(_len_5789)) {
        _2993 = (_len_5789 == 0);
    }
    else {
        _2993 = (DBL_PTR(_len_5789)->dbl == (double)0);
    }
    if (_2993 == 0)
    {
        DeRef(_2993);
        _2993 = NOVALUE;
        goto L5; // [84] 95
    }
    else{
        DeRef(_2993);
        _2993 = NOVALUE;
    }
L4: 

    /** 		return ""*/
    RefDS(_5);
    DeRefDS(_source_5787);
    DeRef(_start_5788);
    DeRef(_len_5789);
    DeRef(_2991);
    _2991 = NOVALUE;
    return _5;
L5: 

    /** 	if start<1 then*/
    if (binary_op_a(GREATEREQ, _start_5788, 1)){
        goto L6; // [97] 107
    }

    /** 		start=1*/
    DeRef(_start_5788);
    _start_5788 = 1;
L6: 

    /** 	if start+len-1 >= length(source) then*/
    if (IS_ATOM_INT(_start_5788) && IS_ATOM_INT(_len_5789)) {
        _2995 = _start_5788 + _len_5789;
        if ((long)((unsigned long)_2995 + (unsigned long)HIGH_BITS) >= 0) 
        _2995 = NewDouble((double)_2995);
    }
    else {
        if (IS_ATOM_INT(_start_5788)) {
            _2995 = NewDouble((double)_start_5788 + DBL_PTR(_len_5789)->dbl);
        }
        else {
            if (IS_ATOM_INT(_len_5789)) {
                _2995 = NewDouble(DBL_PTR(_start_5788)->dbl + (double)_len_5789);
            }
            else
            _2995 = NewDouble(DBL_PTR(_start_5788)->dbl + DBL_PTR(_len_5789)->dbl);
        }
    }
    if (IS_ATOM_INT(_2995)) {
        _2996 = _2995 - 1;
        if ((long)((unsigned long)_2996 +(unsigned long) HIGH_BITS) >= 0){
            _2996 = NewDouble((double)_2996);
        }
    }
    else {
        _2996 = NewDouble(DBL_PTR(_2995)->dbl - (double)1);
    }
    DeRef(_2995);
    _2995 = NOVALUE;
    if (IS_SEQUENCE(_source_5787)){
            _2997 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2997 = 1;
    }
    if (binary_op_a(LESS, _2996, _2997)){
        DeRef(_2996);
        _2996 = NOVALUE;
        _2997 = NOVALUE;
        goto L7; // [120] 141
    }
    DeRef(_2996);
    _2996 = NOVALUE;
    _2997 = NOVALUE;

    /** 		return source[start..$]*/
    if (IS_SEQUENCE(_source_5787)){
            _2999 = SEQ_PTR(_source_5787)->length;
    }
    else {
        _2999 = 1;
    }
    rhs_slice_target = (object_ptr)&_3000;
    RHS_Slice(_source_5787, _start_5788, _2999);
    DeRefDS(_source_5787);
    DeRef(_start_5788);
    DeRef(_len_5789);
    DeRef(_2991);
    _2991 = NOVALUE;
    return _3000;
    goto L8; // [138] 161
L7: 

    /** 		return source[start..len+start-1]*/
    if (IS_ATOM_INT(_len_5789) && IS_ATOM_INT(_start_5788)) {
        _3001 = _len_5789 + _start_5788;
        if ((long)((unsigned long)_3001 + (unsigned long)HIGH_BITS) >= 0) 
        _3001 = NewDouble((double)_3001);
    }
    else {
        if (IS_ATOM_INT(_len_5789)) {
            _3001 = NewDouble((double)_len_5789 + DBL_PTR(_start_5788)->dbl);
        }
        else {
            if (IS_ATOM_INT(_start_5788)) {
                _3001 = NewDouble(DBL_PTR(_len_5789)->dbl + (double)_start_5788);
            }
            else
            _3001 = NewDouble(DBL_PTR(_len_5789)->dbl + DBL_PTR(_start_5788)->dbl);
        }
    }
    if (IS_ATOM_INT(_3001)) {
        _3002 = _3001 - 1;
    }
    else {
        _3002 = NewDouble(DBL_PTR(_3001)->dbl - (double)1);
    }
    DeRef(_3001);
    _3001 = NOVALUE;
    rhs_slice_target = (object_ptr)&_3003;
    RHS_Slice(_source_5787, _start_5788, _3002);
    DeRefDS(_source_5787);
    DeRef(_start_5788);
    DeRef(_len_5789);
    DeRef(_2991);
    _2991 = NOVALUE;
    DeRef(_3000);
    _3000 = NOVALUE;
    DeRef(_3002);
    _3002 = NOVALUE;
    return _3003;
L8: 
    ;
}


int  __stdcall _23slice(int _source_5825, int _start_5826, int _stop_5827)
{
    int _3012 = NOVALUE;
    int _3007 = NOVALUE;
    int _3005 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if stop < 1 then */
    if (binary_op_a(GREATEREQ, _stop_5827, 1)){
        goto L1; // [5] 21
    }

    /** 		stop += length(source) */
    if (IS_SEQUENCE(_source_5825)){
            _3005 = SEQ_PTR(_source_5825)->length;
    }
    else {
        _3005 = 1;
    }
    _0 = _stop_5827;
    if (IS_ATOM_INT(_stop_5827)) {
        _stop_5827 = _stop_5827 + _3005;
        if ((long)((unsigned long)_stop_5827 + (unsigned long)HIGH_BITS) >= 0) 
        _stop_5827 = NewDouble((double)_stop_5827);
    }
    else {
        _stop_5827 = NewDouble(DBL_PTR(_stop_5827)->dbl + (double)_3005);
    }
    DeRef(_0);
    _3005 = NOVALUE;
    goto L2; // [18] 37
L1: 

    /** 	elsif stop > length(source) then */
    if (IS_SEQUENCE(_source_5825)){
            _3007 = SEQ_PTR(_source_5825)->length;
    }
    else {
        _3007 = 1;
    }
    if (binary_op_a(LESSEQ, _stop_5827, _3007)){
        _3007 = NOVALUE;
        goto L3; // [26] 36
    }
    _3007 = NOVALUE;

    /** 		stop = length(source) */
    DeRef(_stop_5827);
    if (IS_SEQUENCE(_source_5825)){
            _stop_5827 = SEQ_PTR(_source_5825)->length;
    }
    else {
        _stop_5827 = 1;
    }
L3: 
L2: 

    /** 	if start < 1 then */
    if (binary_op_a(GREATEREQ, _start_5826, 1)){
        goto L4; // [39] 49
    }

    /** 		start = 1 */
    DeRef(_start_5826);
    _start_5826 = 1;
L4: 

    /** 	if start > stop then*/
    if (binary_op_a(LESSEQ, _start_5826, _stop_5827)){
        goto L5; // [51] 62
    }

    /** 		return ""*/
    RefDS(_5);
    DeRefDS(_source_5825);
    DeRef(_start_5826);
    DeRef(_stop_5827);
    return _5;
L5: 

    /** 	return source[start..stop]*/
    rhs_slice_target = (object_ptr)&_3012;
    RHS_Slice(_source_5825, _start_5826, _stop_5827);
    DeRefDS(_source_5825);
    DeRef(_start_5826);
    DeRef(_stop_5827);
    return _3012;
    ;
}


int  __stdcall _23vslice(int _source_5843, int _colno_5844, int _error_control_5845)
{
    int _substitutes_5846 = NOVALUE;
    int _current_sub_5847 = NOVALUE;
    int _msg_inlined_crash_at_10_5852 = NOVALUE;
    int _msg_inlined_crash_at_103_5872 = NOVALUE;
    int _data_inlined_crash_at_100_5871 = NOVALUE;
    int _3036 = NOVALUE;
    int _3035 = NOVALUE;
    int _3034 = NOVALUE;
    int _3033 = NOVALUE;
    int _3032 = NOVALUE;
    int _3030 = NOVALUE;
    int _3028 = NOVALUE;
    int _3027 = NOVALUE;
    int _3025 = NOVALUE;
    int _3021 = NOVALUE;
    int _3020 = NOVALUE;
    int _3019 = NOVALUE;
    int _3016 = NOVALUE;
    int _3015 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if colno < 1 then*/
    if (binary_op_a(GREATEREQ, _colno_5844, 1)){
        goto L1; // [5] 30
    }

    /** 		error:crash("sequence:vslice(): colno should be a valid index, but was %d",colno)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_10_5852);
    _msg_inlined_crash_at_10_5852 = EPrintf(-9999999, _3014, _colno_5844);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_10_5852);

    /** end procedure*/
    goto L2; // [24] 27
L2: 
    DeRefi(_msg_inlined_crash_at_10_5852);
    _msg_inlined_crash_at_10_5852 = NOVALUE;
L1: 

    /** 	if atom(error_control) then*/
    _3015 = IS_ATOM(_error_control_5845);
    if (_3015 == 0)
    {
        _3015 = NOVALUE;
        goto L3; // [35] 51
    }
    else{
        _3015 = NOVALUE;
    }

    /** 		substitutes =-(not error_control)*/
    if (IS_ATOM_INT(_error_control_5845)) {
        _3016 = (_error_control_5845 == 0);
    }
    else {
        _3016 = unary_op(NOT, _error_control_5845);
    }
    if (IS_ATOM_INT(_3016)) {
        if ((unsigned long)_3016 == 0xC0000000)
        _substitutes_5846 = (int)NewDouble((double)-0xC0000000);
        else
        _substitutes_5846 = - _3016;
    }
    else {
        _substitutes_5846 = unary_op(UMINUS, _3016);
    }
    DeRef(_3016);
    _3016 = NOVALUE;
    if (!IS_ATOM_INT(_substitutes_5846)) {
        _1 = (long)(DBL_PTR(_substitutes_5846)->dbl);
        DeRefDS(_substitutes_5846);
        _substitutes_5846 = _1;
    }
    goto L4; // [48] 62
L3: 

    /** 		substitutes = length(error_control)*/
    if (IS_SEQUENCE(_error_control_5845)){
            _substitutes_5846 = SEQ_PTR(_error_control_5845)->length;
    }
    else {
        _substitutes_5846 = 1;
    }

    /** 		current_sub = 0*/
    _current_sub_5847 = 0;
L4: 

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5843)){
            _3019 = SEQ_PTR(_source_5843)->length;
    }
    else {
        _3019 = 1;
    }
    {
        int _i_5860;
        _i_5860 = 1;
L5: 
        if (_i_5860 > _3019){
            goto L6; // [67] 221
        }

        /** 		if colno > length(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5843);
        _3020 = (int)*(((s1_ptr)_2)->base + _i_5860);
        if (IS_SEQUENCE(_3020)){
                _3021 = SEQ_PTR(_3020)->length;
        }
        else {
            _3021 = 1;
        }
        _3020 = NOVALUE;
        if (binary_op_a(LESSEQ, _colno_5844, _3021)){
            _3021 = NOVALUE;
            goto L7; // [83] 186
        }
        _3021 = NOVALUE;

        /** 			if substitutes = -1 then*/
        if (_substitutes_5846 != -1)
        goto L8; // [91] 125

        /** 				error:crash("sequence:vslice(): colno should be a valid index on the %d-th element, but was %d", {i, colno})*/
        Ref(_colno_5844);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_5860;
        ((int *)_2)[2] = _colno_5844;
        _3025 = MAKE_SEQ(_1);
        DeRef(_data_inlined_crash_at_100_5871);
        _data_inlined_crash_at_100_5871 = _3025;
        _3025 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_103_5872);
        _msg_inlined_crash_at_103_5872 = EPrintf(-9999999, _3024, _data_inlined_crash_at_100_5871);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_103_5872);

        /** end procedure*/
        goto L9; // [117] 120
L9: 
        DeRef(_data_inlined_crash_at_100_5871);
        _data_inlined_crash_at_100_5871 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_103_5872);
        _msg_inlined_crash_at_103_5872 = NOVALUE;
        goto LA; // [122] 214
L8: 

        /** 			elsif substitutes = 0 then*/
        if (_substitutes_5846 != 0)
        goto LB; // [127] 149

        /** 				return source[1..i-1]*/
        _3027 = _i_5860 - 1;
        rhs_slice_target = (object_ptr)&_3028;
        RHS_Slice(_source_5843, 1, _3027);
        DeRefDS(_source_5843);
        DeRef(_colno_5844);
        DeRef(_error_control_5845);
        _3020 = NOVALUE;
        _3027 = NOVALUE;
        return _3028;
        goto LA; // [146] 214
LB: 

        /** 				current_sub += 1*/
        _current_sub_5847 = _current_sub_5847 + 1;

        /** 				if current_sub > length(error_control) then*/
        if (IS_SEQUENCE(_error_control_5845)){
                _3030 = SEQ_PTR(_error_control_5845)->length;
        }
        else {
            _3030 = 1;
        }
        if (_current_sub_5847 <= _3030)
        goto LC; // [162] 172

        /** 					current_sub = 1*/
        _current_sub_5847 = 1;
LC: 

        /** 				source[i] = error_control[current_sub]*/
        _2 = (int)SEQ_PTR(_error_control_5845);
        _3032 = (int)*(((s1_ptr)_2)->base + _current_sub_5847);
        Ref(_3032);
        _2 = (int)SEQ_PTR(_source_5843);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5843 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5860);
        _1 = *(int *)_2;
        *(int *)_2 = _3032;
        if( _1 != _3032 ){
            DeRef(_1);
        }
        _3032 = NOVALUE;
        goto LA; // [183] 214
L7: 

        /** 			if sequence(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5843);
        _3033 = (int)*(((s1_ptr)_2)->base + _i_5860);
        _3034 = IS_SEQUENCE(_3033);
        _3033 = NOVALUE;
        if (_3034 == 0)
        {
            _3034 = NOVALUE;
            goto LD; // [195] 213
        }
        else{
            _3034 = NOVALUE;
        }

        /** 				source[i] = source[i][colno]*/
        _2 = (int)SEQ_PTR(_source_5843);
        _3035 = (int)*(((s1_ptr)_2)->base + _i_5860);
        _2 = (int)SEQ_PTR(_3035);
        if (!IS_ATOM_INT(_colno_5844)){
            _3036 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_colno_5844)->dbl));
        }
        else{
            _3036 = (int)*(((s1_ptr)_2)->base + _colno_5844);
        }
        _3035 = NOVALUE;
        Ref(_3036);
        _2 = (int)SEQ_PTR(_source_5843);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5843 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5860);
        _1 = *(int *)_2;
        *(int *)_2 = _3036;
        if( _1 != _3036 ){
            DeRef(_1);
        }
        _3036 = NOVALUE;
LD: 
LA: 

        /** 	end for*/
        _i_5860 = _i_5860 + 1;
        goto L5; // [216] 74
L6: 
        ;
    }

    /** 	return source*/
    DeRef(_colno_5844);
    DeRef(_error_control_5845);
    _3020 = NOVALUE;
    DeRef(_3027);
    _3027 = NOVALUE;
    DeRef(_3028);
    _3028 = NOVALUE;
    return _source_5843;
    ;
}


int  __stdcall _23patch(int _target_5891, int _source_5892, int _start_5893, int _filler_5894)
{
    int _3074 = NOVALUE;
    int _3073 = NOVALUE;
    int _3072 = NOVALUE;
    int _3071 = NOVALUE;
    int _3070 = NOVALUE;
    int _3069 = NOVALUE;
    int _3068 = NOVALUE;
    int _3067 = NOVALUE;
    int _3065 = NOVALUE;
    int _3064 = NOVALUE;
    int _3062 = NOVALUE;
    int _3061 = NOVALUE;
    int _3060 = NOVALUE;
    int _3059 = NOVALUE;
    int _3058 = NOVALUE;
    int _3057 = NOVALUE;
    int _3056 = NOVALUE;
    int _3055 = NOVALUE;
    int _3054 = NOVALUE;
    int _3053 = NOVALUE;
    int _3052 = NOVALUE;
    int _3051 = NOVALUE;
    int _3048 = NOVALUE;
    int _3047 = NOVALUE;
    int _3046 = NOVALUE;
    int _3045 = NOVALUE;
    int _3044 = NOVALUE;
    int _3043 = NOVALUE;
    int _3042 = NOVALUE;
    int _3041 = NOVALUE;
    int _3040 = NOVALUE;
    int _3038 = NOVALUE;
    int _3037 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_5893)) {
        _1 = (long)(DBL_PTR(_start_5893)->dbl);
        DeRefDS(_start_5893);
        _start_5893 = _1;
    }

    /** 	if start + length(source) <= 0 then*/
    if (IS_SEQUENCE(_source_5892)){
            _3037 = SEQ_PTR(_source_5892)->length;
    }
    else {
        _3037 = 1;
    }
    _3038 = _start_5893 + _3037;
    if ((long)((unsigned long)_3038 + (unsigned long)HIGH_BITS) >= 0) 
    _3038 = NewDouble((double)_3038);
    _3037 = NOVALUE;
    if (binary_op_a(GREATER, _3038, 0)){
        DeRef(_3038);
        _3038 = NOVALUE;
        goto L1; // [16] 53
    }
    DeRef(_3038);
    _3038 = NOVALUE;

    /** 		return source & repeat(filler, -start-length(source))+1 & target*/
    if ((unsigned long)_start_5893 == 0xC0000000)
    _3040 = (int)NewDouble((double)-0xC0000000);
    else
    _3040 = - _start_5893;
    if (IS_SEQUENCE(_source_5892)){
            _3041 = SEQ_PTR(_source_5892)->length;
    }
    else {
        _3041 = 1;
    }
    if (IS_ATOM_INT(_3040)) {
        _3042 = _3040 - _3041;
    }
    else {
        _3042 = NewDouble(DBL_PTR(_3040)->dbl - (double)_3041);
    }
    DeRef(_3040);
    _3040 = NOVALUE;
    _3041 = NOVALUE;
    _3043 = Repeat(_filler_5894, _3042);
    DeRef(_3042);
    _3042 = NOVALUE;
    _3044 = binary_op(PLUS, 1, _3043);
    DeRefDS(_3043);
    _3043 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _target_5891;
        concat_list[1] = _3044;
        concat_list[2] = _source_5892;
        Concat_N((object_ptr)&_3045, concat_list, 3);
    }
    DeRefDS(_3044);
    _3044 = NOVALUE;
    DeRefDS(_target_5891);
    DeRefDS(_source_5892);
    DeRef(_filler_5894);
    return _3045;
    goto L2; // [50] 221
L1: 

    /** 	elsif start + length(source) <= length(target) then*/
    if (IS_SEQUENCE(_source_5892)){
            _3046 = SEQ_PTR(_source_5892)->length;
    }
    else {
        _3046 = 1;
    }
    _3047 = _start_5893 + _3046;
    if ((long)((unsigned long)_3047 + (unsigned long)HIGH_BITS) >= 0) 
    _3047 = NewDouble((double)_3047);
    _3046 = NOVALUE;
    if (IS_SEQUENCE(_target_5891)){
            _3048 = SEQ_PTR(_target_5891)->length;
    }
    else {
        _3048 = 1;
    }
    if (binary_op_a(GREATER, _3047, _3048)){
        DeRef(_3047);
        _3047 = NOVALUE;
        _3048 = NOVALUE;
        goto L3; // [65] 143
    }
    DeRef(_3047);
    _3047 = NOVALUE;
    _3048 = NOVALUE;

    /** 		if start<=0 then*/
    if (_start_5893 > 0)
    goto L4; // [71] 103

    /** 			return source & target[start+length(source)..$]*/
    if (IS_SEQUENCE(_source_5892)){
            _3051 = SEQ_PTR(_source_5892)->length;
    }
    else {
        _3051 = 1;
    }
    _3052 = _start_5893 + _3051;
    if ((long)((unsigned long)_3052 + (unsigned long)HIGH_BITS) >= 0) 
    _3052 = NewDouble((double)_3052);
    _3051 = NOVALUE;
    if (IS_SEQUENCE(_target_5891)){
            _3053 = SEQ_PTR(_target_5891)->length;
    }
    else {
        _3053 = 1;
    }
    rhs_slice_target = (object_ptr)&_3054;
    RHS_Slice(_target_5891, _3052, _3053);
    Concat((object_ptr)&_3055, _source_5892, _3054);
    DeRefDS(_3054);
    _3054 = NOVALUE;
    DeRefDS(_target_5891);
    DeRefDS(_source_5892);
    DeRef(_filler_5894);
    DeRef(_3045);
    _3045 = NOVALUE;
    DeRef(_3052);
    _3052 = NOVALUE;
    return _3055;
    goto L2; // [100] 221
L4: 

    /**         	return target[1..start-1] & source &  target[start+length(source)..$]*/
    _3056 = _start_5893 - 1;
    rhs_slice_target = (object_ptr)&_3057;
    RHS_Slice(_target_5891, 1, _3056);
    if (IS_SEQUENCE(_source_5892)){
            _3058 = SEQ_PTR(_source_5892)->length;
    }
    else {
        _3058 = 1;
    }
    _3059 = _start_5893 + _3058;
    if ((long)((unsigned long)_3059 + (unsigned long)HIGH_BITS) >= 0) 
    _3059 = NewDouble((double)_3059);
    _3058 = NOVALUE;
    if (IS_SEQUENCE(_target_5891)){
            _3060 = SEQ_PTR(_target_5891)->length;
    }
    else {
        _3060 = 1;
    }
    rhs_slice_target = (object_ptr)&_3061;
    RHS_Slice(_target_5891, _3059, _3060);
    {
        int concat_list[3];

        concat_list[0] = _3061;
        concat_list[1] = _source_5892;
        concat_list[2] = _3057;
        Concat_N((object_ptr)&_3062, concat_list, 3);
    }
    DeRefDS(_3061);
    _3061 = NOVALUE;
    DeRefDS(_3057);
    _3057 = NOVALUE;
    DeRefDS(_target_5891);
    DeRefDS(_source_5892);
    DeRef(_filler_5894);
    DeRef(_3045);
    _3045 = NOVALUE;
    DeRef(_3052);
    _3052 = NOVALUE;
    DeRef(_3055);
    _3055 = NOVALUE;
    _3056 = NOVALUE;
    DeRef(_3059);
    _3059 = NOVALUE;
    return _3062;
    goto L2; // [140] 221
L3: 

    /** 	elsif start <= 1 then*/
    if (_start_5893 > 1)
    goto L5; // [145] 158

    /** 		return source*/
    DeRefDS(_target_5891);
    DeRef(_filler_5894);
    DeRef(_3045);
    _3045 = NOVALUE;
    DeRef(_3052);
    _3052 = NOVALUE;
    DeRef(_3055);
    _3055 = NOVALUE;
    DeRef(_3056);
    _3056 = NOVALUE;
    DeRef(_3062);
    _3062 = NOVALUE;
    DeRef(_3059);
    _3059 = NOVALUE;
    return _source_5892;
    goto L2; // [155] 221
L5: 

    /** 	elsif start <= length(target)+1 then*/
    if (IS_SEQUENCE(_target_5891)){
            _3064 = SEQ_PTR(_target_5891)->length;
    }
    else {
        _3064 = 1;
    }
    _3065 = _3064 + 1;
    _3064 = NOVALUE;
    if (_start_5893 > _3065)
    goto L6; // [167] 193

    /** 		return target[1..start-1] & source*/
    _3067 = _start_5893 - 1;
    rhs_slice_target = (object_ptr)&_3068;
    RHS_Slice(_target_5891, 1, _3067);
    Concat((object_ptr)&_3069, _3068, _source_5892);
    DeRefDS(_3068);
    _3068 = NOVALUE;
    DeRef(_3068);
    _3068 = NOVALUE;
    DeRefDS(_target_5891);
    DeRefDS(_source_5892);
    DeRef(_filler_5894);
    DeRef(_3045);
    _3045 = NOVALUE;
    DeRef(_3052);
    _3052 = NOVALUE;
    DeRef(_3055);
    _3055 = NOVALUE;
    DeRef(_3056);
    _3056 = NOVALUE;
    DeRef(_3062);
    _3062 = NOVALUE;
    DeRef(_3059);
    _3059 = NOVALUE;
    _3065 = NOVALUE;
    _3067 = NOVALUE;
    return _3069;
    goto L2; // [190] 221
L6: 

    /** 		return target & repeat(filler,start-length(target)-1) & source*/
    if (IS_SEQUENCE(_target_5891)){
            _3070 = SEQ_PTR(_target_5891)->length;
    }
    else {
        _3070 = 1;
    }
    _3071 = _start_5893 - _3070;
    if ((long)((unsigned long)_3071 +(unsigned long) HIGH_BITS) >= 0){
        _3071 = NewDouble((double)_3071);
    }
    _3070 = NOVALUE;
    if (IS_ATOM_INT(_3071)) {
        _3072 = _3071 - 1;
    }
    else {
        _3072 = NewDouble(DBL_PTR(_3071)->dbl - (double)1);
    }
    DeRef(_3071);
    _3071 = NOVALUE;
    _3073 = Repeat(_filler_5894, _3072);
    DeRef(_3072);
    _3072 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _source_5892;
        concat_list[1] = _3073;
        concat_list[2] = _target_5891;
        Concat_N((object_ptr)&_3074, concat_list, 3);
    }
    DeRefDS(_3073);
    _3073 = NOVALUE;
    DeRefDS(_target_5891);
    DeRefDS(_source_5892);
    DeRef(_filler_5894);
    DeRef(_3045);
    _3045 = NOVALUE;
    DeRef(_3052);
    _3052 = NOVALUE;
    DeRef(_3055);
    _3055 = NOVALUE;
    DeRef(_3056);
    _3056 = NOVALUE;
    DeRef(_3062);
    _3062 = NOVALUE;
    DeRef(_3059);
    _3059 = NOVALUE;
    DeRef(_3065);
    _3065 = NOVALUE;
    DeRef(_3067);
    _3067 = NOVALUE;
    DeRef(_3069);
    _3069 = NOVALUE;
    return _3074;
L2: 
    ;
}


int  __stdcall _23remove_all(int _needle_5942, int _haystack_5943)
{
    int _found_5944 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer found = 1*/
    _found_5944 = 1;

    /** 	while found entry do*/
    goto L1; // [10] 26
L2: 
    if (_found_5944 == 0)
    {
        goto L3; // [13] 38
    }
    else{
    }

    /** 		haystack = remove( haystack, found )*/
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_5943);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_found_5944)) ? _found_5944 : (long)(DBL_PTR(_found_5944)->dbl);
        int stop = (IS_ATOM_INT(_found_5944)) ? _found_5944 : (long)(DBL_PTR(_found_5944)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_5943), start, &_haystack_5943 );
            }
            else Tail(SEQ_PTR(_haystack_5943), stop+1, &_haystack_5943);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_5943), start, &_haystack_5943);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_5943 = Remove_elements(start, stop, (SEQ_PTR(_haystack_5943)->ref == 1));
        }
    }

    /** 	entry*/
L1: 

    /** 		found = find( needle, haystack, found )*/
    _found_5944 = find_from(_needle_5942, _haystack_5943, _found_5944);

    /** 	end while*/
    goto L2; // [35] 13
L3: 

    /** 	return haystack*/
    DeRef(_needle_5942);
    return _haystack_5943;
    ;
}


int  __stdcall _23retain_all(int _needles_5950, int _haystack_5951)
{
    int _lp_5952 = NOVALUE;
    int _np_5953 = NOVALUE;
    int _result_5954 = NOVALUE;
    int _3092 = NOVALUE;
    int _3089 = NOVALUE;
    int _3088 = NOVALUE;
    int _3086 = NOVALUE;
    int _3085 = NOVALUE;
    int _3084 = NOVALUE;
    int _3081 = NOVALUE;
    int _3079 = NOVALUE;
    int _3077 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(needles) then*/
    _3077 = IS_ATOM(_needles_5950);
    if (_3077 == 0)
    {
        _3077 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _3077 = NOVALUE;
    }

    /** 		needles = {needles}*/
    _0 = _needles_5950;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needles_5950);
    *((int *)(_2+4)) = _needles_5950;
    _needles_5950 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if length(needles) = 0 then*/
    if (IS_SEQUENCE(_needles_5950)){
            _3079 = SEQ_PTR(_needles_5950)->length;
    }
    else {
        _3079 = 1;
    }
    if (_3079 != 0)
    goto L2; // [23] 34

    /** 		return {}*/
    RefDS(_5);
    DeRef(_needles_5950);
    DeRefDS(_haystack_5951);
    DeRef(_result_5954);
    return _5;
L2: 

    /** 	if length(haystack) = 0 then*/
    if (IS_SEQUENCE(_haystack_5951)){
            _3081 = SEQ_PTR(_haystack_5951)->length;
    }
    else {
        _3081 = 1;
    }
    if (_3081 != 0)
    goto L3; // [39] 50

    /** 		return {}*/
    RefDS(_5);
    DeRef(_needles_5950);
    DeRefDS(_haystack_5951);
    DeRef(_result_5954);
    return _5;
L3: 

    /** 	result = haystack*/
    RefDS(_haystack_5951);
    DeRef(_result_5954);
    _result_5954 = _haystack_5951;

    /** 	lp = length(haystack)*/
    if (IS_SEQUENCE(_haystack_5951)){
            _lp_5952 = SEQ_PTR(_haystack_5951)->length;
    }
    else {
        _lp_5952 = 1;
    }

    /** 	np = 1*/
    _np_5953 = 1;

    /** 	for i = 1 to length(haystack) do*/
    if (IS_SEQUENCE(_haystack_5951)){
            _3084 = SEQ_PTR(_haystack_5951)->length;
    }
    else {
        _3084 = 1;
    }
    {
        int _i_5966;
        _i_5966 = 1;
L4: 
        if (_i_5966 > _3084){
            goto L5; // [72] 138
        }

        /** 		if find(haystack[i], needles) then*/
        _2 = (int)SEQ_PTR(_haystack_5951);
        _3085 = (int)*(((s1_ptr)_2)->base + _i_5966);
        _3086 = find_from(_3085, _needles_5950, 1);
        _3085 = NOVALUE;
        if (_3086 == 0)
        {
            _3086 = NOVALUE;
            goto L6; // [90] 124
        }
        else{
            _3086 = NOVALUE;
        }

        /** 			if np < i then*/
        if (_np_5953 >= _i_5966)
        goto L7; // [95] 115

        /** 				result[np .. lp] = haystack[i..$]*/
        if (IS_SEQUENCE(_haystack_5951)){
                _3088 = SEQ_PTR(_haystack_5951)->length;
        }
        else {
            _3088 = 1;
        }
        rhs_slice_target = (object_ptr)&_3089;
        RHS_Slice(_haystack_5951, _i_5966, _3088);
        assign_slice_seq = (s1_ptr *)&_result_5954;
        AssignSlice(_np_5953, _lp_5952, _3089);
        DeRefDS(_3089);
        _3089 = NOVALUE;
L7: 

        /** 			np += 1*/
        _np_5953 = _np_5953 + 1;
        goto L8; // [121] 131
L6: 

        /** 			lp -= 1*/
        _lp_5952 = _lp_5952 - 1;
L8: 

        /** 	end for*/
        _i_5966 = _i_5966 + 1;
        goto L4; // [133] 79
L5: 
        ;
    }

    /** 	return result[1 .. lp]*/
    rhs_slice_target = (object_ptr)&_3092;
    RHS_Slice(_result_5954, 1, _lp_5952);
    DeRef(_needles_5950);
    DeRefDS(_haystack_5951);
    DeRefDS(_result_5954);
    return _3092;
    ;
}


int  __stdcall _23filter(int _source_5981, int _rid_5982, int _userdata_5983, int _rangetype_5984)
{
    int _dest_5985 = NOVALUE;
    int _idx_5986 = NOVALUE;
    int _3267 = NOVALUE;
    int _3266 = NOVALUE;
    int _3264 = NOVALUE;
    int _3263 = NOVALUE;
    int _3262 = NOVALUE;
    int _3261 = NOVALUE;
    int _3260 = NOVALUE;
    int _3257 = NOVALUE;
    int _3256 = NOVALUE;
    int _3255 = NOVALUE;
    int _3254 = NOVALUE;
    int _3251 = NOVALUE;
    int _3250 = NOVALUE;
    int _3249 = NOVALUE;
    int _3248 = NOVALUE;
    int _3247 = NOVALUE;
    int _3244 = NOVALUE;
    int _3243 = NOVALUE;
    int _3242 = NOVALUE;
    int _3241 = NOVALUE;
    int _3238 = NOVALUE;
    int _3237 = NOVALUE;
    int _3236 = NOVALUE;
    int _3235 = NOVALUE;
    int _3234 = NOVALUE;
    int _3231 = NOVALUE;
    int _3230 = NOVALUE;
    int _3229 = NOVALUE;
    int _3228 = NOVALUE;
    int _3225 = NOVALUE;
    int _3224 = NOVALUE;
    int _3223 = NOVALUE;
    int _3222 = NOVALUE;
    int _3221 = NOVALUE;
    int _3218 = NOVALUE;
    int _3217 = NOVALUE;
    int _3216 = NOVALUE;
    int _3215 = NOVALUE;
    int _3212 = NOVALUE;
    int _3211 = NOVALUE;
    int _3210 = NOVALUE;
    int _3209 = NOVALUE;
    int _3208 = NOVALUE;
    int _3205 = NOVALUE;
    int _3204 = NOVALUE;
    int _3203 = NOVALUE;
    int _3199 = NOVALUE;
    int _3196 = NOVALUE;
    int _3195 = NOVALUE;
    int _3194 = NOVALUE;
    int _3192 = NOVALUE;
    int _3191 = NOVALUE;
    int _3190 = NOVALUE;
    int _3189 = NOVALUE;
    int _3188 = NOVALUE;
    int _3185 = NOVALUE;
    int _3184 = NOVALUE;
    int _3183 = NOVALUE;
    int _3181 = NOVALUE;
    int _3180 = NOVALUE;
    int _3179 = NOVALUE;
    int _3178 = NOVALUE;
    int _3177 = NOVALUE;
    int _3174 = NOVALUE;
    int _3173 = NOVALUE;
    int _3172 = NOVALUE;
    int _3170 = NOVALUE;
    int _3169 = NOVALUE;
    int _3168 = NOVALUE;
    int _3167 = NOVALUE;
    int _3166 = NOVALUE;
    int _3163 = NOVALUE;
    int _3162 = NOVALUE;
    int _3161 = NOVALUE;
    int _3159 = NOVALUE;
    int _3158 = NOVALUE;
    int _3157 = NOVALUE;
    int _3156 = NOVALUE;
    int _3155 = NOVALUE;
    int _3153 = NOVALUE;
    int _3152 = NOVALUE;
    int _3151 = NOVALUE;
    int _3147 = NOVALUE;
    int _3144 = NOVALUE;
    int _3143 = NOVALUE;
    int _3142 = NOVALUE;
    int _3139 = NOVALUE;
    int _3136 = NOVALUE;
    int _3135 = NOVALUE;
    int _3134 = NOVALUE;
    int _3131 = NOVALUE;
    int _3128 = NOVALUE;
    int _3127 = NOVALUE;
    int _3126 = NOVALUE;
    int _3123 = NOVALUE;
    int _3120 = NOVALUE;
    int _3119 = NOVALUE;
    int _3118 = NOVALUE;
    int _3114 = NOVALUE;
    int _3111 = NOVALUE;
    int _3110 = NOVALUE;
    int _3109 = NOVALUE;
    int _3106 = NOVALUE;
    int _3103 = NOVALUE;
    int _3102 = NOVALUE;
    int _3101 = NOVALUE;
    int _3095 = NOVALUE;
    int _3093 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_5981)){
            _3093 = SEQ_PTR(_source_5981)->length;
    }
    else {
        _3093 = 1;
    }
    if (_3093 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRef(_rid_5982);
    DeRef(_userdata_5983);
    DeRef(_rangetype_5984);
    DeRef(_dest_5985);
    return _source_5981;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_5981)){
            _3095 = SEQ_PTR(_source_5981)->length;
    }
    else {
        _3095 = 1;
    }
    DeRef(_dest_5985);
    _dest_5985 = Repeat(0, _3095);
    _3095 = NOVALUE;

    /** 	idx = 0*/
    _idx_5986 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_5982, _3097);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3101 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3101 = 1;
        }
        {
            int _a_5998;
            _a_5998 = 1;
L2: 
            if (_a_5998 > _3101){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3102 = (int)*(((s1_ptr)_2)->base + _a_5998);
            if (IS_ATOM_INT(_3102) && IS_ATOM_INT(_userdata_5983)){
                _3103 = (_3102 < _userdata_5983) ? -1 : (_3102 > _userdata_5983);
            }
            else{
                _3103 = compare(_3102, _userdata_5983);
            }
            _3102 = NOVALUE;
            if (_3103 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3106 = (int)*(((s1_ptr)_2)->base + _a_5998);
            Ref(_3106);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3106;
            if( _1 != _3106 ){
                DeRef(_1);
            }
            _3106 = NOVALUE;
L4: 

            /** 			end for*/
            _a_5998 = _a_5998 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3109 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3109 = 1;
        }
        {
            int _a_6010;
            _a_6010 = 1;
L6: 
            if (_a_6010 > _3109){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3110 = (int)*(((s1_ptr)_2)->base + _a_6010);
            if (IS_ATOM_INT(_3110) && IS_ATOM_INT(_userdata_5983)){
                _3111 = (_3110 < _userdata_5983) ? -1 : (_3110 > _userdata_5983);
            }
            else{
                _3111 = compare(_3110, _userdata_5983);
            }
            _3110 = NOVALUE;
            if (_3111 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3114 = (int)*(((s1_ptr)_2)->base + _a_6010);
            Ref(_3114);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3114;
            if( _1 != _3114 ){
                DeRef(_1);
            }
            _3114 = NOVALUE;
L8: 

            /** 			end for*/
            _a_6010 = _a_6010 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3118 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3118 = 1;
        }
        {
            int _a_6023;
            _a_6023 = 1;
L9: 
            if (_a_6023 > _3118){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3119 = (int)*(((s1_ptr)_2)->base + _a_6023);
            if (IS_ATOM_INT(_3119) && IS_ATOM_INT(_userdata_5983)){
                _3120 = (_3119 < _userdata_5983) ? -1 : (_3119 > _userdata_5983);
            }
            else{
                _3120 = compare(_3119, _userdata_5983);
            }
            _3119 = NOVALUE;
            if (_3120 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3123 = (int)*(((s1_ptr)_2)->base + _a_6023);
            Ref(_3123);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3123;
            if( _1 != _3123 ){
                DeRef(_1);
            }
            _3123 = NOVALUE;
LB: 

            /** 			end for*/
            _a_6023 = _a_6023 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3126 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3126 = 1;
        }
        {
            int _a_6035;
            _a_6035 = 1;
LC: 
            if (_a_6035 > _3126){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3127 = (int)*(((s1_ptr)_2)->base + _a_6035);
            if (IS_ATOM_INT(_3127) && IS_ATOM_INT(_userdata_5983)){
                _3128 = (_3127 < _userdata_5983) ? -1 : (_3127 > _userdata_5983);
            }
            else{
                _3128 = compare(_3127, _userdata_5983);
            }
            _3127 = NOVALUE;
            if (_3128 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3131 = (int)*(((s1_ptr)_2)->base + _a_6035);
            Ref(_3131);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3131;
            if( _1 != _3131 ){
                DeRef(_1);
            }
            _3131 = NOVALUE;
LE: 

            /** 			end for*/
            _a_6035 = _a_6035 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3134 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3134 = 1;
        }
        {
            int _a_6047;
            _a_6047 = 1;
LF: 
            if (_a_6047 > _3134){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3135 = (int)*(((s1_ptr)_2)->base + _a_6047);
            if (IS_ATOM_INT(_3135) && IS_ATOM_INT(_userdata_5983)){
                _3136 = (_3135 < _userdata_5983) ? -1 : (_3135 > _userdata_5983);
            }
            else{
                _3136 = compare(_3135, _userdata_5983);
            }
            _3135 = NOVALUE;
            if (_3136 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3139 = (int)*(((s1_ptr)_2)->base + _a_6047);
            Ref(_3139);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3139;
            if( _1 != _3139 ){
                DeRef(_1);
            }
            _3139 = NOVALUE;
L11: 

            /** 			end for*/
            _a_6047 = _a_6047 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3142 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3142 = 1;
        }
        {
            int _a_6059;
            _a_6059 = 1;
L12: 
            if (_a_6059 > _3142){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3143 = (int)*(((s1_ptr)_2)->base + _a_6059);
            if (IS_ATOM_INT(_3143) && IS_ATOM_INT(_userdata_5983)){
                _3144 = (_3143 < _userdata_5983) ? -1 : (_3143 > _userdata_5983);
            }
            else{
                _3144 = compare(_3143, _userdata_5983);
            }
            _3143 = NOVALUE;
            if (_3144 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3147 = (int)*(((s1_ptr)_2)->base + _a_6059);
            Ref(_3147);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3147;
            if( _1 != _3147 ){
                DeRef(_1);
            }
            _3147 = NOVALUE;
L14: 

            /** 			end for*/
            _a_6059 = _a_6059 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_5984, _3149);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3151 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3151 = 1;
            }
            {
                int _a_6073;
                _a_6073 = 1;
L15: 
                if (_a_6073 > _3151){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3152 = (int)*(((s1_ptr)_2)->base + _a_6073);
                _3153 = find_from(_3152, _userdata_5983, 1);
                _3152 = NOVALUE;
                if (_3153 == 0)
                {
                    _3153 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _3153 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3155 = (int)*(((s1_ptr)_2)->base + _a_6073);
                Ref(_3155);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3155;
                if( _1 != _3155 ){
                    DeRef(_1);
                }
                _3155 = NOVALUE;
L17: 

                /** 					end for*/
                _a_6073 = _a_6073 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3156 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3156 = 1;
            }
            {
                int _a_6082;
                _a_6082 = 1;
L18: 
                if (_a_6082 > _3156){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3157 = (int)*(((s1_ptr)_2)->base + _a_6082);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3158 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3157) && IS_ATOM_INT(_3158)){
                    _3159 = (_3157 < _3158) ? -1 : (_3157 > _3158);
                }
                else{
                    _3159 = compare(_3157, _3158);
                }
                _3157 = NOVALUE;
                _3158 = NOVALUE;
                if (_3159 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3161 = (int)*(((s1_ptr)_2)->base + _a_6082);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3162 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3161) && IS_ATOM_INT(_3162)){
                    _3163 = (_3161 < _3162) ? -1 : (_3161 > _3162);
                }
                else{
                    _3163 = compare(_3161, _3162);
                }
                _3161 = NOVALUE;
                _3162 = NOVALUE;
                if (_3163 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3166 = (int)*(((s1_ptr)_2)->base + _a_6082);
                Ref(_3166);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3166;
                if( _1 != _3166 ){
                    DeRef(_1);
                }
                _3166 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_6082 = _a_6082 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3167 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3167 = 1;
            }
            {
                int _a_6098;
                _a_6098 = 1;
L1C: 
                if (_a_6098 > _3167){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3168 = (int)*(((s1_ptr)_2)->base + _a_6098);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3169 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3168) && IS_ATOM_INT(_3169)){
                    _3170 = (_3168 < _3169) ? -1 : (_3168 > _3169);
                }
                else{
                    _3170 = compare(_3168, _3169);
                }
                _3168 = NOVALUE;
                _3169 = NOVALUE;
                if (_3170 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3172 = (int)*(((s1_ptr)_2)->base + _a_6098);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3173 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3172) && IS_ATOM_INT(_3173)){
                    _3174 = (_3172 < _3173) ? -1 : (_3172 > _3173);
                }
                else{
                    _3174 = compare(_3172, _3173);
                }
                _3172 = NOVALUE;
                _3173 = NOVALUE;
                if (_3174 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3177 = (int)*(((s1_ptr)_2)->base + _a_6098);
                Ref(_3177);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3177;
                if( _1 != _3177 ){
                    DeRef(_1);
                }
                _3177 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_6098 = _a_6098 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3178 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3178 = 1;
            }
            {
                int _a_6114;
                _a_6114 = 1;
L20: 
                if (_a_6114 > _3178){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3179 = (int)*(((s1_ptr)_2)->base + _a_6114);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3180 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3179) && IS_ATOM_INT(_3180)){
                    _3181 = (_3179 < _3180) ? -1 : (_3179 > _3180);
                }
                else{
                    _3181 = compare(_3179, _3180);
                }
                _3179 = NOVALUE;
                _3180 = NOVALUE;
                if (_3181 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3183 = (int)*(((s1_ptr)_2)->base + _a_6114);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3184 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3183) && IS_ATOM_INT(_3184)){
                    _3185 = (_3183 < _3184) ? -1 : (_3183 > _3184);
                }
                else{
                    _3185 = compare(_3183, _3184);
                }
                _3183 = NOVALUE;
                _3184 = NOVALUE;
                if (_3185 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3188 = (int)*(((s1_ptr)_2)->base + _a_6114);
                Ref(_3188);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3188;
                if( _1 != _3188 ){
                    DeRef(_1);
                }
                _3188 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_6114 = _a_6114 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3189 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3189 = 1;
            }
            {
                int _a_6130;
                _a_6130 = 1;
L24: 
                if (_a_6130 > _3189){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3190 = (int)*(((s1_ptr)_2)->base + _a_6130);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3191 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3190) && IS_ATOM_INT(_3191)){
                    _3192 = (_3190 < _3191) ? -1 : (_3190 > _3191);
                }
                else{
                    _3192 = compare(_3190, _3191);
                }
                _3190 = NOVALUE;
                _3191 = NOVALUE;
                if (_3192 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3194 = (int)*(((s1_ptr)_2)->base + _a_6130);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3195 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3194) && IS_ATOM_INT(_3195)){
                    _3196 = (_3194 < _3195) ? -1 : (_3194 > _3195);
                }
                else{
                    _3196 = compare(_3194, _3195);
                }
                _3194 = NOVALUE;
                _3195 = NOVALUE;
                if (_3196 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3199 = (int)*(((s1_ptr)_2)->base + _a_6130);
                Ref(_3199);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3199;
                if( _1 != _3199 ){
                    DeRef(_1);
                }
                _3199 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_6130 = _a_6130 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_5984, _3201);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3203 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3203 = 1;
            }
            {
                int _a_6151;
                _a_6151 = 1;
L28: 
                if (_a_6151 > _3203){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3204 = (int)*(((s1_ptr)_2)->base + _a_6151);
                _3205 = find_from(_3204, _userdata_5983, 1);
                _3204 = NOVALUE;
                if (_3205 != 0)
                goto L2A; // [818] 838
                _3205 = NOVALUE;

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3208 = (int)*(((s1_ptr)_2)->base + _a_6151);
                Ref(_3208);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3208;
                if( _1 != _3208 ){
                    DeRef(_1);
                }
                _3208 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_6151 = _a_6151 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3209 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3209 = 1;
            }
            {
                int _a_6161;
                _a_6161 = 1;
L2B: 
                if (_a_6161 > _3209){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3210 = (int)*(((s1_ptr)_2)->base + _a_6161);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3211 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3210) && IS_ATOM_INT(_3211)){
                    _3212 = (_3210 < _3211) ? -1 : (_3210 > _3211);
                }
                else{
                    _3212 = compare(_3210, _3211);
                }
                _3210 = NOVALUE;
                _3211 = NOVALUE;
                if (_3212 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3215 = (int)*(((s1_ptr)_2)->base + _a_6161);
                Ref(_3215);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3215;
                if( _1 != _3215 ){
                    DeRef(_1);
                }
                _3215 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3216 = (int)*(((s1_ptr)_2)->base + _a_6161);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3217 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3216) && IS_ATOM_INT(_3217)){
                    _3218 = (_3216 < _3217) ? -1 : (_3216 > _3217);
                }
                else{
                    _3218 = compare(_3216, _3217);
                }
                _3216 = NOVALUE;
                _3217 = NOVALUE;
                if (_3218 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3221 = (int)*(((s1_ptr)_2)->base + _a_6161);
                Ref(_3221);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3221;
                if( _1 != _3221 ){
                    DeRef(_1);
                }
                _3221 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_6161 = _a_6161 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3222 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3222 = 1;
            }
            {
                int _a_6179;
                _a_6179 = 1;
L30: 
                if (_a_6179 > _3222){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3223 = (int)*(((s1_ptr)_2)->base + _a_6179);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3224 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3223) && IS_ATOM_INT(_3224)){
                    _3225 = (_3223 < _3224) ? -1 : (_3223 > _3224);
                }
                else{
                    _3225 = compare(_3223, _3224);
                }
                _3223 = NOVALUE;
                _3224 = NOVALUE;
                if (_3225 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3228 = (int)*(((s1_ptr)_2)->base + _a_6179);
                Ref(_3228);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3228;
                if( _1 != _3228 ){
                    DeRef(_1);
                }
                _3228 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3229 = (int)*(((s1_ptr)_2)->base + _a_6179);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3230 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3229) && IS_ATOM_INT(_3230)){
                    _3231 = (_3229 < _3230) ? -1 : (_3229 > _3230);
                }
                else{
                    _3231 = compare(_3229, _3230);
                }
                _3229 = NOVALUE;
                _3230 = NOVALUE;
                if (_3231 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3234 = (int)*(((s1_ptr)_2)->base + _a_6179);
                Ref(_3234);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3234;
                if( _1 != _3234 ){
                    DeRef(_1);
                }
                _3234 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_6179 = _a_6179 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3235 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3235 = 1;
            }
            {
                int _a_6197;
                _a_6197 = 1;
L35: 
                if (_a_6197 > _3235){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3236 = (int)*(((s1_ptr)_2)->base + _a_6197);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3237 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3236) && IS_ATOM_INT(_3237)){
                    _3238 = (_3236 < _3237) ? -1 : (_3236 > _3237);
                }
                else{
                    _3238 = compare(_3236, _3237);
                }
                _3236 = NOVALUE;
                _3237 = NOVALUE;
                if (_3238 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3241 = (int)*(((s1_ptr)_2)->base + _a_6197);
                Ref(_3241);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3241;
                if( _1 != _3241 ){
                    DeRef(_1);
                }
                _3241 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3242 = (int)*(((s1_ptr)_2)->base + _a_6197);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3243 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3242) && IS_ATOM_INT(_3243)){
                    _3244 = (_3242 < _3243) ? -1 : (_3242 > _3243);
                }
                else{
                    _3244 = compare(_3242, _3243);
                }
                _3242 = NOVALUE;
                _3243 = NOVALUE;
                if (_3244 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3247 = (int)*(((s1_ptr)_2)->base + _a_6197);
                Ref(_3247);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3247;
                if( _1 != _3247 ){
                    DeRef(_1);
                }
                _3247 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_6197 = _a_6197 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5981)){
                    _3248 = SEQ_PTR(_source_5981)->length;
            }
            else {
                _3248 = 1;
            }
            {
                int _a_6215;
                _a_6215 = 1;
L3A: 
                if (_a_6215 > _3248){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3249 = (int)*(((s1_ptr)_2)->base + _a_6215);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3250 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3249) && IS_ATOM_INT(_3250)){
                    _3251 = (_3249 < _3250) ? -1 : (_3249 > _3250);
                }
                else{
                    _3251 = compare(_3249, _3250);
                }
                _3249 = NOVALUE;
                _3250 = NOVALUE;
                if (_3251 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3254 = (int)*(((s1_ptr)_2)->base + _a_6215);
                Ref(_3254);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3254;
                if( _1 != _3254 ){
                    DeRef(_1);
                }
                _3254 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3255 = (int)*(((s1_ptr)_2)->base + _a_6215);
                _2 = (int)SEQ_PTR(_userdata_5983);
                _3256 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3255) && IS_ATOM_INT(_3256)){
                    _3257 = (_3255 < _3256) ? -1 : (_3255 > _3256);
                }
                else{
                    _3257 = compare(_3255, _3256);
                }
                _3255 = NOVALUE;
                _3256 = NOVALUE;
                if (_3257 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_5986 = _idx_5986 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5981);
                _3260 = (int)*(((s1_ptr)_2)->base + _a_6215);
                Ref(_3260);
                _2 = (int)SEQ_PTR(_dest_5985);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
                _1 = *(int *)_2;
                *(int *)_2 = _3260;
                if( _1 != _3260 ){
                    DeRef(_1);
                }
                _3260 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_6215 = _a_6215 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5981)){
                _3261 = SEQ_PTR(_source_5981)->length;
        }
        else {
            _3261 = 1;
        }
        {
            int _a_6234;
            _a_6234 = 1;
L3F: 
            if (_a_6234 > _3261){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3262 = (int)*(((s1_ptr)_2)->base + _a_6234);
            Ref(_userdata_5983);
            Ref(_3262);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _3262;
            ((int *)_2)[2] = _userdata_5983;
            _3263 = MAKE_SEQ(_1);
            _3262 = NOVALUE;
            _1 = (int)SEQ_PTR(_3263);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_5982].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid_5982].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            DeRef(_3264);
            _3264 = _1;
            DeRefDS(_3263);
            _3263 = NOVALUE;
            if (_3264 == 0) {
                DeRef(_3264);
                _3264 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_3264) && DBL_PTR(_3264)->dbl == 0.0){
                    DeRef(_3264);
                    _3264 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_3264);
                _3264 = NOVALUE;
            }
            DeRef(_3264);
            _3264 = NOVALUE;

            /** 					idx += 1*/
            _idx_5986 = _idx_5986 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5981);
            _3266 = (int)*(((s1_ptr)_2)->base + _a_6234);
            Ref(_3266);
            _2 = (int)SEQ_PTR(_dest_5985);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5986);
            _1 = *(int *)_2;
            *(int *)_2 = _3266;
            if( _1 != _3266 ){
                DeRef(_1);
            }
            _3266 = NOVALUE;
L41: 

            /** 			end for*/
            _a_6234 = _a_6234 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_3267;
    RHS_Slice(_dest_5985, 1, _idx_5986);
    DeRefDS(_source_5981);
    DeRef(_rid_5982);
    DeRef(_userdata_5983);
    DeRef(_rangetype_5984);
    DeRefDS(_dest_5985);
    return _3267;
    ;
}


int _23filter_alpha(int _elem_6246, int _ud_6247)
{
    int _3268 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_6246);
    _3268 = _7t_alpha(_elem_6246);
    DeRef(_elem_6246);
    return _3268;
    ;
}


int  __stdcall _23extract(int _source_6255, int _indexes_6256)
{
    int _p_6257 = NOVALUE;
    int _msg_inlined_crash_at_34_6267 = NOVALUE;
    int _3276 = NOVALUE;
    int _3273 = NOVALUE;
    int _3271 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(indexes) do*/
    if (IS_SEQUENCE(_indexes_6256)){
            _3271 = SEQ_PTR(_indexes_6256)->length;
    }
    else {
        _3271 = 1;
    }
    {
        int _i_6259;
        _i_6259 = 1;
L1: 
        if (_i_6259 > _3271){
            goto L2; // [10] 71
        }

        /** 		p = indexes[i]*/
        DeRef(_p_6257);
        _2 = (int)SEQ_PTR(_indexes_6256);
        _p_6257 = (int)*(((s1_ptr)_2)->base + _i_6259);
        Ref(_p_6257);

        /** 		if not valid_index(source,p) then*/
        RefDS(_source_6255);
        Ref(_p_6257);
        _3273 = _23valid_index(_source_6255, _p_6257);
        if (IS_ATOM_INT(_3273)) {
            if (_3273 != 0){
                DeRef(_3273);
                _3273 = NOVALUE;
                goto L3; // [30] 54
            }
        }
        else {
            if (DBL_PTR(_3273)->dbl != 0.0){
                DeRef(_3273);
                _3273 = NOVALUE;
                goto L3; // [30] 54
            }
        }
        DeRef(_3273);
        _3273 = NOVALUE;

        /** 			error:crash("%d is not a valid index for the input sequence",p)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_34_6267);
        _msg_inlined_crash_at_34_6267 = EPrintf(-9999999, _3275, _p_6257);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_34_6267);

        /** end procedure*/
        goto L4; // [48] 51
L4: 
        DeRefi(_msg_inlined_crash_at_34_6267);
        _msg_inlined_crash_at_34_6267 = NOVALUE;
L3: 

        /** 		indexes[i] = source[p]*/
        _2 = (int)SEQ_PTR(_source_6255);
        if (!IS_ATOM_INT(_p_6257)){
            _3276 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_6257)->dbl));
        }
        else{
            _3276 = (int)*(((s1_ptr)_2)->base + _p_6257);
        }
        Ref(_3276);
        _2 = (int)SEQ_PTR(_indexes_6256);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _indexes_6256 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6259);
        _1 = *(int *)_2;
        *(int *)_2 = _3276;
        if( _1 != _3276 ){
            DeRef(_1);
        }
        _3276 = NOVALUE;

        /** 	end for*/
        _i_6259 = _i_6259 + 1;
        goto L1; // [66] 17
L2: 
        ;
    }

    /** 	return indexes*/
    DeRefDS(_source_6255);
    DeRef(_p_6257);
    return _indexes_6256;
    ;
}


int  __stdcall _23project(int _source_6271, int _coords_6272)
{
    int _result_6273 = NOVALUE;
    int _3287 = NOVALUE;
    int _3286 = NOVALUE;
    int _3285 = NOVALUE;
    int _3283 = NOVALUE;
    int _3282 = NOVALUE;
    int _3281 = NOVALUE;
    int _3279 = NOVALUE;
    int _3278 = NOVALUE;
    int _3277 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	result = repeat( repeat(0, length(coords)), length(source) )*/
    if (IS_SEQUENCE(_coords_6272)){
            _3277 = SEQ_PTR(_coords_6272)->length;
    }
    else {
        _3277 = 1;
    }
    _3278 = Repeat(0, _3277);
    _3277 = NOVALUE;
    if (IS_SEQUENCE(_source_6271)){
            _3279 = SEQ_PTR(_source_6271)->length;
    }
    else {
        _3279 = 1;
    }
    DeRef(_result_6273);
    _result_6273 = Repeat(_3278, _3279);
    DeRefDS(_3278);
    _3278 = NOVALUE;
    _3279 = NOVALUE;

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_6271)){
            _3281 = SEQ_PTR(_source_6271)->length;
    }
    else {
        _3281 = 1;
    }
    {
        int _i_6279;
        _i_6279 = 1;
L1: 
        if (_i_6279 > _3281){
            goto L2; // [26] 83
        }

        /** 		for j = 1 to length(coords) do*/
        if (IS_SEQUENCE(_coords_6272)){
                _3282 = SEQ_PTR(_coords_6272)->length;
        }
        else {
            _3282 = 1;
        }
        {
            int _j_6282;
            _j_6282 = 1;
L3: 
            if (_j_6282 > _3282){
                goto L4; // [38] 76
            }

            /** 			result[i][j] = extract(source[i], coords[j])*/
            _2 = (int)SEQ_PTR(_result_6273);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_6273 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_6279 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_source_6271);
            _3285 = (int)*(((s1_ptr)_2)->base + _i_6279);
            _2 = (int)SEQ_PTR(_coords_6272);
            _3286 = (int)*(((s1_ptr)_2)->base + _j_6282);
            Ref(_3285);
            Ref(_3286);
            _3287 = _23extract(_3285, _3286);
            _3285 = NOVALUE;
            _3286 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_6282);
            _1 = *(int *)_2;
            *(int *)_2 = _3287;
            if( _1 != _3287 ){
                DeRef(_1);
            }
            _3287 = NOVALUE;
            _3283 = NOVALUE;

            /** 		end for*/
            _j_6282 = _j_6282 + 1;
            goto L3; // [71] 45
L4: 
            ;
        }

        /** 	end for*/
        _i_6279 = _i_6279 + 1;
        goto L1; // [78] 33
L2: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_6271);
    DeRefDS(_coords_6272);
    return _result_6273;
    ;
}


int  __stdcall _23split(int _st_6291, int _delim_6292, int _no_empty_6293, int _limit_6294)
{
    int _ret_6295 = NOVALUE;
    int _start_6296 = NOVALUE;
    int _pos_6297 = NOVALUE;
    int _k_6349 = NOVALUE;
    int _3336 = NOVALUE;
    int _3334 = NOVALUE;
    int _3333 = NOVALUE;
    int _3329 = NOVALUE;
    int _3328 = NOVALUE;
    int _3327 = NOVALUE;
    int _3324 = NOVALUE;
    int _3323 = NOVALUE;
    int _3318 = NOVALUE;
    int _3317 = NOVALUE;
    int _3313 = NOVALUE;
    int _3309 = NOVALUE;
    int _3307 = NOVALUE;
    int _3306 = NOVALUE;
    int _3302 = NOVALUE;
    int _3300 = NOVALUE;
    int _3299 = NOVALUE;
    int _3298 = NOVALUE;
    int _3297 = NOVALUE;
    int _3294 = NOVALUE;
    int _3293 = NOVALUE;
    int _3292 = NOVALUE;
    int _3291 = NOVALUE;
    int _3290 = NOVALUE;
    int _3288 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_no_empty_6293)) {
        _1 = (long)(DBL_PTR(_no_empty_6293)->dbl);
        DeRefDS(_no_empty_6293);
        _no_empty_6293 = _1;
    }
    if (!IS_ATOM_INT(_limit_6294)) {
        _1 = (long)(DBL_PTR(_limit_6294)->dbl);
        DeRefDS(_limit_6294);
        _limit_6294 = _1;
    }

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_6295);
    _ret_6295 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_6291)){
            _3288 = SEQ_PTR(_st_6291)->length;
    }
    else {
        _3288 = 1;
    }
    if (_3288 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_6291);
    DeRef(_delim_6292);
    return _ret_6295;
L1: 

    /** 	if sequence(delim) then*/
    _3290 = IS_SEQUENCE(_delim_6292);
    if (_3290 == 0)
    {
        _3290 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _3290 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_6292 == _5)
    _3291 = 1;
    else if (IS_ATOM_INT(_delim_6292) && IS_ATOM_INT(_5))
    _3291 = 0;
    else
    _3291 = (compare(_delim_6292, _5) == 0);
    if (_3291 == 0)
    {
        _3291 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _3291 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_6291)){
            _3292 = SEQ_PTR(_st_6291)->length;
    }
    else {
        _3292 = 1;
    }
    {
        int _i_6306;
        _i_6306 = 1;
L4: 
        if (_i_6306 > _3292){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_6291);
        _3293 = (int)*(((s1_ptr)_2)->base + _i_6306);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_3293);
        *((int *)(_2+4)) = _3293;
        _3294 = MAKE_SEQ(_1);
        _3293 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_6291);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_6291 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6306);
        _1 = *(int *)_2;
        *(int *)_2 = _3294;
        if( _1 != _3294 ){
            DeRef(_1);
        }
        _3294 = NOVALUE;

        /** 				limit -= 1*/
        _limit_6294 = _limit_6294 - 1;

        /** 				if limit = 0 then*/
        if (_limit_6294 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_3297;
        RHS_Slice(_st_6291, 1, _i_6306);
        _3298 = _i_6306 + 1;
        if (IS_SEQUENCE(_st_6291)){
                _3299 = SEQ_PTR(_st_6291)->length;
        }
        else {
            _3299 = 1;
        }
        rhs_slice_target = (object_ptr)&_3300;
        RHS_Slice(_st_6291, _3298, _3299);
        RefDS(_3300);
        Append(&_st_6291, _3297, _3300);
        DeRefDS(_3297);
        _3297 = NOVALUE;
        DeRefDS(_3300);
        _3300 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_6306 = _i_6306 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRef(_delim_6292);
    DeRef(_ret_6295);
    DeRef(_3298);
    _3298 = NOVALUE;
    return _st_6291;
L3: 

    /** 		start = 1*/
    _start_6296 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_6291)){
            _3302 = SEQ_PTR(_st_6291)->length;
    }
    else {
        _3302 = 1;
    }
    if (_start_6296 > _3302)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_6297 = e_match_from(_delim_6292, _st_6291, _start_6296);

    /** 			if pos = 0 then*/
    if (_pos_6297 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3306 = _pos_6297 - 1;
    rhs_slice_target = (object_ptr)&_3307;
    RHS_Slice(_st_6291, _start_6296, _3306);
    RefDS(_3307);
    Append(&_ret_6295, _ret_6295, _3307);
    DeRefDS(_3307);
    _3307 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_6292)){
            _3309 = SEQ_PTR(_delim_6292)->length;
    }
    else {
        _3309 = 1;
    }
    _start_6296 = _pos_6297 + _3309;
    _3309 = NOVALUE;

    /** 			limit -= 1*/
    _limit_6294 = _limit_6294 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6294 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_6296 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_6291)){
            _3313 = SEQ_PTR(_st_6291)->length;
    }
    else {
        _3313 = 1;
    }
    if (_start_6296 > _3313)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_6297 = find_from(_delim_6292, _st_6291, _start_6296);

    /** 			if pos = 0 then*/
    if (_pos_6297 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3317 = _pos_6297 - 1;
    rhs_slice_target = (object_ptr)&_3318;
    RHS_Slice(_st_6291, _start_6296, _3317);
    RefDS(_3318);
    Append(&_ret_6295, _ret_6295, _3318);
    DeRefDS(_3318);
    _3318 = NOVALUE;

    /** 			start = pos + 1*/
    _start_6296 = _pos_6297 + 1;

    /** 			limit -= 1*/
    _limit_6294 = _limit_6294 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6294 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_6291)){
            _3323 = SEQ_PTR(_st_6291)->length;
    }
    else {
        _3323 = 1;
    }
    rhs_slice_target = (object_ptr)&_3324;
    RHS_Slice(_st_6291, _start_6296, _3323);
    RefDS(_3324);
    Append(&_ret_6295, _ret_6295, _3324);
    DeRefDS(_3324);
    _3324 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_6295)){
            _k_6349 = SEQ_PTR(_ret_6295)->length;
    }
    else {
        _k_6349 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_6293 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_6349 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_6295)){
            _3327 = SEQ_PTR(_ret_6295)->length;
    }
    else {
        _3327 = 1;
    }
    {
        int _i_6353;
        _i_6353 = 1;
LE: 
        if (_i_6353 > _3327){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_6295);
        _3328 = (int)*(((s1_ptr)_2)->base + _i_6353);
        if (IS_SEQUENCE(_3328)){
                _3329 = SEQ_PTR(_3328)->length;
        }
        else {
            _3329 = 1;
        }
        _3328 = NOVALUE;
        if (_3329 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_6349 = _k_6349 + 1;

        /** 				if k != i then*/
        if (_k_6349 == _i_6353)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_6295);
        _3333 = (int)*(((s1_ptr)_2)->base + _i_6353);
        Ref(_3333);
        _2 = (int)SEQ_PTR(_ret_6295);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_6295 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_6349);
        _1 = *(int *)_2;
        *(int *)_2 = _3333;
        if( _1 != _3333 ){
            DeRef(_1);
        }
        _3333 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_6353 = _i_6353 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_6295)){
            _3334 = SEQ_PTR(_ret_6295)->length;
    }
    else {
        _3334 = 1;
    }
    if (_k_6349 >= _3334)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3336;
    RHS_Slice(_ret_6295, 1, _k_6349);
    DeRefDS(_st_6291);
    DeRef(_delim_6292);
    DeRefDS(_ret_6295);
    DeRef(_3306);
    _3306 = NOVALUE;
    DeRef(_3298);
    _3298 = NOVALUE;
    DeRef(_3317);
    _3317 = NOVALUE;
    _3328 = NOVALUE;
    return _3336;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_6291);
    DeRef(_delim_6292);
    DeRef(_3306);
    _3306 = NOVALUE;
    DeRef(_3298);
    _3298 = NOVALUE;
    DeRef(_3317);
    _3317 = NOVALUE;
    _3328 = NOVALUE;
    DeRef(_3336);
    _3336 = NOVALUE;
    return _ret_6295;
L13: 
    ;
}


int  __stdcall _23split_any(int _source_6370, int _delim_6371, int _limit_6373, int _no_empty_6374)
{
    int _ret_6375 = NOVALUE;
    int _start_6376 = NOVALUE;
    int _pos_6377 = NOVALUE;
    int _next_pos_6378 = NOVALUE;
    int _k_6397 = NOVALUE;
    int _3361 = NOVALUE;
    int _3359 = NOVALUE;
    int _3358 = NOVALUE;
    int _3354 = NOVALUE;
    int _3353 = NOVALUE;
    int _3352 = NOVALUE;
    int _3349 = NOVALUE;
    int _3348 = NOVALUE;
    int _3344 = NOVALUE;
    int _3343 = NOVALUE;
    int _3340 = NOVALUE;
    int _3338 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_6373)) {
        _1 = (long)(DBL_PTR(_limit_6373)->dbl);
        DeRefDS(_limit_6373);
        _limit_6373 = _1;
    }
    if (!IS_ATOM_INT(_no_empty_6374)) {
        _1 = (long)(DBL_PTR(_no_empty_6374)->dbl);
        DeRefDS(_no_empty_6374);
        _no_empty_6374 = _1;
    }

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_6375);
    _ret_6375 = _5;

    /** 	integer start = 1, pos, next_pos*/
    _start_6376 = 1;

    /** 	if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_6371)){
            _3338 = SEQ_PTR(_delim_6371)->length;
    }
    else {
        _3338 = 1;
    }
    if (_3338 != 0)
    goto L1; // [24] 39

    /** 		return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6370);
    *((int *)(_2+4)) = _source_6370;
    _3340 = MAKE_SEQ(_1);
    DeRefDS(_source_6370);
    DeRef(_delim_6371);
    DeRefDS(_ret_6375);
    return _3340;
L1: 

    /** 	while 1 do*/
L2: 

    /** 		pos = search:find_any(delim, source, start)*/
    Ref(_delim_6371);
    RefDS(_source_6370);
    _pos_6377 = _9find_any(_delim_6371, _source_6370, _start_6376);
    if (!IS_ATOM_INT(_pos_6377)) {
        _1 = (long)(DBL_PTR(_pos_6377)->dbl);
        DeRefDS(_pos_6377);
        _pos_6377 = _1;
    }

    /** 		next_pos = pos + 1*/
    _next_pos_6378 = _pos_6377 + 1;

    /** 		if pos then*/
    if (_pos_6377 == 0)
    {
        goto L3; // [62] 115
    }
    else{
    }

    /** 			ret = append(ret, source[start..pos-1])*/
    _3343 = _pos_6377 - 1;
    rhs_slice_target = (object_ptr)&_3344;
    RHS_Slice(_source_6370, _start_6376, _3343);
    RefDS(_3344);
    Append(&_ret_6375, _ret_6375, _3344);
    DeRefDS(_3344);
    _3344 = NOVALUE;

    /** 			start = next_pos*/
    _start_6376 = _next_pos_6378;

    /** 			limit -= 1*/
    _limit_6373 = _limit_6373 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6373 != 0)
    goto L2; // [93] 44

    /** 				exit*/
    goto L3; // [99] 115
    goto L2; // [102] 44

    /** 			exit*/
    goto L3; // [107] 115

    /** 	end while*/
    goto L2; // [112] 44
L3: 

    /** 	ret = append(ret, source[start..$])*/
    if (IS_SEQUENCE(_source_6370)){
            _3348 = SEQ_PTR(_source_6370)->length;
    }
    else {
        _3348 = 1;
    }
    rhs_slice_target = (object_ptr)&_3349;
    RHS_Slice(_source_6370, _start_6376, _3348);
    RefDS(_3349);
    Append(&_ret_6375, _ret_6375, _3349);
    DeRefDS(_3349);
    _3349 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_6375)){
            _k_6397 = SEQ_PTR(_ret_6375)->length;
    }
    else {
        _k_6397 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_6374 == 0)
    {
        goto L4; // [136] 201
    }
    else{
    }

    /** 		k = 0*/
    _k_6397 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_6375)){
            _3352 = SEQ_PTR(_ret_6375)->length;
    }
    else {
        _3352 = 1;
    }
    {
        int _i_6401;
        _i_6401 = 1;
L5: 
        if (_i_6401 > _3352){
            goto L6; // [149] 200
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_6375);
        _3353 = (int)*(((s1_ptr)_2)->base + _i_6401);
        if (IS_SEQUENCE(_3353)){
                _3354 = SEQ_PTR(_3353)->length;
        }
        else {
            _3354 = 1;
        }
        _3353 = NOVALUE;
        if (_3354 == 0)
        goto L7; // [165] 193

        /** 				k += 1*/
        _k_6397 = _k_6397 + 1;

        /** 				if k != i then*/
        if (_k_6397 == _i_6401)
        goto L8; // [177] 192

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_6375);
        _3358 = (int)*(((s1_ptr)_2)->base + _i_6401);
        Ref(_3358);
        _2 = (int)SEQ_PTR(_ret_6375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_6375 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_6397);
        _1 = *(int *)_2;
        *(int *)_2 = _3358;
        if( _1 != _3358 ){
            DeRef(_1);
        }
        _3358 = NOVALUE;
L8: 
L7: 

        /** 		end for*/
        _i_6401 = _i_6401 + 1;
        goto L5; // [195] 156
L6: 
        ;
    }
L4: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_6375)){
            _3359 = SEQ_PTR(_ret_6375)->length;
    }
    else {
        _3359 = 1;
    }
    if (_k_6397 >= _3359)
    goto L9; // [206] 224

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3361;
    RHS_Slice(_ret_6375, 1, _k_6397);
    DeRefDS(_source_6370);
    DeRef(_delim_6371);
    DeRefDS(_ret_6375);
    DeRef(_3340);
    _3340 = NOVALUE;
    DeRef(_3343);
    _3343 = NOVALUE;
    _3353 = NOVALUE;
    return _3361;
    goto LA; // [221] 231
L9: 

    /** 		return ret*/
    DeRefDS(_source_6370);
    DeRef(_delim_6371);
    DeRef(_3340);
    _3340 = NOVALUE;
    DeRef(_3343);
    _3343 = NOVALUE;
    _3353 = NOVALUE;
    DeRef(_3361);
    _3361 = NOVALUE;
    return _ret_6375;
LA: 
    ;
}


int  __stdcall _23join(int _items_6418, int _delim_6419)
{
    int _ret_6421 = NOVALUE;
    int _3371 = NOVALUE;
    int _3370 = NOVALUE;
    int _3368 = NOVALUE;
    int _3367 = NOVALUE;
    int _3366 = NOVALUE;
    int _3365 = NOVALUE;
    int _3363 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_6418)){
            _3363 = SEQ_PTR(_items_6418)->length;
    }
    else {
        _3363 = 1;
    }
    if (_3363 != 0)
    goto L1; // [8] 16
    _3363 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_6418);
    DeRef(_delim_6419);
    DeRef(_ret_6421);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_6421);
    _ret_6421 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_6418)){
            _3365 = SEQ_PTR(_items_6418)->length;
    }
    else {
        _3365 = 1;
    }
    _3366 = _3365 - 1;
    _3365 = NOVALUE;
    {
        int _i_6426;
        _i_6426 = 1;
L2: 
        if (_i_6426 > _3366){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_6418);
        _3367 = (int)*(((s1_ptr)_2)->base + _i_6426);
        if (IS_SEQUENCE(_3367) && IS_ATOM(_delim_6419)) {
            Ref(_delim_6419);
            Append(&_3368, _3367, _delim_6419);
        }
        else if (IS_ATOM(_3367) && IS_SEQUENCE(_delim_6419)) {
            Ref(_3367);
            Prepend(&_3368, _delim_6419, _3367);
        }
        else {
            Concat((object_ptr)&_3368, _3367, _delim_6419);
            _3367 = NOVALUE;
        }
        _3367 = NOVALUE;
        if (IS_SEQUENCE(_ret_6421) && IS_ATOM(_3368)) {
        }
        else if (IS_ATOM(_ret_6421) && IS_SEQUENCE(_3368)) {
            Ref(_ret_6421);
            Prepend(&_ret_6421, _3368, _ret_6421);
        }
        else {
            Concat((object_ptr)&_ret_6421, _ret_6421, _3368);
        }
        DeRefDS(_3368);
        _3368 = NOVALUE;

        /** 	end for*/
        _i_6426 = _i_6426 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_6418)){
            _3370 = SEQ_PTR(_items_6418)->length;
    }
    else {
        _3370 = 1;
    }
    _2 = (int)SEQ_PTR(_items_6418);
    _3371 = (int)*(((s1_ptr)_2)->base + _3370);
    if (IS_SEQUENCE(_ret_6421) && IS_ATOM(_3371)) {
        Ref(_3371);
        Append(&_ret_6421, _ret_6421, _3371);
    }
    else if (IS_ATOM(_ret_6421) && IS_SEQUENCE(_3371)) {
        Ref(_ret_6421);
        Prepend(&_ret_6421, _3371, _ret_6421);
    }
    else {
        Concat((object_ptr)&_ret_6421, _ret_6421, _3371);
    }
    _3371 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_6418);
    DeRef(_delim_6419);
    DeRef(_3366);
    _3366 = NOVALUE;
    return _ret_6421;
    ;
}


int  __stdcall _23breakup(int _source_6439, int _size_6440, int _style_6441)
{
    int _len_6450 = NOVALUE;
    int _rem_6451 = NOVALUE;
    int _ns_6492 = NOVALUE;
    int _source_idx_6495 = NOVALUE;
    int _k_6502 = NOVALUE;
    int _3430 = NOVALUE;
    int _3429 = NOVALUE;
    int _3427 = NOVALUE;
    int _3424 = NOVALUE;
    int _3422 = NOVALUE;
    int _3421 = NOVALUE;
    int _3420 = NOVALUE;
    int _3419 = NOVALUE;
    int _3417 = NOVALUE;
    int _3416 = NOVALUE;
    int _3415 = NOVALUE;
    int _3414 = NOVALUE;
    int _3412 = NOVALUE;
    int _3411 = NOVALUE;
    int _3409 = NOVALUE;
    int _3407 = NOVALUE;
    int _3406 = NOVALUE;
    int _3404 = NOVALUE;
    int _3401 = NOVALUE;
    int _3400 = NOVALUE;
    int _3397 = NOVALUE;
    int _3396 = NOVALUE;
    int _3392 = NOVALUE;
    int _3387 = NOVALUE;
    int _3385 = NOVALUE;
    int _3384 = NOVALUE;
    int _3383 = NOVALUE;
    int _3382 = NOVALUE;
    int _3380 = NOVALUE;
    int _3378 = NOVALUE;
    int _3376 = NOVALUE;
    int _3375 = NOVALUE;
    int _3374 = NOVALUE;
    int _3373 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_style_6441)) {
        _1 = (long)(DBL_PTR(_style_6441)->dbl);
        DeRefDS(_style_6441);
        _style_6441 = _1;
    }

    /** 	if atom(size) and not integer(size) then*/
    _3373 = IS_ATOM(_size_6440);
    if (_3373 == 0) {
        goto L1; // [10] 30
    }
    if (IS_ATOM_INT(_size_6440))
    _3375 = 1;
    else if (IS_ATOM_DBL(_size_6440))
    _3375 = IS_ATOM_INT(DoubleToInt(_size_6440));
    else
    _3375 = 0;
    _3376 = (_3375 == 0);
    _3375 = NOVALUE;
    if (_3376 == 0)
    {
        DeRef(_3376);
        _3376 = NOVALUE;
        goto L1; // [21] 30
    }
    else{
        DeRef(_3376);
        _3376 = NOVALUE;
    }

    /** 		size = floor(size)*/
    _0 = _size_6440;
    if (IS_ATOM_INT(_size_6440))
    _size_6440 = e_floor(_size_6440);
    else
    _size_6440 = unary_op(FLOOR, _size_6440);
    DeRef(_0);
L1: 

    /** 	if integer(size) then*/
    if (IS_ATOM_INT(_size_6440))
    _3378 = 1;
    else if (IS_ATOM_DBL(_size_6440))
    _3378 = IS_ATOM_INT(DoubleToInt(_size_6440));
    else
    _3378 = 0;
    if (_3378 == 0)
    {
        _3378 = NOVALUE;
        goto L2; // [35] 253
    }
    else{
        _3378 = NOVALUE;
    }

    /** 		integer len*/

    /** 		integer rem*/

    /** 		if style = BK_LEN then*/
    if (_style_6441 != 1)
    goto L3; // [44] 125

    /** 			if size < 1 or size >= length(source) then*/
    if (IS_ATOM_INT(_size_6440)) {
        _3380 = (_size_6440 < 1);
    }
    else {
        _3380 = binary_op(LESS, _size_6440, 1);
    }
    if (IS_ATOM_INT(_3380)) {
        if (_3380 != 0) {
            goto L4; // [54] 70
        }
    }
    else {
        if (DBL_PTR(_3380)->dbl != 0.0) {
            goto L4; // [54] 70
        }
    }
    if (IS_SEQUENCE(_source_6439)){
            _3382 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3382 = 1;
    }
    if (IS_ATOM_INT(_size_6440)) {
        _3383 = (_size_6440 >= _3382);
    }
    else {
        _3383 = binary_op(GREATEREQ, _size_6440, _3382);
    }
    _3382 = NOVALUE;
    if (_3383 == 0) {
        DeRef(_3383);
        _3383 = NOVALUE;
        goto L5; // [66] 81
    }
    else {
        if (!IS_ATOM_INT(_3383) && DBL_PTR(_3383)->dbl == 0.0){
            DeRef(_3383);
            _3383 = NOVALUE;
            goto L5; // [66] 81
        }
        DeRef(_3383);
        _3383 = NOVALUE;
    }
    DeRef(_3383);
    _3383 = NOVALUE;
L4: 

    /** 				return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6439);
    *((int *)(_2+4)) = _source_6439;
    _3384 = MAKE_SEQ(_1);
    DeRefDS(_source_6439);
    DeRef(_size_6440);
    DeRef(_ns_6492);
    DeRef(_3380);
    _3380 = NOVALUE;
    return _3384;
L5: 

    /** 			len = floor(length(source) / size)*/
    if (IS_SEQUENCE(_source_6439)){
            _3385 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3385 = 1;
    }
    if (IS_ATOM_INT(_size_6440)) {
        if (_size_6440 > 0 && _3385 >= 0) {
            _len_6450 = _3385 / _size_6440;
        }
        else {
            temp_dbl = floor((double)_3385 / (double)_size_6440);
            _len_6450 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _3385, _size_6440);
        _len_6450 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _3385 = NOVALUE;
    if (!IS_ATOM_INT(_len_6450)) {
        _1 = (long)(DBL_PTR(_len_6450)->dbl);
        DeRefDS(_len_6450);
        _len_6450 = _1;
    }

    /** 			rem = remainder(length(source), size)*/
    if (IS_SEQUENCE(_source_6439)){
            _3387 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3387 = 1;
    }
    if (IS_ATOM_INT(_size_6440)) {
        _rem_6451 = (_3387 % _size_6440);
    }
    else {
        _rem_6451 = binary_op(REMAINDER, _3387, _size_6440);
    }
    _3387 = NOVALUE;
    if (!IS_ATOM_INT(_rem_6451)) {
        _1 = (long)(DBL_PTR(_rem_6451)->dbl);
        DeRefDS(_rem_6451);
        _rem_6451 = _1;
    }

    /** 			size = repeat(size, len)*/
    _0 = _size_6440;
    _size_6440 = Repeat(_size_6440, _len_6450);
    DeRef(_0);

    /** 			if rem > 0 then*/
    if (_rem_6451 <= 0)
    goto L6; // [111] 252

    /** 				size &= rem*/
    Append(&_size_6440, _size_6440, _rem_6451);
    goto L6; // [122] 252
L3: 

    /** 			if size > length(source) then*/
    if (IS_SEQUENCE(_source_6439)){
            _3392 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3392 = 1;
    }
    if (binary_op_a(LESSEQ, _size_6440, _3392)){
        _3392 = NOVALUE;
        goto L7; // [130] 140
    }
    _3392 = NOVALUE;

    /** 				size = length(source)*/
    DeRef(_size_6440);
    if (IS_SEQUENCE(_source_6439)){
            _size_6440 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _size_6440 = 1;
    }
L7: 

    /** 			if size < 1 then*/
    if (binary_op_a(GREATEREQ, _size_6440, 1)){
        goto L8; // [142] 157
    }

    /** 				return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6439);
    *((int *)(_2+4)) = _source_6439;
    _3396 = MAKE_SEQ(_1);
    DeRefDS(_source_6439);
    DeRef(_size_6440);
    DeRef(_ns_6492);
    DeRef(_3380);
    _3380 = NOVALUE;
    DeRef(_3384);
    _3384 = NOVALUE;
    return _3396;
L8: 

    /** 			len = floor(length(source) / size)*/
    if (IS_SEQUENCE(_source_6439)){
            _3397 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3397 = 1;
    }
    if (IS_ATOM_INT(_size_6440)) {
        if (_size_6440 > 0 && _3397 >= 0) {
            _len_6450 = _3397 / _size_6440;
        }
        else {
            temp_dbl = floor((double)_3397 / (double)_size_6440);
            _len_6450 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _3397, _size_6440);
        _len_6450 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _3397 = NOVALUE;
    if (!IS_ATOM_INT(_len_6450)) {
        _1 = (long)(DBL_PTR(_len_6450)->dbl);
        DeRefDS(_len_6450);
        _len_6450 = _1;
    }

    /** 			if len < 1 then*/
    if (_len_6450 >= 1)
    goto L9; // [170] 180

    /** 				len = 1*/
    _len_6450 = 1;
L9: 

    /** 			rem = length(source) - (size * len)*/
    if (IS_SEQUENCE(_source_6439)){
            _3400 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3400 = 1;
    }
    if (IS_ATOM_INT(_size_6440)) {
        if (_size_6440 == (short)_size_6440 && _len_6450 <= INT15 && _len_6450 >= -INT15)
        _3401 = _size_6440 * _len_6450;
        else
        _3401 = NewDouble(_size_6440 * (double)_len_6450);
    }
    else {
        _3401 = binary_op(MULTIPLY, _size_6440, _len_6450);
    }
    if (IS_ATOM_INT(_3401)) {
        _rem_6451 = _3400 - _3401;
    }
    else {
        _rem_6451 = binary_op(MINUS, _3400, _3401);
    }
    _3400 = NOVALUE;
    DeRef(_3401);
    _3401 = NOVALUE;
    if (!IS_ATOM_INT(_rem_6451)) {
        _1 = (long)(DBL_PTR(_rem_6451)->dbl);
        DeRefDS(_rem_6451);
        _rem_6451 = _1;
    }

    /** 			size = repeat(len, size)*/
    _0 = _size_6440;
    _size_6440 = Repeat(_len_6450, _size_6440);
    DeRef(_0);

    /** 			for i = 1 to length(size) do*/
    if (IS_SEQUENCE(_size_6440)){
            _3404 = SEQ_PTR(_size_6440)->length;
    }
    else {
        _3404 = 1;
    }
    {
        int _i_6485;
        _i_6485 = 1;
LA: 
        if (_i_6485 > _3404){
            goto LB; // [206] 251
        }

        /** 				if rem = 0 then*/
        if (_rem_6451 != 0)
        goto LC; // [215] 224

        /** 					exit*/
        goto LB; // [221] 251
LC: 

        /** 				size[i] += 1*/
        _2 = (int)SEQ_PTR(_size_6440);
        _3406 = (int)*(((s1_ptr)_2)->base + _i_6485);
        if (IS_ATOM_INT(_3406)) {
            _3407 = _3406 + 1;
            if (_3407 > MAXINT){
                _3407 = NewDouble((double)_3407);
            }
        }
        else
        _3407 = binary_op(PLUS, 1, _3406);
        _3406 = NOVALUE;
        _2 = (int)SEQ_PTR(_size_6440);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _size_6440 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6485);
        _1 = *(int *)_2;
        *(int *)_2 = _3407;
        if( _1 != _3407 ){
            DeRef(_1);
        }
        _3407 = NOVALUE;

        /** 				rem -= 1*/
        _rem_6451 = _rem_6451 - 1;

        /** 			end for*/
        _i_6485 = _i_6485 + 1;
        goto LA; // [246] 213
LB: 
        ;
    }
L6: 
L2: 

    /** 	sequence ns = repeat(0, length(size))*/
    if (IS_SEQUENCE(_size_6440)){
            _3409 = SEQ_PTR(_size_6440)->length;
    }
    else {
        _3409 = 1;
    }
    DeRef(_ns_6492);
    _ns_6492 = Repeat(0, _3409);
    _3409 = NOVALUE;

    /** 	integer source_idx = 1*/
    _source_idx_6495 = 1;

    /** 	for i = 1 to length(size) do*/
    if (IS_SEQUENCE(_size_6440)){
            _3411 = SEQ_PTR(_size_6440)->length;
    }
    else {
        _3411 = 1;
    }
    {
        int _i_6497;
        _i_6497 = 1;
LD: 
        if (_i_6497 > _3411){
            goto LE; // [274] 408
        }

        /** 		if source_idx <= length(source) then*/
        if (IS_SEQUENCE(_source_6439)){
                _3412 = SEQ_PTR(_source_6439)->length;
        }
        else {
            _3412 = 1;
        }
        if (_source_idx_6495 > _3412)
        goto LF; // [286] 394

        /** 			integer k = 1*/
        _k_6502 = 1;

        /** 			ns[i] = repeat(0, size[i])*/
        _2 = (int)SEQ_PTR(_size_6440);
        _3414 = (int)*(((s1_ptr)_2)->base + _i_6497);
        _3415 = Repeat(0, _3414);
        _3414 = NOVALUE;
        _2 = (int)SEQ_PTR(_ns_6492);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ns_6492 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6497);
        _1 = *(int *)_2;
        *(int *)_2 = _3415;
        if( _1 != _3415 ){
            DeRef(_1);
        }
        _3415 = NOVALUE;

        /** 			for j = 1 to size[i] do*/
        _2 = (int)SEQ_PTR(_size_6440);
        _3416 = (int)*(((s1_ptr)_2)->base + _i_6497);
        {
            int _j_6506;
            _j_6506 = 1;
L10: 
            if (binary_op_a(GREATER, _j_6506, _3416)){
                goto L11; // [315] 389
            }

            /** 				if source_idx > length(source) then*/
            if (IS_SEQUENCE(_source_6439)){
                    _3417 = SEQ_PTR(_source_6439)->length;
            }
            else {
                _3417 = 1;
            }
            if (_source_idx_6495 <= _3417)
            goto L12; // [327] 355

            /** 					ns[i] = ns[i][1 .. k-1]*/
            _2 = (int)SEQ_PTR(_ns_6492);
            _3419 = (int)*(((s1_ptr)_2)->base + _i_6497);
            _3420 = _k_6502 - 1;
            rhs_slice_target = (object_ptr)&_3421;
            RHS_Slice(_3419, 1, _3420);
            _3419 = NOVALUE;
            _2 = (int)SEQ_PTR(_ns_6492);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _ns_6492 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_6497);
            _1 = *(int *)_2;
            *(int *)_2 = _3421;
            if( _1 != _3421 ){
                DeRef(_1);
            }
            _3421 = NOVALUE;

            /** 					exit*/
            goto L11; // [352] 389
L12: 

            /** 				ns[i][k] = source[source_idx]*/
            _2 = (int)SEQ_PTR(_ns_6492);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _ns_6492 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_6497 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_source_6439);
            _3424 = (int)*(((s1_ptr)_2)->base + _source_idx_6495);
            Ref(_3424);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_6502);
            _1 = *(int *)_2;
            *(int *)_2 = _3424;
            if( _1 != _3424 ){
                DeRef(_1);
            }
            _3424 = NOVALUE;
            _3422 = NOVALUE;

            /** 				k += 1*/
            _k_6502 = _k_6502 + 1;

            /** 				source_idx += 1*/
            _source_idx_6495 = _source_idx_6495 + 1;

            /** 			end for*/
            _0 = _j_6506;
            if (IS_ATOM_INT(_j_6506)) {
                _j_6506 = _j_6506 + 1;
                if ((long)((unsigned long)_j_6506 +(unsigned long) HIGH_BITS) >= 0){
                    _j_6506 = NewDouble((double)_j_6506);
                }
            }
            else {
                _j_6506 = binary_op_a(PLUS, _j_6506, 1);
            }
            DeRef(_0);
            goto L10; // [384] 322
L11: 
            ;
            DeRef(_j_6506);
        }
        goto L13; // [391] 401
LF: 

        /** 			ns[i] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_ns_6492);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ns_6492 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6497);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
L13: 

        /** 	end for*/
        _i_6497 = _i_6497 + 1;
        goto LD; // [403] 281
LE: 
        ;
    }

    /** 	if source_idx <= length(source) then*/
    if (IS_SEQUENCE(_source_6439)){
            _3427 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3427 = 1;
    }
    if (_source_idx_6495 > _3427)
    goto L14; // [413] 432

    /** 		ns = append(ns, source[source_idx .. $])*/
    if (IS_SEQUENCE(_source_6439)){
            _3429 = SEQ_PTR(_source_6439)->length;
    }
    else {
        _3429 = 1;
    }
    rhs_slice_target = (object_ptr)&_3430;
    RHS_Slice(_source_6439, _source_idx_6495, _3429);
    RefDS(_3430);
    Append(&_ns_6492, _ns_6492, _3430);
    DeRefDS(_3430);
    _3430 = NOVALUE;
L14: 

    /** 	return ns*/
    DeRefDS(_source_6439);
    DeRef(_size_6440);
    DeRef(_3380);
    _3380 = NOVALUE;
    DeRef(_3384);
    _3384 = NOVALUE;
    DeRef(_3396);
    _3396 = NOVALUE;
    _3416 = NOVALUE;
    DeRef(_3420);
    _3420 = NOVALUE;
    return _ns_6492;
    ;
}


int  __stdcall _23flatten(int _s_6528, int _delim_6529)
{
    int _ret_6530 = NOVALUE;
    int _x_6531 = NOVALUE;
    int _len_6532 = NOVALUE;
    int _pos_6533 = NOVALUE;
    int _temp_6551 = NOVALUE;
    int _3457 = NOVALUE;
    int _3456 = NOVALUE;
    int _3455 = NOVALUE;
    int _3453 = NOVALUE;
    int _3452 = NOVALUE;
    int _3451 = NOVALUE;
    int _3449 = NOVALUE;
    int _3447 = NOVALUE;
    int _3446 = NOVALUE;
    int _3445 = NOVALUE;
    int _3443 = NOVALUE;
    int _3442 = NOVALUE;
    int _3441 = NOVALUE;
    int _3440 = NOVALUE;
    int _3439 = NOVALUE;
    int _3438 = NOVALUE;
    int _3436 = NOVALUE;
    int _3435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_6528);
    DeRef(_ret_6530);
    _ret_6530 = _s_6528;

    /** 	pos = 1*/
    _pos_6533 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_6530)){
            _len_6532 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _len_6532 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_6533 > _len_6532)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_6531);
    _2 = (int)SEQ_PTR(_ret_6530);
    _x_6531 = (int)*(((s1_ptr)_2)->base + _pos_6533);
    Ref(_x_6531);

    /** 		if sequence(x) then*/
    _3435 = IS_SEQUENCE(_x_6531);
    if (_3435 == 0)
    {
        _3435 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _3435 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_6529)){
            _3436 = SEQ_PTR(_delim_6529)->length;
    }
    else {
        _3436 = 1;
    }
    if (_3436 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _3438 = _pos_6533 - 1;
    rhs_slice_target = (object_ptr)&_3439;
    RHS_Slice(_ret_6530, 1, _3438);
    Ref(_x_6531);
    RefDS(_5);
    _3440 = _23flatten(_x_6531, _5);
    _3441 = _pos_6533 + 1;
    if (_3441 > MAXINT){
        _3441 = NewDouble((double)_3441);
    }
    if (IS_SEQUENCE(_ret_6530)){
            _3442 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _3442 = 1;
    }
    rhs_slice_target = (object_ptr)&_3443;
    RHS_Slice(_ret_6530, _3441, _3442);
    {
        int concat_list[3];

        concat_list[0] = _3443;
        concat_list[1] = _3440;
        concat_list[2] = _3439;
        Concat_N((object_ptr)&_ret_6530, concat_list, 3);
    }
    DeRefDS(_3443);
    _3443 = NOVALUE;
    DeRef(_3440);
    _3440 = NOVALUE;
    DeRefDS(_3439);
    _3439 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _3445 = _pos_6533 - 1;
    rhs_slice_target = (object_ptr)&_3446;
    RHS_Slice(_ret_6530, 1, _3445);
    Ref(_x_6531);
    RefDS(_5);
    _3447 = _23flatten(_x_6531, _5);
    if (IS_SEQUENCE(_3446) && IS_ATOM(_3447)) {
        Ref(_3447);
        Append(&_temp_6551, _3446, _3447);
    }
    else if (IS_ATOM(_3446) && IS_SEQUENCE(_3447)) {
    }
    else {
        Concat((object_ptr)&_temp_6551, _3446, _3447);
        DeRefDS(_3446);
        _3446 = NOVALUE;
    }
    DeRef(_3446);
    _3446 = NOVALUE;
    DeRef(_3447);
    _3447 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_6530)){
            _3449 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _3449 = 1;
    }
    if (_pos_6533 == _3449)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _3451 = _pos_6533 + 1;
    if (_3451 > MAXINT){
        _3451 = NewDouble((double)_3451);
    }
    if (IS_SEQUENCE(_ret_6530)){
            _3452 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _3452 = 1;
    }
    rhs_slice_target = (object_ptr)&_3453;
    RHS_Slice(_ret_6530, _3451, _3452);
    {
        int concat_list[3];

        concat_list[0] = _3453;
        concat_list[1] = _delim_6529;
        concat_list[2] = _temp_6551;
        Concat_N((object_ptr)&_ret_6530, concat_list, 3);
    }
    DeRefDS(_3453);
    _3453 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _3455 = _pos_6533 + 1;
    if (_3455 > MAXINT){
        _3455 = NewDouble((double)_3455);
    }
    if (IS_SEQUENCE(_ret_6530)){
            _3456 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _3456 = 1;
    }
    rhs_slice_target = (object_ptr)&_3457;
    RHS_Slice(_ret_6530, _3455, _3456);
    Concat((object_ptr)&_ret_6530, _temp_6551, _3457);
    DeRefDS(_3457);
    _3457 = NOVALUE;
L7: 
    DeRef(_temp_6551);
    _temp_6551 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_6530)){
            _len_6532 = SEQ_PTR(_ret_6530)->length;
    }
    else {
        _len_6532 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_6533 = _pos_6533 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_6528);
    DeRef(_delim_6529);
    DeRef(_x_6531);
    DeRef(_3438);
    _3438 = NOVALUE;
    DeRef(_3445);
    _3445 = NOVALUE;
    DeRef(_3451);
    _3451 = NOVALUE;
    DeRef(_3441);
    _3441 = NOVALUE;
    DeRef(_3455);
    _3455 = NOVALUE;
    return _ret_6530;
    ;
}


int  __stdcall _23pivot(int _data_p_6573, int _pivot_p_6574)
{
    int _result__6575 = NOVALUE;
    int _pos__6576 = NOVALUE;
    int _3470 = NOVALUE;
    int _3469 = NOVALUE;
    int _3468 = NOVALUE;
    int _3466 = NOVALUE;
    int _3465 = NOVALUE;
    int _3464 = NOVALUE;
    int _3462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_ = {{}, {}, {}}*/
    _0 = _result__6575;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_5, 3);
    *((int *)(_2+4)) = _5;
    *((int *)(_2+8)) = _5;
    *((int *)(_2+12)) = _5;
    _result__6575 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if atom(data_p) then*/
    _3462 = IS_ATOM(_data_p_6573);
    if (_3462 == 0)
    {
        _3462 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _3462 = NOVALUE;
    }

    /** 		data_p = {data_p}*/
    _0 = _data_p_6573;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_p_6573);
    *((int *)(_2+4)) = _data_p_6573;
    _data_p_6573 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(data_p) do*/
    if (IS_SEQUENCE(_data_p_6573)){
            _3464 = SEQ_PTR(_data_p_6573)->length;
    }
    else {
        _3464 = 1;
    }
    {
        int _i_6582;
        _i_6582 = 1;
L2: 
        if (_i_6582 > _3464){
            goto L3; // [29] 75
        }

        /** 		pos_ = eu:compare(data_p[i], pivot_p) + 2*/
        _2 = (int)SEQ_PTR(_data_p_6573);
        _3465 = (int)*(((s1_ptr)_2)->base + _i_6582);
        if (IS_ATOM_INT(_3465) && IS_ATOM_INT(_pivot_p_6574)){
            _3466 = (_3465 < _pivot_p_6574) ? -1 : (_3465 > _pivot_p_6574);
        }
        else{
            _3466 = compare(_3465, _pivot_p_6574);
        }
        _3465 = NOVALUE;
        _pos__6576 = _3466 + 2;
        _3466 = NOVALUE;

        /** 		result_[pos_] = append(result_[pos_], data_p[i])*/
        _2 = (int)SEQ_PTR(_result__6575);
        _3468 = (int)*(((s1_ptr)_2)->base + _pos__6576);
        _2 = (int)SEQ_PTR(_data_p_6573);
        _3469 = (int)*(((s1_ptr)_2)->base + _i_6582);
        Ref(_3469);
        Append(&_3470, _3468, _3469);
        _3468 = NOVALUE;
        _3469 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__6575);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__6575 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__6576);
        _1 = *(int *)_2;
        *(int *)_2 = _3470;
        if( _1 != _3470 ){
            DeRefDS(_1);
        }
        _3470 = NOVALUE;

        /** 	end for*/
        _i_6582 = _i_6582 + 1;
        goto L2; // [70] 36
L3: 
        ;
    }

    /** 	return result_*/
    DeRef(_data_p_6573);
    DeRef(_pivot_p_6574);
    return _result__6575;
    ;
}


int  __stdcall _23build_list(int _source_6592, int _transformer_6593, int _singleton_6594, int _user_data_6595)
{
    int _result_6596 = NOVALUE;
    int _x_6597 = NOVALUE;
    int _new_x_6598 = NOVALUE;
    int _3487 = NOVALUE;
    int _3485 = NOVALUE;
    int _3483 = NOVALUE;
    int _3481 = NOVALUE;
    int _3479 = NOVALUE;
    int _3478 = NOVALUE;
    int _3476 = NOVALUE;
    int _3475 = NOVALUE;
    int _3474 = NOVALUE;
    int _3473 = NOVALUE;
    int _3471 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_singleton_6594)) {
        _1 = (long)(DBL_PTR(_singleton_6594)->dbl);
        DeRefDS(_singleton_6594);
        _singleton_6594 = _1;
    }

    /** 	sequence result = {}*/
    RefDS(_5);
    DeRef(_result_6596);
    _result_6596 = _5;

    /** 	if atom(transformer) then*/
    _3471 = IS_ATOM(_transformer_6593);
    if (_3471 == 0)
    {
        _3471 = NOVALUE;
        goto L1; // [17] 27
    }
    else{
        _3471 = NOVALUE;
    }

    /** 		transformer = {transformer}*/
    _0 = _transformer_6593;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_transformer_6593);
    *((int *)(_2+4)) = _transformer_6593;
    _transformer_6593 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_6592)){
            _3473 = SEQ_PTR(_source_6592)->length;
    }
    else {
        _3473 = 1;
    }
    {
        int _i_6603;
        _i_6603 = 1;
L2: 
        if (_i_6603 > _3473){
            goto L3; // [32] 193
        }

        /** 		x = {source[i], {i, length(source)}, user_data}*/
        _2 = (int)SEQ_PTR(_source_6592);
        _3474 = (int)*(((s1_ptr)_2)->base + _i_6603);
        if (IS_SEQUENCE(_source_6592)){
                _3475 = SEQ_PTR(_source_6592)->length;
        }
        else {
            _3475 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_6603;
        ((int *)_2)[2] = _3475;
        _3476 = MAKE_SEQ(_1);
        _3475 = NOVALUE;
        _0 = _x_6597;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_3474);
        *((int *)(_2+4)) = _3474;
        *((int *)(_2+8)) = _3476;
        Ref(_user_data_6595);
        *((int *)(_2+12)) = _user_data_6595;
        _x_6597 = MAKE_SEQ(_1);
        DeRef(_0);
        _3476 = NOVALUE;
        _3474 = NOVALUE;

        /** 		for j = 1 to length(transformer) do*/
        if (IS_SEQUENCE(_transformer_6593)){
                _3478 = SEQ_PTR(_transformer_6593)->length;
        }
        else {
            _3478 = 1;
        }
        {
            int _j_6610;
            _j_6610 = 1;
L4: 
            if (_j_6610 > _3478){
                goto L5; // [63] 186
            }

            /** 			if transformer[j] >= 0 then*/
            _2 = (int)SEQ_PTR(_transformer_6593);
            _3479 = (int)*(((s1_ptr)_2)->base + _j_6610);
            if (binary_op_a(LESS, _3479, 0)){
                _3479 = NOVALUE;
                goto L6; // [76] 143
            }
            _3479 = NOVALUE;

            /** 				new_x = call_func(transformer[j], x)*/
            _2 = (int)SEQ_PTR(_transformer_6593);
            _3481 = (int)*(((s1_ptr)_2)->base + _j_6610);
            _1 = (int)SEQ_PTR(_x_6597);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_3481].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_3481].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            DeRef(_new_x_6598);
            _new_x_6598 = _1;

            /** 				if length(new_x) = 0 then*/
            if (IS_SEQUENCE(_new_x_6598)){
                    _3483 = SEQ_PTR(_new_x_6598)->length;
            }
            else {
                _3483 = 1;
            }
            if (_3483 != 0)
            goto L7; // [95] 104

            /** 					continue*/
            goto L8; // [101] 181
L7: 

            /** 				if new_x[1] = 0 then*/
            _2 = (int)SEQ_PTR(_new_x_6598);
            _3485 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _3485, 0)){
                _3485 = NOVALUE;
                goto L9; // [110] 119
            }
            _3485 = NOVALUE;

            /** 					continue*/
            goto L8; // [116] 181
L9: 

            /** 				if new_x[1] < 0 then*/
            _2 = (int)SEQ_PTR(_new_x_6598);
            _3487 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(GREATEREQ, _3487, 0)){
                _3487 = NOVALUE;
                goto LA; // [125] 134
            }
            _3487 = NOVALUE;

            /** 					exit*/
            goto L5; // [131] 186
LA: 

            /** 				new_x = new_x[2]*/
            _0 = _new_x_6598;
            _2 = (int)SEQ_PTR(_new_x_6598);
            _new_x_6598 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_new_x_6598);
            DeRef(_0);
            goto LB; // [140] 150
L6: 

            /** 				new_x = x[1]*/
            DeRef(_new_x_6598);
            _2 = (int)SEQ_PTR(_x_6597);
            _new_x_6598 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_new_x_6598);
LB: 

            /** 			if singleton then*/
            if (_singleton_6594 == 0)
            {
                goto LC; // [152] 166
            }
            else{
            }

            /** 				result = append(result, new_x)*/
            Ref(_new_x_6598);
            Append(&_result_6596, _result_6596, _new_x_6598);
            goto L5; // [163] 186
LC: 

            /** 				result &= new_x*/
            if (IS_SEQUENCE(_result_6596) && IS_ATOM(_new_x_6598)) {
                Ref(_new_x_6598);
                Append(&_result_6596, _result_6596, _new_x_6598);
            }
            else if (IS_ATOM(_result_6596) && IS_SEQUENCE(_new_x_6598)) {
            }
            else {
                Concat((object_ptr)&_result_6596, _result_6596, _new_x_6598);
            }

            /** 			exit*/
            goto L5; // [177] 186

            /** 		end for*/
L8: 
            _j_6610 = _j_6610 + 1;
            goto L4; // [181] 70
L5: 
            ;
        }

        /** 	end for*/
        _i_6603 = _i_6603 + 1;
        goto L2; // [188] 39
L3: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_6592);
    DeRef(_transformer_6593);
    DeRef(_user_data_6595);
    DeRef(_x_6597);
    DeRef(_new_x_6598);
    _3481 = NOVALUE;
    return _result_6596;
    ;
}


int  __stdcall _23transform(int _source_data_6635, int _transformer_rids_6636)
{
    int _lResult_6637 = NOVALUE;
    int _3507 = NOVALUE;
    int _3506 = NOVALUE;
    int _3505 = NOVALUE;
    int _3504 = NOVALUE;
    int _3503 = NOVALUE;
    int _3502 = NOVALUE;
    int _3501 = NOVALUE;
    int _3499 = NOVALUE;
    int _3498 = NOVALUE;
    int _3497 = NOVALUE;
    int _3496 = NOVALUE;
    int _3495 = NOVALUE;
    int _3493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lResult = source_data*/
    RefDS(_source_data_6635);
    DeRef(_lResult_6637);
    _lResult_6637 = _source_data_6635;

    /** 	if atom(transformer_rids) then*/
    _3493 = IS_ATOM(_transformer_rids_6636);
    if (_3493 == 0)
    {
        _3493 = NOVALUE;
        goto L1; // [15] 25
    }
    else{
        _3493 = NOVALUE;
    }

    /** 		transformer_rids = {transformer_rids}*/
    _0 = _transformer_rids_6636;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_transformer_rids_6636);
    *((int *)(_2+4)) = _transformer_rids_6636;
    _transformer_rids_6636 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(transformer_rids) do*/
    if (IS_SEQUENCE(_transformer_rids_6636)){
            _3495 = SEQ_PTR(_transformer_rids_6636)->length;
    }
    else {
        _3495 = 1;
    }
    {
        int _i_6642;
        _i_6642 = 1;
L2: 
        if (_i_6642 > _3495){
            goto L3; // [30] 112
        }

        /** 		if atom(transformer_rids[i]) then*/
        _2 = (int)SEQ_PTR(_transformer_rids_6636);
        _3496 = (int)*(((s1_ptr)_2)->base + _i_6642);
        _3497 = IS_ATOM(_3496);
        _3496 = NOVALUE;
        if (_3497 == 0)
        {
            _3497 = NOVALUE;
            goto L4; // [46] 68
        }
        else{
            _3497 = NOVALUE;
        }

        /** 			lResult = call_func(transformer_rids[i], {lResult})*/
        _2 = (int)SEQ_PTR(_transformer_rids_6636);
        _3498 = (int)*(((s1_ptr)_2)->base + _i_6642);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_lResult_6637);
        *((int *)(_2+4)) = _lResult_6637;
        _3499 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_3499);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_3498].addr;
        Ref(*(int *)(_2+4));
        if (_00[_3498].convention) {
            _1 = (*(int (__stdcall *)())_0)(
                                *(int *)(_2+4)
                                 );
        }
        else {
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
        }
        DeRefDS(_lResult_6637);
        _lResult_6637 = _1;
        DeRefDS(_3499);
        _3499 = NOVALUE;
        goto L5; // [65] 105
L4: 

        /** 			lResult = call_func(transformer_rids[i][1], {lResult} & transformer_rids[i][2..$])*/
        _2 = (int)SEQ_PTR(_transformer_rids_6636);
        _3501 = (int)*(((s1_ptr)_2)->base + _i_6642);
        _2 = (int)SEQ_PTR(_3501);
        _3502 = (int)*(((s1_ptr)_2)->base + 1);
        _3501 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_lResult_6637);
        *((int *)(_2+4)) = _lResult_6637;
        _3503 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_transformer_rids_6636);
        _3504 = (int)*(((s1_ptr)_2)->base + _i_6642);
        if (IS_SEQUENCE(_3504)){
                _3505 = SEQ_PTR(_3504)->length;
        }
        else {
            _3505 = 1;
        }
        rhs_slice_target = (object_ptr)&_3506;
        RHS_Slice(_3504, 2, _3505);
        _3504 = NOVALUE;
        Concat((object_ptr)&_3507, _3503, _3506);
        DeRefDS(_3503);
        _3503 = NOVALUE;
        DeRef(_3503);
        _3503 = NOVALUE;
        DeRefDS(_3506);
        _3506 = NOVALUE;
        _1 = (int)SEQ_PTR(_3507);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_3502].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                         );
                }
                break;
            case 1:
                Ref(*(int *)(_2+4));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4)
                                         );
                }
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8)
                                         );
                }
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12)
                                         );
                }
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16)
                                         );
                }
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20)
                                         );
                }
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                if (_00[_3502].convention) {
                    _1 = (*(int (__stdcall *)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                else {
                    _1 = (*(int (*)())_0)(
                                        *(int *)(_2+4), 
                                        *(int *)(_2+8), 
                                        *(int *)(_2+12), 
                                        *(int *)(_2+16), 
                                        *(int *)(_2+20), 
                                        *(int *)(_2+24)
                                         );
                }
                break;
        }
        DeRefDS(_lResult_6637);
        _lResult_6637 = _1;
        DeRefDS(_3507);
        _3507 = NOVALUE;
L5: 

        /** 	end for*/
        _i_6642 = _i_6642 + 1;
        goto L2; // [107] 37
L3: 
        ;
    }

    /** 	return lResult*/
    DeRefDS(_source_data_6635);
    DeRef(_transformer_rids_6636);
    _3498 = NOVALUE;
    _3502 = NOVALUE;
    return _lResult_6637;
    ;
}


int  __stdcall _23transmute(int _source_data_6661, int _current_items_6662, int _new_items_6663, int _start_6664, int _limit_6665)
{
    int _pos_6667 = NOVALUE;
    int _cs_6668 = NOVALUE;
    int _ns_6669 = NOVALUE;
    int _i_6670 = NOVALUE;
    int _elen_6671 = NOVALUE;
    int _3578 = NOVALUE;
    int _3577 = NOVALUE;
    int _3576 = NOVALUE;
    int _3574 = NOVALUE;
    int _3573 = NOVALUE;
    int _3571 = NOVALUE;
    int _3570 = NOVALUE;
    int _3569 = NOVALUE;
    int _3568 = NOVALUE;
    int _3567 = NOVALUE;
    int _3566 = NOVALUE;
    int _3565 = NOVALUE;
    int _3560 = NOVALUE;
    int _3558 = NOVALUE;
    int _3557 = NOVALUE;
    int _3556 = NOVALUE;
    int _3554 = NOVALUE;
    int _3553 = NOVALUE;
    int _3552 = NOVALUE;
    int _3551 = NOVALUE;
    int _3550 = NOVALUE;
    int _3549 = NOVALUE;
    int _3548 = NOVALUE;
    int _3543 = NOVALUE;
    int _3540 = NOVALUE;
    int _3539 = NOVALUE;
    int _3538 = NOVALUE;
    int _3536 = NOVALUE;
    int _3534 = NOVALUE;
    int _3529 = NOVALUE;
    int _3528 = NOVALUE;
    int _3526 = NOVALUE;
    int _3521 = NOVALUE;
    int _3516 = NOVALUE;
    int _3515 = NOVALUE;
    int _3514 = NOVALUE;
    int _3512 = NOVALUE;
    int _3511 = NOVALUE;
    int _3510 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_6664)) {
        _1 = (long)(DBL_PTR(_start_6664)->dbl);
        DeRefDS(_start_6664);
        _start_6664 = _1;
    }
    if (!IS_ATOM_INT(_limit_6665)) {
        _1 = (long)(DBL_PTR(_limit_6665)->dbl);
        DeRefDS(_limit_6665);
        _limit_6665 = _1;
    }

    /** 	if equal(current_items[1], {}) then*/
    _2 = (int)SEQ_PTR(_current_items_6662);
    _3510 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3510 == _5)
    _3511 = 1;
    else if (IS_ATOM_INT(_3510) && IS_ATOM_INT(_5))
    _3511 = 0;
    else
    _3511 = (compare(_3510, _5) == 0);
    _3510 = NOVALUE;
    if (_3511 == 0)
    {
        _3511 = NOVALUE;
        goto L1; // [21] 42
    }
    else{
        _3511 = NOVALUE;
    }

    /** 		cs = 1*/
    _cs_6668 = 1;

    /** 		current_items = current_items[2 .. $]*/
    if (IS_SEQUENCE(_current_items_6662)){
            _3512 = SEQ_PTR(_current_items_6662)->length;
    }
    else {
        _3512 = 1;
    }
    rhs_slice_target = (object_ptr)&_current_items_6662;
    RHS_Slice(_current_items_6662, 2, _3512);
    goto L2; // [39] 48
L1: 

    /** 		cs = 0*/
    _cs_6668 = 0;
L2: 

    /** 	if equal(new_items[1], {}) then*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3514 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3514 == _5)
    _3515 = 1;
    else if (IS_ATOM_INT(_3514) && IS_ATOM_INT(_5))
    _3515 = 0;
    else
    _3515 = (compare(_3514, _5) == 0);
    _3514 = NOVALUE;
    if (_3515 == 0)
    {
        _3515 = NOVALUE;
        goto L3; // [58] 79
    }
    else{
        _3515 = NOVALUE;
    }

    /** 		ns = 1*/
    _ns_6669 = 1;

    /** 		new_items = new_items[2 .. $]*/
    if (IS_SEQUENCE(_new_items_6663)){
            _3516 = SEQ_PTR(_new_items_6663)->length;
    }
    else {
        _3516 = 1;
    }
    rhs_slice_target = (object_ptr)&_new_items_6663;
    RHS_Slice(_new_items_6663, 2, _3516);
    goto L4; // [76] 85
L3: 

    /** 		ns = 0*/
    _ns_6669 = 0;
L4: 

    /** 	i = start - 1*/
    _i_6670 = _start_6664 - 1;

    /** 	if cs = 0 then*/
    if (_cs_6668 != 0)
    goto L5; // [95] 269

    /** 		if ns = 0 then*/
    if (_ns_6669 != 0)
    goto L6; // [103] 177

    /** 			while i < length(source_data) do*/
L7: 
    if (IS_SEQUENCE(_source_data_6661)){
            _3521 = SEQ_PTR(_source_data_6661)->length;
    }
    else {
        _3521 = 1;
    }
    if (_i_6670 >= _3521)
    goto L8; // [115] 567

    /** 				if limit <= 0 then*/
    if (_limit_6665 > 0)
    goto L9; // [121] 130

    /** 					exit*/
    goto L8; // [127] 567
L9: 

    /** 				limit -= 1*/
    _limit_6665 = _limit_6665 - 1;

    /** 				i += 1*/
    _i_6670 = _i_6670 + 1;

    /** 				pos = find(source_data[i], current_items) */
    _2 = (int)SEQ_PTR(_source_data_6661);
    _3526 = (int)*(((s1_ptr)_2)->base + _i_6670);
    _pos_6667 = find_from(_3526, _current_items_6662, 1);
    _3526 = NOVALUE;

    /** 				if pos then*/
    if (_pos_6667 == 0)
    {
        goto L7; // [155] 112
    }
    else{
    }

    /** 					source_data[i] = new_items[pos]*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3528 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    Ref(_3528);
    _2 = (int)SEQ_PTR(_source_data_6661);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _source_data_6661 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_6670);
    _1 = *(int *)_2;
    *(int *)_2 = _3528;
    if( _1 != _3528 ){
        DeRef(_1);
    }
    _3528 = NOVALUE;

    /** 			end while*/
    goto L7; // [171] 112
    goto L8; // [174] 567
L6: 

    /** 			while i < length(source_data) do*/
LA: 
    if (IS_SEQUENCE(_source_data_6661)){
            _3529 = SEQ_PTR(_source_data_6661)->length;
    }
    else {
        _3529 = 1;
    }
    if (_i_6670 >= _3529)
    goto L8; // [185] 567

    /** 				if limit <= 0 then*/
    if (_limit_6665 > 0)
    goto LB; // [191] 200

    /** 					exit*/
    goto L8; // [197] 567
LB: 

    /** 				limit -= 1*/
    _limit_6665 = _limit_6665 - 1;

    /** 				i += 1*/
    _i_6670 = _i_6670 + 1;

    /** 				pos = find(source_data[i], current_items) */
    _2 = (int)SEQ_PTR(_source_data_6661);
    _3534 = (int)*(((s1_ptr)_2)->base + _i_6670);
    _pos_6667 = find_from(_3534, _current_items_6662, 1);
    _3534 = NOVALUE;

    /** 				if pos then*/
    if (_pos_6667 == 0)
    {
        goto LA; // [225] 182
    }
    else{
    }

    /** 					source_data = replace(source_data, new_items[pos], i, i)*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3536 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    {
        int p1 = _source_data_6661;
        int p2 = _3536;
        int p3 = _i_6670;
        int p4 = _i_6670;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6661;
        Replace( &replace_params );
    }
    _3536 = NOVALUE;

    /** 					i += length(new_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3538 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    if (IS_SEQUENCE(_3538)){
            _3539 = SEQ_PTR(_3538)->length;
    }
    else {
        _3539 = 1;
    }
    _3538 = NOVALUE;
    _3540 = _3539 - 1;
    _3539 = NOVALUE;
    _i_6670 = _i_6670 + _3540;
    _3540 = NOVALUE;

    /** 			end while*/
    goto LA; // [262] 182
    goto L8; // [266] 567
L5: 

    /** 		if ns = 0 then*/
    if (_ns_6669 != 0)
    goto LC; // [273] 415

    /** 			while i < length(source_data) do*/
LD: 
    if (IS_SEQUENCE(_source_data_6661)){
            _3543 = SEQ_PTR(_source_data_6661)->length;
    }
    else {
        _3543 = 1;
    }
    if (_i_6670 >= _3543)
    goto LE; // [285] 566

    /** 				if limit <= 0 then*/
    if (_limit_6665 > 0)
    goto LF; // [291] 300

    /** 					exit*/
    goto LE; // [297] 566
LF: 

    /** 				limit -= 1*/
    _limit_6665 = _limit_6665 - 1;

    /** 				i += 1*/
    _i_6670 = _i_6670 + 1;

    /** 				pos = 0*/
    _pos_6667 = 0;

    /** 				for j = 1 to length(current_items) do*/
    if (IS_SEQUENCE(_current_items_6662)){
            _3548 = SEQ_PTR(_current_items_6662)->length;
    }
    else {
        _3548 = 1;
    }
    {
        int _j_6728;
        _j_6728 = 1;
L10: 
        if (_j_6728 > _3548){
            goto L11; // [322] 368
        }

        /** 					if search:begins(current_items[j], source_data[i .. $]) then*/
        _2 = (int)SEQ_PTR(_current_items_6662);
        _3549 = (int)*(((s1_ptr)_2)->base + _j_6728);
        if (IS_SEQUENCE(_source_data_6661)){
                _3550 = SEQ_PTR(_source_data_6661)->length;
        }
        else {
            _3550 = 1;
        }
        rhs_slice_target = (object_ptr)&_3551;
        RHS_Slice(_source_data_6661, _i_6670, _3550);
        Ref(_3549);
        _3552 = _9begins(_3549, _3551);
        _3549 = NOVALUE;
        _3551 = NOVALUE;
        if (_3552 == 0) {
            DeRef(_3552);
            _3552 = NOVALUE;
            goto L12; // [348] 361
        }
        else {
            if (!IS_ATOM_INT(_3552) && DBL_PTR(_3552)->dbl == 0.0){
                DeRef(_3552);
                _3552 = NOVALUE;
                goto L12; // [348] 361
            }
            DeRef(_3552);
            _3552 = NOVALUE;
        }
        DeRef(_3552);
        _3552 = NOVALUE;

        /** 						pos = j*/
        _pos_6667 = _j_6728;

        /** 						exit*/
        goto L11; // [358] 368
L12: 

        /** 				end for*/
        _j_6728 = _j_6728 + 1;
        goto L10; // [363] 329
L11: 
        ;
    }

    /** 				if pos then*/
    if (_pos_6667 == 0)
    {
        goto LD; // [370] 282
    }
    else{
    }

    /** 			    	elen = length(current_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_current_items_6662);
    _3553 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    if (IS_SEQUENCE(_3553)){
            _3554 = SEQ_PTR(_3553)->length;
    }
    else {
        _3554 = 1;
    }
    _3553 = NOVALUE;
    _elen_6671 = _3554 - 1;
    _3554 = NOVALUE;

    /** 					source_data = replace(source_data, {new_items[pos]}, i, i + elen)*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3556 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_3556);
    *((int *)(_2+4)) = _3556;
    _3557 = MAKE_SEQ(_1);
    _3556 = NOVALUE;
    _3558 = _i_6670 + _elen_6671;
    if ((long)((unsigned long)_3558 + (unsigned long)HIGH_BITS) >= 0) 
    _3558 = NewDouble((double)_3558);
    {
        int p1 = _source_data_6661;
        int p2 = _3557;
        int p3 = _i_6670;
        int p4 = _3558;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6661;
        Replace( &replace_params );
    }
    DeRefDS(_3557);
    _3557 = NOVALUE;
    DeRef(_3558);
    _3558 = NOVALUE;

    /** 			end while*/
    goto LD; // [409] 282
    goto LE; // [412] 566
LC: 

    /** 			while i < length(source_data) do*/
L13: 
    if (IS_SEQUENCE(_source_data_6661)){
            _3560 = SEQ_PTR(_source_data_6661)->length;
    }
    else {
        _3560 = 1;
    }
    if (_i_6670 >= _3560)
    goto L14; // [423] 565

    /** 				if limit <= 0 then*/
    if (_limit_6665 > 0)
    goto L15; // [429] 438

    /** 					exit*/
    goto L14; // [435] 565
L15: 

    /** 				limit -= 1*/
    _limit_6665 = _limit_6665 - 1;

    /** 				i += 1*/
    _i_6670 = _i_6670 + 1;

    /** 				pos = 0*/
    _pos_6667 = 0;

    /** 				for j = 1 to length(current_items) do*/
    if (IS_SEQUENCE(_current_items_6662)){
            _3565 = SEQ_PTR(_current_items_6662)->length;
    }
    else {
        _3565 = 1;
    }
    {
        int _j_6752;
        _j_6752 = 1;
L16: 
        if (_j_6752 > _3565){
            goto L17; // [460] 506
        }

        /** 					if search:begins(current_items[j], source_data[i .. $]) then*/
        _2 = (int)SEQ_PTR(_current_items_6662);
        _3566 = (int)*(((s1_ptr)_2)->base + _j_6752);
        if (IS_SEQUENCE(_source_data_6661)){
                _3567 = SEQ_PTR(_source_data_6661)->length;
        }
        else {
            _3567 = 1;
        }
        rhs_slice_target = (object_ptr)&_3568;
        RHS_Slice(_source_data_6661, _i_6670, _3567);
        Ref(_3566);
        _3569 = _9begins(_3566, _3568);
        _3566 = NOVALUE;
        _3568 = NOVALUE;
        if (_3569 == 0) {
            DeRef(_3569);
            _3569 = NOVALUE;
            goto L18; // [486] 499
        }
        else {
            if (!IS_ATOM_INT(_3569) && DBL_PTR(_3569)->dbl == 0.0){
                DeRef(_3569);
                _3569 = NOVALUE;
                goto L18; // [486] 499
            }
            DeRef(_3569);
            _3569 = NOVALUE;
        }
        DeRef(_3569);
        _3569 = NOVALUE;

        /** 						pos = j*/
        _pos_6667 = _j_6752;

        /** 						exit*/
        goto L17; // [496] 506
L18: 

        /** 				end for*/
        _j_6752 = _j_6752 + 1;
        goto L16; // [501] 467
L17: 
        ;
    }

    /** 				if pos then*/
    if (_pos_6667 == 0)
    {
        goto L13; // [508] 420
    }
    else{
    }

    /** 			    	elen = length(current_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_current_items_6662);
    _3570 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    if (IS_SEQUENCE(_3570)){
            _3571 = SEQ_PTR(_3570)->length;
    }
    else {
        _3571 = 1;
    }
    _3570 = NOVALUE;
    _elen_6671 = _3571 - 1;
    _3571 = NOVALUE;

    /** 					source_data = replace(source_data, new_items[pos], i, i + elen)*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3573 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    _3574 = _i_6670 + _elen_6671;
    if ((long)((unsigned long)_3574 + (unsigned long)HIGH_BITS) >= 0) 
    _3574 = NewDouble((double)_3574);
    {
        int p1 = _source_data_6661;
        int p2 = _3573;
        int p3 = _i_6670;
        int p4 = _3574;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6661;
        Replace( &replace_params );
    }
    _3573 = NOVALUE;
    DeRef(_3574);
    _3574 = NOVALUE;

    /** 					i += length(new_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_new_items_6663);
    _3576 = (int)*(((s1_ptr)_2)->base + _pos_6667);
    if (IS_SEQUENCE(_3576)){
            _3577 = SEQ_PTR(_3576)->length;
    }
    else {
        _3577 = 1;
    }
    _3576 = NOVALUE;
    _3578 = _3577 - 1;
    _3577 = NOVALUE;
    _i_6670 = _i_6670 + _3578;
    _3578 = NOVALUE;

    /** 			end while*/
    goto L13; // [562] 420
L14: 
LE: 
L8: 

    /** 	return source_data*/
    DeRefDS(_current_items_6662);
    DeRefDS(_new_items_6663);
    _3538 = NOVALUE;
    _3553 = NOVALUE;
    _3570 = NOVALUE;
    _3576 = NOVALUE;
    return _source_data_6661;
    ;
}


int  __stdcall _23sim_index(int _A_6772, int _B_6773)
{
    int _accum_score_6774 = NOVALUE;
    int _pos_factor_6775 = NOVALUE;
    int _indx_a_6776 = NOVALUE;
    int _indx_b_6777 = NOVALUE;
    int _used_A_6778 = NOVALUE;
    int _used_B_6779 = NOVALUE;
    int _total_elems_6838 = NOVALUE;
    int _3648 = NOVALUE;
    int _3647 = NOVALUE;
    int _3646 = NOVALUE;
    int _3643 = NOVALUE;
    int _3642 = NOVALUE;
    int _3641 = NOVALUE;
    int _3640 = NOVALUE;
    int _3638 = NOVALUE;
    int _3637 = NOVALUE;
    int _3636 = NOVALUE;
    int _3635 = NOVALUE;
    int _3634 = NOVALUE;
    int _3632 = NOVALUE;
    int _3631 = NOVALUE;
    int _3628 = NOVALUE;
    int _3627 = NOVALUE;
    int _3626 = NOVALUE;
    int _3625 = NOVALUE;
    int _3624 = NOVALUE;
    int _3622 = NOVALUE;
    int _3621 = NOVALUE;
    int _3620 = NOVALUE;
    int _3619 = NOVALUE;
    int _3618 = NOVALUE;
    int _3616 = NOVALUE;
    int _3615 = NOVALUE;
    int _3609 = NOVALUE;
    int _3608 = NOVALUE;
    int _3607 = NOVALUE;
    int _3606 = NOVALUE;
    int _3605 = NOVALUE;
    int _3604 = NOVALUE;
    int _3603 = NOVALUE;
    int _3602 = NOVALUE;
    int _3600 = NOVALUE;
    int _3599 = NOVALUE;
    int _3598 = NOVALUE;
    int _3597 = NOVALUE;
    int _3596 = NOVALUE;
    int _3595 = NOVALUE;
    int _3593 = NOVALUE;
    int _3591 = NOVALUE;
    int _3590 = NOVALUE;
    int _3589 = NOVALUE;
    int _3588 = NOVALUE;
    int _3587 = NOVALUE;
    int _3584 = NOVALUE;
    int _3582 = NOVALUE;
    int _3580 = NOVALUE;
    int _0, _1, _2;
    

    /** 	accum_score = 0*/
    DeRef(_accum_score_6774);
    _accum_score_6774 = 0;

    /** 	indx_a = 1*/
    _indx_a_6776 = 1;

    /** 	used_A = repeat(0, length(A))*/
    if (IS_SEQUENCE(_A_6772)){
            _3580 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3580 = 1;
    }
    DeRefi(_used_A_6778);
    _used_A_6778 = Repeat(0, _3580);
    _3580 = NOVALUE;

    /** 	used_B = repeat(0, length(B))*/
    if (IS_SEQUENCE(_B_6773)){
            _3582 = SEQ_PTR(_B_6773)->length;
    }
    else {
        _3582 = 1;
    }
    DeRefi(_used_B_6779);
    _used_B_6779 = Repeat(0, _3582);
    _3582 = NOVALUE;

    /** 	while indx_a <= length(A) label "DoA" do*/
L1: 
    if (IS_SEQUENCE(_A_6772)){
            _3584 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3584 = 1;
    }
    if (_indx_a_6776 > _3584)
    goto L2; // [41] 232

    /** 		pos_factor = power((1 + length(A) - indx_a) / length(A),2)*/
    if (IS_SEQUENCE(_A_6772)){
            _3587 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3587 = 1;
    }
    _3588 = _3587 + 1;
    _3587 = NOVALUE;
    _3589 = _3588 - _indx_a_6776;
    if ((long)((unsigned long)_3589 +(unsigned long) HIGH_BITS) >= 0){
        _3589 = NewDouble((double)_3589);
    }
    _3588 = NOVALUE;
    if (IS_SEQUENCE(_A_6772)){
            _3590 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3590 = 1;
    }
    if (IS_ATOM_INT(_3589)) {
        _3591 = (_3589 % _3590) ? NewDouble((double)_3589 / _3590) : (_3589 / _3590);
    }
    else {
        _3591 = NewDouble(DBL_PTR(_3589)->dbl / (double)_3590);
    }
    DeRef(_3589);
    _3589 = NOVALUE;
    _3590 = NOVALUE;
    DeRef(_pos_factor_6775);
    if (IS_ATOM_INT(_3591) && IS_ATOM_INT(_3591)) {
        if (_3591 == (short)_3591 && _3591 <= INT15 && _3591 >= -INT15)
        _pos_factor_6775 = _3591 * _3591;
        else
        _pos_factor_6775 = NewDouble(_3591 * (double)_3591);
    }
    else {
        if (IS_ATOM_INT(_3591)) {
            _pos_factor_6775 = NewDouble((double)_3591 * DBL_PTR(_3591)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3591)) {
                _pos_factor_6775 = NewDouble(DBL_PTR(_3591)->dbl * (double)_3591);
            }
            else
            _pos_factor_6775 = NewDouble(DBL_PTR(_3591)->dbl * DBL_PTR(_3591)->dbl);
        }
    }
    DeRef(_3591);
    _3591 = NOVALUE;
    _3591 = NOVALUE;

    /** 		indx_b = 1*/
    _indx_b_6777 = 1;

    /** 		while indx_b <= length(B) do*/
L3: 
    if (IS_SEQUENCE(_B_6773)){
            _3593 = SEQ_PTR(_B_6773)->length;
    }
    else {
        _3593 = 1;
    }
    if (_indx_b_6777 > _3593)
    goto L4; // [82] 221

    /** 			if equal(A[indx_a],B[indx_b]) then*/
    _2 = (int)SEQ_PTR(_A_6772);
    _3595 = (int)*(((s1_ptr)_2)->base + _indx_a_6776);
    _2 = (int)SEQ_PTR(_B_6773);
    _3596 = (int)*(((s1_ptr)_2)->base + _indx_b_6777);
    if (_3595 == _3596)
    _3597 = 1;
    else if (IS_ATOM_INT(_3595) && IS_ATOM_INT(_3596))
    _3597 = 0;
    else
    _3597 = (compare(_3595, _3596) == 0);
    _3595 = NOVALUE;
    _3596 = NOVALUE;
    if (_3597 == 0)
    {
        _3597 = NOVALUE;
        goto L5; // [100] 210
    }
    else{
        _3597 = NOVALUE;
    }

    /** 				accum_score += power((indx_b - indx_a) * pos_factor,2)*/
    _3598 = _indx_b_6777 - _indx_a_6776;
    if ((long)((unsigned long)_3598 +(unsigned long) HIGH_BITS) >= 0){
        _3598 = NewDouble((double)_3598);
    }
    if (IS_ATOM_INT(_3598) && IS_ATOM_INT(_pos_factor_6775)) {
        if (_3598 == (short)_3598 && _pos_factor_6775 <= INT15 && _pos_factor_6775 >= -INT15)
        _3599 = _3598 * _pos_factor_6775;
        else
        _3599 = NewDouble(_3598 * (double)_pos_factor_6775);
    }
    else {
        if (IS_ATOM_INT(_3598)) {
            _3599 = NewDouble((double)_3598 * DBL_PTR(_pos_factor_6775)->dbl);
        }
        else {
            if (IS_ATOM_INT(_pos_factor_6775)) {
                _3599 = NewDouble(DBL_PTR(_3598)->dbl * (double)_pos_factor_6775);
            }
            else
            _3599 = NewDouble(DBL_PTR(_3598)->dbl * DBL_PTR(_pos_factor_6775)->dbl);
        }
    }
    DeRef(_3598);
    _3598 = NOVALUE;
    if (IS_ATOM_INT(_3599) && IS_ATOM_INT(_3599)) {
        if (_3599 == (short)_3599 && _3599 <= INT15 && _3599 >= -INT15)
        _3600 = _3599 * _3599;
        else
        _3600 = NewDouble(_3599 * (double)_3599);
    }
    else {
        if (IS_ATOM_INT(_3599)) {
            _3600 = NewDouble((double)_3599 * DBL_PTR(_3599)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3599)) {
                _3600 = NewDouble(DBL_PTR(_3599)->dbl * (double)_3599);
            }
            else
            _3600 = NewDouble(DBL_PTR(_3599)->dbl * DBL_PTR(_3599)->dbl);
        }
    }
    DeRef(_3599);
    _3599 = NOVALUE;
    _3599 = NOVALUE;
    _0 = _accum_score_6774;
    if (IS_ATOM_INT(_accum_score_6774) && IS_ATOM_INT(_3600)) {
        _accum_score_6774 = _accum_score_6774 + _3600;
        if ((long)((unsigned long)_accum_score_6774 + (unsigned long)HIGH_BITS) >= 0) 
        _accum_score_6774 = NewDouble((double)_accum_score_6774);
    }
    else {
        if (IS_ATOM_INT(_accum_score_6774)) {
            _accum_score_6774 = NewDouble((double)_accum_score_6774 + DBL_PTR(_3600)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3600)) {
                _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + (double)_3600);
            }
            else
            _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + DBL_PTR(_3600)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_3600);
    _3600 = NOVALUE;

    /** 				while indx_a <= length(A) and indx_b <= length(B) with entry do*/
    goto L6; // [123] 176
L7: 
    if (IS_SEQUENCE(_A_6772)){
            _3602 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3602 = 1;
    }
    _3603 = (_indx_a_6776 <= _3602);
    _3602 = NOVALUE;
    if (_3603 == 0) {
        DeRef(_3604);
        _3604 = 0;
        goto L8; // [133] 148
    }
    if (IS_SEQUENCE(_B_6773)){
            _3605 = SEQ_PTR(_B_6773)->length;
    }
    else {
        _3605 = 1;
    }
    _3606 = (_indx_b_6777 <= _3605);
    _3605 = NOVALUE;
    _3604 = (_3606 != 0);
L8: 
    if (_3604 == 0)
    {
        _3604 = NOVALUE;
        goto L1; // [148] 38
    }
    else{
        _3604 = NOVALUE;
    }

    /** 					if not equal(A[indx_a], B[indx_b]) then*/
    _2 = (int)SEQ_PTR(_A_6772);
    _3607 = (int)*(((s1_ptr)_2)->base + _indx_a_6776);
    _2 = (int)SEQ_PTR(_B_6773);
    _3608 = (int)*(((s1_ptr)_2)->base + _indx_b_6777);
    if (_3607 == _3608)
    _3609 = 1;
    else if (IS_ATOM_INT(_3607) && IS_ATOM_INT(_3608))
    _3609 = 0;
    else
    _3609 = (compare(_3607, _3608) == 0);
    _3607 = NOVALUE;
    _3608 = NOVALUE;
    if (_3609 != 0)
    goto L9; // [165] 173
    _3609 = NOVALUE;

    /** 						exit*/
    goto L1; // [170] 38
L9: 

    /** 				entry*/
L6: 

    /** 					used_B[indx_b] = 1*/
    _2 = (int)SEQ_PTR(_used_B_6779);
    _2 = (int)(((s1_ptr)_2)->base + _indx_b_6777);
    *(int *)_2 = 1;

    /** 					used_A[indx_a] = 1*/
    _2 = (int)SEQ_PTR(_used_A_6778);
    _2 = (int)(((s1_ptr)_2)->base + _indx_a_6776);
    *(int *)_2 = 1;

    /** 					indx_a += 1*/
    _indx_a_6776 = _indx_a_6776 + 1;

    /** 					indx_b += 1*/
    _indx_b_6777 = _indx_b_6777 + 1;

    /** 				end while*/
    goto L7; // [202] 126

    /** 				continue "DoA"*/
    goto L1; // [207] 38
L5: 

    /** 			indx_b += 1*/
    _indx_b_6777 = _indx_b_6777 + 1;

    /** 		end while*/
    goto L3; // [218] 79
L4: 

    /** 		indx_a += 1*/
    _indx_a_6776 = _indx_a_6776 + 1;

    /** 	end while*/
    goto L1; // [229] 38
L2: 

    /**  	for i = 1 to length(A) do*/
    if (IS_SEQUENCE(_A_6772)){
            _3615 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _3615 = 1;
    }
    {
        int _i_6821;
        _i_6821 = 1;
LA: 
        if (_i_6821 > _3615){
            goto LB; // [237] 311
        }

        /**  		if used_A[i] = 0 then*/
        _2 = (int)SEQ_PTR(_used_A_6778);
        _3616 = (int)*(((s1_ptr)_2)->base + _i_6821);
        if (_3616 != 0)
        goto LC; // [250] 304

        /** 			pos_factor = power((1 + length(A) - i) / length(A),2)*/
        if (IS_SEQUENCE(_A_6772)){
                _3618 = SEQ_PTR(_A_6772)->length;
        }
        else {
            _3618 = 1;
        }
        _3619 = _3618 + 1;
        _3618 = NOVALUE;
        _3620 = _3619 - _i_6821;
        _3619 = NOVALUE;
        if (IS_SEQUENCE(_A_6772)){
                _3621 = SEQ_PTR(_A_6772)->length;
        }
        else {
            _3621 = 1;
        }
        _3622 = (_3620 % _3621) ? NewDouble((double)_3620 / _3621) : (_3620 / _3621);
        _3620 = NOVALUE;
        _3621 = NOVALUE;
        DeRef(_pos_factor_6775);
        if (IS_ATOM_INT(_3622) && IS_ATOM_INT(_3622)) {
            if (_3622 == (short)_3622 && _3622 <= INT15 && _3622 >= -INT15)
            _pos_factor_6775 = _3622 * _3622;
            else
            _pos_factor_6775 = NewDouble(_3622 * (double)_3622);
        }
        else {
            if (IS_ATOM_INT(_3622)) {
                _pos_factor_6775 = NewDouble((double)_3622 * DBL_PTR(_3622)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3622)) {
                    _pos_factor_6775 = NewDouble(DBL_PTR(_3622)->dbl * (double)_3622);
                }
                else
                _pos_factor_6775 = NewDouble(DBL_PTR(_3622)->dbl * DBL_PTR(_3622)->dbl);
            }
        }
        DeRef(_3622);
        _3622 = NOVALUE;
        _3622 = NOVALUE;

        /**  			accum_score += power((length(A) - i + 1) * pos_factor,2)*/
        if (IS_SEQUENCE(_A_6772)){
                _3624 = SEQ_PTR(_A_6772)->length;
        }
        else {
            _3624 = 1;
        }
        _3625 = _3624 - _i_6821;
        _3624 = NOVALUE;
        _3626 = _3625 + 1;
        _3625 = NOVALUE;
        if (IS_ATOM_INT(_pos_factor_6775)) {
            if (_3626 == (short)_3626 && _pos_factor_6775 <= INT15 && _pos_factor_6775 >= -INT15)
            _3627 = _3626 * _pos_factor_6775;
            else
            _3627 = NewDouble(_3626 * (double)_pos_factor_6775);
        }
        else {
            _3627 = NewDouble((double)_3626 * DBL_PTR(_pos_factor_6775)->dbl);
        }
        _3626 = NOVALUE;
        if (IS_ATOM_INT(_3627) && IS_ATOM_INT(_3627)) {
            if (_3627 == (short)_3627 && _3627 <= INT15 && _3627 >= -INT15)
            _3628 = _3627 * _3627;
            else
            _3628 = NewDouble(_3627 * (double)_3627);
        }
        else {
            if (IS_ATOM_INT(_3627)) {
                _3628 = NewDouble((double)_3627 * DBL_PTR(_3627)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3627)) {
                    _3628 = NewDouble(DBL_PTR(_3627)->dbl * (double)_3627);
                }
                else
                _3628 = NewDouble(DBL_PTR(_3627)->dbl * DBL_PTR(_3627)->dbl);
            }
        }
        DeRef(_3627);
        _3627 = NOVALUE;
        _3627 = NOVALUE;
        _0 = _accum_score_6774;
        if (IS_ATOM_INT(_accum_score_6774) && IS_ATOM_INT(_3628)) {
            _accum_score_6774 = _accum_score_6774 + _3628;
            if ((long)((unsigned long)_accum_score_6774 + (unsigned long)HIGH_BITS) >= 0) 
            _accum_score_6774 = NewDouble((double)_accum_score_6774);
        }
        else {
            if (IS_ATOM_INT(_accum_score_6774)) {
                _accum_score_6774 = NewDouble((double)_accum_score_6774 + DBL_PTR(_3628)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3628)) {
                    _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + (double)_3628);
                }
                else
                _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + DBL_PTR(_3628)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_3628);
        _3628 = NOVALUE;
LC: 

        /**  	end for*/
        _i_6821 = _i_6821 + 1;
        goto LA; // [306] 244
LB: 
        ;
    }

    /**  	integer total_elems = length(A)*/
    if (IS_SEQUENCE(_A_6772)){
            _total_elems_6838 = SEQ_PTR(_A_6772)->length;
    }
    else {
        _total_elems_6838 = 1;
    }

    /**  	for i = 1 to length(B) do*/
    if (IS_SEQUENCE(_B_6773)){
            _3631 = SEQ_PTR(_B_6773)->length;
    }
    else {
        _3631 = 1;
    }
    {
        int _i_6841;
        _i_6841 = 1;
LD: 
        if (_i_6841 > _3631){
            goto LE; // [321] 397
        }

        /**  		if used_B[i] = 0 then*/
        _2 = (int)SEQ_PTR(_used_B_6779);
        _3632 = (int)*(((s1_ptr)_2)->base + _i_6841);
        if (_3632 != 0)
        goto LF; // [334] 390

        /** 			pos_factor = power((1 + length(B) - i) / length(B),2)*/
        if (IS_SEQUENCE(_B_6773)){
                _3634 = SEQ_PTR(_B_6773)->length;
        }
        else {
            _3634 = 1;
        }
        _3635 = _3634 + 1;
        _3634 = NOVALUE;
        _3636 = _3635 - _i_6841;
        _3635 = NOVALUE;
        if (IS_SEQUENCE(_B_6773)){
                _3637 = SEQ_PTR(_B_6773)->length;
        }
        else {
            _3637 = 1;
        }
        _3638 = (_3636 % _3637) ? NewDouble((double)_3636 / _3637) : (_3636 / _3637);
        _3636 = NOVALUE;
        _3637 = NOVALUE;
        DeRef(_pos_factor_6775);
        if (IS_ATOM_INT(_3638) && IS_ATOM_INT(_3638)) {
            if (_3638 == (short)_3638 && _3638 <= INT15 && _3638 >= -INT15)
            _pos_factor_6775 = _3638 * _3638;
            else
            _pos_factor_6775 = NewDouble(_3638 * (double)_3638);
        }
        else {
            if (IS_ATOM_INT(_3638)) {
                _pos_factor_6775 = NewDouble((double)_3638 * DBL_PTR(_3638)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3638)) {
                    _pos_factor_6775 = NewDouble(DBL_PTR(_3638)->dbl * (double)_3638);
                }
                else
                _pos_factor_6775 = NewDouble(DBL_PTR(_3638)->dbl * DBL_PTR(_3638)->dbl);
            }
        }
        DeRef(_3638);
        _3638 = NOVALUE;
        _3638 = NOVALUE;

        /**  			accum_score += (length(B) - i + 1) * pos_factor*/
        if (IS_SEQUENCE(_B_6773)){
                _3640 = SEQ_PTR(_B_6773)->length;
        }
        else {
            _3640 = 1;
        }
        _3641 = _3640 - _i_6841;
        _3640 = NOVALUE;
        _3642 = _3641 + 1;
        _3641 = NOVALUE;
        if (IS_ATOM_INT(_pos_factor_6775)) {
            if (_3642 == (short)_3642 && _pos_factor_6775 <= INT15 && _pos_factor_6775 >= -INT15)
            _3643 = _3642 * _pos_factor_6775;
            else
            _3643 = NewDouble(_3642 * (double)_pos_factor_6775);
        }
        else {
            _3643 = NewDouble((double)_3642 * DBL_PTR(_pos_factor_6775)->dbl);
        }
        _3642 = NOVALUE;
        _0 = _accum_score_6774;
        if (IS_ATOM_INT(_accum_score_6774) && IS_ATOM_INT(_3643)) {
            _accum_score_6774 = _accum_score_6774 + _3643;
            if ((long)((unsigned long)_accum_score_6774 + (unsigned long)HIGH_BITS) >= 0) 
            _accum_score_6774 = NewDouble((double)_accum_score_6774);
        }
        else {
            if (IS_ATOM_INT(_accum_score_6774)) {
                _accum_score_6774 = NewDouble((double)_accum_score_6774 + DBL_PTR(_3643)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3643)) {
                    _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + (double)_3643);
                }
                else
                _accum_score_6774 = NewDouble(DBL_PTR(_accum_score_6774)->dbl + DBL_PTR(_3643)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_3643);
        _3643 = NOVALUE;

        /**  			total_elems += 1*/
        _total_elems_6838 = _total_elems_6838 + 1;
LF: 

        /**  	end for*/
        _i_6841 = _i_6841 + 1;
        goto LD; // [392] 328
LE: 
        ;
    }

    /** 	return power(accum_score / power(total_elems,2), 0.5)*/
    if (_total_elems_6838 == (short)_total_elems_6838 && _total_elems_6838 <= INT15 && _total_elems_6838 >= -INT15)
    _3646 = _total_elems_6838 * _total_elems_6838;
    else
    _3646 = NewDouble(_total_elems_6838 * (double)_total_elems_6838);
    if (IS_ATOM_INT(_accum_score_6774) && IS_ATOM_INT(_3646)) {
        _3647 = (_accum_score_6774 % _3646) ? NewDouble((double)_accum_score_6774 / _3646) : (_accum_score_6774 / _3646);
    }
    else {
        if (IS_ATOM_INT(_accum_score_6774)) {
            _3647 = NewDouble((double)_accum_score_6774 / DBL_PTR(_3646)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3646)) {
                _3647 = NewDouble(DBL_PTR(_accum_score_6774)->dbl / (double)_3646);
            }
            else
            _3647 = NewDouble(DBL_PTR(_accum_score_6774)->dbl / DBL_PTR(_3646)->dbl);
        }
    }
    DeRef(_3646);
    _3646 = NOVALUE;
    if (IS_ATOM_INT(_3647)) {
        temp_d.dbl = (double)_3647;
        _3648 = Dpower(&temp_d, DBL_PTR(_2369));
    }
    else {
        _3648 = Dpower(DBL_PTR(_3647), DBL_PTR(_2369));
    }
    DeRef(_3647);
    _3647 = NOVALUE;
    DeRefDS(_A_6772);
    DeRefDS(_B_6773);
    DeRef(_accum_score_6774);
    DeRef(_pos_factor_6775);
    DeRefi(_used_A_6778);
    DeRefi(_used_B_6779);
    DeRef(_3603);
    _3603 = NOVALUE;
    DeRef(_3606);
    _3606 = NOVALUE;
    _3616 = NOVALUE;
    _3632 = NOVALUE;
    return _3648;
    ;
}


int  __stdcall _23remove_subseq(int _source_list_6867, int _alt_value_6868)
{
    int _lResult_6869 = NOVALUE;
    int _lCOW_6870 = NOVALUE;
    int _3665 = NOVALUE;
    int _3664 = NOVALUE;
    int _3660 = NOVALUE;
    int _3657 = NOVALUE;
    int _3654 = NOVALUE;
    int _3653 = NOVALUE;
    int _3652 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lCOW = 0*/
    _lCOW_6870 = 0;

    /** 	for i = 1 to length(source_list) do*/
    if (IS_SEQUENCE(_source_list_6867)){
            _3652 = SEQ_PTR(_source_list_6867)->length;
    }
    else {
        _3652 = 1;
    }
    {
        int _i_6872;
        _i_6872 = 1;
L1: 
        if (_i_6872 > _3652){
            goto L2; // [13] 121
        }

        /** 		if atom(source_list[i]) then*/
        _2 = (int)SEQ_PTR(_source_list_6867);
        _3653 = (int)*(((s1_ptr)_2)->base + _i_6872);
        _3654 = IS_ATOM(_3653);
        _3653 = NOVALUE;
        if (_3654 == 0)
        {
            _3654 = NOVALUE;
            goto L3; // [29] 69
        }
        else{
            _3654 = NOVALUE;
        }

        /** 			if lCOW != 0 then*/
        if (_lCOW_6870 == 0)
        goto L4; // [34] 116

        /** 				if lCOW != i then*/
        if (_lCOW_6870 == _i_6872)
        goto L5; // [40] 57

        /** 					lResult[lCOW] = source_list[i]*/
        _2 = (int)SEQ_PTR(_source_list_6867);
        _3657 = (int)*(((s1_ptr)_2)->base + _i_6872);
        Ref(_3657);
        _2 = (int)SEQ_PTR(_lResult_6869);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lResult_6869 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lCOW_6870);
        _1 = *(int *)_2;
        *(int *)_2 = _3657;
        if( _1 != _3657 ){
            DeRef(_1);
        }
        _3657 = NOVALUE;
L5: 

        /** 				lCOW += 1*/
        _lCOW_6870 = _lCOW_6870 + 1;

        /** 			continue*/
        goto L4; // [66] 116
L3: 

        /** 		if lCOW = 0 then*/
        if (_lCOW_6870 != 0)
        goto L6; // [71] 88

        /** 			lResult = source_list*/
        RefDS(_source_list_6867);
        DeRef(_lResult_6869);
        _lResult_6869 = _source_list_6867;

        /** 			lCOW = i*/
        _lCOW_6870 = _i_6872;
L6: 

        /** 		if not equal(alt_value, SEQ_NOALT) then*/
        if (_alt_value_6868 == _23SEQ_NOALT_6861)
        _3660 = 1;
        else if (IS_ATOM_INT(_alt_value_6868) && IS_ATOM_INT(_23SEQ_NOALT_6861))
        _3660 = 0;
        else
        _3660 = (compare(_alt_value_6868, _23SEQ_NOALT_6861) == 0);
        if (_3660 != 0)
        goto L7; // [96] 114
        _3660 = NOVALUE;

        /** 			lResult[lCOW] = alt_value*/
        Ref(_alt_value_6868);
        _2 = (int)SEQ_PTR(_lResult_6869);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lResult_6869 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lCOW_6870);
        _1 = *(int *)_2;
        *(int *)_2 = _alt_value_6868;
        DeRef(_1);

        /** 			lCOW += 1*/
        _lCOW_6870 = _lCOW_6870 + 1;
L7: 

        /** 	end for*/
L4: 
        _i_6872 = _i_6872 + 1;
        goto L1; // [116] 20
L2: 
        ;
    }

    /** 	if lCOW = 0 then*/
    if (_lCOW_6870 != 0)
    goto L8; // [123] 134

    /** 		return source_list*/
    DeRef(_alt_value_6868);
    DeRef(_lResult_6869);
    return _source_list_6867;
L8: 

    /** 	return lResult[1.. lCOW - 1]*/
    _3664 = _lCOW_6870 - 1;
    rhs_slice_target = (object_ptr)&_3665;
    RHS_Slice(_lResult_6869, 1, _3664);
    DeRefDS(_source_list_6867);
    DeRef(_alt_value_6868);
    DeRefDS(_lResult_6869);
    _3664 = NOVALUE;
    return _3665;
    ;
}


int  __stdcall _23remove_dups(int _source_data_6898, int _proc_option_6899)
{
    int _lTo_6900 = NOVALUE;
    int _lFrom_6901 = NOVALUE;
    int _lResult_6924 = NOVALUE;
    int _3686 = NOVALUE;
    int _3684 = NOVALUE;
    int _3683 = NOVALUE;
    int _3682 = NOVALUE;
    int _3681 = NOVALUE;
    int _3679 = NOVALUE;
    int _3675 = NOVALUE;
    int _3674 = NOVALUE;
    int _3673 = NOVALUE;
    int _3671 = NOVALUE;
    int _3666 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_option_6899)) {
        _1 = (long)(DBL_PTR(_proc_option_6899)->dbl);
        DeRefDS(_proc_option_6899);
        _proc_option_6899 = _1;
    }

    /** 	if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_6898)){
            _3666 = SEQ_PTR(_source_data_6898)->length;
    }
    else {
        _3666 = 1;
    }
    if (_3666 >= 2)
    goto L1; // [10] 21

    /** 		return source_data*/
    DeRef(_lResult_6924);
    return _source_data_6898;
L1: 

    /** 	if proc_option = RD_SORT then*/
    if (_proc_option_6899 != 3)
    goto L2; // [23] 42

    /** 		source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_6898);
    _0 = _source_data_6898;
    _source_data_6898 = _24sort(_source_data_6898, 1);
    DeRefDS(_0);

    /** 		proc_option = RD_PRESORTED*/
    _proc_option_6899 = 2;
L2: 

    /** 	if proc_option = RD_PRESORTED then*/
    if (_proc_option_6899 != 2)
    goto L3; // [44] 134

    /** 		lTo = 1*/
    _lTo_6900 = 1;

    /** 		lFrom = 2*/
    _lFrom_6901 = 2;

    /** 		while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_6898)){
            _3671 = SEQ_PTR(_source_data_6898)->length;
    }
    else {
        _3671 = 1;
    }
    if (_lFrom_6901 > _3671)
    goto L5; // [66] 122

    /** 			if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (int)SEQ_PTR(_source_data_6898);
    _3673 = (int)*(((s1_ptr)_2)->base + _lFrom_6901);
    _2 = (int)SEQ_PTR(_source_data_6898);
    _3674 = (int)*(((s1_ptr)_2)->base + _lTo_6900);
    if (_3673 == _3674)
    _3675 = 1;
    else if (IS_ATOM_INT(_3673) && IS_ATOM_INT(_3674))
    _3675 = 0;
    else
    _3675 = (compare(_3673, _3674) == 0);
    _3673 = NOVALUE;
    _3674 = NOVALUE;
    if (_3675 != 0)
    goto L6; // [84] 111
    _3675 = NOVALUE;

    /** 				lTo += 1*/
    _lTo_6900 = _lTo_6900 + 1;

    /** 				if lTo != lFrom then*/
    if (_lTo_6900 == _lFrom_6901)
    goto L7; // [95] 110

    /** 					source_data[lTo] = source_data[lFrom]*/
    _2 = (int)SEQ_PTR(_source_data_6898);
    _3679 = (int)*(((s1_ptr)_2)->base + _lFrom_6901);
    Ref(_3679);
    _2 = (int)SEQ_PTR(_source_data_6898);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _source_data_6898 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lTo_6900);
    _1 = *(int *)_2;
    *(int *)_2 = _3679;
    if( _1 != _3679 ){
        DeRef(_1);
    }
    _3679 = NOVALUE;
L7: 
L6: 

    /** 			lFrom += 1*/
    _lFrom_6901 = _lFrom_6901 + 1;

    /** 		end while*/
    goto L4; // [119] 63
L5: 

    /** 		return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_3681;
    RHS_Slice(_source_data_6898, 1, _lTo_6900);
    DeRefDS(_source_data_6898);
    DeRef(_lResult_6924);
    return _3681;
L3: 

    /** 	sequence lResult*/

    /** 	lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_6924);
    _lResult_6924 = _5;

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6898)){
            _3682 = SEQ_PTR(_source_data_6898)->length;
    }
    else {
        _3682 = 1;
    }
    {
        int _i_6926;
        _i_6926 = 1;
L8: 
        if (_i_6926 > _3682){
            goto L9; // [148] 187
        }

        /** 		if not find(source_data[i], lResult) then*/
        _2 = (int)SEQ_PTR(_source_data_6898);
        _3683 = (int)*(((s1_ptr)_2)->base + _i_6926);
        _3684 = find_from(_3683, _lResult_6924, 1);
        _3683 = NOVALUE;
        if (_3684 != 0)
        goto LA; // [166] 180
        _3684 = NOVALUE;

        /** 			lResult = append(lResult, source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6898);
        _3686 = (int)*(((s1_ptr)_2)->base + _i_6926);
        Ref(_3686);
        Append(&_lResult_6924, _lResult_6924, _3686);
        _3686 = NOVALUE;
LA: 

        /** 	end for*/
        _i_6926 = _i_6926 + 1;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** 	return lResult*/
    DeRefDS(_source_data_6898);
    DeRef(_3681);
    _3681 = NOVALUE;
    return _lResult_6924;
    ;
}


int  __stdcall _23combine(int _source_data_6938, int _proc_option_6939)
{
    int _lResult_6940 = NOVALUE;
    int _lTotalSize_6941 = NOVALUE;
    int _lPos_6942 = NOVALUE;
    int _3708 = NOVALUE;
    int _3705 = NOVALUE;
    int _3704 = NOVALUE;
    int _3703 = NOVALUE;
    int _3702 = NOVALUE;
    int _3701 = NOVALUE;
    int _3700 = NOVALUE;
    int _3699 = NOVALUE;
    int _3698 = NOVALUE;
    int _3695 = NOVALUE;
    int _3694 = NOVALUE;
    int _3693 = NOVALUE;
    int _3692 = NOVALUE;
    int _3690 = NOVALUE;
    int _3688 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_option_6939)) {
        _1 = (long)(DBL_PTR(_proc_option_6939)->dbl);
        DeRefDS(_proc_option_6939);
        _proc_option_6939 = _1;
    }

    /** 	integer lTotalSize = 0*/
    _lTotalSize_6941 = 0;

    /** 	if length(source_data) = 0 then*/
    if (IS_SEQUENCE(_source_data_6938)){
            _3688 = SEQ_PTR(_source_data_6938)->length;
    }
    else {
        _3688 = 1;
    }
    if (_3688 != 0)
    goto L1; // [15] 26

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_source_data_6938);
    DeRef(_lResult_6940);
    return _5;
L1: 

    /** 	if length(source_data) = 1 then*/
    if (IS_SEQUENCE(_source_data_6938)){
            _3690 = SEQ_PTR(_source_data_6938)->length;
    }
    else {
        _3690 = 1;
    }
    if (_3690 != 1)
    goto L2; // [31] 46

    /** 		return source_data[1]*/
    _2 = (int)SEQ_PTR(_source_data_6938);
    _3692 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3692);
    DeRefDS(_source_data_6938);
    DeRef(_lResult_6940);
    return _3692;
L2: 

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6938)){
            _3693 = SEQ_PTR(_source_data_6938)->length;
    }
    else {
        _3693 = 1;
    }
    {
        int _i_6951;
        _i_6951 = 1;
L3: 
        if (_i_6951 > _3693){
            goto L4; // [51] 78
        }

        /** 		lTotalSize += length(source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6938);
        _3694 = (int)*(((s1_ptr)_2)->base + _i_6951);
        if (IS_SEQUENCE(_3694)){
                _3695 = SEQ_PTR(_3694)->length;
        }
        else {
            _3695 = 1;
        }
        _3694 = NOVALUE;
        _lTotalSize_6941 = _lTotalSize_6941 + _3695;
        _3695 = NOVALUE;

        /** 	end for*/
        _i_6951 = _i_6951 + 1;
        goto L3; // [73] 58
L4: 
        ;
    }

    /** 	lResult = repeat(0, lTotalSize)*/
    DeRef(_lResult_6940);
    _lResult_6940 = Repeat(0, _lTotalSize_6941);

    /** 	lPos = 1*/
    _lPos_6942 = 1;

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6938)){
            _3698 = SEQ_PTR(_source_data_6938)->length;
    }
    else {
        _3698 = 1;
    }
    {
        int _i_6958;
        _i_6958 = 1;
L5: 
        if (_i_6958 > _3698){
            goto L6; // [94] 147
        }

        /** 		lResult[lPos .. length(source_data[i]) + lPos - 1] = source_data[i]*/
        _2 = (int)SEQ_PTR(_source_data_6938);
        _3699 = (int)*(((s1_ptr)_2)->base + _i_6958);
        if (IS_SEQUENCE(_3699)){
                _3700 = SEQ_PTR(_3699)->length;
        }
        else {
            _3700 = 1;
        }
        _3699 = NOVALUE;
        _3701 = _3700 + _lPos_6942;
        if ((long)((unsigned long)_3701 + (unsigned long)HIGH_BITS) >= 0) 
        _3701 = NewDouble((double)_3701);
        _3700 = NOVALUE;
        if (IS_ATOM_INT(_3701)) {
            _3702 = _3701 - 1;
            if ((long)((unsigned long)_3702 +(unsigned long) HIGH_BITS) >= 0){
                _3702 = NewDouble((double)_3702);
            }
        }
        else {
            _3702 = NewDouble(DBL_PTR(_3701)->dbl - (double)1);
        }
        DeRef(_3701);
        _3701 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_data_6938);
        _3703 = (int)*(((s1_ptr)_2)->base + _i_6958);
        assign_slice_seq = (s1_ptr *)&_lResult_6940;
        AssignSlice(_lPos_6942, _3702, _3703);
        DeRef(_3702);
        _3702 = NOVALUE;
        _3703 = NOVALUE;

        /** 		lPos += length(source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6938);
        _3704 = (int)*(((s1_ptr)_2)->base + _i_6958);
        if (IS_SEQUENCE(_3704)){
                _3705 = SEQ_PTR(_3704)->length;
        }
        else {
            _3705 = 1;
        }
        _3704 = NOVALUE;
        _lPos_6942 = _lPos_6942 + _3705;
        _3705 = NOVALUE;

        /** 	end for*/
        _i_6958 = _i_6958 + 1;
        goto L5; // [142] 101
L6: 
        ;
    }

    /** 	if proc_option = COMBINE_SORTED then*/
    if (_proc_option_6939 != 1)
    goto L7; // [149] 167

    /** 		return stdsort:sort(lResult)*/
    RefDS(_lResult_6940);
    _3708 = _24sort(_lResult_6940, 1);
    DeRefDS(_source_data_6938);
    DeRefDS(_lResult_6940);
    _3692 = NOVALUE;
    _3694 = NOVALUE;
    _3699 = NOVALUE;
    _3704 = NOVALUE;
    return _3708;
    goto L8; // [164] 174
L7: 

    /** 		return lResult*/
    DeRefDS(_source_data_6938);
    _3692 = NOVALUE;
    _3694 = NOVALUE;
    _3699 = NOVALUE;
    _3704 = NOVALUE;
    DeRef(_3708);
    _3708 = NOVALUE;
    return _lResult_6940;
L8: 
    ;
}


int  __stdcall _23minsize(int _source_data_6974, int _min_size_6975, int _new_data_6980)
{
    int _3717 = NOVALUE;
    int _3716 = NOVALUE;
    int _3715 = NOVALUE;
    int _3713 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_min_size_6975)) {
        _1 = (long)(DBL_PTR(_min_size_6975)->dbl);
        DeRefDS(_min_size_6975);
        _min_size_6975 = _1;
    }

    /**     if length(source_data) < min_size then*/
    if (IS_SEQUENCE(_source_data_6974)){
            _3713 = SEQ_PTR(_source_data_6974)->length;
    }
    else {
        _3713 = 1;
    }
    if (_3713 >= _min_size_6975)
    goto L1; // [8] 30

    /**         source_data &= repeat(new_data, min_size - length(source_data))*/
    if (IS_SEQUENCE(_source_data_6974)){
            _3715 = SEQ_PTR(_source_data_6974)->length;
    }
    else {
        _3715 = 1;
    }
    _3716 = _min_size_6975 - _3715;
    _3715 = NOVALUE;
    _3717 = Repeat(_new_data_6980, _3716);
    _3716 = NOVALUE;
    if (IS_SEQUENCE(_source_data_6974) && IS_ATOM(_3717)) {
    }
    else if (IS_ATOM(_source_data_6974) && IS_SEQUENCE(_3717)) {
        Ref(_source_data_6974);
        Prepend(&_source_data_6974, _3717, _source_data_6974);
    }
    else {
        Concat((object_ptr)&_source_data_6974, _source_data_6974, _3717);
    }
    DeRefDS(_3717);
    _3717 = NOVALUE;
L1: 

    /**     return source_data*/
    DeRef(_new_data_6980);
    return _source_data_6974;
    ;
}



// 0xC9CB2E4C
