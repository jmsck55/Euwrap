// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _17get_ch()
{
    int _1392 = NOVALUE;
    int _1391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _1391 = IS_SEQUENCE(_17input_string_2935);
    if (_1391 == 0)
    {
        _1391 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _1391 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_17input_string_2935)){
            _1392 = SEQ_PTR(_17input_string_2935)->length;
    }
    else {
        _1392 = 1;
    }
    if (_17string_next_2936 > _1392)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_17input_string_2935);
    _17ch_2937 = (int)*(((s1_ptr)_2)->base + _17string_next_2936);
    if (!IS_ATOM_INT(_17ch_2937)){
        _17ch_2937 = (long)DBL_PTR(_17ch_2937)->dbl;
    }

    /** 			string_next += 1*/
    _17string_next_2936 = _17string_next_2936 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _17ch_2937 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_17input_file_2934 != last_r_file_no) {
        last_r_file_ptr = which_file(_17input_file_2934, EF_READ);
        last_r_file_no = _17input_file_2934;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _17ch_2937 = getKBchar();
        }
        else
        _17ch_2937 = getc(last_r_file_ptr);
    }
    else
    _17ch_2937 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_17ch_2937 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _17string_next_2936 = _17string_next_2936 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _17escape_char(int _c_2964)
{
    int _i_2965 = NOVALUE;
    int _1404 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_2965 = find_from(_c_2964, _17ESCAPE_CHARS_2958, 1);

    /** 	if i = 0 then*/
    if (_i_2965 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_17ESCAPED_CHARS_2960);
    _1404 = (int)*(((s1_ptr)_2)->base + _i_2965);
    Ref(_1404);
    return _1404;
L2: 
    ;
}


int _17get_qchar()
{
    int _c_2973 = NOVALUE;
    int _1415 = NOVALUE;
    int _1414 = NOVALUE;
    int _1412 = NOVALUE;
    int _1409 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _17get_ch();

    /** 	c = ch*/
    _c_2973 = _17ch_2937;

    /** 	if ch = '\\' then*/
    if (_17ch_2937 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _17get_ch();

    /** 		c = escape_char(ch)*/
    _c_2973 = _17escape_char(_17ch_2937);
    if (!IS_ATOM_INT(_c_2973)) {
        _1 = (long)(DBL_PTR(_c_2973)->dbl);
        DeRefDS(_c_2973);
        _c_2973 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_2973 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1409 = MAKE_SEQ(_1);
    return _1409;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_17ch_2937 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1412 = MAKE_SEQ(_1);
    DeRef(_1409);
    _1409 = NOVALUE;
    return _1412;
L3: 
L2: 

    /** 	get_ch()*/
    _17get_ch();

    /** 	if ch != '\'' then*/
    if (_17ch_2937 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1414 = MAKE_SEQ(_1);
    DeRef(_1409);
    _1409 = NOVALUE;
    DeRef(_1412);
    _1412 = NOVALUE;
    return _1414;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_2973;
    _1415 = MAKE_SEQ(_1);
    DeRef(_1409);
    _1409 = NOVALUE;
    DeRef(_1412);
    _1412 = NOVALUE;
    DeRef(_1414);
    _1414 = NOVALUE;
    return _1415;
L5: 
    ;
}


int _17get_string()
{
    int _text_2992 = NOVALUE;
    int _1425 = NOVALUE;
    int _1421 = NOVALUE;
    int _1419 = NOVALUE;
    int _1418 = NOVALUE;
    int _1416 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_2992);
    _text_2992 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _1416 = (_17ch_2937 == -1);
    if (_1416 != 0) {
        goto L2; // [25] 40
    }
    _1418 = (_17ch_2937 == 10);
    if (_1418 == 0)
    {
        DeRef(_1418);
        _1418 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_1418);
        _1418 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1419 = MAKE_SEQ(_1);
    DeRefi(_text_2992);
    DeRef(_1416);
    _1416 = NOVALUE;
    return _1419;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_17ch_2937 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _17get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_2992);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_2992;
    _1421 = MAKE_SEQ(_1);
    DeRefDSi(_text_2992);
    DeRef(_1416);
    _1416 = NOVALUE;
    DeRef(_1419);
    _1419 = NOVALUE;
    return _1421;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_17ch_2937 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _17get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _17escape_char(_17ch_2937);
    _17ch_2937 = _0;
    if (!IS_ATOM_INT(_17ch_2937)) {
        _1 = (long)(DBL_PTR(_17ch_2937)->dbl);
        DeRefDS(_17ch_2937);
        _17ch_2937 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_17ch_2937 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1425 = MAKE_SEQ(_1);
    DeRefi(_text_2992);
    DeRef(_1416);
    _1416 = NOVALUE;
    DeRef(_1419);
    _1419 = NOVALUE;
    DeRef(_1421);
    _1421 = NOVALUE;
    return _1425;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_2992, _text_2992, _17ch_2937);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _17read_comment()
{
    int _1446 = NOVALUE;
    int _1445 = NOVALUE;
    int _1443 = NOVALUE;
    int _1441 = NOVALUE;
    int _1439 = NOVALUE;
    int _1438 = NOVALUE;
    int _1437 = NOVALUE;
    int _1435 = NOVALUE;
    int _1434 = NOVALUE;
    int _1433 = NOVALUE;
    int _1432 = NOVALUE;
    int _1431 = NOVALUE;
    int _1430 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _1430 = IS_ATOM(_17input_string_2935);
    if (_1430 == 0)
    {
        _1430 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _1430 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _1431 = (_17ch_2937 != 10);
    if (_1431 == 0) {
        _1432 = 0;
        goto L3; // [22] 36
    }
    _1433 = (_17ch_2937 != 13);
    _1432 = (_1433 != 0);
L3: 
    if (_1432 == 0) {
        goto L4; // [36] 59
    }
    _1435 = (_17ch_2937 != -1);
    if (_1435 == 0)
    {
        DeRef(_1435);
        _1435 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_1435);
        _1435 = NOVALUE;
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch=-1 then*/
    if (_17ch_2937 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1437 = MAKE_SEQ(_1);
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    return _1437;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1438 = MAKE_SEQ(_1);
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    DeRef(_1437);
    _1437 = NOVALUE;
    return _1438;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_17input_string_2935)){
            _1439 = SEQ_PTR(_17input_string_2935)->length;
    }
    else {
        _1439 = 1;
    }
    {
        int _i_3033;
        _i_3033 = _17string_next_2936;
L7: 
        if (_i_3033 > _1439){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_17input_string_2935);
        _17ch_2937 = (int)*(((s1_ptr)_2)->base + _i_3033);
        if (!IS_ATOM_INT(_17ch_2937)){
            _17ch_2937 = (long)DBL_PTR(_17ch_2937)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _1441 = (_17ch_2937 == 10);
        if (_1441 != 0) {
            goto L9; // [132] 147
        }
        _1443 = (_17ch_2937 == 13);
        if (_1443 == 0)
        {
            DeRef(_1443);
            _1443 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_1443);
            _1443 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _17string_next_2936 = _i_3033 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _1445 = MAKE_SEQ(_1);
        DeRef(_1431);
        _1431 = NOVALUE;
        DeRef(_1433);
        _1433 = NOVALUE;
        DeRef(_1437);
        _1437 = NOVALUE;
        DeRef(_1438);
        _1438 = NOVALUE;
        DeRef(_1441);
        _1441 = NOVALUE;
        return _1445;
LA: 

        /** 		end for*/
        _i_3033 = _i_3033 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1446 = MAKE_SEQ(_1);
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    DeRef(_1437);
    _1437 = NOVALUE;
    DeRef(_1438);
    _1438 = NOVALUE;
    DeRef(_1441);
    _1441 = NOVALUE;
    DeRef(_1445);
    _1445 = NOVALUE;
    return _1446;
L6: 
    ;
}


int _17get_number()
{
    int _sign_3045 = NOVALUE;
    int _e_sign_3046 = NOVALUE;
    int _ndigits_3047 = NOVALUE;
    int _hex_digit_3048 = NOVALUE;
    int _mantissa_3049 = NOVALUE;
    int _dec_3050 = NOVALUE;
    int _e_mag_3051 = NOVALUE;
    int _1508 = NOVALUE;
    int _1506 = NOVALUE;
    int _1504 = NOVALUE;
    int _1500 = NOVALUE;
    int _1496 = NOVALUE;
    int _1494 = NOVALUE;
    int _1493 = NOVALUE;
    int _1492 = NOVALUE;
    int _1491 = NOVALUE;
    int _1490 = NOVALUE;
    int _1488 = NOVALUE;
    int _1487 = NOVALUE;
    int _1486 = NOVALUE;
    int _1483 = NOVALUE;
    int _1481 = NOVALUE;
    int _1479 = NOVALUE;
    int _1475 = NOVALUE;
    int _1474 = NOVALUE;
    int _1472 = NOVALUE;
    int _1471 = NOVALUE;
    int _1470 = NOVALUE;
    int _1467 = NOVALUE;
    int _1466 = NOVALUE;
    int _1464 = NOVALUE;
    int _1463 = NOVALUE;
    int _1462 = NOVALUE;
    int _1461 = NOVALUE;
    int _1460 = NOVALUE;
    int _1459 = NOVALUE;
    int _1456 = NOVALUE;
    int _1452 = NOVALUE;
    int _1449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_3045 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_3049);
    _mantissa_3049 = 0;

    /** 	ndigits = 0*/
    _ndigits_3047 = 0;

    /** 	if ch = '-' then*/
    if (_17ch_2937 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_3045 = -1;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch='-' then*/
    if (_17ch_2937 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _1449 = _17read_comment();
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    return _1449;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_17ch_2937 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _17get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_17ch_2937 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _17get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _1452 = find_from(_17ch_2937, _17HEX_DIGITS_2917, 1);
    _hex_digit_3048 = _1452 - 1;
    _1452 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_3048 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_3047 = _ndigits_3047 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_3049)) {
        if (_mantissa_3049 == (short)_mantissa_3049)
        _1456 = _mantissa_3049 * 16;
        else
        _1456 = NewDouble(_mantissa_3049 * (double)16);
    }
    else {
        _1456 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * (double)16);
    }
    DeRef(_mantissa_3049);
    if (IS_ATOM_INT(_1456)) {
        _mantissa_3049 = _1456 + _hex_digit_3048;
        if ((long)((unsigned long)_mantissa_3049 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3049 = NewDouble((double)_mantissa_3049);
    }
    else {
        _mantissa_3049 = NewDouble(DBL_PTR(_1456)->dbl + (double)_hex_digit_3048);
    }
    DeRef(_1456);
    _1456 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_3047 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_3049)) {
        if (_sign_3045 == (short)_sign_3045 && _mantissa_3049 <= INT15 && _mantissa_3049 >= -INT15)
        _1459 = _sign_3045 * _mantissa_3049;
        else
        _1459 = NewDouble(_sign_3045 * (double)_mantissa_3049);
    }
    else {
        _1459 = NewDouble((double)_sign_3045 * DBL_PTR(_mantissa_3049)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _1459;
    _1460 = MAKE_SEQ(_1);
    _1459 = NOVALUE;
    DeRef(_mantissa_3049);
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    DeRef(_1449);
    _1449 = NOVALUE;
    return _1460;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1461 = MAKE_SEQ(_1);
    DeRef(_mantissa_3049);
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    DeRef(_1449);
    _1449 = NOVALUE;
    DeRef(_1460);
    _1460 = NOVALUE;
    return _1461;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _1462 = (_17ch_2937 >= 48);
    if (_1462 == 0) {
        goto L9; // [181] 226
    }
    _1464 = (_17ch_2937 <= 57);
    if (_1464 == 0)
    {
        DeRef(_1464);
        _1464 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_1464);
        _1464 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_3047 = _ndigits_3047 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_3049)) {
        if (_mantissa_3049 == (short)_mantissa_3049)
        _1466 = _mantissa_3049 * 10;
        else
        _1466 = NewDouble(_mantissa_3049 * (double)10);
    }
    else {
        _1466 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * (double)10);
    }
    _1467 = _17ch_2937 - 48;
    if ((long)((unsigned long)_1467 +(unsigned long) HIGH_BITS) >= 0){
        _1467 = NewDouble((double)_1467);
    }
    DeRef(_mantissa_3049);
    if (IS_ATOM_INT(_1466) && IS_ATOM_INT(_1467)) {
        _mantissa_3049 = _1466 + _1467;
        if ((long)((unsigned long)_mantissa_3049 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3049 = NewDouble((double)_mantissa_3049);
    }
    else {
        if (IS_ATOM_INT(_1466)) {
            _mantissa_3049 = NewDouble((double)_1466 + DBL_PTR(_1467)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1467)) {
                _mantissa_3049 = NewDouble(DBL_PTR(_1466)->dbl + (double)_1467);
            }
            else
            _mantissa_3049 = NewDouble(DBL_PTR(_1466)->dbl + DBL_PTR(_1467)->dbl);
        }
    }
    DeRef(_1466);
    _1466 = NOVALUE;
    DeRef(_1467);
    _1467 = NOVALUE;

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_17ch_2937 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _17get_ch();

    /** 		dec = 10*/
    DeRef(_dec_3050);
    _dec_3050 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _1470 = (_17ch_2937 >= 48);
    if (_1470 == 0) {
        goto LC; // [254] 305
    }
    _1472 = (_17ch_2937 <= 57);
    if (_1472 == 0)
    {
        DeRef(_1472);
        _1472 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_1472);
        _1472 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_3047 = _ndigits_3047 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _1474 = _17ch_2937 - 48;
    if ((long)((unsigned long)_1474 +(unsigned long) HIGH_BITS) >= 0){
        _1474 = NewDouble((double)_1474);
    }
    if (IS_ATOM_INT(_1474) && IS_ATOM_INT(_dec_3050)) {
        _1475 = (_1474 % _dec_3050) ? NewDouble((double)_1474 / _dec_3050) : (_1474 / _dec_3050);
    }
    else {
        if (IS_ATOM_INT(_1474)) {
            _1475 = NewDouble((double)_1474 / DBL_PTR(_dec_3050)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_3050)) {
                _1475 = NewDouble(DBL_PTR(_1474)->dbl / (double)_dec_3050);
            }
            else
            _1475 = NewDouble(DBL_PTR(_1474)->dbl / DBL_PTR(_dec_3050)->dbl);
        }
    }
    DeRef(_1474);
    _1474 = NOVALUE;
    _0 = _mantissa_3049;
    if (IS_ATOM_INT(_mantissa_3049) && IS_ATOM_INT(_1475)) {
        _mantissa_3049 = _mantissa_3049 + _1475;
        if ((long)((unsigned long)_mantissa_3049 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3049 = NewDouble((double)_mantissa_3049);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3049)) {
            _mantissa_3049 = NewDouble((double)_mantissa_3049 + DBL_PTR(_1475)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1475)) {
                _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl + (double)_1475);
            }
            else
            _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl + DBL_PTR(_1475)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1475);
    _1475 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_3050;
    if (IS_ATOM_INT(_dec_3050)) {
        if (_dec_3050 == (short)_dec_3050)
        _dec_3050 = _dec_3050 * 10;
        else
        _dec_3050 = NewDouble(_dec_3050 * (double)10);
    }
    else {
        _dec_3050 = NewDouble(DBL_PTR(_dec_3050)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_3047 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1479 = MAKE_SEQ(_1);
    DeRef(_mantissa_3049);
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    DeRef(_1449);
    _1449 = NOVALUE;
    DeRef(_1460);
    _1460 = NOVALUE;
    DeRef(_1461);
    _1461 = NOVALUE;
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1470);
    _1470 = NOVALUE;
    return _1479;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_3049;
    if (IS_ATOM_INT(_mantissa_3049)) {
        if (_sign_3045 == (short)_sign_3045 && _mantissa_3049 <= INT15 && _mantissa_3049 >= -INT15)
        _mantissa_3049 = _sign_3045 * _mantissa_3049;
        else
        _mantissa_3049 = NewDouble(_sign_3045 * (double)_mantissa_3049);
    }
    else {
        _mantissa_3049 = NewDouble((double)_sign_3045 * DBL_PTR(_mantissa_3049)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _1481 = (_17ch_2937 == 101);
    if (_1481 != 0) {
        goto LE; // [337] 352
    }
    _1483 = (_17ch_2937 == 69);
    if (_1483 == 0)
    {
        DeRef(_1483);
        _1483 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_1483);
        _1483 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_3046 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_3051);
    _e_mag_3051 = 0;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = '-' then*/
    if (_17ch_2937 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_3046 = -1;

    /** 			get_ch()*/
    _17get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_17ch_2937 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _17get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _1486 = (_17ch_2937 >= 48);
    if (_1486 == 0) {
        goto L13; // [408] 487
    }
    _1488 = (_17ch_2937 <= 57);
    if (_1488 == 0)
    {
        DeRef(_1488);
        _1488 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_1488);
        _1488 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_3051);
    _e_mag_3051 = _17ch_2937 - 48;
    if ((long)((unsigned long)_e_mag_3051 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_3051 = NewDouble((double)_e_mag_3051);
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _1490 = (_17ch_2937 >= 48);
    if (_1490 == 0) {
        goto L15; // [445] 498
    }
    _1492 = (_17ch_2937 <= 57);
    if (_1492 == 0)
    {
        DeRef(_1492);
        _1492 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_1492);
        _1492 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_3051)) {
        if (_e_mag_3051 == (short)_e_mag_3051)
        _1493 = _e_mag_3051 * 10;
        else
        _1493 = NewDouble(_e_mag_3051 * (double)10);
    }
    else {
        _1493 = NewDouble(DBL_PTR(_e_mag_3051)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_1493)) {
        _1494 = _1493 + _17ch_2937;
        if ((long)((unsigned long)_1494 + (unsigned long)HIGH_BITS) >= 0) 
        _1494 = NewDouble((double)_1494);
    }
    else {
        _1494 = NewDouble(DBL_PTR(_1493)->dbl + (double)_17ch_2937);
    }
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_e_mag_3051);
    if (IS_ATOM_INT(_1494)) {
        _e_mag_3051 = _1494 - 48;
        if ((long)((unsigned long)_e_mag_3051 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_3051 = NewDouble((double)_e_mag_3051);
        }
    }
    else {
        _e_mag_3051 = NewDouble(DBL_PTR(_1494)->dbl - (double)48);
    }
    DeRef(_1494);
    _1494 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1496 = MAKE_SEQ(_1);
    DeRef(_mantissa_3049);
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    DeRef(_1449);
    _1449 = NOVALUE;
    DeRef(_1460);
    _1460 = NOVALUE;
    DeRef(_1461);
    _1461 = NOVALUE;
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1470);
    _1470 = NOVALUE;
    DeRef(_1479);
    _1479 = NOVALUE;
    DeRef(_1481);
    _1481 = NOVALUE;
    DeRef(_1486);
    _1486 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    return _1496;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_3051;
    if (IS_ATOM_INT(_e_mag_3051)) {
        if (_e_mag_3051 == (short)_e_mag_3051 && _e_sign_3046 <= INT15 && _e_sign_3046 >= -INT15)
        _e_mag_3051 = _e_mag_3051 * _e_sign_3046;
        else
        _e_mag_3051 = NewDouble(_e_mag_3051 * (double)_e_sign_3046);
    }
    else {
        _e_mag_3051 = NewDouble(DBL_PTR(_e_mag_3051)->dbl * (double)_e_sign_3046);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_3051, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _1500 = power(10, 308);
    _0 = _mantissa_3049;
    if (IS_ATOM_INT(_mantissa_3049) && IS_ATOM_INT(_1500)) {
        if (_mantissa_3049 == (short)_mantissa_3049 && _1500 <= INT15 && _1500 >= -INT15)
        _mantissa_3049 = _mantissa_3049 * _1500;
        else
        _mantissa_3049 = NewDouble(_mantissa_3049 * (double)_1500);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3049)) {
            _mantissa_3049 = NewDouble((double)_mantissa_3049 * DBL_PTR(_1500)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1500)) {
                _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * (double)_1500);
            }
            else
            _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * DBL_PTR(_1500)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1500);
    _1500 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_3051, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_3051);
    _e_mag_3051 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_3051)) {
        _1504 = _e_mag_3051 - 308;
        if ((long)((unsigned long)_1504 +(unsigned long) HIGH_BITS) >= 0){
            _1504 = NewDouble((double)_1504);
        }
    }
    else {
        _1504 = NewDouble(DBL_PTR(_e_mag_3051)->dbl - (double)308);
    }
    {
        int _i_3131;
        _i_3131 = 1;
L18: 
        if (binary_op_a(GREATER, _i_3131, _1504)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_3049;
        if (IS_ATOM_INT(_mantissa_3049)) {
            if (_mantissa_3049 == (short)_mantissa_3049)
            _mantissa_3049 = _mantissa_3049 * 10;
            else
            _mantissa_3049 = NewDouble(_mantissa_3049 * (double)10);
        }
        else {
            _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_3131;
        if (IS_ATOM_INT(_i_3131)) {
            _i_3131 = _i_3131 + 1;
            if ((long)((unsigned long)_i_3131 +(unsigned long) HIGH_BITS) >= 0){
                _i_3131 = NewDouble((double)_i_3131);
            }
        }
        else {
            _i_3131 = binary_op_a(PLUS, _i_3131, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_3131);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_3051)) {
        _1506 = power(10, _e_mag_3051);
    }
    else {
        temp_d.dbl = (double)10;
        _1506 = Dpower(&temp_d, DBL_PTR(_e_mag_3051));
    }
    _0 = _mantissa_3049;
    if (IS_ATOM_INT(_mantissa_3049) && IS_ATOM_INT(_1506)) {
        if (_mantissa_3049 == (short)_mantissa_3049 && _1506 <= INT15 && _1506 >= -INT15)
        _mantissa_3049 = _mantissa_3049 * _1506;
        else
        _mantissa_3049 = NewDouble(_mantissa_3049 * (double)_1506);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3049)) {
            _mantissa_3049 = NewDouble((double)_mantissa_3049 * DBL_PTR(_1506)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1506)) {
                _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * (double)_1506);
            }
            else
            _mantissa_3049 = NewDouble(DBL_PTR(_mantissa_3049)->dbl * DBL_PTR(_1506)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1506);
    _1506 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_3049);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_3049;
    _1508 = MAKE_SEQ(_1);
    DeRef(_mantissa_3049);
    DeRef(_dec_3050);
    DeRef(_e_mag_3051);
    DeRef(_1449);
    _1449 = NOVALUE;
    DeRef(_1460);
    _1460 = NOVALUE;
    DeRef(_1461);
    _1461 = NOVALUE;
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1470);
    _1470 = NOVALUE;
    DeRef(_1479);
    _1479 = NOVALUE;
    DeRef(_1481);
    _1481 = NOVALUE;
    DeRef(_1486);
    _1486 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1496);
    _1496 = NOVALUE;
    DeRef(_1504);
    _1504 = NOVALUE;
    return _1508;
    ;
}


int _17Get()
{
    int _skip_blanks_1__tmp_at328_3184 = NOVALUE;
    int _skip_blanks_1__tmp_at177_3165 = NOVALUE;
    int _skip_blanks_1__tmp_at88_3156 = NOVALUE;
    int _s_3140 = NOVALUE;
    int _e_3141 = NOVALUE;
    int _e1_3142 = NOVALUE;
    int _1544 = NOVALUE;
    int _1543 = NOVALUE;
    int _1541 = NOVALUE;
    int _1539 = NOVALUE;
    int _1537 = NOVALUE;
    int _1535 = NOVALUE;
    int _1532 = NOVALUE;
    int _1530 = NOVALUE;
    int _1526 = NOVALUE;
    int _1522 = NOVALUE;
    int _1519 = NOVALUE;
    int _1518 = NOVALUE;
    int _1516 = NOVALUE;
    int _1514 = NOVALUE;
    int _1512 = NOVALUE;
    int _1511 = NOVALUE;
    int _1509 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _1509 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_1509 == 0)
    {
        _1509 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _1509 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_2937 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1511 = MAKE_SEQ(_1);
    DeRef(_s_3140);
    DeRef(_e_3141);
    return _1511;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1512 = find_from(_17ch_2937, _17START_NUMERIC_2920, 1);
    if (_1512 == 0)
    {
        _1512 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _1512 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3141;
    _e_3141 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3141);
    _1514 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1514, -2)){
        _1514 = NOVALUE;
        goto L6; // [76] 87
    }
    _1514 = NOVALUE;

    /** 				return e*/
    DeRef(_s_3140);
    DeRef(_1511);
    _1511 = NOVALUE;
    return _e_3141;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_3156 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_skip_blanks_1__tmp_at88_3156 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _1516 = (_17ch_2937 == -1);
    if (_1516 != 0) {
        goto L9; // [128] 143
    }
    _1518 = (_17ch_2937 == 125);
    if (_1518 == 0)
    {
        DeRef(_1518);
        _1518 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_1518);
        _1518 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1519 = MAKE_SEQ(_1);
    DeRef(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    return _1519;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_2937 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3140);
    _s_3140 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_3165 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_skip_blanks_1__tmp_at177_3165 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_2937 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3140);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3140;
    _1522 = MAKE_SEQ(_1);
    DeRefDS(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    return _1522;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3141;
    _e_3141 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3141);
    _e1_3142 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3142))
    _e1_3142 = (long)DBL_PTR(_e1_3142)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3142 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3141);
    _1526 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1526);
    Append(&_s_3140, _s_3140, _1526);
    _1526 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3142 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_3140);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    return _e_3141;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_17ch_2937 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3140);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3140;
    _1530 = MAKE_SEQ(_1);
    DeRefDS(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    return _1530;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_3184 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_skip_blanks_1__tmp_at328_3184 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_17ch_2937 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_3140);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3140;
    _1532 = MAKE_SEQ(_1);
    DeRefDS(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    return _1532;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_17ch_2937 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3141;
    _e_3141 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3141);
    _1535 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1535, -2)){
        _1535 = NOVALUE;
        goto L13; // [413] 327
    }
    _1535 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1537 = MAKE_SEQ(_1);
    DeRef(_s_3140);
    DeRefDS(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    DeRef(_1532);
    _1532 = NOVALUE;
    return _1537;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_17ch_2937 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1539 = MAKE_SEQ(_1);
    DeRef(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    DeRef(_1532);
    _1532 = NOVALUE;
    DeRef(_1537);
    _1537 = NOVALUE;
    return _1539;
L19: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_2937 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _1541 = _17get_string();
    DeRef(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    DeRef(_1532);
    _1532 = NOVALUE;
    DeRef(_1537);
    _1537 = NOVALUE;
    DeRef(_1539);
    _1539 = NOVALUE;
    return _1541;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_2937 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _1543 = _17get_qchar();
    DeRef(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    DeRef(_1532);
    _1532 = NOVALUE;
    DeRef(_1537);
    _1537 = NOVALUE;
    DeRef(_1539);
    _1539 = NOVALUE;
    DeRef(_1541);
    _1541 = NOVALUE;
    return _1543;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1544 = MAKE_SEQ(_1);
    DeRef(_s_3140);
    DeRef(_e_3141);
    DeRef(_1511);
    _1511 = NOVALUE;
    DeRef(_1516);
    _1516 = NOVALUE;
    DeRef(_1519);
    _1519 = NOVALUE;
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1530);
    _1530 = NOVALUE;
    DeRef(_1532);
    _1532 = NOVALUE;
    DeRef(_1537);
    _1537 = NOVALUE;
    DeRef(_1539);
    _1539 = NOVALUE;
    DeRef(_1541);
    _1541 = NOVALUE;
    DeRef(_1543);
    _1543 = NOVALUE;
    return _1544;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _17Get2()
{
    int _skip_blanks_1__tmp_at464_3281 = NOVALUE;
    int _skip_blanks_1__tmp_at233_3248 = NOVALUE;
    int _s_3210 = NOVALUE;
    int _e_3211 = NOVALUE;
    int _e1_3212 = NOVALUE;
    int _offset_3213 = NOVALUE;
    int _1636 = NOVALUE;
    int _1635 = NOVALUE;
    int _1634 = NOVALUE;
    int _1633 = NOVALUE;
    int _1632 = NOVALUE;
    int _1631 = NOVALUE;
    int _1630 = NOVALUE;
    int _1629 = NOVALUE;
    int _1628 = NOVALUE;
    int _1627 = NOVALUE;
    int _1626 = NOVALUE;
    int _1623 = NOVALUE;
    int _1622 = NOVALUE;
    int _1621 = NOVALUE;
    int _1620 = NOVALUE;
    int _1619 = NOVALUE;
    int _1618 = NOVALUE;
    int _1615 = NOVALUE;
    int _1614 = NOVALUE;
    int _1613 = NOVALUE;
    int _1612 = NOVALUE;
    int _1611 = NOVALUE;
    int _1609 = NOVALUE;
    int _1608 = NOVALUE;
    int _1607 = NOVALUE;
    int _1606 = NOVALUE;
    int _1605 = NOVALUE;
    int _1603 = NOVALUE;
    int _1600 = NOVALUE;
    int _1599 = NOVALUE;
    int _1598 = NOVALUE;
    int _1597 = NOVALUE;
    int _1596 = NOVALUE;
    int _1594 = NOVALUE;
    int _1593 = NOVALUE;
    int _1592 = NOVALUE;
    int _1591 = NOVALUE;
    int _1590 = NOVALUE;
    int _1588 = NOVALUE;
    int _1587 = NOVALUE;
    int _1586 = NOVALUE;
    int _1585 = NOVALUE;
    int _1584 = NOVALUE;
    int _1583 = NOVALUE;
    int _1580 = NOVALUE;
    int _1576 = NOVALUE;
    int _1575 = NOVALUE;
    int _1574 = NOVALUE;
    int _1573 = NOVALUE;
    int _1572 = NOVALUE;
    int _1569 = NOVALUE;
    int _1568 = NOVALUE;
    int _1567 = NOVALUE;
    int _1566 = NOVALUE;
    int _1565 = NOVALUE;
    int _1563 = NOVALUE;
    int _1562 = NOVALUE;
    int _1561 = NOVALUE;
    int _1560 = NOVALUE;
    int _1559 = NOVALUE;
    int _1558 = NOVALUE;
    int _1556 = NOVALUE;
    int _1554 = NOVALUE;
    int _1552 = NOVALUE;
    int _1551 = NOVALUE;
    int _1550 = NOVALUE;
    int _1549 = NOVALUE;
    int _1548 = NOVALUE;
    int _1546 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_3213 = _17string_next_2936 - 1;

    /** 	get_ch()*/
    _17get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _1546 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_1546 == 0)
    {
        _1546 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _1546 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_2937 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _1548 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1548 +(unsigned long) HIGH_BITS) >= 0){
        _1548 = NewDouble((double)_1548);
    }
    if (IS_ATOM_INT(_1548)) {
        _1549 = _1548 - _offset_3213;
        if ((long)((unsigned long)_1549 +(unsigned long) HIGH_BITS) >= 0){
            _1549 = NewDouble((double)_1549);
        }
    }
    else {
        _1549 = NewDouble(DBL_PTR(_1548)->dbl - (double)_offset_3213);
    }
    DeRef(_1548);
    _1548 = NOVALUE;
    _1550 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1550 +(unsigned long) HIGH_BITS) >= 0){
        _1550 = NewDouble((double)_1550);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1549;
    *((int *)(_2+16)) = _1550;
    _1551 = MAKE_SEQ(_1);
    _1550 = NOVALUE;
    _1549 = NOVALUE;
    DeRef(_s_3210);
    DeRef(_e_3211);
    return _1551;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _1552 = _17string_next_2936 - 2;
    if ((long)((unsigned long)_1552 +(unsigned long) HIGH_BITS) >= 0){
        _1552 = NewDouble((double)_1552);
    }
    if (IS_ATOM_INT(_1552)) {
        _17leading_whitespace_3207 = _1552 - _offset_3213;
    }
    else {
        _17leading_whitespace_3207 = NewDouble(DBL_PTR(_1552)->dbl - (double)_offset_3213);
    }
    DeRef(_1552);
    _1552 = NOVALUE;
    if (!IS_ATOM_INT(_17leading_whitespace_3207)) {
        _1 = (long)(DBL_PTR(_17leading_whitespace_3207)->dbl);
        DeRefDS(_17leading_whitespace_3207);
        _17leading_whitespace_3207 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1554 = find_from(_17ch_2937, _17START_NUMERIC_2920, 1);
    if (_1554 == 0)
    {
        _1554 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _1554 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3211;
    _e_3211 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3211);
    _1556 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1556, -2)){
        _1556 = NOVALUE;
        goto L6; // [121] 162
    }
    _1556 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1558 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1558 +(unsigned long) HIGH_BITS) >= 0){
        _1558 = NewDouble((double)_1558);
    }
    if (IS_ATOM_INT(_1558)) {
        _1559 = _1558 - _offset_3213;
        if ((long)((unsigned long)_1559 +(unsigned long) HIGH_BITS) >= 0){
            _1559 = NewDouble((double)_1559);
        }
    }
    else {
        _1559 = NewDouble(DBL_PTR(_1558)->dbl - (double)_offset_3213);
    }
    DeRef(_1558);
    _1558 = NOVALUE;
    _1560 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1559)) {
        _1561 = _1559 - _1560;
        if ((long)((unsigned long)_1561 +(unsigned long) HIGH_BITS) >= 0){
            _1561 = NewDouble((double)_1561);
        }
    }
    else {
        _1561 = NewDouble(DBL_PTR(_1559)->dbl - (double)_1560);
    }
    DeRef(_1559);
    _1559 = NOVALUE;
    _1560 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1561;
    ((int *)_2)[2] = _17leading_whitespace_3207;
    _1562 = MAKE_SEQ(_1);
    _1561 = NOVALUE;
    Concat((object_ptr)&_1563, _e_3211, _1562);
    DeRefDS(_1562);
    _1562 = NOVALUE;
    DeRef(_s_3210);
    DeRefDS(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    return _1563;
L6: 

    /** 			get_ch()*/
    _17get_ch();

    /** 			if ch=-1 then*/
    if (_17ch_2937 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1565 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1565 +(unsigned long) HIGH_BITS) >= 0){
        _1565 = NewDouble((double)_1565);
    }
    if (IS_ATOM_INT(_1565)) {
        _1566 = _1565 - _offset_3213;
        if ((long)((unsigned long)_1566 +(unsigned long) HIGH_BITS) >= 0){
            _1566 = NewDouble((double)_1566);
        }
    }
    else {
        _1566 = NewDouble(DBL_PTR(_1565)->dbl - (double)_offset_3213);
    }
    DeRef(_1565);
    _1565 = NOVALUE;
    _1567 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1566)) {
        _1568 = _1566 - _1567;
        if ((long)((unsigned long)_1568 +(unsigned long) HIGH_BITS) >= 0){
            _1568 = NewDouble((double)_1568);
        }
    }
    else {
        _1568 = NewDouble(DBL_PTR(_1566)->dbl - (double)_1567);
    }
    DeRef(_1566);
    _1566 = NOVALUE;
    _1567 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1568;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1569 = MAKE_SEQ(_1);
    _1568 = NOVALUE;
    DeRef(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    return _1569;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_2937 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3210);
    _s_3210 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_3248 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_skip_blanks_1__tmp_at233_3248 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_2937 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1572 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1572 +(unsigned long) HIGH_BITS) >= 0){
        _1572 = NewDouble((double)_1572);
    }
    if (IS_ATOM_INT(_1572)) {
        _1573 = _1572 - _offset_3213;
        if ((long)((unsigned long)_1573 +(unsigned long) HIGH_BITS) >= 0){
            _1573 = NewDouble((double)_1573);
        }
    }
    else {
        _1573 = NewDouble(DBL_PTR(_1572)->dbl - (double)_offset_3213);
    }
    DeRef(_1572);
    _1572 = NOVALUE;
    _1574 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1573)) {
        _1575 = _1573 - _1574;
        if ((long)((unsigned long)_1575 +(unsigned long) HIGH_BITS) >= 0){
            _1575 = NewDouble((double)_1575);
        }
    }
    else {
        _1575 = NewDouble(DBL_PTR(_1573)->dbl - (double)_1574);
    }
    DeRef(_1573);
    _1573 = NOVALUE;
    _1574 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3210);
    *((int *)(_2+8)) = _s_3210;
    *((int *)(_2+12)) = _1575;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1576 = MAKE_SEQ(_1);
    _1575 = NOVALUE;
    DeRefDS(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    return _1576;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3211;
    _e_3211 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3211);
    _e1_3212 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3212))
    _e1_3212 = (long)DBL_PTR(_e1_3212)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3212 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3211);
    _1580 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1580);
    Append(&_s_3210, _s_3210, _1580);
    _1580 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3212 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1583 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1583 +(unsigned long) HIGH_BITS) >= 0){
        _1583 = NewDouble((double)_1583);
    }
    if (IS_ATOM_INT(_1583)) {
        _1584 = _1583 - _offset_3213;
        if ((long)((unsigned long)_1584 +(unsigned long) HIGH_BITS) >= 0){
            _1584 = NewDouble((double)_1584);
        }
    }
    else {
        _1584 = NewDouble(DBL_PTR(_1583)->dbl - (double)_offset_3213);
    }
    DeRef(_1583);
    _1583 = NOVALUE;
    _1585 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1584)) {
        _1586 = _1584 - _1585;
        if ((long)((unsigned long)_1586 +(unsigned long) HIGH_BITS) >= 0){
            _1586 = NewDouble((double)_1586);
        }
    }
    else {
        _1586 = NewDouble(DBL_PTR(_1584)->dbl - (double)_1585);
    }
    DeRef(_1584);
    _1584 = NOVALUE;
    _1585 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1586;
    ((int *)_2)[2] = _17leading_whitespace_3207;
    _1587 = MAKE_SEQ(_1);
    _1586 = NOVALUE;
    Concat((object_ptr)&_1588, _e_3211, _1587);
    DeRefDS(_1587);
    _1587 = NOVALUE;
    DeRef(_s_3210);
    DeRefDS(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    return _1588;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_17ch_2937 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _1590 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1590 +(unsigned long) HIGH_BITS) >= 0){
        _1590 = NewDouble((double)_1590);
    }
    if (IS_ATOM_INT(_1590)) {
        _1591 = _1590 - _offset_3213;
        if ((long)((unsigned long)_1591 +(unsigned long) HIGH_BITS) >= 0){
            _1591 = NewDouble((double)_1591);
        }
    }
    else {
        _1591 = NewDouble(DBL_PTR(_1590)->dbl - (double)_offset_3213);
    }
    DeRef(_1590);
    _1590 = NOVALUE;
    _1592 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1591)) {
        _1593 = _1591 - _1592;
        if ((long)((unsigned long)_1593 +(unsigned long) HIGH_BITS) >= 0){
            _1593 = NewDouble((double)_1593);
        }
    }
    else {
        _1593 = NewDouble(DBL_PTR(_1591)->dbl - (double)_1592);
    }
    DeRef(_1591);
    _1591 = NOVALUE;
    _1592 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3210);
    *((int *)(_2+8)) = _s_3210;
    *((int *)(_2+12)) = _1593;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1594 = MAKE_SEQ(_1);
    _1593 = NOVALUE;
    DeRefDS(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    return _1594;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_3281 = find_from(_17ch_2937, _17white_space_2953, 1);
    if (_skip_blanks_1__tmp_at464_3281 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_17ch_2937 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1596 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1596 +(unsigned long) HIGH_BITS) >= 0){
        _1596 = NewDouble((double)_1596);
    }
    if (IS_ATOM_INT(_1596)) {
        _1597 = _1596 - _offset_3213;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0){
            _1597 = NewDouble((double)_1597);
        }
    }
    else {
        _1597 = NewDouble(DBL_PTR(_1596)->dbl - (double)_offset_3213);
    }
    DeRef(_1596);
    _1596 = NOVALUE;
    _1598 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1597)) {
        _1599 = _1597 - _1598;
        if ((long)((unsigned long)_1599 +(unsigned long) HIGH_BITS) >= 0){
            _1599 = NewDouble((double)_1599);
        }
    }
    else {
        _1599 = NewDouble(DBL_PTR(_1597)->dbl - (double)_1598);
    }
    DeRef(_1597);
    _1597 = NOVALUE;
    _1598 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3210);
    *((int *)(_2+8)) = _s_3210;
    *((int *)(_2+12)) = _1599;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1600 = MAKE_SEQ(_1);
    _1599 = NOVALUE;
    DeRefDS(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    return _1600;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_17ch_2937 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3211;
    _e_3211 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3211);
    _1603 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1603, -2)){
        _1603 = NOVALUE;
        goto L10; // [574] 463
    }
    _1603 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _1605 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1605 +(unsigned long) HIGH_BITS) >= 0){
        _1605 = NewDouble((double)_1605);
    }
    if (IS_ATOM_INT(_1605)) {
        _1606 = _1605 - _offset_3213;
        if ((long)((unsigned long)_1606 +(unsigned long) HIGH_BITS) >= 0){
            _1606 = NewDouble((double)_1606);
        }
    }
    else {
        _1606 = NewDouble(DBL_PTR(_1605)->dbl - (double)_offset_3213);
    }
    DeRef(_1605);
    _1605 = NOVALUE;
    _1607 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1606)) {
        _1608 = _1606 - _1607;
        if ((long)((unsigned long)_1608 +(unsigned long) HIGH_BITS) >= 0){
            _1608 = NewDouble((double)_1608);
        }
    }
    else {
        _1608 = NewDouble(DBL_PTR(_1606)->dbl - (double)_1607);
    }
    DeRef(_1606);
    _1606 = NOVALUE;
    _1607 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1608;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1609 = MAKE_SEQ(_1);
    _1608 = NOVALUE;
    DeRef(_s_3210);
    DeRefDS(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    return _1609;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_17ch_2937 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1611 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1611 +(unsigned long) HIGH_BITS) >= 0){
        _1611 = NewDouble((double)_1611);
    }
    if (IS_ATOM_INT(_1611)) {
        _1612 = _1611 - _offset_3213;
        if ((long)((unsigned long)_1612 +(unsigned long) HIGH_BITS) >= 0){
            _1612 = NewDouble((double)_1612);
        }
    }
    else {
        _1612 = NewDouble(DBL_PTR(_1611)->dbl - (double)_offset_3213);
    }
    DeRef(_1611);
    _1611 = NOVALUE;
    _1613 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1612)) {
        _1614 = _1612 - _1613;
        if ((long)((unsigned long)_1614 +(unsigned long) HIGH_BITS) >= 0){
            _1614 = NewDouble((double)_1614);
        }
    }
    else {
        _1614 = NewDouble(DBL_PTR(_1612)->dbl - (double)_1613);
    }
    DeRef(_1612);
    _1612 = NOVALUE;
    _1613 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1614;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1615 = MAKE_SEQ(_1);
    _1614 = NOVALUE;
    DeRef(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1609);
    _1609 = NOVALUE;
    return _1615;
L16: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_2937 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_3211;
    _e_3211 = _17get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1618 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1618 +(unsigned long) HIGH_BITS) >= 0){
        _1618 = NewDouble((double)_1618);
    }
    if (IS_ATOM_INT(_1618)) {
        _1619 = _1618 - _offset_3213;
        if ((long)((unsigned long)_1619 +(unsigned long) HIGH_BITS) >= 0){
            _1619 = NewDouble((double)_1619);
        }
    }
    else {
        _1619 = NewDouble(DBL_PTR(_1618)->dbl - (double)_offset_3213);
    }
    DeRef(_1618);
    _1618 = NOVALUE;
    _1620 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1619)) {
        _1621 = _1619 - _1620;
        if ((long)((unsigned long)_1621 +(unsigned long) HIGH_BITS) >= 0){
            _1621 = NewDouble((double)_1621);
        }
    }
    else {
        _1621 = NewDouble(DBL_PTR(_1619)->dbl - (double)_1620);
    }
    DeRef(_1619);
    _1619 = NOVALUE;
    _1620 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1621;
    ((int *)_2)[2] = _17leading_whitespace_3207;
    _1622 = MAKE_SEQ(_1);
    _1621 = NOVALUE;
    Concat((object_ptr)&_1623, _e_3211, _1622);
    DeRefDS(_1622);
    _1622 = NOVALUE;
    DeRef(_s_3210);
    DeRefDS(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1609);
    _1609 = NOVALUE;
    DeRef(_1615);
    _1615 = NOVALUE;
    return _1623;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_2937 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_3211;
    _e_3211 = _17get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1626 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1626 +(unsigned long) HIGH_BITS) >= 0){
        _1626 = NewDouble((double)_1626);
    }
    if (IS_ATOM_INT(_1626)) {
        _1627 = _1626 - _offset_3213;
        if ((long)((unsigned long)_1627 +(unsigned long) HIGH_BITS) >= 0){
            _1627 = NewDouble((double)_1627);
        }
    }
    else {
        _1627 = NewDouble(DBL_PTR(_1626)->dbl - (double)_offset_3213);
    }
    DeRef(_1626);
    _1626 = NOVALUE;
    _1628 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1627)) {
        _1629 = _1627 - _1628;
        if ((long)((unsigned long)_1629 +(unsigned long) HIGH_BITS) >= 0){
            _1629 = NewDouble((double)_1629);
        }
    }
    else {
        _1629 = NewDouble(DBL_PTR(_1627)->dbl - (double)_1628);
    }
    DeRef(_1627);
    _1627 = NOVALUE;
    _1628 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1629;
    ((int *)_2)[2] = _17leading_whitespace_3207;
    _1630 = MAKE_SEQ(_1);
    _1629 = NOVALUE;
    Concat((object_ptr)&_1631, _e_3211, _1630);
    DeRefDS(_1630);
    _1630 = NOVALUE;
    DeRef(_s_3210);
    DeRefDS(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1609);
    _1609 = NOVALUE;
    DeRef(_1615);
    _1615 = NOVALUE;
    DeRef(_1623);
    _1623 = NOVALUE;
    return _1631;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1632 = _17string_next_2936 - 1;
    if ((long)((unsigned long)_1632 +(unsigned long) HIGH_BITS) >= 0){
        _1632 = NewDouble((double)_1632);
    }
    if (IS_ATOM_INT(_1632)) {
        _1633 = _1632 - _offset_3213;
        if ((long)((unsigned long)_1633 +(unsigned long) HIGH_BITS) >= 0){
            _1633 = NewDouble((double)_1633);
        }
    }
    else {
        _1633 = NewDouble(DBL_PTR(_1632)->dbl - (double)_offset_3213);
    }
    DeRef(_1632);
    _1632 = NOVALUE;
    _1634 = (_17ch_2937 != -1);
    if (IS_ATOM_INT(_1633)) {
        _1635 = _1633 - _1634;
        if ((long)((unsigned long)_1635 +(unsigned long) HIGH_BITS) >= 0){
            _1635 = NewDouble((double)_1635);
        }
    }
    else {
        _1635 = NewDouble(DBL_PTR(_1633)->dbl - (double)_1634);
    }
    DeRef(_1633);
    _1633 = NOVALUE;
    _1634 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1635;
    *((int *)(_2+16)) = _17leading_whitespace_3207;
    _1636 = MAKE_SEQ(_1);
    _1635 = NOVALUE;
    DeRef(_s_3210);
    DeRef(_e_3211);
    DeRef(_1551);
    _1551 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1569);
    _1569 = NOVALUE;
    DeRef(_1576);
    _1576 = NOVALUE;
    DeRef(_1588);
    _1588 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1609);
    _1609 = NOVALUE;
    DeRef(_1615);
    _1615 = NOVALUE;
    DeRef(_1623);
    _1623 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    return _1636;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}


int _17get_value(int _target_3340, int _start_point_3341, int _answer_type_3342)
{
    int _msg_inlined_crash_at_35_3353 = NOVALUE;
    int _data_inlined_crash_at_32_3352 = NOVALUE;
    int _where_inlined_where_at_76_3359 = NOVALUE;
    int _seek_1__tmp_at90_3364 = NOVALUE;
    int _seek_inlined_seek_at_90_3363 = NOVALUE;
    int _pos_inlined_seek_at_87_3362 = NOVALUE;
    int _msg_inlined_crash_at_108_3367 = NOVALUE;
    int _1652 = NOVALUE;
    int _1649 = NOVALUE;
    int _1648 = NOVALUE;
    int _1647 = NOVALUE;
    int _1643 = NOVALUE;
    int _1642 = NOVALUE;
    int _1641 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _1641 = (_answer_type_3342 != _17GET_SHORT_ANSWER_3332);
    if (_1641 == 0) {
        goto L1; // [13] 55
    }
    _1643 = (_answer_type_3342 != _17GET_LONG_ANSWER_3335);
    if (_1643 == 0)
    {
        DeRef(_1643);
        _1643 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_1643);
        _1643 = NOVALUE;
    }

    /** 		error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_1646);
    RefDS(_1645);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1645;
    ((int *)_2)[2] = _1646;
    _1647 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_3352);
    _data_inlined_crash_at_32_3352 = _1647;
    _1647 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_3353);
    _msg_inlined_crash_at_35_3353 = EPrintf(-9999999, _1644, _data_inlined_crash_at_32_3352);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_3353);

    /** end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_3352);
    _data_inlined_crash_at_32_3352 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_3353);
    _msg_inlined_crash_at_35_3353 = NOVALUE;
L1: 

    /** 	if atom(target) then -- get()*/
    _1648 = IS_ATOM(_target_3340);
    if (_1648 == 0)
    {
        _1648 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _1648 = NOVALUE;
    }

    /** 		input_file = target*/
    Ref(_target_3340);
    _17input_file_2934 = _target_3340;
    if (!IS_ATOM_INT(_17input_file_2934)) {
        _1 = (long)(DBL_PTR(_17input_file_2934)->dbl);
        DeRefDS(_17input_file_2934);
        _17input_file_2934 = _1;
    }

    /** 		if start_point then*/
    if (_start_point_3341 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** 			if io:seek(target, io:where(target)+start_point) then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_3359);
    _where_inlined_where_at_76_3359 = machine(20, _target_3340);
    if (IS_ATOM_INT(_where_inlined_where_at_76_3359)) {
        _1649 = _where_inlined_where_at_76_3359 + _start_point_3341;
        if ((long)((unsigned long)_1649 + (unsigned long)HIGH_BITS) >= 0) 
        _1649 = NewDouble((double)_1649);
    }
    else {
        _1649 = NewDouble(DBL_PTR(_where_inlined_where_at_76_3359)->dbl + (double)_start_point_3341);
    }
    DeRef(_pos_inlined_seek_at_87_3362);
    _pos_inlined_seek_at_87_3362 = _1649;
    _1649 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_3362);
    Ref(_target_3340);
    DeRef(_seek_1__tmp_at90_3364);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _target_3340;
    ((int *)_2)[2] = _pos_inlined_seek_at_87_3362;
    _seek_1__tmp_at90_3364 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_3363 = machine(19, _seek_1__tmp_at90_3364);
    DeRef(_pos_inlined_seek_at_87_3362);
    _pos_inlined_seek_at_87_3362 = NOVALUE;
    DeRef(_seek_1__tmp_at90_3364);
    _seek_1__tmp_at90_3364 = NOVALUE;
    if (_seek_inlined_seek_at_90_3363 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** 				error:crash("Initial seek() for get() failed!")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_3367);
    _msg_inlined_crash_at_108_3367 = EPrintf(-9999999, _1650, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_3367);

    /** end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_3367);
    _msg_inlined_crash_at_108_3367 = NOVALUE;
L5: 
L4: 

    /** 		string_next = 1*/
    _17string_next_2936 = 1;

    /** 		input_string = 0*/
    DeRef(_17input_string_2935);
    _17input_string_2935 = 0;
    goto L7; // [139] 153
L3: 

    /** 		input_string = target*/
    Ref(_target_3340);
    DeRef(_17input_string_2935);
    _17input_string_2935 = _target_3340;

    /** 		string_next = start_point*/
    _17string_next_2936 = _start_point_3341;
L7: 

    /** 	if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_3342 != _17GET_SHORT_ANSWER_3332)
    goto L8; // [157] 166

    /** 		get_ch()*/
    _17get_ch();
L8: 

    /** 	return call_func(answer_type, {})*/
    _0 = (int)_00[_answer_type_3342].addr;
    if (_00[_answer_type_3342].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                             );
    }
    DeRef(_1652);
    _1652 = _1;
    DeRef(_target_3340);
    DeRef(_1641);
    _1641 = NOVALUE;
    return _1652;
    ;
}


int  __stdcall _17get(int _file_3374, int _offset_3375, int _answer_3376)
{
    int _1653 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_3374)) {
        _1 = (long)(DBL_PTR(_file_3374)->dbl);
        DeRefDS(_file_3374);
        _file_3374 = _1;
    }
    if (!IS_ATOM_INT(_offset_3375)) {
        _1 = (long)(DBL_PTR(_offset_3375)->dbl);
        DeRefDS(_offset_3375);
        _offset_3375 = _1;
    }
    if (!IS_ATOM_INT(_answer_3376)) {
        _1 = (long)(DBL_PTR(_answer_3376)->dbl);
        DeRefDS(_answer_3376);
        _answer_3376 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _1653 = _17get_value(_file_3374, _offset_3375, _answer_3376);
    return _1653;
    ;
}


int  __stdcall _17value(int _st_3380, int _start_point_3381, int _answer_3382)
{
    int _1654 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_point_3381)) {
        _1 = (long)(DBL_PTR(_start_point_3381)->dbl);
        DeRefDS(_start_point_3381);
        _start_point_3381 = _1;
    }
    if (!IS_ATOM_INT(_answer_3382)) {
        _1 = (long)(DBL_PTR(_answer_3382)->dbl);
        DeRefDS(_answer_3382);
        _answer_3382 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_3380);
    _1654 = _17get_value(_st_3380, _start_point_3381, _answer_3382);
    DeRefDS(_st_3380);
    return _1654;
    ;
}


int  __stdcall _17defaulted_value(int _st_3386, int _def_3387, int _start_point_3388)
{
    int _result_3391 = NOVALUE;
    int _1659 = NOVALUE;
    int _1657 = NOVALUE;
    int _1655 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_point_3388)) {
        _1 = (long)(DBL_PTR(_start_point_3388)->dbl);
        DeRefDS(_start_point_3388);
        _start_point_3388 = _1;
    }

    /** 	if atom(st) then*/
    _1655 = IS_ATOM(_st_3386);
    if (_1655 == 0)
    {
        _1655 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _1655 = NOVALUE;
    }

    /** 		return def*/
    DeRef(_st_3386);
    DeRef(_result_3391);
    return _def_3387;
L1: 

    /** 	object result = get_value(st,start_point, GET_SHORT_ANSWER)*/
    Ref(_st_3386);
    _0 = _result_3391;
    _result_3391 = _17get_value(_st_3386, _start_point_3388, _17GET_SHORT_ANSWER_3332);
    DeRef(_0);

    /** 	if result[1] = GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_result_3391);
    _1657 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _1657, 0)){
        _1657 = NOVALUE;
        goto L2; // [34] 49
    }
    _1657 = NOVALUE;

    /** 		return result[2]*/
    _2 = (int)SEQ_PTR(_result_3391);
    _1659 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1659);
    DeRef(_st_3386);
    DeRef(_def_3387);
    DeRef(_result_3391);
    return _1659;
L2: 

    /** 	return def*/
    DeRef(_st_3386);
    DeRef(_result_3391);
    _1659 = NOVALUE;
    return _def_3387;
    ;
}



// 0x76449D6D
