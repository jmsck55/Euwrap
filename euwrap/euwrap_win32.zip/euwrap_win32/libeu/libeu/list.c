// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _58set_return_linked_list(int _i_23973)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_23973)) {
        _1 = (long)(DBL_PTR(_i_23973)->dbl);
        DeRefDS(_i_23973);
        _i_23973 = _1;
    }

    /** 	always_linked_list = i*/
    _58always_linked_list_23970 = _i_23973;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _58get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _58always_linked_list_23970;
    ;
}


int  __stdcall _58mystring(int _x_23978)
{
    int _flag_23979 = NOVALUE;
    int _i_23980 = NOVALUE;
    int _ob_23981 = NOVALUE;
    int _13254 = NOVALUE;
    int _13248 = NOVALUE;
    int _13246 = NOVALUE;
    int _13244 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _13244 = IS_SEQUENCE(_x_23978);
    if (_13244 != 0)
    goto L1; // [6] 16
    _13244 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_23978);
    DeRef(_ob_23981);
    return 0;
L1: 

    /** 	flag = 0*/
    _flag_23979 = 0;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_23978)){
            _13246 = SEQ_PTR(_x_23978)->length;
    }
    else {
        _13246 = 1;
    }
    {
        int _j_23986;
        _j_23986 = 1;
L2: 
        if (_j_23986 > _13246){
            goto L3; // [26] 107
        }

        /** 		ob = x[j]*/
        DeRef(_ob_23981);
        _2 = (int)SEQ_PTR(_x_23978);
        _ob_23981 = (int)*(((s1_ptr)_2)->base + _j_23986);
        Ref(_ob_23981);

        /** 		if not integer(ob) then*/
        if (IS_ATOM_INT(_ob_23981))
        _13248 = 1;
        else if (IS_ATOM_DBL(_ob_23981))
        _13248 = IS_ATOM_INT(DoubleToInt(_ob_23981));
        else
        _13248 = 0;
        if (_13248 != 0)
        goto L4; // [44] 54
        _13248 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_23978);
        DeRef(_ob_23981);
        return 0;
L4: 

        /** 		i = ob*/
        Ref(_ob_23981);
        _i_23980 = _ob_23981;
        if (!IS_ATOM_INT(_i_23980)) {
            _1 = (long)(DBL_PTR(_i_23980)->dbl);
            DeRefDS(_i_23980);
            _i_23980 = _1;
        }

        /** 		if i < 0 then*/
        if (_i_23980 >= 0)
        goto L5; // [63] 74

        /** 			return 0*/
        DeRef(_x_23978);
        DeRef(_ob_23981);
        return 0;
L5: 

        /** 		if i > 255 then*/
        if (_i_23980 <= 255)
        goto L6; // [76] 87

        /** 			return 0*/
        DeRef(_x_23978);
        DeRef(_ob_23981);
        return 0;
L6: 

        /** 		if flag = 0 then*/
        if (_flag_23979 != 0)
        goto L7; // [89] 100

        /** 			flag = (i = 0)*/
        _flag_23979 = (_i_23980 == 0);
L7: 

        /** 	end for*/
        _j_23986 = _j_23986 + 1;
        goto L2; // [102] 33
L3: 
        ;
    }

    /** 	return 1 + flag*/
    _13254 = _flag_23979 + 1;
    if (_13254 > MAXINT){
        _13254 = NewDouble((double)_13254);
    }
    DeRef(_x_23978);
    DeRef(_ob_23981);
    return _13254;
    ;
}


int  __stdcall _58myarray(int _x_24002)
{
    int _flag_24003 = NOVALUE;
    int _i_24004 = NOVALUE;
    int _ob_24005 = NOVALUE;
    int _13262 = NOVALUE;
    int _13259 = NOVALUE;
    int _13257 = NOVALUE;
    int _13255 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _13255 = IS_SEQUENCE(_x_24002);
    if (_13255 != 0)
    goto L1; // [6] 16
    _13255 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_24002);
    DeRef(_i_24004);
    DeRef(_ob_24005);
    return 0;
L1: 

    /** 	flag = 1*/
    _flag_24003 = 1;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_24002)){
            _13257 = SEQ_PTR(_x_24002)->length;
    }
    else {
        _13257 = 1;
    }
    {
        int _j_24010;
        _j_24010 = 1;
L2: 
        if (_j_24010 > _13257){
            goto L3; // [26] 152
        }

        /** 		ob = x[j]*/
        DeRef(_ob_24005);
        _2 = (int)SEQ_PTR(_x_24002);
        _ob_24005 = (int)*(((s1_ptr)_2)->base + _j_24010);
        Ref(_ob_24005);

        /** 		if not atom(ob) then*/
        _13259 = IS_ATOM(_ob_24005);
        if (_13259 != 0)
        goto L4; // [44] 54
        _13259 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_24002);
        DeRef(_i_24004);
        DeRef(_ob_24005);
        return 0;
L4: 

        /** 		if flag <= 2 then*/
        if (_flag_24003 > 2)
        goto L5; // [56] 145

        /** 			i = ob*/
        Ref(_ob_24005);
        DeRef(_i_24004);
        _i_24004 = _ob_24005;

        /** 			if floor(i) != i then*/
        if (IS_ATOM_INT(_i_24004))
        _13262 = e_floor(_i_24004);
        else
        _13262 = unary_op(FLOOR, _i_24004);
        if (binary_op_a(EQUALS, _13262, _i_24004)){
            DeRef(_13262);
            _13262 = NOVALUE;
            goto L6; // [70] 82
        }
        DeRef(_13262);
        _13262 = NOVALUE;

        /** 				flag = 3 -- for double*/
        _flag_24003 = 3;
        goto L7; // [79] 144
L6: 

        /** 			elsif i < (-2147483648) then*/
        if (binary_op_a(GREATEREQ, _i_24004, _13265)){
            goto L8; // [84] 96
        }

        /** 				flag = 3 -- for double*/
        _flag_24003 = 3;
        goto L7; // [93] 144
L8: 

        /** 			elsif i > 4294967295 then*/
        if (binary_op_a(LESSEQ, _i_24004, _13267)){
            goto L9; // [98] 110
        }

        /** 				flag = 3 -- for double*/
        _flag_24003 = 3;
        goto L7; // [107] 144
L9: 

        /** 			elsif flag = 2 then*/
        if (_flag_24003 != 2)
        goto LA; // [112] 131

        /** 				if i > 2147483647 then*/
        if (binary_op_a(LESSEQ, _i_24004, _13270)){
            goto L7; // [118] 144
        }

        /** 					flag = 3 -- for double*/
        _flag_24003 = 3;
        goto L7; // [128] 144
LA: 

        /** 			elsif i < 0 then*/
        if (binary_op_a(GREATEREQ, _i_24004, 0)){
            goto LB; // [133] 143
        }

        /** 				flag = 2 -- for signed int*/
        _flag_24003 = 2;
LB: 
L7: 
L5: 

        /** 	end for*/
        _j_24010 = _j_24010 + 1;
        goto L2; // [147] 33
L3: 
        ;
    }

    /** 	return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list*/
    DeRef(_x_24002);
    DeRef(_i_24004);
    DeRef(_ob_24005);
    return _flag_24003;
    ;
}


int  __stdcall _58sequence_to_linked_list(int _s_24054)
{
    int _ma_24055 = NOVALUE;
    int _next_24056 = NOVALUE;
    int _tmp_24057 = NOVALUE;
    int _a_24058 = NOVALUE;
    int _i_24059 = NOVALUE;
    int _13364 = NOVALUE;
    int _13363 = NOVALUE;
    int _13362 = NOVALUE;
    int _13361 = NOVALUE;
    int _13360 = NOVALUE;
    int _13358 = NOVALUE;
    int _13357 = NOVALUE;
    int _13355 = NOVALUE;
    int _13354 = NOVALUE;
    int _13353 = NOVALUE;
    int _13352 = NOVALUE;
    int _13350 = NOVALUE;
    int _13349 = NOVALUE;
    int _13347 = NOVALUE;
    int _13346 = NOVALUE;
    int _13344 = NOVALUE;
    int _13343 = NOVALUE;
    int _13342 = NOVALUE;
    int _13341 = NOVALUE;
    int _13340 = NOVALUE;
    int _13339 = NOVALUE;
    int _13338 = NOVALUE;
    int _13336 = NOVALUE;
    int _13335 = NOVALUE;
    int _13334 = NOVALUE;
    int _13332 = NOVALUE;
    int _13331 = NOVALUE;
    int _13329 = NOVALUE;
    int _13328 = NOVALUE;
    int _13327 = NOVALUE;
    int _13325 = NOVALUE;
    int _13324 = NOVALUE;
    int _13322 = NOVALUE;
    int _13321 = NOVALUE;
    int _13320 = NOVALUE;
    int _13318 = NOVALUE;
    int _13317 = NOVALUE;
    int _13314 = NOVALUE;
    int _13313 = NOVALUE;
    int _13312 = NOVALUE;
    int _13310 = NOVALUE;
    int _13309 = NOVALUE;
    int _13308 = NOVALUE;
    int _13306 = NOVALUE;
    int _13302 = NOVALUE;
    int _13300 = NOVALUE;
    int _13299 = NOVALUE;
    int _13298 = NOVALUE;
    int _13296 = NOVALUE;
    int _13295 = NOVALUE;
    int _13293 = NOVALUE;
    int _13292 = NOVALUE;
    int _13291 = NOVALUE;
    int _13290 = NOVALUE;
    int _13289 = NOVALUE;
    int _13288 = NOVALUE;
    int _13287 = NOVALUE;
    int _13286 = NOVALUE;
    int _13284 = NOVALUE;
    int _13283 = NOVALUE;
    int _13282 = NOVALUE;
    int _13280 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = allocate(SIZE_OF_STRUCT)*/
    _0 = _ma_24055;
    _ma_24055 = _59allocate(16);
    DeRef(_0);

    /** 	if integer(s) then -- most of the time it will be an integer(a)*/
    if (IS_ATOM_INT(_s_24054))
    _13280 = 1;
    else if (IS_ATOM_DBL(_s_24054))
    _13280 = IS_ATOM_INT(DoubleToInt(_s_24054));
    else
    _13280 = 0;
    if (_13280 == 0)
    {
        _13280 = NOVALUE;
        goto L1; // [12] 54
    }
    else{
        _13280 = NOVALUE;
    }

    /** 		i = s*/
    Ref(_s_24054);
    _i_24059 = _s_24054;
    if (!IS_ATOM_INT(_i_24059)) {
        _1 = (long)(DBL_PTR(_i_24059)->dbl);
        DeRefDS(_i_24059);
        _i_24059 = _1;
    }

    /** 		if i >= 0 then*/
    if (_i_24059 < 0)
    goto L2; // [24] 36

    /** 			poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58UINT_FLAG_24046)->dbl;
    goto L3; // [33] 42
L2: 

    /** 			poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58INT_FLAG_24044)->dbl;
L3: 

    /** 		poke4(ma + 4, i)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13282 = _ma_24055 + 4;
        if ((long)((unsigned long)_13282 + (unsigned long)HIGH_BITS) >= 0) 
        _13282 = NewDouble((double)_13282);
    }
    else {
        _13282 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13282)){
        poke4_addr = (unsigned long *)_13282;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13282)->dbl);
    }
    *poke4_addr = (unsigned long)_i_24059;
    DeRef(_13282);
    _13282 = NOVALUE;
    goto L4; // [51] 695
L1: 

    /** 	elsif atom(s) then*/
    _13283 = IS_ATOM(_s_24054);
    if (_13283 == 0)
    {
        _13283 = NOVALUE;
        goto L5; // [59] 212
    }
    else{
        _13283 = NOVALUE;
    }

    /** 		a = s*/
    Ref(_s_24054);
    DeRef(_a_24058);
    _a_24058 = _s_24054;

    /** 		if a = floor(a) then*/
    if (IS_ATOM_INT(_a_24058))
    _13284 = e_floor(_a_24058);
    else
    _13284 = unary_op(FLOOR, _a_24058);
    if (binary_op_a(NOTEQ, _a_24058, _13284)){
        DeRef(_13284);
        _13284 = NOVALUE;
        goto L6; // [72] 179
    }
    DeRef(_13284);
    _13284 = NOVALUE;

    /** 			if a <= #FFFFFFFF and a >= 0 then*/
    if (IS_ATOM_INT(_a_24058)) {
        _13286 = ((double)_a_24058 <= DBL_PTR(_13267)->dbl);
    }
    else {
        _13286 = (DBL_PTR(_a_24058)->dbl <= DBL_PTR(_13267)->dbl);
    }
    if (_13286 == 0) {
        goto L7; // [82] 111
    }
    if (IS_ATOM_INT(_a_24058)) {
        _13288 = (_a_24058 >= 0);
    }
    else {
        _13288 = (DBL_PTR(_a_24058)->dbl >= (double)0);
    }
    if (_13288 == 0)
    {
        DeRef(_13288);
        _13288 = NOVALUE;
        goto L7; // [91] 111
    }
    else{
        DeRef(_13288);
        _13288 = NOVALUE;
    }

    /** 				poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58UINT_FLAG_24046)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13289 = _ma_24055 + 4;
        if ((long)((unsigned long)_13289 + (unsigned long)HIGH_BITS) >= 0) 
        _13289 = NewDouble((double)_13289);
    }
    else {
        _13289 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13289)){
        poke4_addr = (unsigned long *)_13289;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13289)->dbl);
    }
    if (IS_ATOM_INT(_a_24058)) {
        *poke4_addr = (unsigned long)_a_24058;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_24058)->dbl;
    }
    DeRef(_13289);
    _13289 = NOVALUE;
    goto L4; // [108] 695
L7: 

    /** 			elsif a <= 2147483647 and a >= -2147483648 then*/
    if (IS_ATOM_INT(_a_24058)) {
        _13290 = ((double)_a_24058 <= DBL_PTR(_13270)->dbl);
    }
    else {
        _13290 = (DBL_PTR(_a_24058)->dbl <= DBL_PTR(_13270)->dbl);
    }
    if (_13290 == 0) {
        goto L8; // [117] 146
    }
    if (IS_ATOM_INT(_a_24058)) {
        _13292 = ((double)_a_24058 >= DBL_PTR(_13265)->dbl);
    }
    else {
        _13292 = (DBL_PTR(_a_24058)->dbl >= DBL_PTR(_13265)->dbl);
    }
    if (_13292 == 0)
    {
        DeRef(_13292);
        _13292 = NOVALUE;
        goto L8; // [126] 146
    }
    else{
        DeRef(_13292);
        _13292 = NOVALUE;
    }

    /** 				poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58INT_FLAG_24044)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13293 = _ma_24055 + 4;
        if ((long)((unsigned long)_13293 + (unsigned long)HIGH_BITS) >= 0) 
        _13293 = NewDouble((double)_13293);
    }
    else {
        _13293 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13293)){
        poke4_addr = (unsigned long *)_13293;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13293)->dbl);
    }
    if (IS_ATOM_INT(_a_24058)) {
        *poke4_addr = (unsigned long)_a_24058;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_24058)->dbl;
    }
    DeRef(_13293);
    _13293 = NOVALUE;
    goto L4; // [143] 695
L8: 

    /** 				tmp = allocate(8)*/
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(8);
    DeRef(_0);

    /** 				poke(tmp, atom_to_float64(a))*/
    Ref(_a_24058);
    _13295 = _59atom_to_float64(_a_24058);
    if (IS_ATOM_INT(_tmp_24057)){
        poke_addr = (unsigned char *)_tmp_24057;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
    }
    if (IS_ATOM_INT(_13295)) {
        *poke_addr = (unsigned char)_13295;
    }
    else if (IS_ATOM(_13295)) {
        *poke_addr = (signed char)DBL_PTR(_13295)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13295);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13295);
    _13295 = NOVALUE;

    /** 				poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58DOUBLE_FLAG_24042)->dbl;

    /** 				poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13296 = _ma_24055 + 4;
        if ((long)((unsigned long)_13296 + (unsigned long)HIGH_BITS) >= 0) 
        _13296 = NewDouble((double)_13296);
    }
    else {
        _13296 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13296)){
        poke4_addr = (unsigned long *)_13296;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13296)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13296);
    _13296 = NOVALUE;
    goto L4; // [176] 695
L6: 

    /** 			tmp = allocate(8)*/
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(8);
    DeRef(_0);

    /** 			poke(tmp, atom_to_float64(a))*/
    Ref(_a_24058);
    _13298 = _59atom_to_float64(_a_24058);
    if (IS_ATOM_INT(_tmp_24057)){
        poke_addr = (unsigned char *)_tmp_24057;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
    }
    if (IS_ATOM_INT(_13298)) {
        *poke_addr = (unsigned char)_13298;
    }
    else if (IS_ATOM(_13298)) {
        *poke_addr = (signed char)DBL_PTR(_13298)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13298);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13298);
    _13298 = NOVALUE;

    /** 			poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58DOUBLE_FLAG_24042)->dbl;

    /** 			poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13299 = _ma_24055 + 4;
        if ((long)((unsigned long)_13299 + (unsigned long)HIGH_BITS) >= 0) 
        _13299 = NewDouble((double)_13299);
    }
    else {
        _13299 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13299)){
        poke4_addr = (unsigned long *)_13299;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13299)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13299);
    _13299 = NOVALUE;
    goto L4; // [209] 695
L5: 

    /** 	elsif length(s) = 0 then*/
    if (IS_SEQUENCE(_s_24054)){
            _13300 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13300 = 1;
    }
    if (_13300 != 0)
    goto L9; // [217] 233

    /** 		poke4(ma, {NULL,NULL})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13302 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    _1 = (int)SEQ_PTR(_13302);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_13302);
    _13302 = NOVALUE;
    goto L4; // [230] 695
L9: 

    /** 		if not always_linked_list then*/
    if (_58always_linked_list_23970 != 0)
    goto LA; // [237] 548

    /** 			i = mystring(s)*/
    Ref(_s_24054);
    _i_24059 = _58mystring(_s_24054);
    if (!IS_ATOM_INT(_i_24059)) {
        _1 = (long)(DBL_PTR(_i_24059)->dbl);
        DeRefDS(_i_24059);
        _i_24059 = _1;
    }

    /** 			if i then -- string*/
    if (_i_24059 == 0)
    {
        goto LB; // [250] 338
    }
    else{
    }

    /** 				if i = 2 then*/
    if (_i_24059 != 2)
    goto LC; // [255] 297

    /** 					tmp = allocate(length(s))*/
    if (IS_SEQUENCE(_s_24054)){
            _13306 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13306 = 1;
    }
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(_13306);
    DeRef(_0);
    _13306 = NOVALUE;

    /** 					poke(tmp, s)*/
    if (IS_ATOM_INT(_tmp_24057)){
        poke_addr = (unsigned char *)_tmp_24057;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
    }
    if (IS_ATOM_INT(_s_24054)) {
        *poke_addr = (unsigned char)_s_24054;
    }
    else if (IS_ATOM(_s_24054)) {
        *poke_addr = (signed char)DBL_PTR(_s_24054)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_24054);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH*/
    if (IS_SEQUENCE(_s_24054)){
            _13308 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13308 = 1;
    }
    temp_d.dbl = (double)_13308;
    _13309 = Dor_bits(DBL_PTR(_58CBYTES_24051), &temp_d);
    _13308 = NOVALUE;
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    if (IS_ATOM_INT(_13309)) {
        *poke4_addr = (unsigned long)_13309;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13309)->dbl;
    }
    DeRef(_13309);
    _13309 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13310 = _ma_24055 + 4;
        if ((long)((unsigned long)_13310 + (unsigned long)HIGH_BITS) >= 0) 
        _13310 = NewDouble((double)_13310);
    }
    else {
        _13310 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13310)){
        poke4_addr = (unsigned long *)_13310;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13310)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13310);
    _13310 = NOVALUE;
    goto LD; // [294] 318
LC: 

    /** 					tmp = allocate_string(s)*/
    Ref(_s_24054);
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate_string(_s_24054);
    DeRef(_0);

    /** 					poke4(ma, CSTRING) -- why?*/
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58CSTRING_24050)->dbl;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13312 = _ma_24055 + 4;
        if ((long)((unsigned long)_13312 + (unsigned long)HIGH_BITS) >= 0) 
        _13312 = NewDouble((double)_13312);
    }
    else {
        _13312 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13312)){
        poke4_addr = (unsigned long *)_13312;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13312)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13312);
    _13312 = NOVALUE;
LD: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13313 = _ma_24055 + 8;
        if ((long)((unsigned long)_13313 + (unsigned long)HIGH_BITS) >= 0) 
        _13313 = NewDouble((double)_13313);
    }
    else {
        _13313 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13314 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13313)){
        poke4_addr = (unsigned long *)_13313;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13313)->dbl);
    }
    _1 = (int)SEQ_PTR(_13314);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13313);
    _13313 = NOVALUE;
    DeRefDS(_13314);
    _13314 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_24054);
    DeRef(_next_24056);
    DeRef(_tmp_24057);
    DeRef(_a_24058);
    DeRef(_13286);
    _13286 = NOVALUE;
    DeRef(_13290);
    _13290 = NOVALUE;
    return _ma_24055;
LB: 

    /** 			i = myarray(s)*/
    Ref(_s_24054);
    _i_24059 = _58myarray(_s_24054);
    if (!IS_ATOM_INT(_i_24059)) {
        _1 = (long)(DBL_PTR(_i_24059)->dbl);
        DeRefDS(_i_24059);
        _i_24059 = _1;
    }

    /** 			if i then*/
    if (_i_24059 == 0)
    {
        goto LE; // [348] 547
    }
    else{
    }

    /** 				if i = 1 then*/
    if (_i_24059 != 1)
    goto LF; // [353] 399

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_24054)){
            _13317 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13317 = 1;
    }
    if (_13317 == (short)_13317)
    _13318 = _13317 * 4;
    else
    _13318 = NewDouble(_13317 * (double)4);
    _13317 = NOVALUE;
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(_13318);
    DeRef(_0);
    _13318 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_24057)){
        poke4_addr = (unsigned long *)_tmp_24057;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
    }
    if (IS_ATOM_INT(_s_24054)) {
        *poke4_addr = (unsigned long)_s_24054;
    }
    else if (IS_ATOM(_s_24054)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_24054)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_24054);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(UINT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_24054)){
            _13320 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13320 = 1;
    }
    temp_d.dbl = (double)_13320;
    _13321 = Dor_bits(DBL_PTR(_58UINT_FLAG_24046), &temp_d);
    _13320 = NOVALUE;
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    if (IS_ATOM_INT(_13321)) {
        *poke4_addr = (unsigned long)_13321;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13321)->dbl;
    }
    DeRef(_13321);
    _13321 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13322 = _ma_24055 + 4;
        if ((long)((unsigned long)_13322 + (unsigned long)HIGH_BITS) >= 0) 
        _13322 = NewDouble((double)_13322);
    }
    else {
        _13322 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13322)){
        poke4_addr = (unsigned long *)_13322;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13322)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13322);
    _13322 = NOVALUE;
    goto L10; // [396] 527
LF: 

    /** 				elsif i = 2 then*/
    if (_i_24059 != 2)
    goto L11; // [401] 447

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_24054)){
            _13324 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13324 = 1;
    }
    if (_13324 == (short)_13324)
    _13325 = _13324 * 4;
    else
    _13325 = NewDouble(_13324 * (double)4);
    _13324 = NOVALUE;
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(_13325);
    DeRef(_0);
    _13325 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_24057)){
        poke4_addr = (unsigned long *)_tmp_24057;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
    }
    if (IS_ATOM_INT(_s_24054)) {
        *poke4_addr = (unsigned long)_s_24054;
    }
    else if (IS_ATOM(_s_24054)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_24054)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_24054);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(INT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_24054)){
            _13327 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13327 = 1;
    }
    temp_d.dbl = (double)_13327;
    _13328 = Dor_bits(DBL_PTR(_58INT_FLAG_24044), &temp_d);
    _13327 = NOVALUE;
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    if (IS_ATOM_INT(_13328)) {
        *poke4_addr = (unsigned long)_13328;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13328)->dbl;
    }
    DeRef(_13328);
    _13328 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13329 = _ma_24055 + 4;
        if ((long)((unsigned long)_13329 + (unsigned long)HIGH_BITS) >= 0) 
        _13329 = NewDouble((double)_13329);
    }
    else {
        _13329 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13329)){
        poke4_addr = (unsigned long *)_13329;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13329)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13329);
    _13329 = NOVALUE;
    goto L10; // [444] 527
L11: 

    /** 				elsif i = 3 then*/
    if (_i_24059 != 3)
    goto L12; // [449] 526

    /** 					tmp = allocate(length(s) * 8)*/
    if (IS_SEQUENCE(_s_24054)){
            _13331 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13331 = 1;
    }
    if (_13331 == (short)_13331)
    _13332 = _13331 * 8;
    else
    _13332 = NewDouble(_13331 * (double)8);
    _13331 = NOVALUE;
    _0 = _tmp_24057;
    _tmp_24057 = _59allocate(_13332);
    DeRef(_0);
    _13332 = NOVALUE;

    /** 					for j = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_24054)){
            _13334 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13334 = 1;
    }
    {
        int _j_24145;
        _j_24145 = 1;
L13: 
        if (_j_24145 > _13334){
            goto L14; // [471] 504
        }

        /** 						poke(tmp, atom_to_float64(s[j]))*/
        _2 = (int)SEQ_PTR(_s_24054);
        _13335 = (int)*(((s1_ptr)_2)->base + _j_24145);
        Ref(_13335);
        _13336 = _59atom_to_float64(_13335);
        _13335 = NOVALUE;
        if (IS_ATOM_INT(_tmp_24057)){
            poke_addr = (unsigned char *)_tmp_24057;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_24057)->dbl);
        }
        if (IS_ATOM_INT(_13336)) {
            *poke_addr = (unsigned char)_13336;
        }
        else if (IS_ATOM(_13336)) {
            *poke_addr = (signed char)DBL_PTR(_13336)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_13336);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
                }
            }
        }
        DeRef(_13336);
        _13336 = NOVALUE;

        /** 						tmp += 8*/
        _0 = _tmp_24057;
        if (IS_ATOM_INT(_tmp_24057)) {
            _tmp_24057 = _tmp_24057 + 8;
            if ((long)((unsigned long)_tmp_24057 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_24057 = NewDouble((double)_tmp_24057);
        }
        else {
            _tmp_24057 = NewDouble(DBL_PTR(_tmp_24057)->dbl + (double)8);
        }
        DeRef(_0);

        /** 					end for*/
        _j_24145 = _j_24145 + 1;
        goto L13; // [499] 478
L14: 
        ;
    }

    /** 					poke4(ma, or_bits(DOUBLE_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_24054)){
            _13338 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13338 = 1;
    }
    temp_d.dbl = (double)_13338;
    _13339 = Dor_bits(DBL_PTR(_58DOUBLE_FLAG_24042), &temp_d);
    _13338 = NOVALUE;
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    if (IS_ATOM_INT(_13339)) {
        *poke4_addr = (unsigned long)_13339;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13339)->dbl;
    }
    DeRef(_13339);
    _13339 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13340 = _ma_24055 + 4;
        if ((long)((unsigned long)_13340 + (unsigned long)HIGH_BITS) >= 0) 
        _13340 = NewDouble((double)_13340);
    }
    else {
        _13340 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13340)){
        poke4_addr = (unsigned long *)_13340;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13340)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13340);
    _13340 = NOVALUE;
L12: 
L10: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13341 = _ma_24055 + 8;
        if ((long)((unsigned long)_13341 + (unsigned long)HIGH_BITS) >= 0) 
        _13341 = NewDouble((double)_13341);
    }
    else {
        _13341 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13342 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13341)){
        poke4_addr = (unsigned long *)_13341;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13341)->dbl);
    }
    _1 = (int)SEQ_PTR(_13342);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13341);
    _13341 = NOVALUE;
    DeRefDS(_13342);
    _13342 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_24054);
    DeRef(_next_24056);
    DeRef(_tmp_24057);
    DeRef(_a_24058);
    DeRef(_13286);
    _13286 = NOVALUE;
    DeRef(_13290);
    _13290 = NOVALUE;
    return _ma_24055;
LE: 
LA: 

    /** 		next = NULL -- 0*/
    DeRef(_next_24056);
    _next_24056 = 0;

    /** 		poke4(ma, length(s))*/
    if (IS_SEQUENCE(_s_24054)){
            _13343 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13343 = 1;
    }
    if (IS_ATOM_INT(_ma_24055)){
        poke4_addr = (unsigned long *)_ma_24055;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24055)->dbl);
    }
    *poke4_addr = (unsigned long)_13343;
    _13343 = NOVALUE;

    /** 		if length(s) then*/
    if (IS_SEQUENCE(_s_24054)){
            _13344 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13344 = 1;
    }
    if (_13344 == 0)
    {
        _13344 = NOVALUE;
        goto L15; // [566] 678
    }
    else{
        _13344 = NOVALUE;
    }

    /** 			a = allocate(8) -- iterators to beginning and end of list*/
    _0 = _a_24058;
    _a_24058 = _59allocate(8);
    DeRef(_0);

    /** 			next = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_24054)){
            _13346 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13346 = 1;
    }
    _2 = (int)SEQ_PTR(_s_24054);
    _13347 = (int)*(((s1_ptr)_2)->base + _13346);
    Ref(_13347);
    _next_24056 = _58sequence_to_linked_list(_13347);
    _13347 = NOVALUE;

    /** 			s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_24054)){
            _13349 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13349 = 1;
    }
    _13350 = _13349 - 1;
    _13349 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_24054;
    RHS_Slice(_s_24054, 1, _13350);

    /** 			poke4(a + 4, next) -- store the end iterator*/
    if (IS_ATOM_INT(_a_24058)) {
        _13352 = _a_24058 + 4;
        if ((long)((unsigned long)_13352 + (unsigned long)HIGH_BITS) >= 0) 
        _13352 = NewDouble((double)_13352);
    }
    else {
        _13352 = NewDouble(DBL_PTR(_a_24058)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13352)){
        poke4_addr = (unsigned long *)_13352;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13352)->dbl);
    }
    if (IS_ATOM_INT(_next_24056)) {
        *poke4_addr = (unsigned long)_next_24056;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_24056)->dbl;
    }
    DeRef(_13352);
    _13352 = NOVALUE;

    /** 			while length(s) do*/
L16: 
    if (IS_SEQUENCE(_s_24054)){
            _13353 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13353 = 1;
    }
    if (_13353 == 0)
    {
        _13353 = NOVALUE;
        goto L17; // [619] 677
    }
    else{
        _13353 = NOVALUE;
    }

    /** 				tmp = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_24054)){
            _13354 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13354 = 1;
    }
    _2 = (int)SEQ_PTR(_s_24054);
    _13355 = (int)*(((s1_ptr)_2)->base + _13354);
    Ref(_13355);
    _0 = _tmp_24057;
    _tmp_24057 = _58sequence_to_linked_list(_13355);
    DeRef(_0);
    _13355 = NOVALUE;

    /** 				s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_24054)){
            _13357 = SEQ_PTR(_s_24054)->length;
    }
    else {
        _13357 = 1;
    }
    _13358 = _13357 - 1;
    _13357 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_24054;
    RHS_Slice(_s_24054, 1, _13358);

    /** 				poke4(next + 8, tmp)*/
    if (IS_ATOM_INT(_next_24056)) {
        _13360 = _next_24056 + 8;
        if ((long)((unsigned long)_13360 + (unsigned long)HIGH_BITS) >= 0) 
        _13360 = NewDouble((double)_13360);
    }
    else {
        _13360 = NewDouble(DBL_PTR(_next_24056)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_13360)){
        poke4_addr = (unsigned long *)_13360;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13360)->dbl);
    }
    if (IS_ATOM_INT(_tmp_24057)) {
        *poke4_addr = (unsigned long)_tmp_24057;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_24057)->dbl;
    }
    DeRef(_13360);
    _13360 = NOVALUE;

    /** 				poke4(tmp + 12, next)*/
    if (IS_ATOM_INT(_tmp_24057)) {
        _13361 = _tmp_24057 + 12;
        if ((long)((unsigned long)_13361 + (unsigned long)HIGH_BITS) >= 0) 
        _13361 = NewDouble((double)_13361);
    }
    else {
        _13361 = NewDouble(DBL_PTR(_tmp_24057)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_13361)){
        poke4_addr = (unsigned long *)_13361;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13361)->dbl);
    }
    if (IS_ATOM_INT(_next_24056)) {
        *poke4_addr = (unsigned long)_next_24056;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_24056)->dbl;
    }
    DeRef(_13361);
    _13361 = NOVALUE;

    /** 				next = tmp*/
    Ref(_tmp_24057);
    DeRef(_next_24056);
    _next_24056 = _tmp_24057;

    /** 			end while*/
    goto L16; // [674] 616
L17: 
L15: 

    /** 		poke4(a, next) -- store the beginning iterator*/
    if (IS_ATOM_INT(_a_24058)){
        poke4_addr = (unsigned long *)_a_24058;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_a_24058)->dbl);
    }
    if (IS_ATOM_INT(_next_24056)) {
        *poke4_addr = (unsigned long)_next_24056;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_24056)->dbl;
    }

    /** 		poke4(ma + 4, a) -- point data to the iterators*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13362 = _ma_24055 + 4;
        if ((long)((unsigned long)_13362 + (unsigned long)HIGH_BITS) >= 0) 
        _13362 = NewDouble((double)_13362);
    }
    else {
        _13362 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13362)){
        poke4_addr = (unsigned long *)_13362;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13362)->dbl);
    }
    if (IS_ATOM_INT(_a_24058)) {
        *poke4_addr = (unsigned long)_a_24058;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_24058)->dbl;
    }
    DeRef(_13362);
    _13362 = NOVALUE;
L4: 

    /** 	poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_24055)) {
        _13363 = _ma_24055 + 8;
        if ((long)((unsigned long)_13363 + (unsigned long)HIGH_BITS) >= 0) 
        _13363 = NewDouble((double)_13363);
    }
    else {
        _13363 = NewDouble(DBL_PTR(_ma_24055)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13364 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13363)){
        poke4_addr = (unsigned long *)_13363;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13363)->dbl);
    }
    _1 = (int)SEQ_PTR(_13364);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13363);
    _13363 = NOVALUE;
    DeRefDS(_13364);
    _13364 = NOVALUE;

    /** 	return ma*/
    DeRef(_s_24054);
    DeRef(_next_24056);
    DeRef(_tmp_24057);
    DeRef(_a_24058);
    DeRef(_13286);
    _13286 = NOVALUE;
    DeRef(_13290);
    _13290 = NOVALUE;
    DeRef(_13350);
    _13350 = NOVALUE;
    DeRef(_13358);
    _13358 = NOVALUE;
    return _ma_24055;
    ;
}


void  __stdcall _58free_linked_list(int _ma_24183)
{
    int _len_24184 = NOVALUE;
    int _tmp_24185 = NOVALUE;
    int _next_24186 = NOVALUE;
    int _ptr_24187 = NOVALUE;
    int _13376 = NOVALUE;
    int _13374 = NOVALUE;
    int _13373 = NOVALUE;
    int _13369 = NOVALUE;
    int _13368 = NOVALUE;
    int _13366 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_24184);
    if (IS_ATOM_INT(_ma_24183)) {
        _len_24184 = *(unsigned long *)_ma_24183;
        if ((unsigned)_len_24184 > (unsigned)MAXINT)
        _len_24184 = NewDouble((double)(unsigned long)_len_24184);
    }
    else {
        _len_24184 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_24183)->dbl);
        if ((unsigned)_len_24184 > (unsigned)MAXINT)
        _len_24184 = NewDouble((double)(unsigned long)_len_24184);
    }

    /** 	ptr = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24183)) {
        _13366 = _ma_24183 + 4;
        if ((long)((unsigned long)_13366 + (unsigned long)HIGH_BITS) >= 0) 
        _13366 = NewDouble((double)_13366);
    }
    else {
        _13366 = NewDouble(DBL_PTR(_ma_24183)->dbl + (double)4);
    }
    DeRef(_ptr_24187);
    if (IS_ATOM_INT(_13366)) {
        _ptr_24187 = *(unsigned long *)_13366;
        if ((unsigned)_ptr_24187 > (unsigned)MAXINT)
        _ptr_24187 = NewDouble((double)(unsigned long)_ptr_24187);
    }
    else {
        _ptr_24187 = *(unsigned long *)(unsigned long)(DBL_PTR(_13366)->dbl);
        if ((unsigned)_ptr_24187 > (unsigned)MAXINT)
        _ptr_24187 = NewDouble((double)(unsigned long)_ptr_24187);
    }
    DeRef(_13366);
    _13366 = NOVALUE;

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_24184)) {
        temp_d.dbl = (double)_len_24184;
        _13368 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_FLAG_24041));
    }
    else {
        _13368 = Dand_bits(DBL_PTR(_len_24184), DBL_PTR(_58SIGN_FLAG_24041));
    }
    if (_13368 == 0) {
        DeRef(_13368);
        _13368 = NOVALUE;
        goto L1; // [21] 57
    }
    else {
        if (!IS_ATOM_INT(_13368) && DBL_PTR(_13368)->dbl == 0.0){
            DeRef(_13368);
            _13368 = NOVALUE;
            goto L1; // [21] 57
        }
        DeRef(_13368);
        _13368 = NOVALUE;
    }
    DeRef(_13368);
    _13368 = NOVALUE;

    /** 	 	if and_bits(len, MAX_LENGTH) then*/
    if (IS_ATOM_INT(_len_24184)) {
        {unsigned long tu;
             tu = (unsigned long)_len_24184 & (unsigned long)268435455;
             _13369 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _13369 = Dand_bits(DBL_PTR(_len_24184), &temp_d);
    }
    if (_13369 == 0) {
        DeRef(_13369);
        _13369 = NOVALUE;
        goto L2; // [30] 41
    }
    else {
        if (!IS_ATOM_INT(_13369) && DBL_PTR(_13369)->dbl == 0.0){
            DeRef(_13369);
            _13369 = NOVALUE;
            goto L2; // [30] 41
        }
        DeRef(_13369);
        _13369 = NOVALUE;
    }
    DeRef(_13369);
    _13369 = NOVALUE;

    /** 			free(ptr)*/
    Ref(_ptr_24187);
    _59free(_ptr_24187);
    goto L3; // [38] 116
L2: 

    /** 		elsif len = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _len_24184, _58DOUBLE_FLAG_24042)){
        goto L3; // [43] 116
    }

    /** 			free(ptr)*/
    Ref(_ptr_24187);
    _59free(_ptr_24187);
    goto L3; // [54] 116
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_24184, 0)){
        goto L4; // [59] 115
    }

    /** 		tmp = peek4u(ptr) -- iterator to the beginning of the list*/
    DeRef(_tmp_24185);
    if (IS_ATOM_INT(_ptr_24187)) {
        _tmp_24185 = *(unsigned long *)_ptr_24187;
        if ((unsigned)_tmp_24185 > (unsigned)MAXINT)
        _tmp_24185 = NewDouble((double)(unsigned long)_tmp_24185);
    }
    else {
        _tmp_24185 = *(unsigned long *)(unsigned long)(DBL_PTR(_ptr_24187)->dbl);
        if ((unsigned)_tmp_24185 > (unsigned)MAXINT)
        _tmp_24185 = NewDouble((double)(unsigned long)_tmp_24185);
    }

    /** 		free(ptr) -- free the iterators*/
    Ref(_ptr_24187);
    _59free(_ptr_24187);

    /** 		for i = 1 to len do*/
    Ref(_len_24184);
    DeRef(_13373);
    _13373 = _len_24184;
    {
        int _i_24204;
        _i_24204 = 1;
L5: 
        if (binary_op_a(GREATER, _i_24204, _13373)){
            goto L6; // [78] 114
        }

        /** 			next = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_24185)) {
            _13374 = _tmp_24185 + 12;
            if ((long)((unsigned long)_13374 + (unsigned long)HIGH_BITS) >= 0) 
            _13374 = NewDouble((double)_13374);
        }
        else {
            _13374 = NewDouble(DBL_PTR(_tmp_24185)->dbl + (double)12);
        }
        DeRef(_next_24186);
        if (IS_ATOM_INT(_13374)) {
            _next_24186 = *(unsigned long *)_13374;
            if ((unsigned)_next_24186 > (unsigned)MAXINT)
            _next_24186 = NewDouble((double)(unsigned long)_next_24186);
        }
        else {
            _next_24186 = *(unsigned long *)(unsigned long)(DBL_PTR(_13374)->dbl);
            if ((unsigned)_next_24186 > (unsigned)MAXINT)
            _next_24186 = NewDouble((double)(unsigned long)_next_24186);
        }
        DeRef(_13374);
        _13374 = NOVALUE;

        /** 			free_linked_list(tmp)*/
        Ref(_tmp_24185);
        DeRef(_13376);
        _13376 = _tmp_24185;
        _58free_linked_list(_13376);
        _13376 = NOVALUE;

        /** 			tmp = next*/
        Ref(_next_24186);
        DeRef(_tmp_24185);
        _tmp_24185 = _next_24186;

        /** 		end for*/
        _0 = _i_24204;
        if (IS_ATOM_INT(_i_24204)) {
            _i_24204 = _i_24204 + 1;
            if ((long)((unsigned long)_i_24204 +(unsigned long) HIGH_BITS) >= 0){
                _i_24204 = NewDouble((double)_i_24204);
            }
        }
        else {
            _i_24204 = binary_op_a(PLUS, _i_24204, 1);
        }
        DeRef(_0);
        goto L5; // [109] 85
L6: 
        ;
        DeRef(_i_24204);
    }
L4: 
L3: 

    /** 	free(ma)*/
    Ref(_ma_24183);
    _59free(_ma_24183);

    /** end procedure*/
    DeRef(_ma_24183);
    DeRef(_len_24184);
    DeRef(_tmp_24185);
    DeRef(_next_24186);
    DeRef(_ptr_24187);
    return;
    ;
}


int  __stdcall _58linked_list_to_sequence(int _ma_24212)
{
    int _len_24213 = NOVALUE;
    int _tmp_24214 = NOVALUE;
    int _val_24215 = NOVALUE;
    int _s_24216 = NOVALUE;
    int _13435 = NOVALUE;
    int _13434 = NOVALUE;
    int _13432 = NOVALUE;
    int _13431 = NOVALUE;
    int _13430 = NOVALUE;
    int _13429 = NOVALUE;
    int _13425 = NOVALUE;
    int _13422 = NOVALUE;
    int _13420 = NOVALUE;
    int _13419 = NOVALUE;
    int _13417 = NOVALUE;
    int _13416 = NOVALUE;
    int _13415 = NOVALUE;
    int _13414 = NOVALUE;
    int _13410 = NOVALUE;
    int _13408 = NOVALUE;
    int _13407 = NOVALUE;
    int _13406 = NOVALUE;
    int _13404 = NOVALUE;
    int _13403 = NOVALUE;
    int _13402 = NOVALUE;
    int _13401 = NOVALUE;
    int _13398 = NOVALUE;
    int _13395 = NOVALUE;
    int _13393 = NOVALUE;
    int _13392 = NOVALUE;
    int _13389 = NOVALUE;
    int _13387 = NOVALUE;
    int _13386 = NOVALUE;
    int _13380 = NOVALUE;
    int _13378 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_24213);
    if (IS_ATOM_INT(_ma_24212)) {
        _len_24213 = *(unsigned long *)_ma_24212;
        if ((unsigned)_len_24213 > (unsigned)MAXINT)
        _len_24213 = NewDouble((double)(unsigned long)_len_24213);
    }
    else {
        _len_24213 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_24212)->dbl);
        if ((unsigned)_len_24213 > (unsigned)MAXINT)
        _len_24213 = NewDouble((double)(unsigned long)_len_24213);
    }

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_24213)) {
        temp_d.dbl = (double)_len_24213;
        _13378 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_FLAG_24041));
    }
    else {
        _13378 = Dand_bits(DBL_PTR(_len_24213), DBL_PTR(_58SIGN_FLAG_24041));
    }
    if (_13378 == 0) {
        DeRef(_13378);
        _13378 = NOVALUE;
        goto L1; // [12] 380
    }
    else {
        if (!IS_ATOM_INT(_13378) && DBL_PTR(_13378)->dbl == 0.0){
            DeRef(_13378);
            _13378 = NOVALUE;
            goto L1; // [12] 380
        }
        DeRef(_13378);
        _13378 = NOVALUE;
    }
    DeRef(_13378);
    _13378 = NOVALUE;

    /** 		if len = CSTRING then*/
    if (binary_op_a(NOTEQ, _len_24213, _58CSTRING_24050)){
        goto L2; // [17] 44
    }

    /** 			tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13380 = _ma_24212 + 4;
        if ((long)((unsigned long)_13380 + (unsigned long)HIGH_BITS) >= 0) 
        _13380 = NewDouble((double)_13380);
    }
    else {
        _13380 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13380)) {
        _tmp_24214 = *(unsigned long *)_13380;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13380)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_13380);
    _13380 = NOVALUE;

    /** 			s = peek_string(tmp)*/
    DeRef(_s_24216);
    if (IS_ATOM_INT(_tmp_24214)) {
        _s_24216 =  NewString((char *)_tmp_24214);
    }
    else {
        _s_24216 = NewString((char *)(unsigned long)(DBL_PTR(_tmp_24214)->dbl));
    }

    /** 			return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
L2: 

    /** 		val = and_bits(len, SIGN_MASK)*/
    DeRef(_val_24215);
    if (IS_ATOM_INT(_len_24213)) {
        temp_d.dbl = (double)_len_24213;
        _val_24215 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_MASK_24039));
    }
    else {
        _val_24215 = Dand_bits(DBL_PTR(_len_24213), DBL_PTR(_58SIGN_MASK_24039));
    }

    /** 		len = and_bits(len, MAX_LENGTH)*/
    _0 = _len_24213;
    if (IS_ATOM_INT(_len_24213)) {
        {unsigned long tu;
             tu = (unsigned long)_len_24213 & (unsigned long)268435455;
             _len_24213 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _len_24213 = Dand_bits(DBL_PTR(_len_24213), &temp_d);
    }
    DeRef(_0);

    /** 		if val = UINT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_24215, _58UINT_FLAG_24046)){
        goto L3; // [58] 108
    }

    /** 			if len then*/
    if (_len_24213 == 0) {
        goto L4; // [64] 91
    }
    else {
        if (!IS_ATOM_INT(_len_24213) && DBL_PTR(_len_24213)->dbl == 0.0){
            goto L4; // [64] 91
        }
    }

    /** 				s = peek4u({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13386 = _ma_24212 + 4;
        if ((long)((unsigned long)_13386 + (unsigned long)HIGH_BITS) >= 0) 
        _13386 = NewDouble((double)_13386);
    }
    else {
        _13386 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    Ref(_len_24213);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13386;
    ((int *)_2)[2] = _len_24213;
    _13387 = MAKE_SEQ(_1);
    _13386 = NOVALUE;
    DeRef(_s_24216);
    _1 = (int)SEQ_PTR(_13387);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_24216 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13387);
    _13387 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto L5; // [88] 107
L4: 

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13389 = _ma_24212 + 4;
        if ((long)((unsigned long)_13389 + (unsigned long)HIGH_BITS) >= 0) 
        _13389 = NewDouble((double)_13389);
    }
    else {
        _13389 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13389)) {
        _tmp_24214 = *(unsigned long *)_13389;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13389)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_13389);
    _13389 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_val_24215);
    DeRef(_s_24216);
    return _tmp_24214;
L5: 
L3: 

    /** 		if val = INT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_24215, _58INT_FLAG_24044)){
        goto L6; // [110] 160
    }

    /** 			if len then*/
    if (_len_24213 == 0) {
        goto L7; // [116] 143
    }
    else {
        if (!IS_ATOM_INT(_len_24213) && DBL_PTR(_len_24213)->dbl == 0.0){
            goto L7; // [116] 143
        }
    }

    /** 				s = peek4s({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13392 = _ma_24212 + 4;
        if ((long)((unsigned long)_13392 + (unsigned long)HIGH_BITS) >= 0) 
        _13392 = NewDouble((double)_13392);
    }
    else {
        _13392 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    Ref(_len_24213);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13392;
    ((int *)_2)[2] = _len_24213;
    _13393 = MAKE_SEQ(_1);
    _13392 = NOVALUE;
    DeRef(_s_24216);
    _1 = (int)SEQ_PTR(_13393);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_24216 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
        _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13393);
    _13393 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto L8; // [140] 159
L7: 

    /** 				tmp = peek4s(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13395 = _ma_24212 + 4;
        if ((long)((unsigned long)_13395 + (unsigned long)HIGH_BITS) >= 0) 
        _13395 = NewDouble((double)_13395);
    }
    else {
        _13395 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13395)) {
        _tmp_24214 = *(unsigned long *)_13395;
        if (_tmp_24214 < MININT || _tmp_24214 > MAXINT)
        _tmp_24214 = NewDouble((double)(long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13395)->dbl);
        if (_tmp_24214 < MININT || _tmp_24214 > MAXINT)
        _tmp_24214 = NewDouble((double)(long)_tmp_24214);
    }
    DeRef(_13395);
    _13395 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_val_24215);
    DeRef(_s_24216);
    return _tmp_24214;
L8: 
L6: 

    /** 		if val = FLOAT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_24215, _58FLOAT_FLAG_24048)){
        goto L9; // [162] 262
    }

    /** 			if len then*/
    if (_len_24213 == 0) {
        goto LA; // [168] 237
    }
    else {
        if (!IS_ATOM_INT(_len_24213) && DBL_PTR(_len_24213)->dbl == 0.0){
            goto LA; // [168] 237
        }
    }

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13398 = _ma_24212 + 4;
        if ((long)((unsigned long)_13398 + (unsigned long)HIGH_BITS) >= 0) 
        _13398 = NewDouble((double)_13398);
    }
    else {
        _13398 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13398)) {
        _tmp_24214 = *(unsigned long *)_13398;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13398)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_13398);
    _13398 = NOVALUE;

    /** 				s = repeat(0, len)*/
    DeRef(_s_24216);
    _s_24216 = Repeat(0, _len_24213);

    /** 				for i = 1 to len do*/
    Ref(_len_24213);
    DeRef(_13401);
    _13401 = _len_24213;
    {
        int _i_24252;
        _i_24252 = 1;
LB: 
        if (binary_op_a(GREATER, _i_24252, _13401)){
            goto LC; // [191] 228
        }

        /** 					s[i] = float32_to_atom(peek({tmp, 4}))*/
        Ref(_tmp_24214);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_24214;
        ((int *)_2)[2] = 4;
        _13402 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_13402);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13403 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_13402);
        _13402 = NOVALUE;
        _13404 = _59float32_to_atom(_13403);
        _13403 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_24216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_24216 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_24252))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_24252)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_24252);
        _1 = *(int *)_2;
        *(int *)_2 = _13404;
        if( _1 != _13404 ){
            DeRef(_1);
        }
        _13404 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_24214;
        if (IS_ATOM_INT(_tmp_24214)) {
            _tmp_24214 = _tmp_24214 + 8;
            if ((long)((unsigned long)_tmp_24214 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_24214 = NewDouble((double)_tmp_24214);
        }
        else {
            _tmp_24214 = NewDouble(DBL_PTR(_tmp_24214)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_24252;
        if (IS_ATOM_INT(_i_24252)) {
            _i_24252 = _i_24252 + 1;
            if ((long)((unsigned long)_i_24252 +(unsigned long) HIGH_BITS) >= 0){
                _i_24252 = NewDouble((double)_i_24252);
            }
        }
        else {
            _i_24252 = binary_op_a(PLUS, _i_24252, 1);
        }
        DeRef(_0);
        goto LB; // [223] 198
LC: 
        ;
        DeRef(_i_24252);
    }

    /** 				return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto LD; // [234] 261
LA: 

    /** 				tmp = float32_to_atom(peek({ma + 4, 4}))*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13406 = _ma_24212 + 4;
        if ((long)((unsigned long)_13406 + (unsigned long)HIGH_BITS) >= 0) 
        _13406 = NewDouble((double)_13406);
    }
    else {
        _13406 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13406;
    ((int *)_2)[2] = 4;
    _13407 = MAKE_SEQ(_1);
    _13406 = NOVALUE;
    _1 = (int)SEQ_PTR(_13407);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _13408 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13407);
    _13407 = NOVALUE;
    _0 = _tmp_24214;
    _tmp_24214 = _59float32_to_atom(_13408);
    DeRef(_0);
    _13408 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_val_24215);
    DeRef(_s_24216);
    return _tmp_24214;
LD: 
L9: 

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13410 = _ma_24212 + 4;
        if ((long)((unsigned long)_13410 + (unsigned long)HIGH_BITS) >= 0) 
        _13410 = NewDouble((double)_13410);
    }
    else {
        _13410 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13410)) {
        _tmp_24214 = *(unsigned long *)_13410;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13410)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_13410);
    _13410 = NOVALUE;

    /** 		if val = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _val_24215, _58DOUBLE_FLAG_24042)){
        goto LE; // [273] 360
    }

    /** 			if len then*/
    if (_len_24213 == 0) {
        goto LF; // [279] 339
    }
    else {
        if (!IS_ATOM_INT(_len_24213) && DBL_PTR(_len_24213)->dbl == 0.0){
            goto LF; // [279] 339
        }
    }

    /** 				s = repeat(0, len)*/
    DeRef(_s_24216);
    _s_24216 = Repeat(0, _len_24213);

    /** 				for i = 1 to len do*/
    Ref(_len_24213);
    DeRef(_13414);
    _13414 = _len_24213;
    {
        int _i_24272;
        _i_24272 = 1;
L10: 
        if (binary_op_a(GREATER, _i_24272, _13414)){
            goto L11; // [293] 330
        }

        /** 					s[i] = float64_to_atom(peek({tmp, 8}))*/
        Ref(_tmp_24214);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_24214;
        ((int *)_2)[2] = 8;
        _13415 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_13415);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13416 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_13415);
        _13415 = NOVALUE;
        _13417 = _59float64_to_atom(_13416);
        _13416 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_24216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_24216 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_24272))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_24272)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_24272);
        _1 = *(int *)_2;
        *(int *)_2 = _13417;
        if( _1 != _13417 ){
            DeRef(_1);
        }
        _13417 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_24214;
        if (IS_ATOM_INT(_tmp_24214)) {
            _tmp_24214 = _tmp_24214 + 8;
            if ((long)((unsigned long)_tmp_24214 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_24214 = NewDouble((double)_tmp_24214);
        }
        else {
            _tmp_24214 = NewDouble(DBL_PTR(_tmp_24214)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_24272;
        if (IS_ATOM_INT(_i_24272)) {
            _i_24272 = _i_24272 + 1;
            if ((long)((unsigned long)_i_24272 +(unsigned long) HIGH_BITS) >= 0){
                _i_24272 = NewDouble((double)_i_24272);
            }
        }
        else {
            _i_24272 = binary_op_a(PLUS, _i_24272, 1);
        }
        DeRef(_0);
        goto L10; // [325] 300
L11: 
        ;
        DeRef(_i_24272);
    }

    /** 				return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto L12; // [336] 359
LF: 

    /** 				tmp = float64_to_atom(peek({tmp, 8}))*/
    Ref(_tmp_24214);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_24214;
    ((int *)_2)[2] = 8;
    _13419 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_13419);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _13420 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13419);
    _13419 = NOVALUE;
    _0 = _tmp_24214;
    _tmp_24214 = _59float64_to_atom(_13420);
    DeRef(_0);
    _13420 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_val_24215);
    DeRef(_s_24216);
    return _tmp_24214;
L12: 
LE: 

    /** 		s = peek({tmp, len})*/
    Ref(_len_24213);
    Ref(_tmp_24214);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_24214;
    ((int *)_2)[2] = _len_24213;
    _13422 = MAKE_SEQ(_1);
    DeRef(_s_24216);
    _1 = (int)SEQ_PTR(_13422);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_24216 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13422);
    _13422 = NOVALUE;

    /** 		return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto L13; // [377] 476
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_24213, 0)){
        goto L14; // [382] 469
    }

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_24212)) {
        _13425 = _ma_24212 + 4;
        if ((long)((unsigned long)_13425 + (unsigned long)HIGH_BITS) >= 0) 
        _13425 = NewDouble((double)_13425);
    }
    else {
        _13425 = NewDouble(DBL_PTR(_ma_24212)->dbl + (double)4);
    }
    DeRef(_tmp_24214);
    if (IS_ATOM_INT(_13425)) {
        _tmp_24214 = *(unsigned long *)_13425;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13425)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_13425);
    _13425 = NOVALUE;

    /** 		tmp = peek4u(tmp)*/
    _0 = _tmp_24214;
    if (IS_ATOM_INT(_tmp_24214)) {
        _tmp_24214 = *(unsigned long *)_tmp_24214;
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    else {
        _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_tmp_24214)->dbl);
        if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
        _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
    }
    DeRef(_0);

    /** 		s = repeat(0, len)*/
    DeRef(_s_24216);
    _s_24216 = Repeat(0, _len_24213);

    /** 		s[1] = linked_list_to_sequence(tmp)*/
    Ref(_tmp_24214);
    DeRef(_13429);
    _13429 = _tmp_24214;
    _13430 = _58linked_list_to_sequence(_13429);
    _13429 = NOVALUE;
    _2 = (int)SEQ_PTR(_s_24216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_24216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _13430;
    if( _1 != _13430 ){
    }
    _13430 = NOVALUE;

    /** 		for i = 2 to length(s) do*/
    if (IS_SEQUENCE(_s_24216)){
            _13431 = SEQ_PTR(_s_24216)->length;
    }
    else {
        _13431 = 1;
    }
    {
        int _i_24295;
        _i_24295 = 2;
L15: 
        if (_i_24295 > _13431){
            goto L16; // [424] 460
        }

        /** 			tmp = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_24214)) {
            _13432 = _tmp_24214 + 12;
            if ((long)((unsigned long)_13432 + (unsigned long)HIGH_BITS) >= 0) 
            _13432 = NewDouble((double)_13432);
        }
        else {
            _13432 = NewDouble(DBL_PTR(_tmp_24214)->dbl + (double)12);
        }
        DeRef(_tmp_24214);
        if (IS_ATOM_INT(_13432)) {
            _tmp_24214 = *(unsigned long *)_13432;
            if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
            _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
        }
        else {
            _tmp_24214 = *(unsigned long *)(unsigned long)(DBL_PTR(_13432)->dbl);
            if ((unsigned)_tmp_24214 > (unsigned)MAXINT)
            _tmp_24214 = NewDouble((double)(unsigned long)_tmp_24214);
        }
        DeRef(_13432);
        _13432 = NOVALUE;

        /** 			s[i] = linked_list_to_sequence(tmp)*/
        Ref(_tmp_24214);
        DeRef(_13434);
        _13434 = _tmp_24214;
        _13435 = _58linked_list_to_sequence(_13434);
        _13434 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_24216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_24216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_24295);
        _1 = *(int *)_2;
        *(int *)_2 = _13435;
        if( _1 != _13435 ){
            DeRef(_1);
        }
        _13435 = NOVALUE;

        /** 		end for*/
        _i_24295 = _i_24295 + 1;
        goto L15; // [455] 431
L16: 
        ;
    }

    /** 		return s*/
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    return _s_24216;
    goto L13; // [466] 476
L14: 

    /** 		return {}*/
    RefDS(_5);
    DeRef(_ma_24212);
    DeRef(_len_24213);
    DeRef(_tmp_24214);
    DeRef(_val_24215);
    DeRef(_s_24216);
    return _5;
L13: 
    ;
}



// 0x5E5E9C56
