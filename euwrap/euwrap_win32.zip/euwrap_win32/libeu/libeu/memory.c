// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _16positive_int(int _x_1887)
{
    int _961 = NOVALUE;
    int _959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(x) then*/
    if (IS_ATOM_INT(_x_1887))
    _959 = 1;
    else if (IS_ATOM_DBL(_x_1887))
    _959 = IS_ATOM_INT(DoubleToInt(_x_1887));
    else
    _959 = 0;
    if (_959 != 0)
    goto L1; // [6] 16
    _959 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_1887);
    return 0;
L1: 

    /**     return x >= 1*/
    if (IS_ATOM_INT(_x_1887)) {
        _961 = (_x_1887 >= 1);
    }
    else {
        _961 = binary_op(GREATEREQ, _x_1887, 1);
    }
    DeRef(_x_1887);
    return _961;
    ;
}


int  __stdcall _16machine_addr(int _a_1894)
{
    int _970 = NOVALUE;
    int _969 = NOVALUE;
    int _968 = NOVALUE;
    int _966 = NOVALUE;
    int _964 = NOVALUE;
    int _962 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _962 = IS_ATOM(_a_1894);
    if (_962 != 0)
    goto L1; // [6] 16
    _962 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_1894);
    return 0;
L1: 

    /** 	if not integer(a)then*/
    if (IS_ATOM_INT(_a_1894))
    _964 = 1;
    else if (IS_ATOM_DBL(_a_1894))
    _964 = IS_ATOM_INT(DoubleToInt(_a_1894));
    else
    _964 = 0;
    if (_964 != 0)
    goto L2; // [21] 41
    _964 = NOVALUE;

    /** 		if floor(a) != a then*/
    if (IS_ATOM_INT(_a_1894))
    _966 = e_floor(_a_1894);
    else
    _966 = unary_op(FLOOR, _a_1894);
    if (binary_op_a(EQUALS, _966, _a_1894)){
        DeRef(_966);
        _966 = NOVALUE;
        goto L3; // [29] 40
    }
    DeRef(_966);
    _966 = NOVALUE;

    /** 			return 0*/
    DeRef(_a_1894);
    return 0;
L3: 
L2: 

    /** 	return a > 0 and a <= MAX_ADDR*/
    if (IS_ATOM_INT(_a_1894)) {
        _968 = (_a_1894 > 0);
    }
    else {
        _968 = binary_op(GREATER, _a_1894, 0);
    }
    if (IS_ATOM_INT(_a_1894) && IS_ATOM_INT(_16MAX_ADDR_1880)) {
        _969 = (_a_1894 <= _16MAX_ADDR_1880);
    }
    else {
        _969 = binary_op(LESSEQ, _a_1894, _16MAX_ADDR_1880);
    }
    if (IS_ATOM_INT(_968) && IS_ATOM_INT(_969)) {
        _970 = (_968 != 0 && _969 != 0);
    }
    else {
        _970 = binary_op(AND, _968, _969);
    }
    DeRef(_968);
    _968 = NOVALUE;
    DeRef(_969);
    _969 = NOVALUE;
    DeRef(_a_1894);
    return _970;
    ;
}


void  __stdcall _16deallocate(int _addr_1909)
{
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1909);

    /** end procedure*/
    DeRef(_addr_1909);
    return;
    ;
}


void  __stdcall _16register_block(int _block_addr_1916, int _block_len_1917, int _protection_1918)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_1918)) {
        _1 = (long)(DBL_PTR(_protection_1918)->dbl);
        DeRefDS(_protection_1918);
        _protection_1918 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void  __stdcall _16unregister_block(int _block_addr_1922)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int  __stdcall _16safe_address(int _start_1926, int _len_1927, int _action_1928)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_len_1927)) {
        _1 = (long)(DBL_PTR(_len_1927)->dbl);
        DeRefDS(_len_1927);
        _len_1927 = _1;
    }

    /** 	return 1*/
    return 1;
    ;
}


void  __stdcall _16check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int  __stdcall _16prepare_block(int _addr_1935, int _a_1936, int _protection_1937)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1936)) {
        _1 = (long)(DBL_PTR(_a_1936)->dbl);
        DeRefDS(_a_1936);
        _a_1936 = _1;
    }
    if (!IS_ATOM_INT(_protection_1937)) {
        _1 = (long)(DBL_PTR(_protection_1937)->dbl);
        DeRefDS(_protection_1937);
        _protection_1937 = _1;
    }

    /** 	return addr*/
    return _addr_1935;
    ;
}


int  __stdcall _16bordered_address(int _addr_1945)
{
    int _975 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(addr) then*/
    _975 = IS_ATOM(_addr_1945);
    if (_975 != 0)
    goto L1; // [6] 16
    _975 = NOVALUE;

    /** 		return 0*/
    DeRef(_addr_1945);
    return 0;
L1: 

    /** 	return 1*/
    DeRef(_addr_1945);
    return 1;
    ;
}


int  __stdcall _16dep_works()
{
    int _977 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return (DEP_really_works and use_DEP)*/
    _977 = (_15DEP_really_works_1853 != 0 && _15use_DEP_1854 != 0);
    return _977;

    /** 	return 1*/
    _977 = NOVALUE;
    return 1;
    ;
}


void  __stdcall _16free_code(int _addr_1957, int _size_1958, int _wordsize_1960)
{
    int _dep_works_inlined_dep_works_at_4_25234 = NOVALUE;
    int _981 = NOVALUE;
    int _980 = NOVALUE;
    int _979 = NOVALUE;
    int _978 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_1958)) {
        _1 = (long)(DBL_PTR(_size_1958)->dbl);
        DeRefDS(_size_1958);
        _size_1958 = _1;
    }

    /** 		if dep_works() then*/

    /** 	ifdef WINDOWS then*/

    /** 		return (DEP_really_works and use_DEP)*/
    _dep_works_inlined_dep_works_at_4_25234 = (_15DEP_really_works_1853 != 0 && _15use_DEP_1854 != 0);
    goto L1; // [17] 25

    /** 	return 1*/
    _dep_works_inlined_dep_works_at_4_25234 = 1;
L1: 
    DeRef(_978);
    _978 = _dep_works_inlined_dep_works_at_4_25234;
    if (_978 == 0)
    {
        _978 = NOVALUE;
        goto L2; // [28] 55
    }
    else{
        _978 = NOVALUE;
    }

    /** 			c_func(VirtualFree_rid, { addr, size*wordsize, MEM_RELEASE })*/
    if (IS_ATOM_INT(_wordsize_1960)) {
        if (_size_1958 == (short)_size_1958 && _wordsize_1960 <= INT15 && _wordsize_1960 >= -INT15)
        _979 = _size_1958 * _wordsize_1960;
        else
        _979 = NewDouble(_size_1958 * (double)_wordsize_1960);
    }
    else {
        _979 = binary_op(MULTIPLY, _size_1958, _wordsize_1960);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_1957);
    *((int *)(_2+4)) = _addr_1957;
    *((int *)(_2+8)) = _979;
    *((int *)(_2+12)) = 32768;
    _980 = MAKE_SEQ(_1);
    _979 = NOVALUE;
    _981 = call_c(1, _16VirtualFree_rid_1954, _980);
    DeRefDS(_980);
    _980 = NOVALUE;
    goto L3; // [52] 61
L2: 

    /** 			machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1957);
L3: 

    /** end procedure*/
    DeRef(_addr_1957);
    DeRef(_wordsize_1960);
    DeRef(_981);
    _981 = NOVALUE;
    return;
    ;
}



// 0x27AC66DD
