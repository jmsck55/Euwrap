// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(int _text_8704)
{
    int _4751 = NOVALUE;
    int _4749 = NOVALUE;
    int _4747 = NOVALUE;
    int _4746 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_8701) && IS_ATOM(_text_8704)) {
        Ref(_text_8704);
        Append(&_26pretty_line_8701, _26pretty_line_8701, _text_8704);
    }
    else if (IS_ATOM(_26pretty_line_8701) && IS_SEQUENCE(_text_8704)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_8701, _26pretty_line_8701, _text_8704);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_8704 == 10)
    _4746 = 1;
    else if (IS_ATOM_INT(_text_8704) && IS_ATOM_INT(10))
    _4746 = 0;
    else
    _4746 = (compare(_text_8704, 10) == 0);
    if (_4746 == 0) {
        goto L1; // [15] 50
    }
    if (_26pretty_printing_8698 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_8689, _26pretty_line_8701); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_8701);
    _26pretty_line_8701 = _5;

    /** 		pretty_line_count += 1*/
    _26pretty_line_count_8694 = _26pretty_line_count_8694 + 1;
L1: 

    /** 	if atom(text) then*/
    _4749 = IS_ATOM(_text_8704);
    if (_4749 == 0)
    {
        _4749 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4749 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _26pretty_chars_8686 = _26pretty_chars_8686 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_8704)){
            _4751 = SEQ_PTR(_text_8704)->length;
    }
    else {
        _4751 = 1;
    }
    _26pretty_chars_8686 = _26pretty_chars_8686 + _4751;
    _4751 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_8704);
    return;
    ;
}


void _26cut_line(int _n_8718)
{
    int _4754 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_8697 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _26pretty_chars_8686 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _4754 = _26pretty_chars_8686 + _n_8718;
    if ((long)((unsigned long)_4754 + (unsigned long)HIGH_BITS) >= 0) 
    _4754 = NewDouble((double)_4754);
    if (binary_op_a(LESSEQ, _4754, _26pretty_end_col_8685)){
        DeRef(_4754);
        _4754 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4754);
    _4754 = NOVALUE;

    /** 		pretty_out('\n')*/
    _26pretty_out(10);

    /** 		pretty_chars = 0*/
    _26pretty_chars_8686 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _26indent()
{
    int _4762 = NOVALUE;
    int _4761 = NOVALUE;
    int _4760 = NOVALUE;
    int _4759 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_8697 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _26pretty_chars_8686 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_8697 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _26cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_26pretty_chars_8686 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _26pretty_out(10);

    /** 			pretty_chars = 0*/
    _26pretty_chars_8686 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4759 = _26pretty_start_col_8687 - 1;
    if ((long)((unsigned long)_4759 +(unsigned long) HIGH_BITS) >= 0){
        _4759 = NewDouble((double)_4759);
    }
    if (_26pretty_level_8688 == (short)_26pretty_level_8688 && _26pretty_indent_8691 <= INT15 && _26pretty_indent_8691 >= -INT15)
    _4760 = _26pretty_level_8688 * _26pretty_indent_8691;
    else
    _4760 = NewDouble(_26pretty_level_8688 * (double)_26pretty_indent_8691);
    if (IS_ATOM_INT(_4759) && IS_ATOM_INT(_4760)) {
        _4761 = _4759 + _4760;
    }
    else {
        if (IS_ATOM_INT(_4759)) {
            _4761 = NewDouble((double)_4759 + DBL_PTR(_4760)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4760)) {
                _4761 = NewDouble(DBL_PTR(_4759)->dbl + (double)_4760);
            }
            else
            _4761 = NewDouble(DBL_PTR(_4759)->dbl + DBL_PTR(_4760)->dbl);
        }
    }
    DeRef(_4759);
    _4759 = NOVALUE;
    DeRef(_4760);
    _4760 = NOVALUE;
    _4762 = Repeat(32, _4761);
    DeRef(_4761);
    _4761 = NOVALUE;
    _26pretty_out(_4762);
    _4762 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _26esc_char(int _a_8739)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_8739)) {
        _1 = (long)(DBL_PTR(_a_8739)->dbl);
        DeRefDS(_a_8739);
        _a_8739 = _1;
    }

    /** 	switch a do*/
    _0 = _a_8739;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_4765);
        return _4765;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_4766);
        return _4766;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_4767);
        return _4767;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_911);
        return _911;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_4768);
        return _4768;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_8739;
    ;}L1: 
    ;
}


void _26rPrint(int _a_8754)
{
    int _sbuff_8755 = NOVALUE;
    int _multi_line_8756 = NOVALUE;
    int _all_ascii_8757 = NOVALUE;
    int _4824 = NOVALUE;
    int _4823 = NOVALUE;
    int _4822 = NOVALUE;
    int _4821 = NOVALUE;
    int _4817 = NOVALUE;
    int _4816 = NOVALUE;
    int _4815 = NOVALUE;
    int _4814 = NOVALUE;
    int _4812 = NOVALUE;
    int _4811 = NOVALUE;
    int _4809 = NOVALUE;
    int _4808 = NOVALUE;
    int _4806 = NOVALUE;
    int _4805 = NOVALUE;
    int _4804 = NOVALUE;
    int _4803 = NOVALUE;
    int _4802 = NOVALUE;
    int _4801 = NOVALUE;
    int _4800 = NOVALUE;
    int _4799 = NOVALUE;
    int _4798 = NOVALUE;
    int _4797 = NOVALUE;
    int _4796 = NOVALUE;
    int _4795 = NOVALUE;
    int _4794 = NOVALUE;
    int _4793 = NOVALUE;
    int _4792 = NOVALUE;
    int _4791 = NOVALUE;
    int _4790 = NOVALUE;
    int _4786 = NOVALUE;
    int _4785 = NOVALUE;
    int _4784 = NOVALUE;
    int _4783 = NOVALUE;
    int _4782 = NOVALUE;
    int _4781 = NOVALUE;
    int _4779 = NOVALUE;
    int _4778 = NOVALUE;
    int _4775 = NOVALUE;
    int _4774 = NOVALUE;
    int _4773 = NOVALUE;
    int _4770 = NOVALUE;
    int _4769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _4769 = IS_ATOM(_a_8754);
    if (_4769 == 0)
    {
        _4769 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4769 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_8754))
    _4770 = 1;
    else if (IS_ATOM_DBL(_a_8754))
    _4770 = IS_ATOM_INT(DoubleToInt(_a_8754));
    else
    _4770 = 0;
    if (_4770 == 0)
    {
        _4770 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4770 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_8755);
    _sbuff_8755 = EPrintf(-9999999, _26pretty_int_format_8700, _a_8754);

    /** 			if pretty_ascii then */
    if (_26pretty_ascii_8690 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_26pretty_ascii_8690 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_8754)) {
        _4773 = (_a_8754 >= _26pretty_ascii_min_8692);
    }
    else {
        _4773 = binary_op(GREATEREQ, _a_8754, _26pretty_ascii_min_8692);
    }
    if (IS_ATOM_INT(_4773)) {
        if (_4773 == 0) {
            _4774 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4773)->dbl == 0.0) {
            _4774 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_8754)) {
        _4775 = (_a_8754 <= _26pretty_ascii_max_8693);
    }
    else {
        _4775 = binary_op(LESSEQ, _a_8754, _26pretty_ascii_max_8693);
    }
    DeRef(_4774);
    if (IS_ATOM_INT(_4775))
    _4774 = (_4775 != 0);
    else
    _4774 = DBL_PTR(_4775)->dbl != 0.0;
L5: 
    if (_4774 == 0)
    {
        _4774 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4774 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_8754;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_8755, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _4778 = find_from(_a_8754, _4777, 1);
    if (_4778 == 0)
    {
        _4778 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4778 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_8754);
    _4779 = _26esc_char(_a_8754);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _4779;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_8755, concat_list, 3);
    }
    DeRef(_4779);
    _4779 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_8754)) {
        _4781 = (_a_8754 >= _26pretty_ascii_min_8692);
    }
    else {
        _4781 = binary_op(GREATEREQ, _a_8754, _26pretty_ascii_min_8692);
    }
    if (IS_ATOM_INT(_4781)) {
        if (_4781 == 0) {
            DeRef(_4782);
            _4782 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4781)->dbl == 0.0) {
            DeRef(_4782);
            _4782 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_8754)) {
        _4783 = (_a_8754 <= _26pretty_ascii_max_8693);
    }
    else {
        _4783 = binary_op(LESSEQ, _a_8754, _26pretty_ascii_max_8693);
    }
    DeRef(_4782);
    if (IS_ATOM_INT(_4783))
    _4782 = (_4783 != 0);
    else
    _4782 = DBL_PTR(_4783)->dbl != 0.0;
L7: 
    if (_4782 == 0) {
        goto L3; // [125] 166
    }
    _4785 = (_26pretty_ascii_8690 < 2);
    if (_4785 == 0)
    {
        DeRef(_4785);
        _4785 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4785);
        _4785 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_8754;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_4786, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_8755, _sbuff_8755, _4786);
    DeRefDS(_4786);
    _4786 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_8755);
    _sbuff_8755 = EPrintf(-9999999, _26pretty_fp_format_8699, _a_8754);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_8755);
    _26pretty_out(_sbuff_8755);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _26cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_8756 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_8757 = (_26pretty_ascii_8690 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_8754)){
            _4790 = SEQ_PTR(_a_8754)->length;
    }
    else {
        _4790 = 1;
    }
    {
        int _i_8790;
        _i_8790 = 1;
L9: 
        if (_i_8790 > _4790){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_8754);
        _4791 = (int)*(((s1_ptr)_2)->base + _i_8790);
        _4792 = IS_SEQUENCE(_4791);
        _4791 = NOVALUE;
        if (_4792 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_8754);
        _4794 = (int)*(((s1_ptr)_2)->base + _i_8790);
        if (IS_SEQUENCE(_4794)){
                _4795 = SEQ_PTR(_4794)->length;
        }
        else {
            _4795 = 1;
        }
        _4794 = NOVALUE;
        _4796 = (_4795 > 0);
        _4795 = NOVALUE;
        if (_4796 == 0)
        {
            DeRef(_4796);
            _4796 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4796);
            _4796 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_8756 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_8757 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_8754);
        _4797 = (int)*(((s1_ptr)_2)->base + _i_8790);
        if (IS_ATOM_INT(_4797))
        _4798 = 1;
        else if (IS_ATOM_DBL(_4797))
        _4798 = IS_ATOM_INT(DoubleToInt(_4797));
        else
        _4798 = 0;
        _4797 = NOVALUE;
        _4799 = (_4798 == 0);
        _4798 = NOVALUE;
        if (_4799 != 0) {
            _4800 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_8754);
        _4801 = (int)*(((s1_ptr)_2)->base + _i_8790);
        if (IS_ATOM_INT(_4801)) {
            _4802 = (_4801 < _26pretty_ascii_min_8692);
        }
        else {
            _4802 = binary_op(LESS, _4801, _26pretty_ascii_min_8692);
        }
        _4801 = NOVALUE;
        if (IS_ATOM_INT(_4802)) {
            if (_4802 == 0) {
                DeRef(_4803);
                _4803 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4802)->dbl == 0.0) {
                DeRef(_4803);
                _4803 = 0;
                goto LD; // [275] 309
            }
        }
        _4804 = (_26pretty_ascii_8690 < 2);
        if (_4804 != 0) {
            _4805 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_8754);
        _4806 = (int)*(((s1_ptr)_2)->base + _i_8790);
        _4808 = find_from(_4806, _4807, 1);
        _4806 = NOVALUE;
        _4809 = (_4808 == 0);
        _4808 = NOVALUE;
        _4805 = (_4809 != 0);
LE: 
        DeRef(_4803);
        _4803 = (_4805 != 0);
LD: 
        _4800 = (_4803 != 0);
LC: 
        if (_4800 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_8754);
        _4811 = (int)*(((s1_ptr)_2)->base + _i_8790);
        if (IS_ATOM_INT(_4811)) {
            _4812 = (_4811 > _26pretty_ascii_max_8693);
        }
        else {
            _4812 = binary_op(GREATER, _4811, _26pretty_ascii_max_8693);
        }
        _4811 = NOVALUE;
        if (_4812 == 0) {
            DeRef(_4812);
            _4812 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4812) && DBL_PTR(_4812)->dbl == 0.0){
                DeRef(_4812);
                _4812 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4812);
            _4812 = NOVALUE;
        }
        DeRef(_4812);
        _4812 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_8757 = 0;
L10: 

        /** 		end for*/
        _i_8790 = _i_8790 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_8757 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _26pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _26pretty_level_8688 = _26pretty_level_8688 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_8754)){
            _4814 = SEQ_PTR(_a_8754)->length;
    }
    else {
        _4814 = 1;
    }
    {
        int _i_8820;
        _i_8820 = 1;
L13: 
        if (_i_8820 > _4814){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_8756 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _26indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_8757 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_8754);
        _4815 = (int)*(((s1_ptr)_2)->base + _i_8820);
        Ref(_4815);
        _4816 = _26esc_char(_4815);
        _4815 = NOVALUE;
        _26pretty_out(_4816);
        _4816 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_8754);
        _4817 = (int)*(((s1_ptr)_2)->base + _i_8820);
        Ref(_4817);
        _26rPrint(_4817);
        _4817 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_8694 < _26pretty_line_max_8695)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_26pretty_dots_8696 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_4820);
        _26pretty_out(_4820);
L19: 

        /** 				pretty_dots = 1*/
        _26pretty_dots_8696 = 1;

        /** 				return*/
        DeRef(_a_8754);
        DeRef(_sbuff_8755);
        DeRef(_4773);
        _4773 = NOVALUE;
        DeRef(_4775);
        _4775 = NOVALUE;
        DeRef(_4781);
        _4781 = NOVALUE;
        DeRef(_4783);
        _4783 = NOVALUE;
        _4794 = NOVALUE;
        DeRef(_4799);
        _4799 = NOVALUE;
        DeRef(_4804);
        _4804 = NOVALUE;
        DeRef(_4802);
        _4802 = NOVALUE;
        DeRef(_4809);
        _4809 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_8754)){
                _4821 = SEQ_PTR(_a_8754)->length;
        }
        else {
            _4821 = 1;
        }
        _4822 = (_i_8820 != _4821);
        _4821 = NOVALUE;
        if (_4822 == 0) {
            goto L1A; // [468] 490
        }
        _4824 = (_all_ascii_8757 == 0);
        if (_4824 == 0)
        {
            DeRef(_4824);
            _4824 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4824);
            _4824 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _26pretty_out(44);

        /** 				cut_line(6)*/
        _26cut_line(6);
L1A: 

        /** 		end for*/
        _i_8820 = _i_8820 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _26pretty_level_8688 = _26pretty_level_8688 - 1;

    /** 		if multi_line then*/
    if (_multi_line_8756 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _26indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_8757 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _26pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_8754);
    DeRef(_sbuff_8755);
    DeRef(_4773);
    _4773 = NOVALUE;
    DeRef(_4775);
    _4775 = NOVALUE;
    DeRef(_4781);
    _4781 = NOVALUE;
    DeRef(_4783);
    _4783 = NOVALUE;
    _4794 = NOVALUE;
    DeRef(_4799);
    _4799 = NOVALUE;
    DeRef(_4804);
    _4804 = NOVALUE;
    DeRef(_4802);
    _4802 = NOVALUE;
    DeRef(_4809);
    _4809 = NOVALUE;
    DeRef(_4822);
    _4822 = NOVALUE;
    return;
    ;
}


void _26pretty(int _x_8859, int _options_8860)
{
    int _4836 = NOVALUE;
    int _4835 = NOVALUE;
    int _4834 = NOVALUE;
    int _4833 = NOVALUE;
    int _4831 = NOVALUE;
    int _4830 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_8860)){
            _4830 = SEQ_PTR(_options_8860)->length;
    }
    else {
        _4830 = 1;
    }
    _4831 = 10;
    if (_4830 >= 10)
    goto L1; // [13] 41

    /** 		options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_8860)){
            _4833 = SEQ_PTR(_options_8860)->length;
    }
    else {
        _4833 = 1;
    }
    _4834 = _4833 + 1;
    _4833 = NOVALUE;
    _4835 = 10;
    rhs_slice_target = (object_ptr)&_4836;
    RHS_Slice(_26PRETTY_DEFAULT_8845, _4834, 10);
    Concat((object_ptr)&_options_8860, _options_8860, _4836);
    DeRefDS(_4836);
    _4836 = NOVALUE;
L1: 

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_ascii_8690 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26pretty_ascii_8690))
    _26pretty_ascii_8690 = (long)DBL_PTR(_26pretty_ascii_8690)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_indent_8691 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26pretty_indent_8691))
    _26pretty_indent_8691 = (long)DBL_PTR(_26pretty_indent_8691)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_start_col_8687 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26pretty_start_col_8687))
    _26pretty_start_col_8687 = (long)DBL_PTR(_26pretty_start_col_8687)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_end_col_8685 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26pretty_end_col_8685))
    _26pretty_end_col_8685 = (long)DBL_PTR(_26pretty_end_col_8685)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_8700);
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_int_format_8700 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_26pretty_int_format_8700);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_8699);
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_fp_format_8699 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_26pretty_fp_format_8699);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_ascii_min_8692 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26pretty_ascii_min_8692))
    _26pretty_ascii_min_8692 = (long)DBL_PTR(_26pretty_ascii_min_8692)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_ascii_max_8693 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26pretty_ascii_max_8693))
    _26pretty_ascii_max_8693 = (long)DBL_PTR(_26pretty_ascii_max_8693)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_line_max_8695 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26pretty_line_max_8695))
    _26pretty_line_max_8695 = (long)DBL_PTR(_26pretty_line_max_8695)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_8860);
    _26pretty_line_breaks_8697 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_26pretty_line_breaks_8697))
    _26pretty_line_breaks_8697 = (long)DBL_PTR(_26pretty_line_breaks_8697)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _26pretty_chars_8686 = _26pretty_start_col_8687;

    /** 	pretty_level = 0 */
    _26pretty_level_8688 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_8701);
    _26pretty_line_8701 = _5;

    /** 	pretty_line_count = 0*/
    _26pretty_line_count_8694 = 0;

    /** 	pretty_dots = 0*/
    _26pretty_dots_8696 = 0;

    /** 	rPrint(x)*/
    Ref(_x_8859);
    _26rPrint(_x_8859);

    /** end procedure*/
    DeRef(_x_8859);
    DeRefDS(_options_8860);
    DeRef(_4834);
    _4834 = NOVALUE;
    return;
    ;
}


void  __stdcall _26pretty_print(int _fn_8882, int _x_8883, int _options_8884)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_8882)) {
        _1 = (long)(DBL_PTR(_fn_8882)->dbl);
        DeRefDS(_fn_8882);
        _fn_8882 = _1;
    }

    /** 	pretty_printing = 1*/
    _26pretty_printing_8698 = 1;

    /** 	pretty_file = fn*/
    _26pretty_file_8689 = _fn_8882;

    /** 	pretty( x, options )*/
    Ref(_x_8883);
    RefDS(_options_8884);
    _26pretty(_x_8883, _options_8884);

    /** 	puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_8689, _26pretty_line_8701); // DJP 

    /** end procedure*/
    DeRef(_x_8883);
    DeRefDS(_options_8884);
    return;
    ;
}


int  __stdcall _26pretty_sprint(int _x_8887, int _options_8888)
{
    int _0, _1, _2;
    

    /** 	pretty_printing = 0*/
    _26pretty_printing_8698 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_8887);
    RefDS(_options_8888);
    _26pretty(_x_8887, _options_8888);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8701);
    DeRef(_x_8887);
    DeRefDS(_options_8888);
    return _26pretty_line_8701;
    ;
}



// 0x6A7B5E51
