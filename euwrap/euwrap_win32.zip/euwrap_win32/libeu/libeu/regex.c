// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _47regex(int _o_21418)
{
    int _12102 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _12102 = IS_SEQUENCE(_o_21418);
    DeRef(_o_21418);
    return _12102;
    ;
}


int  __stdcall _47option_spec(int _o_21422)
{
    int _12109 = NOVALUE;
    int _12108 = NOVALUE;
    int _12106 = NOVALUE;
    int _12104 = NOVALUE;
    int _12103 = NOVALUE;
    int _0, _1, _2;
    
L1: 

    /** 	if atom(o) then*/
    _12103 = IS_ATOM(_o_21422);
    if (_12103 == 0)
    {
        _12103 = NOVALUE;
        goto L2; // [6] 60
    }
    else{
        _12103 = NOVALUE;
    }

    /** 		if not integer(o) then*/
    if (IS_ATOM_INT(_o_21422))
    _12104 = 1;
    else if (IS_ATOM_DBL(_o_21422))
    _12104 = IS_ATOM_INT(DoubleToInt(_o_21422));
    else
    _12104 = 0;
    if (_12104 != 0)
    goto L3; // [14] 26
    _12104 = NOVALUE;

    /** 			return 0*/
    DeRef(_o_21422);
    return 0;
    goto L4; // [23] 89
L3: 

    /** 			if (or_bits(o,all_options) != all_options) then*/
    if (IS_ATOM_INT(_o_21422) && IS_ATOM_INT(_47all_options_21413)) {
        {unsigned long tu;
             tu = (unsigned long)_o_21422 | (unsigned long)_47all_options_21413;
             _12106 = MAKE_UINT(tu);
        }
    }
    else {
        _12106 = binary_op(OR_BITS, _o_21422, _47all_options_21413);
    }
    if (binary_op_a(EQUALS, _12106, _47all_options_21413)){
        DeRef(_12106);
        _12106 = NOVALUE;
        goto L5; // [36] 49
    }
    DeRef(_12106);
    _12106 = NOVALUE;

    /** 				return 0*/
    DeRef(_o_21422);
    return 0;
    goto L4; // [46] 89
L5: 

    /** 				return 1*/
    DeRef(_o_21422);
    return 1;
    goto L4; // [57] 89
L2: 

    /** 	elsif integer_array(o) then*/
    Ref(_o_21422);
    _12108 = _7integer_array(_o_21422);
    if (_12108 == 0) {
        DeRef(_12108);
        _12108 = NOVALUE;
        goto L6; // [66] 82
    }
    else {
        if (!IS_ATOM_INT(_12108) && DBL_PTR(_12108)->dbl == 0.0){
            DeRef(_12108);
            _12108 = NOVALUE;
            goto L6; // [66] 82
        }
        DeRef(_12108);
        _12108 = NOVALUE;
    }
    DeRef(_12108);
    _12108 = NOVALUE;

    /** 		return option_spec( math:or_all(o) )*/
    Ref(_o_21422);
    _12109 = _20or_all(_o_21422);
    _0 = _o_21422;
    _o_21422 = _12109;
    Ref(_o_21422);
    DeRef(_0);
    DeRef(_12109);
    _12109 = NOVALUE;
    goto L1; // [75] 1
    goto L4; // [79] 89
L6: 

    /** 		return 0*/
    DeRef(_o_21422);
    return 0;
L4: 
    ;
}


int  __stdcall _47option_spec_to_string(int _o_21441)
{
    int _12111 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return flags:flags_to_string(o, option_names)*/
    Ref(_o_21441);
    RefDS(_47option_names_21264);
    _12111 = _39flags_to_string(_o_21441, _47option_names_21264, 0);
    DeRef(_o_21441);
    return _12111;
    ;
}


int  __stdcall _47error_to_string(int _i_21445)
{
    int _12118 = NOVALUE;
    int _12116 = NOVALUE;
    int _12115 = NOVALUE;
    int _12114 = NOVALUE;
    int _12112 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_21445)) {
        _1 = (long)(DBL_PTR(_i_21445)->dbl);
        DeRefDS(_i_21445);
        _i_21445 = _1;
    }

    /** 	if i >= 0 or i < -23 then*/
    _12112 = (_i_21445 >= 0);
    if (_12112 != 0) {
        goto L1; // [9] 22
    }
    _12114 = (_i_21445 < -23);
    if (_12114 == 0)
    {
        DeRef(_12114);
        _12114 = NOVALUE;
        goto L2; // [18] 39
    }
    else{
        DeRef(_12114);
        _12114 = NOVALUE;
    }
L1: 

    /** 		return sprintf("%d",{i})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _i_21445;
    _12115 = MAKE_SEQ(_1);
    _12116 = EPrintf(-9999999, _11715, _12115);
    DeRefDS(_12115);
    _12115 = NOVALUE;
    DeRef(_12112);
    _12112 = NOVALUE;
    return _12116;
    goto L3; // [36] 56
L2: 

    /** 		return search:vlookup(i, error_names, 1, 2, "Unknown Error")*/
    RefDS(_47error_names_21364);
    RefDS(_12117);
    _12118 = _9vlookup(_i_21445, _47error_names_21364, 1, 2, _12117);
    DeRef(_12112);
    _12112 = NOVALUE;
    DeRef(_12116);
    _12116 = NOVALUE;
    return _12118;
L3: 
    ;
}


int  __stdcall _47new(int _pattern_21458, int _options_21459)
{
    int _12122 = NOVALUE;
    int _12121 = NOVALUE;
    int _12119 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12119 = IS_SEQUENCE(_options_21459);
    if (_12119 == 0)
    {
        _12119 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12119 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21459);
    _0 = _options_21459;
    _options_21459 = _20or_all(_options_21459);
    DeRef(_0);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21459);
    Ref(_pattern_21458);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21458;
    ((int *)_2)[2] = _options_21459;
    _12121 = MAKE_SEQ(_1);
    _12122 = machine(68, _12121);
    DeRefDS(_12121);
    _12121 = NOVALUE;
    DeRef(_pattern_21458);
    DeRef(_options_21459);
    return _12122;
    ;
}


int  __stdcall _47error_message(int _re_21467)
{
    int _12124 = NOVALUE;
    int _12123 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_PCRE_ERROR_MESSAGE, { re })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21467);
    *((int *)(_2+4)) = _re_21467;
    _12123 = MAKE_SEQ(_1);
    _12124 = machine(95, _12123);
    DeRefDS(_12123);
    _12123 = NOVALUE;
    DeRef(_re_21467);
    return _12124;
    ;
}


int  __stdcall _47escape(int _s_21473)
{
    int _12126 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:escape(s, ".\\+*?[^]$(){}=!<>|:-")*/
    Ref(_s_21473);
    RefDS(_12125);
    _12126 = _6escape(_s_21473, _12125);
    DeRef(_s_21473);
    return _12126;
    ;
}


int  __stdcall _47get_ovector_size(int _ex_21478, int _maxsize_21479)
{
    int _m_21480 = NOVALUE;
    int _12130 = NOVALUE;
    int _12127 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_maxsize_21479)) {
        _1 = (long)(DBL_PTR(_maxsize_21479)->dbl);
        DeRefDS(_maxsize_21479);
        _maxsize_21479 = _1;
    }

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21478);
    *((int *)(_2+4)) = _ex_21478;
    _12127 = MAKE_SEQ(_1);
    _m_21480 = machine(97, _12127);
    DeRefDS(_12127);
    _12127 = NOVALUE;
    if (!IS_ATOM_INT(_m_21480)) {
        _1 = (long)(DBL_PTR(_m_21480)->dbl);
        DeRefDS(_m_21480);
        _m_21480 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21480 <= _maxsize_21479)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21478);
    return _maxsize_21479;
L1: 

    /** 	return m+1*/
    _12130 = _m_21480 + 1;
    if (_12130 > MAXINT){
        _12130 = NewDouble((double)_12130);
    }
    DeRef(_ex_21478);
    return _12130;
    ;
}


int  __stdcall _47find(int _re_21488, int _haystack_21490, int _from_21491, int _options_21492, int _size_21493)
{
    int _12137 = NOVALUE;
    int _12136 = NOVALUE;
    int _12135 = NOVALUE;
    int _12132 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21491)) {
        _1 = (long)(DBL_PTR(_from_21491)->dbl);
        DeRefDS(_from_21491);
        _from_21491 = _1;
    }
    if (!IS_ATOM_INT(_size_21493)) {
        _1 = (long)(DBL_PTR(_size_21493)->dbl);
        DeRefDS(_size_21493);
        _size_21493 = _1;
    }

    /** 	if sequence(options) then */
    _12132 = IS_SEQUENCE(_options_21492);
    if (_12132 == 0)
    {
        _12132 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12132 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21492);
    _0 = _options_21492;
    _options_21492 = _20or_all(_options_21492);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21493 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21493 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21490)){
            _12135 = SEQ_PTR(_haystack_21490)->length;
    }
    else {
        _12135 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21488);
    *((int *)(_2+4)) = _re_21488;
    Ref(_haystack_21490);
    *((int *)(_2+8)) = _haystack_21490;
    *((int *)(_2+12)) = _12135;
    Ref(_options_21492);
    *((int *)(_2+16)) = _options_21492;
    *((int *)(_2+20)) = _from_21491;
    *((int *)(_2+24)) = _size_21493;
    _12136 = MAKE_SEQ(_1);
    _12135 = NOVALUE;
    _12137 = machine(70, _12136);
    DeRefDS(_12136);
    _12136 = NOVALUE;
    DeRef(_re_21488);
    DeRef(_haystack_21490);
    DeRef(_options_21492);
    return _12137;
    ;
}


int  __stdcall _47find_all(int _re_21505, int _haystack_21507, int _from_21508, int _options_21509, int _size_21510)
{
    int _result_21517 = NOVALUE;
    int _results_21518 = NOVALUE;
    int _pHaystack_21519 = NOVALUE;
    int _12150 = NOVALUE;
    int _12149 = NOVALUE;
    int _12147 = NOVALUE;
    int _12145 = NOVALUE;
    int _12143 = NOVALUE;
    int _12139 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21508)) {
        _1 = (long)(DBL_PTR(_from_21508)->dbl);
        DeRefDS(_from_21508);
        _from_21508 = _1;
    }
    if (!IS_ATOM_INT(_size_21510)) {
        _1 = (long)(DBL_PTR(_size_21510)->dbl);
        DeRefDS(_size_21510);
        _size_21510 = _1;
    }

    /** 	if sequence(options) then */
    _12139 = IS_SEQUENCE(_options_21509);
    if (_12139 == 0)
    {
        _12139 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12139 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21509);
    _0 = _options_21509;
    _options_21509 = _20or_all(_options_21509);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21510 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21510 = 0;
L2: 

    /** 	object result*/

    /** 	sequence results = {}*/
    RefDS(_5);
    DeRef(_results_21518);
    _results_21518 = _5;

    /** 	atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_21507);
    _0 = _pHaystack_21519;
    _pHaystack_21519 = _14allocate_string(_haystack_21507, 0);
    DeRef(_0);

    /** 	while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12143 = IS_SEQUENCE(_result_21517);
    if (_12143 == 0)
    {
        _12143 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12143 = NOVALUE;
    }

    /** 		results = append(results, result)*/
    Ref(_result_21517);
    Append(&_results_21518, _results_21518, _result_21517);

    /** 		from = math:max(result) + 1*/
    Ref(_result_21517);
    _12145 = _20max(_result_21517);
    if (IS_ATOM_INT(_12145)) {
        _from_21508 = _12145 + 1;
    }
    else
    { // coercing _from_21508 to an integer 1
        _from_21508 = 1+(long)(DBL_PTR(_12145)->dbl);
        if( !IS_ATOM_INT(_from_21508) ){
            _from_21508 = (object)DBL_PTR(_from_21508)->dbl;
        }
    }
    DeRef(_12145);
    _12145 = NOVALUE;

    /** 		if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_21507)){
            _12147 = SEQ_PTR(_haystack_21507)->length;
    }
    else {
        _12147 = 1;
    }
    if (_from_21508 <= _12147)
    goto L6; // [82] 91

    /** 			exit*/
    goto L5; // [88] 117
L6: 

    /** 	entry*/
L3: 

    /** 		result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21507)){
            _12149 = SEQ_PTR(_haystack_21507)->length;
    }
    else {
        _12149 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21505);
    *((int *)(_2+4)) = _re_21505;
    Ref(_pHaystack_21519);
    *((int *)(_2+8)) = _pHaystack_21519;
    *((int *)(_2+12)) = _12149;
    Ref(_options_21509);
    *((int *)(_2+16)) = _options_21509;
    *((int *)(_2+20)) = _from_21508;
    *((int *)(_2+24)) = _size_21510;
    _12150 = MAKE_SEQ(_1);
    _12149 = NOVALUE;
    DeRef(_result_21517);
    _result_21517 = machine(70, _12150);
    DeRefDS(_12150);
    _12150 = NOVALUE;

    /** 	end while*/
    goto L4; // [114] 53
L5: 

    /** 	machine:free(pHaystack)*/
    Ref(_pHaystack_21519);
    _14free(_pHaystack_21519);

    /** 	return results*/
    DeRef(_re_21505);
    DeRef(_haystack_21507);
    DeRef(_options_21509);
    DeRef(_result_21517);
    DeRef(_pHaystack_21519);
    return _results_21518;
    ;
}


int  __stdcall _47has_match(int _re_21534, int _haystack_21536, int _from_21537, int _options_21538)
{
    int _12154 = NOVALUE;
    int _12153 = NOVALUE;
    int _12152 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21537)) {
        _1 = (long)(DBL_PTR(_from_21537)->dbl);
        DeRefDS(_from_21537);
        _from_21537 = _1;
    }

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21534);
    _12152 = _47get_ovector_size(_re_21534, 30);
    Ref(_re_21534);
    Ref(_haystack_21536);
    Ref(_options_21538);
    _12153 = _47find(_re_21534, _haystack_21536, _from_21537, _options_21538, _12152);
    _12152 = NOVALUE;
    _12154 = IS_SEQUENCE(_12153);
    DeRef(_12153);
    _12153 = NOVALUE;
    DeRef(_re_21534);
    DeRef(_haystack_21536);
    DeRef(_options_21538);
    return _12154;
    ;
}


int  __stdcall _47is_match(int _re_21544, int _haystack_21546, int _from_21547, int _options_21548)
{
    int _m_21549 = NOVALUE;
    int _12169 = NOVALUE;
    int _12168 = NOVALUE;
    int _12167 = NOVALUE;
    int _12166 = NOVALUE;
    int _12165 = NOVALUE;
    int _12164 = NOVALUE;
    int _12163 = NOVALUE;
    int _12162 = NOVALUE;
    int _12161 = NOVALUE;
    int _12160 = NOVALUE;
    int _12159 = NOVALUE;
    int _12158 = NOVALUE;
    int _12157 = NOVALUE;
    int _12155 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21547)) {
        _1 = (long)(DBL_PTR(_from_21547)->dbl);
        DeRefDS(_from_21547);
        _from_21547 = _1;
    }

    /** 	object m = find(re, haystack, from, options)*/
    Ref(_re_21544);
    _12155 = _47get_ovector_size(_re_21544, 30);
    Ref(_re_21544);
    Ref(_haystack_21546);
    Ref(_options_21548);
    _0 = _m_21549;
    _m_21549 = _47find(_re_21544, _haystack_21546, _from_21547, _options_21548, _12155);
    DeRef(_0);
    _12155 = NOVALUE;

    /** 	if sequence(m) and length(m) > 0 and m[1][1] = from and m[1][2] = length(haystack) then*/
    _12157 = IS_SEQUENCE(_m_21549);
    if (_12157 == 0) {
        _12158 = 0;
        goto L1; // [23] 38
    }
    if (IS_SEQUENCE(_m_21549)){
            _12159 = SEQ_PTR(_m_21549)->length;
    }
    else {
        _12159 = 1;
    }
    _12160 = (_12159 > 0);
    _12159 = NOVALUE;
    _12158 = (_12160 != 0);
L1: 
    if (_12158 == 0) {
        _12161 = 0;
        goto L2; // [38] 58
    }
    _2 = (int)SEQ_PTR(_m_21549);
    _12162 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_12162);
    _12163 = (int)*(((s1_ptr)_2)->base + 1);
    _12162 = NOVALUE;
    if (IS_ATOM_INT(_12163)) {
        _12164 = (_12163 == _from_21547);
    }
    else {
        _12164 = binary_op(EQUALS, _12163, _from_21547);
    }
    _12163 = NOVALUE;
    if (IS_ATOM_INT(_12164))
    _12161 = (_12164 != 0);
    else
    _12161 = DBL_PTR(_12164)->dbl != 0.0;
L2: 
    if (_12161 == 0) {
        goto L3; // [58] 88
    }
    _2 = (int)SEQ_PTR(_m_21549);
    _12166 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_12166);
    _12167 = (int)*(((s1_ptr)_2)->base + 2);
    _12166 = NOVALUE;
    if (IS_SEQUENCE(_haystack_21546)){
            _12168 = SEQ_PTR(_haystack_21546)->length;
    }
    else {
        _12168 = 1;
    }
    if (IS_ATOM_INT(_12167)) {
        _12169 = (_12167 == _12168);
    }
    else {
        _12169 = binary_op(EQUALS, _12167, _12168);
    }
    _12167 = NOVALUE;
    _12168 = NOVALUE;
    if (_12169 == 0) {
        DeRef(_12169);
        _12169 = NOVALUE;
        goto L3; // [78] 88
    }
    else {
        if (!IS_ATOM_INT(_12169) && DBL_PTR(_12169)->dbl == 0.0){
            DeRef(_12169);
            _12169 = NOVALUE;
            goto L3; // [78] 88
        }
        DeRef(_12169);
        _12169 = NOVALUE;
    }
    DeRef(_12169);
    _12169 = NOVALUE;

    /** 		return 1*/
    DeRef(_re_21544);
    DeRef(_haystack_21546);
    DeRef(_options_21548);
    DeRef(_m_21549);
    DeRef(_12160);
    _12160 = NOVALUE;
    DeRef(_12164);
    _12164 = NOVALUE;
    return 1;
L3: 

    /** 	return 0*/
    DeRef(_re_21544);
    DeRef(_haystack_21546);
    DeRef(_options_21548);
    DeRef(_m_21549);
    DeRef(_12160);
    _12160 = NOVALUE;
    DeRef(_12164);
    _12164 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _47matches(int _re_21568, int _haystack_21570, int _from_21571, int _options_21572)
{
    int _str_offsets_21576 = NOVALUE;
    int _match_data_21578 = NOVALUE;
    int _tmp_21588 = NOVALUE;
    int _12191 = NOVALUE;
    int _12190 = NOVALUE;
    int _12189 = NOVALUE;
    int _12188 = NOVALUE;
    int _12187 = NOVALUE;
    int _12185 = NOVALUE;
    int _12184 = NOVALUE;
    int _12183 = NOVALUE;
    int _12182 = NOVALUE;
    int _12180 = NOVALUE;
    int _12179 = NOVALUE;
    int _12178 = NOVALUE;
    int _12177 = NOVALUE;
    int _12175 = NOVALUE;
    int _12174 = NOVALUE;
    int _12173 = NOVALUE;
    int _12170 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21571)) {
        _1 = (long)(DBL_PTR(_from_21571)->dbl);
        DeRefDS(_from_21571);
        _from_21571 = _1;
    }

    /** 	if sequence(options) then */
    _12170 = IS_SEQUENCE(_options_21572);
    if (_12170 == 0)
    {
        _12170 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12170 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21572);
    _0 = _options_21572;
    _options_21572 = _20or_all(_options_21572);
    DeRef(_0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21572)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21572;
             _str_offsets_21576 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21576 = binary_op(AND_BITS, 201326592, _options_21572);
    }
    if (!IS_ATOM_INT(_str_offsets_21576)) {
        _1 = (long)(DBL_PTR(_str_offsets_21576)->dbl);
        DeRefDS(_str_offsets_21576);
        _str_offsets_21576 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12173 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21572) && IS_ATOM_INT(_12173)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21572 & (unsigned long)_12173;
             _12174 = MAKE_UINT(tu);
        }
    }
    else {
        _12174 = binary_op(AND_BITS, _options_21572, _12173);
    }
    DeRef(_12173);
    _12173 = NOVALUE;
    Ref(_re_21568);
    _12175 = _47get_ovector_size(_re_21568, 30);
    Ref(_re_21568);
    Ref(_haystack_21570);
    _0 = _match_data_21578;
    _match_data_21578 = _47find(_re_21568, _haystack_21570, _from_21571, _12174, _12175);
    DeRef(_0);
    _12174 = NOVALUE;
    _12175 = NOVALUE;

    /** 	if atom(match_data) then */
    _12177 = IS_ATOM(_match_data_21578);
    if (_12177 == 0)
    {
        _12177 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12177 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21568);
    DeRef(_haystack_21570);
    DeRef(_options_21572);
    DeRef(_match_data_21578);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21578)){
            _12178 = SEQ_PTR(_match_data_21578)->length;
    }
    else {
        _12178 = 1;
    }
    {
        int _i_21586;
        _i_21586 = 1;
L3: 
        if (_i_21586 > _12178){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21578);
        _12179 = (int)*(((s1_ptr)_2)->base + _i_21586);
        _2 = (int)SEQ_PTR(_12179);
        _12180 = (int)*(((s1_ptr)_2)->base + 1);
        _12179 = NOVALUE;
        if (binary_op_a(NOTEQ, _12180, 0)){
            _12180 = NOVALUE;
            goto L5; // [87] 101
        }
        _12180 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21588);
        _tmp_21588 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21578);
        _12182 = (int)*(((s1_ptr)_2)->base + _i_21586);
        _2 = (int)SEQ_PTR(_12182);
        _12183 = (int)*(((s1_ptr)_2)->base + 1);
        _12182 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21578);
        _12184 = (int)*(((s1_ptr)_2)->base + _i_21586);
        _2 = (int)SEQ_PTR(_12184);
        _12185 = (int)*(((s1_ptr)_2)->base + 2);
        _12184 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21588;
        RHS_Slice(_haystack_21570, _12183, _12185);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21576 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21578);
        _12187 = (int)*(((s1_ptr)_2)->base + _i_21586);
        _2 = (int)SEQ_PTR(_12187);
        _12188 = (int)*(((s1_ptr)_2)->base + 1);
        _12187 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21578);
        _12189 = (int)*(((s1_ptr)_2)->base + _i_21586);
        _2 = (int)SEQ_PTR(_12189);
        _12190 = (int)*(((s1_ptr)_2)->base + 2);
        _12189 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21588);
        *((int *)(_2+4)) = _tmp_21588;
        Ref(_12188);
        *((int *)(_2+8)) = _12188;
        Ref(_12190);
        *((int *)(_2+12)) = _12190;
        _12191 = MAKE_SEQ(_1);
        _12190 = NOVALUE;
        _12188 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21578);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21578 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21586);
        _1 = *(int *)_2;
        *(int *)_2 = _12191;
        if( _1 != _12191 ){
            DeRef(_1);
        }
        _12191 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21588);
        _2 = (int)SEQ_PTR(_match_data_21578);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21578 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21586);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21588;
        DeRef(_1);
L8: 
        DeRef(_tmp_21588);
        _tmp_21588 = NOVALUE;

        /** 	end for*/
        _i_21586 = _i_21586 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21568);
    DeRef(_haystack_21570);
    DeRef(_options_21572);
    _12183 = NOVALUE;
    _12185 = NOVALUE;
    return _match_data_21578;
    ;
}


int  __stdcall _47all_matches(int _re_21608, int _haystack_21610, int _from_21611, int _options_21612)
{
    int _str_offsets_21616 = NOVALUE;
    int _match_data_21618 = NOVALUE;
    int _tmp_21633 = NOVALUE;
    int _a_21634 = NOVALUE;
    int _b_21635 = NOVALUE;
    int _12215 = NOVALUE;
    int _12214 = NOVALUE;
    int _12212 = NOVALUE;
    int _12209 = NOVALUE;
    int _12208 = NOVALUE;
    int _12205 = NOVALUE;
    int _12204 = NOVALUE;
    int _12203 = NOVALUE;
    int _12202 = NOVALUE;
    int _12201 = NOVALUE;
    int _12199 = NOVALUE;
    int _12197 = NOVALUE;
    int _12196 = NOVALUE;
    int _12195 = NOVALUE;
    int _12192 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_from_21611)) {
        _1 = (long)(DBL_PTR(_from_21611)->dbl);
        DeRefDS(_from_21611);
        _from_21611 = _1;
    }

    /** 	if sequence(options) then */
    _12192 = IS_SEQUENCE(_options_21612);
    if (_12192 == 0)
    {
        _12192 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12192 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21612);
    _0 = _options_21612;
    _options_21612 = _20or_all(_options_21612);
    DeRef(_0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21612)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21612;
             _str_offsets_21616 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21616 = binary_op(AND_BITS, 201326592, _options_21612);
    }
    if (!IS_ATOM_INT(_str_offsets_21616)) {
        _1 = (long)(DBL_PTR(_str_offsets_21616)->dbl);
        DeRefDS(_str_offsets_21616);
        _str_offsets_21616 = _1;
    }

    /** 	object match_data = find_all(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12195 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21612) && IS_ATOM_INT(_12195)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21612 & (unsigned long)_12195;
             _12196 = MAKE_UINT(tu);
        }
    }
    else {
        _12196 = binary_op(AND_BITS, _options_21612, _12195);
    }
    DeRef(_12195);
    _12195 = NOVALUE;
    Ref(_re_21608);
    _12197 = _47get_ovector_size(_re_21608, 30);
    Ref(_re_21608);
    Ref(_haystack_21610);
    _0 = _match_data_21618;
    _match_data_21618 = _47find_all(_re_21608, _haystack_21610, _from_21611, _12196, _12197);
    DeRef(_0);
    _12196 = NOVALUE;
    _12197 = NOVALUE;

    /** 	if length(match_data) = 0 then */
    if (IS_SEQUENCE(_match_data_21618)){
            _12199 = SEQ_PTR(_match_data_21618)->length;
    }
    else {
        _12199 = 1;
    }
    if (_12199 != 0)
    goto L2; // [53] 64

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21608);
    DeRef(_haystack_21610);
    DeRef(_options_21612);
    DeRef(_match_data_21618);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21618)){
            _12201 = SEQ_PTR(_match_data_21618)->length;
    }
    else {
        _12201 = 1;
    }
    {
        int _i_21627;
        _i_21627 = 1;
L3: 
        if (_i_21627 > _12201){
            goto L4; // [69] 211
        }

        /** 		for j = 1 to length(match_data[i]) do*/
        _2 = (int)SEQ_PTR(_match_data_21618);
        _12202 = (int)*(((s1_ptr)_2)->base + _i_21627);
        if (IS_SEQUENCE(_12202)){
                _12203 = SEQ_PTR(_12202)->length;
        }
        else {
            _12203 = 1;
        }
        _12202 = NOVALUE;
        {
            int _j_21630;
            _j_21630 = 1;
L5: 
            if (_j_21630 > _12203){
                goto L6; // [85] 204
            }

            /** 			sequence tmp*/

            /** 			integer a,b*/

            /** 			a = match_data[i][j][1]*/
            _2 = (int)SEQ_PTR(_match_data_21618);
            _12204 = (int)*(((s1_ptr)_2)->base + _i_21627);
            _2 = (int)SEQ_PTR(_12204);
            _12205 = (int)*(((s1_ptr)_2)->base + _j_21630);
            _12204 = NOVALUE;
            _2 = (int)SEQ_PTR(_12205);
            _a_21634 = (int)*(((s1_ptr)_2)->base + 1);
            if (!IS_ATOM_INT(_a_21634)){
                _a_21634 = (long)DBL_PTR(_a_21634)->dbl;
            }
            _12205 = NOVALUE;

            /** 			if a = 0 then*/
            if (_a_21634 != 0)
            goto L7; // [114] 128

            /** 				tmp = ""*/
            RefDS(_5);
            DeRef(_tmp_21633);
            _tmp_21633 = _5;
            goto L8; // [125] 152
L7: 

            /** 				b = match_data[i][j][2]*/
            _2 = (int)SEQ_PTR(_match_data_21618);
            _12208 = (int)*(((s1_ptr)_2)->base + _i_21627);
            _2 = (int)SEQ_PTR(_12208);
            _12209 = (int)*(((s1_ptr)_2)->base + _j_21630);
            _12208 = NOVALUE;
            _2 = (int)SEQ_PTR(_12209);
            _b_21635 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_b_21635)){
                _b_21635 = (long)DBL_PTR(_b_21635)->dbl;
            }
            _12209 = NOVALUE;

            /** 				tmp = haystack[a..b]*/
            rhs_slice_target = (object_ptr)&_tmp_21633;
            RHS_Slice(_haystack_21610, _a_21634, _b_21635);
L8: 

            /** 			if str_offsets then*/
            if (_str_offsets_21616 == 0)
            {
                goto L9; // [154] 181
            }
            else{
            }

            /** 				match_data[i][j] = { tmp, a, b }*/
            _2 = (int)SEQ_PTR(_match_data_21618);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _match_data_21618 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_21627 + ((s1_ptr)_2)->base);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_tmp_21633);
            *((int *)(_2+4)) = _tmp_21633;
            *((int *)(_2+8)) = _a_21634;
            *((int *)(_2+12)) = _b_21635;
            _12214 = MAKE_SEQ(_1);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21630);
            _1 = *(int *)_2;
            *(int *)_2 = _12214;
            if( _1 != _12214 ){
                DeRef(_1);
            }
            _12214 = NOVALUE;
            _12212 = NOVALUE;
            goto LA; // [178] 195
L9: 

            /** 				match_data[i][j] = tmp*/
            _2 = (int)SEQ_PTR(_match_data_21618);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _match_data_21618 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_21627 + ((s1_ptr)_2)->base);
            RefDS(_tmp_21633);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21630);
            _1 = *(int *)_2;
            *(int *)_2 = _tmp_21633;
            DeRef(_1);
            _12215 = NOVALUE;
LA: 
            DeRef(_tmp_21633);
            _tmp_21633 = NOVALUE;

            /** 		end for*/
            _j_21630 = _j_21630 + 1;
            goto L5; // [199] 92
L6: 
            ;
        }

        /** 	end for*/
        _i_21627 = _i_21627 + 1;
        goto L3; // [206] 76
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21608);
    DeRef(_haystack_21610);
    DeRef(_options_21612);
    _12202 = NOVALUE;
    return _match_data_21618;
    ;
}


int  __stdcall _47split(int _re_21655, int _text_21657, int _from_21658, int _options_21659)
{
    int _12217 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21658)) {
        _1 = (long)(DBL_PTR(_from_21658)->dbl);
        DeRefDS(_from_21658);
        _from_21658 = _1;
    }

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_re_21655);
    Ref(_text_21657);
    Ref(_options_21659);
    _12217 = _47split_limit(_re_21655, _text_21657, 0, _from_21658, _options_21659);
    DeRef(_re_21655);
    DeRef(_text_21657);
    DeRef(_options_21659);
    return _12217;
    ;
}


int  __stdcall _47split_limit(int _re_21664, int _text_21666, int _limit_21667, int _from_21668, int _options_21669)
{
    int _match_data_21673 = NOVALUE;
    int _result_21676 = NOVALUE;
    int _last_21677 = NOVALUE;
    int _a_21688 = NOVALUE;
    int _12243 = NOVALUE;
    int _12242 = NOVALUE;
    int _12241 = NOVALUE;
    int _12239 = NOVALUE;
    int _12237 = NOVALUE;
    int _12236 = NOVALUE;
    int _12235 = NOVALUE;
    int _12234 = NOVALUE;
    int _12233 = NOVALUE;
    int _12230 = NOVALUE;
    int _12229 = NOVALUE;
    int _12228 = NOVALUE;
    int _12225 = NOVALUE;
    int _12224 = NOVALUE;
    int _12222 = NOVALUE;
    int _12220 = NOVALUE;
    int _12218 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_21667)) {
        _1 = (long)(DBL_PTR(_limit_21667)->dbl);
        DeRefDS(_limit_21667);
        _limit_21667 = _1;
    }
    if (!IS_ATOM_INT(_from_21668)) {
        _1 = (long)(DBL_PTR(_from_21668)->dbl);
        DeRefDS(_from_21668);
        _from_21668 = _1;
    }

    /** 	if sequence(options) then */
    _12218 = IS_SEQUENCE(_options_21669);
    if (_12218 == 0)
    {
        _12218 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12218 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21669);
    _0 = _options_21669;
    _options_21669 = _20or_all(_options_21669);
    DeRef(_0);
L1: 

    /** 	sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_21664);
    _12220 = _47get_ovector_size(_re_21664, 30);
    Ref(_re_21664);
    Ref(_text_21666);
    Ref(_options_21669);
    _0 = _match_data_21673;
    _match_data_21673 = _47find_all(_re_21664, _text_21666, _from_21668, _options_21669, _12220);
    DeRef(_0);
    _12220 = NOVALUE;

    /** 	integer last = 1*/
    _last_21677 = 1;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12222 = (_limit_21667 == 0);
    if (_12222 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_21673)){
            _12224 = SEQ_PTR(_match_data_21673)->length;
    }
    else {
        _12224 = 1;
    }
    _12225 = (_limit_21667 > _12224);
    _12224 = NOVALUE;
    if (_12225 == 0)
    {
        DeRef(_12225);
        _12225 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12225);
        _12225 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21673)){
            _limit_21667 = SEQ_PTR(_match_data_21673)->length;
    }
    else {
        _limit_21667 = 1;
    }
L3: 

    /** 	result = repeat(0, limit)*/
    DeRef(_result_21676);
    _result_21676 = Repeat(0, _limit_21667);

    /** 	for i = 1 to limit do*/
    _12228 = _limit_21667;
    {
        int _i_21686;
        _i_21686 = 1;
L4: 
        if (_i_21686 > _12228){
            goto L5; // [81] 164
        }

        /** 		integer a*/

        /** 		a = match_data[i][1][1]*/
        _2 = (int)SEQ_PTR(_match_data_21673);
        _12229 = (int)*(((s1_ptr)_2)->base + _i_21686);
        _2 = (int)SEQ_PTR(_12229);
        _12230 = (int)*(((s1_ptr)_2)->base + 1);
        _12229 = NOVALUE;
        _2 = (int)SEQ_PTR(_12230);
        _a_21688 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_a_21688)){
            _a_21688 = (long)DBL_PTR(_a_21688)->dbl;
        }
        _12230 = NOVALUE;

        /** 		if a = 0 then*/
        if (_a_21688 != 0)
        goto L6; // [108] 121

        /** 			result[i] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_result_21676);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21676 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21686);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** 			result[i] = text[last..a - 1]*/
        _12233 = _a_21688 - 1;
        rhs_slice_target = (object_ptr)&_12234;
        RHS_Slice(_text_21666, _last_21677, _12233);
        _2 = (int)SEQ_PTR(_result_21676);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21676 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21686);
        _1 = *(int *)_2;
        *(int *)_2 = _12234;
        if( _1 != _12234 ){
            DeRef(_1);
        }
        _12234 = NOVALUE;

        /** 			last = match_data[i][1][2] + 1*/
        _2 = (int)SEQ_PTR(_match_data_21673);
        _12235 = (int)*(((s1_ptr)_2)->base + _i_21686);
        _2 = (int)SEQ_PTR(_12235);
        _12236 = (int)*(((s1_ptr)_2)->base + 1);
        _12235 = NOVALUE;
        _2 = (int)SEQ_PTR(_12236);
        _12237 = (int)*(((s1_ptr)_2)->base + 2);
        _12236 = NOVALUE;
        if (IS_ATOM_INT(_12237)) {
            _last_21677 = _12237 + 1;
        }
        else
        { // coercing _last_21677 to an integer 1
            _last_21677 = 1+(long)(DBL_PTR(_12237)->dbl);
            if( !IS_ATOM_INT(_last_21677) ){
                _last_21677 = (object)DBL_PTR(_last_21677)->dbl;
            }
        }
        _12237 = NOVALUE;
L7: 

        /** 	end for*/
        _i_21686 = _i_21686 + 1;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** 	if last < length(text) then*/
    if (IS_SEQUENCE(_text_21666)){
            _12239 = SEQ_PTR(_text_21666)->length;
    }
    else {
        _12239 = 1;
    }
    if (_last_21677 >= _12239)
    goto L8; // [169] 192

    /** 		result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_21666)){
            _12241 = SEQ_PTR(_text_21666)->length;
    }
    else {
        _12241 = 1;
    }
    rhs_slice_target = (object_ptr)&_12242;
    RHS_Slice(_text_21666, _last_21677, _12241);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12242;
    _12243 = MAKE_SEQ(_1);
    _12242 = NOVALUE;
    Concat((object_ptr)&_result_21676, _result_21676, _12243);
    DeRefDS(_12243);
    _12243 = NOVALUE;
L8: 

    /** 	return result*/
    DeRef(_re_21664);
    DeRef(_text_21666);
    DeRef(_options_21669);
    DeRef(_match_data_21673);
    DeRef(_12222);
    _12222 = NOVALUE;
    DeRef(_12233);
    _12233 = NOVALUE;
    return _result_21676;
    ;
}


int  __stdcall _47find_replace(int _ex_21710, int _text_21712, int _replacement_21713, int _from_21714, int _options_21715)
{
    int _12245 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21714)) {
        _1 = (long)(DBL_PTR(_from_21714)->dbl);
        DeRefDS(_from_21714);
        _from_21714 = _1;
    }

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_21710);
    Ref(_text_21712);
    RefDS(_replacement_21713);
    Ref(_options_21715);
    _12245 = _47find_replace_limit(_ex_21710, _text_21712, _replacement_21713, -1, _from_21714, _options_21715);
    DeRef(_ex_21710);
    DeRef(_text_21712);
    DeRefDS(_replacement_21713);
    DeRef(_options_21715);
    return _12245;
    ;
}


int  __stdcall _47find_replace_limit(int _ex_21720, int _text_21722, int _replacement_21723, int _limit_21724, int _from_21725, int _options_21726)
{
    int _12249 = NOVALUE;
    int _12248 = NOVALUE;
    int _12246 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_21724)) {
        _1 = (long)(DBL_PTR(_limit_21724)->dbl);
        DeRefDS(_limit_21724);
        _limit_21724 = _1;
    }
    if (!IS_ATOM_INT(_from_21725)) {
        _1 = (long)(DBL_PTR(_from_21725)->dbl);
        DeRefDS(_from_21725);
        _from_21725 = _1;
    }

    /** 	if sequence(options) then */
    _12246 = IS_SEQUENCE(_options_21726);
    if (_12246 == 0)
    {
        _12246 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12246 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21726);
    _0 = _options_21726;
    _options_21726 = _20or_all(_options_21726);
    DeRef(_0);
L1: 

    /**     return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21720);
    *((int *)(_2+4)) = _ex_21720;
    Ref(_text_21722);
    *((int *)(_2+8)) = _text_21722;
    RefDS(_replacement_21723);
    *((int *)(_2+12)) = _replacement_21723;
    Ref(_options_21726);
    *((int *)(_2+16)) = _options_21726;
    *((int *)(_2+20)) = _from_21725;
    *((int *)(_2+24)) = _limit_21724;
    _12248 = MAKE_SEQ(_1);
    _12249 = machine(71, _12248);
    DeRefDS(_12248);
    _12248 = NOVALUE;
    DeRef(_ex_21720);
    DeRef(_text_21722);
    DeRefDS(_replacement_21723);
    DeRef(_options_21726);
    return _12249;
    ;
}


int  __stdcall _47find_replace_callback(int _ex_21734, int _text_21736, int _rid_21737, int _limit_21738, int _from_21739, int _options_21740)
{
    int _match_data_21744 = NOVALUE;
    int _replace_data_21747 = NOVALUE;
    int _params_21758 = NOVALUE;
    int _12285 = NOVALUE;
    int _12284 = NOVALUE;
    int _12283 = NOVALUE;
    int _12282 = NOVALUE;
    int _12281 = NOVALUE;
    int _12280 = NOVALUE;
    int _12279 = NOVALUE;
    int _12278 = NOVALUE;
    int _12277 = NOVALUE;
    int _12276 = NOVALUE;
    int _12275 = NOVALUE;
    int _12274 = NOVALUE;
    int _12273 = NOVALUE;
    int _12272 = NOVALUE;
    int _12271 = NOVALUE;
    int _12270 = NOVALUE;
    int _12269 = NOVALUE;
    int _12268 = NOVALUE;
    int _12267 = NOVALUE;
    int _12266 = NOVALUE;
    int _12265 = NOVALUE;
    int _12264 = NOVALUE;
    int _12262 = NOVALUE;
    int _12261 = NOVALUE;
    int _12260 = NOVALUE;
    int _12257 = NOVALUE;
    int _12256 = NOVALUE;
    int _12254 = NOVALUE;
    int _12252 = NOVALUE;
    int _12250 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_21737)) {
        _1 = (long)(DBL_PTR(_rid_21737)->dbl);
        DeRefDS(_rid_21737);
        _rid_21737 = _1;
    }
    if (!IS_ATOM_INT(_limit_21738)) {
        _1 = (long)(DBL_PTR(_limit_21738)->dbl);
        DeRefDS(_limit_21738);
        _limit_21738 = _1;
    }
    if (!IS_ATOM_INT(_from_21739)) {
        _1 = (long)(DBL_PTR(_from_21739)->dbl);
        DeRefDS(_from_21739);
        _from_21739 = _1;
    }

    /** 	if sequence(options) then */
    _12250 = IS_SEQUENCE(_options_21740);
    if (_12250 == 0)
    {
        _12250 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12250 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21740);
    _0 = _options_21740;
    _options_21740 = _20or_all(_options_21740);
    DeRef(_0);
L1: 

    /** 	sequence match_data = find_all(ex, text, from, options), replace_data*/
    Ref(_ex_21734);
    _12252 = _47get_ovector_size(_ex_21734, 30);
    Ref(_ex_21734);
    Ref(_text_21736);
    Ref(_options_21740);
    _0 = _match_data_21744;
    _match_data_21744 = _47find_all(_ex_21734, _text_21736, _from_21739, _options_21740, _12252);
    DeRef(_0);
    _12252 = NOVALUE;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12254 = (_limit_21738 == 0);
    if (_12254 != 0) {
        goto L2; // [45] 61
    }
    if (IS_SEQUENCE(_match_data_21744)){
            _12256 = SEQ_PTR(_match_data_21744)->length;
    }
    else {
        _12256 = 1;
    }
    _12257 = (_limit_21738 > _12256);
    _12256 = NOVALUE;
    if (_12257 == 0)
    {
        DeRef(_12257);
        _12257 = NOVALUE;
        goto L3; // [57] 67
    }
    else{
        DeRef(_12257);
        _12257 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21744)){
            _limit_21738 = SEQ_PTR(_match_data_21744)->length;
    }
    else {
        _limit_21738 = 1;
    }
L3: 

    /** 	replace_data = repeat(0, limit)*/
    DeRef(_replace_data_21747);
    _replace_data_21747 = Repeat(0, _limit_21738);

    /** 	for i = 1 to limit do*/
    _12260 = _limit_21738;
    {
        int _i_21756;
        _i_21756 = 1;
L4: 
        if (_i_21756 > _12260){
            goto L5; // [78] 210
        }

        /** 		sequence params = repeat(0, length(match_data[i]))*/
        _2 = (int)SEQ_PTR(_match_data_21744);
        _12261 = (int)*(((s1_ptr)_2)->base + _i_21756);
        if (IS_SEQUENCE(_12261)){
                _12262 = SEQ_PTR(_12261)->length;
        }
        else {
            _12262 = 1;
        }
        _12261 = NOVALUE;
        DeRef(_params_21758);
        _params_21758 = Repeat(0, _12262);
        _12262 = NOVALUE;

        /** 		for j = 1 to length(match_data[i]) do*/
        _2 = (int)SEQ_PTR(_match_data_21744);
        _12264 = (int)*(((s1_ptr)_2)->base + _i_21756);
        if (IS_SEQUENCE(_12264)){
                _12265 = SEQ_PTR(_12264)->length;
        }
        else {
            _12265 = 1;
        }
        _12264 = NOVALUE;
        {
            int _j_21763;
            _j_21763 = 1;
L6: 
            if (_j_21763 > _12265){
                goto L7; // [107] 187
            }

            /** 			if equal(match_data[i][j],{0,0}) then*/
            _2 = (int)SEQ_PTR(_match_data_21744);
            _12266 = (int)*(((s1_ptr)_2)->base + _i_21756);
            _2 = (int)SEQ_PTR(_12266);
            _12267 = (int)*(((s1_ptr)_2)->base + _j_21763);
            _12266 = NOVALUE;
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = 0;
            ((int *)_2)[2] = 0;
            _12268 = MAKE_SEQ(_1);
            if (_12267 == _12268)
            _12269 = 1;
            else if (IS_ATOM_INT(_12267) && IS_ATOM_INT(_12268))
            _12269 = 0;
            else
            _12269 = (compare(_12267, _12268) == 0);
            _12267 = NOVALUE;
            DeRefDS(_12268);
            _12268 = NOVALUE;
            if (_12269 == 0)
            {
                _12269 = NOVALUE;
                goto L8; // [132] 144
            }
            else{
                _12269 = NOVALUE;
            }

            /** 				params[j] = 0*/
            _2 = (int)SEQ_PTR(_params_21758);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _params_21758 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21763);
            _1 = *(int *)_2;
            *(int *)_2 = 0;
            DeRef(_1);
            goto L9; // [141] 180
L8: 

            /** 				params[j] = text[match_data[i][j][1]..match_data[i][j][2]]*/
            _2 = (int)SEQ_PTR(_match_data_21744);
            _12270 = (int)*(((s1_ptr)_2)->base + _i_21756);
            _2 = (int)SEQ_PTR(_12270);
            _12271 = (int)*(((s1_ptr)_2)->base + _j_21763);
            _12270 = NOVALUE;
            _2 = (int)SEQ_PTR(_12271);
            _12272 = (int)*(((s1_ptr)_2)->base + 1);
            _12271 = NOVALUE;
            _2 = (int)SEQ_PTR(_match_data_21744);
            _12273 = (int)*(((s1_ptr)_2)->base + _i_21756);
            _2 = (int)SEQ_PTR(_12273);
            _12274 = (int)*(((s1_ptr)_2)->base + _j_21763);
            _12273 = NOVALUE;
            _2 = (int)SEQ_PTR(_12274);
            _12275 = (int)*(((s1_ptr)_2)->base + 2);
            _12274 = NOVALUE;
            rhs_slice_target = (object_ptr)&_12276;
            RHS_Slice(_text_21736, _12272, _12275);
            _2 = (int)SEQ_PTR(_params_21758);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _params_21758 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21763);
            _1 = *(int *)_2;
            *(int *)_2 = _12276;
            if( _1 != _12276 ){
                DeRef(_1);
            }
            _12276 = NOVALUE;
L9: 

            /** 		end for*/
            _j_21763 = _j_21763 + 1;
            goto L6; // [182] 114
L7: 
            ;
        }

        /** 		replace_data[i] = call_func(rid, { params })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_params_21758);
        *((int *)(_2+4)) = _params_21758;
        _12277 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_12277);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_rid_21737].addr;
        Ref(*(int *)(_2+4));
        if (_00[_rid_21737].convention) {
            _1 = (*(int (__stdcall *)())_0)(
                                *(int *)(_2+4)
                                 );
        }
        else {
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
        }
        DeRef(_12278);
        _12278 = _1;
        DeRefDS(_12277);
        _12277 = NOVALUE;
        _2 = (int)SEQ_PTR(_replace_data_21747);
        _2 = (int)(((s1_ptr)_2)->base + _i_21756);
        _1 = *(int *)_2;
        *(int *)_2 = _12278;
        if( _1 != _12278 ){
            DeRef(_1);
        }
        _12278 = NOVALUE;
        DeRefDS(_params_21758);
        _params_21758 = NOVALUE;

        /** 	end for*/
        _i_21756 = _i_21756 + 1;
        goto L4; // [205] 85
L5: 
        ;
    }

    /** 	for i = limit to 1 by -1 do*/
    {
        int _i_21782;
        _i_21782 = _limit_21738;
LA: 
        if (_i_21782 < 1){
            goto LB; // [212] 262
        }

        /** 		text = replace(text, replace_data[i], match_data[i][1][1], match_data[i][1][2])*/
        _2 = (int)SEQ_PTR(_replace_data_21747);
        _12279 = (int)*(((s1_ptr)_2)->base + _i_21782);
        _2 = (int)SEQ_PTR(_match_data_21744);
        _12280 = (int)*(((s1_ptr)_2)->base + _i_21782);
        _2 = (int)SEQ_PTR(_12280);
        _12281 = (int)*(((s1_ptr)_2)->base + 1);
        _12280 = NOVALUE;
        _2 = (int)SEQ_PTR(_12281);
        _12282 = (int)*(((s1_ptr)_2)->base + 1);
        _12281 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21744);
        _12283 = (int)*(((s1_ptr)_2)->base + _i_21782);
        _2 = (int)SEQ_PTR(_12283);
        _12284 = (int)*(((s1_ptr)_2)->base + 1);
        _12283 = NOVALUE;
        _2 = (int)SEQ_PTR(_12284);
        _12285 = (int)*(((s1_ptr)_2)->base + 2);
        _12284 = NOVALUE;
        {
            int p1 = _text_21736;
            int p2 = _12279;
            int p3 = _12282;
            int p4 = _12285;
            struct replace_block replace_params;
            replace_params.copy_to   = &p1;
            replace_params.copy_from = &p2;
            replace_params.start     = &p3;
            replace_params.stop      = &p4;
            replace_params.target    = &_text_21736;
            Replace( &replace_params );
        }
        _12279 = NOVALUE;
        _12282 = NOVALUE;
        _12285 = NOVALUE;

        /** 	end for*/
        _i_21782 = _i_21782 + -1;
        goto LA; // [257] 219
LB: 
        ;
    }

    /** 	return text*/
    DeRef(_ex_21734);
    DeRef(_options_21740);
    DeRef(_match_data_21744);
    DeRef(_replace_data_21747);
    DeRef(_12254);
    _12254 = NOVALUE;
    _12261 = NOVALUE;
    _12264 = NOVALUE;
    _12272 = NOVALUE;
    _12275 = NOVALUE;
    return _text_21736;
    ;
}



// 0x781EC53D
