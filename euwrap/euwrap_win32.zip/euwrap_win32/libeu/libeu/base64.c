// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _30encode(int _in_12188, int _wrap_column_12189)
{
    int _len_12190 = NOVALUE;
    int _oidx_12191 = NOVALUE;
    int _prev_12192 = NOVALUE;
    int _case4_12193 = NOVALUE;
    int _tmp_12194 = NOVALUE;
    int _inch_12195 = NOVALUE;
    int _result_12196 = NOVALUE;
    int _6919 = NOVALUE;
    int _6916 = NOVALUE;
    int _6915 = NOVALUE;
    int _6913 = NOVALUE;
    int _6912 = NOVALUE;
    int _6911 = NOVALUE;
    int _6910 = NOVALUE;
    int _6908 = NOVALUE;
    int _6906 = NOVALUE;
    int _6905 = NOVALUE;
    int _6904 = NOVALUE;
    int _6903 = NOVALUE;
    int _6902 = NOVALUE;
    int _6901 = NOVALUE;
    int _6900 = NOVALUE;
    int _6898 = NOVALUE;
    int _6897 = NOVALUE;
    int _6895 = NOVALUE;
    int _6892 = NOVALUE;
    int _6891 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_wrap_column_12189)) {
        _1 = (long)(DBL_PTR(_wrap_column_12189)->dbl);
        DeRefDS(_wrap_column_12189);
        _wrap_column_12189 = _1;
    }

    /** 	len = length(in)*/
    if (IS_SEQUENCE(_in_12188)){
            _len_12190 = SEQ_PTR(_in_12188)->length;
    }
    else {
        _len_12190 = 1;
    }

    /** 	oidx = floor((len + 2) / 3) * 4*/
    _6891 = _len_12190 + 2;
    if (3 > 0 && _6891 >= 0) {
        _6892 = _6891 / 3;
    }
    else {
        temp_dbl = floor((double)_6891 / (double)3);
        _6892 = (long)temp_dbl;
    }
    _6891 = NOVALUE;
    _oidx_12191 = _6892 * 4;
    _6892 = NOVALUE;

    /** 	result = repeat('=', oidx)*/
    DeRef(_result_12196);
    _result_12196 = Repeat(61, _oidx_12191);

    /** 	if remainder(len, 3) != 0 then*/
    _6895 = (_len_12190 % 3);
    if (_6895 == 0)
    goto L1; // [38] 59

    /** 		oidx = oidx + remainder(len, 3) - 3*/
    _6897 = (_len_12190 % 3);
    _6898 = _oidx_12191 + _6897;
    if ((long)((unsigned long)_6898 + (unsigned long)HIGH_BITS) >= 0) 
    _6898 = NewDouble((double)_6898);
    _6897 = NOVALUE;
    if (IS_ATOM_INT(_6898)) {
        _oidx_12191 = _6898 - 3;
    }
    else {
        _oidx_12191 = NewDouble(DBL_PTR(_6898)->dbl - (double)3);
    }
    DeRef(_6898);
    _6898 = NOVALUE;
    if (!IS_ATOM_INT(_oidx_12191)) {
        _1 = (long)(DBL_PTR(_oidx_12191)->dbl);
        DeRefDS(_oidx_12191);
        _oidx_12191 = _1;
    }
L1: 

    /** 	case4 = 1*/
    _case4_12193 = 1;

    /** 	inch  = 1*/
    _inch_12195 = 1;

    /** 	for i = 1 to oidx do*/
    _6900 = _oidx_12191;
    {
        int _i_12209;
        _i_12209 = 1;
L2: 
        if (_i_12209 > _6900){
            goto L3; // [74] 226
        }

        /** 		tmp = 0*/
        _tmp_12194 = 0;

        /** 		if ediv[case4] > 0 and inch <= len then*/
        _2 = (int)SEQ_PTR(_30ediv_12166);
        _6901 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        _6902 = (_6901 > 0);
        _6901 = NOVALUE;
        if (_6902 == 0) {
            goto L4; // [98] 129
        }
        _6904 = (_inch_12195 <= _len_12190);
        if (_6904 == 0)
        {
            DeRef(_6904);
            _6904 = NOVALUE;
            goto L4; // [107] 129
        }
        else{
            DeRef(_6904);
            _6904 = NOVALUE;
        }

        /** 			tmp = floor(in[inch] / ediv[case4])*/
        _2 = (int)SEQ_PTR(_in_12188);
        _6905 = (int)*(((s1_ptr)_2)->base + _inch_12195);
        _2 = (int)SEQ_PTR(_30ediv_12166);
        _6906 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        if (IS_ATOM_INT(_6905)) {
            if (_6906 > 0 && _6905 >= 0) {
                _tmp_12194 = _6905 / _6906;
            }
            else {
                temp_dbl = floor((double)_6905 / (double)_6906);
                _tmp_12194 = (long)temp_dbl;
            }
        }
        else {
            _2 = binary_op(DIVIDE, _6905, _6906);
            _tmp_12194 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _6905 = NOVALUE;
        _6906 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12194)) {
            _1 = (long)(DBL_PTR(_tmp_12194)->dbl);
            DeRefDS(_tmp_12194);
            _tmp_12194 = _1;
        }
L4: 

        /** 		if erem[case4] > 0 then*/
        _2 = (int)SEQ_PTR(_30erem_12168);
        _6908 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        if (_6908 <= 0)
        goto L5; // [137] 172

        /** 			tmp += remainder(prev, erem[case4]) * emul[case4]*/
        _2 = (int)SEQ_PTR(_30erem_12168);
        _6910 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        _6911 = (_prev_12192 % _6910);
        _6910 = NOVALUE;
        _2 = (int)SEQ_PTR(_30emul_12170);
        _6912 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        if (_6911 == (short)_6911 && _6912 <= INT15 && _6912 >= -INT15)
        _6913 = _6911 * _6912;
        else
        _6913 = NewDouble(_6911 * (double)_6912);
        _6911 = NOVALUE;
        _6912 = NOVALUE;
        if (IS_ATOM_INT(_6913)) {
            _tmp_12194 = _tmp_12194 + _6913;
        }
        else {
            _tmp_12194 = NewDouble((double)_tmp_12194 + DBL_PTR(_6913)->dbl);
        }
        DeRef(_6913);
        _6913 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12194)) {
            _1 = (long)(DBL_PTR(_tmp_12194)->dbl);
            DeRefDS(_tmp_12194);
            _tmp_12194 = _1;
        }
L5: 

        /** 		result[i] = aleph[tmp + 1] --# and encode it*/
        _6915 = _tmp_12194 + 1;
        _2 = (int)SEQ_PTR(_30aleph_12149);
        _6916 = (int)*(((s1_ptr)_2)->base + _6915);
        Ref(_6916);
        _2 = (int)SEQ_PTR(_result_12196);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_12196 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12209);
        _1 = *(int *)_2;
        *(int *)_2 = _6916;
        if( _1 != _6916 ){
            DeRef(_1);
        }
        _6916 = NOVALUE;

        /** 		if inch <= len then*/
        if (_inch_12195 > _len_12190)
        goto L6; // [188] 199

        /** 			prev = in[inch]*/
        _2 = (int)SEQ_PTR(_in_12188);
        _prev_12192 = (int)*(((s1_ptr)_2)->base + _inch_12195);
        if (!IS_ATOM_INT(_prev_12192))
        _prev_12192 = (long)DBL_PTR(_prev_12192)->dbl;
L6: 

        /** 		inch += next[case4]*/
        _2 = (int)SEQ_PTR(_30next_12180);
        _6919 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        _inch_12195 = _inch_12195 + _6919;
        _6919 = NOVALUE;

        /** 		case4 = nc4[case4]*/
        _2 = (int)SEQ_PTR(_30nc4_12178);
        _case4_12193 = (int)*(((s1_ptr)_2)->base + _case4_12193);
        if (!IS_ATOM_INT(_case4_12193))
        _case4_12193 = (long)DBL_PTR(_case4_12193)->dbl;

        /** 	end for*/
        _i_12209 = _i_12209 + 1;
        goto L2; // [221] 81
L3: 
        ;
    }

    /** 	if wrap_column > 0 then*/
    if (_wrap_column_12189 <= 0)
    goto L7; // [228] 252

    /** 		result = stdseq:breakup(result, wrap_column)*/
    RefDS(_result_12196);
    _0 = _result_12196;
    _result_12196 = _23breakup(_result_12196, _wrap_column_12189, 1);
    DeRefDS(_0);

    /** 		result = stdseq:join(result, "\r\n")*/
    RefDS(_result_12196);
    RefDS(_1325);
    _0 = _result_12196;
    _result_12196 = _23join(_result_12196, _1325);
    DeRefDS(_0);
L7: 

    /** 	return result*/
    DeRefDS(_in_12188);
    DeRef(_6895);
    _6895 = NOVALUE;
    _6908 = NOVALUE;
    DeRef(_6902);
    _6902 = NOVALUE;
    DeRef(_6915);
    _6915 = NOVALUE;
    return _result_12196;
    ;
}


int  __stdcall _30decode(int _in_12241)
{
    int _len_12242 = NOVALUE;
    int _oidx_12243 = NOVALUE;
    int _case3_12244 = NOVALUE;
    int _tmp_12245 = NOVALUE;
    int _result_12246 = NOVALUE;
    int _ccha_12247 = NOVALUE;
    int _6952 = NOVALUE;
    int _6950 = NOVALUE;
    int _6949 = NOVALUE;
    int _6948 = NOVALUE;
    int _6947 = NOVALUE;
    int _6945 = NOVALUE;
    int _6944 = NOVALUE;
    int _6943 = NOVALUE;
    int _6942 = NOVALUE;
    int _6941 = NOVALUE;
    int _6940 = NOVALUE;
    int _6938 = NOVALUE;
    int _6937 = NOVALUE;
    int _6931 = NOVALUE;
    int _6929 = NOVALUE;
    int _6927 = NOVALUE;
    int _0, _1, _2;
    

    /** 	in = search:match_replace("\r\n", in, "")*/
    RefDS(_1325);
    RefDS(_in_12241);
    RefDS(_5);
    _0 = _in_12241;
    _in_12241 = _9match_replace(_1325, _in_12241, _5, 0);
    DeRefDS(_0);

    /** 	len = length(in)*/
    if (IS_SEQUENCE(_in_12241)){
            _len_12242 = SEQ_PTR(_in_12241)->length;
    }
    else {
        _len_12242 = 1;
    }

    /** 	if remainder(len, 4) != 0 then*/
    _6927 = (_len_12242 % 4);
    if (_6927 == 0)
    goto L1; // [25] 36

    /** 		return -1*/
    DeRefDS(_in_12241);
    DeRefi(_result_12246);
    DeRefi(_ccha_12247);
    _6927 = NOVALUE;
    return -1;
L1: 

    /** 	oidx = (len / 4) * 3*/
    _6929 = (_len_12242 % 4) ? NewDouble((double)_len_12242 / 4) : (_len_12242 / 4);
    if (IS_ATOM_INT(_6929)) {
        _oidx_12243 = _6929 * 3;
    }
    else {
        _oidx_12243 = NewDouble(DBL_PTR(_6929)->dbl * (double)3);
    }
    DeRef(_6929);
    _6929 = NOVALUE;
    if (!IS_ATOM_INT(_oidx_12243)) {
        _1 = (long)(DBL_PTR(_oidx_12243)->dbl);
        DeRefDS(_oidx_12243);
        _oidx_12243 = _1;
    }

    /** 	case3 = 3*/
    _case3_12244 = 3;

    /** 	while in[len] = '=' do	--# should only happen 0 1 or 2 times*/
L2: 
    _2 = (int)SEQ_PTR(_in_12241);
    _6931 = (int)*(((s1_ptr)_2)->base + _len_12242);
    if (binary_op_a(NOTEQ, _6931, 61)){
        _6931 = NOVALUE;
        goto L3; // [62] 89
    }
    _6931 = NOVALUE;

    /** 		oidx -= 1*/
    _oidx_12243 = _oidx_12243 - 1;

    /** 		case3 = nc3[case3]*/
    _2 = (int)SEQ_PTR(_30nc3_12182);
    _case3_12244 = (int)*(((s1_ptr)_2)->base + _case3_12244);
    if (!IS_ATOM_INT(_case3_12244))
    _case3_12244 = (long)DBL_PTR(_case3_12244)->dbl;

    /** 		len -= 1*/
    _len_12242 = _len_12242 - 1;

    /** 	end while*/
    goto L2; // [86] 58
L3: 

    /** 	ccha = repeat(0, 256)*/
    DeRefi(_ccha_12247);
    _ccha_12247 = Repeat(0, 256);

    /** 	for i = 1 to 64 do*/
    {
        int _i_12263;
        _i_12263 = 1;
L4: 
        if (_i_12263 > 64){
            goto L5; // [97] 125
        }

        /** 		ccha[aleph[i]] = i - 1*/
        _2 = (int)SEQ_PTR(_30aleph_12149);
        _6937 = (int)*(((s1_ptr)_2)->base + _i_12263);
        _6938 = _i_12263 - 1;
        _2 = (int)SEQ_PTR(_ccha_12247);
        if (!IS_ATOM_INT(_6937))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_6937)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _6937);
        *(int *)_2 = _6938;
        if( _1 != _6938 ){
        }
        _6938 = NOVALUE;

        /** 	end for	*/
        _i_12263 = _i_12263 + 1;
        goto L4; // [120] 104
L5: 
        ;
    }

    /** 	result = repeat('?', oidx)*/
    DeRefi(_result_12246);
    _result_12246 = Repeat(63, _oidx_12243);

    /** 	for i = oidx to 1 by -1 do*/
    {
        int _i_12268;
        _i_12268 = _oidx_12243;
L6: 
        if (_i_12268 < 1){
            goto L7; // [133] 227
        }

        /** 		tmp = remainder(ccha[in[len - 1]], drem[case3]) * dmul[case3]*/
        _6940 = _len_12242 - 1;
        _2 = (int)SEQ_PTR(_in_12241);
        _6941 = (int)*(((s1_ptr)_2)->base + _6940);
        _2 = (int)SEQ_PTR(_ccha_12247);
        if (!IS_ATOM_INT(_6941)){
            _6942 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6941)->dbl));
        }
        else{
            _6942 = (int)*(((s1_ptr)_2)->base + _6941);
        }
        _2 = (int)SEQ_PTR(_30drem_12172);
        _6943 = (int)*(((s1_ptr)_2)->base + _case3_12244);
        if (IS_ATOM_INT(_6943)) {
            _6944 = (_6942 % _6943);
        }
        else {
            _6944 = binary_op(REMAINDER, _6942, _6943);
        }
        _6942 = NOVALUE;
        _6943 = NOVALUE;
        _2 = (int)SEQ_PTR(_30dmul_12174);
        _6945 = (int)*(((s1_ptr)_2)->base + _case3_12244);
        if (IS_ATOM_INT(_6944) && IS_ATOM_INT(_6945)) {
            _tmp_12245 = _6944 * _6945;
        }
        else {
            _tmp_12245 = binary_op(MULTIPLY, _6944, _6945);
        }
        DeRef(_6944);
        _6944 = NOVALUE;
        _6945 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12245)) {
            _1 = (long)(DBL_PTR(_tmp_12245)->dbl);
            DeRefDS(_tmp_12245);
            _tmp_12245 = _1;
        }

        /** 		tmp += floor(ccha[in[len]] / ddiv[case3])*/
        _2 = (int)SEQ_PTR(_in_12241);
        _6947 = (int)*(((s1_ptr)_2)->base + _len_12242);
        _2 = (int)SEQ_PTR(_ccha_12247);
        if (!IS_ATOM_INT(_6947)){
            _6948 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6947)->dbl));
        }
        else{
            _6948 = (int)*(((s1_ptr)_2)->base + _6947);
        }
        _2 = (int)SEQ_PTR(_30ddiv_12176);
        _6949 = (int)*(((s1_ptr)_2)->base + _case3_12244);
        if (IS_ATOM_INT(_6949)) {
            if (_6949 > 0 && _6948 >= 0) {
                _6950 = _6948 / _6949;
            }
            else {
                temp_dbl = floor((double)_6948 / (double)_6949);
                if (_6948 != MININT)
                _6950 = (long)temp_dbl;
                else
                _6950 = NewDouble(temp_dbl);
            }
        }
        else {
            _2 = binary_op(DIVIDE, _6948, _6949);
            _6950 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _6948 = NOVALUE;
        _6949 = NOVALUE;
        if (IS_ATOM_INT(_6950)) {
            _tmp_12245 = _tmp_12245 + _6950;
        }
        else {
            _tmp_12245 = binary_op(PLUS, _tmp_12245, _6950);
        }
        DeRef(_6950);
        _6950 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12245)) {
            _1 = (long)(DBL_PTR(_tmp_12245)->dbl);
            DeRefDS(_tmp_12245);
            _tmp_12245 = _1;
        }

        /** 		result[i] = tmp*/
        _2 = (int)SEQ_PTR(_result_12246);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_12246 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12268);
        *(int *)_2 = _tmp_12245;

        /** 		len -= ldrop[case3]*/
        _2 = (int)SEQ_PTR(_30ldrop_12184);
        _6952 = (int)*(((s1_ptr)_2)->base + _case3_12244);
        if (IS_ATOM_INT(_6952)) {
            _len_12242 = _len_12242 - _6952;
        }
        else {
            _len_12242 = binary_op(MINUS, _len_12242, _6952);
        }
        _6952 = NOVALUE;
        if (!IS_ATOM_INT(_len_12242)) {
            _1 = (long)(DBL_PTR(_len_12242)->dbl);
            DeRefDS(_len_12242);
            _len_12242 = _1;
        }

        /** 		case3 = nc3[case3]*/
        _2 = (int)SEQ_PTR(_30nc3_12182);
        _case3_12244 = (int)*(((s1_ptr)_2)->base + _case3_12244);
        if (!IS_ATOM_INT(_case3_12244))
        _case3_12244 = (long)DBL_PTR(_case3_12244)->dbl;

        /** 	end for*/
        _i_12268 = _i_12268 + -1;
        goto L6; // [222] 140
L7: 
        ;
    }

    /** 	return result*/
    DeRefDS(_in_12241);
    DeRefi(_ccha_12247);
    DeRef(_6927);
    _6927 = NOVALUE;
    _6937 = NOVALUE;
    DeRef(_6940);
    _6940 = NOVALUE;
    _6941 = NOVALUE;
    _6947 = NOVALUE;
    return _result_12246;
    ;
}



// 0xB5E97E2A
