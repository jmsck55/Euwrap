// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _21rand_range(int _lo_4315, int _hi_4316)
{
    int _temp_4319 = NOVALUE;
    int _2227 = NOVALUE;
    int _2225 = NOVALUE;
    int _2222 = NOVALUE;
    int _2221 = NOVALUE;
    int _2220 = NOVALUE;
    int _2219 = NOVALUE;
    int _2217 = NOVALUE;
    int _2216 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if lo > hi then*/
    if (binary_op_a(LESSEQ, _lo_4315, _hi_4316)){
        goto L1; // [3] 23
    }

    /** 		atom temp = hi*/
    Ref(_hi_4316);
    DeRef(_temp_4319);
    _temp_4319 = _hi_4316;

    /** 		hi = lo*/
    Ref(_lo_4315);
    DeRef(_hi_4316);
    _hi_4316 = _lo_4315;

    /** 		lo = temp*/
    Ref(_temp_4319);
    DeRef(_lo_4315);
    _lo_4315 = _temp_4319;
L1: 
    DeRef(_temp_4319);
    _temp_4319 = NOVALUE;

    /** 	if not integer(lo) or not integer(hi) then*/
    if (IS_ATOM_INT(_lo_4315))
    _2216 = 1;
    else if (IS_ATOM_DBL(_lo_4315))
    _2216 = IS_ATOM_INT(DoubleToInt(_lo_4315));
    else
    _2216 = 0;
    _2217 = (_2216 == 0);
    _2216 = NOVALUE;
    if (_2217 != 0) {
        goto L2; // [33] 48
    }
    if (IS_ATOM_INT(_hi_4316))
    _2219 = 1;
    else if (IS_ATOM_DBL(_hi_4316))
    _2219 = IS_ATOM_INT(DoubleToInt(_hi_4316));
    else
    _2219 = 0;
    _2220 = (_2219 == 0);
    _2219 = NOVALUE;
    if (_2220 == 0)
    {
        DeRef(_2220);
        _2220 = NOVALUE;
        goto L3; // [44] 64
    }
    else{
        DeRef(_2220);
        _2220 = NOVALUE;
    }
L2: 

    /**    		hi = rnd() * (hi - lo)*/
    _2221 = _21rnd();
    if (IS_ATOM_INT(_hi_4316) && IS_ATOM_INT(_lo_4315)) {
        _2222 = _hi_4316 - _lo_4315;
        if ((long)((unsigned long)_2222 +(unsigned long) HIGH_BITS) >= 0){
            _2222 = NewDouble((double)_2222);
        }
    }
    else {
        if (IS_ATOM_INT(_hi_4316)) {
            _2222 = NewDouble((double)_hi_4316 - DBL_PTR(_lo_4315)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lo_4315)) {
                _2222 = NewDouble(DBL_PTR(_hi_4316)->dbl - (double)_lo_4315);
            }
            else
            _2222 = NewDouble(DBL_PTR(_hi_4316)->dbl - DBL_PTR(_lo_4315)->dbl);
        }
    }
    DeRef(_hi_4316);
    if (IS_ATOM_INT(_2221) && IS_ATOM_INT(_2222)) {
        if (_2221 == (short)_2221 && _2222 <= INT15 && _2222 >= -INT15)
        _hi_4316 = _2221 * _2222;
        else
        _hi_4316 = NewDouble(_2221 * (double)_2222);
    }
    else {
        _hi_4316 = binary_op(MULTIPLY, _2221, _2222);
    }
    DeRef(_2221);
    _2221 = NOVALUE;
    DeRef(_2222);
    _2222 = NOVALUE;
    goto L4; // [61] 80
L3: 

    /** 		lo -= 1*/
    _0 = _lo_4315;
    if (IS_ATOM_INT(_lo_4315)) {
        _lo_4315 = _lo_4315 - 1;
        if ((long)((unsigned long)_lo_4315 +(unsigned long) HIGH_BITS) >= 0){
            _lo_4315 = NewDouble((double)_lo_4315);
        }
    }
    else {
        _lo_4315 = NewDouble(DBL_PTR(_lo_4315)->dbl - (double)1);
    }
    DeRef(_0);

    /**    		hi = rand(hi - lo)*/
    if (IS_ATOM_INT(_hi_4316) && IS_ATOM_INT(_lo_4315)) {
        _2225 = _hi_4316 - _lo_4315;
        if ((long)((unsigned long)_2225 +(unsigned long) HIGH_BITS) >= 0){
            _2225 = NewDouble((double)_2225);
        }
    }
    else {
        if (IS_ATOM_INT(_hi_4316)) {
            _2225 = NewDouble((double)_hi_4316 - DBL_PTR(_lo_4315)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lo_4315)) {
                _2225 = NewDouble(DBL_PTR(_hi_4316)->dbl - (double)_lo_4315);
            }
            else
            _2225 = NewDouble(DBL_PTR(_hi_4316)->dbl - DBL_PTR(_lo_4315)->dbl);
        }
    }
    DeRef(_hi_4316);
    if (IS_ATOM_INT(_2225)) {
        _hi_4316 = good_rand() % ((unsigned)_2225) + 1;
    }
    else {
        _hi_4316 = unary_op(RAND, _2225);
    }
    DeRef(_2225);
    _2225 = NOVALUE;
L4: 

    /**    	return lo + hi*/
    if (IS_ATOM_INT(_lo_4315) && IS_ATOM_INT(_hi_4316)) {
        _2227 = _lo_4315 + _hi_4316;
        if ((long)((unsigned long)_2227 + (unsigned long)HIGH_BITS) >= 0) 
        _2227 = NewDouble((double)_2227);
    }
    else {
        if (IS_ATOM_INT(_lo_4315)) {
            _2227 = NewDouble((double)_lo_4315 + DBL_PTR(_hi_4316)->dbl);
        }
        else {
            if (IS_ATOM_INT(_hi_4316)) {
                _2227 = NewDouble(DBL_PTR(_lo_4315)->dbl + (double)_hi_4316);
            }
            else
            _2227 = NewDouble(DBL_PTR(_lo_4315)->dbl + DBL_PTR(_hi_4316)->dbl);
        }
    }
    DeRef(_lo_4315);
    DeRef(_hi_4316);
    DeRef(_2217);
    _2217 = NOVALUE;
    return _2227;
    ;
}


int  __stdcall _21rnd()
{
    int _a_4339 = NOVALUE;
    int _b_4340 = NOVALUE;
    int _r_4341 = NOVALUE;
    int _0, _1, _2;
    

    /** 	 a = rand(#FFFFFFFF)*/
    DeRef(_a_4339);
    _a_4339 = unary_op(RAND, _2228);

    /** 	 if a = 1 then return 0 end if*/
    if (binary_op_a(NOTEQ, _a_4339, 1)){
        goto L1; // [8] 17
    }
    DeRef(_a_4339);
    DeRef(_b_4340);
    DeRef(_r_4341);
    return 0;
L1: 

    /** 	 b = rand(#FFFFFFFF)*/
    DeRef(_b_4340);
    _b_4340 = unary_op(RAND, _2228);

    /** 	 if b = 1 then return 0 end if*/
    if (binary_op_a(NOTEQ, _b_4340, 1)){
        goto L2; // [24] 33
    }
    DeRef(_a_4339);
    DeRef(_b_4340);
    DeRef(_r_4341);
    return 0;
L2: 

    /** 	 if a > b then*/
    if (binary_op_a(LESSEQ, _a_4339, _b_4340)){
        goto L3; // [35] 48
    }

    /** 	 	r = b / a*/
    DeRef(_r_4341);
    if (IS_ATOM_INT(_b_4340) && IS_ATOM_INT(_a_4339)) {
        _r_4341 = (_b_4340 % _a_4339) ? NewDouble((double)_b_4340 / _a_4339) : (_b_4340 / _a_4339);
    }
    else {
        if (IS_ATOM_INT(_b_4340)) {
            _r_4341 = NewDouble((double)_b_4340 / DBL_PTR(_a_4339)->dbl);
        }
        else {
            if (IS_ATOM_INT(_a_4339)) {
                _r_4341 = NewDouble(DBL_PTR(_b_4340)->dbl / (double)_a_4339);
            }
            else
            _r_4341 = NewDouble(DBL_PTR(_b_4340)->dbl / DBL_PTR(_a_4339)->dbl);
        }
    }
    goto L4; // [45] 55
L3: 

    /** 	 	r = a / b*/
    DeRef(_r_4341);
    if (IS_ATOM_INT(_a_4339) && IS_ATOM_INT(_b_4340)) {
        _r_4341 = (_a_4339 % _b_4340) ? NewDouble((double)_a_4339 / _b_4340) : (_a_4339 / _b_4340);
    }
    else {
        if (IS_ATOM_INT(_a_4339)) {
            _r_4341 = NewDouble((double)_a_4339 / DBL_PTR(_b_4340)->dbl);
        }
        else {
            if (IS_ATOM_INT(_b_4340)) {
                _r_4341 = NewDouble(DBL_PTR(_a_4339)->dbl / (double)_b_4340);
            }
            else
            _r_4341 = NewDouble(DBL_PTR(_a_4339)->dbl / DBL_PTR(_b_4340)->dbl);
        }
    }
L4: 

    /** 	 return r*/
    DeRef(_a_4339);
    DeRef(_b_4340);
    return _r_4341;
    ;
}


int  __stdcall _21rnd_1()
{
    int _r_4356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while r >= 1.0 with entry do*/
    goto L1; // [3] 15
L2: 
    if (binary_op_a(LESS, _r_4356, _2236)){
        goto L3; // [8] 25
    }

    /** 	entry*/
L1: 

    /** 		r = rnd()*/
    _0 = _r_4356;
    _r_4356 = _21rnd();
    DeRef(_0);

    /** 	end while	 */
    goto L2; // [22] 6
L3: 

    /** 	return r*/
    return _r_4356;
    ;
}


void  __stdcall _21set_rand(int _seed_4363)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_4363);

    /** end procedure*/
    DeRef(_seed_4363);
    return;
    ;
}


int  __stdcall _21get_rand()
{
    int _2239 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_GET_RAND, {})*/
    _2239 = machine(98, _5);
    return _2239;
    ;
}


int  __stdcall _21chance(int _my_limit_4369, int _top_limit_4370)
{
    int _2242 = NOVALUE;
    int _2241 = NOVALUE;
    int _2240 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (rnd_1() * top_limit) <= my_limit*/
    _2240 = _21rnd_1();
    if (IS_ATOM_INT(_2240) && IS_ATOM_INT(_top_limit_4370)) {
        if (_2240 == (short)_2240 && _top_limit_4370 <= INT15 && _top_limit_4370 >= -INT15)
        _2241 = _2240 * _top_limit_4370;
        else
        _2241 = NewDouble(_2240 * (double)_top_limit_4370);
    }
    else {
        _2241 = binary_op(MULTIPLY, _2240, _top_limit_4370);
    }
    DeRef(_2240);
    _2240 = NOVALUE;
    if (IS_ATOM_INT(_2241) && IS_ATOM_INT(_my_limit_4369)) {
        _2242 = (_2241 <= _my_limit_4369);
    }
    else {
        _2242 = binary_op(LESSEQ, _2241, _my_limit_4369);
    }
    DeRef(_2241);
    _2241 = NOVALUE;
    DeRef(_my_limit_4369);
    DeRef(_top_limit_4370);
    return _2242;
    ;
}


int  __stdcall _21roll(int _desired_4376, int _sides_4377)
{
    int _rolled_4378 = NOVALUE;
    int _2247 = NOVALUE;
    int _2244 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sides_4377)) {
        _1 = (long)(DBL_PTR(_sides_4377)->dbl);
        DeRefDS(_sides_4377);
        _sides_4377 = _1;
    }

    /** 	if sides < 2 then*/
    if (_sides_4377 >= 2)
    goto L1; // [5] 16

    /** 		return 0*/
    DeRef(_desired_4376);
    return 0;
L1: 

    /** 	if atom(desired) then*/
    _2244 = IS_ATOM(_desired_4376);
    if (_2244 == 0)
    {
        _2244 = NOVALUE;
        goto L2; // [21] 31
    }
    else{
        _2244 = NOVALUE;
    }

    /** 		desired = {desired}*/
    _0 = _desired_4376;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_desired_4376);
    *((int *)(_2+4)) = _desired_4376;
    _desired_4376 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	rolled =  rand(sides)*/
    _rolled_4378 = good_rand() % ((unsigned)_sides_4377) + 1;

    /** 	if find(rolled, desired) then*/
    _2247 = find_from(_rolled_4378, _desired_4376, 1);
    if (_2247 == 0)
    {
        _2247 = NOVALUE;
        goto L3; // [43] 55
    }
    else{
        _2247 = NOVALUE;
    }

    /** 		return rolled*/
    DeRef(_desired_4376);
    return _rolled_4378;
    goto L4; // [52] 62
L3: 

    /** 		return 0*/
    DeRef(_desired_4376);
    return 0;
L4: 
    ;
}


int  __stdcall _21sample(int _population_4390, int _sample_size_4391, int _sampling_method_4392)
{
    int _lResult_4393 = NOVALUE;
    int _lIdx_4394 = NOVALUE;
    int _lChoice_4395 = NOVALUE;
    int _2265 = NOVALUE;
    int _2261 = NOVALUE;
    int _2258 = NOVALUE;
    int _2254 = NOVALUE;
    int _2253 = NOVALUE;
    int _2252 = NOVALUE;
    int _2251 = NOVALUE;
    int _2250 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sample_size_4391)) {
        _1 = (long)(DBL_PTR(_sample_size_4391)->dbl);
        DeRefDS(_sample_size_4391);
        _sample_size_4391 = _1;
    }
    if (!IS_ATOM_INT(_sampling_method_4392)) {
        _1 = (long)(DBL_PTR(_sampling_method_4392)->dbl);
        DeRefDS(_sampling_method_4392);
        _sampling_method_4392 = _1;
    }

    /** 	if sample_size < 1 then*/
    if (_sample_size_4391 >= 1)
    goto L1; // [9] 40

    /** 		if sampling_method > 0 then*/
    if (_sampling_method_4392 <= 0)
    goto L2; // [15] 32

    /** 			return {{}, population}	*/
    RefDS(_population_4390);
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _population_4390;
    _2250 = MAKE_SEQ(_1);
    DeRefDS(_population_4390);
    DeRef(_lResult_4393);
    return _2250;
    goto L3; // [29] 39
L2: 

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_population_4390);
    DeRef(_lResult_4393);
    DeRef(_2250);
    _2250 = NOVALUE;
    return _5;
L3: 
L1: 

    /** 	if sampling_method >= 0 and sample_size >= length(population) then*/
    _2251 = (_sampling_method_4392 >= 0);
    if (_2251 == 0) {
        goto L4; // [46] 67
    }
    if (IS_SEQUENCE(_population_4390)){
            _2253 = SEQ_PTR(_population_4390)->length;
    }
    else {
        _2253 = 1;
    }
    _2254 = (_sample_size_4391 >= _2253);
    _2253 = NOVALUE;
    if (_2254 == 0)
    {
        DeRef(_2254);
        _2254 = NOVALUE;
        goto L4; // [58] 67
    }
    else{
        DeRef(_2254);
        _2254 = NOVALUE;
    }

    /** 		sample_size = length(population)*/
    if (IS_SEQUENCE(_population_4390)){
            _sample_size_4391 = SEQ_PTR(_population_4390)->length;
    }
    else {
        _sample_size_4391 = 1;
    }
L4: 

    /** 	lResult = repeat(0, sample_size)*/
    DeRef(_lResult_4393);
    _lResult_4393 = Repeat(0, _sample_size_4391);

    /** 	lIdx = 0*/
    _lIdx_4394 = 0;

    /** 	while lIdx < sample_size do*/
L5: 
    if (_lIdx_4394 >= _sample_size_4391)
    goto L6; // [83] 130

    /** 		lChoice = rand(length(population))*/
    if (IS_SEQUENCE(_population_4390)){
            _2258 = SEQ_PTR(_population_4390)->length;
    }
    else {
        _2258 = 1;
    }
    _lChoice_4395 = good_rand() % ((unsigned)_2258) + 1;
    _2258 = NOVALUE;

    /** 		lIdx += 1*/
    _lIdx_4394 = _lIdx_4394 + 1;

    /** 		lResult[lIdx] = population[lChoice]*/
    _2 = (int)SEQ_PTR(_population_4390);
    _2261 = (int)*(((s1_ptr)_2)->base + _lChoice_4395);
    Ref(_2261);
    _2 = (int)SEQ_PTR(_lResult_4393);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lResult_4393 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lIdx_4394);
    _1 = *(int *)_2;
    *(int *)_2 = _2261;
    if( _1 != _2261 ){
        DeRef(_1);
    }
    _2261 = NOVALUE;

    /** 		if sampling_method >= 0 then*/
    if (_sampling_method_4392 < 0)
    goto L5; // [113] 83

    /** 			population = remove(population, lChoice)*/
    {
        s1_ptr assign_space = SEQ_PTR(_population_4390);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lChoice_4395)) ? _lChoice_4395 : (long)(DBL_PTR(_lChoice_4395)->dbl);
        int stop = (IS_ATOM_INT(_lChoice_4395)) ? _lChoice_4395 : (long)(DBL_PTR(_lChoice_4395)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_population_4390), start, &_population_4390 );
            }
            else Tail(SEQ_PTR(_population_4390), stop+1, &_population_4390);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_population_4390), start, &_population_4390);
        }
        else {
            assign_slice_seq = &assign_space;
            _population_4390 = Remove_elements(start, stop, (SEQ_PTR(_population_4390)->ref == 1));
        }
    }

    /** 	end while*/
    goto L5; // [127] 83
L6: 

    /** 	if sampling_method > 0 then*/
    if (_sampling_method_4392 <= 0)
    goto L7; // [132] 149

    /** 		return {lResult, population}	*/
    RefDS(_population_4390);
    RefDS(_lResult_4393);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_4393;
    ((int *)_2)[2] = _population_4390;
    _2265 = MAKE_SEQ(_1);
    DeRefDS(_population_4390);
    DeRefDS(_lResult_4393);
    DeRef(_2250);
    _2250 = NOVALUE;
    DeRef(_2251);
    _2251 = NOVALUE;
    return _2265;
    goto L8; // [146] 156
L7: 

    /** 		return lResult*/
    DeRefDS(_population_4390);
    DeRef(_2250);
    _2250 = NOVALUE;
    DeRef(_2251);
    _2251 = NOVALUE;
    DeRef(_2265);
    _2265 = NOVALUE;
    return _lResult_4393;
L8: 
    ;
}



// 0x0F94E6BB
