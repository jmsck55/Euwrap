// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _29report_error(int _err_11414)
{
    int _0, _1, _2;
    

    /** 	Look = io:EOF*/
    _29Look_11383 = -1;

    /** 	ERR = err*/
    _29ERR_11384 = _err_11414;

    /** 	ERR_LNUM = Token[TLNUM]*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _29ERR_LNUM_11385 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_29ERR_LNUM_11385))
    _29ERR_LNUM_11385 = (long)DBL_PTR(_29ERR_LNUM_11385)->dbl;

    /** 	ERR_LPOS = Token[TLPOS]*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _29ERR_LPOS_11386 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29ERR_LPOS_11386))
    _29ERR_LPOS_11386 = (long)DBL_PTR(_29ERR_LPOS_11386)->dbl;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _29error_string(int _err_11419)
{
    int _6410 = NOVALUE;
    int _6409 = NOVALUE;
    int _6408 = NOVALUE;
    int _6407 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_err_11419)) {
        _1 = (long)(DBL_PTR(_err_11419)->dbl);
        DeRefDS(_err_11419);
        _err_11419 = _1;
    }

    /** 	if err >= ERR_OPEN and err <= ERR_EOF then*/
    _6407 = (_err_11419 >= 1);
    if (_6407 == 0) {
        goto L1; // [9] 36
    }
    _6409 = (_err_11419 <= 9);
    if (_6409 == 0)
    {
        DeRef(_6409);
        _6409 = NOVALUE;
        goto L1; // [18] 36
    }
    else{
        DeRef(_6409);
        _6409 = NOVALUE;
    }

    /** 		return ERROR_STRING[err]*/
    _2 = (int)SEQ_PTR(_29ERROR_STRING_11399);
    _6410 = (int)*(((s1_ptr)_2)->base + _err_11419);
    RefDS(_6410);
    DeRef(_6407);
    _6407 = NOVALUE;
    return _6410;
    goto L2; // [33] 43
L1: 

    /** 		return ""*/
    RefDS(_5);
    DeRef(_6407);
    _6407 = NOVALUE;
    _6410 = NOVALUE;
    return _5;
L2: 
    ;
}


void  __stdcall _29keep_newlines(int _val_11431)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11431)) {
        _1 = (long)(DBL_PTR(_val_11431)->dbl);
        DeRefDS(_val_11431);
        _val_11431 = _1;
    }

    /** 	IGNORE_NEWLINES = not val*/
    _29IGNORE_NEWLINES_11426 = (_val_11431 == 0);

    /** end procedure*/
    return;
    ;
}


void  __stdcall _29keep_comments(int _val_11435)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11435)) {
        _1 = (long)(DBL_PTR(_val_11435)->dbl);
        DeRefDS(_val_11435);
        _val_11435 = _1;
    }

    /** 	IGNORE_COMMENTS = not val*/
    _29IGNORE_COMMENTS_11427 = (_val_11435 == 0);

    /** end procedure*/
    return;
    ;
}


void  __stdcall _29string_numbers(int _val_11439)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11439)) {
        _1 = (long)(DBL_PTR(_val_11439)->dbl);
        DeRefDS(_val_11439);
        _val_11439 = _1;
    }

    /** 	STRING_NUMBERS = val*/
    _29STRING_NUMBERS_11428 = _val_11439;

    /** end procedure*/
    return;
    ;
}


int _29White_Char(int _c_11442)
{
    int _6417 = NOVALUE;
    int _6416 = NOVALUE;
    int _6415 = NOVALUE;
    int _6414 = NOVALUE;
    int _6413 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (c >= 0) and (c <= ' ')*/
    _6413 = 1;
    _6414 = (_c_11442 >= 0);
    _6415 = (_6413 != 0 && _6414 != 0);
    _6413 = NOVALUE;
    _6414 = NOVALUE;
    _6416 = (_c_11442 <= 32);
    _6417 = (_6415 != 0 && _6416 != 0);
    _6415 = NOVALUE;
    _6416 = NOVALUE;
    return _6417;
    ;
}


int _29Digit_Char(int _c_11450)
{
    int _6424 = NOVALUE;
    int _6423 = NOVALUE;
    int _6422 = NOVALUE;
    int _6421 = NOVALUE;
    int _6420 = NOVALUE;
    int _6419 = NOVALUE;
    int _6418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ((('0' <= c) and (c <= '9')) or (c = '_'))*/
    _6418 = 1;
    _6419 = (48 <= _c_11450);
    _6420 = (_c_11450 <= 57);
    _6421 = (_6419 != 0 && _6420 != 0);
    _6419 = NOVALUE;
    _6420 = NOVALUE;
    _6422 = (_c_11450 == 95);
    _6423 = (_6421 != 0 || _6422 != 0);
    _6421 = NOVALUE;
    _6422 = NOVALUE;
    _6424 = (_6418 != 0 && _6423 != 0);
    _6418 = NOVALUE;
    _6423 = NOVALUE;
    return _6424;
    ;
}


int _29uHex_Char(int _c_11460)
{
    int _6429 = NOVALUE;
    int _6428 = NOVALUE;
    int _6427 = NOVALUE;
    int _6426 = NOVALUE;
    int _6425 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('A' <= c) and (c <= 'F')*/
    _6425 = 1;
    _6426 = (65 <= _c_11460);
    _6427 = (_6425 != 0 && _6426 != 0);
    _6425 = NOVALUE;
    _6426 = NOVALUE;
    _6428 = (_c_11460 <= 70);
    _6429 = (_6427 != 0 && _6428 != 0);
    _6427 = NOVALUE;
    _6428 = NOVALUE;
    return _6429;
    ;
}


int _29lHex_Char(int _c_11468)
{
    int _6434 = NOVALUE;
    int _6433 = NOVALUE;
    int _6432 = NOVALUE;
    int _6431 = NOVALUE;
    int _6430 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('a' <= c) and (c <= 'f')*/
    _6430 = 1;
    _6431 = (97 <= _c_11468);
    _6432 = (_6430 != 0 && _6431 != 0);
    _6430 = NOVALUE;
    _6431 = NOVALUE;
    _6433 = (_c_11468 <= 102);
    _6434 = (_6432 != 0 && _6433 != 0);
    _6432 = NOVALUE;
    _6433 = NOVALUE;
    return _6434;
    ;
}


int _29Hex_Char(int _c_11476)
{
    int _6441 = NOVALUE;
    int _6440 = NOVALUE;
    int _6439 = NOVALUE;
    int _6438 = NOVALUE;
    int _6437 = NOVALUE;
    int _6436 = NOVALUE;
    int _6435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (Digit_Char(c) or uHex_Char(c) or lHex_Char(c))*/
    _6435 = 1;
    _6436 = _29Digit_Char(_c_11476);
    _6437 = _29uHex_Char(_c_11476);
    if (IS_ATOM_INT(_6436) && IS_ATOM_INT(_6437)) {
        _6438 = (_6436 != 0 || _6437 != 0);
    }
    else {
        _6438 = binary_op(OR, _6436, _6437);
    }
    DeRef(_6436);
    _6436 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    _6439 = _29lHex_Char(_c_11476);
    if (IS_ATOM_INT(_6438) && IS_ATOM_INT(_6439)) {
        _6440 = (_6438 != 0 || _6439 != 0);
    }
    else {
        _6440 = binary_op(OR, _6438, _6439);
    }
    DeRef(_6438);
    _6438 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    if (IS_ATOM_INT(_6440)) {
        _6441 = (_6435 != 0 && _6440 != 0);
    }
    else {
        _6441 = binary_op(AND, _6435, _6440);
    }
    _6435 = NOVALUE;
    DeRef(_6440);
    _6440 = NOVALUE;
    return _6441;
    ;
}


int _29uAlpha_Char(int _c_11486)
{
    int _6446 = NOVALUE;
    int _6445 = NOVALUE;
    int _6444 = NOVALUE;
    int _6443 = NOVALUE;
    int _6442 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('A' <= c) and (c <= 'Z')*/
    _6442 = 1;
    _6443 = (65 <= _c_11486);
    _6444 = (_6442 != 0 && _6443 != 0);
    _6442 = NOVALUE;
    _6443 = NOVALUE;
    _6445 = (_c_11486 <= 90);
    _6446 = (_6444 != 0 && _6445 != 0);
    _6444 = NOVALUE;
    _6445 = NOVALUE;
    return _6446;
    ;
}


int _29lAlpha_Char(int _c_11494)
{
    int _6451 = NOVALUE;
    int _6450 = NOVALUE;
    int _6449 = NOVALUE;
    int _6448 = NOVALUE;
    int _6447 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('a' <= c) and (c <= 'z')*/
    _6447 = 1;
    _6448 = (97 <= _c_11494);
    _6449 = (_6447 != 0 && _6448 != 0);
    _6447 = NOVALUE;
    _6448 = NOVALUE;
    _6450 = (_c_11494 <= 122);
    _6451 = (_6449 != 0 && _6450 != 0);
    _6449 = NOVALUE;
    _6450 = NOVALUE;
    return _6451;
    ;
}


int _29Alpha_Char(int _c_11502)
{
    int _6456 = NOVALUE;
    int _6455 = NOVALUE;
    int _6454 = NOVALUE;
    int _6453 = NOVALUE;
    int _6452 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (uAlpha_Char(c) or lAlpha_Char(c))*/
    _6452 = 1;
    _6453 = _29uAlpha_Char(_c_11502);
    _6454 = _29lAlpha_Char(_c_11502);
    if (IS_ATOM_INT(_6453) && IS_ATOM_INT(_6454)) {
        _6455 = (_6453 != 0 || _6454 != 0);
    }
    else {
        _6455 = binary_op(OR, _6453, _6454);
    }
    DeRef(_6453);
    _6453 = NOVALUE;
    DeRef(_6454);
    _6454 = NOVALUE;
    if (IS_ATOM_INT(_6455)) {
        _6456 = (_6452 != 0 && _6455 != 0);
    }
    else {
        _6456 = binary_op(AND, _6452, _6455);
    }
    _6452 = NOVALUE;
    DeRef(_6455);
    _6455 = NOVALUE;
    return _6456;
    ;
}


int _29Alphanum_Char(int _c_11510)
{
    int _6461 = NOVALUE;
    int _6460 = NOVALUE;
    int _6459 = NOVALUE;
    int _6458 = NOVALUE;
    int _6457 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (Alpha_Char(c) or Digit_Char(c))*/
    _6457 = 1;
    _6458 = _29Alpha_Char(_c_11510);
    _6459 = _29Digit_Char(_c_11510);
    if (IS_ATOM_INT(_6458) && IS_ATOM_INT(_6459)) {
        _6460 = (_6458 != 0 || _6459 != 0);
    }
    else {
        _6460 = binary_op(OR, _6458, _6459);
    }
    DeRef(_6458);
    _6458 = NOVALUE;
    DeRef(_6459);
    _6459 = NOVALUE;
    if (IS_ATOM_INT(_6460)) {
        _6461 = (_6457 != 0 && _6460 != 0);
    }
    else {
        _6461 = binary_op(AND, _6457, _6460);
    }
    _6457 = NOVALUE;
    DeRef(_6460);
    _6460 = NOVALUE;
    return _6461;
    ;
}


int _29Identifier_Char(int _c_11518)
{
    int _6462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return Alphanum_Char(c)*/
    _6462 = _29Alphanum_Char(_c_11518);
    return _6462;
    ;
}


void _29scan_char()
{
    int _6470 = NOVALUE;
    int _6466 = NOVALUE;
    int _6465 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Look = EOL then*/
    if (_29Look_11383 != 10)
    goto L1; // [5] 57

    /** 		LNum += 1*/
    _29LNum_11381 = _29LNum_11381 + 1;

    /** 		LPos = 0*/
    _29LPos_11382 = 0;

    /** 		if length(Token[TDATA]) = 0 then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6465 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6465)){
            _6466 = SEQ_PTR(_6465)->length;
    }
    else {
        _6466 = 1;
    }
    _6465 = NOVALUE;
    if (_6466 != 0)
    goto L2; // [33] 56

    /** 			Token[TLNUM] = LNum*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29LNum_11381;
    DeRef(_1);

    /** 			Token[TLPOS] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L2: 
L1: 

    /** 	LPos += 1*/
    _29LPos_11382 = _29LPos_11382 + 1;

    /** 	sti += 1*/
    _29sti_11380 = _29sti_11380 + 1;

    /** 	if sti > length(source_text) then*/
    if (IS_SEQUENCE(_29source_text_11379)){
            _6470 = SEQ_PTR(_29source_text_11379)->length;
    }
    else {
        _6470 = 1;
    }
    if (_29sti_11380 <= _6470)
    goto L3; // [82] 94

    /** 		Look = io:EOF*/
    _29Look_11383 = -1;
    goto L4; // [91] 105
L3: 

    /** 		Look = source_text[sti]*/
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _29Look_11383 = (int)*(((s1_ptr)_2)->base + _29sti_11380);
    if (!IS_ATOM_INT(_29Look_11383))
    _29Look_11383 = (long)DBL_PTR(_29Look_11383)->dbl;
L4: 

    /** end procedure*/
    _6465 = NOVALUE;
    return;
    ;
}


int _29lookahead(int _dist_11538)
{
    int _6477 = NOVALUE;
    int _6476 = NOVALUE;
    int _6474 = NOVALUE;
    int _6473 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sti + dist <= length(source_text) then*/
    _6473 = _29sti_11380 + _dist_11538;
    if ((long)((unsigned long)_6473 + (unsigned long)HIGH_BITS) >= 0) 
    _6473 = NewDouble((double)_6473);
    if (IS_SEQUENCE(_29source_text_11379)){
            _6474 = SEQ_PTR(_29source_text_11379)->length;
    }
    else {
        _6474 = 1;
    }
    if (binary_op_a(GREATER, _6473, _6474)){
        DeRef(_6473);
        _6473 = NOVALUE;
        _6474 = NOVALUE;
        goto L1; // [16] 41
    }
    DeRef(_6473);
    _6473 = NOVALUE;
    _6474 = NOVALUE;

    /** 		return source_text[sti + dist]*/
    _6476 = _29sti_11380 + _dist_11538;
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _6477 = (int)*(((s1_ptr)_2)->base + _6476);
    Ref(_6477);
    _6476 = NOVALUE;
    return _6477;
    goto L2; // [38] 48
L1: 

    /** 		return io:EOF*/
    DeRef(_6476);
    _6476 = NOVALUE;
    _6477 = NOVALUE;
    return -1;
L2: 
    ;
}


int _29scan_white()
{
    int _6478 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TTYPE] = T_NEWLINE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	while White_Char(Look) do*/
L1: 
    _6478 = _29White_Char(_29Look_11383);
    if (_6478 <= 0) {
        if (_6478 == 0) {
            DeRef(_6478);
            _6478 = NOVALUE;
            goto L2; // [28] 55
        }
        else {
            if (!IS_ATOM_INT(_6478) && DBL_PTR(_6478)->dbl == 0.0){
                DeRef(_6478);
                _6478 = NOVALUE;
                goto L2; // [28] 55
            }
            DeRef(_6478);
            _6478 = NOVALUE;
        }
    }
    DeRef(_6478);
    _6478 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		if Look = EOL then*/
    if (_29Look_11383 != 10)
    goto L1; // [39] 22

    /** 			return TRUE*/
    return 1;

    /** 	end while*/
    goto L1; // [52] 22
L2: 

    /** 	return FALSE*/
    return 0;
    ;
}


int _29scan_multicomment()
{
    int _6489 = NOVALUE;
    int _6488 = NOVALUE;
    int _6487 = NOVALUE;
    int _6486 = NOVALUE;
    int _6485 = NOVALUE;
    int _6484 = NOVALUE;
    int _6483 = NOVALUE;
    int _6482 = NOVALUE;
    int _6481 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TTYPE] = T_COMMENT*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 	Token[TDATA] = "/"*/
    RefDS(_3806);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3806;
    DeRef(_1);

    /** 	Token[TFORM] = TF_COMMENT_MULTIPLE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	while 1 do*/
L1: 

    /** 		if (Look = io:EOF) then*/
    if (_29Look_11383 != -1)
    goto L2; // [34] 50

    /** 			report_error(ERR_EOF)*/
    _29report_error(9);

    /** 			return TRUE */
    return 1;
L2: 

    /** 		if (Look = '*') and source_text[sti + 1] = '/' then*/
    _6481 = (_29Look_11383 == 42);
    if (_6481 == 0) {
        goto L3; // [58] 111
    }
    _6483 = _29sti_11380 + 1;
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _6484 = (int)*(((s1_ptr)_2)->base + _6483);
    if (IS_ATOM_INT(_6484)) {
        _6485 = (_6484 == 47);
    }
    else {
        _6485 = binary_op(EQUALS, _6484, 47);
    }
    _6484 = NOVALUE;
    if (_6485 == 0) {
        DeRef(_6485);
        _6485 = NOVALUE;
        goto L3; // [79] 111
    }
    else {
        if (!IS_ATOM_INT(_6485) && DBL_PTR(_6485)->dbl == 0.0){
            DeRef(_6485);
            _6485 = NOVALUE;
            goto L3; // [79] 111
        }
        DeRef(_6485);
        _6485 = NOVALUE;
    }
    DeRef(_6485);
    _6485 = NOVALUE;

    //			Token[TDATA] &= "*/"
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6486 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6486) && IS_ATOM(_6313)) {
    }
    else if (IS_ATOM(_6486) && IS_SEQUENCE(_6313)) {
        Ref(_6486);
        Prepend(&_6487, _6313, _6486);
    }
    else {
        Concat((object_ptr)&_6487, _6486, _6313);
        _6486 = NOVALUE;
    }
    _6486 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6487;
    if( _1 != _6487 ){
        DeRef(_1);
    }
    _6487 = NOVALUE;

    //			scan_char() -- skip the */
    _29scan_char();

    /** 			scan_char()*/
    _29scan_char();

    /** 			exit*/
    goto L4; // [108] 138
L3: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6488 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6488) && IS_ATOM(_29Look_11383)) {
        Append(&_6489, _6488, _29Look_11383);
    }
    else if (IS_ATOM(_6488) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6489, _6488, _29Look_11383);
        _6488 = NOVALUE;
    }
    _6488 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6489;
    if( _1 != _6489 ){
        DeRef(_1);
    }
    _6489 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L1; // [135] 30
L4: 

    /** 	return TRUE*/
    DeRef(_6481);
    _6481 = NOVALUE;
    DeRef(_6483);
    _6483 = NOVALUE;
    return 1;
    ;
}


void _29scan_escaped_char()
{
    int _f_11571 = NOVALUE;
    int _6497 = NOVALUE;
    int _6496 = NOVALUE;
    int _6492 = NOVALUE;
    int _6491 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6491 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6491) && IS_ATOM(_29Look_11383)) {
        Append(&_6492, _6491, _29Look_11383);
    }
    else if (IS_ATOM(_6491) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6492, _6491, _29Look_11383);
        _6491 = NOVALUE;
    }
    _6491 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6492;
    if( _1 != _6492 ){
        DeRef(_1);
    }
    _6492 = NOVALUE;

    /** 	if (Look = '\\') then*/
    if (_29Look_11383 != 92)
    goto L1; // [23] 71

    /** 		scan_char()*/
    _29scan_char();

    /** 		f = find(Look,QFLAGS)*/
    _f_11571 = find_from(_29Look_11383, _29QFLAGS_11567, 1);

    /** 		if not f then report_error(ERR_ESCAPE) return end if*/
    if (_f_11571 != 0)
    goto L2; // [42] 52
    _29report_error(2);
    return;
L2: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6496 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6496) && IS_ATOM(_29Look_11383)) {
        Append(&_6497, _6496, _29Look_11383);
    }
    else if (IS_ATOM(_6496) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6497, _6496, _29Look_11383);
        _6496 = NOVALUE;
    }
    _6496 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6497;
    if( _1 != _6497 ){
        DeRef(_1);
    }
    _6497 = NOVALUE;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** end procedure*/
    return;
    ;
}


int _29scan_qchar()
{
    int _0, _1, _2;
    

    /** 	if (Look != '\'') then return FALSE end if*/
    if (_29Look_11383 == 39)
    goto L1; // [5] 14
    return 0;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	Token[TTYPE] = T_CHAR*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 7;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	if (Look = EOL) then report_error(ERR_EOL_CHAR) return TRUE end if*/
    if (_29Look_11383 != 10)
    goto L2; // [38] 50
    _29report_error(3);
    return 1;
L2: 

    /** 	scan_escaped_char()*/
    _29scan_escaped_char();

    /** 	if ERR then return 1 end if*/
    if (_29ERR_11384 == 0)
    {
        goto L3; // [58] 66
    }
    else{
    }
    return 1;
L3: 

    /** 	if (Look != '\'') then report_error(ERR_CLOSE_CHAR) return TRUE end if*/
    if (_29Look_11383 == 39)
    goto L4; // [70] 82
    _29report_error(4);
    return 1;
L4: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    return 1;
    ;
}


int _29scan_string()
{
    int _6521 = NOVALUE;
    int _6520 = NOVALUE;
    int _6519 = NOVALUE;
    int _6518 = NOVALUE;
    int _6516 = NOVALUE;
    int _6515 = NOVALUE;
    int _6514 = NOVALUE;
    int _6513 = NOVALUE;
    int _6512 = NOVALUE;
    int _6511 = NOVALUE;
    int _6510 = NOVALUE;
    int _6509 = NOVALUE;
    int _6507 = NOVALUE;
    int _6506 = NOVALUE;
    int _6505 = NOVALUE;
    int _6503 = NOVALUE;
    int _6502 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '"') then */
    if (_29Look_11383 == 34)
    goto L1; // [5] 16

    /** 		return FALSE */
    return 0;
L1: 

    /** 	if sti + 3 < length(source_text) then*/
    _6502 = _29sti_11380 + 3;
    if ((long)((unsigned long)_6502 + (unsigned long)HIGH_BITS) >= 0) 
    _6502 = NewDouble((double)_6502);
    if (IS_SEQUENCE(_29source_text_11379)){
            _6503 = SEQ_PTR(_29source_text_11379)->length;
    }
    else {
        _6503 = 1;
    }
    if (binary_op_a(GREATEREQ, _6502, _6503)){
        DeRef(_6502);
        _6502 = NOVALUE;
        _6503 = NOVALUE;
        goto L2; // [29] 239
    }
    DeRef(_6502);
    _6502 = NOVALUE;
    _6503 = NOVALUE;

    /** 		if equal(source_text[sti .. sti + 2], "\"\"\"") then*/
    _6505 = _29sti_11380 + 2;
    rhs_slice_target = (object_ptr)&_6506;
    RHS_Slice(_29source_text_11379, _29sti_11380, _6505);
    if (_6506 == _6353)
    _6507 = 1;
    else if (IS_ATOM_INT(_6506) && IS_ATOM_INT(_6353))
    _6507 = 0;
    else
    _6507 = (compare(_6506, _6353) == 0);
    DeRefDS(_6506);
    _6506 = NOVALUE;
    if (_6507 == 0)
    {
        _6507 = NOVALUE;
        goto L3; // [54] 238
    }
    else{
        _6507 = NOVALUE;
    }

    /** 			Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 			Token[TFORM] = TF_STRING_TRIPLE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 			sti += 2*/
    _29sti_11380 = _29sti_11380 + 2;

    /** 			scan_char()*/
    _29scan_char();

    /** 			while (sti < length(source_text) - 2) and*/
L4: 
    if (IS_SEQUENCE(_29source_text_11379)){
            _6509 = SEQ_PTR(_29source_text_11379)->length;
    }
    else {
        _6509 = 1;
    }
    _6510 = _6509 - 2;
    _6509 = NOVALUE;
    _6511 = (_29sti_11380 < _6510);
    _6510 = NOVALUE;
    if (_6511 == 0) {
        goto L5; // [113] 190
    }
    _6513 = _29sti_11380 + 2;
    rhs_slice_target = (object_ptr)&_6514;
    RHS_Slice(_29source_text_11379, _29sti_11380, _6513);
    if (_6514 == _6353)
    _6515 = 1;
    else if (IS_ATOM_INT(_6514) && IS_ATOM_INT(_6353))
    _6515 = 0;
    else
    _6515 = (compare(_6514, _6353) == 0);
    DeRefDS(_6514);
    _6514 = NOVALUE;
    _6516 = (_6515 == 0);
    _6515 = NOVALUE;
    if (_6516 == 0)
    {
        DeRef(_6516);
        _6516 = NOVALUE;
        goto L5; // [140] 190
    }
    else{
        DeRef(_6516);
        _6516 = NOVALUE;
    }

    /** 				if (Look = io:EOF) then*/
    if (_29Look_11383 != -1)
    goto L6; // [147] 163

    /** 					report_error(ERR_EOF)*/
    _29report_error(9);

    /** 					return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    return 1;
L6: 

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6518 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6518) && IS_ATOM(_29Look_11383)) {
        Append(&_6519, _6518, _29Look_11383);
    }
    else if (IS_ATOM(_6518) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6519, _6518, _29Look_11383);
        _6518 = NOVALUE;
    }
    _6518 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6519;
    if( _1 != _6519 ){
        DeRef(_1);
    }
    _6519 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L4; // [187] 98
L5: 

    /** 			if sti > length(source_text) - 2 then*/
    if (IS_SEQUENCE(_29source_text_11379)){
            _6520 = SEQ_PTR(_29source_text_11379)->length;
    }
    else {
        _6520 = 1;
    }
    _6521 = _6520 - 2;
    _6520 = NOVALUE;
    if (_29sti_11380 <= _6521)
    goto L7; // [203] 219

    /** 				report_error(ERR_EOF)*/
    _29report_error(9);

    /** 				return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    _6521 = NOVALUE;
    return 1;
L7: 

    /** 			sti += 2*/
    _29sti_11380 = _29sti_11380 + 2;

    /** 			scan_char()*/
    _29scan_char();

    /** 			return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6521);
    _6521 = NOVALUE;
    return 1;
L3: 
L2: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TFORM] = TF_STRING_SINGLE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 	while (Look != '"') do*/
L8: 
    if (_29Look_11383 == 34)
    goto L9; // [274] 321

    /** 		if (Look = EOL) then */
    if (_29Look_11383 != 10)
    goto LA; // [282] 298

    /** 			report_error(ERR_EOL_STRING) */
    _29report_error(5);

    /** 			return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6521);
    _6521 = NOVALUE;
    return 1;
LA: 

    /** 		scan_escaped_char()*/
    _29scan_escaped_char();

    /** 		if ERR then */
    if (_29ERR_11384 == 0)
    {
        goto L8; // [306] 272
    }
    else{
    }

    /** 			return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6521);
    _6521 = NOVALUE;
    return 1;

    /** 	end while*/
    goto L8; // [318] 272
L9: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    DeRef(_6505);
    _6505 = NOVALUE;
    DeRef(_6513);
    _6513 = NOVALUE;
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6521);
    _6521 = NOVALUE;
    return 1;
    ;
}


int _29scan_multistring()
{
    int _end_of_string_11628 = NOVALUE;
    int _6530 = NOVALUE;
    int _6529 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '`') then*/
    if (_29Look_11383 == 96)
    goto L1; // [5] 16

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	end_of_string = '`'*/
    _end_of_string_11628 = 96;

    /** 	Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TFORM] = TF_STRING_BACKTICK*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	while (Look != end_of_string) do*/
L2: 
    if (_29Look_11383 == _end_of_string_11628)
    goto L3; // [56] 107

    /** 		if (Look = io:EOF) then*/
    if (_29Look_11383 != -1)
    goto L4; // [64] 80

    /** 			report_error(ERR_EOF)*/
    _29report_error(9);

    /** 			return TRUE*/
    return 1;
L4: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6529 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6529) && IS_ATOM(_29Look_11383)) {
        Append(&_6530, _6529, _29Look_11383);
    }
    else if (IS_ATOM(_6529) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6530, _6529, _29Look_11383);
        _6529 = NOVALUE;
    }
    _6529 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6530;
    if( _1 != _6530 ){
        DeRef(_1);
    }
    _6530 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L2; // [104] 54
L3: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    return 1;
    ;
}


int _29hex_val(int _h_11639)
{
    int _6537 = NOVALUE;
    int _6536 = NOVALUE;
    int _6535 = NOVALUE;
    int _6533 = NOVALUE;
    int _6532 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if h >= 'a' then*/
    if (_h_11639 < 97)
    goto L1; // [5] 26

    /** 		return h - 'a' + 10*/
    _6532 = _h_11639 - 97;
    if ((long)((unsigned long)_6532 +(unsigned long) HIGH_BITS) >= 0){
        _6532 = NewDouble((double)_6532);
    }
    if (IS_ATOM_INT(_6532)) {
        _6533 = _6532 + 10;
        if ((long)((unsigned long)_6533 + (unsigned long)HIGH_BITS) >= 0) 
        _6533 = NewDouble((double)_6533);
    }
    else {
        _6533 = NewDouble(DBL_PTR(_6532)->dbl + (double)10);
    }
    DeRef(_6532);
    _6532 = NOVALUE;
    return _6533;
    goto L2; // [23] 60
L1: 

    /** 	elsif h >= 'A' then*/
    if (_h_11639 < 65)
    goto L3; // [28] 49

    /** 		return h - 'A' + 10*/
    _6535 = _h_11639 - 65;
    if ((long)((unsigned long)_6535 +(unsigned long) HIGH_BITS) >= 0){
        _6535 = NewDouble((double)_6535);
    }
    if (IS_ATOM_INT(_6535)) {
        _6536 = _6535 + 10;
        if ((long)((unsigned long)_6536 + (unsigned long)HIGH_BITS) >= 0) 
        _6536 = NewDouble((double)_6536);
    }
    else {
        _6536 = NewDouble(DBL_PTR(_6535)->dbl + (double)10);
    }
    DeRef(_6535);
    _6535 = NOVALUE;
    DeRef(_6533);
    _6533 = NOVALUE;
    return _6536;
    goto L2; // [46] 60
L3: 

    /** 		return h - '0'*/
    _6537 = _h_11639 - 48;
    if ((long)((unsigned long)_6537 +(unsigned long) HIGH_BITS) >= 0){
        _6537 = NewDouble((double)_6537);
    }
    DeRef(_6533);
    _6533 = NOVALUE;
    DeRef(_6536);
    _6536 = NOVALUE;
    return _6537;
L2: 
    ;
}


int _29scan_hex()
{
    int _startSti_11654 = NOVALUE;
    int _6550 = NOVALUE;
    int _6549 = NOVALUE;
    int _6548 = NOVALUE;
    int _6547 = NOVALUE;
    int _6545 = NOVALUE;
    int _6544 = NOVALUE;
    int _6543 = NOVALUE;
    int _6542 = NOVALUE;
    int _6541 = NOVALUE;
    int _6539 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '#') then*/
    if (_29Look_11383 == 35)
    goto L1; // [5] 16

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	integer startSti = sti*/
    _startSti_11654 = _29sti_11380;

    /** 	scan_char()*/
    _29scan_char();

    /** 	if not Hex_Char(Look) then*/
    _6539 = _29Hex_Char(_29Look_11383);
    if (IS_ATOM_INT(_6539)) {
        if (_6539 != 0){
            DeRef(_6539);
            _6539 = NOVALUE;
            goto L2; // [35] 48
        }
    }
    else {
        if (DBL_PTR(_6539)->dbl != 0.0){
            DeRef(_6539);
            _6539 = NOVALUE;
            goto L2; // [35] 48
        }
    }
    DeRef(_6539);
    _6539 = NOVALUE;

    /** 		report_error(ERR_HEX) return TRUE*/
    _29report_error(6);
    return 1;
L2: 

    /** 	Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	Token[TFORM] = TF_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11428 == 0)
    {
        goto L3; // [68] 118
    }
    else{
    }

    /** 		while Hex_Char(Look) do*/
L4: 
    _6541 = _29Hex_Char(_29Look_11383);
    if (_6541 <= 0) {
        if (_6541 == 0) {
            DeRef(_6541);
            _6541 = NOVALUE;
            goto L5; // [82] 94
        }
        else {
            if (!IS_ATOM_INT(_6541) && DBL_PTR(_6541)->dbl == 0.0){
                DeRef(_6541);
                _6541 = NOVALUE;
                goto L5; // [82] 94
            }
            DeRef(_6541);
            _6541 = NOVALUE;
        }
    }
    DeRef(_6541);
    _6541 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L4; // [91] 76
L5: 

    /** 		Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6542 = _29sti_11380 - 1;
    rhs_slice_target = (object_ptr)&_6543;
    RHS_Slice(_29source_text_11379, _startSti_11654, _6542);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6543;
    if( _1 != _6543 ){
        DeRef(_1);
    }
    _6543 = NOVALUE;
    goto L6; // [115] 197
L3: 

    /** 		Token[TDATA] = hex_val(Look)*/
    _6544 = _29hex_val(_29Look_11383);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6544;
    if( _1 != _6544 ){
        DeRef(_1);
    }
    _6544 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		while Hex_Char(Look) do*/
L7: 
    _6545 = _29Hex_Char(_29Look_11383);
    if (_6545 <= 0) {
        if (_6545 == 0) {
            DeRef(_6545);
            _6545 = NOVALUE;
            goto L8; // [147] 196
        }
        else {
            if (!IS_ATOM_INT(_6545) && DBL_PTR(_6545)->dbl == 0.0){
                DeRef(_6545);
                _6545 = NOVALUE;
                goto L8; // [147] 196
            }
            DeRef(_6545);
            _6545 = NOVALUE;
        }
    }
    DeRef(_6545);
    _6545 = NOVALUE;

    /** 			if Look != '_' then*/
    if (_29Look_11383 == 95)
    goto L9; // [154] 187

    /** 				Token[TDATA] = Token[TDATA] * 16 + hex_val(Look)*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6547 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6547)) {
        if (_6547 == (short)_6547)
        _6548 = _6547 * 16;
        else
        _6548 = NewDouble(_6547 * (double)16);
    }
    else {
        _6548 = binary_op(MULTIPLY, _6547, 16);
    }
    _6547 = NOVALUE;
    _6549 = _29hex_val(_29Look_11383);
    if (IS_ATOM_INT(_6548) && IS_ATOM_INT(_6549)) {
        _6550 = _6548 + _6549;
        if ((long)((unsigned long)_6550 + (unsigned long)HIGH_BITS) >= 0) 
        _6550 = NewDouble((double)_6550);
    }
    else {
        _6550 = binary_op(PLUS, _6548, _6549);
    }
    DeRef(_6548);
    _6548 = NOVALUE;
    DeRef(_6549);
    _6549 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6550;
    if( _1 != _6550 ){
        DeRef(_1);
    }
    _6550 = NOVALUE;
L9: 

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L7; // [193] 141
L8: 
L6: 

    /** 	return TRUE*/
    DeRef(_6542);
    _6542 = NOVALUE;
    return 1;
    ;
}


int _29scan_integer()
{
    int _i_11676 = NOVALUE;
    int _6554 = NOVALUE;
    int _6553 = NOVALUE;
    int _6551 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom i = 0*/
    DeRef(_i_11676);
    _i_11676 = 0;

    /** 	while Digit_Char(Look) do*/
L1: 
    _6551 = _29Digit_Char(_29Look_11383);
    if (_6551 <= 0) {
        if (_6551 == 0) {
            DeRef(_6551);
            _6551 = NOVALUE;
            goto L2; // [17] 54
        }
        else {
            if (!IS_ATOM_INT(_6551) && DBL_PTR(_6551)->dbl == 0.0){
                DeRef(_6551);
                _6551 = NOVALUE;
                goto L2; // [17] 54
            }
            DeRef(_6551);
            _6551 = NOVALUE;
        }
    }
    DeRef(_6551);
    _6551 = NOVALUE;

    /** 		if (Look != '_') then*/
    if (_29Look_11383 == 95)
    goto L3; // [24] 45

    /** 			i = (i * 10) + (Look - '0')*/
    if (IS_ATOM_INT(_i_11676)) {
        if (_i_11676 == (short)_i_11676)
        _6553 = _i_11676 * 10;
        else
        _6553 = NewDouble(_i_11676 * (double)10);
    }
    else {
        _6553 = NewDouble(DBL_PTR(_i_11676)->dbl * (double)10);
    }
    _6554 = _29Look_11383 - 48;
    if ((long)((unsigned long)_6554 +(unsigned long) HIGH_BITS) >= 0){
        _6554 = NewDouble((double)_6554);
    }
    DeRef(_i_11676);
    if (IS_ATOM_INT(_6553) && IS_ATOM_INT(_6554)) {
        _i_11676 = _6553 + _6554;
        if ((long)((unsigned long)_i_11676 + (unsigned long)HIGH_BITS) >= 0) 
        _i_11676 = NewDouble((double)_i_11676);
    }
    else {
        if (IS_ATOM_INT(_6553)) {
            _i_11676 = NewDouble((double)_6553 + DBL_PTR(_6554)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6554)) {
                _i_11676 = NewDouble(DBL_PTR(_6553)->dbl + (double)_6554);
            }
            else
            _i_11676 = NewDouble(DBL_PTR(_6553)->dbl + DBL_PTR(_6554)->dbl);
        }
    }
    DeRef(_6553);
    _6553 = NOVALUE;
    DeRef(_6554);
    _6554 = NOVALUE;
L3: 

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L1; // [51] 11
L2: 

    /** 	return i*/
    return _i_11676;
    ;
}


int _29scan_fraction(int _v_11686)
{
    int _d_11690 = NOVALUE;
    int _6561 = NOVALUE;
    int _6560 = NOVALUE;
    int _6558 = NOVALUE;
    int _6556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Digit_Char(Look) then report_error(ERR_DECIMAL) return 0 end if*/
    _6556 = _29Digit_Char(_29Look_11383);
    if (IS_ATOM_INT(_6556)) {
        if (_6556 != 0){
            DeRef(_6556);
            _6556 = NOVALUE;
            goto L1; // [9] 20
        }
    }
    else {
        if (DBL_PTR(_6556)->dbl != 0.0){
            DeRef(_6556);
            _6556 = NOVALUE;
            goto L1; // [9] 20
        }
    }
    DeRef(_6556);
    _6556 = NOVALUE;
    _29report_error(7);
    DeRef(_v_11686);
    DeRef(_d_11690);
    return 0;
L1: 

    /** 	atom d = 10*/
    DeRef(_d_11690);
    _d_11690 = 10;

    /** 	while Digit_Char(Look) do*/
L2: 
    _6558 = _29Digit_Char(_29Look_11383);
    if (_6558 <= 0) {
        if (_6558 == 0) {
            DeRef(_6558);
            _6558 = NOVALUE;
            goto L3; // [36] 79
        }
        else {
            if (!IS_ATOM_INT(_6558) && DBL_PTR(_6558)->dbl == 0.0){
                DeRef(_6558);
                _6558 = NOVALUE;
                goto L3; // [36] 79
            }
            DeRef(_6558);
            _6558 = NOVALUE;
        }
    }
    DeRef(_6558);
    _6558 = NOVALUE;

    /** 		if Look != '_' then*/
    if (_29Look_11383 == 95)
    goto L4; // [43] 70

    /** 			v += (Look - '0') / d*/
    _6560 = _29Look_11383 - 48;
    if ((long)((unsigned long)_6560 +(unsigned long) HIGH_BITS) >= 0){
        _6560 = NewDouble((double)_6560);
    }
    if (IS_ATOM_INT(_6560) && IS_ATOM_INT(_d_11690)) {
        _6561 = (_6560 % _d_11690) ? NewDouble((double)_6560 / _d_11690) : (_6560 / _d_11690);
    }
    else {
        if (IS_ATOM_INT(_6560)) {
            _6561 = NewDouble((double)_6560 / DBL_PTR(_d_11690)->dbl);
        }
        else {
            if (IS_ATOM_INT(_d_11690)) {
                _6561 = NewDouble(DBL_PTR(_6560)->dbl / (double)_d_11690);
            }
            else
            _6561 = NewDouble(DBL_PTR(_6560)->dbl / DBL_PTR(_d_11690)->dbl);
        }
    }
    DeRef(_6560);
    _6560 = NOVALUE;
    _0 = _v_11686;
    if (IS_ATOM_INT(_v_11686) && IS_ATOM_INT(_6561)) {
        _v_11686 = _v_11686 + _6561;
        if ((long)((unsigned long)_v_11686 + (unsigned long)HIGH_BITS) >= 0) 
        _v_11686 = NewDouble((double)_v_11686);
    }
    else {
        if (IS_ATOM_INT(_v_11686)) {
            _v_11686 = NewDouble((double)_v_11686 + DBL_PTR(_6561)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6561)) {
                _v_11686 = NewDouble(DBL_PTR(_v_11686)->dbl + (double)_6561);
            }
            else
            _v_11686 = NewDouble(DBL_PTR(_v_11686)->dbl + DBL_PTR(_6561)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6561);
    _6561 = NOVALUE;

    /** 			d *= 10*/
    _0 = _d_11690;
    if (IS_ATOM_INT(_d_11690)) {
        if (_d_11690 == (short)_d_11690)
        _d_11690 = _d_11690 * 10;
        else
        _d_11690 = NewDouble(_d_11690 * (double)10);
    }
    else {
        _d_11690 = NewDouble(DBL_PTR(_d_11690)->dbl * (double)10);
    }
    DeRef(_0);
L4: 

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L2; // [76] 30
L3: 

    /** 	return v*/
    DeRef(_d_11690);
    return _v_11686;
    ;
}


int _29scan_exponent(int _v_11701)
{
    int _e_11702 = NOVALUE;
    int _6578 = NOVALUE;
    int _6576 = NOVALUE;
    int _6573 = NOVALUE;
    int _6568 = NOVALUE;
    int _6566 = NOVALUE;
    int _6565 = NOVALUE;
    int _6564 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ((Look != 'e') and (Look != 'E')) then return v end if*/
    _6564 = (_29Look_11383 != 101);
    if (_6564 == 0) {
        _6565 = 0;
        goto L1; // [9] 23
    }
    _6566 = (_29Look_11383 != 69);
    _6565 = (_6566 != 0);
L1: 
    if (_6565 == 0)
    {
        _6565 = NOVALUE;
        goto L2; // [23] 31
    }
    else{
        _6565 = NOVALUE;
    }
    DeRef(_e_11702);
    DeRef(_6564);
    _6564 = NOVALUE;
    DeRef(_6566);
    _6566 = NOVALUE;
    return _v_11701;
L2: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	if (Look = '-') then*/
    if (_29Look_11383 != 45)
    goto L3; // [39] 58

    /** 		scan_char()*/
    _29scan_char();

    /** 		e = -scan_integer()*/
    _6568 = _29scan_integer();
    DeRef(_e_11702);
    if (IS_ATOM_INT(_6568)) {
        if ((unsigned long)_6568 == 0xC0000000)
        _e_11702 = (int)NewDouble((double)-0xC0000000);
        else
        _e_11702 = - _6568;
    }
    else {
        _e_11702 = unary_op(UMINUS, _6568);
    }
    DeRef(_6568);
    _6568 = NOVALUE;
    goto L4; // [55] 75
L3: 

    /** 		if (Look = '+') then scan_char() end if*/
    if (_29Look_11383 != 43)
    goto L5; // [62] 69
    _29scan_char();
L5: 

    /** 		e = scan_integer()*/
    _0 = _e_11702;
    _e_11702 = _29scan_integer();
    DeRef(_0);
L4: 

    /** 	if e > 308 then*/
    if (binary_op_a(LESSEQ, _e_11702, 308)){
        goto L6; // [79] 132
    }

    /** 		v *= power(10, 308)*/
    _6573 = power(10, 308);
    _0 = _v_11701;
    if (IS_ATOM_INT(_v_11701) && IS_ATOM_INT(_6573)) {
        if (_v_11701 == (short)_v_11701 && _6573 <= INT15 && _6573 >= -INT15)
        _v_11701 = _v_11701 * _6573;
        else
        _v_11701 = NewDouble(_v_11701 * (double)_6573);
    }
    else {
        if (IS_ATOM_INT(_v_11701)) {
            _v_11701 = NewDouble((double)_v_11701 * DBL_PTR(_6573)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6573)) {
                _v_11701 = NewDouble(DBL_PTR(_v_11701)->dbl * (double)_6573);
            }
            else
            _v_11701 = NewDouble(DBL_PTR(_v_11701)->dbl * DBL_PTR(_6573)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6573);
    _6573 = NOVALUE;

    /** 		if e > 1000 then e = 1000 end if*/
    if (binary_op_a(LESSEQ, _e_11702, 1000)){
        goto L7; // [95] 103
    }
    DeRef(_e_11702);
    _e_11702 = 1000;
L7: 

    /** 		for i = 1 to e - 308 do*/
    if (IS_ATOM_INT(_e_11702)) {
        _6576 = _e_11702 - 308;
        if ((long)((unsigned long)_6576 +(unsigned long) HIGH_BITS) >= 0){
            _6576 = NewDouble((double)_6576);
        }
    }
    else {
        _6576 = NewDouble(DBL_PTR(_e_11702)->dbl - (double)308);
    }
    {
        int _i_11722;
        _i_11722 = 1;
L8: 
        if (binary_op_a(GREATER, _i_11722, _6576)){
            goto L9; // [109] 129
        }

        /** 			v *= 10*/
        _0 = _v_11701;
        if (IS_ATOM_INT(_v_11701)) {
            if (_v_11701 == (short)_v_11701)
            _v_11701 = _v_11701 * 10;
            else
            _v_11701 = NewDouble(_v_11701 * (double)10);
        }
        else {
            _v_11701 = NewDouble(DBL_PTR(_v_11701)->dbl * (double)10);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _i_11722;
        if (IS_ATOM_INT(_i_11722)) {
            _i_11722 = _i_11722 + 1;
            if ((long)((unsigned long)_i_11722 +(unsigned long) HIGH_BITS) >= 0){
                _i_11722 = NewDouble((double)_i_11722);
            }
        }
        else {
            _i_11722 = binary_op_a(PLUS, _i_11722, 1);
        }
        DeRef(_0);
        goto L8; // [124] 116
L9: 
        ;
        DeRef(_i_11722);
    }
    goto LA; // [129] 143
L6: 

    /** 		v *= power(10, e)*/
    if (IS_ATOM_INT(_e_11702)) {
        _6578 = power(10, _e_11702);
    }
    else {
        temp_d.dbl = (double)10;
        _6578 = Dpower(&temp_d, DBL_PTR(_e_11702));
    }
    _0 = _v_11701;
    if (IS_ATOM_INT(_v_11701) && IS_ATOM_INT(_6578)) {
        if (_v_11701 == (short)_v_11701 && _6578 <= INT15 && _6578 >= -INT15)
        _v_11701 = _v_11701 * _6578;
        else
        _v_11701 = NewDouble(_v_11701 * (double)_6578);
    }
    else {
        if (IS_ATOM_INT(_v_11701)) {
            _v_11701 = NewDouble((double)_v_11701 * DBL_PTR(_6578)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6578)) {
                _v_11701 = NewDouble(DBL_PTR(_v_11701)->dbl * (double)_6578);
            }
            else
            _v_11701 = NewDouble(DBL_PTR(_v_11701)->dbl * DBL_PTR(_6578)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6578);
    _6578 = NOVALUE;
LA: 

    /** 	return v*/
    DeRef(_e_11702);
    DeRef(_6564);
    _6564 = NOVALUE;
    DeRef(_6566);
    _6566 = NOVALUE;
    DeRef(_6576);
    _6576 = NOVALUE;
    return _v_11701;
    ;
}


int _29scan_number()
{
    int _startSti_11734 = NOVALUE;
    int _v_11747 = NOVALUE;
    int _6600 = NOVALUE;
    int _6599 = NOVALUE;
    int _6598 = NOVALUE;
    int _6597 = NOVALUE;
    int _6596 = NOVALUE;
    int _6594 = NOVALUE;
    int _6590 = NOVALUE;
    int _6589 = NOVALUE;
    int _6588 = NOVALUE;
    int _6587 = NOVALUE;
    int _6586 = NOVALUE;
    int _6585 = NOVALUE;
    int _6584 = NOVALUE;
    int _6583 = NOVALUE;
    int _6582 = NOVALUE;
    int _6580 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Digit_Char(Look) then*/
    _6580 = _29Digit_Char(_29Look_11383);
    if (IS_ATOM_INT(_6580)) {
        if (_6580 != 0){
            DeRef(_6580);
            _6580 = NOVALUE;
            goto L1; // [9] 19
        }
    }
    else {
        if (DBL_PTR(_6580)->dbl != 0.0){
            DeRef(_6580);
            _6580 = NOVALUE;
            goto L1; // [9] 19
        }
    }
    DeRef(_6580);
    _6580 = NOVALUE;

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	Token[TFORM] = TF_INT*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);

    /** 	if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11428 == 0)
    {
        goto L2; // [39] 158
    }
    else{
    }

    /** 		integer startSti = sti*/
    _startSti_11734 = _29sti_11380;

    /** 		while Digit_Char(Look) do*/
L3: 
    _6582 = _29Digit_Char(_29Look_11383);
    if (_6582 <= 0) {
        if (_6582 == 0) {
            DeRef(_6582);
            _6582 = NOVALUE;
            goto L4; // [60] 72
        }
        else {
            if (!IS_ATOM_INT(_6582) && DBL_PTR(_6582)->dbl == 0.0){
                DeRef(_6582);
                _6582 = NOVALUE;
                goto L4; // [60] 72
            }
            DeRef(_6582);
            _6582 = NOVALUE;
        }
    }
    DeRef(_6582);
    _6582 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L3; // [69] 54
L4: 

    /** 		if Look = '.' and lookahead(1) != '.' then*/
    _6583 = (_29Look_11383 == 46);
    if (_6583 == 0) {
        goto L5; // [80] 132
    }
    _6585 = _29lookahead(1);
    if (IS_ATOM_INT(_6585)) {
        _6586 = (_6585 != 46);
    }
    else {
        _6586 = binary_op(NOTEQ, _6585, 46);
    }
    DeRef(_6585);
    _6585 = NOVALUE;
    if (_6586 == 0) {
        DeRef(_6586);
        _6586 = NOVALUE;
        goto L5; // [93] 132
    }
    else {
        if (!IS_ATOM_INT(_6586) && DBL_PTR(_6586)->dbl == 0.0){
            DeRef(_6586);
            _6586 = NOVALUE;
            goto L5; // [93] 132
        }
        DeRef(_6586);
        _6586 = NOVALUE;
    }
    DeRef(_6586);
    _6586 = NOVALUE;

    /** 			Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 			scan_char()*/
    _29scan_char();

    /** 			while Digit_Char(Look) do*/
L6: 
    _6587 = _29Digit_Char(_29Look_11383);
    if (_6587 <= 0) {
        if (_6587 == 0) {
            DeRef(_6587);
            _6587 = NOVALUE;
            goto L7; // [119] 131
        }
        else {
            if (!IS_ATOM_INT(_6587) && DBL_PTR(_6587)->dbl == 0.0){
                DeRef(_6587);
                _6587 = NOVALUE;
                goto L7; // [119] 131
            }
            DeRef(_6587);
            _6587 = NOVALUE;
        }
    }
    DeRef(_6587);
    _6587 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L6; // [128] 113
L7: 
L5: 

    /** 		Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6588 = _29sti_11380 - 1;
    rhs_slice_target = (object_ptr)&_6589;
    RHS_Slice(_29source_text_11379, _startSti_11734, _6588);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6589;
    if( _1 != _6589 ){
        DeRef(_1);
    }
    _6589 = NOVALUE;
    goto L8; // [155] 289
L2: 

    /** 		atom v*/

    /** 		Token[TDATA] = scan_integer()*/
    _6590 = _29scan_integer();
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6590;
    if( _1 != _6590 ){
        DeRef(_1);
    }
    _6590 = NOVALUE;

    /** 		if not SUBSCRIPT then*/
    if (_29SUBSCRIPT_11673 != 0)
    goto L9; // [175] 286

    /** 			v = Token[TDATA]*/
    DeRef(_v_11747);
    _2 = (int)SEQ_PTR(_29Token_11377);
    _v_11747 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_v_11747);

    /** 			if Look = '.' then*/
    if (_29Look_11383 != 46)
    goto LA; // [190] 246

    /** 				if lookahead() = '.' then*/
    _6594 = _29lookahead(1);
    if (binary_op_a(NOTEQ, _6594, 46)){
        DeRef(_6594);
        _6594 = NOVALUE;
        goto LB; // [200] 211
    }
    DeRef(_6594);
    _6594 = NOVALUE;

    /** 					return TRUE*/
    DeRef(_v_11747);
    DeRef(_6583);
    _6583 = NOVALUE;
    DeRef(_6588);
    _6588 = NOVALUE;
    return 1;
LB: 

    /** 				scan_char()*/
    _29scan_char();

    /** 				Token[TDATA] = scan_fraction(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6596 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6596);
    _6597 = _29scan_fraction(_6596);
    _6596 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6597;
    if( _1 != _6597 ){
        DeRef(_1);
    }
    _6597 = NOVALUE;

    /** 				if ERR then return TRUE end if*/
    if (_29ERR_11384 == 0)
    {
        goto LC; // [237] 245
    }
    else{
    }
    DeRef(_v_11747);
    DeRef(_6583);
    _6583 = NOVALUE;
    DeRef(_6588);
    _6588 = NOVALUE;
    return 1;
LC: 
LA: 

    /** 			Token[TDATA] = scan_exponent(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6598 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6598);
    _6599 = _29scan_exponent(_6598);
    _6598 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6599;
    if( _1 != _6599 ){
        DeRef(_1);
    }
    _6599 = NOVALUE;

    /** 			if v != Token[TDATA] then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6600 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _v_11747, _6600)){
        _6600 = NOVALUE;
        goto LD; // [272] 285
    }
    _6600 = NOVALUE;

    /** 				Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
LD: 
L9: 
    DeRef(_v_11747);
    _v_11747 = NOVALUE;
L8: 

    /** 	return TRUE*/
    DeRef(_6583);
    _6583 = NOVALUE;
    DeRef(_6588);
    _6588 = NOVALUE;
    return 1;
    ;
}


int _29scan_prefixed_number()
{
    int _pfxCh_11770 = NOVALUE;
    int _firstCh_11776 = NOVALUE;
    int _startSti_11782 = NOVALUE;
    int _6622 = NOVALUE;
    int _6621 = NOVALUE;
    int _6620 = NOVALUE;
    int _6619 = NOVALUE;
    int _6618 = NOVALUE;
    int _6617 = NOVALUE;
    int _6616 = NOVALUE;
    int _6614 = NOVALUE;
    int _6611 = NOVALUE;
    int _6609 = NOVALUE;
    int _6606 = NOVALUE;
    int _6602 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not (Look = '0') then*/
    _6602 = (_29Look_11383 == 48);
    if (_6602 != 0)
    goto L1; // [9] 19
    _6602 = NOVALUE;

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	integer pfxCh = lookahead(1)*/
    _pfxCh_11770 = _29lookahead(1);
    if (!IS_ATOM_INT(_pfxCh_11770)) {
        _1 = (long)(DBL_PTR(_pfxCh_11770)->dbl);
        DeRefDS(_pfxCh_11770);
        _pfxCh_11770 = _1;
    }

    /** 	if find(pfxCh, "btdx") = 0 then*/
    _6606 = find_from(_pfxCh_11770, _6605, 1);
    if (_6606 != 0)
    goto L2; // [34] 45

    /** 		return FALSE*/
    return 0;
L2: 

    /** 	integer firstCh = lookahead(2)*/
    _firstCh_11776 = _29lookahead(2);
    if (!IS_ATOM_INT(_firstCh_11776)) {
        _1 = (long)(DBL_PTR(_firstCh_11776)->dbl);
        DeRefDS(_firstCh_11776);
        _firstCh_11776 = _1;
    }

    /** 	if Digit_Char(firstCh) or Hex_Char(firstCh) then*/
    _6609 = _29Digit_Char(_firstCh_11776);
    if (IS_ATOM_INT(_6609)) {
        if (_6609 != 0) {
            goto L3; // [59] 72
        }
    }
    else {
        if (DBL_PTR(_6609)->dbl != 0.0) {
            goto L3; // [59] 72
        }
    }
    _6611 = _29Hex_Char(_firstCh_11776);
    if (_6611 == 0) {
        DeRef(_6611);
        _6611 = NOVALUE;
        goto L4; // [68] 225
    }
    else {
        if (!IS_ATOM_INT(_6611) && DBL_PTR(_6611)->dbl == 0.0){
            DeRef(_6611);
            _6611 = NOVALUE;
            goto L4; // [68] 225
        }
        DeRef(_6611);
        _6611 = NOVALUE;
    }
    DeRef(_6611);
    _6611 = NOVALUE;
L3: 

    /** 		integer startSti = sti*/
    _startSti_11782 = _29sti_11380;

    /** 		scan_char() -- skip the leading zero*/
    _29scan_char();

    /** 		scan_char() -- skip prefix character*/
    _29scan_char();

    /** 		Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 		if pfxCh = 'x' then*/
    if (_pfxCh_11770 != 120)
    goto L5; // [97] 112

    /** 			Token[TFORM] = TF_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    goto L6; // [109] 121
L5: 

    /** 			Token[TFORM] = TF_INT*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
L6: 

    /** 		while Hex_Char(Look) or Digit_Char(Look) do*/
L7: 
    _6614 = _29Hex_Char(_29Look_11383);
    if (IS_ATOM_INT(_6614)) {
        if (_6614 != 0) {
            goto L8; // [132] 147
        }
    }
    else {
        if (DBL_PTR(_6614)->dbl != 0.0) {
            goto L8; // [132] 147
        }
    }
    _6616 = _29Digit_Char(_29Look_11383);
    if (_6616 <= 0) {
        if (_6616 == 0) {
            DeRef(_6616);
            _6616 = NOVALUE;
            goto L9; // [143] 156
        }
        else {
            if (!IS_ATOM_INT(_6616) && DBL_PTR(_6616)->dbl == 0.0){
                DeRef(_6616);
                _6616 = NOVALUE;
                goto L9; // [143] 156
            }
            DeRef(_6616);
            _6616 = NOVALUE;
        }
    }
    DeRef(_6616);
    _6616 = NOVALUE;
L8: 

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L7; // [153] 126
L9: 

    /** 		if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11428 == 0)
    {
        goto LA; // [160] 187
    }
    else{
    }

    /** 			Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6617 = _29sti_11380 - 1;
    rhs_slice_target = (object_ptr)&_6618;
    RHS_Slice(_29source_text_11379, _startSti_11782, _6617);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6618;
    if( _1 != _6618 ){
        DeRef(_1);
    }
    _6618 = NOVALUE;
    goto LB; // [184] 218
LA: 

    /** 			Token[TDATA] = convert:to_number(source_text[startSti + 2 .. sti - 1])*/
    _6619 = _startSti_11782 + 2;
    if ((long)((unsigned long)_6619 + (unsigned long)HIGH_BITS) >= 0) 
    _6619 = NewDouble((double)_6619);
    _6620 = _29sti_11380 - 1;
    rhs_slice_target = (object_ptr)&_6621;
    RHS_Slice(_29source_text_11379, _6619, _6620);
    _6622 = _8to_number(_6621, 0);
    _6621 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6622;
    if( _1 != _6622 ){
        DeRef(_1);
    }
    _6622 = NOVALUE;
LB: 

    /** 		return TRUE*/
    DeRef(_6609);
    _6609 = NOVALUE;
    DeRef(_6614);
    _6614 = NOVALUE;
    DeRef(_6617);
    _6617 = NOVALUE;
    DeRef(_6619);
    _6619 = NOVALUE;
    DeRef(_6620);
    _6620 = NOVALUE;
    return 1;
L4: 

    /** 	return FALSE*/
    DeRef(_6609);
    _6609 = NOVALUE;
    DeRef(_6614);
    _6614 = NOVALUE;
    DeRef(_6617);
    _6617 = NOVALUE;
    DeRef(_6619);
    _6619 = NOVALUE;
    DeRef(_6620);
    _6620 = NOVALUE;
    return 0;
    ;
}


int _29hex_string(int _textdata_11801, int _string_type_11802)
{
    int _ch_11803 = NOVALUE;
    int _digit_11804 = NOVALUE;
    int _val_11805 = NOVALUE;
    int _nibble_11806 = NOVALUE;
    int _maxnibbles_11807 = NOVALUE;
    int _string_text_11808 = NOVALUE;
    int _6638 = NOVALUE;
    int _6637 = NOVALUE;
    int _6627 = NOVALUE;
    int _6626 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_string_type_11802)) {
        _1 = (long)(DBL_PTR(_string_type_11802)->dbl);
        DeRefDS(_string_type_11802);
        _string_type_11802 = _1;
    }

    /** 	switch string_type do*/
    _0 = _string_type_11802;
    switch ( _0 ){ 

        /** 		case 'x' then*/
        case 120:

        /** 			maxnibbles = 2*/
        _maxnibbles_11807 = 2;
        goto L1; // [21] 60

        /** 		case 'u' then*/
        case 117:

        /** 			maxnibbles = 4*/
        _maxnibbles_11807 = 4;
        goto L1; // [32] 60

        /** 		case 'U' then*/
        case 85:

        /** 			maxnibbles = 8*/
        _maxnibbles_11807 = 8;
        goto L1; // [43] 60

        /** 		case else*/
        default:

        /** 			printf(2, "tokenize.e: Unknown base code '%s', ignored.\n", {string_type})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _string_type_11802;
        _6626 = MAKE_SEQ(_1);
        EPrintf(2, _6625, _6626);
        DeRefDS(_6626);
        _6626 = NOVALUE;
    ;}L1: 

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_11808);
    _string_text_11808 = _5;

    /** 	nibble = 1*/
    _nibble_11806 = 1;

    /** 	val = -1*/
    DeRef(_val_11805);
    _val_11805 = -1;

    /** 	for cpos = 1 to length(textdata) do*/
    if (IS_SEQUENCE(_textdata_11801)){
            _6627 = SEQ_PTR(_textdata_11801)->length;
    }
    else {
        _6627 = 1;
    }
    {
        int _cpos_11818;
        _cpos_11818 = 1;
L2: 
        if (_cpos_11818 > _6627){
            goto L3; // [82] 229
        }

        /** 		ch = textdata[cpos]*/
        _2 = (int)SEQ_PTR(_textdata_11801);
        _ch_11803 = (int)*(((s1_ptr)_2)->base + _cpos_11818);
        if (!IS_ATOM_INT(_ch_11803))
        _ch_11803 = (long)DBL_PTR(_ch_11803)->dbl;

        /** 		digit = find(ch, "0123456789ABCDEFabcdef _\t\n\r")*/
        _digit_11804 = find_from(_ch_11803, _6629, 1);

        /** 		if digit = 0 then*/
        if (_digit_11804 != 0)
        goto L4; // [104] 115

        /** 			return 0*/
        DeRefDS(_textdata_11801);
        DeRef(_val_11805);
        DeRef(_string_text_11808);
        return 0;
L4: 

        /** 		if digit < 23 then*/
        if (_digit_11804 >= 23)
        goto L5; // [117] 198

        /** 			if digit > 16 then*/
        if (_digit_11804 <= 16)
        goto L6; // [123] 134

        /** 				digit -= 6*/
        _digit_11804 = _digit_11804 - 6;
L6: 

        /** 			if nibble = 1 then*/
        if (_nibble_11806 != 1)
        goto L7; // [136] 149

        /** 				val = digit - 1*/
        DeRef(_val_11805);
        _val_11805 = _digit_11804 - 1;
        if ((long)((unsigned long)_val_11805 +(unsigned long) HIGH_BITS) >= 0){
            _val_11805 = NewDouble((double)_val_11805);
        }
        goto L8; // [146] 189
L7: 

        /** 				val = val * 16 + digit - 1*/
        if (IS_ATOM_INT(_val_11805)) {
            if (_val_11805 == (short)_val_11805)
            _6637 = _val_11805 * 16;
            else
            _6637 = NewDouble(_val_11805 * (double)16);
        }
        else {
            _6637 = NewDouble(DBL_PTR(_val_11805)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_6637)) {
            _6638 = _6637 + _digit_11804;
            if ((long)((unsigned long)_6638 + (unsigned long)HIGH_BITS) >= 0) 
            _6638 = NewDouble((double)_6638);
        }
        else {
            _6638 = NewDouble(DBL_PTR(_6637)->dbl + (double)_digit_11804);
        }
        DeRef(_6637);
        _6637 = NOVALUE;
        DeRef(_val_11805);
        if (IS_ATOM_INT(_6638)) {
            _val_11805 = _6638 - 1;
            if ((long)((unsigned long)_val_11805 +(unsigned long) HIGH_BITS) >= 0){
                _val_11805 = NewDouble((double)_val_11805);
            }
        }
        else {
            _val_11805 = NewDouble(DBL_PTR(_6638)->dbl - (double)1);
        }
        DeRef(_6638);
        _6638 = NOVALUE;

        /** 				if nibble = maxnibbles then*/
        if (_nibble_11806 != _maxnibbles_11807)
        goto L9; // [167] 188

        /** 					string_text &= val*/
        Ref(_val_11805);
        Append(&_string_text_11808, _string_text_11808, _val_11805);

        /** 					val = -1*/
        DeRef(_val_11805);
        _val_11805 = -1;

        /** 					nibble = 0*/
        _nibble_11806 = 0;
L9: 
L8: 

        /** 			nibble += 1*/
        _nibble_11806 = _nibble_11806 + 1;
        goto LA; // [195] 222
L5: 

        /** 			if val >= 0 then*/
        if (binary_op_a(LESS, _val_11805, 0)){
            goto LB; // [200] 216
        }

        /** 				string_text &= val*/
        Ref(_val_11805);
        Append(&_string_text_11808, _string_text_11808, _val_11805);

        /** 				val = -1*/
        DeRef(_val_11805);
        _val_11805 = -1;
LB: 

        /** 			nibble = 1*/
        _nibble_11806 = 1;
LA: 

        /** 	end for*/
        _cpos_11818 = _cpos_11818 + 1;
        goto L2; // [224] 89
L3: 
        ;
    }

    /** 	if val >= 0 then*/
    if (binary_op_a(LESS, _val_11805, 0)){
        goto LC; // [231] 242
    }

    /** 		string_text &= val*/
    Ref(_val_11805);
    Append(&_string_text_11808, _string_text_11808, _val_11805);
LC: 

    /** 	return string_text*/
    DeRefDS(_textdata_11801);
    DeRef(_val_11805);
    return _string_text_11808;
    ;
}


int _29scan_identifier()
{
    int _nextch_11851 = NOVALUE;
    int _startpos_11852 = NOVALUE;
    int _textdata_11853 = NOVALUE;
    int _6670 = NOVALUE;
    int _6669 = NOVALUE;
    int _6668 = NOVALUE;
    int _6667 = NOVALUE;
    int _6666 = NOVALUE;
    int _6665 = NOVALUE;
    int _6664 = NOVALUE;
    int _6663 = NOVALUE;
    int _6661 = NOVALUE;
    int _6660 = NOVALUE;
    int _6659 = NOVALUE;
    int _6658 = NOVALUE;
    int _6655 = NOVALUE;
    int _6654 = NOVALUE;
    int _6651 = NOVALUE;
    int _6650 = NOVALUE;
    int _6649 = NOVALUE;
    int _6648 = NOVALUE;
    int _6647 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Alpha_Char(Look) and Look != '_' then*/
    _6647 = _29Alpha_Char(_29Look_11383);
    if (IS_ATOM_INT(_6647)) {
        _6648 = (_6647 == 0);
    }
    else {
        _6648 = unary_op(NOT, _6647);
    }
    DeRef(_6647);
    _6647 = NOVALUE;
    if (IS_ATOM_INT(_6648)) {
        if (_6648 == 0) {
            goto L1; // [12] 33
        }
    }
    else {
        if (DBL_PTR(_6648)->dbl == 0.0) {
            goto L1; // [12] 33
        }
    }
    _6650 = (_29Look_11383 != 95);
    if (_6650 == 0)
    {
        DeRef(_6650);
        _6650 = NOVALUE;
        goto L1; // [23] 33
    }
    else{
        DeRef(_6650);
        _6650 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_textdata_11853);
    DeRef(_6648);
    _6648 = NOVALUE;
    return 0;
L1: 

    /** 	if find(Look, "xuU") then*/
    _6651 = find_from(_29Look_11383, _6623, 1);
    if (_6651 == 0)
    {
        _6651 = NOVALUE;
        goto L2; // [42] 213
    }
    else{
        _6651 = NOVALUE;
    }

    /** 		nextch = lookahead()*/
    _nextch_11851 = _29lookahead(1);
    if (!IS_ATOM_INT(_nextch_11851)) {
        _1 = (long)(DBL_PTR(_nextch_11851)->dbl);
        DeRefDS(_nextch_11851);
        _nextch_11851 = _1;
    }

    /** 		if nextch = '"' then*/
    if (_nextch_11851 != 34)
    goto L3; // [55] 212

    /** 			textdata = ""*/
    RefDS(_5);
    DeRef(_textdata_11853);
    _textdata_11853 = _5;

    /** 			scan_char()	-- Skip over starting quote*/
    _29scan_char();

    /** 			scan_char() -- First char of string*/
    _29scan_char();

    /** 			startpos = sti*/
    _startpos_11852 = _29sti_11380;

    /** 			while not find(Look, {'"', io:EOF}) do*/
L4: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 34;
    ((int *)_2)[2] = -1;
    _6654 = MAKE_SEQ(_1);
    _6655 = find_from(_29Look_11383, _6654, 1);
    DeRefDS(_6654);
    _6654 = NOVALUE;
    if (_6655 != 0)
    goto L5; // [95] 107
    _6655 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L4; // [104] 84
L5: 

    /** 			if Look = io:EOF then*/
    if (_29Look_11383 != -1)
    goto L6; // [111] 127

    /** 				report_error(ERR_EOF_STRING)*/
    _29report_error(10);

    /** 				return TRUE*/
    DeRef(_textdata_11853);
    DeRef(_6648);
    _6648 = NOVALUE;
    return 1;
L6: 

    /** 			textdata = hex_string(source_text[startpos .. sti-1], source_text[startpos - 2])*/
    _6658 = _29sti_11380 - 1;
    rhs_slice_target = (object_ptr)&_6659;
    RHS_Slice(_29source_text_11379, _startpos_11852, _6658);
    _6660 = _startpos_11852 - 2;
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _6661 = (int)*(((s1_ptr)_2)->base + _6660);
    Ref(_6661);
    _0 = _textdata_11853;
    _textdata_11853 = _29hex_string(_6659, _6661);
    DeRef(_0);
    _6659 = NOVALUE;
    _6661 = NOVALUE;

    /** 			if atom(textdata) then*/
    _6663 = IS_ATOM(_textdata_11853);
    if (_6663 == 0)
    {
        _6663 = NOVALUE;
        goto L7; // [162] 177
    }
    else{
        _6663 = NOVALUE;
    }

    /** 				report_error(ERR_HEX_STRING)*/
    _29report_error(11);

    /** 				return TRUE*/
    DeRef(_textdata_11853);
    DeRef(_6648);
    _6648 = NOVALUE;
    _6658 = NOVALUE;
    _6660 = NOVALUE;
    return 1;
L7: 

    /** 			Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			Token[TDATA] = textdata*/
    Ref(_textdata_11853);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _textdata_11853;
    DeRef(_1);

    /** 			Token[TFORM] = TF_STRING_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 7;
    DeRef(_1);

    /** 			scan_char()	-- go to next char after end of string*/
    _29scan_char();

    /** 			return TRUE*/
    DeRef(_textdata_11853);
    DeRef(_6648);
    _6648 = NOVALUE;
    DeRef(_6658);
    _6658 = NOVALUE;
    DeRef(_6660);
    _6660 = NOVALUE;
    return 1;
L3: 
L2: 

    /** 	Token[TTYPE] = T_IDENTIFIER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	while Identifier_Char(Look) do*/
L8: 
    _6664 = _29Identifier_Char(_29Look_11383);
    if (_6664 <= 0) {
        if (_6664 == 0) {
            DeRef(_6664);
            _6664 = NOVALUE;
            goto L9; // [240] 270
        }
        else {
            if (!IS_ATOM_INT(_6664) && DBL_PTR(_6664)->dbl == 0.0){
                DeRef(_6664);
                _6664 = NOVALUE;
                goto L9; // [240] 270
            }
            DeRef(_6664);
            _6664 = NOVALUE;
        }
    }
    DeRef(_6664);
    _6664 = NOVALUE;

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6665 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6665) && IS_ATOM(_29Look_11383)) {
        Append(&_6666, _6665, _29Look_11383);
    }
    else if (IS_ATOM(_6665) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6666, _6665, _29Look_11383);
        _6665 = NOVALUE;
    }
    _6665 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6666;
    if( _1 != _6666 ){
        DeRef(_1);
    }
    _6666 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L8; // [267] 234
L9: 

    /** 	if find(Token[TDATA],keywords) then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6667 = (int)*(((s1_ptr)_2)->base + 2);
    _6668 = find_from(_6667, _4keywords_296, 1);
    _6667 = NOVALUE;
    if (_6668 == 0)
    {
        _6668 = NOVALUE;
        goto LA; // [285] 318
    }
    else{
        _6668 = NOVALUE;
    }

    /** 		Token[TTYPE] = T_KEYWORD*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);

    /** 		if equal(Token[TDATA],"include") then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6669 = (int)*(((s1_ptr)_2)->base + 2);
    if (_6669 == _118)
    _6670 = 1;
    else if (IS_ATOM_INT(_6669) && IS_ATOM_INT(_118))
    _6670 = 0;
    else
    _6670 = (compare(_6669, _118) == 0);
    _6669 = NOVALUE;
    if (_6670 == 0)
    {
        _6670 = NOVALUE;
        goto LB; // [308] 317
    }
    else{
        _6670 = NOVALUE;
    }

    /** 			INCLUDE_NEXT = TRUE*/
    _29INCLUDE_NEXT_11848 = 1;
LB: 
LA: 

    /** 	return TRUE*/
    DeRef(_textdata_11853);
    DeRef(_6648);
    _6648 = NOVALUE;
    DeRef(_6658);
    _6658 = NOVALUE;
    DeRef(_6660);
    _6660 = NOVALUE;
    return 1;
    ;
}


int _29scan_include()
{
    int _6677 = NOVALUE;
    int _6676 = NOVALUE;
    int _6674 = NOVALUE;
    int _6672 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not INCLUDE_NEXT then*/
    if (_29INCLUDE_NEXT_11848 != 0)
    goto L1; // [5] 15

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	INCLUDE_NEXT = FALSE*/
    _29INCLUDE_NEXT_11848 = 0;

    /** 	Token[TTYPE] = T_IDENTIFIER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	if not scan_string() then*/
    _6672 = _29scan_string();
    if (IS_ATOM_INT(_6672)) {
        if (_6672 != 0){
            DeRef(_6672);
            _6672 = NOVALUE;
            goto L2; // [41] 86
        }
    }
    else {
        if (DBL_PTR(_6672)->dbl != 0.0){
            DeRef(_6672);
            _6672 = NOVALUE;
            goto L2; // [41] 86
        }
    }
    DeRef(_6672);
    _6672 = NOVALUE;

    /** 		while not White_Char(Look) do*/
L3: 
    _6674 = _29White_Char(_29Look_11383);
    if (IS_ATOM_INT(_6674)) {
        if (_6674 != 0){
            DeRef(_6674);
            _6674 = NOVALUE;
            goto L4; // [55] 85
        }
    }
    else {
        if (DBL_PTR(_6674)->dbl != 0.0){
            DeRef(_6674);
            _6674 = NOVALUE;
            goto L4; // [55] 85
        }
    }
    DeRef(_6674);
    _6674 = NOVALUE;

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6676 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6676) && IS_ATOM(_29Look_11383)) {
        Append(&_6677, _6676, _29Look_11383);
    }
    else if (IS_ATOM(_6676) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6677, _6676, _29Look_11383);
        _6676 = NOVALUE;
    }
    _6676 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6677;
    if( _1 != _6677 ){
        DeRef(_1);
    }
    _6677 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L3; // [82] 49
L4: 
L2: 

    /** 	return TRUE*/
    return 1;
    ;
}


void _29next_token()
{
    int _6740 = NOVALUE;
    int _6739 = NOVALUE;
    int _6738 = NOVALUE;
    int _6737 = NOVALUE;
    int _6736 = NOVALUE;
    int _6735 = NOVALUE;
    int _6734 = NOVALUE;
    int _6733 = NOVALUE;
    int _6732 = NOVALUE;
    int _6731 = NOVALUE;
    int _6730 = NOVALUE;
    int _6729 = NOVALUE;
    int _6728 = NOVALUE;
    int _6727 = NOVALUE;
    int _6724 = NOVALUE;
    int _6723 = NOVALUE;
    int _6722 = NOVALUE;
    int _6721 = NOVALUE;
    int _6720 = NOVALUE;
    int _6719 = NOVALUE;
    int _6718 = NOVALUE;
    int _6716 = NOVALUE;
    int _6715 = NOVALUE;
    int _6714 = NOVALUE;
    int _6713 = NOVALUE;
    int _6712 = NOVALUE;
    int _6711 = NOVALUE;
    int _6710 = NOVALUE;
    int _6709 = NOVALUE;
    int _6708 = NOVALUE;
    int _6707 = NOVALUE;
    int _6704 = NOVALUE;
    int _6703 = NOVALUE;
    int _6702 = NOVALUE;
    int _6701 = NOVALUE;
    int _6700 = NOVALUE;
    int _6699 = NOVALUE;
    int _6698 = NOVALUE;
    int _6697 = NOVALUE;
    int _6696 = NOVALUE;
    int _6695 = NOVALUE;
    int _6692 = NOVALUE;
    int _6689 = NOVALUE;
    int _6688 = NOVALUE;
    int _6687 = NOVALUE;
    int _6686 = NOVALUE;
    int _6685 = NOVALUE;
    int _6684 = NOVALUE;
    int _6683 = NOVALUE;
    int _6682 = NOVALUE;
    int _6681 = NOVALUE;
    int _6680 = NOVALUE;
    int _6679 = NOVALUE;
    int _6678 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TLNUM] = LNum*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29LNum_11381;
    DeRef(_1);

    /** 	Token[TLPOS] = LPos*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _29LPos_11382;
    DeRef(_1);

    /** 	Token[TFORM] = -1*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	if Look = EOL and not IGNORE_NEWLINES then*/
    _6678 = (_29Look_11383 == 10);
    if (_6678 == 0) {
        goto L1; // [37] 76
    }
    _6680 = (_29IGNORE_NEWLINES_11426 == 0);
    if (_6680 == 0)
    {
        DeRef(_6680);
        _6680 = NOVALUE;
        goto L1; // [47] 76
    }
    else{
        DeRef(_6680);
        _6680 = NOVALUE;
    }

    /** 		Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 		Token[TTYPE] = T_NEWLINE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 		scan_char() -- advance past this newline*/
    _29scan_char();

    /** 		return*/
    DeRef(_6678);
    _6678 = NOVALUE;
    return;
L1: 

    /** 	if scan_white() then*/
    _6681 = _29scan_white();
    if (_6681 == 0) {
        DeRef(_6681);
        _6681 = NOVALUE;
        goto L2; // [81] 100
    }
    else {
        if (!IS_ATOM_INT(_6681) && DBL_PTR(_6681)->dbl == 0.0){
            DeRef(_6681);
            _6681 = NOVALUE;
            goto L2; // [81] 100
        }
        DeRef(_6681);
        _6681 = NOVALUE;
    }
    DeRef(_6681);
    _6681 = NOVALUE;

    /** 		if IGNORE_NEWLINES then next_token() end if*/
    if (_29IGNORE_NEWLINES_11426 == 0)
    {
        goto L3; // [88] 94
    }
    else{
    }
    _29next_token();
L3: 

    /** 		return*/
    DeRef(_6678);
    _6678 = NOVALUE;
    return;
L2: 

    /** 	if scan_include() then*/
    _6682 = _29scan_include();
    if (_6682 == 0) {
        DeRef(_6682);
        _6682 = NOVALUE;
        goto L4; // [105] 114
    }
    else {
        if (!IS_ATOM_INT(_6682) && DBL_PTR(_6682)->dbl == 0.0){
            DeRef(_6682);
            _6682 = NOVALUE;
            goto L4; // [105] 114
        }
        DeRef(_6682);
        _6682 = NOVALUE;
    }
    DeRef(_6682);
    _6682 = NOVALUE;

    /** 		return*/
    DeRef(_6678);
    _6678 = NOVALUE;
    return;
L4: 

    /** 	Token[TTYPE] = find(Look, Delimiters)*/
    _6683 = find_from(_29Look_11383, _29Delimiters_11368, 1);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6683;
    if( _1 != _6683 ){
        DeRef(_1);
    }
    _6683 = NOVALUE;

    /** 	if Token[TTYPE] then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6684 = (int)*(((s1_ptr)_2)->base + 1);
    if (_6684 == 0) {
        _6684 = NOVALUE;
        goto L5; // [139] 626
    }
    else {
        if (!IS_ATOM_INT(_6684) && DBL_PTR(_6684)->dbl == 0.0){
            _6684 = NOVALUE;
            goto L5; // [139] 626
        }
        _6684 = NOVALUE;
    }
    _6684 = NOVALUE;

    /** 		Token[TTYPE] += T_DELIMITER - 1*/
    _6685 = 18;
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6686 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6686)) {
        _6687 = _6686 + 18;
        if ((long)((unsigned long)_6687 + (unsigned long)HIGH_BITS) >= 0) 
        _6687 = NewDouble((double)_6687);
    }
    else {
        _6687 = binary_op(PLUS, _6686, 18);
    }
    _6686 = NOVALUE;
    _6685 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6687;
    if( _1 != _6687 ){
        DeRef(_1);
    }
    _6687 = NOVALUE;

    /** 		Token[TDATA] = { Look }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29Look_11383;
    _6688 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6688;
    if( _1 != _6688 ){
        DeRef(_1);
    }
    _6688 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		if (Token[TTYPE] = T_LBRACKET) then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6689 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6689, 32)){
        _6689 = NOVALUE;
        goto L6; // [188] 203
    }
    _6689 = NOVALUE;

    /** 			SUBSCRIPT += 1 -- push subscript stack counter*/
    _29SUBSCRIPT_11673 = _29SUBSCRIPT_11673 + 1;
    goto L7; // [200] 736
L6: 

    /** 		elsif (Token[TTYPE] = T_RBRACKET) then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6692 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6692, 33)){
        _6692 = NOVALUE;
        goto L8; // [211] 226
    }
    _6692 = NOVALUE;

    /** 			SUBSCRIPT -= 1 -- pop subscript stack counter*/
    _29SUBSCRIPT_11673 = _29SUBSCRIPT_11673 - 1;
    goto L7; // [223] 736
L8: 

    /** 		elsif (Look = '=') and (Token[TTYPE] <= T_SINGLE_OPS) then*/
    _6695 = (_29Look_11383 == 61);
    if (_6695 == 0) {
        goto L9; // [234] 297
    }
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6697 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6697)) {
        _6698 = (_6697 <= 27);
    }
    else {
        _6698 = binary_op(LESSEQ, _6697, 27);
    }
    _6697 = NOVALUE;
    if (_6698 == 0) {
        DeRef(_6698);
        _6698 = NOVALUE;
        goto L9; // [249] 297
    }
    else {
        if (!IS_ATOM_INT(_6698) && DBL_PTR(_6698)->dbl == 0.0){
            DeRef(_6698);
            _6698 = NOVALUE;
            goto L9; // [249] 297
        }
        DeRef(_6698);
        _6698 = NOVALUE;
    }
    DeRef(_6698);
    _6698 = NOVALUE;

    /** 			Token[TTYPE] -= T_DOUBLE_OPS - 3*/
    _6699 = 8;
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6700 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6700)) {
        _6701 = _6700 - 8;
        if ((long)((unsigned long)_6701 +(unsigned long) HIGH_BITS) >= 0){
            _6701 = NewDouble((double)_6701);
        }
    }
    else {
        _6701 = binary_op(MINUS, _6700, 8);
    }
    _6700 = NOVALUE;
    _6699 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6701;
    if( _1 != _6701 ){
        DeRef(_1);
    }
    _6701 = NOVALUE;

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6702 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6702) && IS_ATOM(_29Look_11383)) {
        Append(&_6703, _6702, _29Look_11383);
    }
    else if (IS_ATOM(_6702) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6703, _6702, _29Look_11383);
        _6702 = NOVALUE;
    }
    _6702 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6703;
    if( _1 != _6703 ){
        DeRef(_1);
    }
    _6703 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();
    goto L7; // [294] 736
L9: 

    /** 		elsif (Token[TTYPE] = T_PERIOD) then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6704 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6704, 36)){
        _6704 = NOVALUE;
        goto LA; // [305] 483
    }
    _6704 = NOVALUE;

    /** 			if (Look = '.') then*/
    if (_29Look_11383 != 46)
    goto LB; // [313] 350

    /** 				Token[TTYPE] = T_SLICE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 39;
    DeRef(_1);

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6707 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6707) && IS_ATOM(_29Look_11383)) {
        Append(&_6708, _6707, _29Look_11383);
    }
    else if (IS_ATOM(_6707) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6708, _6707, _29Look_11383);
        _6707 = NOVALUE;
    }
    _6707 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6708;
    if( _1 != _6708 ){
        DeRef(_1);
    }
    _6708 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();
    goto L7; // [347] 736
LB: 

    /** 				Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 				Token[TDATA] = scan_fraction(0)*/
    _6709 = _29scan_fraction(0);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6709;
    if( _1 != _6709 ){
        DeRef(_1);
    }
    _6709 = NOVALUE;

    /** 				Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 				if ERR then*/
    if (_29ERR_11384 == 0)
    {
        goto LC; // [382] 391
    }
    else{
    }

    /** 					return*/
    DeRef(_6678);
    _6678 = NOVALUE;
    DeRef(_6695);
    _6695 = NOVALUE;
    return;
LC: 

    /** 				Token[TDATA] = scan_exponent(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6710 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6710);
    _6711 = _29scan_exponent(_6710);
    _6710 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6711;
    if( _1 != _6711 ){
        DeRef(_1);
    }
    _6711 = NOVALUE;

    /** 				if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11428 == 0)
    {
        goto L7; // [413] 736
    }
    else{
    }

    /** 					if integer(Token[TDATA]) then*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6712 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6712))
    _6713 = 1;
    else if (IS_ATOM_DBL(_6712))
    _6713 = IS_ATOM_INT(DoubleToInt(_6712));
    else
    _6713 = 0;
    _6712 = NOVALUE;
    if (_6713 == 0)
    {
        _6713 = NOVALUE;
        goto LD; // [427] 455
    }
    else{
        _6713 = NOVALUE;
    }

    /** 						Token[TDATA] = sprintf("%d",{Token[TDATA]})*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6714 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6714);
    *((int *)(_2+4)) = _6714;
    _6715 = MAKE_SEQ(_1);
    _6714 = NOVALUE;
    _6716 = EPrintf(-9999999, _919, _6715);
    DeRefDS(_6715);
    _6715 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6716;
    if( _1 != _6716 ){
        DeRef(_1);
    }
    _6716 = NOVALUE;
    goto L7; // [452] 736
LD: 

    /** 						Token[TDATA] = sprintf("%g",{Token[TDATA]})*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6718 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6718);
    *((int *)(_2+4)) = _6718;
    _6719 = MAKE_SEQ(_1);
    _6718 = NOVALUE;
    _6720 = EPrintf(-9999999, _6717, _6719);
    DeRefDS(_6719);
    _6719 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6720;
    if( _1 != _6720 ){
        DeRef(_1);
    }
    _6720 = NOVALUE;
    goto L7; // [480] 736
LA: 

    /** 		elsif (Look = '-') and (Token[TTYPE] = T_MINUS) then*/
    _6721 = (_29Look_11383 == 45);
    if (_6721 == 0) {
        goto LE; // [491] 590
    }
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6723 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6723)) {
        _6724 = (_6723 == 20);
    }
    else {
        _6724 = binary_op(EQUALS, _6723, 20);
    }
    _6723 = NOVALUE;
    if (_6724 == 0) {
        DeRef(_6724);
        _6724 = NOVALUE;
        goto LE; // [506] 590
    }
    else {
        if (!IS_ATOM_INT(_6724) && DBL_PTR(_6724)->dbl == 0.0){
            DeRef(_6724);
            _6724 = NOVALUE;
            goto LE; // [506] 590
        }
        DeRef(_6724);
        _6724 = NOVALUE;
    }
    DeRef(_6724);
    _6724 = NOVALUE;

    /** 			Token[TTYPE] = T_COMMENT*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 			Token[TDATA] = "--"*/
    RefDS(_6725);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6725;
    DeRef(_1);

    /** 			Token[TFORM] = TF_COMMENT_SINGLE*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			scan_char()*/
    _29scan_char();

    /** 			while (Look != EOL) do*/
LF: 
    if (_29Look_11383 == 10)
    goto L10; // [544] 575

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6727 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6727) && IS_ATOM(_29Look_11383)) {
        Append(&_6728, _6727, _29Look_11383);
    }
    else if (IS_ATOM(_6727) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6728, _6727, _29Look_11383);
        _6727 = NOVALUE;
    }
    _6727 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6728;
    if( _1 != _6728 ){
        DeRef(_1);
    }
    _6728 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto LF; // [572] 542
L10: 

    /** 			if IGNORE_COMMENTS then*/
    if (_29IGNORE_COMMENTS_11427 == 0)
    {
        goto L7; // [579] 736
    }
    else{
    }

    /** 				next_token()*/
    _29next_token();
    goto L7; // [587] 736
LE: 

    /** 		elsif (Look = '*') and (Token[TTYPE] = T_DIVIDE) then*/
    _6729 = (_29Look_11383 == 42);
    if (_6729 == 0) {
        goto L7; // [598] 736
    }
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6731 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6731)) {
        _6732 = (_6731 == 22);
    }
    else {
        _6732 = binary_op(EQUALS, _6731, 22);
    }
    _6731 = NOVALUE;
    if (_6732 == 0) {
        DeRef(_6732);
        _6732 = NOVALUE;
        goto L7; // [613] 736
    }
    else {
        if (!IS_ATOM_INT(_6732) && DBL_PTR(_6732)->dbl == 0.0){
            DeRef(_6732);
            _6732 = NOVALUE;
            goto L7; // [613] 736
        }
        DeRef(_6732);
        _6732 = NOVALUE;
    }
    DeRef(_6732);
    _6732 = NOVALUE;

    /** 			scan_multicomment()*/
    _6733 = _29scan_multicomment();
    goto L7; // [623] 736
L5: 

    /** 	elsif scan_identifier() then*/
    _6734 = _29scan_identifier();
    if (_6734 == 0) {
        DeRef(_6734);
        _6734 = NOVALUE;
        goto L11; // [631] 637
    }
    else {
        if (!IS_ATOM_INT(_6734) && DBL_PTR(_6734)->dbl == 0.0){
            DeRef(_6734);
            _6734 = NOVALUE;
            goto L11; // [631] 637
        }
        DeRef(_6734);
        _6734 = NOVALUE;
    }
    DeRef(_6734);
    _6734 = NOVALUE;
    goto L7; // [634] 736
L11: 

    /** 	elsif scan_qchar() then*/
    _6735 = _29scan_qchar();
    if (_6735 == 0) {
        DeRef(_6735);
        _6735 = NOVALUE;
        goto L12; // [642] 648
    }
    else {
        if (!IS_ATOM_INT(_6735) && DBL_PTR(_6735)->dbl == 0.0){
            DeRef(_6735);
            _6735 = NOVALUE;
            goto L12; // [642] 648
        }
        DeRef(_6735);
        _6735 = NOVALUE;
    }
    DeRef(_6735);
    _6735 = NOVALUE;
    goto L7; // [645] 736
L12: 

    /** 	elsif scan_string() then*/
    _6736 = _29scan_string();
    if (_6736 == 0) {
        DeRef(_6736);
        _6736 = NOVALUE;
        goto L13; // [653] 659
    }
    else {
        if (!IS_ATOM_INT(_6736) && DBL_PTR(_6736)->dbl == 0.0){
            DeRef(_6736);
            _6736 = NOVALUE;
            goto L13; // [653] 659
        }
        DeRef(_6736);
        _6736 = NOVALUE;
    }
    DeRef(_6736);
    _6736 = NOVALUE;
    goto L7; // [656] 736
L13: 

    /** 	elsif scan_multistring() then*/
    _6737 = _29scan_multistring();
    if (_6737 == 0) {
        DeRef(_6737);
        _6737 = NOVALUE;
        goto L14; // [664] 670
    }
    else {
        if (!IS_ATOM_INT(_6737) && DBL_PTR(_6737)->dbl == 0.0){
            DeRef(_6737);
            _6737 = NOVALUE;
            goto L14; // [664] 670
        }
        DeRef(_6737);
        _6737 = NOVALUE;
    }
    DeRef(_6737);
    _6737 = NOVALUE;
    goto L7; // [667] 736
L14: 

    /** 	elsif scan_prefixed_number() then*/
    _6738 = _29scan_prefixed_number();
    if (_6738 == 0) {
        DeRef(_6738);
        _6738 = NOVALUE;
        goto L15; // [675] 681
    }
    else {
        if (!IS_ATOM_INT(_6738) && DBL_PTR(_6738)->dbl == 0.0){
            DeRef(_6738);
            _6738 = NOVALUE;
            goto L15; // [675] 681
        }
        DeRef(_6738);
        _6738 = NOVALUE;
    }
    DeRef(_6738);
    _6738 = NOVALUE;
    goto L7; // [678] 736
L15: 

    /** 	elsif scan_hex() then*/
    _6739 = _29scan_hex();
    if (_6739 == 0) {
        DeRef(_6739);
        _6739 = NOVALUE;
        goto L16; // [686] 692
    }
    else {
        if (!IS_ATOM_INT(_6739) && DBL_PTR(_6739)->dbl == 0.0){
            DeRef(_6739);
            _6739 = NOVALUE;
            goto L16; // [686] 692
        }
        DeRef(_6739);
        _6739 = NOVALUE;
    }
    DeRef(_6739);
    _6739 = NOVALUE;
    goto L7; // [689] 736
L16: 

    /** 	elsif scan_number() then*/
    _6740 = _29scan_number();
    if (_6740 == 0) {
        DeRef(_6740);
        _6740 = NOVALUE;
        goto L17; // [697] 703
    }
    else {
        if (!IS_ATOM_INT(_6740) && DBL_PTR(_6740)->dbl == 0.0){
            DeRef(_6740);
            _6740 = NOVALUE;
            goto L17; // [697] 703
        }
        DeRef(_6740);
        _6740 = NOVALUE;
    }
    DeRef(_6740);
    _6740 = NOVALUE;
    goto L7; // [700] 736
L17: 

    /** 		Token[TTYPE] = T_EOF*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 		Token[TDATA] = Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29Look_11383;
    DeRef(_1);

    /** 		if (Look != io:EOF) then*/
    if (_29Look_11383 == -1)
    goto L18; // [725] 735

    /** 			report_error(ERR_UNKNOWN)*/
    _29report_error(8);
L18: 
L7: 

    /** end procedure*/
    DeRef(_6678);
    _6678 = NOVALUE;
    DeRef(_6695);
    _6695 = NOVALUE;
    DeRef(_6721);
    _6721 = NOVALUE;
    DeRef(_6729);
    _6729 = NOVALUE;
    DeRef(_6733);
    _6733 = NOVALUE;
    return;
    ;
}


int  __stdcall _29tokenize_string(int _code_11996)
{
    int _tokens_11997 = NOVALUE;
    int _6761 = NOVALUE;
    int _6759 = NOVALUE;
    int _6757 = NOVALUE;
    int _6754 = NOVALUE;
    int _6753 = NOVALUE;
    int _6752 = NOVALUE;
    int _6750 = NOVALUE;
    int _6748 = NOVALUE;
    int _6747 = NOVALUE;
    int _6746 = NOVALUE;
    int _6745 = NOVALUE;
    int _6744 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ERR = FALSE*/
    _29ERR_11384 = 0;

    /** 	ERR_LNUM = 0*/
    _29ERR_LNUM_11385 = 0;

    /** 	ERR_LPOS = 0*/
    _29ERR_LPOS_11386 = 0;

    /** 	tokens = {}*/
    RefDS(_5);
    DeRef(_tokens_11997);
    _tokens_11997 = _5;

    /** 	source_text = code & EOL & io:EOF*/
    {
        int concat_list[3];

        concat_list[0] = -1;
        concat_list[1] = 10;
        concat_list[2] = _code_11996;
        Concat_N((object_ptr)&_29source_text_11379, concat_list, 3);
    }

    /** 	LNum = 1*/
    _29LNum_11381 = 1;

    /** 	LPos = 1*/
    _29LPos_11382 = 1;

    /** 	sti = 1*/
    _29sti_11380 = 1;

    /** 	Look = source_text[sti]*/
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _29Look_11383 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_29Look_11383))
    _29Look_11383 = (long)DBL_PTR(_29Look_11383)->dbl;

    /** 	Token[TTYPE] = io:EOF*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TLNUM] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	Token[TLPOS] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	if (Look = '#') and (source_text[sti+1] = '!') then*/
    _6744 = (_29Look_11383 == 35);
    if (_6744 == 0) {
        goto L1; // [98] 202
    }
    _6746 = 2;
    _2 = (int)SEQ_PTR(_29source_text_11379);
    _6747 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6747)) {
        _6748 = (_6747 == 33);
    }
    else {
        _6748 = binary_op(EQUALS, _6747, 33);
    }
    _6747 = NOVALUE;
    if (_6748 == 0) {
        DeRef(_6748);
        _6748 = NOVALUE;
        goto L1; // [119] 202
    }
    else {
        if (!IS_ATOM_INT(_6748) && DBL_PTR(_6748)->dbl == 0.0){
            DeRef(_6748);
            _6748 = NOVALUE;
            goto L1; // [119] 202
        }
        DeRef(_6748);
        _6748 = NOVALUE;
    }
    DeRef(_6748);
    _6748 = NOVALUE;

    /** 		sti += 1*/
    _29sti_11380 = _29sti_11380 + 1;

    /** 		scan_char()*/
    _29scan_char();

    /** 		scan_white()*/
    _6750 = _29scan_white();

    /** 		Token[TTYPE] = T_SHBANG*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 		while Look != EOL do*/
L2: 
    if (_29Look_11383 == 10)
    goto L3; // [154] 185

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6752 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6752) && IS_ATOM(_29Look_11383)) {
        Append(&_6753, _6752, _29Look_11383);
    }
    else if (IS_ATOM(_6752) && IS_SEQUENCE(_29Look_11383)) {
    }
    else {
        Concat((object_ptr)&_6753, _6752, _29Look_11383);
        _6752 = NOVALUE;
    }
    _6752 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6753;
    if( _1 != _6753 ){
        DeRef(_1);
    }
    _6753 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L2; // [182] 152
L3: 

    /** 		scan_char()*/
    _29scan_char();

    /** 		tokens &= { Token }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_29Token_11377);
    *((int *)(_2+4)) = _29Token_11377;
    _6754 = MAKE_SEQ(_1);
    Concat((object_ptr)&_tokens_11997, _tokens_11997, _6754);
    DeRefDS(_6754);
    _6754 = NOVALUE;
L1: 

    /** 	next_token()*/
    _29next_token();

    /** 	if not ERR then*/
    if (_29ERR_11384 != 0)
    goto L4; // [210] 262

    /** 		while Token[TTYPE] != T_EOF do*/
L5: 
    _2 = (int)SEQ_PTR(_29Token_11377);
    _6757 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6757, 1)){
        _6757 = NOVALUE;
        goto L6; // [224] 261
    }
    _6757 = NOVALUE;

    /** 			tokens &= { Token }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_29Token_11377);
    *((int *)(_2+4)) = _29Token_11377;
    _6759 = MAKE_SEQ(_1);
    Concat((object_ptr)&_tokens_11997, _tokens_11997, _6759);
    DeRefDS(_6759);
    _6759 = NOVALUE;

    /** 			next_token()*/
    _29next_token();

    /** 			if ERR then*/
    if (_29ERR_11384 == 0)
    {
        goto L5; // [248] 218
    }
    else{
    }

    /** 				exit */
    goto L6; // [253] 261

    /** 		end while*/
    goto L5; // [258] 218
L6: 
L4: 

    /** 	return { tokens, ERR, ERR_LNUM, ERR_LPOS }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_tokens_11997);
    *((int *)(_2+4)) = _tokens_11997;
    *((int *)(_2+8)) = _29ERR_11384;
    *((int *)(_2+12)) = _29ERR_LNUM_11385;
    *((int *)(_2+16)) = _29ERR_LPOS_11386;
    _6761 = MAKE_SEQ(_1);
    DeRefDS(_code_11996);
    DeRefDS(_tokens_11997);
    DeRef(_6744);
    _6744 = NOVALUE;
    DeRef(_6746);
    _6746 = NOVALUE;
    DeRef(_6750);
    _6750 = NOVALUE;
    return _6761;
    ;
}


int  __stdcall _29tokenize_file(int _fname_12025)
{
    int _txt_12026 = NOVALUE;
    int _6767 = NOVALUE;
    int _6766 = NOVALUE;
    int _6765 = NOVALUE;
    int _6764 = NOVALUE;
    int _6763 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object txt = io:read_file(fname, io:TEXT_MODE)*/
    RefDS(_fname_12025);
    _0 = _txt_12026;
    _txt_12026 = _18read_file(_fname_12025, 2);
    DeRef(_0);

    /** 	if atom(txt) and txt = -1 then*/
    _6763 = IS_ATOM(_txt_12026);
    if (_6763 == 0) {
        goto L1; // [15] 45
    }
    if (IS_ATOM_INT(_txt_12026)) {
        _6765 = (_txt_12026 == -1);
    }
    else {
        _6765 = binary_op(EQUALS, _txt_12026, -1);
    }
    if (_6765 == 0) {
        DeRef(_6765);
        _6765 = NOVALUE;
        goto L1; // [24] 45
    }
    else {
        if (!IS_ATOM_INT(_6765) && DBL_PTR(_6765)->dbl == 0.0){
            DeRef(_6765);
            _6765 = NOVALUE;
            goto L1; // [24] 45
        }
        DeRef(_6765);
        _6765 = NOVALUE;
    }
    DeRef(_6765);
    _6765 = NOVALUE;

    /** 		return {{}, ERR_OPEN, ERR_LNUM, ERR_LPOS}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _29ERR_LNUM_11385;
    *((int *)(_2+16)) = _29ERR_LPOS_11386;
    _6766 = MAKE_SEQ(_1);
    DeRefDS(_fname_12025);
    DeRef(_txt_12026);
    return _6766;
L1: 

    /** 	return tokenize_string(txt)*/
    Ref(_txt_12026);
    _6767 = _29tokenize_string(_txt_12026);
    DeRefDS(_fname_12025);
    DeRef(_txt_12026);
    DeRef(_6766);
    _6766 = NOVALUE;
    return _6767;
    ;
}


void  __stdcall _29show_tokens(int _fh_12088, int _tokens_12089)
{
    int _v_12106 = NOVALUE;
    int _6863 = NOVALUE;
    int _6862 = NOVALUE;
    int _6861 = NOVALUE;
    int _6860 = NOVALUE;
    int _6859 = NOVALUE;
    int _6858 = NOVALUE;
    int _6856 = NOVALUE;
    int _6855 = NOVALUE;
    int _6854 = NOVALUE;
    int _6852 = NOVALUE;
    int _6851 = NOVALUE;
    int _6850 = NOVALUE;
    int _6849 = NOVALUE;
    int _6847 = NOVALUE;
    int _6846 = NOVALUE;
    int _6845 = NOVALUE;
    int _6843 = NOVALUE;
    int _6842 = NOVALUE;
    int _6841 = NOVALUE;
    int _6840 = NOVALUE;
    int _6837 = NOVALUE;
    int _6835 = NOVALUE;
    int _6833 = NOVALUE;
    int _6832 = NOVALUE;
    int _6830 = NOVALUE;
    int _6829 = NOVALUE;
    int _6828 = NOVALUE;
    int _6827 = NOVALUE;
    int _6826 = NOVALUE;
    int _6825 = NOVALUE;
    int _6824 = NOVALUE;
    int _6820 = NOVALUE;
    int _6819 = NOVALUE;
    int _6818 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_12088)) {
        _1 = (long)(DBL_PTR(_fh_12088)->dbl);
        DeRefDS(_fh_12088);
        _fh_12088 = _1;
    }

    /** 	for i = 1 to length(tokens) do*/
    if (IS_SEQUENCE(_tokens_12089)){
            _6818 = SEQ_PTR(_tokens_12089)->length;
    }
    else {
        _6818 = 1;
    }
    {
        int _i_12091;
        _i_12091 = 1;
L1: 
        if (_i_12091 > _6818){
            goto L2; // [10] 271
        }

        /** 		switch tokens[i][TTYPE] do*/
        _2 = (int)SEQ_PTR(_tokens_12089);
        _6819 = (int)*(((s1_ptr)_2)->base + _i_12091);
        _2 = (int)SEQ_PTR(_6819);
        _6820 = (int)*(((s1_ptr)_2)->base + 1);
        _6819 = NOVALUE;
        if (IS_SEQUENCE(_6820) ){
            goto L3; // [27] 167
        }
        if(!IS_ATOM_INT(_6820)){
            if( (DBL_PTR(_6820)->dbl != (double) ((int) DBL_PTR(_6820)->dbl) ) ){
                goto L3; // [27] 167
            }
            _0 = (int) DBL_PTR(_6820)->dbl;
        }
        else {
            _0 = _6820;
        };
        _6820 = NOVALUE;
        switch ( _0 ){ 

            /** 			case T_STRING then*/
            case 8:

            /** 				printf(fh, "T_STRING %20s : [[[%s]]]\n", { */
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6824 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6824);
            _6825 = (int)*(((s1_ptr)_2)->base + 5);
            _6824 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_forms_12075);
            if (!IS_ATOM_INT(_6825)){
                _6826 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6825)->dbl));
            }
            else{
                _6826 = (int)*(((s1_ptr)_2)->base + _6825);
            }
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6827 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6827);
            _6828 = (int)*(((s1_ptr)_2)->base + 2);
            _6827 = NOVALUE;
            Ref(_6828);
            RefDS(_6826);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6826;
            ((int *)_2)[2] = _6828;
            _6829 = MAKE_SEQ(_1);
            _6828 = NOVALUE;
            _6826 = NOVALUE;
            EPrintf(_fh_12088, _6823, _6829);
            DeRefDS(_6829);
            _6829 = NOVALUE;
            goto L4; // [68] 264

            /** 			case T_NUMBER then*/
            case 6:

            /** 				object v = tokens[i][TDATA]*/
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6830 = (int)*(((s1_ptr)_2)->base + _i_12091);
            DeRef(_v_12106);
            _2 = (int)SEQ_PTR(_6830);
            _v_12106 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_v_12106);
            _6830 = NOVALUE;

            /** 				if integer(v) then*/
            if (IS_ATOM_INT(_v_12106))
            _6832 = 1;
            else if (IS_ATOM_DBL(_v_12106))
            _6832 = IS_ATOM_INT(DoubleToInt(_v_12106));
            else
            _6832 = 0;
            if (_6832 == 0)
            {
                _6832 = NOVALUE;
                goto L5; // [89] 105
            }
            else{
                _6832 = NOVALUE;
            }

            /** 					v = sprintf("%d", { v })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_v_12106);
            *((int *)(_2+4)) = _v_12106;
            _6833 = MAKE_SEQ(_1);
            DeRef(_v_12106);
            _v_12106 = EPrintf(-9999999, _919, _6833);
            DeRefDS(_6833);
            _6833 = NOVALUE;
            goto L6; // [102] 125
L5: 

            /** 				elsif atom(v) then*/
            _6835 = IS_ATOM(_v_12106);
            if (_6835 == 0)
            {
                _6835 = NOVALUE;
                goto L7; // [110] 124
            }
            else{
                _6835 = NOVALUE;
            }

            /** 					v = sprintf("%f", { v })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_v_12106);
            *((int *)(_2+4)) = _v_12106;
            _6837 = MAKE_SEQ(_1);
            DeRef(_v_12106);
            _v_12106 = EPrintf(-9999999, _6836, _6837);
            DeRefDS(_6837);
            _6837 = NOVALUE;
L7: 
L6: 

            /** 				printf(fh, "T_NUMBER %20s : %s\n", { */
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6840 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6840);
            _6841 = (int)*(((s1_ptr)_2)->base + 5);
            _6840 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_forms_12075);
            if (!IS_ATOM_INT(_6841)){
                _6842 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6841)->dbl));
            }
            else{
                _6842 = (int)*(((s1_ptr)_2)->base + _6841);
            }
            Ref(_v_12106);
            RefDS(_6842);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6842;
            ((int *)_2)[2] = _v_12106;
            _6843 = MAKE_SEQ(_1);
            _6842 = NOVALUE;
            EPrintf(_fh_12088, _6839, _6843);
            DeRefDS(_6843);
            _6843 = NOVALUE;
            DeRef(_v_12106);
            _v_12106 = NOVALUE;
            goto L4; // [151] 264

            /** 			case T_NEWLINE then*/
            case 4:

            /** 				printf(fh, "T_NEWLINE                     : \\n\n", {})*/
            EPrintf(_fh_12088, _6844, _5);
            goto L4; // [163] 264

            /** 			case else*/
            default:
L3: 

            /** 				if tokens[i][TTYPE] < 1 or tokens[i][TTYPE] > length(token_names) then*/
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6845 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6845);
            _6846 = (int)*(((s1_ptr)_2)->base + 1);
            _6845 = NOVALUE;
            if (IS_ATOM_INT(_6846)) {
                _6847 = (_6846 < 1);
            }
            else {
                _6847 = binary_op(LESS, _6846, 1);
            }
            _6846 = NOVALUE;
            if (IS_ATOM_INT(_6847)) {
                if (_6847 != 0) {
                    goto L8; // [183] 209
                }
            }
            else {
                if (DBL_PTR(_6847)->dbl != 0.0) {
                    goto L8; // [183] 209
                }
            }
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6849 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6849);
            _6850 = (int)*(((s1_ptr)_2)->base + 1);
            _6849 = NOVALUE;
            _6851 = 39;
            if (IS_ATOM_INT(_6850)) {
                _6852 = (_6850 > 39);
            }
            else {
                _6852 = binary_op(GREATER, _6850, 39);
            }
            _6850 = NOVALUE;
            _6851 = NOVALUE;
            if (_6852 == 0) {
                DeRef(_6852);
                _6852 = NOVALUE;
                goto L9; // [205] 230
            }
            else {
                if (!IS_ATOM_INT(_6852) && DBL_PTR(_6852)->dbl == 0.0){
                    DeRef(_6852);
                    _6852 = NOVALUE;
                    goto L9; // [205] 230
                }
                DeRef(_6852);
                _6852 = NOVALUE;
            }
            DeRef(_6852);
            _6852 = NOVALUE;
L8: 

            /** 					printf(fh, "UNKNOWN                       : %d\n", { tokens[i][TTYPE] })*/
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6854 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6854);
            _6855 = (int)*(((s1_ptr)_2)->base + 1);
            _6854 = NOVALUE;
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_6855);
            *((int *)(_2+4)) = _6855;
            _6856 = MAKE_SEQ(_1);
            _6855 = NOVALUE;
            EPrintf(_fh_12088, _6853, _6856);
            DeRefDS(_6856);
            _6856 = NOVALUE;
            goto LA; // [227] 263
L9: 

            /** 					printf(fh, "%-29s : %s\n", { */
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6858 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6858);
            _6859 = (int)*(((s1_ptr)_2)->base + 1);
            _6858 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_names_12034);
            if (!IS_ATOM_INT(_6859)){
                _6860 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6859)->dbl));
            }
            else{
                _6860 = (int)*(((s1_ptr)_2)->base + _6859);
            }
            _2 = (int)SEQ_PTR(_tokens_12089);
            _6861 = (int)*(((s1_ptr)_2)->base + _i_12091);
            _2 = (int)SEQ_PTR(_6861);
            _6862 = (int)*(((s1_ptr)_2)->base + 2);
            _6861 = NOVALUE;
            Ref(_6862);
            RefDS(_6860);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6860;
            ((int *)_2)[2] = _6862;
            _6863 = MAKE_SEQ(_1);
            _6862 = NOVALUE;
            _6860 = NOVALUE;
            EPrintf(_fh_12088, _6857, _6863);
            DeRefDS(_6863);
            _6863 = NOVALUE;
LA: 
        ;}L4: 

        /** 	end for*/
        _i_12091 = _i_12091 + 1;
        goto L1; // [266] 17
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_tokens_12089);
    _6825 = NOVALUE;
    _6841 = NOVALUE;
    _6859 = NOVALUE;
    DeRef(_6847);
    _6847 = NOVALUE;
    return;
    ;
}



// 0x8683E37D
