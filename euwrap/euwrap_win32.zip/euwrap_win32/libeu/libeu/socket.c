// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _48error_code()
{
    int _12341 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_ERROR_CODE, {})*/
    _12341 = machine(96, _5);
    return _12341;
    ;
}


int  __stdcall _48socket(int _o_22353)
{
    int _12513 = NOVALUE;
    int _12512 = NOVALUE;
    int _12510 = NOVALUE;
    int _12509 = NOVALUE;
    int _12507 = NOVALUE;
    int _12505 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(o) then */
    _12505 = IS_SEQUENCE(_o_22353);
    if (_12505 != 0)
    goto L1; // [6] 16
    _12505 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22353);
    return 0;
L1: 

    /**     if length(o) != 2 then */
    if (IS_SEQUENCE(_o_22353)){
            _12507 = SEQ_PTR(_o_22353)->length;
    }
    else {
        _12507 = 1;
    }
    if (_12507 == 2)
    goto L2; // [21] 32

    /**         return 0 */
    DeRef(_o_22353);
    return 0;
L2: 

    /**     if not atom(o[1]) then */
    _2 = (int)SEQ_PTR(_o_22353);
    _12509 = (int)*(((s1_ptr)_2)->base + 1);
    _12510 = IS_ATOM(_12509);
    _12509 = NOVALUE;
    if (_12510 != 0)
    goto L3; // [41] 51
    _12510 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22353);
    return 0;
L3: 

    /**     if not atom(o[2]) then */
    _2 = (int)SEQ_PTR(_o_22353);
    _12512 = (int)*(((s1_ptr)_2)->base + 2);
    _12513 = IS_ATOM(_12512);
    _12512 = NOVALUE;
    if (_12513 != 0)
    goto L4; // [60] 70
    _12513 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22353);
    return 0;
L4: 

    /** 	return 1*/
    DeRef(_o_22353);
    return 1;
    ;
}


void _48delete_socket(int _o_22370)
{
    int _12519 = NOVALUE;
    int _12517 = NOVALUE;
    int _12515 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not socket(o) then*/
    Ref(_o_22370);
    _12515 = _48socket(_o_22370);
    if (IS_ATOM_INT(_12515)) {
        if (_12515 != 0){
            DeRef(_12515);
            _12515 = NOVALUE;
            goto L1; // [7] 16
        }
    }
    else {
        if (DBL_PTR(_12515)->dbl != 0.0){
            DeRef(_12515);
            _12515 = NOVALUE;
            goto L1; // [7] 16
        }
    }
    DeRef(_12515);
    _12515 = NOVALUE;

    /** 		return*/
    DeRef(_o_22370);
    return;
L1: 

    /** 	if o[SOCKET_SOCKADDR_IN] = 0 then*/
    _2 = (int)SEQ_PTR(_o_22370);
    _12517 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _12517, 0)){
        _12517 = NOVALUE;
        goto L2; // [22] 32
    }
    _12517 = NOVALUE;

    /** 		return*/
    DeRef(_o_22370);
    return;
L2: 

    /** 	machine:free(o[SOCKET_SOCKADDR_IN])*/
    _2 = (int)SEQ_PTR(_o_22370);
    _12519 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_12519);
    _14free(_12519);
    _12519 = NOVALUE;

    /** end procedure*/
    DeRef(_o_22370);
    return;
    ;
}


int  __stdcall _48create(int _family_22383, int _sock_type_22384, int _protocol_22385)
{
    int _o_22386 = NOVALUE;
    int _12525 = NOVALUE;
    int _12524 = NOVALUE;
    int _12522 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_family_22383)) {
        _1 = (long)(DBL_PTR(_family_22383)->dbl);
        DeRefDS(_family_22383);
        _family_22383 = _1;
    }
    if (!IS_ATOM_INT(_sock_type_22384)) {
        _1 = (long)(DBL_PTR(_sock_type_22384)->dbl);
        DeRefDS(_sock_type_22384);
        _sock_type_22384 = _1;
    }
    if (!IS_ATOM_INT(_protocol_22385)) {
        _1 = (long)(DBL_PTR(_protocol_22385)->dbl);
        DeRefDS(_protocol_22385);
        _protocol_22385 = _1;
    }

    /** 	object o = machine_func(M_SOCK_SOCKET, { family, sock_type, protocol })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _family_22383;
    *((int *)(_2+8)) = _sock_type_22384;
    *((int *)(_2+12)) = _protocol_22385;
    _12522 = MAKE_SEQ(_1);
    DeRef(_o_22386);
    _o_22386 = machine(81, _12522);
    DeRefDS(_12522);
    _12522 = NOVALUE;

    /** 	if atom(o) then*/
    _12524 = IS_ATOM(_o_22386);
    if (_12524 == 0)
    {
        _12524 = NOVALUE;
        goto L1; // [24] 34
    }
    else{
        _12524 = NOVALUE;
    }

    /**         return o */
    return _o_22386;
L1: 

    /**     return delete_routine(o, delete_socket_rid)*/
    DeRef(_12525);
    if( IS_ATOM_INT(_o_22386) ){
        _12525 = NewDouble( (double) _o_22386 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_o_22386)) ){
            if( IS_ATOM_DBL( _o_22386 ) ){
                _12525 = NewDouble( DBL_PTR(_o_22386)->dbl );
            }
            else {
                RefDS(_o_22386);
                _12525 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_o_22386) ));
            }
        }
        else {
            _12525 = _o_22386;
        }
    }
    _1 = (int) _00[_48delete_socket_rid_22378].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_48delete_socket_rid_22378].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _48delete_socket_rid_22378;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_12525) ){
        if( IS_ATOM_INT(_12525) ){
            _12525 = NewDouble( (double) _o_22386 );
        }
        if(DBL_PTR(_12525)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_12525)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_12525)) ){
            DeRefDS(_12525);
            _12525 = NewDouble( DBL_PTR(_12525)->dbl );
        }
        DBL_PTR(_12525)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_12525)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_12525)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_12525)) ){
            _12525 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_12525) ));
        }
        SEQ_PTR(_12525)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_o_22386) ){
        RefDS(_12525);
    }
    DeRef(_o_22386);
    return _12525;
    ;
}


int  __stdcall _48close(int _sock_22394)
{
    int _12527 = NOVALUE;
    int _12526 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22394);
    *((int *)(_2+4)) = _sock_22394;
    _12526 = MAKE_SEQ(_1);
    _12527 = machine(82, _12526);
    DeRefDS(_12526);
    _12526 = NOVALUE;
    DeRef(_sock_22394);
    return _12527;
    ;
}


int  __stdcall _48shutdown(int _sock_22399, int _method_22400)
{
    int _12529 = NOVALUE;
    int _12528 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_SHUTDOWN, { sock, method })*/
    Ref(_method_22400);
    Ref(_sock_22399);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22399;
    ((int *)_2)[2] = _method_22400;
    _12528 = MAKE_SEQ(_1);
    _12529 = machine(83, _12528);
    DeRefDS(_12528);
    _12528 = NOVALUE;
    DeRef(_sock_22399);
    DeRef(_method_22400);
    return _12529;
    ;
}


int  __stdcall _48select(int _sockets_read_22405, int _sockets_write_22406, int _sockets_err_22407, int _timeout_22408, int _timeout_micro_22409)
{
    int _sockets_all_22410 = NOVALUE;
    int _12548 = NOVALUE;
    int _12547 = NOVALUE;
    int _12545 = NOVALUE;
    int _12544 = NOVALUE;
    int _12543 = NOVALUE;
    int _12542 = NOVALUE;
    int _12540 = NOVALUE;
    int _12539 = NOVALUE;
    int _12538 = NOVALUE;
    int _12536 = NOVALUE;
    int _12535 = NOVALUE;
    int _12534 = NOVALUE;
    int _12532 = NOVALUE;
    int _12531 = NOVALUE;
    int _12530 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_timeout_22408)) {
        _1 = (long)(DBL_PTR(_timeout_22408)->dbl);
        DeRefDS(_timeout_22408);
        _timeout_22408 = _1;
    }
    if (!IS_ATOM_INT(_timeout_micro_22409)) {
        _1 = (long)(DBL_PTR(_timeout_micro_22409)->dbl);
        DeRefDS(_timeout_micro_22409);
        _timeout_micro_22409 = _1;
    }

    /** 	if length(sockets_read) and socket(sockets_read) then*/
    if (IS_SEQUENCE(_sockets_read_22405)){
            _12530 = SEQ_PTR(_sockets_read_22405)->length;
    }
    else {
        _12530 = 1;
    }
    if (_12530 == 0) {
        goto L1; // [10] 29
    }
    Ref(_sockets_read_22405);
    _12532 = _48socket(_sockets_read_22405);
    if (_12532 == 0) {
        DeRef(_12532);
        _12532 = NOVALUE;
        goto L1; // [19] 29
    }
    else {
        if (!IS_ATOM_INT(_12532) && DBL_PTR(_12532)->dbl == 0.0){
            DeRef(_12532);
            _12532 = NOVALUE;
            goto L1; // [19] 29
        }
        DeRef(_12532);
        _12532 = NOVALUE;
    }
    DeRef(_12532);
    _12532 = NOVALUE;

    /** 		sockets_read = { sockets_read }*/
    _0 = _sockets_read_22405;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_read_22405);
    *((int *)(_2+4)) = _sockets_read_22405;
    _sockets_read_22405 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if length(sockets_write) and socket(sockets_write) then*/
    if (IS_SEQUENCE(_sockets_write_22406)){
            _12534 = SEQ_PTR(_sockets_write_22406)->length;
    }
    else {
        _12534 = 1;
    }
    if (_12534 == 0) {
        goto L2; // [34] 53
    }
    Ref(_sockets_write_22406);
    _12536 = _48socket(_sockets_write_22406);
    if (_12536 == 0) {
        DeRef(_12536);
        _12536 = NOVALUE;
        goto L2; // [43] 53
    }
    else {
        if (!IS_ATOM_INT(_12536) && DBL_PTR(_12536)->dbl == 0.0){
            DeRef(_12536);
            _12536 = NOVALUE;
            goto L2; // [43] 53
        }
        DeRef(_12536);
        _12536 = NOVALUE;
    }
    DeRef(_12536);
    _12536 = NOVALUE;

    /** 		sockets_write = { sockets_write }*/
    _0 = _sockets_write_22406;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_write_22406);
    *((int *)(_2+4)) = _sockets_write_22406;
    _sockets_write_22406 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if length(sockets_err) and socket(sockets_err) then*/
    if (IS_SEQUENCE(_sockets_err_22407)){
            _12538 = SEQ_PTR(_sockets_err_22407)->length;
    }
    else {
        _12538 = 1;
    }
    if (_12538 == 0) {
        goto L3; // [58] 77
    }
    Ref(_sockets_err_22407);
    _12540 = _48socket(_sockets_err_22407);
    if (_12540 == 0) {
        DeRef(_12540);
        _12540 = NOVALUE;
        goto L3; // [67] 77
    }
    else {
        if (!IS_ATOM_INT(_12540) && DBL_PTR(_12540)->dbl == 0.0){
            DeRef(_12540);
            _12540 = NOVALUE;
            goto L3; // [67] 77
        }
        DeRef(_12540);
        _12540 = NOVALUE;
    }
    DeRef(_12540);
    _12540 = NOVALUE;

    /** 		sockets_err = { sockets_err }*/
    _0 = _sockets_err_22407;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_err_22407);
    *((int *)(_2+4)) = _sockets_err_22407;
    _sockets_err_22407 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	if equal(sockets_err, sockets_read) and*/
    if (_sockets_err_22407 == _sockets_read_22405)
    _12542 = 1;
    else if (IS_ATOM_INT(_sockets_err_22407) && IS_ATOM_INT(_sockets_read_22405))
    _12542 = 0;
    else
    _12542 = (compare(_sockets_err_22407, _sockets_read_22405) == 0);
    if (_12542 == 0) {
        goto L4; // [83] 105
    }
    if (_sockets_write_22406 == _sockets_read_22405)
    _12544 = 1;
    else if (IS_ATOM_INT(_sockets_write_22406) && IS_ATOM_INT(_sockets_read_22405))
    _12544 = 0;
    else
    _12544 = (compare(_sockets_write_22406, _sockets_read_22405) == 0);
    if (_12544 == 0)
    {
        _12544 = NOVALUE;
        goto L4; // [92] 105
    }
    else{
        _12544 = NOVALUE;
    }

    /** 		sockets_all = sockets_read*/
    Ref(_sockets_read_22405);
    DeRef(_sockets_all_22410);
    _sockets_all_22410 = _sockets_read_22405;
    goto L5; // [102] 121
L4: 

    /** 		sockets_all = stdseq:remove_dups(sockets_read & sockets_write*/
    {
        int concat_list[3];

        concat_list[0] = _sockets_err_22407;
        concat_list[1] = _sockets_write_22406;
        concat_list[2] = _sockets_read_22405;
        Concat_N((object_ptr)&_12545, concat_list, 3);
    }
    _0 = _sockets_all_22410;
    _sockets_all_22410 = _23remove_dups(_12545, 3);
    DeRef(_0);
    _12545 = NOVALUE;
L5: 

    /** 	return machine_func(M_SOCK_SELECT, { sockets_read, sockets_write,*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_read_22405);
    *((int *)(_2+4)) = _sockets_read_22405;
    Ref(_sockets_write_22406);
    *((int *)(_2+8)) = _sockets_write_22406;
    Ref(_sockets_err_22407);
    *((int *)(_2+12)) = _sockets_err_22407;
    RefDS(_sockets_all_22410);
    *((int *)(_2+16)) = _sockets_all_22410;
    *((int *)(_2+20)) = _timeout_micro_22409;
    *((int *)(_2+24)) = _timeout_22408;
    _12547 = MAKE_SEQ(_1);
    _12548 = machine(92, _12547);
    DeRefDS(_12547);
    _12547 = NOVALUE;
    DeRef(_sockets_read_22405);
    DeRef(_sockets_write_22406);
    DeRef(_sockets_err_22407);
    DeRefDS(_sockets_all_22410);
    return _12548;
    ;
}


int  __stdcall _48send(int _sock_22437, int _data_22438, int _flags_22439)
{
    int _12550 = NOVALUE;
    int _12549 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_SEND, { sock, data, flags })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22437);
    *((int *)(_2+4)) = _sock_22437;
    RefDS(_data_22438);
    *((int *)(_2+8)) = _data_22438;
    Ref(_flags_22439);
    *((int *)(_2+12)) = _flags_22439;
    _12549 = MAKE_SEQ(_1);
    _12550 = machine(85, _12549);
    DeRefDS(_12549);
    _12549 = NOVALUE;
    DeRef(_sock_22437);
    DeRefDS(_data_22438);
    DeRef(_flags_22439);
    return _12550;
    ;
}


int  __stdcall _48receive(int _sock_22444, int _flags_22445)
{
    int _12552 = NOVALUE;
    int _12551 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_RECV, { sock, flags })*/
    Ref(_flags_22445);
    Ref(_sock_22444);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22444;
    ((int *)_2)[2] = _flags_22445;
    _12551 = MAKE_SEQ(_1);
    _12552 = machine(86, _12551);
    DeRefDS(_12551);
    _12551 = NOVALUE;
    DeRef(_sock_22444);
    DeRef(_flags_22445);
    return _12552;
    ;
}


int  __stdcall _48get_option(int _sock_22450, int _level_22451, int _optname_22452)
{
    int _12554 = NOVALUE;
    int _12553 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_level_22451)) {
        _1 = (long)(DBL_PTR(_level_22451)->dbl);
        DeRefDS(_level_22451);
        _level_22451 = _1;
    }
    if (!IS_ATOM_INT(_optname_22452)) {
        _1 = (long)(DBL_PTR(_optname_22452)->dbl);
        DeRefDS(_optname_22452);
        _optname_22452 = _1;
    }

    /** 	return machine_func(M_SOCK_GETSOCKOPT, { sock, level, optname })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22450);
    *((int *)(_2+4)) = _sock_22450;
    *((int *)(_2+8)) = _level_22451;
    *((int *)(_2+12)) = _optname_22452;
    _12553 = MAKE_SEQ(_1);
    _12554 = machine(91, _12553);
    DeRefDS(_12553);
    _12553 = NOVALUE;
    DeRef(_sock_22450);
    return _12554;
    ;
}


int  __stdcall _48set_option(int _sock_22457, int _level_22458, int _optname_22459, int _val_22460)
{
    int _12556 = NOVALUE;
    int _12555 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_level_22458)) {
        _1 = (long)(DBL_PTR(_level_22458)->dbl);
        DeRefDS(_level_22458);
        _level_22458 = _1;
    }
    if (!IS_ATOM_INT(_optname_22459)) {
        _1 = (long)(DBL_PTR(_optname_22459)->dbl);
        DeRefDS(_optname_22459);
        _optname_22459 = _1;
    }

    /** 	return machine_func(M_SOCK_SETSOCKOPT, { sock, level, optname, val })*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22457);
    *((int *)(_2+4)) = _sock_22457;
    *((int *)(_2+8)) = _level_22458;
    *((int *)(_2+12)) = _optname_22459;
    Ref(_val_22460);
    *((int *)(_2+16)) = _val_22460;
    _12555 = MAKE_SEQ(_1);
    _12556 = machine(90, _12555);
    DeRefDS(_12555);
    _12555 = NOVALUE;
    DeRef(_sock_22457);
    DeRef(_val_22460);
    return _12556;
    ;
}


int  __stdcall _48connect(int _sock_22465, int _address_22466, int _port_22467)
{
    int _sock_data_22469 = NOVALUE;
    int _12562 = NOVALUE;
    int _12561 = NOVALUE;
    int _12560 = NOVALUE;
    int _12559 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22467)) {
        _1 = (long)(DBL_PTR(_port_22467)->dbl);
        DeRefDS(_port_22467);
        _port_22467 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22466);
    _0 = _sock_data_22469;
    _sock_data_22469 = _49parse_ip_address(_address_22466, _port_22467);
    DeRef(_0);

    /** 	return machine_func(M_SOCK_CONNECT, { sock, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22469);
    _12559 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22469);
    _12560 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22465);
    *((int *)(_2+4)) = _sock_22465;
    Ref(_12559);
    *((int *)(_2+8)) = _12559;
    Ref(_12560);
    *((int *)(_2+12)) = _12560;
    _12561 = MAKE_SEQ(_1);
    _12560 = NOVALUE;
    _12559 = NOVALUE;
    _12562 = machine(84, _12561);
    DeRefDS(_12561);
    _12561 = NOVALUE;
    DeRef(_sock_22465);
    DeRefDS(_address_22466);
    DeRef(_sock_data_22469);
    return _12562;
    ;
}


int  __stdcall _48bind(int _sock_22477, int _address_22478, int _port_22479)
{
    int _sock_data_22480 = NOVALUE;
    int _12567 = NOVALUE;
    int _12566 = NOVALUE;
    int _12565 = NOVALUE;
    int _12564 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22479)) {
        _1 = (long)(DBL_PTR(_port_22479)->dbl);
        DeRefDS(_port_22479);
        _port_22479 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22478);
    _0 = _sock_data_22480;
    _sock_data_22480 = _49parse_ip_address(_address_22478, _port_22479);
    DeRef(_0);

    /** 	return machine_func(M_SOCK_BIND, { sock, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22480);
    _12564 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22480);
    _12565 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22477);
    *((int *)(_2+4)) = _sock_22477;
    Ref(_12564);
    *((int *)(_2+8)) = _12564;
    Ref(_12565);
    *((int *)(_2+12)) = _12565;
    _12566 = MAKE_SEQ(_1);
    _12565 = NOVALUE;
    _12564 = NOVALUE;
    _12567 = machine(87, _12566);
    DeRefDS(_12566);
    _12566 = NOVALUE;
    DeRef(_sock_22477);
    DeRefDS(_address_22478);
    DeRef(_sock_data_22480);
    return _12567;
    ;
}


int  __stdcall _48listen(int _sock_22488, int _backlog_22489)
{
    int _12569 = NOVALUE;
    int _12568 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_backlog_22489)) {
        _1 = (long)(DBL_PTR(_backlog_22489)->dbl);
        DeRefDS(_backlog_22489);
        _backlog_22489 = _1;
    }

    /** 	return machine_func(M_SOCK_LISTEN, { sock, backlog })*/
    Ref(_sock_22488);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22488;
    ((int *)_2)[2] = _backlog_22489;
    _12568 = MAKE_SEQ(_1);
    _12569 = machine(88, _12568);
    DeRefDS(_12568);
    _12568 = NOVALUE;
    DeRef(_sock_22488);
    return _12569;
    ;
}


int  __stdcall _48accept(int _sock_22494)
{
    int _12571 = NOVALUE;
    int _12570 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_ACCEPT, { sock })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22494);
    *((int *)(_2+4)) = _sock_22494;
    _12570 = MAKE_SEQ(_1);
    _12571 = machine(89, _12570);
    DeRefDS(_12570);
    _12570 = NOVALUE;
    DeRef(_sock_22494);
    return _12571;
    ;
}


int  __stdcall _48send_to(int _sock_22499, int _data_22500, int _address_22501, int _port_22502, int _flags_22503)
{
    int _sock_data_22504 = NOVALUE;
    int _12576 = NOVALUE;
    int _12575 = NOVALUE;
    int _12574 = NOVALUE;
    int _12573 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22502)) {
        _1 = (long)(DBL_PTR(_port_22502)->dbl);
        DeRefDS(_port_22502);
        _port_22502 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22501);
    _0 = _sock_data_22504;
    _sock_data_22504 = _49parse_ip_address(_address_22501, _port_22502);
    DeRef(_0);

    /**     return machine_func(M_SOCK_SENDTO, { sock, data, flags, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22504);
    _12573 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22504);
    _12574 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22499);
    *((int *)(_2+4)) = _sock_22499;
    RefDS(_data_22500);
    *((int *)(_2+8)) = _data_22500;
    Ref(_flags_22503);
    *((int *)(_2+12)) = _flags_22503;
    Ref(_12573);
    *((int *)(_2+16)) = _12573;
    Ref(_12574);
    *((int *)(_2+20)) = _12574;
    _12575 = MAKE_SEQ(_1);
    _12574 = NOVALUE;
    _12573 = NOVALUE;
    _12576 = machine(93, _12575);
    DeRefDS(_12575);
    _12575 = NOVALUE;
    DeRef(_sock_22499);
    DeRefDS(_data_22500);
    DeRefDS(_address_22501);
    DeRef(_flags_22503);
    DeRef(_sock_data_22504);
    return _12576;
    ;
}


int  __stdcall _48receive_from(int _sock_22512, int _flags_22513)
{
    int _12578 = NOVALUE;
    int _12577 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_SOCK_RECVFROM, { sock, flags })*/
    Ref(_flags_22513);
    Ref(_sock_22512);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22512;
    ((int *)_2)[2] = _flags_22513;
    _12577 = MAKE_SEQ(_1);
    _12578 = machine(94, _12577);
    DeRefDS(_12577);
    _12577 = NOVALUE;
    DeRef(_sock_22512);
    DeRef(_flags_22513);
    return _12578;
    ;
}


int  __stdcall _48service_by_name(int _name_22518, int _protocol_22519)
{
    int _12580 = NOVALUE;
    int _12579 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETSERVBYNAME, { name, protocol })*/
    Ref(_protocol_22519);
    RefDS(_name_22518);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_22518;
    ((int *)_2)[2] = _protocol_22519;
    _12579 = MAKE_SEQ(_1);
    _12580 = machine(77, _12579);
    DeRefDS(_12579);
    _12579 = NOVALUE;
    DeRefDS(_name_22518);
    DeRef(_protocol_22519);
    return _12580;
    ;
}


int  __stdcall _48service_by_port(int _port_22524, int _protocol_22525)
{
    int _12582 = NOVALUE;
    int _12581 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22524)) {
        _1 = (long)(DBL_PTR(_port_22524)->dbl);
        DeRefDS(_port_22524);
        _port_22524 = _1;
    }

    /** 	return machine_func(M_SOCK_GETSERVBYPORT, { port, protocol })*/
    Ref(_protocol_22525);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _port_22524;
    ((int *)_2)[2] = _protocol_22525;
    _12581 = MAKE_SEQ(_1);
    _12582 = machine(78, _12581);
    DeRefDS(_12581);
    _12581 = NOVALUE;
    DeRef(_protocol_22525);
    return _12582;
    ;
}


int  __stdcall _48info(int _Type_22530)
{
    int _12583 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_Type_22530)) {
        _1 = (long)(DBL_PTR(_Type_22530)->dbl);
        DeRefDS(_Type_22530);
        _Type_22530 = _1;
    }

    /** 	return machine_func(M_SOCK_INFO, Type)*/
    _12583 = machine(4, _Type_22530);
    return _12583;
    ;
}



// 0xA624C43A
