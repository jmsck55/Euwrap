// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _27init_float80()
{
    int _data_inlined_allocate_code_at_55_25236 = NOVALUE;
    int _code_8944 = NOVALUE;
    int _4889 = NOVALUE;
    int _4888 = NOVALUE;
    int _4886 = NOVALUE;
    int _0, _1, _2;
    

    /** 	f80 = allocate( 10 )*/
    _0 = _14allocate(10, 0);
    DeRef(_27f80_8933);
    _27f80_8933 = _0;

    /** 	if f64 = 0 then*/
    if (binary_op_a(NOTEQ, _27f64_8934, 0)){
        goto L1; // [12] 24
    }

    /** 		f64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27f64_8934);
    _27f64_8934 = _0;
L1: 

    /** 	atom code*/

    /** 	code = machine:allocate_code(*/
    _1 = NewS1(25);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 85;
    *((int *)(_2+8)) = 137;
    *((int *)(_2+12)) = 229;
    *((int *)(_2+16)) = 131;
    *((int *)(_2+20)) = 236;
    *((int *)(_2+24)) = 8;
    *((int *)(_2+28)) = 139;
    *((int *)(_2+32)) = 69;
    *((int *)(_2+36)) = 12;
    *((int *)(_2+40)) = 139;
    *((int *)(_2+44)) = 85;
    *((int *)(_2+48)) = 8;
    *((int *)(_2+52)) = 219;
    *((int *)(_2+56)) = 42;
    *((int *)(_2+60)) = 221;
    *((int *)(_2+64)) = 93;
    *((int *)(_2+68)) = 248;
    *((int *)(_2+72)) = 221;
    *((int *)(_2+76)) = 69;
    *((int *)(_2+80)) = 248;
    *((int *)(_2+84)) = 221;
    *((int *)(_2+88)) = 24;
    *((int *)(_2+92)) = 201;
    *((int *)(_2+96)) = 195;
    *((int *)(_2+100)) = 0;
    _4886 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_allocate_code_at_55_25236);
    _data_inlined_allocate_code_at_55_25236 = _4886;
    _4886 = NOVALUE;

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    RefDS(_data_inlined_allocate_code_at_55_25236);
    _0 = _code_8944;
    _code_8944 = _14allocate_protect(_data_inlined_allocate_code_at_55_25236, 1, 16);
    DeRef(_0);
    DeRefi(_data_inlined_allocate_code_at_55_25236);
    _data_inlined_allocate_code_at_55_25236 = NOVALUE;

    /** 	F80_TO_ATOM = dll:define_c_proc( "", {'+', code}, { dll:C_POINTER, dll:C_POINTER } )*/
    Ref(_code_8944);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 43;
    ((int *)_2)[2] = _code_8944;
    _4888 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _4889 = MAKE_SEQ(_1);
    RefDS(_5);
    _0 = _13define_c_proc(_5, _4888, _4889);
    _27F80_TO_ATOM_8935 = _0;
    _4888 = NOVALUE;
    _4889 = NOVALUE;
    if (!IS_ATOM_INT(_27F80_TO_ATOM_8935)) {
        _1 = (long)(DBL_PTR(_27F80_TO_ATOM_8935)->dbl);
        DeRefDS(_27F80_TO_ATOM_8935);
        _27F80_TO_ATOM_8935 = _1;
    }

    /** end procedure*/
    DeRef(_code_8944);
    return;
    ;
}


int _27float80_to_atom(int _f_8965)
{
    int _4895 = NOVALUE;
    int _4894 = NOVALUE;
    int _4893 = NOVALUE;
    int _4892 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not f80 then*/
    if (IS_ATOM_INT(_27f80_8933)) {
        if (_27f80_8933 != 0){
            goto L1; // [7] 15
        }
    }
    else {
        if (DBL_PTR(_27f80_8933)->dbl != 0.0){
            goto L1; // [7] 15
        }
    }

    /** 		init_float80()*/
    _27init_float80();
L1: 

    /** 	poke( f80, f )*/
    if (IS_ATOM_INT(_27f80_8933)){
        poke_addr = (unsigned char *)_27f80_8933;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27f80_8933)->dbl);
    }
    _1 = (int)SEQ_PTR(_f_8965);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	c_proc( F80_TO_ATOM, { f80, f64 } )*/
    Ref(_27f64_8934);
    Ref(_27f80_8933);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27f80_8933;
    ((int *)_2)[2] = _27f64_8934;
    _4892 = MAKE_SEQ(_1);
    call_c(0, _27F80_TO_ATOM_8935, _4892);
    DeRefDS(_4892);
    _4892 = NOVALUE;

    /** 	return float64_to_atom( peek( { f64, 8 } ) )*/
    Ref(_27f64_8934);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27f64_8934;
    ((int *)_2)[2] = 8;
    _4893 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_4893);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _4894 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4893);
    _4893 = NOVALUE;
    _4895 = _8float64_to_atom(_4894);
    _4894 = NOVALUE;
    DeRefDS(_f_8965);
    return _4895;
    ;
}


void _27init_peek8s()
{
    int _data_inlined_allocate_code_at_58_25238 = NOVALUE;
    int _code_8983 = NOVALUE;
    int _4903 = NOVALUE;
    int _4902 = NOVALUE;
    int _4900 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27i64_8973);
    _27i64_8973 = _0;

    /** 	if f64 = 0 then*/
    if (binary_op_a(NOTEQ, _27f64_8934, 0)){
        goto L1; // [12] 24
    }

    /** 		f64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27f64_8934);
    _27f64_8934 = _0;
L1: 

    /** 	atom code = machine:allocate_code(	{*/
    _1 = NewS1(30);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 85;
    *((int *)(_2+8)) = 137;
    *((int *)(_2+12)) = 229;
    *((int *)(_2+16)) = 131;
    *((int *)(_2+20)) = 236;
    *((int *)(_2+24)) = 8;
    *((int *)(_2+28)) = 139;
    *((int *)(_2+32)) = 69;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 139;
    *((int *)(_2+44)) = 80;
    *((int *)(_2+48)) = 4;
    *((int *)(_2+52)) = 139;
    *((int *)(_2+56)) = 0;
    *((int *)(_2+60)) = 137;
    *((int *)(_2+64)) = 69;
    *((int *)(_2+68)) = 248;
    *((int *)(_2+72)) = 137;
    *((int *)(_2+76)) = 85;
    *((int *)(_2+80)) = 252;
    *((int *)(_2+84)) = 223;
    *((int *)(_2+88)) = 109;
    *((int *)(_2+92)) = 248;
    *((int *)(_2+96)) = 139;
    *((int *)(_2+100)) = 69;
    *((int *)(_2+104)) = 12;
    *((int *)(_2+108)) = 221;
    *((int *)(_2+112)) = 24;
    *((int *)(_2+116)) = 201;
    *((int *)(_2+120)) = 195;
    _4900 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_allocate_code_at_58_25238);
    _data_inlined_allocate_code_at_58_25238 = _4900;
    _4900 = NOVALUE;

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    RefDS(_data_inlined_allocate_code_at_58_25238);
    _0 = _code_8983;
    _code_8983 = _14allocate_protect(_data_inlined_allocate_code_at_58_25238, 1, 16);
    DeRef(_0);
    DeRefi(_data_inlined_allocate_code_at_58_25238);
    _data_inlined_allocate_code_at_58_25238 = NOVALUE;

    /** 	PEEK8S = define_c_proc( {}, {'+', code}, { C_POINTER, C_POINTER } )*/
    Ref(_code_8983);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 43;
    ((int *)_2)[2] = _code_8983;
    _4902 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _4903 = MAKE_SEQ(_1);
    RefDS(_5);
    _0 = _13define_c_proc(_5, _4902, _4903);
    _27PEEK8S_8974 = _0;
    _4902 = NOVALUE;
    _4903 = NOVALUE;
    if (!IS_ATOM_INT(_27PEEK8S_8974)) {
        _1 = (long)(DBL_PTR(_27PEEK8S_8974)->dbl);
        DeRefDS(_27PEEK8S_8974);
        _27PEEK8S_8974 = _1;
    }

    /** end procedure*/
    DeRef(_code_8983);
    return;
    ;
}


int _27int64_to_atom(int _s_8995)
{
    int _4909 = NOVALUE;
    int _4908 = NOVALUE;
    int _4907 = NOVALUE;
    int _4906 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if i64 = 0 then*/
    if (binary_op_a(NOTEQ, _27i64_8973, 0)){
        goto L1; // [7] 16
    }

    /** 		init_peek8s()*/
    _27init_peek8s();
L1: 

    /** 	poke( i64, s )*/
    if (IS_ATOM_INT(_27i64_8973)){
        poke_addr = (unsigned char *)_27i64_8973;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27i64_8973)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_8995);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	c_proc( PEEK8S, { i64, f64 } )*/
    Ref(_27f64_8934);
    Ref(_27i64_8973);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27i64_8973;
    ((int *)_2)[2] = _27f64_8934;
    _4906 = MAKE_SEQ(_1);
    call_c(0, _27PEEK8S_8974, _4906);
    DeRefDS(_4906);
    _4906 = NOVALUE;

    /** 	return float64_to_atom( peek( f64 & 8 ) )*/
    Concat((object_ptr)&_4907, _27f64_8934, 8);
    _1 = (int)SEQ_PTR(_4907);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _4908 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4907);
    _4907 = NOVALUE;
    _4909 = _8float64_to_atom(_4908);
    _4908 = NOVALUE;
    DeRefDS(_s_8995);
    return _4909;
    ;
}


int _27get4(int _fh_9005)
{
    int _4914 = NOVALUE;
    int _4913 = NOVALUE;
    int _4912 = NOVALUE;
    int _4911 = NOVALUE;
    int _4910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_9005 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9005, EF_READ);
        last_r_file_no = _fh_9005;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _4910 = getKBchar();
        }
        else
        _4910 = getc(last_r_file_ptr);
    }
    else
    _4910 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem0_8925)){
        poke_addr = (unsigned char *)_27mem0_8925;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem0_8925)->dbl);
    }
    *poke_addr = (unsigned char)_4910;
    _4910 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_9005 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9005, EF_READ);
        last_r_file_no = _fh_9005;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _4911 = getKBchar();
        }
        else
        _4911 = getc(last_r_file_ptr);
    }
    else
    _4911 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem1_8926)){
        poke_addr = (unsigned char *)_27mem1_8926;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem1_8926)->dbl);
    }
    *poke_addr = (unsigned char)_4911;
    _4911 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_9005 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9005, EF_READ);
        last_r_file_no = _fh_9005;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _4912 = getKBchar();
        }
        else
        _4912 = getc(last_r_file_ptr);
    }
    else
    _4912 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem2_8927)){
        poke_addr = (unsigned char *)_27mem2_8927;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem2_8927)->dbl);
    }
    *poke_addr = (unsigned char)_4912;
    _4912 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_9005 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9005, EF_READ);
        last_r_file_no = _fh_9005;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _4913 = getKBchar();
        }
        else
        _4913 = getc(last_r_file_ptr);
    }
    else
    _4913 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem3_8928)){
        poke_addr = (unsigned char *)_27mem3_8928;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem3_8928)->dbl);
    }
    *poke_addr = (unsigned char)_4913;
    _4913 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_27mem0_8925)) {
        _4914 = *(unsigned long *)_27mem0_8925;
        if ((unsigned)_4914 > (unsigned)MAXINT)
        _4914 = NewDouble((double)(unsigned long)_4914);
    }
    else {
        _4914 = *(unsigned long *)(unsigned long)(DBL_PTR(_27mem0_8925)->dbl);
        if ((unsigned)_4914 > (unsigned)MAXINT)
        _4914 = NewDouble((double)(unsigned long)_4914);
    }
    return _4914;
    ;
}


int _27deserialize_file(int _fh_9013, int _c_9014)
{
    int _s_9015 = NOVALUE;
    int _len_9016 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_159_9052 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_156_9051 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_218_9065 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_215_9064 = NOVALUE;
    int _msg_inlined_crash_at_424_9110 = NOVALUE;
    int _4993 = NOVALUE;
    int _4992 = NOVALUE;
    int _4991 = NOVALUE;
    int _4990 = NOVALUE;
    int _4987 = NOVALUE;
    int _4984 = NOVALUE;
    int _4983 = NOVALUE;
    int _4982 = NOVALUE;
    int _4981 = NOVALUE;
    int _4980 = NOVALUE;
    int _4979 = NOVALUE;
    int _4978 = NOVALUE;
    int _4977 = NOVALUE;
    int _4976 = NOVALUE;
    int _4975 = NOVALUE;
    int _4974 = NOVALUE;
    int _4973 = NOVALUE;
    int _4971 = NOVALUE;
    int _4970 = NOVALUE;
    int _4969 = NOVALUE;
    int _4968 = NOVALUE;
    int _4967 = NOVALUE;
    int _4966 = NOVALUE;
    int _4965 = NOVALUE;
    int _4964 = NOVALUE;
    int _4963 = NOVALUE;
    int _4962 = NOVALUE;
    int _4960 = NOVALUE;
    int _4959 = NOVALUE;
    int _4958 = NOVALUE;
    int _4957 = NOVALUE;
    int _4956 = NOVALUE;
    int _4954 = NOVALUE;
    int _4950 = NOVALUE;
    int _4949 = NOVALUE;
    int _4948 = NOVALUE;
    int _4947 = NOVALUE;
    int _4946 = NOVALUE;
    int _4945 = NOVALUE;
    int _4944 = NOVALUE;
    int _4943 = NOVALUE;
    int _4942 = NOVALUE;
    int _4941 = NOVALUE;
    int _4940 = NOVALUE;
    int _4939 = NOVALUE;
    int _4938 = NOVALUE;
    int _4937 = NOVALUE;
    int _4936 = NOVALUE;
    int _4935 = NOVALUE;
    int _4934 = NOVALUE;
    int _4933 = NOVALUE;
    int _4932 = NOVALUE;
    int _4931 = NOVALUE;
    int _4929 = NOVALUE;
    int _4928 = NOVALUE;
    int _4927 = NOVALUE;
    int _4926 = NOVALUE;
    int _4925 = NOVALUE;
    int _4924 = NOVALUE;
    int _4923 = NOVALUE;
    int _4922 = NOVALUE;
    int _4921 = NOVALUE;
    int _4918 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_9013)) {
        _1 = (long)(DBL_PTR(_fh_9013)->dbl);
        DeRefDS(_fh_9013);
        _fh_9013 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_9014 != 0)
    goto L1; // [7] 34

    /** 		c = getc(fh)*/
    if (_fh_9013 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9013, EF_READ);
        last_r_file_no = _fh_9013;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9014 = getKBchar();
        }
        else
        _c_9014 = getc(last_r_file_ptr);
    }
    else
    _c_9014 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_9014 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _4918 = _c_9014 + -9;
    DeRef(_s_9015);
    DeRef(_len_9016);
    return _4918;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_9014;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(fh) +*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4921 = getKBchar();
            }
            else
            _4921 = getc(last_r_file_ptr);
        }
        else
        _4921 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4922 = getKBchar();
            }
            else
            _4922 = getc(last_r_file_ptr);
        }
        else
        _4922 = getc(last_r_file_ptr);
        _4923 = 256 * _4922;
        _4922 = NOVALUE;
        _4924 = _4921 + _4923;
        _4921 = NOVALUE;
        _4923 = NOVALUE;
        _4925 = _4924 + _27MIN2B_8910;
        if ((long)((unsigned long)_4925 + (unsigned long)HIGH_BITS) >= 0) 
        _4925 = NewDouble((double)_4925);
        _4924 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        return _4925;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(fh) +*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4926 = getKBchar();
            }
            else
            _4926 = getc(last_r_file_ptr);
        }
        else
        _4926 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4927 = getKBchar();
            }
            else
            _4927 = getc(last_r_file_ptr);
        }
        else
        _4927 = getc(last_r_file_ptr);
        _4928 = 256 * _4927;
        _4927 = NOVALUE;
        _4929 = _4926 + _4928;
        _4926 = NOVALUE;
        _4928 = NOVALUE;
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4931 = getKBchar();
            }
            else
            _4931 = getc(last_r_file_ptr);
        }
        else
        _4931 = getc(last_r_file_ptr);
        _4932 = 65536 * _4931;
        _4931 = NOVALUE;
        _4933 = _4929 + _4932;
        _4929 = NOVALUE;
        _4932 = NOVALUE;
        _4934 = _4933 + _27MIN3B_8916;
        if ((long)((unsigned long)_4934 + (unsigned long)HIGH_BITS) >= 0) 
        _4934 = NewDouble((double)_4934);
        _4933 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        return _4934;

        /** 		case I4B then*/
        case 251:

        /** 			return get4(fh) + MIN4B*/
        _4935 = _27get4(_fh_9013);
        if (IS_ATOM_INT(_4935) && IS_ATOM_INT(_27MIN4B_8922)) {
            _4936 = _4935 + _27MIN4B_8922;
            if ((long)((unsigned long)_4936 + (unsigned long)HIGH_BITS) >= 0) 
            _4936 = NewDouble((double)_4936);
        }
        else {
            _4936 = binary_op(PLUS, _4935, _27MIN4B_8922);
        }
        DeRef(_4935);
        _4935 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        return _4936;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(fh), getc(fh),*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4937 = getKBchar();
            }
            else
            _4937 = getc(last_r_file_ptr);
        }
        else
        _4937 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4938 = getKBchar();
            }
            else
            _4938 = getc(last_r_file_ptr);
        }
        else
        _4938 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4939 = getKBchar();
            }
            else
            _4939 = getc(last_r_file_ptr);
        }
        else
        _4939 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4940 = getKBchar();
            }
            else
            _4940 = getc(last_r_file_ptr);
        }
        else
        _4940 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4937;
        *((int *)(_2+8)) = _4938;
        *((int *)(_2+12)) = _4939;
        *((int *)(_2+16)) = _4940;
        _4941 = MAKE_SEQ(_1);
        _4940 = NOVALUE;
        _4939 = NOVALUE;
        _4938 = NOVALUE;
        _4937 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_156_9051);
        _ieee32_inlined_float32_to_atom_at_156_9051 = _4941;
        _4941 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_159_9052);
        _float32_to_atom_inlined_float32_to_atom_at_159_9052 = machine(49, _ieee32_inlined_float32_to_atom_at_156_9051);
        DeRefi(_ieee32_inlined_float32_to_atom_at_156_9051);
        _ieee32_inlined_float32_to_atom_at_156_9051 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_159_9052;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(fh), getc(fh),*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4942 = getKBchar();
            }
            else
            _4942 = getc(last_r_file_ptr);
        }
        else
        _4942 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4943 = getKBchar();
            }
            else
            _4943 = getc(last_r_file_ptr);
        }
        else
        _4943 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4944 = getKBchar();
            }
            else
            _4944 = getc(last_r_file_ptr);
        }
        else
        _4944 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4945 = getKBchar();
            }
            else
            _4945 = getc(last_r_file_ptr);
        }
        else
        _4945 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4946 = getKBchar();
            }
            else
            _4946 = getc(last_r_file_ptr);
        }
        else
        _4946 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4947 = getKBchar();
            }
            else
            _4947 = getc(last_r_file_ptr);
        }
        else
        _4947 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4948 = getKBchar();
            }
            else
            _4948 = getc(last_r_file_ptr);
        }
        else
        _4948 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4949 = getKBchar();
            }
            else
            _4949 = getc(last_r_file_ptr);
        }
        else
        _4949 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4942;
        *((int *)(_2+8)) = _4943;
        *((int *)(_2+12)) = _4944;
        *((int *)(_2+16)) = _4945;
        *((int *)(_2+20)) = _4946;
        *((int *)(_2+24)) = _4947;
        *((int *)(_2+28)) = _4948;
        *((int *)(_2+32)) = _4949;
        _4950 = MAKE_SEQ(_1);
        _4949 = NOVALUE;
        _4948 = NOVALUE;
        _4947 = NOVALUE;
        _4946 = NOVALUE;
        _4945 = NOVALUE;
        _4944 = NOVALUE;
        _4943 = NOVALUE;
        _4942 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_215_9064);
        _ieee64_inlined_float64_to_atom_at_215_9064 = _4950;
        _4950 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_218_9065);
        _float64_to_atom_inlined_float64_to_atom_at_218_9065 = machine(47, _ieee64_inlined_float64_to_atom_at_215_9064);
        DeRefi(_ieee64_inlined_float64_to_atom_at_215_9064);
        _ieee64_inlined_float64_to_atom_at_215_9064 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_218_9065;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_9014 != 254)
        goto L3; // [240] 252

        /** 				len = getc(fh)*/
        DeRef(_len_9016);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_9016 = getKBchar();
            }
            else
            _len_9016 = getc(last_r_file_ptr);
        }
        else
        _len_9016 = getc(last_r_file_ptr);
        goto L4; // [249] 259
L3: 

        /** 				len = get4(fh)*/
        _0 = _len_9016;
        _len_9016 = _27get4(_fh_9013);
        DeRef(_0);
L4: 

        /** 			if len < 0  or not integer(len) then*/
        if (IS_ATOM_INT(_len_9016)) {
            _4954 = (_len_9016 < 0);
        }
        else {
            _4954 = (DBL_PTR(_len_9016)->dbl < (double)0);
        }
        if (_4954 != 0) {
            goto L5; // [267] 282
        }
        if (IS_ATOM_INT(_len_9016))
        _4956 = 1;
        else if (IS_ATOM_DBL(_len_9016))
        _4956 = IS_ATOM_INT(DoubleToInt(_len_9016));
        else
        _4956 = 0;
        _4957 = (_4956 == 0);
        _4956 = NOVALUE;
        if (_4957 == 0)
        {
            DeRef(_4957);
            _4957 = NOVALUE;
            goto L6; // [278] 289
        }
        else{
            DeRef(_4957);
            _4957 = NOVALUE;
        }
L5: 

        /** 				return 0*/
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4954);
        _4954 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        return 0;
L6: 

        /** 			if c = S4B and len < 256 then*/
        _4958 = (_c_9014 == 255);
        if (_4958 == 0) {
            goto L7; // [295] 447
        }
        if (IS_ATOM_INT(_len_9016)) {
            _4960 = (_len_9016 < 256);
        }
        else {
            _4960 = (DBL_PTR(_len_9016)->dbl < (double)256);
        }
        if (_4960 == 0)
        {
            DeRef(_4960);
            _4960 = NOVALUE;
            goto L7; // [304] 447
        }
        else{
            DeRef(_4960);
            _4960 = NOVALUE;
        }

        /** 				if len = I8B then*/
        if (binary_op_a(NOTEQ, _len_9016, 0)){
            goto L8; // [309] 361
        }

        /** 					return int64_to_atom( {*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4962 = getKBchar();
            }
            else
            _4962 = getc(last_r_file_ptr);
        }
        else
        _4962 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4963 = getKBchar();
            }
            else
            _4963 = getc(last_r_file_ptr);
        }
        else
        _4963 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4964 = getKBchar();
            }
            else
            _4964 = getc(last_r_file_ptr);
        }
        else
        _4964 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4965 = getKBchar();
            }
            else
            _4965 = getc(last_r_file_ptr);
        }
        else
        _4965 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4966 = getKBchar();
            }
            else
            _4966 = getc(last_r_file_ptr);
        }
        else
        _4966 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4967 = getKBchar();
            }
            else
            _4967 = getc(last_r_file_ptr);
        }
        else
        _4967 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4968 = getKBchar();
            }
            else
            _4968 = getc(last_r_file_ptr);
        }
        else
        _4968 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4969 = getKBchar();
            }
            else
            _4969 = getc(last_r_file_ptr);
        }
        else
        _4969 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4962;
        *((int *)(_2+8)) = _4963;
        *((int *)(_2+12)) = _4964;
        *((int *)(_2+16)) = _4965;
        *((int *)(_2+20)) = _4966;
        *((int *)(_2+24)) = _4967;
        *((int *)(_2+28)) = _4968;
        *((int *)(_2+32)) = _4969;
        _4970 = MAKE_SEQ(_1);
        _4969 = NOVALUE;
        _4968 = NOVALUE;
        _4967 = NOVALUE;
        _4966 = NOVALUE;
        _4965 = NOVALUE;
        _4964 = NOVALUE;
        _4963 = NOVALUE;
        _4962 = NOVALUE;
        _4971 = _27int64_to_atom(_4970);
        _4970 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4954);
        _4954 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        DeRef(_4958);
        _4958 = NOVALUE;
        return _4971;
        goto L9; // [358] 521
L8: 

        /** 				elsif len = F10B then*/
        if (binary_op_a(NOTEQ, _len_9016, 1)){
            goto LA; // [363] 423
        }

        /** 					return float80_to_atom(*/
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4973 = getKBchar();
            }
            else
            _4973 = getc(last_r_file_ptr);
        }
        else
        _4973 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4974 = getKBchar();
            }
            else
            _4974 = getc(last_r_file_ptr);
        }
        else
        _4974 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4975 = getKBchar();
            }
            else
            _4975 = getc(last_r_file_ptr);
        }
        else
        _4975 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4976 = getKBchar();
            }
            else
            _4976 = getc(last_r_file_ptr);
        }
        else
        _4976 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4977 = getKBchar();
            }
            else
            _4977 = getc(last_r_file_ptr);
        }
        else
        _4977 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4978 = getKBchar();
            }
            else
            _4978 = getc(last_r_file_ptr);
        }
        else
        _4978 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4979 = getKBchar();
            }
            else
            _4979 = getc(last_r_file_ptr);
        }
        else
        _4979 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4980 = getKBchar();
            }
            else
            _4980 = getc(last_r_file_ptr);
        }
        else
        _4980 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4981 = getKBchar();
            }
            else
            _4981 = getc(last_r_file_ptr);
        }
        else
        _4981 = getc(last_r_file_ptr);
        if (_fh_9013 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_9013, EF_READ);
            last_r_file_no = _fh_9013;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _4982 = getKBchar();
            }
            else
            _4982 = getc(last_r_file_ptr);
        }
        else
        _4982 = getc(last_r_file_ptr);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4973;
        *((int *)(_2+8)) = _4974;
        *((int *)(_2+12)) = _4975;
        *((int *)(_2+16)) = _4976;
        *((int *)(_2+20)) = _4977;
        *((int *)(_2+24)) = _4978;
        *((int *)(_2+28)) = _4979;
        *((int *)(_2+32)) = _4980;
        *((int *)(_2+36)) = _4981;
        *((int *)(_2+40)) = _4982;
        _4983 = MAKE_SEQ(_1);
        _4982 = NOVALUE;
        _4981 = NOVALUE;
        _4980 = NOVALUE;
        _4979 = NOVALUE;
        _4978 = NOVALUE;
        _4977 = NOVALUE;
        _4976 = NOVALUE;
        _4975 = NOVALUE;
        _4974 = NOVALUE;
        _4973 = NOVALUE;
        _4984 = _27float80_to_atom(_4983);
        _4983 = NOVALUE;
        DeRef(_s_9015);
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4954);
        _4954 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        DeRef(_4958);
        _4958 = NOVALUE;
        DeRef(_4971);
        _4971 = NOVALUE;
        return _4984;
        goto L9; // [420] 521
LA: 

        /** 					error:crash( "Invalid sequence serialization" )*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_424_9110);
        _msg_inlined_crash_at_424_9110 = EPrintf(-9999999, _4985, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_424_9110);

        /** end procedure*/
        goto LB; // [438] 441
LB: 
        DeRefi(_msg_inlined_crash_at_424_9110);
        _msg_inlined_crash_at_424_9110 = NOVALUE;
        goto L9; // [444] 521
L7: 

        /** 				s = repeat(0, len)*/
        DeRef(_s_9015);
        _s_9015 = Repeat(0, _len_9016);

        /** 				for i = 1 to len do*/
        Ref(_len_9016);
        DeRef(_4987);
        _4987 = _len_9016;
        {
            int _i_9114;
            _i_9114 = 1;
LC: 
            if (binary_op_a(GREATER, _i_9114, _4987)){
                goto LD; // [458] 514
            }

            /** 					c = getc(fh)*/
            if (_fh_9013 != last_r_file_no) {
                last_r_file_ptr = which_file(_fh_9013, EF_READ);
                last_r_file_no = _fh_9013;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_9014 = getKBchar();
                }
                else
                _c_9014 = getc(last_r_file_ptr);
            }
            else
            _c_9014 = getc(last_r_file_ptr);

            /** 					if c < I2B then*/
            if (_c_9014 >= 249)
            goto LE; // [472] 489

            /** 						s[i] = c + MIN1B*/
            _4990 = _c_9014 + -9;
            _2 = (int)SEQ_PTR(_s_9015);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9015 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_i_9114))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_9114)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_9114);
            _1 = *(int *)_2;
            *(int *)_2 = _4990;
            if( _1 != _4990 ){
                DeRef(_1);
            }
            _4990 = NOVALUE;
            goto LF; // [486] 507
LE: 

            /** 						s[i] = deserialize_file(fh, c)*/
            DeRef(_4991);
            _4991 = _fh_9013;
            DeRef(_4992);
            _4992 = _c_9014;
            _4993 = _27deserialize_file(_4991, _4992);
            _4991 = NOVALUE;
            _4992 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_9015);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9015 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_i_9114))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_9114)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_9114);
            _1 = *(int *)_2;
            *(int *)_2 = _4993;
            if( _1 != _4993 ){
                DeRef(_1);
            }
            _4993 = NOVALUE;
LF: 

            /** 				end for*/
            _0 = _i_9114;
            if (IS_ATOM_INT(_i_9114)) {
                _i_9114 = _i_9114 + 1;
                if ((long)((unsigned long)_i_9114 +(unsigned long) HIGH_BITS) >= 0){
                    _i_9114 = NewDouble((double)_i_9114);
                }
            }
            else {
                _i_9114 = binary_op_a(PLUS, _i_9114, 1);
            }
            DeRef(_0);
            goto LC; // [509] 465
LD: 
            ;
            DeRef(_i_9114);
        }

        /** 				return s*/
        DeRef(_len_9016);
        DeRef(_4918);
        _4918 = NOVALUE;
        DeRef(_4925);
        _4925 = NOVALUE;
        DeRef(_4934);
        _4934 = NOVALUE;
        DeRef(_4954);
        _4954 = NOVALUE;
        DeRef(_4936);
        _4936 = NOVALUE;
        DeRef(_4958);
        _4958 = NOVALUE;
        DeRef(_4971);
        _4971 = NOVALUE;
        DeRef(_4984);
        _4984 = NOVALUE;
        return _s_9015;
L9: 
    ;}    ;
}


int _27getp4(int _sdata_9126, int _pos_9127)
{
    int _5002 = NOVALUE;
    int _5001 = NOVALUE;
    int _5000 = NOVALUE;
    int _4999 = NOVALUE;
    int _4998 = NOVALUE;
    int _4997 = NOVALUE;
    int _4996 = NOVALUE;
    int _4995 = NOVALUE;
    int _4994 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, sdata[pos+0])*/
    _4994 = _pos_9127 + 0;
    _2 = (int)SEQ_PTR(_sdata_9126);
    _4995 = (int)*(((s1_ptr)_2)->base + _4994);
    if (IS_ATOM_INT(_27mem0_8925)){
        poke_addr = (unsigned char *)_27mem0_8925;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem0_8925)->dbl);
    }
    if (IS_ATOM_INT(_4995)) {
        *poke_addr = (unsigned char)_4995;
    }
    else if (IS_ATOM(_4995)) {
        *poke_addr = (signed char)DBL_PTR(_4995)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4995);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4995 = NOVALUE;

    /** 	poke(mem1, sdata[pos+1])*/
    _4996 = _pos_9127 + 1;
    _2 = (int)SEQ_PTR(_sdata_9126);
    _4997 = (int)*(((s1_ptr)_2)->base + _4996);
    if (IS_ATOM_INT(_27mem1_8926)){
        poke_addr = (unsigned char *)_27mem1_8926;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem1_8926)->dbl);
    }
    if (IS_ATOM_INT(_4997)) {
        *poke_addr = (unsigned char)_4997;
    }
    else if (IS_ATOM(_4997)) {
        *poke_addr = (signed char)DBL_PTR(_4997)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4997);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4997 = NOVALUE;

    /** 	poke(mem2, sdata[pos+2])*/
    _4998 = _pos_9127 + 2;
    _2 = (int)SEQ_PTR(_sdata_9126);
    _4999 = (int)*(((s1_ptr)_2)->base + _4998);
    if (IS_ATOM_INT(_27mem2_8927)){
        poke_addr = (unsigned char *)_27mem2_8927;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem2_8927)->dbl);
    }
    if (IS_ATOM_INT(_4999)) {
        *poke_addr = (unsigned char)_4999;
    }
    else if (IS_ATOM(_4999)) {
        *poke_addr = (signed char)DBL_PTR(_4999)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4999);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4999 = NOVALUE;

    /** 	poke(mem3, sdata[pos+3])*/
    _5000 = _pos_9127 + 3;
    _2 = (int)SEQ_PTR(_sdata_9126);
    _5001 = (int)*(((s1_ptr)_2)->base + _5000);
    if (IS_ATOM_INT(_27mem3_8928)){
        poke_addr = (unsigned char *)_27mem3_8928;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem3_8928)->dbl);
    }
    if (IS_ATOM_INT(_5001)) {
        *poke_addr = (unsigned char)_5001;
    }
    else if (IS_ATOM(_5001)) {
        *poke_addr = (signed char)DBL_PTR(_5001)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_5001);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _5001 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_27mem0_8925)) {
        _5002 = *(unsigned long *)_27mem0_8925;
        if ((unsigned)_5002 > (unsigned)MAXINT)
        _5002 = NewDouble((double)(unsigned long)_5002);
    }
    else {
        _5002 = *(unsigned long *)(unsigned long)(DBL_PTR(_27mem0_8925)->dbl);
        if ((unsigned)_5002 > (unsigned)MAXINT)
        _5002 = NewDouble((double)(unsigned long)_5002);
    }
    DeRefDS(_sdata_9126);
    _4994 = NOVALUE;
    _4996 = NOVALUE;
    _4998 = NOVALUE;
    _5000 = NOVALUE;
    return _5002;
    ;
}


int _27deserialize_object(int _sdata_9139, int _pos_9140, int _c_9141)
{
    int _s_9142 = NOVALUE;
    int _len_9143 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_230_9192 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_227_9191 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_333_9214 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_330_9213 = NOVALUE;
    int _msg_inlined_crash_at_493_9245 = NOVALUE;
    int _temp_9257 = NOVALUE;
    int _5095 = NOVALUE;
    int _5093 = NOVALUE;
    int _5091 = NOVALUE;
    int _5090 = NOVALUE;
    int _5089 = NOVALUE;
    int _5088 = NOVALUE;
    int _5084 = NOVALUE;
    int _5082 = NOVALUE;
    int _5081 = NOVALUE;
    int _5080 = NOVALUE;
    int _5079 = NOVALUE;
    int _5078 = NOVALUE;
    int _5076 = NOVALUE;
    int _5075 = NOVALUE;
    int _5074 = NOVALUE;
    int _5073 = NOVALUE;
    int _5072 = NOVALUE;
    int _5070 = NOVALUE;
    int _5069 = NOVALUE;
    int _5068 = NOVALUE;
    int _5062 = NOVALUE;
    int _5061 = NOVALUE;
    int _5060 = NOVALUE;
    int _5059 = NOVALUE;
    int _5058 = NOVALUE;
    int _5057 = NOVALUE;
    int _5056 = NOVALUE;
    int _5055 = NOVALUE;
    int _5054 = NOVALUE;
    int _5053 = NOVALUE;
    int _5052 = NOVALUE;
    int _5051 = NOVALUE;
    int _5050 = NOVALUE;
    int _5049 = NOVALUE;
    int _5048 = NOVALUE;
    int _5047 = NOVALUE;
    int _5046 = NOVALUE;
    int _5045 = NOVALUE;
    int _5044 = NOVALUE;
    int _5043 = NOVALUE;
    int _5042 = NOVALUE;
    int _5041 = NOVALUE;
    int _5040 = NOVALUE;
    int _5039 = NOVALUE;
    int _5038 = NOVALUE;
    int _5037 = NOVALUE;
    int _5036 = NOVALUE;
    int _5035 = NOVALUE;
    int _5034 = NOVALUE;
    int _5033 = NOVALUE;
    int _5032 = NOVALUE;
    int _5031 = NOVALUE;
    int _5030 = NOVALUE;
    int _5029 = NOVALUE;
    int _5028 = NOVALUE;
    int _5027 = NOVALUE;
    int _5026 = NOVALUE;
    int _5025 = NOVALUE;
    int _5024 = NOVALUE;
    int _5023 = NOVALUE;
    int _5022 = NOVALUE;
    int _5021 = NOVALUE;
    int _5020 = NOVALUE;
    int _5019 = NOVALUE;
    int _5018 = NOVALUE;
    int _5017 = NOVALUE;
    int _5016 = NOVALUE;
    int _5015 = NOVALUE;
    int _5014 = NOVALUE;
    int _5013 = NOVALUE;
    int _5012 = NOVALUE;
    int _5011 = NOVALUE;
    int _5008 = NOVALUE;
    int _5007 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_9141 != 0)
    goto L1; // [9] 47

    /** 		c = sdata[pos]*/
    _2 = (int)SEQ_PTR(_sdata_9139);
    _c_9141 = (int)*(((s1_ptr)_2)->base + _pos_9140);
    if (!IS_ATOM_INT(_c_9141))
    _c_9141 = (long)DBL_PTR(_c_9141)->dbl;

    /** 		pos += 1*/
    _pos_9140 = _pos_9140 + 1;

    /** 		if c < I2B then*/
    if (_c_9141 >= 249)
    goto L2; // [27] 46

    /** 			return {c + MIN1B, pos}*/
    _5007 = _c_9141 + -9;
    if ((long)((unsigned long)_5007 + (unsigned long)HIGH_BITS) >= 0) 
    _5007 = NewDouble((double)_5007);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5007;
    ((int *)_2)[2] = _pos_9140;
    _5008 = MAKE_SEQ(_1);
    _5007 = NOVALUE;
    DeRefDS(_sdata_9139);
    DeRef(_s_9142);
    return _5008;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_9141;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return {sdata[pos] +*/
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5011 = (int)*(((s1_ptr)_2)->base + _pos_9140);
        _5012 = _pos_9140 + 1;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5013 = (int)*(((s1_ptr)_2)->base + _5012);
        if (IS_ATOM_INT(_5013)) {
            if (_5013 <= INT15 && _5013 >= -INT15)
            _5014 = 256 * _5013;
            else
            _5014 = NewDouble(256 * (double)_5013);
        }
        else {
            _5014 = binary_op(MULTIPLY, 256, _5013);
        }
        _5013 = NOVALUE;
        if (IS_ATOM_INT(_5011) && IS_ATOM_INT(_5014)) {
            _5015 = _5011 + _5014;
            if ((long)((unsigned long)_5015 + (unsigned long)HIGH_BITS) >= 0) 
            _5015 = NewDouble((double)_5015);
        }
        else {
            _5015 = binary_op(PLUS, _5011, _5014);
        }
        _5011 = NOVALUE;
        DeRef(_5014);
        _5014 = NOVALUE;
        if (IS_ATOM_INT(_5015)) {
            _5016 = _5015 + _27MIN2B_8910;
            if ((long)((unsigned long)_5016 + (unsigned long)HIGH_BITS) >= 0) 
            _5016 = NewDouble((double)_5016);
        }
        else {
            _5016 = binary_op(PLUS, _5015, _27MIN2B_8910);
        }
        DeRef(_5015);
        _5015 = NOVALUE;
        _5017 = _pos_9140 + 2;
        if ((long)((unsigned long)_5017 + (unsigned long)HIGH_BITS) >= 0) 
        _5017 = NewDouble((double)_5017);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5016;
        ((int *)_2)[2] = _5017;
        _5018 = MAKE_SEQ(_1);
        _5017 = NOVALUE;
        _5016 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5008);
        _5008 = NOVALUE;
        _5012 = NOVALUE;
        return _5018;

        /** 		case I3B then*/
        case 250:

        /** 			return {sdata[pos] +*/
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5019 = (int)*(((s1_ptr)_2)->base + _pos_9140);
        _5020 = _pos_9140 + 1;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5021 = (int)*(((s1_ptr)_2)->base + _5020);
        if (IS_ATOM_INT(_5021)) {
            if (_5021 <= INT15 && _5021 >= -INT15)
            _5022 = 256 * _5021;
            else
            _5022 = NewDouble(256 * (double)_5021);
        }
        else {
            _5022 = binary_op(MULTIPLY, 256, _5021);
        }
        _5021 = NOVALUE;
        if (IS_ATOM_INT(_5019) && IS_ATOM_INT(_5022)) {
            _5023 = _5019 + _5022;
            if ((long)((unsigned long)_5023 + (unsigned long)HIGH_BITS) >= 0) 
            _5023 = NewDouble((double)_5023);
        }
        else {
            _5023 = binary_op(PLUS, _5019, _5022);
        }
        _5019 = NOVALUE;
        DeRef(_5022);
        _5022 = NOVALUE;
        _5024 = _pos_9140 + 2;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5025 = (int)*(((s1_ptr)_2)->base + _5024);
        if (IS_ATOM_INT(_5025)) {
            _5026 = NewDouble(65536 * (double)_5025);
        }
        else {
            _5026 = binary_op(MULTIPLY, 65536, _5025);
        }
        _5025 = NOVALUE;
        if (IS_ATOM_INT(_5023) && IS_ATOM_INT(_5026)) {
            _5027 = _5023 + _5026;
            if ((long)((unsigned long)_5027 + (unsigned long)HIGH_BITS) >= 0) 
            _5027 = NewDouble((double)_5027);
        }
        else {
            _5027 = binary_op(PLUS, _5023, _5026);
        }
        DeRef(_5023);
        _5023 = NOVALUE;
        DeRef(_5026);
        _5026 = NOVALUE;
        if (IS_ATOM_INT(_5027)) {
            _5028 = _5027 + _27MIN3B_8916;
            if ((long)((unsigned long)_5028 + (unsigned long)HIGH_BITS) >= 0) 
            _5028 = NewDouble((double)_5028);
        }
        else {
            _5028 = binary_op(PLUS, _5027, _27MIN3B_8916);
        }
        DeRef(_5027);
        _5027 = NOVALUE;
        _5029 = _pos_9140 + 3;
        if ((long)((unsigned long)_5029 + (unsigned long)HIGH_BITS) >= 0) 
        _5029 = NewDouble((double)_5029);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5028;
        ((int *)_2)[2] = _5029;
        _5030 = MAKE_SEQ(_1);
        _5029 = NOVALUE;
        _5028 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        _5024 = NOVALUE;
        _5020 = NOVALUE;
        return _5030;

        /** 		case I4B then*/
        case 251:

        /** 			return {getp4(sdata, pos) + MIN4B, pos + 4}*/
        RefDS(_sdata_9139);
        _5031 = _27getp4(_sdata_9139, _pos_9140);
        if (IS_ATOM_INT(_5031) && IS_ATOM_INT(_27MIN4B_8922)) {
            _5032 = _5031 + _27MIN4B_8922;
            if ((long)((unsigned long)_5032 + (unsigned long)HIGH_BITS) >= 0) 
            _5032 = NewDouble((double)_5032);
        }
        else {
            _5032 = binary_op(PLUS, _5031, _27MIN4B_8922);
        }
        DeRef(_5031);
        _5031 = NOVALUE;
        _5033 = _pos_9140 + 4;
        if ((long)((unsigned long)_5033 + (unsigned long)HIGH_BITS) >= 0) 
        _5033 = NewDouble((double)_5033);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5032;
        ((int *)_2)[2] = _5033;
        _5034 = MAKE_SEQ(_1);
        _5033 = NOVALUE;
        _5032 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        return _5034;

        /** 		case F4B then*/
        case 252:

        /** 			return {convert:float32_to_atom({sdata[pos], sdata[pos+1],*/
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5035 = (int)*(((s1_ptr)_2)->base + _pos_9140);
        _5036 = _pos_9140 + 1;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5037 = (int)*(((s1_ptr)_2)->base + _5036);
        _5038 = _pos_9140 + 2;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5039 = (int)*(((s1_ptr)_2)->base + _5038);
        _5040 = _pos_9140 + 3;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5041 = (int)*(((s1_ptr)_2)->base + _5040);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_5035);
        *((int *)(_2+4)) = _5035;
        Ref(_5037);
        *((int *)(_2+8)) = _5037;
        Ref(_5039);
        *((int *)(_2+12)) = _5039;
        Ref(_5041);
        *((int *)(_2+16)) = _5041;
        _5042 = MAKE_SEQ(_1);
        _5041 = NOVALUE;
        _5039 = NOVALUE;
        _5037 = NOVALUE;
        _5035 = NOVALUE;
        DeRef(_ieee32_inlined_float32_to_atom_at_227_9191);
        _ieee32_inlined_float32_to_atom_at_227_9191 = _5042;
        _5042 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_230_9192);
        _float32_to_atom_inlined_float32_to_atom_at_230_9192 = machine(49, _ieee32_inlined_float32_to_atom_at_227_9191);
        DeRef(_ieee32_inlined_float32_to_atom_at_227_9191);
        _ieee32_inlined_float32_to_atom_at_227_9191 = NOVALUE;
        _5043 = _pos_9140 + 4;
        if ((long)((unsigned long)_5043 + (unsigned long)HIGH_BITS) >= 0) 
        _5043 = NewDouble((double)_5043);
        Ref(_float32_to_atom_inlined_float32_to_atom_at_230_9192);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _float32_to_atom_inlined_float32_to_atom_at_230_9192;
        ((int *)_2)[2] = _5043;
        _5044 = MAKE_SEQ(_1);
        _5043 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        DeRef(_5034);
        _5034 = NOVALUE;
        DeRef(_5036);
        _5036 = NOVALUE;
        DeRef(_5038);
        _5038 = NOVALUE;
        DeRef(_5040);
        _5040 = NOVALUE;
        return _5044;

        /** 		case F8B then*/
        case 253:

        /** 			return {convert:float64_to_atom({sdata[pos], sdata[pos+1],*/
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5045 = (int)*(((s1_ptr)_2)->base + _pos_9140);
        _5046 = _pos_9140 + 1;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5047 = (int)*(((s1_ptr)_2)->base + _5046);
        _5048 = _pos_9140 + 2;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5049 = (int)*(((s1_ptr)_2)->base + _5048);
        _5050 = _pos_9140 + 3;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5051 = (int)*(((s1_ptr)_2)->base + _5050);
        _5052 = _pos_9140 + 4;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5053 = (int)*(((s1_ptr)_2)->base + _5052);
        _5054 = _pos_9140 + 5;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5055 = (int)*(((s1_ptr)_2)->base + _5054);
        _5056 = _pos_9140 + 6;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5057 = (int)*(((s1_ptr)_2)->base + _5056);
        _5058 = _pos_9140 + 7;
        _2 = (int)SEQ_PTR(_sdata_9139);
        _5059 = (int)*(((s1_ptr)_2)->base + _5058);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_5045);
        *((int *)(_2+4)) = _5045;
        Ref(_5047);
        *((int *)(_2+8)) = _5047;
        Ref(_5049);
        *((int *)(_2+12)) = _5049;
        Ref(_5051);
        *((int *)(_2+16)) = _5051;
        Ref(_5053);
        *((int *)(_2+20)) = _5053;
        Ref(_5055);
        *((int *)(_2+24)) = _5055;
        Ref(_5057);
        *((int *)(_2+28)) = _5057;
        Ref(_5059);
        *((int *)(_2+32)) = _5059;
        _5060 = MAKE_SEQ(_1);
        _5059 = NOVALUE;
        _5057 = NOVALUE;
        _5055 = NOVALUE;
        _5053 = NOVALUE;
        _5051 = NOVALUE;
        _5049 = NOVALUE;
        _5047 = NOVALUE;
        _5045 = NOVALUE;
        DeRef(_ieee64_inlined_float64_to_atom_at_330_9213);
        _ieee64_inlined_float64_to_atom_at_330_9213 = _5060;
        _5060 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_333_9214);
        _float64_to_atom_inlined_float64_to_atom_at_333_9214 = machine(47, _ieee64_inlined_float64_to_atom_at_330_9213);
        DeRef(_ieee64_inlined_float64_to_atom_at_330_9213);
        _ieee64_inlined_float64_to_atom_at_330_9213 = NOVALUE;
        _5061 = _pos_9140 + 8;
        if ((long)((unsigned long)_5061 + (unsigned long)HIGH_BITS) >= 0) 
        _5061 = NewDouble((double)_5061);
        Ref(_float64_to_atom_inlined_float64_to_atom_at_333_9214);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _float64_to_atom_inlined_float64_to_atom_at_333_9214;
        ((int *)_2)[2] = _5061;
        _5062 = MAKE_SEQ(_1);
        _5061 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5054);
        _5054 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        DeRef(_5040);
        _5040 = NOVALUE;
        DeRef(_5044);
        _5044 = NOVALUE;
        DeRef(_5036);
        _5036 = NOVALUE;
        DeRef(_5034);
        _5034 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5048);
        _5048 = NOVALUE;
        DeRef(_5050);
        _5050 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5038);
        _5038 = NOVALUE;
        DeRef(_5056);
        _5056 = NOVALUE;
        DeRef(_5046);
        _5046 = NOVALUE;
        DeRef(_5058);
        _5058 = NOVALUE;
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5052);
        _5052 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        return _5062;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_9141 != 254)
        goto L3; // [363] 382

        /** 				len = sdata[pos]*/
        _2 = (int)SEQ_PTR(_sdata_9139);
        _len_9143 = (int)*(((s1_ptr)_2)->base + _pos_9140);
        if (!IS_ATOM_INT(_len_9143))
        _len_9143 = (long)DBL_PTR(_len_9143)->dbl;

        /** 				pos += 1*/
        _pos_9140 = _pos_9140 + 1;
        goto L4; // [379] 398
L3: 

        /** 				len = getp4(sdata, pos)*/
        RefDS(_sdata_9139);
        _len_9143 = _27getp4(_sdata_9139, _pos_9140);
        if (!IS_ATOM_INT(_len_9143)) {
            _1 = (long)(DBL_PTR(_len_9143)->dbl);
            DeRefDS(_len_9143);
            _len_9143 = _1;
        }

        /** 				pos += 4*/
        _pos_9140 = _pos_9140 + 4;
L4: 

        /** 			if c = S4B and len < 256 then*/
        _5068 = (_c_9141 == 255);
        if (_5068 == 0) {
            goto L5; // [404] 516
        }
        _5070 = (_len_9143 < 256);
        if (_5070 == 0)
        {
            DeRef(_5070);
            _5070 = NOVALUE;
            goto L5; // [415] 516
        }
        else{
            DeRef(_5070);
            _5070 = NOVALUE;
        }

        /** 				if len = I8B then*/
        if (_len_9143 != 0)
        goto L6; // [422] 456

        /** 					return {int64_to_atom( sdata[pos..pos+7] ), pos + 8 }*/
        _5072 = _pos_9140 + 7;
        rhs_slice_target = (object_ptr)&_5073;
        RHS_Slice(_sdata_9139, _pos_9140, _5072);
        _5074 = _27int64_to_atom(_5073);
        _5073 = NOVALUE;
        _5075 = _pos_9140 + 8;
        if ((long)((unsigned long)_5075 + (unsigned long)HIGH_BITS) >= 0) 
        _5075 = NewDouble((double)_5075);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5074;
        ((int *)_2)[2] = _5075;
        _5076 = MAKE_SEQ(_1);
        _5075 = NOVALUE;
        _5074 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5054);
        _5054 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        DeRef(_5040);
        _5040 = NOVALUE;
        DeRef(_5044);
        _5044 = NOVALUE;
        DeRef(_5036);
        _5036 = NOVALUE;
        DeRef(_5034);
        _5034 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5048);
        _5048 = NOVALUE;
        DeRef(_5050);
        _5050 = NOVALUE;
        _5072 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5062);
        _5062 = NOVALUE;
        DeRef(_5038);
        _5038 = NOVALUE;
        DeRef(_5056);
        _5056 = NOVALUE;
        DeRef(_5046);
        _5046 = NOVALUE;
        DeRef(_5058);
        _5058 = NOVALUE;
        DeRef(_5068);
        _5068 = NOVALUE;
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5052);
        _5052 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        return _5076;
        goto L7; // [453] 623
L6: 

        /** 				elsif len = F10B then*/
        if (_len_9143 != 1)
        goto L8; // [458] 492

        /** 					return { float80_to_atom( sdata[pos..pos+9] ), pos + 10 }*/
        _5078 = _pos_9140 + 9;
        rhs_slice_target = (object_ptr)&_5079;
        RHS_Slice(_sdata_9139, _pos_9140, _5078);
        _5080 = _27float80_to_atom(_5079);
        _5079 = NOVALUE;
        _5081 = _pos_9140 + 10;
        if ((long)((unsigned long)_5081 + (unsigned long)HIGH_BITS) >= 0) 
        _5081 = NewDouble((double)_5081);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5080;
        ((int *)_2)[2] = _5081;
        _5082 = MAKE_SEQ(_1);
        _5081 = NOVALUE;
        _5080 = NOVALUE;
        DeRefDS(_sdata_9139);
        DeRef(_s_9142);
        DeRef(_5054);
        _5054 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        DeRef(_5040);
        _5040 = NOVALUE;
        DeRef(_5044);
        _5044 = NOVALUE;
        DeRef(_5036);
        _5036 = NOVALUE;
        DeRef(_5034);
        _5034 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5048);
        _5048 = NOVALUE;
        DeRef(_5050);
        _5050 = NOVALUE;
        DeRef(_5072);
        _5072 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        _5078 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5062);
        _5062 = NOVALUE;
        DeRef(_5038);
        _5038 = NOVALUE;
        DeRef(_5056);
        _5056 = NOVALUE;
        DeRef(_5046);
        _5046 = NOVALUE;
        DeRef(_5058);
        _5058 = NOVALUE;
        DeRef(_5068);
        _5068 = NOVALUE;
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5052);
        _5052 = NOVALUE;
        DeRef(_5076);
        _5076 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        return _5082;
        goto L7; // [489] 623
L8: 

        /** 					error:crash( "Invalid sequence serialization" )*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_493_9245);
        _msg_inlined_crash_at_493_9245 = EPrintf(-9999999, _4985, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_493_9245);

        /** end procedure*/
        goto L9; // [507] 510
L9: 
        DeRefi(_msg_inlined_crash_at_493_9245);
        _msg_inlined_crash_at_493_9245 = NOVALUE;
        goto L7; // [513] 623
L5: 

        /** 				s = repeat(0, len)*/
        DeRef(_s_9142);
        _s_9142 = Repeat(0, _len_9143);

        /** 				for i = 1 to len do*/
        _5084 = _len_9143;
        {
            int _i_9249;
            _i_9249 = 1;
LA: 
            if (_i_9249 > _5084){
                goto LB; // [529] 612
            }

            /** 					c = sdata[pos]*/
            _2 = (int)SEQ_PTR(_sdata_9139);
            _c_9141 = (int)*(((s1_ptr)_2)->base + _pos_9140);
            if (!IS_ATOM_INT(_c_9141))
            _c_9141 = (long)DBL_PTR(_c_9141)->dbl;

            /** 					pos += 1*/
            _pos_9140 = _pos_9140 + 1;

            /** 					if c < I2B then*/
            if (_c_9141 >= 249)
            goto LC; // [550] 567

            /** 						s[i] = c + MIN1B*/
            _5088 = _c_9141 + -9;
            if ((long)((unsigned long)_5088 + (unsigned long)HIGH_BITS) >= 0) 
            _5088 = NewDouble((double)_5088);
            _2 = (int)SEQ_PTR(_s_9142);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9142 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_9249);
            _1 = *(int *)_2;
            *(int *)_2 = _5088;
            if( _1 != _5088 ){
                DeRef(_1);
            }
            _5088 = NOVALUE;
            goto LD; // [564] 605
LC: 

            /** 						sequence temp = deserialize_object(sdata, pos, c)*/
            RefDS(_sdata_9139);
            DeRef(_5089);
            _5089 = _sdata_9139;
            DeRef(_5090);
            _5090 = _pos_9140;
            DeRef(_5091);
            _5091 = _c_9141;
            _0 = _temp_9257;
            _temp_9257 = _27deserialize_object(_5089, _5090, _5091);
            DeRef(_0);
            _5089 = NOVALUE;
            _5090 = NOVALUE;
            _5091 = NOVALUE;

            /** 						s[i] = temp[1]*/
            _2 = (int)SEQ_PTR(_temp_9257);
            _5093 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_5093);
            _2 = (int)SEQ_PTR(_s_9142);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9142 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_9249);
            _1 = *(int *)_2;
            *(int *)_2 = _5093;
            if( _1 != _5093 ){
                DeRef(_1);
            }
            _5093 = NOVALUE;

            /** 						pos = temp[2]*/
            _2 = (int)SEQ_PTR(_temp_9257);
            _pos_9140 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_pos_9140))
            _pos_9140 = (long)DBL_PTR(_pos_9140)->dbl;
            DeRefDS(_temp_9257);
            _temp_9257 = NOVALUE;
LD: 

            /** 				end for*/
            _i_9249 = _i_9249 + 1;
            goto LA; // [607] 536
LB: 
            ;
        }

        /** 				return {s, pos}*/
        RefDS(_s_9142);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _s_9142;
        ((int *)_2)[2] = _pos_9140;
        _5095 = MAKE_SEQ(_1);
        DeRefDS(_sdata_9139);
        DeRefDS(_s_9142);
        DeRef(_5054);
        _5054 = NOVALUE;
        DeRef(_5030);
        _5030 = NOVALUE;
        DeRef(_5040);
        _5040 = NOVALUE;
        DeRef(_5044);
        _5044 = NOVALUE;
        DeRef(_5036);
        _5036 = NOVALUE;
        DeRef(_5034);
        _5034 = NOVALUE;
        DeRef(_5024);
        _5024 = NOVALUE;
        DeRef(_5048);
        _5048 = NOVALUE;
        DeRef(_5050);
        _5050 = NOVALUE;
        DeRef(_5072);
        _5072 = NOVALUE;
        DeRef(_5012);
        _5012 = NOVALUE;
        DeRef(_5078);
        _5078 = NOVALUE;
        DeRef(_5018);
        _5018 = NOVALUE;
        DeRef(_5062);
        _5062 = NOVALUE;
        DeRef(_5082);
        _5082 = NOVALUE;
        DeRef(_5038);
        _5038 = NOVALUE;
        DeRef(_5056);
        _5056 = NOVALUE;
        DeRef(_5046);
        _5046 = NOVALUE;
        DeRef(_5058);
        _5058 = NOVALUE;
        DeRef(_5068);
        _5068 = NOVALUE;
        DeRef(_5008);
        _5008 = NOVALUE;
        DeRef(_5052);
        _5052 = NOVALUE;
        DeRef(_5076);
        _5076 = NOVALUE;
        DeRef(_5020);
        _5020 = NOVALUE;
        return _5095;
L7: 
    ;}    ;
}


int  __stdcall _27deserialize(int _sdata_9267, int _pos_9268)
{
    int _5099 = NOVALUE;
    int _5098 = NOVALUE;
    int _5097 = NOVALUE;
    int _5096 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pos_9268)) {
        _1 = (long)(DBL_PTR(_pos_9268)->dbl);
        DeRefDS(_pos_9268);
        _pos_9268 = _1;
    }

    /** 	if integer(sdata) then*/
    if (IS_ATOM_INT(_sdata_9267))
    _5096 = 1;
    else if (IS_ATOM_DBL(_sdata_9267))
    _5096 = IS_ATOM_INT(DoubleToInt(_sdata_9267));
    else
    _5096 = 0;
    if (_5096 == 0)
    {
        _5096 = NOVALUE;
        goto L1; // [8] 23
    }
    else{
        _5096 = NOVALUE;
    }

    /** 		return deserialize_file(sdata, 0)*/
    Ref(_sdata_9267);
    _5097 = _27deserialize_file(_sdata_9267, 0);
    DeRef(_sdata_9267);
    return _5097;
L1: 

    /** 	if atom(sdata) then*/
    _5098 = IS_ATOM(_sdata_9267);
    if (_5098 == 0)
    {
        _5098 = NOVALUE;
        goto L2; // [28] 38
    }
    else{
        _5098 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_sdata_9267);
    DeRef(_5097);
    _5097 = NOVALUE;
    return 0;
L2: 

    /** 	return deserialize_object(sdata, pos, 0)*/
    Ref(_sdata_9267);
    _5099 = _27deserialize_object(_sdata_9267, _pos_9268, 0);
    DeRef(_sdata_9267);
    DeRef(_5097);
    _5097 = NOVALUE;
    return _5099;
    ;
}


int  __stdcall _27serialize(int _x_9277)
{
    int _x4_9278 = NOVALUE;
    int _s_9279 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_9313 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_9316 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_9321 = NOVALUE;
    int _5138 = NOVALUE;
    int _5137 = NOVALUE;
    int _5136 = NOVALUE;
    int _5134 = NOVALUE;
    int _5133 = NOVALUE;
    int _5131 = NOVALUE;
    int _5129 = NOVALUE;
    int _5128 = NOVALUE;
    int _5127 = NOVALUE;
    int _5125 = NOVALUE;
    int _5124 = NOVALUE;
    int _5123 = NOVALUE;
    int _5122 = NOVALUE;
    int _5121 = NOVALUE;
    int _5120 = NOVALUE;
    int _5119 = NOVALUE;
    int _5118 = NOVALUE;
    int _5117 = NOVALUE;
    int _5115 = NOVALUE;
    int _5114 = NOVALUE;
    int _5113 = NOVALUE;
    int _5112 = NOVALUE;
    int _5111 = NOVALUE;
    int _5110 = NOVALUE;
    int _5108 = NOVALUE;
    int _5107 = NOVALUE;
    int _5106 = NOVALUE;
    int _5105 = NOVALUE;
    int _5104 = NOVALUE;
    int _5103 = NOVALUE;
    int _5102 = NOVALUE;
    int _5101 = NOVALUE;
    int _5100 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_9277))
    _5100 = 1;
    else if (IS_ATOM_DBL(_x_9277))
    _5100 = IS_ATOM_INT(DoubleToInt(_x_9277));
    else
    _5100 = 0;
    if (_5100 == 0)
    {
        _5100 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _5100 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_9277)) {
        _5101 = (_x_9277 >= -9);
    }
    else {
        _5101 = binary_op(GREATEREQ, _x_9277, -9);
    }
    if (IS_ATOM_INT(_5101)) {
        if (_5101 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_5101)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_9277)) {
        _5103 = (_x_9277 <= 239);
    }
    else {
        _5103 = binary_op(LESSEQ, _x_9277, 239);
    }
    if (_5103 == 0) {
        DeRef(_5103);
        _5103 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_5103) && DBL_PTR(_5103)->dbl == 0.0){
            DeRef(_5103);
            _5103 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_5103);
        _5103 = NOVALUE;
    }
    DeRef(_5103);
    _5103 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_9277)) {
        _5104 = _x_9277 - -9;
        if ((long)((unsigned long)_5104 +(unsigned long) HIGH_BITS) >= 0){
            _5104 = NewDouble((double)_5104);
        }
    }
    else {
        _5104 = binary_op(MINUS, _x_9277, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5104;
    _5105 = MAKE_SEQ(_1);
    _5104 = NOVALUE;
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    return _5105;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_9277)) {
        _5106 = (_x_9277 >= _27MIN2B_8910);
    }
    else {
        _5106 = binary_op(GREATEREQ, _x_9277, _27MIN2B_8910);
    }
    if (IS_ATOM_INT(_5106)) {
        if (_5106 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_5106)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_9277)) {
        _5108 = (_x_9277 <= 32767);
    }
    else {
        _5108 = binary_op(LESSEQ, _x_9277, 32767);
    }
    if (_5108 == 0) {
        DeRef(_5108);
        _5108 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_5108) && DBL_PTR(_5108)->dbl == 0.0){
            DeRef(_5108);
            _5108 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_5108);
        _5108 = NOVALUE;
    }
    DeRef(_5108);
    _5108 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_9277;
    if (IS_ATOM_INT(_x_9277)) {
        _x_9277 = _x_9277 - _27MIN2B_8910;
        if ((long)((unsigned long)_x_9277 +(unsigned long) HIGH_BITS) >= 0){
            _x_9277 = NewDouble((double)_x_9277);
        }
    }
    else {
        _x_9277 = binary_op(MINUS, _x_9277, _27MIN2B_8910);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_9277)) {
        {unsigned long tu;
             tu = (unsigned long)_x_9277 & (unsigned long)255;
             _5110 = MAKE_UINT(tu);
        }
    }
    else {
        _5110 = binary_op(AND_BITS, _x_9277, 255);
    }
    if (IS_ATOM_INT(_x_9277)) {
        if (256 > 0 && _x_9277 >= 0) {
            _5111 = _x_9277 / 256;
        }
        else {
            temp_dbl = floor((double)_x_9277 / (double)256);
            if (_x_9277 != MININT)
            _5111 = (long)temp_dbl;
            else
            _5111 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9277, 256);
        _5111 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _5110;
    *((int *)(_2+12)) = _5111;
    _5112 = MAKE_SEQ(_1);
    _5111 = NOVALUE;
    _5110 = NOVALUE;
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    return _5112;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_9277)) {
        _5113 = (_x_9277 >= _27MIN3B_8916);
    }
    else {
        _5113 = binary_op(GREATEREQ, _x_9277, _27MIN3B_8916);
    }
    if (IS_ATOM_INT(_5113)) {
        if (_5113 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_5113)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_9277)) {
        _5115 = (_x_9277 <= 8388607);
    }
    else {
        _5115 = binary_op(LESSEQ, _x_9277, 8388607);
    }
    if (_5115 == 0) {
        DeRef(_5115);
        _5115 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_5115) && DBL_PTR(_5115)->dbl == 0.0){
            DeRef(_5115);
            _5115 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_5115);
        _5115 = NOVALUE;
    }
    DeRef(_5115);
    _5115 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_9277;
    if (IS_ATOM_INT(_x_9277)) {
        _x_9277 = _x_9277 - _27MIN3B_8916;
        if ((long)((unsigned long)_x_9277 +(unsigned long) HIGH_BITS) >= 0){
            _x_9277 = NewDouble((double)_x_9277);
        }
    }
    else {
        _x_9277 = binary_op(MINUS, _x_9277, _27MIN3B_8916);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_9277)) {
        {unsigned long tu;
             tu = (unsigned long)_x_9277 & (unsigned long)255;
             _5117 = MAKE_UINT(tu);
        }
    }
    else {
        _5117 = binary_op(AND_BITS, _x_9277, 255);
    }
    if (IS_ATOM_INT(_x_9277)) {
        if (256 > 0 && _x_9277 >= 0) {
            _5118 = _x_9277 / 256;
        }
        else {
            temp_dbl = floor((double)_x_9277 / (double)256);
            if (_x_9277 != MININT)
            _5118 = (long)temp_dbl;
            else
            _5118 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9277, 256);
        _5118 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_5118)) {
        {unsigned long tu;
             tu = (unsigned long)_5118 & (unsigned long)255;
             _5119 = MAKE_UINT(tu);
        }
    }
    else {
        _5119 = binary_op(AND_BITS, _5118, 255);
    }
    DeRef(_5118);
    _5118 = NOVALUE;
    if (IS_ATOM_INT(_x_9277)) {
        if (65536 > 0 && _x_9277 >= 0) {
            _5120 = _x_9277 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_9277 / (double)65536);
            if (_x_9277 != MININT)
            _5120 = (long)temp_dbl;
            else
            _5120 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9277, 65536);
        _5120 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _5117;
    *((int *)(_2+12)) = _5119;
    *((int *)(_2+16)) = _5120;
    _5121 = MAKE_SEQ(_1);
    _5120 = NOVALUE;
    _5119 = NOVALUE;
    _5117 = NOVALUE;
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    DeRef(_5112);
    _5112 = NOVALUE;
    DeRef(_5113);
    _5113 = NOVALUE;
    return _5121;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_9277) && IS_ATOM_INT(_27MIN4B_8922)) {
        _5122 = _x_9277 - _27MIN4B_8922;
        if ((long)((unsigned long)_5122 +(unsigned long) HIGH_BITS) >= 0){
            _5122 = NewDouble((double)_5122);
        }
    }
    else {
        _5122 = binary_op(MINUS, _x_9277, _27MIN4B_8922);
    }
    _5123 = _8int_to_bytes(_5122);
    _5122 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_5123)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_5123)) {
        Prepend(&_5124, _5123, 251);
    }
    else {
        Concat((object_ptr)&_5124, 251, _5123);
    }
    DeRef(_5123);
    _5123 = NOVALUE;
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    DeRef(_5112);
    _5112 = NOVALUE;
    DeRef(_5113);
    _5113 = NOVALUE;
    DeRef(_5121);
    _5121 = NOVALUE;
    return _5124;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _5125 = IS_ATOM(_x_9277);
    if (_5125 == 0)
    {
        _5125 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _5125 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_9278);
    _x4_9278 = machine(48, _x_9277);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_9316);
    _float32_to_atom_inlined_float32_to_atom_at_203_9316 = machine(49, _x4_9278);
    if (binary_op_a(NOTEQ, _x_9277, _float32_to_atom_inlined_float32_to_atom_at_203_9316)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_5127, _x4_9278, 252);
    DeRef(_x_9277);
    DeRefDSi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    DeRef(_5112);
    _5112 = NOVALUE;
    DeRef(_5113);
    _5113 = NOVALUE;
    DeRef(_5121);
    _5121 = NOVALUE;
    DeRef(_5124);
    _5124 = NOVALUE;
    return _5127;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_9321);
    _atom_to_float64_inlined_atom_to_float64_at_229_9321 = machine(46, _x_9277);
    Prepend(&_5128, _atom_to_float64_inlined_atom_to_float64_at_229_9321, 253);
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_s_9279);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    DeRef(_5112);
    _5112 = NOVALUE;
    DeRef(_5113);
    _5113 = NOVALUE;
    DeRef(_5121);
    _5121 = NOVALUE;
    DeRef(_5124);
    _5124 = NOVALUE;
    DeRef(_5127);
    _5127 = NOVALUE;
    return _5128;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_9277)){
            _5129 = SEQ_PTR(_x_9277)->length;
    }
    else {
        _5129 = 1;
    }
    if (_5129 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_9277)){
            _5131 = SEQ_PTR(_x_9277)->length;
    }
    else {
        _5131 = 1;
    }
    DeRef(_s_9279);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _5131;
    _s_9279 = MAKE_SEQ(_1);
    _5131 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_9277)){
            _5133 = SEQ_PTR(_x_9277)->length;
    }
    else {
        _5133 = 1;
    }
    _5134 = _8int_to_bytes(_5133);
    _5133 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_5134)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_5134)) {
        Prepend(&_s_9279, _5134, 255);
    }
    else {
        Concat((object_ptr)&_s_9279, 255, _5134);
    }
    DeRef(_5134);
    _5134 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9277)){
            _5136 = SEQ_PTR(_x_9277)->length;
    }
    else {
        _5136 = 1;
    }
    {
        int _i_9334;
        _i_9334 = 1;
LA: 
        if (_i_9334 > _5136){
            goto LB; // [289] 319
        }

        /** 			s &= serialize(x[i])*/
        _2 = (int)SEQ_PTR(_x_9277);
        _5137 = (int)*(((s1_ptr)_2)->base + _i_9334);
        Ref(_5137);
        _5138 = _27serialize(_5137);
        _5137 = NOVALUE;
        if (IS_SEQUENCE(_s_9279) && IS_ATOM(_5138)) {
            Ref(_5138);
            Append(&_s_9279, _s_9279, _5138);
        }
        else if (IS_ATOM(_s_9279) && IS_SEQUENCE(_5138)) {
        }
        else {
            Concat((object_ptr)&_s_9279, _s_9279, _5138);
        }
        DeRef(_5138);
        _5138 = NOVALUE;

        /** 		end for*/
        _i_9334 = _i_9334 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_9277);
    DeRefi(_x4_9278);
    DeRef(_5101);
    _5101 = NOVALUE;
    DeRef(_5105);
    _5105 = NOVALUE;
    DeRef(_5106);
    _5106 = NOVALUE;
    DeRef(_5112);
    _5112 = NOVALUE;
    DeRef(_5113);
    _5113 = NOVALUE;
    DeRef(_5121);
    _5121 = NOVALUE;
    DeRef(_5124);
    _5124 = NOVALUE;
    DeRef(_5127);
    _5127 = NOVALUE;
    DeRef(_5128);
    _5128 = NOVALUE;
    return _s_9279;
L3: 
    ;
}


int  __stdcall _27dump(int _data_9341, int _filename_9342)
{
    int _fh_9343 = NOVALUE;
    int _sdata_9344 = NOVALUE;
    int _5143 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(filename, "wb")*/
    _fh_9343 = EOpen(_filename_9342, _1354, 0);

    /** 	if fh < 0 then*/
    if (_fh_9343 >= 0)
    goto L1; // [14] 25

    /** 		return 0*/
    DeRefDS(_data_9341);
    DeRefDS(_filename_9342);
    DeRef(_sdata_9344);
    return 0;
L1: 

    /** 	sdata = serialize(data)*/
    RefDS(_data_9341);
    _0 = _sdata_9344;
    _sdata_9344 = _27serialize(_data_9341);
    DeRef(_0);

    /** 	puts(fh, sdata)*/
    EPuts(_fh_9343, _sdata_9344); // DJP 

    /** 	close(fh)*/
    EClose(_fh_9343);

    /** 	return length(sdata) -- Length is always > 0*/
    if (IS_SEQUENCE(_sdata_9344)){
            _5143 = SEQ_PTR(_sdata_9344)->length;
    }
    else {
        _5143 = 1;
    }
    DeRefDS(_data_9341);
    DeRefDS(_filename_9342);
    DeRefDS(_sdata_9344);
    return _5143;
    ;
}


int  __stdcall _27load(int _filename_9352)
{
    int _fh_9353 = NOVALUE;
    int _sdata_9354 = NOVALUE;
    int _5148 = NOVALUE;
    int _5146 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(filename, "rb")*/
    _fh_9353 = EOpen(_filename_9352, _1309, 0);

    /** 	if fh < 0 then*/
    if (_fh_9353 >= 0)
    goto L1; // [12] 27

    /** 		return {0}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _5146 = MAKE_SEQ(_1);
    DeRefDS(_filename_9352);
    DeRef(_sdata_9354);
    return _5146;
L1: 

    /** 	sdata = deserialize(fh)*/
    _0 = _sdata_9354;
    _sdata_9354 = _27deserialize(_fh_9353, 1);
    DeRef(_0);

    /** 	close(fh)*/
    EClose(_fh_9353);

    /** 	return {1, sdata}*/
    RefDS(_sdata_9354);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _sdata_9354;
    _5148 = MAKE_SEQ(_1);
    DeRefDS(_filename_9352);
    DeRefDS(_sdata_9354);
    DeRef(_5146);
    _5146 = NOVALUE;
    return _5148;
    ;
}



// 0xA850081B
