// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _49is_inetaddr(int _address_21880)
{
    int _12304 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:is_match(re_ip, address)*/
    Ref(_49re_ip_21869);
    RefDS(_address_21880);
    _12304 = _47is_match(_49re_ip_21869, _address_21880, 1, 0);
    DeRefDS(_address_21880);
    return _12304;
    ;
}


int  __stdcall _49parse_ip_address(int _address_21884, int _port_21885)
{
    int _value_inlined_value_at_92_21906 = NOVALUE;
    int _st_inlined_value_at_89_21905 = NOVALUE;
    int _12322 = NOVALUE;
    int _12321 = NOVALUE;
    int _12319 = NOVALUE;
    int _12318 = NOVALUE;
    int _12317 = NOVALUE;
    int _12316 = NOVALUE;
    int _12314 = NOVALUE;
    int _12311 = NOVALUE;
    int _12308 = NOVALUE;
    int _12306 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_21885)) {
        _1 = (long)(DBL_PTR(_port_21885)->dbl);
        DeRefDS(_port_21885);
        _port_21885 = _1;
    }

    /** 	address = seq:split(address, ':')*/
    RefDS(_address_21884);
    _0 = _address_21884;
    _address_21884 = _23split(_address_21884, 58, 0, 0);
    DeRefDS(_0);

    /** 	if length(address) = 1 then*/
    if (IS_SEQUENCE(_address_21884)){
            _12306 = SEQ_PTR(_address_21884)->length;
    }
    else {
        _12306 = 1;
    }
    if (_12306 != 1)
    goto L1; // [21] 63

    /** 		if port < 0 or port > 65_535 then*/
    _12308 = (_port_21885 < 0);
    if (_12308 != 0) {
        goto L2; // [31] 44
    }
    _12311 = (_port_21885 > 65535);
    if (_12311 == 0)
    {
        DeRef(_12311);
        _12311 = NOVALUE;
        goto L3; // [40] 53
    }
    else{
        DeRef(_12311);
        _12311 = NOVALUE;
    }
L2: 

    /** 			address &= DEFAULT_PORT*/
    Append(&_address_21884, _address_21884, 80);
    goto L4; // [50] 161
L3: 

    /** 			address &= port*/
    Append(&_address_21884, _address_21884, _port_21885);
    goto L4; // [60] 161
L1: 

    /** 		if port < 0 or port > 65_535 then*/
    _12314 = (_port_21885 < 0);
    if (_12314 != 0) {
        goto L5; // [69] 82
    }
    _12316 = (_port_21885 > 65535);
    if (_12316 == 0)
    {
        DeRef(_12316);
        _12316 = NOVALUE;
        goto L6; // [78] 153
    }
    else{
        DeRef(_12316);
        _12316 = NOVALUE;
    }
L5: 

    /** 			address[2] = stdget:value(address[2])*/
    _2 = (int)SEQ_PTR(_address_21884);
    _12317 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_12317);
    DeRef(_st_inlined_value_at_89_21905);
    _st_inlined_value_at_89_21905 = _12317;
    _12317 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3332)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3332)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3332);
        _17GET_SHORT_ANSWER_3332 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_st_inlined_value_at_89_21905);
    _0 = _value_inlined_value_at_92_21906;
    _value_inlined_value_at_92_21906 = _17get_value(_st_inlined_value_at_89_21905, 1, _17GET_SHORT_ANSWER_3332);
    DeRef(_0);
    DeRef(_st_inlined_value_at_89_21905);
    _st_inlined_value_at_89_21905 = NOVALUE;
    Ref(_value_inlined_value_at_92_21906);
    _2 = (int)SEQ_PTR(_address_21884);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21884 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_92_21906;
    DeRef(_1);

    /** 			if address[2][1] != stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_address_21884);
    _12318 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_12318);
    _12319 = (int)*(((s1_ptr)_2)->base + 1);
    _12318 = NOVALUE;
    if (binary_op_a(EQUALS, _12319, 0)){
        _12319 = NOVALUE;
        goto L7; // [122] 135
    }
    _12319 = NOVALUE;

    /** 				address[2] = DEFAULT_PORT*/
    _2 = (int)SEQ_PTR(_address_21884);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21884 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 80;
    DeRef(_1);
    goto L8; // [132] 160
L7: 

    /** 				address[2] = address[2][2]*/
    _2 = (int)SEQ_PTR(_address_21884);
    _12321 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_12321);
    _12322 = (int)*(((s1_ptr)_2)->base + 2);
    _12321 = NOVALUE;
    Ref(_12322);
    _2 = (int)SEQ_PTR(_address_21884);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21884 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _12322;
    if( _1 != _12322 ){
        DeRef(_1);
    }
    _12322 = NOVALUE;
    goto L8; // [150] 160
L6: 

    /** 			address[2] = port*/
    _2 = (int)SEQ_PTR(_address_21884);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21884 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _port_21885;
    DeRef(_1);
L8: 
L4: 

    /** 	return address*/
    DeRef(_12308);
    _12308 = NOVALUE;
    DeRef(_12314);
    _12314 = NOVALUE;
    return _address_21884;
    ;
}


int  __stdcall _49parse_url(int _url_21926)
{
    int _m_21927 = NOVALUE;
    int _12338 = NOVALUE;
    int _12336 = NOVALUE;
    int _12335 = NOVALUE;
    int _12332 = NOVALUE;
    int _12330 = NOVALUE;
    int _12328 = NOVALUE;
    int _12325 = NOVALUE;
    int _12324 = NOVALUE;
    int _0, _1, _2;
    

    /** 	m = regex:matches(re_http_url, url)*/
    Ref(_49re_http_url_21872);
    RefDS(_url_21926);
    _0 = _m_21927;
    _m_21927 = _47matches(_49re_http_url_21872, _url_21926, 1, 0);
    DeRef(_0);

    /** 	if sequence(m) then*/
    _12324 = IS_SEQUENCE(_m_21927);
    if (_12324 == 0)
    {
        _12324 = NOVALUE;
        goto L1; // [19] 69
    }
    else{
        _12324 = NOVALUE;
    }

    /** 		if length(m) < URL_HTTP_PATH then*/
    if (IS_SEQUENCE(_m_21927)){
            _12325 = SEQ_PTR(_m_21927)->length;
    }
    else {
        _12325 = 1;
    }
    if (_12325 >= 4)
    goto L2; // [27] 42

    /** 			m &= { "/" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_12327);
    *((int *)(_2+4)) = _12327;
    _12328 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21927) && IS_ATOM(_12328)) {
    }
    else if (IS_ATOM(_m_21927) && IS_SEQUENCE(_12328)) {
        Ref(_m_21927);
        Prepend(&_m_21927, _12328, _m_21927);
    }
    else {
        Concat((object_ptr)&_m_21927, _m_21927, _12328);
    }
    DeRefDS(_12328);
    _12328 = NOVALUE;
L2: 

    /** 		if length(m) < URL_HTTP_QUERY then*/
    if (IS_SEQUENCE(_m_21927)){
            _12330 = SEQ_PTR(_m_21927)->length;
    }
    else {
        _12330 = 1;
    }
    if (_12330 >= 5)
    goto L3; // [47] 62

    /** 			m &= { "" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    _12332 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21927) && IS_ATOM(_12332)) {
    }
    else if (IS_ATOM(_m_21927) && IS_SEQUENCE(_12332)) {
        Ref(_m_21927);
        Prepend(&_m_21927, _12332, _m_21927);
    }
    else {
        Concat((object_ptr)&_m_21927, _m_21927, _12332);
    }
    DeRefDS(_12332);
    _12332 = NOVALUE;
L3: 

    /** 		return m*/
    DeRefDS(_url_21926);
    return _m_21927;
L1: 

    /** 	m = regex:matches(re_mail_url, url)*/
    Ref(_49re_mail_url_21875);
    RefDS(_url_21926);
    _0 = _m_21927;
    _m_21927 = _47matches(_49re_mail_url_21875, _url_21926, 1, 0);
    DeRef(_0);

    /** 	if sequence(m) then*/
    _12335 = IS_SEQUENCE(_m_21927);
    if (_12335 == 0)
    {
        _12335 = NOVALUE;
        goto L4; // [85] 115
    }
    else{
        _12335 = NOVALUE;
    }

    /** 		if length(m) < URL_MAIL_QUERY then*/
    if (IS_SEQUENCE(_m_21927)){
            _12336 = SEQ_PTR(_m_21927)->length;
    }
    else {
        _12336 = 1;
    }
    if (_12336 >= 6)
    goto L5; // [93] 108

    /** 			m &= { "" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    _12338 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21927) && IS_ATOM(_12338)) {
    }
    else if (IS_ATOM(_m_21927) && IS_SEQUENCE(_12338)) {
        Ref(_m_21927);
        Prepend(&_m_21927, _12338, _m_21927);
    }
    else {
        Concat((object_ptr)&_m_21927, _m_21927, _12338);
    }
    DeRefDS(_12338);
    _12338 = NOVALUE;
L5: 

    /** 		return m*/
    DeRefDS(_url_21926);
    return _m_21927;
L4: 

    /** 	return regex:ERROR_NOMATCH*/
    DeRefDS(_url_21926);
    DeRef(_m_21927);
    return -1;
    ;
}



// 0x3765C337
