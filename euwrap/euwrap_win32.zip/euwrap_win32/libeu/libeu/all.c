// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _2syncolor_new()
{
    int _new_inlined_new_at_2_25249 = NOVALUE;
    int _state_inlined_new_at_2_25248 = NOVALUE;
    int _6384 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return syncolor:new()*/

    /** 	atom state = eumem:malloc()*/
    _0 = _state_inlined_new_at_2_25248;
    _state_inlined_new_at_2_25248 = _28malloc(1, 1);
    DeRef(_0);

    /** 	reset(state)*/
    Ref(_state_inlined_new_at_2_25248);
    _5reset(_state_inlined_new_at_2_25248);

    /** 	return state*/
    Ref(_state_inlined_new_at_2_25248);
    DeRef(_new_inlined_new_at_2_25249);
    _new_inlined_new_at_2_25249 = _state_inlined_new_at_2_25248;
    DeRef(_state_inlined_new_at_2_25248);
    _state_inlined_new_at_2_25248 = NOVALUE;
    Ref(_new_inlined_new_at_2_25249);
    DeRef(_6384);
    _6384 = _new_inlined_new_at_2_25249;
    return _6384;
    ;
}


int  __stdcall _2base64_encode(int _a_12286, int _b_12287)
{
    int _6955 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return base64:encode(a,b)*/
    Ref(_a_12286);
    Ref(_b_12287);
    _6955 = _30encode(_a_12286, _b_12287);
    DeRef(_a_12286);
    DeRef(_b_12287);
    return _6955;
    ;
}


int  __stdcall _2base64_decode(int _a_12291)
{
    int _6956 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return base64:decode(a)*/
    Ref(_a_12291);
    _6956 = _30decode(_a_12291);
    DeRef(_a_12291);
    return _6956;
    ;
}


void  __stdcall _2console_allow_break(int _a_16616)
{
    int _0, _1, _2;
    

    /** 	console:allow_break(a)*/

    /** 	machine_proc(M_ALLOW_BREAK, b)*/
    machine(42, _a_16616);

    /** end procedure*/
    goto L1; // [10] 13
L1: 

    /** end procedure*/
    DeRef(_a_16616);
    return;
    ;
}


int  __stdcall _2console_has_console()
{
    int _has_console_inlined_has_console_at_2_16621 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return console:has_console()*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_2_16621);
    _has_console_inlined_has_console_at_2_16621 = machine(99, 0);
    return _has_console_inlined_has_console_at_2_16621;
    ;
}


int  __stdcall _2datetime_format(int _a_16624, int _b_16625)
{
    int _9490 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:format(a,b)*/
    Ref(_a_16624);
    Ref(_b_16625);
    _9490 = _12format(_a_16624, _b_16625);
    DeRef(_a_16624);
    DeRef(_b_16625);
    return _9490;
    ;
}


int  __stdcall _2datetime_new(int _n1_16629, int _n2_16630, int _n3_16631, int _n4_16632, int _n5_16633, int _n6_16634)
{
    int _9491 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:new(n1,n2,n3,n4,n5,n6)*/
    Ref(_n1_16629);
    Ref(_n2_16630);
    Ref(_n3_16631);
    Ref(_n4_16632);
    Ref(_n5_16633);
    Ref(_n6_16634);
    _9491 = _12new(_n1_16629, _n2_16630, _n3_16631, _n4_16632, _n5_16633, _n6_16634);
    DeRef(_n1_16629);
    DeRef(_n2_16630);
    DeRef(_n3_16631);
    DeRef(_n4_16632);
    DeRef(_n5_16633);
    DeRef(_n6_16634);
    return _9491;
    ;
}


int  __stdcall _2datetime_datetime(int _a_16638)
{
    int _9492 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:datetime(a)*/
    Ref(_a_16638);
    _9492 = _12datetime(_a_16638);
    DeRef(_a_16638);
    return _9492;
    ;
}


int  __stdcall _2datetime_parse(int _a_16642, int _b_16643, int _c_16644)
{
    int _9493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:parse(a,b,c)*/
    Ref(_a_16642);
    Ref(_b_16643);
    Ref(_c_16644);
    _9493 = _12parse(_a_16642, _b_16643, _c_16644);
    DeRef(_a_16642);
    DeRef(_b_16643);
    DeRef(_c_16644);
    return _9493;
    ;
}


int  __stdcall _2datetime_add(int _a_16648, int _b_16649, int _c_16650)
{
    int _9494 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:add(a,b,c)*/
    Ref(_a_16648);
    Ref(_b_16649);
    Ref(_c_16650);
    _9494 = _12add(_a_16648, _b_16649, _c_16650);
    DeRef(_a_16648);
    DeRef(_b_16649);
    DeRef(_c_16650);
    return _9494;
    ;
}


int  __stdcall _2stdget_get(int _a_19099, int _b_19100, int _c_19101)
{
    int _get_inlined_get_at_2_19103 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdget:get(a,b,c)*/
    if (!IS_ATOM_INT(_a_19099)) {
        _1 = (long)(DBL_PTR(_a_19099)->dbl);
        DeRefDS(_a_19099);
        _a_19099 = _1;
    }
    if (!IS_ATOM_INT(_b_19100)) {
        _1 = (long)(DBL_PTR(_b_19100)->dbl);
        DeRefDS(_b_19100);
        _b_19100 = _1;
    }
    if (!IS_ATOM_INT(_c_19101)) {
        _1 = (long)(DBL_PTR(_c_19101)->dbl);
        DeRefDS(_c_19101);
        _c_19101 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _0 = _get_inlined_get_at_2_19103;
    _get_inlined_get_at_2_19103 = _17get_value(_a_19099, _b_19100, _c_19101);
    DeRef(_0);
    DeRef(_a_19099);
    DeRef(_b_19100);
    DeRef(_c_19101);
    return _get_inlined_get_at_2_19103;
    ;
}


void  __stdcall _2graphics_wrap(int _a_19204)
{
    int _wrap_2__tmp_at2_19207 = NOVALUE;
    int _wrap_1__tmp_at2_19206 = NOVALUE;
    int _0, _1, _2;
    

    /** 	graphics:wrap(a)*/

    /** 	machine_proc(M_WRAP, not equal(on, 0))*/
    if (_a_19204 == 0)
    _wrap_1__tmp_at2_19206 = 1;
    else if (IS_ATOM_INT(_a_19204) && IS_ATOM_INT(0))
    _wrap_1__tmp_at2_19206 = 0;
    else
    _wrap_1__tmp_at2_19206 = (compare(_a_19204, 0) == 0);
    _wrap_2__tmp_at2_19207 = (_wrap_1__tmp_at2_19206 == 0);
    machine(7, _wrap_2__tmp_at2_19207);

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** end procedure*/
    DeRef(_a_19204);
    return;
    ;
}


int  __stdcall _2locale_get()
{
    int _11819 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:get()*/
    _11819 = _43get();
    return _11819;
    ;
}


int  __stdcall _2locale_datetime(int _a_20870, int _b_20871)
{
    int _11820 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:datetime(a,b)*/
    Ref(_a_20870);
    Ref(_b_20871);
    _11820 = _43datetime(_a_20870, _b_20871);
    DeRef(_a_20870);
    DeRef(_b_20871);
    return _11820;
    ;
}


int  __stdcall _2locale_set(int _a_20875)
{
    int _11821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:set(a)*/
    Ref(_a_20875);
    _11821 = _43set(_a_20875);
    DeRef(_a_20875);
    return _11821;
    ;
}


int  __stdcall _2map_new(int _a_20879)
{
    int _11822 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:new(a)*/
    Ref(_a_20879);
    _11822 = _33new(_a_20879);
    DeRef(_a_20879);
    return _11822;
    ;
}


int  __stdcall _2map_get(int _a_20883, int _b_20884, int _c_20885)
{
    int _11823 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:get(a,b,c)*/
    Ref(_a_20883);
    Ref(_b_20884);
    Ref(_c_20885);
    _11823 = _33get(_a_20883, _b_20884, _c_20885);
    DeRef(_a_20883);
    DeRef(_b_20884);
    DeRef(_c_20885);
    return _11823;
    ;
}


int  __stdcall _2map_size(int _a_20889)
{
    int _size_1__tmp_at2_20892 = NOVALUE;
    int _size_inlined_size_at_2_20891 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:size(a)*/

    /** 	return eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    DeRef(_size_1__tmp_at2_20892);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_a_20889)){
        _size_1__tmp_at2_20892 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_20889)->dbl));
    }
    else{
        _size_1__tmp_at2_20892 = (int)*(((s1_ptr)_2)->base + _a_20889);
    }
    Ref(_size_1__tmp_at2_20892);
    DeRef(_size_inlined_size_at_2_20891);
    _2 = (int)SEQ_PTR(_size_1__tmp_at2_20892);
    _size_inlined_size_at_2_20891 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_size_inlined_size_at_2_20891);
    DeRef(_size_1__tmp_at2_20892);
    _size_1__tmp_at2_20892 = NOVALUE;
    DeRef(_a_20889);
    return _size_inlined_size_at_2_20891;
    ;
}


void  __stdcall _2map_clear(int _a_20895)
{
    int _0, _1, _2;
    

    /** 	map:clear(a)*/
    Ref(_a_20895);
    _33clear(_a_20895);

    /** end procedure*/
    DeRef(_a_20895);
    return;
    ;
}


void  __stdcall _2map_remove(int _a_20898, int _b_20899)
{
    int _0, _1, _2;
    

    /** 	map:remove(a,b)*/
    Ref(_a_20898);
    Ref(_b_20899);
    _33remove(_a_20898, _b_20899);

    /** end procedure*/
    DeRef(_a_20898);
    DeRef(_b_20899);
    return;
    ;
}


int  __stdcall _2map_calc_hash(int _a_20902, int _b_20903)
{
    int _calc_hash_1__tmp_at2_20907 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_2_20906 = NOVALUE;
    int _ret__inlined_calc_hash_at_2_20905 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:calc_hash(a,b)*/
    if (!IS_ATOM_INT(_b_20903)) {
        _1 = (long)(DBL_PTR(_b_20903)->dbl);
        DeRefDS(_b_20903);
        _b_20903 = _1;
    }

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_2_20905);
    _ret__inlined_calc_hash_at_2_20905 = calc_hash(_a_20902, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_2_20905)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_2_20905)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_2_20905);
        _ret__inlined_calc_hash_at_2_20905 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at2_20907 = (_ret__inlined_calc_hash_at_2_20905 % _b_20903);
    DeRef(_calc_hash_inlined_calc_hash_at_2_20906);
    _calc_hash_inlined_calc_hash_at_2_20906 = _calc_hash_1__tmp_at2_20907 + 1;
    if (_calc_hash_inlined_calc_hash_at_2_20906 > MAXINT){
        _calc_hash_inlined_calc_hash_at_2_20906 = NewDouble((double)_calc_hash_inlined_calc_hash_at_2_20906);
    }
    DeRef(_ret__inlined_calc_hash_at_2_20905);
    _ret__inlined_calc_hash_at_2_20905 = NOVALUE;
    DeRef(_a_20902);
    DeRef(_b_20903);
    return _calc_hash_inlined_calc_hash_at_2_20906;
    ;
}


int  __stdcall _2map_compare(int _a_20910, int _b_20911, int _c_20912)
{
    int _11824 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:compare(a,b,c)*/
    Ref(_a_20910);
    Ref(_b_20911);
    Ref(_c_20912);
    _11824 = _33compare(_a_20910, _b_20911, _c_20912);
    DeRef(_a_20910);
    DeRef(_b_20911);
    DeRef(_c_20912);
    return _11824;
    ;
}


int  __stdcall _2math_sum(int _a_20916)
{
    int _11825 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return math:sum(a)*/
    Ref(_a_20916);
    _11825 = _20sum(_a_20916);
    DeRef(_a_20916);
    return _11825;
    ;
}


int  __stdcall _2pipeio_create()
{
    int _11972 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return pipeio:create()*/
    _11972 = _46create();
    return _11972;
    ;
}


int  __stdcall _2pipeio_close(int _a_21222)
{
    int _11973 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return pipeio:close(a)*/
    Ref(_a_21222);
    _11973 = _46close(_a_21222);
    DeRef(_a_21222);
    return _11973;
    ;
}


int  __stdcall _2regex_new(int _a_21793, int _b_21794)
{
    int _new_2__tmp_at5_25254 = NOVALUE;
    int _new_1__tmp_at5_25253 = NOVALUE;
    int _new_inlined_new_at_5_25252 = NOVALUE;
    int _options_inlined_new_at_2_25251 = NOVALUE;
    int _12287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:new(a,b)*/
    Ref(_b_21794);
    DeRef(_options_inlined_new_at_2_25251);
    _options_inlined_new_at_2_25251 = _b_21794;

    /** 	if sequence(options) then */
    _new_1__tmp_at5_25253 = IS_SEQUENCE(_options_inlined_new_at_2_25251);
    if (_new_1__tmp_at5_25253 == 0)
    {
        goto L1; // [11] 21
    }
    else{
    }

    /** 		options = math:or_all(options) */
    Ref(_options_inlined_new_at_2_25251);
    _0 = _options_inlined_new_at_2_25251;
    _options_inlined_new_at_2_25251 = _20or_all(_options_inlined_new_at_2_25251);
    DeRef(_0);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_inlined_new_at_2_25251);
    Ref(_a_21793);
    DeRef(_new_2__tmp_at5_25254);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _a_21793;
    ((int *)_2)[2] = _options_inlined_new_at_2_25251;
    _new_2__tmp_at5_25254 = MAKE_SEQ(_1);
    DeRef(_new_inlined_new_at_5_25252);
    _new_inlined_new_at_5_25252 = machine(68, _new_2__tmp_at5_25254);
    DeRef(_options_inlined_new_at_2_25251);
    _options_inlined_new_at_2_25251 = NOVALUE;
    DeRef(_new_2__tmp_at5_25254);
    _new_2__tmp_at5_25254 = NOVALUE;
    Ref(_new_inlined_new_at_5_25252);
    DeRef(_12287);
    _12287 = _new_inlined_new_at_5_25252;
    DeRef(_a_21793);
    DeRef(_b_21794);
    return _12287;
    ;
}


int  __stdcall _2regex_escape(int _a_21798)
{
    int _escape_inlined_escape_at_2_25268 = NOVALUE;
    int _12288 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:escape(a)*/

    /** 	return text:escape(s, ".\\+*?[^]$(){}=!<>|:-")*/
    Ref(_a_21798);
    RefDS(_12125);
    _0 = _escape_inlined_escape_at_2_25268;
    _escape_inlined_escape_at_2_25268 = _6escape(_a_21798, _12125);
    DeRef(_0);
    Ref(_escape_inlined_escape_at_2_25268);
    DeRef(_12288);
    _12288 = _escape_inlined_escape_at_2_25268;
    DeRef(_a_21798);
    return _12288;
    ;
}


int  __stdcall _2regex_find_all(int _n1_21802, int _n2_21803, int _n3_21804, int _n4_21805, int _n5_21806)
{
    int _12289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find_all(n1,n2,n3,n4,n5)*/
    Ref(_n1_21802);
    Ref(_n2_21803);
    Ref(_n3_21804);
    Ref(_n4_21805);
    Ref(_n5_21806);
    _12289 = _47find_all(_n1_21802, _n2_21803, _n3_21804, _n4_21805, _n5_21806);
    DeRef(_n1_21802);
    DeRef(_n2_21803);
    DeRef(_n3_21804);
    DeRef(_n4_21805);
    DeRef(_n5_21806);
    return _12289;
    ;
}


int  __stdcall _2regex_is_match(int _a_21810, int _b_21811, int _c_21812, int _d_21813)
{
    int _12290 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:is_match(a,b,c,d)*/
    Ref(_a_21810);
    Ref(_b_21811);
    Ref(_c_21812);
    Ref(_d_21813);
    _12290 = _47is_match(_a_21810, _b_21811, _c_21812, _d_21813);
    DeRef(_a_21810);
    DeRef(_b_21811);
    DeRef(_c_21812);
    DeRef(_d_21813);
    return _12290;
    ;
}


int  __stdcall _2regex_split(int _a_21817, int _b_21818, int _c_21819, int _d_21820)
{
    int _split_inlined_split_at_2_25270 = NOVALUE;
    int _12291 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:split(a,b,c,d)*/
    if (!IS_ATOM_INT(_c_21819)) {
        _1 = (long)(DBL_PTR(_c_21819)->dbl);
        DeRefDS(_c_21819);
        _c_21819 = _1;
    }

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_a_21817);
    Ref(_b_21818);
    Ref(_d_21820);
    _0 = _split_inlined_split_at_2_25270;
    _split_inlined_split_at_2_25270 = _47split_limit(_a_21817, _b_21818, 0, _c_21819, _d_21820);
    DeRef(_0);
    Ref(_split_inlined_split_at_2_25270);
    DeRef(_12291);
    _12291 = _split_inlined_split_at_2_25270;
    DeRef(_a_21817);
    DeRef(_b_21818);
    DeRef(_c_21819);
    DeRef(_d_21820);
    return _12291;
    ;
}


int  __stdcall _2regex_find_replace(int _n1_21824, int _n2_21825, int _n3_21826, int _n4_21827, int _n5_21828)
{
    int _find_replace_inlined_find_replace_at_2_25272 = NOVALUE;
    int _12292 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find_replace(n1,n2,n3,n4,n5)*/
    if (!IS_ATOM_INT(_n4_21827)) {
        _1 = (long)(DBL_PTR(_n4_21827)->dbl);
        DeRefDS(_n4_21827);
        _n4_21827 = _1;
    }

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_n1_21824);
    Ref(_n2_21825);
    Ref(_n3_21826);
    Ref(_n5_21828);
    _0 = _find_replace_inlined_find_replace_at_2_25272;
    _find_replace_inlined_find_replace_at_2_25272 = _47find_replace_limit(_n1_21824, _n2_21825, _n3_21826, -1, _n4_21827, _n5_21828);
    DeRef(_0);
    Ref(_find_replace_inlined_find_replace_at_2_25272);
    DeRef(_12292);
    _12292 = _find_replace_inlined_find_replace_at_2_25272;
    DeRef(_n1_21824);
    DeRef(_n2_21825);
    DeRef(_n3_21826);
    DeRef(_n4_21827);
    DeRef(_n5_21828);
    return _12292;
    ;
}


int  __stdcall _2regex_get_ovector_size(int _a_21832, int _b_21833)
{
    int _12293 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:get_ovector_size(a,b)*/
    Ref(_a_21832);
    Ref(_b_21833);
    _12293 = _47get_ovector_size(_a_21832, _b_21833);
    DeRef(_a_21832);
    DeRef(_b_21833);
    return _12293;
    ;
}


int  __stdcall _2regex_find(int _n1_21837, int _n2_21838, int _n3_21839, int _n4_21840, int _n5_21841)
{
    int _12294 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find(n1,n2,n3,n4,n5)*/
    Ref(_n1_21837);
    Ref(_n2_21838);
    Ref(_n3_21839);
    Ref(_n4_21840);
    Ref(_n5_21841);
    _12294 = _47find(_n1_21837, _n2_21838, _n3_21839, _n4_21840, _n5_21841);
    DeRef(_n1_21837);
    DeRef(_n2_21838);
    DeRef(_n3_21839);
    DeRef(_n4_21840);
    DeRef(_n5_21841);
    return _12294;
    ;
}


int  __stdcall _2search_find_all(int _a_21845, int _b_21846, int _c_21847)
{
    int _12295 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return search:find_all(a,b,c)*/
    Ref(_a_21845);
    Ref(_b_21846);
    Ref(_c_21847);
    _12295 = _9find_all(_a_21845, _b_21846, _c_21847);
    DeRef(_a_21845);
    DeRef(_b_21846);
    DeRef(_c_21847);
    return _12295;
    ;
}


int  __stdcall _2search_find_replace(int _a_21851, int _b_21852, int _c_21853, int _d_21854)
{
    int _12296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return search:find_replace(a,b,c,d)*/
    Ref(_a_21851);
    Ref(_b_21852);
    Ref(_c_21853);
    Ref(_d_21854);
    _12296 = _9find_replace(_a_21851, _b_21852, _c_21853, _d_21854);
    DeRef(_a_21851);
    DeRef(_b_21852);
    DeRef(_c_21853);
    DeRef(_d_21854);
    return _12296;
    ;
}


int  __stdcall _2stdseq_split(int _a_21858, int _b_21859, int _c_21860, int _d_21861)
{
    int _12297 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:split(a,b,c,d)*/
    Ref(_a_21858);
    Ref(_b_21859);
    Ref(_c_21860);
    Ref(_d_21861);
    _12297 = _23split(_a_21858, _b_21859, _c_21860, _d_21861);
    DeRef(_a_21858);
    DeRef(_b_21859);
    DeRef(_c_21860);
    DeRef(_d_21861);
    return _12297;
    ;
}


int  __stdcall _2sockets_create(int _a_22534, int _b_22535, int _c_22536)
{
    int _12584 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sockets:create(a,b,c)*/
    Ref(_a_22534);
    Ref(_b_22535);
    Ref(_c_22536);
    _12584 = _48create(_a_22534, _b_22535, _c_22536);
    DeRef(_a_22534);
    DeRef(_b_22535);
    DeRef(_c_22536);
    return _12584;
    ;
}


int  __stdcall _2sockets_close(int _a_22540)
{
    int _close_1__tmp_at2_22543 = NOVALUE;
    int _close_inlined_close_at_2_22542 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sockets:close(a)*/

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _0 = _close_1__tmp_at2_22543;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_a_22540);
    *((int *)(_2+4)) = _a_22540;
    _close_1__tmp_at2_22543 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_close_inlined_close_at_2_22542);
    _close_inlined_close_at_2_22542 = machine(82, _close_1__tmp_at2_22543);
    DeRef(_close_1__tmp_at2_22543);
    _close_1__tmp_at2_22543 = NOVALUE;
    DeRef(_a_22540);
    return _close_inlined_close_at_2_22542;
    ;
}


int  __stdcall _2stack_new(int _a_22848)
{
    int _new_1__tmp_at2_22852 = NOVALUE;
    int _new_inlined_new_at_2_22851 = NOVALUE;
    int _new_stack_inlined_new_at_2_22850 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stack:new(a)*/
    if (!IS_ATOM_INT(_a_22848)) {
        _1 = (long)(DBL_PTR(_a_22848)->dbl);
        DeRefDS(_a_22848);
        _a_22848 = _1;
    }

    /** 	atom new_stack = eumem:malloc()*/
    _0 = _new_stack_inlined_new_at_2_22850;
    _new_stack_inlined_new_at_2_22850 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[new_stack] = { type_is_stack, typ, {} }*/
    _0 = _new_1__tmp_at2_22852;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50type_is_stack_22551);
    *((int *)(_2+4)) = _50type_is_stack_22551;
    *((int *)(_2+8)) = _a_22848;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _new_1__tmp_at2_22852 = MAKE_SEQ(_1);
    DeRef(_0);
    RefDS(_new_1__tmp_at2_22852);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_new_stack_inlined_new_at_2_22850))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_new_stack_inlined_new_at_2_22850)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _new_stack_inlined_new_at_2_22850);
    _1 = *(int *)_2;
    *(int *)_2 = _new_1__tmp_at2_22852;
    DeRef(_1);

    /** 	return new_stack*/
    Ref(_new_stack_inlined_new_at_2_22850);
    DeRef(_new_inlined_new_at_2_22851);
    _new_inlined_new_at_2_22851 = _new_stack_inlined_new_at_2_22850;
    DeRef(_new_stack_inlined_new_at_2_22850);
    _new_stack_inlined_new_at_2_22850 = NOVALUE;
    DeRef(_new_1__tmp_at2_22852);
    _new_1__tmp_at2_22852 = NOVALUE;
    DeRef(_a_22848);
    return _new_inlined_new_at_2_22851;
    ;
}


int  __stdcall _2stack_size(int _a_22855)
{
    int _size_2__tmp_at2_22859 = NOVALUE;
    int _size_1__tmp_at2_22858 = NOVALUE;
    int _size_inlined_size_at_2_22857 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stack:size(a)*/

    /** 	return length(eumem:ram_space[sk][data])*/
    DeRef(_size_1__tmp_at2_22858);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_a_22855)){
        _size_1__tmp_at2_22858 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_22855)->dbl));
    }
    else{
        _size_1__tmp_at2_22858 = (int)*(((s1_ptr)_2)->base + _a_22855);
    }
    Ref(_size_1__tmp_at2_22858);
    DeRef(_size_2__tmp_at2_22859);
    _2 = (int)SEQ_PTR(_size_1__tmp_at2_22858);
    _size_2__tmp_at2_22859 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_size_2__tmp_at2_22859);
    if (IS_SEQUENCE(_size_2__tmp_at2_22859)){
            _size_inlined_size_at_2_22857 = SEQ_PTR(_size_2__tmp_at2_22859)->length;
    }
    else {
        _size_inlined_size_at_2_22857 = 1;
    }
    DeRef(_size_1__tmp_at2_22858);
    _size_1__tmp_at2_22858 = NOVALUE;
    DeRef(_size_2__tmp_at2_22859);
    _size_2__tmp_at2_22859 = NOVALUE;
    DeRef(_a_22855);
    return _size_inlined_size_at_2_22857;
    ;
}


void  __stdcall _2stack_set(int _a_22862, int _b_22863, int _c_22864)
{
    int _0, _1, _2;
    

    /** 	stack:set(a,b,c)*/
    Ref(_a_22862);
    Ref(_b_22863);
    Ref(_c_22864);
    _50set(_a_22862, _b_22863, _c_22864);

    /** end procedure*/
    DeRef(_a_22862);
    DeRef(_b_22863);
    DeRef(_c_22864);
    return;
    ;
}


void  __stdcall _2stack_clear(int _a_22867)
{
    int _clear_2__tmp_at2_22870 = NOVALUE;
    int _clear_1__tmp_at2_22869 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	stack:clear(a)*/

    /** 	eumem:ram_space[sk][data] = {}*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_a_22867))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_22867)->dbl));
    else
    _3 = (int)(_a_22867 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** end procedure*/
    goto L1; // [18] 21
L1: 

    /** end procedure*/
    DeRef(_a_22867);
    return;
    ;
}


int  __stdcall _2stats_sum(int _a_22873, int _b_22874)
{
    int _12754 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stats:sum(a, b)*/
    Ref(_a_22873);
    Ref(_b_22874);
    _12754 = _35sum(_a_22873, _b_22874);
    DeRef(_a_22873);
    DeRef(_b_22874);
    return _12754;
    ;
}


int  __stdcall _2text_format(int _a_22891, int _b_22892)
{
    int _12760 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:format(a, b)*/
    Ref(_a_22891);
    Ref(_b_22892);
    _12760 = _6format(_a_22891, _b_22892);
    DeRef(_a_22891);
    DeRef(_b_22892);
    return _12760;
    ;
}


int  __stdcall _2text_wrap(int _a_22896, int _b_22897, int _c_22898, int _d_22899)
{
    int _12761 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:wrap(a,b,c,d)*/
    Ref(_a_22896);
    Ref(_b_22897);
    Ref(_c_22898);
    Ref(_d_22899);
    _12761 = _6wrap(_a_22896, _b_22897, _c_22898, _d_22899);
    DeRef(_a_22896);
    DeRef(_b_22897);
    DeRef(_c_22898);
    DeRef(_d_22899);
    return _12761;
    ;
}


int  __stdcall _2text_escape(int _a_22903, int _b_22904)
{
    int _12762 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:escape(a,b)*/
    Ref(_a_22903);
    Ref(_b_22904);
    _12762 = _6escape(_a_22903, _b_22904);
    DeRef(_a_22903);
    DeRef(_b_22904);
    return _12762;
    ;
}


int  __stdcall _2wildcard_is_match(int _a_22923, int _b_22924)
{
    int _12763 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return wildcard:is_match(a,b)*/
    Ref(_a_22923);
    Ref(_b_22924);
    _12763 = _25is_match(_a_22923, _b_22924);
    DeRef(_a_22923);
    DeRef(_b_22924);
    return _12763;
    ;
}


int  __stdcall _2url_parse(int _a_23642, int _b_23643)
{
    int _13150 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:parse(a,b)*/
    Ref(_a_23642);
    Ref(_b_23643);
    _13150 = _55parse(_a_23642, _b_23643);
    DeRef(_a_23642);
    DeRef(_b_23643);
    return _13150;
    ;
}


int  __stdcall _2url_encode(int _a_23647, int _b_23648)
{
    int _13151 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:encode(a,b)*/
    Ref(_a_23647);
    Ref(_b_23648);
    _13151 = _55encode(_a_23647, _b_23648);
    DeRef(_a_23647);
    DeRef(_b_23648);
    return _13151;
    ;
}


int  __stdcall _2url_decode(int _a_23652)
{
    int _13152 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:decode(a)*/
    Ref(_a_23652);
    _13152 = _55decode(_a_23652);
    DeRef(_a_23652);
    return _13152;
    ;
}


int  __stdcall _2lib_call_func(int _a_23764, int _b_23765)
{
    int _13185 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eu:call_func(a,b)*/
    _1 = (int)SEQ_PTR(_b_23765);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_a_23764].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_a_23764].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }
    _13185 = _1;
    DeRef(_a_23764);
    DeRef(_b_23765);
    return _13185;
    ;
}


void  __stdcall _2lib_call_proc(int _a_23769, int _b_23770)
{
    int _0, _1, _2;
    

    /** 	eu:call_proc(a,b)*/
    _1 = (int)SEQ_PTR(_b_23770);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_a_23769].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            if (_00[_a_23769].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
            }
            break;
    }

    /** end procedure*/
    DeRef(_a_23769);
    DeRef(_b_23770);
    return;
    ;
}


int  __stdcall _2lib_routine_id(int _a_23773)
{
    int _13186 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eu:routine_id(a)*/
    _13186 = CRoutineId(816, 2, _a_23773);
    DeRefDS(_a_23773);
    return _13186;
    ;
}



// 0x45C55F39
