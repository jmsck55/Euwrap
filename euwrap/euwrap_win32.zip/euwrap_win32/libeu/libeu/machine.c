// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _14allocate(int _n_1972, int _cleanup_1973)
{
    int _iaddr_1974 = NOVALUE;
    int _eaddr_1975 = NOVALUE;
    int _983 = NOVALUE;
    int _982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _982 = 0;
    if (IS_ATOM_INT(_n_1972)) {
        _983 = _n_1972 + 0;
        if ((long)((unsigned long)_983 + (unsigned long)HIGH_BITS) >= 0) 
        _983 = NewDouble((double)_983);
    }
    else {
        _983 = binary_op(PLUS, _n_1972, 0);
    }
    _982 = NOVALUE;
    DeRef(_iaddr_1974);
    _iaddr_1974 = machine(16, _983);
    DeRef(_983);
    _983 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_1974);
    Ref(_n_1972);
    _0 = _eaddr_1975;
    _eaddr_1975 = _16prepare_block(_iaddr_1974, _n_1972, 4);
    DeRef(_0);

    /** 	if cleanup then*/
    if (_cleanup_1973 == 0) {
        goto L1; // [29] 43
    }
    else {
        if (!IS_ATOM_INT(_cleanup_1973) && DBL_PTR(_cleanup_1973)->dbl == 0.0){
            goto L1; // [29] 43
        }
    }

    /** 		eaddr = delete_routine( eaddr, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1863].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1863].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1863;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_eaddr_1975) ){
        if( IS_ATOM_INT(_eaddr_1975) ){
            _eaddr_1975 = NewDouble( (double) _eaddr_1975 );
        }
        if(DBL_PTR(_eaddr_1975)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_eaddr_1975)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_eaddr_1975)) ){
            DeRefDS(_eaddr_1975);
            _eaddr_1975 = NewDouble( DBL_PTR(_eaddr_1975)->dbl );
        }
        DBL_PTR(_eaddr_1975)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_eaddr_1975)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_eaddr_1975)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_eaddr_1975)) ){
            _eaddr_1975 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_eaddr_1975) ));
        }
        SEQ_PTR(_eaddr_1975)->cleanup = (cleanup_ptr)_1;
    }
L1: 

    /** 	return eaddr*/
    DeRef(_n_1972);
    DeRef(_cleanup_1973);
    DeRef(_iaddr_1974);
    return _eaddr_1975;
    ;
}


int  __stdcall _14allocate_data(int _n_1985, int _cleanup_1986)
{
    int _a_1987 = NOVALUE;
    int _sla_1989 = NOVALUE;
    int _991 = NOVALUE;
    int _988 = NOVALUE;
    int _987 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = eu:machine_func( memconst:M_ALLOC, n+BORDER_SPACE*2)*/
    _987 = 0;
    if (IS_ATOM_INT(_n_1985)) {
        _988 = _n_1985 + 0;
        if ((long)((unsigned long)_988 + (unsigned long)HIGH_BITS) >= 0) 
        _988 = NewDouble((double)_988);
    }
    else {
        _988 = binary_op(PLUS, _n_1985, 0);
    }
    _987 = NOVALUE;
    DeRef(_a_1987);
    _a_1987 = machine(16, _988);
    DeRef(_988);
    _988 = NOVALUE;

    /** 	sla = memory:prepare_block(a, n, PAGE_READ_WRITE )*/
    Ref(_a_1987);
    Ref(_n_1985);
    _0 = _sla_1989;
    _sla_1989 = _16prepare_block(_a_1987, _n_1985, 4);
    DeRef(_0);

    /** 	if cleanup then*/
    if (_cleanup_1986 == 0) {
        goto L1; // [29] 47
    }
    else {
        if (!IS_ATOM_INT(_cleanup_1986) && DBL_PTR(_cleanup_1986)->dbl == 0.0){
            goto L1; // [29] 47
        }
    }

    /** 		return delete_routine( sla, memconst:FREE_RID )*/
    if( IS_ATOM_INT(_sla_1989) ){
        _991 = NewDouble( (double) _sla_1989 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_sla_1989)) ){
            if( IS_ATOM_DBL( _sla_1989 ) ){
                _991 = NewDouble( DBL_PTR(_sla_1989)->dbl );
            }
            else {
                RefDS(_sla_1989);
                _991 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_sla_1989) ));
            }
        }
        else {
            _991 = _sla_1989;
        }
    }
    _1 = (int) _00[_15FREE_RID_1863].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1863].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1863;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_991) ){
        if( IS_ATOM_INT(_991) ){
            _991 = NewDouble( (double) _sla_1989 );
        }
        if(DBL_PTR(_991)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_991)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_991)) ){
            DeRefDS(_991);
            _991 = NewDouble( DBL_PTR(_991)->dbl );
        }
        DBL_PTR(_991)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_991)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_991)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_991)) ){
            _991 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_991) ));
        }
        SEQ_PTR(_991)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_sla_1989) ){
        RefDS(_991);
    }
    DeRef(_n_1985);
    DeRef(_cleanup_1986);
    DeRef(_a_1987);
    DeRef(_sla_1989);
    return _991;
    goto L2; // [44] 54
L1: 

    /** 		return sla*/
    DeRef(_n_1985);
    DeRef(_cleanup_1986);
    DeRef(_a_1987);
    DeRef(_991);
    _991 = NOVALUE;
    return _sla_1989;
L2: 
    ;
}


int  __stdcall _14allocate_pointer_array(int _pointers_2001, int _cleanup_2002)
{
    int _pList_2003 = NOVALUE;
    int _len_2004 = NOVALUE;
    int _997 = NOVALUE;
    int _996 = NOVALUE;
    int _994 = NOVALUE;
    int _992 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(pointers) * ADDRESS_LENGTH*/
    if (IS_SEQUENCE(_pointers_2001)){
            _992 = SEQ_PTR(_pointers_2001)->length;
    }
    else {
        _992 = 1;
    }
    _len_2004 = _992 * 4;
    _992 = NOVALUE;

    /**     pList = allocate( (len + ADDRESS_LENGTH ) )*/
    _994 = _len_2004 + 4;
    if ((long)((unsigned long)_994 + (unsigned long)HIGH_BITS) >= 0) 
    _994 = NewDouble((double)_994);
    _0 = _pList_2003;
    _pList_2003 = _14allocate(_994, 0);
    DeRef(_0);
    _994 = NOVALUE;

    /**     poke4(pList, pointers)*/
    if (IS_ATOM_INT(_pList_2003)){
        poke4_addr = (unsigned long *)_pList_2003;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_pList_2003)->dbl);
    }
    _1 = (int)SEQ_PTR(_pointers_2001);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    /**     poke4(pList + len, 0)*/
    if (IS_ATOM_INT(_pList_2003)) {
        _996 = _pList_2003 + _len_2004;
        if ((long)((unsigned long)_996 + (unsigned long)HIGH_BITS) >= 0) 
        _996 = NewDouble((double)_996);
    }
    else {
        _996 = NewDouble(DBL_PTR(_pList_2003)->dbl + (double)_len_2004);
    }
    if (IS_ATOM_INT(_996)){
        poke4_addr = (unsigned long *)_996;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_996)->dbl);
    }
    *poke4_addr = (unsigned long)0;
    DeRef(_996);
    _996 = NOVALUE;

    /** 	if cleanup then*/
    if (_cleanup_2002 == 0) {
        goto L1; // [41] 57
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2002) && DBL_PTR(_cleanup_2002)->dbl == 0.0){
            goto L1; // [41] 57
        }
    }

    /** 		return delete_routine( pList, FREE_ARRAY_RID )*/
    if( IS_ATOM_INT(_pList_2003) ){
        _997 = NewDouble( (double) _pList_2003 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_pList_2003)) ){
            if( IS_ATOM_DBL( _pList_2003 ) ){
                _997 = NewDouble( DBL_PTR(_pList_2003)->dbl );
            }
            else {
                RefDS(_pList_2003);
                _997 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_pList_2003) ));
            }
        }
        else {
            _997 = _pList_2003;
        }
    }
    _1 = (int) _00[_14FREE_ARRAY_RID_1968].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_14FREE_ARRAY_RID_1968].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _14FREE_ARRAY_RID_1968;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_997) ){
        if( IS_ATOM_INT(_997) ){
            _997 = NewDouble( (double) _pList_2003 );
        }
        if(DBL_PTR(_997)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_997)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_997)) ){
            DeRefDS(_997);
            _997 = NewDouble( DBL_PTR(_997)->dbl );
        }
        DBL_PTR(_997)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_997)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_997)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_997)) ){
            _997 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_997) ));
        }
        SEQ_PTR(_997)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_pList_2003) ){
        RefDS(_997);
    }
    DeRefDS(_pointers_2001);
    DeRef(_cleanup_2002);
    DeRef(_pList_2003);
    return _997;
L1: 

    /**     return pList*/
    DeRefDS(_pointers_2001);
    DeRef(_cleanup_2002);
    DeRef(_997);
    _997 = NOVALUE;
    return _pList_2003;
    ;
}


int  __stdcall _14allocate_string_pointer_array(int _string_list_2014, int _cleanup_2015)
{
    int _1003 = NOVALUE;
    int _1002 = NOVALUE;
    int _1001 = NOVALUE;
    int _1000 = NOVALUE;
    int _999 = NOVALUE;
    int _998 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(string_list) do*/
    if (IS_SEQUENCE(_string_list_2014)){
            _998 = SEQ_PTR(_string_list_2014)->length;
    }
    else {
        _998 = 1;
    }
    {
        int _i_2017;
        _i_2017 = 1;
L1: 
        if (_i_2017 > _998){
            goto L2; // [6] 35
        }

        /** 		string_list[i] = allocate_string(string_list[i])*/
        _2 = (int)SEQ_PTR(_string_list_2014);
        _999 = (int)*(((s1_ptr)_2)->base + _i_2017);
        Ref(_999);
        _1000 = _14allocate_string(_999, 0);
        _999 = NOVALUE;
        _2 = (int)SEQ_PTR(_string_list_2014);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _string_list_2014 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2017);
        _1 = *(int *)_2;
        *(int *)_2 = _1000;
        if( _1 != _1000 ){
            DeRef(_1);
        }
        _1000 = NOVALUE;

        /** 	end for*/
        _i_2017 = _i_2017 + 1;
        goto L1; // [30] 13
L2: 
        ;
    }

    /** 	if cleanup then*/
    if (_cleanup_2015 == 0) {
        goto L3; // [37] 60
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2015) && DBL_PTR(_cleanup_2015)->dbl == 0.0){
            goto L3; // [37] 60
        }
    }

    /** 		return delete_routine( allocate_pointer_array(string_list), FREE_ARRAY_RID )*/
    Ref(_string_list_2014);
    _1001 = _14allocate_pointer_array(_string_list_2014, 0);
    DeRef(_1002);
    if( IS_ATOM_INT(_1001) ){
        _1002 = NewDouble( (double) _1001 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_1001)) ){
            if( IS_ATOM_DBL( _1001 ) ){
                _1002 = NewDouble( DBL_PTR(_1001)->dbl );
            }
            else {
                RefDS(_1001);
                _1002 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_1001) ));
            }
        }
        else {
            _1002 = _1001;
        }
    }
    _1 = (int) _00[_14FREE_ARRAY_RID_1968].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_14FREE_ARRAY_RID_1968].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _14FREE_ARRAY_RID_1968;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_1002) ){
        if( IS_ATOM_INT(_1002) ){
            _1002 = NewDouble( (double) _1001 );
        }
        if(DBL_PTR(_1002)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_1002)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_1002)) ){
            DeRefDS(_1002);
            _1002 = NewDouble( DBL_PTR(_1002)->dbl );
        }
        DBL_PTR(_1002)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_1002)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_1002)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_1002)) ){
            _1002 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_1002) ));
        }
        SEQ_PTR(_1002)->cleanup = (cleanup_ptr)_1;
    }
    _1001 = NOVALUE;
    DeRef(_string_list_2014);
    DeRef(_cleanup_2015);
    return _1002;
    goto L4; // [57] 72
L3: 

    /** 		return allocate_pointer_array(string_list)*/
    Ref(_string_list_2014);
    _1003 = _14allocate_pointer_array(_string_list_2014, 0);
    DeRef(_string_list_2014);
    DeRef(_cleanup_2015);
    DeRef(_1002);
    _1002 = NOVALUE;
    return _1003;
L4: 
    ;
}


int  __stdcall _14allocate_wstring(int _s_2029, int _cleanup_2030)
{
    int _mem_2031 = NOVALUE;
    int _1010 = NOVALUE;
    int _1009 = NOVALUE;
    int _1008 = NOVALUE;
    int _1006 = NOVALUE;
    int _1005 = NOVALUE;
    int _1004 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( 2 * (length(s) + 1) )*/
    if (IS_SEQUENCE(_s_2029)){
            _1004 = SEQ_PTR(_s_2029)->length;
    }
    else {
        _1004 = 1;
    }
    _1005 = _1004 + 1;
    _1004 = NOVALUE;
    _1006 = _1005 + _1005;
    if ((long)((unsigned long)_1006 + (unsigned long)HIGH_BITS) >= 0) 
    _1006 = NewDouble((double)_1006);
    _1005 = NOVALUE;
    _1005 = NOVALUE;
    _0 = _mem_2031;
    _mem_2031 = _14allocate(_1006, 0);
    DeRef(_0);
    _1006 = NOVALUE;

    /** 	if mem then*/
    if (_mem_2031 == 0) {
        goto L1; // [23] 62
    }
    else {
        if (!IS_ATOM_INT(_mem_2031) && DBL_PTR(_mem_2031)->dbl == 0.0){
            goto L1; // [23] 62
        }
    }

    /** 		poke2(mem, s)*/
    if (IS_ATOM_INT(_mem_2031)){
        poke2_addr = (unsigned short *)_mem_2031;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_mem_2031)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2029);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke2_addr++ = (unsigned short)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke2(mem + length(s)*2, 0)*/
    if (IS_SEQUENCE(_s_2029)){
            _1008 = SEQ_PTR(_s_2029)->length;
    }
    else {
        _1008 = 1;
    }
    _1009 = _1008 + _1008;
    if ((long)((unsigned long)_1009 + (unsigned long)HIGH_BITS) >= 0) 
    _1009 = NewDouble((double)_1009);
    _1008 = NOVALUE;
    _1008 = NOVALUE;
    if (IS_ATOM_INT(_mem_2031) && IS_ATOM_INT(_1009)) {
        _1010 = _mem_2031 + _1009;
        if ((long)((unsigned long)_1010 + (unsigned long)HIGH_BITS) >= 0) 
        _1010 = NewDouble((double)_1010);
    }
    else {
        if (IS_ATOM_INT(_mem_2031)) {
            _1010 = NewDouble((double)_mem_2031 + DBL_PTR(_1009)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1009)) {
                _1010 = NewDouble(DBL_PTR(_mem_2031)->dbl + (double)_1009);
            }
            else
            _1010 = NewDouble(DBL_PTR(_mem_2031)->dbl + DBL_PTR(_1009)->dbl);
        }
    }
    DeRef(_1009);
    _1009 = NOVALUE;
    if (IS_ATOM_INT(_1010)){
        poke2_addr = (unsigned short *)_1010;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_1010)->dbl);
    }
    *poke2_addr = (unsigned short)0;
    DeRef(_1010);
    _1010 = NOVALUE;

    /** 		if cleanup then*/
    if (_cleanup_2030 == 0) {
        goto L2; // [49] 61
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2030) && DBL_PTR(_cleanup_2030)->dbl == 0.0){
            goto L2; // [49] 61
        }
    }

    /** 			mem = delete_routine( mem, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1863].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1863].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1863;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_mem_2031) ){
        if( IS_ATOM_INT(_mem_2031) ){
            _mem_2031 = NewDouble( (double) _mem_2031 );
        }
        if(DBL_PTR(_mem_2031)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_mem_2031)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_mem_2031)) ){
            DeRefDS(_mem_2031);
            _mem_2031 = NewDouble( DBL_PTR(_mem_2031)->dbl );
        }
        DBL_PTR(_mem_2031)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_mem_2031)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_mem_2031)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_mem_2031)) ){
            _mem_2031 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_mem_2031) ));
        }
        SEQ_PTR(_mem_2031)->cleanup = (cleanup_ptr)_1;
    }
L2: 
L1: 

    /** 	return mem*/
    DeRefDS(_s_2029);
    DeRef(_cleanup_2030);
    return _mem_2031;
    ;
}


int  __stdcall _14peek_wstring(int _addr_2044)
{
    int _ptr_2045 = NOVALUE;
    int _1017 = NOVALUE;
    int _1016 = NOVALUE;
    int _1015 = NOVALUE;
    int _1014 = NOVALUE;
    int _1012 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom ptr = addr*/
    Ref(_addr_2044);
    DeRef(_ptr_2045);
    _ptr_2045 = _addr_2044;

    /** 	while peek2u(ptr) do*/
L1: 
    if (IS_ATOM_INT(_ptr_2045)) {
        _1012 = *(unsigned short *)_ptr_2045;
    }
    else {
        _1012 = *(unsigned short *)(unsigned long)(DBL_PTR(_ptr_2045)->dbl);
    }
    if (_1012 == 0)
    {
        _1012 = NOVALUE;
        goto L2; // [14] 28
    }
    else{
        DeRef(_1012);
        _1012 = NOVALUE;
    }

    /** 		ptr += 2*/
    _0 = _ptr_2045;
    if (IS_ATOM_INT(_ptr_2045)) {
        _ptr_2045 = _ptr_2045 + 2;
        if ((long)((unsigned long)_ptr_2045 + (unsigned long)HIGH_BITS) >= 0) 
        _ptr_2045 = NewDouble((double)_ptr_2045);
    }
    else {
        _ptr_2045 = NewDouble(DBL_PTR(_ptr_2045)->dbl + (double)2);
    }
    DeRef(_0);

    /** 	end while*/
    goto L1; // [25] 11
L2: 

    /** 	return peek2u({addr, (ptr - addr) / 2})*/
    if (IS_ATOM_INT(_ptr_2045) && IS_ATOM_INT(_addr_2044)) {
        _1014 = _ptr_2045 - _addr_2044;
        if ((long)((unsigned long)_1014 +(unsigned long) HIGH_BITS) >= 0){
            _1014 = NewDouble((double)_1014);
        }
    }
    else {
        if (IS_ATOM_INT(_ptr_2045)) {
            _1014 = NewDouble((double)_ptr_2045 - DBL_PTR(_addr_2044)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_2044)) {
                _1014 = NewDouble(DBL_PTR(_ptr_2045)->dbl - (double)_addr_2044);
            }
            else
            _1014 = NewDouble(DBL_PTR(_ptr_2045)->dbl - DBL_PTR(_addr_2044)->dbl);
        }
    }
    if (IS_ATOM_INT(_1014)) {
        if (_1014 & 1) {
            _1015 = NewDouble((_1014 >> 1) + 0.5);
        }
        else
        _1015 = _1014 >> 1;
    }
    else {
        _1015 = binary_op(DIVIDE, _1014, 2);
    }
    DeRef(_1014);
    _1014 = NOVALUE;
    Ref(_addr_2044);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _addr_2044;
    ((int *)_2)[2] = _1015;
    _1016 = MAKE_SEQ(_1);
    _1015 = NOVALUE;
    _1 = (int)SEQ_PTR(_1016);
    poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1017 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned short)*poke2_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1016);
    _1016 = NOVALUE;
    DeRef(_addr_2044);
    DeRef(_ptr_2045);
    return _1017;
    ;
}


int  __stdcall _14poke_string(int _buffaddr_2055, int _buffsize_2056, int _s_2057)
{
    int _1023 = NOVALUE;
    int _1021 = NOVALUE;
    int _1019 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_buffsize_2056)) {
        _1 = (long)(DBL_PTR(_buffsize_2056)->dbl);
        DeRefDS(_buffsize_2056);
        _buffsize_2056 = _1;
    }

    /** 	if buffaddr <= 0 then*/
    if (binary_op_a(GREATER, _buffaddr_2055, 0)){
        goto L1; // [7] 18
    }

    /** 		return 0*/
    DeRef(_buffaddr_2055);
    DeRefDS(_s_2057);
    return 0;
L1: 

    /** 	if not types:string(s) then*/
    RefDS(_s_2057);
    _1019 = _7string(_s_2057);
    if (IS_ATOM_INT(_1019)) {
        if (_1019 != 0){
            DeRef(_1019);
            _1019 = NOVALUE;
            goto L2; // [24] 34
        }
    }
    else {
        if (DBL_PTR(_1019)->dbl != 0.0){
            DeRef(_1019);
            _1019 = NOVALUE;
            goto L2; // [24] 34
        }
    }
    DeRef(_1019);
    _1019 = NOVALUE;

    /** 		return 0*/
    DeRef(_buffaddr_2055);
    DeRefDS(_s_2057);
    return 0;
L2: 

    /** 	if buffsize <= length(s) then*/
    if (IS_SEQUENCE(_s_2057)){
            _1021 = SEQ_PTR(_s_2057)->length;
    }
    else {
        _1021 = 1;
    }
    if (_buffsize_2056 > _1021)
    goto L3; // [39] 50

    /** 		return 0*/
    DeRef(_buffaddr_2055);
    DeRefDS(_s_2057);
    return 0;
L3: 

    /** 	poke(buffaddr, s)*/
    if (IS_ATOM_INT(_buffaddr_2055)){
        poke_addr = (unsigned char *)_buffaddr_2055;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_buffaddr_2055)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2057);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	buffaddr += length(s)*/
    if (IS_SEQUENCE(_s_2057)){
            _1023 = SEQ_PTR(_s_2057)->length;
    }
    else {
        _1023 = 1;
    }
    _0 = _buffaddr_2055;
    if (IS_ATOM_INT(_buffaddr_2055)) {
        _buffaddr_2055 = _buffaddr_2055 + _1023;
        if ((long)((unsigned long)_buffaddr_2055 + (unsigned long)HIGH_BITS) >= 0) 
        _buffaddr_2055 = NewDouble((double)_buffaddr_2055);
    }
    else {
        _buffaddr_2055 = NewDouble(DBL_PTR(_buffaddr_2055)->dbl + (double)_1023);
    }
    DeRef(_0);
    _1023 = NOVALUE;

    /** 	poke(buffaddr, 0)*/
    if (IS_ATOM_INT(_buffaddr_2055)){
        poke_addr = (unsigned char *)_buffaddr_2055;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_buffaddr_2055)->dbl);
    }
    *poke_addr = (unsigned char)0;

    /** 	return buffaddr*/
    DeRefDS(_s_2057);
    return _buffaddr_2055;
    ;
}


int  __stdcall _14poke_wstring(int _buffaddr_2070, int _buffsize_2071, int _s_2072)
{
    int _1030 = NOVALUE;
    int _1029 = NOVALUE;
    int _1027 = NOVALUE;
    int _1026 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_buffsize_2071)) {
        _1 = (long)(DBL_PTR(_buffsize_2071)->dbl);
        DeRefDS(_buffsize_2071);
        _buffsize_2071 = _1;
    }

    /** 	if buffaddr <= 0 then*/
    if (binary_op_a(GREATER, _buffaddr_2070, 0)){
        goto L1; // [7] 18
    }

    /** 		return 0*/
    DeRef(_buffaddr_2070);
    DeRefDS(_s_2072);
    return 0;
L1: 

    /** 	if buffsize <= 2 * length(s) then*/
    if (IS_SEQUENCE(_s_2072)){
            _1026 = SEQ_PTR(_s_2072)->length;
    }
    else {
        _1026 = 1;
    }
    _1027 = _1026 + _1026;
    if ((long)((unsigned long)_1027 + (unsigned long)HIGH_BITS) >= 0) 
    _1027 = NewDouble((double)_1027);
    _1026 = NOVALUE;
    _1026 = NOVALUE;
    if (binary_op_a(GREATER, _buffsize_2071, _1027)){
        DeRef(_1027);
        _1027 = NOVALUE;
        goto L2; // [27] 38
    }
    DeRef(_1027);
    _1027 = NOVALUE;

    /** 		return 0*/
    DeRef(_buffaddr_2070);
    DeRefDS(_s_2072);
    return 0;
L2: 

    /** 	poke2(buffaddr, s)*/
    if (IS_ATOM_INT(_buffaddr_2070)){
        poke2_addr = (unsigned short *)_buffaddr_2070;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_buffaddr_2070)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2072);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke2_addr++ = (unsigned short)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
        }
    }

    /** 	buffaddr += 2 * length(s)*/
    if (IS_SEQUENCE(_s_2072)){
            _1029 = SEQ_PTR(_s_2072)->length;
    }
    else {
        _1029 = 1;
    }
    _1030 = _1029 + _1029;
    if ((long)((unsigned long)_1030 + (unsigned long)HIGH_BITS) >= 0) 
    _1030 = NewDouble((double)_1030);
    _1029 = NOVALUE;
    _1029 = NOVALUE;
    _0 = _buffaddr_2070;
    if (IS_ATOM_INT(_buffaddr_2070) && IS_ATOM_INT(_1030)) {
        _buffaddr_2070 = _buffaddr_2070 + _1030;
        if ((long)((unsigned long)_buffaddr_2070 + (unsigned long)HIGH_BITS) >= 0) 
        _buffaddr_2070 = NewDouble((double)_buffaddr_2070);
    }
    else {
        if (IS_ATOM_INT(_buffaddr_2070)) {
            _buffaddr_2070 = NewDouble((double)_buffaddr_2070 + DBL_PTR(_1030)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1030)) {
                _buffaddr_2070 = NewDouble(DBL_PTR(_buffaddr_2070)->dbl + (double)_1030);
            }
            else
            _buffaddr_2070 = NewDouble(DBL_PTR(_buffaddr_2070)->dbl + DBL_PTR(_1030)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1030);
    _1030 = NOVALUE;

    /** 	poke2(buffaddr, 0)*/
    if (IS_ATOM_INT(_buffaddr_2070)){
        poke2_addr = (unsigned short *)_buffaddr_2070;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_buffaddr_2070)->dbl);
    }
    *poke2_addr = (unsigned short)0;

    /** 	return buffaddr*/
    DeRefDS(_s_2072);
    return _buffaddr_2070;
    ;
}


int _14VirtualAlloc(int _addr_2168, int _size_2169, int _allocation_type_2170, int _protect__2171)
{
    int _r1_2172 = NOVALUE;
    int _1071 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r1 = c_func( VirtualAlloc_rid, {addr, size, allocation_type, protect_ } )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    Ref(_allocation_type_2170);
    *((int *)(_2+12)) = _allocation_type_2170;
    *((int *)(_2+16)) = 64;
    _1071 = MAKE_SEQ(_1);
    DeRef(_r1_2172);
    _r1_2172 = call_c(1, _14VirtualAlloc_rid_2085, _1071);
    DeRefDS(_1071);
    _1071 = NOVALUE;

    /** 		return r1*/
    DeRef(_allocation_type_2170);
    return _r1_2172;
    ;
}


int  __stdcall _14is_DEP_supported()
{
    int _0, _1, _2;
    

    /** 	return memconst:DEP_really_works*/
    return _15DEP_really_works_1853;
    ;
}


int  __stdcall _14is_using_DEP()
{
    int _0, _1, _2;
    

    /** 	return memconst:use_DEP*/
    return _15use_DEP_1854;
    ;
}


void  __stdcall _14DEP_on(int _value_2181)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_2181)) {
        _1 = (long)(DBL_PTR(_value_2181)->dbl);
        DeRefDS(_value_2181);
        _value_2181 = _1;
    }

    /** 	memconst:use_DEP = value*/
    _15use_DEP_1854 = _value_2181;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _14allocate_code(int _data_2184, int _wordsize_2185)
{
    int _1073 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    Ref(_data_2184);
    Ref(_wordsize_2185);
    _1073 = _14allocate_protect(_data_2184, _wordsize_2185, 16);
    DeRef(_data_2184);
    DeRef(_wordsize_2185);
    return _1073;
    ;
}


int  __stdcall _14allocate_string(int _s_2191, int _cleanup_2192)
{
    int _mem_2193 = NOVALUE;
    int _1078 = NOVALUE;
    int _1077 = NOVALUE;
    int _1075 = NOVALUE;
    int _1074 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_2191)){
            _1074 = SEQ_PTR(_s_2191)->length;
    }
    else {
        _1074 = 1;
    }
    _1075 = _1074 + 1;
    _1074 = NOVALUE;
    _0 = _mem_2193;
    _mem_2193 = _14allocate(_1075, 0);
    DeRef(_0);
    _1075 = NOVALUE;

    /** 	if mem then*/
    if (_mem_2193 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_2193) && DBL_PTR(_mem_2193)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_2193)){
        poke_addr = (unsigned char *)_mem_2193;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_2193)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2191);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_2191)){
            _1077 = SEQ_PTR(_s_2191)->length;
    }
    else {
        _1077 = 1;
    }
    if (IS_ATOM_INT(_mem_2193)) {
        _1078 = _mem_2193 + _1077;
        if ((long)((unsigned long)_1078 + (unsigned long)HIGH_BITS) >= 0) 
        _1078 = NewDouble((double)_1078);
    }
    else {
        _1078 = NewDouble(DBL_PTR(_mem_2193)->dbl + (double)_1077);
    }
    _1077 = NOVALUE;
    if (IS_ATOM_INT(_1078)){
        poke_addr = (unsigned char *)_1078;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_1078)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_1078);
    _1078 = NOVALUE;

    /** 		if cleanup then*/
    if (_cleanup_2192 == 0) {
        goto L2; // [41] 53
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2192) && DBL_PTR(_cleanup_2192)->dbl == 0.0){
            goto L2; // [41] 53
        }
    }

    /** 			mem = delete_routine( mem, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1863].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1863].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1863;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_mem_2193) ){
        if( IS_ATOM_INT(_mem_2193) ){
            _mem_2193 = NewDouble( (double) _mem_2193 );
        }
        if(DBL_PTR(_mem_2193)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_mem_2193)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_mem_2193)) ){
            DeRefDS(_mem_2193);
            _mem_2193 = NewDouble( DBL_PTR(_mem_2193)->dbl );
        }
        DBL_PTR(_mem_2193)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_mem_2193)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_mem_2193)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_mem_2193)) ){
            _mem_2193 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_mem_2193) ));
        }
        SEQ_PTR(_mem_2193)->cleanup = (cleanup_ptr)_1;
    }
L2: 
L1: 

    /** 	return mem*/
    DeRefDS(_s_2191);
    DeRef(_cleanup_2192);
    return _mem_2193;
    ;
}


int  __stdcall _14allocate_protect(int _data_2204, int _wordsize_2205, int _protection_2207)
{
    int _iaddr_2208 = NOVALUE;
    int _eaddr_2210 = NOVALUE;
    int _size_2211 = NOVALUE;
    int _first_protection_2213 = NOVALUE;
    int _true_protection_2215 = NOVALUE;
    int _prepare_block_inlined_prepare_block_at_104_2230 = NOVALUE;
    int _msg_inlined_crash_at_186_2243 = NOVALUE;
    int _1099 = NOVALUE;
    int _1098 = NOVALUE;
    int _1096 = NOVALUE;
    int _1095 = NOVALUE;
    int _1094 = NOVALUE;
    int _1090 = NOVALUE;
    int _1088 = NOVALUE;
    int _1085 = NOVALUE;
    int _1084 = NOVALUE;
    int _1082 = NOVALUE;
    int _1080 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom iaddr = 0*/
    DeRef(_iaddr_2208);
    _iaddr_2208 = 0;

    /** 	integer size*/

    /** 	valid_memory_protection_constant true_protection = protection*/
    Ref(_protection_2207);
    DeRef(_true_protection_2215);
    _true_protection_2215 = _protection_2207;

    /** 	ifdef SAFE then	*/

    /** 	if atom(data) then*/
    _1080 = IS_ATOM(_data_2204);
    if (_1080 == 0)
    {
        _1080 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _1080 = NOVALUE;
    }

    /** 		size = data * wordsize*/
    if (IS_ATOM_INT(_data_2204) && IS_ATOM_INT(_wordsize_2205)) {
        _size_2211 = _data_2204 * _wordsize_2205;
    }
    else {
        _size_2211 = binary_op(MULTIPLY, _data_2204, _wordsize_2205);
    }
    if (!IS_ATOM_INT(_size_2211)) {
        _1 = (long)(DBL_PTR(_size_2211)->dbl);
        DeRefDS(_size_2211);
        _size_2211 = _1;
    }

    /** 		first_protection = true_protection*/
    Ref(_true_protection_2215);
    DeRef(_first_protection_2213);
    _first_protection_2213 = _true_protection_2215;
    goto L2; // [36] 58
L1: 

    /** 		size = length(data) * wordsize*/
    if (IS_SEQUENCE(_data_2204)){
            _1082 = SEQ_PTR(_data_2204)->length;
    }
    else {
        _1082 = 1;
    }
    if (IS_ATOM_INT(_wordsize_2205)) {
        _size_2211 = _1082 * _wordsize_2205;
    }
    else {
        _size_2211 = binary_op(MULTIPLY, _1082, _wordsize_2205);
    }
    _1082 = NOVALUE;
    if (!IS_ATOM_INT(_size_2211)) {
        _1 = (long)(DBL_PTR(_size_2211)->dbl);
        DeRefDS(_size_2211);
        _size_2211 = _1;
    }

    /** 		first_protection = PAGE_READ_WRITE*/
    DeRef(_first_protection_2213);
    _first_protection_2213 = 4;
L2: 

    /** 	iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _1084 = 0;
    _1085 = _size_2211 + 0;
    _1084 = NOVALUE;
    Ref(_first_protection_2213);
    _0 = _iaddr_2208;
    _iaddr_2208 = _14local_allocate_protected_memory(_1085, _first_protection_2213);
    DeRef(_0);
    _1085 = NOVALUE;

    /** 	if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_2208, 0)){
        goto L3; // [79] 90
    }

    /** 		return 0*/
    DeRef(_data_2204);
    DeRef(_wordsize_2205);
    DeRef(_protection_2207);
    DeRef(_iaddr_2208);
    DeRef(_eaddr_2210);
    DeRef(_first_protection_2213);
    DeRef(_true_protection_2215);
    return 0;
L3: 

    /** 	eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_2207)) {
        _1 = (long)(DBL_PTR(_protection_2207)->dbl);
        DeRefDS(_protection_2207);
        _protection_2207 = _1;
    }

    /** 	return addr*/
    Ref(_iaddr_2208);
    DeRef(_eaddr_2210);
    _eaddr_2210 = _iaddr_2208;

    /** 	if eaddr = 0 or atom( data ) then*/
    if (IS_ATOM_INT(_eaddr_2210)) {
        _1088 = (_eaddr_2210 == 0);
    }
    else {
        _1088 = (DBL_PTR(_eaddr_2210)->dbl == (double)0);
    }
    if (_1088 != 0) {
        goto L4; // [106] 118
    }
    _1090 = IS_ATOM(_data_2204);
    if (_1090 == 0)
    {
        _1090 = NOVALUE;
        goto L5; // [114] 125
    }
    else{
        _1090 = NOVALUE;
    }
L4: 

    /** 		return eaddr*/
    DeRef(_data_2204);
    DeRef(_wordsize_2205);
    DeRef(_protection_2207);
    DeRef(_iaddr_2208);
    DeRef(_first_protection_2213);
    DeRef(_true_protection_2215);
    DeRef(_1088);
    _1088 = NOVALUE;
    return _eaddr_2210;
L5: 

    /** 	switch wordsize do*/
    if (IS_SEQUENCE(_wordsize_2205) ){
        goto L6; // [127] 167
    }
    if(!IS_ATOM_INT(_wordsize_2205)){
        if( (DBL_PTR(_wordsize_2205)->dbl != (double) ((int) DBL_PTR(_wordsize_2205)->dbl) ) ){
            goto L6; // [127] 167
        }
        _0 = (int) DBL_PTR(_wordsize_2205)->dbl;
    }
    else {
        _0 = _wordsize_2205;
    };
    switch ( _0 ){ 

        /** 		case 1 then*/
        case 1:

        /** 			eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2210)){
            poke_addr = (unsigned char *)_eaddr_2210;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_eaddr_2210)->dbl);
        }
        if (IS_ATOM_INT(_data_2204)) {
            *poke_addr = (unsigned char)_data_2204;
        }
        else if (IS_ATOM(_data_2204)) {
            *poke_addr = (signed char)DBL_PTR(_data_2204)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2204);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [141] 190

        /** 		case 2 then*/
        case 2:

        /** 			eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2210)){
            poke2_addr = (unsigned short *)_eaddr_2210;
        }
        else {
            poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_eaddr_2210)->dbl);
        }
        if (IS_ATOM_INT(_data_2204)) {
            *poke2_addr = (unsigned short)_data_2204;
        }
        else if (IS_ATOM(_data_2204)) {
            *poke_addr = (signed char)DBL_PTR(_data_2204)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2204);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke2_addr++ = (unsigned short)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [152] 190

        /** 		case 4 then*/
        case 4:

        /** 			eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2210)){
            poke4_addr = (unsigned long *)_eaddr_2210;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_eaddr_2210)->dbl);
        }
        if (IS_ATOM_INT(_data_2204)) {
            *poke4_addr = (unsigned long)_data_2204;
        }
        else if (IS_ATOM(_data_2204)) {
            *poke4_addr = (unsigned long)DBL_PTR(_data_2204)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2204);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [163] 190

        /** 		case else*/
        default:
L6: 

        /** 			error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_186_2243);
        _msg_inlined_crash_at_186_2243 = EPrintf(-9999999, _1093, _wordsize_2205);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_186_2243);

        /** end procedure*/
        goto L8; // [184] 187
L8: 
        DeRefi(_msg_inlined_crash_at_186_2243);
        _msg_inlined_crash_at_186_2243 = NOVALUE;
    ;}L7: 

    /** 	ifdef SAFE then*/

    /** 	if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _1094 = 0;
    _1095 = _size_2211 + 0;
    _1094 = NOVALUE;
    Ref(_iaddr_2208);
    Ref(_true_protection_2215);
    _1096 = _14local_change_protection_on_protected_memory(_iaddr_2208, _1095, _true_protection_2215);
    _1095 = NOVALUE;
    if (binary_op_a(NOTEQ, _1096, -1)){
        DeRef(_1096);
        _1096 = NOVALUE;
        goto L9; // [208] 232
    }
    DeRef(_1096);
    _1096 = NOVALUE;

    /** 		local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _1098 = 0;
    _1099 = _size_2211 + 0;
    _1098 = NOVALUE;
    Ref(_iaddr_2208);
    _14local_free_protected_memory(_iaddr_2208, _1099);
    _1099 = NOVALUE;

    /** 		eaddr = 0*/
    DeRef(_eaddr_2210);
    _eaddr_2210 = 0;
L9: 

    /** 	return eaddr*/
    DeRef(_data_2204);
    DeRef(_wordsize_2205);
    DeRef(_protection_2207);
    DeRef(_iaddr_2208);
    DeRef(_first_protection_2213);
    DeRef(_true_protection_2215);
    DeRef(_1088);
    _1088 = NOVALUE;
    return _eaddr_2210;
    ;
}


int _14local_allocate_protected_memory(int _s_2258, int _first_protection_2259)
{
    int _1105 = NOVALUE;
    int _1104 = NOVALUE;
    int _1103 = NOVALUE;
    int _1102 = NOVALUE;
    int _1101 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_first_protection_2259)) {
        _1 = (long)(DBL_PTR(_first_protection_2259)->dbl);
        DeRefDS(_first_protection_2259);
        _first_protection_2259 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _1101 = _16dep_works();
    if (_1101 == 0) {
        DeRef(_1101);
        _1101 = NOVALUE;
        goto L1; // [12] 46
    }
    else {
        if (!IS_ATOM_INT(_1101) && DBL_PTR(_1101)->dbl == 0.0){
            DeRef(_1101);
            _1101 = NOVALUE;
            goto L1; // [12] 46
        }
        DeRef(_1101);
        _1101 = NOVALUE;
    }
    DeRef(_1101);
    _1101 = NOVALUE;

    /** 			return eu:c_func(VirtualAlloc_rid, */
    {unsigned long tu;
         tu = (unsigned long)8192 | (unsigned long)4096;
         _1102 = MAKE_UINT(tu);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = _s_2258;
    *((int *)(_2+12)) = _1102;
    *((int *)(_2+16)) = _first_protection_2259;
    _1103 = MAKE_SEQ(_1);
    _1102 = NOVALUE;
    _1104 = call_c(1, _14VirtualAlloc_rid_2085, _1103);
    DeRefDS(_1103);
    _1103 = NOVALUE;
    return _1104;
    goto L2; // [43] 61
L1: 

    /** 			return machine_func(M_ALLOC, PAGE_SIZE)*/
    _1105 = machine(16, _14PAGE_SIZE_2165);
    DeRef(_1104);
    _1104 = NOVALUE;
    return _1105;
L2: 
    ;
}


int _14local_change_protection_on_protected_memory(int _p_2273, int _s_2274, int _new_protection_2275)
{
    int _1108 = NOVALUE;
    int _1107 = NOVALUE;
    int _1106 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_protection_2275)) {
        _1 = (long)(DBL_PTR(_new_protection_2275)->dbl);
        DeRefDS(_new_protection_2275);
        _new_protection_2275 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _1106 = _16dep_works();
    if (_1106 == 0) {
        DeRef(_1106);
        _1106 = NOVALUE;
        goto L1; // [12] 45
    }
    else {
        if (!IS_ATOM_INT(_1106) && DBL_PTR(_1106)->dbl == 0.0){
            DeRef(_1106);
            _1106 = NOVALUE;
            goto L1; // [12] 45
        }
        DeRef(_1106);
        _1106 = NOVALUE;
    }
    DeRef(_1106);
    _1106 = NOVALUE;

    /** 			if eu:c_func( VirtualProtect_rid, { p, s, new_protection , oldprotptr } ) = 0 then*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_2273);
    *((int *)(_2+4)) = _p_2273;
    *((int *)(_2+8)) = _s_2274;
    *((int *)(_2+12)) = _new_protection_2275;
    Ref(_14oldprotptr_2254);
    *((int *)(_2+16)) = _14oldprotptr_2254;
    _1107 = MAKE_SEQ(_1);
    _1108 = call_c(1, _14VirtualProtect_rid_2086, _1107);
    DeRefDS(_1107);
    _1107 = NOVALUE;
    if (binary_op_a(NOTEQ, _1108, 0)){
        DeRef(_1108);
        _1108 = NOVALUE;
        goto L2; // [33] 44
    }
    DeRef(_1108);
    _1108 = NOVALUE;

    /** 				return -1*/
    DeRef(_p_2273);
    return -1;
L2: 
L1: 

    /** 		return 0*/
    DeRef(_p_2273);
    return 0;
    ;
}


void _14local_free_protected_memory(int _p_2285, int _s_2286)
{
    int _1114 = NOVALUE;
    int _1113 = NOVALUE;
    int _1112 = NOVALUE;
    int _1111 = NOVALUE;
    int _1110 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _1110 = _16dep_works();
    if (_1110 == 0) {
        DeRef(_1110);
        _1110 = NOVALUE;
        goto L1; // [10] 33
    }
    else {
        if (!IS_ATOM_INT(_1110) && DBL_PTR(_1110)->dbl == 0.0){
            DeRef(_1110);
            _1110 = NOVALUE;
            goto L1; // [10] 33
        }
        DeRef(_1110);
        _1110 = NOVALUE;
    }
    DeRef(_1110);
    _1110 = NOVALUE;

    /** 			c_func(VirtualFree_rid, { p, s, MEM_RELEASE })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_2285);
    *((int *)(_2+4)) = _p_2285;
    *((int *)(_2+8)) = _s_2286;
    *((int *)(_2+12)) = 32768;
    _1111 = MAKE_SEQ(_1);
    _1112 = call_c(1, _16VirtualFree_rid_1954, _1111);
    DeRefDS(_1111);
    _1111 = NOVALUE;
    goto L2; // [30] 46
L1: 

    /** 			machine_func(M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_2285);
    *((int *)(_2+4)) = _p_2285;
    _1113 = MAKE_SEQ(_1);
    _1114 = machine(17, _1113);
    DeRefDS(_1113);
    _1113 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_p_2285);
    DeRef(_1112);
    _1112 = NOVALUE;
    DeRef(_1114);
    _1114 = NOVALUE;
    return;
    ;
}


void  __stdcall _14free(int _addr_2300)
{
    int _msg_inlined_crash_at_27_2309 = NOVALUE;
    int _data_inlined_crash_at_24_2308 = NOVALUE;
    int _addr_inlined_deallocate_at_64_2315 = NOVALUE;
    int _msg_inlined_crash_at_106_2320 = NOVALUE;
    int _1121 = NOVALUE;
    int _1120 = NOVALUE;
    int _1119 = NOVALUE;
    int _1118 = NOVALUE;
    int _1116 = NOVALUE;
    int _1115 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_2300);
    _1115 = _7number_array(_addr_2300);
    if (_1115 == 0) {
        DeRef(_1115);
        _1115 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_1115) && DBL_PTR(_1115)->dbl == 0.0){
            DeRef(_1115);
            _1115 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_1115);
        _1115 = NOVALUE;
    }
    DeRef(_1115);
    _1115 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_2300);
    _1116 = _7ascii_string(_addr_2300);
    if (_1116 == 0) {
        DeRef(_1116);
        _1116 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_1116) && DBL_PTR(_1116)->dbl == 0.0){
            DeRef(_1116);
            _1116 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_1116);
        _1116 = NOVALUE;
    }
    DeRef(_1116);
    _1116 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_2300);
    *((int *)(_2+4)) = _addr_2300;
    _1118 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_2308);
    _data_inlined_crash_at_24_2308 = _1118;
    _1118 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_2309);
    _msg_inlined_crash_at_27_2309 = EPrintf(-9999999, _1117, _data_inlined_crash_at_24_2308);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_2309);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_2308);
    _data_inlined_crash_at_24_2308 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_2309);
    _msg_inlined_crash_at_27_2309 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_2300)){
            _1119 = SEQ_PTR(_addr_2300)->length;
    }
    else {
        _1119 = 1;
    }
    {
        int _i_2311;
        _i_2311 = 1;
L4: 
        if (_i_2311 > _1119){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_2300);
        _1120 = (int)*(((s1_ptr)_2)->base + _i_2311);
        Ref(_1120);
        DeRef(_addr_inlined_deallocate_at_64_2315);
        _addr_inlined_deallocate_at_64_2315 = _1120;
        _1120 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_2315);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_2315);
        _addr_inlined_deallocate_at_64_2315 = NOVALUE;

        /** 		end for*/
        _i_2311 = _i_2311 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_2300);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _1121 = IS_SEQUENCE(_addr_2300);
    if (_1121 == 0)
    {
        _1121 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _1121 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_2320);
    _msg_inlined_crash_at_106_2320 = EPrintf(-9999999, _1122, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_2320);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_2320);
    _msg_inlined_crash_at_106_2320 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_2300, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_2300);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_2300);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_2300);
    return;
    ;
}


void  __stdcall _14free_pointer_array(int _pointers_array_2328)
{
    int _saved_2329 = NOVALUE;
    int _ptr_2330 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_2328);
    DeRef(_saved_2329);
    _saved_2329 = _pointers_array_2328;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_2330 <= 0) {
        if (_ptr_2330 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_2330) && DBL_PTR(_ptr_2330)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_2330);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_2328;
    if (IS_ATOM_INT(_pointers_array_2328)) {
        _pointers_array_2328 = _pointers_array_2328 + 4;
        if ((long)((unsigned long)_pointers_array_2328 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_2328 = NewDouble((double)_pointers_array_2328);
    }
    else {
        _pointers_array_2328 = NewDouble(DBL_PTR(_pointers_array_2328)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_2330);
    if (IS_ATOM_INT(_pointers_array_2328)) {
        _ptr_2330 = *(unsigned long *)_pointers_array_2328;
        if ((unsigned)_ptr_2330 > (unsigned)MAXINT)
        _ptr_2330 = NewDouble((double)(unsigned long)_ptr_2330);
    }
    else {
        _ptr_2330 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_2328)->dbl);
        if ((unsigned)_ptr_2330 > (unsigned)MAXINT)
        _ptr_2330 = NewDouble((double)(unsigned long)_ptr_2330);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_2329);
    _14free(_saved_2329);

    /** end procedure*/
    DeRef(_pointers_array_2328);
    DeRef(_saved_2329);
    DeRef(_ptr_2330);
    return;
    ;
}


int  __stdcall _14std_library_address(int _addr_2339)
{
    int _1130 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef not SAFE then*/

    /** 		return atom(addr)*/
    _1130 = IS_ATOM(_addr_2339);
    DeRef(_addr_2339);
    return _1130;
    ;
}


int  __stdcall _14valid_memory_protection_constant(int _x_2343)
{
    int _1131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, memconst:MEMORY_PROTECTION )*/
    _1131 = find_from(_x_2343, _15MEMORY_PROTECTION_1827, 1);
    DeRef(_x_2343);
    return _1131;
    ;
}


int  __stdcall _14page_aligned_address(int _a_2347)
{
    int _1135 = NOVALUE;
    int _1134 = NOVALUE;
    int _1132 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _1132 = IS_ATOM(_a_2347);
    if (_1132 != 0)
    goto L1; // [6] 16
    _1132 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_2347);
    return 0;
L1: 

    /** 	return remainder( a, PAGE_SIZE ) = 0*/
    if (IS_ATOM_INT(_a_2347)) {
        _1134 = (_a_2347 % _14PAGE_SIZE_2165);
    }
    else {
        _1134 = binary_op(REMAINDER, _a_2347, _14PAGE_SIZE_2165);
    }
    if (IS_ATOM_INT(_1134)) {
        _1135 = (_1134 == 0);
    }
    else {
        _1135 = binary_op(EQUALS, _1134, 0);
    }
    DeRef(_1134);
    _1134 = NOVALUE;
    DeRef(_a_2347);
    return _1135;
    ;
}



// 0x3D8B5F12
