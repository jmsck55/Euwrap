// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _35small(int _data_set_12442, int _ordinal_idx_12443)
{
    int _lSortedData_12444 = NOVALUE;
    int _7053 = NOVALUE;
    int _7052 = NOVALUE;
    int _7051 = NOVALUE;
    int _7050 = NOVALUE;
    int _7048 = NOVALUE;
    int _7047 = NOVALUE;
    int _7045 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ordinal_idx_12443)) {
        _1 = (long)(DBL_PTR(_ordinal_idx_12443)->dbl);
        DeRefDS(_ordinal_idx_12443);
        _ordinal_idx_12443 = _1;
    }

    /** 	if ordinal_idx < 1 or ordinal_idx > length(data_set) then*/
    _7045 = (_ordinal_idx_12443 < 1);
    if (_7045 != 0) {
        goto L1; // [11] 27
    }
    if (IS_SEQUENCE(_data_set_12442)){
            _7047 = SEQ_PTR(_data_set_12442)->length;
    }
    else {
        _7047 = 1;
    }
    _7048 = (_ordinal_idx_12443 > _7047);
    _7047 = NOVALUE;
    if (_7048 == 0)
    {
        DeRef(_7048);
        _7048 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_7048);
        _7048 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12442);
    DeRef(_lSortedData_12444);
    DeRef(_7045);
    _7045 = NOVALUE;
    return _5;
L2: 

    /** 	lSortedData = stdsort:sort(data_set)*/
    RefDS(_data_set_12442);
    _0 = _lSortedData_12444;
    _lSortedData_12444 = _24sort(_data_set_12442, 1);
    DeRef(_0);

    /** 	return {lSortedData[ordinal_idx], find(lSortedData[ordinal_idx], data_set)}*/
    _2 = (int)SEQ_PTR(_lSortedData_12444);
    _7050 = (int)*(((s1_ptr)_2)->base + _ordinal_idx_12443);
    _2 = (int)SEQ_PTR(_lSortedData_12444);
    _7051 = (int)*(((s1_ptr)_2)->base + _ordinal_idx_12443);
    _7052 = find_from(_7051, _data_set_12442, 1);
    _7051 = NOVALUE;
    Ref(_7050);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _7050;
    ((int *)_2)[2] = _7052;
    _7053 = MAKE_SEQ(_1);
    _7052 = NOVALUE;
    _7050 = NOVALUE;
    DeRefDS(_data_set_12442);
    DeRefDS(_lSortedData_12444);
    DeRef(_7045);
    _7045 = NOVALUE;
    return _7053;
    ;
}


int  __stdcall _35largest(int _data_set_12457)
{
    int _result__12458 = NOVALUE;
    int _temp__12459 = NOVALUE;
    int _lFoundAny_12460 = NOVALUE;
    int _7057 = NOVALUE;
    int _7056 = NOVALUE;
    int _7055 = NOVALUE;
    int _7054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7054 = IS_ATOM(_data_set_12457);
    if (_7054 == 0)
    {
        _7054 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7054 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_result__12458);
    DeRef(_temp__12459);
    return _data_set_12457;
L1: 

    /** 	lFoundAny = 0*/
    _lFoundAny_12460 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12457)){
            _7055 = SEQ_PTR(_data_set_12457)->length;
    }
    else {
        _7055 = 1;
    }
    {
        int _i_12464;
        _i_12464 = 1;
L2: 
        if (_i_12464 > _7055){
            goto L3; // [26] 92
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12457);
        _7056 = (int)*(((s1_ptr)_2)->base + _i_12464);
        _7057 = IS_ATOM(_7056);
        _7056 = NOVALUE;
        if (_7057 == 0)
        {
            _7057 = NOVALUE;
            goto L4; // [42] 85
        }
        else{
            _7057 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12459);
        _2 = (int)SEQ_PTR(_data_set_12457);
        _temp__12459 = (int)*(((s1_ptr)_2)->base + _i_12464);
        Ref(_temp__12459);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12460 == 0)
        {
            goto L5; // [53] 73
        }
        else{
        }

        /** 				if temp_ > result_ then*/
        if (binary_op_a(LESSEQ, _temp__12459, _result__12458)){
            goto L6; // [60] 84
        }

        /** 					result_ = temp_*/
        Ref(_temp__12459);
        DeRef(_result__12458);
        _result__12458 = _temp__12459;
        goto L6; // [70] 84
L5: 

        /** 				result_ = temp_*/
        Ref(_temp__12459);
        DeRef(_result__12458);
        _result__12458 = _temp__12459;

        /** 				lFoundAny = 1*/
        _lFoundAny_12460 = 1;
L6: 
L4: 

        /** 	end for*/
        _i_12464 = _i_12464 + 1;
        goto L2; // [87] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12460 != 0)
    goto L7; // [94] 105

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12457);
    DeRef(_result__12458);
    DeRef(_temp__12459);
    return _5;
L7: 

    /** 	return result_*/
    DeRef(_data_set_12457);
    DeRef(_temp__12459);
    return _result__12458;
    ;
}


int  __stdcall _35smallest(int _data_set_12478)
{
    int _result__12479 = NOVALUE;
    int _temp__12480 = NOVALUE;
    int _lFoundAny_12481 = NOVALUE;
    int _7064 = NOVALUE;
    int _7063 = NOVALUE;
    int _7062 = NOVALUE;
    int _7061 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7061 = IS_ATOM(_data_set_12478);
    if (_7061 == 0)
    {
        _7061 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7061 = NOVALUE;
    }

    /** 			return data_set*/
    DeRef(_result__12479);
    DeRef(_temp__12480);
    return _data_set_12478;
L1: 

    /** 	lFoundAny = 0*/
    _lFoundAny_12481 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12478)){
            _7062 = SEQ_PTR(_data_set_12478)->length;
    }
    else {
        _7062 = 1;
    }
    {
        int _i_12485;
        _i_12485 = 1;
L2: 
        if (_i_12485 > _7062){
            goto L3; // [26] 92
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12478);
        _7063 = (int)*(((s1_ptr)_2)->base + _i_12485);
        _7064 = IS_ATOM(_7063);
        _7063 = NOVALUE;
        if (_7064 == 0)
        {
            _7064 = NOVALUE;
            goto L4; // [42] 85
        }
        else{
            _7064 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12480);
        _2 = (int)SEQ_PTR(_data_set_12478);
        _temp__12480 = (int)*(((s1_ptr)_2)->base + _i_12485);
        Ref(_temp__12480);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12481 == 0)
        {
            goto L5; // [53] 73
        }
        else{
        }

        /** 				if temp_ < result_ then*/
        if (binary_op_a(GREATEREQ, _temp__12480, _result__12479)){
            goto L6; // [60] 84
        }

        /** 					result_ = temp_*/
        Ref(_temp__12480);
        DeRef(_result__12479);
        _result__12479 = _temp__12480;
        goto L6; // [70] 84
L5: 

        /** 				result_ = temp_*/
        Ref(_temp__12480);
        DeRef(_result__12479);
        _result__12479 = _temp__12480;

        /** 				lFoundAny = 1*/
        _lFoundAny_12481 = 1;
L6: 
L4: 

        /** 	end for*/
        _i_12485 = _i_12485 + 1;
        goto L2; // [87] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12481 != 0)
    goto L7; // [94] 105

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12478);
    DeRef(_result__12479);
    DeRef(_temp__12480);
    return _5;
L7: 

    /** 	return result_*/
    DeRef(_data_set_12478);
    DeRef(_temp__12480);
    return _result__12479;
    ;
}


int  __stdcall _35range(int _data_set_12499)
{
    int _result__12500 = NOVALUE;
    int _temp__12501 = NOVALUE;
    int _lFoundAny_12502 = NOVALUE;
    int _7086 = NOVALUE;
    int _7085 = NOVALUE;
    int _7084 = NOVALUE;
    int _7083 = NOVALUE;
    int _7082 = NOVALUE;
    int _7081 = NOVALUE;
    int _7080 = NOVALUE;
    int _7076 = NOVALUE;
    int _7074 = NOVALUE;
    int _7072 = NOVALUE;
    int _7071 = NOVALUE;
    int _7070 = NOVALUE;
    int _7068 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lFoundAny = 0*/
    _lFoundAny_12502 = 0;

    /** 	if atom(data_set) then*/
    _7068 = IS_ATOM(_data_set_12499);
    if (_7068 == 0)
    {
        _7068 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _7068 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12499;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12499);
    *((int *)(_2+4)) = _data_set_12499;
    _data_set_12499 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12499)){
            _7070 = SEQ_PTR(_data_set_12499)->length;
    }
    else {
        _7070 = 1;
    }
    {
        int _i_12507;
        _i_12507 = 1;
L2: 
        if (_i_12507 > _7070){
            goto L3; // [26] 121
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12499);
        _7071 = (int)*(((s1_ptr)_2)->base + _i_12507);
        _7072 = IS_ATOM(_7071);
        _7071 = NOVALUE;
        if (_7072 == 0)
        {
            _7072 = NOVALUE;
            goto L4; // [42] 114
        }
        else{
            _7072 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12501);
        _2 = (int)SEQ_PTR(_data_set_12499);
        _temp__12501 = (int)*(((s1_ptr)_2)->base + _i_12507);
        Ref(_temp__12501);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12502 == 0)
        {
            goto L5; // [53] 98
        }
        else{
        }

        /** 				if temp_ < result_[1] then*/
        _2 = (int)SEQ_PTR(_result__12500);
        _7074 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(GREATEREQ, _temp__12501, _7074)){
            _7074 = NOVALUE;
            goto L6; // [64] 77
        }
        _7074 = NOVALUE;

        /** 					result_[1] = temp_*/
        Ref(_temp__12501);
        _2 = (int)SEQ_PTR(_result__12500);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12500 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _temp__12501;
        DeRef(_1);
        goto L7; // [74] 113
L6: 

        /** 				elsif temp_ > result_[2] then*/
        _2 = (int)SEQ_PTR(_result__12500);
        _7076 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(LESSEQ, _temp__12501, _7076)){
            _7076 = NOVALUE;
            goto L7; // [83] 113
        }
        _7076 = NOVALUE;

        /** 					result_[2] = temp_*/
        Ref(_temp__12501);
        _2 = (int)SEQ_PTR(_result__12500);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12500 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _temp__12501;
        DeRef(_1);
        goto L7; // [95] 113
L5: 

        /** 				result_ = {temp_, temp_, 0, 0}*/
        _0 = _result__12500;
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Refn(_temp__12501, 2);
        *((int *)(_2+4)) = _temp__12501;
        *((int *)(_2+8)) = _temp__12501;
        *((int *)(_2+12)) = 0;
        *((int *)(_2+16)) = 0;
        _result__12500 = MAKE_SEQ(_1);
        DeRef(_0);

        /** 				lFoundAny = 1*/
        _lFoundAny_12502 = 1;
L7: 
L4: 

        /** 	end for*/
        _i_12507 = _i_12507 + 1;
        goto L2; // [116] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12502 != 0)
    goto L8; // [123] 134

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12499);
    DeRef(_result__12500);
    DeRef(_temp__12501);
    return _5;
L8: 

    /** 	result_[3] = result_[2] - result_[1]*/
    _2 = (int)SEQ_PTR(_result__12500);
    _7080 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_result__12500);
    _7081 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_7080) && IS_ATOM_INT(_7081)) {
        _7082 = _7080 - _7081;
        if ((long)((unsigned long)_7082 +(unsigned long) HIGH_BITS) >= 0){
            _7082 = NewDouble((double)_7082);
        }
    }
    else {
        _7082 = binary_op(MINUS, _7080, _7081);
    }
    _7080 = NOVALUE;
    _7081 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12500);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12500 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7082;
    if( _1 != _7082 ){
        DeRef(_1);
    }
    _7082 = NOVALUE;

    /** 	result_[4] = (result_[1] + result_[2]) / 2*/
    _2 = (int)SEQ_PTR(_result__12500);
    _7083 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_result__12500);
    _7084 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7083) && IS_ATOM_INT(_7084)) {
        _7085 = _7083 + _7084;
        if ((long)((unsigned long)_7085 + (unsigned long)HIGH_BITS) >= 0) 
        _7085 = NewDouble((double)_7085);
    }
    else {
        _7085 = binary_op(PLUS, _7083, _7084);
    }
    _7083 = NOVALUE;
    _7084 = NOVALUE;
    if (IS_ATOM_INT(_7085)) {
        if (_7085 & 1) {
            _7086 = NewDouble((_7085 >> 1) + 0.5);
        }
        else
        _7086 = _7085 >> 1;
    }
    else {
        _7086 = binary_op(DIVIDE, _7085, 2);
    }
    DeRef(_7085);
    _7085 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12500);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12500 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _7086;
    if( _1 != _7086 ){
        DeRef(_1);
    }
    _7086 = NOVALUE;

    /** 	return result_*/
    DeRef(_data_set_12499);
    DeRef(_temp__12501);
    return _result__12500;
    ;
}


int _35massage(int _data_set_12538, int _subseq_opt_12539)
{
    int _7090 = NOVALUE;
    int _7089 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch subseq_opt do*/
    if (IS_SEQUENCE(_subseq_opt_12539) ){
        goto L1; // [5] 48
    }
    if(!IS_ATOM_INT(_subseq_opt_12539)){
        if( (DBL_PTR(_subseq_opt_12539)->dbl != (double) ((int) DBL_PTR(_subseq_opt_12539)->dbl) ) ){
            goto L1; // [5] 48
        }
        _0 = (int) DBL_PTR(_subseq_opt_12539)->dbl;
    }
    else {
        _0 = _subseq_opt_12539;
    };
    switch ( _0 ){ 

        /** 		case ST_IGNSTR then*/
        case 2:

        /** 			return stdseq:remove_subseq(data_set, stdseq:SEQ_NOALT)*/
        RefDS(_data_set_12538);
        RefDS(_23SEQ_NOALT_6861);
        _7089 = _23remove_subseq(_data_set_12538, _23SEQ_NOALT_6861);
        DeRefDS(_data_set_12538);
        DeRef(_subseq_opt_12539);
        return _7089;
        goto L2; // [27] 57

        /** 		case ST_ZEROSTR then*/
        case 3:

        /** 			return stdseq:remove_subseq(data_set, 0)*/
        RefDS(_data_set_12538);
        _7090 = _23remove_subseq(_data_set_12538, 0);
        DeRefDS(_data_set_12538);
        DeRef(_subseq_opt_12539);
        DeRef(_7089);
        _7089 = NOVALUE;
        return _7090;
        goto L2; // [44] 57

        /** 		case else*/
        default:
L1: 

        /** 			return data_set*/
        DeRef(_subseq_opt_12539);
        DeRef(_7089);
        _7089 = NOVALUE;
        DeRef(_7090);
        _7090 = NOVALUE;
        return _data_set_12538;
    ;}L2: 
    ;
}


int  __stdcall _35stdev(int _data_set_12549, int _subseq_opt_12550, int _population_type_12551)
{
    int _lSum_12552 = NOVALUE;
    int _lMean_12553 = NOVALUE;
    int _lCnt_12554 = NOVALUE;
    int _7107 = NOVALUE;
    int _7106 = NOVALUE;
    int _7102 = NOVALUE;
    int _7101 = NOVALUE;
    int _7100 = NOVALUE;
    int _7099 = NOVALUE;
    int _7096 = NOVALUE;
    int _7095 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_population_type_12551)) {
        _1 = (long)(DBL_PTR(_population_type_12551)->dbl);
        DeRefDS(_population_type_12551);
        _population_type_12551 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12549);
    Ref(_subseq_opt_12550);
    _0 = _data_set_12549;
    _data_set_12549 = _35massage(_data_set_12549, _subseq_opt_12550);
    DeRefDS(_0);

    /** 	lCnt = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12549)){
            _lCnt_12554 = SEQ_PTR(_data_set_12549)->length;
    }
    else {
        _lCnt_12554 = 1;
    }

    /** 	if lCnt = 0 then*/
    if (_lCnt_12554 != 0)
    goto L1; // [21] 32

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12549);
    DeRef(_subseq_opt_12550);
    DeRef(_lSum_12552);
    DeRef(_lMean_12553);
    return _5;
L1: 

    /** 	if lCnt = 1 then*/
    if (_lCnt_12554 != 1)
    goto L2; // [34] 45

    /** 		return 0*/
    DeRefDS(_data_set_12549);
    DeRef(_subseq_opt_12550);
    DeRef(_lSum_12552);
    DeRef(_lMean_12553);
    return 0;
L2: 

    /** 	lSum = 0*/
    DeRef(_lSum_12552);
    _lSum_12552 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12549)){
            _7095 = SEQ_PTR(_data_set_12549)->length;
    }
    else {
        _7095 = 1;
    }
    {
        int _i_12562;
        _i_12562 = 1;
L3: 
        if (_i_12562 > _7095){
            goto L4; // [55] 79
        }

        /** 		lSum += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12549);
        _7096 = (int)*(((s1_ptr)_2)->base + _i_12562);
        _0 = _lSum_12552;
        if (IS_ATOM_INT(_lSum_12552) && IS_ATOM_INT(_7096)) {
            _lSum_12552 = _lSum_12552 + _7096;
            if ((long)((unsigned long)_lSum_12552 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12552 = NewDouble((double)_lSum_12552);
        }
        else {
            _lSum_12552 = binary_op(PLUS, _lSum_12552, _7096);
        }
        DeRef(_0);
        _7096 = NOVALUE;

        /** 	end for*/
        _i_12562 = _i_12562 + 1;
        goto L3; // [74] 62
L4: 
        ;
    }

    /** 	lMean = lSum / lCnt*/
    DeRef(_lMean_12553);
    if (IS_ATOM_INT(_lSum_12552)) {
        _lMean_12553 = (_lSum_12552 % _lCnt_12554) ? NewDouble((double)_lSum_12552 / _lCnt_12554) : (_lSum_12552 / _lCnt_12554);
    }
    else {
        _lMean_12553 = NewDouble(DBL_PTR(_lSum_12552)->dbl / (double)_lCnt_12554);
    }

    /** 	lSum = 0*/
    DeRef(_lSum_12552);
    _lSum_12552 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12549)){
            _7099 = SEQ_PTR(_data_set_12549)->length;
    }
    else {
        _7099 = 1;
    }
    {
        int _i_12568;
        _i_12568 = 1;
L5: 
        if (_i_12568 > _7099){
            goto L6; // [95] 127
        }

        /** 		lSum += power(data_set[i] - lMean, 2)*/
        _2 = (int)SEQ_PTR(_data_set_12549);
        _7100 = (int)*(((s1_ptr)_2)->base + _i_12568);
        if (IS_ATOM_INT(_7100) && IS_ATOM_INT(_lMean_12553)) {
            _7101 = _7100 - _lMean_12553;
            if ((long)((unsigned long)_7101 +(unsigned long) HIGH_BITS) >= 0){
                _7101 = NewDouble((double)_7101);
            }
        }
        else {
            _7101 = binary_op(MINUS, _7100, _lMean_12553);
        }
        _7100 = NOVALUE;
        if (IS_ATOM_INT(_7101) && IS_ATOM_INT(_7101)) {
            if (_7101 == (short)_7101 && _7101 <= INT15 && _7101 >= -INT15)
            _7102 = _7101 * _7101;
            else
            _7102 = NewDouble(_7101 * (double)_7101);
        }
        else {
            _7102 = binary_op(MULTIPLY, _7101, _7101);
        }
        DeRef(_7101);
        _7101 = NOVALUE;
        _7101 = NOVALUE;
        _0 = _lSum_12552;
        if (IS_ATOM_INT(_lSum_12552) && IS_ATOM_INT(_7102)) {
            _lSum_12552 = _lSum_12552 + _7102;
            if ((long)((unsigned long)_lSum_12552 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12552 = NewDouble((double)_lSum_12552);
        }
        else {
            _lSum_12552 = binary_op(PLUS, _lSum_12552, _7102);
        }
        DeRef(_0);
        DeRef(_7102);
        _7102 = NOVALUE;

        /** 	end for*/
        _i_12568 = _i_12568 + 1;
        goto L5; // [122] 102
L6: 
        ;
    }

    /** 	if population_type = ST_SAMPLE then*/
    if (_population_type_12551 != 2)
    goto L7; // [129] 140

    /** 		lCnt -= 1*/
    _lCnt_12554 = _lCnt_12554 - 1;
L7: 

    /** 	return power(lSum / lCnt, 0.5)*/
    if (IS_ATOM_INT(_lSum_12552)) {
        _7106 = (_lSum_12552 % _lCnt_12554) ? NewDouble((double)_lSum_12552 / _lCnt_12554) : (_lSum_12552 / _lCnt_12554);
    }
    else {
        _7106 = NewDouble(DBL_PTR(_lSum_12552)->dbl / (double)_lCnt_12554);
    }
    if (IS_ATOM_INT(_7106)) {
        temp_d.dbl = (double)_7106;
        _7107 = Dpower(&temp_d, DBL_PTR(_2369));
    }
    else {
        _7107 = Dpower(DBL_PTR(_7106), DBL_PTR(_2369));
    }
    DeRef(_7106);
    _7106 = NOVALUE;
    DeRefDS(_data_set_12549);
    DeRef(_subseq_opt_12550);
    DeRef(_lSum_12552);
    DeRef(_lMean_12553);
    return _7107;
    ;
}


int  __stdcall _35avedev(int _data_set_12581, int _subseq_opt_12582, int _population_type_12583)
{
    int _lSum_12584 = NOVALUE;
    int _lMean_12585 = NOVALUE;
    int _lCnt_12586 = NOVALUE;
    int _7127 = NOVALUE;
    int _7123 = NOVALUE;
    int _7122 = NOVALUE;
    int _7120 = NOVALUE;
    int _7119 = NOVALUE;
    int _7117 = NOVALUE;
    int _7116 = NOVALUE;
    int _7113 = NOVALUE;
    int _7112 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_population_type_12583)) {
        _1 = (long)(DBL_PTR(_population_type_12583)->dbl);
        DeRefDS(_population_type_12583);
        _population_type_12583 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12581);
    Ref(_subseq_opt_12582);
    _0 = _data_set_12581;
    _data_set_12581 = _35massage(_data_set_12581, _subseq_opt_12582);
    DeRefDS(_0);

    /** 	lCnt = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12581)){
            _lCnt_12586 = SEQ_PTR(_data_set_12581)->length;
    }
    else {
        _lCnt_12586 = 1;
    }

    /** 	if lCnt = 0 then*/
    if (_lCnt_12586 != 0)
    goto L1; // [21] 32

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12581);
    DeRef(_subseq_opt_12582);
    DeRef(_lSum_12584);
    DeRef(_lMean_12585);
    return _5;
L1: 

    /** 	if lCnt = 1 then*/
    if (_lCnt_12586 != 1)
    goto L2; // [34] 45

    /** 		return 0*/
    DeRefDS(_data_set_12581);
    DeRef(_subseq_opt_12582);
    DeRef(_lSum_12584);
    DeRef(_lMean_12585);
    return 0;
L2: 

    /** 	lSum = 0*/
    DeRef(_lSum_12584);
    _lSum_12584 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12581)){
            _7112 = SEQ_PTR(_data_set_12581)->length;
    }
    else {
        _7112 = 1;
    }
    {
        int _i_12594;
        _i_12594 = 1;
L3: 
        if (_i_12594 > _7112){
            goto L4; // [55] 79
        }

        /** 		lSum += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12581);
        _7113 = (int)*(((s1_ptr)_2)->base + _i_12594);
        _0 = _lSum_12584;
        if (IS_ATOM_INT(_lSum_12584) && IS_ATOM_INT(_7113)) {
            _lSum_12584 = _lSum_12584 + _7113;
            if ((long)((unsigned long)_lSum_12584 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12584 = NewDouble((double)_lSum_12584);
        }
        else {
            _lSum_12584 = binary_op(PLUS, _lSum_12584, _7113);
        }
        DeRef(_0);
        _7113 = NOVALUE;

        /** 	end for*/
        _i_12594 = _i_12594 + 1;
        goto L3; // [74] 62
L4: 
        ;
    }

    /** 	lMean = lSum / lCnt*/
    DeRef(_lMean_12585);
    if (IS_ATOM_INT(_lSum_12584)) {
        _lMean_12585 = (_lSum_12584 % _lCnt_12586) ? NewDouble((double)_lSum_12584 / _lCnt_12586) : (_lSum_12584 / _lCnt_12586);
    }
    else {
        _lMean_12585 = NewDouble(DBL_PTR(_lSum_12584)->dbl / (double)_lCnt_12586);
    }

    /** 	lSum = 0*/
    DeRef(_lSum_12584);
    _lSum_12584 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12581)){
            _7116 = SEQ_PTR(_data_set_12581)->length;
    }
    else {
        _7116 = 1;
    }
    {
        int _i_12600;
        _i_12600 = 1;
L5: 
        if (_i_12600 > _7116){
            goto L6; // [95] 151
        }

        /** 		if data_set[i] > lMean then*/
        _2 = (int)SEQ_PTR(_data_set_12581);
        _7117 = (int)*(((s1_ptr)_2)->base + _i_12600);
        if (binary_op_a(LESSEQ, _7117, _lMean_12585)){
            _7117 = NOVALUE;
            goto L7; // [108] 129
        }
        _7117 = NOVALUE;

        /** 			lSum += data_set[i] - lMean*/
        _2 = (int)SEQ_PTR(_data_set_12581);
        _7119 = (int)*(((s1_ptr)_2)->base + _i_12600);
        if (IS_ATOM_INT(_7119) && IS_ATOM_INT(_lMean_12585)) {
            _7120 = _7119 - _lMean_12585;
            if ((long)((unsigned long)_7120 +(unsigned long) HIGH_BITS) >= 0){
                _7120 = NewDouble((double)_7120);
            }
        }
        else {
            _7120 = binary_op(MINUS, _7119, _lMean_12585);
        }
        _7119 = NOVALUE;
        _0 = _lSum_12584;
        if (IS_ATOM_INT(_lSum_12584) && IS_ATOM_INT(_7120)) {
            _lSum_12584 = _lSum_12584 + _7120;
            if ((long)((unsigned long)_lSum_12584 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12584 = NewDouble((double)_lSum_12584);
        }
        else {
            _lSum_12584 = binary_op(PLUS, _lSum_12584, _7120);
        }
        DeRef(_0);
        DeRef(_7120);
        _7120 = NOVALUE;
        goto L8; // [126] 144
L7: 

        /** 			lSum += lMean - data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12581);
        _7122 = (int)*(((s1_ptr)_2)->base + _i_12600);
        if (IS_ATOM_INT(_lMean_12585) && IS_ATOM_INT(_7122)) {
            _7123 = _lMean_12585 - _7122;
            if ((long)((unsigned long)_7123 +(unsigned long) HIGH_BITS) >= 0){
                _7123 = NewDouble((double)_7123);
            }
        }
        else {
            _7123 = binary_op(MINUS, _lMean_12585, _7122);
        }
        _7122 = NOVALUE;
        _0 = _lSum_12584;
        if (IS_ATOM_INT(_lSum_12584) && IS_ATOM_INT(_7123)) {
            _lSum_12584 = _lSum_12584 + _7123;
            if ((long)((unsigned long)_lSum_12584 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12584 = NewDouble((double)_lSum_12584);
        }
        else {
            _lSum_12584 = binary_op(PLUS, _lSum_12584, _7123);
        }
        DeRef(_0);
        DeRef(_7123);
        _7123 = NOVALUE;
L8: 

        /** 	end for*/
        _i_12600 = _i_12600 + 1;
        goto L5; // [146] 102
L6: 
        ;
    }

    /** 	if population_type = ST_SAMPLE then*/
    if (_population_type_12583 != 2)
    goto L9; // [153] 164

    /** 		lCnt -= 1*/
    _lCnt_12586 = _lCnt_12586 - 1;
L9: 

    /** 	return lSum / lCnt*/
    if (IS_ATOM_INT(_lSum_12584)) {
        _7127 = (_lSum_12584 % _lCnt_12586) ? NewDouble((double)_lSum_12584 / _lCnt_12586) : (_lSum_12584 / _lCnt_12586);
    }
    else {
        _7127 = NewDouble(DBL_PTR(_lSum_12584)->dbl / (double)_lCnt_12586);
    }
    DeRefDS(_data_set_12581);
    DeRef(_subseq_opt_12582);
    DeRef(_lSum_12584);
    DeRef(_lMean_12585);
    return _7127;
    ;
}


int  __stdcall _35sum(int _data_set_12618, int _subseq_opt_12619)
{
    int _result__12620 = NOVALUE;
    int _7131 = NOVALUE;
    int _7130 = NOVALUE;
    int _7128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7128 = IS_ATOM(_data_set_12618);
    if (_7128 == 0)
    {
        _7128 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7128 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12619);
    DeRef(_result__12620);
    return _data_set_12618;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12618);
    Ref(_subseq_opt_12619);
    _0 = _data_set_12618;
    _data_set_12618 = _35massage(_data_set_12618, _subseq_opt_12619);
    DeRef(_0);

    /** 	result_ = 0*/
    DeRef(_result__12620);
    _result__12620 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12618)){
            _7130 = SEQ_PTR(_data_set_12618)->length;
    }
    else {
        _7130 = 1;
    }
    {
        int _i_12625;
        _i_12625 = 1;
L2: 
        if (_i_12625 > _7130){
            goto L3; // [33] 57
        }

        /** 		result_ += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12618);
        _7131 = (int)*(((s1_ptr)_2)->base + _i_12625);
        _0 = _result__12620;
        if (IS_ATOM_INT(_result__12620) && IS_ATOM_INT(_7131)) {
            _result__12620 = _result__12620 + _7131;
            if ((long)((unsigned long)_result__12620 + (unsigned long)HIGH_BITS) >= 0) 
            _result__12620 = NewDouble((double)_result__12620);
        }
        else {
            _result__12620 = binary_op(PLUS, _result__12620, _7131);
        }
        DeRef(_0);
        _7131 = NOVALUE;

        /** 	end for*/
        _i_12625 = _i_12625 + 1;
        goto L2; // [52] 40
L3: 
        ;
    }

    /** 	return result_*/
    DeRef(_data_set_12618);
    DeRef(_subseq_opt_12619);
    return _result__12620;
    ;
}


int  __stdcall _35count(int _data_set_12631, int _subseq_opt_12632)
{
    int _7135 = NOVALUE;
    int _7134 = NOVALUE;
    int _7133 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7133 = IS_ATOM(_data_set_12631);
    if (_7133 == 0)
    {
        _7133 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7133 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_data_set_12631);
    DeRef(_subseq_opt_12632);
    return 1;
L1: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12631);
    Ref(_subseq_opt_12632);
    _7134 = _35massage(_data_set_12631, _subseq_opt_12632);
    if (IS_SEQUENCE(_7134)){
            _7135 = SEQ_PTR(_7134)->length;
    }
    else {
        _7135 = 1;
    }
    DeRef(_7134);
    _7134 = NOVALUE;
    DeRef(_data_set_12631);
    DeRef(_subseq_opt_12632);
    _7134 = NOVALUE;
    return _7135;
    ;
}


int  __stdcall _35average(int _data_set_12639, int _subseq_opt_12640)
{
    int _7142 = NOVALUE;
    int _7141 = NOVALUE;
    int _7140 = NOVALUE;
    int _7138 = NOVALUE;
    int _7136 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7136 = IS_ATOM(_data_set_12639);
    if (_7136 == 0)
    {
        _7136 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7136 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12640);
    return _data_set_12639;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12639);
    Ref(_subseq_opt_12640);
    _0 = _data_set_12639;
    _data_set_12639 = _35massage(_data_set_12639, _subseq_opt_12640);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12639)){
            _7138 = SEQ_PTR(_data_set_12639)->length;
    }
    else {
        _7138 = 1;
    }
    if (_7138 != 0)
    goto L2; // [28] 39

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12639);
    DeRef(_subseq_opt_12640);
    return _5;
L2: 

    /** 	return sum(data_set) / length(data_set)*/
    Ref(_data_set_12639);
    _7140 = _35sum(_data_set_12639, 1);
    if (IS_SEQUENCE(_data_set_12639)){
            _7141 = SEQ_PTR(_data_set_12639)->length;
    }
    else {
        _7141 = 1;
    }
    if (IS_ATOM_INT(_7140)) {
        _7142 = (_7140 % _7141) ? NewDouble((double)_7140 / _7141) : (_7140 / _7141);
    }
    else {
        _7142 = binary_op(DIVIDE, _7140, _7141);
    }
    DeRef(_7140);
    _7140 = NOVALUE;
    _7141 = NOVALUE;
    DeRef(_data_set_12639);
    DeRef(_subseq_opt_12640);
    return _7142;
    ;
}


int  __stdcall _35geomean(int _data_set_12652, int _subseq_opt_12653)
{
    int _prod__12654 = NOVALUE;
    int _count__12655 = NOVALUE;
    int _x_12668 = NOVALUE;
    int _7158 = NOVALUE;
    int _7157 = NOVALUE;
    int _7156 = NOVALUE;
    int _7155 = NOVALUE;
    int _7154 = NOVALUE;
    int _7149 = NOVALUE;
    int _7148 = NOVALUE;
    int _7143 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom prod_ = 1.0*/
    RefDS(_2236);
    DeRef(_prod__12654);
    _prod__12654 = _2236;

    /** 	if atom(data_set) then*/
    _7143 = IS_ATOM(_data_set_12652);
    if (_7143 == 0)
    {
        _7143 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _7143 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12653);
    DeRefDS(_prod__12654);
    return _data_set_12652;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12652);
    Ref(_subseq_opt_12653);
    _0 = _data_set_12652;
    _data_set_12652 = _35massage(_data_set_12652, _subseq_opt_12653);
    DeRef(_0);

    /** 	count_ = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12652)){
            _count__12655 = SEQ_PTR(_data_set_12652)->length;
    }
    else {
        _count__12655 = 1;
    }

    /** 	if count_ = 0 then*/
    if (_count__12655 != 0)
    goto L2; // [35] 46

    /** 		return 1*/
    DeRef(_data_set_12652);
    DeRef(_subseq_opt_12653);
    DeRef(_prod__12654);
    return 1;
L2: 

    /** 	if count_ = 1 then*/
    if (_count__12655 != 1)
    goto L3; // [48] 63

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12652);
    _7148 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7148);
    DeRef(_data_set_12652);
    DeRef(_subseq_opt_12653);
    DeRef(_prod__12654);
    return _7148;
L3: 

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12652)){
            _7149 = SEQ_PTR(_data_set_12652)->length;
    }
    else {
        _7149 = 1;
    }
    {
        int _i_12666;
        _i_12666 = 1;
L4: 
        if (_i_12666 > _7149){
            goto L5; // [68] 112
        }

        /** 		atom x = data_set[i]*/
        DeRef(_x_12668);
        _2 = (int)SEQ_PTR(_data_set_12652);
        _x_12668 = (int)*(((s1_ptr)_2)->base + _i_12666);
        Ref(_x_12668);

        /** 	    if x = 0 then*/
        if (binary_op_a(NOTEQ, _x_12668, 0)){
            goto L6; // [83] 96
        }

        /** 	        return 0*/
        DeRef(_x_12668);
        DeRef(_data_set_12652);
        DeRef(_subseq_opt_12653);
        DeRef(_prod__12654);
        _7148 = NOVALUE;
        return 0;
        goto L7; // [93] 103
L6: 

        /** 		    prod_ *= x*/
        _0 = _prod__12654;
        if (IS_ATOM_INT(_prod__12654) && IS_ATOM_INT(_x_12668)) {
            if (_prod__12654 == (short)_prod__12654 && _x_12668 <= INT15 && _x_12668 >= -INT15)
            _prod__12654 = _prod__12654 * _x_12668;
            else
            _prod__12654 = NewDouble(_prod__12654 * (double)_x_12668);
        }
        else {
            if (IS_ATOM_INT(_prod__12654)) {
                _prod__12654 = NewDouble((double)_prod__12654 * DBL_PTR(_x_12668)->dbl);
            }
            else {
                if (IS_ATOM_INT(_x_12668)) {
                    _prod__12654 = NewDouble(DBL_PTR(_prod__12654)->dbl * (double)_x_12668);
                }
                else
                _prod__12654 = NewDouble(DBL_PTR(_prod__12654)->dbl * DBL_PTR(_x_12668)->dbl);
            }
        }
        DeRef(_0);
L7: 
        DeRef(_x_12668);
        _x_12668 = NOVALUE;

        /** 	end for*/
        _i_12666 = _i_12666 + 1;
        goto L4; // [107] 75
L5: 
        ;
    }

    /** 	if prod_ < 0 then*/
    if (binary_op_a(GREATEREQ, _prod__12654, 0)){
        goto L8; // [114] 138
    }

    /** 		return power(-prod_, 1/count_)*/
    if (IS_ATOM_INT(_prod__12654)) {
        if ((unsigned long)_prod__12654 == 0xC0000000)
        _7154 = (int)NewDouble((double)-0xC0000000);
        else
        _7154 = - _prod__12654;
    }
    else {
        _7154 = unary_op(UMINUS, _prod__12654);
    }
    _7155 = (1 % _count__12655) ? NewDouble((double)1 / _count__12655) : (1 / _count__12655);
    if (IS_ATOM_INT(_7154) && IS_ATOM_INT(_7155)) {
        _7156 = power(_7154, _7155);
    }
    else {
        if (IS_ATOM_INT(_7154)) {
            temp_d.dbl = (double)_7154;
            _7156 = Dpower(&temp_d, DBL_PTR(_7155));
        }
        else {
            if (IS_ATOM_INT(_7155)) {
                temp_d.dbl = (double)_7155;
                _7156 = Dpower(DBL_PTR(_7154), &temp_d);
            }
            else
            _7156 = Dpower(DBL_PTR(_7154), DBL_PTR(_7155));
        }
    }
    DeRef(_7154);
    _7154 = NOVALUE;
    DeRef(_7155);
    _7155 = NOVALUE;
    DeRef(_data_set_12652);
    DeRef(_subseq_opt_12653);
    DeRef(_prod__12654);
    _7148 = NOVALUE;
    return _7156;
    goto L9; // [135] 153
L8: 

    /** 		return power(prod_, 1/count_)*/
    _7157 = (1 % _count__12655) ? NewDouble((double)1 / _count__12655) : (1 / _count__12655);
    if (IS_ATOM_INT(_prod__12654) && IS_ATOM_INT(_7157)) {
        _7158 = power(_prod__12654, _7157);
    }
    else {
        if (IS_ATOM_INT(_prod__12654)) {
            temp_d.dbl = (double)_prod__12654;
            _7158 = Dpower(&temp_d, DBL_PTR(_7157));
        }
        else {
            if (IS_ATOM_INT(_7157)) {
                temp_d.dbl = (double)_7157;
                _7158 = Dpower(DBL_PTR(_prod__12654), &temp_d);
            }
            else
            _7158 = Dpower(DBL_PTR(_prod__12654), DBL_PTR(_7157));
        }
    }
    DeRef(_7157);
    _7157 = NOVALUE;
    DeRef(_data_set_12652);
    DeRef(_subseq_opt_12653);
    DeRef(_prod__12654);
    _7148 = NOVALUE;
    DeRef(_7156);
    _7156 = NOVALUE;
    return _7158;
L9: 
    ;
}


int  __stdcall _35harmean(int _data_set_12684, int _subseq_opt_12685)
{
    int _count__12686 = NOVALUE;
    int _y_12692 = NOVALUE;
    int _z_12693 = NOVALUE;
    int _x_12697 = NOVALUE;
    int _7173 = NOVALUE;
    int _7172 = NOVALUE;
    int _7168 = NOVALUE;
    int _7166 = NOVALUE;
    int _7164 = NOVALUE;
    int _7163 = NOVALUE;
    int _7162 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12684);
    Ref(_subseq_opt_12685);
    _0 = _data_set_12684;
    _data_set_12684 = _35massage(_data_set_12684, _subseq_opt_12685);
    DeRefDS(_0);

    /** 	count_ = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12684)){
            _count__12686 = SEQ_PTR(_data_set_12684)->length;
    }
    else {
        _count__12686 = 1;
    }

    /** 	if count_ = 1 then*/
    if (_count__12686 != 1)
    goto L1; // [19] 34

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12684);
    _7162 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7162);
    DeRefDS(_data_set_12684);
    DeRef(_subseq_opt_12685);
    DeRef(_y_12692);
    DeRef(_z_12693);
    return _7162;
L1: 

    /** 	atom y = 0*/
    DeRef(_y_12692);
    _y_12692 = 0;

    /** 	atom z = 1*/
    DeRef(_z_12693);
    _z_12693 = 1;

    /** 	for i = 1 to count_ do*/
    _7163 = _count__12686;
    {
        int _i_12695;
        _i_12695 = 1;
L2: 
        if (_i_12695 > _7163){
            goto L3; // [49] 122
        }

        /** 		atom x = 1*/
        DeRef(_x_12697);
        _x_12697 = 1;

        /** 		z *= data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12684);
        _7164 = (int)*(((s1_ptr)_2)->base + _i_12695);
        _0 = _z_12693;
        if (IS_ATOM_INT(_z_12693) && IS_ATOM_INT(_7164)) {
            if (_z_12693 == (short)_z_12693 && _7164 <= INT15 && _7164 >= -INT15)
            _z_12693 = _z_12693 * _7164;
            else
            _z_12693 = NewDouble(_z_12693 * (double)_7164);
        }
        else {
            _z_12693 = binary_op(MULTIPLY, _z_12693, _7164);
        }
        DeRef(_0);
        _7164 = NOVALUE;

        /** 		for j = 1 to count_ do*/
        _7166 = _count__12686;
        {
            int _j_12701;
            _j_12701 = 1;
L4: 
            if (_j_12701 > _7166){
                goto L5; // [76] 107
            }

            /** 			if j != i then*/
            if (_j_12701 == _i_12695)
            goto L6; // [85] 100

            /** 				x *= data_set[j]*/
            _2 = (int)SEQ_PTR(_data_set_12684);
            _7168 = (int)*(((s1_ptr)_2)->base + _j_12701);
            _0 = _x_12697;
            if (IS_ATOM_INT(_x_12697) && IS_ATOM_INT(_7168)) {
                if (_x_12697 == (short)_x_12697 && _7168 <= INT15 && _7168 >= -INT15)
                _x_12697 = _x_12697 * _7168;
                else
                _x_12697 = NewDouble(_x_12697 * (double)_7168);
            }
            else {
                _x_12697 = binary_op(MULTIPLY, _x_12697, _7168);
            }
            DeRef(_0);
            _7168 = NOVALUE;
L6: 

            /** 		end for*/
            _j_12701 = _j_12701 + 1;
            goto L4; // [102] 83
L5: 
            ;
        }

        /** 		y += x*/
        _0 = _y_12692;
        if (IS_ATOM_INT(_y_12692) && IS_ATOM_INT(_x_12697)) {
            _y_12692 = _y_12692 + _x_12697;
            if ((long)((unsigned long)_y_12692 + (unsigned long)HIGH_BITS) >= 0) 
            _y_12692 = NewDouble((double)_y_12692);
        }
        else {
            if (IS_ATOM_INT(_y_12692)) {
                _y_12692 = NewDouble((double)_y_12692 + DBL_PTR(_x_12697)->dbl);
            }
            else {
                if (IS_ATOM_INT(_x_12697)) {
                    _y_12692 = NewDouble(DBL_PTR(_y_12692)->dbl + (double)_x_12697);
                }
                else
                _y_12692 = NewDouble(DBL_PTR(_y_12692)->dbl + DBL_PTR(_x_12697)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_x_12697);
        _x_12697 = NOVALUE;

        /** 	end for*/
        _i_12695 = _i_12695 + 1;
        goto L2; // [117] 56
L3: 
        ;
    }

    /**  	if y = 0 then*/
    if (binary_op_a(NOTEQ, _y_12692, 0)){
        goto L7; // [124] 135
    }

    /**  		return 0*/
    DeRefDS(_data_set_12684);
    DeRef(_subseq_opt_12685);
    DeRef(_y_12692);
    DeRef(_z_12693);
    _7162 = NOVALUE;
    return 0;
L7: 

    /**  	return count_ * z / y*/
    if (IS_ATOM_INT(_z_12693)) {
        if (_count__12686 == (short)_count__12686 && _z_12693 <= INT15 && _z_12693 >= -INT15)
        _7172 = _count__12686 * _z_12693;
        else
        _7172 = NewDouble(_count__12686 * (double)_z_12693);
    }
    else {
        _7172 = NewDouble((double)_count__12686 * DBL_PTR(_z_12693)->dbl);
    }
    if (IS_ATOM_INT(_7172) && IS_ATOM_INT(_y_12692)) {
        _7173 = (_7172 % _y_12692) ? NewDouble((double)_7172 / _y_12692) : (_7172 / _y_12692);
    }
    else {
        if (IS_ATOM_INT(_7172)) {
            _7173 = NewDouble((double)_7172 / DBL_PTR(_y_12692)->dbl);
        }
        else {
            if (IS_ATOM_INT(_y_12692)) {
                _7173 = NewDouble(DBL_PTR(_7172)->dbl / (double)_y_12692);
            }
            else
            _7173 = NewDouble(DBL_PTR(_7172)->dbl / DBL_PTR(_y_12692)->dbl);
        }
    }
    DeRef(_7172);
    _7172 = NOVALUE;
    DeRefDS(_data_set_12684);
    DeRef(_subseq_opt_12685);
    DeRef(_y_12692);
    DeRef(_z_12693);
    _7162 = NOVALUE;
    return _7173;
    ;
}


int  __stdcall _35movavg(int _data_set_12714, int _period_delta_12715)
{
    int _result__12716 = NOVALUE;
    int _lLow_12717 = NOVALUE;
    int _lHigh_12718 = NOVALUE;
    int _j_12719 = NOVALUE;
    int _n_12720 = NOVALUE;
    int _count_2__tmp_at19_12728 = NOVALUE;
    int _count_1__tmp_at19_12727 = NOVALUE;
    int _count_inlined_count_at_19_12726 = NOVALUE;
    int _7210 = NOVALUE;
    int _7209 = NOVALUE;
    int _7205 = NOVALUE;
    int _7204 = NOVALUE;
    int _7203 = NOVALUE;
    int _7202 = NOVALUE;
    int _7201 = NOVALUE;
    int _7200 = NOVALUE;
    int _7199 = NOVALUE;
    int _7198 = NOVALUE;
    int _7196 = NOVALUE;
    int _7194 = NOVALUE;
    int _7193 = NOVALUE;
    int _7192 = NOVALUE;
    int _7191 = NOVALUE;
    int _7188 = NOVALUE;
    int _7187 = NOVALUE;
    int _7186 = NOVALUE;
    int _7185 = NOVALUE;
    int _7183 = NOVALUE;
    int _7182 = NOVALUE;
    int _7180 = NOVALUE;
    int _7178 = NOVALUE;
    int _7177 = NOVALUE;
    int _7174 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7174 = IS_ATOM(_data_set_12714);
    if (_7174 == 0)
    {
        _7174 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _7174 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12714;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12714);
    *((int *)(_2+4)) = _data_set_12714;
    _data_set_12714 = MAKE_SEQ(_1);
    DeRef(_0);
    goto L2; // [15] 61
L1: 

    /** 	elsif count(data_set) = 0 then*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at19_12727 = IS_ATOM(_data_set_12714);
    if (_count_1__tmp_at19_12727 == 0)
    {
        goto L3; // [25] 36
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_19_12726 = 1;
    goto L4; // [33] 47
L3: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12714);
    _0 = _count_2__tmp_at19_12728;
    _count_2__tmp_at19_12728 = _35massage(_data_set_12714, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at19_12728)){
            _count_inlined_count_at_19_12726 = SEQ_PTR(_count_2__tmp_at19_12728)->length;
    }
    else {
        _count_inlined_count_at_19_12726 = 1;
    }
L4: 
    DeRef(_count_2__tmp_at19_12728);
    _count_2__tmp_at19_12728 = NOVALUE;
    if (_count_inlined_count_at_19_12726 != 0)
    goto L5; // [49] 60

    /** 		return data_set*/
    DeRef(_period_delta_12715);
    DeRef(_result__12716);
    return _data_set_12714;
L5: 
L2: 

    /** 	if atom(period_delta) then*/
    _7177 = IS_ATOM(_period_delta_12715);
    if (_7177 == 0)
    {
        _7177 = NOVALUE;
        goto L6; // [66] 95
    }
    else{
        _7177 = NOVALUE;
    }

    /** 		if floor(period_delta) < 1 then*/
    if (IS_ATOM_INT(_period_delta_12715))
    _7178 = e_floor(_period_delta_12715);
    else
    _7178 = unary_op(FLOOR, _period_delta_12715);
    if (binary_op_a(GREATEREQ, _7178, 1)){
        DeRef(_7178);
        _7178 = NOVALUE;
        goto L7; // [74] 85
    }
    DeRef(_7178);
    _7178 = NOVALUE;

    /** 			return {}*/
    RefDS(_5);
    DeRef(_data_set_12714);
    DeRef(_period_delta_12715);
    DeRef(_result__12716);
    return _5;
L7: 

    /** 		period_delta = repeat(1, floor(period_delta))*/
    if (IS_ATOM_INT(_period_delta_12715))
    _7180 = e_floor(_period_delta_12715);
    else
    _7180 = unary_op(FLOOR, _period_delta_12715);
    DeRef(_period_delta_12715);
    _period_delta_12715 = Repeat(1, _7180);
    DeRef(_7180);
    _7180 = NOVALUE;
L6: 

    /** 	if length(data_set) < length(period_delta) then*/
    if (IS_SEQUENCE(_data_set_12714)){
            _7182 = SEQ_PTR(_data_set_12714)->length;
    }
    else {
        _7182 = 1;
    }
    if (IS_SEQUENCE(_period_delta_12715)){
            _7183 = SEQ_PTR(_period_delta_12715)->length;
    }
    else {
        _7183 = 1;
    }
    if (_7182 >= _7183)
    goto L8; // [103] 128

    /** 		data_set = repeat(0, length(period_delta) - length(data_set)) & data_set*/
    if (IS_SEQUENCE(_period_delta_12715)){
            _7185 = SEQ_PTR(_period_delta_12715)->length;
    }
    else {
        _7185 = 1;
    }
    if (IS_SEQUENCE(_data_set_12714)){
            _7186 = SEQ_PTR(_data_set_12714)->length;
    }
    else {
        _7186 = 1;
    }
    _7187 = _7185 - _7186;
    _7185 = NOVALUE;
    _7186 = NOVALUE;
    _7188 = Repeat(0, _7187);
    _7187 = NOVALUE;
    if (IS_SEQUENCE(_7188) && IS_ATOM(_data_set_12714)) {
        Ref(_data_set_12714);
        Append(&_data_set_12714, _7188, _data_set_12714);
    }
    else if (IS_ATOM(_7188) && IS_SEQUENCE(_data_set_12714)) {
    }
    else {
        Concat((object_ptr)&_data_set_12714, _7188, _data_set_12714);
        DeRefDS(_7188);
        _7188 = NOVALUE;
    }
    DeRef(_7188);
    _7188 = NOVALUE;
L8: 

    /** 	lLow = 1*/
    _lLow_12717 = 1;

    /** 	lHigh = length(period_delta)*/
    if (IS_SEQUENCE(_period_delta_12715)){
            _lHigh_12718 = SEQ_PTR(_period_delta_12715)->length;
    }
    else {
        _lHigh_12718 = 1;
    }

    /** 	result_ = repeat(0, length(data_set) - length(period_delta) + 1)*/
    if (IS_SEQUENCE(_data_set_12714)){
            _7191 = SEQ_PTR(_data_set_12714)->length;
    }
    else {
        _7191 = 1;
    }
    if (IS_SEQUENCE(_period_delta_12715)){
            _7192 = SEQ_PTR(_period_delta_12715)->length;
    }
    else {
        _7192 = 1;
    }
    _7193 = _7191 - _7192;
    _7191 = NOVALUE;
    _7192 = NOVALUE;
    _7194 = _7193 + 1;
    _7193 = NOVALUE;
    DeRef(_result__12716);
    _result__12716 = Repeat(0, _7194);
    _7194 = NOVALUE;

    /** 	while lHigh <= length(data_set) do*/
L9: 
    if (IS_SEQUENCE(_data_set_12714)){
            _7196 = SEQ_PTR(_data_set_12714)->length;
    }
    else {
        _7196 = 1;
    }
    if (_lHigh_12718 > _7196)
    goto LA; // [166] 297

    /** 		j = 1*/
    _j_12719 = 1;

    /** 		n = 0*/
    _n_12720 = 0;

    /** 		for i = lLow to lHigh do*/
    _7198 = _lHigh_12718;
    {
        int _i_12756;
        _i_12756 = _lLow_12717;
LB: 
        if (_i_12756 > _7198){
            goto LC; // [185] 250
        }

        /** 			if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12714);
        _7199 = (int)*(((s1_ptr)_2)->base + _i_12756);
        _7200 = IS_ATOM(_7199);
        _7199 = NOVALUE;
        if (_7200 == 0)
        {
            _7200 = NOVALUE;
            goto LD; // [201] 237
        }
        else{
            _7200 = NOVALUE;
        }

        /** 				result_[lLow] += data_set[i] * period_delta[j]*/
        _2 = (int)SEQ_PTR(_data_set_12714);
        _7201 = (int)*(((s1_ptr)_2)->base + _i_12756);
        _2 = (int)SEQ_PTR(_period_delta_12715);
        _7202 = (int)*(((s1_ptr)_2)->base + _j_12719);
        if (IS_ATOM_INT(_7201) && IS_ATOM_INT(_7202)) {
            if (_7201 == (short)_7201 && _7202 <= INT15 && _7202 >= -INT15)
            _7203 = _7201 * _7202;
            else
            _7203 = NewDouble(_7201 * (double)_7202);
        }
        else {
            _7203 = binary_op(MULTIPLY, _7201, _7202);
        }
        _7201 = NOVALUE;
        _7202 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__12716);
        _7204 = (int)*(((s1_ptr)_2)->base + _lLow_12717);
        if (IS_ATOM_INT(_7204) && IS_ATOM_INT(_7203)) {
            _7205 = _7204 + _7203;
            if ((long)((unsigned long)_7205 + (unsigned long)HIGH_BITS) >= 0) 
            _7205 = NewDouble((double)_7205);
        }
        else {
            _7205 = binary_op(PLUS, _7204, _7203);
        }
        _7204 = NOVALUE;
        DeRef(_7203);
        _7203 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__12716);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12716 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lLow_12717);
        _1 = *(int *)_2;
        *(int *)_2 = _7205;
        if( _1 != _7205 ){
            DeRef(_1);
        }
        _7205 = NOVALUE;

        /** 				n += 1*/
        _n_12720 = _n_12720 + 1;
LD: 

        /** 			j += 1*/
        _j_12719 = _j_12719 + 1;

        /** 		end for*/
        _i_12756 = _i_12756 + 1;
        goto LB; // [245] 192
LC: 
        ;
    }

    /** 		if n > 0 then*/
    if (_n_12720 <= 0)
    goto LE; // [252] 273

    /** 			result_[lLow] /= n*/
    _2 = (int)SEQ_PTR(_result__12716);
    _7209 = (int)*(((s1_ptr)_2)->base + _lLow_12717);
    if (IS_ATOM_INT(_7209)) {
        _7210 = (_7209 % _n_12720) ? NewDouble((double)_7209 / _n_12720) : (_7209 / _n_12720);
    }
    else {
        _7210 = binary_op(DIVIDE, _7209, _n_12720);
    }
    _7209 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12716);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12716 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lLow_12717);
    _1 = *(int *)_2;
    *(int *)_2 = _7210;
    if( _1 != _7210 ){
        DeRef(_1);
    }
    _7210 = NOVALUE;
    goto LF; // [270] 280
LE: 

    /** 			result_[lLow] = 0*/
    _2 = (int)SEQ_PTR(_result__12716);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12716 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lLow_12717);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
LF: 

    /** 		lLow += 1*/
    _lLow_12717 = _lLow_12717 + 1;

    /** 		lHigh += 1*/
    _lHigh_12718 = _lHigh_12718 + 1;

    /** 	end while*/
    goto L9; // [294] 163
LA: 

    /** 	return result_*/
    DeRef(_data_set_12714);
    DeRef(_period_delta_12715);
    return _result__12716;
    ;
}


int  __stdcall _35emovavg(int _data_set_12777, int _smoothing_factor_12778)
{
    int _lPrev_12779 = NOVALUE;
    int _count_2__tmp_at19_12787 = NOVALUE;
    int _count_1__tmp_at19_12786 = NOVALUE;
    int _count_inlined_count_at_19_12785 = NOVALUE;
    int _count_2__tmp_at81_12796 = NOVALUE;
    int _count_1__tmp_at81_12795 = NOVALUE;
    int _count_inlined_count_at_81_12794 = NOVALUE;
    int _7228 = NOVALUE;
    int _7227 = NOVALUE;
    int _7226 = NOVALUE;
    int _7225 = NOVALUE;
    int _7224 = NOVALUE;
    int _7223 = NOVALUE;
    int _7222 = NOVALUE;
    int _7219 = NOVALUE;
    int _7218 = NOVALUE;
    int _7216 = NOVALUE;
    int _7213 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7213 = IS_ATOM(_data_set_12777);
    if (_7213 == 0)
    {
        _7213 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _7213 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12777;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12777);
    *((int *)(_2+4)) = _data_set_12777;
    _data_set_12777 = MAKE_SEQ(_1);
    DeRef(_0);
    goto L2; // [15] 61
L1: 

    /** 	elsif count(data_set) = 0 then*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at19_12786 = IS_ATOM(_data_set_12777);
    if (_count_1__tmp_at19_12786 == 0)
    {
        goto L3; // [25] 36
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_19_12785 = 1;
    goto L4; // [33] 47
L3: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12777);
    _0 = _count_2__tmp_at19_12787;
    _count_2__tmp_at19_12787 = _35massage(_data_set_12777, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at19_12787)){
            _count_inlined_count_at_19_12785 = SEQ_PTR(_count_2__tmp_at19_12787)->length;
    }
    else {
        _count_inlined_count_at_19_12785 = 1;
    }
L4: 
    DeRef(_count_2__tmp_at19_12787);
    _count_2__tmp_at19_12787 = NOVALUE;
    if (_count_inlined_count_at_19_12785 != 0)
    goto L5; // [49] 60

    /** 		return data_set*/
    DeRef(_smoothing_factor_12778);
    DeRef(_lPrev_12779);
    return _data_set_12777;
L5: 
L2: 

    /** 	if smoothing_factor < 0 or smoothing_factor > 1 then*/
    if (IS_ATOM_INT(_smoothing_factor_12778)) {
        _7216 = (_smoothing_factor_12778 < 0);
    }
    else {
        _7216 = (DBL_PTR(_smoothing_factor_12778)->dbl < (double)0);
    }
    if (_7216 != 0) {
        goto L6; // [67] 80
    }
    if (IS_ATOM_INT(_smoothing_factor_12778)) {
        _7218 = (_smoothing_factor_12778 > 1);
    }
    else {
        _7218 = (DBL_PTR(_smoothing_factor_12778)->dbl > (double)1);
    }
    if (_7218 == 0)
    {
        DeRef(_7218);
        _7218 = NOVALUE;
        goto L7; // [76] 120
    }
    else{
        DeRef(_7218);
        _7218 = NOVALUE;
    }
L6: 

    /** 		smoothing_factor = (2 / (count(data_set) + 1))*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at81_12795 = IS_ATOM(_data_set_12777);
    if (_count_1__tmp_at81_12795 == 0)
    {
        goto L8; // [87] 98
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_81_12794 = 1;
    goto L9; // [95] 109
L8: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12777);
    _0 = _count_2__tmp_at81_12796;
    _count_2__tmp_at81_12796 = _35massage(_data_set_12777, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at81_12796)){
            _count_inlined_count_at_81_12794 = SEQ_PTR(_count_2__tmp_at81_12796)->length;
    }
    else {
        _count_inlined_count_at_81_12794 = 1;
    }
L9: 
    DeRef(_count_2__tmp_at81_12796);
    _count_2__tmp_at81_12796 = NOVALUE;
    _7219 = _count_inlined_count_at_81_12794 + 1;
    DeRef(_smoothing_factor_12778);
    _smoothing_factor_12778 = (2 % _7219) ? NewDouble((double)2 / _7219) : (2 / _7219);
    _7219 = NOVALUE;
L7: 

    /** 	lPrev = average(data_set)*/
    Ref(_data_set_12777);
    _0 = _lPrev_12779;
    _lPrev_12779 = _35average(_data_set_12777, 1);
    DeRef(_0);

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12777)){
            _7222 = SEQ_PTR(_data_set_12777)->length;
    }
    else {
        _7222 = 1;
    }
    {
        int _i_12801;
        _i_12801 = 1;
LA: 
        if (_i_12801 > _7222){
            goto LB; // [132] 187
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12777);
        _7223 = (int)*(((s1_ptr)_2)->base + _i_12801);
        _7224 = IS_ATOM(_7223);
        _7223 = NOVALUE;
        if (_7224 == 0)
        {
            _7224 = NOVALUE;
            goto LC; // [148] 180
        }
        else{
            _7224 = NOVALUE;
        }

        /** 			data_set[i] = (data_set[i] - lPrev) * smoothing_factor + lPrev*/
        _2 = (int)SEQ_PTR(_data_set_12777);
        _7225 = (int)*(((s1_ptr)_2)->base + _i_12801);
        if (IS_ATOM_INT(_7225) && IS_ATOM_INT(_lPrev_12779)) {
            _7226 = _7225 - _lPrev_12779;
            if ((long)((unsigned long)_7226 +(unsigned long) HIGH_BITS) >= 0){
                _7226 = NewDouble((double)_7226);
            }
        }
        else {
            _7226 = binary_op(MINUS, _7225, _lPrev_12779);
        }
        _7225 = NOVALUE;
        if (IS_ATOM_INT(_7226) && IS_ATOM_INT(_smoothing_factor_12778)) {
            if (_7226 == (short)_7226 && _smoothing_factor_12778 <= INT15 && _smoothing_factor_12778 >= -INT15)
            _7227 = _7226 * _smoothing_factor_12778;
            else
            _7227 = NewDouble(_7226 * (double)_smoothing_factor_12778);
        }
        else {
            _7227 = binary_op(MULTIPLY, _7226, _smoothing_factor_12778);
        }
        DeRef(_7226);
        _7226 = NOVALUE;
        if (IS_ATOM_INT(_7227) && IS_ATOM_INT(_lPrev_12779)) {
            _7228 = _7227 + _lPrev_12779;
            if ((long)((unsigned long)_7228 + (unsigned long)HIGH_BITS) >= 0) 
            _7228 = NewDouble((double)_7228);
        }
        else {
            _7228 = binary_op(PLUS, _7227, _lPrev_12779);
        }
        DeRef(_7227);
        _7227 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_set_12777);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_set_12777 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12801);
        _1 = *(int *)_2;
        *(int *)_2 = _7228;
        if( _1 != _7228 ){
            DeRef(_1);
        }
        _7228 = NOVALUE;

        /** 			lPrev = data_set[i]*/
        DeRef(_lPrev_12779);
        _2 = (int)SEQ_PTR(_data_set_12777);
        _lPrev_12779 = (int)*(((s1_ptr)_2)->base + _i_12801);
        Ref(_lPrev_12779);
LC: 

        /** 	end for*/
        _i_12801 = _i_12801 + 1;
        goto LA; // [182] 139
LB: 
        ;
    }

    /** 	return data_set*/
    DeRef(_smoothing_factor_12778);
    DeRef(_lPrev_12779);
    DeRef(_7216);
    _7216 = NOVALUE;
    return _data_set_12777;
    ;
}


int  __stdcall _35median(int _data_set_12813, int _subseq_opt_12814)
{
    int _7241 = NOVALUE;
    int _7240 = NOVALUE;
    int _7239 = NOVALUE;
    int _7238 = NOVALUE;
    int _7236 = NOVALUE;
    int _7234 = NOVALUE;
    int _7232 = NOVALUE;
    int _7230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7230 = IS_ATOM(_data_set_12813);
    if (_7230 == 0)
    {
        _7230 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7230 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12814);
    return _data_set_12813;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12813);
    Ref(_subseq_opt_12814);
    _0 = _data_set_12813;
    _data_set_12813 = _35massage(_data_set_12813, _subseq_opt_12814);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12813)){
            _7232 = SEQ_PTR(_data_set_12813)->length;
    }
    else {
        _7232 = 1;
    }
    if (_7232 != 0)
    goto L2; // [28] 39

    /** 		return data_set*/
    DeRef(_subseq_opt_12814);
    return _data_set_12813;
L2: 

    /** 	if length(data_set) < 3 then*/
    if (IS_SEQUENCE(_data_set_12813)){
            _7234 = SEQ_PTR(_data_set_12813)->length;
    }
    else {
        _7234 = 1;
    }
    if (_7234 >= 3)
    goto L3; // [44] 59

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12813);
    _7236 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7236);
    DeRef(_data_set_12813);
    DeRef(_subseq_opt_12814);
    return _7236;
L3: 

    /** 	data_set = stdsort:sort(data_set)*/
    Ref(_data_set_12813);
    _0 = _data_set_12813;
    _data_set_12813 = _24sort(_data_set_12813, 1);
    DeRef(_0);

    /** 	return data_set[ floor((length(data_set) + 1) / 2) ]*/
    if (IS_SEQUENCE(_data_set_12813)){
            _7238 = SEQ_PTR(_data_set_12813)->length;
    }
    else {
        _7238 = 1;
    }
    _7239 = _7238 + 1;
    _7238 = NOVALUE;
    _7240 = _7239 >> 1;
    _7239 = NOVALUE;
    _2 = (int)SEQ_PTR(_data_set_12813);
    _7241 = (int)*(((s1_ptr)_2)->base + _7240);
    Ref(_7241);
    DeRef(_data_set_12813);
    DeRef(_subseq_opt_12814);
    _7236 = NOVALUE;
    _7240 = NOVALUE;
    return _7241;
    ;
}


int  __stdcall _35raw_frequency(int _data_set_12832, int _subseq_opt_12833)
{
    int _lCounts_12834 = NOVALUE;
    int _lKeys_12835 = NOVALUE;
    int _lNew_12836 = NOVALUE;
    int _lPos_12837 = NOVALUE;
    int _lMax_12838 = NOVALUE;
    int _7270 = NOVALUE;
    int _7269 = NOVALUE;
    int _7268 = NOVALUE;
    int _7267 = NOVALUE;
    int _7265 = NOVALUE;
    int _7263 = NOVALUE;
    int _7262 = NOVALUE;
    int _7260 = NOVALUE;
    int _7256 = NOVALUE;
    int _7255 = NOVALUE;
    int _7253 = NOVALUE;
    int _7251 = NOVALUE;
    int _7250 = NOVALUE;
    int _7249 = NOVALUE;
    int _7248 = NOVALUE;
    int _7246 = NOVALUE;
    int _7244 = NOVALUE;
    int _7243 = NOVALUE;
    int _7242 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lNew = 0*/
    _lNew_12836 = 0;

    /** 	integer lMax = -1*/
    _lMax_12838 = -1;

    /** 	if atom(data_set) then*/
    _7242 = IS_ATOM(_data_set_12832);
    if (_7242 == 0)
    {
        _7242 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _7242 = NOVALUE;
    }

    /** 		return {{1,data_set}}*/
    Ref(_data_set_12832);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _data_set_12832;
    _7243 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _7243;
    _7244 = MAKE_SEQ(_1);
    _7243 = NOVALUE;
    DeRef(_data_set_12832);
    DeRef(_subseq_opt_12833);
    DeRef(_lCounts_12834);
    DeRef(_lKeys_12835);
    return _7244;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12832);
    Ref(_subseq_opt_12833);
    _0 = _data_set_12832;
    _data_set_12832 = _35massage(_data_set_12832, _subseq_opt_12833);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12832)){
            _7246 = SEQ_PTR(_data_set_12832)->length;
    }
    else {
        _7246 = 1;
    }
    if (_7246 != 0)
    goto L2; // [46] 65

    /** 		return {{1,data_set}}*/
    Ref(_data_set_12832);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _data_set_12832;
    _7248 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _7248;
    _7249 = MAKE_SEQ(_1);
    _7248 = NOVALUE;
    DeRef(_data_set_12832);
    DeRef(_subseq_opt_12833);
    DeRef(_lCounts_12834);
    DeRef(_lKeys_12835);
    DeRef(_7244);
    _7244 = NOVALUE;
    return _7249;
L2: 

    /** 	lCounts = repeat({0,0}, length(data_set))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7250 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_data_set_12832)){
            _7251 = SEQ_PTR(_data_set_12832)->length;
    }
    else {
        _7251 = 1;
    }
    DeRef(_lCounts_12834);
    _lCounts_12834 = Repeat(_7250, _7251);
    DeRefDS(_7250);
    _7250 = NOVALUE;
    _7251 = NOVALUE;

    /** 	lKeys   = repeat(0, length(data_set))*/
    if (IS_SEQUENCE(_data_set_12832)){
            _7253 = SEQ_PTR(_data_set_12832)->length;
    }
    else {
        _7253 = 1;
    }
    DeRef(_lKeys_12835);
    _lKeys_12835 = Repeat(0, _7253);
    _7253 = NOVALUE;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12832)){
            _7255 = SEQ_PTR(_data_set_12832)->length;
    }
    else {
        _7255 = 1;
    }
    {
        int _i_12855;
        _i_12855 = 1;
L3: 
        if (_i_12855 > _7255){
            goto L4; // [92] 191
        }

        /** 		lPos = find(data_set[i], lKeys)*/
        _2 = (int)SEQ_PTR(_data_set_12832);
        _7256 = (int)*(((s1_ptr)_2)->base + _i_12855);
        _lPos_12837 = find_from(_7256, _lKeys_12835, 1);
        _7256 = NOVALUE;

        /** 		if lPos = 0 then*/
        if (_lPos_12837 != 0)
        goto L5; // [112] 165

        /** 			lNew += 1*/
        _lNew_12836 = _lNew_12836 + 1;

        /** 			lPos = lNew*/
        _lPos_12837 = _lNew_12836;

        /** 			lCounts[lPos][2] = data_set[i]*/
        _2 = (int)SEQ_PTR(_lCounts_12834);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lCounts_12834 = MAKE_SEQ(_2);
        }
        _3 = (int)(_lPos_12837 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_data_set_12832);
        _7262 = (int)*(((s1_ptr)_2)->base + _i_12855);
        Ref(_7262);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7262;
        if( _1 != _7262 ){
            DeRef(_1);
        }
        _7262 = NOVALUE;
        _7260 = NOVALUE;

        /** 			lKeys[lPos] = data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12832);
        _7263 = (int)*(((s1_ptr)_2)->base + _i_12855);
        Ref(_7263);
        _2 = (int)SEQ_PTR(_lKeys_12835);
        _2 = (int)(((s1_ptr)_2)->base + _lPos_12837);
        _1 = *(int *)_2;
        *(int *)_2 = _7263;
        if( _1 != _7263 ){
            DeRef(_1);
        }
        _7263 = NOVALUE;

        /** 			if lPos > lMax then*/
        if (_lPos_12837 <= _lMax_12838)
        goto L6; // [154] 164

        /** 				lMax = lPos*/
        _lMax_12838 = _lPos_12837;
L6: 
L5: 

        /** 		lCounts[lPos][1] += 1*/
        _2 = (int)SEQ_PTR(_lCounts_12834);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lCounts_12834 = MAKE_SEQ(_2);
        }
        _3 = (int)(_lPos_12837 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7267 = (int)*(((s1_ptr)_2)->base + 1);
        _7265 = NOVALUE;
        if (IS_ATOM_INT(_7267)) {
            _7268 = _7267 + 1;
            if (_7268 > MAXINT){
                _7268 = NewDouble((double)_7268);
            }
        }
        else
        _7268 = binary_op(PLUS, 1, _7267);
        _7267 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7268;
        if( _1 != _7268 ){
            DeRef(_1);
        }
        _7268 = NOVALUE;
        _7265 = NOVALUE;

        /** 	end for*/
        _i_12855 = _i_12855 + 1;
        goto L3; // [186] 99
L4: 
        ;
    }

    /** 	return stdsort:sort(lCounts[1..lMax], stdsort:DESCENDING)*/
    rhs_slice_target = (object_ptr)&_7269;
    RHS_Slice(_lCounts_12834, 1, _lMax_12838);
    _7270 = _24sort(_7269, -1);
    _7269 = NOVALUE;
    DeRef(_data_set_12832);
    DeRef(_subseq_opt_12833);
    DeRefDS(_lCounts_12834);
    DeRef(_lKeys_12835);
    DeRef(_7244);
    _7244 = NOVALUE;
    DeRef(_7249);
    _7249 = NOVALUE;
    return _7270;
    ;
}


int  __stdcall _35mode(int _data_set_12876, int _subseq_opt_12877)
{
    int _lCounts_12878 = NOVALUE;
    int _lRes_12879 = NOVALUE;
    int _7285 = NOVALUE;
    int _7284 = NOVALUE;
    int _7282 = NOVALUE;
    int _7281 = NOVALUE;
    int _7280 = NOVALUE;
    int _7279 = NOVALUE;
    int _7278 = NOVALUE;
    int _7276 = NOVALUE;
    int _7275 = NOVALUE;
    int _7272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12876);
    Ref(_subseq_opt_12877);
    _0 = _data_set_12876;
    _data_set_12876 = _35massage(_data_set_12876, _subseq_opt_12877);
    DeRefDS(_0);

    /** 	if not length( data_set ) then*/
    if (IS_SEQUENCE(_data_set_12876)){
            _7272 = SEQ_PTR(_data_set_12876)->length;
    }
    else {
        _7272 = 1;
    }
    if (_7272 != 0)
    goto L1; // [17] 27
    _7272 = NOVALUE;

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12876);
    DeRef(_subseq_opt_12877);
    DeRef(_lCounts_12878);
    DeRef(_lRes_12879);
    return _5;
L1: 

    /** 	lCounts = raw_frequency(data_set, subseq_opt)*/
    RefDS(_data_set_12876);
    Ref(_subseq_opt_12877);
    _0 = _lCounts_12878;
    _lCounts_12878 = _35raw_frequency(_data_set_12876, _subseq_opt_12877);
    DeRef(_0);

    /** 	lRes = {lCounts[1][2]}*/
    _2 = (int)SEQ_PTR(_lCounts_12878);
    _7275 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_7275);
    _7276 = (int)*(((s1_ptr)_2)->base + 2);
    _7275 = NOVALUE;
    _0 = _lRes_12879;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7276);
    *((int *)(_2+4)) = _7276;
    _lRes_12879 = MAKE_SEQ(_1);
    DeRef(_0);
    _7276 = NOVALUE;

    /** 	for i = 2 to length(lCounts) do*/
    if (IS_SEQUENCE(_lCounts_12878)){
            _7278 = SEQ_PTR(_lCounts_12878)->length;
    }
    else {
        _7278 = 1;
    }
    {
        int _i_12889;
        _i_12889 = 2;
L2: 
        if (_i_12889 > _7278){
            goto L3; // [55] 110
        }

        /** 		if lCounts[i][1] < lCounts[1][1] then*/
        _2 = (int)SEQ_PTR(_lCounts_12878);
        _7279 = (int)*(((s1_ptr)_2)->base + _i_12889);
        _2 = (int)SEQ_PTR(_7279);
        _7280 = (int)*(((s1_ptr)_2)->base + 1);
        _7279 = NOVALUE;
        _2 = (int)SEQ_PTR(_lCounts_12878);
        _7281 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_7281);
        _7282 = (int)*(((s1_ptr)_2)->base + 1);
        _7281 = NOVALUE;
        if (binary_op_a(GREATEREQ, _7280, _7282)){
            _7280 = NOVALUE;
            _7282 = NOVALUE;
            goto L4; // [80] 89
        }
        _7280 = NOVALUE;
        _7282 = NOVALUE;

        /** 			exit*/
        goto L3; // [86] 110
L4: 

        /** 		lRes = append(lRes, lCounts[i][2])*/
        _2 = (int)SEQ_PTR(_lCounts_12878);
        _7284 = (int)*(((s1_ptr)_2)->base + _i_12889);
        _2 = (int)SEQ_PTR(_7284);
        _7285 = (int)*(((s1_ptr)_2)->base + 2);
        _7284 = NOVALUE;
        Ref(_7285);
        Append(&_lRes_12879, _lRes_12879, _7285);
        _7285 = NOVALUE;

        /** 	end for*/
        _i_12889 = _i_12889 + 1;
        goto L2; // [105] 62
L3: 
        ;
    }

    /** 	return lRes*/
    DeRefDS(_data_set_12876);
    DeRef(_subseq_opt_12877);
    DeRef(_lCounts_12878);
    return _lRes_12879;
    ;
}


int  __stdcall _35central_moment(int _data_set_12902, int _datum_12903, int _order_mag_12904, int _subseq_opt_12905)
{
    int _lMean_12906 = NOVALUE;
    int _7292 = NOVALUE;
    int _7291 = NOVALUE;
    int _7288 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_mag_12904)) {
        _1 = (long)(DBL_PTR(_order_mag_12904)->dbl);
        DeRefDS(_order_mag_12904);
        _order_mag_12904 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12902);
    Ref(_subseq_opt_12905);
    _0 = _data_set_12902;
    _data_set_12902 = _35massage(_data_set_12902, _subseq_opt_12905);
    DeRefDS(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12902)){
            _7288 = SEQ_PTR(_data_set_12902)->length;
    }
    else {
        _7288 = 1;
    }
    if (_7288 != 0)
    goto L1; // [19] 30

    /** 		return 0*/
    DeRefDS(_data_set_12902);
    DeRef(_datum_12903);
    DeRef(_subseq_opt_12905);
    DeRef(_lMean_12906);
    return 0;
L1: 

    /** 	lMean = average(data_set)*/
    RefDS(_data_set_12902);
    _0 = _lMean_12906;
    _lMean_12906 = _35average(_data_set_12902, 1);
    DeRef(_0);

    /** 	return power( datum - lMean, order_mag)*/
    if (IS_ATOM_INT(_datum_12903) && IS_ATOM_INT(_lMean_12906)) {
        _7291 = _datum_12903 - _lMean_12906;
        if ((long)((unsigned long)_7291 +(unsigned long) HIGH_BITS) >= 0){
            _7291 = NewDouble((double)_7291);
        }
    }
    else {
        _7291 = binary_op(MINUS, _datum_12903, _lMean_12906);
    }
    if (IS_ATOM_INT(_7291)) {
        _7292 = power(_7291, _order_mag_12904);
    }
    else {
        _7292 = binary_op(POWER, _7291, _order_mag_12904);
    }
    DeRef(_7291);
    _7291 = NOVALUE;
    DeRefDS(_data_set_12902);
    DeRef(_datum_12903);
    DeRef(_subseq_opt_12905);
    DeRef(_lMean_12906);
    return _7292;
    ;
}


int  __stdcall _35sum_central_moments(int _data_set_12916, int _order_mag_12917, int _subseq_opt_12918)
{
    int _7294 = NOVALUE;
    int _7293 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_mag_12917)) {
        _1 = (long)(DBL_PTR(_order_mag_12917)->dbl);
        DeRefDS(_order_mag_12917);
        _order_mag_12917 = _1;
    }

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12916);
    Ref(_data_set_12916);
    Ref(_subseq_opt_12918);
    _7293 = _35central_moment(_data_set_12916, _data_set_12916, _order_mag_12917, _subseq_opt_12918);
    _7294 = _35sum(_7293, 1);
    _7293 = NOVALUE;
    DeRef(_data_set_12916);
    DeRef(_subseq_opt_12918);
    return _7294;
    ;
}


int  __stdcall _35skewness(int _data_set_12923, int _subseq_opt_12924)
{
    int _sum_central_moments_1__tmp_at40_12933 = NOVALUE;
    int _sum_central_moments_inlined_sum_central_moments_at_40_12932 = NOVALUE;
    int _7304 = NOVALUE;
    int _7303 = NOVALUE;
    int _7302 = NOVALUE;
    int _7301 = NOVALUE;
    int _7300 = NOVALUE;
    int _7299 = NOVALUE;
    int _7297 = NOVALUE;
    int _7295 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7295 = IS_ATOM(_data_set_12923);
    if (_7295 == 0)
    {
        _7295 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7295 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12924);
    return _data_set_12923;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12923);
    Ref(_subseq_opt_12924);
    _0 = _data_set_12923;
    _data_set_12923 = _35massage(_data_set_12923, _subseq_opt_12924);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12923)){
            _7297 = SEQ_PTR(_data_set_12923)->length;
    }
    else {
        _7297 = 1;
    }
    if (_7297 != 0)
    goto L2; // [28] 39

    /** 		return data_set*/
    DeRef(_subseq_opt_12924);
    return _data_set_12923;
L2: 

    /** 	return sum_central_moments(data_set, 3) / ((length(data_set) - 1) * power(stdev(data_set), 3))*/

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12923);
    Ref(_data_set_12923);
    _0 = _sum_central_moments_1__tmp_at40_12933;
    _sum_central_moments_1__tmp_at40_12933 = _35central_moment(_data_set_12923, _data_set_12923, 3, 1);
    DeRef(_0);
    Ref(_sum_central_moments_1__tmp_at40_12933);
    _0 = _sum_central_moments_inlined_sum_central_moments_at_40_12932;
    _sum_central_moments_inlined_sum_central_moments_at_40_12932 = _35sum(_sum_central_moments_1__tmp_at40_12933, 1);
    DeRef(_0);
    DeRef(_sum_central_moments_1__tmp_at40_12933);
    _sum_central_moments_1__tmp_at40_12933 = NOVALUE;
    if (IS_SEQUENCE(_data_set_12923)){
            _7299 = SEQ_PTR(_data_set_12923)->length;
    }
    else {
        _7299 = 1;
    }
    _7300 = _7299 - 1;
    _7299 = NOVALUE;
    Ref(_data_set_12923);
    _7301 = _35stdev(_data_set_12923, 1, 2);
    if (IS_ATOM_INT(_7301)) {
        _7302 = power(_7301, 3);
    }
    else {
        _7302 = binary_op(POWER, _7301, 3);
    }
    DeRef(_7301);
    _7301 = NOVALUE;
    if (IS_ATOM_INT(_7302)) {
        if (_7300 == (short)_7300 && _7302 <= INT15 && _7302 >= -INT15)
        _7303 = _7300 * _7302;
        else
        _7303 = NewDouble(_7300 * (double)_7302);
    }
    else {
        _7303 = binary_op(MULTIPLY, _7300, _7302);
    }
    _7300 = NOVALUE;
    DeRef(_7302);
    _7302 = NOVALUE;
    if (IS_ATOM_INT(_sum_central_moments_inlined_sum_central_moments_at_40_12932) && IS_ATOM_INT(_7303)) {
        _7304 = (_sum_central_moments_inlined_sum_central_moments_at_40_12932 % _7303) ? NewDouble((double)_sum_central_moments_inlined_sum_central_moments_at_40_12932 / _7303) : (_sum_central_moments_inlined_sum_central_moments_at_40_12932 / _7303);
    }
    else {
        _7304 = binary_op(DIVIDE, _sum_central_moments_inlined_sum_central_moments_at_40_12932, _7303);
    }
    DeRef(_7303);
    _7303 = NOVALUE;
    DeRef(_data_set_12923);
    DeRef(_subseq_opt_12924);
    return _7304;
    ;
}


int  __stdcall _35kurtosis(int _data_set_12942, int _subseq_opt_12943)
{
    int _sd_12944 = NOVALUE;
    int _sum_central_moments_1__tmp_at65_12958 = NOVALUE;
    int _sum_central_moments_inlined_sum_central_moments_at_65_12957 = NOVALUE;
    int _7319 = NOVALUE;
    int _7318 = NOVALUE;
    int _7317 = NOVALUE;
    int _7316 = NOVALUE;
    int _7315 = NOVALUE;
    int _7314 = NOVALUE;
    int _7313 = NOVALUE;
    int _7309 = NOVALUE;
    int _7307 = NOVALUE;
    int _7305 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7305 = IS_ATOM(_data_set_12942);
    if (_7305 == 0)
    {
        _7305 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7305 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12943);
    DeRef(_sd_12944);
    return _data_set_12942;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12942);
    Ref(_subseq_opt_12943);
    _0 = _data_set_12942;
    _data_set_12942 = _35massage(_data_set_12942, _subseq_opt_12943);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12942)){
            _7307 = SEQ_PTR(_data_set_12942)->length;
    }
    else {
        _7307 = 1;
    }
    if (_7307 != 0)
    goto L2; // [28] 43

    /** 		return {0}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _7309 = MAKE_SEQ(_1);
    DeRef(_data_set_12942);
    DeRef(_subseq_opt_12943);
    DeRef(_sd_12944);
    return _7309;
L2: 

    /** 	sd = stdev(data_set)*/
    Ref(_data_set_12942);
    _0 = _sd_12944;
    _sd_12944 = _35stdev(_data_set_12942, 1, 2);
    DeRef(_0);

    /** 	if sd = 0 then*/
    if (binary_op_a(NOTEQ, _sd_12944, 0)){
        goto L3; // [53] 64
    }

    /** 		return {1}*/
    RefDS(_7312);
    DeRef(_data_set_12942);
    DeRef(_subseq_opt_12943);
    DeRef(_sd_12944);
    DeRef(_7309);
    _7309 = NOVALUE;
    return _7312;
L3: 

    /** 	return (sum_central_moments(data_set, 4) / ((length(data_set) - 1) * power(stdev(data_set), 4))) - 3*/

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12942);
    Ref(_data_set_12942);
    _0 = _sum_central_moments_1__tmp_at65_12958;
    _sum_central_moments_1__tmp_at65_12958 = _35central_moment(_data_set_12942, _data_set_12942, 4, 1);
    DeRef(_0);
    Ref(_sum_central_moments_1__tmp_at65_12958);
    _0 = _sum_central_moments_inlined_sum_central_moments_at_65_12957;
    _sum_central_moments_inlined_sum_central_moments_at_65_12957 = _35sum(_sum_central_moments_1__tmp_at65_12958, 1);
    DeRef(_0);
    DeRef(_sum_central_moments_1__tmp_at65_12958);
    _sum_central_moments_1__tmp_at65_12958 = NOVALUE;
    if (IS_SEQUENCE(_data_set_12942)){
            _7313 = SEQ_PTR(_data_set_12942)->length;
    }
    else {
        _7313 = 1;
    }
    _7314 = _7313 - 1;
    _7313 = NOVALUE;
    Ref(_data_set_12942);
    _7315 = _35stdev(_data_set_12942, 1, 2);
    if (IS_ATOM_INT(_7315)) {
        _7316 = power(_7315, 4);
    }
    else {
        _7316 = binary_op(POWER, _7315, 4);
    }
    DeRef(_7315);
    _7315 = NOVALUE;
    if (IS_ATOM_INT(_7316)) {
        if (_7314 == (short)_7314 && _7316 <= INT15 && _7316 >= -INT15)
        _7317 = _7314 * _7316;
        else
        _7317 = NewDouble(_7314 * (double)_7316);
    }
    else {
        _7317 = binary_op(MULTIPLY, _7314, _7316);
    }
    _7314 = NOVALUE;
    DeRef(_7316);
    _7316 = NOVALUE;
    if (IS_ATOM_INT(_sum_central_moments_inlined_sum_central_moments_at_65_12957) && IS_ATOM_INT(_7317)) {
        _7318 = (_sum_central_moments_inlined_sum_central_moments_at_65_12957 % _7317) ? NewDouble((double)_sum_central_moments_inlined_sum_central_moments_at_65_12957 / _7317) : (_sum_central_moments_inlined_sum_central_moments_at_65_12957 / _7317);
    }
    else {
        _7318 = binary_op(DIVIDE, _sum_central_moments_inlined_sum_central_moments_at_65_12957, _7317);
    }
    DeRef(_7317);
    _7317 = NOVALUE;
    if (IS_ATOM_INT(_7318)) {
        _7319 = _7318 - 3;
        if ((long)((unsigned long)_7319 +(unsigned long) HIGH_BITS) >= 0){
            _7319 = NewDouble((double)_7319);
        }
    }
    else {
        _7319 = binary_op(MINUS, _7318, 3);
    }
    DeRef(_7318);
    _7318 = NOVALUE;
    DeRef(_data_set_12942);
    DeRef(_subseq_opt_12943);
    DeRef(_sd_12944);
    DeRef(_7309);
    _7309 = NOVALUE;
    return _7319;
    ;
}



// 0xC322875D
