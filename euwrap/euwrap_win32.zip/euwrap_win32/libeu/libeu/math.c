// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _20abs(int _a_4487)
{
    int _t_4488 = NOVALUE;
    int _2306 = NOVALUE;
    int _2305 = NOVALUE;
    int _2304 = NOVALUE;
    int _2302 = NOVALUE;
    int _2300 = NOVALUE;
    int _2299 = NOVALUE;
    int _2297 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2297 = IS_ATOM(_a_4487);
    if (_2297 == 0)
    {
        _2297 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _2297 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_4487, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_4488);
    return _a_4487;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_4487)) {
        if ((unsigned long)_a_4487 == 0xC0000000)
        _2299 = (int)NewDouble((double)-0xC0000000);
        else
        _2299 = - _a_4487;
    }
    else {
        _2299 = unary_op(UMINUS, _a_4487);
    }
    DeRef(_a_4487);
    DeRef(_t_4488);
    return _2299;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4487)){
            _2300 = SEQ_PTR(_a_4487)->length;
    }
    else {
        _2300 = 1;
    }
    {
        int _i_4496;
        _i_4496 = 1;
L4: 
        if (_i_4496 > _2300){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_4488);
        _2 = (int)SEQ_PTR(_a_4487);
        _t_4488 = (int)*(((s1_ptr)_2)->base + _i_4496);
        Ref(_t_4488);

        /** 		if atom(t) then*/
        _2302 = IS_ATOM(_t_4488);
        if (_2302 == 0)
        {
            _2302 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _2302 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_4488, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_4488)) {
            if ((unsigned long)_t_4488 == 0xC0000000)
            _2304 = (int)NewDouble((double)-0xC0000000);
            else
            _2304 = - _t_4488;
        }
        else {
            _2304 = unary_op(UMINUS, _t_4488);
        }
        _2 = (int)SEQ_PTR(_a_4487);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4487 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4496);
        _1 = *(int *)_2;
        *(int *)_2 = _2304;
        if( _1 != _2304 ){
            DeRef(_1);
        }
        _2304 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_4488);
        DeRef(_2305);
        _2305 = _t_4488;
        _2306 = _20abs(_2305);
        _2305 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_4487);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4487 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4496);
        _1 = *(int *)_2;
        *(int *)_2 = _2306;
        if( _1 != _2306 ){
            DeRef(_1);
        }
        _2306 = NOVALUE;
L7: 

        /** 	end for*/
        _i_4496 = _i_4496 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_4488);
    DeRef(_2299);
    _2299 = NOVALUE;
    return _a_4487;
    ;
}


int  __stdcall _20sign(int _a_4509)
{
    int _2309 = NOVALUE;
    int _2308 = NOVALUE;
    int _2307 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (a > 0) - (a < 0)*/
    if (IS_ATOM_INT(_a_4509)) {
        _2307 = (_a_4509 > 0);
    }
    else {
        _2307 = binary_op(GREATER, _a_4509, 0);
    }
    if (IS_ATOM_INT(_a_4509)) {
        _2308 = (_a_4509 < 0);
    }
    else {
        _2308 = binary_op(LESS, _a_4509, 0);
    }
    if (IS_ATOM_INT(_2307) && IS_ATOM_INT(_2308)) {
        _2309 = _2307 - _2308;
        if ((long)((unsigned long)_2309 +(unsigned long) HIGH_BITS) >= 0){
            _2309 = NewDouble((double)_2309);
        }
    }
    else {
        _2309 = binary_op(MINUS, _2307, _2308);
    }
    DeRef(_2307);
    _2307 = NOVALUE;
    DeRef(_2308);
    _2308 = NOVALUE;
    DeRef(_a_4509);
    return _2309;
    ;
}


int  __stdcall _20larger_of(int _objA_4515, int _objB_4516)
{
    int _2310 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compare(objA, objB) > 0 then*/
    if (IS_ATOM_INT(_objA_4515) && IS_ATOM_INT(_objB_4516)){
        _2310 = (_objA_4515 < _objB_4516) ? -1 : (_objA_4515 > _objB_4516);
    }
    else{
        _2310 = compare(_objA_4515, _objB_4516);
    }
    if (_2310 <= 0)
    goto L1; // [7] 20

    /** 		return objA*/
    DeRef(_objB_4516);
    return _objA_4515;
    goto L2; // [17] 27
L1: 

    /** 		return objB*/
    DeRef(_objA_4515);
    return _objB_4516;
L2: 
    ;
}


int  __stdcall _20smaller_of(int _objA_4523, int _objB_4524)
{
    int _2312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compare(objA, objB) < 0 then*/
    if (IS_ATOM_INT(_objA_4523) && IS_ATOM_INT(_objB_4524)){
        _2312 = (_objA_4523 < _objB_4524) ? -1 : (_objA_4523 > _objB_4524);
    }
    else{
        _2312 = compare(_objA_4523, _objB_4524);
    }
    if (_2312 >= 0)
    goto L1; // [7] 20

    /** 		return objA*/
    DeRef(_objB_4524);
    return _objA_4523;
    goto L2; // [17] 27
L1: 

    /** 		return objB*/
    DeRef(_objA_4523);
    return _objB_4524;
L2: 
    ;
}


int  __stdcall _20max(int _a_4531)
{
    int _b_4532 = NOVALUE;
    int _c_4533 = NOVALUE;
    int _2316 = NOVALUE;
    int _2315 = NOVALUE;
    int _2314 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2314 = IS_ATOM(_a_4531);
    if (_2314 == 0)
    {
        _2314 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2314 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4532);
    DeRef(_c_4533);
    return _a_4531;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_22MINF_4465);
    DeRef(_b_4532);
    _b_4532 = _22MINF_4465;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4531)){
            _2315 = SEQ_PTR(_a_4531)->length;
    }
    else {
        _2315 = 1;
    }
    {
        int _i_4537;
        _i_4537 = 1;
L2: 
        if (_i_4537 > _2315){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_4531);
        _2316 = (int)*(((s1_ptr)_2)->base + _i_4537);
        Ref(_2316);
        _0 = _c_4533;
        _c_4533 = _20max(_2316);
        DeRef(_0);
        _2316 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_4533, _b_4532)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_4533);
        DeRef(_b_4532);
        _b_4532 = _c_4533;
L4: 

        /** 	end for*/
        _i_4537 = _i_4537 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4531);
    DeRef(_c_4533);
    return _b_4532;
    ;
}


int  __stdcall _20min(int _a_4545)
{
    int _b_4546 = NOVALUE;
    int _c_4547 = NOVALUE;
    int _2321 = NOVALUE;
    int _2320 = NOVALUE;
    int _2319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2319 = IS_ATOM(_a_4545);
    if (_2319 == 0)
    {
        _2319 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2319 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_4546);
    DeRef(_c_4547);
    return _a_4545;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_22PINF_4462);
    DeRef(_b_4546);
    _b_4546 = _22PINF_4462;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4545)){
            _2320 = SEQ_PTR(_a_4545)->length;
    }
    else {
        _2320 = 1;
    }
    {
        int _i_4551;
        _i_4551 = 1;
L2: 
        if (_i_4551 > _2320){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_4545);
        _2321 = (int)*(((s1_ptr)_2)->base + _i_4551);
        Ref(_2321);
        _0 = _c_4547;
        _c_4547 = _20min(_2321);
        DeRef(_0);
        _2321 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_4547, _b_4546)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_4547);
        DeRef(_b_4546);
        _b_4546 = _c_4547;
L4: 

        /** 	end for*/
        _i_4551 = _i_4551 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4545);
    DeRef(_c_4547);
    return _b_4546;
    ;
}


int  __stdcall _20ensure_in_range(int _item_4559, int _range_limits_4560)
{
    int _2335 = NOVALUE;
    int _2334 = NOVALUE;
    int _2332 = NOVALUE;
    int _2331 = NOVALUE;
    int _2330 = NOVALUE;
    int _2329 = NOVALUE;
    int _2327 = NOVALUE;
    int _2326 = NOVALUE;
    int _2324 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(range_limits) < 2 then*/
    if (IS_SEQUENCE(_range_limits_4560)){
            _2324 = SEQ_PTR(_range_limits_4560)->length;
    }
    else {
        _2324 = 1;
    }
    if (_2324 >= 2)
    goto L1; // [8] 19

    /** 		return item*/
    DeRefDS(_range_limits_4560);
    return _item_4559;
L1: 

    /** 	if eu:compare(item, range_limits[1]) < 0 then*/
    _2 = (int)SEQ_PTR(_range_limits_4560);
    _2326 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_item_4559) && IS_ATOM_INT(_2326)){
        _2327 = (_item_4559 < _2326) ? -1 : (_item_4559 > _2326);
    }
    else{
        _2327 = compare(_item_4559, _2326);
    }
    _2326 = NOVALUE;
    if (_2327 >= 0)
    goto L2; // [29] 44

    /** 		return range_limits[1]*/
    _2 = (int)SEQ_PTR(_range_limits_4560);
    _2329 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2329);
    DeRef(_item_4559);
    DeRefDS(_range_limits_4560);
    return _2329;
L2: 

    /** 	if eu:compare(item, range_limits[$]) > 0 then*/
    if (IS_SEQUENCE(_range_limits_4560)){
            _2330 = SEQ_PTR(_range_limits_4560)->length;
    }
    else {
        _2330 = 1;
    }
    _2 = (int)SEQ_PTR(_range_limits_4560);
    _2331 = (int)*(((s1_ptr)_2)->base + _2330);
    if (IS_ATOM_INT(_item_4559) && IS_ATOM_INT(_2331)){
        _2332 = (_item_4559 < _2331) ? -1 : (_item_4559 > _2331);
    }
    else{
        _2332 = compare(_item_4559, _2331);
    }
    _2331 = NOVALUE;
    if (_2332 <= 0)
    goto L3; // [57] 75

    /** 		return range_limits[$]*/
    if (IS_SEQUENCE(_range_limits_4560)){
            _2334 = SEQ_PTR(_range_limits_4560)->length;
    }
    else {
        _2334 = 1;
    }
    _2 = (int)SEQ_PTR(_range_limits_4560);
    _2335 = (int)*(((s1_ptr)_2)->base + _2334);
    Ref(_2335);
    DeRef(_item_4559);
    DeRefDS(_range_limits_4560);
    _2329 = NOVALUE;
    return _2335;
L3: 

    /** 	return item*/
    DeRefDS(_range_limits_4560);
    _2329 = NOVALUE;
    _2335 = NOVALUE;
    return _item_4559;
    ;
}


int  __stdcall _20ensure_in_list(int _item_4578, int _list_4579, int _default_4580)
{
    int _2345 = NOVALUE;
    int _2344 = NOVALUE;
    int _2343 = NOVALUE;
    int _2342 = NOVALUE;
    int _2341 = NOVALUE;
    int _2340 = NOVALUE;
    int _2338 = NOVALUE;
    int _2336 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_default_4580)) {
        _1 = (long)(DBL_PTR(_default_4580)->dbl);
        DeRefDS(_default_4580);
        _default_4580 = _1;
    }

    /** 	if length(list) = 0 then*/
    if (IS_SEQUENCE(_list_4579)){
            _2336 = SEQ_PTR(_list_4579)->length;
    }
    else {
        _2336 = 1;
    }
    if (_2336 != 0)
    goto L1; // [10] 21

    /** 		return item*/
    DeRefDS(_list_4579);
    return _item_4578;
L1: 

    /** 	if find(item, list) = 0 then*/
    _2338 = find_from(_item_4578, _list_4579, 1);
    if (_2338 != 0)
    goto L2; // [28] 78

    /** 		if default>=1 and default<=length(list) then*/
    _2340 = (_default_4580 >= 1);
    if (_2340 == 0) {
        goto L3; // [38] 66
    }
    if (IS_SEQUENCE(_list_4579)){
            _2342 = SEQ_PTR(_list_4579)->length;
    }
    else {
        _2342 = 1;
    }
    _2343 = (_default_4580 <= _2342);
    _2342 = NOVALUE;
    if (_2343 == 0)
    {
        DeRef(_2343);
        _2343 = NOVALUE;
        goto L3; // [50] 66
    }
    else{
        DeRef(_2343);
        _2343 = NOVALUE;
    }

    /** 		    return list[default]*/
    _2 = (int)SEQ_PTR(_list_4579);
    _2344 = (int)*(((s1_ptr)_2)->base + _default_4580);
    Ref(_2344);
    DeRef(_item_4578);
    DeRefDS(_list_4579);
    DeRef(_2340);
    _2340 = NOVALUE;
    return _2344;
    goto L4; // [63] 77
L3: 

    /** 			return list[1]*/
    _2 = (int)SEQ_PTR(_list_4579);
    _2345 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2345);
    DeRef(_item_4578);
    DeRefDS(_list_4579);
    DeRef(_2340);
    _2340 = NOVALUE;
    _2344 = NOVALUE;
    return _2345;
L4: 
L2: 

    /** 	return item*/
    DeRefDS(_list_4579);
    DeRef(_2340);
    _2340 = NOVALUE;
    _2344 = NOVALUE;
    _2345 = NOVALUE;
    return _item_4578;
    ;
}


int  __stdcall _20mod(int _x_4597, int _y_4598)
{
    int _sign_2__tmp_at2_4603 = NOVALUE;
    int _sign_1__tmp_at2_4602 = NOVALUE;
    int _sign_inlined_sign_at_2_4601 = NOVALUE;
    int _sign_2__tmp_at19_4607 = NOVALUE;
    int _sign_1__tmp_at19_4606 = NOVALUE;
    int _sign_inlined_sign_at_19_4605 = NOVALUE;
    int _2350 = NOVALUE;
    int _2349 = NOVALUE;
    int _2348 = NOVALUE;
    int _2347 = NOVALUE;
    int _2346 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(sign(x), sign(y)) then*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4602);
    if (IS_ATOM_INT(_x_4597)) {
        _sign_1__tmp_at2_4602 = (_x_4597 > 0);
    }
    else {
        _sign_1__tmp_at2_4602 = binary_op(GREATER, _x_4597, 0);
    }
    DeRef(_sign_2__tmp_at2_4603);
    if (IS_ATOM_INT(_x_4597)) {
        _sign_2__tmp_at2_4603 = (_x_4597 < 0);
    }
    else {
        _sign_2__tmp_at2_4603 = binary_op(LESS, _x_4597, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4601);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4602) && IS_ATOM_INT(_sign_2__tmp_at2_4603)) {
        _sign_inlined_sign_at_2_4601 = _sign_1__tmp_at2_4602 - _sign_2__tmp_at2_4603;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4601 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4601 = NewDouble((double)_sign_inlined_sign_at_2_4601);
        }
    }
    else {
        _sign_inlined_sign_at_2_4601 = binary_op(MINUS, _sign_1__tmp_at2_4602, _sign_2__tmp_at2_4603);
    }
    DeRef(_sign_1__tmp_at2_4602);
    _sign_1__tmp_at2_4602 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4603);
    _sign_2__tmp_at2_4603 = NOVALUE;

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at19_4606);
    if (IS_ATOM_INT(_y_4598)) {
        _sign_1__tmp_at19_4606 = (_y_4598 > 0);
    }
    else {
        _sign_1__tmp_at19_4606 = binary_op(GREATER, _y_4598, 0);
    }
    DeRef(_sign_2__tmp_at19_4607);
    if (IS_ATOM_INT(_y_4598)) {
        _sign_2__tmp_at19_4607 = (_y_4598 < 0);
    }
    else {
        _sign_2__tmp_at19_4607 = binary_op(LESS, _y_4598, 0);
    }
    DeRef(_sign_inlined_sign_at_19_4605);
    if (IS_ATOM_INT(_sign_1__tmp_at19_4606) && IS_ATOM_INT(_sign_2__tmp_at19_4607)) {
        _sign_inlined_sign_at_19_4605 = _sign_1__tmp_at19_4606 - _sign_2__tmp_at19_4607;
        if ((long)((unsigned long)_sign_inlined_sign_at_19_4605 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_19_4605 = NewDouble((double)_sign_inlined_sign_at_19_4605);
        }
    }
    else {
        _sign_inlined_sign_at_19_4605 = binary_op(MINUS, _sign_1__tmp_at19_4606, _sign_2__tmp_at19_4607);
    }
    DeRef(_sign_1__tmp_at19_4606);
    _sign_1__tmp_at19_4606 = NOVALUE;
    DeRef(_sign_2__tmp_at19_4607);
    _sign_2__tmp_at19_4607 = NOVALUE;
    if (_sign_inlined_sign_at_2_4601 == _sign_inlined_sign_at_19_4605)
    _2346 = 1;
    else if (IS_ATOM_INT(_sign_inlined_sign_at_2_4601) && IS_ATOM_INT(_sign_inlined_sign_at_19_4605))
    _2346 = 0;
    else
    _2346 = (compare(_sign_inlined_sign_at_2_4601, _sign_inlined_sign_at_19_4605) == 0);
    if (_2346 == 0)
    {
        _2346 = NOVALUE;
        goto L1; // [41] 55
    }
    else{
        _2346 = NOVALUE;
    }

    /** 		return remainder(x,y)*/
    if (IS_ATOM_INT(_x_4597) && IS_ATOM_INT(_y_4598)) {
        _2347 = (_x_4597 % _y_4598);
    }
    else {
        _2347 = binary_op(REMAINDER, _x_4597, _y_4598);
    }
    DeRef(_x_4597);
    DeRef(_y_4598);
    return _2347;
L1: 

    /** 	return x - y * floor(x / y)*/
    if (IS_ATOM_INT(_x_4597) && IS_ATOM_INT(_y_4598)) {
        if (_y_4598 > 0 && _x_4597 >= 0) {
            _2348 = _x_4597 / _y_4598;
        }
        else {
            temp_dbl = floor((double)_x_4597 / (double)_y_4598);
            if (_x_4597 != MININT)
            _2348 = (long)temp_dbl;
            else
            _2348 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_4597, _y_4598);
        _2348 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_y_4598) && IS_ATOM_INT(_2348)) {
        if (_y_4598 == (short)_y_4598 && _2348 <= INT15 && _2348 >= -INT15)
        _2349 = _y_4598 * _2348;
        else
        _2349 = NewDouble(_y_4598 * (double)_2348);
    }
    else {
        _2349 = binary_op(MULTIPLY, _y_4598, _2348);
    }
    DeRef(_2348);
    _2348 = NOVALUE;
    if (IS_ATOM_INT(_x_4597) && IS_ATOM_INT(_2349)) {
        _2350 = _x_4597 - _2349;
        if ((long)((unsigned long)_2350 +(unsigned long) HIGH_BITS) >= 0){
            _2350 = NewDouble((double)_2350);
        }
    }
    else {
        _2350 = binary_op(MINUS, _x_4597, _2349);
    }
    DeRef(_2349);
    _2349 = NOVALUE;
    DeRef(_x_4597);
    DeRef(_y_4598);
    DeRef(_2347);
    _2347 = NOVALUE;
    return _2350;
    ;
}


int  __stdcall _20trunc(int _x_4615)
{
    int _sign_2__tmp_at2_4619 = NOVALUE;
    int _sign_1__tmp_at2_4618 = NOVALUE;
    int _sign_inlined_sign_at_2_4617 = NOVALUE;
    int _2353 = NOVALUE;
    int _2352 = NOVALUE;
    int _2351 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sign(x) * floor(abs(x))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4618);
    if (IS_ATOM_INT(_x_4615)) {
        _sign_1__tmp_at2_4618 = (_x_4615 > 0);
    }
    else {
        _sign_1__tmp_at2_4618 = binary_op(GREATER, _x_4615, 0);
    }
    DeRef(_sign_2__tmp_at2_4619);
    if (IS_ATOM_INT(_x_4615)) {
        _sign_2__tmp_at2_4619 = (_x_4615 < 0);
    }
    else {
        _sign_2__tmp_at2_4619 = binary_op(LESS, _x_4615, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4617);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4618) && IS_ATOM_INT(_sign_2__tmp_at2_4619)) {
        _sign_inlined_sign_at_2_4617 = _sign_1__tmp_at2_4618 - _sign_2__tmp_at2_4619;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4617 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4617 = NewDouble((double)_sign_inlined_sign_at_2_4617);
        }
    }
    else {
        _sign_inlined_sign_at_2_4617 = binary_op(MINUS, _sign_1__tmp_at2_4618, _sign_2__tmp_at2_4619);
    }
    DeRef(_sign_1__tmp_at2_4618);
    _sign_1__tmp_at2_4618 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4619);
    _sign_2__tmp_at2_4619 = NOVALUE;
    Ref(_x_4615);
    _2351 = _20abs(_x_4615);
    if (IS_ATOM_INT(_2351))
    _2352 = e_floor(_2351);
    else
    _2352 = unary_op(FLOOR, _2351);
    DeRef(_2351);
    _2351 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_2_4617) && IS_ATOM_INT(_2352)) {
        if (_sign_inlined_sign_at_2_4617 == (short)_sign_inlined_sign_at_2_4617 && _2352 <= INT15 && _2352 >= -INT15)
        _2353 = _sign_inlined_sign_at_2_4617 * _2352;
        else
        _2353 = NewDouble(_sign_inlined_sign_at_2_4617 * (double)_2352);
    }
    else {
        _2353 = binary_op(MULTIPLY, _sign_inlined_sign_at_2_4617, _2352);
    }
    DeRef(_2352);
    _2352 = NOVALUE;
    DeRef(_x_4615);
    return _2353;
    ;
}


int  __stdcall _20frac(int _x_4625)
{
    int _temp_4626 = NOVALUE;
    int _sign_2__tmp_at8_4631 = NOVALUE;
    int _sign_1__tmp_at8_4630 = NOVALUE;
    int _sign_inlined_sign_at_8_4629 = NOVALUE;
    int _2357 = NOVALUE;
    int _2356 = NOVALUE;
    int _2355 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object temp = abs(x)*/
    Ref(_x_4625);
    _0 = _temp_4626;
    _temp_4626 = _20abs(_x_4625);
    DeRef(_0);

    /** 	return sign(x) * (temp - floor(temp))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at8_4630);
    if (IS_ATOM_INT(_x_4625)) {
        _sign_1__tmp_at8_4630 = (_x_4625 > 0);
    }
    else {
        _sign_1__tmp_at8_4630 = binary_op(GREATER, _x_4625, 0);
    }
    DeRef(_sign_2__tmp_at8_4631);
    if (IS_ATOM_INT(_x_4625)) {
        _sign_2__tmp_at8_4631 = (_x_4625 < 0);
    }
    else {
        _sign_2__tmp_at8_4631 = binary_op(LESS, _x_4625, 0);
    }
    DeRef(_sign_inlined_sign_at_8_4629);
    if (IS_ATOM_INT(_sign_1__tmp_at8_4630) && IS_ATOM_INT(_sign_2__tmp_at8_4631)) {
        _sign_inlined_sign_at_8_4629 = _sign_1__tmp_at8_4630 - _sign_2__tmp_at8_4631;
        if ((long)((unsigned long)_sign_inlined_sign_at_8_4629 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_8_4629 = NewDouble((double)_sign_inlined_sign_at_8_4629);
        }
    }
    else {
        _sign_inlined_sign_at_8_4629 = binary_op(MINUS, _sign_1__tmp_at8_4630, _sign_2__tmp_at8_4631);
    }
    DeRef(_sign_1__tmp_at8_4630);
    _sign_1__tmp_at8_4630 = NOVALUE;
    DeRef(_sign_2__tmp_at8_4631);
    _sign_2__tmp_at8_4631 = NOVALUE;
    if (IS_ATOM_INT(_temp_4626))
    _2355 = e_floor(_temp_4626);
    else
    _2355 = unary_op(FLOOR, _temp_4626);
    if (IS_ATOM_INT(_temp_4626) && IS_ATOM_INT(_2355)) {
        _2356 = _temp_4626 - _2355;
        if ((long)((unsigned long)_2356 +(unsigned long) HIGH_BITS) >= 0){
            _2356 = NewDouble((double)_2356);
        }
    }
    else {
        _2356 = binary_op(MINUS, _temp_4626, _2355);
    }
    DeRef(_2355);
    _2355 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_8_4629) && IS_ATOM_INT(_2356)) {
        if (_sign_inlined_sign_at_8_4629 == (short)_sign_inlined_sign_at_8_4629 && _2356 <= INT15 && _2356 >= -INT15)
        _2357 = _sign_inlined_sign_at_8_4629 * _2356;
        else
        _2357 = NewDouble(_sign_inlined_sign_at_8_4629 * (double)_2356);
    }
    else {
        _2357 = binary_op(MULTIPLY, _sign_inlined_sign_at_8_4629, _2356);
    }
    DeRef(_2356);
    _2356 = NOVALUE;
    DeRef(_x_4625);
    DeRef(_temp_4626);
    return _2357;
    ;
}


int  __stdcall _20intdiv(int _a_4637, int _b_4638)
{
    int _sign_2__tmp_at2_4642 = NOVALUE;
    int _sign_1__tmp_at2_4641 = NOVALUE;
    int _sign_inlined_sign_at_2_4640 = NOVALUE;
    int _2362 = NOVALUE;
    int _2361 = NOVALUE;
    int _2360 = NOVALUE;
    int _2359 = NOVALUE;
    int _2358 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sign(a)*ceil(abs(a)/abs(b))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4641);
    if (IS_ATOM_INT(_a_4637)) {
        _sign_1__tmp_at2_4641 = (_a_4637 > 0);
    }
    else {
        _sign_1__tmp_at2_4641 = binary_op(GREATER, _a_4637, 0);
    }
    DeRef(_sign_2__tmp_at2_4642);
    if (IS_ATOM_INT(_a_4637)) {
        _sign_2__tmp_at2_4642 = (_a_4637 < 0);
    }
    else {
        _sign_2__tmp_at2_4642 = binary_op(LESS, _a_4637, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4640);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4641) && IS_ATOM_INT(_sign_2__tmp_at2_4642)) {
        _sign_inlined_sign_at_2_4640 = _sign_1__tmp_at2_4641 - _sign_2__tmp_at2_4642;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4640 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4640 = NewDouble((double)_sign_inlined_sign_at_2_4640);
        }
    }
    else {
        _sign_inlined_sign_at_2_4640 = binary_op(MINUS, _sign_1__tmp_at2_4641, _sign_2__tmp_at2_4642);
    }
    DeRef(_sign_1__tmp_at2_4641);
    _sign_1__tmp_at2_4641 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4642);
    _sign_2__tmp_at2_4642 = NOVALUE;
    Ref(_a_4637);
    _2358 = _20abs(_a_4637);
    Ref(_b_4638);
    _2359 = _20abs(_b_4638);
    if (IS_ATOM_INT(_2358) && IS_ATOM_INT(_2359)) {
        _2360 = (_2358 % _2359) ? NewDouble((double)_2358 / _2359) : (_2358 / _2359);
    }
    else {
        _2360 = binary_op(DIVIDE, _2358, _2359);
    }
    DeRef(_2358);
    _2358 = NOVALUE;
    DeRef(_2359);
    _2359 = NOVALUE;
    _2361 = _20ceil(_2360);
    _2360 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_2_4640) && IS_ATOM_INT(_2361)) {
        if (_sign_inlined_sign_at_2_4640 == (short)_sign_inlined_sign_at_2_4640 && _2361 <= INT15 && _2361 >= -INT15)
        _2362 = _sign_inlined_sign_at_2_4640 * _2361;
        else
        _2362 = NewDouble(_sign_inlined_sign_at_2_4640 * (double)_2361);
    }
    else {
        _2362 = binary_op(MULTIPLY, _sign_inlined_sign_at_2_4640, _2361);
    }
    DeRef(_2361);
    _2361 = NOVALUE;
    DeRef(_a_4637);
    DeRef(_b_4638);
    return _2362;
    ;
}


int  __stdcall _20ceil(int _a_4651)
{
    int _2365 = NOVALUE;
    int _2364 = NOVALUE;
    int _2363 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return -floor(-a)*/
    if (IS_ATOM_INT(_a_4651)) {
        if ((unsigned long)_a_4651 == 0xC0000000)
        _2363 = (int)NewDouble((double)-0xC0000000);
        else
        _2363 = - _a_4651;
    }
    else {
        _2363 = unary_op(UMINUS, _a_4651);
    }
    if (IS_ATOM_INT(_2363))
    _2364 = e_floor(_2363);
    else
    _2364 = unary_op(FLOOR, _2363);
    DeRef(_2363);
    _2363 = NOVALUE;
    if (IS_ATOM_INT(_2364)) {
        if ((unsigned long)_2364 == 0xC0000000)
        _2365 = (int)NewDouble((double)-0xC0000000);
        else
        _2365 = - _2364;
    }
    else {
        _2365 = unary_op(UMINUS, _2364);
    }
    DeRef(_2364);
    _2364 = NOVALUE;
    DeRef(_a_4651);
    return _2365;
    ;
}


int  __stdcall _20round(int _a_4657, int _precision_4658)
{
    int _len_4659 = NOVALUE;
    int _s_4660 = NOVALUE;
    int _t_4661 = NOVALUE;
    int _u_4662 = NOVALUE;
    int _msg_inlined_crash_at_257_4713 = NOVALUE;
    int _2417 = NOVALUE;
    int _2416 = NOVALUE;
    int _2415 = NOVALUE;
    int _2414 = NOVALUE;
    int _2413 = NOVALUE;
    int _2412 = NOVALUE;
    int _2411 = NOVALUE;
    int _2410 = NOVALUE;
    int _2409 = NOVALUE;
    int _2408 = NOVALUE;
    int _2406 = NOVALUE;
    int _2404 = NOVALUE;
    int _2400 = NOVALUE;
    int _2398 = NOVALUE;
    int _2397 = NOVALUE;
    int _2396 = NOVALUE;
    int _2395 = NOVALUE;
    int _2394 = NOVALUE;
    int _2393 = NOVALUE;
    int _2392 = NOVALUE;
    int _2391 = NOVALUE;
    int _2389 = NOVALUE;
    int _2386 = NOVALUE;
    int _2385 = NOVALUE;
    int _2384 = NOVALUE;
    int _2383 = NOVALUE;
    int _2382 = NOVALUE;
    int _2381 = NOVALUE;
    int _2380 = NOVALUE;
    int _2379 = NOVALUE;
    int _2378 = NOVALUE;
    int _2376 = NOVALUE;
    int _2373 = NOVALUE;
    int _2372 = NOVALUE;
    int _2371 = NOVALUE;
    int _2370 = NOVALUE;
    int _2368 = NOVALUE;
    int _2367 = NOVALUE;
    int _0, _1, _2;
    

    /** 	precision = abs(precision)*/
    Ref(_precision_4658);
    _0 = _precision_4658;
    _precision_4658 = _20abs(_precision_4658);
    DeRef(_0);

    /** 	if atom(a) then*/
    _2367 = IS_ATOM(_a_4657);
    if (_2367 == 0)
    {
        _2367 = NOVALUE;
        goto L1; // [12] 140
    }
    else{
        _2367 = NOVALUE;
    }

    /** 		if atom(precision) then*/
    _2368 = IS_ATOM(_precision_4658);
    if (_2368 == 0)
    {
        _2368 = NOVALUE;
        goto L2; // [20] 45
    }
    else{
        _2368 = NOVALUE;
    }

    /** 			return floor(0.5 + (a * precision )) / precision*/
    if (IS_ATOM_INT(_a_4657) && IS_ATOM_INT(_precision_4658)) {
        if (_a_4657 == (short)_a_4657 && _precision_4658 <= INT15 && _precision_4658 >= -INT15)
        _2370 = _a_4657 * _precision_4658;
        else
        _2370 = NewDouble(_a_4657 * (double)_precision_4658);
    }
    else {
        _2370 = binary_op(MULTIPLY, _a_4657, _precision_4658);
    }
    _2371 = binary_op(PLUS, _2369, _2370);
    DeRef(_2370);
    _2370 = NOVALUE;
    if (IS_ATOM_INT(_2371))
    _2372 = e_floor(_2371);
    else
    _2372 = unary_op(FLOOR, _2371);
    DeRef(_2371);
    _2371 = NOVALUE;
    if (IS_ATOM_INT(_2372) && IS_ATOM_INT(_precision_4658)) {
        _2373 = (_2372 % _precision_4658) ? NewDouble((double)_2372 / _precision_4658) : (_2372 / _precision_4658);
    }
    else {
        _2373 = binary_op(DIVIDE, _2372, _precision_4658);
    }
    DeRef(_2372);
    _2372 = NOVALUE;
    DeRef(_a_4657);
    DeRef(_precision_4658);
    DeRef(_s_4660);
    DeRef(_t_4661);
    DeRef(_u_4662);
    return _2373;
L2: 

    /** 		len = length(precision)*/
    if (IS_SEQUENCE(_precision_4658)){
            _len_4659 = SEQ_PTR(_precision_4658)->length;
    }
    else {
        _len_4659 = 1;
    }

    /** 		s = repeat(0, len)*/
    DeRef(_s_4660);
    _s_4660 = Repeat(0, _len_4659);

    /** 		for i = 1 to len do*/
    _2376 = _len_4659;
    {
        int _i_4676;
        _i_4676 = 1;
L3: 
        if (_i_4676 > _2376){
            goto L4; // [61] 131
        }

        /** 			t = precision[i]*/
        DeRef(_t_4661);
        _2 = (int)SEQ_PTR(_precision_4658);
        _t_4661 = (int)*(((s1_ptr)_2)->base + _i_4676);
        Ref(_t_4661);

        /** 			if atom (t) then*/
        _2378 = IS_ATOM(_t_4661);
        if (_2378 == 0)
        {
            _2378 = NOVALUE;
            goto L5; // [79] 106
        }
        else{
            _2378 = NOVALUE;
        }

        /** 				s[i] = floor( 0.5 + (a * t)) / t*/
        if (IS_ATOM_INT(_a_4657) && IS_ATOM_INT(_t_4661)) {
            if (_a_4657 == (short)_a_4657 && _t_4661 <= INT15 && _t_4661 >= -INT15)
            _2379 = _a_4657 * _t_4661;
            else
            _2379 = NewDouble(_a_4657 * (double)_t_4661);
        }
        else {
            _2379 = binary_op(MULTIPLY, _a_4657, _t_4661);
        }
        _2380 = binary_op(PLUS, _2369, _2379);
        DeRef(_2379);
        _2379 = NOVALUE;
        if (IS_ATOM_INT(_2380))
        _2381 = e_floor(_2380);
        else
        _2381 = unary_op(FLOOR, _2380);
        DeRef(_2380);
        _2380 = NOVALUE;
        if (IS_ATOM_INT(_2381) && IS_ATOM_INT(_t_4661)) {
            _2382 = (_2381 % _t_4661) ? NewDouble((double)_2381 / _t_4661) : (_2381 / _t_4661);
        }
        else {
            _2382 = binary_op(DIVIDE, _2381, _t_4661);
        }
        DeRef(_2381);
        _2381 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4676);
        _1 = *(int *)_2;
        *(int *)_2 = _2382;
        if( _1 != _2382 ){
            DeRef(_1);
        }
        _2382 = NOVALUE;
        goto L6; // [103] 124
L5: 

        /** 				s[i] = round(a, t)*/
        Ref(_a_4657);
        DeRef(_2383);
        _2383 = _a_4657;
        Ref(_t_4661);
        DeRef(_2384);
        _2384 = _t_4661;
        _2385 = _20round(_2383, _2384);
        _2383 = NOVALUE;
        _2384 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4676);
        _1 = *(int *)_2;
        *(int *)_2 = _2385;
        if( _1 != _2385 ){
            DeRef(_1);
        }
        _2385 = NOVALUE;
L6: 

        /** 		end for*/
        _i_4676 = _i_4676 + 1;
        goto L3; // [126] 68
L4: 
        ;
    }

    /** 		return s*/
    DeRef(_a_4657);
    DeRef(_precision_4658);
    DeRef(_t_4661);
    DeRef(_u_4662);
    DeRef(_2373);
    _2373 = NOVALUE;
    return _s_4660;
    goto L7; // [137] 242
L1: 

    /** 	elsif atom(precision) then*/
    _2386 = IS_ATOM(_precision_4658);
    if (_2386 == 0)
    {
        _2386 = NOVALUE;
        goto L8; // [145] 241
    }
    else{
        _2386 = NOVALUE;
    }

    /** 		len = length(a)*/
    if (IS_SEQUENCE(_a_4657)){
            _len_4659 = SEQ_PTR(_a_4657)->length;
    }
    else {
        _len_4659 = 1;
    }

    /** 		s = repeat(0, len)*/
    DeRef(_s_4660);
    _s_4660 = Repeat(0, _len_4659);

    /** 		for i = 1 to len do*/
    _2389 = _len_4659;
    {
        int _i_4694;
        _i_4694 = 1;
L9: 
        if (_i_4694 > _2389){
            goto LA; // [164] 234
        }

        /** 			t = a[i]*/
        DeRef(_t_4661);
        _2 = (int)SEQ_PTR(_a_4657);
        _t_4661 = (int)*(((s1_ptr)_2)->base + _i_4694);
        Ref(_t_4661);

        /** 			if atom(t) then*/
        _2391 = IS_ATOM(_t_4661);
        if (_2391 == 0)
        {
            _2391 = NOVALUE;
            goto LB; // [182] 209
        }
        else{
            _2391 = NOVALUE;
        }

        /** 				s[i] = floor(0.5 + (t * precision)) / precision*/
        if (IS_ATOM_INT(_t_4661) && IS_ATOM_INT(_precision_4658)) {
            if (_t_4661 == (short)_t_4661 && _precision_4658 <= INT15 && _precision_4658 >= -INT15)
            _2392 = _t_4661 * _precision_4658;
            else
            _2392 = NewDouble(_t_4661 * (double)_precision_4658);
        }
        else {
            _2392 = binary_op(MULTIPLY, _t_4661, _precision_4658);
        }
        _2393 = binary_op(PLUS, _2369, _2392);
        DeRef(_2392);
        _2392 = NOVALUE;
        if (IS_ATOM_INT(_2393))
        _2394 = e_floor(_2393);
        else
        _2394 = unary_op(FLOOR, _2393);
        DeRef(_2393);
        _2393 = NOVALUE;
        if (IS_ATOM_INT(_2394) && IS_ATOM_INT(_precision_4658)) {
            _2395 = (_2394 % _precision_4658) ? NewDouble((double)_2394 / _precision_4658) : (_2394 / _precision_4658);
        }
        else {
            _2395 = binary_op(DIVIDE, _2394, _precision_4658);
        }
        DeRef(_2394);
        _2394 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4694);
        _1 = *(int *)_2;
        *(int *)_2 = _2395;
        if( _1 != _2395 ){
            DeRef(_1);
        }
        _2395 = NOVALUE;
        goto LC; // [206] 227
LB: 

        /** 				s[i] = round(t, precision)*/
        Ref(_t_4661);
        DeRef(_2396);
        _2396 = _t_4661;
        Ref(_precision_4658);
        DeRef(_2397);
        _2397 = _precision_4658;
        _2398 = _20round(_2396, _2397);
        _2396 = NOVALUE;
        _2397 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4694);
        _1 = *(int *)_2;
        *(int *)_2 = _2398;
        if( _1 != _2398 ){
            DeRef(_1);
        }
        _2398 = NOVALUE;
LC: 

        /** 		end for*/
        _i_4694 = _i_4694 + 1;
        goto L9; // [229] 171
LA: 
        ;
    }

    /** 		return s*/
    DeRef(_a_4657);
    DeRef(_precision_4658);
    DeRef(_t_4661);
    DeRef(_u_4662);
    DeRef(_2373);
    _2373 = NOVALUE;
    return _s_4660;
L8: 
L7: 

    /** 	len = length(a)*/
    if (IS_SEQUENCE(_a_4657)){
            _len_4659 = SEQ_PTR(_a_4657)->length;
    }
    else {
        _len_4659 = 1;
    }

    /** 	if len != length(precision) then*/
    if (IS_SEQUENCE(_precision_4658)){
            _2400 = SEQ_PTR(_precision_4658)->length;
    }
    else {
        _2400 = 1;
    }
    if (_len_4659 == _2400)
    goto LD; // [252] 277

    /** 		error:crash("The lengths of the two supplied sequences do not match.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_257_4713);
    _msg_inlined_crash_at_257_4713 = EPrintf(-9999999, _2402, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_257_4713);

    /** end procedure*/
    goto LE; // [271] 274
LE: 
    DeRefi(_msg_inlined_crash_at_257_4713);
    _msg_inlined_crash_at_257_4713 = NOVALUE;
LD: 

    /** 	s = repeat(0, len)*/
    DeRef(_s_4660);
    _s_4660 = Repeat(0, _len_4659);

    /** 	for i = 1 to len do*/
    _2404 = _len_4659;
    {
        int _i_4716;
        _i_4716 = 1;
LF: 
        if (_i_4716 > _2404){
            goto L10; // [288] 391
        }

        /** 		t = precision[i]*/
        DeRef(_t_4661);
        _2 = (int)SEQ_PTR(_precision_4658);
        _t_4661 = (int)*(((s1_ptr)_2)->base + _i_4716);
        Ref(_t_4661);

        /** 		if atom(t) then*/
        _2406 = IS_ATOM(_t_4661);
        if (_2406 == 0)
        {
            _2406 = NOVALUE;
            goto L11; // [306] 365
        }
        else{
            _2406 = NOVALUE;
        }

        /** 			u = a[i]*/
        DeRef(_u_4662);
        _2 = (int)SEQ_PTR(_a_4657);
        _u_4662 = (int)*(((s1_ptr)_2)->base + _i_4716);
        Ref(_u_4662);

        /** 			if atom(u) then*/
        _2408 = IS_ATOM(_u_4662);
        if (_2408 == 0)
        {
            _2408 = NOVALUE;
            goto L12; // [320] 347
        }
        else{
            _2408 = NOVALUE;
        }

        /** 				s[i] = floor(0.5 + (u * t)) / t*/
        if (IS_ATOM_INT(_u_4662) && IS_ATOM_INT(_t_4661)) {
            if (_u_4662 == (short)_u_4662 && _t_4661 <= INT15 && _t_4661 >= -INT15)
            _2409 = _u_4662 * _t_4661;
            else
            _2409 = NewDouble(_u_4662 * (double)_t_4661);
        }
        else {
            _2409 = binary_op(MULTIPLY, _u_4662, _t_4661);
        }
        _2410 = binary_op(PLUS, _2369, _2409);
        DeRef(_2409);
        _2409 = NOVALUE;
        if (IS_ATOM_INT(_2410))
        _2411 = e_floor(_2410);
        else
        _2411 = unary_op(FLOOR, _2410);
        DeRef(_2410);
        _2410 = NOVALUE;
        if (IS_ATOM_INT(_2411) && IS_ATOM_INT(_t_4661)) {
            _2412 = (_2411 % _t_4661) ? NewDouble((double)_2411 / _t_4661) : (_2411 / _t_4661);
        }
        else {
            _2412 = binary_op(DIVIDE, _2411, _t_4661);
        }
        DeRef(_2411);
        _2411 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4716);
        _1 = *(int *)_2;
        *(int *)_2 = _2412;
        if( _1 != _2412 ){
            DeRef(_1);
        }
        _2412 = NOVALUE;
        goto L13; // [344] 384
L12: 

        /** 				s[i] = round(u, t)*/
        Ref(_t_4661);
        DeRef(_2413);
        _2413 = _t_4661;
        Ref(_u_4662);
        _2414 = _20round(_u_4662, _2413);
        _2413 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4716);
        _1 = *(int *)_2;
        *(int *)_2 = _2414;
        if( _1 != _2414 ){
            DeRef(_1);
        }
        _2414 = NOVALUE;
        goto L13; // [362] 384
L11: 

        /** 			s[i] = round(a[i], t)*/
        _2 = (int)SEQ_PTR(_a_4657);
        _2415 = (int)*(((s1_ptr)_2)->base + _i_4716);
        Ref(_t_4661);
        DeRef(_2416);
        _2416 = _t_4661;
        Ref(_2415);
        _2417 = _20round(_2415, _2416);
        _2415 = NOVALUE;
        _2416 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4660);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4660 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4716);
        _1 = *(int *)_2;
        *(int *)_2 = _2417;
        if( _1 != _2417 ){
            DeRef(_1);
        }
        _2417 = NOVALUE;
L13: 

        /** 	end for*/
        _i_4716 = _i_4716 + 1;
        goto LF; // [386] 295
L10: 
        ;
    }

    /** 	return s*/
    DeRef(_a_4657);
    DeRef(_precision_4658);
    DeRef(_t_4661);
    DeRef(_u_4662);
    DeRef(_2373);
    _2373 = NOVALUE;
    return _s_4660;
    ;
}


int  __stdcall _20arccos(int _x_4737)
{
    int _2425 = NOVALUE;
    int _2424 = NOVALUE;
    int _2423 = NOVALUE;
    int _2422 = NOVALUE;
    int _2421 = NOVALUE;
    int _2420 = NOVALUE;
    int _2419 = NOVALUE;
    int _2418 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return mathcons:HALFPI - 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))*/
    if (IS_ATOM_INT(_x_4737) && IS_ATOM_INT(_x_4737)) {
        if (_x_4737 == (short)_x_4737 && _x_4737 <= INT15 && _x_4737 >= -INT15)
        _2418 = _x_4737 * _x_4737;
        else
        _2418 = NewDouble(_x_4737 * (double)_x_4737);
    }
    else {
        _2418 = binary_op(MULTIPLY, _x_4737, _x_4737);
    }
    _2419 = binary_op(MINUS, _2236, _2418);
    DeRef(_2418);
    _2418 = NOVALUE;
    if (IS_ATOM_INT(_2419))
    _2420 = e_sqrt(_2419);
    else
    _2420 = unary_op(SQRT, _2419);
    DeRef(_2419);
    _2419 = NOVALUE;
    _2421 = binary_op(PLUS, _2236, _2420);
    DeRef(_2420);
    _2420 = NOVALUE;
    if (IS_ATOM_INT(_x_4737) && IS_ATOM_INT(_2421)) {
        _2422 = (_x_4737 % _2421) ? NewDouble((double)_x_4737 / _2421) : (_x_4737 / _2421);
    }
    else {
        _2422 = binary_op(DIVIDE, _x_4737, _2421);
    }
    DeRef(_2421);
    _2421 = NOVALUE;
    if (IS_ATOM_INT(_2422))
    _2423 = e_arctan(_2422);
    else
    _2423 = unary_op(ARCTAN, _2422);
    DeRef(_2422);
    _2422 = NOVALUE;
    if (IS_ATOM_INT(_2423) && IS_ATOM_INT(_2423)) {
        _2424 = _2423 + _2423;
        if ((long)((unsigned long)_2424 + (unsigned long)HIGH_BITS) >= 0) 
        _2424 = NewDouble((double)_2424);
    }
    else {
        _2424 = binary_op(PLUS, _2423, _2423);
    }
    DeRef(_2423);
    _2423 = NOVALUE;
    _2423 = NOVALUE;
    _2425 = binary_op(MINUS, _22HALFPI_4428, _2424);
    DeRef(_2424);
    _2424 = NOVALUE;
    DeRef(_x_4737);
    return _2425;
    ;
}


int  __stdcall _20arcsin(int _x_4748)
{
    int _2432 = NOVALUE;
    int _2431 = NOVALUE;
    int _2430 = NOVALUE;
    int _2429 = NOVALUE;
    int _2428 = NOVALUE;
    int _2427 = NOVALUE;
    int _2426 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))*/
    if (IS_ATOM_INT(_x_4748) && IS_ATOM_INT(_x_4748)) {
        if (_x_4748 == (short)_x_4748 && _x_4748 <= INT15 && _x_4748 >= -INT15)
        _2426 = _x_4748 * _x_4748;
        else
        _2426 = NewDouble(_x_4748 * (double)_x_4748);
    }
    else {
        _2426 = binary_op(MULTIPLY, _x_4748, _x_4748);
    }
    _2427 = binary_op(MINUS, _2236, _2426);
    DeRef(_2426);
    _2426 = NOVALUE;
    if (IS_ATOM_INT(_2427))
    _2428 = e_sqrt(_2427);
    else
    _2428 = unary_op(SQRT, _2427);
    DeRef(_2427);
    _2427 = NOVALUE;
    _2429 = binary_op(PLUS, _2236, _2428);
    DeRef(_2428);
    _2428 = NOVALUE;
    if (IS_ATOM_INT(_x_4748) && IS_ATOM_INT(_2429)) {
        _2430 = (_x_4748 % _2429) ? NewDouble((double)_x_4748 / _2429) : (_x_4748 / _2429);
    }
    else {
        _2430 = binary_op(DIVIDE, _x_4748, _2429);
    }
    DeRef(_2429);
    _2429 = NOVALUE;
    if (IS_ATOM_INT(_2430))
    _2431 = e_arctan(_2430);
    else
    _2431 = unary_op(ARCTAN, _2430);
    DeRef(_2430);
    _2430 = NOVALUE;
    if (IS_ATOM_INT(_2431) && IS_ATOM_INT(_2431)) {
        _2432 = _2431 + _2431;
        if ((long)((unsigned long)_2432 + (unsigned long)HIGH_BITS) >= 0) 
        _2432 = NewDouble((double)_2432);
    }
    else {
        _2432 = binary_op(PLUS, _2431, _2431);
    }
    DeRef(_2431);
    _2431 = NOVALUE;
    _2431 = NOVALUE;
    DeRef(_x_4748);
    return _2432;
    ;
}


int  __stdcall _20atan2(int _y_4758, int _x_4759)
{
    int _2443 = NOVALUE;
    int _2442 = NOVALUE;
    int _2441 = NOVALUE;
    int _2440 = NOVALUE;
    int _2439 = NOVALUE;
    int _2438 = NOVALUE;
    int _2435 = NOVALUE;
    int _2434 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if x > 0 then*/
    if (binary_op_a(LESSEQ, _x_4759, 0)){
        goto L1; // [3] 23
    }

    /** 		return arctan(y/x)*/
    if (IS_ATOM_INT(_y_4758) && IS_ATOM_INT(_x_4759)) {
        _2434 = (_y_4758 % _x_4759) ? NewDouble((double)_y_4758 / _x_4759) : (_y_4758 / _x_4759);
    }
    else {
        if (IS_ATOM_INT(_y_4758)) {
            _2434 = NewDouble((double)_y_4758 / DBL_PTR(_x_4759)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4759)) {
                _2434 = NewDouble(DBL_PTR(_y_4758)->dbl / (double)_x_4759);
            }
            else
            _2434 = NewDouble(DBL_PTR(_y_4758)->dbl / DBL_PTR(_x_4759)->dbl);
        }
    }
    if (IS_ATOM_INT(_2434))
    _2435 = e_arctan(_2434);
    else
    _2435 = unary_op(ARCTAN, _2434);
    DeRef(_2434);
    _2434 = NOVALUE;
    DeRef(_y_4758);
    DeRef(_x_4759);
    return _2435;
    goto L2; // [20] 113
L1: 

    /** 	elsif x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_4759, 0)){
        goto L3; // [25] 76
    }

    /** 		if y < 0 then*/
    if (binary_op_a(GREATEREQ, _y_4758, 0)){
        goto L4; // [31] 55
    }

    /** 			return arctan(y/x) - mathcons:PI*/
    if (IS_ATOM_INT(_y_4758) && IS_ATOM_INT(_x_4759)) {
        _2438 = (_y_4758 % _x_4759) ? NewDouble((double)_y_4758 / _x_4759) : (_y_4758 / _x_4759);
    }
    else {
        if (IS_ATOM_INT(_y_4758)) {
            _2438 = NewDouble((double)_y_4758 / DBL_PTR(_x_4759)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4759)) {
                _2438 = NewDouble(DBL_PTR(_y_4758)->dbl / (double)_x_4759);
            }
            else
            _2438 = NewDouble(DBL_PTR(_y_4758)->dbl / DBL_PTR(_x_4759)->dbl);
        }
    }
    if (IS_ATOM_INT(_2438))
    _2439 = e_arctan(_2438);
    else
    _2439 = unary_op(ARCTAN, _2438);
    DeRef(_2438);
    _2438 = NOVALUE;
    _2440 = NewDouble(DBL_PTR(_2439)->dbl - DBL_PTR(_22PI_4424)->dbl);
    DeRefDS(_2439);
    _2439 = NOVALUE;
    DeRef(_y_4758);
    DeRef(_x_4759);
    DeRef(_2435);
    _2435 = NOVALUE;
    return _2440;
    goto L2; // [52] 113
L4: 

    /** 			return arctan(y/x) + mathcons:PI*/
    if (IS_ATOM_INT(_y_4758) && IS_ATOM_INT(_x_4759)) {
        _2441 = (_y_4758 % _x_4759) ? NewDouble((double)_y_4758 / _x_4759) : (_y_4758 / _x_4759);
    }
    else {
        if (IS_ATOM_INT(_y_4758)) {
            _2441 = NewDouble((double)_y_4758 / DBL_PTR(_x_4759)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4759)) {
                _2441 = NewDouble(DBL_PTR(_y_4758)->dbl / (double)_x_4759);
            }
            else
            _2441 = NewDouble(DBL_PTR(_y_4758)->dbl / DBL_PTR(_x_4759)->dbl);
        }
    }
    if (IS_ATOM_INT(_2441))
    _2442 = e_arctan(_2441);
    else
    _2442 = unary_op(ARCTAN, _2441);
    DeRef(_2441);
    _2441 = NOVALUE;
    _2443 = NewDouble(DBL_PTR(_2442)->dbl + DBL_PTR(_22PI_4424)->dbl);
    DeRefDS(_2442);
    _2442 = NOVALUE;
    DeRef(_y_4758);
    DeRef(_x_4759);
    DeRef(_2435);
    _2435 = NOVALUE;
    DeRef(_2440);
    _2440 = NOVALUE;
    return _2443;
    goto L2; // [73] 113
L3: 

    /** 	elsif y > 0 then*/
    if (binary_op_a(LESSEQ, _y_4758, 0)){
        goto L5; // [78] 91
    }

    /** 		return mathcons:HALFPI*/
    RefDS(_22HALFPI_4428);
    DeRef(_y_4758);
    DeRef(_x_4759);
    DeRef(_2435);
    _2435 = NOVALUE;
    DeRef(_2440);
    _2440 = NOVALUE;
    DeRef(_2443);
    _2443 = NOVALUE;
    return _22HALFPI_4428;
    goto L2; // [88] 113
L5: 

    /** 	elsif y < 0 then*/
    if (binary_op_a(GREATEREQ, _y_4758, 0)){
        goto L6; // [93] 106
    }

    /** 		return -(mathcons:HALFPI)*/
    RefDS(_2446);
    DeRef(_y_4758);
    DeRef(_x_4759);
    DeRef(_2435);
    _2435 = NOVALUE;
    DeRef(_2440);
    _2440 = NOVALUE;
    DeRef(_2443);
    _2443 = NOVALUE;
    return _2446;
    goto L2; // [103] 113
L6: 

    /** 		return 0*/
    DeRef(_y_4758);
    DeRef(_x_4759);
    DeRef(_2435);
    _2435 = NOVALUE;
    DeRef(_2440);
    _2440 = NOVALUE;
    DeRef(_2443);
    _2443 = NOVALUE;
    return 0;
L2: 
    ;
}


int  __stdcall _20rad2deg(int _x_4783)
{
    int _2447 = NOVALUE;
    int _0, _1, _2;
    

    /**    return x * mathcons:RADIANS_TO_DEGREES*/
    _2447 = binary_op(MULTIPLY, _x_4783, _22RADIANS_TO_DEGREES_4456);
    DeRef(_x_4783);
    return _2447;
    ;
}


int  __stdcall _20deg2rad(int _x_4787)
{
    int _2448 = NOVALUE;
    int _0, _1, _2;
    

    /**    return x * mathcons:DEGREES_TO_RADIANS*/
    _2448 = binary_op(MULTIPLY, _x_4787, _22DEGREES_TO_RADIANS_4454);
    DeRef(_x_4787);
    return _2448;
    ;
}


int  __stdcall _20log10(int _x1_4791)
{
    int _2450 = NOVALUE;
    int _2449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return log(x1) * mathcons:INVLN10*/
    if (IS_ATOM_INT(_x1_4791))
    _2449 = e_log(_x1_4791);
    else
    _2449 = unary_op(LOG, _x1_4791);
    _2450 = binary_op(MULTIPLY, _2449, _22INVLN10_4446);
    DeRef(_2449);
    _2449 = NOVALUE;
    DeRef(_x1_4791);
    return _2450;
    ;
}


int  __stdcall _20exp(int _x_4796)
{
    int _2451 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return power( mathcons:E, x)*/
    if (IS_ATOM_INT(_x_4796)) {
        temp_d.dbl = (double)_x_4796;
        _2451 = Dpower(DBL_PTR(_22E_4438), &temp_d);
    }
    else
    _2451 = Dpower(DBL_PTR(_22E_4438), DBL_PTR(_x_4796));
    DeRef(_x_4796);
    return _2451;
    ;
}


int  __stdcall _20fib(int _i_4800)
{
    int _2455 = NOVALUE;
    int _2454 = NOVALUE;
    int _2453 = NOVALUE;
    int _2452 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_4800)) {
        _1 = (long)(DBL_PTR(_i_4800)->dbl);
        DeRefDS(_i_4800);
        _i_4800 = _1;
    }

    /** 	return floor((power( mathcons:PHI, i) / mathcons:SQRT5) + 0.5)*/
    temp_d.dbl = (double)_i_4800;
    _2452 = Dpower(DBL_PTR(_22PHI_4436), &temp_d);
    _2453 = NewDouble(DBL_PTR(_2452)->dbl / DBL_PTR(_22SQRT5_4467)->dbl);
    DeRefDS(_2452);
    _2452 = NOVALUE;
    _2454 = NewDouble(DBL_PTR(_2453)->dbl + DBL_PTR(_2369)->dbl);
    DeRefDS(_2453);
    _2453 = NOVALUE;
    _2455 = unary_op(FLOOR, _2454);
    DeRefDS(_2454);
    _2454 = NOVALUE;
    return _2455;
    ;
}


int  __stdcall _20cosh(int _a_4807)
{
    int _exp_inlined_exp_at_2_4809 = NOVALUE;
    int _exp_inlined_exp_at_15_4813 = NOVALUE;
    int _x_inlined_exp_at_12_4812 = NOVALUE;
    int _2458 = NOVALUE;
    int _2457 = NOVALUE;
    int _2456 = NOVALUE;
    int _0, _1, _2;
    

    /**     return (exp(a)+exp(-a))/2*/

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_2_4809);
    _exp_inlined_exp_at_2_4809 = binary_op(POWER, _22E_4438, _a_4807);
    if (IS_ATOM_INT(_a_4807)) {
        if ((unsigned long)_a_4807 == 0xC0000000)
        _2456 = (int)NewDouble((double)-0xC0000000);
        else
        _2456 = - _a_4807;
    }
    else {
        _2456 = unary_op(UMINUS, _a_4807);
    }
    DeRef(_x_inlined_exp_at_12_4812);
    _x_inlined_exp_at_12_4812 = _2456;
    _2456 = NOVALUE;

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_15_4813);
    _exp_inlined_exp_at_15_4813 = binary_op(POWER, _22E_4438, _x_inlined_exp_at_12_4812);
    DeRef(_x_inlined_exp_at_12_4812);
    _x_inlined_exp_at_12_4812 = NOVALUE;
    if (IS_ATOM_INT(_exp_inlined_exp_at_2_4809) && IS_ATOM_INT(_exp_inlined_exp_at_15_4813)) {
        _2457 = _exp_inlined_exp_at_2_4809 + _exp_inlined_exp_at_15_4813;
        if ((long)((unsigned long)_2457 + (unsigned long)HIGH_BITS) >= 0) 
        _2457 = NewDouble((double)_2457);
    }
    else {
        _2457 = binary_op(PLUS, _exp_inlined_exp_at_2_4809, _exp_inlined_exp_at_15_4813);
    }
    if (IS_ATOM_INT(_2457)) {
        if (_2457 & 1) {
            _2458 = NewDouble((_2457 >> 1) + 0.5);
        }
        else
        _2458 = _2457 >> 1;
    }
    else {
        _2458 = binary_op(DIVIDE, _2457, 2);
    }
    DeRef(_2457);
    _2457 = NOVALUE;
    DeRef(_a_4807);
    return _2458;
    ;
}


int  __stdcall _20sinh(int _a_4818)
{
    int _exp_inlined_exp_at_2_4820 = NOVALUE;
    int _exp_inlined_exp_at_15_4824 = NOVALUE;
    int _x_inlined_exp_at_12_4823 = NOVALUE;
    int _2461 = NOVALUE;
    int _2460 = NOVALUE;
    int _2459 = NOVALUE;
    int _0, _1, _2;
    

    /**     return (exp(a)-exp(-a))/2*/

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_2_4820);
    _exp_inlined_exp_at_2_4820 = binary_op(POWER, _22E_4438, _a_4818);
    if (IS_ATOM_INT(_a_4818)) {
        if ((unsigned long)_a_4818 == 0xC0000000)
        _2459 = (int)NewDouble((double)-0xC0000000);
        else
        _2459 = - _a_4818;
    }
    else {
        _2459 = unary_op(UMINUS, _a_4818);
    }
    DeRef(_x_inlined_exp_at_12_4823);
    _x_inlined_exp_at_12_4823 = _2459;
    _2459 = NOVALUE;

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_15_4824);
    _exp_inlined_exp_at_15_4824 = binary_op(POWER, _22E_4438, _x_inlined_exp_at_12_4823);
    DeRef(_x_inlined_exp_at_12_4823);
    _x_inlined_exp_at_12_4823 = NOVALUE;
    if (IS_ATOM_INT(_exp_inlined_exp_at_2_4820) && IS_ATOM_INT(_exp_inlined_exp_at_15_4824)) {
        _2460 = _exp_inlined_exp_at_2_4820 - _exp_inlined_exp_at_15_4824;
        if ((long)((unsigned long)_2460 +(unsigned long) HIGH_BITS) >= 0){
            _2460 = NewDouble((double)_2460);
        }
    }
    else {
        _2460 = binary_op(MINUS, _exp_inlined_exp_at_2_4820, _exp_inlined_exp_at_15_4824);
    }
    if (IS_ATOM_INT(_2460)) {
        if (_2460 & 1) {
            _2461 = NewDouble((_2460 >> 1) + 0.5);
        }
        else
        _2461 = _2460 >> 1;
    }
    else {
        _2461 = binary_op(DIVIDE, _2460, 2);
    }
    DeRef(_2460);
    _2460 = NOVALUE;
    DeRef(_a_4818);
    return _2461;
    ;
}


int  __stdcall _20tanh(int _a_4829)
{
    int _2464 = NOVALUE;
    int _2463 = NOVALUE;
    int _2462 = NOVALUE;
    int _0, _1, _2;
    

    /**     return sinh(a)/cosh(a)*/
    Ref(_a_4829);
    _2462 = _20sinh(_a_4829);
    Ref(_a_4829);
    _2463 = _20cosh(_a_4829);
    if (IS_ATOM_INT(_2462) && IS_ATOM_INT(_2463)) {
        _2464 = (_2462 % _2463) ? NewDouble((double)_2462 / _2463) : (_2462 / _2463);
    }
    else {
        _2464 = binary_op(DIVIDE, _2462, _2463);
    }
    DeRef(_2462);
    _2462 = NOVALUE;
    DeRef(_2463);
    _2463 = NOVALUE;
    DeRef(_a_4829);
    return _2464;
    ;
}


int  __stdcall _20arcsinh(int _a_4835)
{
    int _2469 = NOVALUE;
    int _2468 = NOVALUE;
    int _2467 = NOVALUE;
    int _2466 = NOVALUE;
    int _2465 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log(a+sqrt(1+a*a))*/
    if (IS_ATOM_INT(_a_4835) && IS_ATOM_INT(_a_4835)) {
        if (_a_4835 == (short)_a_4835 && _a_4835 <= INT15 && _a_4835 >= -INT15)
        _2465 = _a_4835 * _a_4835;
        else
        _2465 = NewDouble(_a_4835 * (double)_a_4835);
    }
    else {
        _2465 = binary_op(MULTIPLY, _a_4835, _a_4835);
    }
    if (IS_ATOM_INT(_2465)) {
        _2466 = _2465 + 1;
        if (_2466 > MAXINT){
            _2466 = NewDouble((double)_2466);
        }
    }
    else
    _2466 = binary_op(PLUS, 1, _2465);
    DeRef(_2465);
    _2465 = NOVALUE;
    if (IS_ATOM_INT(_2466))
    _2467 = e_sqrt(_2466);
    else
    _2467 = unary_op(SQRT, _2466);
    DeRef(_2466);
    _2466 = NOVALUE;
    if (IS_ATOM_INT(_a_4835) && IS_ATOM_INT(_2467)) {
        _2468 = _a_4835 + _2467;
        if ((long)((unsigned long)_2468 + (unsigned long)HIGH_BITS) >= 0) 
        _2468 = NewDouble((double)_2468);
    }
    else {
        _2468 = binary_op(PLUS, _a_4835, _2467);
    }
    DeRef(_2467);
    _2467 = NOVALUE;
    if (IS_ATOM_INT(_2468))
    _2469 = e_log(_2468);
    else
    _2469 = unary_op(LOG, _2468);
    DeRef(_2468);
    _2468 = NOVALUE;
    DeRef(_a_4835);
    return _2469;
    ;
}


int  __stdcall _20arccosh(int _a_4856)
{
    int _2480 = NOVALUE;
    int _2479 = NOVALUE;
    int _2478 = NOVALUE;
    int _2477 = NOVALUE;
    int _2476 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log(a+sqrt(a*a-1))*/
    if (IS_ATOM_INT(_a_4856) && IS_ATOM_INT(_a_4856)) {
        if (_a_4856 == (short)_a_4856 && _a_4856 <= INT15 && _a_4856 >= -INT15)
        _2476 = _a_4856 * _a_4856;
        else
        _2476 = NewDouble(_a_4856 * (double)_a_4856);
    }
    else {
        _2476 = binary_op(MULTIPLY, _a_4856, _a_4856);
    }
    if (IS_ATOM_INT(_2476)) {
        _2477 = _2476 - 1;
        if ((long)((unsigned long)_2477 +(unsigned long) HIGH_BITS) >= 0){
            _2477 = NewDouble((double)_2477);
        }
    }
    else {
        _2477 = binary_op(MINUS, _2476, 1);
    }
    DeRef(_2476);
    _2476 = NOVALUE;
    if (IS_ATOM_INT(_2477))
    _2478 = e_sqrt(_2477);
    else
    _2478 = unary_op(SQRT, _2477);
    DeRef(_2477);
    _2477 = NOVALUE;
    if (IS_ATOM_INT(_a_4856) && IS_ATOM_INT(_2478)) {
        _2479 = _a_4856 + _2478;
        if ((long)((unsigned long)_2479 + (unsigned long)HIGH_BITS) >= 0) 
        _2479 = NewDouble((double)_2479);
    }
    else {
        _2479 = binary_op(PLUS, _a_4856, _2478);
    }
    DeRef(_2478);
    _2478 = NOVALUE;
    if (IS_ATOM_INT(_2479))
    _2480 = e_log(_2479);
    else
    _2480 = unary_op(LOG, _2479);
    DeRef(_2479);
    _2479 = NOVALUE;
    DeRef(_a_4856);
    return _2480;
    ;
}


int  __stdcall _20arctanh(int _a_4880)
{
    int _2494 = NOVALUE;
    int _2493 = NOVALUE;
    int _2492 = NOVALUE;
    int _2491 = NOVALUE;
    int _2490 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log((1+a)/(1-a))/2*/
    if (IS_ATOM_INT(_a_4880)) {
        _2490 = _a_4880 + 1;
        if (_2490 > MAXINT){
            _2490 = NewDouble((double)_2490);
        }
    }
    else
    _2490 = binary_op(PLUS, 1, _a_4880);
    if (IS_ATOM_INT(_a_4880)) {
        _2491 = 1 - _a_4880;
        if ((long)((unsigned long)_2491 +(unsigned long) HIGH_BITS) >= 0){
            _2491 = NewDouble((double)_2491);
        }
    }
    else {
        _2491 = binary_op(MINUS, 1, _a_4880);
    }
    if (IS_ATOM_INT(_2490) && IS_ATOM_INT(_2491)) {
        _2492 = (_2490 % _2491) ? NewDouble((double)_2490 / _2491) : (_2490 / _2491);
    }
    else {
        _2492 = binary_op(DIVIDE, _2490, _2491);
    }
    DeRef(_2490);
    _2490 = NOVALUE;
    DeRef(_2491);
    _2491 = NOVALUE;
    if (IS_ATOM_INT(_2492))
    _2493 = e_log(_2492);
    else
    _2493 = unary_op(LOG, _2492);
    DeRef(_2492);
    _2492 = NOVALUE;
    if (IS_ATOM_INT(_2493)) {
        if (_2493 & 1) {
            _2494 = NewDouble((_2493 >> 1) + 0.5);
        }
        else
        _2494 = _2493 >> 1;
    }
    else {
        _2494 = binary_op(DIVIDE, _2493, 2);
    }
    DeRef(_2493);
    _2493 = NOVALUE;
    DeRef(_a_4880);
    return _2494;
    ;
}


int  __stdcall _20sum(int _a_4888)
{
    int _b_4889 = NOVALUE;
    int _2502 = NOVALUE;
    int _2501 = NOVALUE;
    int _2499 = NOVALUE;
    int _2498 = NOVALUE;
    int _2497 = NOVALUE;
    int _2496 = NOVALUE;
    int _2495 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2495 = IS_ATOM(_a_4888);
    if (_2495 == 0)
    {
        _2495 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2495 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4889);
    return _a_4888;
L1: 

    /** 	b = 0*/
    DeRef(_b_4889);
    _b_4889 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4888)){
            _2496 = SEQ_PTR(_a_4888)->length;
    }
    else {
        _2496 = 1;
    }
    {
        int _i_4893;
        _i_4893 = 1;
L2: 
        if (_i_4893 > _2496){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4888);
        _2497 = (int)*(((s1_ptr)_2)->base + _i_4893);
        _2498 = IS_ATOM(_2497);
        _2497 = NOVALUE;
        if (_2498 == 0)
        {
            _2498 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2498 = NOVALUE;
        }

        /** 			b += a[i]*/
        _2 = (int)SEQ_PTR(_a_4888);
        _2499 = (int)*(((s1_ptr)_2)->base + _i_4893);
        _0 = _b_4889;
        if (IS_ATOM_INT(_b_4889) && IS_ATOM_INT(_2499)) {
            _b_4889 = _b_4889 + _2499;
            if ((long)((unsigned long)_b_4889 + (unsigned long)HIGH_BITS) >= 0) 
            _b_4889 = NewDouble((double)_b_4889);
        }
        else {
            _b_4889 = binary_op(PLUS, _b_4889, _2499);
        }
        DeRef(_0);
        _2499 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b += sum(a[i])*/
        _2 = (int)SEQ_PTR(_a_4888);
        _2501 = (int)*(((s1_ptr)_2)->base + _i_4893);
        Ref(_2501);
        _2502 = _20sum(_2501);
        _2501 = NOVALUE;
        _0 = _b_4889;
        if (IS_ATOM_INT(_b_4889) && IS_ATOM_INT(_2502)) {
            _b_4889 = _b_4889 + _2502;
            if ((long)((unsigned long)_b_4889 + (unsigned long)HIGH_BITS) >= 0) 
            _b_4889 = NewDouble((double)_b_4889);
        }
        else {
            _b_4889 = binary_op(PLUS, _b_4889, _2502);
        }
        DeRef(_0);
        DeRef(_2502);
        _2502 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4893 = _i_4893 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4888);
    return _b_4889;
    ;
}


int  __stdcall _20product(int _a_4906)
{
    int _b_4907 = NOVALUE;
    int _2511 = NOVALUE;
    int _2510 = NOVALUE;
    int _2508 = NOVALUE;
    int _2507 = NOVALUE;
    int _2506 = NOVALUE;
    int _2505 = NOVALUE;
    int _2504 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2504 = IS_ATOM(_a_4906);
    if (_2504 == 0)
    {
        _2504 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2504 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4907);
    return _a_4906;
L1: 

    /** 	b = 1*/
    DeRef(_b_4907);
    _b_4907 = 1;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4906)){
            _2505 = SEQ_PTR(_a_4906)->length;
    }
    else {
        _2505 = 1;
    }
    {
        int _i_4911;
        _i_4911 = 1;
L2: 
        if (_i_4911 > _2505){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4906);
        _2506 = (int)*(((s1_ptr)_2)->base + _i_4911);
        _2507 = IS_ATOM(_2506);
        _2506 = NOVALUE;
        if (_2507 == 0)
        {
            _2507 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2507 = NOVALUE;
        }

        /** 			b *= a[i]*/
        _2 = (int)SEQ_PTR(_a_4906);
        _2508 = (int)*(((s1_ptr)_2)->base + _i_4911);
        _0 = _b_4907;
        if (IS_ATOM_INT(_b_4907) && IS_ATOM_INT(_2508)) {
            if (_b_4907 == (short)_b_4907 && _2508 <= INT15 && _2508 >= -INT15)
            _b_4907 = _b_4907 * _2508;
            else
            _b_4907 = NewDouble(_b_4907 * (double)_2508);
        }
        else {
            _b_4907 = binary_op(MULTIPLY, _b_4907, _2508);
        }
        DeRef(_0);
        _2508 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b *= product(a[i])*/
        _2 = (int)SEQ_PTR(_a_4906);
        _2510 = (int)*(((s1_ptr)_2)->base + _i_4911);
        Ref(_2510);
        _2511 = _20product(_2510);
        _2510 = NOVALUE;
        _0 = _b_4907;
        if (IS_ATOM_INT(_b_4907) && IS_ATOM_INT(_2511)) {
            if (_b_4907 == (short)_b_4907 && _2511 <= INT15 && _2511 >= -INT15)
            _b_4907 = _b_4907 * _2511;
            else
            _b_4907 = NewDouble(_b_4907 * (double)_2511);
        }
        else {
            _b_4907 = binary_op(MULTIPLY, _b_4907, _2511);
        }
        DeRef(_0);
        DeRef(_2511);
        _2511 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4911 = _i_4911 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4906);
    return _b_4907;
    ;
}


int  __stdcall _20or_all(int _a_4924)
{
    int _b_4925 = NOVALUE;
    int _2520 = NOVALUE;
    int _2519 = NOVALUE;
    int _2517 = NOVALUE;
    int _2516 = NOVALUE;
    int _2515 = NOVALUE;
    int _2514 = NOVALUE;
    int _2513 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2513 = IS_ATOM(_a_4924);
    if (_2513 == 0)
    {
        _2513 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2513 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4925);
    return _a_4924;
L1: 

    /** 	b = 0*/
    DeRef(_b_4925);
    _b_4925 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4924)){
            _2514 = SEQ_PTR(_a_4924)->length;
    }
    else {
        _2514 = 1;
    }
    {
        int _i_4929;
        _i_4929 = 1;
L2: 
        if (_i_4929 > _2514){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4924);
        _2515 = (int)*(((s1_ptr)_2)->base + _i_4929);
        _2516 = IS_ATOM(_2515);
        _2515 = NOVALUE;
        if (_2516 == 0)
        {
            _2516 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2516 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_4924);
        _2517 = (int)*(((s1_ptr)_2)->base + _i_4929);
        _0 = _b_4925;
        if (IS_ATOM_INT(_b_4925) && IS_ATOM_INT(_2517)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_4925 | (unsigned long)_2517;
                 _b_4925 = MAKE_UINT(tu);
            }
        }
        else {
            _b_4925 = binary_op(OR_BITS, _b_4925, _2517);
        }
        DeRef(_0);
        _2517 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_4924);
        _2519 = (int)*(((s1_ptr)_2)->base + _i_4929);
        Ref(_2519);
        _2520 = _20or_all(_2519);
        _2519 = NOVALUE;
        _0 = _b_4925;
        if (IS_ATOM_INT(_b_4925) && IS_ATOM_INT(_2520)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_4925 | (unsigned long)_2520;
                 _b_4925 = MAKE_UINT(tu);
            }
        }
        else {
            _b_4925 = binary_op(OR_BITS, _b_4925, _2520);
        }
        DeRef(_0);
        DeRef(_2520);
        _2520 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4929 = _i_4929 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4924);
    return _b_4925;
    ;
}


int  __stdcall _20shift_bits(int _source_number_4942, int _shift_distance_4943)
{
    int _lSigned_4961 = NOVALUE;
    int _2544 = NOVALUE;
    int _2542 = NOVALUE;
    int _2541 = NOVALUE;
    int _2540 = NOVALUE;
    int _2539 = NOVALUE;
    int _2537 = NOVALUE;
    int _2534 = NOVALUE;
    int _2531 = NOVALUE;
    int _2530 = NOVALUE;
    int _2526 = NOVALUE;
    int _2525 = NOVALUE;
    int _2524 = NOVALUE;
    int _2523 = NOVALUE;
    int _2522 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_distance_4943)) {
        _1 = (long)(DBL_PTR(_shift_distance_4943)->dbl);
        DeRefDS(_shift_distance_4943);
        _shift_distance_4943 = _1;
    }

    /** 	if sequence(source_number) then*/
    _2522 = IS_SEQUENCE(_source_number_4942);
    if (_2522 == 0)
    {
        _2522 = NOVALUE;
        goto L1; // [8] 55
    }
    else{
        _2522 = NOVALUE;
    }

    /** 		for i = 1 to length(source_number) do*/
    if (IS_SEQUENCE(_source_number_4942)){
            _2523 = SEQ_PTR(_source_number_4942)->length;
    }
    else {
        _2523 = 1;
    }
    {
        int _i_4947;
        _i_4947 = 1;
L2: 
        if (_i_4947 > _2523){
            goto L3; // [16] 48
        }

        /** 			source_number[i] = shift_bits(source_number[i], shift_distance)*/
        _2 = (int)SEQ_PTR(_source_number_4942);
        _2524 = (int)*(((s1_ptr)_2)->base + _i_4947);
        DeRef(_2525);
        _2525 = _shift_distance_4943;
        Ref(_2524);
        _2526 = _20shift_bits(_2524, _2525);
        _2524 = NOVALUE;
        _2525 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_number_4942);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_number_4942 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4947);
        _1 = *(int *)_2;
        *(int *)_2 = _2526;
        if( _1 != _2526 ){
            DeRef(_1);
        }
        _2526 = NOVALUE;

        /** 		end for*/
        _i_4947 = _i_4947 + 1;
        goto L2; // [43] 23
L3: 
        ;
    }

    /** 		return source_number*/
    return _source_number_4942;
L1: 

    /** 	source_number = and_bits(source_number, 0xFFFFFFFF)*/
    _0 = _source_number_4942;
    _source_number_4942 = binary_op(AND_BITS, _source_number_4942, _2228);
    DeRef(_0);

    /** 	if shift_distance = 0 then*/
    if (_shift_distance_4943 != 0)
    goto L4; // [63] 74

    /** 		return source_number*/
    return _source_number_4942;
L4: 

    /** 	if shift_distance < 0 then*/
    if (_shift_distance_4943 >= 0)
    goto L5; // [76] 96

    /** 		source_number *= power(2, -shift_distance)*/
    if ((unsigned long)_shift_distance_4943 == 0xC0000000)
    _2530 = (int)NewDouble((double)-0xC0000000);
    else
    _2530 = - _shift_distance_4943;
    if (IS_ATOM_INT(_2530)) {
        _2531 = power(2, _2530);
    }
    else {
        temp_d.dbl = (double)2;
        _2531 = Dpower(&temp_d, DBL_PTR(_2530));
    }
    DeRef(_2530);
    _2530 = NOVALUE;
    _0 = _source_number_4942;
    if (IS_ATOM_INT(_source_number_4942) && IS_ATOM_INT(_2531)) {
        if (_source_number_4942 == (short)_source_number_4942 && _2531 <= INT15 && _2531 >= -INT15)
        _source_number_4942 = _source_number_4942 * _2531;
        else
        _source_number_4942 = NewDouble(_source_number_4942 * (double)_2531);
    }
    else {
        _source_number_4942 = binary_op(MULTIPLY, _source_number_4942, _2531);
    }
    DeRef(_0);
    DeRef(_2531);
    _2531 = NOVALUE;
    goto L6; // [93] 164
L5: 

    /** 		integer lSigned = 0*/
    _lSigned_4961 = 0;

    /** 		if and_bits(source_number, 0x80000000) then*/
    _2534 = binary_op(AND_BITS, _source_number_4942, _2533);
    if (_2534 == 0) {
        DeRef(_2534);
        _2534 = NOVALUE;
        goto L7; // [107] 122
    }
    else {
        if (!IS_ATOM_INT(_2534) && DBL_PTR(_2534)->dbl == 0.0){
            DeRef(_2534);
            _2534 = NOVALUE;
            goto L7; // [107] 122
        }
        DeRef(_2534);
        _2534 = NOVALUE;
    }
    DeRef(_2534);
    _2534 = NOVALUE;

    /** 			lSigned = 1*/
    _lSigned_4961 = 1;

    /** 			source_number = and_bits(source_number, 0x7FFFFFFF)*/
    _0 = _source_number_4942;
    _source_number_4942 = binary_op(AND_BITS, _source_number_4942, _2535);
    DeRef(_0);
L7: 

    /** 		source_number /= power(2, shift_distance)*/
    _2537 = power(2, _shift_distance_4943);
    _0 = _source_number_4942;
    if (IS_ATOM_INT(_source_number_4942) && IS_ATOM_INT(_2537)) {
        _source_number_4942 = (_source_number_4942 % _2537) ? NewDouble((double)_source_number_4942 / _2537) : (_source_number_4942 / _2537);
    }
    else {
        _source_number_4942 = binary_op(DIVIDE, _source_number_4942, _2537);
    }
    DeRef(_0);
    DeRef(_2537);
    _2537 = NOVALUE;

    /** 		if lSigned and shift_distance < 32 then*/
    if (_lSigned_4961 == 0) {
        goto L8; // [134] 161
    }
    _2540 = (_shift_distance_4943 < 32);
    if (_2540 == 0)
    {
        DeRef(_2540);
        _2540 = NOVALUE;
        goto L8; // [143] 161
    }
    else{
        DeRef(_2540);
        _2540 = NOVALUE;
    }

    /** 			source_number = or_bits(source_number, power(2, 31-shift_distance))*/
    _2541 = 31 - _shift_distance_4943;
    if ((long)((unsigned long)_2541 +(unsigned long) HIGH_BITS) >= 0){
        _2541 = NewDouble((double)_2541);
    }
    if (IS_ATOM_INT(_2541)) {
        _2542 = power(2, _2541);
    }
    else {
        temp_d.dbl = (double)2;
        _2542 = Dpower(&temp_d, DBL_PTR(_2541));
    }
    DeRef(_2541);
    _2541 = NOVALUE;
    _0 = _source_number_4942;
    if (IS_ATOM_INT(_source_number_4942) && IS_ATOM_INT(_2542)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4942 | (unsigned long)_2542;
             _source_number_4942 = MAKE_UINT(tu);
        }
    }
    else {
        _source_number_4942 = binary_op(OR_BITS, _source_number_4942, _2542);
    }
    DeRef(_0);
    DeRef(_2542);
    _2542 = NOVALUE;
L8: 
L6: 

    /** 	return and_bits(source_number, 0xFFFFFFFF)*/
    _2544 = binary_op(AND_BITS, _source_number_4942, _2228);
    DeRef(_source_number_4942);
    return _2544;
    ;
}


int  __stdcall _20rotate_bits(int _source_number_4978, int _shift_distance_4979)
{
    int _lTemp_4980 = NOVALUE;
    int _lSave_4981 = NOVALUE;
    int _lRest_4982 = NOVALUE;
    int _2564 = NOVALUE;
    int _2561 = NOVALUE;
    int _2558 = NOVALUE;
    int _2555 = NOVALUE;
    int _2554 = NOVALUE;
    int _2553 = NOVALUE;
    int _2549 = NOVALUE;
    int _2548 = NOVALUE;
    int _2547 = NOVALUE;
    int _2546 = NOVALUE;
    int _2545 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_distance_4979)) {
        _1 = (long)(DBL_PTR(_shift_distance_4979)->dbl);
        DeRefDS(_shift_distance_4979);
        _shift_distance_4979 = _1;
    }

    /** 	if sequence(source_number) then*/
    _2545 = IS_SEQUENCE(_source_number_4978);
    if (_2545 == 0)
    {
        _2545 = NOVALUE;
        goto L1; // [8] 55
    }
    else{
        _2545 = NOVALUE;
    }

    /** 		for i = 1 to length(source_number) do*/
    if (IS_SEQUENCE(_source_number_4978)){
            _2546 = SEQ_PTR(_source_number_4978)->length;
    }
    else {
        _2546 = 1;
    }
    {
        int _i_4986;
        _i_4986 = 1;
L2: 
        if (_i_4986 > _2546){
            goto L3; // [16] 48
        }

        /** 			source_number[i] = rotate_bits(source_number[i], shift_distance)*/
        _2 = (int)SEQ_PTR(_source_number_4978);
        _2547 = (int)*(((s1_ptr)_2)->base + _i_4986);
        DeRef(_2548);
        _2548 = _shift_distance_4979;
        Ref(_2547);
        _2549 = _20rotate_bits(_2547, _2548);
        _2547 = NOVALUE;
        _2548 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_number_4978);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_number_4978 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4986);
        _1 = *(int *)_2;
        *(int *)_2 = _2549;
        if( _1 != _2549 ){
            DeRef(_1);
        }
        _2549 = NOVALUE;

        /** 		end for*/
        _i_4986 = _i_4986 + 1;
        goto L2; // [43] 23
L3: 
        ;
    }

    /** 		return source_number*/
    DeRef(_lTemp_4980);
    DeRef(_lSave_4981);
    return _source_number_4978;
L1: 

    /** 	source_number = and_bits(source_number, 0xFFFFFFFF)*/
    _0 = _source_number_4978;
    _source_number_4978 = binary_op(AND_BITS, _source_number_4978, _2228);
    DeRef(_0);

    /** 	if shift_distance = 0 then*/
    if (_shift_distance_4979 != 0)
    goto L4; // [63] 74

    /** 		return source_number*/
    DeRef(_lTemp_4980);
    DeRef(_lSave_4981);
    return _source_number_4978;
L4: 

    /** 	if shift_distance < 0 then*/
    if (_shift_distance_4979 >= 0)
    goto L5; // [76] 106

    /** 		lSave = not_bits(power(2, 32 + shift_distance) - 1) 	*/
    _2553 = 32 + _shift_distance_4979;
    if ((long)((unsigned long)_2553 + (unsigned long)HIGH_BITS) >= 0) 
    _2553 = NewDouble((double)_2553);
    if (IS_ATOM_INT(_2553)) {
        _2554 = power(2, _2553);
    }
    else {
        temp_d.dbl = (double)2;
        _2554 = Dpower(&temp_d, DBL_PTR(_2553));
    }
    DeRef(_2553);
    _2553 = NOVALUE;
    if (IS_ATOM_INT(_2554)) {
        _2555 = _2554 - 1;
        if ((long)((unsigned long)_2555 +(unsigned long) HIGH_BITS) >= 0){
            _2555 = NewDouble((double)_2555);
        }
    }
    else {
        _2555 = NewDouble(DBL_PTR(_2554)->dbl - (double)1);
    }
    DeRef(_2554);
    _2554 = NOVALUE;
    DeRef(_lSave_4981);
    if (IS_ATOM_INT(_2555))
    _lSave_4981 = not_bits(_2555);
    else
    _lSave_4981 = unary_op(NOT_BITS, _2555);
    DeRef(_2555);
    _2555 = NOVALUE;

    /** 		lRest = 32 + shift_distance*/
    _lRest_4982 = 32 + _shift_distance_4979;
    goto L6; // [103] 123
L5: 

    /** 		lSave = power(2, shift_distance) - 1*/
    _2558 = power(2, _shift_distance_4979);
    DeRef(_lSave_4981);
    if (IS_ATOM_INT(_2558)) {
        _lSave_4981 = _2558 - 1;
        if ((long)((unsigned long)_lSave_4981 +(unsigned long) HIGH_BITS) >= 0){
            _lSave_4981 = NewDouble((double)_lSave_4981);
        }
    }
    else {
        _lSave_4981 = NewDouble(DBL_PTR(_2558)->dbl - (double)1);
    }
    DeRef(_2558);
    _2558 = NOVALUE;

    /** 		lRest = shift_distance - 32*/
    _lRest_4982 = _shift_distance_4979 - 32;
L6: 

    /** 	lTemp = shift_bits(and_bits(source_number, lSave), lRest)*/
    if (IS_ATOM_INT(_source_number_4978) && IS_ATOM_INT(_lSave_4981)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4978 & (unsigned long)_lSave_4981;
             _2561 = MAKE_UINT(tu);
        }
    }
    else {
        _2561 = binary_op(AND_BITS, _source_number_4978, _lSave_4981);
    }
    _0 = _lTemp_4980;
    _lTemp_4980 = _20shift_bits(_2561, _lRest_4982);
    DeRef(_0);
    _2561 = NOVALUE;

    /** 	source_number = shift_bits(source_number, shift_distance)*/
    Ref(_source_number_4978);
    _0 = _source_number_4978;
    _source_number_4978 = _20shift_bits(_source_number_4978, _shift_distance_4979);
    DeRef(_0);

    /** 	return or_bits(source_number, lTemp)*/
    if (IS_ATOM_INT(_source_number_4978) && IS_ATOM_INT(_lTemp_4980)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4978 | (unsigned long)_lTemp_4980;
             _2564 = MAKE_UINT(tu);
        }
    }
    else {
        _2564 = binary_op(OR_BITS, _source_number_4978, _lTemp_4980);
    }
    DeRef(_source_number_4978);
    DeRef(_lTemp_4980);
    DeRef(_lSave_4981);
    return _2564;
    ;
}


int  __stdcall _20gcd(int _p_5011, int _q_5012)
{
    int _r_5013 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if p < 0 then*/
    if (binary_op_a(GREATEREQ, _p_5011, 0)){
        goto L1; // [3] 13
    }

    /** 		p = -p*/
    _0 = _p_5011;
    if (IS_ATOM_INT(_p_5011)) {
        if ((unsigned long)_p_5011 == 0xC0000000)
        _p_5011 = (int)NewDouble((double)-0xC0000000);
        else
        _p_5011 = - _p_5011;
    }
    else {
        _p_5011 = unary_op(UMINUS, _p_5011);
    }
    DeRef(_0);
L1: 

    /** 	if q < 0 then*/
    if (binary_op_a(GREATEREQ, _q_5012, 0)){
        goto L2; // [15] 25
    }

    /** 		q = -q*/
    _0 = _q_5012;
    if (IS_ATOM_INT(_q_5012)) {
        if ((unsigned long)_q_5012 == 0xC0000000)
        _q_5012 = (int)NewDouble((double)-0xC0000000);
        else
        _q_5012 = - _q_5012;
    }
    else {
        _q_5012 = unary_op(UMINUS, _q_5012);
    }
    DeRef(_0);
L2: 

    /** 	p = floor(p)*/
    _0 = _p_5011;
    if (IS_ATOM_INT(_p_5011))
    _p_5011 = e_floor(_p_5011);
    else
    _p_5011 = unary_op(FLOOR, _p_5011);
    DeRef(_0);

    /** 	q = floor(q)*/
    _0 = _q_5012;
    if (IS_ATOM_INT(_q_5012))
    _q_5012 = e_floor(_q_5012);
    else
    _q_5012 = unary_op(FLOOR, _q_5012);
    DeRef(_0);

    /** 	if p < q then*/
    if (binary_op_a(GREATEREQ, _p_5011, _q_5012)){
        goto L3; // [37] 57
    }

    /** 		r = p*/
    Ref(_p_5011);
    DeRef(_r_5013);
    _r_5013 = _p_5011;

    /** 		p = q*/
    Ref(_q_5012);
    DeRef(_p_5011);
    _p_5011 = _q_5012;

    /** 		q = r*/
    Ref(_r_5013);
    DeRef(_q_5012);
    _q_5012 = _r_5013;
L3: 

    /** 	if q = 0 then*/
    if (binary_op_a(NOTEQ, _q_5012, 0)){
        goto L4; // [59] 94
    }

    /** 		return p*/
    DeRef(_q_5012);
    DeRef(_r_5013);
    return _p_5011;

    /**     while r > 1 with entry do*/
    goto L4; // [72] 94
L5: 
    if (binary_op_a(LESSEQ, _r_5013, 1)){
        goto L6; // [77] 105
    }

    /** 		p = q*/
    Ref(_q_5012);
    DeRef(_p_5011);
    _p_5011 = _q_5012;

    /** 		q = r*/
    Ref(_r_5013);
    DeRef(_q_5012);
    _q_5012 = _r_5013;

    /** 	entry*/
L4: 

    /** 		r = remainder(p, q)*/
    DeRef(_r_5013);
    if (IS_ATOM_INT(_p_5011) && IS_ATOM_INT(_q_5012)) {
        _r_5013 = (_p_5011 % _q_5012);
    }
    else {
        if (IS_ATOM_INT(_p_5011)) {
            temp_d.dbl = (double)_p_5011;
            _r_5013 = Dremainder(&temp_d, DBL_PTR(_q_5012));
        }
        else {
            if (IS_ATOM_INT(_q_5012)) {
                temp_d.dbl = (double)_q_5012;
                _r_5013 = Dremainder(DBL_PTR(_p_5011), &temp_d);
            }
            else
            _r_5013 = Dremainder(DBL_PTR(_p_5011), DBL_PTR(_q_5012));
        }
    }

    /**     end while*/
    goto L5; // [102] 75
L6: 

    /** 	if r = 1 then*/
    if (binary_op_a(NOTEQ, _r_5013, 1)){
        goto L7; // [109] 122
    }

    /** 		return 1*/
    DeRef(_p_5011);
    DeRef(_q_5012);
    DeRef(_r_5013);
    return 1;
    goto L8; // [119] 129
L7: 

    /** 		return q*/
    DeRef(_p_5011);
    DeRef(_r_5013);
    return _q_5012;
L8: 
    ;
}


int  __stdcall _20approx(int _p_5034, int _q_5035, int _epsilon_5036)
{
    int _msg_inlined_crash_at_30_5048 = NOVALUE;
    int _2598 = NOVALUE;
    int _2596 = NOVALUE;
    int _2595 = NOVALUE;
    int _2594 = NOVALUE;
    int _2593 = NOVALUE;
    int _2592 = NOVALUE;
    int _2591 = NOVALUE;
    int _2590 = NOVALUE;
    int _2589 = NOVALUE;
    int _2588 = NOVALUE;
    int _2587 = NOVALUE;
    int _2586 = NOVALUE;
    int _2585 = NOVALUE;
    int _2584 = NOVALUE;
    int _2583 = NOVALUE;
    int _2580 = NOVALUE;
    int _2579 = NOVALUE;
    int _2578 = NOVALUE;
    int _2577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(p) then*/
    _2577 = IS_SEQUENCE(_p_5034);
    if (_2577 == 0)
    {
        _2577 = NOVALUE;
        goto L1; // [6] 146
    }
    else{
        _2577 = NOVALUE;
    }

    /** 		if sequence(q) then*/
    _2578 = IS_SEQUENCE(_q_5035);
    if (_2578 == 0)
    {
        _2578 = NOVALUE;
        goto L2; // [14] 98
    }
    else{
        _2578 = NOVALUE;
    }

    /** 			if length(p) != length(q) then*/
    if (IS_SEQUENCE(_p_5034)){
            _2579 = SEQ_PTR(_p_5034)->length;
    }
    else {
        _2579 = 1;
    }
    if (IS_SEQUENCE(_q_5035)){
            _2580 = SEQ_PTR(_q_5035)->length;
    }
    else {
        _2580 = 1;
    }
    if (_2579 == _2580)
    goto L3; // [25] 50

    /** 				error:crash("approx(): Sequence arguments must be the same length")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_30_5048);
    _msg_inlined_crash_at_30_5048 = EPrintf(-9999999, _2582, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_30_5048);

    /** end procedure*/
    goto L4; // [44] 47
L4: 
    DeRefi(_msg_inlined_crash_at_30_5048);
    _msg_inlined_crash_at_30_5048 = NOVALUE;
L3: 

    /** 			for i = 1 to length(p) do*/
    if (IS_SEQUENCE(_p_5034)){
            _2583 = SEQ_PTR(_p_5034)->length;
    }
    else {
        _2583 = 1;
    }
    {
        int _i_5050;
        _i_5050 = 1;
L5: 
        if (_i_5050 > _2583){
            goto L6; // [55] 89
        }

        /** 				p[i] = approx(p[i], q[i])*/
        _2 = (int)SEQ_PTR(_p_5034);
        _2584 = (int)*(((s1_ptr)_2)->base + _i_5050);
        _2 = (int)SEQ_PTR(_q_5035);
        _2585 = (int)*(((s1_ptr)_2)->base + _i_5050);
        Ref(_2584);
        Ref(_2585);
        RefDS(_2576);
        _2586 = _20approx(_2584, _2585, _2576);
        _2584 = NOVALUE;
        _2585 = NOVALUE;
        _2 = (int)SEQ_PTR(_p_5034);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _p_5034 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5050);
        _1 = *(int *)_2;
        *(int *)_2 = _2586;
        if( _1 != _2586 ){
            DeRef(_1);
        }
        _2586 = NOVALUE;

        /** 			end for*/
        _i_5050 = _i_5050 + 1;
        goto L5; // [84] 62
L6: 
        ;
    }

    /** 			return p*/
    DeRef(_q_5035);
    DeRef(_epsilon_5036);
    return _p_5034;
    goto L7; // [95] 242
L2: 

    /** 			for i = 1 to length(p) do*/
    if (IS_SEQUENCE(_p_5034)){
            _2587 = SEQ_PTR(_p_5034)->length;
    }
    else {
        _2587 = 1;
    }
    {
        int _i_5057;
        _i_5057 = 1;
L8: 
        if (_i_5057 > _2587){
            goto L9; // [103] 136
        }

        /** 				p[i] = approx(p[i], q)*/
        _2 = (int)SEQ_PTR(_p_5034);
        _2588 = (int)*(((s1_ptr)_2)->base + _i_5057);
        Ref(_q_5035);
        DeRef(_2589);
        _2589 = _q_5035;
        Ref(_2588);
        RefDS(_2576);
        _2590 = _20approx(_2588, _2589, _2576);
        _2588 = NOVALUE;
        _2589 = NOVALUE;
        _2 = (int)SEQ_PTR(_p_5034);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _p_5034 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5057);
        _1 = *(int *)_2;
        *(int *)_2 = _2590;
        if( _1 != _2590 ){
            DeRef(_1);
        }
        _2590 = NOVALUE;

        /** 			end for*/
        _i_5057 = _i_5057 + 1;
        goto L8; // [131] 110
L9: 
        ;
    }

    /** 			return p*/
    DeRef(_q_5035);
    DeRef(_epsilon_5036);
    return _p_5034;
    goto L7; // [143] 242
L1: 

    /** 	elsif sequence(q) then*/
    _2591 = IS_SEQUENCE(_q_5035);
    if (_2591 == 0)
    {
        _2591 = NOVALUE;
        goto LA; // [151] 201
    }
    else{
        _2591 = NOVALUE;
    }

    /** 			for i = 1 to length(q) do*/
    if (IS_SEQUENCE(_q_5035)){
            _2592 = SEQ_PTR(_q_5035)->length;
    }
    else {
        _2592 = 1;
    }
    {
        int _i_5065;
        _i_5065 = 1;
LB: 
        if (_i_5065 > _2592){
            goto LC; // [159] 192
        }

        /** 				q[i] = approx(p, q[i])*/
        _2 = (int)SEQ_PTR(_q_5035);
        _2593 = (int)*(((s1_ptr)_2)->base + _i_5065);
        Ref(_p_5034);
        DeRef(_2594);
        _2594 = _p_5034;
        Ref(_2593);
        RefDS(_2576);
        _2595 = _20approx(_2594, _2593, _2576);
        _2594 = NOVALUE;
        _2593 = NOVALUE;
        _2 = (int)SEQ_PTR(_q_5035);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _q_5035 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5065);
        _1 = *(int *)_2;
        *(int *)_2 = _2595;
        if( _1 != _2595 ){
            DeRef(_1);
        }
        _2595 = NOVALUE;

        /** 			end for*/
        _i_5065 = _i_5065 + 1;
        goto LB; // [187] 166
LC: 
        ;
    }

    /** 			return q*/
    DeRef(_p_5034);
    DeRef(_epsilon_5036);
    return _q_5035;
    goto L7; // [198] 242
LA: 

    /** 		if p > (q + epsilon) then*/
    if (IS_ATOM_INT(_q_5035) && IS_ATOM_INT(_epsilon_5036)) {
        _2596 = _q_5035 + _epsilon_5036;
        if ((long)((unsigned long)_2596 + (unsigned long)HIGH_BITS) >= 0) 
        _2596 = NewDouble((double)_2596);
    }
    else {
        _2596 = binary_op(PLUS, _q_5035, _epsilon_5036);
    }
    if (binary_op_a(LESSEQ, _p_5034, _2596)){
        DeRef(_2596);
        _2596 = NOVALUE;
        goto LD; // [207] 218
    }
    DeRef(_2596);
    _2596 = NOVALUE;

    /** 			return 1*/
    DeRef(_p_5034);
    DeRef(_q_5035);
    DeRef(_epsilon_5036);
    return 1;
LD: 

    /** 		if p < (q - epsilon) then*/
    if (IS_ATOM_INT(_q_5035) && IS_ATOM_INT(_epsilon_5036)) {
        _2598 = _q_5035 - _epsilon_5036;
        if ((long)((unsigned long)_2598 +(unsigned long) HIGH_BITS) >= 0){
            _2598 = NewDouble((double)_2598);
        }
    }
    else {
        _2598 = binary_op(MINUS, _q_5035, _epsilon_5036);
    }
    if (binary_op_a(GREATEREQ, _p_5034, _2598)){
        DeRef(_2598);
        _2598 = NOVALUE;
        goto LE; // [224] 235
    }
    DeRef(_2598);
    _2598 = NOVALUE;

    /** 			return -1*/
    DeRef(_p_5034);
    DeRef(_q_5035);
    DeRef(_epsilon_5036);
    return -1;
LE: 

    /** 		return 0*/
    DeRef(_p_5034);
    DeRef(_q_5035);
    DeRef(_epsilon_5036);
    return 0;
L7: 
    ;
}


int  __stdcall _20powof2(int _p_5079)
{
    int _2602 = NOVALUE;
    int _2601 = NOVALUE;
    int _2600 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return not (and_bits(p, p-1))*/
    if (IS_ATOM_INT(_p_5079)) {
        _2600 = _p_5079 - 1;
        if ((long)((unsigned long)_2600 +(unsigned long) HIGH_BITS) >= 0){
            _2600 = NewDouble((double)_2600);
        }
    }
    else {
        _2600 = binary_op(MINUS, _p_5079, 1);
    }
    if (IS_ATOM_INT(_p_5079) && IS_ATOM_INT(_2600)) {
        {unsigned long tu;
             tu = (unsigned long)_p_5079 & (unsigned long)_2600;
             _2601 = MAKE_UINT(tu);
        }
    }
    else {
        _2601 = binary_op(AND_BITS, _p_5079, _2600);
    }
    DeRef(_2600);
    _2600 = NOVALUE;
    if (IS_ATOM_INT(_2601)) {
        _2602 = (_2601 == 0);
    }
    else {
        _2602 = unary_op(NOT, _2601);
    }
    DeRef(_2601);
    _2601 = NOVALUE;
    DeRef(_p_5079);
    return _2602;
    ;
}


int  __stdcall _20is_even(int _test_integer_5085)
{
    int _2604 = NOVALUE;
    int _2603 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_test_integer_5085)) {
        _1 = (long)(DBL_PTR(_test_integer_5085)->dbl);
        DeRefDS(_test_integer_5085);
        _test_integer_5085 = _1;
    }

    /** 	return (and_bits(test_integer, 1) = 0)*/
    {unsigned long tu;
         tu = (unsigned long)_test_integer_5085 & (unsigned long)1;
         _2603 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_2603)) {
        _2604 = (_2603 == 0);
    }
    else {
        _2604 = (DBL_PTR(_2603)->dbl == (double)0);
    }
    DeRef(_2603);
    _2603 = NOVALUE;
    return _2604;
    ;
}


int  __stdcall _20is_even_obj(int _test_object_5090)
{
    int _2611 = NOVALUE;
    int _2610 = NOVALUE;
    int _2609 = NOVALUE;
    int _2608 = NOVALUE;
    int _2607 = NOVALUE;
    int _2606 = NOVALUE;
    int _2605 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(test_object) then*/
    _2605 = IS_ATOM(_test_object_5090);
    if (_2605 == 0)
    {
        _2605 = NOVALUE;
        goto L1; // [6] 39
    }
    else{
        _2605 = NOVALUE;
    }

    /** 		if integer(test_object) then*/
    if (IS_ATOM_INT(_test_object_5090))
    _2606 = 1;
    else if (IS_ATOM_DBL(_test_object_5090))
    _2606 = IS_ATOM_INT(DoubleToInt(_test_object_5090));
    else
    _2606 = 0;
    if (_2606 == 0)
    {
        _2606 = NOVALUE;
        goto L2; // [14] 32
    }
    else{
        _2606 = NOVALUE;
    }

    /** 			return (and_bits(test_object, 1) = 0)*/
    if (IS_ATOM_INT(_test_object_5090)) {
        {unsigned long tu;
             tu = (unsigned long)_test_object_5090 & (unsigned long)1;
             _2607 = MAKE_UINT(tu);
        }
    }
    else {
        _2607 = binary_op(AND_BITS, _test_object_5090, 1);
    }
    if (IS_ATOM_INT(_2607)) {
        _2608 = (_2607 == 0);
    }
    else {
        _2608 = binary_op(EQUALS, _2607, 0);
    }
    DeRef(_2607);
    _2607 = NOVALUE;
    DeRef(_test_object_5090);
    return _2608;
L2: 

    /** 		return 0*/
    DeRef(_test_object_5090);
    DeRef(_2608);
    _2608 = NOVALUE;
    return 0;
L1: 

    /** 	for i = 1 to length(test_object) do*/
    if (IS_SEQUENCE(_test_object_5090)){
            _2609 = SEQ_PTR(_test_object_5090)->length;
    }
    else {
        _2609 = 1;
    }
    {
        int _i_5098;
        _i_5098 = 1;
L3: 
        if (_i_5098 > _2609){
            goto L4; // [44] 72
        }

        /** 		test_object[i] = is_even_obj(test_object[i])*/
        _2 = (int)SEQ_PTR(_test_object_5090);
        _2610 = (int)*(((s1_ptr)_2)->base + _i_5098);
        Ref(_2610);
        _2611 = _20is_even_obj(_2610);
        _2610 = NOVALUE;
        _2 = (int)SEQ_PTR(_test_object_5090);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _test_object_5090 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5098);
        _1 = *(int *)_2;
        *(int *)_2 = _2611;
        if( _1 != _2611 ){
            DeRef(_1);
        }
        _2611 = NOVALUE;

        /** 	end for*/
        _i_5098 = _i_5098 + 1;
        goto L3; // [67] 51
L4: 
        ;
    }

    /** 	return test_object*/
    DeRef(_2608);
    _2608 = NOVALUE;
    return _test_object_5090;
    ;
}



// 0xBE70FE65
