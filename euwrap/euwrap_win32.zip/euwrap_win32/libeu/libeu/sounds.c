// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _57sound(int _sound_type_23752)
{
    int _13184 = NOVALUE;
    int _13182 = NOVALUE;
    int _13178 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not object(xMessageBeep) then*/
    if( NOVALUE == _57xMessageBeep_23748 ){
        _13178 = 0;
    }
    else{
        _13178 = 1;
    }
    if (_13178 != 0)
    goto L1; // [6] 34
    _13178 = NOVALUE;

    /** 		xUser32 = dll:open_dll("user32.dll")*/
    RefDS(_13156);
    _0 = _13open_dll(_13156);
    DeRef(_57xUser32_23749);
    _57xUser32_23749 = _0;

    /** 		xMessageBeep   = dll:define_c_proc(xUser32, "MessageBeep", {C_UINT})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _13182 = MAKE_SEQ(_1);
    Ref(_57xUser32_23749);
    RefDS(_13181);
    _0 = _13define_c_proc(_57xUser32_23749, _13181, _13182);
    _57xMessageBeep_23748 = _0;
    _13182 = NOVALUE;
    if (!IS_ATOM_INT(_57xMessageBeep_23748)) {
        _1 = (long)(DBL_PTR(_57xMessageBeep_23748)->dbl);
        DeRefDS(_57xMessageBeep_23748);
        _57xMessageBeep_23748 = _1;
    }
L1: 

    /**     c_proc( xMessageBeep, { sound_type } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sound_type_23752);
    *((int *)(_2+4)) = _sound_type_23752;
    _13184 = MAKE_SEQ(_1);
    call_c(0, _57xMessageBeep_23748, _13184);
    DeRefDS(_13184);
    _13184 = NOVALUE;

    /** end procedure*/
    DeRef(_sound_type_23752);
    return;
    ;
}



// 0x441E3384
