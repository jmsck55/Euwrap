// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _46process(int _o_20991)
{
    int _11866 = NOVALUE;
    int _11865 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(o) then*/
    _11865 = IS_ATOM(_o_20991);
    if (_11865 == 0)
    {
        _11865 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _11865 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_o_20991);
    return 0;
L1: 

    /** 	if length(o) != 4 then*/
    if (IS_SEQUENCE(_o_20991)){
            _11866 = SEQ_PTR(_o_20991)->length;
    }
    else {
        _11866 = 1;
    }
    if (_11866 == 4)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_o_20991);
    return 0;
L2: 

    /** 	return 1*/
    DeRef(_o_20991);
    return 1;
    ;
}


int  __stdcall _46close(int _fd_20999)
{
    int _ret_21000 = NOVALUE;
    int _get_errno_inlined_get_errno_at_25_21006 = NOVALUE;
    int _11868 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		ret=c_func(iCloseHandle,{fd})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_20999);
    *((int *)(_2+4)) = _fd_20999;
    _11868 = MAKE_SEQ(_1);
    DeRef(_ret_21000);
    _ret_21000 = call_c(1, _46iCloseHandle_20935, _11868);
    DeRefDS(_11868);
    _11868 = NOVALUE;

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_21000, 0)){
        goto L1; // [20] 45
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return c_func(iGetLastError,{})*/
    DeRef(_46os_errno_20985);
    _46os_errno_20985 = call_c(1, _46iGetLastError_20943, _5);

    /** 		return -1*/
    DeRef(_fd_20999);
    DeRef(_ret_21000);
    return -1;
L1: 

    /** 	return 0*/
    DeRef(_fd_20999);
    DeRef(_ret_21000);
    return 0;
    ;
}


void  __stdcall _46kill(int _p_21009, int _signal_21010)
{
    int _11880 = NOVALUE;
    int _11879 = NOVALUE;
    int _11878 = NOVALUE;
    int _11877 = NOVALUE;
    int _11876 = NOVALUE;
    int _11875 = NOVALUE;
    int _11874 = NOVALUE;
    int _11873 = NOVALUE;
    int _11872 = NOVALUE;
    int _11871 = NOVALUE;
    int _0, _1, _2;
    

    /** 	close(p[STDIN])*/
    _2 = (int)SEQ_PTR(_p_21009);
    _11871 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11871);
    _11872 = _46close(_11871);
    _11871 = NOVALUE;

    /** 	close(p[STDOUT])*/
    _2 = (int)SEQ_PTR(_p_21009);
    _11873 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11873);
    _11874 = _46close(_11873);
    _11873 = NOVALUE;

    /** 	close(p[STDERR])*/
    _2 = (int)SEQ_PTR(_p_21009);
    _11875 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_11875);
    _11876 = _46close(_11875);
    _11875 = NOVALUE;

    /** 	ifdef WINDOWS then*/

    /** 		c_func(iTerminateProcess,{p[PID],signal and 0})*/
    _2 = (int)SEQ_PTR(_p_21009);
    _11877 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_signal_21010)) {
        _11878 = (_signal_21010 != 0 && 0 != 0);
    }
    else {
        temp_d.dbl = (double)0;
        _11878 = Dand(DBL_PTR(_signal_21010), &temp_d);
    }
    Ref(_11877);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11877;
    ((int *)_2)[2] = _11878;
    _11879 = MAKE_SEQ(_1);
    _11878 = NOVALUE;
    _11877 = NOVALUE;
    _11880 = call_c(1, _46iTerminateProcess_20939, _11879);
    DeRefDS(_11879);
    _11879 = NOVALUE;

    /** end procedure*/
    DeRef(_p_21009);
    DeRef(_signal_21010);
    DeRef(_11880);
    _11880 = NOVALUE;
    DeRef(_11872);
    _11872 = NOVALUE;
    DeRef(_11874);
    _11874 = NOVALUE;
    DeRef(_11876);
    _11876 = NOVALUE;
    return;
    ;
}


int _46os_pipe()
{
    int _get_errno_inlined_get_errno_at_88_21042 = NOVALUE;
    int _handles_21023 = NOVALUE;
    int _ret_21024 = NOVALUE;
    int _psaAttrib_21025 = NOVALUE;
    int _phWriteToPipe_21026 = NOVALUE;
    int _phReadFromPipe_21027 = NOVALUE;
    int _11890 = NOVALUE;
    int _11888 = NOVALUE;
    int _11886 = NOVALUE;
    int _11884 = NOVALUE;
    int _11882 = NOVALUE;
    int _11881 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		atom psaAttrib, phWriteToPipe, phReadFromPipe*/

    /** 		psaAttrib = machine:allocate(SA_SIZE+2*4)*/
    _11881 = 8;
    _11882 = 20;
    _11881 = NOVALUE;
    _0 = _psaAttrib_21025;
    _psaAttrib_21025 = _14allocate(20, 0);
    DeRef(_0);
    _11882 = NOVALUE;

    /** 		poke4(psaAttrib,{SA_SIZE,0,1})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 12;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    _11884 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_psaAttrib_21025)){
        poke4_addr = (unsigned long *)_psaAttrib_21025;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_psaAttrib_21025)->dbl);
    }
    _1 = (int)SEQ_PTR(_11884);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_11884);
    _11884 = NOVALUE;

    /** 		phWriteToPipe = psaAttrib+SA_SIZE*/
    DeRef(_phWriteToPipe_21026);
    if (IS_ATOM_INT(_psaAttrib_21025)) {
        _phWriteToPipe_21026 = _psaAttrib_21025 + 12;
        if ((long)((unsigned long)_phWriteToPipe_21026 + (unsigned long)HIGH_BITS) >= 0) 
        _phWriteToPipe_21026 = NewDouble((double)_phWriteToPipe_21026);
    }
    else {
        _phWriteToPipe_21026 = NewDouble(DBL_PTR(_psaAttrib_21025)->dbl + (double)12);
    }

    /** 		phReadFromPipe = psaAttrib+SA_SIZE+4*/
    if (IS_ATOM_INT(_psaAttrib_21025)) {
        _11886 = _psaAttrib_21025 + 12;
        if ((long)((unsigned long)_11886 + (unsigned long)HIGH_BITS) >= 0) 
        _11886 = NewDouble((double)_11886);
    }
    else {
        _11886 = NewDouble(DBL_PTR(_psaAttrib_21025)->dbl + (double)12);
    }
    DeRef(_phReadFromPipe_21027);
    if (IS_ATOM_INT(_11886)) {
        _phReadFromPipe_21027 = _11886 + 4;
        if ((long)((unsigned long)_phReadFromPipe_21027 + (unsigned long)HIGH_BITS) >= 0) 
        _phReadFromPipe_21027 = NewDouble((double)_phReadFromPipe_21027);
    }
    else {
        _phReadFromPipe_21027 = NewDouble(DBL_PTR(_11886)->dbl + (double)4);
    }
    DeRef(_11886);
    _11886 = NOVALUE;

    /** 		ret = c_func(iCreatePipe,{phReadFromPipe,phWriteToPipe,psaAttrib,0})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_phReadFromPipe_21027);
    *((int *)(_2+4)) = _phReadFromPipe_21027;
    Ref(_phWriteToPipe_21026);
    *((int *)(_2+8)) = _phWriteToPipe_21026;
    Ref(_psaAttrib_21025);
    *((int *)(_2+12)) = _psaAttrib_21025;
    *((int *)(_2+16)) = 0;
    _11888 = MAKE_SEQ(_1);
    DeRef(_ret_21024);
    _ret_21024 = call_c(1, _46iCreatePipe_20923, _11888);
    DeRefDS(_11888);
    _11888 = NOVALUE;

    /** 		handles = peek4u({phWriteToPipe,2})*/
    Ref(_phWriteToPipe_21026);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _phWriteToPipe_21026;
    ((int *)_2)[2] = 2;
    _11890 = MAKE_SEQ(_1);
    DeRef(_handles_21023);
    _1 = (int)SEQ_PTR(_11890);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _handles_21023 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_11890);
    _11890 = NOVALUE;

    /** 		machine:free(psaAttrib)*/
    Ref(_psaAttrib_21025);
    _14free(_psaAttrib_21025);

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_21024, 0)){
        goto L1; // [83] 108
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return c_func(iGetLastError,{})*/
    DeRef(_46os_errno_20985);
    _46os_errno_20985 = call_c(1, _46iGetLastError_20943, _5);

    /** 		return -1*/
    DeRef(_handles_21023);
    DeRef(_ret_21024);
    DeRef(_psaAttrib_21025);
    DeRef(_phWriteToPipe_21026);
    DeRef(_phReadFromPipe_21027);
    return -1;
L1: 

    /** 	return handles*/
    DeRef(_ret_21024);
    DeRef(_psaAttrib_21025);
    DeRef(_phWriteToPipe_21026);
    DeRef(_phReadFromPipe_21027);
    return _handles_21023;
    ;
}


int  __stdcall _46read(int _fd_21045, int _bytes_21046)
{
    int _data_21049 = NOVALUE;
    int _ret_21050 = NOVALUE;
    int _ReadCount_21051 = NOVALUE;
    int _buf_21052 = NOVALUE;
    int _pReadCount_21055 = NOVALUE;
    int _get_errno_inlined_get_errno_at_70_21063 = NOVALUE;
    int _11900 = NOVALUE;
    int _11896 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_bytes_21046)) {
        _1 = (long)(DBL_PTR(_bytes_21046)->dbl);
        DeRefDS(_bytes_21046);
        _bytes_21046 = _1;
    }

    /** 	if bytes=0 then return "" end if*/
    if (_bytes_21046 != 0)
    goto L1; // [5] 14
    RefDS(_5);
    DeRef(_fd_21045);
    DeRefi(_data_21049);
    DeRef(_ret_21050);
    DeRef(_ReadCount_21051);
    DeRef(_buf_21052);
    DeRef(_pReadCount_21055);
    return _5;
L1: 

    /** 	sequence data*/

    /** 	atom*/

    /** 		buf = allocate(bytes)*/
    _0 = _buf_21052;
    _buf_21052 = _14allocate(_bytes_21046, 0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		atom pReadCount=machine:allocate(4)*/
    _0 = _pReadCount_21055;
    _pReadCount_21055 = _14allocate(4, 0);
    DeRef(_0);

    /** 		ret = c_func(iReadFile,{fd,buf,bytes,pReadCount,0})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_21045);
    *((int *)(_2+4)) = _fd_21045;
    Ref(_buf_21052);
    *((int *)(_2+8)) = _buf_21052;
    *((int *)(_2+12)) = _bytes_21046;
    Ref(_pReadCount_21055);
    *((int *)(_2+16)) = _pReadCount_21055;
    *((int *)(_2+20)) = 0;
    _11896 = MAKE_SEQ(_1);
    DeRef(_ret_21050);
    _ret_21050 = call_c(1, _46iReadFile_20927, _11896);
    DeRefDS(_11896);
    _11896 = NOVALUE;

    /** 		ReadCount=peek4u(pReadCount)*/
    DeRef(_ReadCount_21051);
    if (IS_ATOM_INT(_pReadCount_21055)) {
        _ReadCount_21051 = *(unsigned long *)_pReadCount_21055;
        if ((unsigned)_ReadCount_21051 > (unsigned)MAXINT)
        _ReadCount_21051 = NewDouble((double)(unsigned long)_ReadCount_21051);
    }
    else {
        _ReadCount_21051 = *(unsigned long *)(unsigned long)(DBL_PTR(_pReadCount_21055)->dbl);
        if ((unsigned)_ReadCount_21051 > (unsigned)MAXINT)
        _ReadCount_21051 = NewDouble((double)(unsigned long)_ReadCount_21051);
    }

    /** 		machine:free(pReadCount)*/
    Ref(_pReadCount_21055);
    _14free(_pReadCount_21055);

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_21050, 0)){
        goto L2; // [65] 95
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return c_func(iGetLastError,{})*/
    DeRef(_46os_errno_20985);
    _46os_errno_20985 = call_c(1, _46iGetLastError_20943, _5);

    /** 		machine:free(buf)*/
    Ref(_buf_21052);
    _14free(_buf_21052);

    /** 		return ""*/
    RefDS(_5);
    DeRef(_fd_21045);
    DeRefi(_data_21049);
    DeRef(_ret_21050);
    DeRef(_ReadCount_21051);
    DeRef(_buf_21052);
    DeRef(_pReadCount_21055);
    return _5;
L2: 

    /** 	data=peek({buf,ReadCount})*/
    Ref(_ReadCount_21051);
    Ref(_buf_21052);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _buf_21052;
    ((int *)_2)[2] = _ReadCount_21051;
    _11900 = MAKE_SEQ(_1);
    DeRefi(_data_21049);
    _1 = (int)SEQ_PTR(_11900);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _data_21049 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_11900);
    _11900 = NOVALUE;

    /** 	machine:free(buf)*/
    Ref(_buf_21052);
    _14free(_buf_21052);

    /** 	return data*/
    DeRef(_fd_21045);
    DeRef(_ret_21050);
    DeRef(_ReadCount_21051);
    DeRef(_buf_21052);
    DeRef(_pReadCount_21055);
    return _data_21049;
    ;
}


int  __stdcall _46write(int _fd_21068, int _str_21069)
{
    int _buf_21070 = NOVALUE;
    int _ret_21073 = NOVALUE;
    int _WrittenCount_21074 = NOVALUE;
    int _pWrittenCount_21075 = NOVALUE;
    int _get_errno_inlined_get_errno_at_63_21084 = NOVALUE;
    int _11905 = NOVALUE;
    int _11904 = NOVALUE;
    int _0, _1, _2;
    

    /** 		buf = allocate_string(str),*/
    RefDS(_str_21069);
    _0 = _buf_21070;
    _buf_21070 = _14allocate_string(_str_21069, 0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		atom pWrittenCount=machine:allocate(4)*/
    _0 = _pWrittenCount_21075;
    _pWrittenCount_21075 = _14allocate(4, 0);
    DeRef(_0);

    /** 		ret=c_func(iWriteFile,{fd,buf,length(str),pWrittenCount,0})*/
    if (IS_SEQUENCE(_str_21069)){
            _11904 = SEQ_PTR(_str_21069)->length;
    }
    else {
        _11904 = 1;
    }
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_21068);
    *((int *)(_2+4)) = _fd_21068;
    Ref(_buf_21070);
    *((int *)(_2+8)) = _buf_21070;
    *((int *)(_2+12)) = _11904;
    Ref(_pWrittenCount_21075);
    *((int *)(_2+16)) = _pWrittenCount_21075;
    *((int *)(_2+20)) = 0;
    _11905 = MAKE_SEQ(_1);
    _11904 = NOVALUE;
    DeRef(_ret_21073);
    _ret_21073 = call_c(1, _46iWriteFile_20931, _11905);
    DeRefDS(_11905);
    _11905 = NOVALUE;

    /** 		WrittenCount=peek4u(pWrittenCount)*/
    DeRef(_WrittenCount_21074);
    if (IS_ATOM_INT(_pWrittenCount_21075)) {
        _WrittenCount_21074 = *(unsigned long *)_pWrittenCount_21075;
        if ((unsigned)_WrittenCount_21074 > (unsigned)MAXINT)
        _WrittenCount_21074 = NewDouble((double)(unsigned long)_WrittenCount_21074);
    }
    else {
        _WrittenCount_21074 = *(unsigned long *)(unsigned long)(DBL_PTR(_pWrittenCount_21075)->dbl);
        if ((unsigned)_WrittenCount_21074 > (unsigned)MAXINT)
        _WrittenCount_21074 = NewDouble((double)(unsigned long)_WrittenCount_21074);
    }

    /** 		machine:free(pWrittenCount)*/
    Ref(_pWrittenCount_21075);
    _14free(_pWrittenCount_21075);

    /** 	machine:free(buf)*/
    Ref(_buf_21070);
    _14free(_buf_21070);

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_21073, 0)){
        goto L1; // [58] 83
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return c_func(iGetLastError,{})*/
    DeRef(_46os_errno_20985);
    _46os_errno_20985 = call_c(1, _46iGetLastError_20943, _5);

    /** 		return -1*/
    DeRef(_fd_21068);
    DeRefDS(_str_21069);
    DeRef(_buf_21070);
    DeRef(_ret_21073);
    DeRef(_WrittenCount_21074);
    DeRef(_pWrittenCount_21075);
    return -1;
L1: 

    /** 	return WrittenCount*/
    DeRef(_fd_21068);
    DeRefDS(_str_21069);
    DeRef(_buf_21070);
    DeRef(_ret_21073);
    DeRef(_pWrittenCount_21075);
    return _WrittenCount_21074;
    ;
}


int  __stdcall _46error_no()
{
    int _0, _1, _2;
    

    /** 	return os_errno*/
    Ref(_46os_errno_20985);
    return _46os_errno_20985;
    ;
}


void _46CloseAllHandles(int _handles_21108)
{
    int _11917 = NOVALUE;
    int _11916 = NOVALUE;
    int _11915 = NOVALUE;
    int _0, _1, _2;
    

    /** 	   for i = 1 to length(handles) do*/
    if (IS_SEQUENCE(_handles_21108)){
            _11915 = SEQ_PTR(_handles_21108)->length;
    }
    else {
        _11915 = 1;
    }
    {
        int _i_21110;
        _i_21110 = 1;
L1: 
        if (_i_21110 > _11915){
            goto L2; // [8] 32
        }

        /** 	     close(handles[i])*/
        _2 = (int)SEQ_PTR(_handles_21108);
        _11916 = (int)*(((s1_ptr)_2)->base + _i_21110);
        Ref(_11916);
        _11917 = _46close(_11916);
        _11916 = NOVALUE;

        /** 	   end for*/
        _i_21110 = _i_21110 + 1;
        goto L1; // [27] 15
L2: 
        ;
    }

    /** 	end procedure*/
    DeRefDS(_handles_21108);
    DeRef(_11917);
    _11917 = NOVALUE;
    return;
    ;
}


int _46CreateProcess(int _CommandLine_21116, int _StdHandles_21117)
{
    int _fnVal_21118 = NOVALUE;
    int _pPI_21119 = NOVALUE;
    int _pSUI_21120 = NOVALUE;
    int _pCmdLine_21121 = NOVALUE;
    int _ProcInfo_21122 = NOVALUE;
    int _11926 = NOVALUE;
    int _11924 = NOVALUE;
    int _11923 = NOVALUE;
    int _11922 = NOVALUE;
    int _11921 = NOVALUE;
    int _0, _1, _2;
    

    /** 	   pCmdLine = machine:allocate_string(CommandLine)*/
    RefDS(_CommandLine_21116);
    _0 = _pCmdLine_21121;
    _pCmdLine_21121 = _14allocate_string(_CommandLine_21116, 0);
    DeRef(_0);

    /** 	   pPI = machine:allocate(PROCESS_INFORMATION_SIZE)*/
    _0 = _pPI_21119;
    _pPI_21119 = _14allocate(16, 0);
    DeRef(_0);

    /** 	   mem_set(pPI,0,PROCESS_INFORMATION_SIZE)*/
    memory_set(_pPI_21119, 0, 16);

    /** 	   pSUI = machine:allocate(STARTUPINFO_SIZE)*/
    _0 = _pSUI_21120;
    _pSUI_21120 = _14allocate(68, 0);
    DeRef(_0);

    /** 	   mem_set(pSUI,0,STARTUPINFO_SIZE)*/
    memory_set(_pSUI_21120, 0, 68);

    /** 	   poke4(pSUI,STARTUPINFO_SIZE)*/
    if (IS_ATOM_INT(_pSUI_21120)){
        poke4_addr = (unsigned long *)_pSUI_21120;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_pSUI_21120)->dbl);
    }
    *poke4_addr = (unsigned long)68;

    /** 	   poke4(pSUI+SUIdwFlags,or_bits(STARTF_USESTDHANDLES,STARTF_USESHOWWINDOW))*/
    if (IS_ATOM_INT(_pSUI_21120)) {
        _11921 = _pSUI_21120 + 44;
        if ((long)((unsigned long)_11921 + (unsigned long)HIGH_BITS) >= 0) 
        _11921 = NewDouble((double)_11921);
    }
    else {
        _11921 = NewDouble(DBL_PTR(_pSUI_21120)->dbl + (double)44);
    }
    {unsigned long tu;
         tu = (unsigned long)256 | (unsigned long)1;
         _11922 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_11921)){
        poke4_addr = (unsigned long *)_11921;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11921)->dbl);
    }
    if (IS_ATOM_INT(_11922)) {
        *poke4_addr = (unsigned long)_11922;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_11922)->dbl;
    }
    DeRef(_11921);
    _11921 = NOVALUE;
    DeRef(_11922);
    _11922 = NOVALUE;

    /** 	   poke4(pSUI+SUIhStdInput,StdHandles)*/
    if (IS_ATOM_INT(_pSUI_21120)) {
        _11923 = _pSUI_21120 + 56;
        if ((long)((unsigned long)_11923 + (unsigned long)HIGH_BITS) >= 0) 
        _11923 = NewDouble((double)_11923);
    }
    else {
        _11923 = NewDouble(DBL_PTR(_pSUI_21120)->dbl + (double)56);
    }
    if (IS_ATOM_INT(_11923)){
        poke4_addr = (unsigned long *)_11923;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11923)->dbl);
    }
    _1 = (int)SEQ_PTR(_StdHandles_21117);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_11923);
    _11923 = NOVALUE;

    /** 	   fnVal = c_func(iCreateProcess,{0,pCmdLine,0,0,1,0,0,0,pSUI,pPI})*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    Ref(_pCmdLine_21121);
    *((int *)(_2+8)) = _pCmdLine_21121;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 1;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    *((int *)(_2+32)) = 0;
    Ref(_pSUI_21120);
    *((int *)(_2+36)) = _pSUI_21120;
    Ref(_pPI_21119);
    *((int *)(_2+40)) = _pPI_21119;
    _11924 = MAKE_SEQ(_1);
    DeRef(_fnVal_21118);
    _fnVal_21118 = call_c(1, _46iCreateProcess_20954, _11924);
    DeRefDS(_11924);
    _11924 = NOVALUE;

    /** 	   machine:free(pCmdLine)*/
    Ref(_pCmdLine_21121);
    _14free(_pCmdLine_21121);

    /** 	   machine:free(pSUI)*/
    Ref(_pSUI_21120);
    _14free(_pSUI_21120);

    /** 	   ProcInfo = peek4u({pPI,4})*/
    Ref(_pPI_21119);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pPI_21119;
    ((int *)_2)[2] = 4;
    _11926 = MAKE_SEQ(_1);
    DeRef(_ProcInfo_21122);
    _1 = (int)SEQ_PTR(_11926);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _ProcInfo_21122 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_11926);
    _11926 = NOVALUE;

    /** 	   machine:free(pPI)*/
    Ref(_pPI_21119);
    _14free(_pPI_21119);

    /** 	   if not fnVal then*/
    if (IS_ATOM_INT(_fnVal_21118)) {
        if (_fnVal_21118 != 0){
            goto L1; // [115] 125
        }
    }
    else {
        if (DBL_PTR(_fnVal_21118)->dbl != 0.0){
            goto L1; // [115] 125
        }
    }

    /** 	     return 0*/
    DeRefDS(_CommandLine_21116);
    DeRefDS(_StdHandles_21117);
    DeRef(_fnVal_21118);
    DeRef(_pPI_21119);
    DeRef(_pSUI_21120);
    DeRef(_pCmdLine_21121);
    DeRefDS(_ProcInfo_21122);
    return 0;
L1: 

    /** 	   return ProcInfo*/
    DeRefDS(_CommandLine_21116);
    DeRefDS(_StdHandles_21117);
    DeRef(_fnVal_21118);
    DeRef(_pPI_21119);
    DeRef(_pSUI_21120);
    DeRef(_pCmdLine_21121);
    return _ProcInfo_21122;
    ;
}


int  __stdcall _46create()
{
    int _SetHandleInformation_1__tmp_at186_21176 = NOVALUE;
    int _SetHandleInformation_inlined_SetHandleInformation_at_186_21175 = NOVALUE;
    int _hObject_inlined_SetHandleInformation_at_183_21174 = NOVALUE;
    int _SetHandleInformation_1__tmp_at159_21171 = NOVALUE;
    int _SetHandleInformation_inlined_SetHandleInformation_at_159_21170 = NOVALUE;
    int _hObject_inlined_SetHandleInformation_at_156_21169 = NOVALUE;
    int _SetHandleInformation_1__tmp_at132_21166 = NOVALUE;
    int _SetHandleInformation_inlined_SetHandleInformation_at_132_21165 = NOVALUE;
    int _hObject_inlined_SetHandleInformation_at_129_21164 = NOVALUE;
    int _hChildStdInRd_21137 = NOVALUE;
    int _hChildStdOutWr_21138 = NOVALUE;
    int _hChildStdErrWr_21139 = NOVALUE;
    int _hChildStdInWr_21140 = NOVALUE;
    int _hChildStdOutRd_21141 = NOVALUE;
    int _hChildStdErrRd_21142 = NOVALUE;
    int _StdInPipe_21143 = NOVALUE;
    int _StdOutPipe_21144 = NOVALUE;
    int _StdErrPipe_21145 = NOVALUE;
    int _11947 = NOVALUE;
    int _11946 = NOVALUE;
    int _11945 = NOVALUE;
    int _11944 = NOVALUE;
    int _11943 = NOVALUE;
    int _11942 = NOVALUE;
    int _11939 = NOVALUE;
    int _11938 = NOVALUE;
    int _11934 = NOVALUE;
    int _11930 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  StdInPipe = {},*/
    RefDS(_5);
    DeRef(_StdInPipe_21143);
    _StdInPipe_21143 = _5;

    /** 	  StdOutPipe = {},*/
    RefDS(_5);
    DeRef(_StdOutPipe_21144);
    _StdOutPipe_21144 = _5;

    /** 	  StdErrPipe = {}*/
    RefDS(_5);
    DeRef(_StdErrPipe_21145);
    _StdErrPipe_21145 = _5;

    /** 	    StdInPipe = os_pipe()*/
    _0 = _StdInPipe_21143;
    _StdInPipe_21143 = _46os_pipe();
    DeRefDS(_0);

    /** 	    if atom(StdInPipe) then return -1 end if*/
    _11930 = IS_ATOM(_StdInPipe_21143);
    if (_11930 == 0)
    {
        _11930 = NOVALUE;
        goto L1; // [26] 34
    }
    else{
        _11930 = NOVALUE;
    }
    DeRef(_hChildStdInRd_21137);
    DeRef(_hChildStdOutWr_21138);
    DeRef(_hChildStdErrWr_21139);
    DeRef(_hChildStdInWr_21140);
    DeRef(_hChildStdOutRd_21141);
    DeRef(_hChildStdErrRd_21142);
    DeRef(_StdInPipe_21143);
    DeRefDS(_StdOutPipe_21144);
    DeRefDS(_StdErrPipe_21145);
    return -1;
L1: 

    /** 	    hChildStdInRd = StdInPipe[PIPE_READ_HANDLE]*/
    DeRef(_hChildStdInRd_21137);
    _2 = (int)SEQ_PTR(_StdInPipe_21143);
    _hChildStdInRd_21137 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_hChildStdInRd_21137);

    /** 	    hChildStdInWr = StdInPipe[PIPE_WRITE_HANDLE]*/
    DeRef(_hChildStdInWr_21140);
    _2 = (int)SEQ_PTR(_StdInPipe_21143);
    _hChildStdInWr_21140 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildStdInWr_21140);

    /** 	    StdOutPipe = os_pipe()*/
    _0 = _StdOutPipe_21144;
    _StdOutPipe_21144 = _46os_pipe();
    DeRef(_0);

    /** 	    if atom(StdOutPipe) then */
    _11934 = IS_ATOM(_StdOutPipe_21144);
    if (_11934 == 0)
    {
        _11934 = NOVALUE;
        goto L2; // [56] 71
    }
    else{
        _11934 = NOVALUE;
    }

    /** 	      CloseAllHandles(StdInPipe)*/
    Ref(_StdInPipe_21143);
    _46CloseAllHandles(_StdInPipe_21143);

    /** 	      return -1*/
    DeRef(_hChildStdInRd_21137);
    DeRef(_hChildStdOutWr_21138);
    DeRef(_hChildStdErrWr_21139);
    DeRef(_hChildStdInWr_21140);
    DeRef(_hChildStdOutRd_21141);
    DeRef(_hChildStdErrRd_21142);
    DeRef(_StdInPipe_21143);
    DeRef(_StdOutPipe_21144);
    DeRef(_StdErrPipe_21145);
    return -1;
L2: 

    /** 	    hChildStdOutWr = StdOutPipe[PIPE_WRITE_HANDLE]*/
    DeRef(_hChildStdOutWr_21138);
    _2 = (int)SEQ_PTR(_StdOutPipe_21144);
    _hChildStdOutWr_21138 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildStdOutWr_21138);

    /** 	    hChildStdOutRd = StdOutPipe[PIPE_READ_HANDLE]*/
    DeRef(_hChildStdOutRd_21141);
    _2 = (int)SEQ_PTR(_StdOutPipe_21144);
    _hChildStdOutRd_21141 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_hChildStdOutRd_21141);

    /** 	    StdErrPipe = os_pipe()*/
    _0 = _StdErrPipe_21145;
    _StdErrPipe_21145 = _46os_pipe();
    DeRef(_0);

    /** 	    if atom(StdErrPipe) then*/
    _11938 = IS_ATOM(_StdErrPipe_21145);
    if (_11938 == 0)
    {
        _11938 = NOVALUE;
        goto L3; // [93] 112
    }
    else{
        _11938 = NOVALUE;
    }

    /** 	       CloseAllHandles(StdErrPipe & StdOutPipe)*/
    if (IS_SEQUENCE(_StdErrPipe_21145) && IS_ATOM(_StdOutPipe_21144)) {
        Ref(_StdOutPipe_21144);
        Append(&_11939, _StdErrPipe_21145, _StdOutPipe_21144);
    }
    else if (IS_ATOM(_StdErrPipe_21145) && IS_SEQUENCE(_StdOutPipe_21144)) {
        Ref(_StdErrPipe_21145);
        Prepend(&_11939, _StdOutPipe_21144, _StdErrPipe_21145);
    }
    else {
        Concat((object_ptr)&_11939, _StdErrPipe_21145, _StdOutPipe_21144);
    }
    _46CloseAllHandles(_11939);
    _11939 = NOVALUE;

    /** 	       return -1*/
    DeRef(_hChildStdInRd_21137);
    DeRef(_hChildStdOutWr_21138);
    DeRef(_hChildStdErrWr_21139);
    DeRef(_hChildStdInWr_21140);
    DeRef(_hChildStdOutRd_21141);
    DeRef(_hChildStdErrRd_21142);
    DeRef(_StdInPipe_21143);
    DeRef(_StdOutPipe_21144);
    DeRef(_StdErrPipe_21145);
    return -1;
L3: 

    /** 	    hChildStdErrWr = StdErrPipe[PIPE_WRITE_HANDLE]*/
    DeRef(_hChildStdErrWr_21139);
    _2 = (int)SEQ_PTR(_StdErrPipe_21145);
    _hChildStdErrWr_21139 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildStdErrWr_21139);

    /** 	    hChildStdErrRd = StdErrPipe[PIPE_READ_HANDLE]*/
    DeRef(_hChildStdErrRd_21142);
    _2 = (int)SEQ_PTR(_StdErrPipe_21145);
    _hChildStdErrRd_21142 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_hChildStdErrRd_21142);

    /** 	    SetHandleInformation(StdInPipe[PIPE_WRITE_HANDLE],HANDLE_FLAG_INHERIT,0)*/
    _2 = (int)SEQ_PTR(_StdInPipe_21143);
    _11942 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11942);
    DeRef(_hObject_inlined_SetHandleInformation_at_129_21164);
    _hObject_inlined_SetHandleInformation_at_129_21164 = _11942;
    _11942 = NOVALUE;

    /** 		return c_func(iSetHandleInformation,{hObject,dwMask,dwFlags})*/
    _0 = _SetHandleInformation_1__tmp_at132_21166;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hObject_inlined_SetHandleInformation_at_129_21164);
    *((int *)(_2+4)) = _hObject_inlined_SetHandleInformation_at_129_21164;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 0;
    _SetHandleInformation_1__tmp_at132_21166 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_SetHandleInformation_inlined_SetHandleInformation_at_132_21165);
    _SetHandleInformation_inlined_SetHandleInformation_at_132_21165 = call_c(1, _46iSetHandleInformation_20950, _SetHandleInformation_1__tmp_at132_21166);
    DeRef(_hObject_inlined_SetHandleInformation_at_129_21164);
    _hObject_inlined_SetHandleInformation_at_129_21164 = NOVALUE;
    DeRef(_SetHandleInformation_1__tmp_at132_21166);
    _SetHandleInformation_1__tmp_at132_21166 = NOVALUE;

    /** 	    SetHandleInformation(StdOutPipe[PIPE_READ_HANDLE],HANDLE_FLAG_INHERIT,0)*/
    _2 = (int)SEQ_PTR(_StdOutPipe_21144);
    _11943 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11943);
    DeRef(_hObject_inlined_SetHandleInformation_at_156_21169);
    _hObject_inlined_SetHandleInformation_at_156_21169 = _11943;
    _11943 = NOVALUE;

    /** 		return c_func(iSetHandleInformation,{hObject,dwMask,dwFlags})*/
    _0 = _SetHandleInformation_1__tmp_at159_21171;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hObject_inlined_SetHandleInformation_at_156_21169);
    *((int *)(_2+4)) = _hObject_inlined_SetHandleInformation_at_156_21169;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 0;
    _SetHandleInformation_1__tmp_at159_21171 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_SetHandleInformation_inlined_SetHandleInformation_at_159_21170);
    _SetHandleInformation_inlined_SetHandleInformation_at_159_21170 = call_c(1, _46iSetHandleInformation_20950, _SetHandleInformation_1__tmp_at159_21171);
    DeRef(_hObject_inlined_SetHandleInformation_at_156_21169);
    _hObject_inlined_SetHandleInformation_at_156_21169 = NOVALUE;
    DeRef(_SetHandleInformation_1__tmp_at159_21171);
    _SetHandleInformation_1__tmp_at159_21171 = NOVALUE;

    /** 	    SetHandleInformation(StdErrPipe[PIPE_READ_HANDLE],HANDLE_FLAG_INHERIT,0)*/
    _2 = (int)SEQ_PTR(_StdErrPipe_21145);
    _11944 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11944);
    DeRef(_hObject_inlined_SetHandleInformation_at_183_21174);
    _hObject_inlined_SetHandleInformation_at_183_21174 = _11944;
    _11944 = NOVALUE;

    /** 		return c_func(iSetHandleInformation,{hObject,dwMask,dwFlags})*/
    _0 = _SetHandleInformation_1__tmp_at186_21176;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hObject_inlined_SetHandleInformation_at_183_21174);
    *((int *)(_2+4)) = _hObject_inlined_SetHandleInformation_at_183_21174;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 0;
    _SetHandleInformation_1__tmp_at186_21176 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_SetHandleInformation_inlined_SetHandleInformation_at_186_21175);
    _SetHandleInformation_inlined_SetHandleInformation_at_186_21175 = call_c(1, _46iSetHandleInformation_20950, _SetHandleInformation_1__tmp_at186_21176);
    DeRef(_hObject_inlined_SetHandleInformation_at_183_21174);
    _hObject_inlined_SetHandleInformation_at_183_21174 = NOVALUE;
    DeRef(_SetHandleInformation_1__tmp_at186_21176);
    _SetHandleInformation_1__tmp_at186_21176 = NOVALUE;

    /** 	  return {{hChildStdInWr,hChildStdOutRd,hChildStdErrRd},*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hChildStdInWr_21140);
    *((int *)(_2+4)) = _hChildStdInWr_21140;
    Ref(_hChildStdOutRd_21141);
    *((int *)(_2+8)) = _hChildStdOutRd_21141;
    Ref(_hChildStdErrRd_21142);
    *((int *)(_2+12)) = _hChildStdErrRd_21142;
    _11945 = MAKE_SEQ(_1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hChildStdInRd_21137);
    *((int *)(_2+4)) = _hChildStdInRd_21137;
    Ref(_hChildStdOutWr_21138);
    *((int *)(_2+8)) = _hChildStdOutWr_21138;
    Ref(_hChildStdErrWr_21139);
    *((int *)(_2+12)) = _hChildStdErrWr_21139;
    _11946 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11945;
    ((int *)_2)[2] = _11946;
    _11947 = MAKE_SEQ(_1);
    _11946 = NOVALUE;
    _11945 = NOVALUE;
    DeRef(_hChildStdInRd_21137);
    DeRef(_hChildStdOutWr_21138);
    DeRef(_hChildStdErrWr_21139);
    DeRef(_hChildStdInWr_21140);
    DeRef(_hChildStdOutRd_21141);
    DeRef(_hChildStdErrRd_21142);
    DeRef(_StdInPipe_21143);
    DeRef(_StdOutPipe_21144);
    DeRef(_StdErrPipe_21145);
    return _11947;
    ;
}


int  __stdcall _46exec(int _cmd_21182, int _pipe_21183)
{
    int _fnVal_21184 = NOVALUE;
    int _hChildStdInRd_21185 = NOVALUE;
    int _hChildStdOutWr_21186 = NOVALUE;
    int _hChildStdErrWr_21187 = NOVALUE;
    int _hChildStdInWr_21188 = NOVALUE;
    int _hChildStdOutRd_21189 = NOVALUE;
    int _hChildStdErrRd_21190 = NOVALUE;
    int _hChildProcess_21203 = NOVALUE;
    int _11969 = NOVALUE;
    int _11968 = NOVALUE;
    int _11967 = NOVALUE;
    int _11966 = NOVALUE;
    int _11965 = NOVALUE;
    int _11964 = NOVALUE;
    int _11962 = NOVALUE;
    int _11960 = NOVALUE;
    int _11958 = NOVALUE;
    int _11956 = NOVALUE;
    int _11954 = NOVALUE;
    int _11952 = NOVALUE;
    int _11950 = NOVALUE;
    int _11948 = NOVALUE;
    int _0, _1, _2;
    

    /** 	hChildStdInWr = pipe[1][1]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11948 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_hChildStdInWr_21188);
    _2 = (int)SEQ_PTR(_11948);
    _hChildStdInWr_21188 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildStdInWr_21188);
    _11948 = NOVALUE;

    /** 	hChildStdOutRd = pipe[1][2]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11950 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_hChildStdOutRd_21189);
    _2 = (int)SEQ_PTR(_11950);
    _hChildStdOutRd_21189 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_hChildStdOutRd_21189);
    _11950 = NOVALUE;

    /** 	hChildStdErrRd = pipe[1][3]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11952 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_hChildStdErrRd_21190);
    _2 = (int)SEQ_PTR(_11952);
    _hChildStdErrRd_21190 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_hChildStdErrRd_21190);
    _11952 = NOVALUE;

    /** 	hChildStdInRd = pipe[2][1]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11954 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_hChildStdInRd_21185);
    _2 = (int)SEQ_PTR(_11954);
    _hChildStdInRd_21185 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildStdInRd_21185);
    _11954 = NOVALUE;

    /** 	hChildStdOutWr = pipe[2][2]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11956 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_hChildStdOutWr_21186);
    _2 = (int)SEQ_PTR(_11956);
    _hChildStdOutWr_21186 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_hChildStdOutWr_21186);
    _11956 = NOVALUE;

    /** 	hChildStdErrWr = pipe[2][3]*/
    _2 = (int)SEQ_PTR(_pipe_21183);
    _11958 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_hChildStdErrWr_21187);
    _2 = (int)SEQ_PTR(_11958);
    _hChildStdErrWr_21187 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_hChildStdErrWr_21187);
    _11958 = NOVALUE;

    /** 	atom hChildProcess*/

    /** 	  fnVal = CreateProcess(cmd,{hChildStdInRd,hChildStdOutWr,hChildStdErrWr})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hChildStdInRd_21185);
    *((int *)(_2+4)) = _hChildStdInRd_21185;
    Ref(_hChildStdOutWr_21186);
    *((int *)(_2+8)) = _hChildStdOutWr_21186;
    Ref(_hChildStdErrWr_21187);
    *((int *)(_2+12)) = _hChildStdErrWr_21187;
    _11960 = MAKE_SEQ(_1);
    RefDS(_cmd_21182);
    _0 = _fnVal_21184;
    _fnVal_21184 = _46CreateProcess(_cmd_21182, _11960);
    DeRef(_0);
    _11960 = NOVALUE;

    /** 	  if atom(fnVal) then*/
    _11962 = IS_ATOM(_fnVal_21184);
    if (_11962 == 0)
    {
        _11962 = NOVALUE;
        goto L1; // [85] 95
    }
    else{
        _11962 = NOVALUE;
    }

    /** 	    return -1*/
    DeRefDS(_cmd_21182);
    DeRefDS(_pipe_21183);
    DeRef(_fnVal_21184);
    DeRef(_hChildStdInRd_21185);
    DeRef(_hChildStdOutWr_21186);
    DeRef(_hChildStdErrWr_21187);
    DeRef(_hChildStdInWr_21188);
    DeRef(_hChildStdOutRd_21189);
    DeRef(_hChildStdErrRd_21190);
    DeRef(_hChildProcess_21203);
    return -1;
L1: 

    /** 	  hChildProcess = fnVal[1]*/
    DeRef(_hChildProcess_21203);
    _2 = (int)SEQ_PTR(_fnVal_21184);
    _hChildProcess_21203 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_hChildProcess_21203);

    /** 	  close(fnVal[2])*/
    _2 = (int)SEQ_PTR(_fnVal_21184);
    _11964 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11964);
    _11965 = _46close(_11964);
    _11964 = NOVALUE;

    /** 	  close(hChildStdInRd)*/
    Ref(_hChildStdInRd_21185);
    _11966 = _46close(_hChildStdInRd_21185);

    /** 	  close(hChildStdOutWr)*/
    Ref(_hChildStdOutWr_21186);
    _11967 = _46close(_hChildStdOutWr_21186);

    /** 	  close(hChildStdErrWr)*/
    Ref(_hChildStdErrWr_21187);
    _11968 = _46close(_hChildStdErrWr_21187);

    /** 	  return {hChildStdInWr, hChildStdOutRd, hChildStdErrRd, hChildProcess}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_hChildStdInWr_21188);
    *((int *)(_2+4)) = _hChildStdInWr_21188;
    Ref(_hChildStdOutRd_21189);
    *((int *)(_2+8)) = _hChildStdOutRd_21189;
    Ref(_hChildStdErrRd_21190);
    *((int *)(_2+12)) = _hChildStdErrRd_21190;
    Ref(_hChildProcess_21203);
    *((int *)(_2+16)) = _hChildProcess_21203;
    _11969 = MAKE_SEQ(_1);
    DeRefDS(_cmd_21182);
    DeRefDS(_pipe_21183);
    DeRef(_fnVal_21184);
    DeRef(_hChildStdInRd_21185);
    DeRef(_hChildStdOutWr_21186);
    DeRef(_hChildStdErrWr_21187);
    DeRef(_hChildStdInWr_21188);
    DeRef(_hChildStdOutRd_21189);
    DeRef(_hChildStdErrRd_21190);
    DeRef(_hChildProcess_21203);
    DeRef(_11966);
    _11966 = NOVALUE;
    DeRef(_11965);
    _11965 = NOVALUE;
    DeRef(_11967);
    _11967 = NOVALUE;
    DeRef(_11968);
    _11968 = NOVALUE;
    return _11969;
    ;
}



// 0x05E04886
