// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _56message_box(int _text_23717, int _title_23718, int _style_23719)
{
    int _or_style_23720 = NOVALUE;
    int _text_ptr_23721 = NOVALUE;
    int _title_ptr_23722 = NOVALUE;
    int _ret_23723 = NOVALUE;
    int _13176 = NOVALUE;
    int _13175 = NOVALUE;
    int _13173 = NOVALUE;
    int _13172 = NOVALUE;
    int _13171 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text_ptr = machine:allocate_string(text)*/
    RefDS(_text_23717);
    _0 = _text_ptr_23721;
    _text_ptr_23721 = _14allocate_string(_text_23717, 0);
    DeRef(_0);

    /** 	if not text_ptr then*/
    if (IS_ATOM_INT(_text_ptr_23721)) {
        if (_text_ptr_23721 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_text_ptr_23721)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		return 0*/
    DeRefDS(_text_23717);
    DeRefDS(_title_23718);
    DeRef(_style_23719);
    DeRef(_text_ptr_23721);
    DeRef(_title_ptr_23722);
    DeRef(_ret_23723);
    return 0;
L1: 

    /** 	title_ptr = machine:allocate_string(title)*/
    RefDS(_title_23718);
    _0 = _title_ptr_23722;
    _title_ptr_23722 = _14allocate_string(_title_23718, 0);
    DeRef(_0);

    /** 	if not title_ptr then*/
    if (IS_ATOM_INT(_title_ptr_23722)) {
        if (_title_ptr_23722 != 0){
            goto L2; // [33] 48
        }
    }
    else {
        if (DBL_PTR(_title_ptr_23722)->dbl != 0.0){
            goto L2; // [33] 48
        }
    }

    /** 		machine:free(text_ptr)*/
    Ref(_text_ptr_23721);
    _14free(_text_ptr_23721);

    /** 		return 0*/
    DeRefDS(_text_23717);
    DeRefDS(_title_23718);
    DeRef(_style_23719);
    DeRef(_text_ptr_23721);
    DeRef(_title_ptr_23722);
    DeRef(_ret_23723);
    return 0;
L2: 

    /** 	if atom(style) then*/
    _13171 = IS_ATOM(_style_23719);
    if (_13171 == 0)
    {
        _13171 = NOVALUE;
        goto L3; // [53] 66
    }
    else{
        _13171 = NOVALUE;
    }

    /** 		or_style = style*/
    Ref(_style_23719);
    _or_style_23720 = _style_23719;
    if (!IS_ATOM_INT(_or_style_23720)) {
        _1 = (long)(DBL_PTR(_or_style_23720)->dbl);
        DeRefDS(_or_style_23720);
        _or_style_23720 = _1;
    }
    goto L4; // [63] 103
L3: 

    /** 		or_style = 0*/
    _or_style_23720 = 0;

    /** 		for i = 1 to length(style) do*/
    if (IS_SEQUENCE(_style_23719)){
            _13172 = SEQ_PTR(_style_23719)->length;
    }
    else {
        _13172 = 1;
    }
    {
        int _i_23734;
        _i_23734 = 1;
L5: 
        if (_i_23734 > _13172){
            goto L6; // [76] 102
        }

        /** 			or_style = or_bits(or_style, style[i])*/
        _2 = (int)SEQ_PTR(_style_23719);
        _13173 = (int)*(((s1_ptr)_2)->base + _i_23734);
        if (IS_ATOM_INT(_13173)) {
            {unsigned long tu;
                 tu = (unsigned long)_or_style_23720 | (unsigned long)_13173;
                 _or_style_23720 = MAKE_UINT(tu);
            }
        }
        else {
            _or_style_23720 = binary_op(OR_BITS, _or_style_23720, _13173);
        }
        _13173 = NOVALUE;
        if (!IS_ATOM_INT(_or_style_23720)) {
            _1 = (long)(DBL_PTR(_or_style_23720)->dbl);
            DeRefDS(_or_style_23720);
            _or_style_23720 = _1;
        }

        /** 		end for*/
        _i_23734 = _i_23734 + 1;
        goto L5; // [97] 83
L6: 
        ;
    }
L4: 

    /** 	ret = c_func(msgbox_id, {c_func(get_active_id, {}), */
    _13175 = call_c(1, _56get_active_id_23695, _5);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13175;
    Ref(_text_ptr_23721);
    *((int *)(_2+8)) = _text_ptr_23721;
    Ref(_title_ptr_23722);
    *((int *)(_2+12)) = _title_ptr_23722;
    *((int *)(_2+16)) = _or_style_23720;
    _13176 = MAKE_SEQ(_1);
    _13175 = NOVALUE;
    DeRef(_ret_23723);
    _ret_23723 = call_c(1, _56msgbox_id_23694, _13176);
    DeRefDS(_13176);
    _13176 = NOVALUE;

    /** 	machine:free(text_ptr)*/
    Ref(_text_ptr_23721);
    _14free(_text_ptr_23721);

    /** 	machine:free(title_ptr)*/
    Ref(_title_ptr_23722);
    _14free(_title_ptr_23722);

    /** 	return ret*/
    DeRefDS(_text_23717);
    DeRefDS(_title_23718);
    DeRef(_style_23719);
    DeRef(_text_ptr_23721);
    DeRef(_title_ptr_23722);
    return _ret_23723;
    ;
}



// 0xDDDF59AA
