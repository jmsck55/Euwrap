// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _54format_base_request(int _request_type_23281, int _url_23282, int _headers_23283)
{
    int _request_23284 = NOVALUE;
    int _formatted_request_23285 = NOVALUE;
    int _noport_23286 = NOVALUE;
    int _parsedUrl_23287 = NOVALUE;
    int _host_23297 = NOVALUE;
    int _port_23300 = NOVALUE;
    int _path_23305 = NOVALUE;
    int _has_user_agent_23330 = NOVALUE;
    int _has_connection_23331 = NOVALUE;
    int _header_23337 = NOVALUE;
    int _12969 = NOVALUE;
    int _12967 = NOVALUE;
    int _12965 = NOVALUE;
    int _12964 = NOVALUE;
    int _12962 = NOVALUE;
    int _12960 = NOVALUE;
    int _12959 = NOVALUE;
    int _12957 = NOVALUE;
    int _12954 = NOVALUE;
    int _12951 = NOVALUE;
    int _12950 = NOVALUE;
    int _12948 = NOVALUE;
    int _12947 = NOVALUE;
    int _12945 = NOVALUE;
    int _12944 = NOVALUE;
    int _12939 = NOVALUE;
    int _12937 = NOVALUE;
    int _12936 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence request = ""*/
    RefDS(_5);
    DeRefi(_request_23284);
    _request_23284 = _5;

    /** 	integer noport = 0*/
    _noport_23286 = 0;

    /** 	object parsedUrl = url:parse(url)*/
    RefDS(_url_23282);
    _0 = _parsedUrl_23287;
    _parsedUrl_23287 = _55parse(_url_23282, 0);
    DeRef(_0);

    /** 	if atom(parsedUrl) then*/
    _12936 = IS_ATOM(_parsedUrl_23287);
    if (_12936 == 0)
    {
        _12936 = NOVALUE;
        goto L1; // [29] 41
    }
    else{
        _12936 = NOVALUE;
    }

    /** 		return ERR_MALFORMED_URL*/
    DeRefDSi(_request_type_23281);
    DeRefDS(_url_23282);
    DeRef(_headers_23283);
    DeRefDSi(_request_23284);
    DeRef(_formatted_request_23285);
    DeRef(_parsedUrl_23287);
    DeRef(_host_23297);
    DeRef(_path_23305);
    return -1;
    goto L2; // [38] 64
L1: 

    /** 	elsif not equal(parsedUrl[URL_PROTOCOL], "http") then*/
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _12937 = (int)*(((s1_ptr)_2)->base + 1);
    if (_12937 == _12938)
    _12939 = 1;
    else if (IS_ATOM_INT(_12937) && IS_ATOM_INT(_12938))
    _12939 = 0;
    else
    _12939 = (compare(_12937, _12938) == 0);
    _12937 = NOVALUE;
    if (_12939 != 0)
    goto L3; // [53] 63
    _12939 = NOVALUE;

    /** 		return ERR_INVALID_PROTOCOL*/
    DeRefDSi(_request_type_23281);
    DeRefDS(_url_23282);
    DeRef(_headers_23283);
    DeRefi(_request_23284);
    DeRef(_formatted_request_23285);
    DeRef(_parsedUrl_23287);
    DeRef(_host_23297);
    DeRef(_path_23305);
    return -2;
L3: 
L2: 

    /** 	sequence host = parsedUrl[URL_HOSTNAME]*/
    DeRef(_host_23297);
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _host_23297 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_host_23297);

    /** 	integer port = parsedUrl[URL_PORT]*/
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _port_23300 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_port_23300)){
        _port_23300 = (long)DBL_PTR(_port_23300)->dbl;
    }

    /** 	if port = 0 then*/
    if (_port_23300 != 0)
    goto L4; // [86] 101

    /** 		port = 80*/
    _port_23300 = 80;

    /** 		noport = 1*/
    _noport_23286 = 1;
L4: 

    /** 	sequence path*/

    /** 	if sequence(parsedUrl[URL_PATH]) then*/
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _12944 = (int)*(((s1_ptr)_2)->base + 4);
    _12945 = IS_SEQUENCE(_12944);
    _12944 = NOVALUE;
    if (_12945 == 0)
    {
        _12945 = NOVALUE;
        goto L5; // [114] 130
    }
    else{
        _12945 = NOVALUE;
    }

    /** 		path = parsedUrl[URL_PATH]*/
    DeRef(_path_23305);
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _path_23305 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_path_23305);
    goto L6; // [127] 138
L5: 

    /** 		path = "/"*/
    RefDS(_12327);
    DeRef(_path_23305);
    _path_23305 = _12327;
L6: 

    /** 	if sequence(parsedUrl[URL_QUERY_STRING]) then*/
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _12947 = (int)*(((s1_ptr)_2)->base + 7);
    _12948 = IS_SEQUENCE(_12947);
    _12947 = NOVALUE;
    if (_12948 == 0)
    {
        _12948 = NOVALUE;
        goto L7; // [149] 171
    }
    else{
        _12948 = NOVALUE;
    }

    /** 		path &= "?" & parsedUrl[URL_QUERY_STRING]*/
    _2 = (int)SEQ_PTR(_parsedUrl_23287);
    _12950 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_12949) && IS_ATOM(_12950)) {
        Ref(_12950);
        Append(&_12951, _12949, _12950);
    }
    else if (IS_ATOM(_12949) && IS_SEQUENCE(_12950)) {
    }
    else {
        Concat((object_ptr)&_12951, _12949, _12950);
    }
    _12950 = NOVALUE;
    Concat((object_ptr)&_path_23305, _path_23305, _12951);
    DeRefDS(_12951);
    _12951 = NOVALUE;
L7: 

    /** 	if noport then*/
    if (_noport_23286 == 0)
    {
        goto L8; // [173] 193
    }
    else{
    }

    /** 	request = sprintf("%s %s HTTP/1.0\r\nHost: %s\r\n", {*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_request_type_23281);
    *((int *)(_2+4)) = _request_type_23281;
    RefDS(_path_23305);
    *((int *)(_2+8)) = _path_23305;
    RefDS(_host_23297);
    *((int *)(_2+12)) = _host_23297;
    _12954 = MAKE_SEQ(_1);
    DeRefi(_request_23284);
    _request_23284 = EPrintf(-9999999, _12953, _12954);
    DeRefDS(_12954);
    _12954 = NOVALUE;
    goto L9; // [190] 209
L8: 

    /** 	request = sprintf("%s %s HTTP/1.0\r\nHost: %s:%d\r\n", {*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_request_type_23281);
    *((int *)(_2+4)) = _request_type_23281;
    RefDS(_path_23305);
    *((int *)(_2+8)) = _path_23305;
    RefDS(_host_23297);
    *((int *)(_2+12)) = _host_23297;
    *((int *)(_2+16)) = _port_23300;
    _12957 = MAKE_SEQ(_1);
    DeRefi(_request_23284);
    _request_23284 = EPrintf(-9999999, _12956, _12957);
    DeRefDS(_12957);
    _12957 = NOVALUE;
L9: 

    /** 	integer has_user_agent = 0*/
    _has_user_agent_23330 = 0;

    /** 	integer has_connection = 0*/
    _has_connection_23331 = 0;

    /** 	if sequence(headers) then*/
    _12959 = IS_SEQUENCE(_headers_23283);
    if (_12959 == 0)
    {
        _12959 = NOVALUE;
        goto LA; // [224] 306
    }
    else{
        _12959 = NOVALUE;
    }

    /** 		for i = 1 to length(headers) do*/
    if (IS_SEQUENCE(_headers_23283)){
            _12960 = SEQ_PTR(_headers_23283)->length;
    }
    else {
        _12960 = 1;
    }
    {
        int _i_23335;
        _i_23335 = 1;
LB: 
        if (_i_23335 > _12960){
            goto LC; // [232] 305
        }

        /** 			object header = headers[i]*/
        DeRef(_header_23337);
        _2 = (int)SEQ_PTR(_headers_23283);
        _header_23337 = (int)*(((s1_ptr)_2)->base + _i_23335);
        Ref(_header_23337);

        /** 			if equal(header[1], "User-Agent") then*/
        _2 = (int)SEQ_PTR(_header_23337);
        _12962 = (int)*(((s1_ptr)_2)->base + 1);
        if (_12962 == _12963)
        _12964 = 1;
        else if (IS_ATOM_INT(_12962) && IS_ATOM_INT(_12963))
        _12964 = 0;
        else
        _12964 = (compare(_12962, _12963) == 0);
        _12962 = NOVALUE;
        if (_12964 == 0)
        {
            _12964 = NOVALUE;
            goto LD; // [255] 266
        }
        else{
            _12964 = NOVALUE;
        }

        /** 				has_user_agent = 1*/
        _has_user_agent_23330 = 1;
        goto LE; // [263] 286
LD: 

        /** 			elsif equal(header[1], "Connection") then*/
        _2 = (int)SEQ_PTR(_header_23337);
        _12965 = (int)*(((s1_ptr)_2)->base + 1);
        if (_12965 == _12966)
        _12967 = 1;
        else if (IS_ATOM_INT(_12965) && IS_ATOM_INT(_12966))
        _12967 = 0;
        else
        _12967 = (compare(_12965, _12966) == 0);
        _12965 = NOVALUE;
        if (_12967 == 0)
        {
            _12967 = NOVALUE;
            goto LF; // [276] 285
        }
        else{
            _12967 = NOVALUE;
        }

        /** 				has_connection = 1*/
        _has_connection_23331 = 1;
LF: 
LE: 

        /** 			request &= sprintf("%s: %s\r\n", header)*/
        _12969 = EPrintf(-9999999, _12968, _header_23337);
        Concat((object_ptr)&_request_23284, _request_23284, _12969);
        DeRefDS(_12969);
        _12969 = NOVALUE;
        DeRef(_header_23337);
        _header_23337 = NOVALUE;

        /** 		end for*/
        _i_23335 = _i_23335 + 1;
        goto LB; // [300] 239
LC: 
        ;
    }
LA: 

    /** 	if not has_user_agent then*/
    if (_has_user_agent_23330 != 0)
    goto L10; // [308] 320

    /** 		request &= USER_AGENT_HEADER*/
    Concat((object_ptr)&_request_23284, _request_23284, _54USER_AGENT_HEADER_23245);
L10: 

    /** 	if not has_connection then*/
    if (_has_connection_23331 != 0)
    goto L11; // [322] 332

    /** 		request &= "Connection: close\r\n"*/
    Concat((object_ptr)&_request_23284, _request_23284, _12974);
L11: 

    /** 	formatted_request = repeat(0, FR_SIZE)*/
    DeRef(_formatted_request_23285);
    _formatted_request_23285 = Repeat(0, 4);

    /** 	formatted_request[R_HOST] = host*/
    RefDS(_host_23297);
    _2 = (int)SEQ_PTR(_formatted_request_23285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_23285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _host_23297;

    /** 	formatted_request[R_PORT] = port*/
    _2 = (int)SEQ_PTR(_formatted_request_23285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_23285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _port_23300;
    DeRef(_1);

    /** 	formatted_request[R_PATH] = path*/
    RefDS(_path_23305);
    _2 = (int)SEQ_PTR(_formatted_request_23285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_23285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _path_23305;
    DeRef(_1);

    /** 	formatted_request[R_REQUEST] = request*/
    RefDS(_request_23284);
    _2 = (int)SEQ_PTR(_formatted_request_23285);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_23285 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _request_23284;
    DeRef(_1);

    /** 	return formatted_request*/
    DeRefDSi(_request_type_23281);
    DeRefDS(_url_23282);
    DeRef(_headers_23283);
    DeRefDSi(_request_23284);
    DeRef(_parsedUrl_23287);
    DeRefDS(_host_23297);
    DeRefDS(_path_23305);
    return _formatted_request_23285;
    ;
}


int _54form_urlencode(int _kvpairs_23360)
{
    int _data_23361 = NOVALUE;
    int _kvpair_23365 = NOVALUE;
    int _12986 = NOVALUE;
    int _12985 = NOVALUE;
    int _12984 = NOVALUE;
    int _12982 = NOVALUE;
    int _12977 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence data = ""*/
    RefDS(_5);
    DeRef(_data_23361);
    _data_23361 = _5;

    /** 	for i = 1 to length(kvpairs) do*/
    if (IS_SEQUENCE(_kvpairs_23360)){
            _12977 = SEQ_PTR(_kvpairs_23360)->length;
    }
    else {
        _12977 = 1;
    }
    {
        int _i_23363;
        _i_23363 = 1;
L1: 
        if (_i_23363 > _12977){
            goto L2; // [15] 75
        }

        /** 		object kvpair = kvpairs[i]*/
        DeRef(_kvpair_23365);
        _2 = (int)SEQ_PTR(_kvpairs_23360);
        _kvpair_23365 = (int)*(((s1_ptr)_2)->base + _i_23363);
        Ref(_kvpair_23365);

        /** 		if i > 1 then*/
        if (_i_23363 <= 1)
        goto L3; // [30] 41

        /** 			data &= "&"*/
        Concat((object_ptr)&_data_23361, _data_23361, _12980);
L3: 

        /** 		data &= kvpair[1] & "=" & url:encode(kvpair[2])*/
        _2 = (int)SEQ_PTR(_kvpair_23365);
        _12982 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_kvpair_23365);
        _12984 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_12984);
        RefDS(_12861);
        _12985 = _55encode(_12984, _12861);
        _12984 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _12985;
            concat_list[1] = _12983;
            concat_list[2] = _12982;
            Concat_N((object_ptr)&_12986, concat_list, 3);
        }
        DeRef(_12985);
        _12985 = NOVALUE;
        _12982 = NOVALUE;
        Concat((object_ptr)&_data_23361, _data_23361, _12986);
        DeRefDS(_12986);
        _12986 = NOVALUE;
        DeRef(_kvpair_23365);
        _kvpair_23365 = NOVALUE;

        /** 	end for*/
        _i_23363 = _i_23363 + 1;
        goto L1; // [70] 22
L2: 
        ;
    }

    /** 	return data*/
    DeRefDS(_kvpairs_23360);
    return _data_23361;
    ;
}


int _54multipart_form_data_encode(int _kvpairs_23379, int _boundary_23380)
{
    int _data_23381 = NOVALUE;
    int _kvpair_23385 = NOVALUE;
    int _enctyp_23387 = NOVALUE;
    int _mimetyp_23388 = NOVALUE;
    int _13025 = NOVALUE;
    int _13022 = NOVALUE;
    int _13021 = NOVALUE;
    int _13019 = NOVALUE;
    int _13017 = NOVALUE;
    int _13012 = NOVALUE;
    int _13010 = NOVALUE;
    int _13009 = NOVALUE;
    int _13006 = NOVALUE;
    int _13004 = NOVALUE;
    int _13001 = NOVALUE;
    int _12999 = NOVALUE;
    int _12997 = NOVALUE;
    int _12994 = NOVALUE;
    int _12988 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence data = ""*/
    RefDS(_5);
    DeRef(_data_23381);
    _data_23381 = _5;

    /** 	for i = 1 to length(kvpairs) do*/
    if (IS_SEQUENCE(_kvpairs_23379)){
            _12988 = SEQ_PTR(_kvpairs_23379)->length;
    }
    else {
        _12988 = 1;
    }
    {
        int _i_23383;
        _i_23383 = 1;
L1: 
        if (_i_23383 > _12988){
            goto L2; // [17] 200
        }

        /** 		object kvpair = kvpairs[i]*/
        DeRef(_kvpair_23385);
        _2 = (int)SEQ_PTR(_kvpairs_23379);
        _kvpair_23385 = (int)*(((s1_ptr)_2)->base + _i_23383);
        Ref(_kvpair_23385);

        /** 		integer enctyp = ENCODE_NONE*/
        _enctyp_23387 = 0;

        /** 		sequence mimetyp = ""*/
        RefDS(_5);
        DeRef(_mimetyp_23388);
        _mimetyp_23388 = _5;

        /** 		if i > 1 then*/
        if (_i_23383 <= 1)
        goto L3; // [44] 55

        /** 			data &= "\r\n"*/
        Concat((object_ptr)&_data_23381, _data_23381, _12991);
L3: 

        /** 		data &= "--" & boundary & "\r\n"*/
        {
            int concat_list[3];

            concat_list[0] = _12991;
            concat_list[1] = _boundary_23380;
            concat_list[2] = _12993;
            Concat_N((object_ptr)&_12994, concat_list, 3);
        }
        Concat((object_ptr)&_data_23381, _data_23381, _12994);
        DeRefDS(_12994);
        _12994 = NOVALUE;

        /** 		data &= "Content-Disposition: form-data; name=\"" & kvpair[1] & "\""*/
        _2 = (int)SEQ_PTR(_kvpair_23385);
        _12997 = (int)*(((s1_ptr)_2)->base + 1);
        {
            int concat_list[3];

            concat_list[0] = _12998;
            concat_list[1] = _12997;
            concat_list[2] = _12996;
            Concat_N((object_ptr)&_12999, concat_list, 3);
        }
        _12997 = NOVALUE;
        Concat((object_ptr)&_data_23381, _data_23381, _12999);
        DeRefDS(_12999);
        _12999 = NOVALUE;

        /** 		if length(kvpair) = 5 then*/
        if (IS_SEQUENCE(_kvpair_23385)){
                _13001 = SEQ_PTR(_kvpair_23385)->length;
        }
        else {
            _13001 = 1;
        }
        if (_13001 != 5)
        goto L4; // [88] 170

        /** 			data &= "; filename=\"" & kvpair[3] & "\"\r\n"*/
        _2 = (int)SEQ_PTR(_kvpair_23385);
        _13004 = (int)*(((s1_ptr)_2)->base + 3);
        {
            int concat_list[3];

            concat_list[0] = _13005;
            concat_list[1] = _13004;
            concat_list[2] = _13003;
            Concat_N((object_ptr)&_13006, concat_list, 3);
        }
        _13004 = NOVALUE;
        Concat((object_ptr)&_data_23381, _data_23381, _13006);
        DeRefDS(_13006);
        _13006 = NOVALUE;

        /** 			data &= "Content-Type: " & kvpair[4] & "\r\n"*/
        _2 = (int)SEQ_PTR(_kvpair_23385);
        _13009 = (int)*(((s1_ptr)_2)->base + 4);
        {
            int concat_list[3];

            concat_list[0] = _12991;
            concat_list[1] = _13009;
            concat_list[2] = _13008;
            Concat_N((object_ptr)&_13010, concat_list, 3);
        }
        _13009 = NOVALUE;
        Concat((object_ptr)&_data_23381, _data_23381, _13010);
        DeRefDS(_13010);
        _13010 = NOVALUE;

        /** 			switch kvpair[5] do*/
        _2 = (int)SEQ_PTR(_kvpair_23385);
        _13012 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_SEQUENCE(_13012) ){
            goto L5; // [130] 177
        }
        if(!IS_ATOM_INT(_13012)){
            if( (DBL_PTR(_13012)->dbl != (double) ((int) DBL_PTR(_13012)->dbl) ) ){
                goto L5; // [130] 177
            }
            _0 = (int) DBL_PTR(_13012)->dbl;
        }
        else {
            _0 = _13012;
        };
        _13012 = NOVALUE;
        switch ( _0 ){ 

            /** 				case ENCODE_NONE then*/
            case 0:

            /** 				case ENCODE_BASE64 then*/
            goto L5; // [141] 177
            case 1:

            /** 					data &= "Content-Transfer-Encoding: base64\r\n"*/
            Concat((object_ptr)&_data_23381, _data_23381, _13015);

            /** 					kvpair[2] = base64:encode(kvpair[2], 76)*/
            _2 = (int)SEQ_PTR(_kvpair_23385);
            _13017 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_13017);
            _13019 = _30encode(_13017, 76);
            _13017 = NOVALUE;
            _2 = (int)SEQ_PTR(_kvpair_23385);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _kvpair_23385 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _13019;
            if( _1 != _13019 ){
                DeRef(_1);
            }
            _13019 = NOVALUE;
        ;}        goto L5; // [167] 177
L4: 

        /** 			data &= "\r\n"*/
        Concat((object_ptr)&_data_23381, _data_23381, _12991);
L5: 

        /** 		data &= "\r\n" & kvpair[2]*/
        _2 = (int)SEQ_PTR(_kvpair_23385);
        _13021 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_12991) && IS_ATOM(_13021)) {
            Ref(_13021);
            Append(&_13022, _12991, _13021);
        }
        else if (IS_ATOM(_12991) && IS_SEQUENCE(_13021)) {
        }
        else {
            Concat((object_ptr)&_13022, _12991, _13021);
        }
        _13021 = NOVALUE;
        Concat((object_ptr)&_data_23381, _data_23381, _13022);
        DeRefDS(_13022);
        _13022 = NOVALUE;
        DeRef(_kvpair_23385);
        _kvpair_23385 = NOVALUE;
        DeRef(_mimetyp_23388);
        _mimetyp_23388 = NOVALUE;

        /** 	end for*/
        _i_23383 = _i_23383 + 1;
        goto L1; // [195] 24
L2: 
        ;
    }

    /** 	return data & "\r\n--" & boundary & "--"*/
    {
        int concat_list[4];

        concat_list[0] = _12993;
        concat_list[1] = _boundary_23380;
        concat_list[2] = _13024;
        concat_list[3] = _data_23381;
        Concat_N((object_ptr)&_13025, concat_list, 4);
    }
    DeRefDS(_kvpairs_23379);
    DeRefDS(_boundary_23380);
    DeRefDS(_data_23381);
    return _13025;
    ;
}


int _54random_boundary(int _len_23436)
{
    int _boundary_23437 = NOVALUE;
    int _13031 = NOVALUE;
    int _13030 = NOVALUE;
    int _13029 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence boundary = repeat(0, len)*/
    DeRef(_boundary_23437);
    _boundary_23437 = Repeat(0, 20);

    /** 	for i = 1 to len do*/
    _13029 = 20;
    {
        int _i_23440;
        _i_23440 = 1;
L1: 
        if (_i_23440 > 20){
            goto L2; // [14] 43
        }

        /** 		boundary[i] = rand_chars[rand(rand_chars_len)]*/
        _13030 = good_rand() % ((unsigned)_54rand_chars_len_23432) + 1;
        _2 = (int)SEQ_PTR(_54rand_chars_23430);
        _13031 = (int)*(((s1_ptr)_2)->base + _13030);
        Ref(_13031);
        _2 = (int)SEQ_PTR(_boundary_23437);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _boundary_23437 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23440);
        _1 = *(int *)_2;
        *(int *)_2 = _13031;
        if( _1 != _13031 ){
            DeRef(_1);
        }
        _13031 = NOVALUE;

        /** 	end for*/
        _i_23440 = _i_23440 + 1;
        goto L1; // [38] 21
L2: 
        ;
    }

    /** 	return boundary*/
    DeRef(_13030);
    _13030 = NOVALUE;
    return _boundary_23437;
    ;
}


int _54execute_request(int _host_23446, int _port_23447, int _request_23448, int _timeout_23449)
{
    int _addrinfo_23450 = NOVALUE;
    int _sock_23462 = NOVALUE;
    int _send_1__tmp_at103_23472 = NOVALUE;
    int _send_inlined_send_at_103_23471 = NOVALUE;
    int _close_1__tmp_at130_23478 = NOVALUE;
    int _close_inlined_close_at_130_23477 = NOVALUE;
    int _start_time_23479 = NOVALUE;
    int _got_header_23481 = NOVALUE;
    int _content_length_23482 = NOVALUE;
    int _content_23483 = NOVALUE;
    int _headers_23484 = NOVALUE;
    int _has_data_23494 = NOVALUE;
    int _data_23504 = NOVALUE;
    int _receive_1__tmp_at258_23507 = NOVALUE;
    int _receive_inlined_receive_at_258_23506 = NOVALUE;
    int _header_end_pos_23516 = NOVALUE;
    int _raw_header_23520 = NOVALUE;
    int _header_lines_23525 = NOVALUE;
    int _header_23535 = NOVALUE;
    int _this_header_23537 = NOVALUE;
    int _13092 = NOVALUE;
    int _13090 = NOVALUE;
    int _13089 = NOVALUE;
    int _13087 = NOVALUE;
    int _13086 = NOVALUE;
    int _13084 = NOVALUE;
    int _13083 = NOVALUE;
    int _13079 = NOVALUE;
    int _13077 = NOVALUE;
    int _13076 = NOVALUE;
    int _13073 = NOVALUE;
    int _13072 = NOVALUE;
    int _13065 = NOVALUE;
    int _13064 = NOVALUE;
    int _13063 = NOVALUE;
    int _13062 = NOVALUE;
    int _13061 = NOVALUE;
    int _13060 = NOVALUE;
    int _13059 = NOVALUE;
    int _13058 = NOVALUE;
    int _13056 = NOVALUE;
    int _13055 = NOVALUE;
    int _13054 = NOVALUE;
    int _13051 = NOVALUE;
    int _13050 = NOVALUE;
    int _13047 = NOVALUE;
    int _13046 = NOVALUE;
    int _13044 = NOVALUE;
    int _13043 = NOVALUE;
    int _13042 = NOVALUE;
    int _13040 = NOVALUE;
    int _13039 = NOVALUE;
    int _13038 = NOVALUE;
    int _13036 = NOVALUE;
    int _13035 = NOVALUE;
    int _13034 = NOVALUE;
    int _13033 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_23447)) {
        _1 = (long)(DBL_PTR(_port_23447)->dbl);
        DeRefDS(_port_23447);
        _port_23447 = _1;
    }

    /** 	object addrinfo = host_by_name(host)*/
    RefDS(_host_23446);
    _0 = _addrinfo_23450;
    _addrinfo_23450 = _53host_by_name(_host_23446);
    DeRef(_0);

    /** 	if atom(addrinfo) or length(addrinfo) < 3 or length(addrinfo[3]) = 0 then*/
    _13033 = IS_ATOM(_addrinfo_23450);
    if (_13033 != 0) {
        _13034 = 1;
        goto L1; // [20] 35
    }
    if (IS_SEQUENCE(_addrinfo_23450)){
            _13035 = SEQ_PTR(_addrinfo_23450)->length;
    }
    else {
        _13035 = 1;
    }
    _13036 = (_13035 < 3);
    _13035 = NOVALUE;
    _13034 = (_13036 != 0);
L1: 
    if (_13034 != 0) {
        goto L2; // [35] 55
    }
    _2 = (int)SEQ_PTR(_addrinfo_23450);
    _13038 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13038)){
            _13039 = SEQ_PTR(_13038)->length;
    }
    else {
        _13039 = 1;
    }
    _13038 = NOVALUE;
    _13040 = (_13039 == 0);
    _13039 = NOVALUE;
    if (_13040 == 0)
    {
        DeRef(_13040);
        _13040 = NOVALUE;
        goto L3; // [51] 62
    }
    else{
        DeRef(_13040);
        _13040 = NOVALUE;
    }
L2: 

    /** 		return ERR_HOST_LOOKUP_FAILED*/
    DeRefDS(_host_23446);
    DeRefDS(_request_23448);
    DeRef(_addrinfo_23450);
    DeRef(_sock_23462);
    DeRef(_start_time_23479);
    DeRef(_content_23483);
    DeRef(_headers_23484);
    DeRef(_13036);
    _13036 = NOVALUE;
    _13038 = NOVALUE;
    return -5;
L3: 

    /** 	sock:socket sock = sock:create(sock:AF_INET, sock:SOCK_STREAM, 0)*/
    Ref(_48AF_INET_22072);
    Ref(_48SOCK_STREAM_22082);
    _0 = _sock_23462;
    _sock_23462 = _48create(_48AF_INET_22072, _48SOCK_STREAM_22082, 0);
    DeRef(_0);

    /** 	if sock:connect(sock, addrinfo[3][1], port) != sock:OK then*/
    _2 = (int)SEQ_PTR(_addrinfo_23450);
    _13042 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_13042);
    _13043 = (int)*(((s1_ptr)_2)->base + 1);
    _13042 = NOVALUE;
    Ref(_sock_23462);
    Ref(_13043);
    _13044 = _48connect(_sock_23462, _13043, _port_23447);
    _13043 = NOVALUE;
    if (binary_op_a(EQUALS, _13044, 0)){
        DeRef(_13044);
        _13044 = NOVALUE;
        goto L4; // [90] 101
    }
    DeRef(_13044);
    _13044 = NOVALUE;

    /** 		return ERR_CONNECT_FAILED*/
    DeRefDS(_host_23446);
    DeRefDS(_request_23448);
    DeRef(_addrinfo_23450);
    DeRef(_sock_23462);
    DeRef(_start_time_23479);
    DeRef(_content_23483);
    DeRef(_headers_23484);
    DeRef(_13036);
    _13036 = NOVALUE;
    _13038 = NOVALUE;
    return -6;
L4: 

    /** 	if not sock:send(sock, request, 0) = length(request) then*/

    /** 	return machine_func(M_SOCK_SEND, { sock, data, flags })*/
    _0 = _send_1__tmp_at103_23472;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_23462);
    *((int *)(_2+4)) = _sock_23462;
    RefDS(_request_23448);
    *((int *)(_2+8)) = _request_23448;
    *((int *)(_2+12)) = 0;
    _send_1__tmp_at103_23472 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_send_inlined_send_at_103_23471);
    _send_inlined_send_at_103_23471 = machine(85, _send_1__tmp_at103_23472);
    DeRef(_send_1__tmp_at103_23472);
    _send_1__tmp_at103_23472 = NOVALUE;
    if (IS_ATOM_INT(_send_inlined_send_at_103_23471)) {
        _13046 = (_send_inlined_send_at_103_23471 == 0);
    }
    else {
        _13046 = unary_op(NOT, _send_inlined_send_at_103_23471);
    }
    if (IS_SEQUENCE(_request_23448)){
            _13047 = SEQ_PTR(_request_23448)->length;
    }
    else {
        _13047 = 1;
    }
    if (binary_op_a(NOTEQ, _13046, _13047)){
        DeRef(_13046);
        _13046 = NOVALUE;
        _13047 = NOVALUE;
        goto L5; // [124] 150
    }
    DeRef(_13046);
    _13046 = NOVALUE;
    _13047 = NOVALUE;

    /** 		sock:close(sock)*/

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _0 = _close_1__tmp_at130_23478;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_23462);
    *((int *)(_2+4)) = _sock_23462;
    _close_1__tmp_at130_23478 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_close_inlined_close_at_130_23477);
    _close_inlined_close_at_130_23477 = machine(82, _close_1__tmp_at130_23478);
    DeRef(_close_1__tmp_at130_23478);
    _close_1__tmp_at130_23478 = NOVALUE;

    /** 		return ERR_SEND_FAILED*/
    DeRefDS(_host_23446);
    DeRefDS(_request_23448);
    DeRef(_addrinfo_23450);
    DeRef(_sock_23462);
    DeRef(_start_time_23479);
    DeRef(_content_23483);
    DeRef(_headers_23484);
    DeRef(_13036);
    _13036 = NOVALUE;
    _13038 = NOVALUE;
    return -7;
L5: 

    /** 	atom start_time = time()*/
    DeRef(_start_time_23479);
    _start_time_23479 = NewDouble(current_time());

    /** 	integer got_header = 0, content_length = -1*/
    _got_header_23481 = 0;
    _content_length_23482 = -1;

    /** 	sequence content = ""*/
    RefDS(_5);
    DeRef(_content_23483);
    _content_23483 = _5;

    /** 	sequence headers = {}*/
    RefDS(_5);
    DeRef(_headers_23484);
    _headers_23484 = _5;

    /** 	while time() - start_time < timeout label "top" do*/
L6: 
    DeRef(_13050);
    _13050 = NewDouble(current_time());
    if (IS_ATOM_INT(_start_time_23479)) {
        _13051 = NewDouble(DBL_PTR(_13050)->dbl - (double)_start_time_23479);
    }
    else
    _13051 = NewDouble(DBL_PTR(_13050)->dbl - DBL_PTR(_start_time_23479)->dbl);
    DeRefDS(_13050);
    _13050 = NOVALUE;
    if (binary_op_a(GREATEREQ, _13051, _timeout_23449)){
        DeRefDS(_13051);
        _13051 = NOVALUE;
        goto L7; // [187] 486
    }
    DeRef(_13051);
    _13051 = NOVALUE;

    /** 		if got_header and length(content) = content_length then*/
    if (_got_header_23481 == 0) {
        goto L8; // [193] 213
    }
    if (IS_SEQUENCE(_content_23483)){
            _13055 = SEQ_PTR(_content_23483)->length;
    }
    else {
        _13055 = 1;
    }
    _13056 = (_13055 == _content_length_23482);
    _13055 = NOVALUE;
    if (_13056 == 0)
    {
        DeRef(_13056);
        _13056 = NOVALUE;
        goto L8; // [205] 213
    }
    else{
        DeRef(_13056);
        _13056 = NOVALUE;
    }

    /** 			exit*/
    goto L7; // [210] 486
L8: 

    /** 		object has_data = sock:select(sock, {}, {}, timeout)*/
    Ref(_sock_23462);
    RefDS(_5);
    RefDS(_5);
    _0 = _has_data_23494;
    _has_data_23494 = _48select(_sock_23462, _5, _5, _timeout_23449, 0);
    DeRef(_0);

    /** 		if (length(has_data[1]) > 2) and equal(has_data[1][2],1) then*/
    _2 = (int)SEQ_PTR(_has_data_23494);
    _13058 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_13058)){
            _13059 = SEQ_PTR(_13058)->length;
    }
    else {
        _13059 = 1;
    }
    _13058 = NOVALUE;
    _13060 = (_13059 > 2);
    _13059 = NOVALUE;
    if (_13060 == 0) {
        goto L9; // [236] 477
    }
    _2 = (int)SEQ_PTR(_has_data_23494);
    _13062 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_13062);
    _13063 = (int)*(((s1_ptr)_2)->base + 2);
    _13062 = NOVALUE;
    if (_13063 == 1)
    _13064 = 1;
    else if (IS_ATOM_INT(_13063) && IS_ATOM_INT(1))
    _13064 = 0;
    else
    _13064 = (compare(_13063, 1) == 0);
    _13063 = NOVALUE;
    if (_13064 == 0)
    {
        _13064 = NOVALUE;
        goto L9; // [253] 477
    }
    else{
        _13064 = NOVALUE;
    }

    /** 			object data = sock:receive(sock, 0)*/

    /** 	return machine_func(M_SOCK_RECV, { sock, flags })*/
    Ref(_sock_23462);
    DeRef(_receive_1__tmp_at258_23507);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_23462;
    ((int *)_2)[2] = 0;
    _receive_1__tmp_at258_23507 = MAKE_SEQ(_1);
    DeRef(_data_23504);
    _data_23504 = machine(86, _receive_1__tmp_at258_23507);
    DeRef(_receive_1__tmp_at258_23507);
    _receive_1__tmp_at258_23507 = NOVALUE;

    /** 			if atom(data) then*/
    _13065 = IS_ATOM(_data_23504);
    if (_13065 == 0)
    {
        _13065 = NOVALUE;
        goto LA; // [276] 304
    }
    else{
        _13065 = NOVALUE;
    }

    /** 				if data = 0 then*/
    if (binary_op_a(NOTEQ, _data_23504, 0)){
        goto LB; // [281] 296
    }

    /** 					exit "top"*/
    DeRef(_data_23504);
    _data_23504 = NOVALUE;
    DeRef(_has_data_23494);
    _has_data_23494 = NOVALUE;
    goto L7; // [291] 486
    goto LC; // [293] 303
LB: 

    /** 					return ERR_RECEIVE_FAILED*/
    DeRef(_data_23504);
    DeRef(_has_data_23494);
    DeRefDS(_host_23446);
    DeRefDS(_request_23448);
    DeRef(_addrinfo_23450);
    DeRef(_sock_23462);
    DeRef(_start_time_23479);
    DeRef(_content_23483);
    DeRef(_headers_23484);
    DeRef(_13036);
    _13036 = NOVALUE;
    _13038 = NOVALUE;
    _13058 = NOVALUE;
    DeRef(_13060);
    _13060 = NOVALUE;
    return -8;
LC: 
LA: 

    /** 			content &= data*/
    if (IS_SEQUENCE(_content_23483) && IS_ATOM(_data_23504)) {
        Ref(_data_23504);
        Append(&_content_23483, _content_23483, _data_23504);
    }
    else if (IS_ATOM(_content_23483) && IS_SEQUENCE(_data_23504)) {
    }
    else {
        Concat((object_ptr)&_content_23483, _content_23483, _data_23504);
    }

    /** 			if not got_header then*/
    if (_got_header_23481 != 0)
    goto LD; // [312] 474

    /** 				integer header_end_pos = match("\r\n\r\n", content)*/
    _header_end_pos_23516 = e_match_from(_13069, _content_23483, 1);

    /** 				if header_end_pos then*/
    if (_header_end_pos_23516 == 0)
    {
        goto LE; // [324] 471
    }
    else{
    }

    /** 					sequence raw_header = content[1..header_end_pos]*/
    rhs_slice_target = (object_ptr)&_raw_header_23520;
    RHS_Slice(_content_23483, 1, _header_end_pos_23516);

    /** 					content = content[header_end_pos + 4..$]*/
    _13072 = _header_end_pos_23516 + 4;
    if (IS_SEQUENCE(_content_23483)){
            _13073 = SEQ_PTR(_content_23483)->length;
    }
    else {
        _13073 = 1;
    }
    rhs_slice_target = (object_ptr)&_content_23483;
    RHS_Slice(_content_23483, _13072, _13073);

    /** 					sequence header_lines = split(raw_header, "\r\n")*/
    RefDS(_raw_header_23520);
    RefDS(_12991);
    _0 = _header_lines_23525;
    _header_lines_23525 = _23split(_raw_header_23520, _12991, 0, 0);
    DeRef(_0);

    /** 					headers = append(headers, split(header_lines[1], " "))*/
    _2 = (int)SEQ_PTR(_header_lines_23525);
    _13076 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_13076);
    RefDS(_12790);
    _13077 = _23split(_13076, _12790, 0, 0);
    _13076 = NOVALUE;
    Ref(_13077);
    Append(&_headers_23484, _headers_23484, _13077);
    DeRef(_13077);
    _13077 = NOVALUE;

    /** 					for i = 2 to length(header_lines) do*/
    if (IS_SEQUENCE(_header_lines_23525)){
            _13079 = SEQ_PTR(_header_lines_23525)->length;
    }
    else {
        _13079 = 1;
    }
    {
        int _i_23533;
        _i_23533 = 2;
LF: 
        if (_i_23533 > _13079){
            goto L10; // [381] 465
        }

        /** 						object header = header_lines[i]*/
        DeRef(_header_23535);
        _2 = (int)SEQ_PTR(_header_lines_23525);
        _header_23535 = (int)*(((s1_ptr)_2)->base + _i_23533);
        Ref(_header_23535);

        /** 						sequence this_header = split(header, ": ", , 1)*/
        Ref(_header_23535);
        RefDS(_13081);
        _0 = _this_header_23537;
        _this_header_23537 = _23split(_header_23535, _13081, 0, 1);
        DeRef(_0);

        /** 						this_header[1] = lower(this_header[1])*/
        _2 = (int)SEQ_PTR(_this_header_23537);
        _13083 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_13083);
        _13084 = _6lower(_13083);
        _13083 = NOVALUE;
        _2 = (int)SEQ_PTR(_this_header_23537);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _this_header_23537 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _13084;
        if( _1 != _13084 ){
            DeRef(_1);
        }
        _13084 = NOVALUE;

        /** 						headers = append(headers, this_header)*/
        RefDS(_this_header_23537);
        Append(&_headers_23484, _headers_23484, _this_header_23537);

        /** 						if equal(lower(this_header[1]), "content-length") then*/
        _2 = (int)SEQ_PTR(_this_header_23537);
        _13086 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_13086);
        _13087 = _6lower(_13086);
        _13086 = NOVALUE;
        if (_13087 == _13088)
        _13089 = 1;
        else if (IS_ATOM_INT(_13087) && IS_ATOM_INT(_13088))
        _13089 = 0;
        else
        _13089 = (compare(_13087, _13088) == 0);
        DeRef(_13087);
        _13087 = NOVALUE;
        if (_13089 == 0)
        {
            _13089 = NOVALUE;
            goto L11; // [439] 456
        }
        else{
            _13089 = NOVALUE;
        }

        /** 							content_length = to_number(this_header[2])*/
        _2 = (int)SEQ_PTR(_this_header_23537);
        _13090 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_13090);
        _content_length_23482 = _8to_number(_13090, 0);
        _13090 = NOVALUE;
        if (!IS_ATOM_INT(_content_length_23482)) {
            _1 = (long)(DBL_PTR(_content_length_23482)->dbl);
            DeRefDS(_content_length_23482);
            _content_length_23482 = _1;
        }
L11: 
        DeRef(_header_23535);
        _header_23535 = NOVALUE;
        DeRef(_this_header_23537);
        _this_header_23537 = NOVALUE;

        /** 					end for*/
        _i_23533 = _i_23533 + 1;
        goto LF; // [460] 388
L10: 
        ;
    }

    /** 					got_header = 1*/
    _got_header_23481 = 1;
LE: 
    DeRef(_raw_header_23520);
    _raw_header_23520 = NOVALUE;
    DeRef(_header_lines_23525);
    _header_lines_23525 = NOVALUE;
LD: 
L9: 
    DeRef(_data_23504);
    _data_23504 = NOVALUE;
    DeRef(_has_data_23494);
    _has_data_23494 = NOVALUE;

    /** 	end while*/
    goto L6; // [483] 181
L7: 

    /** 	return { headers, content }*/
    RefDS(_content_23483);
    RefDS(_headers_23484);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _headers_23484;
    ((int *)_2)[2] = _content_23483;
    _13092 = MAKE_SEQ(_1);
    DeRefDS(_host_23446);
    DeRefDS(_request_23448);
    DeRef(_addrinfo_23450);
    DeRef(_sock_23462);
    DeRef(_start_time_23479);
    DeRefDS(_content_23483);
    DeRefDS(_headers_23484);
    DeRef(_13036);
    _13036 = NOVALUE;
    _13038 = NOVALUE;
    _13058 = NOVALUE;
    DeRef(_13060);
    _13060 = NOVALUE;
    DeRef(_13072);
    _13072 = NOVALUE;
    return _13092;
    ;
}


int  __stdcall _54http_post(int _url_23557, int _data_23558, int _headers_23559, int _follow_redirects_23560, int _timeout_23561)
{
    int _request_23568 = NOVALUE;
    int _data_type_23573 = NOVALUE;
    int _content_type_23589 = NOVALUE;
    int _boundary_23598 = NOVALUE;
    int _13140 = NOVALUE;
    int _13139 = NOVALUE;
    int _13138 = NOVALUE;
    int _13137 = NOVALUE;
    int _13136 = NOVALUE;
    int _13135 = NOVALUE;
    int _13134 = NOVALUE;
    int _13133 = NOVALUE;
    int _13132 = NOVALUE;
    int _13131 = NOVALUE;
    int _13130 = NOVALUE;
    int _13129 = NOVALUE;
    int _13128 = NOVALUE;
    int _13126 = NOVALUE;
    int _13125 = NOVALUE;
    int _13124 = NOVALUE;
    int _13123 = NOVALUE;
    int _13119 = NOVALUE;
    int _13114 = NOVALUE;
    int _13113 = NOVALUE;
    int _13109 = NOVALUE;
    int _13108 = NOVALUE;
    int _13106 = NOVALUE;
    int _13105 = NOVALUE;
    int _13104 = NOVALUE;
    int _13103 = NOVALUE;
    int _13101 = NOVALUE;
    int _13100 = NOVALUE;
    int _13097 = NOVALUE;
    int _13096 = NOVALUE;
    int _13094 = NOVALUE;
    int _13093 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_follow_redirects_23560)) {
        _1 = (long)(DBL_PTR(_follow_redirects_23560)->dbl);
        DeRefDS(_follow_redirects_23560);
        _follow_redirects_23560 = _1;
    }
    if (!IS_ATOM_INT(_timeout_23561)) {
        _1 = (long)(DBL_PTR(_timeout_23561)->dbl);
        DeRefDS(_timeout_23561);
        _timeout_23561 = _1;
    }

    /** 	follow_redirects = follow_redirects -- Not used yet.*/
    _follow_redirects_23560 = _follow_redirects_23560;

    /** 	if not sequence(data) or length(data) = 0 then*/
    _13093 = IS_SEQUENCE(_data_23558);
    _13094 = (_13093 == 0);
    _13093 = NOVALUE;
    if (_13094 != 0) {
        goto L1; // [20] 36
    }
    if (IS_SEQUENCE(_data_23558)){
            _13096 = SEQ_PTR(_data_23558)->length;
    }
    else {
        _13096 = 1;
    }
    _13097 = (_13096 == 0);
    _13096 = NOVALUE;
    if (_13097 == 0)
    {
        DeRef(_13097);
        _13097 = NOVALUE;
        goto L2; // [32] 43
    }
    else{
        DeRef(_13097);
        _13097 = NOVALUE;
    }
L1: 

    /** 		return ERR_INVALID_DATA*/
    DeRefDS(_url_23557);
    DeRef(_data_23558);
    DeRef(_headers_23559);
    DeRef(_request_23568);
    DeRef(_content_type_23589);
    DeRef(_13094);
    _13094 = NOVALUE;
    return -3;
L2: 

    /** 	object request = format_base_request("POST", url, headers)*/
    RefDS(_13098);
    RefDS(_url_23557);
    Ref(_headers_23559);
    _0 = _request_23568;
    _request_23568 = _54format_base_request(_13098, _url_23557, _headers_23559);
    DeRef(_0);

    /** 	if atom(request) then*/
    _13100 = IS_ATOM(_request_23568);
    if (_13100 == 0)
    {
        _13100 = NOVALUE;
        goto L3; // [56] 66
    }
    else{
        _13100 = NOVALUE;
    }

    /** 		return request*/
    DeRefDS(_url_23557);
    DeRef(_data_23558);
    DeRef(_headers_23559);
    DeRef(_content_type_23589);
    DeRef(_13094);
    _13094 = NOVALUE;
    return _request_23568;
L3: 

    /** 	integer data_type*/

    /** 	if ascii_string(data) or sequence(data[1]) then*/
    Ref(_data_23558);
    _13101 = _7ascii_string(_data_23558);
    if (IS_ATOM_INT(_13101)) {
        if (_13101 != 0) {
            goto L4; // [74] 90
        }
    }
    else {
        if (DBL_PTR(_13101)->dbl != 0.0) {
            goto L4; // [74] 90
        }
    }
    _2 = (int)SEQ_PTR(_data_23558);
    _13103 = (int)*(((s1_ptr)_2)->base + 1);
    _13104 = IS_SEQUENCE(_13103);
    _13103 = NOVALUE;
    if (_13104 == 0)
    {
        _13104 = NOVALUE;
        goto L5; // [86] 98
    }
    else{
        _13104 = NOVALUE;
    }
L4: 

    /** 		data_type = FORM_URLENCODED*/
    _data_type_23573 = 1;
    goto L6; // [95] 147
L5: 

    /** 		if data[1] < 1 or data[1] > 2 then*/
    _2 = (int)SEQ_PTR(_data_23558);
    _13105 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13105)) {
        _13106 = (_13105 < 1);
    }
    else {
        _13106 = binary_op(LESS, _13105, 1);
    }
    _13105 = NOVALUE;
    if (IS_ATOM_INT(_13106)) {
        if (_13106 != 0) {
            goto L7; // [108] 125
        }
    }
    else {
        if (DBL_PTR(_13106)->dbl != 0.0) {
            goto L7; // [108] 125
        }
    }
    _2 = (int)SEQ_PTR(_data_23558);
    _13108 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13108)) {
        _13109 = (_13108 > 2);
    }
    else {
        _13109 = binary_op(GREATER, _13108, 2);
    }
    _13108 = NOVALUE;
    if (_13109 == 0) {
        DeRef(_13109);
        _13109 = NOVALUE;
        goto L8; // [121] 132
    }
    else {
        if (!IS_ATOM_INT(_13109) && DBL_PTR(_13109)->dbl == 0.0){
            DeRef(_13109);
            _13109 = NOVALUE;
            goto L8; // [121] 132
        }
        DeRef(_13109);
        _13109 = NOVALUE;
    }
    DeRef(_13109);
    _13109 = NOVALUE;
L7: 

    /** 			return ERR_INVALID_DATA_ENCODING*/
    DeRefDS(_url_23557);
    DeRef(_data_23558);
    DeRef(_headers_23559);
    DeRef(_request_23568);
    DeRef(_content_type_23589);
    DeRef(_13094);
    _13094 = NOVALUE;
    DeRef(_13101);
    _13101 = NOVALUE;
    DeRef(_13106);
    _13106 = NOVALUE;
    return -4;
L8: 

    /** 		data_type = data[1]*/
    _2 = (int)SEQ_PTR(_data_23558);
    _data_type_23573 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_data_type_23573)){
        _data_type_23573 = (long)DBL_PTR(_data_type_23573)->dbl;
    }

    /** 		data = data[2]*/
    _0 = _data_23558;
    _2 = (int)SEQ_PTR(_data_23558);
    _data_23558 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_23558);
    DeRef(_0);
L6: 

    /** 	sequence content_type = ENCODING_STRINGS[data_type]*/
    DeRef(_content_type_23589);
    _2 = (int)SEQ_PTR(_54ENCODING_STRINGS_23275);
    _content_type_23589 = (int)*(((s1_ptr)_2)->base + _data_type_23573);
    RefDS(_content_type_23589);

    /** 	if sequence(data[1]) then*/
    _2 = (int)SEQ_PTR(_data_23558);
    _13113 = (int)*(((s1_ptr)_2)->base + 1);
    _13114 = IS_SEQUENCE(_13113);
    _13113 = NOVALUE;
    if (_13114 == 0)
    {
        _13114 = NOVALUE;
        goto L9; // [168] 215
    }
    else{
        _13114 = NOVALUE;
    }

    /** 		if data_type = FORM_URLENCODED then*/
    if (_data_type_23573 != 1)
    goto LA; // [173] 186

    /** 			data = form_urlencode(data)*/
    Ref(_data_23558);
    _0 = _data_23558;
    _data_23558 = _54form_urlencode(_data_23558);
    DeRef(_0);
    goto LB; // [183] 214
LA: 

    /** 			sequence boundary = random_boundary(20)*/
    _0 = _boundary_23598;
    _boundary_23598 = _54random_boundary(20);
    DeRef(_0);

    /** 			content_type &= "; boundary=" & boundary*/
    Concat((object_ptr)&_13119, _13118, _boundary_23598);
    Concat((object_ptr)&_content_type_23589, _content_type_23589, _13119);
    DeRefDS(_13119);
    _13119 = NOVALUE;

    /** 			data = multipart_form_data_encode(data, boundary)*/
    Ref(_data_23558);
    RefDS(_boundary_23598);
    _0 = _data_23558;
    _data_23558 = _54multipart_form_data_encode(_data_23558, _boundary_23598);
    DeRef(_0);
    DeRefDS(_boundary_23598);
    _boundary_23598 = NOVALUE;
LB: 
L9: 

    /** 	request[R_REQUEST] &= sprintf("Content-Type: %s\r\n", { content_type })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_content_type_23589);
    *((int *)(_2+4)) = _content_type_23589;
    _13123 = MAKE_SEQ(_1);
    _13124 = EPrintf(-9999999, _13122, _13123);
    DeRefDS(_13123);
    _13123 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    _13125 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_13125) && IS_ATOM(_13124)) {
    }
    else if (IS_ATOM(_13125) && IS_SEQUENCE(_13124)) {
        Ref(_13125);
        Prepend(&_13126, _13124, _13125);
    }
    else {
        Concat((object_ptr)&_13126, _13125, _13124);
        _13125 = NOVALUE;
    }
    _13125 = NOVALUE;
    DeRefDS(_13124);
    _13124 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23568 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _13126;
    if( _1 != _13126 ){
        DeRef(_1);
    }
    _13126 = NOVALUE;

    /** 	request[R_REQUEST] &= sprintf("Content-Length: %d\r\n", { length(data) })*/
    if (IS_SEQUENCE(_data_23558)){
            _13128 = SEQ_PTR(_data_23558)->length;
    }
    else {
        _13128 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13128;
    _13129 = MAKE_SEQ(_1);
    _13128 = NOVALUE;
    _13130 = EPrintf(-9999999, _13127, _13129);
    DeRefDS(_13129);
    _13129 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    _13131 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_13131) && IS_ATOM(_13130)) {
    }
    else if (IS_ATOM(_13131) && IS_SEQUENCE(_13130)) {
        Ref(_13131);
        Prepend(&_13132, _13130, _13131);
    }
    else {
        Concat((object_ptr)&_13132, _13131, _13130);
        _13131 = NOVALUE;
    }
    _13131 = NOVALUE;
    DeRefDS(_13130);
    _13130 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23568 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _13132;
    if( _1 != _13132 ){
        DeRef(_1);
    }
    _13132 = NOVALUE;

    /** 	request[R_REQUEST] &= "\r\n"*/
    _2 = (int)SEQ_PTR(_request_23568);
    _13133 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_13133) && IS_ATOM(_12991)) {
    }
    else if (IS_ATOM(_13133) && IS_SEQUENCE(_12991)) {
        Ref(_13133);
        Prepend(&_13134, _12991, _13133);
    }
    else {
        Concat((object_ptr)&_13134, _13133, _12991);
        _13133 = NOVALUE;
    }
    _13133 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23568 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _13134;
    if( _1 != _13134 ){
        DeRef(_1);
    }
    _13134 = NOVALUE;

    /** 	request[R_REQUEST] &= data*/
    _2 = (int)SEQ_PTR(_request_23568);
    _13135 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_13135) && IS_ATOM(_data_23558)) {
        Ref(_data_23558);
        Append(&_13136, _13135, _data_23558);
    }
    else if (IS_ATOM(_13135) && IS_SEQUENCE(_data_23558)) {
        Ref(_13135);
        Prepend(&_13136, _data_23558, _13135);
    }
    else {
        Concat((object_ptr)&_13136, _13135, _data_23558);
        _13135 = NOVALUE;
    }
    _13135 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23568);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23568 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _13136;
    if( _1 != _13136 ){
        DeRef(_1);
    }
    _13136 = NOVALUE;

    /** 	return execute_request(request[R_HOST], request[R_PORT], request[R_REQUEST], timeout)*/
    _2 = (int)SEQ_PTR(_request_23568);
    _13137 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_request_23568);
    _13138 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_request_23568);
    _13139 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_13137);
    Ref(_13138);
    Ref(_13139);
    _13140 = _54execute_request(_13137, _13138, _13139, _timeout_23561);
    _13137 = NOVALUE;
    _13138 = NOVALUE;
    _13139 = NOVALUE;
    DeRefDS(_url_23557);
    DeRef(_data_23558);
    DeRef(_headers_23559);
    DeRefDS(_request_23568);
    DeRefDS(_content_type_23589);
    DeRef(_13094);
    _13094 = NOVALUE;
    DeRef(_13101);
    _13101 = NOVALUE;
    DeRef(_13106);
    _13106 = NOVALUE;
    return _13140;
    ;
}


int  __stdcall _54http_get(int _url_23625, int _headers_23626, int _follow_redirects_23627, int _timeout_23628)
{
    int _request_23629 = NOVALUE;
    int _13149 = NOVALUE;
    int _13148 = NOVALUE;
    int _13147 = NOVALUE;
    int _13146 = NOVALUE;
    int _13145 = NOVALUE;
    int _13144 = NOVALUE;
    int _13143 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_follow_redirects_23627)) {
        _1 = (long)(DBL_PTR(_follow_redirects_23627)->dbl);
        DeRefDS(_follow_redirects_23627);
        _follow_redirects_23627 = _1;
    }
    if (!IS_ATOM_INT(_timeout_23628)) {
        _1 = (long)(DBL_PTR(_timeout_23628)->dbl);
        DeRefDS(_timeout_23628);
        _timeout_23628 = _1;
    }

    /** 	object request = format_base_request("GET", url, headers)*/
    RefDS(_13141);
    RefDS(_url_23625);
    Ref(_headers_23626);
    _0 = _request_23629;
    _request_23629 = _54format_base_request(_13141, _url_23625, _headers_23626);
    DeRef(_0);

    /** 	follow_redirects = follow_redirects -- Not used yet.*/
    _follow_redirects_23627 = _follow_redirects_23627;

    /** 	if atom(request) then*/
    _13143 = IS_ATOM(_request_23629);
    if (_13143 == 0)
    {
        _13143 = NOVALUE;
        goto L1; // [25] 35
    }
    else{
        _13143 = NOVALUE;
    }

    /** 		return request*/
    DeRefDS(_url_23625);
    DeRef(_headers_23626);
    return _request_23629;
L1: 

    /** 	request[R_REQUEST] &= "\r\n"*/
    _2 = (int)SEQ_PTR(_request_23629);
    _13144 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_13144) && IS_ATOM(_12991)) {
    }
    else if (IS_ATOM(_13144) && IS_SEQUENCE(_12991)) {
        Ref(_13144);
        Prepend(&_13145, _12991, _13144);
    }
    else {
        Concat((object_ptr)&_13145, _13144, _12991);
        _13144 = NOVALUE;
    }
    _13144 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23629);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23629 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _13145;
    if( _1 != _13145 ){
        DeRef(_1);
    }
    _13145 = NOVALUE;

    /** 	return execute_request(request[R_HOST], request[R_PORT], request[R_REQUEST], timeout)*/
    _2 = (int)SEQ_PTR(_request_23629);
    _13146 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_request_23629);
    _13147 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_request_23629);
    _13148 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_13146);
    Ref(_13147);
    Ref(_13148);
    _13149 = _54execute_request(_13146, _13147, _13148, _timeout_23628);
    _13146 = NOVALUE;
    _13147 = NOVALUE;
    _13148 = NOVALUE;
    DeRefDS(_url_23625);
    DeRef(_headers_23626);
    DeRefDS(_request_23629);
    return _13149;
    ;
}



// 0x49C4FA55
