// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _52iif(int _test_22910, int _ifTrue_22911, int _ifFalse_22912)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_22910 == 0) {
        goto L1; // [3] 13
    }
    else {
        if (!IS_ATOM_INT(_test_22910) && DBL_PTR(_test_22910)->dbl == 0.0){
            goto L1; // [3] 13
        }
    }

    /** 		return ifTrue*/
    DeRef(_test_22910);
    DeRef(_ifFalse_22912);
    return _ifTrue_22911;
L1: 

    /** 	return ifFalse*/
    DeRef(_test_22910);
    DeRef(_ifTrue_22911);
    return _ifFalse_22912;
    ;
}


int  __stdcall _52iff(int _test_22916, int _ifTrue_22917, int _ifFalse_22918)
{
    int _iif_inlined_iif_at_2_22920 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return iif(test, ifTrue, ifFalse)*/

    /** 	if test then*/
    if (_test_22916 == 0) {
        goto L1; // [5] 16
    }
    else {
        if (!IS_ATOM_INT(_test_22916) && DBL_PTR(_test_22916)->dbl == 0.0){
            goto L1; // [5] 16
        }
    }

    /** 		return ifTrue*/
    Ref(_ifTrue_22917);
    DeRef(_iif_inlined_iif_at_2_22920);
    _iif_inlined_iif_at_2_22920 = _ifTrue_22917;
    goto L2; // [13] 22
L1: 

    /** 	return ifFalse*/
    Ref(_ifFalse_22918);
    DeRef(_iif_inlined_iif_at_2_22920);
    _iif_inlined_iif_at_2_22920 = _ifFalse_22918;
L2: 
    DeRef(_test_22916);
    DeRef(_ifTrue_22917);
    DeRef(_ifFalse_22918);
    return _iif_inlined_iif_at_2_22920;
    ;
}



// 0x96C9605E
