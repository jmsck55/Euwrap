// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _36color(int _x_14328)
{
    int _8116 = NOVALUE;
    int _8115 = NOVALUE;
    int _8114 = NOVALUE;
    int _8113 = NOVALUE;
    int _8112 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) and x >= 0 and x <= 255 then*/
    if (IS_ATOM_INT(_x_14328))
    _8112 = 1;
    else if (IS_ATOM_DBL(_x_14328))
    _8112 = IS_ATOM_INT(DoubleToInt(_x_14328));
    else
    _8112 = 0;
    if (_8112 == 0) {
        _8113 = 0;
        goto L1; // [6] 18
    }
    if (IS_ATOM_INT(_x_14328)) {
        _8114 = (_x_14328 >= 0);
    }
    else {
        _8114 = binary_op(GREATEREQ, _x_14328, 0);
    }
    if (IS_ATOM_INT(_8114))
    _8113 = (_8114 != 0);
    else
    _8113 = DBL_PTR(_8114)->dbl != 0.0;
L1: 
    if (_8113 == 0) {
        goto L2; // [18] 39
    }
    if (IS_ATOM_INT(_x_14328)) {
        _8116 = (_x_14328 <= 255);
    }
    else {
        _8116 = binary_op(LESSEQ, _x_14328, 255);
    }
    if (_8116 == 0) {
        DeRef(_8116);
        _8116 = NOVALUE;
        goto L2; // [27] 39
    }
    else {
        if (!IS_ATOM_INT(_8116) && DBL_PTR(_8116)->dbl == 0.0){
            DeRef(_8116);
            _8116 = NOVALUE;
            goto L2; // [27] 39
        }
        DeRef(_8116);
        _8116 = NOVALUE;
    }
    DeRef(_8116);
    _8116 = NOVALUE;

    /** 		return 1*/
    DeRef(_x_14328);
    DeRef(_8114);
    _8114 = NOVALUE;
    return 1;
    goto L3; // [36] 46
L2: 

    /** 		return 0*/
    DeRef(_x_14328);
    DeRef(_8114);
    _8114 = NOVALUE;
    return 0;
L3: 
    ;
}


int  __stdcall _36mixture(int _s_14338)
{
    int _8125 = NOVALUE;
    int _8123 = NOVALUE;
    int _8121 = NOVALUE;
    int _8120 = NOVALUE;
    int _8118 = NOVALUE;
    int _8117 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _8117 = IS_ATOM(_s_14338);
    if (_8117 == 0)
    {
        _8117 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _8117 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_s_14338);
    return 0;
L1: 

    /** 	if length(s) != 3 then*/
    if (IS_SEQUENCE(_s_14338)){
            _8118 = SEQ_PTR(_s_14338)->length;
    }
    else {
        _8118 = 1;
    }
    if (_8118 == 3)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_s_14338);
    return 0;
L2: 

    /** 	for i=1 to 3 do*/
    {
        int _i_14345;
        _i_14345 = 1;
L3: 
        if (_i_14345 > 3){
            goto L4; // [34] 87
        }

        /** 		if not integer(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_14338);
        _8120 = (int)*(((s1_ptr)_2)->base + _i_14345);
        if (IS_ATOM_INT(_8120))
        _8121 = 1;
        else if (IS_ATOM_DBL(_8120))
        _8121 = IS_ATOM_INT(DoubleToInt(_8120));
        else
        _8121 = 0;
        _8120 = NOVALUE;
        if (_8121 != 0)
        goto L5; // [50] 60
        _8121 = NOVALUE;

        /** 			return 0*/
        DeRef(_s_14338);
        return 0;
L5: 

        /**   		if and_bits(s[i],#FFFFFFC0) then*/
        _2 = (int)SEQ_PTR(_s_14338);
        _8123 = (int)*(((s1_ptr)_2)->base + _i_14345);
        _8125 = binary_op(AND_BITS, _8123, _8124);
        _8123 = NOVALUE;
        if (_8125 == 0) {
            DeRef(_8125);
            _8125 = NOVALUE;
            goto L6; // [70] 80
        }
        else {
            if (!IS_ATOM_INT(_8125) && DBL_PTR(_8125)->dbl == 0.0){
                DeRef(_8125);
                _8125 = NOVALUE;
                goto L6; // [70] 80
            }
            DeRef(_8125);
            _8125 = NOVALUE;
        }
        DeRef(_8125);
        _8125 = NOVALUE;

        /**   			return 0*/
        DeRef(_s_14338);
        return 0;
L6: 

        /** 	end for*/
        _i_14345 = _i_14345 + 1;
        goto L3; // [82] 41
L4: 
        ;
    }

    /** 	return 1*/
    DeRef(_s_14338);
    return 1;
    ;
}


int  __stdcall _36video_config()
{
    int _8126 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_VIDEO_CONFIG, 0)*/
    _8126 = machine(13, 0);
    return _8126;
    ;
}



// 0xE8EE020A
