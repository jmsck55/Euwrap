// Copyright (C) 2020 James J. Cook


// To be able to execute on Linux, do the following:
/*

LD_LIBRARY_PATH=$PWD
export LD_LIBRARY_PATH
gcc -o testdl testdl.c -ldl
./testdl

*/


#include <stdio.h>
#include <stdlib.h>

#include "eu.h"

int main() {
	char myfunc_name[] = "log10";
	int func_id;
	int num, seq;
	linked_list a = {0,0,0,0};
	int b;
	
	a.length = 0xA0000000;
	a.data = (void *)2;
	
	init_lib();
	// run the function:
	printf("eu_platform returns: %d\n", eu_platform());
	printf("myfunc_name address is: %u\n", (unsigned int)&myfunc_name);
	printf("to_low_high is: %d, %d\n", TO_LOW_HIGH(myfunc_name));
	func_id = eu_routine_id_str(TO_LOW_HIGH(myfunc_name));
	printf("func_id is: %d\n", func_id);
	
	num = register_linked_list(TO_LOW_HIGH(&a));
	eu_question_mark(num);
	seq = eu_repeat(num, 1);
	eu_question_mark(seq);
	
	b = eu_call_func_std(func_id, seq);
	//printf("using eu_call_func, eu_platform returns: %d\n", b);
	printf("log10()\n");
	eu_question_mark(b);
	
	close_lib();
	printf("Success!\n");
	return 0;
}

