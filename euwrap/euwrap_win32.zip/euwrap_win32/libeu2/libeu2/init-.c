#include "include/euphoria.h"
#include "main-.h"

int _5;
int _115;
int _116;
int _118;
int _121;
int _125;
int _126;
int _127;
int _128;
int _129;
int _527;
int _528;
int _529;

// 0xA6A692F1
// Declaring file vars
int _2M_ALLOC_142 = 16;
int _2M_FREE_144 = 17;
int _2M_ALLOC_LOW_146 = 32;
int _2M_FREE_LOW_148 = 33;
int _2M_INTERRUPT_150 = 34;
int _2M_SET_RAND_152 = 35;
int _2M_USE_VESA_154 = 36;
int _2M_CRASH_MESSAGE_156 = 37;
int _2M_TICK_RATE_158 = 38;
int _2M_GET_VECTOR_160 = 39;
int _2M_SET_VECTOR_162 = 40;
int _2M_LOCK_MEMORY_164 = 41;
int _2M_A_TO_F64_166 = 46;
int _2M_F64_TO_A_168 = 47;
int _2M_A_TO_F32_170 = 48;
int _2M_F32_TO_A_172 = 49;
int _2M_CRASH_FILE_174 = 57;
int _2M_CRASH_ROUTINE_176 = 66;
int _2MAX_ADDR_178 = NOVALUE;
int _2LOW_ADDR_182 = NOVALUE;
int _2REG_LIST_SIZE_215 = 10;
int _2REG_DI_217 = 1;
int _2REG_SI_218 = 2;
int _2REG_BP_219 = 3;
int _2REG_BX_221 = 4;
int _2REG_DX_222 = 5;
int _2REG_CX_224 = 6;
int _2REG_AX_226 = 7;
int _2REG_FLAGS_228 = 8;
int _2REG_ES_229 = 9;
int _2REG_DS_231 = 10;
int _2mem_264 = NOVALUE;
int _2allocate_inlined_allocate_at_23_266 = NOVALUE;
int _2check_calls_354 = NOVALUE;
int _3always_linked_list_366 = NOVALUE;
int _3NULL_432 = 0;
int _3SIZE_OF_STRUCT_433 = 16;
int _3MAX_LENGTH_434 = 268435455;
int _3SIGN_MASK_436 = NOVALUE;
int _3SIGN_FLAG_438 = NOVALUE;
int _3DOUBLE_FLAG_439 = NOVALUE;
int _3INT_FLAG_441 = NOVALUE;
int _3UINT_FLAG_443 = NOVALUE;
int _3FLOAT_FLAG_445 = NOVALUE;
int _3CSTRING_447 = NOVALUE;
int _3CBYTES_448 = NOVALUE;
int _1VERSION_707 = 2;
int _1high_address_750 = NOVALUE;
int _1data_751 = NOVALUE;
int _1free_list_752 = NOVALUE;


struct routine_list _00[] = {
  {"set_return_linked_list", (int (*)())_1set_return_linked_list, 0, 1, 1, 1, 6, 0},
  {"get_return_linked_list", (int (*)())_1get_return_linked_list, 1, 1, 0, 1, 6, 0},
  {"get_version", (int (*)())_1get_version, 2, 1, 0, 1, 6, 0},
  {"binary_search", (int (*)())_1binary_search, 3, 1, 2, 0, 5, 0},
  {"init", (int (*)())_1init, 4, 1, 0, 1, 6, 0},
  {"get_high_address", (int (*)())_1get_high_address, 5, 1, 0, 1, 6, 0},
  {"set_high_address", (int (*)())_1set_high_address, 6, 1, 1, 0, 5, 0},
  {"get_address", (int (*)())_1get_address, 7, 1, 2, 0, 5, 0},
  {"register_data", (int (*)())_1register_data, 8, 1, 1, 0, 5, 0},
  {"retval", (int (*)())_1retval, 9, 1, 1, 0, 5, 0},
  {"length_of_data", (int (*)())_1length_of_data, 10, 1, 0, 1, 6, 0},
  {"is_free", (int (*)())_1is_free, 11, 1, 1, 1, 6, 0},
  {"access_free_list", (int (*)())_1access_free_list, 12, 1, 0, 1, 6, 0},
  {"generic_free", (int (*)())_1generic_free, 13, 1, 2, 1, 6, 0},
  {"delete_linked_list", (int (*)())_1delete_linked_list, 14, 1, 1, 1, 6, 0},
  {"free_linked_lists", (int (*)())_1free_linked_lists, 15, 1, 3, 1, 6, 0},
  {"register_linked_list", (int (*)())_1register_linked_list, 16, 1, 2, 1, 6, 0},
  {"new_linked_list", (int (*)())_1new_linked_list, 17, 1, 2, 1, 6, 0},
  {"store_linked_list", (int (*)())_1store_linked_list, 18, 1, 3, 1, 6, 0},
  {"access_linked_list", (int (*)())_1access_linked_list, 19, 1, 1, 1, 6, 0},
  {"at_linked_list", (int (*)())_1at_linked_list, 20, 1, 2, 1, 6, 0},
  {"free_linked_list_dll", (int (*)())_1free_linked_list_dll, 21, 1, 2, 1, 6, 0},
  {"length_linked_list", (int (*)())_1length_linked_list, 22, 1, 1, 1, 6, 0},
  {"store_at_linked_list", (int (*)())_1store_at_linked_list, 23, 1, 4, 1, 6, 0},
  {"eu_repeat", (int (*)())_1eu_repeat, 24, 1, 2, 1, 6, 0},
  {"eu_mem_set", (int (*)())_1eu_mem_set, 25, 1, 4, 1, 6, 0},
  {"eu_mem_copy", (int (*)())_1eu_mem_copy, 26, 1, 5, 1, 6, 0},
  {"eu_add", (int (*)())_1eu_add, 27, 1, 2, 1, 6, 0},
  {"eu_subtract", (int (*)())_1eu_subtract, 28, 1, 2, 1, 6, 0},
  {"eu_multiply", (int (*)())_1eu_multiply, 29, 1, 2, 1, 6, 0},
  {"eu_divide", (int (*)())_1eu_divide, 30, 1, 2, 1, 6, 0},
  {"eu_negate", (int (*)())_1eu_negate, 31, 1, 1, 1, 6, 0},
  {"eu_not", (int (*)())_1eu_not, 32, 1, 1, 1, 6, 0},
  {"eu_equals", (int (*)())_1eu_equals, 33, 1, 2, 1, 6, 0},
  {"eu_and", (int (*)())_1eu_and, 34, 1, 2, 1, 6, 0},
  {"eu_or", (int (*)())_1eu_or, 35, 1, 2, 1, 6, 0},
  {"eu_xor", (int (*)())_1eu_xor, 36, 1, 2, 1, 6, 0},
  {"eu_question_mark", (int (*)())_1eu_question_mark, 37, 1, 1, 1, 6, 0},
  {"eu_abort", (int (*)())_1eu_abort, 38, 1, 1, 1, 6, 0},
  {"eu_and_bits", (int (*)())_1eu_and_bits, 39, 1, 2, 1, 6, 0},
  {"eu_append", (int (*)())_1eu_append, 40, 1, 2, 1, 6, 0},
  {"eu_arctan", (int (*)())_1eu_arctan, 41, 1, 1, 1, 6, 0},
  {"eu_atom", (int (*)())_1eu_atom, 42, 1, 1, 1, 6, 0},
  {"eu_c_func", (int (*)())_1eu_c_func, 43, 1, 2, 1, 6, 0},
  {"eu_c_proc", (int (*)())_1eu_c_proc, 44, 1, 2, 1, 6, 0},
  {"eu_call", (int (*)())_1eu_call, 45, 1, 2, 1, 6, 0},
  {"eu_clear_screen", (int (*)())_1eu_clear_screen, 46, 1, 0, 1, 6, 0},
  {"eu_close", (int (*)())_1eu_close, 47, 1, 1, 1, 6, 0},
  {"eu_command_line", (int (*)())_1eu_command_line, 48, 1, 0, 1, 6, 0},
  {"eu_compare", (int (*)())_1eu_compare, 49, 1, 2, 1, 6, 0},
  {"eu_concat", (int (*)())_1eu_concat, 50, 1, 2, 1, 6, 0},
  {"eu_cos", (int (*)())_1eu_cos, 51, 1, 1, 1, 6, 0},
  {"eu_date", (int (*)())_1eu_date, 52, 1, 0, 1, 6, 0},
  {"eu_equal", (int (*)())_1eu_equal, 53, 1, 2, 1, 6, 0},
  {"eu_find_from", (int (*)())_1eu_find_from, 54, 1, 3, 1, 6, 0},
  {"eu_find", (int (*)())_1eu_find, 55, 1, 3, 1, 6, 0},
  {"eu_floor", (int (*)())_1eu_floor, 56, 1, 1, 1, 6, 0},
  {"eu_integer_division", (int (*)())_1eu_integer_division, 57, 1, 2, 1, 6, 0},
  {"eu_get_key", (int (*)())_1eu_get_key, 58, 1, 0, 1, 6, 0},
  {"eu_getc", (int (*)())_1eu_getc, 59, 1, 1, 1, 6, 0},
  {"eu_getenv", (int (*)())_1eu_getenv, 60, 1, 1, 1, 6, 0},
  {"eu_gets", (int (*)())_1eu_gets, 61, 1, 1, 1, 6, 0},
  {"eu_integer", (int (*)())_1eu_integer, 62, 1, 1, 1, 6, 0},
  {"eu_length", (int (*)())_1eu_length, 63, 1, 1, 1, 6, 0},
  {"eu_log", (int (*)())_1eu_log, 64, 1, 1, 1, 6, 0},
  {"eu_machine_func", (int (*)())_1eu_machine_func, 65, 1, 2, 1, 6, 0},
  {"eu_machine_proc", (int (*)())_1eu_machine_proc, 66, 1, 2, 1, 6, 0},
  {"eu_match_from", (int (*)())_1eu_match_from, 67, 1, 3, 1, 6, 0},
  {"eu_match", (int (*)())_1eu_match, 68, 1, 3, 1, 6, 0},
  {"eu_not_bits", (int (*)())_1eu_not_bits, 69, 1, 1, 1, 6, 0},
  {"eu_object", (int (*)())_1eu_object, 70, 1, 1, 1, 6, 0},
  {"eu_open", (int (*)())_1eu_open, 71, 1, 2, 1, 6, 0},
  {"eu_open_str", (int (*)())_1eu_open_str, 72, 1, 3, 1, 6, 0},
  {"eu_or_bits", (int (*)())_1eu_or_bits, 73, 1, 2, 1, 6, 0},
  {"eu_peek", (int (*)())_1eu_peek, 74, 1, 1, 1, 6, 0},
  {"eu_peek4s", (int (*)())_1eu_peek4s, 75, 1, 1, 1, 6, 0},
  {"eu_peek4u", (int (*)())_1eu_peek4u, 76, 1, 1, 1, 6, 0},
  {"eu_platform", (int (*)())_1eu_platform, 77, 1, 0, 1, 6, 0},
  {"eu_poke", (int (*)())_1eu_poke, 78, 1, 2, 1, 6, 0},
  {"eu_poke4", (int (*)())_1eu_poke4, 79, 1, 2, 1, 6, 0},
  {"eu_position", (int (*)())_1eu_position, 80, 1, 2, 1, 6, 0},
  {"eu_power", (int (*)())_1eu_power, 81, 1, 2, 1, 6, 0},
  {"eu_prepend", (int (*)())_1eu_prepend, 82, 1, 2, 1, 6, 0},
  {"eu_print", (int (*)())_1eu_print, 83, 1, 2, 1, 6, 0},
  {"eu_printf", (int (*)())_1eu_printf, 84, 1, 3, 1, 6, 0},
  {"eu_puts", (int (*)())_1eu_puts, 85, 1, 2, 1, 6, 0},
  {"eu_rand", (int (*)())_1eu_rand, 86, 1, 1, 1, 6, 0},
  {"eu_remainder", (int (*)())_1eu_remainder, 87, 1, 2, 1, 6, 0},
  {"eu_sequence", (int (*)())_1eu_sequence, 88, 1, 1, 1, 6, 0},
  {"eu_sin", (int (*)())_1eu_sin, 89, 1, 1, 1, 6, 0},
  {"eu_sprintf", (int (*)())_1eu_sprintf, 90, 1, 2, 1, 6, 0},
  {"eu_sqrt", (int (*)())_1eu_sqrt, 91, 1, 1, 1, 6, 0},
  {"eu_subscript", (int (*)())_1eu_subscript, 92, 1, 3, 1, 6, 0},
  {"eu_system", (int (*)())_1eu_system, 93, 1, 2, 1, 6, 0},
  {"eu_system_exec", (int (*)())_1eu_system_exec, 94, 1, 2, 1, 6, 0},
  {"eu_tan", (int (*)())_1eu_tan, 95, 1, 1, 1, 6, 0},
  {"eu_time", (int (*)())_1eu_time, 96, 1, 0, 1, 6, 0},
  {"eu_xor_bits", (int (*)())_1eu_xor_bits, 97, 1, 2, 1, 6, 0},
  {"eu_hash", (int (*)())_1eu_hash, 98, 1, 2, 1, 6, 0},
  {"eu_head", (int (*)())_1eu_head, 99, 1, 2, 1, 6, 0},
  {"eu_include_paths", (int (*)())_1eu_include_paths, 100, 1, 1, 1, 6, 0},
  {"eu_insert", (int (*)())_1eu_insert, 101, 1, 3, 1, 6, 0},
  {"eu_peek2s", (int (*)())_1eu_peek2s, 102, 1, 1, 1, 6, 0},
  {"eu_peek2u", (int (*)())_1eu_peek2u, 103, 1, 1, 1, 6, 0},
  {"eu_peek_string", (int (*)())_1eu_peek_string, 104, 1, 1, 1, 6, 0},
  {"eu_peeks", (int (*)())_1eu_peeks, 105, 1, 1, 1, 6, 0},
  {"eu_poke2", (int (*)())_1eu_poke2, 106, 1, 2, 1, 6, 0},
  {"eu_remove", (int (*)())_1eu_remove, 107, 1, 3, 1, 6, 0},
  {"eu_replace", (int (*)())_1eu_replace, 108, 1, 4, 1, 6, 0},
  {"eu_splice", (int (*)())_1eu_splice, 109, 1, 3, 1, 6, 0},
  {"eu_tail", (int (*)())_1eu_tail, 110, 1, 2, 1, 6, 0},
  {"eu_call_func_std", (int (*)())_1eu_call_func_std, 111, 1, 2, 1, 6, 0},
  {"eu_call_func_val", (int (*)())_1eu_call_func_val, 112, 1, 2, 1, 6, 0},
  {"eu_call_func", (int (*)())_1eu_call_func, 113, 1, 2, 1, 6, 0},
  {"eu_call_proc", (int (*)())_1eu_call_proc, 114, 1, 2, 1, 6, 0},
  {"eu_routine_id", (int (*)())_1eu_routine_id, 115, 1, 1, 1, 6, 0},
  {"eu_routine_id_str", (int (*)())_1eu_routine_id_str, 116, 1, 2, 1, 6, 0},
  {"allocate", (int (*)())_2allocate, 122, 2, 1, 1, 6, 0},
  {"free", (int (*)())_2free, 123, 2, 1, 1, 6, 0},
  {"allocate_low", (int (*)())_2allocate_low, 124, 2, 1, 1, 6, 0},
  {"free_low", (int (*)())_2free_low, 125, 2, 1, 1, 6, 0},
  {"int_to_bytes", (int (*)())_2int_to_bytes, 126, 2, 1, 1, 6, 0},
  {"bytes_to_int", (int (*)())_2bytes_to_int, 127, 2, 1, 1, 6, 0},
  {"int_to_bits", (int (*)())_2int_to_bits, 128, 2, 2, 1, 6, 0},
  {"bits_to_int", (int (*)())_2bits_to_int, 129, 2, 1, 1, 6, 0},
  {"set_rand", (int (*)())_2set_rand, 130, 2, 1, 1, 6, 0},
  {"crash_message", (int (*)())_2crash_message, 131, 2, 1, 1, 6, 0},
  {"crash_file", (int (*)())_2crash_file, 132, 2, 1, 1, 6, 0},
  {"crash_routine", (int (*)())_2crash_routine, 133, 2, 1, 1, 6, 0},
  {"atom_to_float64", (int (*)())_2atom_to_float64, 134, 2, 1, 1, 6, 0},
  {"atom_to_float32", (int (*)())_2atom_to_float32, 135, 2, 1, 1, 6, 0},
  {"float64_to_atom", (int (*)())_2float64_to_atom, 136, 2, 1, 1, 6, 0},
  {"float32_to_atom", (int (*)())_2float32_to_atom, 137, 2, 1, 1, 6, 0},
  {"allocate_string", (int (*)())_2allocate_string, 138, 2, 1, 1, 6, 0},
  {"register_block", (int (*)())_2register_block, 139, 2, 2, 1, 6, 0},
  {"unregister_block", (int (*)())_2unregister_block, 140, 2, 1, 1, 6, 0},
  {"check_all_blocks", (int (*)())_2check_all_blocks, 141, 2, 0, 1, 6, 0},
  {"set_return_linked_list", (int (*)())_3set_return_linked_list, 142, 3, 1, 1, 13, 0},
  {"get_return_linked_list", (int (*)())_3get_return_linked_list, 143, 3, 0, 1, 13, 0},
  {"mystring", (int (*)())_3mystring, 144, 3, 1, 1, 13, 0},
  {"myarray", (int (*)())_3myarray, 145, 3, 1, 1, 13, 0},
  {"sequence_to_linked_list", (int (*)())_3sequence_to_linked_list, 146, 3, 1, 1, 13, 0},
  {"free_linked_list", (int (*)())_3free_linked_list, 147, 3, 1, 1, 13, 0},
  {"linked_list_to_sequence", (int (*)())_3linked_list_to_sequence, 148, 3, 1, 1, 13, 0},
  {"", 0, 999999999, 0, 0, 0, 0}
};

unsigned char ** _02;
object _0switches;
struct ns_list _01[] = {
  {"eu", 0, 0, 1},
  {"libeu", 1, 1, 1},
  {"list", 3, 27, 3},
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern unsigned char *string_ptr;
    extern object decompress(unsigned int c);
    extern double sqrt();
    setran(); /* initialize random generator seeds */
    _529 = NewString("C:\\Users\\jmsck\\OneDrive\\euphoria40\\bin\\");
    _528 = NewString("C:\\Users\\Owner\\OneDrive\\euwrap_the_one_im_working_on\\euwrap\\euwrap_win32\\libeu2");
    _527 = NewString("C:\\Users\\Owner\\OneDrive\\euphoria40/include");
    _5 = NewString("");
    _116 = NewDouble((double)-2.1474836480000000e+09);
    _115 = NewDouble((double)2.1474836480000000e+09);
    _121 = NewDouble((double)2.1474836470000000e+09);
    _118 = NewDouble((double)4.2949672950000000e+09);
    _129 = NewDouble((double)3.4896609280000000e+09);
    _128 = NewDouble((double)2.9527900160000000e+09);
    _127 = NewDouble((double)2.6843545600000000e+09);
    _126 = NewDouble((double)2.4159191040000000e+09);
    _125 = NewDouble((double)4.0265318400000000e+09);
	_3SIGN_MASK_436 = NewDouble( 4026531840.0000000000000000 );
	_3SIGN_FLAG_438 = NewDouble( 2147483648.0000000000000000 );
	_3DOUBLE_FLAG_439 = NewDouble( 2415919104.0000000000000000 );
	_3INT_FLAG_441 = NewDouble( 2684354560.0000000000000000 );
	_3UINT_FLAG_443 = NewDouble( 2952790016.0000000000000000 );
	_3FLOAT_FLAG_445 = NewDouble( 3489660928.0000000000000000 );
	_3CSTRING_447 = NewDouble( 4294967295.0000000000000000 );
	_3CBYTES_448 = NewDouble( 2147483648.0000000000000000 );
}
