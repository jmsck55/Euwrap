// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _3set_return_linked_list(int _i_369)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_369)) {
        _1 = (long)(DBL_PTR(_i_369)->dbl);
        DeRefDS(_i_369);
        _i_369 = _1;
    }

    /** 	always_linked_list = i*/
    _3always_linked_list_366 = _i_369;

    /** end procedure*/
    return;
    ;
}


int _3get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _3always_linked_list_366;
    ;
}


int _3mystring(int _x_374)
{
    int _flag_375 = NOVALUE;
    int _i_376 = NOVALUE;
    int _ob_377 = NOVALUE;
    int _105 = NOVALUE;
    int _98 = NOVALUE;
    int _96 = NOVALUE;
    int _94 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _94 = IS_SEQUENCE(_x_374);
    if (_94 != 0)
    goto L1; // [6] 16
    _94 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_374);
    DeRef(_ob_377);
    return 0;
L1: 

    /** 	flag = 0*/
    _flag_375 = 0;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_374)){
            _96 = SEQ_PTR(_x_374)->length;
    }
    else {
        _96 = 1;
    }
    {
        int _j_382;
        _j_382 = 1;
L2: 
        if (_j_382 > _96){
            goto L3; // [26] 107
        }

        /** 		ob = x[j]*/
        DeRef(_ob_377);
        _2 = (int)SEQ_PTR(_x_374);
        _ob_377 = (int)*(((s1_ptr)_2)->base + _j_382);
        Ref(_ob_377);

        /** 		if not integer(ob) then*/
        if (IS_ATOM_INT(_ob_377))
        _98 = 1;
        else if (IS_ATOM_DBL(_ob_377))
        _98 = IS_ATOM_INT(DoubleToInt(_ob_377));
        else
        _98 = 0;
        if (_98 != 0)
        goto L4; // [44] 54
        _98 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_374);
        DeRef(_ob_377);
        return 0;
L4: 

        /** 		i = ob*/
        Ref(_ob_377);
        _i_376 = _ob_377;
        if (!IS_ATOM_INT(_i_376)) {
            _1 = (long)(DBL_PTR(_i_376)->dbl);
            DeRefDS(_i_376);
            _i_376 = _1;
        }

        /** 		if i < 0 then*/
        if (_i_376 >= 0)
        goto L5; // [63] 74

        /** 			return 0*/
        DeRef(_x_374);
        DeRef(_ob_377);
        return 0;
L5: 

        /** 		if i > 255 then*/
        if (_i_376 <= 255)
        goto L6; // [76] 87

        /** 			return 0*/
        DeRef(_x_374);
        DeRef(_ob_377);
        return 0;
L6: 

        /** 		if flag = 0 then*/
        if (_flag_375 != 0)
        goto L7; // [89] 100

        /** 			flag = (i = 0)*/
        _flag_375 = (_i_376 == 0);
L7: 

        /** 	end for*/
        _j_382 = _j_382 + 1;
        goto L2; // [102] 33
L3: 
        ;
    }

    /** 	return 1 + flag*/
    _105 = _flag_375 + 1;
    if (_105 > MAXINT){
        _105 = NewDouble((double)_105);
    }
    DeRef(_x_374);
    DeRef(_ob_377);
    return _105;
    ;
}


int _3myarray(int _x_399)
{
    int _flag_400 = NOVALUE;
    int _i_401 = NOVALUE;
    int _ob_402 = NOVALUE;
    int _113 = NOVALUE;
    int _110 = NOVALUE;
    int _108 = NOVALUE;
    int _106 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _106 = IS_SEQUENCE(_x_399);
    if (_106 != 0)
    goto L1; // [6] 16
    _106 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_399);
    DeRef(_i_401);
    DeRef(_ob_402);
    return 0;
L1: 

    /** 	flag = 1*/
    _flag_400 = 1;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_399)){
            _108 = SEQ_PTR(_x_399)->length;
    }
    else {
        _108 = 1;
    }
    {
        int _j_407;
        _j_407 = 1;
L2: 
        if (_j_407 > _108){
            goto L3; // [26] 152
        }

        /** 		ob = x[j]*/
        DeRef(_ob_402);
        _2 = (int)SEQ_PTR(_x_399);
        _ob_402 = (int)*(((s1_ptr)_2)->base + _j_407);
        Ref(_ob_402);

        /** 		if not atom(ob) then*/
        _110 = IS_ATOM(_ob_402);
        if (_110 != 0)
        goto L4; // [44] 54
        _110 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_399);
        DeRef(_i_401);
        DeRef(_ob_402);
        return 0;
L4: 

        /** 		if flag <= 2 then*/
        if (_flag_400 > 2)
        goto L5; // [56] 145

        /** 			i = ob*/
        Ref(_ob_402);
        DeRef(_i_401);
        _i_401 = _ob_402;

        /** 			if floor(i) != i then*/
        if (IS_ATOM_INT(_i_401))
        _113 = e_floor(_i_401);
        else
        _113 = unary_op(FLOOR, _i_401);
        if (binary_op_a(EQUALS, _113, _i_401)){
            DeRef(_113);
            _113 = NOVALUE;
            goto L6; // [70] 82
        }
        DeRef(_113);
        _113 = NOVALUE;

        /** 				flag = 3 -- for double*/
        _flag_400 = 3;
        goto L7; // [79] 144
L6: 

        /** 			elsif i < (-2147483648) then*/
        if (binary_op_a(GREATEREQ, _i_401, _116)){
            goto L8; // [84] 96
        }

        /** 				flag = 3 -- for double*/
        _flag_400 = 3;
        goto L7; // [93] 144
L8: 

        /** 			elsif i > 4294967295 then*/
        if (binary_op_a(LESSEQ, _i_401, _118)){
            goto L9; // [98] 110
        }

        /** 				flag = 3 -- for double*/
        _flag_400 = 3;
        goto L7; // [107] 144
L9: 

        /** 			elsif flag = 2 then*/
        if (_flag_400 != 2)
        goto LA; // [112] 131

        /** 				if i > 2147483647 then*/
        if (binary_op_a(LESSEQ, _i_401, _121)){
            goto L7; // [118] 144
        }

        /** 					flag = 3 -- for double*/
        _flag_400 = 3;
        goto L7; // [128] 144
LA: 

        /** 			elsif i < 0 then*/
        if (binary_op_a(GREATEREQ, _i_401, 0)){
            goto LB; // [133] 143
        }

        /** 				flag = 2 -- for signed int*/
        _flag_400 = 2;
LB: 
L7: 
L5: 

        /** 	end for*/
        _j_407 = _j_407 + 1;
        goto L2; // [147] 33
L3: 
        ;
    }

    /** 	return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list*/
    DeRef(_x_399);
    DeRef(_i_401);
    DeRef(_ob_402);
    return _flag_400;
    ;
}


int _3sequence_to_linked_list(int _s_451)
{
    int _ma_452 = NOVALUE;
    int _next_453 = NOVALUE;
    int _tmp_454 = NOVALUE;
    int _a_455 = NOVALUE;
    int _i_456 = NOVALUE;
    int _216 = NOVALUE;
    int _215 = NOVALUE;
    int _214 = NOVALUE;
    int _213 = NOVALUE;
    int _211 = NOVALUE;
    int _209 = NOVALUE;
    int _208 = NOVALUE;
    int _206 = NOVALUE;
    int _205 = NOVALUE;
    int _204 = NOVALUE;
    int _203 = NOVALUE;
    int _201 = NOVALUE;
    int _200 = NOVALUE;
    int _198 = NOVALUE;
    int _197 = NOVALUE;
    int _195 = NOVALUE;
    int _194 = NOVALUE;
    int _193 = NOVALUE;
    int _192 = NOVALUE;
    int _191 = NOVALUE;
    int _190 = NOVALUE;
    int _189 = NOVALUE;
    int _187 = NOVALUE;
    int _186 = NOVALUE;
    int _185 = NOVALUE;
    int _183 = NOVALUE;
    int _182 = NOVALUE;
    int _180 = NOVALUE;
    int _179 = NOVALUE;
    int _178 = NOVALUE;
    int _176 = NOVALUE;
    int _175 = NOVALUE;
    int _173 = NOVALUE;
    int _172 = NOVALUE;
    int _171 = NOVALUE;
    int _169 = NOVALUE;
    int _168 = NOVALUE;
    int _165 = NOVALUE;
    int _164 = NOVALUE;
    int _163 = NOVALUE;
    int _161 = NOVALUE;
    int _160 = NOVALUE;
    int _159 = NOVALUE;
    int _157 = NOVALUE;
    int _153 = NOVALUE;
    int _151 = NOVALUE;
    int _150 = NOVALUE;
    int _149 = NOVALUE;
    int _147 = NOVALUE;
    int _146 = NOVALUE;
    int _144 = NOVALUE;
    int _143 = NOVALUE;
    int _142 = NOVALUE;
    int _141 = NOVALUE;
    int _140 = NOVALUE;
    int _139 = NOVALUE;
    int _138 = NOVALUE;
    int _137 = NOVALUE;
    int _135 = NOVALUE;
    int _134 = NOVALUE;
    int _133 = NOVALUE;
    int _131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = allocate(SIZE_OF_STRUCT)*/
    _0 = _ma_452;
    _ma_452 = _2allocate(16);
    DeRef(_0);

    /** 	if integer(s) then -- most of the time it will be an integer(a)*/
    if (IS_ATOM_INT(_s_451))
    _131 = 1;
    else if (IS_ATOM_DBL(_s_451))
    _131 = IS_ATOM_INT(DoubleToInt(_s_451));
    else
    _131 = 0;
    if (_131 == 0)
    {
        _131 = NOVALUE;
        goto L1; // [12] 54
    }
    else{
        _131 = NOVALUE;
    }

    /** 		i = s*/
    Ref(_s_451);
    _i_456 = _s_451;
    if (!IS_ATOM_INT(_i_456)) {
        _1 = (long)(DBL_PTR(_i_456)->dbl);
        DeRefDS(_i_456);
        _i_456 = _1;
    }

    /** 		if i >= 0 then*/
    if (_i_456 < 0)
    goto L2; // [24] 36

    /** 			poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3UINT_FLAG_443)->dbl;
    goto L3; // [33] 42
L2: 

    /** 			poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3INT_FLAG_441)->dbl;
L3: 

    /** 		poke4(ma + 4, i)*/
    if (IS_ATOM_INT(_ma_452)) {
        _133 = _ma_452 + 4;
        if ((long)((unsigned long)_133 + (unsigned long)HIGH_BITS) >= 0) 
        _133 = NewDouble((double)_133);
    }
    else {
        _133 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_133)){
        poke4_addr = (unsigned long *)_133;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_133)->dbl);
    }
    *poke4_addr = (unsigned long)_i_456;
    DeRef(_133);
    _133 = NOVALUE;
    goto L4; // [51] 695
L1: 

    /** 	elsif atom(s) then*/
    _134 = IS_ATOM(_s_451);
    if (_134 == 0)
    {
        _134 = NOVALUE;
        goto L5; // [59] 212
    }
    else{
        _134 = NOVALUE;
    }

    /** 		a = s*/
    Ref(_s_451);
    DeRef(_a_455);
    _a_455 = _s_451;

    /** 		if a = floor(a) then*/
    if (IS_ATOM_INT(_a_455))
    _135 = e_floor(_a_455);
    else
    _135 = unary_op(FLOOR, _a_455);
    if (binary_op_a(NOTEQ, _a_455, _135)){
        DeRef(_135);
        _135 = NOVALUE;
        goto L6; // [72] 179
    }
    DeRef(_135);
    _135 = NOVALUE;

    /** 			if a <= #FFFFFFFF and a >= 0 then*/
    if (IS_ATOM_INT(_a_455)) {
        _137 = ((double)_a_455 <= DBL_PTR(_118)->dbl);
    }
    else {
        _137 = (DBL_PTR(_a_455)->dbl <= DBL_PTR(_118)->dbl);
    }
    if (_137 == 0) {
        goto L7; // [82] 111
    }
    if (IS_ATOM_INT(_a_455)) {
        _139 = (_a_455 >= 0);
    }
    else {
        _139 = (DBL_PTR(_a_455)->dbl >= (double)0);
    }
    if (_139 == 0)
    {
        DeRef(_139);
        _139 = NOVALUE;
        goto L7; // [91] 111
    }
    else{
        DeRef(_139);
        _139 = NOVALUE;
    }

    /** 				poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3UINT_FLAG_443)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_452)) {
        _140 = _ma_452 + 4;
        if ((long)((unsigned long)_140 + (unsigned long)HIGH_BITS) >= 0) 
        _140 = NewDouble((double)_140);
    }
    else {
        _140 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_140)){
        poke4_addr = (unsigned long *)_140;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_140)->dbl);
    }
    if (IS_ATOM_INT(_a_455)) {
        *poke4_addr = (unsigned long)_a_455;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_455)->dbl;
    }
    DeRef(_140);
    _140 = NOVALUE;
    goto L4; // [108] 695
L7: 

    /** 			elsif a <= 2147483647 and a >= -2147483648 then*/
    if (IS_ATOM_INT(_a_455)) {
        _141 = ((double)_a_455 <= DBL_PTR(_121)->dbl);
    }
    else {
        _141 = (DBL_PTR(_a_455)->dbl <= DBL_PTR(_121)->dbl);
    }
    if (_141 == 0) {
        goto L8; // [117] 146
    }
    if (IS_ATOM_INT(_a_455)) {
        _143 = ((double)_a_455 >= DBL_PTR(_116)->dbl);
    }
    else {
        _143 = (DBL_PTR(_a_455)->dbl >= DBL_PTR(_116)->dbl);
    }
    if (_143 == 0)
    {
        DeRef(_143);
        _143 = NOVALUE;
        goto L8; // [126] 146
    }
    else{
        DeRef(_143);
        _143 = NOVALUE;
    }

    /** 				poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3INT_FLAG_441)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_452)) {
        _144 = _ma_452 + 4;
        if ((long)((unsigned long)_144 + (unsigned long)HIGH_BITS) >= 0) 
        _144 = NewDouble((double)_144);
    }
    else {
        _144 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_144)){
        poke4_addr = (unsigned long *)_144;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_144)->dbl);
    }
    if (IS_ATOM_INT(_a_455)) {
        *poke4_addr = (unsigned long)_a_455;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_455)->dbl;
    }
    DeRef(_144);
    _144 = NOVALUE;
    goto L4; // [143] 695
L8: 

    /** 				tmp = allocate(8)*/
    _0 = _tmp_454;
    _tmp_454 = _2allocate(8);
    DeRef(_0);

    /** 				poke(tmp, atom_to_float64(a))*/
    Ref(_a_455);
    _146 = _2atom_to_float64(_a_455);
    if (IS_ATOM_INT(_tmp_454)){
        poke_addr = (unsigned char *)_tmp_454;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
    }
    if (IS_ATOM_INT(_146)) {
        *poke_addr = (unsigned char)_146;
    }
    else if (IS_ATOM(_146)) {
        *poke_addr = (signed char)DBL_PTR(_146)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_146);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_146);
    _146 = NOVALUE;

    /** 				poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3DOUBLE_FLAG_439)->dbl;

    /** 				poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _147 = _ma_452 + 4;
        if ((long)((unsigned long)_147 + (unsigned long)HIGH_BITS) >= 0) 
        _147 = NewDouble((double)_147);
    }
    else {
        _147 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_147)){
        poke4_addr = (unsigned long *)_147;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_147)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_147);
    _147 = NOVALUE;
    goto L4; // [176] 695
L6: 

    /** 			tmp = allocate(8)*/
    _0 = _tmp_454;
    _tmp_454 = _2allocate(8);
    DeRef(_0);

    /** 			poke(tmp, atom_to_float64(a))*/
    Ref(_a_455);
    _149 = _2atom_to_float64(_a_455);
    if (IS_ATOM_INT(_tmp_454)){
        poke_addr = (unsigned char *)_tmp_454;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
    }
    if (IS_ATOM_INT(_149)) {
        *poke_addr = (unsigned char)_149;
    }
    else if (IS_ATOM(_149)) {
        *poke_addr = (signed char)DBL_PTR(_149)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_149);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_149);
    _149 = NOVALUE;

    /** 			poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3DOUBLE_FLAG_439)->dbl;

    /** 			poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _150 = _ma_452 + 4;
        if ((long)((unsigned long)_150 + (unsigned long)HIGH_BITS) >= 0) 
        _150 = NewDouble((double)_150);
    }
    else {
        _150 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_150)){
        poke4_addr = (unsigned long *)_150;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_150)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_150);
    _150 = NOVALUE;
    goto L4; // [209] 695
L5: 

    /** 	elsif length(s) = 0 then*/
    if (IS_SEQUENCE(_s_451)){
            _151 = SEQ_PTR(_s_451)->length;
    }
    else {
        _151 = 1;
    }
    if (_151 != 0)
    goto L9; // [217] 233

    /** 		poke4(ma, {NULL,NULL})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _153 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    _1 = (int)SEQ_PTR(_153);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_153);
    _153 = NOVALUE;
    goto L4; // [230] 695
L9: 

    /** 		if not always_linked_list then*/
    if (_3always_linked_list_366 != 0)
    goto LA; // [237] 548

    /** 			i = mystring(s)*/
    Ref(_s_451);
    _i_456 = _3mystring(_s_451);
    if (!IS_ATOM_INT(_i_456)) {
        _1 = (long)(DBL_PTR(_i_456)->dbl);
        DeRefDS(_i_456);
        _i_456 = _1;
    }

    /** 			if i then -- string*/
    if (_i_456 == 0)
    {
        goto LB; // [250] 338
    }
    else{
    }

    /** 				if i = 2 then*/
    if (_i_456 != 2)
    goto LC; // [255] 297

    /** 					tmp = allocate(length(s))*/
    if (IS_SEQUENCE(_s_451)){
            _157 = SEQ_PTR(_s_451)->length;
    }
    else {
        _157 = 1;
    }
    _0 = _tmp_454;
    _tmp_454 = _2allocate(_157);
    DeRef(_0);
    _157 = NOVALUE;

    /** 					poke(tmp, s)*/
    if (IS_ATOM_INT(_tmp_454)){
        poke_addr = (unsigned char *)_tmp_454;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
    }
    if (IS_ATOM_INT(_s_451)) {
        *poke_addr = (unsigned char)_s_451;
    }
    else if (IS_ATOM(_s_451)) {
        *poke_addr = (signed char)DBL_PTR(_s_451)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_451);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH*/
    if (IS_SEQUENCE(_s_451)){
            _159 = SEQ_PTR(_s_451)->length;
    }
    else {
        _159 = 1;
    }
    temp_d.dbl = (double)_159;
    _160 = Dor_bits(DBL_PTR(_3CBYTES_448), &temp_d);
    _159 = NOVALUE;
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    if (IS_ATOM_INT(_160)) {
        *poke4_addr = (unsigned long)_160;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_160)->dbl;
    }
    DeRef(_160);
    _160 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _161 = _ma_452 + 4;
        if ((long)((unsigned long)_161 + (unsigned long)HIGH_BITS) >= 0) 
        _161 = NewDouble((double)_161);
    }
    else {
        _161 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_161)){
        poke4_addr = (unsigned long *)_161;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_161)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_161);
    _161 = NOVALUE;
    goto LD; // [294] 318
LC: 

    /** 					tmp = allocate_string(s)*/
    Ref(_s_451);
    _0 = _tmp_454;
    _tmp_454 = _2allocate_string(_s_451);
    DeRef(_0);

    /** 					poke4(ma, CSTRING) -- why?*/
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_3CSTRING_447)->dbl;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _163 = _ma_452 + 4;
        if ((long)((unsigned long)_163 + (unsigned long)HIGH_BITS) >= 0) 
        _163 = NewDouble((double)_163);
    }
    else {
        _163 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_163)){
        poke4_addr = (unsigned long *)_163;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_163)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_163);
    _163 = NOVALUE;
LD: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_452)) {
        _164 = _ma_452 + 8;
        if ((long)((unsigned long)_164 + (unsigned long)HIGH_BITS) >= 0) 
        _164 = NewDouble((double)_164);
    }
    else {
        _164 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _165 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_164)){
        poke4_addr = (unsigned long *)_164;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_164)->dbl);
    }
    _1 = (int)SEQ_PTR(_165);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_164);
    _164 = NOVALUE;
    DeRefDS(_165);
    _165 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_451);
    DeRef(_next_453);
    DeRef(_tmp_454);
    DeRef(_a_455);
    DeRef(_137);
    _137 = NOVALUE;
    DeRef(_141);
    _141 = NOVALUE;
    return _ma_452;
LB: 

    /** 			i = myarray(s)*/
    Ref(_s_451);
    _i_456 = _3myarray(_s_451);
    if (!IS_ATOM_INT(_i_456)) {
        _1 = (long)(DBL_PTR(_i_456)->dbl);
        DeRefDS(_i_456);
        _i_456 = _1;
    }

    /** 			if i then*/
    if (_i_456 == 0)
    {
        goto LE; // [348] 547
    }
    else{
    }

    /** 				if i = 1 then*/
    if (_i_456 != 1)
    goto LF; // [353] 399

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_451)){
            _168 = SEQ_PTR(_s_451)->length;
    }
    else {
        _168 = 1;
    }
    if (_168 == (short)_168)
    _169 = _168 * 4;
    else
    _169 = NewDouble(_168 * (double)4);
    _168 = NOVALUE;
    _0 = _tmp_454;
    _tmp_454 = _2allocate(_169);
    DeRef(_0);
    _169 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_454)){
        poke4_addr = (unsigned long *)_tmp_454;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
    }
    if (IS_ATOM_INT(_s_451)) {
        *poke4_addr = (unsigned long)_s_451;
    }
    else if (IS_ATOM(_s_451)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_451)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_451);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(UINT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_451)){
            _171 = SEQ_PTR(_s_451)->length;
    }
    else {
        _171 = 1;
    }
    temp_d.dbl = (double)_171;
    _172 = Dor_bits(DBL_PTR(_3UINT_FLAG_443), &temp_d);
    _171 = NOVALUE;
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    if (IS_ATOM_INT(_172)) {
        *poke4_addr = (unsigned long)_172;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_172)->dbl;
    }
    DeRef(_172);
    _172 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _173 = _ma_452 + 4;
        if ((long)((unsigned long)_173 + (unsigned long)HIGH_BITS) >= 0) 
        _173 = NewDouble((double)_173);
    }
    else {
        _173 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_173)){
        poke4_addr = (unsigned long *)_173;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_173)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_173);
    _173 = NOVALUE;
    goto L10; // [396] 527
LF: 

    /** 				elsif i = 2 then*/
    if (_i_456 != 2)
    goto L11; // [401] 447

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_451)){
            _175 = SEQ_PTR(_s_451)->length;
    }
    else {
        _175 = 1;
    }
    if (_175 == (short)_175)
    _176 = _175 * 4;
    else
    _176 = NewDouble(_175 * (double)4);
    _175 = NOVALUE;
    _0 = _tmp_454;
    _tmp_454 = _2allocate(_176);
    DeRef(_0);
    _176 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_454)){
        poke4_addr = (unsigned long *)_tmp_454;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
    }
    if (IS_ATOM_INT(_s_451)) {
        *poke4_addr = (unsigned long)_s_451;
    }
    else if (IS_ATOM(_s_451)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_451)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_451);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(INT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_451)){
            _178 = SEQ_PTR(_s_451)->length;
    }
    else {
        _178 = 1;
    }
    temp_d.dbl = (double)_178;
    _179 = Dor_bits(DBL_PTR(_3INT_FLAG_441), &temp_d);
    _178 = NOVALUE;
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    if (IS_ATOM_INT(_179)) {
        *poke4_addr = (unsigned long)_179;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_179)->dbl;
    }
    DeRef(_179);
    _179 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _180 = _ma_452 + 4;
        if ((long)((unsigned long)_180 + (unsigned long)HIGH_BITS) >= 0) 
        _180 = NewDouble((double)_180);
    }
    else {
        _180 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_180)){
        poke4_addr = (unsigned long *)_180;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_180)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_180);
    _180 = NOVALUE;
    goto L10; // [444] 527
L11: 

    /** 				elsif i = 3 then*/
    if (_i_456 != 3)
    goto L12; // [449] 526

    /** 					tmp = allocate(length(s) * 8)*/
    if (IS_SEQUENCE(_s_451)){
            _182 = SEQ_PTR(_s_451)->length;
    }
    else {
        _182 = 1;
    }
    if (_182 == (short)_182)
    _183 = _182 * 8;
    else
    _183 = NewDouble(_182 * (double)8);
    _182 = NOVALUE;
    _0 = _tmp_454;
    _tmp_454 = _2allocate(_183);
    DeRef(_0);
    _183 = NOVALUE;

    /** 					for j = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_451)){
            _185 = SEQ_PTR(_s_451)->length;
    }
    else {
        _185 = 1;
    }
    {
        int _j_542;
        _j_542 = 1;
L13: 
        if (_j_542 > _185){
            goto L14; // [471] 504
        }

        /** 						poke(tmp, atom_to_float64(s[j]))*/
        _2 = (int)SEQ_PTR(_s_451);
        _186 = (int)*(((s1_ptr)_2)->base + _j_542);
        Ref(_186);
        _187 = _2atom_to_float64(_186);
        _186 = NOVALUE;
        if (IS_ATOM_INT(_tmp_454)){
            poke_addr = (unsigned char *)_tmp_454;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_454)->dbl);
        }
        if (IS_ATOM_INT(_187)) {
            *poke_addr = (unsigned char)_187;
        }
        else if (IS_ATOM(_187)) {
            *poke_addr = (signed char)DBL_PTR(_187)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_187);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
                }
            }
        }
        DeRef(_187);
        _187 = NOVALUE;

        /** 						tmp += 8*/
        _0 = _tmp_454;
        if (IS_ATOM_INT(_tmp_454)) {
            _tmp_454 = _tmp_454 + 8;
            if ((long)((unsigned long)_tmp_454 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_454 = NewDouble((double)_tmp_454);
        }
        else {
            _tmp_454 = NewDouble(DBL_PTR(_tmp_454)->dbl + (double)8);
        }
        DeRef(_0);

        /** 					end for*/
        _j_542 = _j_542 + 1;
        goto L13; // [499] 478
L14: 
        ;
    }

    /** 					poke4(ma, or_bits(DOUBLE_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_451)){
            _189 = SEQ_PTR(_s_451)->length;
    }
    else {
        _189 = 1;
    }
    temp_d.dbl = (double)_189;
    _190 = Dor_bits(DBL_PTR(_3DOUBLE_FLAG_439), &temp_d);
    _189 = NOVALUE;
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    if (IS_ATOM_INT(_190)) {
        *poke4_addr = (unsigned long)_190;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_190)->dbl;
    }
    DeRef(_190);
    _190 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_452)) {
        _191 = _ma_452 + 4;
        if ((long)((unsigned long)_191 + (unsigned long)HIGH_BITS) >= 0) 
        _191 = NewDouble((double)_191);
    }
    else {
        _191 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_191)){
        poke4_addr = (unsigned long *)_191;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_191)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_191);
    _191 = NOVALUE;
L12: 
L10: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_452)) {
        _192 = _ma_452 + 8;
        if ((long)((unsigned long)_192 + (unsigned long)HIGH_BITS) >= 0) 
        _192 = NewDouble((double)_192);
    }
    else {
        _192 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _193 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_192)){
        poke4_addr = (unsigned long *)_192;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_192)->dbl);
    }
    _1 = (int)SEQ_PTR(_193);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_192);
    _192 = NOVALUE;
    DeRefDS(_193);
    _193 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_451);
    DeRef(_next_453);
    DeRef(_tmp_454);
    DeRef(_a_455);
    DeRef(_137);
    _137 = NOVALUE;
    DeRef(_141);
    _141 = NOVALUE;
    return _ma_452;
LE: 
LA: 

    /** 		next = NULL -- 0*/
    DeRef(_next_453);
    _next_453 = 0;

    /** 		poke4(ma, length(s))*/
    if (IS_SEQUENCE(_s_451)){
            _194 = SEQ_PTR(_s_451)->length;
    }
    else {
        _194 = 1;
    }
    if (IS_ATOM_INT(_ma_452)){
        poke4_addr = (unsigned long *)_ma_452;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_452)->dbl);
    }
    *poke4_addr = (unsigned long)_194;
    _194 = NOVALUE;

    /** 		if length(s) then*/
    if (IS_SEQUENCE(_s_451)){
            _195 = SEQ_PTR(_s_451)->length;
    }
    else {
        _195 = 1;
    }
    if (_195 == 0)
    {
        _195 = NOVALUE;
        goto L15; // [566] 678
    }
    else{
        _195 = NOVALUE;
    }

    /** 			a = allocate(8) -- iterators to beginning and end of list*/
    _0 = _a_455;
    _a_455 = _2allocate(8);
    DeRef(_0);

    /** 			next = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_451)){
            _197 = SEQ_PTR(_s_451)->length;
    }
    else {
        _197 = 1;
    }
    _2 = (int)SEQ_PTR(_s_451);
    _198 = (int)*(((s1_ptr)_2)->base + _197);
    Ref(_198);
    _next_453 = _3sequence_to_linked_list(_198);
    _198 = NOVALUE;

    /** 			s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_451)){
            _200 = SEQ_PTR(_s_451)->length;
    }
    else {
        _200 = 1;
    }
    _201 = _200 - 1;
    _200 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_451;
    RHS_Slice(_s_451, 1, _201);

    /** 			poke4(a + 4, next) -- store the end iterator*/
    if (IS_ATOM_INT(_a_455)) {
        _203 = _a_455 + 4;
        if ((long)((unsigned long)_203 + (unsigned long)HIGH_BITS) >= 0) 
        _203 = NewDouble((double)_203);
    }
    else {
        _203 = NewDouble(DBL_PTR(_a_455)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_203)){
        poke4_addr = (unsigned long *)_203;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_203)->dbl);
    }
    if (IS_ATOM_INT(_next_453)) {
        *poke4_addr = (unsigned long)_next_453;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_453)->dbl;
    }
    DeRef(_203);
    _203 = NOVALUE;

    /** 			while length(s) do*/
L16: 
    if (IS_SEQUENCE(_s_451)){
            _204 = SEQ_PTR(_s_451)->length;
    }
    else {
        _204 = 1;
    }
    if (_204 == 0)
    {
        _204 = NOVALUE;
        goto L17; // [619] 677
    }
    else{
        _204 = NOVALUE;
    }

    /** 				tmp = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_451)){
            _205 = SEQ_PTR(_s_451)->length;
    }
    else {
        _205 = 1;
    }
    _2 = (int)SEQ_PTR(_s_451);
    _206 = (int)*(((s1_ptr)_2)->base + _205);
    Ref(_206);
    _0 = _tmp_454;
    _tmp_454 = _3sequence_to_linked_list(_206);
    DeRef(_0);
    _206 = NOVALUE;

    /** 				s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_451)){
            _208 = SEQ_PTR(_s_451)->length;
    }
    else {
        _208 = 1;
    }
    _209 = _208 - 1;
    _208 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_451;
    RHS_Slice(_s_451, 1, _209);

    /** 				poke4(next + 8, tmp)*/
    if (IS_ATOM_INT(_next_453)) {
        _211 = _next_453 + 8;
        if ((long)((unsigned long)_211 + (unsigned long)HIGH_BITS) >= 0) 
        _211 = NewDouble((double)_211);
    }
    else {
        _211 = NewDouble(DBL_PTR(_next_453)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_211)){
        poke4_addr = (unsigned long *)_211;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_211)->dbl);
    }
    if (IS_ATOM_INT(_tmp_454)) {
        *poke4_addr = (unsigned long)_tmp_454;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_454)->dbl;
    }
    DeRef(_211);
    _211 = NOVALUE;

    /** 				poke4(tmp + 12, next)*/
    if (IS_ATOM_INT(_tmp_454)) {
        _213 = _tmp_454 + 12;
        if ((long)((unsigned long)_213 + (unsigned long)HIGH_BITS) >= 0) 
        _213 = NewDouble((double)_213);
    }
    else {
        _213 = NewDouble(DBL_PTR(_tmp_454)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_213)){
        poke4_addr = (unsigned long *)_213;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_213)->dbl);
    }
    if (IS_ATOM_INT(_next_453)) {
        *poke4_addr = (unsigned long)_next_453;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_453)->dbl;
    }
    DeRef(_213);
    _213 = NOVALUE;

    /** 				next = tmp*/
    Ref(_tmp_454);
    DeRef(_next_453);
    _next_453 = _tmp_454;

    /** 			end while*/
    goto L16; // [674] 616
L17: 
L15: 

    /** 		poke4(a, next) -- store the beginning iterator*/
    if (IS_ATOM_INT(_a_455)){
        poke4_addr = (unsigned long *)_a_455;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_a_455)->dbl);
    }
    if (IS_ATOM_INT(_next_453)) {
        *poke4_addr = (unsigned long)_next_453;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_453)->dbl;
    }

    /** 		poke4(ma + 4, a) -- point data to the iterators*/
    if (IS_ATOM_INT(_ma_452)) {
        _214 = _ma_452 + 4;
        if ((long)((unsigned long)_214 + (unsigned long)HIGH_BITS) >= 0) 
        _214 = NewDouble((double)_214);
    }
    else {
        _214 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_214)){
        poke4_addr = (unsigned long *)_214;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_214)->dbl);
    }
    if (IS_ATOM_INT(_a_455)) {
        *poke4_addr = (unsigned long)_a_455;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_455)->dbl;
    }
    DeRef(_214);
    _214 = NOVALUE;
L4: 

    /** 	poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_452)) {
        _215 = _ma_452 + 8;
        if ((long)((unsigned long)_215 + (unsigned long)HIGH_BITS) >= 0) 
        _215 = NewDouble((double)_215);
    }
    else {
        _215 = NewDouble(DBL_PTR(_ma_452)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _216 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_215)){
        poke4_addr = (unsigned long *)_215;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_215)->dbl);
    }
    _1 = (int)SEQ_PTR(_216);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_215);
    _215 = NOVALUE;
    DeRefDS(_216);
    _216 = NOVALUE;

    /** 	return ma*/
    DeRef(_s_451);
    DeRef(_next_453);
    DeRef(_tmp_454);
    DeRef(_a_455);
    DeRef(_137);
    _137 = NOVALUE;
    DeRef(_141);
    _141 = NOVALUE;
    DeRef(_201);
    _201 = NOVALUE;
    DeRef(_209);
    _209 = NOVALUE;
    return _ma_452;
    ;
}


void _3free_linked_list(int _ma_581)
{
    int _len_582 = NOVALUE;
    int _tmp_583 = NOVALUE;
    int _next_584 = NOVALUE;
    int _ptr_585 = NOVALUE;
    int _228 = NOVALUE;
    int _226 = NOVALUE;
    int _225 = NOVALUE;
    int _221 = NOVALUE;
    int _220 = NOVALUE;
    int _218 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_582);
    if (IS_ATOM_INT(_ma_581)) {
        _len_582 = *(unsigned long *)_ma_581;
        if ((unsigned)_len_582 > (unsigned)MAXINT)
        _len_582 = NewDouble((double)(unsigned long)_len_582);
    }
    else {
        _len_582 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_581)->dbl);
        if ((unsigned)_len_582 > (unsigned)MAXINT)
        _len_582 = NewDouble((double)(unsigned long)_len_582);
    }

    /** 	ptr = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_581)) {
        _218 = _ma_581 + 4;
        if ((long)((unsigned long)_218 + (unsigned long)HIGH_BITS) >= 0) 
        _218 = NewDouble((double)_218);
    }
    else {
        _218 = NewDouble(DBL_PTR(_ma_581)->dbl + (double)4);
    }
    DeRef(_ptr_585);
    if (IS_ATOM_INT(_218)) {
        _ptr_585 = *(unsigned long *)_218;
        if ((unsigned)_ptr_585 > (unsigned)MAXINT)
        _ptr_585 = NewDouble((double)(unsigned long)_ptr_585);
    }
    else {
        _ptr_585 = *(unsigned long *)(unsigned long)(DBL_PTR(_218)->dbl);
        if ((unsigned)_ptr_585 > (unsigned)MAXINT)
        _ptr_585 = NewDouble((double)(unsigned long)_ptr_585);
    }
    DeRef(_218);
    _218 = NOVALUE;

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_582)) {
        temp_d.dbl = (double)_len_582;
        _220 = Dand_bits(&temp_d, DBL_PTR(_3SIGN_FLAG_438));
    }
    else {
        _220 = Dand_bits(DBL_PTR(_len_582), DBL_PTR(_3SIGN_FLAG_438));
    }
    if (_220 == 0) {
        DeRef(_220);
        _220 = NOVALUE;
        goto L1; // [21] 57
    }
    else {
        if (!IS_ATOM_INT(_220) && DBL_PTR(_220)->dbl == 0.0){
            DeRef(_220);
            _220 = NOVALUE;
            goto L1; // [21] 57
        }
        DeRef(_220);
        _220 = NOVALUE;
    }
    DeRef(_220);
    _220 = NOVALUE;

    /** 	 	if and_bits(len, MAX_LENGTH) then*/
    if (IS_ATOM_INT(_len_582)) {
        {unsigned long tu;
             tu = (unsigned long)_len_582 & (unsigned long)268435455;
             _221 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _221 = Dand_bits(DBL_PTR(_len_582), &temp_d);
    }
    if (_221 == 0) {
        DeRef(_221);
        _221 = NOVALUE;
        goto L2; // [30] 41
    }
    else {
        if (!IS_ATOM_INT(_221) && DBL_PTR(_221)->dbl == 0.0){
            DeRef(_221);
            _221 = NOVALUE;
            goto L2; // [30] 41
        }
        DeRef(_221);
        _221 = NOVALUE;
    }
    DeRef(_221);
    _221 = NOVALUE;

    /** 			free(ptr)*/
    Ref(_ptr_585);
    _2free(_ptr_585);
    goto L3; // [38] 116
L2: 

    /** 		elsif len = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _len_582, _3DOUBLE_FLAG_439)){
        goto L3; // [43] 116
    }

    /** 			free(ptr)*/
    Ref(_ptr_585);
    _2free(_ptr_585);
    goto L3; // [54] 116
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_582, 0)){
        goto L4; // [59] 115
    }

    /** 		tmp = peek4u(ptr) -- iterator to the beginning of the list*/
    DeRef(_tmp_583);
    if (IS_ATOM_INT(_ptr_585)) {
        _tmp_583 = *(unsigned long *)_ptr_585;
        if ((unsigned)_tmp_583 > (unsigned)MAXINT)
        _tmp_583 = NewDouble((double)(unsigned long)_tmp_583);
    }
    else {
        _tmp_583 = *(unsigned long *)(unsigned long)(DBL_PTR(_ptr_585)->dbl);
        if ((unsigned)_tmp_583 > (unsigned)MAXINT)
        _tmp_583 = NewDouble((double)(unsigned long)_tmp_583);
    }

    /** 		free(ptr) -- free the iterators*/
    Ref(_ptr_585);
    _2free(_ptr_585);

    /** 		for i = 1 to len do*/
    Ref(_len_582);
    DeRef(_225);
    _225 = _len_582;
    {
        int _i_602;
        _i_602 = 1;
L5: 
        if (binary_op_a(GREATER, _i_602, _225)){
            goto L6; // [78] 114
        }

        /** 			next = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_583)) {
            _226 = _tmp_583 + 12;
            if ((long)((unsigned long)_226 + (unsigned long)HIGH_BITS) >= 0) 
            _226 = NewDouble((double)_226);
        }
        else {
            _226 = NewDouble(DBL_PTR(_tmp_583)->dbl + (double)12);
        }
        DeRef(_next_584);
        if (IS_ATOM_INT(_226)) {
            _next_584 = *(unsigned long *)_226;
            if ((unsigned)_next_584 > (unsigned)MAXINT)
            _next_584 = NewDouble((double)(unsigned long)_next_584);
        }
        else {
            _next_584 = *(unsigned long *)(unsigned long)(DBL_PTR(_226)->dbl);
            if ((unsigned)_next_584 > (unsigned)MAXINT)
            _next_584 = NewDouble((double)(unsigned long)_next_584);
        }
        DeRef(_226);
        _226 = NOVALUE;

        /** 			free_linked_list(tmp)*/
        Ref(_tmp_583);
        DeRef(_228);
        _228 = _tmp_583;
        _3free_linked_list(_228);
        _228 = NOVALUE;

        /** 			tmp = next*/
        Ref(_next_584);
        DeRef(_tmp_583);
        _tmp_583 = _next_584;

        /** 		end for*/
        _0 = _i_602;
        if (IS_ATOM_INT(_i_602)) {
            _i_602 = _i_602 + 1;
            if ((long)((unsigned long)_i_602 +(unsigned long) HIGH_BITS) >= 0){
                _i_602 = NewDouble((double)_i_602);
            }
        }
        else {
            _i_602 = binary_op_a(PLUS, _i_602, 1);
        }
        DeRef(_0);
        goto L5; // [109] 85
L6: 
        ;
        DeRef(_i_602);
    }
L4: 
L3: 

    /** 	free(ma)*/
    Ref(_ma_581);
    _2free(_ma_581);

    /** end procedure*/
    DeRef(_ma_581);
    DeRef(_len_582);
    DeRef(_tmp_583);
    DeRef(_next_584);
    DeRef(_ptr_585);
    return;
    ;
}


int _3linked_list_to_sequence(int _ma_610)
{
    int _len_611 = NOVALUE;
    int _tmp_612 = NOVALUE;
    int _val_613 = NOVALUE;
    int _s_614 = NOVALUE;
    int _287 = NOVALUE;
    int _286 = NOVALUE;
    int _284 = NOVALUE;
    int _283 = NOVALUE;
    int _282 = NOVALUE;
    int _281 = NOVALUE;
    int _277 = NOVALUE;
    int _274 = NOVALUE;
    int _272 = NOVALUE;
    int _271 = NOVALUE;
    int _269 = NOVALUE;
    int _268 = NOVALUE;
    int _267 = NOVALUE;
    int _266 = NOVALUE;
    int _262 = NOVALUE;
    int _260 = NOVALUE;
    int _259 = NOVALUE;
    int _258 = NOVALUE;
    int _256 = NOVALUE;
    int _255 = NOVALUE;
    int _254 = NOVALUE;
    int _253 = NOVALUE;
    int _250 = NOVALUE;
    int _247 = NOVALUE;
    int _245 = NOVALUE;
    int _244 = NOVALUE;
    int _241 = NOVALUE;
    int _239 = NOVALUE;
    int _238 = NOVALUE;
    int _232 = NOVALUE;
    int _230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_611);
    if (IS_ATOM_INT(_ma_610)) {
        _len_611 = *(unsigned long *)_ma_610;
        if ((unsigned)_len_611 > (unsigned)MAXINT)
        _len_611 = NewDouble((double)(unsigned long)_len_611);
    }
    else {
        _len_611 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_610)->dbl);
        if ((unsigned)_len_611 > (unsigned)MAXINT)
        _len_611 = NewDouble((double)(unsigned long)_len_611);
    }

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_611)) {
        temp_d.dbl = (double)_len_611;
        _230 = Dand_bits(&temp_d, DBL_PTR(_3SIGN_FLAG_438));
    }
    else {
        _230 = Dand_bits(DBL_PTR(_len_611), DBL_PTR(_3SIGN_FLAG_438));
    }
    if (_230 == 0) {
        DeRef(_230);
        _230 = NOVALUE;
        goto L1; // [12] 380
    }
    else {
        if (!IS_ATOM_INT(_230) && DBL_PTR(_230)->dbl == 0.0){
            DeRef(_230);
            _230 = NOVALUE;
            goto L1; // [12] 380
        }
        DeRef(_230);
        _230 = NOVALUE;
    }
    DeRef(_230);
    _230 = NOVALUE;

    /** 		if len = CSTRING then*/
    if (binary_op_a(NOTEQ, _len_611, _3CSTRING_447)){
        goto L2; // [17] 44
    }

    /** 			tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _232 = _ma_610 + 4;
        if ((long)((unsigned long)_232 + (unsigned long)HIGH_BITS) >= 0) 
        _232 = NewDouble((double)_232);
    }
    else {
        _232 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_232)) {
        _tmp_612 = *(unsigned long *)_232;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_232)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_232);
    _232 = NOVALUE;

    /** 			s = peek_string(tmp)*/
    DeRef(_s_614);
    if (IS_ATOM_INT(_tmp_612)) {
        _s_614 =  NewString((char *)_tmp_612);
    }
    else {
        _s_614 = NewString((char *)(unsigned long)(DBL_PTR(_tmp_612)->dbl));
    }

    /** 			return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
L2: 

    /** 		val = and_bits(len, SIGN_MASK)*/
    DeRef(_val_613);
    if (IS_ATOM_INT(_len_611)) {
        temp_d.dbl = (double)_len_611;
        _val_613 = Dand_bits(&temp_d, DBL_PTR(_3SIGN_MASK_436));
    }
    else {
        _val_613 = Dand_bits(DBL_PTR(_len_611), DBL_PTR(_3SIGN_MASK_436));
    }

    /** 		len = and_bits(len, MAX_LENGTH)*/
    _0 = _len_611;
    if (IS_ATOM_INT(_len_611)) {
        {unsigned long tu;
             tu = (unsigned long)_len_611 & (unsigned long)268435455;
             _len_611 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _len_611 = Dand_bits(DBL_PTR(_len_611), &temp_d);
    }
    DeRef(_0);

    /** 		if val = UINT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_613, _3UINT_FLAG_443)){
        goto L3; // [58] 108
    }

    /** 			if len then*/
    if (_len_611 == 0) {
        goto L4; // [64] 91
    }
    else {
        if (!IS_ATOM_INT(_len_611) && DBL_PTR(_len_611)->dbl == 0.0){
            goto L4; // [64] 91
        }
    }

    /** 				s = peek4u({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_610)) {
        _238 = _ma_610 + 4;
        if ((long)((unsigned long)_238 + (unsigned long)HIGH_BITS) >= 0) 
        _238 = NewDouble((double)_238);
    }
    else {
        _238 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    Ref(_len_611);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _238;
    ((int *)_2)[2] = _len_611;
    _239 = MAKE_SEQ(_1);
    _238 = NOVALUE;
    DeRef(_s_614);
    _1 = (int)SEQ_PTR(_239);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_614 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_239);
    _239 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto L5; // [88] 107
L4: 

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _241 = _ma_610 + 4;
        if ((long)((unsigned long)_241 + (unsigned long)HIGH_BITS) >= 0) 
        _241 = NewDouble((double)_241);
    }
    else {
        _241 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_241)) {
        _tmp_612 = *(unsigned long *)_241;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_241)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_241);
    _241 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_val_613);
    DeRef(_s_614);
    return _tmp_612;
L5: 
L3: 

    /** 		if val = INT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_613, _3INT_FLAG_441)){
        goto L6; // [110] 160
    }

    /** 			if len then*/
    if (_len_611 == 0) {
        goto L7; // [116] 143
    }
    else {
        if (!IS_ATOM_INT(_len_611) && DBL_PTR(_len_611)->dbl == 0.0){
            goto L7; // [116] 143
        }
    }

    /** 				s = peek4s({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_610)) {
        _244 = _ma_610 + 4;
        if ((long)((unsigned long)_244 + (unsigned long)HIGH_BITS) >= 0) 
        _244 = NewDouble((double)_244);
    }
    else {
        _244 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    Ref(_len_611);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _244;
    ((int *)_2)[2] = _len_611;
    _245 = MAKE_SEQ(_1);
    _244 = NOVALUE;
    DeRef(_s_614);
    _1 = (int)SEQ_PTR(_245);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_614 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
        _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_245);
    _245 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto L8; // [140] 159
L7: 

    /** 				tmp = peek4s(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _247 = _ma_610 + 4;
        if ((long)((unsigned long)_247 + (unsigned long)HIGH_BITS) >= 0) 
        _247 = NewDouble((double)_247);
    }
    else {
        _247 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_247)) {
        _tmp_612 = *(unsigned long *)_247;
        if (_tmp_612 < MININT || _tmp_612 > MAXINT)
        _tmp_612 = NewDouble((double)(long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_247)->dbl);
        if (_tmp_612 < MININT || _tmp_612 > MAXINT)
        _tmp_612 = NewDouble((double)(long)_tmp_612);
    }
    DeRef(_247);
    _247 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_val_613);
    DeRef(_s_614);
    return _tmp_612;
L8: 
L6: 

    /** 		if val = FLOAT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_613, _3FLOAT_FLAG_445)){
        goto L9; // [162] 262
    }

    /** 			if len then*/
    if (_len_611 == 0) {
        goto LA; // [168] 237
    }
    else {
        if (!IS_ATOM_INT(_len_611) && DBL_PTR(_len_611)->dbl == 0.0){
            goto LA; // [168] 237
        }
    }

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _250 = _ma_610 + 4;
        if ((long)((unsigned long)_250 + (unsigned long)HIGH_BITS) >= 0) 
        _250 = NewDouble((double)_250);
    }
    else {
        _250 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_250)) {
        _tmp_612 = *(unsigned long *)_250;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_250)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_250);
    _250 = NOVALUE;

    /** 				s = repeat(0, len)*/
    DeRef(_s_614);
    _s_614 = Repeat(0, _len_611);

    /** 				for i = 1 to len do*/
    Ref(_len_611);
    DeRef(_253);
    _253 = _len_611;
    {
        int _i_650;
        _i_650 = 1;
LB: 
        if (binary_op_a(GREATER, _i_650, _253)){
            goto LC; // [191] 228
        }

        /** 					s[i] = float32_to_atom(peek({tmp, 4}))*/
        Ref(_tmp_612);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_612;
        ((int *)_2)[2] = 4;
        _254 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_254);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _255 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_254);
        _254 = NOVALUE;
        _256 = _2float32_to_atom(_255);
        _255 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_614);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_614 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_650))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_650)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_650);
        _1 = *(int *)_2;
        *(int *)_2 = _256;
        if( _1 != _256 ){
            DeRef(_1);
        }
        _256 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_612;
        if (IS_ATOM_INT(_tmp_612)) {
            _tmp_612 = _tmp_612 + 8;
            if ((long)((unsigned long)_tmp_612 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_612 = NewDouble((double)_tmp_612);
        }
        else {
            _tmp_612 = NewDouble(DBL_PTR(_tmp_612)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_650;
        if (IS_ATOM_INT(_i_650)) {
            _i_650 = _i_650 + 1;
            if ((long)((unsigned long)_i_650 +(unsigned long) HIGH_BITS) >= 0){
                _i_650 = NewDouble((double)_i_650);
            }
        }
        else {
            _i_650 = binary_op_a(PLUS, _i_650, 1);
        }
        DeRef(_0);
        goto LB; // [223] 198
LC: 
        ;
        DeRef(_i_650);
    }

    /** 				return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto LD; // [234] 261
LA: 

    /** 				tmp = float32_to_atom(peek({ma + 4, 4}))*/
    if (IS_ATOM_INT(_ma_610)) {
        _258 = _ma_610 + 4;
        if ((long)((unsigned long)_258 + (unsigned long)HIGH_BITS) >= 0) 
        _258 = NewDouble((double)_258);
    }
    else {
        _258 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _258;
    ((int *)_2)[2] = 4;
    _259 = MAKE_SEQ(_1);
    _258 = NOVALUE;
    _1 = (int)SEQ_PTR(_259);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _260 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_259);
    _259 = NOVALUE;
    _0 = _tmp_612;
    _tmp_612 = _2float32_to_atom(_260);
    DeRef(_0);
    _260 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_val_613);
    DeRef(_s_614);
    return _tmp_612;
LD: 
L9: 

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _262 = _ma_610 + 4;
        if ((long)((unsigned long)_262 + (unsigned long)HIGH_BITS) >= 0) 
        _262 = NewDouble((double)_262);
    }
    else {
        _262 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_262)) {
        _tmp_612 = *(unsigned long *)_262;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_262)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_262);
    _262 = NOVALUE;

    /** 		if val = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _val_613, _3DOUBLE_FLAG_439)){
        goto LE; // [273] 360
    }

    /** 			if len then*/
    if (_len_611 == 0) {
        goto LF; // [279] 339
    }
    else {
        if (!IS_ATOM_INT(_len_611) && DBL_PTR(_len_611)->dbl == 0.0){
            goto LF; // [279] 339
        }
    }

    /** 				s = repeat(0, len)*/
    DeRef(_s_614);
    _s_614 = Repeat(0, _len_611);

    /** 				for i = 1 to len do*/
    Ref(_len_611);
    DeRef(_266);
    _266 = _len_611;
    {
        int _i_670;
        _i_670 = 1;
L10: 
        if (binary_op_a(GREATER, _i_670, _266)){
            goto L11; // [293] 330
        }

        /** 					s[i] = float64_to_atom(peek({tmp, 8}))*/
        Ref(_tmp_612);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_612;
        ((int *)_2)[2] = 8;
        _267 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_267);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _268 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_267);
        _267 = NOVALUE;
        _269 = _2float64_to_atom(_268);
        _268 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_614);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_614 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_670))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_670)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_670);
        _1 = *(int *)_2;
        *(int *)_2 = _269;
        if( _1 != _269 ){
            DeRef(_1);
        }
        _269 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_612;
        if (IS_ATOM_INT(_tmp_612)) {
            _tmp_612 = _tmp_612 + 8;
            if ((long)((unsigned long)_tmp_612 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_612 = NewDouble((double)_tmp_612);
        }
        else {
            _tmp_612 = NewDouble(DBL_PTR(_tmp_612)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_670;
        if (IS_ATOM_INT(_i_670)) {
            _i_670 = _i_670 + 1;
            if ((long)((unsigned long)_i_670 +(unsigned long) HIGH_BITS) >= 0){
                _i_670 = NewDouble((double)_i_670);
            }
        }
        else {
            _i_670 = binary_op_a(PLUS, _i_670, 1);
        }
        DeRef(_0);
        goto L10; // [325] 300
L11: 
        ;
        DeRef(_i_670);
    }

    /** 				return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto L12; // [336] 359
LF: 

    /** 				tmp = float64_to_atom(peek({tmp, 8}))*/
    Ref(_tmp_612);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_612;
    ((int *)_2)[2] = 8;
    _271 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_271);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _272 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_271);
    _271 = NOVALUE;
    _0 = _tmp_612;
    _tmp_612 = _2float64_to_atom(_272);
    DeRef(_0);
    _272 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_val_613);
    DeRef(_s_614);
    return _tmp_612;
L12: 
LE: 

    /** 		s = peek({tmp, len})*/
    Ref(_len_611);
    Ref(_tmp_612);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_612;
    ((int *)_2)[2] = _len_611;
    _274 = MAKE_SEQ(_1);
    DeRef(_s_614);
    _1 = (int)SEQ_PTR(_274);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_614 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_274);
    _274 = NOVALUE;

    /** 		return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto L13; // [377] 476
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_611, 0)){
        goto L14; // [382] 469
    }

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_610)) {
        _277 = _ma_610 + 4;
        if ((long)((unsigned long)_277 + (unsigned long)HIGH_BITS) >= 0) 
        _277 = NewDouble((double)_277);
    }
    else {
        _277 = NewDouble(DBL_PTR(_ma_610)->dbl + (double)4);
    }
    DeRef(_tmp_612);
    if (IS_ATOM_INT(_277)) {
        _tmp_612 = *(unsigned long *)_277;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_277)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_277);
    _277 = NOVALUE;

    /** 		tmp = peek4u(tmp)*/
    _0 = _tmp_612;
    if (IS_ATOM_INT(_tmp_612)) {
        _tmp_612 = *(unsigned long *)_tmp_612;
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    else {
        _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_tmp_612)->dbl);
        if ((unsigned)_tmp_612 > (unsigned)MAXINT)
        _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
    }
    DeRef(_0);

    /** 		s = repeat(0, len)*/
    DeRef(_s_614);
    _s_614 = Repeat(0, _len_611);

    /** 		s[1] = linked_list_to_sequence(tmp)*/
    Ref(_tmp_612);
    DeRef(_281);
    _281 = _tmp_612;
    _282 = _3linked_list_to_sequence(_281);
    _281 = NOVALUE;
    _2 = (int)SEQ_PTR(_s_614);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_614 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _282;
    if( _1 != _282 ){
    }
    _282 = NOVALUE;

    /** 		for i = 2 to length(s) do*/
    if (IS_SEQUENCE(_s_614)){
            _283 = SEQ_PTR(_s_614)->length;
    }
    else {
        _283 = 1;
    }
    {
        int _i_693;
        _i_693 = 2;
L15: 
        if (_i_693 > _283){
            goto L16; // [424] 460
        }

        /** 			tmp = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_612)) {
            _284 = _tmp_612 + 12;
            if ((long)((unsigned long)_284 + (unsigned long)HIGH_BITS) >= 0) 
            _284 = NewDouble((double)_284);
        }
        else {
            _284 = NewDouble(DBL_PTR(_tmp_612)->dbl + (double)12);
        }
        DeRef(_tmp_612);
        if (IS_ATOM_INT(_284)) {
            _tmp_612 = *(unsigned long *)_284;
            if ((unsigned)_tmp_612 > (unsigned)MAXINT)
            _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
        }
        else {
            _tmp_612 = *(unsigned long *)(unsigned long)(DBL_PTR(_284)->dbl);
            if ((unsigned)_tmp_612 > (unsigned)MAXINT)
            _tmp_612 = NewDouble((double)(unsigned long)_tmp_612);
        }
        DeRef(_284);
        _284 = NOVALUE;

        /** 			s[i] = linked_list_to_sequence(tmp)*/
        Ref(_tmp_612);
        DeRef(_286);
        _286 = _tmp_612;
        _287 = _3linked_list_to_sequence(_286);
        _286 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_614);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_614 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_693);
        _1 = *(int *)_2;
        *(int *)_2 = _287;
        if( _1 != _287 ){
            DeRef(_1);
        }
        _287 = NOVALUE;

        /** 		end for*/
        _i_693 = _i_693 + 1;
        goto L15; // [455] 431
L16: 
        ;
    }

    /** 		return s*/
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    return _s_614;
    goto L13; // [466] 476
L14: 

    /** 		return {}*/
    RefDS(_5);
    DeRef(_ma_610);
    DeRef(_len_611);
    DeRef(_tmp_612);
    DeRef(_val_613);
    DeRef(_s_614);
    return _5;
L13: 
    ;
}



// 0x7F81E50D
