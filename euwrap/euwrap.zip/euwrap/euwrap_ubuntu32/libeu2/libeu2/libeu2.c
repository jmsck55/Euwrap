// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _1set_return_linked_list(int _i_702)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_702)) {
        _1 = (long)(DBL_PTR(_i_702)->dbl);
        DeRefDS(_i_702);
        _i_702 = _1;
    }

    /** 	always_linked_list = i*/
    _3always_linked_list_366 = _i_702;

    /** end procedure*/
    return;
    ;
}
void set_return_linked_list() __attribute__ ((alias ("_1set_return_linked_list")));


int _1get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _3always_linked_list_366;
    ;
}
int get_return_linked_list() __attribute__ ((alias ("_1get_return_linked_list")));


int _1get_version()
{
    int _0, _1, _2;
    

    /** 	return VERSION*/
    return 2;
    ;
}
int get_version() __attribute__ ((alias ("_1get_version")));


int _1binary_search(int _needle_712, int _haystack_713)
{
    int _start_point_714 = NOVALUE;
    int _end_point_715 = NOVALUE;
    int _lo_716 = NOVALUE;
    int _hi_717 = NOVALUE;
    int _mid_718 = NOVALUE;
    int _c_719 = NOVALUE;
    int _308 = NOVALUE;
    int _300 = NOVALUE;
    int _298 = NOVALUE;
    int _295 = NOVALUE;
    int _294 = NOVALUE;
    int _293 = NOVALUE;
    int _292 = NOVALUE;
    int _289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	start_point = 1*/
    _start_point_714 = 1;

    /** 	end_point = 0*/
    _end_point_715 = 0;

    /** 	lo = start_point*/
    _lo_716 = 1;

    /** 	if end_point <= 0 then*/

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_713)){
            _289 = SEQ_PTR(_haystack_713)->length;
    }
    else {
        _289 = 1;
    }
    _hi_717 = _289 + 0;
    _289 = NOVALUE;
    goto L1; // [33] 42

    /** 		hi = end_point*/
    _hi_717 = _end_point_715;
L1: 

    /** 	if lo<1 then*/
    if (_lo_716 >= 1)
    goto L2; // [44] 54

    /** 		lo=1*/
    _lo_716 = 1;
L2: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _292 = (_lo_716 > _hi_717);
    if (_292 == 0) {
        goto L3; // [62] 83
    }
    if (IS_SEQUENCE(_haystack_713)){
            _294 = SEQ_PTR(_haystack_713)->length;
    }
    else {
        _294 = 1;
    }
    _295 = (_294 > 0);
    _294 = NOVALUE;
    if (_295 == 0)
    {
        DeRef(_295);
        _295 = NOVALUE;
        goto L3; // [74] 83
    }
    else{
        DeRef(_295);
        _295 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_713)){
            _hi_717 = SEQ_PTR(_haystack_713)->length;
    }
    else {
        _hi_717 = 1;
    }
L3: 

    /** 	mid = start_point*/
    _mid_718 = _start_point_714;

    /** 	c = 0*/
    _c_719 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_716 > _hi_717)
    goto L5; // [98] 166

    /** 		mid = floor((lo + hi) / 2)*/
    _298 = _lo_716 + _hi_717;
    if ((long)((unsigned long)_298 + (unsigned long)HIGH_BITS) >= 0) 
    _298 = NewDouble((double)_298);
    if (IS_ATOM_INT(_298)) {
        _mid_718 = _298 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _298, 2);
        _mid_718 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_298);
    _298 = NOVALUE;
    if (!IS_ATOM_INT(_mid_718)) {
        _1 = (long)(DBL_PTR(_mid_718)->dbl);
        DeRefDS(_mid_718);
        _mid_718 = _1;
    }

    /** 		c = compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_713);
    _300 = (int)*(((s1_ptr)_2)->base + _mid_718);
    if (IS_ATOM_INT(_needle_712) && IS_ATOM_INT(_300)){
        _c_719 = (_needle_712 < _300) ? -1 : (_needle_712 > _300);
    }
    else{
        _c_719 = compare(_needle_712, _300);
    }
    _300 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_719 >= 0)
    goto L6; // [126] 139

    /** 			hi = mid - 1*/
    _hi_717 = _mid_718 - 1;
    goto L4; // [136] 98
L6: 

    /** 		elsif c > 0 then*/
    if (_c_719 <= 0)
    goto L7; // [141] 154

    /** 			lo = mid + 1*/
    _lo_716 = _mid_718 + 1;
    goto L4; // [151] 98
L7: 

    /** 			return mid*/
    DeRef(_needle_712);
    DeRefDS(_haystack_713);
    DeRef(_292);
    _292 = NOVALUE;
    return _mid_718;

    /** 	end while*/
    goto L4; // [163] 98
L5: 

    /** 	if c > 0 then*/
    if (_c_719 <= 0)
    goto L8; // [168] 179

    /** 		mid += 1*/
    _mid_718 = _mid_718 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_718 == 0xC0000000)
    _308 = (int)NewDouble((double)-0xC0000000);
    else
    _308 = - _mid_718;
    DeRef(_needle_712);
    DeRefDS(_haystack_713);
    DeRef(_292);
    _292 = NOVALUE;
    return _308;
    ;
}


void _1init()
{
    int _0, _1, _2;
    

    /** 	high_address = 0*/
    _1high_address_750 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef(_1data_751);
    _1data_751 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef(_1free_list_752);
    _1free_list_752 = _5;

    /** end procedure*/
    return;
    ;
}
void init() __attribute__ ((alias ("_1init")));


int _1get_high_address()
{
    int _0, _1, _2;
    

    /** 	return high_address*/
    return _1high_address_750;
    ;
}
int get_high_address() __attribute__ ((alias ("_1get_high_address")));


int _1set_high_address(int _ma_760)
{
    int _312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_760)) {
        if (65536 > 0 && _ma_760 >= 0) {
            _1high_address_750 = _ma_760 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_760 / (double)65536);
            _1high_address_750 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_760, 65536);
        _1high_address_750 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_750)) {
        _1 = (long)(DBL_PTR(_1high_address_750)->dbl);
        DeRefDS(_1high_address_750);
        _1high_address_750 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    if (IS_ATOM_INT(_ma_760)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_760 & (unsigned long)65535;
             _312 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _312 = Dand_bits(DBL_PTR(_ma_760), &temp_d);
    }
    DeRef(_ma_760);
    return _312;
    ;
}


int _1get_address(int _low_767, int _high_768)
{
    int _314 = NOVALUE;
    int _313 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_767)) {
        _1 = (long)(DBL_PTR(_low_767)->dbl);
        DeRefDS(_low_767);
        _low_767 = _1;
    }
    if (!IS_ATOM_INT(_high_768)) {
        _1 = (long)(DBL_PTR(_high_768)->dbl);
        DeRefDS(_high_768);
        _high_768 = _1;
    }

    /** 	return high * #00010000 + low*/
    _313 = NewDouble(_high_768 * (double)65536);
    if (IS_ATOM_INT(_313)) {
        _314 = _313 + _low_767;
        if ((long)((unsigned long)_314 + (unsigned long)HIGH_BITS) >= 0) 
        _314 = NewDouble((double)_314);
    }
    else {
        _314 = NewDouble(DBL_PTR(_313)->dbl + (double)_low_767);
    }
    DeRef(_313);
    _313 = NOVALUE;
    return _314;
    ;
}


int _1register_data(int _ob_773)
{
    int _i_774 = NOVALUE;
    int _ret_775 = NOVALUE;
    int _a_776 = NOVALUE;
    int _s_777 = NOVALUE;
    int _326 = NOVALUE;
    int _323 = NOVALUE;
    int _321 = NOVALUE;
    int _320 = NOVALUE;
    int _319 = NOVALUE;
    int _317 = NOVALUE;
    int _315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_752)){
            _315 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _315 = 1;
    }
    if (_315 == 0)
    {
        _315 = NOVALUE;
        goto L1; // [8] 106
    }
    else{
        _315 = NOVALUE;
    }

    /** 		ret = free_list[1]*/
    _2 = (int)SEQ_PTR(_1free_list_752);
    _ret_775 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_ret_775))
    _ret_775 = (long)DBL_PTR(_ret_775)->dbl;

    /** 		free_list = free_list[2..length(free_list)]*/
    if (IS_SEQUENCE(_1free_list_752)){
            _317 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _317 = 1;
    }
    rhs_slice_target = (object_ptr)&_1free_list_752;
    RHS_Slice(_1free_list_752, 2, _317);

    /** 		if integer(ob) then*/
    if (IS_ATOM_INT(_ob_773))
    _319 = 1;
    else if (IS_ATOM_DBL(_ob_773))
    _319 = IS_ATOM_INT(DoubleToInt(_ob_773));
    else
    _319 = 0;
    if (_319 == 0)
    {
        _319 = NOVALUE;
        goto L2; // [38] 59
    }
    else{
        _319 = NOVALUE;
    }

    /** 			i = ob*/
    Ref(_ob_773);
    _i_774 = _ob_773;
    if (!IS_ATOM_INT(_i_774)) {
        _1 = (long)(DBL_PTR(_i_774)->dbl);
        DeRefDS(_i_774);
        _i_774 = _1;
    }

    /** 			data[ret] = i*/
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_775);
    _1 = *(int *)_2;
    *(int *)_2 = _i_774;
    DeRef(_1);
    goto L3; // [56] 99
L2: 

    /** 		elsif atom(ob) then*/
    _320 = IS_ATOM(_ob_773);
    if (_320 == 0)
    {
        _320 = NOVALUE;
        goto L4; // [64] 83
    }
    else{
        _320 = NOVALUE;
    }

    /** 			a = ob*/
    Ref(_ob_773);
    DeRef(_a_776);
    _a_776 = _ob_773;

    /** 			data[ret] = a*/
    Ref(_a_776);
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_775);
    _1 = *(int *)_2;
    *(int *)_2 = _a_776;
    DeRef(_1);
    goto L3; // [80] 99
L4: 

    /** 			s = ob*/
    Ref(_ob_773);
    DeRef(_s_777);
    _s_777 = _ob_773;

    /** 			data[ret] = s*/
    RefDS(_s_777);
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_775);
    _1 = *(int *)_2;
    *(int *)_2 = _s_777;
    DeRef(_1);
L3: 

    /** 		return ret*/
    DeRef(_ob_773);
    DeRef(_a_776);
    DeRef(_s_777);
    return _ret_775;
L1: 

    /** 	if integer(ob) then*/
    if (IS_ATOM_INT(_ob_773))
    _321 = 1;
    else if (IS_ATOM_DBL(_ob_773))
    _321 = IS_ATOM_INT(DoubleToInt(_ob_773));
    else
    _321 = 0;
    if (_321 == 0)
    {
        _321 = NOVALUE;
        goto L5; // [111] 132
    }
    else{
        _321 = NOVALUE;
    }

    /** 		i = ob*/
    Ref(_ob_773);
    _i_774 = _ob_773;
    if (!IS_ATOM_INT(_i_774)) {
        _1 = (long)(DBL_PTR(_i_774)->dbl);
        DeRefDS(_i_774);
        _i_774 = _1;
    }

    /** 		data = append(data, i)*/
    Append(&_1data_751, _1data_751, _i_774);
    goto L6; // [129] 172
L5: 

    /** 	elsif atom(ob) then*/
    _323 = IS_ATOM(_ob_773);
    if (_323 == 0)
    {
        _323 = NOVALUE;
        goto L7; // [137] 156
    }
    else{
        _323 = NOVALUE;
    }

    /** 		a = ob*/
    Ref(_ob_773);
    DeRef(_a_776);
    _a_776 = _ob_773;

    /** 		data = append(data, a)*/
    Ref(_a_776);
    Append(&_1data_751, _1data_751, _a_776);
    goto L6; // [153] 172
L7: 

    /** 		s = ob*/
    Ref(_ob_773);
    DeRef(_s_777);
    _s_777 = _ob_773;

    /** 		data = append(data, s)*/
    RefDS(_s_777);
    Append(&_1data_751, _1data_751, _s_777);
L6: 

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_751)){
            _326 = SEQ_PTR(_1data_751)->length;
    }
    else {
        _326 = 1;
    }
    DeRef(_ob_773);
    DeRef(_a_776);
    DeRef(_s_777);
    return _326;
    ;
}


int _1retval(int _ob_799)
{
    int _327 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return register_data(ob)*/
    Ref(_ob_799);
    _327 = _1register_data(_ob_799);
    DeRef(_ob_799);
    return _327;
    ;
}


int _1length_of_data()
{
    int _328 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_751)){
            _328 = SEQ_PTR(_1data_751)->length;
    }
    else {
        _328 = 1;
    }
    return _328;
    ;
}
int length_of_data() __attribute__ ((alias ("_1length_of_data")));


int _1is_free(int _id_806)
{
    int _330 = NOVALUE;
    int _329 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_806)) {
        _1 = (long)(DBL_PTR(_id_806)->dbl);
        DeRefDS(_id_806);
        _id_806 = _1;
    }

    /** 	return find(id, free_list) and 1 -- boolean*/
    _329 = find_from(_id_806, _1free_list_752, 1);
    _330 = (_329 != 0 && 1 != 0);
    _329 = NOVALUE;
    return _330;
    ;
}
int is_free() __attribute__ ((alias ("_1is_free")));


int _1access_free_list()
{
    int _set_high_address_inlined_set_high_address_at_41_819 = NOVALUE;
    int _ma_811 = NOVALUE;
    int _333 = NOVALUE;
    int _332 = NOVALUE;
    int _331 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = 0*/
    DeRef(_ma_811);
    _ma_811 = 0;

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_752)){
            _331 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _331 = 1;
    }
    if (_331 == 0)
    {
        _331 = NOVALUE;
        goto L1; // [13] 39
    }
    else{
        _331 = NOVALUE;
    }

    /** 		ma = allocate(length(free_list) * 4)*/
    if (IS_SEQUENCE(_1free_list_752)){
            _332 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _332 = 1;
    }
    if (_332 == (short)_332)
    _333 = _332 * 4;
    else
    _333 = NewDouble(_332 * (double)4);
    _332 = NOVALUE;
    _ma_811 = _2allocate(_333);
    _333 = NOVALUE;

    /** 		poke4(ma, free_list)*/
    if (IS_ATOM_INT(_ma_811)){
        poke4_addr = (unsigned long *)_ma_811;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_811)->dbl);
    }
    _1 = (int)SEQ_PTR(_1free_list_752);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
L1: 

    /** 	return set_high_address(ma)*/

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_811)) {
        if (65536 > 0 && _ma_811 >= 0) {
            _1high_address_750 = _ma_811 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_811 / (double)65536);
            _1high_address_750 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_811, 65536);
        _1high_address_750 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_750)) {
        _1 = (long)(DBL_PTR(_1high_address_750)->dbl);
        DeRefDS(_1high_address_750);
        _1high_address_750 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_41_819);
    if (IS_ATOM_INT(_ma_811)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_811 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_41_819 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _set_high_address_inlined_set_high_address_at_41_819 = Dand_bits(DBL_PTR(_ma_811), &temp_d);
    }
    DeRef(_ma_811);
    return _set_high_address_inlined_set_high_address_at_41_819;
    ;
}
int access_free_list() __attribute__ ((alias ("_1access_free_list")));


void _1generic_free(int _low_822, int _high_823)
{
    int _ma_824 = NOVALUE;
    int _get_address_1__tmp_at6_827 = NOVALUE;
    int _get_address_inlined_get_address_at_6_826 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_822)) {
        _1 = (long)(DBL_PTR(_low_822)->dbl);
        DeRefDS(_low_822);
        _low_822 = _1;
    }
    if (!IS_ATOM_INT(_high_823)) {
        _1 = (long)(DBL_PTR(_high_823)->dbl);
        DeRefDS(_high_823);
        _high_823 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_827);
    _get_address_1__tmp_at6_827 = NewDouble(_high_823 * (double)65536);
    DeRef(_ma_824);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_827)) {
        _ma_824 = _get_address_1__tmp_at6_827 + _low_822;
        if ((long)((unsigned long)_ma_824 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_824 = NewDouble((double)_ma_824);
    }
    else {
        _ma_824 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_827)->dbl + (double)_low_822);
    }
    DeRef(_get_address_1__tmp_at6_827);
    _get_address_1__tmp_at6_827 = NOVALUE;

    /** 	if ma then*/
    if (_ma_824 == 0) {
        goto L1; // [22] 31
    }
    else {
        if (!IS_ATOM_INT(_ma_824) && DBL_PTR(_ma_824)->dbl == 0.0){
            goto L1; // [22] 31
        }
    }

    /** 		free(ma)*/
    Ref(_ma_824);
    _2free(_ma_824);
L1: 

    /** end procedure*/
    DeRef(_ma_824);
    return;
    ;
}
void generic_free() __attribute__ ((alias ("_1generic_free")));


void _1delete_linked_list(int _id_832)
{
    int _pos_833 = NOVALUE;
    int _354 = NOVALUE;
    int _353 = NOVALUE;
    int _351 = NOVALUE;
    int _350 = NOVALUE;
    int _348 = NOVALUE;
    int _347 = NOVALUE;
    int _346 = NOVALUE;
    int _344 = NOVALUE;
    int _342 = NOVALUE;
    int _341 = NOVALUE;
    int _340 = NOVALUE;
    int _339 = NOVALUE;
    int _338 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_832)) {
        _1 = (long)(DBL_PTR(_id_832)->dbl);
        DeRefDS(_id_832);
        _id_832 = _1;
    }

    /** 	pos = binary_search(id, free_list)*/
    RefDS(_1free_list_752);
    _pos_833 = _1binary_search(_id_832, _1free_list_752);
    if (!IS_ATOM_INT(_pos_833)) {
        _1 = (long)(DBL_PTR(_pos_833)->dbl);
        DeRefDS(_pos_833);
        _pos_833 = _1;
    }

    /** 	if pos < 0 then -- if not in free_list, insert*/
    if (_pos_833 >= 0)
    goto L1; // [16] 150

    /** 		data[id] = {}*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_832);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 		pos = -pos*/
    _pos_833 = - _pos_833;

    /** 		free_list = free_list[1..pos-1] & {id} & free_list[pos..$]*/
    _338 = _pos_833 - 1;
    rhs_slice_target = (object_ptr)&_339;
    RHS_Slice(_1free_list_752, 1, _338);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _id_832;
    _340 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_1free_list_752)){
            _341 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _341 = 1;
    }
    rhs_slice_target = (object_ptr)&_342;
    RHS_Slice(_1free_list_752, _pos_833, _341);
    {
        int concat_list[3];

        concat_list[0] = _342;
        concat_list[1] = _340;
        concat_list[2] = _339;
        Concat_N((object_ptr)&_1free_list_752, concat_list, 3);
    }
    DeRefDS(_342);
    _342 = NOVALUE;
    DeRefDS(_340);
    _340 = NOVALUE;
    DeRefDS(_339);
    _339 = NOVALUE;

    /** 		for i = length(free_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_1free_list_752)){
            _344 = SEQ_PTR(_1free_list_752)->length;
    }
    else {
        _344 = 1;
    }
    {
        int _i_845;
        _i_845 = _344;
L2: 
        if (_i_845 < 1){
            goto L3; // [75] 149
        }

        /** 			if free_list[$] = length(data) then*/
        if (IS_SEQUENCE(_1free_list_752)){
                _346 = SEQ_PTR(_1free_list_752)->length;
        }
        else {
            _346 = 1;
        }
        _2 = (int)SEQ_PTR(_1free_list_752);
        _347 = (int)*(((s1_ptr)_2)->base + _346);
        if (IS_SEQUENCE(_1data_751)){
                _348 = SEQ_PTR(_1data_751)->length;
        }
        else {
            _348 = 1;
        }
        if (binary_op_a(NOTEQ, _347, _348)){
            _347 = NOVALUE;
            _348 = NOVALUE;
            goto L3; // [98] 149
        }
        _347 = NOVALUE;
        _348 = NOVALUE;

        /** 				data = data[1..$-1]*/
        if (IS_SEQUENCE(_1data_751)){
                _350 = SEQ_PTR(_1data_751)->length;
        }
        else {
            _350 = 1;
        }
        _351 = _350 - 1;
        _350 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1data_751;
        RHS_Slice(_1data_751, 1, _351);

        /** 				free_list = free_list[1..$-1]*/
        if (IS_SEQUENCE(_1free_list_752)){
                _353 = SEQ_PTR(_1free_list_752)->length;
        }
        else {
            _353 = 1;
        }
        _354 = _353 - 1;
        _353 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1free_list_752;
        RHS_Slice(_1free_list_752, 1, _354);
        goto L4; // [134] 142

        /** 				exit*/
        goto L3; // [139] 149
L4: 

        /** 		end for*/
        _i_845 = _i_845 + -1;
        goto L2; // [144] 82
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_338);
    _338 = NOVALUE;
    DeRef(_351);
    _351 = NOVALUE;
    DeRef(_354);
    _354 = NOVALUE;
    return;
    ;
}
void delete_linked_list() __attribute__ ((alias ("_1delete_linked_list")));


void _1free_linked_lists(int _low_862, int _high_863, int _len_864)
{
    int _array_865 = NOVALUE;
    int _ma_866 = NOVALUE;
    int _get_address_1__tmp_at8_869 = NOVALUE;
    int _get_address_inlined_get_address_at_8_868 = NOVALUE;
    int _359 = NOVALUE;
    int _358 = NOVALUE;
    int _356 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_862)) {
        _1 = (long)(DBL_PTR(_low_862)->dbl);
        DeRefDS(_low_862);
        _low_862 = _1;
    }
    if (!IS_ATOM_INT(_high_863)) {
        _1 = (long)(DBL_PTR(_high_863)->dbl);
        DeRefDS(_high_863);
        _high_863 = _1;
    }
    if (!IS_ATOM_INT(_len_864)) {
        _1 = (long)(DBL_PTR(_len_864)->dbl);
        DeRefDS(_len_864);
        _len_864 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_869);
    _get_address_1__tmp_at8_869 = NewDouble(_high_863 * (double)65536);
    DeRef(_ma_866);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_869)) {
        _ma_866 = _get_address_1__tmp_at8_869 + _low_862;
        if ((long)((unsigned long)_ma_866 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_866 = NewDouble((double)_ma_866);
    }
    else {
        _ma_866 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_869)->dbl + (double)_low_862);
    }
    DeRef(_get_address_1__tmp_at8_869);
    _get_address_1__tmp_at8_869 = NOVALUE;

    /** 	array = peek4u({ma, len})*/
    Ref(_ma_866);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ma_866;
    ((int *)_2)[2] = _len_864;
    _356 = MAKE_SEQ(_1);
    DeRef(_array_865);
    _1 = (int)SEQ_PTR(_356);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _array_865 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_356);
    _356 = NOVALUE;

    /** 	for i = 1 to length(array) do*/
    if (IS_SEQUENCE(_array_865)){
            _358 = SEQ_PTR(_array_865)->length;
    }
    else {
        _358 = 1;
    }
    {
        int _i_873;
        _i_873 = 1;
L1: 
        if (_i_873 > _358){
            goto L2; // [38] 61
        }

        /** 		delete_linked_list(array[i])*/
        _2 = (int)SEQ_PTR(_array_865);
        _359 = (int)*(((s1_ptr)_2)->base + _i_873);
        Ref(_359);
        _1delete_linked_list(_359);
        _359 = NOVALUE;

        /** 	end for*/
        _i_873 = _i_873 + 1;
        goto L1; // [56] 45
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_array_865);
    DeRef(_ma_866);
    return;
    ;
}
void free_linked_lists() __attribute__ ((alias ("_1free_linked_lists")));


int _1register_linked_list(int _low_878, int _high_879)
{
    int _get_address_1__tmp_at6_883 = NOVALUE;
    int _get_address_inlined_get_address_at_6_882 = NOVALUE;
    int _361 = NOVALUE;
    int _360 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_878)) {
        _1 = (long)(DBL_PTR(_low_878)->dbl);
        DeRefDS(_low_878);
        _low_878 = _1;
    }
    if (!IS_ATOM_INT(_high_879)) {
        _1 = (long)(DBL_PTR(_high_879)->dbl);
        DeRefDS(_high_879);
        _high_879 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_883);
    _get_address_1__tmp_at6_883 = NewDouble(_high_879 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_882);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_883)) {
        _get_address_inlined_get_address_at_6_882 = _get_address_1__tmp_at6_883 + _low_878;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_882 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_882 = NewDouble((double)_get_address_inlined_get_address_at_6_882);
    }
    else {
        _get_address_inlined_get_address_at_6_882 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_883)->dbl + (double)_low_878);
    }
    DeRef(_get_address_1__tmp_at6_883);
    _get_address_1__tmp_at6_883 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_882);
    _360 = _3linked_list_to_sequence(_get_address_inlined_get_address_at_6_882);
    _361 = _1register_data(_360);
    _360 = NOVALUE;
    return _361;
    ;
}
int register_linked_list() __attribute__ ((alias ("_1register_linked_list")));


int _1new_linked_list(int _low_888, int _high_889)
{
    int _get_address_1__tmp_at6_893 = NOVALUE;
    int _get_address_inlined_get_address_at_6_892 = NOVALUE;
    int _363 = NOVALUE;
    int _362 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_888)) {
        _1 = (long)(DBL_PTR(_low_888)->dbl);
        DeRefDS(_low_888);
        _low_888 = _1;
    }
    if (!IS_ATOM_INT(_high_889)) {
        _1 = (long)(DBL_PTR(_high_889)->dbl);
        DeRefDS(_high_889);
        _high_889 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_893);
    _get_address_1__tmp_at6_893 = NewDouble(_high_889 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_892);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_893)) {
        _get_address_inlined_get_address_at_6_892 = _get_address_1__tmp_at6_893 + _low_888;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_892 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_892 = NewDouble((double)_get_address_inlined_get_address_at_6_892);
    }
    else {
        _get_address_inlined_get_address_at_6_892 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_893)->dbl + (double)_low_888);
    }
    DeRef(_get_address_1__tmp_at6_893);
    _get_address_1__tmp_at6_893 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_892);
    _362 = _3linked_list_to_sequence(_get_address_inlined_get_address_at_6_892);
    _363 = _1register_data(_362);
    _362 = NOVALUE;
    return _363;
    ;
}
int new_linked_list() __attribute__ ((alias ("_1new_linked_list")));


void _1store_linked_list(int _id_898, int _low_899, int _high_900)
{
    int _get_address_1__tmp_at10_904 = NOVALUE;
    int _get_address_inlined_get_address_at_10_903 = NOVALUE;
    int _364 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_898)) {
        _1 = (long)(DBL_PTR(_id_898)->dbl);
        DeRefDS(_id_898);
        _id_898 = _1;
    }
    if (!IS_ATOM_INT(_low_899)) {
        _1 = (long)(DBL_PTR(_low_899)->dbl);
        DeRefDS(_low_899);
        _low_899 = _1;
    }
    if (!IS_ATOM_INT(_high_900)) {
        _1 = (long)(DBL_PTR(_high_900)->dbl);
        DeRefDS(_high_900);
        _high_900 = _1;
    }

    /** 	data[id] = linked_list_to_sequence(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_904);
    _get_address_1__tmp_at10_904 = NewDouble(_high_900 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_903);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_904)) {
        _get_address_inlined_get_address_at_10_903 = _get_address_1__tmp_at10_904 + _low_899;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_903 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_903 = NewDouble((double)_get_address_inlined_get_address_at_10_903);
    }
    else {
        _get_address_inlined_get_address_at_10_903 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_904)->dbl + (double)_low_899);
    }
    DeRef(_get_address_1__tmp_at10_904);
    _get_address_1__tmp_at10_904 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_10_903);
    _364 = _3linked_list_to_sequence(_get_address_inlined_get_address_at_10_903);
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_898);
    _1 = *(int *)_2;
    *(int *)_2 = _364;
    if( _1 != _364 ){
        DeRef(_1);
    }
    _364 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void store_linked_list() __attribute__ ((alias ("_1store_linked_list")));


int _1access_linked_list(int _id_908)
{
    int _set_high_address_inlined_set_high_address_at_18_914 = NOVALUE;
    int _ma_inlined_set_high_address_at_15_913 = NOVALUE;
    int _366 = NOVALUE;
    int _365 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_908)) {
        _1 = (long)(DBL_PTR(_id_908)->dbl);
        DeRefDS(_id_908);
        _id_908 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _365 = (int)*(((s1_ptr)_2)->base + _id_908);
    Ref(_365);
    _366 = _3sequence_to_linked_list(_365);
    _365 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_15_913);
    _ma_inlined_set_high_address_at_15_913 = _366;
    _366 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_913)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_15_913 >= 0) {
            _1high_address_750 = _ma_inlined_set_high_address_at_15_913 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_15_913 / (double)65536);
            _1high_address_750 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_15_913, 65536);
        _1high_address_750 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_750)) {
        _1 = (long)(DBL_PTR(_1high_address_750)->dbl);
        DeRefDS(_1high_address_750);
        _1high_address_750 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_18_914);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_913)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_15_913 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_18_914 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_18_914 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_15_913, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_15_913);
    _ma_inlined_set_high_address_at_15_913 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_18_914;
    ;
}
int access_linked_list() __attribute__ ((alias ("_1access_linked_list")));


int _1at_linked_list(int _id_917, int _index_918)
{
    int _set_high_address_inlined_set_high_address_at_24_925 = NOVALUE;
    int _ma_inlined_set_high_address_at_21_924 = NOVALUE;
    int _369 = NOVALUE;
    int _368 = NOVALUE;
    int _367 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_917)) {
        _1 = (long)(DBL_PTR(_id_917)->dbl);
        DeRefDS(_id_917);
        _id_917 = _1;
    }
    if (!IS_ATOM_INT(_index_918)) {
        _1 = (long)(DBL_PTR(_index_918)->dbl);
        DeRefDS(_index_918);
        _index_918 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id][index]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _367 = (int)*(((s1_ptr)_2)->base + _id_917);
    _2 = (int)SEQ_PTR(_367);
    _368 = (int)*(((s1_ptr)_2)->base + _index_918);
    _367 = NOVALUE;
    Ref(_368);
    _369 = _3sequence_to_linked_list(_368);
    _368 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_21_924);
    _ma_inlined_set_high_address_at_21_924 = _369;
    _369 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_924)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_21_924 >= 0) {
            _1high_address_750 = _ma_inlined_set_high_address_at_21_924 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_21_924 / (double)65536);
            _1high_address_750 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_21_924, 65536);
        _1high_address_750 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_750)) {
        _1 = (long)(DBL_PTR(_1high_address_750)->dbl);
        DeRefDS(_1high_address_750);
        _1high_address_750 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_24_925);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_924)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_21_924 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_24_925 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_24_925 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_21_924, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_21_924);
    _ma_inlined_set_high_address_at_21_924 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_24_925;
    ;
}
int at_linked_list() __attribute__ ((alias ("_1at_linked_list")));


void _1free_linked_list_dll(int _low_928, int _high_929)
{
    int _get_address_1__tmp_at6_933 = NOVALUE;
    int _get_address_inlined_get_address_at_6_932 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_928)) {
        _1 = (long)(DBL_PTR(_low_928)->dbl);
        DeRefDS(_low_928);
        _low_928 = _1;
    }
    if (!IS_ATOM_INT(_high_929)) {
        _1 = (long)(DBL_PTR(_high_929)->dbl);
        DeRefDS(_high_929);
        _high_929 = _1;
    }

    /** 	free_linked_list(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_933);
    _get_address_1__tmp_at6_933 = NewDouble(_high_929 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_932);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_933)) {
        _get_address_inlined_get_address_at_6_932 = _get_address_1__tmp_at6_933 + _low_928;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_932 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_932 = NewDouble((double)_get_address_inlined_get_address_at_6_932);
    }
    else {
        _get_address_inlined_get_address_at_6_932 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_933)->dbl + (double)_low_928);
    }
    DeRef(_get_address_1__tmp_at6_933);
    _get_address_1__tmp_at6_933 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_932);
    _3free_linked_list(_get_address_inlined_get_address_at_6_932);

    /** end procedure*/
    return;
    ;
}
void free_linked_list_dll() __attribute__ ((alias ("_1free_linked_list_dll")));


int _1length_linked_list(int _id_936)
{
    int _373 = NOVALUE;
    int _372 = NOVALUE;
    int _371 = NOVALUE;
    int _370 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_936)) {
        _1 = (long)(DBL_PTR(_id_936)->dbl);
        DeRefDS(_id_936);
        _id_936 = _1;
    }

    /** 	if atom(data[id]) then*/
    _2 = (int)SEQ_PTR(_1data_751);
    _370 = (int)*(((s1_ptr)_2)->base + _id_936);
    _371 = IS_ATOM(_370);
    _370 = NOVALUE;
    if (_371 == 0)
    {
        _371 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _371 = NOVALUE;
    }

    /** 		return -1*/
    return -1;
L1: 

    /** 	return length(data[id])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _372 = (int)*(((s1_ptr)_2)->base + _id_936);
    if (IS_SEQUENCE(_372)){
            _373 = SEQ_PTR(_372)->length;
    }
    else {
        _373 = 1;
    }
    _372 = NOVALUE;
    _372 = NOVALUE;
    return _373;
    ;
}
int length_linked_list() __attribute__ ((alias ("_1length_linked_list")));


void _1store_at_linked_list(int _id_944, int _index_945, int _low_946, int _high_947)
{
    int _get_address_1__tmp_at17_953 = NOVALUE;
    int _get_address_inlined_get_address_at_17_952 = NOVALUE;
    int _376 = NOVALUE;
    int _374 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id_944)) {
        _1 = (long)(DBL_PTR(_id_944)->dbl);
        DeRefDS(_id_944);
        _id_944 = _1;
    }
    if (!IS_ATOM_INT(_index_945)) {
        _1 = (long)(DBL_PTR(_index_945)->dbl);
        DeRefDS(_index_945);
        _index_945 = _1;
    }
    if (!IS_ATOM_INT(_low_946)) {
        _1 = (long)(DBL_PTR(_low_946)->dbl);
        DeRefDS(_low_946);
        _low_946 = _1;
    }
    if (!IS_ATOM_INT(_high_947)) {
        _1 = (long)(DBL_PTR(_high_947)->dbl);
        DeRefDS(_high_947);
        _high_947 = _1;
    }

    /** 	data[id][index] = linked_list_to_sequence(get_address(low, high))*/
    _2 = (int)SEQ_PTR(_1data_751);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_751 = MAKE_SEQ(_2);
    }
    _3 = (int)(_id_944 + ((s1_ptr)_2)->base);

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at17_953);
    _get_address_1__tmp_at17_953 = NewDouble(_high_947 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_17_952);
    if (IS_ATOM_INT(_get_address_1__tmp_at17_953)) {
        _get_address_inlined_get_address_at_17_952 = _get_address_1__tmp_at17_953 + _low_946;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_17_952 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_17_952 = NewDouble((double)_get_address_inlined_get_address_at_17_952);
    }
    else {
        _get_address_inlined_get_address_at_17_952 = NewDouble(DBL_PTR(_get_address_1__tmp_at17_953)->dbl + (double)_low_946);
    }
    DeRef(_get_address_1__tmp_at17_953);
    _get_address_1__tmp_at17_953 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_17_952);
    _376 = _3linked_list_to_sequence(_get_address_inlined_get_address_at_17_952);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_945);
    _1 = *(int *)_2;
    *(int *)_2 = _376;
    if( _1 != _376 ){
        DeRef(_1);
    }
    _376 = NOVALUE;
    _374 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void store_at_linked_list() __attribute__ ((alias ("_1store_at_linked_list")));


int _1eu_repeat(int _id_957, int _len_958)
{
    int _retval_inlined_retval_at_19_963 = NOVALUE;
    int _ob_inlined_retval_at_16_962 = NOVALUE;
    int _378 = NOVALUE;
    int _377 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_957)) {
        _1 = (long)(DBL_PTR(_id_957)->dbl);
        DeRefDS(_id_957);
        _id_957 = _1;
    }
    if (!IS_ATOM_INT(_len_958)) {
        _1 = (long)(DBL_PTR(_len_958)->dbl);
        DeRefDS(_len_958);
        _len_958 = _1;
    }

    /** 	return retval(repeat(data[id], len))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _377 = (int)*(((s1_ptr)_2)->base + _id_957);
    _378 = Repeat(_377, _len_958);
    _377 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_962);
    _ob_inlined_retval_at_16_962 = _378;
    _378 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_962);
    _0 = _retval_inlined_retval_at_19_963;
    _retval_inlined_retval_at_19_963 = _1register_data(_ob_inlined_retval_at_16_962);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_962);
    _ob_inlined_retval_at_16_962 = NOVALUE;
    return _retval_inlined_retval_at_19_963;
    ;
}
int eu_repeat() __attribute__ ((alias ("_1eu_repeat")));


void _1eu_mem_set(int _low_966, int _high_967, int _byte_val_968, int _how_many_969)
{
    int _get_address_1__tmp_at10_972 = NOVALUE;
    int _get_address_inlined_get_address_at_10_971 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_966)) {
        _1 = (long)(DBL_PTR(_low_966)->dbl);
        DeRefDS(_low_966);
        _low_966 = _1;
    }
    if (!IS_ATOM_INT(_high_967)) {
        _1 = (long)(DBL_PTR(_high_967)->dbl);
        DeRefDS(_high_967);
        _high_967 = _1;
    }
    if (!IS_ATOM_INT(_byte_val_968)) {
        _1 = (long)(DBL_PTR(_byte_val_968)->dbl);
        DeRefDS(_byte_val_968);
        _byte_val_968 = _1;
    }
    if (!IS_ATOM_INT(_how_many_969)) {
        _1 = (long)(DBL_PTR(_how_many_969)->dbl);
        DeRefDS(_how_many_969);
        _how_many_969 = _1;
    }

    /** 	mem_set(get_address(low, high), byte_val, how_many)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_972);
    _get_address_1__tmp_at10_972 = NewDouble(_high_967 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_971);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_972)) {
        _get_address_inlined_get_address_at_10_971 = _get_address_1__tmp_at10_972 + _low_966;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_971 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_971 = NewDouble((double)_get_address_inlined_get_address_at_10_971);
    }
    else {
        _get_address_inlined_get_address_at_10_971 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_972)->dbl + (double)_low_966);
    }
    DeRef(_get_address_1__tmp_at10_972);
    _get_address_1__tmp_at10_972 = NOVALUE;
    memory_set(_get_address_inlined_get_address_at_10_971, _byte_val_968, _how_many_969);

    /** end procedure*/
    return;
    ;
}
void eu_mem_set() __attribute__ ((alias ("_1eu_mem_set")));


void _1eu_mem_copy(int _dstlow_975, int _dsthigh_976, int _srclow_977, int _srchigh_978, int _len_979)
{
    int _get_address_1__tmp_at12_982 = NOVALUE;
    int _get_address_inlined_get_address_at_12_981 = NOVALUE;
    int _get_address_1__tmp_at25_985 = NOVALUE;
    int _get_address_inlined_get_address_at_25_984 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow_975)) {
        _1 = (long)(DBL_PTR(_dstlow_975)->dbl);
        DeRefDS(_dstlow_975);
        _dstlow_975 = _1;
    }
    if (!IS_ATOM_INT(_dsthigh_976)) {
        _1 = (long)(DBL_PTR(_dsthigh_976)->dbl);
        DeRefDS(_dsthigh_976);
        _dsthigh_976 = _1;
    }
    if (!IS_ATOM_INT(_srclow_977)) {
        _1 = (long)(DBL_PTR(_srclow_977)->dbl);
        DeRefDS(_srclow_977);
        _srclow_977 = _1;
    }
    if (!IS_ATOM_INT(_srchigh_978)) {
        _1 = (long)(DBL_PTR(_srchigh_978)->dbl);
        DeRefDS(_srchigh_978);
        _srchigh_978 = _1;
    }
    if (!IS_ATOM_INT(_len_979)) {
        _1 = (long)(DBL_PTR(_len_979)->dbl);
        DeRefDS(_len_979);
        _len_979 = _1;
    }

    /** 	mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at12_982);
    _get_address_1__tmp_at12_982 = NewDouble(_dsthigh_976 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_12_981);
    if (IS_ATOM_INT(_get_address_1__tmp_at12_982)) {
        _get_address_inlined_get_address_at_12_981 = _get_address_1__tmp_at12_982 + _dstlow_975;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_12_981 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_12_981 = NewDouble((double)_get_address_inlined_get_address_at_12_981);
    }
    else {
        _get_address_inlined_get_address_at_12_981 = NewDouble(DBL_PTR(_get_address_1__tmp_at12_982)->dbl + (double)_dstlow_975);
    }
    DeRef(_get_address_1__tmp_at12_982);
    _get_address_1__tmp_at12_982 = NOVALUE;

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at25_985);
    _get_address_1__tmp_at25_985 = NewDouble(_srchigh_978 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_25_984);
    if (IS_ATOM_INT(_get_address_1__tmp_at25_985)) {
        _get_address_inlined_get_address_at_25_984 = _get_address_1__tmp_at25_985 + _srclow_977;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_25_984 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_25_984 = NewDouble((double)_get_address_inlined_get_address_at_25_984);
    }
    else {
        _get_address_inlined_get_address_at_25_984 = NewDouble(DBL_PTR(_get_address_1__tmp_at25_985)->dbl + (double)_srclow_977);
    }
    DeRef(_get_address_1__tmp_at25_985);
    _get_address_1__tmp_at25_985 = NOVALUE;
    memory_copy(_get_address_inlined_get_address_at_12_981, _get_address_inlined_get_address_at_25_984, _len_979);

    /** end procedure*/
    return;
    ;
}
void eu_mem_copy() __attribute__ ((alias ("_1eu_mem_copy")));


int _1eu_add(int _id1_988, int _id2_989)
{
    int _retval_inlined_retval_at_25_995 = NOVALUE;
    int _ob_inlined_retval_at_22_994 = NOVALUE;
    int _381 = NOVALUE;
    int _380 = NOVALUE;
    int _379 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_988)) {
        _1 = (long)(DBL_PTR(_id1_988)->dbl);
        DeRefDS(_id1_988);
        _id1_988 = _1;
    }
    if (!IS_ATOM_INT(_id2_989)) {
        _1 = (long)(DBL_PTR(_id2_989)->dbl);
        DeRefDS(_id2_989);
        _id2_989 = _1;
    }

    /** 	return retval(data[id1] + data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _379 = (int)*(((s1_ptr)_2)->base + _id1_988);
    _2 = (int)SEQ_PTR(_1data_751);
    _380 = (int)*(((s1_ptr)_2)->base + _id2_989);
    if (IS_ATOM_INT(_379) && IS_ATOM_INT(_380)) {
        _381 = _379 + _380;
        if ((long)((unsigned long)_381 + (unsigned long)HIGH_BITS) >= 0) 
        _381 = NewDouble((double)_381);
    }
    else {
        _381 = binary_op(PLUS, _379, _380);
    }
    _379 = NOVALUE;
    _380 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_994);
    _ob_inlined_retval_at_22_994 = _381;
    _381 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_994);
    _0 = _retval_inlined_retval_at_25_995;
    _retval_inlined_retval_at_25_995 = _1register_data(_ob_inlined_retval_at_22_994);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_994);
    _ob_inlined_retval_at_22_994 = NOVALUE;
    return _retval_inlined_retval_at_25_995;
    ;
}
int eu_add() __attribute__ ((alias ("_1eu_add")));


int _1eu_subtract(int _id1_998, int _id2_999)
{
    int _retval_inlined_retval_at_25_1005 = NOVALUE;
    int _ob_inlined_retval_at_22_1004 = NOVALUE;
    int _384 = NOVALUE;
    int _383 = NOVALUE;
    int _382 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_998)) {
        _1 = (long)(DBL_PTR(_id1_998)->dbl);
        DeRefDS(_id1_998);
        _id1_998 = _1;
    }
    if (!IS_ATOM_INT(_id2_999)) {
        _1 = (long)(DBL_PTR(_id2_999)->dbl);
        DeRefDS(_id2_999);
        _id2_999 = _1;
    }

    /** 	return retval(data[id1] - data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _382 = (int)*(((s1_ptr)_2)->base + _id1_998);
    _2 = (int)SEQ_PTR(_1data_751);
    _383 = (int)*(((s1_ptr)_2)->base + _id2_999);
    if (IS_ATOM_INT(_382) && IS_ATOM_INT(_383)) {
        _384 = _382 - _383;
        if ((long)((unsigned long)_384 +(unsigned long) HIGH_BITS) >= 0){
            _384 = NewDouble((double)_384);
        }
    }
    else {
        _384 = binary_op(MINUS, _382, _383);
    }
    _382 = NOVALUE;
    _383 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1004);
    _ob_inlined_retval_at_22_1004 = _384;
    _384 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1004);
    _0 = _retval_inlined_retval_at_25_1005;
    _retval_inlined_retval_at_25_1005 = _1register_data(_ob_inlined_retval_at_22_1004);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1004);
    _ob_inlined_retval_at_22_1004 = NOVALUE;
    return _retval_inlined_retval_at_25_1005;
    ;
}
int eu_subtract() __attribute__ ((alias ("_1eu_subtract")));


int _1eu_multiply(int _id1_1008, int _id2_1009)
{
    int _retval_inlined_retval_at_25_1015 = NOVALUE;
    int _ob_inlined_retval_at_22_1014 = NOVALUE;
    int _387 = NOVALUE;
    int _386 = NOVALUE;
    int _385 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1008)) {
        _1 = (long)(DBL_PTR(_id1_1008)->dbl);
        DeRefDS(_id1_1008);
        _id1_1008 = _1;
    }
    if (!IS_ATOM_INT(_id2_1009)) {
        _1 = (long)(DBL_PTR(_id2_1009)->dbl);
        DeRefDS(_id2_1009);
        _id2_1009 = _1;
    }

    /** 	return retval(data[id1] * data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _385 = (int)*(((s1_ptr)_2)->base + _id1_1008);
    _2 = (int)SEQ_PTR(_1data_751);
    _386 = (int)*(((s1_ptr)_2)->base + _id2_1009);
    if (IS_ATOM_INT(_385) && IS_ATOM_INT(_386)) {
        if (_385 == (short)_385 && _386 <= INT15 && _386 >= -INT15)
        _387 = _385 * _386;
        else
        _387 = NewDouble(_385 * (double)_386);
    }
    else {
        _387 = binary_op(MULTIPLY, _385, _386);
    }
    _385 = NOVALUE;
    _386 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1014);
    _ob_inlined_retval_at_22_1014 = _387;
    _387 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1014);
    _0 = _retval_inlined_retval_at_25_1015;
    _retval_inlined_retval_at_25_1015 = _1register_data(_ob_inlined_retval_at_22_1014);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1014);
    _ob_inlined_retval_at_22_1014 = NOVALUE;
    return _retval_inlined_retval_at_25_1015;
    ;
}
int eu_multiply() __attribute__ ((alias ("_1eu_multiply")));


int _1eu_divide(int _id1_1018, int _id2_1019)
{
    int _retval_inlined_retval_at_25_1025 = NOVALUE;
    int _ob_inlined_retval_at_22_1024 = NOVALUE;
    int _390 = NOVALUE;
    int _389 = NOVALUE;
    int _388 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1018)) {
        _1 = (long)(DBL_PTR(_id1_1018)->dbl);
        DeRefDS(_id1_1018);
        _id1_1018 = _1;
    }
    if (!IS_ATOM_INT(_id2_1019)) {
        _1 = (long)(DBL_PTR(_id2_1019)->dbl);
        DeRefDS(_id2_1019);
        _id2_1019 = _1;
    }

    /** 	return retval(data[id1] / data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _388 = (int)*(((s1_ptr)_2)->base + _id1_1018);
    _2 = (int)SEQ_PTR(_1data_751);
    _389 = (int)*(((s1_ptr)_2)->base + _id2_1019);
    if (IS_ATOM_INT(_388) && IS_ATOM_INT(_389)) {
        _390 = (_388 % _389) ? NewDouble((double)_388 / _389) : (_388 / _389);
    }
    else {
        _390 = binary_op(DIVIDE, _388, _389);
    }
    _388 = NOVALUE;
    _389 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1024);
    _ob_inlined_retval_at_22_1024 = _390;
    _390 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1024);
    _0 = _retval_inlined_retval_at_25_1025;
    _retval_inlined_retval_at_25_1025 = _1register_data(_ob_inlined_retval_at_22_1024);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1024);
    _ob_inlined_retval_at_22_1024 = NOVALUE;
    return _retval_inlined_retval_at_25_1025;
    ;
}
int eu_divide() __attribute__ ((alias ("_1eu_divide")));


int _1eu_negate(int _id_1028)
{
    int _retval_inlined_retval_at_16_1033 = NOVALUE;
    int _ob_inlined_retval_at_13_1032 = NOVALUE;
    int _392 = NOVALUE;
    int _391 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1028)) {
        _1 = (long)(DBL_PTR(_id_1028)->dbl);
        DeRefDS(_id_1028);
        _id_1028 = _1;
    }

    /** 	return retval(-data[id])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _391 = (int)*(((s1_ptr)_2)->base + _id_1028);
    if (IS_ATOM_INT(_391)) {
        if ((unsigned long)_391 == 0xC0000000)
        _392 = (int)NewDouble((double)-0xC0000000);
        else
        _392 = - _391;
    }
    else {
        _392 = unary_op(UMINUS, _391);
    }
    _391 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1032);
    _ob_inlined_retval_at_13_1032 = _392;
    _392 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1032);
    _0 = _retval_inlined_retval_at_16_1033;
    _retval_inlined_retval_at_16_1033 = _1register_data(_ob_inlined_retval_at_13_1032);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1032);
    _ob_inlined_retval_at_13_1032 = NOVALUE;
    return _retval_inlined_retval_at_16_1033;
    ;
}
int eu_negate() __attribute__ ((alias ("_1eu_negate")));


int _1eu_not(int _id_1036)
{
    int _retval_inlined_retval_at_16_1041 = NOVALUE;
    int _ob_inlined_retval_at_13_1040 = NOVALUE;
    int _394 = NOVALUE;
    int _393 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1036)) {
        _1 = (long)(DBL_PTR(_id_1036)->dbl);
        DeRefDS(_id_1036);
        _id_1036 = _1;
    }

    /** 	return retval(not data[id])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _393 = (int)*(((s1_ptr)_2)->base + _id_1036);
    if (IS_ATOM_INT(_393)) {
        _394 = (_393 == 0);
    }
    else {
        _394 = unary_op(NOT, _393);
    }
    _393 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1040);
    _ob_inlined_retval_at_13_1040 = _394;
    _394 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1040);
    _0 = _retval_inlined_retval_at_16_1041;
    _retval_inlined_retval_at_16_1041 = _1register_data(_ob_inlined_retval_at_13_1040);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1040);
    _ob_inlined_retval_at_13_1040 = NOVALUE;
    return _retval_inlined_retval_at_16_1041;
    ;
}
int eu_not() __attribute__ ((alias ("_1eu_not")));


int _1eu_equals(int _id1_1044, int _id2_1045)
{
    int _retval_inlined_retval_at_25_1051 = NOVALUE;
    int _ob_inlined_retval_at_22_1050 = NOVALUE;
    int _397 = NOVALUE;
    int _396 = NOVALUE;
    int _395 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1044)) {
        _1 = (long)(DBL_PTR(_id1_1044)->dbl);
        DeRefDS(_id1_1044);
        _id1_1044 = _1;
    }
    if (!IS_ATOM_INT(_id2_1045)) {
        _1 = (long)(DBL_PTR(_id2_1045)->dbl);
        DeRefDS(_id2_1045);
        _id2_1045 = _1;
    }

    /** 	return retval(data[id1] = data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _395 = (int)*(((s1_ptr)_2)->base + _id1_1044);
    _2 = (int)SEQ_PTR(_1data_751);
    _396 = (int)*(((s1_ptr)_2)->base + _id2_1045);
    if (IS_ATOM_INT(_395) && IS_ATOM_INT(_396)) {
        _397 = (_395 == _396);
    }
    else {
        _397 = binary_op(EQUALS, _395, _396);
    }
    _395 = NOVALUE;
    _396 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1050);
    _ob_inlined_retval_at_22_1050 = _397;
    _397 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1050);
    _0 = _retval_inlined_retval_at_25_1051;
    _retval_inlined_retval_at_25_1051 = _1register_data(_ob_inlined_retval_at_22_1050);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1050);
    _ob_inlined_retval_at_22_1050 = NOVALUE;
    return _retval_inlined_retval_at_25_1051;
    ;
}
int eu_equals() __attribute__ ((alias ("_1eu_equals")));


int _1eu_and(int _id1_1054, int _id2_1055)
{
    int _retval_inlined_retval_at_25_1061 = NOVALUE;
    int _ob_inlined_retval_at_22_1060 = NOVALUE;
    int _400 = NOVALUE;
    int _399 = NOVALUE;
    int _398 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1054)) {
        _1 = (long)(DBL_PTR(_id1_1054)->dbl);
        DeRefDS(_id1_1054);
        _id1_1054 = _1;
    }
    if (!IS_ATOM_INT(_id2_1055)) {
        _1 = (long)(DBL_PTR(_id2_1055)->dbl);
        DeRefDS(_id2_1055);
        _id2_1055 = _1;
    }

    /** 	return retval(data[id1] and data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _398 = (int)*(((s1_ptr)_2)->base + _id1_1054);
    _2 = (int)SEQ_PTR(_1data_751);
    _399 = (int)*(((s1_ptr)_2)->base + _id2_1055);
    if (IS_ATOM_INT(_398) && IS_ATOM_INT(_399)) {
        _400 = (_398 != 0 && _399 != 0);
    }
    else {
        _400 = binary_op(AND, _398, _399);
    }
    _398 = NOVALUE;
    _399 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1060);
    _ob_inlined_retval_at_22_1060 = _400;
    _400 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1060);
    _0 = _retval_inlined_retval_at_25_1061;
    _retval_inlined_retval_at_25_1061 = _1register_data(_ob_inlined_retval_at_22_1060);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1060);
    _ob_inlined_retval_at_22_1060 = NOVALUE;
    return _retval_inlined_retval_at_25_1061;
    ;
}
int eu_and() __attribute__ ((alias ("_1eu_and")));


int _1eu_or(int _id1_1064, int _id2_1065)
{
    int _retval_inlined_retval_at_25_1071 = NOVALUE;
    int _ob_inlined_retval_at_22_1070 = NOVALUE;
    int _403 = NOVALUE;
    int _402 = NOVALUE;
    int _401 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1064)) {
        _1 = (long)(DBL_PTR(_id1_1064)->dbl);
        DeRefDS(_id1_1064);
        _id1_1064 = _1;
    }
    if (!IS_ATOM_INT(_id2_1065)) {
        _1 = (long)(DBL_PTR(_id2_1065)->dbl);
        DeRefDS(_id2_1065);
        _id2_1065 = _1;
    }

    /** 	return retval(data[id1] or data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _401 = (int)*(((s1_ptr)_2)->base + _id1_1064);
    _2 = (int)SEQ_PTR(_1data_751);
    _402 = (int)*(((s1_ptr)_2)->base + _id2_1065);
    if (IS_ATOM_INT(_401) && IS_ATOM_INT(_402)) {
        _403 = (_401 != 0 || _402 != 0);
    }
    else {
        _403 = binary_op(OR, _401, _402);
    }
    _401 = NOVALUE;
    _402 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1070);
    _ob_inlined_retval_at_22_1070 = _403;
    _403 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1070);
    _0 = _retval_inlined_retval_at_25_1071;
    _retval_inlined_retval_at_25_1071 = _1register_data(_ob_inlined_retval_at_22_1070);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1070);
    _ob_inlined_retval_at_22_1070 = NOVALUE;
    return _retval_inlined_retval_at_25_1071;
    ;
}
int eu_or() __attribute__ ((alias ("_1eu_or")));


int _1eu_xor(int _id1_1074, int _id2_1075)
{
    int _retval_inlined_retval_at_25_1081 = NOVALUE;
    int _ob_inlined_retval_at_22_1080 = NOVALUE;
    int _406 = NOVALUE;
    int _405 = NOVALUE;
    int _404 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1074)) {
        _1 = (long)(DBL_PTR(_id1_1074)->dbl);
        DeRefDS(_id1_1074);
        _id1_1074 = _1;
    }
    if (!IS_ATOM_INT(_id2_1075)) {
        _1 = (long)(DBL_PTR(_id2_1075)->dbl);
        DeRefDS(_id2_1075);
        _id2_1075 = _1;
    }

    /** 	return retval(data[id1] xor data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _404 = (int)*(((s1_ptr)_2)->base + _id1_1074);
    _2 = (int)SEQ_PTR(_1data_751);
    _405 = (int)*(((s1_ptr)_2)->base + _id2_1075);
    if (IS_ATOM_INT(_404) && IS_ATOM_INT(_405)) {
        _406 = ((_404 != 0) != (_405 != 0));
    }
    else {
        _406 = binary_op(XOR, _404, _405);
    }
    _404 = NOVALUE;
    _405 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1080);
    _ob_inlined_retval_at_22_1080 = _406;
    _406 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1080);
    _0 = _retval_inlined_retval_at_25_1081;
    _retval_inlined_retval_at_25_1081 = _1register_data(_ob_inlined_retval_at_22_1080);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1080);
    _ob_inlined_retval_at_22_1080 = NOVALUE;
    return _retval_inlined_retval_at_25_1081;
    ;
}
int eu_xor() __attribute__ ((alias ("_1eu_xor")));


void _1eu_question_mark(int _id_1084)
{
    int _407 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1084)) {
        _1 = (long)(DBL_PTR(_id_1084)->dbl);
        DeRefDS(_id_1084);
        _id_1084 = _1;
    }

    /** 	? data[id]*/
    _2 = (int)SEQ_PTR(_1data_751);
    _407 = (int)*(((s1_ptr)_2)->base + _id_1084);
    StdPrint(1, _407, 1);
    _407 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_question_mark() __attribute__ ((alias ("_1eu_question_mark")));


void _1eu_abort(int _ret_1088)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_1088)) {
        _1 = (long)(DBL_PTR(_ret_1088)->dbl);
        DeRefDS(_ret_1088);
        _ret_1088 = _1;
    }

    /** 	abort(ret)*/
    UserCleanup(_ret_1088);

    /** end procedure*/
    return;
    ;
}
void eu_abort() __attribute__ ((alias ("_1eu_abort")));


int _1eu_and_bits(int _id1_1091, int _id2_1092)
{
    int _retval_inlined_retval_at_25_1098 = NOVALUE;
    int _ob_inlined_retval_at_22_1097 = NOVALUE;
    int _410 = NOVALUE;
    int _409 = NOVALUE;
    int _408 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1091)) {
        _1 = (long)(DBL_PTR(_id1_1091)->dbl);
        DeRefDS(_id1_1091);
        _id1_1091 = _1;
    }
    if (!IS_ATOM_INT(_id2_1092)) {
        _1 = (long)(DBL_PTR(_id2_1092)->dbl);
        DeRefDS(_id2_1092);
        _id2_1092 = _1;
    }

    /** 	return retval(and_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _408 = (int)*(((s1_ptr)_2)->base + _id1_1091);
    _2 = (int)SEQ_PTR(_1data_751);
    _409 = (int)*(((s1_ptr)_2)->base + _id2_1092);
    if (IS_ATOM_INT(_408) && IS_ATOM_INT(_409)) {
        {unsigned long tu;
             tu = (unsigned long)_408 & (unsigned long)_409;
             _410 = MAKE_UINT(tu);
        }
    }
    else {
        _410 = binary_op(AND_BITS, _408, _409);
    }
    _408 = NOVALUE;
    _409 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1097);
    _ob_inlined_retval_at_22_1097 = _410;
    _410 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1097);
    _0 = _retval_inlined_retval_at_25_1098;
    _retval_inlined_retval_at_25_1098 = _1register_data(_ob_inlined_retval_at_22_1097);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1097);
    _ob_inlined_retval_at_22_1097 = NOVALUE;
    return _retval_inlined_retval_at_25_1098;
    ;
}
int eu_and_bits() __attribute__ ((alias ("_1eu_and_bits")));


int _1eu_append(int _id1_1101, int _id2_1102)
{
    int _retval_inlined_retval_at_25_1108 = NOVALUE;
    int _ob_inlined_retval_at_22_1107 = NOVALUE;
    int _413 = NOVALUE;
    int _412 = NOVALUE;
    int _411 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1101)) {
        _1 = (long)(DBL_PTR(_id1_1101)->dbl);
        DeRefDS(_id1_1101);
        _id1_1101 = _1;
    }
    if (!IS_ATOM_INT(_id2_1102)) {
        _1 = (long)(DBL_PTR(_id2_1102)->dbl);
        DeRefDS(_id2_1102);
        _id2_1102 = _1;
    }

    /** 	return retval(append(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _411 = (int)*(((s1_ptr)_2)->base + _id1_1101);
    _2 = (int)SEQ_PTR(_1data_751);
    _412 = (int)*(((s1_ptr)_2)->base + _id2_1102);
    Ref(_412);
    Append(&_413, _411, _412);
    _411 = NOVALUE;
    _412 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1107);
    _ob_inlined_retval_at_22_1107 = _413;
    _413 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1107);
    _0 = _retval_inlined_retval_at_25_1108;
    _retval_inlined_retval_at_25_1108 = _1register_data(_ob_inlined_retval_at_22_1107);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1107);
    _ob_inlined_retval_at_22_1107 = NOVALUE;
    return _retval_inlined_retval_at_25_1108;
    ;
}
int eu_append() __attribute__ ((alias ("_1eu_append")));


int _1eu_arctan(int _id_1111)
{
    int _retval_inlined_retval_at_16_1116 = NOVALUE;
    int _ob_inlined_retval_at_13_1115 = NOVALUE;
    int _415 = NOVALUE;
    int _414 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1111)) {
        _1 = (long)(DBL_PTR(_id_1111)->dbl);
        DeRefDS(_id_1111);
        _id_1111 = _1;
    }

    /** 	return retval(arctan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _414 = (int)*(((s1_ptr)_2)->base + _id_1111);
    if (IS_ATOM_INT(_414))
    _415 = e_arctan(_414);
    else
    _415 = unary_op(ARCTAN, _414);
    _414 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1115);
    _ob_inlined_retval_at_13_1115 = _415;
    _415 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1115);
    _0 = _retval_inlined_retval_at_16_1116;
    _retval_inlined_retval_at_16_1116 = _1register_data(_ob_inlined_retval_at_13_1115);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1115);
    _ob_inlined_retval_at_13_1115 = NOVALUE;
    return _retval_inlined_retval_at_16_1116;
    ;
}
int eu_arctan() __attribute__ ((alias ("_1eu_arctan")));


int _1eu_atom(int _id_1119)
{
    int _417 = NOVALUE;
    int _416 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1119)) {
        _1 = (long)(DBL_PTR(_id_1119)->dbl);
        DeRefDS(_id_1119);
        _id_1119 = _1;
    }

    /** 	return atom(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_751);
    _416 = (int)*(((s1_ptr)_2)->base + _id_1119);
    _417 = IS_ATOM(_416);
    _416 = NOVALUE;
    return _417;
    ;
}
int eu_atom() __attribute__ ((alias ("_1eu_atom")));


int _1eu_c_func(int _rid_1124, int _id1_1125)
{
    int _retval_inlined_retval_at_20_1130 = NOVALUE;
    int _ob_inlined_retval_at_17_1129 = NOVALUE;
    int _419 = NOVALUE;
    int _418 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1124)) {
        _1 = (long)(DBL_PTR(_rid_1124)->dbl);
        DeRefDS(_rid_1124);
        _rid_1124 = _1;
    }
    if (!IS_ATOM_INT(_id1_1125)) {
        _1 = (long)(DBL_PTR(_id1_1125)->dbl);
        DeRefDS(_id1_1125);
        _id1_1125 = _1;
    }

    /** 	return retval(c_func(rid, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _418 = (int)*(((s1_ptr)_2)->base + _id1_1125);
    _419 = call_c(1, _rid_1124, _418);
    _418 = NOVALUE;
    DeRef(_ob_inlined_retval_at_17_1129);
    _ob_inlined_retval_at_17_1129 = _419;
    _419 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_17_1129);
    _0 = _retval_inlined_retval_at_20_1130;
    _retval_inlined_retval_at_20_1130 = _1register_data(_ob_inlined_retval_at_17_1129);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_17_1129);
    _ob_inlined_retval_at_17_1129 = NOVALUE;
    return _retval_inlined_retval_at_20_1130;
    ;
}
int eu_c_func() __attribute__ ((alias ("_1eu_c_func")));


void _1eu_c_proc(int _rid_1133, int _id1_1134)
{
    int _420 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1133)) {
        _1 = (long)(DBL_PTR(_rid_1133)->dbl);
        DeRefDS(_rid_1133);
        _rid_1133 = _1;
    }
    if (!IS_ATOM_INT(_id1_1134)) {
        _1 = (long)(DBL_PTR(_id1_1134)->dbl);
        DeRefDS(_id1_1134);
        _id1_1134 = _1;
    }

    /** 	c_proc(rid, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _420 = (int)*(((s1_ptr)_2)->base + _id1_1134);
    call_c(0, _rid_1133, _420);
    _420 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_c_proc() __attribute__ ((alias ("_1eu_c_proc")));


void _1eu_call(int _low_1138, int _high_1139)
{
    int _get_address_1__tmp_at6_1142 = NOVALUE;
    int _get_address_inlined_get_address_at_6_1141 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1138)) {
        _1 = (long)(DBL_PTR(_low_1138)->dbl);
        DeRefDS(_low_1138);
        _low_1138 = _1;
    }
    if (!IS_ATOM_INT(_high_1139)) {
        _1 = (long)(DBL_PTR(_high_1139)->dbl);
        DeRefDS(_high_1139);
        _high_1139 = _1;
    }

    /** 	call(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_1142);
    _get_address_1__tmp_at6_1142 = NewDouble(_high_1139 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_1141);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_1142)) {
        _get_address_inlined_get_address_at_6_1141 = _get_address_1__tmp_at6_1142 + _low_1138;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_1141 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_1141 = NewDouble((double)_get_address_inlined_get_address_at_6_1141);
    }
    else {
        _get_address_inlined_get_address_at_6_1141 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_1142)->dbl + (double)_low_1138);
    }
    DeRef(_get_address_1__tmp_at6_1142);
    _get_address_1__tmp_at6_1142 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_1141))
    _0 = (int)_get_address_inlined_get_address_at_6_1141;
    else
    _0 = (int)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_1141)->dbl);
    (*(void(*)())_0)();

    /** end procedure*/
    return;
    ;
}
void eu_call() __attribute__ ((alias ("_1eu_call")));


void _1eu_clear_screen()
{
    int _0, _1, _2;
    

    /** 	clear_screen()*/
    ClearScreen();

    /** end procedure*/
    return;
    ;
}
void eu_clear_screen() __attribute__ ((alias ("_1eu_clear_screen")));


void _1eu_close(int _fn_id_1147)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1147)) {
        _1 = (long)(DBL_PTR(_fn_id_1147)->dbl);
        DeRefDS(_fn_id_1147);
        _fn_id_1147 = _1;
    }

    /** 	close(fn_id)*/
    EClose(_fn_id_1147);

    /** end procedure*/
    return;
    ;
}
void eu_close() __attribute__ ((alias ("_1eu_close")));


int _1eu_command_line()
{
    int _retval_inlined_retval_at_7_1153 = NOVALUE;
    int _ob_inlined_retval_at_4_1152 = NOVALUE;
    int _421 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(command_line())*/
    _421 = Command_Line();
    DeRef(_ob_inlined_retval_at_4_1152);
    _ob_inlined_retval_at_4_1152 = _421;
    _421 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1152);
    _0 = _retval_inlined_retval_at_7_1153;
    _retval_inlined_retval_at_7_1153 = _1register_data(_ob_inlined_retval_at_4_1152);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_1152);
    _ob_inlined_retval_at_4_1152 = NOVALUE;
    return _retval_inlined_retval_at_7_1153;
    ;
}
int eu_command_line() __attribute__ ((alias ("_1eu_command_line")));


int _1eu_compare(int _id1_1156, int _id2_1157)
{
    int _424 = NOVALUE;
    int _423 = NOVALUE;
    int _422 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1156)) {
        _1 = (long)(DBL_PTR(_id1_1156)->dbl);
        DeRefDS(_id1_1156);
        _id1_1156 = _1;
    }
    if (!IS_ATOM_INT(_id2_1157)) {
        _1 = (long)(DBL_PTR(_id2_1157)->dbl);
        DeRefDS(_id2_1157);
        _id2_1157 = _1;
    }

    /** 	return compare(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _422 = (int)*(((s1_ptr)_2)->base + _id1_1156);
    _2 = (int)SEQ_PTR(_1data_751);
    _423 = (int)*(((s1_ptr)_2)->base + _id2_1157);
    if (IS_ATOM_INT(_422) && IS_ATOM_INT(_423)){
        _424 = (_422 < _423) ? -1 : (_422 > _423);
    }
    else{
        _424 = compare(_422, _423);
    }
    _422 = NOVALUE;
    _423 = NOVALUE;
    return _424;
    ;
}
int eu_compare() __attribute__ ((alias ("_1eu_compare")));


int _1eu_concat(int _id1_1163, int _id2_1164)
{
    int _retval_inlined_retval_at_25_1170 = NOVALUE;
    int _ob_inlined_retval_at_22_1169 = NOVALUE;
    int _427 = NOVALUE;
    int _426 = NOVALUE;
    int _425 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1163)) {
        _1 = (long)(DBL_PTR(_id1_1163)->dbl);
        DeRefDS(_id1_1163);
        _id1_1163 = _1;
    }
    if (!IS_ATOM_INT(_id2_1164)) {
        _1 = (long)(DBL_PTR(_id2_1164)->dbl);
        DeRefDS(_id2_1164);
        _id2_1164 = _1;
    }

    /** 	return retval(data[id1] & data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _425 = (int)*(((s1_ptr)_2)->base + _id1_1163);
    _2 = (int)SEQ_PTR(_1data_751);
    _426 = (int)*(((s1_ptr)_2)->base + _id2_1164);
    if (IS_SEQUENCE(_425) && IS_ATOM(_426)) {
        Ref(_426);
        Append(&_427, _425, _426);
    }
    else if (IS_ATOM(_425) && IS_SEQUENCE(_426)) {
        Ref(_425);
        Prepend(&_427, _426, _425);
    }
    else {
        Concat((object_ptr)&_427, _425, _426);
        _425 = NOVALUE;
    }
    _425 = NOVALUE;
    _426 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1169);
    _ob_inlined_retval_at_22_1169 = _427;
    _427 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1169);
    _0 = _retval_inlined_retval_at_25_1170;
    _retval_inlined_retval_at_25_1170 = _1register_data(_ob_inlined_retval_at_22_1169);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1169);
    _ob_inlined_retval_at_22_1169 = NOVALUE;
    return _retval_inlined_retval_at_25_1170;
    ;
}
int eu_concat() __attribute__ ((alias ("_1eu_concat")));


int _1eu_cos(int _id_1173)
{
    int _retval_inlined_retval_at_16_1178 = NOVALUE;
    int _ob_inlined_retval_at_13_1177 = NOVALUE;
    int _429 = NOVALUE;
    int _428 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1173)) {
        _1 = (long)(DBL_PTR(_id_1173)->dbl);
        DeRefDS(_id_1173);
        _id_1173 = _1;
    }

    /** 	return retval(cos(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _428 = (int)*(((s1_ptr)_2)->base + _id_1173);
    if (IS_ATOM_INT(_428))
    _429 = e_cos(_428);
    else
    _429 = unary_op(COS, _428);
    _428 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1177);
    _ob_inlined_retval_at_13_1177 = _429;
    _429 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1177);
    _0 = _retval_inlined_retval_at_16_1178;
    _retval_inlined_retval_at_16_1178 = _1register_data(_ob_inlined_retval_at_13_1177);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1177);
    _ob_inlined_retval_at_13_1177 = NOVALUE;
    return _retval_inlined_retval_at_16_1178;
    ;
}
int eu_cos() __attribute__ ((alias ("_1eu_cos")));


int _1eu_date()
{
    int _retval_inlined_retval_at_7_1184 = NOVALUE;
    int _ob_inlined_retval_at_4_1183 = NOVALUE;
    int _430 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(date())*/
    _430 = Date();
    DeRefi(_ob_inlined_retval_at_4_1183);
    _ob_inlined_retval_at_4_1183 = _430;
    _430 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1183);
    _0 = _retval_inlined_retval_at_7_1184;
    _retval_inlined_retval_at_7_1184 = _1register_data(_ob_inlined_retval_at_4_1183);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_4_1183);
    _ob_inlined_retval_at_4_1183 = NOVALUE;
    return _retval_inlined_retval_at_7_1184;
    ;
}
int eu_date() __attribute__ ((alias ("_1eu_date")));


int _1eu_equal(int _id1_1187, int _id2_1188)
{
    int _433 = NOVALUE;
    int _432 = NOVALUE;
    int _431 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1187)) {
        _1 = (long)(DBL_PTR(_id1_1187)->dbl);
        DeRefDS(_id1_1187);
        _id1_1187 = _1;
    }
    if (!IS_ATOM_INT(_id2_1188)) {
        _1 = (long)(DBL_PTR(_id2_1188)->dbl);
        DeRefDS(_id2_1188);
        _id2_1188 = _1;
    }

    /** 	return equal(data[id1], data[id2]) -- boolean, returns 0 or 1*/
    _2 = (int)SEQ_PTR(_1data_751);
    _431 = (int)*(((s1_ptr)_2)->base + _id1_1187);
    _2 = (int)SEQ_PTR(_1data_751);
    _432 = (int)*(((s1_ptr)_2)->base + _id2_1188);
    if (_431 == _432)
    _433 = 1;
    else if (IS_ATOM_INT(_431) && IS_ATOM_INT(_432))
    _433 = 0;
    else
    _433 = (compare(_431, _432) == 0);
    _431 = NOVALUE;
    _432 = NOVALUE;
    return _433;
    ;
}
int eu_equal() __attribute__ ((alias ("_1eu_equal")));


int _1eu_find_from(int _id1_1194, int _id2_1195, int _start_1196)
{
    int _436 = NOVALUE;
    int _435 = NOVALUE;
    int _434 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1194)) {
        _1 = (long)(DBL_PTR(_id1_1194)->dbl);
        DeRefDS(_id1_1194);
        _id1_1194 = _1;
    }
    if (!IS_ATOM_INT(_id2_1195)) {
        _1 = (long)(DBL_PTR(_id2_1195)->dbl);
        DeRefDS(_id2_1195);
        _id2_1195 = _1;
    }
    if (!IS_ATOM_INT(_start_1196)) {
        _1 = (long)(DBL_PTR(_start_1196)->dbl);
        DeRefDS(_start_1196);
        _start_1196 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _434 = (int)*(((s1_ptr)_2)->base + _id1_1194);
    _2 = (int)SEQ_PTR(_1data_751);
    _435 = (int)*(((s1_ptr)_2)->base + _id2_1195);
    _436 = find_from(_434, _435, _start_1196);
    _434 = NOVALUE;
    _435 = NOVALUE;
    return _436;
    ;
}
int eu_find_from() __attribute__ ((alias ("_1eu_find_from")));


int _1eu_find(int _id1_1202, int _id2_1203, int _start_1204)
{
    int _439 = NOVALUE;
    int _438 = NOVALUE;
    int _437 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1202)) {
        _1 = (long)(DBL_PTR(_id1_1202)->dbl);
        DeRefDS(_id1_1202);
        _id1_1202 = _1;
    }
    if (!IS_ATOM_INT(_id2_1203)) {
        _1 = (long)(DBL_PTR(_id2_1203)->dbl);
        DeRefDS(_id2_1203);
        _id2_1203 = _1;
    }
    if (!IS_ATOM_INT(_start_1204)) {
        _1 = (long)(DBL_PTR(_start_1204)->dbl);
        DeRefDS(_start_1204);
        _start_1204 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _437 = (int)*(((s1_ptr)_2)->base + _id1_1202);
    _2 = (int)SEQ_PTR(_1data_751);
    _438 = (int)*(((s1_ptr)_2)->base + _id2_1203);
    _439 = find_from(_437, _438, _start_1204);
    _437 = NOVALUE;
    _438 = NOVALUE;
    return _439;
    ;
}
int eu_find() __attribute__ ((alias ("_1eu_find")));


int _1eu_floor(int _id1_1210)
{
    int _retval_inlined_retval_at_16_1215 = NOVALUE;
    int _ob_inlined_retval_at_13_1214 = NOVALUE;
    int _441 = NOVALUE;
    int _440 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1210)) {
        _1 = (long)(DBL_PTR(_id1_1210)->dbl);
        DeRefDS(_id1_1210);
        _id1_1210 = _1;
    }

    /** 	return retval(floor(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _440 = (int)*(((s1_ptr)_2)->base + _id1_1210);
    if (IS_ATOM_INT(_440))
    _441 = e_floor(_440);
    else
    _441 = unary_op(FLOOR, _440);
    _440 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1214);
    _ob_inlined_retval_at_13_1214 = _441;
    _441 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1214);
    _0 = _retval_inlined_retval_at_16_1215;
    _retval_inlined_retval_at_16_1215 = _1register_data(_ob_inlined_retval_at_13_1214);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1214);
    _ob_inlined_retval_at_13_1214 = NOVALUE;
    return _retval_inlined_retval_at_16_1215;
    ;
}
int eu_floor() __attribute__ ((alias ("_1eu_floor")));


int _1eu_integer_division(int _id1_1218, int _id2_1219)
{
    int _retval_inlined_retval_at_25_1225 = NOVALUE;
    int _ob_inlined_retval_at_22_1224 = NOVALUE;
    int _444 = NOVALUE;
    int _443 = NOVALUE;
    int _442 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1218)) {
        _1 = (long)(DBL_PTR(_id1_1218)->dbl);
        DeRefDS(_id1_1218);
        _id1_1218 = _1;
    }
    if (!IS_ATOM_INT(_id2_1219)) {
        _1 = (long)(DBL_PTR(_id2_1219)->dbl);
        DeRefDS(_id2_1219);
        _id2_1219 = _1;
    }

    /** 	return retval(floor(data[id1] / data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _442 = (int)*(((s1_ptr)_2)->base + _id1_1218);
    _2 = (int)SEQ_PTR(_1data_751);
    _443 = (int)*(((s1_ptr)_2)->base + _id2_1219);
    if (IS_ATOM_INT(_442) && IS_ATOM_INT(_443)) {
        if (_443 > 0 && _442 >= 0) {
            _444 = _442 / _443;
        }
        else {
            temp_dbl = floor((double)_442 / (double)_443);
            if (_442 != MININT)
            _444 = (long)temp_dbl;
            else
            _444 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _442, _443);
        _444 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _442 = NOVALUE;
    _443 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1224);
    _ob_inlined_retval_at_22_1224 = _444;
    _444 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1224);
    _0 = _retval_inlined_retval_at_25_1225;
    _retval_inlined_retval_at_25_1225 = _1register_data(_ob_inlined_retval_at_22_1224);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1224);
    _ob_inlined_retval_at_22_1224 = NOVALUE;
    return _retval_inlined_retval_at_25_1225;
    ;
}
int eu_integer_division() __attribute__ ((alias ("_1eu_integer_division")));


int _1eu_get_key()
{
    int _445 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return get_key() -- returns an integer*/
    _445 = get_key(0);
    return _445;
    ;
}
int eu_get_key() __attribute__ ((alias ("_1eu_get_key")));


int _1eu_getc(int _fn_id_1231)
{
    int _446 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1231)) {
        _1 = (long)(DBL_PTR(_fn_id_1231)->dbl);
        DeRefDS(_fn_id_1231);
        _fn_id_1231 = _1;
    }

    /** 	return getc(fn_id) -- returns a character or byte*/
    if (_fn_id_1231 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id_1231, EF_READ);
        last_r_file_no = _fn_id_1231;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _446 = getc((FILE*)xstdin);
        }
        else
        _446 = getc(last_r_file_ptr);
    }
    else
    _446 = getc(last_r_file_ptr);
    return _446;
    ;
}
int eu_getc() __attribute__ ((alias ("_1eu_getc")));


int _1eu_getenv(int _id1_1235)
{
    int _retval_inlined_retval_at_16_1240 = NOVALUE;
    int _ob_inlined_retval_at_13_1239 = NOVALUE;
    int _448 = NOVALUE;
    int _447 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1235)) {
        _1 = (long)(DBL_PTR(_id1_1235)->dbl);
        DeRefDS(_id1_1235);
        _id1_1235 = _1;
    }

    /** 	return retval(getenv(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _447 = (int)*(((s1_ptr)_2)->base + _id1_1235);
    _448 = EGetEnv(_447);
    _447 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_13_1239);
    _ob_inlined_retval_at_13_1239 = _448;
    _448 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1239);
    _0 = _retval_inlined_retval_at_16_1240;
    _retval_inlined_retval_at_16_1240 = _1register_data(_ob_inlined_retval_at_13_1239);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_13_1239);
    _ob_inlined_retval_at_13_1239 = NOVALUE;
    return _retval_inlined_retval_at_16_1240;
    ;
}
int eu_getenv() __attribute__ ((alias ("_1eu_getenv")));


int _1eu_gets(int _fn_id_1243)
{
    int _retval_inlined_retval_at_10_1247 = NOVALUE;
    int _ob_inlined_retval_at_7_1246 = NOVALUE;
    int _449 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1243)) {
        _1 = (long)(DBL_PTR(_fn_id_1243)->dbl);
        DeRefDS(_fn_id_1243);
        _fn_id_1243 = _1;
    }

    /** 	return retval(gets(fn_id))*/
    _449 = EGets(_fn_id_1243);
    DeRefi(_ob_inlined_retval_at_7_1246);
    _ob_inlined_retval_at_7_1246 = _449;
    _449 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_7_1246);
    _0 = _retval_inlined_retval_at_10_1247;
    _retval_inlined_retval_at_10_1247 = _1register_data(_ob_inlined_retval_at_7_1246);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_7_1246);
    _ob_inlined_retval_at_7_1246 = NOVALUE;
    return _retval_inlined_retval_at_10_1247;
    ;
}
int eu_gets() __attribute__ ((alias ("_1eu_gets")));


int _1eu_integer(int _id_1250)
{
    int _451 = NOVALUE;
    int _450 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1250)) {
        _1 = (long)(DBL_PTR(_id_1250)->dbl);
        DeRefDS(_id_1250);
        _id_1250 = _1;
    }

    /** 	return integer(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_751);
    _450 = (int)*(((s1_ptr)_2)->base + _id_1250);
    if (IS_ATOM_INT(_450))
    _451 = 1;
    else if (IS_ATOM_DBL(_450))
    _451 = IS_ATOM_INT(DoubleToInt(_450));
    else
    _451 = 0;
    _450 = NOVALUE;
    return _451;
    ;
}
int eu_integer() __attribute__ ((alias ("_1eu_integer")));


int _1eu_length(int _id_1255)
{
    int _453 = NOVALUE;
    int _452 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1255)) {
        _1 = (long)(DBL_PTR(_id_1255)->dbl);
        DeRefDS(_id_1255);
        _id_1255 = _1;
    }

    /** 	return length(data[id]) -- small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _452 = (int)*(((s1_ptr)_2)->base + _id_1255);
    if (IS_SEQUENCE(_452)){
            _453 = SEQ_PTR(_452)->length;
    }
    else {
        _453 = 1;
    }
    _452 = NOVALUE;
    _452 = NOVALUE;
    return _453;
    ;
}
int eu_length() __attribute__ ((alias ("_1eu_length")));


int _1eu_log(int _id_1260)
{
    int _retval_inlined_retval_at_16_1265 = NOVALUE;
    int _ob_inlined_retval_at_13_1264 = NOVALUE;
    int _455 = NOVALUE;
    int _454 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1260)) {
        _1 = (long)(DBL_PTR(_id_1260)->dbl);
        DeRefDS(_id_1260);
        _id_1260 = _1;
    }

    /** 	return retval(log(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _454 = (int)*(((s1_ptr)_2)->base + _id_1260);
    if (IS_ATOM_INT(_454))
    _455 = e_log(_454);
    else
    _455 = unary_op(LOG, _454);
    _454 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1264);
    _ob_inlined_retval_at_13_1264 = _455;
    _455 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1264);
    _0 = _retval_inlined_retval_at_16_1265;
    _retval_inlined_retval_at_16_1265 = _1register_data(_ob_inlined_retval_at_13_1264);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1264);
    _ob_inlined_retval_at_13_1264 = NOVALUE;
    return _retval_inlined_retval_at_16_1265;
    ;
}
int eu_log() __attribute__ ((alias ("_1eu_log")));


int _1eu_machine_func(int _machine_id_1268, int _id1_1269)
{
    int _retval_inlined_retval_at_19_1274 = NOVALUE;
    int _ob_inlined_retval_at_16_1273 = NOVALUE;
    int _457 = NOVALUE;
    int _456 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_1268)) {
        _1 = (long)(DBL_PTR(_machine_id_1268)->dbl);
        DeRefDS(_machine_id_1268);
        _machine_id_1268 = _1;
    }
    if (!IS_ATOM_INT(_id1_1269)) {
        _1 = (long)(DBL_PTR(_id1_1269)->dbl);
        DeRefDS(_id1_1269);
        _id1_1269 = _1;
    }

    /** 	return retval(machine_func(machine_id, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _456 = (int)*(((s1_ptr)_2)->base + _id1_1269);
    _457 = machine(_machine_id_1268, _456);
    _456 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1273);
    _ob_inlined_retval_at_16_1273 = _457;
    _457 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1273);
    _0 = _retval_inlined_retval_at_19_1274;
    _retval_inlined_retval_at_19_1274 = _1register_data(_ob_inlined_retval_at_16_1273);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1273);
    _ob_inlined_retval_at_16_1273 = NOVALUE;
    return _retval_inlined_retval_at_19_1274;
    ;
}
int eu_machine_func() __attribute__ ((alias ("_1eu_machine_func")));


void _1eu_machine_proc(int _machine_id_1277, int _id1_1278)
{
    int _458 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_1277)) {
        _1 = (long)(DBL_PTR(_machine_id_1277)->dbl);
        DeRefDS(_machine_id_1277);
        _machine_id_1277 = _1;
    }
    if (!IS_ATOM_INT(_id1_1278)) {
        _1 = (long)(DBL_PTR(_id1_1278)->dbl);
        DeRefDS(_id1_1278);
        _id1_1278 = _1;
    }

    /** 	machine_proc(machine_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _458 = (int)*(((s1_ptr)_2)->base + _id1_1278);
    machine(_machine_id_1277, _458);
    _458 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_machine_proc() __attribute__ ((alias ("_1eu_machine_proc")));


int _1eu_match_from(int _id1_1282, int _id2_1283, int _start_1284)
{
    int _461 = NOVALUE;
    int _460 = NOVALUE;
    int _459 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1282)) {
        _1 = (long)(DBL_PTR(_id1_1282)->dbl);
        DeRefDS(_id1_1282);
        _id1_1282 = _1;
    }
    if (!IS_ATOM_INT(_id2_1283)) {
        _1 = (long)(DBL_PTR(_id2_1283)->dbl);
        DeRefDS(_id2_1283);
        _id2_1283 = _1;
    }
    if (!IS_ATOM_INT(_start_1284)) {
        _1 = (long)(DBL_PTR(_start_1284)->dbl);
        DeRefDS(_start_1284);
        _start_1284 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _459 = (int)*(((s1_ptr)_2)->base + _id1_1282);
    _2 = (int)SEQ_PTR(_1data_751);
    _460 = (int)*(((s1_ptr)_2)->base + _id2_1283);
    _461 = e_match_from(_459, _460, _start_1284);
    _459 = NOVALUE;
    _460 = NOVALUE;
    return _461;
    ;
}
int eu_match_from() __attribute__ ((alias ("_1eu_match_from")));


int _1eu_match(int _id1_1290, int _id2_1291, int _start_1292)
{
    int _464 = NOVALUE;
    int _463 = NOVALUE;
    int _462 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1290)) {
        _1 = (long)(DBL_PTR(_id1_1290)->dbl);
        DeRefDS(_id1_1290);
        _id1_1290 = _1;
    }
    if (!IS_ATOM_INT(_id2_1291)) {
        _1 = (long)(DBL_PTR(_id2_1291)->dbl);
        DeRefDS(_id2_1291);
        _id2_1291 = _1;
    }
    if (!IS_ATOM_INT(_start_1292)) {
        _1 = (long)(DBL_PTR(_start_1292)->dbl);
        DeRefDS(_start_1292);
        _start_1292 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _462 = (int)*(((s1_ptr)_2)->base + _id1_1290);
    _2 = (int)SEQ_PTR(_1data_751);
    _463 = (int)*(((s1_ptr)_2)->base + _id2_1291);
    _464 = e_match_from(_462, _463, _start_1292);
    _462 = NOVALUE;
    _463 = NOVALUE;
    return _464;
    ;
}
int eu_match() __attribute__ ((alias ("_1eu_match")));


int _1eu_not_bits(int _id1_1298)
{
    int _retval_inlined_retval_at_16_1303 = NOVALUE;
    int _ob_inlined_retval_at_13_1302 = NOVALUE;
    int _466 = NOVALUE;
    int _465 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1298)) {
        _1 = (long)(DBL_PTR(_id1_1298)->dbl);
        DeRefDS(_id1_1298);
        _id1_1298 = _1;
    }

    /** 	return retval(not_bits(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _465 = (int)*(((s1_ptr)_2)->base + _id1_1298);
    if (IS_ATOM_INT(_465))
    _466 = not_bits(_465);
    else
    _466 = unary_op(NOT_BITS, _465);
    _465 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1302);
    _ob_inlined_retval_at_13_1302 = _466;
    _466 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1302);
    _0 = _retval_inlined_retval_at_16_1303;
    _retval_inlined_retval_at_16_1303 = _1register_data(_ob_inlined_retval_at_13_1302);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1302);
    _ob_inlined_retval_at_13_1302 = NOVALUE;
    return _retval_inlined_retval_at_16_1303;
    ;
}
int eu_not_bits() __attribute__ ((alias ("_1eu_not_bits")));


int _1eu_object(int _id_1306)
{
    int _468 = NOVALUE;
    int _467 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1306)) {
        _1 = (long)(DBL_PTR(_id_1306)->dbl);
        DeRefDS(_id_1306);
        _id_1306 = _1;
    }

    /** 	return not find(id, free_list)*/
    _467 = find_from(_id_1306, _1free_list_752, 1);
    _468 = (_467 == 0);
    _467 = NOVALUE;
    return _468;
    ;
}
int eu_object() __attribute__ ((alias ("_1eu_object")));


int _1eu_open(int _id1_1311, int _id2_1312)
{
    int _471 = NOVALUE;
    int _470 = NOVALUE;
    int _469 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1311)) {
        _1 = (long)(DBL_PTR(_id1_1311)->dbl);
        DeRefDS(_id1_1311);
        _id1_1311 = _1;
    }
    if (!IS_ATOM_INT(_id2_1312)) {
        _1 = (long)(DBL_PTR(_id2_1312)->dbl);
        DeRefDS(_id2_1312);
        _id2_1312 = _1;
    }

    /** 	return open(data[id1], data[id2]) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_751);
    _469 = (int)*(((s1_ptr)_2)->base + _id1_1311);
    _2 = (int)SEQ_PTR(_1data_751);
    _470 = (int)*(((s1_ptr)_2)->base + _id2_1312);
    _471 = EOpen(_469, _470, 0);
    _469 = NOVALUE;
    _470 = NOVALUE;
    return _471;
    ;
}
int eu_open() __attribute__ ((alias ("_1eu_open")));


int _1eu_open_str(int _low_1318, int _high_1319, int _did_1320)
{
    int _get_address_1__tmp_at8_1323 = NOVALUE;
    int _get_address_inlined_get_address_at_8_1322 = NOVALUE;
    int _474 = NOVALUE;
    int _473 = NOVALUE;
    int _472 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1318)) {
        _1 = (long)(DBL_PTR(_low_1318)->dbl);
        DeRefDS(_low_1318);
        _low_1318 = _1;
    }
    if (!IS_ATOM_INT(_high_1319)) {
        _1 = (long)(DBL_PTR(_high_1319)->dbl);
        DeRefDS(_high_1319);
        _high_1319 = _1;
    }
    if (!IS_ATOM_INT(_did_1320)) {
        _1 = (long)(DBL_PTR(_did_1320)->dbl);
        DeRefDS(_did_1320);
        _did_1320 = _1;
    }

    /** 	return open(peek_string(get_address(low, high)), data[did])*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_1323);
    _get_address_1__tmp_at8_1323 = NewDouble(_high_1319 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_8_1322);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_1323)) {
        _get_address_inlined_get_address_at_8_1322 = _get_address_1__tmp_at8_1323 + _low_1318;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_8_1322 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_8_1322 = NewDouble((double)_get_address_inlined_get_address_at_8_1322);
    }
    else {
        _get_address_inlined_get_address_at_8_1322 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_1323)->dbl + (double)_low_1318);
    }
    DeRef(_get_address_1__tmp_at8_1323);
    _get_address_1__tmp_at8_1323 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_8_1322)) {
        _472 =  NewString((char *)_get_address_inlined_get_address_at_8_1322);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_8_1322)) {
        _472 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_8_1322)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_8_1322);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _472 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _2 = (int)SEQ_PTR(_1data_751);
    _473 = (int)*(((s1_ptr)_2)->base + _did_1320);
    _474 = EOpen(_472, _473, 0);
    DeRef(_472);
    _472 = NOVALUE;
    _473 = NOVALUE;
    return _474;
    ;
}
int eu_open_str() __attribute__ ((alias ("_1eu_open_str")));


int _1eu_or_bits(int _id1_1329, int _id2_1330)
{
    int _retval_inlined_retval_at_25_1336 = NOVALUE;
    int _ob_inlined_retval_at_22_1335 = NOVALUE;
    int _477 = NOVALUE;
    int _476 = NOVALUE;
    int _475 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1329)) {
        _1 = (long)(DBL_PTR(_id1_1329)->dbl);
        DeRefDS(_id1_1329);
        _id1_1329 = _1;
    }
    if (!IS_ATOM_INT(_id2_1330)) {
        _1 = (long)(DBL_PTR(_id2_1330)->dbl);
        DeRefDS(_id2_1330);
        _id2_1330 = _1;
    }

    /** 	return retval(or_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _475 = (int)*(((s1_ptr)_2)->base + _id1_1329);
    _2 = (int)SEQ_PTR(_1data_751);
    _476 = (int)*(((s1_ptr)_2)->base + _id2_1330);
    if (IS_ATOM_INT(_475) && IS_ATOM_INT(_476)) {
        {unsigned long tu;
             tu = (unsigned long)_475 | (unsigned long)_476;
             _477 = MAKE_UINT(tu);
        }
    }
    else {
        _477 = binary_op(OR_BITS, _475, _476);
    }
    _475 = NOVALUE;
    _476 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1335);
    _ob_inlined_retval_at_22_1335 = _477;
    _477 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1335);
    _0 = _retval_inlined_retval_at_25_1336;
    _retval_inlined_retval_at_25_1336 = _1register_data(_ob_inlined_retval_at_22_1335);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1335);
    _ob_inlined_retval_at_22_1335 = NOVALUE;
    return _retval_inlined_retval_at_25_1336;
    ;
}
int eu_or_bits() __attribute__ ((alias ("_1eu_or_bits")));


int _1eu_peek(int _id1_1339)
{
    int _retval_inlined_retval_at_16_1344 = NOVALUE;
    int _ob_inlined_retval_at_13_1343 = NOVALUE;
    int _479 = NOVALUE;
    int _478 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1339)) {
        _1 = (long)(DBL_PTR(_id1_1339)->dbl);
        DeRefDS(_id1_1339);
        _id1_1339 = _1;
    }

    /** 	return retval(peek(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _478 = (int)*(((s1_ptr)_2)->base + _id1_1339);
    if (IS_ATOM_INT(_478)) {
        _479 = *(unsigned char *)_478;
    }
    else if (IS_ATOM(_478)) {
        _479 = *(unsigned char *)(unsigned long)(DBL_PTR(_478)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_478);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _479 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _478 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1343);
    _ob_inlined_retval_at_13_1343 = _479;
    _479 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1343);
    _0 = _retval_inlined_retval_at_16_1344;
    _retval_inlined_retval_at_16_1344 = _1register_data(_ob_inlined_retval_at_13_1343);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1343);
    _ob_inlined_retval_at_13_1343 = NOVALUE;
    return _retval_inlined_retval_at_16_1344;
    ;
}
int eu_peek() __attribute__ ((alias ("_1eu_peek")));


int _1eu_peek4s(int _id1_1347)
{
    int _retval_inlined_retval_at_16_1352 = NOVALUE;
    int _ob_inlined_retval_at_13_1351 = NOVALUE;
    int _481 = NOVALUE;
    int _480 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1347)) {
        _1 = (long)(DBL_PTR(_id1_1347)->dbl);
        DeRefDS(_id1_1347);
        _id1_1347 = _1;
    }

    /** 	return retval(peek4s(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _480 = (int)*(((s1_ptr)_2)->base + _id1_1347);
    if (IS_ATOM_INT(_480)) {
        _481 = *(unsigned long *)_480;
        if (_481 < MININT || _481 > MAXINT)
        _481 = NewDouble((double)(long)_481);
    }
    else if (IS_ATOM(_480)) {
        _481 = *(unsigned long *)(unsigned long)(DBL_PTR(_480)->dbl);
        if (_481 < MININT || _481 > MAXINT)
        _481 = NewDouble((double)(long)_481);
    }
    else {
        _1 = (int)SEQ_PTR(_480);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _481 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _480 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1351);
    _ob_inlined_retval_at_13_1351 = _481;
    _481 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1351);
    _0 = _retval_inlined_retval_at_16_1352;
    _retval_inlined_retval_at_16_1352 = _1register_data(_ob_inlined_retval_at_13_1351);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1351);
    _ob_inlined_retval_at_13_1351 = NOVALUE;
    return _retval_inlined_retval_at_16_1352;
    ;
}
int eu_peek4s() __attribute__ ((alias ("_1eu_peek4s")));


int _1eu_peek4u(int _id1_1355)
{
    int _retval_inlined_retval_at_16_1360 = NOVALUE;
    int _ob_inlined_retval_at_13_1359 = NOVALUE;
    int _483 = NOVALUE;
    int _482 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1355)) {
        _1 = (long)(DBL_PTR(_id1_1355)->dbl);
        DeRefDS(_id1_1355);
        _id1_1355 = _1;
    }

    /** 	return retval(peek4u(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _482 = (int)*(((s1_ptr)_2)->base + _id1_1355);
    if (IS_ATOM_INT(_482)) {
        _483 = *(unsigned long *)_482;
        if ((unsigned)_483 > (unsigned)MAXINT)
        _483 = NewDouble((double)(unsigned long)_483);
    }
    else if (IS_ATOM(_482)) {
        _483 = *(unsigned long *)(unsigned long)(DBL_PTR(_482)->dbl);
        if ((unsigned)_483 > (unsigned)MAXINT)
        _483 = NewDouble((double)(unsigned long)_483);
    }
    else {
        _1 = (int)SEQ_PTR(_482);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _483 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _482 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1359);
    _ob_inlined_retval_at_13_1359 = _483;
    _483 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1359);
    _0 = _retval_inlined_retval_at_16_1360;
    _retval_inlined_retval_at_16_1360 = _1register_data(_ob_inlined_retval_at_13_1359);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1359);
    _ob_inlined_retval_at_13_1359 = NOVALUE;
    return _retval_inlined_retval_at_16_1360;
    ;
}
int eu_peek4u() __attribute__ ((alias ("_1eu_peek4u")));


int _1eu_platform()
{
    int _0, _1, _2;
    

    /** 	return platform() -- returns an integer*/
    return 3;
    ;
}
int eu_platform() __attribute__ ((alias ("_1eu_platform")));


void _1eu_poke(int _id1_1365, int _id2_1366)
{
    int _485 = NOVALUE;
    int _484 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1365)) {
        _1 = (long)(DBL_PTR(_id1_1365)->dbl);
        DeRefDS(_id1_1365);
        _id1_1365 = _1;
    }
    if (!IS_ATOM_INT(_id2_1366)) {
        _1 = (long)(DBL_PTR(_id2_1366)->dbl);
        DeRefDS(_id2_1366);
        _id2_1366 = _1;
    }

    /** 	poke(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _484 = (int)*(((s1_ptr)_2)->base + _id1_1365);
    _2 = (int)SEQ_PTR(_1data_751);
    _485 = (int)*(((s1_ptr)_2)->base + _id2_1366);
    if (IS_ATOM_INT(_484)){
        poke_addr = (unsigned char *)_484;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_484)->dbl);
    }
    if (IS_ATOM_INT(_485)) {
        *poke_addr = (unsigned char)_485;
    }
    else if (IS_ATOM(_485)) {
        *poke_addr = (signed char)DBL_PTR(_485)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_485);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _484 = NOVALUE;
    _485 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke() __attribute__ ((alias ("_1eu_poke")));


void _1eu_poke4(int _id1_1371, int _id2_1372)
{
    int _487 = NOVALUE;
    int _486 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1371)) {
        _1 = (long)(DBL_PTR(_id1_1371)->dbl);
        DeRefDS(_id1_1371);
        _id1_1371 = _1;
    }
    if (!IS_ATOM_INT(_id2_1372)) {
        _1 = (long)(DBL_PTR(_id2_1372)->dbl);
        DeRefDS(_id2_1372);
        _id2_1372 = _1;
    }

    /** 	poke4(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _486 = (int)*(((s1_ptr)_2)->base + _id1_1371);
    _2 = (int)SEQ_PTR(_1data_751);
    _487 = (int)*(((s1_ptr)_2)->base + _id2_1372);
    if (IS_ATOM_INT(_486)){
        poke4_addr = (unsigned long *)_486;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_486)->dbl);
    }
    if (IS_ATOM_INT(_487)) {
        *poke4_addr = (unsigned long)_487;
    }
    else if (IS_ATOM(_487)) {
        *poke4_addr = (unsigned long)DBL_PTR(_487)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_487);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _486 = NOVALUE;
    _487 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke4() __attribute__ ((alias ("_1eu_poke4")));


void _1eu_position(int _row_1377, int _column_1378)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_row_1377)) {
        _1 = (long)(DBL_PTR(_row_1377)->dbl);
        DeRefDS(_row_1377);
        _row_1377 = _1;
    }
    if (!IS_ATOM_INT(_column_1378)) {
        _1 = (long)(DBL_PTR(_column_1378)->dbl);
        DeRefDS(_column_1378);
        _column_1378 = _1;
    }

    /** 	position(row, column)*/
    Position(_row_1377, _column_1378);

    /** end procedure*/
    return;
    ;
}
void eu_position() __attribute__ ((alias ("_1eu_position")));


int _1eu_power(int _id1_1381, int _id2_1382)
{
    int _retval_inlined_retval_at_25_1388 = NOVALUE;
    int _ob_inlined_retval_at_22_1387 = NOVALUE;
    int _490 = NOVALUE;
    int _489 = NOVALUE;
    int _488 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1381)) {
        _1 = (long)(DBL_PTR(_id1_1381)->dbl);
        DeRefDS(_id1_1381);
        _id1_1381 = _1;
    }
    if (!IS_ATOM_INT(_id2_1382)) {
        _1 = (long)(DBL_PTR(_id2_1382)->dbl);
        DeRefDS(_id2_1382);
        _id2_1382 = _1;
    }

    /** 	return retval(power(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _488 = (int)*(((s1_ptr)_2)->base + _id1_1381);
    _2 = (int)SEQ_PTR(_1data_751);
    _489 = (int)*(((s1_ptr)_2)->base + _id2_1382);
    if (IS_ATOM_INT(_488) && IS_ATOM_INT(_489)) {
        _490 = power(_488, _489);
    }
    else {
        _490 = binary_op(POWER, _488, _489);
    }
    _488 = NOVALUE;
    _489 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1387);
    _ob_inlined_retval_at_22_1387 = _490;
    _490 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1387);
    _0 = _retval_inlined_retval_at_25_1388;
    _retval_inlined_retval_at_25_1388 = _1register_data(_ob_inlined_retval_at_22_1387);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1387);
    _ob_inlined_retval_at_22_1387 = NOVALUE;
    return _retval_inlined_retval_at_25_1388;
    ;
}
int eu_power() __attribute__ ((alias ("_1eu_power")));


int _1eu_prepend(int _id1_1391, int _id2_1392)
{
    int _retval_inlined_retval_at_25_1398 = NOVALUE;
    int _ob_inlined_retval_at_22_1397 = NOVALUE;
    int _493 = NOVALUE;
    int _492 = NOVALUE;
    int _491 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1391)) {
        _1 = (long)(DBL_PTR(_id1_1391)->dbl);
        DeRefDS(_id1_1391);
        _id1_1391 = _1;
    }
    if (!IS_ATOM_INT(_id2_1392)) {
        _1 = (long)(DBL_PTR(_id2_1392)->dbl);
        DeRefDS(_id2_1392);
        _id2_1392 = _1;
    }

    /** 	return retval(prepend(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _491 = (int)*(((s1_ptr)_2)->base + _id1_1391);
    _2 = (int)SEQ_PTR(_1data_751);
    _492 = (int)*(((s1_ptr)_2)->base + _id2_1392);
    Ref(_492);
    Prepend(&_493, _491, _492);
    _491 = NOVALUE;
    _492 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1397);
    _ob_inlined_retval_at_22_1397 = _493;
    _493 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1397);
    _0 = _retval_inlined_retval_at_25_1398;
    _retval_inlined_retval_at_25_1398 = _1register_data(_ob_inlined_retval_at_22_1397);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1397);
    _ob_inlined_retval_at_22_1397 = NOVALUE;
    return _retval_inlined_retval_at_25_1398;
    ;
}
int eu_prepend() __attribute__ ((alias ("_1eu_prepend")));


void _1eu_print(int _fn_id_1401, int _id1_1402)
{
    int _494 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1401)) {
        _1 = (long)(DBL_PTR(_fn_id_1401)->dbl);
        DeRefDS(_fn_id_1401);
        _fn_id_1401 = _1;
    }
    if (!IS_ATOM_INT(_id1_1402)) {
        _1 = (long)(DBL_PTR(_id1_1402)->dbl);
        DeRefDS(_id1_1402);
        _id1_1402 = _1;
    }

    /** 	print(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _494 = (int)*(((s1_ptr)_2)->base + _id1_1402);
    StdPrint(_fn_id_1401, _494, 0);
    _494 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_print() __attribute__ ((alias ("_1eu_print")));


void _1eu_printf(int _fn_id_1406, int _id1_1407, int _id2_1408)
{
    int _496 = NOVALUE;
    int _495 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1406)) {
        _1 = (long)(DBL_PTR(_fn_id_1406)->dbl);
        DeRefDS(_fn_id_1406);
        _fn_id_1406 = _1;
    }
    if (!IS_ATOM_INT(_id1_1407)) {
        _1 = (long)(DBL_PTR(_id1_1407)->dbl);
        DeRefDS(_id1_1407);
        _id1_1407 = _1;
    }
    if (!IS_ATOM_INT(_id2_1408)) {
        _1 = (long)(DBL_PTR(_id2_1408)->dbl);
        DeRefDS(_id2_1408);
        _id2_1408 = _1;
    }

    /** 	printf(fn_id, data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _495 = (int)*(((s1_ptr)_2)->base + _id1_1407);
    _2 = (int)SEQ_PTR(_1data_751);
    _496 = (int)*(((s1_ptr)_2)->base + _id2_1408);
    EPrintf(_fn_id_1406, _495, _496);
    _495 = NOVALUE;
    _496 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_printf() __attribute__ ((alias ("_1eu_printf")));


void _1eu_puts(int _fn_id_1413, int _id1_1414)
{
    int _497 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1413)) {
        _1 = (long)(DBL_PTR(_fn_id_1413)->dbl);
        DeRefDS(_fn_id_1413);
        _fn_id_1413 = _1;
    }
    if (!IS_ATOM_INT(_id1_1414)) {
        _1 = (long)(DBL_PTR(_id1_1414)->dbl);
        DeRefDS(_id1_1414);
        _id1_1414 = _1;
    }

    /** 	puts(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _497 = (int)*(((s1_ptr)_2)->base + _id1_1414);
    EPuts(_fn_id_1413, _497); // DJP 
    _497 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_puts() __attribute__ ((alias ("_1eu_puts")));


int _1eu_rand(int _id1_1418)
{
    int _retval_inlined_retval_at_16_1423 = NOVALUE;
    int _ob_inlined_retval_at_13_1422 = NOVALUE;
    int _499 = NOVALUE;
    int _498 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1418)) {
        _1 = (long)(DBL_PTR(_id1_1418)->dbl);
        DeRefDS(_id1_1418);
        _id1_1418 = _1;
    }

    /** 	return retval(rand(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _498 = (int)*(((s1_ptr)_2)->base + _id1_1418);
    if (IS_ATOM_INT(_498)) {
        _499 = good_rand() % ((unsigned)_498) + 1;
    }
    else {
        _499 = unary_op(RAND, _498);
    }
    _498 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1422);
    _ob_inlined_retval_at_13_1422 = _499;
    _499 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1422);
    _0 = _retval_inlined_retval_at_16_1423;
    _retval_inlined_retval_at_16_1423 = _1register_data(_ob_inlined_retval_at_13_1422);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1422);
    _ob_inlined_retval_at_13_1422 = NOVALUE;
    return _retval_inlined_retval_at_16_1423;
    ;
}
int eu_rand() __attribute__ ((alias ("_1eu_rand")));


int _1eu_remainder(int _id1_1426, int _id2_1427)
{
    int _retval_inlined_retval_at_25_1433 = NOVALUE;
    int _ob_inlined_retval_at_22_1432 = NOVALUE;
    int _502 = NOVALUE;
    int _501 = NOVALUE;
    int _500 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1426)) {
        _1 = (long)(DBL_PTR(_id1_1426)->dbl);
        DeRefDS(_id1_1426);
        _id1_1426 = _1;
    }
    if (!IS_ATOM_INT(_id2_1427)) {
        _1 = (long)(DBL_PTR(_id2_1427)->dbl);
        DeRefDS(_id2_1427);
        _id2_1427 = _1;
    }

    /** 	return retval(remainder(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _500 = (int)*(((s1_ptr)_2)->base + _id1_1426);
    _2 = (int)SEQ_PTR(_1data_751);
    _501 = (int)*(((s1_ptr)_2)->base + _id2_1427);
    if (IS_ATOM_INT(_500) && IS_ATOM_INT(_501)) {
        _502 = (_500 % _501);
    }
    else {
        _502 = binary_op(REMAINDER, _500, _501);
    }
    _500 = NOVALUE;
    _501 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1432);
    _ob_inlined_retval_at_22_1432 = _502;
    _502 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1432);
    _0 = _retval_inlined_retval_at_25_1433;
    _retval_inlined_retval_at_25_1433 = _1register_data(_ob_inlined_retval_at_22_1432);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1432);
    _ob_inlined_retval_at_22_1432 = NOVALUE;
    return _retval_inlined_retval_at_25_1433;
    ;
}
int eu_remainder() __attribute__ ((alias ("_1eu_remainder")));


int _1eu_sequence(int _id_1436)
{
    int _504 = NOVALUE;
    int _503 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1436)) {
        _1 = (long)(DBL_PTR(_id_1436)->dbl);
        DeRefDS(_id_1436);
        _id_1436 = _1;
    }

    /** 	return sequence(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_751);
    _503 = (int)*(((s1_ptr)_2)->base + _id_1436);
    _504 = IS_SEQUENCE(_503);
    _503 = NOVALUE;
    return _504;
    ;
}
int eu_sequence() __attribute__ ((alias ("_1eu_sequence")));


int _1eu_sin(int _id_1441)
{
    int _retval_inlined_retval_at_16_1446 = NOVALUE;
    int _ob_inlined_retval_at_13_1445 = NOVALUE;
    int _506 = NOVALUE;
    int _505 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1441)) {
        _1 = (long)(DBL_PTR(_id_1441)->dbl);
        DeRefDS(_id_1441);
        _id_1441 = _1;
    }

    /** 	return retval(sin(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _505 = (int)*(((s1_ptr)_2)->base + _id_1441);
    if (IS_ATOM_INT(_505))
    _506 = e_sin(_505);
    else
    _506 = unary_op(SIN, _505);
    _505 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1445);
    _ob_inlined_retval_at_13_1445 = _506;
    _506 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1445);
    _0 = _retval_inlined_retval_at_16_1446;
    _retval_inlined_retval_at_16_1446 = _1register_data(_ob_inlined_retval_at_13_1445);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1445);
    _ob_inlined_retval_at_13_1445 = NOVALUE;
    return _retval_inlined_retval_at_16_1446;
    ;
}
int eu_sin() __attribute__ ((alias ("_1eu_sin")));


int _1eu_sprintf(int _id1_1449, int _id2_1450)
{
    int _retval_inlined_retval_at_25_1456 = NOVALUE;
    int _ob_inlined_retval_at_22_1455 = NOVALUE;
    int _509 = NOVALUE;
    int _508 = NOVALUE;
    int _507 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1449)) {
        _1 = (long)(DBL_PTR(_id1_1449)->dbl);
        DeRefDS(_id1_1449);
        _id1_1449 = _1;
    }
    if (!IS_ATOM_INT(_id2_1450)) {
        _1 = (long)(DBL_PTR(_id2_1450)->dbl);
        DeRefDS(_id2_1450);
        _id2_1450 = _1;
    }

    /** 	return retval(sprintf(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _507 = (int)*(((s1_ptr)_2)->base + _id1_1449);
    _2 = (int)SEQ_PTR(_1data_751);
    _508 = (int)*(((s1_ptr)_2)->base + _id2_1450);
    _509 = EPrintf(-9999999, _507, _508);
    _507 = NOVALUE;
    _508 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_22_1455);
    _ob_inlined_retval_at_22_1455 = _509;
    _509 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1455);
    _0 = _retval_inlined_retval_at_25_1456;
    _retval_inlined_retval_at_25_1456 = _1register_data(_ob_inlined_retval_at_22_1455);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_22_1455);
    _ob_inlined_retval_at_22_1455 = NOVALUE;
    return _retval_inlined_retval_at_25_1456;
    ;
}
int eu_sprintf() __attribute__ ((alias ("_1eu_sprintf")));


int _1eu_sqrt(int _id_1459)
{
    int _retval_inlined_retval_at_16_1464 = NOVALUE;
    int _ob_inlined_retval_at_13_1463 = NOVALUE;
    int _511 = NOVALUE;
    int _510 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1459)) {
        _1 = (long)(DBL_PTR(_id_1459)->dbl);
        DeRefDS(_id_1459);
        _id_1459 = _1;
    }

    /** 	return retval(sqrt(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _510 = (int)*(((s1_ptr)_2)->base + _id_1459);
    if (IS_ATOM_INT(_510))
    _511 = e_sqrt(_510);
    else
    _511 = unary_op(SQRT, _510);
    _510 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1463);
    _ob_inlined_retval_at_13_1463 = _511;
    _511 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1463);
    _0 = _retval_inlined_retval_at_16_1464;
    _retval_inlined_retval_at_16_1464 = _1register_data(_ob_inlined_retval_at_13_1463);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1463);
    _ob_inlined_retval_at_13_1463 = NOVALUE;
    return _retval_inlined_retval_at_16_1464;
    ;
}
int eu_sqrt() __attribute__ ((alias ("_1eu_sqrt")));


int _1eu_subscript(int _id_1467, int _start_1468, int _stop_1469)
{
    int _retval_inlined_retval_at_22_1474 = NOVALUE;
    int _ob_inlined_retval_at_19_1473 = NOVALUE;
    int _513 = NOVALUE;
    int _512 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1467)) {
        _1 = (long)(DBL_PTR(_id_1467)->dbl);
        DeRefDS(_id_1467);
        _id_1467 = _1;
    }
    if (!IS_ATOM_INT(_start_1468)) {
        _1 = (long)(DBL_PTR(_start_1468)->dbl);
        DeRefDS(_start_1468);
        _start_1468 = _1;
    }
    if (!IS_ATOM_INT(_stop_1469)) {
        _1 = (long)(DBL_PTR(_stop_1469)->dbl);
        DeRefDS(_stop_1469);
        _stop_1469 = _1;
    }

    /** 	return retval(data[id][start..stop])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _512 = (int)*(((s1_ptr)_2)->base + _id_1467);
    rhs_slice_target = (object_ptr)&_513;
    RHS_Slice(_512, _start_1468, _stop_1469);
    _512 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_1473);
    _ob_inlined_retval_at_19_1473 = _513;
    _513 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_1473);
    _0 = _retval_inlined_retval_at_22_1474;
    _retval_inlined_retval_at_22_1474 = _1register_data(_ob_inlined_retval_at_19_1473);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_1473);
    _ob_inlined_retval_at_19_1473 = NOVALUE;
    return _retval_inlined_retval_at_22_1474;
    ;
}
int eu_subscript() __attribute__ ((alias ("_1eu_subscript")));


void _1eu_system(int _id1_1477, int _mode_1478)
{
    int _514 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1477)) {
        _1 = (long)(DBL_PTR(_id1_1477)->dbl);
        DeRefDS(_id1_1477);
        _id1_1477 = _1;
    }
    if (!IS_ATOM_INT(_mode_1478)) {
        _1 = (long)(DBL_PTR(_mode_1478)->dbl);
        DeRefDS(_mode_1478);
        _mode_1478 = _1;
    }

    /** 	system(data[id1], mode)*/
    _2 = (int)SEQ_PTR(_1data_751);
    _514 = (int)*(((s1_ptr)_2)->base + _id1_1477);
    system_call(_514, _mode_1478);
    _514 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_system() __attribute__ ((alias ("_1eu_system")));


int _1eu_system_exec(int _id1_1482, int _mode_1483)
{
    int _516 = NOVALUE;
    int _515 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1482)) {
        _1 = (long)(DBL_PTR(_id1_1482)->dbl);
        DeRefDS(_id1_1482);
        _id1_1482 = _1;
    }
    if (!IS_ATOM_INT(_mode_1483)) {
        _1 = (long)(DBL_PTR(_mode_1483)->dbl);
        DeRefDS(_mode_1483);
        _mode_1483 = _1;
    }

    /** 	return system_exec(data[id1], mode) -- returns the exit code from the called process.*/
    _2 = (int)SEQ_PTR(_1data_751);
    _515 = (int)*(((s1_ptr)_2)->base + _id1_1482);
    _516 = system_exec_call(_515, _mode_1483);
    _515 = NOVALUE;
    return _516;
    ;
}
int eu_system_exec() __attribute__ ((alias ("_1eu_system_exec")));


int _1eu_tan(int _id_1488)
{
    int _retval_inlined_retval_at_16_1493 = NOVALUE;
    int _ob_inlined_retval_at_13_1492 = NOVALUE;
    int _518 = NOVALUE;
    int _517 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1488)) {
        _1 = (long)(DBL_PTR(_id_1488)->dbl);
        DeRefDS(_id_1488);
        _id_1488 = _1;
    }

    /** 	return retval(tan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _517 = (int)*(((s1_ptr)_2)->base + _id_1488);
    if (IS_ATOM_INT(_517))
    _518 = e_tan(_517);
    else
    _518 = unary_op(TAN, _517);
    _517 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1492);
    _ob_inlined_retval_at_13_1492 = _518;
    _518 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1492);
    _0 = _retval_inlined_retval_at_16_1493;
    _retval_inlined_retval_at_16_1493 = _1register_data(_ob_inlined_retval_at_13_1492);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1492);
    _ob_inlined_retval_at_13_1492 = NOVALUE;
    return _retval_inlined_retval_at_16_1493;
    ;
}
int eu_tan() __attribute__ ((alias ("_1eu_tan")));


int _1eu_time()
{
    int _retval_inlined_retval_at_7_1499 = NOVALUE;
    int _ob_inlined_retval_at_4_1498 = NOVALUE;
    int _519 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(time())*/
    _519 = NewDouble(current_time());
    DeRef(_ob_inlined_retval_at_4_1498);
    _ob_inlined_retval_at_4_1498 = _519;
    _519 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1498);
    _0 = _retval_inlined_retval_at_7_1499;
    _retval_inlined_retval_at_7_1499 = _1register_data(_ob_inlined_retval_at_4_1498);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_1498);
    _ob_inlined_retval_at_4_1498 = NOVALUE;
    return _retval_inlined_retval_at_7_1499;
    ;
}
int eu_time() __attribute__ ((alias ("_1eu_time")));


int _1eu_xor_bits(int _id1_1502, int _id2_1503)
{
    int _retval_inlined_retval_at_25_1509 = NOVALUE;
    int _ob_inlined_retval_at_22_1508 = NOVALUE;
    int _522 = NOVALUE;
    int _521 = NOVALUE;
    int _520 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1502)) {
        _1 = (long)(DBL_PTR(_id1_1502)->dbl);
        DeRefDS(_id1_1502);
        _id1_1502 = _1;
    }
    if (!IS_ATOM_INT(_id2_1503)) {
        _1 = (long)(DBL_PTR(_id2_1503)->dbl);
        DeRefDS(_id2_1503);
        _id2_1503 = _1;
    }

    /** 	return retval(xor_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _520 = (int)*(((s1_ptr)_2)->base + _id1_1502);
    _2 = (int)SEQ_PTR(_1data_751);
    _521 = (int)*(((s1_ptr)_2)->base + _id2_1503);
    if (IS_ATOM_INT(_520) && IS_ATOM_INT(_521)) {
        {unsigned long tu;
             tu = (unsigned long)_520 ^ (unsigned long)_521;
             _522 = MAKE_UINT(tu);
        }
    }
    else {
        _522 = binary_op(XOR_BITS, _520, _521);
    }
    _520 = NOVALUE;
    _521 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1508);
    _ob_inlined_retval_at_22_1508 = _522;
    _522 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1508);
    _0 = _retval_inlined_retval_at_25_1509;
    _retval_inlined_retval_at_25_1509 = _1register_data(_ob_inlined_retval_at_22_1508);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1508);
    _ob_inlined_retval_at_22_1508 = NOVALUE;
    return _retval_inlined_retval_at_25_1509;
    ;
}
int eu_xor_bits() __attribute__ ((alias ("_1eu_xor_bits")));


int _1eu_hash(int _did_1512, int _algorithm_1513)
{
    int _retval_inlined_retval_at_19_1518 = NOVALUE;
    int _ob_inlined_retval_at_16_1517 = NOVALUE;
    int _524 = NOVALUE;
    int _523 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1512)) {
        _1 = (long)(DBL_PTR(_did_1512)->dbl);
        DeRefDS(_did_1512);
        _did_1512 = _1;
    }
    if (!IS_ATOM_INT(_algorithm_1513)) {
        _1 = (long)(DBL_PTR(_algorithm_1513)->dbl);
        DeRefDS(_algorithm_1513);
        _algorithm_1513 = _1;
    }

    /** 	return retval(hash(data[did], algorithm))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _523 = (int)*(((s1_ptr)_2)->base + _did_1512);
    _524 = calc_hash(_523, _algorithm_1513);
    _523 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1517);
    _ob_inlined_retval_at_16_1517 = _524;
    _524 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1517);
    _0 = _retval_inlined_retval_at_19_1518;
    _retval_inlined_retval_at_19_1518 = _1register_data(_ob_inlined_retval_at_16_1517);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1517);
    _ob_inlined_retval_at_16_1517 = NOVALUE;
    return _retval_inlined_retval_at_19_1518;
    ;
}
int eu_hash() __attribute__ ((alias ("_1eu_hash")));


int _1eu_head(int _did_1521, int _len_1522)
{
    int _retval_inlined_retval_at_19_1527 = NOVALUE;
    int _ob_inlined_retval_at_16_1526 = NOVALUE;
    int _526 = NOVALUE;
    int _525 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1521)) {
        _1 = (long)(DBL_PTR(_did_1521)->dbl);
        DeRefDS(_did_1521);
        _did_1521 = _1;
    }
    if (!IS_ATOM_INT(_len_1522)) {
        _1 = (long)(DBL_PTR(_len_1522)->dbl);
        DeRefDS(_len_1522);
        _len_1522 = _1;
    }

    /** 	return retval(head(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _525 = (int)*(((s1_ptr)_2)->base + _did_1521);
    {
        int len = SEQ_PTR(_525)->length;
        int size = (IS_ATOM_INT(_len_1522)) ? _len_1522 : (object)(DBL_PTR(_len_1522)->dbl);
        if (size <= 0){
            DeRef( _526 );
            _526 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_525);
            DeRef(_526);
            _526 = _525;
        }
        else{
            Head(SEQ_PTR(_525),size+1,&_526);
        }
    }
    _525 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1526);
    _ob_inlined_retval_at_16_1526 = _526;
    _526 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_1526);
    _0 = _retval_inlined_retval_at_19_1527;
    _retval_inlined_retval_at_19_1527 = _1register_data(_ob_inlined_retval_at_16_1526);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1526);
    _ob_inlined_retval_at_16_1526 = NOVALUE;
    return _retval_inlined_retval_at_19_1527;
    ;
}
int eu_head() __attribute__ ((alias ("_1eu_head")));


int _1eu_include_paths(int _convert_1530)
{
    int _retval_inlined_retval_at_13_1537 = NOVALUE;
    int _ob_inlined_retval_at_10_1536 = NOVALUE;
    int _530 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_convert_1530)) {
        _1 = (long)(DBL_PTR(_convert_1530)->dbl);
        DeRefDS(_convert_1530);
        _convert_1530 = _1;
    }

    /** 	return retval(include_paths(convert))*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_529);
    *((int *)(_2+4)) = _529;
    RefDS(_528);
    *((int *)(_2+8)) = _528;
    RefDS(_527);
    *((int *)(_2+12)) = _527;
    _530 = MAKE_SEQ(_1);
    DeRef(_ob_inlined_retval_at_10_1536);
    _ob_inlined_retval_at_10_1536 = _530;
    _530 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_10_1536);
    _0 = _retval_inlined_retval_at_13_1537;
    _retval_inlined_retval_at_13_1537 = _1register_data(_ob_inlined_retval_at_10_1536);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_10_1536);
    _ob_inlined_retval_at_10_1536 = NOVALUE;
    return _retval_inlined_retval_at_13_1537;
    ;
}
int eu_include_paths() __attribute__ ((alias ("_1eu_include_paths")));


int _1eu_insert(int _did1_1540, int _did2_1541, int _index_1542)
{
    int _retval_inlined_retval_at_28_1548 = NOVALUE;
    int _ob_inlined_retval_at_25_1547 = NOVALUE;
    int _533 = NOVALUE;
    int _532 = NOVALUE;
    int _531 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1540)) {
        _1 = (long)(DBL_PTR(_did1_1540)->dbl);
        DeRefDS(_did1_1540);
        _did1_1540 = _1;
    }
    if (!IS_ATOM_INT(_did2_1541)) {
        _1 = (long)(DBL_PTR(_did2_1541)->dbl);
        DeRefDS(_did2_1541);
        _did2_1541 = _1;
    }
    if (!IS_ATOM_INT(_index_1542)) {
        _1 = (long)(DBL_PTR(_index_1542)->dbl);
        DeRefDS(_index_1542);
        _index_1542 = _1;
    }

    /** 	return retval(insert(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _531 = (int)*(((s1_ptr)_2)->base + _did1_1540);
    _2 = (int)SEQ_PTR(_1data_751);
    _532 = (int)*(((s1_ptr)_2)->base + _did2_1541);
    {
        s1_ptr assign_space;
        insert_pos = _index_1542;
        if (insert_pos <= 0){
            Prepend(&_533,_531,_532);
        }
        else if (insert_pos > SEQ_PTR(_531)->length) {
            Ref( _532 );
            Append(&_533,_531,_532);
        }
        else {
            Ref( _532 );
            RefDS( _531 );
            _533 = Insert(_531,_532,insert_pos);
        }
    }
    _531 = NOVALUE;
    _532 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_1547);
    _ob_inlined_retval_at_25_1547 = _533;
    _533 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_1547);
    _0 = _retval_inlined_retval_at_28_1548;
    _retval_inlined_retval_at_28_1548 = _1register_data(_ob_inlined_retval_at_25_1547);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_1547);
    _ob_inlined_retval_at_25_1547 = NOVALUE;
    return _retval_inlined_retval_at_28_1548;
    ;
}
int eu_insert() __attribute__ ((alias ("_1eu_insert")));


int _1eu_peek2s(int _did_1551)
{
    int _retval_inlined_retval_at_16_1556 = NOVALUE;
    int _ob_inlined_retval_at_13_1555 = NOVALUE;
    int _535 = NOVALUE;
    int _534 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1551)) {
        _1 = (long)(DBL_PTR(_did_1551)->dbl);
        DeRefDS(_did_1551);
        _did_1551 = _1;
    }

    /** 	return retval(peek2s(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _534 = (int)*(((s1_ptr)_2)->base + _did_1551);
    if (IS_ATOM_INT(_534)) {
        _535 = *(signed short *)_534;
    }
    else if (IS_ATOM(_534)) {
        _535 = *(signed short *)(unsigned long)(DBL_PTR(_534)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_534);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _535 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _534 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1555);
    _ob_inlined_retval_at_13_1555 = _535;
    _535 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1555);
    _0 = _retval_inlined_retval_at_16_1556;
    _retval_inlined_retval_at_16_1556 = _1register_data(_ob_inlined_retval_at_13_1555);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1555);
    _ob_inlined_retval_at_13_1555 = NOVALUE;
    return _retval_inlined_retval_at_16_1556;
    ;
}
int eu_peek2s() __attribute__ ((alias ("_1eu_peek2s")));


int _1eu_peek2u(int _did_1559)
{
    int _retval_inlined_retval_at_16_1564 = NOVALUE;
    int _ob_inlined_retval_at_13_1563 = NOVALUE;
    int _537 = NOVALUE;
    int _536 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1559)) {
        _1 = (long)(DBL_PTR(_did_1559)->dbl);
        DeRefDS(_did_1559);
        _did_1559 = _1;
    }

    /** 	return retval(peek2u(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _536 = (int)*(((s1_ptr)_2)->base + _did_1559);
    if (IS_ATOM_INT(_536)) {
        _537 = *(unsigned short *)_536;
    }
    else if (IS_ATOM(_536)) {
        _537 = *(unsigned short *)(unsigned long)(DBL_PTR(_536)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_536);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _537 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _536 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1563);
    _ob_inlined_retval_at_13_1563 = _537;
    _537 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1563);
    _0 = _retval_inlined_retval_at_16_1564;
    _retval_inlined_retval_at_16_1564 = _1register_data(_ob_inlined_retval_at_13_1563);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1563);
    _ob_inlined_retval_at_13_1563 = NOVALUE;
    return _retval_inlined_retval_at_16_1564;
    ;
}
int eu_peek2u() __attribute__ ((alias ("_1eu_peek2u")));


int _1eu_peek_string(int _did_1567)
{
    int _retval_inlined_retval_at_16_1572 = NOVALUE;
    int _ob_inlined_retval_at_13_1571 = NOVALUE;
    int _539 = NOVALUE;
    int _538 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1567)) {
        _1 = (long)(DBL_PTR(_did_1567)->dbl);
        DeRefDS(_did_1567);
        _did_1567 = _1;
    }

    /** 	return retval(peek_string(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _538 = (int)*(((s1_ptr)_2)->base + _did_1567);
    if (IS_ATOM_INT(_538)) {
        _539 =  NewString((char *)_538);
    }
    else if (IS_ATOM(_538)) {
        _539 = NewString((char *)(unsigned long)(DBL_PTR(_538)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_538);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _539 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _538 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1571);
    _ob_inlined_retval_at_13_1571 = _539;
    _539 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1571);
    _0 = _retval_inlined_retval_at_16_1572;
    _retval_inlined_retval_at_16_1572 = _1register_data(_ob_inlined_retval_at_13_1571);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1571);
    _ob_inlined_retval_at_13_1571 = NOVALUE;
    return _retval_inlined_retval_at_16_1572;
    ;
}
int eu_peek_string() __attribute__ ((alias ("_1eu_peek_string")));


int _1eu_peeks(int _did_1575)
{
    int _retval_inlined_retval_at_16_1580 = NOVALUE;
    int _ob_inlined_retval_at_13_1579 = NOVALUE;
    int _541 = NOVALUE;
    int _540 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1575)) {
        _1 = (long)(DBL_PTR(_did_1575)->dbl);
        DeRefDS(_did_1575);
        _did_1575 = _1;
    }

    /** 	return retval(peeks(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _540 = (int)*(((s1_ptr)_2)->base + _did_1575);
    if (IS_ATOM_INT(_540)) {
        _541 = *(signed char *)_540;
    }
    else if (IS_ATOM(_540)) {
        _541 = *(signed char *)(unsigned long)(DBL_PTR(_540)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_540);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _541 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(signed char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _540 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1579);
    _ob_inlined_retval_at_13_1579 = _541;
    _541 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1579);
    _0 = _retval_inlined_retval_at_16_1580;
    _retval_inlined_retval_at_16_1580 = _1register_data(_ob_inlined_retval_at_13_1579);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1579);
    _ob_inlined_retval_at_13_1579 = NOVALUE;
    return _retval_inlined_retval_at_16_1580;
    ;
}
int eu_peeks() __attribute__ ((alias ("_1eu_peeks")));


void _1eu_poke2(int _did1_1583, int _did2_1584)
{
    int _543 = NOVALUE;
    int _542 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1583)) {
        _1 = (long)(DBL_PTR(_did1_1583)->dbl);
        DeRefDS(_did1_1583);
        _did1_1583 = _1;
    }
    if (!IS_ATOM_INT(_did2_1584)) {
        _1 = (long)(DBL_PTR(_did2_1584)->dbl);
        DeRefDS(_did2_1584);
        _did2_1584 = _1;
    }

    /** 	poke2(data[did1], data[did2])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _542 = (int)*(((s1_ptr)_2)->base + _did1_1583);
    _2 = (int)SEQ_PTR(_1data_751);
    _543 = (int)*(((s1_ptr)_2)->base + _did2_1584);
    if (IS_ATOM_INT(_542)){
        poke2_addr = (unsigned short *)_542;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_542)->dbl);
    }
    if (IS_ATOM_INT(_543)) {
        *poke2_addr = (unsigned short)_543;
    }
    else if (IS_ATOM(_543)) {
        *poke_addr = (signed char)DBL_PTR(_543)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_543);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke2_addr++ = (unsigned short)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
            }
        }
    }
    _542 = NOVALUE;
    _543 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke2() __attribute__ ((alias ("_1eu_poke2")));


int _1eu_remove(int _did_1589, int _start_1590, int _stop_1591)
{
    int _retval_inlined_retval_at_22_1596 = NOVALUE;
    int _ob_inlined_retval_at_19_1595 = NOVALUE;
    int _545 = NOVALUE;
    int _544 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1589)) {
        _1 = (long)(DBL_PTR(_did_1589)->dbl);
        DeRefDS(_did_1589);
        _did_1589 = _1;
    }
    if (!IS_ATOM_INT(_start_1590)) {
        _1 = (long)(DBL_PTR(_start_1590)->dbl);
        DeRefDS(_start_1590);
        _start_1590 = _1;
    }
    if (!IS_ATOM_INT(_stop_1591)) {
        _1 = (long)(DBL_PTR(_stop_1591)->dbl);
        DeRefDS(_stop_1591);
        _stop_1591 = _1;
    }

    /** 	return retval(remove(data[did], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _544 = (int)*(((s1_ptr)_2)->base + _did_1589);
    {
        s1_ptr assign_space = SEQ_PTR(_544);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_start_1590)) ? _start_1590 : (long)(DBL_PTR(_start_1590)->dbl);
        int stop = (IS_ATOM_INT(_stop_1591)) ? _stop_1591 : (long)(DBL_PTR(_stop_1591)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_544);
            DeRef(_545);
            _545 = _544;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_544), start, &_545 );
            }
            else Tail(SEQ_PTR(_544), stop+1, &_545);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_544), start, &_545);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_545);
            _545 = _1;
        }
    }
    _544 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_1595);
    _ob_inlined_retval_at_19_1595 = _545;
    _545 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_1595);
    _0 = _retval_inlined_retval_at_22_1596;
    _retval_inlined_retval_at_22_1596 = _1register_data(_ob_inlined_retval_at_19_1595);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_1595);
    _ob_inlined_retval_at_19_1595 = NOVALUE;
    return _retval_inlined_retval_at_22_1596;
    ;
}
int eu_remove() __attribute__ ((alias ("_1eu_remove")));


int _1eu_replace(int _did1_1599, int _did2_1600, int _start_1601, int _stop_1602)
{
    int _retval_inlined_retval_at_31_1608 = NOVALUE;
    int _ob_inlined_retval_at_28_1607 = NOVALUE;
    int _548 = NOVALUE;
    int _547 = NOVALUE;
    int _546 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1599)) {
        _1 = (long)(DBL_PTR(_did1_1599)->dbl);
        DeRefDS(_did1_1599);
        _did1_1599 = _1;
    }
    if (!IS_ATOM_INT(_did2_1600)) {
        _1 = (long)(DBL_PTR(_did2_1600)->dbl);
        DeRefDS(_did2_1600);
        _did2_1600 = _1;
    }
    if (!IS_ATOM_INT(_start_1601)) {
        _1 = (long)(DBL_PTR(_start_1601)->dbl);
        DeRefDS(_start_1601);
        _start_1601 = _1;
    }
    if (!IS_ATOM_INT(_stop_1602)) {
        _1 = (long)(DBL_PTR(_stop_1602)->dbl);
        DeRefDS(_stop_1602);
        _stop_1602 = _1;
    }

    /** 	return retval(replace(data[did1], data[did2], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _546 = (int)*(((s1_ptr)_2)->base + _did1_1599);
    _2 = (int)SEQ_PTR(_1data_751);
    _547 = (int)*(((s1_ptr)_2)->base + _did2_1600);
    {
        int p1 = _546;
        int p2 = _547;
        int p3 = _start_1601;
        int p4 = _stop_1602;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_548;
        Replace( &replace_params );
    }
    _546 = NOVALUE;
    _547 = NOVALUE;
    DeRef(_ob_inlined_retval_at_28_1607);
    _ob_inlined_retval_at_28_1607 = _548;
    _548 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_28_1607);
    _0 = _retval_inlined_retval_at_31_1608;
    _retval_inlined_retval_at_31_1608 = _1register_data(_ob_inlined_retval_at_28_1607);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_28_1607);
    _ob_inlined_retval_at_28_1607 = NOVALUE;
    return _retval_inlined_retval_at_31_1608;
    ;
}
int eu_replace() __attribute__ ((alias ("_1eu_replace")));


int _1eu_splice(int _did1_1611, int _did2_1612, int _index_1613)
{
    int _retval_inlined_retval_at_28_1619 = NOVALUE;
    int _ob_inlined_retval_at_25_1618 = NOVALUE;
    int _551 = NOVALUE;
    int _550 = NOVALUE;
    int _549 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1611)) {
        _1 = (long)(DBL_PTR(_did1_1611)->dbl);
        DeRefDS(_did1_1611);
        _did1_1611 = _1;
    }
    if (!IS_ATOM_INT(_did2_1612)) {
        _1 = (long)(DBL_PTR(_did2_1612)->dbl);
        DeRefDS(_did2_1612);
        _did2_1612 = _1;
    }
    if (!IS_ATOM_INT(_index_1613)) {
        _1 = (long)(DBL_PTR(_index_1613)->dbl);
        DeRefDS(_index_1613);
        _index_1613 = _1;
    }

    /** 	return retval(splice(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _549 = (int)*(((s1_ptr)_2)->base + _did1_1611);
    _2 = (int)SEQ_PTR(_1data_751);
    _550 = (int)*(((s1_ptr)_2)->base + _did2_1612);
    {
        s1_ptr assign_space;
        insert_pos = _index_1613;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_550)) {
                Concat(&_551,_550,_549);
            }
            else{
                Prepend(&_551,_549,_550);
            }
        }
        else if (insert_pos > SEQ_PTR(_549)->length){
            if (IS_SEQUENCE(_550)) {
                Concat(&_551,_549,_550);
            }
            else{
                Append(&_551,_549,_550);
            }
        }
        else if (IS_SEQUENCE(_550)) {
            if( _551 != _549 || SEQ_PTR( _549 )->ref != 1 ){
                DeRef( _551 );
                RefDS( _549 );
            }
            assign_space = Add_internal_space( _549, insert_pos,((s1_ptr)SEQ_PTR(_550))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_550), _549 == _551 );
            _551 = MAKE_SEQ( assign_space );
        }
        else {
            if( _551 != _549 && SEQ_PTR( _549 )->ref != 1 ){
                _551 = Insert( _549, _550, insert_pos);
            }
            else {
                DeRef( _551 );
                RefDS( _549 );
                _551 = Insert( _549, _550, insert_pos);
            }
        }
    }
    _549 = NOVALUE;
    _550 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_1618);
    _ob_inlined_retval_at_25_1618 = _551;
    _551 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_1618);
    _0 = _retval_inlined_retval_at_28_1619;
    _retval_inlined_retval_at_28_1619 = _1register_data(_ob_inlined_retval_at_25_1618);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_1618);
    _ob_inlined_retval_at_25_1618 = NOVALUE;
    return _retval_inlined_retval_at_28_1619;
    ;
}
int eu_splice() __attribute__ ((alias ("_1eu_splice")));


int _1eu_tail(int _did_1622, int _len_1623)
{
    int _retval_inlined_retval_at_19_1628 = NOVALUE;
    int _ob_inlined_retval_at_16_1627 = NOVALUE;
    int _553 = NOVALUE;
    int _552 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1622)) {
        _1 = (long)(DBL_PTR(_did_1622)->dbl);
        DeRefDS(_did_1622);
        _did_1622 = _1;
    }
    if (!IS_ATOM_INT(_len_1623)) {
        _1 = (long)(DBL_PTR(_len_1623)->dbl);
        DeRefDS(_len_1623);
        _len_1623 = _1;
    }

    /** 	return retval(tail(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _552 = (int)*(((s1_ptr)_2)->base + _did_1622);
    {
        int len = SEQ_PTR(_552)->length;
        int size = (IS_ATOM_INT(_len_1623)) ? _len_1623 : (long)(DBL_PTR(_len_1623)->dbl);
        if (size <= 0) {
            DeRef(_553);
            _553 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_552);
            DeRef(_553);
            _553 = _552;
        }
        else Tail(SEQ_PTR(_552), len-size+1, &_553);
    }
    _552 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1627);
    _ob_inlined_retval_at_16_1627 = _553;
    _553 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_1627);
    _0 = _retval_inlined_retval_at_19_1628;
    _retval_inlined_retval_at_19_1628 = _1register_data(_ob_inlined_retval_at_16_1627);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1627);
    _ob_inlined_retval_at_16_1627 = NOVALUE;
    return _retval_inlined_retval_at_19_1628;
    ;
}
int eu_tail() __attribute__ ((alias ("_1eu_tail")));


int _1eu_call_func_std(int _rid_1631, int _did_1632)
{
    int _retval_inlined_retval_at_19_1637 = NOVALUE;
    int _ob_inlined_retval_at_16_1636 = NOVALUE;
    int _555 = NOVALUE;
    int _554 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1631)) {
        _1 = (long)(DBL_PTR(_rid_1631)->dbl);
        DeRefDS(_rid_1631);
        _rid_1631 = _1;
    }
    if (!IS_ATOM_INT(_did_1632)) {
        _1 = (long)(DBL_PTR(_did_1632)->dbl);
        DeRefDS(_did_1632);
        _did_1632 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _554 = (int)*(((s1_ptr)_2)->base + _did_1632);
    _1 = (int)SEQ_PTR(_554);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_1631].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _555 = _1;
    _554 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1636);
    _ob_inlined_retval_at_16_1636 = _555;
    _555 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1636);
    _0 = _retval_inlined_retval_at_19_1637;
    _retval_inlined_retval_at_19_1637 = _1register_data(_ob_inlined_retval_at_16_1636);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1636);
    _ob_inlined_retval_at_16_1636 = NOVALUE;
    return _retval_inlined_retval_at_19_1637;
    ;
}
int eu_call_func_std() __attribute__ ((alias ("_1eu_call_func_std")));


int _1eu_call_func_val(int _rid_1640, int _did_1641)
{
    int _retval_inlined_retval_at_19_1646 = NOVALUE;
    int _ob_inlined_retval_at_16_1645 = NOVALUE;
    int _557 = NOVALUE;
    int _556 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1640)) {
        _1 = (long)(DBL_PTR(_rid_1640)->dbl);
        DeRefDS(_rid_1640);
        _rid_1640 = _1;
    }
    if (!IS_ATOM_INT(_did_1641)) {
        _1 = (long)(DBL_PTR(_did_1641)->dbl);
        DeRefDS(_did_1641);
        _did_1641 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_751);
    _556 = (int)*(((s1_ptr)_2)->base + _did_1641);
    _1 = (int)SEQ_PTR(_556);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_1640].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _557 = _1;
    _556 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1645);
    _ob_inlined_retval_at_16_1645 = _557;
    _557 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1645);
    _0 = _retval_inlined_retval_at_19_1646;
    _retval_inlined_retval_at_19_1646 = _1register_data(_ob_inlined_retval_at_16_1645);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1645);
    _ob_inlined_retval_at_16_1645 = NOVALUE;
    return _retval_inlined_retval_at_19_1646;
    ;
}
int eu_call_func_val() __attribute__ ((alias ("_1eu_call_func_val")));


int _1eu_call_func(int _rid_1649, int _did_1650)
{
    int _i_1651 = NOVALUE;
    int _558 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1649)) {
        _1 = (long)(DBL_PTR(_rid_1649)->dbl);
        DeRefDS(_rid_1649);
        _rid_1649 = _1;
    }
    if (!IS_ATOM_INT(_did_1650)) {
        _1 = (long)(DBL_PTR(_did_1650)->dbl);
        DeRefDS(_did_1650);
        _did_1650 = _1;
    }

    /** 	i = call_func(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _558 = (int)*(((s1_ptr)_2)->base + _did_1650);
    _1 = (int)SEQ_PTR(_558);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_1649].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _i_1651 = _1;
    _558 = NOVALUE;
    if (!IS_ATOM_INT(_i_1651)) {
        _1 = (long)(DBL_PTR(_i_1651)->dbl);
        DeRefDS(_i_1651);
        _i_1651 = _1;
    }

    /** 	return i*/
    return _i_1651;
    ;
}
int eu_call_func() __attribute__ ((alias ("_1eu_call_func")));


void _1eu_call_proc(int _rid_1656, int _did_1657)
{
    int _560 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1656)) {
        _1 = (long)(DBL_PTR(_rid_1656)->dbl);
        DeRefDS(_rid_1656);
        _rid_1656 = _1;
    }
    if (!IS_ATOM_INT(_did_1657)) {
        _1 = (long)(DBL_PTR(_did_1657)->dbl);
        DeRefDS(_did_1657);
        _did_1657 = _1;
    }

    /** 	call_proc(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_751);
    _560 = (int)*(((s1_ptr)_2)->base + _did_1657);
    _1 = (int)SEQ_PTR(_560);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_1656].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _560 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_call_proc() __attribute__ ((alias ("_1eu_call_proc")));


int _1eu_routine_id(int _did_1661)
{
    int _562 = NOVALUE;
    int _561 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1661)) {
        _1 = (long)(DBL_PTR(_did_1661)->dbl);
        DeRefDS(_did_1661);
        _did_1661 = _1;
    }

    /** 	return routine_id(data[did]) -- this is the only time it uses a string*/
    _2 = (int)SEQ_PTR(_1data_751);
    _561 = (int)*(((s1_ptr)_2)->base + _did_1661);
    _562 = CRoutineId(150, 1, _561);
    _561 = NOVALUE;
    return _562;
    ;
}
int eu_routine_id() __attribute__ ((alias ("_1eu_routine_id")));


int _1eu_routine_id_str(int _low_1666, int _high_1667)
{
    int _get_address_1__tmp_at6_1670 = NOVALUE;
    int _get_address_inlined_get_address_at_6_1669 = NOVALUE;
    int _564 = NOVALUE;
    int _563 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1666)) {
        _1 = (long)(DBL_PTR(_low_1666)->dbl);
        DeRefDS(_low_1666);
        _low_1666 = _1;
    }
    if (!IS_ATOM_INT(_high_1667)) {
        _1 = (long)(DBL_PTR(_high_1667)->dbl);
        DeRefDS(_high_1667);
        _high_1667 = _1;
    }

    /** 	return routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_1670);
    _get_address_1__tmp_at6_1670 = NewDouble(_high_1667 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_1669);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_1670)) {
        _get_address_inlined_get_address_at_6_1669 = _get_address_1__tmp_at6_1670 + _low_1666;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_1669 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_1669 = NewDouble((double)_get_address_inlined_get_address_at_6_1669);
    }
    else {
        _get_address_inlined_get_address_at_6_1669 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_1670)->dbl + (double)_low_1666);
    }
    DeRef(_get_address_1__tmp_at6_1670);
    _get_address_1__tmp_at6_1670 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_1669)) {
        _563 =  NewString((char *)_get_address_inlined_get_address_at_6_1669);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_6_1669)) {
        _563 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_1669)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_6_1669);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _563 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _564 = CRoutineId(151, 1, _563);
    DeRef(_563);
    _563 = NOVALUE;
    return _564;
    ;
}
int eu_routine_id_str() __attribute__ ((alias ("_1eu_routine_id_str")));



// 0x496F47B7
