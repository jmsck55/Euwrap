Copyright (C) 2020 James J. Cook

Uses Euphoria v4.0.5 and or v3.1.1

It should work on all systems and all platforms that are supported with Euphoria.
Binary for Win32 and all Source code included, except from rapideuphoria.com or openeuphoria.org

It requires Euphoria to be installed in order to build all of it.
It may also require other compilers to be installed.

Put the *.dll into a folder that is part of the path environment variable in order to install.

See my other software at:
http://rapideuphoria.com/cgi-bin/asearch.exu?dos=on&win=on&lnx=on&gen=on&keywords=James+Cook

See also:
http://rapideuphoria.com/
http://openeuphoria.org/
