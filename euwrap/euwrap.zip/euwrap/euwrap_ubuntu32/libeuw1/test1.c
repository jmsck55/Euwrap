// Copyright (C) 2020 James J. Cook


// To be able to execute on Linux, do the following:
/*

LD_LIBRARY_PATH=$PWD
export LD_LIBRARY_PATH
gcc -o testdl testdl.c -ldl
./testdl

*/


#include <stdio.h>
#include <stdlib.h>

#include "euw1.h"

int main() {
	char myfunc_name[] = "get_version";
	int func_id;
	int empty_seq;
	linked_list a = {0,0,0,0};
	int b;
	
	init_lib();
	// run the function:
	printf("eu_platform returns: %d\n", eu_platform());
	printf("myfunc_name address is: %u\n", (unsigned int)&myfunc_name);
	printf("to_low_high is: %d, %d\n", TO_LOW_HIGH(myfunc_name));
	
	func_id = eu_routine_id_str(TO_LOW_HIGH(myfunc_name));
	
	printf("func_id is: %d\n", func_id);
	
	empty_seq = register_linked_list(TO_LOW_HIGH(&a));
	
	b = eu_call_func(func_id, empty_seq);
	printf("using eu_call_func, get_version returns: %d\n", b);
	//eu_question_mark(b);
	
	close_lib();
	printf("Success!\n");
	return 0;
}
/*
int main() {
	char myfunc_name[] = "eu_date";
	int func_id;
	int empty_seq;
	linked_list a = {0,0,0,0};
	int b;
	
	init_lib();
	// run the function:
	printf("eu_platform returns: %d\n", eu_platform());
	printf("myfunc_name address is: %u\n", (unsigned int)&myfunc_name);
	printf("to_low_high is: %d, %d\n", TO_LOW_HIGH(myfunc_name));
	
	func_id = eu_routine_id_str(TO_LOW_HIGH(myfunc_name));
	
	printf("func_id is: %d\n", func_id);
	
	empty_seq = register_linked_list(TO_LOW_HIGH(&a));
	
	b = eu_call_func(func_id, empty_seq);
	//printf("using eu_call_func, get_version returns: %d\n", b);
	eu_question_mark(b);
	
	close_lib();
	printf("Success!\n");
	return 0;
}
*/
