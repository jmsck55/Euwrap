// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_8draw_line(int _c, int _xyarray)
{
    int _627 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }

    //     machine_proc(M_LINE, {c, 0, xyarray})
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _c;
    *((int *)(_2+8)) = 0;
    RefDS(_xyarray);
    *((int *)(_2+12)) = _xyarray;
    _627 = MAKE_SEQ(_1);
    machine(2, _627);

    // end procedure
    DeRefDS(_xyarray);
    DeRefDS(_627);
    return 0;
    ;
}


_8polygon(int _c, int _fill, int _xyarray)
{
    int _628 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }
    if (!IS_ATOM_INT(_fill)) {
        _1 = (long)(DBL_PTR(_fill)->dbl);
        DeRefDS(_fill);
        _fill = _1;
    }

    //     machine_proc(M_POLYGON, {c, fill, xyarray})
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _c;
    *((int *)(_2+8)) = _fill;
    RefDS(_xyarray);
    *((int *)(_2+12)) = _xyarray;
    _628 = MAKE_SEQ(_1);
    machine(11, _628);

    // end procedure
    DeRefDS(_xyarray);
    DeRefDS(_628);
    return 0;
    ;
}


_8ellipse(int _c, int _fill, int _p1, int _p2)
{
    int _629 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }
    if (!IS_ATOM_INT(_fill)) {
        _1 = (long)(DBL_PTR(_fill)->dbl);
        DeRefDS(_fill);
        _fill = _1;
    }

    //     machine_proc(M_ELLIPSE, {c, fill, p1, p2})
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _c;
    *((int *)(_2+8)) = _fill;
    RefDS(_p1);
    *((int *)(_2+12)) = _p1;
    RefDS(_p2);
    *((int *)(_2+16)) = _p2;
    _629 = MAKE_SEQ(_1);
    machine(18, _629);

    // end procedure
    DeRefDS(_p1);
    DeRefDS(_p2);
    DeRefDS(_629);
    return 0;
    ;
}


_8graphics_mode(int _m)
{
    int _630;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_m)) {
        _1 = (long)(DBL_PTR(_m)->dbl);
        DeRefDS(_m);
        _m = _1;
    }

    //    return machine_func(M_GRAPHICS_MODE, m)
    _630 = machine(5, _m);
    return _630;
    ;
}


_8video_config()
{
    int _631 = 0;
    int _0, _1, _2;
    

    //     return machine_func(M_VIDEO_CONFIG, 0)
    _631 = machine(13, 0);
    return _631;
    ;
}


_8cursor(int _style)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_style)) {
        _1 = (long)(DBL_PTR(_style)->dbl);
        DeRefDS(_style);
        _style = _1;
    }

    //     machine_proc(M_CURSOR, style)
    machine(6, _style);

    // end procedure
    return 0;
    ;
}


_8get_position()
{
    int _636 = 0;
    int _0, _1, _2;
    

    //     return machine_func(M_GET_POSITION, 0)
    _636 = machine(25, 0);
    return _636;
    ;
}


_8text_rows(int _rows)
{
    int _637;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rows)) {
        _1 = (long)(DBL_PTR(_rows)->dbl);
        DeRefDS(_rows);
        _rows = _1;
    }

    //     return machine_func(M_TEXTROWS, rows)
    _637 = machine(12, _rows);
    return _637;
    ;
}


_8wrap(int _on)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_on)) {
        _1 = (long)(DBL_PTR(_on)->dbl);
        DeRefDS(_on);
        _on = _1;
    }

    //     machine_proc(M_WRAP, on)
    machine(7, _on);

    // end procedure
    return 0;
    ;
}


_8scroll(int _amount, int _top_line, int _bottom_line)
{
    int _638 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount)) {
        _1 = (long)(DBL_PTR(_amount)->dbl);
        DeRefDS(_amount);
        _amount = _1;
    }
    if (!IS_ATOM_INT(_top_line)) {
        _1 = (long)(DBL_PTR(_top_line)->dbl);
        DeRefDS(_top_line);
        _top_line = _1;
    }
    if (!IS_ATOM_INT(_bottom_line)) {
        _1 = (long)(DBL_PTR(_bottom_line)->dbl);
        DeRefDS(_bottom_line);
        _bottom_line = _1;
    }

    //     machine_proc(M_SCROLL, {amount, top_line, bottom_line})
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _amount;
    *((int *)(_2+8)) = _top_line;
    *((int *)(_2+12)) = _bottom_line;
    _638 = MAKE_SEQ(_1);
    machine(8, _638);

    // end procedure
    DeRefDSi(_638);
    return 0;
    ;
}


_8text_color(int _c)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }

    //     machine_proc(M_SET_T_COLOR, c)
    machine(9, _c);

    // end procedure
    return 0;
    ;
}


_8bk_color(int _c)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }

    //     machine_proc(M_SET_B_COLOR, c)
    machine(10, _c);

    // end procedure
    return 0;
    ;
}


_8palette(int _c, int _s)
{
    int _641 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c)) {
        _1 = (long)(DBL_PTR(_c)->dbl);
        DeRefDS(_c);
        _c = _1;
    }

    //     return machine_func(M_PALETTE, {c, s})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _c;
    ((int *)_2)[2] = _s;
    RefDS(_s);
    _641 = MAKE_SEQ(_1);
    _0 = _641;
    _641 = machine(3, _641);
    DeRefDS(_0);
    DeRefDS(_s);
    return _641;
    ;
}


_8all_palette(int _s)
{
    int _0, _1, _2;
    

    //     machine_proc(M_ALL_PALETTE, s)
    machine(27, _s);

    // end procedure
    DeRefDS(_s);
    return 0;
    ;
}


_8sound(int _f)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f)) {
        _1 = (long)(DBL_PTR(_f)->dbl);
        DeRefDS(_f);
        _f = _1;
    }

    //     machine_proc(M_SOUND, f)
    machine(1, _f);

    // end procedure
    return 0;
    ;
}


