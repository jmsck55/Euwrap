// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_12set_return_linked_list(int _i)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	always_linked_list = i
    _12always_linked_list = _i;

    // end procedure
    return 0;
    ;
}


_12get_return_linked_list()
{
    int _0, _1, _2;
    

    // 	return always_linked_list
    return _12always_linked_list;
    ;
}


_12peek_string(int _ma)
{
    int _ch;
    int _s = 0;
    int _0, _1, _2;
    

    // 	s = {}
    RefDS(_202);
    _s = _202;

    // 	while 1 do
L1:

    // 		ch = peek(ma)
    if (IS_ATOM_INT(_ma)) {
        _ch = *(unsigned char *)_ma;
    }
    else {
        _ch = *(unsigned char *)(unsigned long)(DBL_PTR(_ma)->dbl);
    }

    // 		if ch = 0 then
    if (_ch != 0)
        goto L2;

    // 			exit
    goto L3;
L2:

    // 		s = append(s, ch)
    Append(&_s, _s, _ch);

    // 		ma += 1
    _0 = _ma;
    if (IS_ATOM_INT(_ma)) {
        _ma = _ma + 1;
        if (_ma > MAXINT)
            _ma = NewDouble((double)_ma);
    }
    else
        _ma = binary_op(PLUS, 1, _ma);
    DeRef(_0);

    // 	end while
    goto L1;
L3:

    // 	return s
    DeRef(_ma);
    return _s;
    ;
}


_12mystring(int _x)
{
    int _flag;
    int _i;
    int _ob = 0;
    int _1988;
    int _1985;
    int _0, _1, _2;
    

    // 	if not sequence(x) then
    _1985 = IS_SEQUENCE(_x);
    if (_1985 != 0)
        goto L1;

    // 		return 0
    DeRef(_x);
    return 0;
L1:

    // 	flag = 0
    _flag = 0;

    // 	for j = 1 to length(x) do
    _1985 = SEQ_PTR(_x)->length;
    { int _j;
        _j = 1;
L2:
        if (_j > _1985)
            goto L3;

        // 		ob = x[j]
        DeRef(_ob);
        _2 = (int)SEQ_PTR(_x);
        _ob = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_ob);

        // 		if not integer(ob) then
        if (IS_ATOM_INT(_ob))
            _1988 = 1;
        else if (IS_ATOM_DBL(_ob))
            _1988 = IS_ATOM_INT(DoubleToInt(_ob));
        else
            _1988 = 0;
        if (_1988 != 0)
            goto L4;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L4:

        // 		i = ob
        Ref(_ob);
        _i = _ob;
        if (!IS_ATOM_INT(_i)) {
            _1 = (long)(DBL_PTR(_i)->dbl);
            DeRefDS(_i);
            _i = _1;
        }

        // 		if i < 0 then
        if (_i >= 0)
            goto L5;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L5:

        // 		if i > 255 then
        if (_i <= 255)
            goto L6;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L6:

        // 		if flag = 0 then
        if (_flag != 0)
            goto L7;

        // 			flag = (i = 0)
        _flag = (_i == 0);
L7:

        // 	end for
        _j = _j + 1;
        goto L2;
L3:
        ;
    }

    // 	return 1 + flag
    _1988 = _flag + 1;
    DeRef(_x);
    DeRef(_ob);
    return _1988;
    ;
}


_12myarray(int _x)
{
    int _flag;
    int _i = 0;
    int _ob = 0;
    int _1999 = 0;
    int _1996;
    int _0, _1, _2;
    

    // 	if not sequence(x) then
    _1996 = IS_SEQUENCE(_x);
    if (_1996 != 0)
        goto L1;

    // 		return 0
    DeRef(_x);
    return 0;
L1:

    // 	flag = 1
    _flag = 1;

    // 	for j = 1 to length(x) do
    _1996 = SEQ_PTR(_x)->length;
    { int _j;
        _j = 1;
L2:
        if (_j > _1996)
            goto L3;

        // 		ob = x[j]
        DeRef(_ob);
        _2 = (int)SEQ_PTR(_x);
        _ob = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_ob);

        // 		if not atom(ob) then
        DeRef(_1999);
        _1999 = IS_ATOM(_ob);
        if (_1999 != 0)
            goto L4;

        // 			return 0
        DeRef(_x);
        DeRef(_i);
        DeRef(_ob);
        return 0;
L4:

        // 		if flag <= 2 then
        if (_flag > 2)
            goto L5;

        // 			i = ob
        Ref(_ob);
        DeRef(_i);
        _i = _ob;

        // 			if floor(i) != i then
        DeRef(_1999);
        if (IS_ATOM_INT(_i))
            _1999 = e_floor(_i);
        else
            _1999 = unary_op(FLOOR, _i);
        if (binary_op_a(EQUALS, _1999, _i))
            goto L6;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L6:

        // 			elsif i < (-2147483648) then
        if (binary_op_a(GREATEREQ, _i, _2006))
            goto L8;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L8:

        // 			elsif i > 4294967295 then
        if (binary_op_a(LESSEQ, _i, _2008))
            goto L9;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L9:

        // 			elsif flag = 2 then
        if (_flag != 2)
            goto LA;

        // 				if i > 2147483647 then
        if (binary_op_a(LESSEQ, _i, _2011))
            goto L7;

        // 					flag = 3 -- for double
        _flag = 3;
LB:
        goto L7;
LA:

        // 			elsif i < 0 then
        if (binary_op_a(GREATEREQ, _i, 0))
            goto LC;

        // 				flag = 2 -- for signed int
        _flag = 2;
LC:
L7:
L5:

        // 	end for
        _j = _j + 1;
        goto L2;
L3:
        ;
    }

    // 	return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list
    DeRef(_x);
    DeRef(_i);
    DeRef(_ob);
    DeRef(_1999);
    return _flag;
    ;
}


_12sequence_to_linked_list(int _s)
{
    int _ma = 0;
    int _next = 0;
    int _tmp = 0;
    int _a = 0;
    int _i;
    int _2020 = 0;
    int _2029 = 0;
    int _0, _1, _2;
    

    // 	ma = allocate(SIZE_OF_STRUCT)
    _ma = _2allocate(16);

    // 	if integer(s) then -- most of the time it will be an integer(a)
    if (IS_ATOM_INT(_s))
        _2020 = 1;
    else if (IS_ATOM_DBL(_s))
        _2020 = IS_ATOM_INT(DoubleToInt(_s));
    else
        _2020 = 0;
    if (_2020 == 0)
        goto L1;

    // 		i = s
    Ref(_s);
    _i = _s;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 		if i >= 0 then
    if (_i < 0)
        goto L2;

    // 			poke4(ma, UINT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12UINT_FLAG)->dbl;
    goto L3;
L2:

    // 			poke4(ma, INT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12INT_FLAG)->dbl;
L3:

    // 		poke4(ma + 4, i)
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    *poke4_addr = (unsigned long)_i;
    goto L4;
L1:

    // 	elsif atom(s) then
    DeRef(_2020);
    _2020 = IS_ATOM(_s);
    if (_2020 == 0)
        goto L5;

    // 		a = s
    Ref(_s);
    DeRef(_a);
    _a = _s;

    // 		if a = floor(a) then
    if (IS_ATOM_INT(_a))
        _2020 = e_floor(_a);
    else
        _2020 = unary_op(FLOOR, _a);
    if (binary_op_a(NOTEQ, _a, _2020))
        goto L6;

    // 			if a <= #FFFFFFFF and a >= 0 then
    DeRef(_2020);
    if (IS_ATOM_INT(_a)) {
        _2020 = ((double)_a <= DBL_PTR(_2008)->dbl);
    }
    else {
        _2020 = (DBL_PTR(_a)->dbl <= DBL_PTR(_2008)->dbl);
    }
    if (_2020 == 0) {
        goto L7;
    }
    DeRef(_2029);
    if (IS_ATOM_INT(_a)) {
        _2029 = (_a >= 0);
    }
    else {
        _2029 = (DBL_PTR(_a)->dbl >= (double)0);
    }
L8:
    if (_2029 == 0)
        goto L7;

    // 				poke4(ma, UINT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12UINT_FLAG)->dbl;

    // 				poke4(ma + 4, a)
    DeRef(_2029);
    if (IS_ATOM_INT(_ma)) {
        _2029 = _ma + 4;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
    goto L4;
L7:

    // 			elsif a <= 2147483647 and a >= -2147483648 then
    DeRef(_2029);
    if (IS_ATOM_INT(_a)) {
        _2029 = ((double)_a <= DBL_PTR(_2011)->dbl);
    }
    else {
        _2029 = (DBL_PTR(_a)->dbl <= DBL_PTR(_2011)->dbl);
    }
    if (_2029 == 0) {
        goto L9;
    }
    DeRef(_2020);
    if (IS_ATOM_INT(_a)) {
        _2020 = ((double)_a >= DBL_PTR(_2006)->dbl);
    }
    else {
        _2020 = (DBL_PTR(_a)->dbl >= DBL_PTR(_2006)->dbl);
    }
LA:
    if (_2020 == 0)
        goto L9;

    // 				poke4(ma, INT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12INT_FLAG)->dbl;

    // 				poke4(ma + 4, a)
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
    goto L4;
L9:

    // 				tmp = allocate(8)
    _0 = _tmp;
    _tmp = _2allocate(8);
    DeRef(_0);

    // 				poke(tmp, atom_to_float64(a))
    Ref(_a);
    _0 = _2020;
    _2020 = _2atom_to_float64(_a);
    DeRef(_0);
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    _1 = (int)SEQ_PTR(_2020);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    // 				poke4(ma, DOUBLE_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12DOUBLE_FLAG)->dbl;

    // 				poke4(ma + 4, tmp)
    DeRefDSi(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
LB:
    goto L4;
L6:

    // 			tmp = allocate(8)
    _0 = _tmp;
    _tmp = _2allocate(8);
    DeRef(_0);

    // 			poke(tmp, atom_to_float64(a))
    Ref(_a);
    _0 = _2020;
    _2020 = _2atom_to_float64(_a);
    DeRef(_0);
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    _1 = (int)SEQ_PTR(_2020);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    // 			poke4(ma, DOUBLE_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12DOUBLE_FLAG)->dbl;

    // 			poke4(ma + 4, tmp)
    DeRefDSi(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
LC:
    goto L4;
L5:

    // 	elsif length(s) = 0 then
    DeRef(_2020);
    _2020 = SEQ_PTR(_s)->length;
    if (_2020 != 0)
        goto LD;

    // 		poke4(ma, {NULL,NULL})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _2020 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    _1 = (int)SEQ_PTR(_2020);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    goto L4;
LD:

    // 		if not always_linked_list then
    if (_12always_linked_list != 0)
        goto LE;

    // 			i = mystring(s)
    Ref(_s);
    _i = _12mystring(_s);

    // 			if i then -- string
    if (_i == 0)
        goto LF;

    // 				if i = 2 then
    if (_i != 2)
        goto L10;

    // 					tmp = allocate(length(s))
    DeRef(_2020);
    _2020 = SEQ_PTR(_s)->length;
    _0 = _tmp;
    _tmp = _2allocate(_2020);
    DeRef(_0);

    // 					poke(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke_addr = (unsigned char)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke_addr = (signed char)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH
    _2020 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_2020;
    _2020 = Dor_bits(DBL_PTR(_12CBYTES), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_2020)) {
        *poke4_addr = (unsigned long)_2020;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_2020)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L11;
L10:

    // 					tmp = allocate_string(s)
    Ref(_s);
    _0 = _tmp;
    _tmp = _2allocate_string(_s);
    DeRef(_0);

    // 					poke4(ma, CSTRING) -- why?
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_12CSTRING)->dbl;

    // 					poke4(ma + 4, tmp)
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
L11:

    // 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 8;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_2029);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _2029 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    _1 = (int)SEQ_PTR(_2029);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 				return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_2029);
    DeRef(_2020);
    return _ma;
LF:

    // 			i = myarray(s)
    Ref(_s);
    _i = _12myarray(_s);

    // 			if i then
    if (_i == 0)
        goto L12;

    // 				if i = 1 then
    if (_i != 1)
        goto L13;

    // 					tmp = allocate(length(s) * 4)
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    if (_2029 == (short)_2029)
        _2029 = _2029 * 4;
    else
        _2029 = NewDouble(_2029 * (double)4);
    Ref(_2029);
    _0 = _tmp;
    _tmp = _2allocate(_2029);
    DeRef(_0);

    // 					poke4(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke4_addr = (unsigned long *)_tmp;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke4_addr = (unsigned long)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(UINT_FLAG, length(s)))
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_2029;
    _2029 = Dor_bits(DBL_PTR(_12UINT_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_2029)) {
        *poke4_addr = (unsigned long)_2029;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_2029)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_2029);
    if (IS_ATOM_INT(_ma)) {
        _2029 = _ma + 4;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L14;
L13:

    // 				elsif i = 2 then
    if (_i != 2)
        goto L15;

    // 					tmp = allocate(length(s) * 4)
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    if (_2029 == (short)_2029)
        _2029 = _2029 * 4;
    else
        _2029 = NewDouble(_2029 * (double)4);
    Ref(_2029);
    _0 = _tmp;
    _tmp = _2allocate(_2029);
    DeRef(_0);

    // 					poke4(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke4_addr = (unsigned long *)_tmp;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke4_addr = (unsigned long)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(INT_FLAG, length(s)))
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_2029;
    _2029 = Dor_bits(DBL_PTR(_12INT_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_2029)) {
        *poke4_addr = (unsigned long)_2029;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_2029)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_2029);
    if (IS_ATOM_INT(_ma)) {
        _2029 = _ma + 4;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L14;
L15:

    // 				elsif i = 3 then
    if (_i != 3)
        goto L16;

    // 					tmp = allocate(length(s) * 8)
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    if (_2029 == (short)_2029)
        _2029 = _2029 * 8;
    else
        _2029 = NewDouble(_2029 * (double)8);
    Ref(_2029);
    _0 = _tmp;
    _tmp = _2allocate(_2029);
    DeRef(_0);

    // 					for j = 1 to length(s) do
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    { int _j;
        _j = 1;
L17:
        if (_j > _2029)
            goto L18;

        // 						poke(tmp, atom_to_float64(s[j]))
        DeRef(_2020);
        _2 = (int)SEQ_PTR(_s);
        _2020 = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_2020);
        Ref(_2020);
        _0 = _2020;
        _2020 = _2atom_to_float64(_2020);
        DeRef(_0);
        if (IS_ATOM_INT(_tmp))
            poke_addr = (unsigned char *)_tmp;
        else
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
        _1 = (int)SEQ_PTR(_2020);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }

        // 						tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 					end for
        _j = _j + 1;
        goto L17;
L18:
        ;
    }

    // 					poke4(ma, or_bits(DOUBLE_FLAG, length(s)))
    DeRef(_2020);
    _2020 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_2020;
    _2020 = Dor_bits(DBL_PTR(_12DOUBLE_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_2020)) {
        *poke4_addr = (unsigned long)_2020;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_2020)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 4;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
L16:
L14:

    // 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_2020);
    if (IS_ATOM_INT(_ma)) {
        _2020 = _ma + 8;
        if ((long)((unsigned long)_2020 + (unsigned long)HIGH_BITS) >= 0) 
            _2020 = NewDouble((double)_2020);
    }
    else {
        _2020 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_2029);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _2029 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_2020))
        poke4_addr = (unsigned long *)_2020;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2020)->dbl);
    _1 = (int)SEQ_PTR(_2029);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 				return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_2029);
    DeRef(_2020);
    return _ma;
L12:
LE:

    // 		next = NULL -- 0
    DeRef(_next);
    _next = 0;

    // 		poke4(ma, length(s))
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)_2029;

    // 		if length(s) then
    _2029 = SEQ_PTR(_s)->length;
    if (_2029 == 0)
        goto L19;

    // 			a = allocate(8) -- iterators to beginning and end of list
    _0 = _a;
    _a = _2allocate(8);
    DeRef(_0);

    // 			next = sequence_to_linked_list(s[$])
    _2029 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _2029 = (int)*(((s1_ptr)_2)->base + _2029);
    Ref(_2029);
    Ref(_2029);
    _next = _12sequence_to_linked_list(_2029);

    // 			s = s[1..$-1]
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    _2029 = _2029 - 1;
    rhs_slice_target = (object_ptr)&_s;
    RHS_Slice((s1_ptr)_s, 1, _2029);

    // 			poke4(a + 4, next) -- store the end iterator
    if (IS_ATOM_INT(_a)) {
        _2029 = _a + 4;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_a)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 			while length(s) do
L1A:
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    if (_2029 == 0)
        goto L1B;

    // 				tmp = sequence_to_linked_list(s[$])
    _2029 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _2029 = (int)*(((s1_ptr)_2)->base + _2029);
    Ref(_2029);
    Ref(_2029);
    _0 = _tmp;
    _tmp = _12sequence_to_linked_list(_2029);
    DeRef(_0);

    // 				s = s[1..$-1]
    DeRef(_2029);
    _2029 = SEQ_PTR(_s)->length;
    _2029 = _2029 - 1;
    rhs_slice_target = (object_ptr)&_s;
    RHS_Slice((s1_ptr)_s, 1, _2029);

    // 				poke4(next + 8, tmp)
    if (IS_ATOM_INT(_next)) {
        _2029 = _next + 8;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_next)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }

    // 				poke4(tmp + 12, next)
    DeRef(_2029);
    if (IS_ATOM_INT(_tmp)) {
        _2029 = _tmp + 12;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 				next = tmp
    Ref(_tmp);
    DeRef(_next);
    _next = _tmp;

    // 			end while
    goto L1A;
L1B:
L19:

    // 		poke4(a, next) -- store the beginning iterator
    if (IS_ATOM_INT(_a))
        poke4_addr = (unsigned long *)_a;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_a)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 		poke4(ma + 4, a) -- point data to the iterators
    DeRef(_2029);
    if (IS_ATOM_INT(_ma)) {
        _2029 = _ma + 4;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
L4:

    // 	poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_2029);
    if (IS_ATOM_INT(_ma)) {
        _2029 = _ma + 8;
        if ((long)((unsigned long)_2029 + (unsigned long)HIGH_BITS) >= 0) 
            _2029 = NewDouble((double)_2029);
    }
    else {
        _2029 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_2020);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _2020 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_2029))
        poke4_addr = (unsigned long *)_2029;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2029)->dbl);
    _1 = (int)SEQ_PTR(_2020);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 	return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_2020);
    DeRef(_2029);
    return _ma;
    ;
}


_12free_linked_list(int _ma)
{
    int _len = 0;
    int _tmp = 0;
    int _next = 0;
    int _ptr = 0;
    int _2115 = 0;
    int _2106 = 0;
    int _0, _1, _2;
    

    // 	len = peek4u(ma)
    if (IS_ATOM_INT(_ma)) {
        _len = *(unsigned long *)_ma;
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }
    else {
        _len = *(unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }

    // 	ptr = peek4u(ma + 4)
    if (IS_ATOM_INT(_ma)) {
        _2106 = _ma + 4;
        if ((long)((unsigned long)_2106 + (unsigned long)HIGH_BITS) >= 0) 
            _2106 = NewDouble((double)_2106);
    }
    else {
        _2106 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2106)) {
        _ptr = *(unsigned long *)_2106;
        if ((unsigned)_ptr > (unsigned)MAXINT)
            _ptr = NewDouble((double)(unsigned long)_ptr);
    }
    else {
        _ptr = *(unsigned long *)(unsigned long)(DBL_PTR(_2106)->dbl);
        if ((unsigned)_ptr > (unsigned)MAXINT)
            _ptr = NewDouble((double)(unsigned long)_ptr);
    }

    // 	if and_bits(len, SIGN_FLAG) then
    DeRef(_2106);
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _2106 = Dand_bits(&temp_d, DBL_PTR(_12SIGN_FLAG));
    }
    else {
        _2106 = Dand_bits(DBL_PTR(_len), DBL_PTR(_12SIGN_FLAG));
    }
    if (_2106 == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_2106) && DBL_PTR(_2106)->dbl == 0.0)
            goto L1;
    }

    // 	 	if and_bits(len, MAX_LENGTH) then
    DeRef(_2106);
    if (IS_ATOM_INT(_len)) {
        _2106 = (_len & 268435455);
    }
    else {
        temp_d.dbl = (double)268435455;
        _2106 = Dand_bits(DBL_PTR(_len), &temp_d);
    }
    if (_2106 == 0) {
        goto L2;
    }
    else {
        if (!IS_ATOM_INT(_2106) && DBL_PTR(_2106)->dbl == 0.0)
            goto L2;
    }

    // 			free(ptr)
    Ref(_ptr);
    _2free(_ptr);
    goto L3;
L2:

    // 		elsif len = DOUBLE_FLAG then
    if (binary_op_a(NOTEQ, _len, _12DOUBLE_FLAG))
        goto L3;

    // 			free(ptr)
    Ref(_ptr);
    _2free(_ptr);
L4:
L5:
    goto L3;
L1:

    // 	elsif len > 0 then
    if (binary_op_a(LESSEQ, _len, 0))
        goto L6;

    // 		tmp = peek4u(ptr) -- iterator to the beginning of the list
    DeRef(_tmp);
    if (IS_ATOM_INT(_ptr)) {
        _tmp = *(unsigned long *)_ptr;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_ptr)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		free(ptr) -- free the iterators
    Ref(_ptr);
    _2free(_ptr);

    // 		for i = 1 to len do
    Ref(_len);
    DeRef(_2106);
    _2106 = _len;
    { int _i;
        _i = 1;
L7:
        if (binary_op_a(GREATER, _i, _2106))
            goto L8;

        // 			next = peek4u(tmp + 12)
        DeRef(_2115);
        if (IS_ATOM_INT(_tmp)) {
            _2115 = _tmp + 12;
            if ((long)((unsigned long)_2115 + (unsigned long)HIGH_BITS) >= 0) 
                _2115 = NewDouble((double)_2115);
        }
        else {
            _2115 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
        }
        DeRef(_next);
        if (IS_ATOM_INT(_2115)) {
            _next = *(unsigned long *)_2115;
            if ((unsigned)_next > (unsigned)MAXINT)
                _next = NewDouble((double)(unsigned long)_next);
        }
        else {
            _next = *(unsigned long *)(unsigned long)(DBL_PTR(_2115)->dbl);
            if ((unsigned)_next > (unsigned)MAXINT)
                _next = NewDouble((double)(unsigned long)_next);
        }

        // 			free_linked_list(tmp)
        Ref(_tmp);
        DeRef(_2115);
        _2115 = _tmp;
        Ref(_2115);
        _12free_linked_list(_2115);

        // 			tmp = next
        Ref(_next);
        DeRef(_tmp);
        _tmp = _next;

        // 		end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L7;
L8:
        ;
        DeRef(_i);
    }
L6:
L3:

    // 	free(ma)
    Ref(_ma);
    _2free(_ma);

    // end procedure
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_next);
    DeRef(_ptr);
    DeRef(_2115);
    DeRef(_2106);
    return 0;
    ;
}


_12linked_list_to_sequence(int _ma)
{
    int _len = 0;
    int _tmp = 0;
    int _val = 0;
    int _s = 0;
    int _2143 = 0;
    int _2118 = 0;
    int _0, _1, _2;
    

    // 	len = peek4u(ma)
    if (IS_ATOM_INT(_ma)) {
        _len = *(unsigned long *)_ma;
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }
    else {
        _len = *(unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }

    // 	if and_bits(len, SIGN_FLAG) then
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _2118 = Dand_bits(&temp_d, DBL_PTR(_12SIGN_FLAG));
    }
    else {
        _2118 = Dand_bits(DBL_PTR(_len), DBL_PTR(_12SIGN_FLAG));
    }
    if (_2118 == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_2118) && DBL_PTR(_2118)->dbl == 0.0)
            goto L1;
    }

    // 		if len = CSTRING then
    if (binary_op_a(NOTEQ, _len, _12CSTRING))
        goto L2;

    // 			tmp = peek4u(ma + 4)
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_2118)) {
        _tmp = *(unsigned long *)_2118;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2118)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 			s = peek_string(tmp)
    Ref(_tmp);
    _s = _12peek_string(_tmp);

    // 			return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_2118);
    return _s;
L2:

    // 		val = and_bits(len, SIGN_MASK)
    DeRef(_val);
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _val = Dand_bits(&temp_d, DBL_PTR(_12SIGN_MASK));
    }
    else {
        _val = Dand_bits(DBL_PTR(_len), DBL_PTR(_12SIGN_MASK));
    }

    // 		len = and_bits(len, MAX_LENGTH)
    _0 = _len;
    if (IS_ATOM_INT(_len)) {
        _len = (_len & 268435455);
    }
    else {
        temp_d.dbl = (double)268435455;
        _len = Dand_bits(DBL_PTR(_len), &temp_d);
    }
    DeRef(_0);

    // 		if val = UINT_FLAG then
    if (binary_op_a(NOTEQ, _val, _12UINT_FLAG))
        goto L3;

    // 			if len then
    if (_len == 0) {
        goto L4;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto L4;
    }

    // 				s = peek4u({ma + 4, len})
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _2118;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _2118;
    Ref(_2118);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _2118 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_2118);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_2118);
    DeRef(_2143);
    return _s;
    goto L5;
L4:

    // 				tmp = peek4u(ma + 4)
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_2118)) {
        _tmp = *(unsigned long *)_2118;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2118)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRef(_2143);
    DeRef(_2118);
    return _tmp;
L5:
L3:

    // 		if val = INT_FLAG then
    if (binary_op_a(NOTEQ, _val, _12INT_FLAG))
        goto L6;

    // 			if len then
    if (_len == 0) {
        goto L7;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto L7;
    }

    // 				s = peek4s({ma + 4, len})
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _2118;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _2118;
    Ref(_2118);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _2118 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_2118);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_2118);
    DeRef(_2143);
    return _s;
    goto L8;
L7:

    // 				tmp = peek4s(ma + 4)
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_2118)) {
        _tmp = *(unsigned long *)_2118;
        if (_tmp < MININT || _tmp > MAXINT)
            _tmp = NewDouble((double)(long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2118)->dbl);
        if (_tmp < MININT || _tmp > MAXINT)
            _tmp = NewDouble((double)(long)_tmp);
    }

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRef(_2143);
    DeRef(_2118);
    return _tmp;
L8:
L6:

    // 		if val = FLOAT_FLAG then
    if (binary_op_a(NOTEQ, _val, _12FLOAT_FLAG))
        goto L9;

    // 			if len then
    if (_len == 0) {
        goto LA;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto LA;
    }

    // 				tmp = peek4u(ma + 4)
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_2118)) {
        _tmp = *(unsigned long *)_2118;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2118)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 				s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 				for i = 1 to len do
    Ref(_len);
    DeRef(_2118);
    _2118 = _len;
    { int _i;
        _i = 1;
LB:
        if (binary_op_a(GREATER, _i, _2118))
            goto LC;

        // 					s[i] = float32_to_atom(peek({tmp, 4}))
        DeRef(_2143);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp;
        Ref(_tmp);
        ((int *)_2)[2] = 4;
        _2143 = MAKE_SEQ(_1);
        _0 = _2143;
        _1 = (int)SEQ_PTR(_2143);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _2143 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
        DeRefDS(_0);
        RefDS(_2143);
        _0 = _2143;
        _2143 = _2float32_to_atom(_2143);
        DeRefDSi(_0);
        Ref(_2143);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i)->dbl));
        else
            _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _2143;
        DeRef(_1);

        // 					tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 				end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto LB;
LC:
        ;
        DeRef(_i);
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_2143);
    DeRef(_2118);
    return _s;
    goto LD;
LA:

    // 				tmp = float32_to_atom(peek({ma + 4, 4}))
    DeRef(_2143);
    if (IS_ATOM_INT(_ma)) {
        _2143 = _ma + 4;
        if ((long)((unsigned long)_2143 + (unsigned long)HIGH_BITS) >= 0) 
            _2143 = NewDouble((double)_2143);
    }
    else {
        _2143 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _2143;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _2143;
    Ref(_2143);
    ((int *)_2)[2] = 4;
    _2143 = MAKE_SEQ(_1);
    DeRef(_0);
    _0 = _2143;
    _1 = (int)SEQ_PTR(_2143);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _2143 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }
    DeRefDS(_0);
    RefDS(_2143);
    _0 = _tmp;
    _tmp = _2float32_to_atom(_2143);
    DeRef(_0);

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRefDSi(_2143);
    DeRef(_2118);
    return _tmp;
LD:
L9:

    // 		tmp = peek4u(ma + 4)
    DeRef(_2143);
    if (IS_ATOM_INT(_ma)) {
        _2143 = _ma + 4;
        if ((long)((unsigned long)_2143 + (unsigned long)HIGH_BITS) >= 0) 
            _2143 = NewDouble((double)_2143);
    }
    else {
        _2143 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_2143)) {
        _tmp = *(unsigned long *)_2143;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2143)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		if val = DOUBLE_FLAG then
    if (binary_op_a(NOTEQ, _val, _12DOUBLE_FLAG))
        goto LE;

    // 			if len then
    if (_len == 0) {
        goto LF;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto LF;
    }

    // 				s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 				for i = 1 to len do
    Ref(_len);
    DeRef(_2143);
    _2143 = _len;
    { int _i;
        _i = 1;
L10:
        if (binary_op_a(GREATER, _i, _2143))
            goto L11;

        // 					s[i] = float64_to_atom(peek({tmp, 8}))
        DeRef(_2118);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp;
        Ref(_tmp);
        ((int *)_2)[2] = 8;
        _2118 = MAKE_SEQ(_1);
        _0 = _2118;
        _1 = (int)SEQ_PTR(_2118);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _2118 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
        DeRefDS(_0);
        RefDS(_2118);
        _0 = _2118;
        _2118 = _2float64_to_atom(_2118);
        DeRefDSi(_0);
        Ref(_2118);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i)->dbl));
        else
            _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _2118;
        DeRef(_1);

        // 					tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 				end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L10;
L11:
        ;
        DeRef(_i);
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_2143);
    DeRef(_2118);
    return _s;
    goto L12;
LF:

    // 				tmp = float64_to_atom(peek({tmp, 8}))
    DeRef(_2118);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp;
    Ref(_tmp);
    ((int *)_2)[2] = 8;
    _2118 = MAKE_SEQ(_1);
    _0 = _2118;
    _1 = (int)SEQ_PTR(_2118);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _2118 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }
    DeRefDS(_0);
    RefDS(_2118);
    _0 = _tmp;
    _tmp = _2float64_to_atom(_2118);
    DeRef(_0);

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRefDSi(_2118);
    DeRef(_2143);
    return _tmp;
L12:
LE:

    // 		s = peek({tmp, len})
    DeRef(_2118);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp;
    Ref(_tmp);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _2118 = MAKE_SEQ(_1);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_2118);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }

    // 		return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_2118);
    DeRef(_2143);
    return _s;
    goto L13;
L1:

    // 	elsif len > 0 then
    if (binary_op_a(LESSEQ, _len, 0))
        goto L14;

    // 		tmp = peek4u(ma + 4)
    DeRef(_2118);
    if (IS_ATOM_INT(_ma)) {
        _2118 = _ma + 4;
        if ((long)((unsigned long)_2118 + (unsigned long)HIGH_BITS) >= 0) 
            _2118 = NewDouble((double)_2118);
    }
    else {
        _2118 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_2118)) {
        _tmp = *(unsigned long *)_2118;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2118)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		tmp = peek4u(tmp)
    _0 = _tmp;
    if (IS_ATOM_INT(_tmp)) {
        _tmp = *(unsigned long *)_tmp;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    DeRef(_0);

    // 		s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 		s[1] = linked_list_to_sequence(tmp)
    Ref(_tmp);
    DeRef(_2118);
    _2118 = _tmp;
    Ref(_2118);
    _0 = _2118;
    _2118 = _12linked_list_to_sequence(_2118);
    DeRef(_0);
    Ref(_2118);
    _2 = (int)SEQ_PTR(_s);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _2118;

    // 		for i = 2 to length(s) do
    DeRef(_2118);
    _2118 = SEQ_PTR(_s)->length;
    { int _i;
        _i = 2;
L15:
        if (_i > _2118)
            goto L16;

        // 			tmp = peek4u(tmp + 12)
        DeRef(_2143);
        if (IS_ATOM_INT(_tmp)) {
            _2143 = _tmp + 12;
            if ((long)((unsigned long)_2143 + (unsigned long)HIGH_BITS) >= 0) 
                _2143 = NewDouble((double)_2143);
        }
        else {
            _2143 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
        }
        DeRef(_tmp);
        if (IS_ATOM_INT(_2143)) {
            _tmp = *(unsigned long *)_2143;
            if ((unsigned)_tmp > (unsigned)MAXINT)
                _tmp = NewDouble((double)(unsigned long)_tmp);
        }
        else {
            _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_2143)->dbl);
            if ((unsigned)_tmp > (unsigned)MAXINT)
                _tmp = NewDouble((double)(unsigned long)_tmp);
        }

        // 			s[i] = linked_list_to_sequence(tmp)
        Ref(_tmp);
        DeRef(_2143);
        _2143 = _tmp;
        Ref(_2143);
        _0 = _2143;
        _2143 = _12linked_list_to_sequence(_2143);
        DeRef(_0);
        Ref(_2143);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _2143;
        DeRef(_1);

        // 		end for
        _i = _i + 1;
        goto L15;
L16:
        ;
    }

    // 		return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_2143);
    DeRef(_2118);
    return _s;
    goto L13;
L14:

    // 		return {}
    RefDS(_202);
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_s);
    DeRef(_2143);
    DeRef(_2118);
    return _202;
L13:
    ;
}


