// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_10lower(int _x)
{
    int _1090 = 0;
    int _1088 = 0;
    int _0, _1, _2;
    

    //     return x + (x >= 'A' and x <= 'Z') * TO_LOWER
    if (IS_ATOM_INT(_x)) {
        _1088 = (_x >= 65);
    }
    else {
        _1088 = binary_op(GREATEREQ, _x, 65);
    }
    if (IS_ATOM_INT(_x)) {
        _1090 = (_x <= 90);
    }
    else {
        _1090 = binary_op(LESSEQ, _x, 90);
    }
    _0 = _1090;
    if (IS_ATOM_INT(_1088) && IS_ATOM_INT(_1090)) {
        _1090 = (_1088 != 0 && _1090 != 0);
    }
    else {
        _1090 = binary_op(AND, _1088, _1090);
    }
    DeRef(_0);
    _0 = _1090;
    if (IS_ATOM_INT(_1090)) {
        if (_1090 == (short)_1090)
            _1090 = _1090 * 32;
        else
            _1090 = NewDouble(_1090 * (double)32);
    }
    else {
        _1090 = binary_op(MULTIPLY, _1090, 32);
    }
    DeRef(_0);
    _0 = _1090;
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_1090)) {
        _1090 = _x + _1090;
        if ((long)((unsigned long)_1090 + (unsigned long)HIGH_BITS) >= 0) 
            _1090 = NewDouble((double)_1090);
    }
    else {
        _1090 = binary_op(PLUS, _x, _1090);
    }
    DeRef(_0);
    DeRef(_x);
    DeRef(_1088);
    return _1090;
    ;
}


_10upper(int _x)
{
    int _1096 = 0;
    int _1094 = 0;
    int _0, _1, _2;
    

    //     return x - (x >= 'a' and x <= 'z') * TO_LOWER
    if (IS_ATOM_INT(_x)) {
        _1094 = (_x >= 97);
    }
    else {
        _1094 = binary_op(GREATEREQ, _x, 97);
    }
    if (IS_ATOM_INT(_x)) {
        _1096 = (_x <= 122);
    }
    else {
        _1096 = binary_op(LESSEQ, _x, 122);
    }
    _0 = _1096;
    if (IS_ATOM_INT(_1094) && IS_ATOM_INT(_1096)) {
        _1096 = (_1094 != 0 && _1096 != 0);
    }
    else {
        _1096 = binary_op(AND, _1094, _1096);
    }
    DeRef(_0);
    _0 = _1096;
    if (IS_ATOM_INT(_1096)) {
        if (_1096 == (short)_1096)
            _1096 = _1096 * 32;
        else
            _1096 = NewDouble(_1096 * (double)32);
    }
    else {
        _1096 = binary_op(MULTIPLY, _1096, 32);
    }
    DeRef(_0);
    _0 = _1096;
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_1096)) {
        _1096 = _x - _1096;
        if ((long)((unsigned long)_1096 +(unsigned long) HIGH_BITS) >= 0)
            _1096 = NewDouble((double)_1096);
    }
    else {
        _1096 = binary_op(MINUS, _x, _1096);
    }
    DeRef(_0);
    DeRef(_x);
    DeRef(_1094);
    return _1096;
    ;
}


int _10qmatch(int _p, int _s)
{
    int _k;
    int _1108 = 0;
    int _1109 = 0;
    int _1100;
    int _1104;
    int _0, _1, _2;
    

    //     if not find('?', p) then
    _1100 = find(63, _p);
    if (_1100 != 0)
        goto L1;

    // 	return match(p, s) -- fast
    _1100 = e_match(_p, _s);
    DeRefDS(_p);
    DeRefDS(_s);
    return _1100;
L1:

    //     for i = 1 to length(s) - length(p) + 1 do
    _1100 = SEQ_PTR(_s)->length;
    _1104 = SEQ_PTR(_p)->length;
    _1104 = _1100 - _1104;
    _1104 = _1104 + 1;
    { int _i;
        _i = 1;
L2:
        if (_i > _1104)
            goto L3;

        // 	k = i
        _k = _i;

        // 	for j = 1 to length(p) do
        _1100 = SEQ_PTR(_p)->length;
        { int _j;
            _j = 1;
L4:
            if (_j > _1100)
                goto L5;

            // 	    if p[j] != s[k] and p[j] != '?' then
            DeRef(_1108);
            _2 = (int)SEQ_PTR(_p);
            _1108 = (int)*(((s1_ptr)_2)->base + _j);
            Ref(_1108);
            DeRef(_1109);
            _2 = (int)SEQ_PTR(_s);
            _1109 = (int)*(((s1_ptr)_2)->base + _k);
            Ref(_1109);
            _0 = _1109;
            if (IS_ATOM_INT(_1108) && IS_ATOM_INT(_1109)) {
                _1109 = (_1108 != _1109);
            }
            else {
                _1109 = binary_op(NOTEQ, _1108, _1109);
            }
            DeRef(_0);
            if (IS_ATOM_INT(_1109)) {
                if (_1109 == 0) {
                    goto L6;
                }
            }
            else {
                if (DBL_PTR(_1109)->dbl == 0.0) {
                    goto L6;
                }
            }
            DeRef(_1108);
            _2 = (int)SEQ_PTR(_p);
            _1108 = (int)*(((s1_ptr)_2)->base + _j);
            Ref(_1108);
            _0 = _1108;
            if (IS_ATOM_INT(_1108)) {
                _1108 = (_1108 != 63);
            }
            else {
                _1108 = binary_op(NOTEQ, _1108, 63);
            }
            DeRef(_0);
L7:
            if (_1108 == 0) {
                goto L6;
            }
            else {
                if (!IS_ATOM_INT(_1108) && DBL_PTR(_1108)->dbl == 0.0)
                    goto L6;
            }

            // 		k = 0
            _k = 0;

            // 		exit
            goto L5;
L6:

            // 	    k += 1
            _k = _k + 1;

            // 	end for
            _j = _j + 1;
            goto L4;
L5:
            ;
        }

        // 	if k != 0 then
        if (_k == 0)
            goto L8;

        // 	    return i
        DeRefDS(_p);
        DeRefDS(_s);
        DeRef(_1108);
        DeRef(_1109);
        return _i;
L8:

        //     end for
        _i = _i + 1;
        goto L2;
L3:
        ;
    }

    //     return 0
    DeRefDS(_p);
    DeRefDS(_s);
    DeRef(_1108);
    DeRef(_1109);
    return 0;
    ;
}


_10wildcard_match(int _pattern, int _string)
{
    int _p;
    int _f;
    int _t;
    int _match_string = 0;
    int _1121 = 0;
    int _1116 = 0;
    int _0, _1, _2;
    

    //     pattern = pattern & END_MARKER
    Append(&_pattern, _pattern, -1);

    //     string = string & END_MARKER
    Append(&_string, _string, -1);

    //     p = 1
    _p = 1;

    //     f = 1
    _f = 1;

    //     while f <= length(string) do
L1:
    DeRef(_1116);
    _1116 = SEQ_PTR(_string)->length;
    if (_f > _1116)
        goto L2;

    // 	if not find(pattern[p], {string[f], '?'}) then
    _2 = (int)SEQ_PTR(_pattern);
    _1116 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1116);
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_string);
    _1121 = (int)*(((s1_ptr)_2)->base + _f);
    Ref(_1121);
    _0 = _1121;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1121;
    Ref(_1121);
    ((int *)_2)[2] = 63;
    _1121 = MAKE_SEQ(_1);
    DeRef(_0);
    _0 = _1121;
    _1121 = find(_1116, _1121);
    DeRefDS(_0);
    if (_1121 != 0)
        goto L3;

    // 	    if pattern[p] = '*' then
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(NOTEQ, _1121, 42))
        goto L4;

    // 		while pattern[p] = '*' do
L5:
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(NOTEQ, _1121, 42))
        goto L6;

    // 		    p += 1
    _p = _p + 1;

    // 		end while
    goto L5;
L6:

    // 		if pattern[p] = END_MARKER then
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(NOTEQ, _1121, -1))
        goto L7;

    // 		    return 1
    DeRefDS(_pattern);
    DeRefDS(_string);
    DeRef(_match_string);
    DeRef(_1121);
    DeRef(_1116);
    return 1;
L7:

    // 		match_string = ""
    RefDS(_202);
    DeRef(_match_string);
    _match_string = _202;

    // 		while pattern[p] != '*' do
L8:
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(EQUALS, _1121, 42))
        goto L9;

    // 		    match_string = match_string & pattern[p]
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (IS_SEQUENCE(_match_string) && IS_ATOM(_1121)) {
        Ref(_1121);
        Append(&_match_string, _match_string, _1121);
    }
    else if (IS_ATOM(_match_string) && IS_SEQUENCE(_1121)) {
    }
    else {
        Concat((object_ptr)&_match_string, _match_string, (s1_ptr)_1121);
    }

    // 		    if pattern[p] = END_MARKER then
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(NOTEQ, _1121, -1))
        goto LA;

    // 			exit
    goto L9;
LA:

    // 		    p += 1
    _p = _p + 1;

    // 		end while
    goto L8;
L9:

    // 		if pattern[p] = '*' then
    DeRef(_1121);
    _2 = (int)SEQ_PTR(_pattern);
    _1121 = (int)*(((s1_ptr)_2)->base + _p);
    Ref(_1121);
    if (binary_op_a(NOTEQ, _1121, 42))
        goto LB;

    // 		    p -= 1
    _p = _p - 1;
LB:

    // 		t = qmatch(match_string, string[f..$])
    DeRef(_1121);
    _1121 = SEQ_PTR(_string)->length;
    rhs_slice_target = (object_ptr)&_1121;
    RHS_Slice((s1_ptr)_string, _f, _1121);
    RefDS(_match_string);
    RefDS(_1121);
    _t = _10qmatch(_match_string, _1121);

    // 		if t = 0 then
    if (_t != 0)
        goto LC;

    // 		    return 0
    DeRefDS(_pattern);
    DeRefDS(_string);
    DeRefDS(_match_string);
    DeRefDS(_1121);
    DeRef(_1116);
    return 0;
    goto LD;
LC:

    // 		    f += t + length(match_string) - 2
    DeRef(_1121);
    _1121 = SEQ_PTR(_match_string)->length;
    _1121 = _t + _1121;
    if ((long)((unsigned long)_1121 + (unsigned long)HIGH_BITS) >= 0) 
        _1121 = NewDouble((double)_1121);
    _0 = _1121;
    if (IS_ATOM_INT(_1121)) {
        _1121 = _1121 - 2;
        if ((long)((unsigned long)_1121 +(unsigned long) HIGH_BITS) >= 0)
            _1121 = NewDouble((double)_1121);
    }
    else {
        _1121 = NewDouble(DBL_PTR(_1121)->dbl - (double)2);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_1121)) {
        _f = _f + _1121;
    }
    else {
        _f = NewDouble((double)_f + DBL_PTR(_1121)->dbl);
    }
    if (!IS_ATOM_INT(_f)) {
        _1 = (long)(DBL_PTR(_f)->dbl);
        DeRefDS(_f);
        _f = _1;
    }
LE:
    goto LD;
L4:

    // 		return 0
    DeRefDS(_pattern);
    DeRefDS(_string);
    DeRef(_match_string);
    DeRef(_1121);
    DeRef(_1116);
    return 0;
LD:
L3:

    // 	p += 1
    _p = _p + 1;

    // 	f += 1
    _f = _f + 1;

    // 	if p > length(pattern) then
    DeRef(_1121);
    _1121 = SEQ_PTR(_pattern)->length;
    if (_p <= _1121)
        goto L1;

    // 	    return f > length(string) 
    _1121 = SEQ_PTR(_string)->length;
    _1121 = (_f > _1121);
    DeRefDS(_pattern);
    DeRefDS(_string);
    DeRef(_match_string);
    DeRef(_1116);
    return _1121;
LF:

    //     end while
    goto L1;
L2:

    //     return 0
    DeRefDS(_pattern);
    DeRefDS(_string);
    DeRef(_match_string);
    DeRef(_1121);
    DeRef(_1116);
    return 0;
    ;
}


_10wildcard_file(int _pattern, int _filename)
{
    int _1156;
    int _0, _1, _2;
    

    //     if platform() != LINUX then

    //     if not find('.', pattern) then
    _1156 = find(46, _pattern);
    if (_1156 != 0)
        goto L1;

    // 	pattern = pattern & '.'
    Append(&_pattern, _pattern, 46);
L1:

    //     if not find('.', filename) then
    _1156 = find(46, _filename);
    if (_1156 != 0)
        goto L2;

    // 	filename = filename & '.'
    Append(&_filename, _filename, 46);
L2:

    //     return wildcard_match(pattern, filename)
    RefDS(_pattern);
    RefDS(_filename);
    _1156 = _10wildcard_match(_pattern, _filename);
    DeRefDS(_pattern);
    DeRefDS(_filename);
    return _1156;
    ;
}


