// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_4seek(int _fn, int _pos)
{
    int _345 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }

    //     return machine_func(M_SEEK, {fn, pos})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn;
    ((int *)_2)[2] = _pos;
    Ref(_pos);
    _345 = MAKE_SEQ(_1);
    _0 = _345;
    _345 = machine(19, _345);
    DeRefDS(_0);
    DeRef(_pos);
    return _345;
    ;
}


_4where(int _fn)
{
    int _347 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }

    //     return machine_func(M_WHERE, fn)
    _347 = machine(20, _fn);
    return _347;
    ;
}


_4flush(int _fn)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }

    //     machine_proc(M_FLUSH, fn)
    machine(60, _fn);

    // end procedure
    return 0;
    ;
}


_4lock_file(int _fn, int _t, int _r)
{
    int _360 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }
    if (!IS_ATOM_INT(_t)) {
        _1 = (long)(DBL_PTR(_t)->dbl);
        DeRefDS(_t);
        _t = _1;
    }

    //     return machine_func(M_LOCK_FILE, {fn, t, r})
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _fn;
    *((int *)(_2+8)) = _t;
    RefDS(_r);
    *((int *)(_2+12)) = _r;
    _360 = MAKE_SEQ(_1);
    _0 = _360;
    _360 = machine(61, _360);
    DeRefDS(_0);
    DeRefDS(_r);
    return _360;
    ;
}


_4unlock_file(int _fn, int _r)
{
    int _362 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }

    //     machine_proc(M_UNLOCK_FILE, {fn, r})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn;
    ((int *)_2)[2] = _r;
    RefDS(_r);
    _362 = MAKE_SEQ(_1);
    machine(62, _362);

    // end procedure
    DeRefDS(_r);
    DeRefDS(_362);
    return 0;
    ;
}


_4dir(int _name)
{
    int _363 = 0;
    int _0, _1, _2;
    

    //     return machine_func(M_DIR, name)
    _363 = machine(22, _name);
    DeRefDS(_name);
    return _363;
    ;
}


_4current_dir()
{
    int _364 = 0;
    int _0, _1, _2;
    

    //     return machine_func(M_CURRENT_DIR, 0)
    _364 = machine(23, 0);
    return _364;
    ;
}


_4chdir(int _newdir)
{
    int _365;
    int _0, _1, _2;
    

    //     return machine_func(M_CHDIR, newdir)
    _365 = machine(63, _newdir);
    DeRefDS(_newdir);
    return _365;
    ;
}


_4allow_break(int _b)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_b)) {
        _1 = (long)(DBL_PTR(_b)->dbl);
        DeRefDS(_b);
        _b = _1;
    }

    //     machine_proc(M_ALLOW_BREAK, b)
    machine(42, _b);

    // end procedure
    return 0;
    ;
}


_4check_break()
{
    int _366;
    int _0, _1, _2;
    

    //     return machine_func(M_CHECK_BREAK, 0)
    _366 = machine(43, 0);
    return _366;
    ;
}


int _4default_dir(int _path)
{
    int _d = 0;
    int _367 = 0;
    int _0, _1, _2;
    

    //     d = dir(path)
    RefDS(_path);
    _d = _4dir(_path);

    //     if atom(d) then
    _367 = IS_ATOM(_d);
    if (_367 == 0)
        goto L1;

    // 	return d
    DeRefDS(_path);
    return _d;
    goto L2;
L1:

    // 	return sort(d)
    Ref(_d);
    _0 = _367;
    _367 = _5sort(_d);
    DeRef(_0);
    DeRefDS(_path);
    DeRef(_d);
    return _367;
L2:
    ;
}


_4walk_dir(int _path_name, int _your_function, int _scan_subdirs)
{
    int _d = 0;
    int _abort_now = 0;
    int _381 = 0;
    int _409;
    int _373 = 0;
    int _383 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_your_function)) {
        _1 = (long)(DBL_PTR(_your_function)->dbl);
        DeRefDS(_your_function);
        _your_function = _1;
    }
    if (!IS_ATOM_INT(_scan_subdirs)) {
        _1 = (long)(DBL_PTR(_scan_subdirs)->dbl);
        DeRefDS(_scan_subdirs);
        _scan_subdirs = _1;
    }

    //     if my_dir = DEFAULT then

    // 	d = default_dir(path_name)
    RefDS(_path_name);
    _d = _4default_dir(_path_name);
    goto L1;
L2:

    // 	d = call_func(my_dir, {path_name})
    _0 = _373;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_path_name);
    *((int *)(_2+4)) = _path_name;
    _373 = MAKE_SEQ(_1);
    DeRef(_0);
    _1 = (int)SEQ_PTR(_373);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[-2].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_d);
    _d = _1;
L1:

    //     if atom(d) then
    DeRef(_373);
    _373 = IS_ATOM(_d);
    if (_373 == 0)
        goto L3;

    // 	return W_BAD_PATH
    DeRefDS(_path_name);
    DeRef(_d);
    DeRef(_abort_now);
    DeRef(_381);
    DeRef(_383);
    return -1;
L3:

    //     while length(path_name) > 0 and 
L4:
    DeRef(_373);
    _373 = SEQ_PTR(_path_name)->length;
    _373 = (_373 > 0);
    if (_373 == 0) {
        goto L5;
    }
    DeRef(_381);
    _381 = SEQ_PTR(_path_name)->length;
    _2 = (int)SEQ_PTR(_path_name);
    _381 = (int)*(((s1_ptr)_2)->base + _381);
    Ref(_381);
    DeRef(_383);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 32;
    ((int *)_2)[2] = _4SLASH;
    _383 = MAKE_SEQ(_1);
    _0 = _383;
    _383 = find(_381, _383);
    DeRefDSi(_0);
L6:
    if (_383 == 0)
        goto L5;

    // 	path_name = path_name[1..$-1]
    DeRef(_383);
    _383 = SEQ_PTR(_path_name)->length;
    _383 = _383 - 1;
    rhs_slice_target = (object_ptr)&_path_name;
    RHS_Slice((s1_ptr)_path_name, 1, _383);

    //     end while
    goto L4;
L5:

    //     for i = 1 to length(d) do
    DeRef(_383);
    _383 = SEQ_PTR(_d)->length;
    { int _i;
        _i = 1;
L7:
        if (_i > _383)
            goto L8;

        // 	if find('d', d[i][D_ATTRIBUTES]) then
        DeRef(_381);
        _2 = (int)SEQ_PTR(_d);
        _381 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_381);
        _0 = _381;
        _2 = (int)SEQ_PTR(_381);
        _381 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_381);
        DeRef(_0);
        _0 = _381;
        _381 = find(100, _381);
        DeRef(_0);
        if (_381 == 0)
            goto L9;

        // 	    if not find(d[i][D_NAME], {".", ".."}) then
        _2 = (int)SEQ_PTR(_d);
        _381 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_381);
        _0 = _381;
        _2 = (int)SEQ_PTR(_381);
        _381 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_381);
        DeRef(_0);
        DeRef(_373);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _395;
        RefDS(_395);
        ((int *)_2)[2] = _396;
        RefDS(_396);
        _373 = MAKE_SEQ(_1);
        _0 = _373;
        _373 = find(_381, _373);
        DeRefDS(_0);
        if (_373 != 0)
            goto LA;

        // 		abort_now = call_func(your_function, {path_name, d[i]})
        _2 = (int)SEQ_PTR(_d);
        _373 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_373);
        _0 = _373;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _path_name;
        RefDS(_path_name);
        ((int *)_2)[2] = _373;
        Ref(_373);
        _373 = MAKE_SEQ(_1);
        DeRef(_0);
        _1 = (int)SEQ_PTR(_373);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_your_function].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
        DeRef(_abort_now);
        _abort_now = _1;

        // 		if not equal(abort_now, 0) then
        DeRefDS(_373);
        if (_abort_now == 0)
            _373 = 1;
        else if (IS_ATOM_INT(_abort_now) && IS_ATOM_INT(0))
            _373 = 0;
        else
            _373 = (compare(_abort_now, 0) == 0);
        if (_373 != 0)
            goto LB;

        // 		    return abort_now
        DeRefDS(_path_name);
        DeRef(_d);
        DeRef(_381);
        DeRef(_383);
        return _abort_now;
LB:

        // 		if scan_subdirs then
        if (_scan_subdirs == 0)
            goto LA;

        // 		    abort_now = walk_dir(path_name & SLASH & d[i][D_NAME],
        DeRef(_373);
        _2 = (int)SEQ_PTR(_d);
        _373 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_373);
        _0 = _373;
        _2 = (int)SEQ_PTR(_373);
        _373 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_373);
        DeRef(_0);
        {
            int concat_list[3];

            concat_list[0] = _373;
            concat_list[1] = _4SLASH;
            concat_list[2] = _path_name;
            Concat_N((object_ptr)&_373, concat_list, 3);
        }
        DeRef(_381);
        _381 = _your_function;
        _409 = _scan_subdirs;
        RefDS(_373);
        _0 = _abort_now;
        _abort_now = _4walk_dir(_373, _381, _409);
        DeRef(_0);

        // 		    if not equal(abort_now, 0) and 
        if (_abort_now == 0)
            _409 = 1;
        else if (IS_ATOM_INT(_abort_now) && IS_ATOM_INT(0))
            _409 = 0;
        else
            _409 = (compare(_abort_now, 0) == 0);
        _409 = (_409 == 0);
        if (_409 == 0) {
            goto LA;
        }
        if (_abort_now == -1)
            _381 = 1;
        else if (IS_ATOM_INT(_abort_now) && IS_ATOM_INT(-1))
            _381 = 0;
        else
            _381 = (compare(_abort_now, -1) == 0);
        _381 = (_381 == 0);
LC:
        if (_381 == 0)
            goto LA;

        // 			return abort_now
        DeRefDS(_path_name);
        DeRef(_d);
        DeRef(_381);
        DeRef(_373);
        DeRef(_383);
        return _abort_now;
LD:
LE:
LF:
        goto LA;
L9:

        // 	    abort_now = call_func(your_function, {path_name, d[i]})
        DeRef(_381);
        _2 = (int)SEQ_PTR(_d);
        _381 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_381);
        _0 = _381;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _path_name;
        RefDS(_path_name);
        ((int *)_2)[2] = _381;
        Ref(_381);
        _381 = MAKE_SEQ(_1);
        DeRef(_0);
        _1 = (int)SEQ_PTR(_381);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_your_function].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
        DeRef(_abort_now);
        _abort_now = _1;

        // 	    if not equal(abort_now, 0) then
        DeRefDS(_381);
        if (_abort_now == 0)
            _381 = 1;
        else if (IS_ATOM_INT(_abort_now) && IS_ATOM_INT(0))
            _381 = 0;
        else
            _381 = (compare(_abort_now, 0) == 0);
        if (_381 != 0)
            goto L10;

        // 		return abort_now
        DeRefDS(_path_name);
        DeRef(_d);
        DeRef(_373);
        DeRef(_383);
        return _abort_now;
L10:
LA:

        //     end for
        _i = _i + 1;
        goto L7;
L8:
        ;
    }

    //     return 0
    DeRefDS(_path_name);
    DeRef(_d);
    DeRef(_abort_now);
    DeRef(_381);
    DeRef(_373);
    DeRef(_383);
    return 0;
    ;
}


