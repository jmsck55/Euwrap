// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_11db_delete_record(int _key_location)
{
    int _key_ptr = 0;
    int _nrecs = 0;
    int _records_ptr = 0;
    int _data_ptr = 0;
    int _index_ptr = 0;
    int _current_block = 0;
    int _r;
    int _blocks;
    int _n;
    int _remaining = 0;
    int _1804 = 0;
    int _1801 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location)) {
        _1 = (long)(DBL_PTR(_key_location)->dbl);
        DeRefDS(_key_location);
        _key_location = _1;
    }

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     if key_location < 1 or key_location > length(key_pointers) then
    DeRef(_1801);
    _1801 = (_key_location < 1);
    if (_1801 != 0) {
        goto L2;
    }
    DeRef(_1804);
    _1804 = SEQ_PTR(_11key_pointers)->length;
    _1804 = (_key_location > _1804);
L3:
    if (_1804 == 0)
        goto L4;
L2:

    // 	fatal("bad record number")
    RefDS(_1806);
    _11fatal(_1806);
L4:

    //     key_ptr = key_pointers[key_location]
    DeRef(_key_ptr);
    _2 = (int)SEQ_PTR(_11key_pointers);
    _key_ptr = (int)*(((s1_ptr)_2)->base + _key_location);
    Ref(_key_ptr);

    //     safe_seek(key_ptr)
    Ref(_key_ptr);
    _11safe_seek(_key_ptr);

    //     data_ptr = get4()
    _0 = _data_ptr;
    _data_ptr = _11get4();
    DeRef(_0);

    //     db_free(key_ptr)
    Ref(_key_ptr);
    _11db_free(_key_ptr);

    //     db_free(data_ptr)
    Ref(_data_ptr);
    _11db_free(_data_ptr);

    //     n = length(key_pointers)
    _n = SEQ_PTR(_11key_pointers)->length;

    //     if key_location >= floor(n/2) then
    DeRef(_1804);
    _1804 = _n >> 1;
    if (_key_location < _1804)
        goto L5;

    // 	key_pointers[key_location..n-1] = key_pointers[key_location+1..n]
    _1804 = _n - 1;
    DeRef(_1801);
    _1801 = _key_location + 1;
    rhs_slice_target = (object_ptr)&_1801;
    RHS_Slice((s1_ptr)_11key_pointers, _1801, _n);
    assign_slice_seq = (s1_ptr *)&_11key_pointers;
    AssignSlice(_key_location, _1804, _1801);

    // 	key_pointers = key_pointers[1..n-1]  
    DeRefDS(_1801);
    _1801 = _n - 1;
    rhs_slice_target = (object_ptr)&_11key_pointers;
    RHS_Slice((s1_ptr)_11key_pointers, 1, _1801);
    goto L6;
L5:

    // 	key_pointers[2..key_location] = key_pointers[1..key_location-1]
    DeRef(_1801);
    _1801 = _key_location - 1;
    rhs_slice_target = (object_ptr)&_1801;
    RHS_Slice((s1_ptr)_11key_pointers, 1, _1801);
    assign_slice_seq = (s1_ptr *)&_11key_pointers;
    AssignSlice(2, _key_location, _1801);

    // 	key_pointers = key_pointers[2..n]
    rhs_slice_target = (object_ptr)&_11key_pointers;
    RHS_Slice((s1_ptr)_11key_pointers, 2, _n);
L6:

    //     safe_seek(current_table+4)
    DeRef(_1801);
    if (IS_ATOM_INT(_11current_table)) {
        _1801 = _11current_table + 4;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        _1801 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)4);
    }
    Ref(_1801);
    _11safe_seek(_1801);

    //     nrecs = get4()-1
    _0 = _1801;
    _1801 = _11get4();
    DeRef(_0);
    DeRef(_nrecs);
    if (IS_ATOM_INT(_1801)) {
        _nrecs = _1801 - 1;
        if ((long)((unsigned long)_nrecs +(unsigned long) HIGH_BITS) >= 0)
            _nrecs = NewDouble((double)_nrecs);
    }
    else {
        _nrecs = NewDouble(DBL_PTR(_1801)->dbl - (double)1);
    }

    //     blocks = get4()
    _blocks = _11get4();
    if (!IS_ATOM_INT(_blocks)) {
        _1 = (long)(DBL_PTR(_blocks)->dbl);
        DeRefDS(_blocks);
        _blocks = _1;
    }

    //     safe_seek(current_table+4)
    DeRef(_1801);
    if (IS_ATOM_INT(_11current_table)) {
        _1801 = _11current_table + 4;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        _1801 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)4);
    }
    Ref(_1801);
    _11safe_seek(_1801);

    //     put4(nrecs)
    Ref(_nrecs);
    _11put4(_nrecs);

    //     safe_seek(current_table+12)
    DeRef(_1801);
    if (IS_ATOM_INT(_11current_table)) {
        _1801 = _11current_table + 12;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        _1801 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)12);
    }
    Ref(_1801);
    _11safe_seek(_1801);

    //     index_ptr = get4()
    _0 = _index_ptr;
    _index_ptr = _11get4();
    DeRef(_0);

    //     safe_seek(index_ptr)
    Ref(_index_ptr);
    _11safe_seek(_index_ptr);

    //     r = 0
    _r = 0;

    //     while TRUE do
L7:

    // 	nrecs = get4()
    _0 = _nrecs;
    _nrecs = _11get4();
    DeRef(_0);

    // 	records_ptr = get4()
    _0 = _records_ptr;
    _records_ptr = _11get4();
    DeRef(_0);

    // 	r += nrecs
    if (IS_ATOM_INT(_nrecs)) {
        _r = _r + _nrecs;
    }
    else {
        _r = NewDouble((double)_r + DBL_PTR(_nrecs)->dbl);
    }
    if (!IS_ATOM_INT(_r)) {
        _1 = (long)(DBL_PTR(_r)->dbl);
        DeRefDS(_r);
        _r = _1;
    }

    // 	if r >= key_location then
    if (_r < _key_location)
        goto L7;

    // 	    exit
    goto L8;
L9:

    //     end while
    goto L7;
L8:

    //     r -= nrecs
    if (IS_ATOM_INT(_nrecs)) {
        _r = _r - _nrecs;
    }
    else {
        _r = NewDouble((double)_r - DBL_PTR(_nrecs)->dbl);
    }
    if (!IS_ATOM_INT(_r)) {
        _1 = (long)(DBL_PTR(_r)->dbl);
        DeRefDS(_r);
        _r = _1;
    }

    //     current_block = where(current_db)-8
    _0 = _1801;
    _1801 = _4where(_11current_db);
    DeRef(_0);
    DeRef(_current_block);
    if (IS_ATOM_INT(_1801)) {
        _current_block = _1801 - 8;
        if ((long)((unsigned long)_current_block +(unsigned long) HIGH_BITS) >= 0)
            _current_block = NewDouble((double)_current_block);
    }
    else {
        _current_block = NewDouble(DBL_PTR(_1801)->dbl - (double)8);
    }

    //     nrecs -= 1
    _0 = _nrecs;
    if (IS_ATOM_INT(_nrecs)) {
        _nrecs = _nrecs - 1;
        if ((long)((unsigned long)_nrecs +(unsigned long) HIGH_BITS) >= 0)
            _nrecs = NewDouble((double)_nrecs);
    }
    else {
        _nrecs = NewDouble(DBL_PTR(_nrecs)->dbl - (double)1);
    }
    DeRef(_0);

    //     if nrecs = 0 and blocks > 1 then
    DeRef(_1801);
    if (IS_ATOM_INT(_nrecs)) {
        _1801 = (_nrecs == 0);
    }
    else {
        _1801 = (DBL_PTR(_nrecs)->dbl == (double)0);
    }
    if (_1801 == 0) {
        goto LA;
    }
    DeRef(_1804);
    _1804 = (_blocks > 1);
LB:
    if (_1804 == 0)
        goto LA;

    // 	remaining = get_bytes(current_db, index_ptr+blocks*8-(current_block+8))
    DeRef(_1804);
    if (_blocks == (short)_blocks)
        _1804 = _blocks * 8;
    else
        _1804 = NewDouble(_blocks * (double)8);
    _0 = _1804;
    if (IS_ATOM_INT(_index_ptr) && IS_ATOM_INT(_1804)) {
        _1804 = _index_ptr + _1804;
        if ((long)((unsigned long)_1804 + (unsigned long)HIGH_BITS) >= 0) 
            _1804 = NewDouble((double)_1804);
    }
    else {
        if (IS_ATOM_INT(_index_ptr)) {
            _1804 = NewDouble((double)_index_ptr + DBL_PTR(_1804)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1804)) {
                _1804 = NewDouble(DBL_PTR(_index_ptr)->dbl + (double)_1804);
            }
            else
                _1804 = NewDouble(DBL_PTR(_index_ptr)->dbl + DBL_PTR(_1804)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1801);
    if (IS_ATOM_INT(_current_block)) {
        _1801 = _current_block + 8;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        _1801 = NewDouble(DBL_PTR(_current_block)->dbl + (double)8);
    }
    _0 = _1801;
    if (IS_ATOM_INT(_1804) && IS_ATOM_INT(_1801)) {
        _1801 = _1804 - _1801;
        if ((long)((unsigned long)_1801 +(unsigned long) HIGH_BITS) >= 0)
            _1801 = NewDouble((double)_1801);
    }
    else {
        if (IS_ATOM_INT(_1804)) {
            _1801 = NewDouble((double)_1804 - DBL_PTR(_1801)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1801)) {
                _1801 = NewDouble(DBL_PTR(_1804)->dbl - (double)_1801);
            }
            else
                _1801 = NewDouble(DBL_PTR(_1804)->dbl - DBL_PTR(_1801)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1801);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1801);
    DeRefi(_0);

    // 	safe_seek(current_block)
    Ref(_current_block);
    _11safe_seek(_current_block);

    // 	putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	safe_seek(current_table+8)
    DeRef(_1801);
    if (IS_ATOM_INT(_11current_table)) {
        _1801 = _11current_table + 8;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        _1801 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)8);
    }
    Ref(_1801);
    _11safe_seek(_1801);

    // 	put4(blocks-1)
    DeRef(_1801);
    _1801 = _blocks - 1;
    if ((long)((unsigned long)_1801 +(unsigned long) HIGH_BITS) >= 0)
        _1801 = NewDouble((double)_1801);
    Ref(_1801);
    _11put4(_1801);

    // 	db_free(records_ptr)
    Ref(_records_ptr);
    _11db_free(_records_ptr);
    goto LC;
LA:

    // 	key_location -= r
    _key_location = _key_location - _r;

    // 	safe_seek(current_block)
    Ref(_current_block);
    _11safe_seek(_current_block);

    // 	put4(nrecs)
    Ref(_nrecs);
    _11put4(_nrecs);

    // 	safe_seek(records_ptr+4*(key_location-1))
    DeRef(_1801);
    _1801 = _key_location - 1;
    if ((long)((unsigned long)_1801 +(unsigned long) HIGH_BITS) >= 0)
        _1801 = NewDouble((double)_1801);
    _0 = _1801;
    if (IS_ATOM_INT(_1801)) {
        if (_1801 <= INT15 && _1801 >= -INT15)
            _1801 = 4 * _1801;
        else
            _1801 = NewDouble(4 * (double)_1801);
    }
    else {
        _1801 = NewDouble((double)4 * DBL_PTR(_1801)->dbl);
    }
    DeRef(_0);
    _0 = _1801;
    if (IS_ATOM_INT(_records_ptr) && IS_ATOM_INT(_1801)) {
        _1801 = _records_ptr + _1801;
        if ((long)((unsigned long)_1801 + (unsigned long)HIGH_BITS) >= 0) 
            _1801 = NewDouble((double)_1801);
    }
    else {
        if (IS_ATOM_INT(_records_ptr)) {
            _1801 = NewDouble((double)_records_ptr + DBL_PTR(_1801)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1801)) {
                _1801 = NewDouble(DBL_PTR(_records_ptr)->dbl + (double)_1801);
            }
            else
                _1801 = NewDouble(DBL_PTR(_records_ptr)->dbl + DBL_PTR(_1801)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1801);
    _11safe_seek(_1801);

    // 	for i = key_location to nrecs do
    Ref(_nrecs);
    DeRef(_1801);
    _1801 = _nrecs;
    { int _i;
        _i = _key_location;
LD:
        if (binary_op_a(GREATER, _i, _1801))
            goto LE;

        // 	    put4(key_pointers[i+r])
        DeRef(_1804);
        if (IS_ATOM_INT(_i)) {
            _1804 = _i + _r;
        }
        else {
            _1804 = NewDouble(DBL_PTR(_i)->dbl + (double)_r);
        }
        _0 = _1804;
        _2 = (int)SEQ_PTR(_11key_pointers);
        if (!IS_ATOM_INT(_1804))
            _1804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1804)->dbl));
        else
            _1804 = (int)*(((s1_ptr)_2)->base + _1804);
        Ref(_1804);
        DeRef(_0);
        Ref(_1804);
        _11put4(_1804);

        // 	end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto LD;
LE:
        ;
        DeRef(_i);
    }
LC:

    // end procedure
    DeRef(_key_ptr);
    DeRef(_nrecs);
    DeRef(_records_ptr);
    DeRef(_data_ptr);
    DeRef(_index_ptr);
    DeRef(_current_block);
    DeRefi(_remaining);
    DeRef(_1804);
    DeRef(_1801);
    return 0;
    ;
}


_11db_replace_data(int _rn, int _data)
{
    int _old_size = 0;
    int _new_size;
    int _key_ptr = 0;
    int _data_ptr = 0;
    int _data_string = 0;
    int _1852 = 0;
    int _1855 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rn)) {
        _1 = (long)(DBL_PTR(_rn)->dbl);
        DeRefDS(_rn);
        _rn = _1;
    }

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     if rn < 1 or rn > length(key_pointers) then
    DeRef(_1852);
    _1852 = (_rn < 1);
    if (_1852 != 0) {
        goto L2;
    }
    DeRef(_1855);
    _1855 = SEQ_PTR(_11key_pointers)->length;
    _1855 = (_rn > _1855);
L3:
    if (_1855 == 0)
        goto L4;
L2:

    // 	fatal("bad record number")
    RefDS(_1806);
    _11fatal(_1806);
L4:

    //     key_ptr = key_pointers[rn]
    DeRef(_key_ptr);
    _2 = (int)SEQ_PTR(_11key_pointers);
    _key_ptr = (int)*(((s1_ptr)_2)->base + _rn);
    Ref(_key_ptr);

    //     safe_seek(key_ptr)
    Ref(_key_ptr);
    _11safe_seek(_key_ptr);

    //     data_ptr = get4()
    _0 = _data_ptr;
    _data_ptr = _11get4();
    DeRef(_0);

    //     safe_seek(data_ptr-4)
    DeRef(_1855);
    if (IS_ATOM_INT(_data_ptr)) {
        _1855 = _data_ptr - 4;
        if ((long)((unsigned long)_1855 +(unsigned long) HIGH_BITS) >= 0)
            _1855 = NewDouble((double)_1855);
    }
    else {
        _1855 = NewDouble(DBL_PTR(_data_ptr)->dbl - (double)4);
    }
    Ref(_1855);
    _11safe_seek(_1855);

    //     old_size = get4()-4
    _0 = _1855;
    _1855 = _11get4();
    DeRef(_0);
    DeRef(_old_size);
    if (IS_ATOM_INT(_1855)) {
        _old_size = _1855 - 4;
        if ((long)((unsigned long)_old_size +(unsigned long) HIGH_BITS) >= 0)
            _old_size = NewDouble((double)_old_size);
    }
    else {
        _old_size = NewDouble(DBL_PTR(_1855)->dbl - (double)4);
    }

    //     data_string = compress(data)
    Ref(_data);
    _0 = _data_string;
    _data_string = _11compress(_data);
    DeRef(_0);

    //     new_size = length(data_string)
    _new_size = SEQ_PTR(_data_string)->length;

    //     if new_size <= old_size and 
    DeRef(_1855);
    if (IS_ATOM_INT(_old_size)) {
        _1855 = (_new_size <= _old_size);
    }
    else {
        _1855 = ((double)_new_size <= DBL_PTR(_old_size)->dbl);
    }
    if (_1855 == 0) {
        goto L5;
    }
    DeRef(_1852);
    if (IS_ATOM_INT(_old_size)) {
        _1852 = _old_size - 8;
        if ((long)((unsigned long)_1852 +(unsigned long) HIGH_BITS) >= 0)
            _1852 = NewDouble((double)_1852);
    }
    else {
        _1852 = NewDouble(DBL_PTR(_old_size)->dbl - (double)8);
    }
    _0 = _1852;
    if (IS_ATOM_INT(_1852)) {
        _1852 = (_new_size >= _1852);
    }
    else {
        _1852 = ((double)_new_size >= DBL_PTR(_1852)->dbl);
    }
    DeRef(_0);
L6:
    if (_1852 == 0)
        goto L5;

    // 	safe_seek(data_ptr)
    Ref(_data_ptr);
    _11safe_seek(_data_ptr);
    goto L7;
L5:

    // 	db_free(data_ptr)
    Ref(_data_ptr);
    _11db_free(_data_ptr);

    // 	data_ptr = db_allocate(new_size)
    _0 = _data_ptr;
    _data_ptr = _11db_allocate(_new_size);
    DeRef(_0);

    // 	safe_seek(key_ptr)
    Ref(_key_ptr);
    _11safe_seek(_key_ptr);

    // 	put4(data_ptr)
    Ref(_data_ptr);
    _11put4(_data_ptr);

    // 	safe_seek(data_ptr)
    Ref(_data_ptr);
    _11safe_seek(_data_ptr);
L7:

    //     putn(data_string)
    RefDS(_data_string);
    _11putn(_data_string);

    // end procedure
    DeRef(_data);
    DeRef(_old_size);
    DeRef(_key_ptr);
    DeRef(_data_ptr);
    DeRefDS(_data_string);
    DeRef(_1852);
    DeRef(_1855);
    return 0;
    ;
}


_11db_table_size()
{
    int _1869;
    int _0, _1, _2;
    

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     return length(key_pointers)
    _1869 = SEQ_PTR(_11key_pointers)->length;
    return _1869;
    ;
}


_11db_record_data(int _rn)
{
    int _data_ptr = 0;
    int _data_value = 0;
    int _1874 = 0;
    int _1871;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rn)) {
        _1 = (long)(DBL_PTR(_rn)->dbl);
        DeRefDS(_rn);
        _rn = _1;
    }

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     if rn < 1 or rn > length(key_pointers) then
    _1871 = (_rn < 1);
    if (_1871 != 0) {
        goto L2;
    }
    DeRef(_1874);
    _1874 = SEQ_PTR(_11key_pointers)->length;
    _1874 = (_rn > _1874);
L3:
    if (_1874 == 0)
        goto L4;
L2:

    // 	fatal("bad record number")
    RefDS(_1806);
    _11fatal(_1806);
L4:

    //     safe_seek(key_pointers[rn])
    DeRef(_1874);
    _2 = (int)SEQ_PTR(_11key_pointers);
    _1874 = (int)*(((s1_ptr)_2)->base + _rn);
    Ref(_1874);
    Ref(_1874);
    _11safe_seek(_1874);

    //     data_ptr = get4()
    _0 = _data_ptr;
    _data_ptr = _11get4();
    DeRef(_0);

    //     safe_seek(data_ptr)
    Ref(_data_ptr);
    _11safe_seek(_data_ptr);

    //     data_value = decompress(0)
    _0 = _data_value;
    _data_value = _11decompress(0);
    DeRef(_0);

    //     return data_value
    DeRef(_data_ptr);
    DeRef(_1874);
    return _data_value;
    ;
}


_11db_record_key(int _rn)
{
    int _key_value = 0;
    int _1882 = 0;
    int _1879;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rn)) {
        _1 = (long)(DBL_PTR(_rn)->dbl);
        DeRefDS(_rn);
        _rn = _1;
    }

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     if rn < 1 or rn > length(key_pointers) then
    _1879 = (_rn < 1);
    if (_1879 != 0) {
        goto L2;
    }
    DeRef(_1882);
    _1882 = SEQ_PTR(_11key_pointers)->length;
    _1882 = (_rn > _1882);
L3:
    if (_1882 == 0)
        goto L4;
L2:

    // 	fatal("bad record number")
    RefDS(_1806);
    _11fatal(_1806);
L4:

    //     safe_seek(key_pointers[rn]+4)
    DeRef(_1882);
    _2 = (int)SEQ_PTR(_11key_pointers);
    _1882 = (int)*(((s1_ptr)_2)->base + _rn);
    Ref(_1882);
    _0 = _1882;
    if (IS_ATOM_INT(_1882)) {
        _1882 = _1882 + 4;
        if ((long)((unsigned long)_1882 + (unsigned long)HIGH_BITS) >= 0) 
            _1882 = NewDouble((double)_1882);
    }
    else {
        _1882 = binary_op(PLUS, _1882, 4);
    }
    DeRef(_0);
    Ref(_1882);
    _11safe_seek(_1882);

    //     key_value = decompress(0)
    _0 = _key_value;
    _key_value = _11decompress(0);
    DeRef(_0);

    //     return key_value
    DeRef(_1882);
    return _key_value;
    ;
}


int _11name_only(int _s)
{
    int _filename = 0;
    int _1887 = 0;
    int _0, _1, _2;
    

    //     filename = ""
    RefDS(_202);
    _filename = _202;

    //     for i = length(s) to 1 by -1 do
    _1887 = SEQ_PTR(_s)->length;
    { int _i;
        _i = _1887;
L1:
        if (_i < 1)
            goto L2;

        // 	if find(s[i], SLASH_CHAR) then
        DeRef(_1887);
        _2 = (int)SEQ_PTR(_s);
        _1887 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1887);
        _0 = _1887;
        _1887 = find(_1887, _11SLASH_CHAR);
        DeRef(_0);
        if (_1887 == 0)
            goto L3;

        // 	    exit
        goto L2;
L3:

        // 	filename = s[i] & filename
        DeRef(_1887);
        _2 = (int)SEQ_PTR(_s);
        _1887 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1887);
        if (IS_SEQUENCE(_1887) && IS_ATOM(_filename)) {
        }
        else if (IS_ATOM(_1887) && IS_SEQUENCE(_filename)) {
            Ref(_1887);
            Prepend(&_filename, _filename, _1887);
        }
        else {
            Concat((object_ptr)&_filename, _1887, (s1_ptr)_filename);
        }

        //     end for
        _i = _i + -1;
        goto L1;
L2:
        ;
    }

    //     return filename
    DeRefDS(_s);
    DeRef(_1887);
    return _filename;
    ;
}


int _11delete_whitespace(int _text)
{
    int _1892 = 0;
    int _1895 = 0;
    int _0, _1, _2;
    

    //     while length(text) > 0 and find(text[1], " \t\r\n") do
L1:
    DeRef(_1892);
    _1892 = SEQ_PTR(_text)->length;
    _1892 = (_1892 > 0);
    if (_1892 == 0) {
        goto L2;
    }
    DeRef(_1895);
    _2 = (int)SEQ_PTR(_text);
    _1895 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1895);
    _0 = _1895;
    _1895 = find(_1895, _1896);
    DeRef(_0);
L3:
    if (_1895 == 0)
        goto L2;

    // 	text = text[2..$]
    DeRef(_1895);
    _1895 = SEQ_PTR(_text)->length;
    rhs_slice_target = (object_ptr)&_text;
    RHS_Slice((s1_ptr)_text, 2, _1895);

    //     end while
    goto L1;
L2:

    //     while length(text) > 0 and find(text[length(text)], " \t\r\n") do
L4:
    DeRef(_1895);
    _1895 = SEQ_PTR(_text)->length;
    _1895 = (_1895 > 0);
    if (_1895 == 0) {
        goto L5;
    }
    DeRef(_1892);
    _1892 = SEQ_PTR(_text)->length;
    _2 = (int)SEQ_PTR(_text);
    _1892 = (int)*(((s1_ptr)_2)->base + _1892);
    Ref(_1892);
    _0 = _1892;
    _1892 = find(_1892, _1896);
    DeRef(_0);
L6:
    if (_1892 == 0)
        goto L5;

    // 	text = text[1..$-1]
    DeRef(_1892);
    _1892 = SEQ_PTR(_text)->length;
    _1892 = _1892 - 1;
    rhs_slice_target = (object_ptr)&_text;
    RHS_Slice((s1_ptr)_text, 1, _1892);

    //     end while
    goto L4;
L5:

    //     return text
    DeRef(_1892);
    DeRef(_1895);
    return _text;
    ;
}


_11db_compress()
{
    int _index;
    int _chunk_size;
    int _nrecs;
    int _r;
    int _fn;
    int _new_path = 0;
    int _old_path = 0;
    int _table_list = 0;
    int _record = 0;
    int _chunk = 0;
    int _1909 = 0;
    int _1961 = 0;
    int _1962 = 0;
    int _1919 = 0;
    int _0, _1, _2;
    

    //     if current_db = -1 then
    if (_11current_db != -1)
        goto L1;

    // 	fatal("no current database")
    RefDS(_1910);
    _11fatal(_1910);
L1:

    //     index = find(current_db, db_file_nums)
    _index = find(_11current_db, _11db_file_nums);

    //     new_path = delete_whitespace(db_names[index])
    DeRef(_1909);
    _2 = (int)SEQ_PTR(_11db_names);
    _1909 = (int)*(((s1_ptr)_2)->base + _index);
    Ref(_1909);
    Ref(_1909);
    _0 = _new_path;
    _new_path = _11delete_whitespace(_1909);
    DeRef(_0);

    //     db_close()
    _11db_close();

    //     fn = -1
    _fn = -1;

    //     for i = 0 to 99 do
    { int _i;
        _i = 0;
L2:
        if (_i > 99)
            goto L3;

        // 	old_path = new_path[1..$-3] & sprintf("t%d", i)
        DeRef(_1909);
        _1909 = SEQ_PTR(_new_path)->length;
        _1909 = _1909 - 3;
        rhs_slice_target = (object_ptr)&_1909;
        RHS_Slice((s1_ptr)_new_path, 1, _1909);
        DeRef(_1919);
        _1919 = EPrintf(-9999999, _1918, _i);
        Concat((object_ptr)&_old_path, _1909, (s1_ptr)_1919);

        // 	fn = open(old_path, "r") 
        _fn = EOpen(_old_path, _1921);

        // 	if fn = -1 then
        if (_fn != -1)
            goto L4;

        // 	    exit
        goto L3;
        goto L5;
L4:

        // 	    close(fn)
        EClose(_fn);
L5:

        //     end for
        _i = _i + 1;
        goto L2;
L3:
        ;
    }

    //     if fn != -1 then
    if (_fn == -1)
        goto L6;

    // 	return DB_EXISTS_ALREADY -- you better delete some temp files
    DeRef(_new_path);
    DeRef(_old_path);
    DeRef(_table_list);
    DeRef(_record);
    DeRef(_chunk);
    DeRef(_1909);
    DeRef(_1961);
    DeRef(_1962);
    DeRef(_1919);
    return -2;
L6:

    //     if platform() = LINUX then

    // 	system( "mv \"" & new_path & "\" \"" & old_path & '"', 2)
    {
        int concat_list[5];

        concat_list[0] = 34;
        concat_list[1] = _old_path;
        concat_list[2] = _1927;
        concat_list[3] = _new_path;
        concat_list[4] = _1926;
        Concat_N((object_ptr)&_1919, concat_list, 5);
    }
    system_call(_1919, 2);
    goto L7;
L8:

    //     elsif platform() = WIN32 then

    // 	system("ren " & new_path & " " & name_only(old_path), 2)
    RefDS(_old_path);
    _0 = _1919;
    _1919 = _11name_only(_old_path);
    DeRef(_0);
    {
        int concat_list[4];

        concat_list[0] = _1919;
        concat_list[1] = _1934;
        concat_list[2] = _new_path;
        concat_list[3] = _1933;
        Concat_N((object_ptr)&_1919, concat_list, 4);
    }
    system_call(_1919, 2);
L7:

    //     index = db_create(new_path, DB_LOCK_NO)
    RefDS(_new_path);
    _index = _11db_create(_new_path, 0);

    //     if index != DB_OK then
    if (_index == 0)
        goto L9;

    // 	if platform() = LINUX then

    // 	    system( "mv \"" & old_path & "\" \"" & new_path & '"', 2)
    {
        int concat_list[5];

        concat_list[0] = 34;
        concat_list[1] = _new_path;
        concat_list[2] = _1927;
        concat_list[3] = _old_path;
        concat_list[4] = _1926;
        Concat_N((object_ptr)&_1919, concat_list, 5);
    }
    system_call(_1919, 2);
    goto LA;
LB:

    // 	elsif platform() = WIN32 then

    // 	    system("ren " & old_path & " " & name_only(new_path), 2)
    RefDS(_new_path);
    _0 = _1919;
    _1919 = _11name_only(_new_path);
    DeRef(_0);
    {
        int concat_list[4];

        concat_list[0] = _1919;
        concat_list[1] = _1934;
        concat_list[2] = _old_path;
        concat_list[3] = _1933;
        Concat_N((object_ptr)&_1919, concat_list, 4);
    }
    system_call(_1919, 2);
LA:

    // 	return index
    DeRef(_new_path);
    DeRef(_old_path);
    DeRef(_table_list);
    DeRef(_record);
    DeRef(_chunk);
    DeRef(_1909);
    DeRef(_1961);
    DeRef(_1962);
    DeRef(_1919);
    return _index;
L9:

    //     index = db_open(old_path, DB_LOCK_NO)
    RefDS(_old_path);
    _index = _11db_open(_old_path, 0);

    //     table_list = db_table_list()
    _0 = _table_list;
    _table_list = _11db_table_list();
    DeRef(_0);

    //     for i = 1 to length(table_list) do
    DeRef(_1919);
    _1919 = SEQ_PTR(_table_list)->length;
    { int _i;
        _i = 1;
LC:
        if (_i > _1919)
            goto LD;

        // 	index = db_select(new_path)
        RefDS(_new_path);
        _index = _11db_select(_new_path);

        // 	index = db_create_table(table_list[i])
        DeRef(_1909);
        _2 = (int)SEQ_PTR(_table_list);
        _1909 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1909);
        Ref(_1909);
        _index = _11db_create_table(_1909);

        // 	index = db_select(old_path)
        RefDS(_old_path);
        _index = _11db_select(_old_path);

        // 	index = db_select_table(table_list[i])
        DeRef(_1909);
        _2 = (int)SEQ_PTR(_table_list);
        _1909 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1909);
        Ref(_1909);
        _index = _11db_select_table(_1909);

        // 	nrecs = db_table_size()
        _nrecs = _11db_table_size();

        // 	r = 1
        _r = 1;

        // 	while r <= nrecs do
LE:
        if (_r > _nrecs)
            goto LF;

        // 	    chunk_size = nrecs - r + 1
        DeRef(_1909);
        _1909 = _nrecs - _r;
        if ((long)((unsigned long)_1909 +(unsigned long) HIGH_BITS) >= 0)
            _1909 = NewDouble((double)_1909);
        if (IS_ATOM_INT(_1909)) {
            _chunk_size = _1909 + 1;
        }
        else
            _chunk_size = 1+(long)(DBL_PTR(_1909)->dbl);

        // 	    if chunk_size > 20 then
        if (_chunk_size <= 20)
            goto L10;

        // 		chunk_size = 20  -- copy up to 20 records at a time
        _chunk_size = 20;
L10:

        // 	    chunk = {}
        RefDS(_202);
        DeRef(_chunk);
        _chunk = _202;

        // 	    for j = 1 to chunk_size do
        DeRef(_1909);
        _1909 = _chunk_size;
        { int _j;
            _j = 1;
L11:
            if (_j > _1909)
                goto L12;

            // 		record = {db_record_key(r), db_record_data(r)}
            _0 = _1961;
            _1961 = _11db_record_key(_r);
            DeRef(_0);
            _0 = _1962;
            _1962 = _11db_record_data(_r);
            DeRef(_0);
            DeRef(_record);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _1961;
            Ref(_1961);
            ((int *)_2)[2] = _1962;
            Ref(_1962);
            _record = MAKE_SEQ(_1);

            // 		r += 1
            _r = _r + 1;

            // 		chunk = append(chunk, record)
            RefDS(_record);
            Append(&_chunk, _chunk, _record);

            // 	    end for
            _j = _j + 1;
            goto L11;
L12:
            ;
        }

        // 	    index = db_select(new_path)
        RefDS(_new_path);
        _index = _11db_select(_new_path);

        // 	    index = db_select_table(table_list[i])
        DeRef(_1962);
        _2 = (int)SEQ_PTR(_table_list);
        _1962 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1962);
        Ref(_1962);
        _index = _11db_select_table(_1962);

        // 	    for j = 1 to chunk_size do
        DeRef(_1962);
        _1962 = _chunk_size;
        { int _j;
            _j = 1;
L13:
            if (_j > _1962)
                goto L14;

            // 		if db_insert(chunk[j][1], chunk[j][2]) != DB_OK then
            DeRef(_1961);
            _2 = (int)SEQ_PTR(_chunk);
            _1961 = (int)*(((s1_ptr)_2)->base + _j);
            RefDS(_1961);
            _0 = _1961;
            _2 = (int)SEQ_PTR(_1961);
            _1961 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_1961);
            DeRefDS(_0);
            DeRef(_1909);
            _2 = (int)SEQ_PTR(_chunk);
            _1909 = (int)*(((s1_ptr)_2)->base + _j);
            RefDS(_1909);
            _0 = _1909;
            _2 = (int)SEQ_PTR(_1909);
            _1909 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_1909);
            DeRefDS(_0);
            Ref(_1961);
            Ref(_1909);
            _0 = _1909;
            _1909 = _11db_insert(_1961, _1909);
            DeRef(_0);
            if (_1909 == 0)
                goto L15;

            // 		    fatal("couldn't insert into new database")
            RefDS(_1976);
            _11fatal(_1976);
L15:

            // 	    end for
            _j = _j + 1;
            goto L13;
L14:
            ;
        }

        // 	    index = db_select(old_path)
        RefDS(_old_path);
        _index = _11db_select(_old_path);

        // 	    index = db_select_table(table_list[i])        
        DeRef(_1909);
        _2 = (int)SEQ_PTR(_table_list);
        _1909 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1909);
        Ref(_1909);
        _index = _11db_select_table(_1909);

        // 	end while
        goto LE;
LF:

        //     end for
        _i = _i + 1;
        goto LC;
LD:
        ;
    }

    //     db_close()
    _11db_close();

    //     index = db_select(new_path)
    RefDS(_new_path);
    _index = _11db_select(_new_path);

    //     return DB_OK
    DeRefDS(_new_path);
    DeRef(_old_path);
    DeRef(_table_list);
    DeRef(_record);
    DeRef(_chunk);
    DeRef(_1909);
    DeRef(_1961);
    DeRef(_1962);
    DeRef(_1919);
    return 0;
    ;
}


