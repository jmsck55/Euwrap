// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_6instance()
{
    int _175 = 0;
    int _0, _1, _2;
    

    //     return machine_func(M_INSTANCE, 0)
    _175 = machine(55, 0);
    return _175;
    ;
}


_6sleep(int _t)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t)) {
        _1 = (long)(DBL_PTR(_t)->dbl);
        DeRefDS(_t);
        _t = _1;
    }

    //     if t >= 0 then
    if (_t < 0)
        goto L1;

    // 	machine_proc(M_SLEEP, t)
    machine(64, _t);
L1:

    // end procedure
    return 0;
    ;
}


_6reverse(int _s)
{
    int _lower;
    int _n;
    int _n2;
    int _t = 0;
    int _183 = 0;
    int _177;
    int _0, _1, _2;
    

    //     n = length(s)
    _n = SEQ_PTR(_s)->length;

    //     n2 = floor(n/2)+1
    _177 = _n >> 1;
    _n2 = _177 + 1;

    //     t = repeat(0, n)
    _t = Repeat(0, _n);

    //     lower = 1
    _lower = 1;

    //     for upper = n to n2 by -1 do
    _177 = _n2;
    { int _upper;
        _upper = _n;
L1:
        if (_upper < _177)
            goto L2;

        // 	t[upper] = s[lower]
        DeRef(_183);
        _2 = (int)SEQ_PTR(_s);
        _183 = (int)*(((s1_ptr)_2)->base + _lower);
        Ref(_183);
        Ref(_183);
        _2 = (int)SEQ_PTR(_t);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _upper);
        _1 = *(int *)_2;
        *(int *)_2 = _183;
        DeRef(_1);

        // 	t[lower] = s[upper]
        DeRef(_183);
        _2 = (int)SEQ_PTR(_s);
        _183 = (int)*(((s1_ptr)_2)->base + _upper);
        Ref(_183);
        Ref(_183);
        _2 = (int)SEQ_PTR(_t);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lower);
        _1 = *(int *)_2;
        *(int *)_2 = _183;
        DeRef(_1);

        // 	lower += 1
        _lower = _lower + 1;

        //     end for
        _upper = _upper + -1;
        goto L1;
L2:
        ;
    }

    //     return t
    DeRefDS(_s);
    DeRef(_183);
    return _t;
    ;
}


_6sprint(int _x)
{
    int _s = 0;
    int _191 = 0;
    int _186 = 0;
    int _0, _1, _2;
    

    //     if atom(x) then
    _186 = IS_ATOM(_x);
    if (_186 == 0)
        goto L1;

    // 	return sprintf("%.10g", x)
    _186 = EPrintf(-9999999, _187, _x);
    DeRef(_x);
    return _186;
    goto L2;
L1:

    // 	s = "{"
    RefDS(_189);
    DeRef(_s);
    _s = _189;

    // 	for i = 1 to length(x) do
    DeRef(_186);
    _186 = SEQ_PTR(_x)->length;
    { int _i;
        _i = 1;
L3:
        if (_i > _186)
            goto L4;

        // 	    s &= sprint(x[i])  
        DeRef(_191);
        _2 = (int)SEQ_PTR(_x);
        _191 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_191);
        Ref(_191);
        _0 = _191;
        _191 = _6sprint(_191);
        DeRef(_0);
        Concat((object_ptr)&_s, _s, (s1_ptr)_191);

        // 	    if i < length(x) then
        DeRefDS(_191);
        _191 = SEQ_PTR(_x)->length;
        if (_i >= _191)
            goto L5;

        // 		s &= ','
        Append(&_s, _s, 44);
L5:

        // 	end for
        _i = _i + 1;
        goto L3;
L4:
        ;
    }

    // 	s &= "}"
    Concat((object_ptr)&_s, _s, (s1_ptr)_198);

    // 	return s
    DeRef(_x);
    DeRef(_191);
    DeRef(_186);
    return _s;
L2:
    ;
}


int _6pretty_out(int _text)
{
    int _200;
    int _0, _1, _2;
    

    //     pretty_line &= text
    if (IS_SEQUENCE(_6pretty_line) && IS_ATOM(_text)) {
        Ref(_text);
        Append(&_6pretty_line, _6pretty_line, _text);
    }
    else if (IS_ATOM(_6pretty_line) && IS_SEQUENCE(_text)) {
    }
    else {
        Concat((object_ptr)&_6pretty_line, _6pretty_line, (s1_ptr)_text);
    }

    //     if equal(text, '\n') then
    if (_text == 10)
        _200 = 1;
    else if (IS_ATOM_INT(_text) && IS_ATOM_INT(10))
        _200 = 0;
    else
        _200 = (compare(_text, 10) == 0);
    if (_200 == 0)
        goto L1;

    // 	puts(pretty_file, pretty_line)
    EPuts(_6pretty_file, _6pretty_line);

    // 	pretty_line = ""
    RefDS(_202);
    DeRefDS(_6pretty_line);
    _6pretty_line = _202;

    // 	pretty_line_count += 1
    _6pretty_line_count = _6pretty_line_count + 1;
L1:

    //     if atom(text) then
    _200 = IS_ATOM(_text);
    if (_200 == 0)
        goto L2;

    // 	pretty_chars += 1
    _6pretty_chars = _6pretty_chars + 1;
    goto L3;
L2:

    // 	pretty_chars += length(text)
    _200 = SEQ_PTR(_text)->length;
    _6pretty_chars = _6pretty_chars + _200;
L3:

    // end procedure
    DeRef(_text);
    return 0;
    ;
}


int _6cut_line(int _n)
{
    int _208 = 0;
    int _0, _1, _2;
    

    //     if pretty_chars + n > pretty_end_col then
    _208 = _6pretty_chars + _n;
    if ((long)((unsigned long)_208 + (unsigned long)HIGH_BITS) >= 0) 
        _208 = NewDouble((double)_208);
    if (binary_op_a(LESSEQ, _208, _6pretty_end_col))
        goto L1;

    // 	pretty_out('\n')
    _6pretty_out(10);

    // 	pretty_chars = 0
    _6pretty_chars = 0;
L1:

    // end procedure
    DeRef(_208);
    return 0;
    ;
}


int _6indent()
{
    int _212 = 0;
    int _210 = 0;
    int _0, _1, _2;
    

    //     if pretty_chars > 0 then
    if (_6pretty_chars <= 0)
        goto L1;

    // 	pretty_out('\n')
    _6pretty_out(10);

    // 	pretty_chars = 0
    _6pretty_chars = 0;
L1:

    //     pretty_out(repeat(' ', (pretty_start_col-1) + 
    DeRef(_210);
    _210 = _6pretty_start_col - 1;
    if ((long)((unsigned long)_210 +(unsigned long) HIGH_BITS) >= 0)
        _210 = NewDouble((double)_210);
    DeRef(_212);
    if (_6pretty_level == (short)_6pretty_level && _6pretty_indent <= INT15 && _6pretty_indent >= -INT15)
        _212 = _6pretty_level * _6pretty_indent;
    else
        _212 = NewDouble(_6pretty_level * (double)_6pretty_indent);
    _0 = _212;
    if (IS_ATOM_INT(_210) && IS_ATOM_INT(_212)) {
        _212 = _210 + _212;
    }
    else {
        if (IS_ATOM_INT(_210)) {
            _212 = NewDouble((double)_210 + DBL_PTR(_212)->dbl);
        }
        else {
            if (IS_ATOM_INT(_212)) {
                _212 = NewDouble(DBL_PTR(_210)->dbl + (double)_212);
            }
            else
                _212 = NewDouble(DBL_PTR(_210)->dbl + DBL_PTR(_212)->dbl);
        }
    }
    DeRef(_0);
    _0 = _212;
    _212 = Repeat(32, _212);
    DeRef(_0);
    RefDS(_212);
    _6pretty_out(_212);

    // end procedure
    DeRefDSi(_212);
    DeRef(_210);
    return 0;
    ;
}


int _6show(int _a)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a)) {
        _1 = (long)(DBL_PTR(_a)->dbl);
        DeRefDS(_a);
        _a = _1;
    }

    //     if a = '\t' then
    if (_a != 9)
        goto L1;

    // 	return "\\t"
    RefDS(_216);
    return _216;
    goto L2;
L1:

    //     elsif a = '\n' then
    if (_a != 10)
        goto L3;

    // 	return "\\n"
    RefDS(_218);
    return _218;
    goto L2;
L3:

    //     elsif a = '\r' then
    if (_a != 13)
        goto L4;

    // 	return "\\r"
    RefDS(_221);
    return _221;
    goto L2;
L4:

    // 	return a
    return _a;
L2:
    ;
}


int _6rPrint(int _a)
{
    int _sbuff = 0;
    int _multi_line;
    int _all_ascii;
    int _228 = 0;
    int _257 = 0;
    int _255 = 0;
    int _245 = 0;
    int _222 = 0;
    int _0, _1, _2;
    

    //     if atom(a) then
    _222 = IS_ATOM(_a);
    if (_222 == 0)
        goto L1;

    // 	if integer(a) then
    if (IS_ATOM_INT(_a))
        _222 = 1;
    else if (IS_ATOM_DBL(_a))
        _222 = IS_ATOM_INT(DoubleToInt(_a));
    else
        _222 = 0;
    if (_222 == 0)
        goto L2;

    // 	    sbuff = sprintf(pretty_int_format, a)
    _sbuff = EPrintf(-9999999, _6pretty_int_format, _a);

    // 	    if pretty_ascii then 
    if (_6pretty_ascii == 0)
        goto L3;

    // 		if pretty_ascii >= 3 then 
    if (_6pretty_ascii < 3)
        goto L4;

    // 		    if (a >= pretty_ascii_min and a <= pretty_ascii_max) then
    if (IS_ATOM_INT(_a)) {
        _222 = (_a >= _6pretty_ascii_min);
    }
    else {
        _222 = binary_op(GREATEREQ, _a, _6pretty_ascii_min);
    }
    if (IS_ATOM_INT(_222)) {
        if (_222 == 0) {
            DeRef(_222);
            _222 = 0;
            goto L5;
        }
    }
    else {
        if (DBL_PTR(_222)->dbl == 0.0) {
            DeRef(_222);
            _222 = 0;
            goto L5;
        }
    }
    if (IS_ATOM_INT(_a)) {
        _228 = (_a <= _6pretty_ascii_max);
    }
    else {
        _228 = binary_op(LESSEQ, _a, _6pretty_ascii_max);
    }
    DeRef(_222);
    if (IS_ATOM_INT(_228))
        _222 = (_228 != 0);
    else
        _222 = DBL_PTR(_228)->dbl != 0.0;
L5:
    if (_222 == 0)
        goto L6;

    // 			sbuff = '\'' & a & '\''  -- display char only
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff, concat_list, 3);
    }
    goto L3;
L6:

    // 		    elsif find(a, "\t\n\r") then
    DeRef(_228);
    _228 = find(_a, _230);
    if (_228 == 0)
        goto L3;

    // 			sbuff = '\'' & show(a) & '\''  -- display char only
    Ref(_a);
    _228 = _6show(_a);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _228;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff, concat_list, 3);
    }
L7:
L8:
    goto L3;
L4:

    // 		    if (a >= pretty_ascii_min and a <= pretty_ascii_max) then
    DeRef(_228);
    if (IS_ATOM_INT(_a)) {
        _228 = (_a >= _6pretty_ascii_min);
    }
    else {
        _228 = binary_op(GREATEREQ, _a, _6pretty_ascii_min);
    }
    if (IS_ATOM_INT(_228)) {
        if (_228 == 0) {
            DeRef(_228);
            _228 = 0;
            goto L9;
        }
    }
    else {
        if (DBL_PTR(_228)->dbl == 0.0) {
            DeRef(_228);
            _228 = 0;
            goto L9;
        }
    }
    DeRef(_222);
    if (IS_ATOM_INT(_a)) {
        _222 = (_a <= _6pretty_ascii_max);
    }
    else {
        _222 = binary_op(LESSEQ, _a, _6pretty_ascii_max);
    }
    DeRef(_228);
    if (IS_ATOM_INT(_222))
        _228 = (_222 != 0);
    else
        _228 = DBL_PTR(_222)->dbl != 0.0;
L9:
    if (_228 == 0)
        goto L3;

    // 			sbuff &= '\'' & a & '\'' -- add to numeric display
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_222, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff, _sbuff, (s1_ptr)_222);
LA:
LB:
LC:
    goto L3;
L2:

    // 	    sbuff = sprintf(pretty_fp_format, a)
    DeRef(_sbuff);
    _sbuff = EPrintf(-9999999, _6pretty_fp_format, _a);
L3:

    // 	pretty_out(sbuff)
    RefDS(_sbuff);
    _6pretty_out(_sbuff);
    goto LD;
L1:

    // 	cut_line(1)
    _6cut_line(1);

    // 	multi_line = 0
    _multi_line = 0;

    // 	all_ascii = pretty_ascii > 1
    _all_ascii = (_6pretty_ascii > 1);

    // 	for i = 1 to length(a) do
    DeRef(_222);
    _222 = SEQ_PTR(_a)->length;
    { int _i;
        _i = 1;
LE:
        if (_i > _222)
            goto LF;

        // 	    if sequence(a[i]) and length(a[i]) > 0 then
        DeRef(_228);
        _2 = (int)SEQ_PTR(_a);
        _228 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_228);
        _0 = _228;
        _228 = IS_SEQUENCE(_228);
        DeRef(_0);
        if (_228 == 0) {
            goto L10;
        }
        DeRef(_245);
        _2 = (int)SEQ_PTR(_a);
        _245 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_245);
        _0 = _245;
        _245 = SEQ_PTR(_245)->length;
        DeRef(_0);
        _245 = (_245 > 0);
L11:
        if (_245 == 0)
            goto L10;

        // 		multi_line = 1
        _multi_line = 1;

        // 		all_ascii = 0
        _all_ascii = 0;

        // 		exit
        goto LF;
L10:

        // 	    if not integer(a[i]) or
        DeRef(_245);
        _2 = (int)SEQ_PTR(_a);
        _245 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_245);
        _0 = _245;
        if (IS_ATOM_INT(_245))
            _245 = 1;
        else if (IS_ATOM_DBL(_245))
            _245 = IS_ATOM_INT(DoubleToInt(_245));
        else
            _245 = 0;
        DeRef(_0);
        _245 = (_245 == 0);
        if (_245 != 0) {
            _245 = 1;
            goto L12;
        }
        DeRef(_228);
        _2 = (int)SEQ_PTR(_a);
        _228 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_228);
        _0 = _228;
        if (IS_ATOM_INT(_228)) {
            _228 = (_228 < _6pretty_ascii_min);
        }
        else {
            _228 = binary_op(LESS, _228, _6pretty_ascii_min);
        }
        DeRef(_0);
        if (IS_ATOM_INT(_228)) {
            if (_228 == 0) {
                DeRef(_228);
                _228 = 0;
                goto L13;
            }
        }
        else {
            if (DBL_PTR(_228)->dbl == 0.0) {
                DeRef(_228);
                _228 = 0;
                goto L13;
            }
        }
        DeRef(_255);
        _255 = (_6pretty_ascii < 3);
        if (_255 != 0) {
            _255 = 1;
            goto L14;
        }
        DeRef(_257);
        _2 = (int)SEQ_PTR(_a);
        _257 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_257);
        _0 = _257;
        _257 = find(_257, _258);
        DeRef(_0);
        _257 = (_257 == 0);
        _255 = (_257 != 0);
L14:
        DeRef(_228);
        _228 = (_255 != 0);
L13:
        DeRef(_245);
        _245 = (_228 != 0);
L12:
        if (_245 != 0) {
            goto L15;
        }
        DeRef(_255);
        _2 = (int)SEQ_PTR(_a);
        _255 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_255);
        _0 = _255;
        if (IS_ATOM_INT(_255)) {
            _255 = (_255 > _6pretty_ascii_max);
        }
        else {
            _255 = binary_op(GREATER, _255, _6pretty_ascii_max);
        }
        DeRef(_0);
L16:
        if (_255 == 0) {
            goto L17;
        }
        else {
            if (!IS_ATOM_INT(_255) && DBL_PTR(_255)->dbl == 0.0)
                goto L17;
        }
L15:

        // 		all_ascii = 0
        _all_ascii = 0;
L17:

        // 	end for
        _i = _i + 1;
        goto LE;
LF:
        ;
    }

    // 	if all_ascii then
    if (_all_ascii == 0)
        goto L18;

    // 	    pretty_out('\"')
    _6pretty_out(34);
    goto L19;
L18:

    // 	    pretty_out('{')
    _6pretty_out(123);
L19:

    // 	pretty_level += 1
    _6pretty_level = _6pretty_level + 1;

    // 	for i = 1 to length(a) do
    DeRef(_255);
    _255 = SEQ_PTR(_a)->length;
    { int _i;
        _i = 1;
L1A:
        if (_i > _255)
            goto L1B;

        // 	    if multi_line then
        if (_multi_line == 0)
            goto L1C;

        // 		indent()
        _6indent();
L1C:

        // 	    if all_ascii then
        if (_all_ascii == 0)
            goto L1D;

        // 		pretty_out(show(a[i]))
        DeRef(_257);
        _2 = (int)SEQ_PTR(_a);
        _257 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_257);
        Ref(_257);
        _0 = _257;
        _257 = _6show(_257);
        DeRef(_0);
        Ref(_257);
        _6pretty_out(_257);
        goto L1E;
L1D:

        // 		rPrint(a[i])
        DeRef(_257);
        _2 = (int)SEQ_PTR(_a);
        _257 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_257);
        Ref(_257);
        _6rPrint(_257);
L1E:

        // 	    if pretty_line_count >= pretty_line_max then
        if (_6pretty_line_count < _6pretty_line_max)
            goto L1F;

        // 		if not pretty_dots then
        if (_6pretty_dots != 0)
            goto L20;

        // 		    pretty_out(" ...")
        RefDS(_272);
        _6pretty_out(_272);
L20:

        // 		pretty_dots = 1
        _6pretty_dots = 1;

        // 		return
        DeRef(_a);
        DeRef(_sbuff);
        DeRef5(_228, _257, _255, _245, _222);
        return 0;
L1F:

        // 	    if i != length(a) and not all_ascii then
        DeRef(_257);
        _257 = SEQ_PTR(_a)->length;
        _257 = (_i != _257);
        if (_257 == 0) {
            goto L21;
        }
        DeRef(_228);
        _228 = (_all_ascii == 0);
L22:
        if (_228 == 0)
            goto L21;

        // 		pretty_out(',')
        _6pretty_out(44);

        // 		cut_line(6)
        _6cut_line(6);
L21:

        // 	end for
        _i = _i + 1;
        goto L1A;
L1B:
        ;
    }

    // 	pretty_level -= 1
    _6pretty_level = _6pretty_level - 1;

    // 	if multi_line then
    if (_multi_line == 0)
        goto L23;

    // 	    indent()
    _6indent();
L23:

    // 	if all_ascii then
    if (_all_ascii == 0)
        goto L24;

    // 	    pretty_out('\"')
    _6pretty_out(34);
    goto L25;
L24:

    // 	    pretty_out('}')
    _6pretty_out(125);
L25:
LD:

    // end procedure
    DeRef(_a);
    DeRef(_sbuff);
    DeRef5(_228, _257, _255, _245, _222);
    return 0;
    ;
}


_6pretty_print(int _fn, int _x, int _options)
{
    int _n;
    int _282;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }

    //     pretty_ascii = 1             --[1] 
    _6pretty_ascii = 1;

    //     pretty_indent = 2            --[2]
    _6pretty_indent = 2;

    //     pretty_start_col = 1         --[3]
    _6pretty_start_col = 1;

    //     pretty_end_col = 78          --[4]
    _6pretty_end_col = 78;

    //     pretty_int_format = "%d"     --[5]
    RefDS(_280);
    DeRef(_6pretty_int_format);
    _6pretty_int_format = _280;

    //     pretty_fp_format = "%.10g"   --[6]
    RefDS(_187);
    DeRef(_6pretty_fp_format);
    _6pretty_fp_format = _187;

    //     pretty_ascii_min = 32        --[7]
    _6pretty_ascii_min = 32;

    //     pretty_ascii_max = 127       --[8] 
    _282 = (3 == 3);
    _6pretty_ascii_max = 127 - _282;

    //     pretty_line_max = 1000000000 --[9]
    _6pretty_line_max = 1000000000;

    //     n = length(options)
    _n = SEQ_PTR(_options)->length;

    //     if n >= 1 then
    if (_n < 1)
        goto L1;

    // 	pretty_ascii = options[1] 
    _2 = (int)SEQ_PTR(_options);
    _6pretty_ascii = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_6pretty_ascii))
        _6pretty_ascii = (long)DBL_PTR(_6pretty_ascii)->dbl;

    // 	if n >= 2 then
    if (_n < 2)
        goto L2;

    // 	    pretty_indent = options[2]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_indent = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_6pretty_indent))
        _6pretty_indent = (long)DBL_PTR(_6pretty_indent)->dbl;

    // 	    if n >= 3 then
    if (_n < 3)
        goto L3;

    // 		pretty_start_col = options[3]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_start_col = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_6pretty_start_col))
        _6pretty_start_col = (long)DBL_PTR(_6pretty_start_col)->dbl;

    // 		if n >= 4 then
    if (_n < 4)
        goto L4;

    // 		    pretty_end_col = options[4]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_end_col = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_6pretty_end_col))
        _6pretty_end_col = (long)DBL_PTR(_6pretty_end_col)->dbl;

    // 		    if n >= 5 then
    if (_n < 5)
        goto L5;

    // 			pretty_int_format = options[5]
    DeRefDSi(_6pretty_int_format);
    _2 = (int)SEQ_PTR(_options);
    _6pretty_int_format = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_6pretty_int_format);

    // 			if n >= 6 then
    if (_n < 6)
        goto L6;

    // 			    pretty_fp_format = options[6]
    DeRefDSi(_6pretty_fp_format);
    _2 = (int)SEQ_PTR(_options);
    _6pretty_fp_format = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_6pretty_fp_format);

    // 			    if n >= 7 then
    if (_n < 7)
        goto L7;

    // 				pretty_ascii_min = options[7]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_ascii_min = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_6pretty_ascii_min))
        _6pretty_ascii_min = (long)DBL_PTR(_6pretty_ascii_min)->dbl;

    // 				if n >= 8 then
    if (_n < 8)
        goto L8;

    // 				    pretty_ascii_max = options[8]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_ascii_max = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_6pretty_ascii_max))
        _6pretty_ascii_max = (long)DBL_PTR(_6pretty_ascii_max)->dbl;

    // 				    if n >= 9 then
    if (_n < 9)
        goto L9;

    // 					pretty_line_max = options[9]
    _2 = (int)SEQ_PTR(_options);
    _6pretty_line_max = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_6pretty_line_max))
        _6pretty_line_max = (long)DBL_PTR(_6pretty_line_max)->dbl;
L9:
L8:
L7:
L6:
L5:
L4:
L3:
L2:
L1:

    //     pretty_chars = pretty_start_col
    _6pretty_chars = _6pretty_start_col;

    //     pretty_file = fn
    _6pretty_file = _fn;

    //     pretty_level = 0 
    _6pretty_level = 0;

    //     pretty_line = ""
    RefDS(_202);
    DeRef(_6pretty_line);
    _6pretty_line = _202;

    //     pretty_line_count = 0
    _6pretty_line_count = 0;

    //     pretty_dots = 0
    _6pretty_dots = 0;

    //     rPrint(x)
    Ref(_x);
    _6rPrint(_x);

    //     puts(pretty_file, pretty_line)
    EPuts(_6pretty_file, _6pretty_line);

    // end procedure
    DeRef(_x);
    DeRefDS(_options);
    return 0;
    ;
}


_6arccos(int _x)
{
    int _316 = 0;
    int _0, _1, _2;
    

    //     return PI_HALF - 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_x)) {
        if (_x == (short)_x && _x <= INT15 && _x >= -INT15)
            _316 = _x * _x;
        else
            _316 = NewDouble(_x * (double)_x);
    }
    else {
        _316 = binary_op(MULTIPLY, _x, _x);
    }
    _0 = _316;
    _316 = binary_op(MINUS, _315, _316);
    DeRef(_0);
    _0 = _316;
    if (IS_ATOM_INT(_316))
        _316 = e_sqrt(_316);
    else
        _316 = unary_op(SQRT, _316);
    DeRef(_0);
    _0 = _316;
    _316 = binary_op(PLUS, _315, _316);
    DeRef(_0);
    _0 = _316;
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_316)) {
        _316 = (_x % _316) ? NewDouble((double)_x / _316) : (_x / _316);
    }
    else {
        _316 = binary_op(DIVIDE, _x, _316);
    }
    DeRef(_0);
    _0 = _316;
    if (IS_ATOM_INT(_316))
        _316 = e_arctan(_316);
    else
        _316 = unary_op(ARCTAN, _316);
    DeRef(_0);
    _0 = _316;
    if (IS_ATOM_INT(_316) && IS_ATOM_INT(_316)) {
        _316 = _316 + _316;
        if ((long)((unsigned long)_316 + (unsigned long)HIGH_BITS) >= 0) 
            _316 = NewDouble((double)_316);
    }
    else {
        _316 = binary_op(PLUS, _316, _316);
    }
    DeRef(_0);
    _0 = _316;
    _316 = binary_op(MINUS, _6PI_HALF, _316);
    DeRef(_0);
    DeRef(_x);
    return _316;
    ;
}


_6arcsin(int _x)
{
    int _324 = 0;
    int _0, _1, _2;
    

    //     return 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_x)) {
        if (_x == (short)_x && _x <= INT15 && _x >= -INT15)
            _324 = _x * _x;
        else
            _324 = NewDouble(_x * (double)_x);
    }
    else {
        _324 = binary_op(MULTIPLY, _x, _x);
    }
    _0 = _324;
    _324 = binary_op(MINUS, _315, _324);
    DeRef(_0);
    _0 = _324;
    if (IS_ATOM_INT(_324))
        _324 = e_sqrt(_324);
    else
        _324 = unary_op(SQRT, _324);
    DeRef(_0);
    _0 = _324;
    _324 = binary_op(PLUS, _315, _324);
    DeRef(_0);
    _0 = _324;
    if (IS_ATOM_INT(_x) && IS_ATOM_INT(_324)) {
        _324 = (_x % _324) ? NewDouble((double)_x / _324) : (_x / _324);
    }
    else {
        _324 = binary_op(DIVIDE, _x, _324);
    }
    DeRef(_0);
    _0 = _324;
    if (IS_ATOM_INT(_324))
        _324 = e_arctan(_324);
    else
        _324 = unary_op(ARCTAN, _324);
    DeRef(_0);
    _0 = _324;
    if (IS_ATOM_INT(_324) && IS_ATOM_INT(_324)) {
        _324 = _324 + _324;
        if ((long)((unsigned long)_324 + (unsigned long)HIGH_BITS) >= 0) 
            _324 = NewDouble((double)_324);
    }
    else {
        _324 = binary_op(PLUS, _324, _324);
    }
    DeRef(_0);
    DeRef(_x);
    return _324;
    ;
}


