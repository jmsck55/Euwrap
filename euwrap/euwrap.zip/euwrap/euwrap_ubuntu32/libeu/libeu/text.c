// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _6sprint(int _x_9247)
{
    int _s_9248 = NOVALUE;
    int _5109 = NOVALUE;
    int _5107 = NOVALUE;
    int _5106 = NOVALUE;
    int _5103 = NOVALUE;
    int _5102 = NOVALUE;
    int _5100 = NOVALUE;
    int _5099 = NOVALUE;
    int _5098 = NOVALUE;
    int _5097 = NOVALUE;
    int _5096 = NOVALUE;
    int _5095 = NOVALUE;
    int _5094 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _5094 = IS_ATOM(_x_9247);
    if (_5094 == 0)
    {
        _5094 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _5094 = NOVALUE;
    }

    /** 		return sprintf("%.10g", x)*/
    _5095 = EPrintf(-9999999, _4772, _x_9247);
    DeRef(_x_9247);
    DeRef(_s_9248);
    return _5095;
    goto L2; // [19] 137
L1: 

    /** 		s = "{"*/
    RefDS(_929);
    DeRef(_s_9248);
    _s_9248 = _929;

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9247)){
            _5096 = SEQ_PTR(_x_9247)->length;
    }
    else {
        _5096 = 1;
    }
    {
        int _i_9254;
        _i_9254 = 1;
L3: 
        if (_i_9254 > _5096){
            goto L4; // [34] 98
        }

        /** 			if atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_9247);
        _5097 = (int)*(((s1_ptr)_2)->base + _i_9254);
        _5098 = IS_ATOM(_5097);
        _5097 = NOVALUE;
        if (_5098 == 0)
        {
            _5098 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _5098 = NOVALUE;
        }

        /** 				s &= sprintf("%.10g", x[i])*/
        _2 = (int)SEQ_PTR(_x_9247);
        _5099 = (int)*(((s1_ptr)_2)->base + _i_9254);
        _5100 = EPrintf(-9999999, _4772, _5099);
        _5099 = NOVALUE;
        Concat((object_ptr)&_s_9248, _s_9248, _5100);
        DeRefDS(_5100);
        _5100 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** 				s &= sprint(x[i])*/
        _2 = (int)SEQ_PTR(_x_9247);
        _5102 = (int)*(((s1_ptr)_2)->base + _i_9254);
        Ref(_5102);
        _5103 = _6sprint(_5102);
        _5102 = NOVALUE;
        if (IS_SEQUENCE(_s_9248) && IS_ATOM(_5103)) {
            Ref(_5103);
            Append(&_s_9248, _s_9248, _5103);
        }
        else if (IS_ATOM(_s_9248) && IS_SEQUENCE(_5103)) {
        }
        else {
            Concat((object_ptr)&_s_9248, _s_9248, _5103);
        }
        DeRef(_5103);
        _5103 = NOVALUE;
L6: 

        /** 			s &= ','*/
        Append(&_s_9248, _s_9248, 44);

        /** 		end for*/
        _i_9254 = _i_9254 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** 		if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_9248)){
            _5106 = SEQ_PTR(_s_9248)->length;
    }
    else {
        _5106 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9248);
    _5107 = (int)*(((s1_ptr)_2)->base + _5106);
    if (binary_op_a(NOTEQ, _5107, 44)){
        _5107 = NOVALUE;
        goto L7; // [107] 123
    }
    _5107 = NOVALUE;

    /** 			s[$] = '}'*/
    if (IS_SEQUENCE(_s_9248)){
            _5109 = SEQ_PTR(_s_9248)->length;
    }
    else {
        _5109 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9248);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_9248 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _5109);
    _1 = *(int *)_2;
    *(int *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** 			s &= '}'*/
    Append(&_s_9248, _s_9248, 125);
L8: 

    /** 		return s*/
    DeRef(_x_9247);
    DeRef(_5095);
    _5095 = NOVALUE;
    return _s_9248;
L2: 
    ;
}
int sprint() __attribute__ ((alias ("_6sprint")));


int _6trim_head(int _source_9276, int _what_9277, int _ret_index_9278)
{
    int _lpos_9279 = NOVALUE;
    int _5120 = NOVALUE;
    int _5119 = NOVALUE;
    int _5116 = NOVALUE;
    int _5115 = NOVALUE;
    int _5113 = NOVALUE;
    int _5111 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9278)) {
        _1 = (long)(DBL_PTR(_ret_index_9278)->dbl);
        DeRefDS(_ret_index_9278);
        _ret_index_9278 = _1;
    }

    /** 	if atom(what) then*/
    _5111 = IS_ATOM(_what_9277);
    if (_5111 == 0)
    {
        _5111 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5111 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9277;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9277);
    *((int *)(_2+4)) = _what_9277;
    _what_9277 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_9279 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9276)){
            _5113 = SEQ_PTR(_source_9276)->length;
    }
    else {
        _5113 = 1;
    }
    if (_lpos_9279 > _5113)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9276);
    _5115 = (int)*(((s1_ptr)_2)->base + _lpos_9279);
    _5116 = find_from(_5115, _what_9277, 1);
    _5115 = NOVALUE;
    if (_5116 != 0)
    goto L4; // [48] 56
    _5116 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_9279 = _lpos_9279 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	if ret_index then*/
    if (_ret_index_9278 == 0)
    {
        goto L5; // [69] 81
    }
    else{
    }

    /** 		return lpos*/
    DeRefDS(_source_9276);
    DeRef(_what_9277);
    return _lpos_9279;
    goto L6; // [78] 96
L5: 

    /** 		return source[lpos .. $]*/
    if (IS_SEQUENCE(_source_9276)){
            _5119 = SEQ_PTR(_source_9276)->length;
    }
    else {
        _5119 = 1;
    }
    rhs_slice_target = (object_ptr)&_5120;
    RHS_Slice(_source_9276, _lpos_9279, _5119);
    DeRefDS(_source_9276);
    DeRef(_what_9277);
    return _5120;
L6: 
    ;
}
int trim_head() __attribute__ ((alias ("_6trim_head")));


int _6trim_tail(int _source_9297, int _what_9298, int _ret_index_9299)
{
    int _rpos_9300 = NOVALUE;
    int _5129 = NOVALUE;
    int _5126 = NOVALUE;
    int _5125 = NOVALUE;
    int _5121 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9299)) {
        _1 = (long)(DBL_PTR(_ret_index_9299)->dbl);
        DeRefDS(_ret_index_9299);
        _ret_index_9299 = _1;
    }

    /** 	if atom(what) then*/
    _5121 = IS_ATOM(_what_9298);
    if (_5121 == 0)
    {
        _5121 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5121 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9298;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9298);
    *((int *)(_2+4)) = _what_9298;
    _what_9298 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_9297)){
            _rpos_9300 = SEQ_PTR(_source_9297)->length;
    }
    else {
        _rpos_9300 = 1;
    }

    /** 	while rpos > 0 do*/
L2: 
    if (_rpos_9300 <= 0)
    goto L3; // [30] 64

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9297);
    _5125 = (int)*(((s1_ptr)_2)->base + _rpos_9300);
    _5126 = find_from(_5125, _what_9298, 1);
    _5125 = NOVALUE;
    if (_5126 != 0)
    goto L4; // [45] 53
    _5126 = NOVALUE;

    /** 			exit*/
    goto L3; // [50] 64
L4: 

    /** 		rpos -= 1*/
    _rpos_9300 = _rpos_9300 - 1;

    /** 	end while*/
    goto L2; // [61] 30
L3: 

    /** 	if ret_index then*/
    if (_ret_index_9299 == 0)
    {
        goto L5; // [66] 78
    }
    else{
    }

    /** 		return rpos*/
    DeRefDS(_source_9297);
    DeRef(_what_9298);
    return _rpos_9300;
    goto L6; // [75] 90
L5: 

    /** 		return source[1..rpos]*/
    rhs_slice_target = (object_ptr)&_5129;
    RHS_Slice(_source_9297, 1, _rpos_9300);
    DeRefDS(_source_9297);
    DeRef(_what_9298);
    return _5129;
L6: 
    ;
}
int trim_tail() __attribute__ ((alias ("_6trim_tail")));


int _6trim(int _source_9317, int _what_9318, int _ret_index_9319)
{
    int _rpos_9320 = NOVALUE;
    int _lpos_9321 = NOVALUE;
    int _5150 = NOVALUE;
    int _5148 = NOVALUE;
    int _5146 = NOVALUE;
    int _5144 = NOVALUE;
    int _5141 = NOVALUE;
    int _5140 = NOVALUE;
    int _5135 = NOVALUE;
    int _5134 = NOVALUE;
    int _5132 = NOVALUE;
    int _5130 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9319)) {
        _1 = (long)(DBL_PTR(_ret_index_9319)->dbl);
        DeRefDS(_ret_index_9319);
        _ret_index_9319 = _1;
    }

    /** 	if atom(what) then*/
    _5130 = IS_ATOM(_what_9318);
    if (_5130 == 0)
    {
        _5130 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5130 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9318;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9318);
    *((int *)(_2+4)) = _what_9318;
    _what_9318 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_9321 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9317)){
            _5132 = SEQ_PTR(_source_9317)->length;
    }
    else {
        _5132 = 1;
    }
    if (_lpos_9321 > _5132)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9317);
    _5134 = (int)*(((s1_ptr)_2)->base + _lpos_9321);
    _5135 = find_from(_5134, _what_9318, 1);
    _5134 = NOVALUE;
    if (_5135 != 0)
    goto L4; // [48] 56
    _5135 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_9321 = _lpos_9321 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_9317)){
            _rpos_9320 = SEQ_PTR(_source_9317)->length;
    }
    else {
        _rpos_9320 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_9320 <= _lpos_9321)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9317);
    _5140 = (int)*(((s1_ptr)_2)->base + _rpos_9320);
    _5141 = find_from(_5140, _what_9318, 1);
    _5140 = NOVALUE;
    if (_5141 != 0)
    goto L7; // [92] 100
    _5141 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_9320 = _rpos_9320 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_9319 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_9321;
    ((int *)_2)[2] = _rpos_9320;
    _5144 = MAKE_SEQ(_1);
    DeRefDS(_source_9317);
    DeRef(_what_9318);
    return _5144;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_9321 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_9317)){
            _5146 = SEQ_PTR(_source_9317)->length;
    }
    else {
        _5146 = 1;
    }
    if (_rpos_9320 != _5146)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_9318);
    DeRef(_5144);
    _5144 = NOVALUE;
    return _source_9317;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_9317)){
            _5148 = SEQ_PTR(_source_9317)->length;
    }
    else {
        _5148 = 1;
    }
    if (_lpos_9321 <= _5148)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_9317);
    DeRef(_what_9318);
    DeRef(_5144);
    _5144 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_5150;
    RHS_Slice(_source_9317, _lpos_9321, _rpos_9320);
    DeRefDS(_source_9317);
    DeRef(_what_9318);
    DeRef(_5144);
    _5144 = NOVALUE;
    return _5150;
L9: 
    ;
}
int trim() __attribute__ ((alias ("_6trim")));


int _6load_code_page(int _cpname_9361)
{
    int _cpdata_9362 = NOVALUE;
    int _pos_9363 = NOVALUE;
    int _kv_9364 = NOVALUE;
    int _cp_source_9365 = NOVALUE;
    int _cp_db_9366 = NOVALUE;
    int _fh_9438 = NOVALUE;
    int _idx_9442 = NOVALUE;
    int _vers_9443 = NOVALUE;
    int _seek_1__tmp_at464_9457 = NOVALUE;
    int _seek_inlined_seek_at_464_9456 = NOVALUE;
    int _seek_1__tmp_at514_9468 = NOVALUE;
    int _seek_inlined_seek_at_514_9467 = NOVALUE;
    int _pos_inlined_seek_at_511_9466 = NOVALUE;
    int _5225 = NOVALUE;
    int _5224 = NOVALUE;
    int _5221 = NOVALUE;
    int _5216 = NOVALUE;
    int _5215 = NOVALUE;
    int _5214 = NOVALUE;
    int _5212 = NOVALUE;
    int _5205 = NOVALUE;
    int _5204 = NOVALUE;
    int _5203 = NOVALUE;
    int _5201 = NOVALUE;
    int _5200 = NOVALUE;
    int _5199 = NOVALUE;
    int _5197 = NOVALUE;
    int _5195 = NOVALUE;
    int _5194 = NOVALUE;
    int _5192 = NOVALUE;
    int _5191 = NOVALUE;
    int _5189 = NOVALUE;
    int _5188 = NOVALUE;
    int _5187 = NOVALUE;
    int _5186 = NOVALUE;
    int _5183 = NOVALUE;
    int _5181 = NOVALUE;
    int _5179 = NOVALUE;
    int _5178 = NOVALUE;
    int _5176 = NOVALUE;
    int _5175 = NOVALUE;
    int _5174 = NOVALUE;
    int _5172 = NOVALUE;
    int _5171 = NOVALUE;
    int _5170 = NOVALUE;
    int _5167 = NOVALUE;
    int _5166 = NOVALUE;
    int _5165 = NOVALUE;
    int _5164 = NOVALUE;
    int _5162 = NOVALUE;
    int _5161 = NOVALUE;
    int _5158 = NOVALUE;
    int _5157 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cp_source = filesys:defaultext(cpname, ".ecp")*/
    RefDS(_cpname_9361);
    RefDS(_5153);
    _0 = _cp_source_9365;
    _cp_source_9365 = _11defaultext(_cpname_9361, _5153);
    DeRef(_0);

    /** 	cp_source = filesys:locate_file(cp_source)*/
    RefDS(_cp_source_9365);
    RefDS(_5);
    RefDS(_5);
    _0 = _cp_source_9365;
    _cp_source_9365 = _11locate_file(_cp_source_9365, _5, _5);
    DeRefDS(_0);

    /** 	cpdata = io:read_lines(cp_source)*/
    RefDS(_cp_source_9365);
    _0 = _cpdata_9362;
    _cpdata_9362 = _18read_lines(_cp_source_9365);
    DeRef(_0);

    /** 	if sequence(cpdata) then*/
    _5157 = IS_SEQUENCE(_cpdata_9362);
    if (_5157 == 0)
    {
        _5157 = NOVALUE;
        goto L1; // [33] 373
    }
    else{
        _5157 = NOVALUE;
    }

    /** 		pos = 0*/
    _pos_9363 = 0;

    /** 		while pos < length(cpdata) do*/
L2: 
    if (IS_SEQUENCE(_cpdata_9362)){
            _5158 = SEQ_PTR(_cpdata_9362)->length;
    }
    else {
        _5158 = 1;
    }
    if (_pos_9363 >= _5158)
    goto L3; // [49] 188

    /** 			pos += 1*/
    _pos_9363 = _pos_9363 + 1;

    /** 			cpdata[pos]  = trim(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5161 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    Ref(_5161);
    RefDS(_4498);
    _5162 = _6trim(_5161, _4498, 0);
    _5161 = NOVALUE;
    _2 = (int)SEQ_PTR(_cpdata_9362);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cpdata_9362 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pos_9363);
    _1 = *(int *)_2;
    *(int *)_2 = _5162;
    if( _1 != _5162 ){
        DeRef(_1);
    }
    _5162 = NOVALUE;

    /** 			if search:begins("--HEAD--", cpdata[pos]) then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5164 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    RefDS(_5163);
    Ref(_5164);
    _5165 = _9begins(_5163, _5164);
    _5164 = NOVALUE;
    if (_5165 == 0) {
        DeRef(_5165);
        _5165 = NOVALUE;
        goto L4; // [86] 94
    }
    else {
        if (!IS_ATOM_INT(_5165) && DBL_PTR(_5165)->dbl == 0.0){
            DeRef(_5165);
            _5165 = NOVALUE;
            goto L4; // [86] 94
        }
        DeRef(_5165);
        _5165 = NOVALUE;
    }
    DeRef(_5165);
    _5165 = NOVALUE;

    /** 				continue*/
    goto L2; // [91] 46
L4: 

    /** 			if cpdata[pos][1] = ';' then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5166 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    _2 = (int)SEQ_PTR(_5166);
    _5167 = (int)*(((s1_ptr)_2)->base + 1);
    _5166 = NOVALUE;
    if (binary_op_a(NOTEQ, _5167, 59)){
        _5167 = NOVALUE;
        goto L5; // [104] 113
    }
    _5167 = NOVALUE;

    /** 				continue	-- A comment line*/
    goto L2; // [110] 46
L5: 

    /** 			if search:begins("--CASE--", cpdata[pos]) then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5170 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    RefDS(_5169);
    Ref(_5170);
    _5171 = _9begins(_5169, _5170);
    _5170 = NOVALUE;
    if (_5171 == 0) {
        DeRef(_5171);
        _5171 = NOVALUE;
        goto L6; // [124] 132
    }
    else {
        if (!IS_ATOM_INT(_5171) && DBL_PTR(_5171)->dbl == 0.0){
            DeRef(_5171);
            _5171 = NOVALUE;
            goto L6; // [124] 132
        }
        DeRef(_5171);
        _5171 = NOVALUE;
    }
    DeRef(_5171);
    _5171 = NOVALUE;

    /** 				exit*/
    goto L3; // [129] 188
L6: 

    /** 			kv = keyvalues(cpdata[pos],,,,"")*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5172 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    Ref(_5172);
    RefDS(_5298);
    RefDS(_5299);
    RefDS(_5300);
    RefDS(_5);
    _0 = _kv_9364;
    _kv_9364 = _6keyvalues(_5172, _5298, _5299, _5300, _5, 1);
    DeRef(_0);
    _5172 = NOVALUE;

    /** 			if equal(lower(kv[1][1]), "title") then*/
    _2 = (int)SEQ_PTR(_kv_9364);
    _5174 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5174);
    _5175 = (int)*(((s1_ptr)_2)->base + 1);
    _5174 = NOVALUE;
    Ref(_5175);
    _5176 = _6lower(_5175);
    _5175 = NOVALUE;
    if (_5176 == _5177)
    _5178 = 1;
    else if (IS_ATOM_INT(_5176) && IS_ATOM_INT(_5177))
    _5178 = 0;
    else
    _5178 = (compare(_5176, _5177) == 0);
    DeRef(_5176);
    _5176 = NOVALUE;
    if (_5178 == 0)
    {
        _5178 = NOVALUE;
        goto L2; // [167] 46
    }
    else{
        _5178 = NOVALUE;
    }

    /** 				encoding_NAME = kv[1][2]*/
    _2 = (int)SEQ_PTR(_kv_9364);
    _5179 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_6encoding_NAME_9357);
    _2 = (int)SEQ_PTR(_5179);
    _6encoding_NAME_9357 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6encoding_NAME_9357);
    _5179 = NOVALUE;

    /** 		end while*/
    goto L2; // [185] 46
L3: 

    /** 		if pos > length(cpdata) then*/
    if (IS_SEQUENCE(_cpdata_9362)){
            _5181 = SEQ_PTR(_cpdata_9362)->length;
    }
    else {
        _5181 = 1;
    }
    if (_pos_9363 <= _5181)
    goto L7; // [193] 204

    /** 			return -2 -- No Case Conversion table found.*/
    DeRefDS(_cpname_9361);
    DeRef(_cpdata_9362);
    DeRef(_kv_9364);
    DeRef(_cp_source_9365);
    DeRef(_cp_db_9366);
    return -2;
L7: 

    /** 		upper_case_SET = ""*/
    RefDS(_5);
    DeRef(_6upper_case_SET_9356);
    _6upper_case_SET_9356 = _5;

    /** 		lower_case_SET = ""*/
    RefDS(_5);
    DeRef(_6lower_case_SET_9355);
    _6lower_case_SET_9355 = _5;

    /** 		while pos < length(cpdata) do*/
L8: 
    if (IS_SEQUENCE(_cpdata_9362)){
            _5183 = SEQ_PTR(_cpdata_9362)->length;
    }
    else {
        _5183 = 1;
    }
    if (_pos_9363 >= _5183)
    goto L9; // [226] 579

    /** 			pos += 1*/
    _pos_9363 = _pos_9363 + 1;

    /** 			cpdata[pos]  = trim(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5186 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    Ref(_5186);
    RefDS(_4498);
    _5187 = _6trim(_5186, _4498, 0);
    _5186 = NOVALUE;
    _2 = (int)SEQ_PTR(_cpdata_9362);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cpdata_9362 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pos_9363);
    _1 = *(int *)_2;
    *(int *)_2 = _5187;
    if( _1 != _5187 ){
        DeRef(_1);
    }
    _5187 = NOVALUE;

    /** 			if length(cpdata[pos]) < 3 then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5188 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    if (IS_SEQUENCE(_5188)){
            _5189 = SEQ_PTR(_5188)->length;
    }
    else {
        _5189 = 1;
    }
    _5188 = NOVALUE;
    if (_5189 >= 3)
    goto LA; // [261] 270

    /** 				continue*/
    goto L8; // [267] 223
LA: 

    /** 			if cpdata[pos][1] = ';' then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5191 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    _2 = (int)SEQ_PTR(_5191);
    _5192 = (int)*(((s1_ptr)_2)->base + 1);
    _5191 = NOVALUE;
    if (binary_op_a(NOTEQ, _5192, 59)){
        _5192 = NOVALUE;
        goto LB; // [280] 289
    }
    _5192 = NOVALUE;

    /** 				continue	-- A comment line*/
    goto L8; // [286] 223
LB: 

    /** 			if cpdata[pos][1] = '-' then*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5194 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    _2 = (int)SEQ_PTR(_5194);
    _5195 = (int)*(((s1_ptr)_2)->base + 1);
    _5194 = NOVALUE;
    if (binary_op_a(NOTEQ, _5195, 45)){
        _5195 = NOVALUE;
        goto LC; // [299] 308
    }
    _5195 = NOVALUE;

    /** 				exit*/
    goto L9; // [305] 579
LC: 

    /** 			kv = keyvalues(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9362);
    _5197 = (int)*(((s1_ptr)_2)->base + _pos_9363);
    Ref(_5197);
    RefDS(_5298);
    RefDS(_5299);
    RefDS(_5300);
    RefDS(_307);
    _0 = _kv_9364;
    _kv_9364 = _6keyvalues(_5197, _5298, _5299, _5300, _307, 1);
    DeRef(_0);
    _5197 = NOVALUE;

    /** 			upper_case_SET &= convert:hex_text(kv[1][1])*/
    _2 = (int)SEQ_PTR(_kv_9364);
    _5199 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5199);
    _5200 = (int)*(((s1_ptr)_2)->base + 1);
    _5199 = NOVALUE;
    Ref(_5200);
    _5201 = _8hex_text(_5200);
    _5200 = NOVALUE;
    if (IS_SEQUENCE(_6upper_case_SET_9356) && IS_ATOM(_5201)) {
        Ref(_5201);
        Append(&_6upper_case_SET_9356, _6upper_case_SET_9356, _5201);
    }
    else if (IS_ATOM(_6upper_case_SET_9356) && IS_SEQUENCE(_5201)) {
    }
    else {
        Concat((object_ptr)&_6upper_case_SET_9356, _6upper_case_SET_9356, _5201);
    }
    DeRef(_5201);
    _5201 = NOVALUE;

    /** 			lower_case_SET &= convert:hex_text(kv[1][2])*/
    _2 = (int)SEQ_PTR(_kv_9364);
    _5203 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5203);
    _5204 = (int)*(((s1_ptr)_2)->base + 2);
    _5203 = NOVALUE;
    Ref(_5204);
    _5205 = _8hex_text(_5204);
    _5204 = NOVALUE;
    if (IS_SEQUENCE(_6lower_case_SET_9355) && IS_ATOM(_5205)) {
        Ref(_5205);
        Append(&_6lower_case_SET_9355, _6lower_case_SET_9355, _5205);
    }
    else if (IS_ATOM(_6lower_case_SET_9355) && IS_SEQUENCE(_5205)) {
    }
    else {
        Concat((object_ptr)&_6lower_case_SET_9355, _6lower_case_SET_9355, _5205);
    }
    DeRef(_5205);
    _5205 = NOVALUE;

    /** 		end while*/
    goto L8; // [367] 223
    goto L9; // [370] 579
L1: 

    /** 		cp_db = filesys:locate_file("ecp.dat")*/
    RefDS(_5207);
    RefDS(_5);
    RefDS(_5);
    _0 = _cp_db_9366;
    _cp_db_9366 = _11locate_file(_5207, _5, _5);
    DeRef(_0);

    /** 		integer fh = open(cp_db, "rb")*/
    _fh_9438 = EOpen(_cp_db_9366, _1284, 0);

    /** 		if fh = -1 then*/
    if (_fh_9438 != -1)
    goto LD; // [392] 403

    /** 			return -2 -- Couldn't open DB*/
    DeRef(_idx_9442);
    DeRef(_vers_9443);
    DeRefDS(_cpname_9361);
    DeRef(_cpdata_9362);
    DeRef(_kv_9364);
    DeRef(_cp_source_9365);
    DeRefDS(_cp_db_9366);
    _5188 = NOVALUE;
    return -2;
LD: 

    /** 		object idx*/

    /** 		object vers*/

    /** 		vers = serialize:deserialize(fh)  -- get the database version*/
    _0 = _vers_9443;
    _vers_9443 = _27deserialize(_fh_9438, 1);
    DeRef(_0);

    /** 		if atom(vers) or length(vers) = 0 then*/
    _5212 = IS_ATOM(_vers_9443);
    if (_5212 != 0) {
        goto LE; // [419] 435
    }
    if (IS_SEQUENCE(_vers_9443)){
            _5214 = SEQ_PTR(_vers_9443)->length;
    }
    else {
        _5214 = 1;
    }
    _5215 = (_5214 == 0);
    _5214 = NOVALUE;
    if (_5215 == 0)
    {
        DeRef(_5215);
        _5215 = NOVALUE;
        goto LF; // [431] 442
    }
    else{
        DeRef(_5215);
        _5215 = NOVALUE;
    }
LE: 

    /** 			return -3 -- DB is wrong or corrupted.*/
    DeRef(_idx_9442);
    DeRef(_vers_9443);
    DeRefDS(_cpname_9361);
    DeRef(_cpdata_9362);
    DeRef(_kv_9364);
    DeRef(_cp_source_9365);
    DeRef(_cp_db_9366);
    _5188 = NOVALUE;
    return -3;
LF: 

    /** 		switch vers[1] do*/
    _2 = (int)SEQ_PTR(_vers_9443);
    _5216 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_5216) ){
        goto L10; // [448] 563
    }
    if(!IS_ATOM_INT(_5216)){
        if( (DBL_PTR(_5216)->dbl != (double) ((int) DBL_PTR(_5216)->dbl) ) ){
            goto L10; // [448] 563
        }
        _0 = (int) DBL_PTR(_5216)->dbl;
    }
    else {
        _0 = _5216;
    };
    _5216 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 1, 2 then*/
        case 1:
        case 2:

        /** 				idx = serialize:deserialize(fh)  -- get Code Page index offset*/
        _0 = _idx_9442;
        _idx_9442 = _27deserialize(_fh_9438, 1);
        DeRef(_0);

        /** 				pos = io:seek(fh, idx)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_idx_9442);
        DeRef(_seek_1__tmp_at464_9457);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _fh_9438;
        ((int *)_2)[2] = _idx_9442;
        _seek_1__tmp_at464_9457 = MAKE_SEQ(_1);
        _pos_9363 = machine(19, _seek_1__tmp_at464_9457);
        DeRef(_seek_1__tmp_at464_9457);
        _seek_1__tmp_at464_9457 = NOVALUE;

        /** 				idx = serialize:deserialize(fh)	-- get the Code Page Index*/
        _0 = _idx_9442;
        _idx_9442 = _27deserialize(_fh_9438, 1);
        DeRef(_0);

        /** 				pos = find(cpname, idx[1])*/
        _2 = (int)SEQ_PTR(_idx_9442);
        _5221 = (int)*(((s1_ptr)_2)->base + 1);
        _pos_9363 = find_from(_cpname_9361, _5221, 1);
        _5221 = NOVALUE;

        /** 				if pos != 0 then*/
        if (_pos_9363 == 0)
        goto L11; // [501] 572

        /** 					pos = io:seek(fh, idx[2][pos])*/
        _2 = (int)SEQ_PTR(_idx_9442);
        _5224 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_5224);
        _5225 = (int)*(((s1_ptr)_2)->base + _pos_9363);
        _5224 = NOVALUE;
        Ref(_5225);
        DeRef(_pos_inlined_seek_at_511_9466);
        _pos_inlined_seek_at_511_9466 = _5225;
        _5225 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_511_9466);
        DeRef(_seek_1__tmp_at514_9468);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _fh_9438;
        ((int *)_2)[2] = _pos_inlined_seek_at_511_9466;
        _seek_1__tmp_at514_9468 = MAKE_SEQ(_1);
        _pos_9363 = machine(19, _seek_1__tmp_at514_9468);
        DeRef(_pos_inlined_seek_at_511_9466);
        _pos_inlined_seek_at_511_9466 = NOVALUE;
        DeRef(_seek_1__tmp_at514_9468);
        _seek_1__tmp_at514_9468 = NOVALUE;

        /** 					upper_case_SET = serialize:deserialize(fh) -- "uppercase"*/
        _0 = _27deserialize(_fh_9438, 1);
        DeRef(_6upper_case_SET_9356);
        _6upper_case_SET_9356 = _0;

        /** 					lower_case_SET = serialize:deserialize(fh) -- "lowercase"*/
        _0 = _27deserialize(_fh_9438, 1);
        DeRef(_6lower_case_SET_9355);
        _6lower_case_SET_9355 = _0;

        /** 					encoding_NAME = serialize:deserialize(fh) -- "title"*/
        _0 = _27deserialize(_fh_9438, 1);
        DeRef(_6encoding_NAME_9357);
        _6encoding_NAME_9357 = _0;
        goto L11; // [559] 572

        /** 			case else*/
        default:
L10: 

        /** 				return -4 -- Unhandled ecp database version.*/
        DeRef(_idx_9442);
        DeRef(_vers_9443);
        DeRefDS(_cpname_9361);
        DeRef(_cpdata_9362);
        DeRef(_kv_9364);
        DeRef(_cp_source_9365);
        DeRef(_cp_db_9366);
        _5188 = NOVALUE;
        return -4;
    ;}L11: 

    /** 		close(fh)*/
    EClose(_fh_9438);
    DeRef(_idx_9442);
    _idx_9442 = NOVALUE;
    DeRef(_vers_9443);
    _vers_9443 = NOVALUE;
L9: 

    /** 	return 0*/
    DeRefDS(_cpname_9361);
    DeRef(_cpdata_9362);
    DeRef(_kv_9364);
    DeRef(_cp_source_9365);
    DeRef(_cp_db_9366);
    _5188 = NOVALUE;
    return 0;
    ;
}


void _6set_encoding_properties(int _en_9475, int _lc_9476, int _uc_9477)
{
    int _res_9478 = NOVALUE;
    int _5248 = NOVALUE;
    int _5247 = NOVALUE;
    int _5246 = NOVALUE;
    int _5245 = NOVALUE;
    int _5244 = NOVALUE;
    int _5242 = NOVALUE;
    int _5241 = NOVALUE;
    int _5240 = NOVALUE;
    int _5236 = NOVALUE;
    int _5235 = NOVALUE;
    int _5234 = NOVALUE;
    int _5233 = NOVALUE;
    int _5232 = NOVALUE;
    int _5231 = NOVALUE;
    int _5230 = NOVALUE;
    int _5229 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(en) > 0 and length(lc) = 0 and length(uc) = 0 then*/
    if (IS_SEQUENCE(_en_9475)){
            _5229 = SEQ_PTR(_en_9475)->length;
    }
    else {
        _5229 = 1;
    }
    _5230 = (_5229 > 0);
    _5229 = NOVALUE;
    if (_5230 == 0) {
        _5231 = 0;
        goto L1; // [16] 31
    }
    if (IS_SEQUENCE(_lc_9476)){
            _5232 = SEQ_PTR(_lc_9476)->length;
    }
    else {
        _5232 = 1;
    }
    _5233 = (_5232 == 0);
    _5232 = NOVALUE;
    _5231 = (_5233 != 0);
L1: 
    if (_5231 == 0) {
        goto L2; // [31] 77
    }
    if (IS_SEQUENCE(_uc_9477)){
            _5235 = SEQ_PTR(_uc_9477)->length;
    }
    else {
        _5235 = 1;
    }
    _5236 = (_5235 == 0);
    _5235 = NOVALUE;
    if (_5236 == 0)
    {
        DeRef(_5236);
        _5236 = NOVALUE;
        goto L2; // [43] 77
    }
    else{
        DeRef(_5236);
        _5236 = NOVALUE;
    }

    /** 		res = load_code_page(en)*/
    RefDS(_en_9475);
    _res_9478 = _6load_code_page(_en_9475);
    if (!IS_ATOM_INT(_res_9478)) {
        _1 = (long)(DBL_PTR(_res_9478)->dbl);
        DeRefDS(_res_9478);
        _res_9478 = _1;
    }

    /** 		if res != 0 then*/
    if (_res_9478 == 0)
    goto L3; // [56] 71

    /** 			printf(2, "Failed to load code page '%s'. Error # %d\n", {en, res})*/
    RefDS(_en_9475);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _en_9475;
    ((int *)_2)[2] = _res_9478;
    _5240 = MAKE_SEQ(_1);
    EPrintf(2, _5239, _5240);
    DeRefDS(_5240);
    _5240 = NOVALUE;
L3: 

    /** 		return*/
    DeRefDS(_en_9475);
    DeRefDS(_lc_9476);
    DeRefDS(_uc_9477);
    DeRef(_5230);
    _5230 = NOVALUE;
    DeRef(_5233);
    _5233 = NOVALUE;
    return;
L2: 

    /** 	if length(lc) = length(uc) then*/
    if (IS_SEQUENCE(_lc_9476)){
            _5241 = SEQ_PTR(_lc_9476)->length;
    }
    else {
        _5241 = 1;
    }
    if (IS_SEQUENCE(_uc_9477)){
            _5242 = SEQ_PTR(_uc_9477)->length;
    }
    else {
        _5242 = 1;
    }
    if (_5241 != _5242)
    goto L4; // [85] 143

    /** 		if length(lc) = 0 and length(en) = 0 then*/
    if (IS_SEQUENCE(_lc_9476)){
            _5244 = SEQ_PTR(_lc_9476)->length;
    }
    else {
        _5244 = 1;
    }
    _5245 = (_5244 == 0);
    _5244 = NOVALUE;
    if (_5245 == 0) {
        goto L5; // [98] 121
    }
    if (IS_SEQUENCE(_en_9475)){
            _5247 = SEQ_PTR(_en_9475)->length;
    }
    else {
        _5247 = 1;
    }
    _5248 = (_5247 == 0);
    _5247 = NOVALUE;
    if (_5248 == 0)
    {
        DeRef(_5248);
        _5248 = NOVALUE;
        goto L5; // [110] 121
    }
    else{
        DeRef(_5248);
        _5248 = NOVALUE;
    }

    /** 			en = "ASCII"*/
    RefDS(_5152);
    DeRefDS(_en_9475);
    _en_9475 = _5152;
L5: 

    /** 		lower_case_SET = lc*/
    RefDS(_lc_9476);
    DeRef(_6lower_case_SET_9355);
    _6lower_case_SET_9355 = _lc_9476;

    /** 		upper_case_SET = uc*/
    RefDS(_uc_9477);
    DeRef(_6upper_case_SET_9356);
    _6upper_case_SET_9356 = _uc_9477;

    /** 		encoding_NAME = en*/
    RefDS(_en_9475);
    DeRef(_6encoding_NAME_9357);
    _6encoding_NAME_9357 = _en_9475;
L4: 

    /** end procedure*/
    DeRefDS(_en_9475);
    DeRefDS(_lc_9476);
    DeRefDS(_uc_9477);
    DeRef(_5230);
    _5230 = NOVALUE;
    DeRef(_5233);
    _5233 = NOVALUE;
    DeRef(_5245);
    _5245 = NOVALUE;
    return;
    ;
}
void set_encoding_properties() __attribute__ ((alias ("_6set_encoding_properties")));


int _6get_encoding_properties()
{
    int _5249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {encoding_NAME, lower_case_SET, upper_case_SET}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6encoding_NAME_9357);
    *((int *)(_2+4)) = _6encoding_NAME_9357;
    RefDS(_6lower_case_SET_9355);
    *((int *)(_2+8)) = _6lower_case_SET_9355;
    RefDS(_6upper_case_SET_9356);
    *((int *)(_2+12)) = _6upper_case_SET_9356;
    _5249 = MAKE_SEQ(_1);
    return _5249;
    ;
}
int get_encoding_properties() __attribute__ ((alias ("_6get_encoding_properties")));


int _6lower(int _x_9511)
{
    int _5260 = NOVALUE;
    int _5259 = NOVALUE;
    int _5258 = NOVALUE;
    int _5257 = NOVALUE;
    int _5256 = NOVALUE;
    int _5255 = NOVALUE;
    int _5253 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    if (IS_SEQUENCE(_6lower_case_SET_9355)){
            _5253 = SEQ_PTR(_6lower_case_SET_9355)->length;
    }
    else {
        _5253 = 1;
    }
    if (_5253 == 0)
    goto L1; // [8] 30

    /** 		return stdseq:mapping(x, upper_case_SET, lower_case_SET)*/
    Ref(_x_9511);
    RefDS(_6upper_case_SET_9356);
    RefDS(_6lower_case_SET_9355);
    _5255 = _23mapping(_x_9511, _6upper_case_SET_9356, _6lower_case_SET_9355, 0);
    DeRef(_x_9511);
    return _5255;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		return x + (x >= 'A' and x <= 'Z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_9511)) {
        _5256 = (_x_9511 >= 65);
    }
    else {
        _5256 = binary_op(GREATEREQ, _x_9511, 65);
    }
    if (IS_ATOM_INT(_x_9511)) {
        _5257 = (_x_9511 <= 90);
    }
    else {
        _5257 = binary_op(LESSEQ, _x_9511, 90);
    }
    if (IS_ATOM_INT(_5256) && IS_ATOM_INT(_5257)) {
        _5258 = (_5256 != 0 && _5257 != 0);
    }
    else {
        _5258 = binary_op(AND, _5256, _5257);
    }
    DeRef(_5256);
    _5256 = NOVALUE;
    DeRef(_5257);
    _5257 = NOVALUE;
    if (IS_ATOM_INT(_5258)) {
        if (_5258 == (short)_5258)
        _5259 = _5258 * 32;
        else
        _5259 = NewDouble(_5258 * (double)32);
    }
    else {
        _5259 = binary_op(MULTIPLY, _5258, 32);
    }
    DeRef(_5258);
    _5258 = NOVALUE;
    if (IS_ATOM_INT(_x_9511) && IS_ATOM_INT(_5259)) {
        _5260 = _x_9511 + _5259;
        if ((long)((unsigned long)_5260 + (unsigned long)HIGH_BITS) >= 0) 
        _5260 = NewDouble((double)_5260);
    }
    else {
        _5260 = binary_op(PLUS, _x_9511, _5259);
    }
    DeRef(_5259);
    _5259 = NOVALUE;
    DeRef(_x_9511);
    DeRef(_5255);
    _5255 = NOVALUE;
    return _5260;
    ;
}
int lower() __attribute__ ((alias ("_6lower")));


int _6upper(int _x_9523)
{
    int _5268 = NOVALUE;
    int _5267 = NOVALUE;
    int _5266 = NOVALUE;
    int _5265 = NOVALUE;
    int _5264 = NOVALUE;
    int _5263 = NOVALUE;
    int _5261 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    if (IS_SEQUENCE(_6upper_case_SET_9356)){
            _5261 = SEQ_PTR(_6upper_case_SET_9356)->length;
    }
    else {
        _5261 = 1;
    }
    if (_5261 == 0)
    goto L1; // [8] 30

    /** 		return stdseq:mapping(x, lower_case_SET, upper_case_SET)*/
    Ref(_x_9523);
    RefDS(_6lower_case_SET_9355);
    RefDS(_6upper_case_SET_9356);
    _5263 = _23mapping(_x_9523, _6lower_case_SET_9355, _6upper_case_SET_9356, 0);
    DeRef(_x_9523);
    return _5263;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		return x - (x >= 'a' and x <= 'z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_9523)) {
        _5264 = (_x_9523 >= 97);
    }
    else {
        _5264 = binary_op(GREATEREQ, _x_9523, 97);
    }
    if (IS_ATOM_INT(_x_9523)) {
        _5265 = (_x_9523 <= 122);
    }
    else {
        _5265 = binary_op(LESSEQ, _x_9523, 122);
    }
    if (IS_ATOM_INT(_5264) && IS_ATOM_INT(_5265)) {
        _5266 = (_5264 != 0 && _5265 != 0);
    }
    else {
        _5266 = binary_op(AND, _5264, _5265);
    }
    DeRef(_5264);
    _5264 = NOVALUE;
    DeRef(_5265);
    _5265 = NOVALUE;
    if (IS_ATOM_INT(_5266)) {
        if (_5266 == (short)_5266)
        _5267 = _5266 * 32;
        else
        _5267 = NewDouble(_5266 * (double)32);
    }
    else {
        _5267 = binary_op(MULTIPLY, _5266, 32);
    }
    DeRef(_5266);
    _5266 = NOVALUE;
    if (IS_ATOM_INT(_x_9523) && IS_ATOM_INT(_5267)) {
        _5268 = _x_9523 - _5267;
        if ((long)((unsigned long)_5268 +(unsigned long) HIGH_BITS) >= 0){
            _5268 = NewDouble((double)_5268);
        }
    }
    else {
        _5268 = binary_op(MINUS, _x_9523, _5267);
    }
    DeRef(_5267);
    _5267 = NOVALUE;
    DeRef(_x_9523);
    DeRef(_5263);
    _5263 = NOVALUE;
    return _5268;
    ;
}
int upper() __attribute__ ((alias ("_6upper")));


int _6proper(int _x_9535)
{
    int _pos_9536 = NOVALUE;
    int _inword_9537 = NOVALUE;
    int _convert_9538 = NOVALUE;
    int _res_9539 = NOVALUE;
    int _5297 = NOVALUE;
    int _5296 = NOVALUE;
    int _5295 = NOVALUE;
    int _5294 = NOVALUE;
    int _5293 = NOVALUE;
    int _5292 = NOVALUE;
    int _5291 = NOVALUE;
    int _5290 = NOVALUE;
    int _5289 = NOVALUE;
    int _5288 = NOVALUE;
    int _5286 = NOVALUE;
    int _5285 = NOVALUE;
    int _5281 = NOVALUE;
    int _5278 = NOVALUE;
    int _5275 = NOVALUE;
    int _5272 = NOVALUE;
    int _5271 = NOVALUE;
    int _5270 = NOVALUE;
    int _5269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_9537 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_9538 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_9535);
    DeRef(_res_9539);
    _res_9539 = _x_9535;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_9539)){
            _5269 = SEQ_PTR(_res_9539)->length;
    }
    else {
        _5269 = 1;
    }
    {
        int _i_9541;
        _i_9541 = 1;
L1: 
        if (_i_9541 > _5269){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5270 = (int)*(((s1_ptr)_2)->base + _i_9541);
        if (IS_ATOM_INT(_5270))
        _5271 = 1;
        else if (IS_ATOM_DBL(_5270))
        _5271 = IS_ATOM_INT(DoubleToInt(_5270));
        else
        _5271 = 0;
        _5270 = NOVALUE;
        if (_5271 == 0)
        {
            _5271 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _5271 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_9538 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5272 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5272);
        _pos_9536 = _7t_upper(_5272);
        _5272 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9536)) {
            _1 = (long)(DBL_PTR(_pos_9536)->dbl);
            DeRefDS(_pos_9536);
            _pos_9536 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_9536 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5275 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5275);
        _pos_9536 = _7t_lower(_5275);
        _5275 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9536)) {
            _1 = (long)(DBL_PTR(_pos_9536)->dbl);
            DeRefDS(_pos_9536);
            _pos_9536 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_9536 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5278 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5278);
        _pos_9536 = _7t_digit(_5278);
        _5278 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9536)) {
            _1 = (long)(DBL_PTR(_pos_9536)->dbl);
            DeRefDS(_pos_9536);
            _pos_9536 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_9536 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5281 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5281);
        _pos_9536 = _7t_specword(_5281);
        _5281 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9536)) {
            _1 = (long)(DBL_PTR(_pos_9536)->dbl);
            DeRefDS(_pos_9536);
            _pos_9536 = _1;
        }

        /** 							if pos then*/
        if (_pos_9536 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_9537 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_9537 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_9537 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_9536 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5285 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5285);
        _5286 = _6upper(_5285);
        _5285 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9539);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9539 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9541);
        _1 = *(int *)_2;
        *(int *)_2 = _5286;
        if( _1 != _5286 ){
            DeRef(_1);
        }
        _5286 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_9537 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_9537 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5288 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5288);
        _5289 = _6lower(_5288);
        _5288 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9539);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9539 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9541);
        _1 = *(int *)_2;
        *(int *)_2 = _5289;
        if( _1 != _5289 ){
            DeRef(_1);
        }
        _5289 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_9537 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_9538 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _5290 = _i_9541 - 1;
        {
            int _j_9581;
            _j_9581 = 1;
LB: 
            if (_j_9581 > _5290){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_9535);
            _5291 = (int)*(((s1_ptr)_2)->base + _j_9581);
            _5292 = IS_ATOM(_5291);
            _5291 = NOVALUE;
            if (_5292 == 0)
            {
                _5292 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _5292 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_9535);
            _5293 = (int)*(((s1_ptr)_2)->base + _j_9581);
            Ref(_5293);
            _2 = (int)SEQ_PTR(_res_9539);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_9539 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_9581);
            _1 = *(int *)_2;
            *(int *)_2 = _5293;
            if( _1 != _5293 ){
                DeRef(_1);
            }
            _5293 = NOVALUE;
LD: 

            /** 				end for*/
            _j_9581 = _j_9581 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_9538 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5294 = (int)*(((s1_ptr)_2)->base + _i_9541);
        _5295 = IS_SEQUENCE(_5294);
        _5294 = NOVALUE;
        if (_5295 == 0)
        {
            _5295 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _5295 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_9539);
        _5296 = (int)*(((s1_ptr)_2)->base + _i_9541);
        Ref(_5296);
        _5297 = _6proper(_5296);
        _5296 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9539);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9539 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9541);
        _1 = *(int *)_2;
        *(int *)_2 = _5297;
        if( _1 != _5297 ){
            DeRef(_1);
        }
        _5297 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_9541 = _i_9541 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_9535);
    DeRef(_5290);
    _5290 = NOVALUE;
    return _res_9539;
    ;
}
int proper() __attribute__ ((alias ("_6proper")));


int _6keyvalues(int _source_9594, int _pair_delim_9595, int _kv_delim_9597, int _quotes_9599, int _whitespace_9601, int _haskeys_9602)
{
    int _lKeyValues_9603 = NOVALUE;
    int _value__9604 = NOVALUE;
    int _key__9605 = NOVALUE;
    int _lAllDelim_9606 = NOVALUE;
    int _lWhitePair_9607 = NOVALUE;
    int _lStartBracket_9608 = NOVALUE;
    int _lEndBracket_9609 = NOVALUE;
    int _lBracketed_9610 = NOVALUE;
    int _lQuote_9611 = NOVALUE;
    int _pos__9612 = NOVALUE;
    int _lChar_9613 = NOVALUE;
    int _lBPos_9614 = NOVALUE;
    int _lWasKV_9615 = NOVALUE;
    int _5473 = NOVALUE;
    int _5470 = NOVALUE;
    int _5466 = NOVALUE;
    int _5463 = NOVALUE;
    int _5462 = NOVALUE;
    int _5461 = NOVALUE;
    int _5460 = NOVALUE;
    int _5459 = NOVALUE;
    int _5458 = NOVALUE;
    int _5457 = NOVALUE;
    int _5455 = NOVALUE;
    int _5454 = NOVALUE;
    int _5453 = NOVALUE;
    int _5452 = NOVALUE;
    int _5451 = NOVALUE;
    int _5450 = NOVALUE;
    int _5449 = NOVALUE;
    int _5448 = NOVALUE;
    int _5445 = NOVALUE;
    int _5444 = NOVALUE;
    int _5443 = NOVALUE;
    int _5442 = NOVALUE;
    int _5441 = NOVALUE;
    int _5440 = NOVALUE;
    int _5436 = NOVALUE;
    int _5434 = NOVALUE;
    int _5433 = NOVALUE;
    int _5430 = NOVALUE;
    int _5426 = NOVALUE;
    int _5424 = NOVALUE;
    int _5421 = NOVALUE;
    int _5418 = NOVALUE;
    int _5415 = NOVALUE;
    int _5412 = NOVALUE;
    int _5409 = NOVALUE;
    int _5406 = NOVALUE;
    int _5402 = NOVALUE;
    int _5401 = NOVALUE;
    int _5400 = NOVALUE;
    int _5399 = NOVALUE;
    int _5398 = NOVALUE;
    int _5397 = NOVALUE;
    int _5396 = NOVALUE;
    int _5394 = NOVALUE;
    int _5393 = NOVALUE;
    int _5392 = NOVALUE;
    int _5391 = NOVALUE;
    int _5390 = NOVALUE;
    int _5389 = NOVALUE;
    int _5388 = NOVALUE;
    int _5387 = NOVALUE;
    int _5385 = NOVALUE;
    int _5382 = NOVALUE;
    int _5380 = NOVALUE;
    int _5378 = NOVALUE;
    int _5377 = NOVALUE;
    int _5376 = NOVALUE;
    int _5375 = NOVALUE;
    int _5374 = NOVALUE;
    int _5373 = NOVALUE;
    int _5372 = NOVALUE;
    int _5371 = NOVALUE;
    int _5368 = NOVALUE;
    int _5367 = NOVALUE;
    int _5366 = NOVALUE;
    int _5365 = NOVALUE;
    int _5364 = NOVALUE;
    int _5361 = NOVALUE;
    int _5358 = NOVALUE;
    int _5355 = NOVALUE;
    int _5352 = NOVALUE;
    int _5351 = NOVALUE;
    int _5349 = NOVALUE;
    int _5348 = NOVALUE;
    int _5344 = NOVALUE;
    int _5341 = NOVALUE;
    int _5338 = NOVALUE;
    int _5334 = NOVALUE;
    int _5333 = NOVALUE;
    int _5332 = NOVALUE;
    int _5331 = NOVALUE;
    int _5327 = NOVALUE;
    int _5324 = NOVALUE;
    int _5321 = NOVALUE;
    int _5320 = NOVALUE;
    int _5318 = NOVALUE;
    int _5316 = NOVALUE;
    int _5310 = NOVALUE;
    int _5308 = NOVALUE;
    int _5306 = NOVALUE;
    int _5304 = NOVALUE;
    int _5302 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_haskeys_9602)) {
        _1 = (long)(DBL_PTR(_haskeys_9602)->dbl);
        DeRefDS(_haskeys_9602);
        _haskeys_9602 = _1;
    }

    /** 	source = trim(source)*/
    RefDS(_source_9594);
    RefDS(_4498);
    _0 = _source_9594;
    _source_9594 = _6trim(_source_9594, _4498, 0);
    DeRefDS(_0);

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_9594)){
            _5302 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5302 = 1;
    }
    if (_5302 != 0)
    goto L1; // [20] 31

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_source_9594);
    DeRef(_pair_delim_9595);
    DeRef(_kv_delim_9597);
    DeRef(_quotes_9599);
    DeRef(_whitespace_9601);
    DeRef(_lKeyValues_9603);
    DeRef(_value__9604);
    DeRef(_key__9605);
    DeRef(_lAllDelim_9606);
    DeRef(_lWhitePair_9607);
    DeRefi(_lStartBracket_9608);
    DeRefi(_lEndBracket_9609);
    DeRefi(_lBracketed_9610);
    return _5;
L1: 

    /** 	if atom(pair_delim) then*/
    _5304 = IS_ATOM(_pair_delim_9595);
    if (_5304 == 0)
    {
        _5304 = NOVALUE;
        goto L2; // [36] 46
    }
    else{
        _5304 = NOVALUE;
    }

    /** 		pair_delim = {pair_delim}*/
    _0 = _pair_delim_9595;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pair_delim_9595);
    *((int *)(_2+4)) = _pair_delim_9595;
    _pair_delim_9595 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if atom(kv_delim) then*/
    _5306 = IS_ATOM(_kv_delim_9597);
    if (_5306 == 0)
    {
        _5306 = NOVALUE;
        goto L3; // [51] 61
    }
    else{
        _5306 = NOVALUE;
    }

    /** 		kv_delim = {kv_delim}*/
    _0 = _kv_delim_9597;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_kv_delim_9597);
    *((int *)(_2+4)) = _kv_delim_9597;
    _kv_delim_9597 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	if atom(quotes) then*/
    _5308 = IS_ATOM(_quotes_9599);
    if (_5308 == 0)
    {
        _5308 = NOVALUE;
        goto L4; // [66] 76
    }
    else{
        _5308 = NOVALUE;
    }

    /** 		quotes = {quotes}*/
    _0 = _quotes_9599;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quotes_9599);
    *((int *)(_2+4)) = _quotes_9599;
    _quotes_9599 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** 	if atom(whitespace) then*/
    _5310 = IS_ATOM(_whitespace_9601);
    if (_5310 == 0)
    {
        _5310 = NOVALUE;
        goto L5; // [81] 91
    }
    else{
        _5310 = NOVALUE;
    }

    /** 		whitespace = {whitespace}*/
    _0 = _whitespace_9601;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_whitespace_9601);
    *((int *)(_2+4)) = _whitespace_9601;
    _whitespace_9601 = MAKE_SEQ(_1);
    DeRef(_0);
L5: 

    /** 	lAllDelim = whitespace & pair_delim & kv_delim*/
    {
        int concat_list[3];

        concat_list[0] = _kv_delim_9597;
        concat_list[1] = _pair_delim_9595;
        concat_list[2] = _whitespace_9601;
        Concat_N((object_ptr)&_lAllDelim_9606, concat_list, 3);
    }

    /** 	lWhitePair = whitespace & pair_delim*/
    if (IS_SEQUENCE(_whitespace_9601) && IS_ATOM(_pair_delim_9595)) {
        Ref(_pair_delim_9595);
        Append(&_lWhitePair_9607, _whitespace_9601, _pair_delim_9595);
    }
    else if (IS_ATOM(_whitespace_9601) && IS_SEQUENCE(_pair_delim_9595)) {
        Ref(_whitespace_9601);
        Prepend(&_lWhitePair_9607, _pair_delim_9595, _whitespace_9601);
    }
    else {
        Concat((object_ptr)&_lWhitePair_9607, _whitespace_9601, _pair_delim_9595);
    }

    /** 	lStartBracket = "{[("*/
    RefDS(_5314);
    DeRefi(_lStartBracket_9608);
    _lStartBracket_9608 = _5314;

    /** 	lEndBracket   = "}])"*/
    RefDS(_5315);
    DeRefi(_lEndBracket_9609);
    _lEndBracket_9609 = _5315;

    /** 	lKeyValues = {}*/
    RefDS(_5);
    DeRef(_lKeyValues_9603);
    _lKeyValues_9603 = _5;

    /** 	pos_ = 1*/
    _pos__9612 = 1;

    /** 	while pos_ <= length(source) do*/
L6: 
    if (IS_SEQUENCE(_source_9594)){
            _5316 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5316 = 1;
    }
    if (_pos__9612 > _5316)
    goto L7; // [139] 1222

    /** 		while pos_ < length(source) do*/
L8: 
    if (IS_SEQUENCE(_source_9594)){
            _5318 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5318 = 1;
    }
    if (_pos__9612 >= _5318)
    goto L9; // [151] 186

    /** 			if find(source[pos_], whitespace) = 0 then*/
    _2 = (int)SEQ_PTR(_source_9594);
    _5320 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    _5321 = find_from(_5320, _whitespace_9601, 1);
    _5320 = NOVALUE;
    if (_5321 != 0)
    goto LA; // [166] 175

    /** 				exit*/
    goto L9; // [172] 186
LA: 

    /** 			pos_ +=1*/
    _pos__9612 = _pos__9612 + 1;

    /** 		end while*/
    goto L8; // [183] 148
L9: 

    /** 		key_ = ""*/
    RefDS(_5);
    DeRef(_key__9605);
    _key__9605 = _5;

    /** 		lQuote = 0*/
    _lQuote_9611 = 0;

    /** 		lChar = 0*/
    _lChar_9613 = 0;

    /** 		lWasKV = 0*/
    _lWasKV_9615 = 0;

    /** 		if haskeys then*/
    if (_haskeys_9602 == 0)
    {
        goto LB; // [210] 401
    }
    else{
    }

    /** 			while pos_ <= length(source) do*/
LC: 
    if (IS_SEQUENCE(_source_9594)){
            _5324 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5324 = 1;
    }
    if (_pos__9612 > _5324)
    goto LD; // [221] 335

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 				if find(lChar, quotes) != 0 then*/
    _5327 = find_from(_lChar_9613, _quotes_9599, 1);
    if (_5327 == 0)
    goto LE; // [238] 282

    /** 					if lChar = lQuote then*/
    if (_lChar_9613 != _lQuote_9611)
    goto LF; // [244] 261

    /** 						lQuote = 0*/
    _lQuote_9611 = 0;

    /** 						lChar = -1*/
    _lChar_9613 = -1;
    goto L10; // [258] 311
LF: 

    /** 					elsif lQuote = 0 then*/
    if (_lQuote_9611 != 0)
    goto L10; // [263] 311

    /** 						lQuote = lChar*/
    _lQuote_9611 = _lChar_9613;

    /** 						lChar = -1*/
    _lChar_9613 = -1;
    goto L10; // [279] 311
LE: 

    /** 				elsif lQuote = 0 and find(lChar, lAllDelim) != 0 then*/
    _5331 = (_lQuote_9611 == 0);
    if (_5331 == 0) {
        goto L11; // [288] 310
    }
    _5333 = find_from(_lChar_9613, _lAllDelim_9606, 1);
    _5334 = (_5333 != 0);
    _5333 = NOVALUE;
    if (_5334 == 0)
    {
        DeRef(_5334);
        _5334 = NOVALUE;
        goto L11; // [302] 310
    }
    else{
        DeRef(_5334);
        _5334 = NOVALUE;
    }

    /** 					exit*/
    goto LD; // [307] 335
L11: 
L10: 

    /** 				if lChar > 0 then*/
    if (_lChar_9613 <= 0)
    goto L12; // [313] 324

    /** 					key_ &= lChar*/
    Append(&_key__9605, _key__9605, _lChar_9613);
L12: 

    /** 				pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 			end while*/
    goto LC; // [332] 218
LD: 

    /** 			if find(lChar, whitespace) != 0 then*/
    _5338 = find_from(_lChar_9613, _whitespace_9601, 1);
    if (_5338 == 0)
    goto L13; // [342] 408

    /** 				pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 				while pos_ <= length(source) do*/
L14: 
    if (IS_SEQUENCE(_source_9594)){
            _5341 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5341 = 1;
    }
    if (_pos__9612 > _5341)
    goto L13; // [360] 408

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 					if find(lChar, whitespace) = 0 then*/
    _5344 = find_from(_lChar_9613, _whitespace_9601, 1);
    if (_5344 != 0)
    goto L15; // [377] 386

    /** 						exit*/
    goto L13; // [383] 408
L15: 

    /** 					pos_ +=1*/
    _pos__9612 = _pos__9612 + 1;

    /** 				end while*/
    goto L14; // [394] 357
    goto L13; // [398] 408
LB: 

    /** 			pos_ -= 1	-- Put back the last char.*/
    _pos__9612 = _pos__9612 - 1;
L13: 

    /** 		value_ = ""*/
    RefDS(_5);
    DeRef(_value__9604);
    _value__9604 = _5;

    /** 		if find(lChar, kv_delim) != 0  or not haskeys then*/
    _5348 = find_from(_lChar_9613, _kv_delim_9597, 1);
    _5349 = (_5348 != 0);
    _5348 = NOVALUE;
    if (_5349 != 0) {
        goto L16; // [426] 438
    }
    _5351 = (_haskeys_9602 == 0);
    if (_5351 == 0)
    {
        DeRef(_5351);
        _5351 = NOVALUE;
        goto L17; // [434] 911
    }
    else{
        DeRef(_5351);
        _5351 = NOVALUE;
    }
L16: 

    /** 			if find(lChar, kv_delim) != 0 then*/
    _5352 = find_from(_lChar_9613, _kv_delim_9597, 1);
    if (_5352 == 0)
    goto L18; // [445] 455

    /** 				lWasKV = 1*/
    _lWasKV_9615 = 1;
L18: 

    /** 			pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 			while pos_ <= length(source) do*/
L19: 
    if (IS_SEQUENCE(_source_9594)){
            _5355 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5355 = 1;
    }
    if (_pos__9612 > _5355)
    goto L1A; // [469] 506

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 				if find(lChar, whitespace) = 0 then*/
    _5358 = find_from(_lChar_9613, _whitespace_9601, 1);
    if (_5358 != 0)
    goto L1B; // [486] 495

    /** 					exit*/
    goto L1A; // [492] 506
L1B: 

    /** 				pos_ +=1*/
    _pos__9612 = _pos__9612 + 1;

    /** 			end while*/
    goto L19; // [503] 466
L1A: 

    /** 			lQuote = 0*/
    _lQuote_9611 = 0;

    /** 			lChar = 0*/
    _lChar_9613 = 0;

    /** 			lBracketed = {}*/
    RefDS(_5);
    DeRefi(_lBracketed_9610);
    _lBracketed_9610 = _5;

    /** 			while pos_ <= length(source) do*/
L1C: 
    if (IS_SEQUENCE(_source_9594)){
            _5361 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5361 = 1;
    }
    if (_pos__9612 > _5361)
    goto L1D; // [531] 813

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 				if length(lBracketed) = 0 and find(lChar, quotes) != 0 then*/
    if (IS_SEQUENCE(_lBracketed_9610)){
            _5364 = SEQ_PTR(_lBracketed_9610)->length;
    }
    else {
        _5364 = 1;
    }
    _5365 = (_5364 == 0);
    _5364 = NOVALUE;
    if (_5365 == 0) {
        goto L1E; // [550] 607
    }
    _5367 = find_from(_lChar_9613, _quotes_9599, 1);
    _5368 = (_5367 != 0);
    _5367 = NOVALUE;
    if (_5368 == 0)
    {
        DeRef(_5368);
        _5368 = NOVALUE;
        goto L1E; // [564] 607
    }
    else{
        DeRef(_5368);
        _5368 = NOVALUE;
    }

    /** 					if lChar = lQuote then*/
    if (_lChar_9613 != _lQuote_9611)
    goto L1F; // [569] 586

    /** 						lQuote = 0*/
    _lQuote_9611 = 0;

    /** 						lChar = -1*/
    _lChar_9613 = -1;
    goto L20; // [583] 789
L1F: 

    /** 					elsif lQuote = 0 then*/
    if (_lQuote_9611 != 0)
    goto L20; // [588] 789

    /** 						lQuote = lChar*/
    _lQuote_9611 = _lChar_9613;

    /** 						lChar = -1*/
    _lChar_9613 = -1;
    goto L20; // [604] 789
L1E: 

    /** 				elsif length(value_) = 1 and value_[1] = '~' and find(lChar, lStartBracket) > 0 then*/
    if (IS_SEQUENCE(_value__9604)){
            _5371 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5371 = 1;
    }
    _5372 = (_5371 == 1);
    _5371 = NOVALUE;
    if (_5372 == 0) {
        _5373 = 0;
        goto L21; // [616] 632
    }
    _2 = (int)SEQ_PTR(_value__9604);
    _5374 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5374)) {
        _5375 = (_5374 == 126);
    }
    else {
        _5375 = binary_op(EQUALS, _5374, 126);
    }
    _5374 = NOVALUE;
    if (IS_ATOM_INT(_5375))
    _5373 = (_5375 != 0);
    else
    _5373 = DBL_PTR(_5375)->dbl != 0.0;
L21: 
    if (_5373 == 0) {
        goto L22; // [632] 669
    }
    _5377 = find_from(_lChar_9613, _lStartBracket_9608, 1);
    _5378 = (_5377 > 0);
    _5377 = NOVALUE;
    if (_5378 == 0)
    {
        DeRef(_5378);
        _5378 = NOVALUE;
        goto L22; // [646] 669
    }
    else{
        DeRef(_5378);
        _5378 = NOVALUE;
    }

    /** 					lBPos = find(lChar, lStartBracket)*/
    _lBPos_9614 = find_from(_lChar_9613, _lStartBracket_9608, 1);

    /** 					lBracketed &= lEndBracket[lBPos]*/
    _2 = (int)SEQ_PTR(_lEndBracket_9609);
    _5380 = (int)*(((s1_ptr)_2)->base + _lBPos_9614);
    Append(&_lBracketed_9610, _lBracketed_9610, _5380);
    _5380 = NOVALUE;
    goto L20; // [666] 789
L22: 

    /** 				elsif find(lChar, lStartBracket) > 0 then*/
    _5382 = find_from(_lChar_9613, _lStartBracket_9608, 1);
    if (_5382 <= 0)
    goto L23; // [676] 700

    /** 					lBPos = find(lChar, lStartBracket)*/
    _lBPos_9614 = find_from(_lChar_9613, _lStartBracket_9608, 1);

    /** 					lBracketed &= lEndBracket[lBPos]*/
    _2 = (int)SEQ_PTR(_lEndBracket_9609);
    _5385 = (int)*(((s1_ptr)_2)->base + _lBPos_9614);
    Append(&_lBracketed_9610, _lBracketed_9610, _5385);
    _5385 = NOVALUE;
    goto L20; // [697] 789
L23: 

    /** 				elsif length(lBracketed) != 0 and lChar = lBracketed[$] then*/
    if (IS_SEQUENCE(_lBracketed_9610)){
            _5387 = SEQ_PTR(_lBracketed_9610)->length;
    }
    else {
        _5387 = 1;
    }
    _5388 = (_5387 != 0);
    _5387 = NOVALUE;
    if (_5388 == 0) {
        goto L24; // [709] 745
    }
    if (IS_SEQUENCE(_lBracketed_9610)){
            _5390 = SEQ_PTR(_lBracketed_9610)->length;
    }
    else {
        _5390 = 1;
    }
    _2 = (int)SEQ_PTR(_lBracketed_9610);
    _5391 = (int)*(((s1_ptr)_2)->base + _5390);
    _5392 = (_lChar_9613 == _5391);
    _5391 = NOVALUE;
    if (_5392 == 0)
    {
        DeRef(_5392);
        _5392 = NOVALUE;
        goto L24; // [725] 745
    }
    else{
        DeRef(_5392);
        _5392 = NOVALUE;
    }

    /** 					lBracketed = lBracketed[1..$-1]*/
    if (IS_SEQUENCE(_lBracketed_9610)){
            _5393 = SEQ_PTR(_lBracketed_9610)->length;
    }
    else {
        _5393 = 1;
    }
    _5394 = _5393 - 1;
    _5393 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lBracketed_9610;
    RHS_Slice(_lBracketed_9610, 1, _5394);
    goto L20; // [742] 789
L24: 

    /** 				elsif length(lBracketed) = 0 and lQuote = 0 and find(lChar, lWhitePair) != 0 then*/
    if (IS_SEQUENCE(_lBracketed_9610)){
            _5396 = SEQ_PTR(_lBracketed_9610)->length;
    }
    else {
        _5396 = 1;
    }
    _5397 = (_5396 == 0);
    _5396 = NOVALUE;
    if (_5397 == 0) {
        _5398 = 0;
        goto L25; // [754] 766
    }
    _5399 = (_lQuote_9611 == 0);
    _5398 = (_5399 != 0);
L25: 
    if (_5398 == 0) {
        goto L26; // [766] 788
    }
    _5401 = find_from(_lChar_9613, _lWhitePair_9607, 1);
    _5402 = (_5401 != 0);
    _5401 = NOVALUE;
    if (_5402 == 0)
    {
        DeRef(_5402);
        _5402 = NOVALUE;
        goto L26; // [780] 788
    }
    else{
        DeRef(_5402);
        _5402 = NOVALUE;
    }

    /** 					exit*/
    goto L1D; // [785] 813
L26: 
L20: 

    /** 				if lChar > 0 then*/
    if (_lChar_9613 <= 0)
    goto L27; // [791] 802

    /** 					value_ &= lChar*/
    Append(&_value__9604, _value__9604, _lChar_9613);
L27: 

    /** 				pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 			end while*/
    goto L1C; // [810] 528
L1D: 

    /** 			if find(lChar, whitespace) != 0  then*/
    _5406 = find_from(_lChar_9613, _whitespace_9601, 1);
    if (_5406 == 0)
    goto L28; // [820] 876

    /** 				pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 				while pos_ <= length(source) do*/
L29: 
    if (IS_SEQUENCE(_source_9594)){
            _5409 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5409 = 1;
    }
    if (_pos__9612 > _5409)
    goto L2A; // [838] 875

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 					if find(lChar, whitespace) = 0 then*/
    _5412 = find_from(_lChar_9613, _whitespace_9601, 1);
    if (_5412 != 0)
    goto L2B; // [855] 864

    /** 						exit*/
    goto L2A; // [861] 875
L2B: 

    /** 					pos_ +=1*/
    _pos__9612 = _pos__9612 + 1;

    /** 				end while*/
    goto L29; // [872] 835
L2A: 
L28: 

    /** 			if find(lChar, pair_delim) != 0  then*/
    _5415 = find_from(_lChar_9613, _pair_delim_9595, 1);
    if (_5415 == 0)
    goto L2C; // [883] 910

    /** 				pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;

    /** 				if pos_ <= length(source) then*/
    if (IS_SEQUENCE(_source_9594)){
            _5418 = SEQ_PTR(_source_9594)->length;
    }
    else {
        _5418 = 1;
    }
    if (_pos__9612 > _5418)
    goto L2D; // [898] 909

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9594);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + _pos__9612);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;
L2D: 
L2C: 
L17: 

    /** 		if find(lChar, pair_delim) != 0  then*/
    _5421 = find_from(_lChar_9613, _pair_delim_9595, 1);
    if (_5421 == 0)
    goto L2E; // [918] 929

    /** 			pos_ += 1*/
    _pos__9612 = _pos__9612 + 1;
L2E: 

    /** 		if length(value_) = 0 then*/
    if (IS_SEQUENCE(_value__9604)){
            _5424 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5424 = 1;
    }
    if (_5424 != 0)
    goto L2F; // [934] 979

    /** 			if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9605)){
            _5426 = SEQ_PTR(_key__9605)->length;
    }
    else {
        _5426 = 1;
    }
    if (_5426 != 0)
    goto L30; // [943] 958

    /** 				lKeyValues = append(lKeyValues, {})*/
    RefDS(_5);
    Append(&_lKeyValues_9603, _lKeyValues_9603, _5);

    /** 				continue*/
    goto L6; // [955] 136
L30: 

    /** 			if not lWasKV then*/
    if (_lWasKV_9615 != 0)
    goto L31; // [960] 978

    /** 				value_ = key_*/
    RefDS(_key__9605);
    DeRef(_value__9604);
    _value__9604 = _key__9605;

    /** 				key_ = ""*/
    RefDS(_5);
    DeRefDS(_key__9605);
    _key__9605 = _5;
L31: 
L2F: 

    /** 		if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9605)){
            _5430 = SEQ_PTR(_key__9605)->length;
    }
    else {
        _5430 = 1;
    }
    if (_5430 != 0)
    goto L32; // [984] 1008

    /** 			if haskeys then*/
    if (_haskeys_9602 == 0)
    {
        goto L33; // [990] 1007
    }
    else{
    }

    /** 				key_ =  sprintf("p[%d]", length(lKeyValues) + 1)*/
    if (IS_SEQUENCE(_lKeyValues_9603)){
            _5433 = SEQ_PTR(_lKeyValues_9603)->length;
    }
    else {
        _5433 = 1;
    }
    _5434 = _5433 + 1;
    _5433 = NOVALUE;
    DeRefDS(_key__9605);
    _key__9605 = EPrintf(-9999999, _5432, _5434);
    _5434 = NOVALUE;
L33: 
L32: 

    /** 		if length(value_) > 0 then*/
    if (IS_SEQUENCE(_value__9604)){
            _5436 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5436 = 1;
    }
    if (_5436 <= 0)
    goto L34; // [1013] 1168

    /** 			lChar = value_[1]*/
    _2 = (int)SEQ_PTR(_value__9604);
    _lChar_9613 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lChar_9613))
    _lChar_9613 = (long)DBL_PTR(_lChar_9613)->dbl;

    /** 			lBPos = find(lChar, lStartBracket)*/
    _lBPos_9614 = find_from(_lChar_9613, _lStartBracket_9608, 1);

    /** 			if lBPos > 0 and value_[$] = lEndBracket[lBPos] then*/
    _5440 = (_lBPos_9614 > 0);
    if (_5440 == 0) {
        goto L35; // [1036] 1149
    }
    if (IS_SEQUENCE(_value__9604)){
            _5442 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5442 = 1;
    }
    _2 = (int)SEQ_PTR(_value__9604);
    _5443 = (int)*(((s1_ptr)_2)->base + _5442);
    _2 = (int)SEQ_PTR(_lEndBracket_9609);
    _5444 = (int)*(((s1_ptr)_2)->base + _lBPos_9614);
    if (IS_ATOM_INT(_5443)) {
        _5445 = (_5443 == _5444);
    }
    else {
        _5445 = binary_op(EQUALS, _5443, _5444);
    }
    _5443 = NOVALUE;
    _5444 = NOVALUE;
    if (_5445 == 0) {
        DeRef(_5445);
        _5445 = NOVALUE;
        goto L35; // [1056] 1149
    }
    else {
        if (!IS_ATOM_INT(_5445) && DBL_PTR(_5445)->dbl == 0.0){
            DeRef(_5445);
            _5445 = NOVALUE;
            goto L35; // [1056] 1149
        }
        DeRef(_5445);
        _5445 = NOVALUE;
    }
    DeRef(_5445);
    _5445 = NOVALUE;

    /** 				if lChar = '(' then*/
    if (_lChar_9613 != 40)
    goto L36; // [1061] 1108

    /** 					value_ = keyvalues(value_[2..$-1], pair_delim, kv_delim, quotes, whitespace, haskeys)*/
    if (IS_SEQUENCE(_value__9604)){
            _5448 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5448 = 1;
    }
    _5449 = _5448 - 1;
    _5448 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5450;
    RHS_Slice(_value__9604, 2, _5449);
    Ref(_pair_delim_9595);
    DeRef(_5451);
    _5451 = _pair_delim_9595;
    Ref(_kv_delim_9597);
    DeRef(_5452);
    _5452 = _kv_delim_9597;
    Ref(_quotes_9599);
    DeRef(_5453);
    _5453 = _quotes_9599;
    Ref(_whitespace_9601);
    DeRef(_5454);
    _5454 = _whitespace_9601;
    DeRef(_5455);
    _5455 = _haskeys_9602;
    _0 = _value__9604;
    _value__9604 = _6keyvalues(_5450, _5451, _5452, _5453, _5454, _5455);
    DeRefDS(_0);
    _5450 = NOVALUE;
    _5451 = NOVALUE;
    _5452 = NOVALUE;
    _5453 = NOVALUE;
    _5454 = NOVALUE;
    _5455 = NOVALUE;
    goto L37; // [1105] 1167
L36: 

    /** 					value_ = keyvalues(value_[2..$-1], pair_delim, kv_delim, quotes, whitespace, 0)*/
    if (IS_SEQUENCE(_value__9604)){
            _5457 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5457 = 1;
    }
    _5458 = _5457 - 1;
    _5457 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5459;
    RHS_Slice(_value__9604, 2, _5458);
    Ref(_pair_delim_9595);
    DeRef(_5460);
    _5460 = _pair_delim_9595;
    Ref(_kv_delim_9597);
    DeRef(_5461);
    _5461 = _kv_delim_9597;
    Ref(_quotes_9599);
    DeRef(_5462);
    _5462 = _quotes_9599;
    Ref(_whitespace_9601);
    DeRef(_5463);
    _5463 = _whitespace_9601;
    _0 = _value__9604;
    _value__9604 = _6keyvalues(_5459, _5460, _5461, _5462, _5463, 0);
    DeRefDS(_0);
    _5459 = NOVALUE;
    _5460 = NOVALUE;
    _5461 = NOVALUE;
    _5462 = NOVALUE;
    _5463 = NOVALUE;
    goto L37; // [1146] 1167
L35: 

    /** 			elsif lChar = '~' then*/
    if (_lChar_9613 != 126)
    goto L38; // [1151] 1166

    /** 				value_ = value_[2 .. $]*/
    if (IS_SEQUENCE(_value__9604)){
            _5466 = SEQ_PTR(_value__9604)->length;
    }
    else {
        _5466 = 1;
    }
    rhs_slice_target = (object_ptr)&_value__9604;
    RHS_Slice(_value__9604, 2, _5466);
L38: 
L37: 
L34: 

    /** 		key_ = trim(key_)*/
    RefDS(_key__9605);
    RefDS(_4498);
    _0 = _key__9605;
    _key__9605 = _6trim(_key__9605, _4498, 0);
    DeRefDS(_0);

    /** 		value_ = trim(value_)*/
    RefDS(_value__9604);
    RefDS(_4498);
    _0 = _value__9604;
    _value__9604 = _6trim(_value__9604, _4498, 0);
    DeRefDS(_0);

    /** 		if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9605)){
            _5470 = SEQ_PTR(_key__9605)->length;
    }
    else {
        _5470 = 1;
    }
    if (_5470 != 0)
    goto L39; // [1193] 1206

    /** 			lKeyValues = append(lKeyValues, value_)*/
    RefDS(_value__9604);
    Append(&_lKeyValues_9603, _lKeyValues_9603, _value__9604);
    goto L6; // [1203] 136
L39: 

    /** 			lKeyValues = append(lKeyValues, {key_, value_})*/
    RefDS(_value__9604);
    RefDS(_key__9605);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key__9605;
    ((int *)_2)[2] = _value__9604;
    _5473 = MAKE_SEQ(_1);
    RefDS(_5473);
    Append(&_lKeyValues_9603, _lKeyValues_9603, _5473);
    DeRefDS(_5473);
    _5473 = NOVALUE;

    /** 	end while*/
    goto L6; // [1219] 136
L7: 

    /** 	return lKeyValues*/
    DeRefDS(_source_9594);
    DeRef(_pair_delim_9595);
    DeRef(_kv_delim_9597);
    DeRef(_quotes_9599);
    DeRef(_whitespace_9601);
    DeRef(_value__9604);
    DeRef(_key__9605);
    DeRef(_lAllDelim_9606);
    DeRef(_lWhitePair_9607);
    DeRefi(_lStartBracket_9608);
    DeRefi(_lEndBracket_9609);
    DeRefi(_lBracketed_9610);
    DeRef(_5331);
    _5331 = NOVALUE;
    DeRef(_5349);
    _5349 = NOVALUE;
    DeRef(_5365);
    _5365 = NOVALUE;
    DeRef(_5372);
    _5372 = NOVALUE;
    DeRef(_5388);
    _5388 = NOVALUE;
    DeRef(_5375);
    _5375 = NOVALUE;
    DeRef(_5394);
    _5394 = NOVALUE;
    DeRef(_5397);
    _5397 = NOVALUE;
    DeRef(_5399);
    _5399 = NOVALUE;
    DeRef(_5440);
    _5440 = NOVALUE;
    DeRef(_5449);
    _5449 = NOVALUE;
    DeRef(_5458);
    _5458 = NOVALUE;
    return _lKeyValues_9603;
    ;
}
int keyvalues() __attribute__ ((alias ("_6keyvalues")));


int _6escape(int _s_9842, int _what_9843)
{
    int _r_9845 = NOVALUE;
    int _5480 = NOVALUE;
    int _5478 = NOVALUE;
    int _5477 = NOVALUE;
    int _5476 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence r = ""*/
    RefDS(_5);
    DeRef(_r_9845);
    _r_9845 = _5;

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_9842)){
            _5476 = SEQ_PTR(_s_9842)->length;
    }
    else {
        _5476 = 1;
    }
    {
        int _i_9847;
        _i_9847 = 1;
L1: 
        if (_i_9847 > _5476){
            goto L2; // [17] 62
        }

        /** 		if find(s[i], what) then*/
        _2 = (int)SEQ_PTR(_s_9842);
        _5477 = (int)*(((s1_ptr)_2)->base + _i_9847);
        _5478 = find_from(_5477, _what_9843, 1);
        _5477 = NOVALUE;
        if (_5478 == 0)
        {
            _5478 = NOVALUE;
            goto L3; // [35] 45
        }
        else{
            _5478 = NOVALUE;
        }

        /** 			r &= "\\"*/
        Concat((object_ptr)&_r_9845, _r_9845, _910);
L3: 

        /** 		r &= s[i]*/
        _2 = (int)SEQ_PTR(_s_9842);
        _5480 = (int)*(((s1_ptr)_2)->base + _i_9847);
        if (IS_SEQUENCE(_r_9845) && IS_ATOM(_5480)) {
            Ref(_5480);
            Append(&_r_9845, _r_9845, _5480);
        }
        else if (IS_ATOM(_r_9845) && IS_SEQUENCE(_5480)) {
        }
        else {
            Concat((object_ptr)&_r_9845, _r_9845, _5480);
        }
        _5480 = NOVALUE;

        /** 	end for*/
        _i_9847 = _i_9847 + 1;
        goto L1; // [57] 24
L2: 
        ;
    }

    /** 	return r*/
    DeRefDS(_s_9842);
    DeRefDS(_what_9843);
    return _r_9845;
    ;
}


int _6quote(int _text_in_9857, int _quote_pair_9858, int _esc_9860, int _sp_9862)
{
    int _5568 = NOVALUE;
    int _5567 = NOVALUE;
    int _5566 = NOVALUE;
    int _5564 = NOVALUE;
    int _5563 = NOVALUE;
    int _5562 = NOVALUE;
    int _5560 = NOVALUE;
    int _5559 = NOVALUE;
    int _5558 = NOVALUE;
    int _5557 = NOVALUE;
    int _5556 = NOVALUE;
    int _5555 = NOVALUE;
    int _5554 = NOVALUE;
    int _5553 = NOVALUE;
    int _5552 = NOVALUE;
    int _5550 = NOVALUE;
    int _5549 = NOVALUE;
    int _5548 = NOVALUE;
    int _5546 = NOVALUE;
    int _5545 = NOVALUE;
    int _5544 = NOVALUE;
    int _5543 = NOVALUE;
    int _5542 = NOVALUE;
    int _5541 = NOVALUE;
    int _5540 = NOVALUE;
    int _5539 = NOVALUE;
    int _5538 = NOVALUE;
    int _5536 = NOVALUE;
    int _5535 = NOVALUE;
    int _5533 = NOVALUE;
    int _5532 = NOVALUE;
    int _5531 = NOVALUE;
    int _5529 = NOVALUE;
    int _5528 = NOVALUE;
    int _5527 = NOVALUE;
    int _5526 = NOVALUE;
    int _5525 = NOVALUE;
    int _5524 = NOVALUE;
    int _5523 = NOVALUE;
    int _5522 = NOVALUE;
    int _5521 = NOVALUE;
    int _5520 = NOVALUE;
    int _5519 = NOVALUE;
    int _5518 = NOVALUE;
    int _5517 = NOVALUE;
    int _5516 = NOVALUE;
    int _5515 = NOVALUE;
    int _5514 = NOVALUE;
    int _5513 = NOVALUE;
    int _5510 = NOVALUE;
    int _5509 = NOVALUE;
    int _5508 = NOVALUE;
    int _5507 = NOVALUE;
    int _5506 = NOVALUE;
    int _5505 = NOVALUE;
    int _5504 = NOVALUE;
    int _5503 = NOVALUE;
    int _5502 = NOVALUE;
    int _5501 = NOVALUE;
    int _5500 = NOVALUE;
    int _5499 = NOVALUE;
    int _5498 = NOVALUE;
    int _5497 = NOVALUE;
    int _5494 = NOVALUE;
    int _5492 = NOVALUE;
    int _5491 = NOVALUE;
    int _5489 = NOVALUE;
    int _5487 = NOVALUE;
    int _5486 = NOVALUE;
    int _5485 = NOVALUE;
    int _5483 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_esc_9860)) {
        _1 = (long)(DBL_PTR(_esc_9860)->dbl);
        DeRefDS(_esc_9860);
        _esc_9860 = _1;
    }

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_9857)){
            _5483 = SEQ_PTR(_text_in_9857)->length;
    }
    else {
        _5483 = 1;
    }
    if (_5483 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_9858);
    DeRef(_sp_9862);
    return _text_in_9857;
L1: 

    /** 	if atom(quote_pair) then*/
    _5485 = IS_ATOM(_quote_pair_9858);
    if (_5485 == 0)
    {
        _5485 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _5485 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_9858);
    *((int *)(_2+4)) = _quote_pair_9858;
    _5486 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_9858);
    *((int *)(_2+4)) = _quote_pair_9858;
    _5487 = MAKE_SEQ(_1);
    DeRef(_quote_pair_9858);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5486;
    ((int *)_2)[2] = _5487;
    _quote_pair_9858 = MAKE_SEQ(_1);
    _5487 = NOVALUE;
    _5486 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_9858)){
            _5489 = SEQ_PTR(_quote_pair_9858)->length;
    }
    else {
        _5489 = 1;
    }
    if (_5489 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5491 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5492 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5492);
    Ref(_5491);
    DeRef(_quote_pair_9858);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5491;
    ((int *)_2)[2] = _5492;
    _quote_pair_9858 = MAKE_SEQ(_1);
    _5492 = NOVALUE;
    _5491 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_9858)){
            _5494 = SEQ_PTR(_quote_pair_9858)->length;
    }
    else {
        _5494 = 1;
    }
    if (_5494 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_5475);
    RefDS(_5475);
    DeRef(_quote_pair_9858);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5475;
    ((int *)_2)[2] = _5475;
    _quote_pair_9858 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_9857);
    _5497 = (int)*(((s1_ptr)_2)->base + 1);
    _5498 = IS_SEQUENCE(_5497);
    _5497 = NOVALUE;
    if (_5498 == 0)
    {
        _5498 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _5498 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_9857)){
            _5499 = SEQ_PTR(_text_in_9857)->length;
    }
    else {
        _5499 = 1;
    }
    {
        int _i_9885;
        _i_9885 = 1;
L7: 
        if (_i_9885 > _5499){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_9857);
        _5500 = (int)*(((s1_ptr)_2)->base + _i_9885);
        _5501 = IS_SEQUENCE(_5500);
        _5500 = NOVALUE;
        if (_5501 == 0)
        {
            _5501 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _5501 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_9857);
        _5502 = (int)*(((s1_ptr)_2)->base + _i_9885);
        Ref(_quote_pair_9858);
        DeRef(_5503);
        _5503 = _quote_pair_9858;
        DeRef(_5504);
        _5504 = _esc_9860;
        Ref(_sp_9862);
        DeRef(_5505);
        _5505 = _sp_9862;
        Ref(_5502);
        _5506 = _6quote(_5502, _5503, _5504, _5505);
        _5502 = NOVALUE;
        _5503 = NOVALUE;
        _5504 = NOVALUE;
        _5505 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_9857);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_9857 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9885);
        _1 = *(int *)_2;
        *(int *)_2 = _5506;
        if( _1 != _5506 ){
            DeRef(_1);
        }
        _5506 = NOVALUE;
L9: 

        /** 		end for*/
        _i_9885 = _i_9885 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_9858);
    DeRef(_sp_9862);
    return _text_in_9857;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_9862)){
            _5507 = SEQ_PTR(_sp_9862)->length;
    }
    else {
        _5507 = 1;
    }
    {
        int _i_9896;
        _i_9896 = 1;
LA: 
        if (_i_9896 > _5507){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_9862);
        _5508 = (int)*(((s1_ptr)_2)->base + _i_9896);
        _5509 = find_from(_5508, _text_in_9857, 1);
        _5508 = NOVALUE;
        if (_5509 == 0)
        {
            _5509 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _5509 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_9862)){
                _5510 = SEQ_PTR(_sp_9862)->length;
        }
        else {
            _5510 = 1;
        }
        if (_i_9896 != _5510)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_9858);
        DeRef(_sp_9862);
        return _text_in_9857;
LD: 

        /** 	end for*/
        _i_9896 = _i_9896 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_9860 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5513 = (int)*(((s1_ptr)_2)->base + 1);
    _5514 = IS_ATOM(_5513);
    _5513 = NOVALUE;
    if (_5514 == 0)
    {
        _5514 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _5514 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5515 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5515);
    *((int *)(_2+4)) = _5515;
    _5516 = MAKE_SEQ(_1);
    _5515 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_9858 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _5516;
    if( _1 != _5516 ){
        DeRef(_1);
    }
    _5516 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5517 = (int)*(((s1_ptr)_2)->base + 2);
    _5518 = IS_ATOM(_5517);
    _5517 = NOVALUE;
    if (_5518 == 0)
    {
        _5518 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _5518 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5519 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5519);
    *((int *)(_2+4)) = _5519;
    _5520 = MAKE_SEQ(_1);
    _5519 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_9858 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5520;
    if( _1 != _5520 ){
        DeRef(_1);
    }
    _5520 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5521 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5522 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5521 == _5522)
    _5523 = 1;
    else if (IS_ATOM_INT(_5521) && IS_ATOM_INT(_5522))
    _5523 = 0;
    else
    _5523 = (compare(_5521, _5522) == 0);
    _5521 = NOVALUE;
    _5522 = NOVALUE;
    if (_5523 == 0)
    {
        _5523 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _5523 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5524 = (int)*(((s1_ptr)_2)->base + 1);
    _5525 = e_match_from(_5524, _text_in_9857, 1);
    _5524 = NOVALUE;
    if (_5525 == 0)
    {
        _5525 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _5525 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5526 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5526)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5526)) {
        Prepend(&_5527, _5526, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5527, _esc_9860, _5526);
    }
    _5526 = NOVALUE;
    _5528 = e_match_from(_5527, _text_in_9857, 1);
    DeRefDS(_5527);
    _5527 = NOVALUE;
    if (_5528 == 0)
    {
        _5528 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _5528 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_5529, _esc_9860, _esc_9860);
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_esc_9860, _text_in_9857, _5529, 0);
    DeRefDS(_0);
    _5529 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5531 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5532 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5532)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5532)) {
        Prepend(&_5533, _5532, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5533, _esc_9860, _5532);
    }
    _5532 = NOVALUE;
    Ref(_5531);
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_5531, _text_in_9857, _5533, 0);
    DeRefDS(_0);
    _5531 = NOVALUE;
    _5533 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5535 = (int)*(((s1_ptr)_2)->base + 1);
    _5536 = e_match_from(_5535, _text_in_9857, 1);
    _5535 = NOVALUE;
    if (_5536 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5538 = (int)*(((s1_ptr)_2)->base + 2);
    _5539 = e_match_from(_5538, _text_in_9857, 1);
    _5538 = NOVALUE;
    if (_5539 == 0)
    {
        _5539 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _5539 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5540 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5540)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5540)) {
        Prepend(&_5541, _5540, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5541, _esc_9860, _5540);
    }
    _5540 = NOVALUE;
    _5542 = e_match_from(_5541, _text_in_9857, 1);
    DeRefDS(_5541);
    _5541 = NOVALUE;
    if (_5542 == 0)
    {
        _5542 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _5542 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5543 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5543)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5543)) {
        Prepend(&_5544, _5543, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5544, _esc_9860, _5543);
    }
    _5543 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5545 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _5545;
        concat_list[1] = _esc_9860;
        concat_list[2] = _esc_9860;
        Concat_N((object_ptr)&_5546, concat_list, 3);
    }
    _5545 = NOVALUE;
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_5544, _text_in_9857, _5546, 0);
    DeRefDS(_0);
    _5544 = NOVALUE;
    _5546 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5548 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5549 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5549)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5549)) {
        Prepend(&_5550, _5549, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5550, _esc_9860, _5549);
    }
    _5549 = NOVALUE;
    Ref(_5548);
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_5548, _text_in_9857, _5550, 0);
    DeRefDS(_0);
    _5548 = NOVALUE;
    _5550 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5552 = (int)*(((s1_ptr)_2)->base + 2);
    _5553 = e_match_from(_5552, _text_in_9857, 1);
    _5552 = NOVALUE;
    if (_5553 == 0)
    {
        _5553 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _5553 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5554 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5554)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5554)) {
        Prepend(&_5555, _5554, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5555, _esc_9860, _5554);
    }
    _5554 = NOVALUE;
    _5556 = e_match_from(_5555, _text_in_9857, 1);
    DeRefDS(_5555);
    _5555 = NOVALUE;
    if (_5556 == 0)
    {
        _5556 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _5556 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5557 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5557)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5557)) {
        Prepend(&_5558, _5557, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5558, _esc_9860, _5557);
    }
    _5557 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5559 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5559;
        concat_list[1] = _esc_9860;
        concat_list[2] = _esc_9860;
        Concat_N((object_ptr)&_5560, concat_list, 3);
    }
    _5559 = NOVALUE;
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_5558, _text_in_9857, _5560, 0);
    DeRefDS(_0);
    _5558 = NOVALUE;
    _5560 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5562 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5563 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9860) && IS_ATOM(_5563)) {
    }
    else if (IS_ATOM(_esc_9860) && IS_SEQUENCE(_5563)) {
        Prepend(&_5564, _5563, _esc_9860);
    }
    else {
        Concat((object_ptr)&_5564, _esc_9860, _5563);
    }
    _5563 = NOVALUE;
    Ref(_5562);
    RefDS(_text_in_9857);
    _0 = _text_in_9857;
    _text_in_9857 = _9match_replace(_5562, _text_in_9857, _5564, 0);
    DeRefDS(_0);
    _5562 = NOVALUE;
    _5564 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5566 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9858);
    _5567 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5567;
        concat_list[1] = _text_in_9857;
        concat_list[2] = _5566;
        Concat_N((object_ptr)&_5568, concat_list, 3);
    }
    _5567 = NOVALUE;
    _5566 = NOVALUE;
    DeRefDS(_text_in_9857);
    DeRef(_quote_pair_9858);
    DeRef(_sp_9862);
    return _5568;
    ;
}
int quote() __attribute__ ((alias ("_6quote")));


int _6dequote(int _text_in_9975, int _quote_pairs_9976, int _esc_9979)
{
    int _pos_10044 = NOVALUE;
    int _5646 = NOVALUE;
    int _5645 = NOVALUE;
    int _5644 = NOVALUE;
    int _5643 = NOVALUE;
    int _5642 = NOVALUE;
    int _5641 = NOVALUE;
    int _5640 = NOVALUE;
    int _5639 = NOVALUE;
    int _5638 = NOVALUE;
    int _5637 = NOVALUE;
    int _5636 = NOVALUE;
    int _5634 = NOVALUE;
    int _5633 = NOVALUE;
    int _5632 = NOVALUE;
    int _5631 = NOVALUE;
    int _5630 = NOVALUE;
    int _5629 = NOVALUE;
    int _5628 = NOVALUE;
    int _5627 = NOVALUE;
    int _5626 = NOVALUE;
    int _5625 = NOVALUE;
    int _5624 = NOVALUE;
    int _5621 = NOVALUE;
    int _5620 = NOVALUE;
    int _5619 = NOVALUE;
    int _5618 = NOVALUE;
    int _5617 = NOVALUE;
    int _5616 = NOVALUE;
    int _5615 = NOVALUE;
    int _5614 = NOVALUE;
    int _5613 = NOVALUE;
    int _5612 = NOVALUE;
    int _5611 = NOVALUE;
    int _5610 = NOVALUE;
    int _5609 = NOVALUE;
    int _5608 = NOVALUE;
    int _5607 = NOVALUE;
    int _5606 = NOVALUE;
    int _5604 = NOVALUE;
    int _5603 = NOVALUE;
    int _5602 = NOVALUE;
    int _5601 = NOVALUE;
    int _5600 = NOVALUE;
    int _5599 = NOVALUE;
    int _5598 = NOVALUE;
    int _5597 = NOVALUE;
    int _5596 = NOVALUE;
    int _5595 = NOVALUE;
    int _5594 = NOVALUE;
    int _5593 = NOVALUE;
    int _5592 = NOVALUE;
    int _5591 = NOVALUE;
    int _5590 = NOVALUE;
    int _5589 = NOVALUE;
    int _5588 = NOVALUE;
    int _5587 = NOVALUE;
    int _5585 = NOVALUE;
    int _5583 = NOVALUE;
    int _5581 = NOVALUE;
    int _5580 = NOVALUE;
    int _5578 = NOVALUE;
    int _5576 = NOVALUE;
    int _5575 = NOVALUE;
    int _5574 = NOVALUE;
    int _5573 = NOVALUE;
    int _5571 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_esc_9979)) {
        _1 = (long)(DBL_PTR(_esc_9979)->dbl);
        DeRefDS(_esc_9979);
        _esc_9979 = _1;
    }

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_9975)){
            _5571 = SEQ_PTR(_text_in_9975)->length;
    }
    else {
        _5571 = 1;
    }
    if (_5571 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pairs_9976);
    return _text_in_9975;
L1: 

    /** 	if atom(quote_pairs) then*/
    _5573 = IS_ATOM(_quote_pairs_9976);
    if (_5573 == 0)
    {
        _5573 = NOVALUE;
        goto L2; // [26] 50
    }
    else{
        _5573 = NOVALUE;
    }

    /** 		quote_pairs = {{{quote_pairs}, {quote_pairs}}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pairs_9976);
    *((int *)(_2+4)) = _quote_pairs_9976;
    _5574 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pairs_9976);
    *((int *)(_2+4)) = _quote_pairs_9976;
    _5575 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5574;
    ((int *)_2)[2] = _5575;
    _5576 = MAKE_SEQ(_1);
    _5575 = NOVALUE;
    _5574 = NOVALUE;
    _0 = _quote_pairs_9976;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5576;
    _quote_pairs_9976 = MAKE_SEQ(_1);
    DeRef(_0);
    _5576 = NOVALUE;
    goto L3; // [47] 97
L2: 

    /** 	elsif length(quote_pairs) = 1 then*/
    if (IS_SEQUENCE(_quote_pairs_9976)){
            _5578 = SEQ_PTR(_quote_pairs_9976)->length;
    }
    else {
        _5578 = 1;
    }
    if (_5578 != 1)
    goto L4; // [55] 76

    /** 		quote_pairs = {quote_pairs[1], quote_pairs[1]}*/
    _2 = (int)SEQ_PTR(_quote_pairs_9976);
    _5580 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pairs_9976);
    _5581 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5581);
    Ref(_5580);
    DeRef(_quote_pairs_9976);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5580;
    ((int *)_2)[2] = _5581;
    _quote_pairs_9976 = MAKE_SEQ(_1);
    _5581 = NOVALUE;
    _5580 = NOVALUE;
    goto L3; // [73] 97
L4: 

    /** 	elsif length(quote_pairs) = 0 then*/
    if (IS_SEQUENCE(_quote_pairs_9976)){
            _5583 = SEQ_PTR(_quote_pairs_9976)->length;
    }
    else {
        _5583 = 1;
    }
    if (_5583 != 0)
    goto L5; // [81] 96

    /** 		quote_pairs = {{"\"", "\""}}*/
    RefDS(_5475);
    RefDS(_5475);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5475;
    ((int *)_2)[2] = _5475;
    _5585 = MAKE_SEQ(_1);
    _0 = _quote_pairs_9976;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5585;
    _quote_pairs_9976 = MAKE_SEQ(_1);
    DeRef(_0);
    _5585 = NOVALUE;
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_9975);
    _5587 = (int)*(((s1_ptr)_2)->base + 1);
    _5588 = IS_SEQUENCE(_5587);
    _5587 = NOVALUE;
    if (_5588 == 0)
    {
        _5588 = NOVALUE;
        goto L6; // [106] 170
    }
    else{
        _5588 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_9975)){
            _5589 = SEQ_PTR(_text_in_9975)->length;
    }
    else {
        _5589 = 1;
    }
    {
        int _i_10004;
        _i_10004 = 1;
L7: 
        if (_i_10004 > _5589){
            goto L8; // [114] 163
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_9975);
        _5590 = (int)*(((s1_ptr)_2)->base + _i_10004);
        _5591 = IS_SEQUENCE(_5590);
        _5590 = NOVALUE;
        if (_5591 == 0)
        {
            _5591 = NOVALUE;
            goto L9; // [130] 156
        }
        else{
            _5591 = NOVALUE;
        }

        /** 				text_in[i] = dequote(text_in[i], quote_pairs, esc)*/
        _2 = (int)SEQ_PTR(_text_in_9975);
        _5592 = (int)*(((s1_ptr)_2)->base + _i_10004);
        Ref(_quote_pairs_9976);
        DeRef(_5593);
        _5593 = _quote_pairs_9976;
        DeRef(_5594);
        _5594 = _esc_9979;
        Ref(_5592);
        _5595 = _6dequote(_5592, _5593, _5594);
        _5592 = NOVALUE;
        _5593 = NOVALUE;
        _5594 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_9975);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_9975 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_10004);
        _1 = *(int *)_2;
        *(int *)_2 = _5595;
        if( _1 != _5595 ){
            DeRef(_1);
        }
        _5595 = NOVALUE;
L9: 

        /** 		end for*/
        _i_10004 = _i_10004 + 1;
        goto L7; // [158] 121
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pairs_9976);
    return _text_in_9975;
L6: 

    /** 	for i = 1 to length(quote_pairs) do*/
    if (IS_SEQUENCE(_quote_pairs_9976)){
            _5596 = SEQ_PTR(_quote_pairs_9976)->length;
    }
    else {
        _5596 = 1;
    }
    {
        int _i_10014;
        _i_10014 = 1;
LA: 
        if (_i_10014 > _5596){
            goto LB; // [175] 466
        }

        /** 		if length(text_in) >= length(quote_pairs[i][1]) + length(quote_pairs[i][2]) then*/
        if (IS_SEQUENCE(_text_in_9975)){
                _5597 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5597 = 1;
        }
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5598 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5598);
        _5599 = (int)*(((s1_ptr)_2)->base + 1);
        _5598 = NOVALUE;
        if (IS_SEQUENCE(_5599)){
                _5600 = SEQ_PTR(_5599)->length;
        }
        else {
            _5600 = 1;
        }
        _5599 = NOVALUE;
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5601 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5601);
        _5602 = (int)*(((s1_ptr)_2)->base + 2);
        _5601 = NOVALUE;
        if (IS_SEQUENCE(_5602)){
                _5603 = SEQ_PTR(_5602)->length;
        }
        else {
            _5603 = 1;
        }
        _5602 = NOVALUE;
        _5604 = _5600 + _5603;
        if ((long)((unsigned long)_5604 + (unsigned long)HIGH_BITS) >= 0) 
        _5604 = NewDouble((double)_5604);
        _5600 = NOVALUE;
        _5603 = NOVALUE;
        if (binary_op_a(LESS, _5597, _5604)){
            _5597 = NOVALUE;
            DeRef(_5604);
            _5604 = NOVALUE;
            goto LC; // [213] 459
        }
        _5597 = NOVALUE;
        DeRef(_5604);
        _5604 = NOVALUE;

        /** 			if search:begins(quote_pairs[i][1], text_in) and search:ends(quote_pairs[i][2], text_in) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5606 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5606);
        _5607 = (int)*(((s1_ptr)_2)->base + 1);
        _5606 = NOVALUE;
        Ref(_5607);
        RefDS(_text_in_9975);
        _5608 = _9begins(_5607, _text_in_9975);
        _5607 = NOVALUE;
        if (IS_ATOM_INT(_5608)) {
            if (_5608 == 0) {
                goto LD; // [232] 456
            }
        }
        else {
            if (DBL_PTR(_5608)->dbl == 0.0) {
                goto LD; // [232] 456
            }
        }
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5610 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5610);
        _5611 = (int)*(((s1_ptr)_2)->base + 2);
        _5610 = NOVALUE;
        Ref(_5611);
        RefDS(_text_in_9975);
        _5612 = _9ends(_5611, _text_in_9975);
        _5611 = NOVALUE;
        if (_5612 == 0) {
            DeRef(_5612);
            _5612 = NOVALUE;
            goto LD; // [250] 456
        }
        else {
            if (!IS_ATOM_INT(_5612) && DBL_PTR(_5612)->dbl == 0.0){
                DeRef(_5612);
                _5612 = NOVALUE;
                goto LD; // [250] 456
            }
            DeRef(_5612);
            _5612 = NOVALUE;
        }
        DeRef(_5612);
        _5612 = NOVALUE;

        /** 				text_in = text_in[1 + length(quote_pairs[i][1]) .. $ - length(quote_pairs[i][2])]*/
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5613 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5613);
        _5614 = (int)*(((s1_ptr)_2)->base + 1);
        _5613 = NOVALUE;
        if (IS_SEQUENCE(_5614)){
                _5615 = SEQ_PTR(_5614)->length;
        }
        else {
            _5615 = 1;
        }
        _5614 = NOVALUE;
        _5616 = _5615 + 1;
        _5615 = NOVALUE;
        if (IS_SEQUENCE(_text_in_9975)){
                _5617 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5617 = 1;
        }
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5618 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5618);
        _5619 = (int)*(((s1_ptr)_2)->base + 2);
        _5618 = NOVALUE;
        if (IS_SEQUENCE(_5619)){
                _5620 = SEQ_PTR(_5619)->length;
        }
        else {
            _5620 = 1;
        }
        _5619 = NOVALUE;
        _5621 = _5617 - _5620;
        _5617 = NOVALUE;
        _5620 = NOVALUE;
        rhs_slice_target = (object_ptr)&_text_in_9975;
        RHS_Slice(_text_in_9975, _5616, _5621);

        /** 				integer pos = 1*/
        _pos_10044 = 1;

        /** 				while pos > 0 with entry do*/
        goto LE; // [300] 437
LF: 
        if (_pos_10044 <= 0)
        goto L10; // [303] 449

        /** 					if search:begins(quote_pairs[i][1], text_in[pos+1 .. $]) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5624 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5624);
        _5625 = (int)*(((s1_ptr)_2)->base + 1);
        _5624 = NOVALUE;
        _5626 = _pos_10044 + 1;
        if (_5626 > MAXINT){
            _5626 = NewDouble((double)_5626);
        }
        if (IS_SEQUENCE(_text_in_9975)){
                _5627 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5627 = 1;
        }
        rhs_slice_target = (object_ptr)&_5628;
        RHS_Slice(_text_in_9975, _5626, _5627);
        Ref(_5625);
        _5629 = _9begins(_5625, _5628);
        _5625 = NOVALUE;
        _5628 = NOVALUE;
        if (_5629 == 0) {
            DeRef(_5629);
            _5629 = NOVALUE;
            goto L11; // [334] 367
        }
        else {
            if (!IS_ATOM_INT(_5629) && DBL_PTR(_5629)->dbl == 0.0){
                DeRef(_5629);
                _5629 = NOVALUE;
                goto L11; // [334] 367
            }
            DeRef(_5629);
            _5629 = NOVALUE;
        }
        DeRef(_5629);
        _5629 = NOVALUE;

        /** 						text_in = text_in[1 .. pos-1] & text_in[pos + 1 .. $]*/
        _5630 = _pos_10044 - 1;
        rhs_slice_target = (object_ptr)&_5631;
        RHS_Slice(_text_in_9975, 1, _5630);
        _5632 = _pos_10044 + 1;
        if (_5632 > MAXINT){
            _5632 = NewDouble((double)_5632);
        }
        if (IS_SEQUENCE(_text_in_9975)){
                _5633 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5633 = 1;
        }
        rhs_slice_target = (object_ptr)&_5634;
        RHS_Slice(_text_in_9975, _5632, _5633);
        Concat((object_ptr)&_text_in_9975, _5631, _5634);
        DeRefDS(_5631);
        _5631 = NOVALUE;
        DeRef(_5631);
        _5631 = NOVALUE;
        DeRefDS(_5634);
        _5634 = NOVALUE;
        goto L12; // [364] 434
L11: 

        /** 					elsif search:begins(quote_pairs[i][2], text_in[pos+1 .. $]) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_9976);
        _5636 = (int)*(((s1_ptr)_2)->base + _i_10014);
        _2 = (int)SEQ_PTR(_5636);
        _5637 = (int)*(((s1_ptr)_2)->base + 2);
        _5636 = NOVALUE;
        _5638 = _pos_10044 + 1;
        if (_5638 > MAXINT){
            _5638 = NewDouble((double)_5638);
        }
        if (IS_SEQUENCE(_text_in_9975)){
                _5639 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5639 = 1;
        }
        rhs_slice_target = (object_ptr)&_5640;
        RHS_Slice(_text_in_9975, _5638, _5639);
        Ref(_5637);
        _5641 = _9begins(_5637, _5640);
        _5637 = NOVALUE;
        _5640 = NOVALUE;
        if (_5641 == 0) {
            DeRef(_5641);
            _5641 = NOVALUE;
            goto L13; // [394] 427
        }
        else {
            if (!IS_ATOM_INT(_5641) && DBL_PTR(_5641)->dbl == 0.0){
                DeRef(_5641);
                _5641 = NOVALUE;
                goto L13; // [394] 427
            }
            DeRef(_5641);
            _5641 = NOVALUE;
        }
        DeRef(_5641);
        _5641 = NOVALUE;

        /** 						text_in = text_in[1 .. pos-1] & text_in[pos + 1 .. $]*/
        _5642 = _pos_10044 - 1;
        rhs_slice_target = (object_ptr)&_5643;
        RHS_Slice(_text_in_9975, 1, _5642);
        _5644 = _pos_10044 + 1;
        if (_5644 > MAXINT){
            _5644 = NewDouble((double)_5644);
        }
        if (IS_SEQUENCE(_text_in_9975)){
                _5645 = SEQ_PTR(_text_in_9975)->length;
        }
        else {
            _5645 = 1;
        }
        rhs_slice_target = (object_ptr)&_5646;
        RHS_Slice(_text_in_9975, _5644, _5645);
        Concat((object_ptr)&_text_in_9975, _5643, _5646);
        DeRefDS(_5643);
        _5643 = NOVALUE;
        DeRef(_5643);
        _5643 = NOVALUE;
        DeRefDS(_5646);
        _5646 = NOVALUE;
        goto L12; // [424] 434
L13: 

        /** 						pos += 1*/
        _pos_10044 = _pos_10044 + 1;
L12: 

        /** 				entry*/
LE: 

        /** 					pos = find(esc, text_in, pos)*/
        _pos_10044 = find_from(_esc_9979, _text_in_9975, _pos_10044);

        /** 				end while*/
        goto LF; // [446] 303
L10: 

        /** 				exit*/
        goto LB; // [453] 466
LD: 
LC: 

        /** 	end for*/
        _i_10014 = _i_10014 + 1;
        goto LA; // [461] 182
LB: 
        ;
    }

    /** 	return text_in*/
    DeRef(_quote_pairs_9976);
    _5599 = NOVALUE;
    _5602 = NOVALUE;
    _5614 = NOVALUE;
    DeRef(_5608);
    _5608 = NOVALUE;
    DeRef(_5616);
    _5616 = NOVALUE;
    _5619 = NOVALUE;
    DeRef(_5621);
    _5621 = NOVALUE;
    DeRef(_5630);
    _5630 = NOVALUE;
    DeRef(_5626);
    _5626 = NOVALUE;
    DeRef(_5642);
    _5642 = NOVALUE;
    DeRef(_5632);
    _5632 = NOVALUE;
    DeRef(_5638);
    _5638 = NOVALUE;
    DeRef(_5644);
    _5644 = NOVALUE;
    return _text_in_9975;
    ;
}
int dequote() __attribute__ ((alias ("_6dequote")));


int _6format(int _format_pattern_10078, int _arg_list_10079)
{
    int _result_10080 = NOVALUE;
    int _in_token_10081 = NOVALUE;
    int _tch_10082 = NOVALUE;
    int _i_10083 = NOVALUE;
    int _tend_10084 = NOVALUE;
    int _cap_10085 = NOVALUE;
    int _align_10086 = NOVALUE;
    int _psign_10087 = NOVALUE;
    int _msign_10088 = NOVALUE;
    int _zfill_10089 = NOVALUE;
    int _bwz_10090 = NOVALUE;
    int _spacer_10091 = NOVALUE;
    int _alt_10092 = NOVALUE;
    int _width_10093 = NOVALUE;
    int _decs_10094 = NOVALUE;
    int _pos_10095 = NOVALUE;
    int _argn_10096 = NOVALUE;
    int _argl_10097 = NOVALUE;
    int _trimming_10098 = NOVALUE;
    int _hexout_10099 = NOVALUE;
    int _binout_10100 = NOVALUE;
    int _tsep_10101 = NOVALUE;
    int _istext_10102 = NOVALUE;
    int _prevargv_10103 = NOVALUE;
    int _currargv_10104 = NOVALUE;
    int _idname_10105 = NOVALUE;
    int _envsym_10106 = NOVALUE;
    int _envvar_10107 = NOVALUE;
    int _ep_10108 = NOVALUE;
    int _sp_10179 = NOVALUE;
    int _sp_10214 = NOVALUE;
    int _argtext_10261 = NOVALUE;
    int _tempv_10484 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_10539 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_10538 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_10546 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_10545 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_10544 = NOVALUE;
    int _msg_inlined_crash_at_2631_10568 = NOVALUE;
    int _dpos_10611 = NOVALUE;
    int _dist_10612 = NOVALUE;
    int _bracketed_10613 = NOVALUE;
    int _6057 = NOVALUE;
    int _6056 = NOVALUE;
    int _6055 = NOVALUE;
    int _6053 = NOVALUE;
    int _6052 = NOVALUE;
    int _6051 = NOVALUE;
    int _6048 = NOVALUE;
    int _6047 = NOVALUE;
    int _6044 = NOVALUE;
    int _6042 = NOVALUE;
    int _6039 = NOVALUE;
    int _6038 = NOVALUE;
    int _6037 = NOVALUE;
    int _6034 = NOVALUE;
    int _6031 = NOVALUE;
    int _6030 = NOVALUE;
    int _6029 = NOVALUE;
    int _6028 = NOVALUE;
    int _6025 = NOVALUE;
    int _6024 = NOVALUE;
    int _6023 = NOVALUE;
    int _6020 = NOVALUE;
    int _6018 = NOVALUE;
    int _6015 = NOVALUE;
    int _6014 = NOVALUE;
    int _6013 = NOVALUE;
    int _6012 = NOVALUE;
    int _6009 = NOVALUE;
    int _6004 = NOVALUE;
    int _6003 = NOVALUE;
    int _6002 = NOVALUE;
    int _6001 = NOVALUE;
    int _5995 = NOVALUE;
    int _5991 = NOVALUE;
    int _5990 = NOVALUE;
    int _5988 = NOVALUE;
    int _5986 = NOVALUE;
    int _5985 = NOVALUE;
    int _5984 = NOVALUE;
    int _5983 = NOVALUE;
    int _5982 = NOVALUE;
    int _5979 = NOVALUE;
    int _5976 = NOVALUE;
    int _5975 = NOVALUE;
    int _5972 = NOVALUE;
    int _5971 = NOVALUE;
    int _5970 = NOVALUE;
    int _5967 = NOVALUE;
    int _5965 = NOVALUE;
    int _5960 = NOVALUE;
    int _5959 = NOVALUE;
    int _5951 = NOVALUE;
    int _5947 = NOVALUE;
    int _5945 = NOVALUE;
    int _5944 = NOVALUE;
    int _5943 = NOVALUE;
    int _5940 = NOVALUE;
    int _5938 = NOVALUE;
    int _5937 = NOVALUE;
    int _5936 = NOVALUE;
    int _5934 = NOVALUE;
    int _5933 = NOVALUE;
    int _5932 = NOVALUE;
    int _5931 = NOVALUE;
    int _5928 = NOVALUE;
    int _5927 = NOVALUE;
    int _5926 = NOVALUE;
    int _5924 = NOVALUE;
    int _5923 = NOVALUE;
    int _5922 = NOVALUE;
    int _5921 = NOVALUE;
    int _5919 = NOVALUE;
    int _5917 = NOVALUE;
    int _5915 = NOVALUE;
    int _5913 = NOVALUE;
    int _5911 = NOVALUE;
    int _5909 = NOVALUE;
    int _5908 = NOVALUE;
    int _5907 = NOVALUE;
    int _5906 = NOVALUE;
    int _5905 = NOVALUE;
    int _5904 = NOVALUE;
    int _5902 = NOVALUE;
    int _5901 = NOVALUE;
    int _5899 = NOVALUE;
    int _5898 = NOVALUE;
    int _5896 = NOVALUE;
    int _5894 = NOVALUE;
    int _5893 = NOVALUE;
    int _5890 = NOVALUE;
    int _5888 = NOVALUE;
    int _5884 = NOVALUE;
    int _5882 = NOVALUE;
    int _5881 = NOVALUE;
    int _5880 = NOVALUE;
    int _5878 = NOVALUE;
    int _5877 = NOVALUE;
    int _5876 = NOVALUE;
    int _5875 = NOVALUE;
    int _5874 = NOVALUE;
    int _5872 = NOVALUE;
    int _5870 = NOVALUE;
    int _5869 = NOVALUE;
    int _5868 = NOVALUE;
    int _5867 = NOVALUE;
    int _5863 = NOVALUE;
    int _5860 = NOVALUE;
    int _5859 = NOVALUE;
    int _5856 = NOVALUE;
    int _5855 = NOVALUE;
    int _5854 = NOVALUE;
    int _5852 = NOVALUE;
    int _5851 = NOVALUE;
    int _5850 = NOVALUE;
    int _5849 = NOVALUE;
    int _5847 = NOVALUE;
    int _5845 = NOVALUE;
    int _5844 = NOVALUE;
    int _5843 = NOVALUE;
    int _5842 = NOVALUE;
    int _5841 = NOVALUE;
    int _5840 = NOVALUE;
    int _5838 = NOVALUE;
    int _5837 = NOVALUE;
    int _5836 = NOVALUE;
    int _5834 = NOVALUE;
    int _5833 = NOVALUE;
    int _5832 = NOVALUE;
    int _5831 = NOVALUE;
    int _5829 = NOVALUE;
    int _5826 = NOVALUE;
    int _5825 = NOVALUE;
    int _5823 = NOVALUE;
    int _5822 = NOVALUE;
    int _5820 = NOVALUE;
    int _5817 = NOVALUE;
    int _5816 = NOVALUE;
    int _5813 = NOVALUE;
    int _5811 = NOVALUE;
    int _5807 = NOVALUE;
    int _5805 = NOVALUE;
    int _5804 = NOVALUE;
    int _5803 = NOVALUE;
    int _5801 = NOVALUE;
    int _5799 = NOVALUE;
    int _5798 = NOVALUE;
    int _5797 = NOVALUE;
    int _5796 = NOVALUE;
    int _5795 = NOVALUE;
    int _5793 = NOVALUE;
    int _5791 = NOVALUE;
    int _5790 = NOVALUE;
    int _5789 = NOVALUE;
    int _5788 = NOVALUE;
    int _5786 = NOVALUE;
    int _5783 = NOVALUE;
    int _5781 = NOVALUE;
    int _5780 = NOVALUE;
    int _5778 = NOVALUE;
    int _5777 = NOVALUE;
    int _5776 = NOVALUE;
    int _5773 = NOVALUE;
    int _5772 = NOVALUE;
    int _5771 = NOVALUE;
    int _5770 = NOVALUE;
    int _5768 = NOVALUE;
    int _5767 = NOVALUE;
    int _5766 = NOVALUE;
    int _5765 = NOVALUE;
    int _5764 = NOVALUE;
    int _5761 = NOVALUE;
    int _5760 = NOVALUE;
    int _5759 = NOVALUE;
    int _5758 = NOVALUE;
    int _5756 = NOVALUE;
    int _5755 = NOVALUE;
    int _5754 = NOVALUE;
    int _5752 = NOVALUE;
    int _5751 = NOVALUE;
    int _5750 = NOVALUE;
    int _5748 = NOVALUE;
    int _5741 = NOVALUE;
    int _5739 = NOVALUE;
    int _5738 = NOVALUE;
    int _5731 = NOVALUE;
    int _5728 = NOVALUE;
    int _5724 = NOVALUE;
    int _5722 = NOVALUE;
    int _5721 = NOVALUE;
    int _5718 = NOVALUE;
    int _5716 = NOVALUE;
    int _5714 = NOVALUE;
    int _5711 = NOVALUE;
    int _5709 = NOVALUE;
    int _5708 = NOVALUE;
    int _5707 = NOVALUE;
    int _5706 = NOVALUE;
    int _5705 = NOVALUE;
    int _5702 = NOVALUE;
    int _5700 = NOVALUE;
    int _5699 = NOVALUE;
    int _5698 = NOVALUE;
    int _5695 = NOVALUE;
    int _5693 = NOVALUE;
    int _5691 = NOVALUE;
    int _5688 = NOVALUE;
    int _5687 = NOVALUE;
    int _5680 = NOVALUE;
    int _5677 = NOVALUE;
    int _5676 = NOVALUE;
    int _5669 = NOVALUE;
    int _5665 = NOVALUE;
    int _5662 = NOVALUE;
    int _5652 = NOVALUE;
    int _5650 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _5650 = IS_ATOM(_arg_list_10079);
    if (_5650 == 0)
    {
        _5650 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5650 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_10079;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_10079);
    *((int *)(_2+4)) = _arg_list_10079;
    _arg_list_10079 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_10080);
    _result_10080 = _5;

    /** 	in_token = 0*/
    _in_token_10081 = 0;

    /** 	i = 0*/
    _i_10083 = 0;

    /** 	tend = 0*/
    _tend_10084 = 0;

    /** 	argl = 0*/
    _argl_10097 = 0;

    /** 	spacer = 0*/
    _spacer_10091 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_10103);
    _prevargv_10103 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_10078)){
            _5652 = SEQ_PTR(_format_pattern_10078)->length;
    }
    else {
        _5652 = 1;
    }
    if (_i_10083 >= _5652)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_10083 = _i_10083 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_10078);
    _tch_10082 = (int)*(((s1_ptr)_2)->base + _i_10083);
    if (!IS_ATOM_INT(_tch_10082))
    _tch_10082 = (long)DBL_PTR(_tch_10082)->dbl;

    /**     	if not in_token then*/
    if (_in_token_10081 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_10082 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_10081 = 1;

    /**     			tend = 0*/
    _tend_10084 = 0;

    /** 				cap = 0*/
    _cap_10085 = 0;

    /** 				align = 0*/
    _align_10086 = 0;

    /** 				psign = 0*/
    _psign_10087 = 0;

    /** 				msign = 0*/
    _msign_10088 = 0;

    /** 				zfill = 0*/
    _zfill_10089 = 0;

    /** 				bwz = 0*/
    _bwz_10090 = 0;

    /** 				spacer = 0*/
    _spacer_10091 = 0;

    /** 				alt = 0*/
    _alt_10092 = 0;

    /**     			width = 0*/
    _width_10093 = 0;

    /**     			decs = -1*/
    _decs_10094 = -1;

    /**     			argn = 0*/
    _argn_10096 = 0;

    /**     			hexout = 0*/
    _hexout_10099 = 0;

    /**     			binout = 0*/
    _binout_10100 = 0;

    /**     			trimming = 0*/
    _trimming_10098 = 0;

    /**     			tsep = 0*/
    _tsep_10101 = 0;

    /**     			istext = 0*/
    _istext_10102 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_10105);
    _idname_10105 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_10107);
    _envvar_10107 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_10106);
    _envsym_10106 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_10080, _result_10080, _tch_10082);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_10082;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_10081 = 0;

        /**     				tend = i*/
        _tend_10084 = _i_10083;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_10080, _result_10080, _tch_10082);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5662 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5662 = 1;
        }
        if (_i_10083 >= _5662)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5665 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5665, 93)){
            _5665 = NOVALUE;
            goto L7; // [267] 248
        }
        _5665 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_10081 = 0;

        /** 	    					tend = 0*/
        _tend_10084 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_10085 = _tch_10082;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_10090 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_10091 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_10098 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_10089 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_10099 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_10100 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_10086 = _tch_10082;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_10087 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_10088 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_10092 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_10102 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5669 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5669 = 1;
        }
        if (_i_10083 >= _5669)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _tch_10082 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (!IS_ATOM_INT(_tch_10082))
        _tch_10082 = (long)DBL_PTR(_tch_10082)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10095 = find_from(_tch_10082, _1353, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10095 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_10083 = _i_10083 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_10093 == (short)_width_10093)
        _5676 = _width_10093 * 10;
        else
        _5676 = NewDouble(_width_10093 * (double)10);
        if (IS_ATOM_INT(_5676)) {
            _5677 = _5676 + _pos_10095;
            if ((long)((unsigned long)_5677 + (unsigned long)HIGH_BITS) >= 0) 
            _5677 = NewDouble((double)_5677);
        }
        else {
            _5677 = NewDouble(DBL_PTR(_5676)->dbl + (double)_pos_10095);
        }
        DeRef(_5676);
        _5676 = NOVALUE;
        if (IS_ATOM_INT(_5677)) {
            _width_10093 = _5677 - 1;
        }
        else {
            _width_10093 = NewDouble(DBL_PTR(_5677)->dbl - (double)1);
        }
        DeRef(_5677);
        _5677 = NOVALUE;
        if (!IS_ATOM_INT(_width_10093)) {
            _1 = (long)(DBL_PTR(_width_10093)->dbl);
            DeRefDS(_width_10093);
            _width_10093 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_10093 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_10089 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_10094 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5680 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5680 = 1;
        }
        if (_i_10083 >= _5680)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _tch_10082 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (!IS_ATOM_INT(_tch_10082))
        _tch_10082 = (long)DBL_PTR(_tch_10082)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10095 = find_from(_tch_10082, _1353, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10095 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_10083 = _i_10083 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_10094 == (short)_decs_10094)
        _5687 = _decs_10094 * 10;
        else
        _5687 = NewDouble(_decs_10094 * (double)10);
        if (IS_ATOM_INT(_5687)) {
            _5688 = _5687 + _pos_10095;
            if ((long)((unsigned long)_5688 + (unsigned long)HIGH_BITS) >= 0) 
            _5688 = NewDouble((double)_5688);
        }
        else {
            _5688 = NewDouble(DBL_PTR(_5687)->dbl + (double)_pos_10095);
        }
        DeRef(_5687);
        _5687 = NOVALUE;
        if (IS_ATOM_INT(_5688)) {
            _decs_10094 = _5688 - 1;
        }
        else {
            _decs_10094 = NewDouble(DBL_PTR(_5688)->dbl - (double)1);
        }
        DeRef(_5688);
        _5688 = NOVALUE;
        if (!IS_ATOM_INT(_decs_10094)) {
            _1 = (long)(DBL_PTR(_decs_10094)->dbl);
            DeRefDS(_decs_10094);
            _decs_10094 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10179 = _i_10083 + 1;

        /** 	    			i = sp*/
        _i_10083 = _sp_10179;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5691 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5691 = 1;
        }
        if (_i_10083 >= _5691)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5693 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5693, 125)){
            _5693 = NOVALUE;
            goto LE; // [637] 646
        }
        _5693 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5695 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5695, 93)){
            _5695 = NOVALUE;
            goto LF; // [652] 661
        }
        _5695 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5698 = _i_10083 - 1;
        rhs_slice_target = (object_ptr)&_5699;
        RHS_Slice(_format_pattern_10078, _sp_10179, _5698);
        RefDS(_4498);
        _5700 = _6trim(_5699, _4498, 0);
        _5699 = NOVALUE;
        if (IS_SEQUENCE(_5700) && IS_ATOM(61)) {
            Append(&_idname_10105, _5700, 61);
        }
        else if (IS_ATOM(_5700) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_10105, _5700, 61);
            DeRef(_5700);
            _5700 = NOVALUE;
        }
        DeRef(_5700);
        _5700 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5702 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5702, 93)){
            _5702 = NOVALUE;
            goto L10; // [699] 710
        }
        _5702 = NOVALUE;

        /**     					i -= 1*/
        _i_10083 = _i_10083 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_10079)){
                _5705 = SEQ_PTR(_arg_list_10079)->length;
        }
        else {
            _5705 = 1;
        }
        {
            int _j_10200;
            _j_10200 = 1;
L11: 
            if (_j_10200 > _5705){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10079);
            _5706 = (int)*(((s1_ptr)_2)->base + _j_10200);
            _5707 = IS_SEQUENCE(_5706);
            _5706 = NOVALUE;
            if (_5707 == 0)
            {
                _5707 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5707 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10079);
            _5708 = (int)*(((s1_ptr)_2)->base + _j_10200);
            RefDS(_idname_10105);
            Ref(_5708);
            _5709 = _9begins(_idname_10105, _5708);
            _5708 = NOVALUE;
            if (_5709 == 0) {
                DeRef(_5709);
                _5709 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5709) && DBL_PTR(_5709)->dbl == 0.0){
                    DeRef(_5709);
                    _5709 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5709);
                _5709 = NOVALUE;
            }
            DeRef(_5709);
            _5709 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_10096 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_10096 = _j_10200;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_10079)){
                    _5711 = SEQ_PTR(_arg_list_10079)->length;
            }
            else {
                _5711 = 1;
            }
            if (_j_10200 != _5711)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_10105);
            _idname_10105 = _5;

            /**     						argn = -1*/
            _argn_10096 = -1;
L16: 

            /**     				end for*/
            _j_10200 = _j_10200 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10214 = _i_10083 + 1;

        /** 	    			i = sp*/
        _i_10083 = _sp_10214;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5714 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5714 = 1;
        }
        if (_i_10083 >= _5714)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5716 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5716, 37)){
            _5716 = NOVALUE;
            goto L19; // [836] 845
        }
        _5716 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5718 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5718, 93)){
            _5718 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5718 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _5721 = _i_10083 - 1;
        rhs_slice_target = (object_ptr)&_5722;
        RHS_Slice(_format_pattern_10078, _sp_10214, _5721);
        RefDS(_4498);
        _0 = _envsym_10106;
        _envsym_10106 = _6trim(_5722, _4498, 0);
        DeRef(_0);
        _5722 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _5724 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (binary_op_a(NOTEQ, _5724, 93)){
            _5724 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5724 = NOVALUE;

        /**     					i -= 1*/
        _i_10083 = _i_10083 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_10107);
        _envvar_10107 = EGetEnv(_envsym_10106);

        /**     				argn = -1*/
        _argn_10096 = -1;

        /**     				if atom(envvar) then*/
        _5728 = IS_ATOM(_envvar_10107);
        if (_5728 == 0)
        {
            _5728 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5728 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_10107);
        _envvar_10107 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_10096 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_10083 = _i_10083 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5731 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5731 = 1;
        }
        if (_i_10083 >= _5731)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_10083 = _i_10083 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _tch_10082 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (!IS_ATOM_INT(_tch_10082))
        _tch_10082 = (long)DBL_PTR(_tch_10082)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_10095 = find_from(_tch_10082, _1353, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_10095 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_10083 = _i_10083 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_10096 == (short)_argn_10096)
        _5738 = _argn_10096 * 10;
        else
        _5738 = NewDouble(_argn_10096 * (double)10);
        if (IS_ATOM_INT(_5738)) {
            _5739 = _5738 + _pos_10095;
            if ((long)((unsigned long)_5739 + (unsigned long)HIGH_BITS) >= 0) 
            _5739 = NewDouble((double)_5739);
        }
        else {
            _5739 = NewDouble(DBL_PTR(_5738)->dbl + (double)_pos_10095);
        }
        DeRef(_5738);
        _5738 = NOVALUE;
        if (IS_ATOM_INT(_5739)) {
            _argn_10096 = _5739 - 1;
        }
        else {
            _argn_10096 = NewDouble(DBL_PTR(_5739)->dbl - (double)1);
        }
        DeRef(_5739);
        _5739 = NOVALUE;
        if (!IS_ATOM_INT(_argn_10096)) {
            _1 = (long)(DBL_PTR(_argn_10096)->dbl);
            DeRefDS(_argn_10096);
            _argn_10096 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_10078)){
                _5741 = SEQ_PTR(_format_pattern_10078)->length;
        }
        else {
            _5741 = 1;
        }
        if (_i_10083 >= _5741)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_10083 = _i_10083 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10078);
        _tsep_10101 = (int)*(((s1_ptr)_2)->base + _i_10083);
        if (!IS_ATOM_INT(_tsep_10101))
        _tsep_10101 = (long)DBL_PTR(_tsep_10101)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_10084 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10261);
    _argtext_10261 = _5;

    /**     			if argn = 0 then*/
    if (_argn_10096 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_10096 = _argl_10097 + 1;
L20: 

    /**     			argl = argn*/
    _argl_10097 = _argn_10096;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _5748 = (_argn_10096 < 1);
    if (_5748 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_10079)){
            _5750 = SEQ_PTR(_arg_list_10079)->length;
    }
    else {
        _5750 = 1;
    }
    _5751 = (_argn_10096 > _5750);
    _5750 = NOVALUE;
    if (_5751 == 0)
    {
        DeRef(_5751);
        _5751 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5751);
        _5751 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_10107)){
            _5752 = SEQ_PTR(_envvar_10107)->length;
    }
    else {
        _5752 = 1;
    }
    if (_5752 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_10107);
    DeRef(_argtext_10261);
    _argtext_10261 = _envvar_10107;

    /** 	    				currargv = envvar*/
    Ref(_envvar_10107);
    DeRef(_currargv_10104);
    _currargv_10104 = _envvar_10107;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10261);
    _argtext_10261 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_10104);
    _currargv_10104 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5754 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    Ref(_5754);
    _5755 = _7string(_5754);
    _5754 = NOVALUE;
    if (_5755 == 0) {
        DeRef(_5755);
        _5755 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5755) && DBL_PTR(_5755)->dbl == 0.0){
            DeRef(_5755);
            _5755 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5755);
        _5755 = NOVALUE;
    }
    DeRef(_5755);
    _5755 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_10105)){
            _5756 = SEQ_PTR(_idname_10105)->length;
    }
    else {
        _5756 = 1;
    }
    if (_5756 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5758 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (IS_SEQUENCE(_idname_10105)){
            _5759 = SEQ_PTR(_idname_10105)->length;
    }
    else {
        _5759 = 1;
    }
    _5760 = _5759 + 1;
    _5759 = NOVALUE;
    if (IS_SEQUENCE(_5758)){
            _5761 = SEQ_PTR(_5758)->length;
    }
    else {
        _5761 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_5758, _5760, _5761);
    _5758 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_10261);
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _argtext_10261 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    Ref(_argtext_10261);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5764 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (IS_ATOM_INT(_5764))
    _5765 = 1;
    else if (IS_ATOM_DBL(_5764))
    _5765 = IS_ATOM_INT(DoubleToInt(_5764));
    else
    _5765 = 0;
    _5764 = NOVALUE;
    if (_5765 == 0)
    {
        _5765 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _5765 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10102 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5766 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    Ref(_5766);
    _5767 = _20abs(_5766);
    _5766 = NOVALUE;
    _5768 = binary_op(AND_BITS, _2185, _5767);
    DeRef(_5767);
    _5767 = NOVALUE;
    _0 = _argtext_10261;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5768;
    _argtext_10261 = MAKE_SEQ(_1);
    DeRef(_0);
    _5768 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5770 = (_bwz_10090 != 0);
    if (_5770 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5772 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (IS_ATOM_INT(_5772)) {
        _5773 = (_5772 == 0);
    }
    else {
        _5773 = binary_op(EQUALS, _5772, 0);
    }
    _5772 = NOVALUE;
    if (_5773 == 0) {
        DeRef(_5773);
        _5773 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_5773) && DBL_PTR(_5773)->dbl == 0.0){
            DeRef(_5773);
            _5773 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_5773);
        _5773 = NOVALUE;
    }
    DeRef(_5773);
    _5773 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_10261);
    _argtext_10261 = Repeat(32, _width_10093);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_10100 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5776 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    Ref(_5776);
    _5777 = _8int_to_bits(_5776, 32);
    _5776 = NOVALUE;
    _5778 = _23reverse(_5777, 1, 0);
    _5777 = NOVALUE;
    DeRef(_argtext_10261);
    if (IS_ATOM_INT(_5778)) {
        _argtext_10261 = _5778 + 48;
        if ((long)((unsigned long)_argtext_10261 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_10261 = NewDouble((double)_argtext_10261);
    }
    else {
        _argtext_10261 = binary_op(PLUS, _5778, 48);
    }
    DeRef(_5778);
    _5778 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5780 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5780 = 1;
    }
    {
        int _ib_10310;
        _ib_10310 = 1;
L2C: 
        if (_ib_10310 > _5780){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_10261);
        _5781 = (int)*(((s1_ptr)_2)->base + _ib_10310);
        if (binary_op_a(NOTEQ, _5781, 49)){
            _5781 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _5781 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_10261)){
                _5783 = SEQ_PTR(_argtext_10261)->length;
        }
        else {
            _5783 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_10261;
        RHS_Slice(_argtext_10261, _ib_10310, _5783);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_10310 = _ib_10310 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_10099 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5786 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_argtext_10261);
    _argtext_10261 = EPrintf(-9999999, _919, _5786);
    _5786 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5788 = (_zfill_10089 != 0);
    if (_5788 == 0) {
        goto L30; // [1408] 1505
    }
    _5790 = (_width_10093 > 0);
    if (_5790 == 0)
    {
        DeRef(_5790);
        _5790 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_5790);
        _5790 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5791 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5791, 45)){
        _5791 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _5791 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5793 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5793 = 1;
    }
    if (_width_10093 <= _5793)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5795 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5795 = 1;
    }
    _5796 = _width_10093 - _5795;
    _5795 = NOVALUE;
    _5797 = Repeat(48, _5796);
    _5796 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10261)){
            _5798 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5798 = 1;
    }
    rhs_slice_target = (object_ptr)&_5799;
    RHS_Slice(_argtext_10261, 2, _5798);
    {
        int concat_list[3];

        concat_list[0] = _5799;
        concat_list[1] = _5797;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5799);
    _5799 = NOVALUE;
    DeRefDS(_5797);
    _5797 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5801 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5801 = 1;
    }
    if (_width_10093 <= _5801)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5803 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5803 = 1;
    }
    _5804 = _width_10093 - _5803;
    _5803 = NOVALUE;
    _5805 = Repeat(48, _5804);
    _5804 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _5805, _argtext_10261);
    DeRefDS(_5805);
    _5805 = NOVALUE;
    DeRef(_5805);
    _5805 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5807 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (binary_op_a(LESSEQ, _5807, 0)){
        _5807 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _5807 = NOVALUE;

    /** 								if psign then*/
    if (_psign_10087 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10089 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_10261, _argtext_10261, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5811 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5811, 48)){
        _5811 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _5811 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5813 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (binary_op_a(GREATEREQ, _5813, 0)){
        _5813 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _5813 = NOVALUE;

    /** 								if msign then*/
    if (_msign_10088 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10089 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5816 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5816 = 1;
    }
    rhs_slice_target = (object_ptr)&_5817;
    RHS_Slice(_argtext_10261, 2, _5816);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5817;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5817);
    _5817 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5820 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5820, 48)){
        _5820 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _5820 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5822 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5822 = 1;
    }
    rhs_slice_target = (object_ptr)&_5823;
    RHS_Slice(_argtext_10261, 3, _5822);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5823;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5823);
    _5823 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5825 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5825 = 1;
    }
    rhs_slice_target = (object_ptr)&_5826;
    RHS_Slice(_argtext_10261, 2, _5825);
    Append(&_argtext_10261, _5826, 41);
    DeRefDS(_5826);
    _5826 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5829 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_argtext_10261);
    _argtext_10261 = EPrintf(-9999999, _5828, _5829);
    _5829 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5831 = (_zfill_10089 != 0);
    if (_5831 == 0) {
        goto L27; // [1670] 2546
    }
    _5833 = (_width_10093 > 0);
    if (_5833 == 0)
    {
        DeRef(_5833);
        _5833 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_5833);
        _5833 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5834 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5834 = 1;
    }
    if (_width_10093 <= _5834)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5836 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5836 = 1;
    }
    _5837 = _width_10093 - _5836;
    _5836 = NOVALUE;
    _5838 = Repeat(48, _5837);
    _5837 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _5838, _argtext_10261);
    DeRefDS(_5838);
    _5838 = NOVALUE;
    DeRef(_5838);
    _5838 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5840 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    _5841 = IS_ATOM(_5840);
    _5840 = NOVALUE;
    if (_5841 == 0)
    {
        _5841 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _5841 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10102 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5842 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (IS_ATOM_INT(_5842))
    _5843 = e_floor(_5842);
    else
    _5843 = unary_op(FLOOR, _5842);
    _5842 = NOVALUE;
    _5844 = _20abs(_5843);
    _5843 = NOVALUE;
    _5845 = binary_op(AND_BITS, _2185, _5844);
    DeRef(_5844);
    _5844 = NOVALUE;
    _0 = _argtext_10261;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5845;
    _argtext_10261 = MAKE_SEQ(_1);
    DeRef(_0);
    _5845 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_10099 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5847 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_argtext_10261);
    _argtext_10261 = EPrintf(-9999999, _5828, _5847);
    _5847 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _5849 = (_zfill_10089 != 0);
    if (_5849 == 0) {
        goto L27; // [1786] 2546
    }
    _5851 = (_width_10093 > 0);
    if (_5851 == 0)
    {
        DeRef(_5851);
        _5851 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_5851);
        _5851 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5852 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5852 = 1;
    }
    if (_width_10093 <= _5852)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5854 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5854 = 1;
    }
    _5855 = _width_10093 - _5854;
    _5854 = NOVALUE;
    _5856 = Repeat(48, _5855);
    _5855 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _5856, _argtext_10261);
    DeRefDS(_5856);
    _5856 = NOVALUE;
    DeRef(_5856);
    _5856 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5859 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    _5860 = EPrintf(-9999999, _5858, _5859);
    _5859 = NOVALUE;
    RefDS(_4498);
    _0 = _argtext_10261;
    _argtext_10261 = _6trim(_5860, _4498, 0);
    DeRef(_0);
    _5860 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_10108 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _5863 = _ep_10108 + 2;
    if ((long)((unsigned long)_5863 + (unsigned long)HIGH_BITS) >= 0) 
    _5863 = NewDouble((double)_5863);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10261);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5863)) ? _5863 : (long)(DBL_PTR(_5863)->dbl);
        int stop = (IS_ATOM_INT(_5863)) ? _5863 : (long)(DBL_PTR(_5863)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10261), start, &_argtext_10261 );
            }
            else Tail(SEQ_PTR(_argtext_10261), stop+1, &_argtext_10261);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10261), start, &_argtext_10261);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10261 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10261)->ref == 1));
        }
    }
    DeRef(_5863);
    _5863 = NOVALUE;
    _5863 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_10108 = e_match_from(_5865, _argtext_10261, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _5867 = (_zfill_10089 != 0);
    if (_5867 == 0) {
        goto L3E; // [1896] 1981
    }
    _5869 = (_width_10093 > 0);
    if (_5869 == 0)
    {
        DeRef(_5869);
        _5869 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_5869);
        _5869 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5870 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5870 = 1;
    }
    if (_width_10093 <= _5870)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5872 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5872, 45)){
        _5872 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _5872 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5874 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5874 = 1;
    }
    _5875 = _width_10093 - _5874;
    _5874 = NOVALUE;
    _5876 = Repeat(48, _5875);
    _5875 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10261)){
            _5877 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5877 = 1;
    }
    rhs_slice_target = (object_ptr)&_5878;
    RHS_Slice(_argtext_10261, 2, _5877);
    {
        int concat_list[3];

        concat_list[0] = _5878;
        concat_list[1] = _5876;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5878);
    _5878 = NOVALUE;
    DeRefDS(_5876);
    _5876 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5880 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5880 = 1;
    }
    _5881 = _width_10093 - _5880;
    _5880 = NOVALUE;
    _5882 = Repeat(48, _5881);
    _5881 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _5882, _argtext_10261);
    DeRefDS(_5882);
    _5882 = NOVALUE;
    DeRef(_5882);
    _5882 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5884 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (binary_op_a(LESSEQ, _5884, 0)){
        _5884 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _5884 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_10087 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10089 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_10261, _argtext_10261, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5888 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5888, 48)){
        _5888 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _5888 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5890 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (binary_op_a(GREATEREQ, _5890, 0)){
        _5890 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _5890 = NOVALUE;

    /** 									if msign then*/
    if (_msign_10088 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10089 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5893 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5893 = 1;
    }
    rhs_slice_target = (object_ptr)&_5894;
    RHS_Slice(_argtext_10261, 2, _5893);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5894;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5894);
    _5894 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5896 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5896, 48)){
        _5896 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _5896 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5898 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5898 = 1;
    }
    rhs_slice_target = (object_ptr)&_5899;
    RHS_Slice(_argtext_10261, 3, _5898);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5899;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5899);
    _5899 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5901 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5901 = 1;
    }
    rhs_slice_target = (object_ptr)&_5902;
    RHS_Slice(_argtext_10261, 2, _5901);
    Append(&_argtext_10261, _5902, 41);
    DeRefDS(_5902);
    _5902 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5904 = (_alt_10092 != 0);
    if (_5904 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5906 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    if (IS_SEQUENCE(_5906)){
            _5907 = SEQ_PTR(_5906)->length;
    }
    else {
        _5907 = 1;
    }
    _5906 = NOVALUE;
    _5908 = (_5907 == 2);
    _5907 = NOVALUE;
    if (_5908 == 0)
    {
        DeRef(_5908);
        _5908 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_5908);
        _5908 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _5909 = IS_ATOM(_prevargv_10103);
    if (_5909 == 0)
    {
        _5909 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _5909 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_10103, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5911 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_tempv_10484);
    _2 = (int)SEQ_PTR(_5911);
    _tempv_10484 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10484);
    _5911 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5913 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_tempv_10484);
    _2 = (int)SEQ_PTR(_5913);
    _tempv_10484 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10484);
    _5913 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_10103)){
            _5915 = SEQ_PTR(_prevargv_10103)->length;
    }
    else {
        _5915 = 1;
    }
    if (_5915 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5917 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_tempv_10484);
    _2 = (int)SEQ_PTR(_5917);
    _tempv_10484 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10484);
    _5917 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5919 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    DeRef(_tempv_10484);
    _2 = (int)SEQ_PTR(_5919);
    _tempv_10484 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10484);
    _5919 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_10484);
    _5921 = _7string(_tempv_10484);
    if (_5921 == 0) {
        DeRef(_5921);
        _5921 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_5921) && DBL_PTR(_5921)->dbl == 0.0){
            DeRef(_5921);
            _5921 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_5921);
        _5921 = NOVALUE;
    }
    DeRef(_5921);
    _5921 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_10484);
    DeRef(_argtext_10261);
    _argtext_10261 = _tempv_10484;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_10484))
    _5922 = 1;
    else if (IS_ATOM_DBL(_tempv_10484))
    _5922 = IS_ATOM_INT(DoubleToInt(_tempv_10484));
    else
    _5922 = 0;
    if (_5922 == 0)
    {
        _5922 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _5922 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10102 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_10484);
    _5923 = _20abs(_tempv_10484);
    _5924 = binary_op(AND_BITS, _2185, _5923);
    DeRef(_5923);
    _5923 = NOVALUE;
    _0 = _argtext_10261;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5924;
    _argtext_10261 = MAKE_SEQ(_1);
    DeRef(_0);
    _5924 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5926 = (_bwz_10090 != 0);
    if (_5926 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_10484)) {
        _5928 = (_tempv_10484 == 0);
    }
    else {
        _5928 = binary_op(EQUALS, _tempv_10484, 0);
    }
    if (_5928 == 0) {
        DeRef(_5928);
        _5928 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_5928) && DBL_PTR(_5928)->dbl == 0.0){
            DeRef(_5928);
            _5928 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_5928);
        _5928 = NOVALUE;
    }
    DeRef(_5928);
    _5928 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10261);
    _argtext_10261 = Repeat(32, _width_10093);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_10261);
    _argtext_10261 = EPrintf(-9999999, _919, _tempv_10484);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _5931 = IS_ATOM(_tempv_10484);
    if (_5931 == 0)
    {
        _5931 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _5931 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10102 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_10484))
    _5932 = e_floor(_tempv_10484);
    else
    _5932 = unary_op(FLOOR, _tempv_10484);
    _5933 = _20abs(_5932);
    _5932 = NOVALUE;
    _5934 = binary_op(AND_BITS, _2185, _5933);
    DeRef(_5933);
    _5933 = NOVALUE;
    _0 = _argtext_10261;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5934;
    _argtext_10261 = MAKE_SEQ(_1);
    DeRef(_0);
    _5934 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5936 = (_bwz_10090 != 0);
    if (_5936 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_10484)) {
        _5938 = (_tempv_10484 == 0);
    }
    else {
        _5938 = binary_op(EQUALS, _tempv_10484, 0);
    }
    if (_5938 == 0) {
        DeRef(_5938);
        _5938 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_5938) && DBL_PTR(_5938)->dbl == 0.0){
            DeRef(_5938);
            _5938 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_5938);
        _5938 = NOVALUE;
    }
    DeRef(_5938);
    _5938 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10261);
    _argtext_10261 = Repeat(32, _width_10093);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _5940 = EPrintf(-9999999, _5858, _tempv_10484);
    RefDS(_4498);
    _0 = _argtext_10261;
    _argtext_10261 = _6trim(_5940, _4498, 0);
    DeRef(_0);
    _5940 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_5942);
    *((int *)(_2+24)) = _5942;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5943 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_10538);
    _options_inlined_pretty_sprint_at_2424_10538 = _5943;
    _5943 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_8582 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_10484);
    RefDS(_options_inlined_pretty_sprint_at_2424_10538);
    _26pretty(_tempv_10484, _options_inlined_pretty_sprint_at_2424_10538);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8585);
    DeRef(_argtext_10261);
    _argtext_10261 = _26pretty_line_8585;
    DeRef(_options_inlined_pretty_sprint_at_2424_10538);
    _options_inlined_pretty_sprint_at_2424_10538 = NOVALUE;
L4D: 
    DeRef(_tempv_10484);
    _tempv_10484 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _5944 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_5942);
    *((int *)(_2+24)) = _5942;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5945 = MAKE_SEQ(_1);
    Ref(_5944);
    DeRef(_x_inlined_pretty_sprint_at_2477_10544);
    _x_inlined_pretty_sprint_at_2477_10544 = _5944;
    _5944 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10545);
    _options_inlined_pretty_sprint_at_2480_10545 = _5945;
    _5945 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_8582 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_10544);
    RefDS(_options_inlined_pretty_sprint_at_2480_10545);
    _26pretty(_x_inlined_pretty_sprint_at_2477_10544, _options_inlined_pretty_sprint_at_2480_10545);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8585);
    DeRef(_argtext_10261);
    _argtext_10261 = _26pretty_line_8585;
    DeRef(_x_inlined_pretty_sprint_at_2477_10544);
    _x_inlined_pretty_sprint_at_2477_10544 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10545);
    _options_inlined_pretty_sprint_at_2480_10545 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_10108 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _5947 = _ep_10108 + 2;
    if ((long)((unsigned long)_5947 + (unsigned long)HIGH_BITS) >= 0) 
    _5947 = NewDouble((double)_5947);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10261);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5947)) ? _5947 : (long)(DBL_PTR(_5947)->dbl);
        int stop = (IS_ATOM_INT(_5947)) ? _5947 : (long)(DBL_PTR(_5947)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10261), start, &_argtext_10261 );
            }
            else Tail(SEQ_PTR(_argtext_10261), stop+1, &_argtext_10261);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10261), start, &_argtext_10261);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10261 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10261)->ref == 1));
        }
    }
    DeRef(_5947);
    _5947 = NOVALUE;
    _5947 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_10108 = e_match_from(_5865, _argtext_10261, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_10104);
    _2 = (int)SEQ_PTR(_arg_list_10079);
    _currargv_10104 = (int)*(((s1_ptr)_2)->base + _argn_10096);
    Ref(_currargv_10104);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5951 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5951 = 1;
    }
    if (_5951 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_10085;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_10261);
        _0 = _argtext_10261;
        _argtext_10261 = _6upper(_argtext_10261);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_10261);
        _0 = _argtext_10261;
        _argtext_10261 = _6lower(_argtext_10261);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_10261);
        _0 = _argtext_10261;
        _argtext_10261 = _6proper(_argtext_10261);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_10085 = _cap_10085;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_10568);
        _msg_inlined_crash_at_2631_10568 = EPrintf(-9999999, _5958, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_10568);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_10568);
        _msg_inlined_crash_at_2631_10568 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _5959 = IS_ATOM(_currargv_10104);
    if (_5959 == 0)
    {
        _5959 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _5959 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _5960 = find_from(101, _argtext_10261, 1);
    if (_5960 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_10094 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_10095 = find_from(46, _argtext_10261, 1);

    /** 								if pos then*/
    if (_pos_10095 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_10094 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _5965 = _pos_10095 - 1;
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, 1, _5965);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5967 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5967 = 1;
    }
    _pos_10095 = _5967 - _pos_10095;
    _5967 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_10095 <= _decs_10094)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5970 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5970 = 1;
    }
    _5971 = _5970 - _pos_10095;
    if ((long)((unsigned long)_5971 +(unsigned long) HIGH_BITS) >= 0){
        _5971 = NewDouble((double)_5971);
    }
    _5970 = NOVALUE;
    if (IS_ATOM_INT(_5971)) {
        _5972 = _5971 + _decs_10094;
    }
    else {
        _5972 = NewDouble(DBL_PTR(_5971)->dbl + (double)_decs_10094);
    }
    DeRef(_5971);
    _5971 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, 1, _5972);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_10095 >= _decs_10094)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _5975 = _decs_10094 - _pos_10095;
    _5976 = Repeat(48, _5975);
    _5975 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _argtext_10261, _5976);
    DeRefDS(_5976);
    _5976 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_10094 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _5979 = Repeat(48, _decs_10094);
    {
        int concat_list[3];

        concat_list[0] = _5979;
        concat_list[1] = 46;
        concat_list[2] = _argtext_10261;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_5979);
    _5979 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_10086 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _5982 = IS_ATOM(_currargv_10104);
    if (_5982 == 0)
    {
        _5982 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _5982 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_10086 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_10086 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _5983 = IS_ATOM(_currargv_10104);
    if (_5983 == 0)
    {
        _5983 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _5983 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _5984 = (_tsep_10101 != 0);
    if (_5984 == 0) {
        goto L66; // [2842] 3029
    }
    _5986 = (_zfill_10089 == 0);
    if (_5986 == 0)
    {
        DeRef(_5986);
        _5986 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_5986);
        _5986 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_10100 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_10099 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_10612 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_10612 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    _5988 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5988)) {
        _bracketed_10613 = (_5988 == 40);
    }
    else {
        _bracketed_10613 = binary_op(EQUALS, _5988, 40);
    }
    _5988 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_10613)) {
        _1 = (long)(DBL_PTR(_bracketed_10613)->dbl);
        DeRefDS(_bracketed_10613);
        _bracketed_10613 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_10613 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5990 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5990 = 1;
    }
    _5991 = _5990 - 1;
    _5990 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, 2, _5991);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_10611 = find_from(46, _argtext_10261, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_10611 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_10261)){
            _5995 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _5995 = 1;
    }
    _dpos_10611 = _5995 + 1;
    _5995 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_10101 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_10261);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10261 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_10611);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_10611 <= _dist_10612)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_10611 = _dpos_10611 - _dist_10612;

    /** 	    						if dpos > 1 then*/
    if (_dpos_10611 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _6001 = _dpos_10611 - 1;
    rhs_slice_target = (object_ptr)&_6002;
    RHS_Slice(_argtext_10261, 1, _6001);
    if (IS_SEQUENCE(_argtext_10261)){
            _6003 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6003 = 1;
    }
    rhs_slice_target = (object_ptr)&_6004;
    RHS_Slice(_argtext_10261, _dpos_10611, _6003);
    {
        int concat_list[3];

        concat_list[0] = _6004;
        concat_list[1] = _tsep_10101;
        concat_list[2] = _6002;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_6004);
    _6004 = NOVALUE;
    DeRefDS(_6002);
    _6002 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_10613 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_10261;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_10093 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_10261)){
            _width_10093 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _width_10093 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6009 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6009 = 1;
    }
    if (_width_10093 >= _6009)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_10086 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6012 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6012 = 1;
    }
    _6013 = _6012 - _width_10093;
    if ((long)((unsigned long)_6013 +(unsigned long) HIGH_BITS) >= 0){
        _6013 = NewDouble((double)_6013);
    }
    _6012 = NOVALUE;
    if (IS_ATOM_INT(_6013)) {
        _6014 = _6013 + 1;
        if (_6014 > MAXINT){
            _6014 = NewDouble((double)_6014);
        }
    }
    else
    _6014 = binary_op(PLUS, 1, _6013);
    DeRef(_6013);
    _6013 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10261)){
            _6015 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6015 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, _6014, _6015);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_10086 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6018 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6018 = 1;
    }
    _pos_10095 = _6018 - _width_10093;
    _6018 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _6020 = (_pos_10095 % 2);
    if (_6020 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_10095 & 1) {
        _pos_10095 = NewDouble((_pos_10095 >> 1) + 0.5);
    }
    else
    _pos_10095 = _pos_10095 >> 1;
    if (!IS_ATOM_INT(_pos_10095)) {
        _1 = (long)(DBL_PTR(_pos_10095)->dbl);
        DeRefDS(_pos_10095);
        _pos_10095 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _6023 = _pos_10095 + 1;
    if (_6023 > MAXINT){
        _6023 = NewDouble((double)_6023);
    }
    if (IS_SEQUENCE(_argtext_10261)){
            _6024 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6024 = 1;
    }
    _6025 = _6024 - _pos_10095;
    _6024 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, _6023, _6025);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_10095 = _pos_10095 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _6028 = _pos_10095 + 1;
    if (_6028 > MAXINT){
        _6028 = NewDouble((double)_6028);
    }
    if (IS_SEQUENCE(_argtext_10261)){
            _6029 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6029 = 1;
    }
    _6030 = _6029 - _pos_10095;
    if ((long)((unsigned long)_6030 +(unsigned long) HIGH_BITS) >= 0){
        _6030 = NewDouble((double)_6030);
    }
    _6029 = NOVALUE;
    if (IS_ATOM_INT(_6030)) {
        _6031 = _6030 - 1;
    }
    else {
        _6031 = NewDouble(DBL_PTR(_6030)->dbl - (double)1);
    }
    DeRef(_6030);
    _6030 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, _6028, _6031);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_10261;
    RHS_Slice(_argtext_10261, 1, _width_10093);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6034 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6034 = 1;
    }
    if (_width_10093 <= _6034)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_10086 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6037 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6037 = 1;
    }
    _6038 = _width_10093 - _6037;
    _6037 = NOVALUE;
    _6039 = Repeat(32, _6038);
    _6038 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _6039, _argtext_10261);
    DeRefDS(_6039);
    _6039 = NOVALUE;
    DeRef(_6039);
    _6039 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_10086 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6042 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6042 = 1;
    }
    _pos_10095 = _width_10093 - _6042;
    _6042 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _6044 = (_pos_10095 % 2);
    if (_6044 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_10095 & 1) {
        _pos_10095 = NewDouble((_pos_10095 >> 1) + 0.5);
    }
    else
    _pos_10095 = _pos_10095 >> 1;
    if (!IS_ATOM_INT(_pos_10095)) {
        _1 = (long)(DBL_PTR(_pos_10095)->dbl);
        DeRefDS(_pos_10095);
        _pos_10095 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _6047 = Repeat(32, _pos_10095);
    _6048 = Repeat(32, _pos_10095);
    {
        int concat_list[3];

        concat_list[0] = _6048;
        concat_list[1] = _argtext_10261;
        concat_list[2] = _6047;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_6048);
    _6048 = NOVALUE;
    DeRefDS(_6047);
    _6047 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_10095 = _pos_10095 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _6051 = Repeat(32, _pos_10095);
    _6052 = _pos_10095 + 1;
    _6053 = Repeat(32, _6052);
    _6052 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _6053;
        concat_list[1] = _argtext_10261;
        concat_list[2] = _6051;
        Concat_N((object_ptr)&_argtext_10261, concat_list, 3);
    }
    DeRefDS(_6053);
    _6053 = NOVALUE;
    DeRefDS(_6051);
    _6051 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_10261)){
            _6055 = SEQ_PTR(_argtext_10261)->length;
    }
    else {
        _6055 = 1;
    }
    _6056 = _width_10093 - _6055;
    _6055 = NOVALUE;
    _6057 = Repeat(32, _6056);
    _6056 = NOVALUE;
    Concat((object_ptr)&_argtext_10261, _argtext_10261, _6057);
    DeRefDS(_6057);
    _6057 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_10080, _result_10080, _argtext_10261);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_10091 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_10080, _result_10080, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_10098 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_10080);
    RefDS(_4498);
    _0 = _result_10080;
    _result_10080 = _6trim(_result_10080, _4498, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_10084 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_10104);
    DeRef(_prevargv_10103);
    _prevargv_10103 = _currargv_10104;
L1F: 
    DeRef(_argtext_10261);
    _argtext_10261 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_10078);
    DeRef(_arg_list_10079);
    DeRef(_prevargv_10103);
    DeRef(_currargv_10104);
    DeRef(_idname_10105);
    DeRef(_envsym_10106);
    DeRefi(_envvar_10107);
    DeRef(_5867);
    _5867 = NOVALUE;
    DeRef(_5965);
    _5965 = NOVALUE;
    DeRef(_6001);
    _6001 = NOVALUE;
    DeRef(_6023);
    _6023 = NOVALUE;
    DeRef(_5831);
    _5831 = NOVALUE;
    DeRef(_5698);
    _5698 = NOVALUE;
    DeRef(_6028);
    _6028 = NOVALUE;
    DeRef(_6025);
    _6025 = NOVALUE;
    DeRef(_6031);
    _6031 = NOVALUE;
    DeRef(_5904);
    _5904 = NOVALUE;
    DeRef(_5721);
    _5721 = NOVALUE;
    _5906 = NOVALUE;
    DeRef(_6020);
    _6020 = NOVALUE;
    DeRef(_5760);
    _5760 = NOVALUE;
    DeRef(_6044);
    _6044 = NOVALUE;
    DeRef(_5770);
    _5770 = NOVALUE;
    DeRef(_5984);
    _5984 = NOVALUE;
    DeRef(_5926);
    _5926 = NOVALUE;
    DeRef(_5936);
    _5936 = NOVALUE;
    DeRef(_5991);
    _5991 = NOVALUE;
    DeRef(_5849);
    _5849 = NOVALUE;
    DeRef(_5972);
    _5972 = NOVALUE;
    DeRef(_5748);
    _5748 = NOVALUE;
    DeRef(_6014);
    _6014 = NOVALUE;
    DeRef(_5788);
    _5788 = NOVALUE;
    return _result_10080;
    ;
}


int _6wrap(int _content_10716, int _width_10717, int _wrap_with_10718, int _wrap_at_10719)
{
    int _result_10724 = NOVALUE;
    int _split_at_10727 = NOVALUE;
    int _6087 = NOVALUE;
    int _6085 = NOVALUE;
    int _6083 = NOVALUE;
    int _6082 = NOVALUE;
    int _6081 = NOVALUE;
    int _6079 = NOVALUE;
    int _6078 = NOVALUE;
    int _6076 = NOVALUE;
    int _6073 = NOVALUE;
    int _6071 = NOVALUE;
    int _6070 = NOVALUE;
    int _6069 = NOVALUE;
    int _6067 = NOVALUE;
    int _6066 = NOVALUE;
    int _6065 = NOVALUE;
    int _6063 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_width_10717)) {
        _1 = (long)(DBL_PTR(_width_10717)->dbl);
        DeRefDS(_width_10717);
        _width_10717 = _1;
    }

    /** 	if length(content) < width then*/
    if (IS_SEQUENCE(_content_10716)){
            _6063 = SEQ_PTR(_content_10716)->length;
    }
    else {
        _6063 = 1;
    }
    if (_6063 >= _width_10717)
    goto L1; // [14] 25

    /** 		return content*/
    DeRefDS(_wrap_with_10718);
    DeRefDS(_wrap_at_10719);
    DeRef(_result_10724);
    return _content_10716;
L1: 

    /** 	sequence result = ""*/
    RefDS(_5);
    DeRef(_result_10724);
    _result_10724 = _5;

    /** 	while length(content) do*/
L2: 
    if (IS_SEQUENCE(_content_10716)){
            _6065 = SEQ_PTR(_content_10716)->length;
    }
    else {
        _6065 = 1;
    }
    if (_6065 == 0)
    {
        _6065 = NOVALUE;
        goto L3; // [40] 259
    }
    else{
        _6065 = NOVALUE;
    }

    /** 		integer split_at = 0*/
    _split_at_10727 = 0;

    /** 		for i = width to 1 by -1 do*/
    {
        int _i_10729;
        _i_10729 = _width_10717;
L4: 
        if (_i_10729 < 1){
            goto L5; // [50] 88
        }

        /** 			if find(content[i], wrap_at) then*/
        _2 = (int)SEQ_PTR(_content_10716);
        _6066 = (int)*(((s1_ptr)_2)->base + _i_10729);
        _6067 = find_from(_6066, _wrap_at_10719, 1);
        _6066 = NOVALUE;
        if (_6067 == 0)
        {
            _6067 = NOVALUE;
            goto L6; // [68] 81
        }
        else{
            _6067 = NOVALUE;
        }

        /** 				split_at = i*/
        _split_at_10727 = _i_10729;

        /** 				exit*/
        goto L5; // [78] 88
L6: 

        /** 		end for*/
        _i_10729 = _i_10729 + -1;
        goto L4; // [83] 57
L5: 
        ;
    }

    /** 		if split_at = 0 then*/
    if (_split_at_10727 != 0)
    goto L7; // [90] 172

    /** 			for i = width to length(content) do*/
    if (IS_SEQUENCE(_content_10716)){
            _6069 = SEQ_PTR(_content_10716)->length;
    }
    else {
        _6069 = 1;
    }
    {
        int _i_10736;
        _i_10736 = _width_10717;
L8: 
        if (_i_10736 > _6069){
            goto L9; // [99] 137
        }

        /** 				if find(content[i], wrap_at) then*/
        _2 = (int)SEQ_PTR(_content_10716);
        _6070 = (int)*(((s1_ptr)_2)->base + _i_10736);
        _6071 = find_from(_6070, _wrap_at_10719, 1);
        _6070 = NOVALUE;
        if (_6071 == 0)
        {
            _6071 = NOVALUE;
            goto LA; // [117] 130
        }
        else{
            _6071 = NOVALUE;
        }

        /** 					split_at = i*/
        _split_at_10727 = _i_10736;

        /** 					exit*/
        goto L9; // [127] 137
LA: 

        /** 			end for*/
        _i_10736 = _i_10736 + 1;
        goto L8; // [132] 106
L9: 
        ;
    }

    /** 			if split_at = 0 then*/
    if (_split_at_10727 != 0)
    goto LB; // [139] 171

    /** 				if length(result) then*/
    if (IS_SEQUENCE(_result_10724)){
            _6073 = SEQ_PTR(_result_10724)->length;
    }
    else {
        _6073 = 1;
    }
    if (_6073 == 0)
    {
        _6073 = NOVALUE;
        goto LC; // [148] 158
    }
    else{
        _6073 = NOVALUE;
    }

    /** 					result &= wrap_with*/
    Concat((object_ptr)&_result_10724, _result_10724, _wrap_with_10718);
LC: 

    /** 				result &= content*/
    Concat((object_ptr)&_result_10724, _result_10724, _content_10716);

    /** 				exit*/
    goto L3; // [168] 259
LB: 
L7: 

    /** 		if length(result) then*/
    if (IS_SEQUENCE(_result_10724)){
            _6076 = SEQ_PTR(_result_10724)->length;
    }
    else {
        _6076 = 1;
    }
    if (_6076 == 0)
    {
        _6076 = NOVALUE;
        goto LD; // [177] 187
    }
    else{
        _6076 = NOVALUE;
    }

    /** 			result &= wrap_with*/
    Concat((object_ptr)&_result_10724, _result_10724, _wrap_with_10718);
LD: 

    /** 		result &= trim(content[1..split_at])*/
    rhs_slice_target = (object_ptr)&_6078;
    RHS_Slice(_content_10716, 1, _split_at_10727);
    RefDS(_4498);
    _6079 = _6trim(_6078, _4498, 0);
    _6078 = NOVALUE;
    if (IS_SEQUENCE(_result_10724) && IS_ATOM(_6079)) {
        Ref(_6079);
        Append(&_result_10724, _result_10724, _6079);
    }
    else if (IS_ATOM(_result_10724) && IS_SEQUENCE(_6079)) {
    }
    else {
        Concat((object_ptr)&_result_10724, _result_10724, _6079);
    }
    DeRef(_6079);
    _6079 = NOVALUE;

    /** 		content = trim(content[split_at + 1..$])*/
    _6081 = _split_at_10727 + 1;
    if (_6081 > MAXINT){
        _6081 = NewDouble((double)_6081);
    }
    if (IS_SEQUENCE(_content_10716)){
            _6082 = SEQ_PTR(_content_10716)->length;
    }
    else {
        _6082 = 1;
    }
    rhs_slice_target = (object_ptr)&_6083;
    RHS_Slice(_content_10716, _6081, _6082);
    RefDS(_4498);
    _0 = _content_10716;
    _content_10716 = _6trim(_6083, _4498, 0);
    DeRefDS(_0);
    _6083 = NOVALUE;

    /** 		if length(content) < width then*/
    if (IS_SEQUENCE(_content_10716)){
            _6085 = SEQ_PTR(_content_10716)->length;
    }
    else {
        _6085 = 1;
    }
    if (_6085 >= _width_10717)
    goto LE; // [231] 252

    /** 			result &= wrap_with & content*/
    Concat((object_ptr)&_6087, _wrap_with_10718, _content_10716);
    Concat((object_ptr)&_result_10724, _result_10724, _6087);
    DeRefDS(_6087);
    _6087 = NOVALUE;

    /** 			exit*/
    goto L3; // [249] 259
LE: 

    /** 	end while*/
    goto L2; // [256] 37
L3: 

    /** 	return result*/
    DeRefDS(_content_10716);
    DeRefDS(_wrap_with_10718);
    DeRefDS(_wrap_at_10719);
    DeRef(_6081);
    _6081 = NOVALUE;
    return _result_10724;
    ;
}



// 0x862AD65F
