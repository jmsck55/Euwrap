// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _33map(int _obj_p_12826)
{
    int _m__12830 = NOVALUE;
    int _7302 = NOVALUE;
    int _7301 = NOVALUE;
    int _7300 = NOVALUE;
    int _7299 = NOVALUE;
    int _7298 = NOVALUE;
    int _7297 = NOVALUE;
    int _7296 = NOVALUE;
    int _7295 = NOVALUE;
    int _7294 = NOVALUE;
    int _7293 = NOVALUE;
    int _7291 = NOVALUE;
    int _7290 = NOVALUE;
    int _7289 = NOVALUE;
    int _7288 = NOVALUE;
    int _7286 = NOVALUE;
    int _7285 = NOVALUE;
    int _7284 = NOVALUE;
    int _7283 = NOVALUE;
    int _7281 = NOVALUE;
    int _7280 = NOVALUE;
    int _7279 = NOVALUE;
    int _7278 = NOVALUE;
    int _7277 = NOVALUE;
    int _7276 = NOVALUE;
    int _7275 = NOVALUE;
    int _7274 = NOVALUE;
    int _7273 = NOVALUE;
    int _7272 = NOVALUE;
    int _7270 = NOVALUE;
    int _7268 = NOVALUE;
    int _7267 = NOVALUE;
    int _7265 = NOVALUE;
    int _7263 = NOVALUE;
    int _7262 = NOVALUE;
    int _7260 = NOVALUE;
    int _7259 = NOVALUE;
    int _7257 = NOVALUE;
    int _7255 = NOVALUE;
    int _7253 = NOVALUE;
    int _7250 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_12826);
    RefDS(_5);
    _7250 = _28valid(_obj_p_12826, _5);
    if (IS_ATOM_INT(_7250)) {
        if (_7250 != 0){
            DeRef(_7250);
            _7250 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_7250)->dbl != 0.0){
            DeRef(_7250);
            _7250 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_7250);
    _7250 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__12830);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_obj_p_12826)){
        _m__12830 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_12826)->dbl));
    }
    else{
        _m__12830 = (int)*(((s1_ptr)_2)->base + _obj_p_12826);
    }
    Ref(_m__12830);

    /** 	if not sequence(m_) then return 0 end if*/
    _7253 = IS_SEQUENCE(_m__12830);
    if (_7253 != 0)
    goto L2; // [31] 39
    _7253 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__12830)){
            _7255 = SEQ_PTR(_m__12830)->length;
    }
    else {
        _7255 = 1;
    }
    if (_7255 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__12830)){
            _7257 = SEQ_PTR(_m__12830)->length;
    }
    else {
        _7257 = 1;
    }
    if (_7257 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7259 = (int)*(((s1_ptr)_2)->base + 1);
    if (_7259 == _33type_is_map_12806)
    _7260 = 1;
    else if (IS_ATOM_INT(_7259) && IS_ATOM_INT(_33type_is_map_12806))
    _7260 = 0;
    else
    _7260 = (compare(_7259, _33type_is_map_12806) == 0);
    _7259 = NOVALUE;
    if (_7260 != 0)
    goto L5; // [77] 85
    _7260 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7262 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7262))
    _7263 = 1;
    else if (IS_ATOM_DBL(_7262))
    _7263 = IS_ATOM_INT(DoubleToInt(_7262));
    else
    _7263 = 0;
    _7262 = NOVALUE;
    if (_7263 != 0)
    goto L6; // [94] 102
    _7263 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7265 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _7265, 0)){
        _7265 = NOVALUE;
        goto L7; // [108] 117
    }
    _7265 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7267 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7267))
    _7268 = 1;
    else if (IS_ATOM_DBL(_7267))
    _7268 = IS_ATOM_INT(DoubleToInt(_7267));
    else
    _7268 = 0;
    _7267 = NOVALUE;
    if (_7268 != 0)
    goto L8; // [126] 134
    _7268 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7270 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _7270, 0)){
        _7270 = NOVALUE;
        goto L9; // [140] 149
    }
    _7270 = NOVALUE;
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7272 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7272 == 115)
    _7273 = 1;
    else if (IS_ATOM_INT(_7272) && IS_ATOM_INT(115))
    _7273 = 0;
    else
    _7273 = (compare(_7272, 115) == 0);
    _7272 = NOVALUE;
    if (_7273 == 0)
    {
        _7273 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _7273 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7274 = (int)*(((s1_ptr)_2)->base + 5);
    _7275 = IS_ATOM(_7274);
    _7274 = NOVALUE;
    if (_7275 == 0)
    {
        _7275 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _7275 = NOVALUE;
    }
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7276 = (int)*(((s1_ptr)_2)->base + 6);
    _7277 = IS_ATOM(_7276);
    _7276 = NOVALUE;
    if (_7277 == 0)
    {
        _7277 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _7277 = NOVALUE;
    }
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7278 = (int)*(((s1_ptr)_2)->base + 7);
    _7279 = IS_ATOM(_7278);
    _7278 = NOVALUE;
    if (_7279 == 0)
    {
        _7279 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _7279 = NOVALUE;
    }
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7280 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7280)){
            _7281 = SEQ_PTR(_7280)->length;
    }
    else {
        _7281 = 1;
    }
    _7280 = NOVALUE;
    if (_7281 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7283 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7283)){
            _7284 = SEQ_PTR(_7283)->length;
    }
    else {
        _7284 = 1;
    }
    _7283 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12830);
    _7285 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7285)){
            _7286 = SEQ_PTR(_7285)->length;
    }
    else {
        _7286 = 1;
    }
    _7285 = NOVALUE;
    if (_7284 == _7286)
    goto LF; // [247] 256
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7288 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7288)){
            _7289 = SEQ_PTR(_7288)->length;
    }
    else {
        _7289 = 1;
    }
    _7288 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12830);
    _7290 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7290)){
            _7291 = SEQ_PTR(_7290)->length;
    }
    else {
        _7291 = 1;
    }
    _7290 = NOVALUE;
    if (_7289 == _7291)
    goto L10; // [272] 366
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7293 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7293 == 76)
    _7294 = 1;
    else if (IS_ATOM_INT(_7293) && IS_ATOM_INT(76))
    _7294 = 0;
    else
    _7294 = (compare(_7293, 76) == 0);
    _7293 = NOVALUE;
    if (_7294 == 0)
    {
        _7294 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _7294 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7295 = (int)*(((s1_ptr)_2)->base + 5);
    _7296 = IS_ATOM(_7295);
    _7295 = NOVALUE;
    if (_7296 == 0)
    {
        _7296 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _7296 = NOVALUE;
    }
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7297 = (int)*(((s1_ptr)_2)->base + 6);
    _7298 = IS_ATOM(_7297);
    _7297 = NOVALUE;
    if (_7298 == 0)
    {
        _7298 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _7298 = NOVALUE;
    }
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12830);
    _7299 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7299)){
            _7300 = SEQ_PTR(_7299)->length;
    }
    else {
        _7300 = 1;
    }
    _7299 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12830);
    _7301 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7301)){
            _7302 = SEQ_PTR(_7301)->length;
    }
    else {
        _7302 = 1;
    }
    _7301 = NOVALUE;
    if (_7300 == _7302)
    goto L10; // [347] 366
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    _7299 = NOVALUE;
    _7301 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    _7299 = NOVALUE;
    _7301 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_12826);
    DeRef(_m__12830);
    _7280 = NOVALUE;
    _7283 = NOVALUE;
    _7285 = NOVALUE;
    _7288 = NOVALUE;
    _7290 = NOVALUE;
    _7299 = NOVALUE;
    _7301 = NOVALUE;
    return 1;
    ;
}
int map() __attribute__ ((alias ("_33map")));


int _33calc_hash(int _key_p_12907, int _max_hash_p_12908)
{
    int _ret__12909 = NOVALUE;
    int _7307 = NOVALUE;
    int _7306 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_hash_p_12908)) {
        _1 = (long)(DBL_PTR(_max_hash_p_12908)->dbl);
        DeRefDS(_max_hash_p_12908);
        _max_hash_p_12908 = _1;
    }

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    _ret__12909 = calc_hash(_key_p_12907, -6);
    if (!IS_ATOM_INT(_ret__12909)) {
        _1 = (long)(DBL_PTR(_ret__12909)->dbl);
        DeRefDS(_ret__12909);
        _ret__12909 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _7306 = (_ret__12909 % _max_hash_p_12908);
    _7307 = _7306 + 1;
    if (_7307 > MAXINT){
        _7307 = NewDouble((double)_7307);
    }
    _7306 = NOVALUE;
    DeRef(_key_p_12907);
    return _7307;
    ;
}


int _33threshold(int _new_value_p_12915)
{
    int _old_value__12918 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_value_p_12915)) {
        _1 = (long)(DBL_PTR(_new_value_p_12915)->dbl);
        DeRefDS(_new_value_p_12915);
        _new_value_p_12915 = _1;
    }

    /** 	if new_value_p < 1 then*/
    if (_new_value_p_12915 >= 1)
    goto L1; // [5] 18

    /** 		return threshold_size*/
    return _33threshold_size_12820;
L1: 

    /** 	integer old_value_ = threshold_size*/
    _old_value__12918 = _33threshold_size_12820;

    /** 	threshold_size = new_value_p*/
    _33threshold_size_12820 = _new_value_p_12915;

    /** 	return old_value_*/
    return _old_value__12918;
    ;
}
int threshold() __attribute__ ((alias ("_33threshold")));


int _33type_of(int _the_map_p_12921)
{
    int _7310 = NOVALUE;
    int _7309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eumem:ram_space[the_map_p][MAP_TYPE]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_12921)){
        _7309 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12921)->dbl));
    }
    else{
        _7309 = (int)*(((s1_ptr)_2)->base + _the_map_p_12921);
    }
    _2 = (int)SEQ_PTR(_7309);
    _7310 = (int)*(((s1_ptr)_2)->base + 4);
    _7309 = NOVALUE;
    Ref(_7310);
    DeRef(_the_map_p_12921);
    return _7310;
    ;
}
int type_of() __attribute__ ((alias ("_33type_of")));


void _33rehash(int _the_map_p_12926, int _requested_bucket_size_p_12927)
{
    int _size__12928 = NOVALUE;
    int _index_2__12929 = NOVALUE;
    int _old_key_buckets__12930 = NOVALUE;
    int _old_val_buckets__12931 = NOVALUE;
    int _new_key_buckets__12932 = NOVALUE;
    int _new_val_buckets__12933 = NOVALUE;
    int _key__12934 = NOVALUE;
    int _value__12935 = NOVALUE;
    int _pos_12936 = NOVALUE;
    int _new_keys_12937 = NOVALUE;
    int _in_use_12938 = NOVALUE;
    int _elem_count_12939 = NOVALUE;
    int _calc_hash_1__tmp_at227_12982 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_12981 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_12980 = NOVALUE;
    int _7370 = NOVALUE;
    int _7369 = NOVALUE;
    int _7368 = NOVALUE;
    int _7367 = NOVALUE;
    int _7366 = NOVALUE;
    int _7365 = NOVALUE;
    int _7364 = NOVALUE;
    int _7363 = NOVALUE;
    int _7362 = NOVALUE;
    int _7360 = NOVALUE;
    int _7359 = NOVALUE;
    int _7358 = NOVALUE;
    int _7355 = NOVALUE;
    int _7354 = NOVALUE;
    int _7352 = NOVALUE;
    int _7351 = NOVALUE;
    int _7350 = NOVALUE;
    int _7349 = NOVALUE;
    int _7347 = NOVALUE;
    int _7345 = NOVALUE;
    int _7343 = NOVALUE;
    int _7340 = NOVALUE;
    int _7338 = NOVALUE;
    int _7337 = NOVALUE;
    int _7336 = NOVALUE;
    int _7335 = NOVALUE;
    int _7333 = NOVALUE;
    int _7331 = NOVALUE;
    int _7329 = NOVALUE;
    int _7328 = NOVALUE;
    int _7326 = NOVALUE;
    int _7324 = NOVALUE;
    int _7321 = NOVALUE;
    int _7319 = NOVALUE;
    int _7318 = NOVALUE;
    int _7317 = NOVALUE;
    int _7316 = NOVALUE;
    int _7315 = NOVALUE;
    int _7312 = NOVALUE;
    int _7311 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_12926)) {
        _1 = (long)(DBL_PTR(_the_map_p_12926)->dbl);
        DeRefDS(_the_map_p_12926);
        _the_map_p_12926 = _1;
    }
    if (!IS_ATOM_INT(_requested_bucket_size_p_12927)) {
        _1 = (long)(DBL_PTR(_requested_bucket_size_p_12927)->dbl);
        DeRefDS(_requested_bucket_size_p_12927);
        _requested_bucket_size_p_12927 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7311 = (int)*(((s1_ptr)_2)->base + _the_map_p_12926);
    _2 = (int)SEQ_PTR(_7311);
    _7312 = (int)*(((s1_ptr)_2)->base + 4);
    _7311 = NOVALUE;
    if (binary_op_a(NOTEQ, _7312, 115)){
        _7312 = NOVALUE;
        goto L1; // [17] 27
    }
    _7312 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__12930);
    DeRef(_old_val_buckets__12931);
    DeRef(_new_key_buckets__12932);
    DeRef(_new_val_buckets__12933);
    DeRef(_key__12934);
    DeRef(_value__12935);
    DeRef(_new_keys_12937);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_12927 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7315 = (int)*(((s1_ptr)_2)->base + _the_map_p_12926);
    _2 = (int)SEQ_PTR(_7315);
    _7316 = (int)*(((s1_ptr)_2)->base + 5);
    _7315 = NOVALUE;
    if (IS_SEQUENCE(_7316)){
            _7317 = SEQ_PTR(_7316)->length;
    }
    else {
        _7317 = 1;
    }
    _7316 = NOVALUE;
    _7318 = NewDouble((double)_7317 * DBL_PTR(_6903)->dbl);
    _7317 = NOVALUE;
    _7319 = unary_op(FLOOR, _7318);
    DeRefDS(_7318);
    _7318 = NOVALUE;
    if (IS_ATOM_INT(_7319)) {
        _size__12928 = _7319 + 1;
    }
    else
    { // coercing _size__12928 to an integer 1
        _size__12928 = 1+(long)(DBL_PTR(_7319)->dbl);
        if( !IS_ATOM_INT(_size__12928) ){
            _size__12928 = (object)DBL_PTR(_size__12928)->dbl;
        }
    }
    DeRef(_7319);
    _7319 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__12928 = _requested_bucket_size_p_12927;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__12928 == 0xC0000000)
    _7321 = (int)NewDouble((double)-0xC0000000);
    else
    _7321 = - _size__12928;
    _size__12928 = _34next_prime(_size__12928, _7321, 2);
    _7321 = NOVALUE;
    if (!IS_ATOM_INT(_size__12928)) {
        _1 = (long)(DBL_PTR(_size__12928)->dbl);
        DeRefDS(_size__12928);
        _size__12928 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__12928 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__12930);
    DeRef(_old_val_buckets__12931);
    DeRef(_new_key_buckets__12932);
    DeRef(_new_val_buckets__12933);
    DeRef(_key__12934);
    DeRef(_value__12935);
    DeRef(_new_keys_12937);
    _7316 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7324 = (int)*(((s1_ptr)_2)->base + _the_map_p_12926);
    DeRef(_old_key_buckets__12930);
    _2 = (int)SEQ_PTR(_7324);
    _old_key_buckets__12930 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__12930);
    _7324 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7326 = (int)*(((s1_ptr)_2)->base + _the_map_p_12926);
    DeRef(_old_val_buckets__12931);
    _2 = (int)SEQ_PTR(_7326);
    _old_val_buckets__12931 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__12931);
    _7326 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _7328 = _33threshold_size_12820 + 1;
    _7329 = Repeat(1, _7328);
    _7328 = NOVALUE;
    DeRef(_new_key_buckets__12932);
    _new_key_buckets__12932 = Repeat(_7329, _size__12928);
    DeRefDS(_7329);
    _7329 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _7331 = Repeat(0, _33threshold_size_12820);
    DeRef(_new_val_buckets__12933);
    _new_val_buckets__12933 = Repeat(_7331, _size__12928);
    DeRefDS(_7331);
    _7331 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7333 = (int)*(((s1_ptr)_2)->base + _the_map_p_12926);
    _2 = (int)SEQ_PTR(_7333);
    _elem_count_12939 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_12939)){
        _elem_count_12939 = (long)DBL_PTR(_elem_count_12939)->dbl;
    }
    _7333 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_12938 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12926);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__12930)){
            _7335 = SEQ_PTR(_old_key_buckets__12930)->length;
    }
    else {
        _7335 = 1;
    }
    {
        int _index_12969;
        _index_12969 = 1;
L5: 
        if (_index_12969 > _7335){
            goto L6; // [183] 371
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__12930);
        _7336 = (int)*(((s1_ptr)_2)->base + _index_12969);
        if (IS_SEQUENCE(_7336)){
                _7337 = SEQ_PTR(_7336)->length;
        }
        else {
            _7337 = 1;
        }
        _7336 = NOVALUE;
        {
            int _entry_idx_12972;
            _entry_idx_12972 = 1;
L7: 
            if (_entry_idx_12972 > _7337){
                goto L8; // [199] 364
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__12930);
            _7338 = (int)*(((s1_ptr)_2)->base + _index_12969);
            DeRef(_key__12934);
            _2 = (int)SEQ_PTR(_7338);
            _key__12934 = (int)*(((s1_ptr)_2)->base + _entry_idx_12972);
            Ref(_key__12934);
            _7338 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__12931);
            _7340 = (int)*(((s1_ptr)_2)->base + _index_12969);
            DeRef(_value__12935);
            _2 = (int)SEQ_PTR(_7340);
            _value__12935 = (int)*(((s1_ptr)_2)->base + _entry_idx_12972);
            Ref(_value__12935);
            _7340 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_12980);
            _ret__inlined_calc_hash_at_227_12980 = calc_hash(_key__12934, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_12980)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_12980)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_12980);
                _ret__inlined_calc_hash_at_227_12980 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_12982 = (_ret__inlined_calc_hash_at_227_12980 % _size__12928);
            _index_2__12929 = _calc_hash_1__tmp_at227_12982 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_12980);
            _ret__inlined_calc_hash_at_227_12980 = NOVALUE;

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_12937);
            _2 = (int)SEQ_PTR(_new_key_buckets__12932);
            _new_keys_12937 = (int)*(((s1_ptr)_2)->base + _index_2__12929);
            RefDS(_new_keys_12937);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_12937)){
                    _7343 = SEQ_PTR(_new_keys_12937)->length;
            }
            else {
                _7343 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_12937);
            _pos_12936 = (int)*(((s1_ptr)_2)->base + _7343);
            if (!IS_ATOM_INT(_pos_12936))
            _pos_12936 = (long)DBL_PTR(_pos_12936)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_12937)){
                    _7345 = SEQ_PTR(_new_keys_12937)->length;
            }
            else {
                _7345 = 1;
            }
            if (_7345 != _pos_12936)
            goto L9; // [271] 308

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _7347 = Repeat(_pos_12936, _33threshold_size_12820);
            Concat((object_ptr)&_new_keys_12937, _new_keys_12937, _7347);
            DeRefDS(_7347);
            _7347 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _7349 = Repeat(0, _33threshold_size_12820);
            _2 = (int)SEQ_PTR(_new_val_buckets__12933);
            _7350 = (int)*(((s1_ptr)_2)->base + _index_2__12929);
            if (IS_SEQUENCE(_7350) && IS_ATOM(_7349)) {
            }
            else if (IS_ATOM(_7350) && IS_SEQUENCE(_7349)) {
                Ref(_7350);
                Prepend(&_7351, _7349, _7350);
            }
            else {
                Concat((object_ptr)&_7351, _7350, _7349);
                _7350 = NOVALUE;
            }
            _7350 = NOVALUE;
            DeRefDS(_7349);
            _7349 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__12933);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__12933 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__12929);
            _1 = *(int *)_2;
            *(int *)_2 = _7351;
            if( _1 != _7351 ){
                DeRef(_1);
            }
            _7351 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__12934);
            _2 = (int)SEQ_PTR(_new_keys_12937);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_12937 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_12936);
            _1 = *(int *)_2;
            *(int *)_2 = _key__12934;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__12933);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__12933 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__12929 + ((s1_ptr)_2)->base);
            Ref(_value__12935);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_12936);
            _1 = *(int *)_2;
            *(int *)_2 = _value__12935;
            DeRef(_1);
            _7352 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_12937)){
                    _7354 = SEQ_PTR(_new_keys_12937)->length;
            }
            else {
                _7354 = 1;
            }
            _7355 = _pos_12936 + 1;
            if (_7355 > MAXINT){
                _7355 = NewDouble((double)_7355);
            }
            _2 = (int)SEQ_PTR(_new_keys_12937);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_12937 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _7354);
            _1 = *(int *)_2;
            *(int *)_2 = _7355;
            if( _1 != _7355 ){
                DeRef(_1);
            }
            _7355 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_12937);
            _2 = (int)SEQ_PTR(_new_key_buckets__12932);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__12932 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__12929);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_12937;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_12936 != 1)
            goto LA; // [346] 357

            /** 				in_use += 1*/
            _in_use_12938 = _in_use_12938 + 1;
LA: 

            /** 		end for*/
            _entry_idx_12972 = _entry_idx_12972 + 1;
            goto L7; // [359] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_12969 = _index_12969 + 1;
        goto L5; // [366] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__12932)){
            _7358 = SEQ_PTR(_new_key_buckets__12932)->length;
    }
    else {
        _7358 = 1;
    }
    {
        int _index_13002;
        _index_13002 = 1;
LB: 
        if (_index_13002 > _7358){
            goto LC; // [376] 449
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__12932);
        _7359 = (int)*(((s1_ptr)_2)->base + _index_13002);
        if (IS_SEQUENCE(_7359)){
                _7360 = SEQ_PTR(_7359)->length;
        }
        else {
            _7360 = 1;
        }
        _2 = (int)SEQ_PTR(_7359);
        _pos_12936 = (int)*(((s1_ptr)_2)->base + _7360);
        if (!IS_ATOM_INT(_pos_12936)){
            _pos_12936 = (long)DBL_PTR(_pos_12936)->dbl;
        }
        _7359 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__12932);
        _7362 = (int)*(((s1_ptr)_2)->base + _index_13002);
        _2 = (int)SEQ_PTR(_new_key_buckets__12932);
        _7363 = (int)*(((s1_ptr)_2)->base + _index_13002);
        if (IS_SEQUENCE(_7363)){
                _7364 = SEQ_PTR(_7363)->length;
        }
        else {
            _7364 = 1;
        }
        _7363 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7362);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_12936)) ? _pos_12936 : (long)(DBL_PTR(_pos_12936)->dbl);
            int stop = (IS_ATOM_INT(_7364)) ? _7364 : (long)(DBL_PTR(_7364)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7362);
                DeRef(_7365);
                _7365 = _7362;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7362), start, &_7365 );
                }
                else Tail(SEQ_PTR(_7362), stop+1, &_7365);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7362), start, &_7365);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7365);
                _7365 = _1;
            }
        }
        _7362 = NOVALUE;
        _7364 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__12932);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__12932 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13002);
        _1 = *(int *)_2;
        *(int *)_2 = _7365;
        if( _1 != _7365 ){
            DeRefDS(_1);
        }
        _7365 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__12933);
        _7366 = (int)*(((s1_ptr)_2)->base + _index_13002);
        _2 = (int)SEQ_PTR(_new_val_buckets__12933);
        _7367 = (int)*(((s1_ptr)_2)->base + _index_13002);
        if (IS_SEQUENCE(_7367)){
                _7368 = SEQ_PTR(_7367)->length;
        }
        else {
            _7368 = 1;
        }
        _7367 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7366);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_12936)) ? _pos_12936 : (long)(DBL_PTR(_pos_12936)->dbl);
            int stop = (IS_ATOM_INT(_7368)) ? _7368 : (long)(DBL_PTR(_7368)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7366);
                DeRef(_7369);
                _7369 = _7366;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7366), start, &_7369 );
                }
                else Tail(SEQ_PTR(_7366), stop+1, &_7369);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7366), start, &_7369);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7369);
                _7369 = _1;
            }
        }
        _7366 = NOVALUE;
        _7368 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__12933);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__12933 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13002);
        _1 = *(int *)_2;
        *(int *)_2 = _7369;
        if( _1 != _7369 ){
            DeRef(_1);
        }
        _7369 = NOVALUE;

        /** 	end for*/
        _index_13002 = _index_13002 + 1;
        goto LB; // [444] 383
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12806);
    *((int *)(_2+4)) = _33type_is_map_12806;
    *((int *)(_2+8)) = _elem_count_12939;
    *((int *)(_2+12)) = _in_use_12938;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__12932);
    *((int *)(_2+20)) = _new_key_buckets__12932;
    RefDS(_new_val_buckets__12933);
    *((int *)(_2+24)) = _new_val_buckets__12933;
    _7370 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12926);
    _1 = *(int *)_2;
    *(int *)_2 = _7370;
    if( _1 != _7370 ){
        DeRef(_1);
    }
    _7370 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__12930);
    DeRef(_old_val_buckets__12931);
    DeRefDS(_new_key_buckets__12932);
    DeRefDS(_new_val_buckets__12933);
    DeRef(_key__12934);
    DeRef(_value__12935);
    DeRef(_new_keys_12937);
    _7316 = NOVALUE;
    _7336 = NOVALUE;
    _7363 = NOVALUE;
    _7367 = NOVALUE;
    return;
    ;
}
void rehash() __attribute__ ((alias ("_33rehash")));


int _33new(int _initial_size_p_13018)
{
    int _buckets__13020 = NOVALUE;
    int _new_map__13021 = NOVALUE;
    int _temp_map__13022 = NOVALUE;
    int _7383 = NOVALUE;
    int _7382 = NOVALUE;
    int _7381 = NOVALUE;
    int _7379 = NOVALUE;
    int _7378 = NOVALUE;
    int _7375 = NOVALUE;
    int _7374 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_initial_size_p_13018)) {
        _1 = (long)(DBL_PTR(_initial_size_p_13018)->dbl);
        DeRefDS(_initial_size_p_13018);
        _initial_size_p_13018 = _1;
    }

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_13018 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_13018 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_13018 <= _33threshold_size_12820)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _7374 = _initial_size_p_13018 + _33threshold_size_12820;
    if ((long)((unsigned long)_7374 + (unsigned long)HIGH_BITS) >= 0) 
    _7374 = NewDouble((double)_7374);
    if (IS_ATOM_INT(_7374)) {
        _7375 = _7374 - 1;
        if ((long)((unsigned long)_7375 +(unsigned long) HIGH_BITS) >= 0){
            _7375 = NewDouble((double)_7375);
        }
    }
    else {
        _7375 = NewDouble(DBL_PTR(_7374)->dbl - (double)1);
    }
    DeRef(_7374);
    _7374 = NOVALUE;
    if (IS_ATOM_INT(_7375)) {
        if (_33threshold_size_12820 > 0 && _7375 >= 0) {
            _buckets__13020 = _7375 / _33threshold_size_12820;
        }
        else {
            temp_dbl = floor((double)_7375 / (double)_33threshold_size_12820);
            _buckets__13020 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7375, _33threshold_size_12820);
        _buckets__13020 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7375);
    _7375 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__13020)) {
        _1 = (long)(DBL_PTR(_buckets__13020)->dbl);
        DeRefDS(_buckets__13020);
        _buckets__13020 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__13020 = _34next_prime(_buckets__13020, -1, 1);
    if (!IS_ATOM_INT(_buckets__13020)) {
        _1 = (long)(DBL_PTR(_buckets__13020)->dbl);
        DeRefDS(_buckets__13020);
        _buckets__13020 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _7378 = Repeat(_5, _buckets__13020);
    _7379 = Repeat(_5, _buckets__13020);
    _0 = _new_map__13021;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12806);
    *((int *)(_2+4)) = _33type_is_map_12806;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _7378;
    *((int *)(_2+24)) = _7379;
    _new_map__13021 = MAKE_SEQ(_1);
    DeRef(_0);
    _7379 = NOVALUE;
    _7378 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _7381 = Repeat(_33init_small_map_key_12821, _initial_size_p_13018);
    _7382 = Repeat(0, _initial_size_p_13018);
    _7383 = Repeat(0, _initial_size_p_13018);
    _0 = _new_map__13021;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12806);
    *((int *)(_2+4)) = _33type_is_map_12806;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7381;
    *((int *)(_2+24)) = _7382;
    *((int *)(_2+28)) = _7383;
    _new_map__13021 = MAKE_SEQ(_1);
    DeRef(_0);
    _7383 = NOVALUE;
    _7382 = NOVALUE;
    _7381 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__13022;
    _temp_map__13022 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__13021);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__13022))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__13022)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__13022);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__13021;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__13021);
    return _temp_map__13022;
    ;
}


int _33new_extra(int _the_map_p_13042, int _initial_size_p_13043)
{
    int _7387 = NOVALUE;
    int _7386 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_initial_size_p_13043)) {
        _1 = (long)(DBL_PTR(_initial_size_p_13043)->dbl);
        DeRefDS(_initial_size_p_13043);
        _initial_size_p_13043 = _1;
    }

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_13042);
    _7386 = _33map(_the_map_p_13042);
    if (_7386 == 0) {
        DeRef(_7386);
        _7386 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_7386) && DBL_PTR(_7386)->dbl == 0.0){
            DeRef(_7386);
            _7386 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_7386);
        _7386 = NOVALUE;
    }
    DeRef(_7386);
    _7386 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_13042;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _7387 = _33new(_initial_size_p_13043);
    DeRef(_the_map_p_13042);
    return _7387;
L2: 
    ;
}
int new_extra() __attribute__ ((alias ("_33new_extra")));


int _33compare(int _map_1_p_13050, int _map_2_p_13051, int _scope_p_13052)
{
    int _data_set_1__13053 = NOVALUE;
    int _data_set_2__13054 = NOVALUE;
    int _7399 = NOVALUE;
    int _7393 = NOVALUE;
    int _7391 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_scope_p_13052)) {
        _1 = (long)(DBL_PTR(_scope_p_13052)->dbl);
        DeRefDS(_scope_p_13052);
        _scope_p_13052 = _1;
    }

    /** 	if map_1_p = map_2_p then*/
    if (binary_op_a(NOTEQ, _map_1_p_13050, _map_2_p_13051)){
        goto L1; // [5] 16
    }

    /** 		return 0*/
    DeRef(_map_1_p_13050);
    DeRef(_map_2_p_13051);
    DeRef(_data_set_1__13053);
    DeRef(_data_set_2__13054);
    return 0;
L1: 

    /** 	switch scope_p do*/
    _0 = _scope_p_13052;
    switch ( _0 ){ 

        /** 		case 'v', 'V' then*/
        case 118:
        case 86:

        /** 			data_set_1_ = stdsort:sort(values(map_1_p))*/
        Ref(_map_1_p_13050);
        _7391 = _33values(_map_1_p_13050, 0, 0);
        _0 = _data_set_1__13053;
        _data_set_1__13053 = _24sort(_7391, 1);
        DeRef(_0);
        _7391 = NOVALUE;

        /** 			data_set_2_ = stdsort:sort(values(map_2_p))*/
        Ref(_map_2_p_13051);
        _7393 = _33values(_map_2_p_13051, 0, 0);
        _0 = _data_set_2__13054;
        _data_set_2__13054 = _24sort(_7393, 1);
        DeRef(_0);
        _7393 = NOVALUE;
        goto L2; // [59] 110

        /** 		case 'k', 'K' then*/
        case 107:
        case 75:

        /** 			data_set_1_ = keys(map_1_p, 1)*/
        Ref(_map_1_p_13050);
        _0 = _data_set_1__13053;
        _data_set_1__13053 = _33keys(_map_1_p_13050, 1);
        DeRef(_0);

        /** 			data_set_2_ = keys(map_2_p, 1)*/
        Ref(_map_2_p_13051);
        _0 = _data_set_2__13054;
        _data_set_2__13054 = _33keys(_map_2_p_13051, 1);
        DeRef(_0);
        goto L2; // [85] 110

        /** 		case else*/
        default:

        /** 			data_set_1_ = pairs(map_1_p, 1)*/
        Ref(_map_1_p_13050);
        _0 = _data_set_1__13053;
        _data_set_1__13053 = _33pairs(_map_1_p_13050, 1);
        DeRef(_0);

        /** 			data_set_2_ = pairs(map_2_p, 1)*/
        Ref(_map_2_p_13051);
        _0 = _data_set_2__13054;
        _data_set_2__13054 = _33pairs(_map_2_p_13051, 1);
        DeRef(_0);
    ;}L2: 

    /** 	if equal(data_set_1_, data_set_2_) then*/
    if (_data_set_1__13053 == _data_set_2__13054)
    _7399 = 1;
    else if (IS_ATOM_INT(_data_set_1__13053) && IS_ATOM_INT(_data_set_2__13054))
    _7399 = 0;
    else
    _7399 = (compare(_data_set_1__13053, _data_set_2__13054) == 0);
    if (_7399 == 0)
    {
        _7399 = NOVALUE;
        goto L3; // [120] 130
    }
    else{
        _7399 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_map_1_p_13050);
    DeRef(_map_2_p_13051);
    DeRefDS(_data_set_1__13053);
    DeRefDS(_data_set_2__13054);
    return 1;
L3: 

    /** 	return -1*/
    DeRef(_map_1_p_13050);
    DeRef(_map_2_p_13051);
    DeRef(_data_set_1__13053);
    DeRef(_data_set_2__13054);
    return -1;
    ;
}


int _33has(int _the_map_p_13080, int _the_key_p_13081)
{
    int _index__13082 = NOVALUE;
    int _pos__13083 = NOVALUE;
    int _from__13084 = NOVALUE;
    int _calc_hash_1__tmp_at36_13096 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_13095 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_13094 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_13093 = NOVALUE;
    int _7423 = NOVALUE;
    int _7421 = NOVALUE;
    int _7420 = NOVALUE;
    int _7417 = NOVALUE;
    int _7416 = NOVALUE;
    int _7415 = NOVALUE;
    int _7413 = NOVALUE;
    int _7412 = NOVALUE;
    int _7410 = NOVALUE;
    int _7408 = NOVALUE;
    int _7407 = NOVALUE;
    int _7406 = NOVALUE;
    int _7405 = NOVALUE;
    int _7404 = NOVALUE;
    int _7403 = NOVALUE;
    int _7401 = NOVALUE;
    int _7400 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13080)) {
        _1 = (long)(DBL_PTR(_the_map_p_13080)->dbl);
        DeRefDS(_the_map_p_13080);
        _the_map_p_13080 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7400 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7400);
    _7401 = (int)*(((s1_ptr)_2)->base + 4);
    _7400 = NOVALUE;
    if (binary_op_a(NOTEQ, _7401, 76)){
        _7401 = NOVALUE;
        goto L1; // [15] 84
    }
    _7401 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7403 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7403);
    _7404 = (int)*(((s1_ptr)_2)->base + 5);
    _7403 = NOVALUE;
    if (IS_SEQUENCE(_7404)){
            _7405 = SEQ_PTR(_7404)->length;
    }
    else {
        _7405 = 1;
    }
    _7404 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_13093 = _7405;
    _7405 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_13094);
    _ret__inlined_calc_hash_at_36_13094 = calc_hash(_the_key_p_13081, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_13094)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_13094)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_13094);
        _ret__inlined_calc_hash_at_36_13094 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_13096 = (_ret__inlined_calc_hash_at_36_13094 % _max_hash_p_inlined_calc_hash_at_33_13093);
    _index__13082 = _calc_hash_1__tmp_at36_13096 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_13094);
    _ret__inlined_calc_hash_at_36_13094 = NOVALUE;

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7406 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7406);
    _7407 = (int)*(((s1_ptr)_2)->base + 5);
    _7406 = NOVALUE;
    _2 = (int)SEQ_PTR(_7407);
    _7408 = (int)*(((s1_ptr)_2)->base + _index__13082);
    _7407 = NOVALUE;
    _pos__13083 = find_from(_the_key_p_13081, _7408, 1);
    _7408 = NOVALUE;
    goto L2; // [81] 199
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13081 == _33init_small_map_key_12821)
    _7410 = 1;
    else if (IS_ATOM_INT(_the_key_p_13081) && IS_ATOM_INT(_33init_small_map_key_12821))
    _7410 = 0;
    else
    _7410 = (compare(_the_key_p_13081, _33init_small_map_key_12821) == 0);
    if (_7410 == 0)
    {
        _7410 = NOVALUE;
        goto L3; // [90] 180
    }
    else{
        _7410 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13084 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__13084 <= 0)
    goto L5; // [103] 198

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7412 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7412);
    _7413 = (int)*(((s1_ptr)_2)->base + 5);
    _7412 = NOVALUE;
    _pos__13083 = find_from(_the_key_p_13081, _7413, _from__13084);
    _7413 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13083 == 0)
    {
        goto L6; // [126] 159
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7415 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7415);
    _7416 = (int)*(((s1_ptr)_2)->base + 7);
    _7415 = NOVALUE;
    _2 = (int)SEQ_PTR(_7416);
    _7417 = (int)*(((s1_ptr)_2)->base + _pos__13083);
    _7416 = NOVALUE;
    if (binary_op_a(NOTEQ, _7417, 1)){
        _7417 = NOVALUE;
        goto L7; // [145] 166
    }
    _7417 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_13081);
    _7404 = NOVALUE;
    return 1;
    goto L7; // [156] 166
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_13081);
    _7404 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__13084 = _pos__13083 + 1;

    /** 			end while*/
    goto L4; // [174] 103
    goto L5; // [177] 198
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _7420 = (int)*(((s1_ptr)_2)->base + _the_map_p_13080);
    _2 = (int)SEQ_PTR(_7420);
    _7421 = (int)*(((s1_ptr)_2)->base + 5);
    _7420 = NOVALUE;
    _pos__13083 = find_from(_the_key_p_13081, _7421, 1);
    _7421 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _7423 = (_pos__13083 != 0);
    DeRef(_the_key_p_13081);
    _7404 = NOVALUE;
    return _7423;
    ;
}
int has() __attribute__ ((alias ("_33has")));


int _33get(int _the_map_p_13124, int _the_key_p_13125, int _default_value_p_13126)
{
    int _bucket__13127 = NOVALUE;
    int _pos__13128 = NOVALUE;
    int _from__13129 = NOVALUE;
    int _themap_13130 = NOVALUE;
    int _thekeys_13135 = NOVALUE;
    int _calc_hash_1__tmp_at40_13142 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13141 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13140 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13139 = NOVALUE;
    int _7448 = NOVALUE;
    int _7447 = NOVALUE;
    int _7445 = NOVALUE;
    int _7443 = NOVALUE;
    int _7442 = NOVALUE;
    int _7440 = NOVALUE;
    int _7439 = NOVALUE;
    int _7437 = NOVALUE;
    int _7435 = NOVALUE;
    int _7434 = NOVALUE;
    int _7433 = NOVALUE;
    int _7432 = NOVALUE;
    int _7429 = NOVALUE;
    int _7428 = NOVALUE;
    int _7425 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13124)) {
        _1 = (long)(DBL_PTR(_the_map_p_13124)->dbl);
        DeRefDS(_the_map_p_13124);
        _the_map_p_13124 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_13130);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _themap_13130 = (int)*(((s1_ptr)_2)->base + _the_map_p_13124);
    Ref(_themap_13130);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7425 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7425, 76)){
        _7425 = NOVALUE;
        goto L1; // [19] 111
    }
    _7425 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_13135);
    _2 = (int)SEQ_PTR(_themap_13130);
    _thekeys_13135 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_13135);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_13135)){
            _7428 = SEQ_PTR(_thekeys_13135)->length;
    }
    else {
        _7428 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_13139 = _7428;
    _7428 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13140);
    _ret__inlined_calc_hash_at_40_13140 = calc_hash(_the_key_p_13125, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13140)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13140)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13140);
        _ret__inlined_calc_hash_at_40_13140 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13142 = (_ret__inlined_calc_hash_at_40_13140 % _max_hash_p_inlined_calc_hash_at_37_13139);
    _bucket__13127 = _calc_hash_1__tmp_at40_13142 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13140);
    _ret__inlined_calc_hash_at_40_13140 = NOVALUE;

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_13135);
    _7429 = (int)*(((s1_ptr)_2)->base + _bucket__13127);
    _pos__13128 = find_from(_the_key_p_13125, _7429, 1);
    _7429 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__13128 <= 0)
    goto L2; // [77] 100

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7432 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7432);
    _7433 = (int)*(((s1_ptr)_2)->base + _bucket__13127);
    _7432 = NOVALUE;
    _2 = (int)SEQ_PTR(_7433);
    _7434 = (int)*(((s1_ptr)_2)->base + _pos__13128);
    _7433 = NOVALUE;
    Ref(_7434);
    DeRefDS(_thekeys_13135);
    DeRef(_the_key_p_13125);
    DeRef(_default_value_p_13126);
    DeRefDS(_themap_13130);
    return _7434;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_13135);
    DeRef(_the_key_p_13125);
    DeRef(_themap_13130);
    _7434 = NOVALUE;
    return _default_value_p_13126;
    goto L3; // [108] 236
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13125 == _33init_small_map_key_12821)
    _7435 = 1;
    else if (IS_ATOM_INT(_the_key_p_13125) && IS_ATOM_INT(_33init_small_map_key_12821))
    _7435 = 0;
    else
    _7435 = (compare(_the_key_p_13125, _33init_small_map_key_12821) == 0);
    if (_7435 == 0)
    {
        _7435 = NOVALUE;
        goto L4; // [117] 203
    }
    else{
        _7435 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13129 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__13129 <= 0)
    goto L6; // [130] 235

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7437 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13128 = find_from(_the_key_p_13125, _7437, _from__13129);
    _7437 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13128 == 0)
    {
        goto L7; // [147] 182
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7439 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7439);
    _7440 = (int)*(((s1_ptr)_2)->base + _pos__13128);
    _7439 = NOVALUE;
    if (binary_op_a(NOTEQ, _7440, 1)){
        _7440 = NOVALUE;
        goto L8; // [160] 189
    }
    _7440 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7442 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7442);
    _7443 = (int)*(((s1_ptr)_2)->base + _pos__13128);
    _7442 = NOVALUE;
    Ref(_7443);
    DeRef(_the_key_p_13125);
    DeRef(_default_value_p_13126);
    DeRefDS(_themap_13130);
    _7434 = NOVALUE;
    return _7443;
    goto L8; // [179] 189
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_13125);
    DeRef(_themap_13130);
    _7434 = NOVALUE;
    _7443 = NOVALUE;
    return _default_value_p_13126;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__13129 = _pos__13128 + 1;

    /** 			end while*/
    goto L5; // [197] 130
    goto L6; // [200] 235
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7445 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13128 = find_from(_the_key_p_13125, _7445, 1);
    _7445 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__13128 == 0)
    {
        goto L9; // [216] 234
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13130);
    _7447 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7447);
    _7448 = (int)*(((s1_ptr)_2)->base + _pos__13128);
    _7447 = NOVALUE;
    Ref(_7448);
    DeRef(_the_key_p_13125);
    DeRef(_default_value_p_13126);
    DeRefDS(_themap_13130);
    _7434 = NOVALUE;
    _7443 = NOVALUE;
    return _7448;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_13125);
    DeRef(_themap_13130);
    _7434 = NOVALUE;
    _7443 = NOVALUE;
    _7448 = NOVALUE;
    return _default_value_p_13126;
    ;
}


int _33nested_get(int _the_map_p_13174, int _the_keys_p_13175, int _default_value_p_13176)
{
    int _val__13181 = NOVALUE;
    int _7458 = NOVALUE;
    int _7457 = NOVALUE;
    int _7455 = NOVALUE;
    int _7453 = NOVALUE;
    int _7451 = NOVALUE;
    int _7450 = NOVALUE;
    int _7449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( the_keys_p ) - 1 do*/
    if (IS_SEQUENCE(_the_keys_p_13175)){
            _7449 = SEQ_PTR(_the_keys_p_13175)->length;
    }
    else {
        _7449 = 1;
    }
    _7450 = _7449 - 1;
    _7449 = NOVALUE;
    {
        int _i_13178;
        _i_13178 = 1;
L1: 
        if (_i_13178 > _7450){
            goto L2; // [12] 74
        }

        /** 		object val_ = get( the_map_p, the_keys_p[1], 0 )*/
        _2 = (int)SEQ_PTR(_the_keys_p_13175);
        _7451 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_the_map_p_13174);
        Ref(_7451);
        _0 = _val__13181;
        _val__13181 = _33get(_the_map_p_13174, _7451, 0);
        DeRef(_0);
        _7451 = NOVALUE;

        /** 		if not map( val_ ) then*/
        Ref(_val__13181);
        _7453 = _33map(_val__13181);
        if (IS_ATOM_INT(_7453)) {
            if (_7453 != 0){
                DeRef(_7453);
                _7453 = NOVALUE;
                goto L3; // [37] 49
            }
        }
        else {
            if (DBL_PTR(_7453)->dbl != 0.0){
                DeRef(_7453);
                _7453 = NOVALUE;
                goto L3; // [37] 49
            }
        }
        DeRef(_7453);
        _7453 = NOVALUE;

        /** 			return default_value_p*/
        DeRef(_val__13181);
        DeRef(_the_map_p_13174);
        DeRefDS(_the_keys_p_13175);
        DeRef(_7450);
        _7450 = NOVALUE;
        return _default_value_p_13176;
        goto L4; // [46] 65
L3: 

        /** 			the_map_p = val_*/
        Ref(_val__13181);
        DeRef(_the_map_p_13174);
        _the_map_p_13174 = _val__13181;

        /** 			the_keys_p = the_keys_p[2..$]*/
        if (IS_SEQUENCE(_the_keys_p_13175)){
                _7455 = SEQ_PTR(_the_keys_p_13175)->length;
        }
        else {
            _7455 = 1;
        }
        rhs_slice_target = (object_ptr)&_the_keys_p_13175;
        RHS_Slice(_the_keys_p_13175, 2, _7455);
L4: 
        DeRef(_val__13181);
        _val__13181 = NOVALUE;

        /** 	end for*/
        _i_13178 = _i_13178 + 1;
        goto L1; // [69] 19
L2: 
        ;
    }

    /** 	return get( the_map_p, the_keys_p[1], default_value_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13175);
    _7457 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13174);
    Ref(_7457);
    Ref(_default_value_p_13176);
    _7458 = _33get(_the_map_p_13174, _7457, _default_value_p_13176);
    _7457 = NOVALUE;
    DeRef(_the_map_p_13174);
    DeRefDS(_the_keys_p_13175);
    DeRef(_default_value_p_13176);
    DeRef(_7450);
    _7450 = NOVALUE;
    return _7458;
    ;
}
int nested_get() __attribute__ ((alias ("_33nested_get")));


void _33put(int _the_map_p_13194, int _the_key_p_13195, int _the_value_p_13196, int _operation_p_13197, int _trigger_p_13198)
{
    int _index__13199 = NOVALUE;
    int _bucket__13200 = NOVALUE;
    int _average_length__13201 = NOVALUE;
    int _from__13202 = NOVALUE;
    int _map_data_13203 = NOVALUE;
    int _calc_hash_1__tmp_at46_13214 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_13213 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_13212 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_13211 = NOVALUE;
    int _data_13246 = NOVALUE;
    int _msg_inlined_crash_at_332_13262 = NOVALUE;
    int _msg_inlined_crash_at_377_13268 = NOVALUE;
    int _tmp_seqk_13282 = NOVALUE;
    int _tmp_seqv_13290 = NOVALUE;
    int _msg_inlined_crash_at_719_13326 = NOVALUE;
    int _msg_inlined_crash_at_1077_13389 = NOVALUE;
    int _7592 = NOVALUE;
    int _7591 = NOVALUE;
    int _7589 = NOVALUE;
    int _7588 = NOVALUE;
    int _7587 = NOVALUE;
    int _7586 = NOVALUE;
    int _7584 = NOVALUE;
    int _7583 = NOVALUE;
    int _7582 = NOVALUE;
    int _7580 = NOVALUE;
    int _7579 = NOVALUE;
    int _7578 = NOVALUE;
    int _7576 = NOVALUE;
    int _7575 = NOVALUE;
    int _7574 = NOVALUE;
    int _7572 = NOVALUE;
    int _7571 = NOVALUE;
    int _7570 = NOVALUE;
    int _7568 = NOVALUE;
    int _7566 = NOVALUE;
    int _7560 = NOVALUE;
    int _7559 = NOVALUE;
    int _7558 = NOVALUE;
    int _7557 = NOVALUE;
    int _7555 = NOVALUE;
    int _7553 = NOVALUE;
    int _7552 = NOVALUE;
    int _7551 = NOVALUE;
    int _7550 = NOVALUE;
    int _7549 = NOVALUE;
    int _7548 = NOVALUE;
    int _7545 = NOVALUE;
    int _7543 = NOVALUE;
    int _7540 = NOVALUE;
    int _7538 = NOVALUE;
    int _7535 = NOVALUE;
    int _7534 = NOVALUE;
    int _7532 = NOVALUE;
    int _7529 = NOVALUE;
    int _7528 = NOVALUE;
    int _7525 = NOVALUE;
    int _7522 = NOVALUE;
    int _7520 = NOVALUE;
    int _7518 = NOVALUE;
    int _7515 = NOVALUE;
    int _7513 = NOVALUE;
    int _7512 = NOVALUE;
    int _7511 = NOVALUE;
    int _7510 = NOVALUE;
    int _7509 = NOVALUE;
    int _7508 = NOVALUE;
    int _7507 = NOVALUE;
    int _7506 = NOVALUE;
    int _7505 = NOVALUE;
    int _7499 = NOVALUE;
    int _7497 = NOVALUE;
    int _7496 = NOVALUE;
    int _7494 = NOVALUE;
    int _7492 = NOVALUE;
    int _7489 = NOVALUE;
    int _7488 = NOVALUE;
    int _7487 = NOVALUE;
    int _7486 = NOVALUE;
    int _7484 = NOVALUE;
    int _7483 = NOVALUE;
    int _7482 = NOVALUE;
    int _7480 = NOVALUE;
    int _7479 = NOVALUE;
    int _7478 = NOVALUE;
    int _7476 = NOVALUE;
    int _7475 = NOVALUE;
    int _7474 = NOVALUE;
    int _7472 = NOVALUE;
    int _7470 = NOVALUE;
    int _7465 = NOVALUE;
    int _7464 = NOVALUE;
    int _7463 = NOVALUE;
    int _7462 = NOVALUE;
    int _7460 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_13194)) {
        _1 = (long)(DBL_PTR(_the_map_p_13194)->dbl);
        DeRefDS(_the_map_p_13194);
        _the_map_p_13194 = _1;
    }
    if (!IS_ATOM_INT(_operation_p_13197)) {
        _1 = (long)(DBL_PTR(_operation_p_13197)->dbl);
        DeRefDS(_operation_p_13197);
        _operation_p_13197 = _1;
    }
    if (!IS_ATOM_INT(_trigger_p_13198)) {
        _1 = (long)(DBL_PTR(_trigger_p_13198)->dbl);
        DeRefDS(_trigger_p_13198);
        _trigger_p_13198 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _map_data_13203 = (int)*(((s1_ptr)_2)->base + _the_map_p_13194);
    Ref(_map_data_13203);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7460 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7460, 76)){
        _7460 = NOVALUE;
        goto L1; // [31] 616
    }
    _7460 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7462 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7462)){
            _7463 = SEQ_PTR(_7462)->length;
    }
    else {
        _7463 = 1;
    }
    _7462 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_13211 = _7463;
    _7463 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_13212);
    _ret__inlined_calc_hash_at_46_13212 = calc_hash(_the_key_p_13195, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_13212)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_13212)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_13212);
        _ret__inlined_calc_hash_at_46_13212 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_13214 = (_ret__inlined_calc_hash_at_46_13212 % _max_hash_p_inlined_calc_hash_at_43_13211);
    _bucket__13200 = _calc_hash_1__tmp_at46_13214 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_13212);
    _ret__inlined_calc_hash_at_46_13212 = NOVALUE;

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7464 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7464);
    _7465 = (int)*(((s1_ptr)_2)->base + _bucket__13200);
    _7464 = NOVALUE;
    _index__13199 = find_from(_the_key_p_13195, _7465, 1);
    _7465 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__13199 <= 0)
    goto L2; // [87] 366

    /** 			switch operation_p do*/
    _0 = _operation_p_13197;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7470 = NOVALUE;
        Ref(_the_value_p_13196);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13196;
        DeRef(_1);
        _7470 = NOVALUE;
        goto L3; // [118] 352

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7472 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7474 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7472 = NOVALUE;
        if (IS_ATOM_INT(_7474) && IS_ATOM_INT(_the_value_p_13196)) {
            _7475 = _7474 + _the_value_p_13196;
            if ((long)((unsigned long)_7475 + (unsigned long)HIGH_BITS) >= 0) 
            _7475 = NewDouble((double)_7475);
        }
        else {
            _7475 = binary_op(PLUS, _7474, _the_value_p_13196);
        }
        _7474 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7475;
        if( _1 != _7475 ){
            DeRef(_1);
        }
        _7475 = NOVALUE;
        _7472 = NOVALUE;
        goto L3; // [148] 352

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7476 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7478 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7476 = NOVALUE;
        if (IS_ATOM_INT(_7478) && IS_ATOM_INT(_the_value_p_13196)) {
            _7479 = _7478 - _the_value_p_13196;
            if ((long)((unsigned long)_7479 +(unsigned long) HIGH_BITS) >= 0){
                _7479 = NewDouble((double)_7479);
            }
        }
        else {
            _7479 = binary_op(MINUS, _7478, _the_value_p_13196);
        }
        _7478 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7479;
        if( _1 != _7479 ){
            DeRef(_1);
        }
        _7479 = NOVALUE;
        _7476 = NOVALUE;
        goto L3; // [178] 352

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7480 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7482 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7480 = NOVALUE;
        if (IS_ATOM_INT(_7482) && IS_ATOM_INT(_the_value_p_13196)) {
            if (_7482 == (short)_7482 && _the_value_p_13196 <= INT15 && _the_value_p_13196 >= -INT15)
            _7483 = _7482 * _the_value_p_13196;
            else
            _7483 = NewDouble(_7482 * (double)_the_value_p_13196);
        }
        else {
            _7483 = binary_op(MULTIPLY, _7482, _the_value_p_13196);
        }
        _7482 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7483;
        if( _1 != _7483 ){
            DeRef(_1);
        }
        _7483 = NOVALUE;
        _7480 = NOVALUE;
        goto L3; // [208] 352

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7484 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7486 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7484 = NOVALUE;
        if (IS_ATOM_INT(_7486) && IS_ATOM_INT(_the_value_p_13196)) {
            _7487 = (_7486 % _the_value_p_13196) ? NewDouble((double)_7486 / _the_value_p_13196) : (_7486 / _the_value_p_13196);
        }
        else {
            _7487 = binary_op(DIVIDE, _7486, _the_value_p_13196);
        }
        _7486 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7487;
        if( _1 != _7487 ){
            DeRef(_1);
        }
        _7487 = NOVALUE;
        _7484 = NOVALUE;
        goto L3; // [238] 352

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        _7488 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7488);
        _7489 = (int)*(((s1_ptr)_2)->base + _bucket__13200);
        _7488 = NOVALUE;
        DeRef(_data_13246);
        _2 = (int)SEQ_PTR(_7489);
        _data_13246 = (int)*(((s1_ptr)_2)->base + _index__13199);
        Ref(_data_13246);
        _7489 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_13196);
        Append(&_data_13246, _data_13246, _the_value_p_13196);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7492 = NOVALUE;
        RefDS(_data_13246);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _data_13246;
        DeRef(_1);
        _7492 = NOVALUE;
        DeRefDS(_data_13246);
        _data_13246 = NOVALUE;
        goto L3; // [284] 352

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13200 + ((s1_ptr)_2)->base);
        _7494 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7496 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7494 = NOVALUE;
        if (IS_SEQUENCE(_7496) && IS_ATOM(_the_value_p_13196)) {
            Ref(_the_value_p_13196);
            Append(&_7497, _7496, _the_value_p_13196);
        }
        else if (IS_ATOM(_7496) && IS_SEQUENCE(_the_value_p_13196)) {
            Ref(_7496);
            Prepend(&_7497, _the_value_p_13196, _7496);
        }
        else {
            Concat((object_ptr)&_7497, _7496, _the_value_p_13196);
            _7496 = NOVALUE;
        }
        _7496 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7497;
        if( _1 != _7497 ){
            DeRef(_1);
        }
        _7497 = NOVALUE;
        _7494 = NOVALUE;
        goto L3; // [314] 352

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_13197 = _operation_p_13197;
        goto L3; // [325] 352

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_332_13262);
        _msg_inlined_crash_at_332_13262 = EPrintf(-9999999, _7498, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_332_13262);

        /** end procedure*/
        goto L4; // [346] 349
L4: 
        DeRefi(_msg_inlined_crash_at_332_13262);
        _msg_inlined_crash_at_332_13262 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13203;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13282);
    DeRef(_tmp_seqv_13290);
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRefDS(_map_data_13203);
    _7462 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7499 = find_from(_operation_p_13197, _33INIT_OPERATIONS_12816, 1);
    if (_7499 != 0)
    goto L5; // [373] 397
    _7499 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_377_13268);
    _msg_inlined_crash_at_377_13268 = EPrintf(-9999999, _7501, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_377_13268);

    /** end procedure*/
    goto L6; // [391] 394
L6: 
    DeRefi(_msg_inlined_crash_at_377_13268);
    _msg_inlined_crash_at_377_13268 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_13197 != 8)
    goto L7; // [399] 417

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13203;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13282);
    DeRef(_tmp_seqv_13290);
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRefDS(_map_data_13203);
    _7462 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_13197 != 6)
    goto L8; // [419] 430

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_13196;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13196);
    *((int *)(_2+4)) = _the_value_p_13196;
    _the_value_p_13196 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7505 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7505);
    _7506 = (int)*(((s1_ptr)_2)->base + _bucket__13200);
    _7505 = NOVALUE;
    if (IS_SEQUENCE(_7506)){
            _7507 = SEQ_PTR(_7506)->length;
    }
    else {
        _7507 = 1;
    }
    _7506 = NOVALUE;
    _7508 = (_7507 == 0);
    _7507 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7509 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7509)) {
        _7510 = _7509 + _7508;
        if ((long)((unsigned long)_7510 + (unsigned long)HIGH_BITS) >= 0) 
        _7510 = NewDouble((double)_7510);
    }
    else {
        _7510 = binary_op(PLUS, _7509, _7508);
    }
    _7509 = NOVALUE;
    _7508 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7510;
    if( _1 != _7510 ){
        DeRef(_1);
    }
    _7510 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7511 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7511)) {
        _7512 = _7511 + 1;
        if (_7512 > MAXINT){
            _7512 = NewDouble((double)_7512);
        }
    }
    else
    _7512 = binary_op(PLUS, 1, _7511);
    _7511 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7512;
    if( _1 != _7512 ){
        DeRef(_1);
    }
    _7512 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7513 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_13282);
    _2 = (int)SEQ_PTR(_7513);
    _tmp_seqk_13282 = (int)*(((s1_ptr)_2)->base + _bucket__13200);
    Ref(_tmp_seqk_13282);
    _7513 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13200);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7515 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_13195);
    Append(&_tmp_seqk_13282, _tmp_seqk_13282, _the_key_p_13195);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_13282);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13200);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_13282;
    DeRef(_1);
    _7518 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7520 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_13290);
    _2 = (int)SEQ_PTR(_7520);
    _tmp_seqv_13290 = (int)*(((s1_ptr)_2)->base + _bucket__13200);
    Ref(_tmp_seqv_13290);
    _7520 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13200);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7522 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_13196);
    Append(&_tmp_seqv_13290, _tmp_seqv_13290, _the_value_p_13196);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_13290);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13200);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_13290;
    DeRef(_1);
    _7525 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13203;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_13198 <= 0)
    goto L9; // [567] 606

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7528 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7529 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__13201);
    if (IS_ATOM_INT(_7528) && IS_ATOM_INT(_7529)) {
        _average_length__13201 = (_7528 % _7529) ? NewDouble((double)_7528 / _7529) : (_7528 / _7529);
    }
    else {
        _average_length__13201 = binary_op(DIVIDE, _7528, _7529);
    }
    _7528 = NOVALUE;
    _7529 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__13201, _trigger_p_13198)){
        goto LA; // [587] 605
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13203);
    _map_data_13203 = _5;

    /** 				rehash(the_map_p)*/
    _33rehash(_the_map_p_13194, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_13282);
    DeRef(_tmp_seqv_13290);
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRef(_map_data_13203);
    _7462 = NOVALUE;
    _7506 = NOVALUE;
    return;
    goto LB; // [613] 1110
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13195 == _33init_small_map_key_12821)
    _7532 = 1;
    else if (IS_ATOM_INT(_the_key_p_13195) && IS_ATOM_INT(_33init_small_map_key_12821))
    _7532 = 0;
    else
    _7532 = (compare(_the_key_p_13195, _33init_small_map_key_12821) == 0);
    if (_7532 == 0)
    {
        _7532 = NOVALUE;
        goto LC; // [622] 688
    }
    else{
        _7532 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13202 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [632] 669
LE: 
    if (_index__13199 <= 0)
    goto LF; // [637] 700

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7534 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7534);
    _7535 = (int)*(((s1_ptr)_2)->base + _index__13199);
    _7534 = NOVALUE;
    if (binary_op_a(NOTEQ, _7535, 1)){
        _7535 = NOVALUE;
        goto L10; // [651] 660
    }
    _7535 = NOVALUE;

    /** 					exit*/
    goto LF; // [657] 700
L10: 

    /** 				from_ = index_ + 1*/
    _from__13202 = _index__13199 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7538 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13199 = find_from(_the_key_p_13195, _7538, _from__13202);
    _7538 = NOVALUE;

    /** 			end while*/
    goto LE; // [682] 635
    goto LF; // [685] 700
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7540 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13199 = find_from(_the_key_p_13195, _7540, 1);
    _7540 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__13199 != 0)
    goto L11; // [704] 882

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7543 = find_from(_operation_p_13197, _33INIT_OPERATIONS_12816, 1);
    if (_7543 != 0)
    goto L12; // [715] 739
    _7543 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_719_13326);
    _msg_inlined_crash_at_719_13326 = EPrintf(-9999999, _7501, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_719_13326);

    /** end procedure*/
    goto L13; // [733] 736
L13: 
    DeRefi(_msg_inlined_crash_at_719_13326);
    _msg_inlined_crash_at_719_13326 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7545 = (int)*(((s1_ptr)_2)->base + 7);
    _index__13199 = find_from(0, _7545, 1);
    _7545 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__13199 != 0)
    goto L14; // [752] 806

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13203;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13203);
    _map_data_13203 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _33convert_to_large_map(_the_map_p_13194);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_7548);
    _7548 = _the_map_p_13194;
    Ref(_the_key_p_13195);
    DeRef(_7549);
    _7549 = _the_key_p_13195;
    Ref(_the_value_p_13196);
    DeRef(_7550);
    _7550 = _the_value_p_13196;
    DeRef(_7551);
    _7551 = _operation_p_13197;
    DeRef(_7552);
    _7552 = _trigger_p_13198;
    _33put(_7548, _7549, _7550, _7551, _7552);
    _7548 = NOVALUE;
    _7549 = NOVALUE;
    _7550 = NOVALUE;
    _7551 = NOVALUE;
    _7552 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRefDS(_map_data_13203);
    _7462 = NOVALUE;
    _7506 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_13195);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13199);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_13195;
    DeRef(_1);
    _7553 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13199);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _7555 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7557 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7557)) {
        _7558 = _7557 + 1;
        if (_7558 > MAXINT){
            _7558 = NewDouble((double)_7558);
        }
    }
    else
    _7558 = binary_op(PLUS, 1, _7557);
    _7557 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7558;
    if( _1 != _7558 ){
        DeRef(_1);
    }
    _7558 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13203);
    _7559 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7559)) {
        _7560 = _7559 + 1;
        if (_7560 > MAXINT){
            _7560 = NewDouble((double)_7560);
        }
    }
    else
    _7560 = binary_op(PLUS, 1, _7559);
    _7559 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13203);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13203 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7560;
    if( _1 != _7560 ){
        DeRef(_1);
    }
    _7560 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_13197 != 6)
    goto L15; // [858] 869

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_13196;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13196);
    *((int *)(_2+4)) = _the_value_p_13196;
    _the_value_p_13196 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_13197 == 8)
    goto L16; // [871] 881

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_13197 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_13197;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_13196);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13196;
        DeRef(_1);
        _7566 = NOVALUE;
        goto L17; // [904] 1096

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7570 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7568 = NOVALUE;
        if (IS_ATOM_INT(_7570) && IS_ATOM_INT(_the_value_p_13196)) {
            _7571 = _7570 + _the_value_p_13196;
            if ((long)((unsigned long)_7571 + (unsigned long)HIGH_BITS) >= 0) 
            _7571 = NewDouble((double)_7571);
        }
        else {
            _7571 = binary_op(PLUS, _7570, _the_value_p_13196);
        }
        _7570 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7571;
        if( _1 != _7571 ){
            DeRef(_1);
        }
        _7571 = NOVALUE;
        _7568 = NOVALUE;
        goto L17; // [929] 1096

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7574 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7572 = NOVALUE;
        if (IS_ATOM_INT(_7574) && IS_ATOM_INT(_the_value_p_13196)) {
            _7575 = _7574 - _the_value_p_13196;
            if ((long)((unsigned long)_7575 +(unsigned long) HIGH_BITS) >= 0){
                _7575 = NewDouble((double)_7575);
            }
        }
        else {
            _7575 = binary_op(MINUS, _7574, _the_value_p_13196);
        }
        _7574 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7575;
        if( _1 != _7575 ){
            DeRef(_1);
        }
        _7575 = NOVALUE;
        _7572 = NOVALUE;
        goto L17; // [954] 1096

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7578 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7576 = NOVALUE;
        if (IS_ATOM_INT(_7578) && IS_ATOM_INT(_the_value_p_13196)) {
            if (_7578 == (short)_7578 && _the_value_p_13196 <= INT15 && _the_value_p_13196 >= -INT15)
            _7579 = _7578 * _the_value_p_13196;
            else
            _7579 = NewDouble(_7578 * (double)_the_value_p_13196);
        }
        else {
            _7579 = binary_op(MULTIPLY, _7578, _the_value_p_13196);
        }
        _7578 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7579;
        if( _1 != _7579 ){
            DeRef(_1);
        }
        _7579 = NOVALUE;
        _7576 = NOVALUE;
        goto L17; // [979] 1096

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7582 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7580 = NOVALUE;
        if (IS_ATOM_INT(_7582) && IS_ATOM_INT(_the_value_p_13196)) {
            _7583 = (_7582 % _the_value_p_13196) ? NewDouble((double)_7582 / _the_value_p_13196) : (_7582 / _the_value_p_13196);
        }
        else {
            _7583 = binary_op(DIVIDE, _7582, _the_value_p_13196);
        }
        _7582 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7583;
        if( _1 != _7583 ){
            DeRef(_1);
        }
        _7583 = NOVALUE;
        _7580 = NOVALUE;
        goto L17; // [1004] 1096

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_13203);
        _7586 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7586);
        _7587 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7586 = NOVALUE;
        Ref(_the_value_p_13196);
        Append(&_7588, _7587, _the_value_p_13196);
        _7587 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7588;
        if( _1 != _7588 ){
            DeRef(_1);
        }
        _7588 = NOVALUE;
        _7584 = NOVALUE;
        goto L17; // [1033] 1096

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13203);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13203 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7591 = (int)*(((s1_ptr)_2)->base + _index__13199);
        _7589 = NOVALUE;
        if (IS_SEQUENCE(_7591) && IS_ATOM(_the_value_p_13196)) {
            Ref(_the_value_p_13196);
            Append(&_7592, _7591, _the_value_p_13196);
        }
        else if (IS_ATOM(_7591) && IS_SEQUENCE(_the_value_p_13196)) {
            Ref(_7591);
            Prepend(&_7592, _the_value_p_13196, _7591);
        }
        else {
            Concat((object_ptr)&_7592, _7591, _the_value_p_13196);
            _7591 = NOVALUE;
        }
        _7591 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13199);
        _1 = *(int *)_2;
        *(int *)_2 = _7592;
        if( _1 != _7592 ){
            DeRef(_1);
        }
        _7592 = NOVALUE;
        _7589 = NOVALUE;
        goto L17; // [1058] 1096

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_13197 = _operation_p_13197;
        goto L17; // [1069] 1096

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1077_13389);
        _msg_inlined_crash_at_1077_13389 = EPrintf(-9999999, _7498, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1077_13389);

        /** end procedure*/
        goto L18; // [1090] 1093
L18: 
        DeRefi(_msg_inlined_crash_at_1077_13389);
        _msg_inlined_crash_at_1077_13389 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13203);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13194);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13203;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRefDS(_map_data_13203);
    _7462 = NOVALUE;
    _7506 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_13195);
    DeRef(_the_value_p_13196);
    DeRef(_average_length__13201);
    DeRef(_map_data_13203);
    _7462 = NOVALUE;
    _7506 = NOVALUE;
    return;
    ;
}
void put() __attribute__ ((alias ("_33put")));


void _33nested_put(int _the_map_p_13392, int _the_keys_p_13393, int _the_value_p_13394, int _operation_p_13395, int _trigger_p_13396)
{
    int _temp_map__13397 = NOVALUE;
    int _7604 = NOVALUE;
    int _7603 = NOVALUE;
    int _7602 = NOVALUE;
    int _7601 = NOVALUE;
    int _7600 = NOVALUE;
    int _7599 = NOVALUE;
    int _7597 = NOVALUE;
    int _7596 = NOVALUE;
    int _7595 = NOVALUE;
    int _7593 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_operation_p_13395)) {
        _1 = (long)(DBL_PTR(_operation_p_13395)->dbl);
        DeRefDS(_operation_p_13395);
        _operation_p_13395 = _1;
    }
    if (!IS_ATOM_INT(_trigger_p_13396)) {
        _1 = (long)(DBL_PTR(_trigger_p_13396)->dbl);
        DeRefDS(_trigger_p_13396);
        _trigger_p_13396 = _1;
    }

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_13393)){
            _7593 = SEQ_PTR(_the_keys_p_13393)->length;
    }
    else {
        _7593 = 1;
    }
    if (_7593 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13393);
    _7595 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13392);
    Ref(_7595);
    Ref(_the_value_p_13394);
    _33put(_the_map_p_13392, _7595, _the_value_p_13394, _operation_p_13395, _trigger_p_13396);
    _7595 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13393);
    _7596 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13392);
    Ref(_7596);
    _7597 = _33get(_the_map_p_13392, _7596, 0);
    _7596 = NOVALUE;
    _0 = _temp_map__13397;
    _temp_map__13397 = _33new_extra(_7597, 690);
    DeRef(_0);
    _7597 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_13393)){
            _7599 = SEQ_PTR(_the_keys_p_13393)->length;
    }
    else {
        _7599 = 1;
    }
    rhs_slice_target = (object_ptr)&_7600;
    RHS_Slice(_the_keys_p_13393, 2, _7599);
    Ref(_the_value_p_13394);
    DeRef(_7601);
    _7601 = _the_value_p_13394;
    DeRef(_7602);
    _7602 = _operation_p_13395;
    DeRef(_7603);
    _7603 = _trigger_p_13396;
    Ref(_temp_map__13397);
    _33nested_put(_temp_map__13397, _7600, _7601, _7602, _7603);
    _7600 = NOVALUE;
    _7601 = NOVALUE;
    _7602 = NOVALUE;
    _7603 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13393);
    _7604 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13392);
    Ref(_7604);
    Ref(_temp_map__13397);
    _33put(_the_map_p_13392, _7604, _temp_map__13397, 1, _trigger_p_13396);
    _7604 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_13392);
    DeRefDS(_the_keys_p_13393);
    DeRef(_the_value_p_13394);
    DeRef(_temp_map__13397);
    return;
    ;
}
void nested_put() __attribute__ ((alias ("_33nested_put")));


void _33remove(int _the_map_p_13414, int _the_key_p_13415)
{
    int _index__13416 = NOVALUE;
    int _bucket__13417 = NOVALUE;
    int _temp_map__13418 = NOVALUE;
    int _from__13419 = NOVALUE;
    int _calc_hash_1__tmp_at40_13430 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13429 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13428 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13427 = NOVALUE;
    int _7669 = NOVALUE;
    int _7668 = NOVALUE;
    int _7667 = NOVALUE;
    int _7666 = NOVALUE;
    int _7664 = NOVALUE;
    int _7662 = NOVALUE;
    int _7660 = NOVALUE;
    int _7658 = NOVALUE;
    int _7657 = NOVALUE;
    int _7655 = NOVALUE;
    int _7652 = NOVALUE;
    int _7651 = NOVALUE;
    int _7650 = NOVALUE;
    int _7649 = NOVALUE;
    int _7648 = NOVALUE;
    int _7647 = NOVALUE;
    int _7646 = NOVALUE;
    int _7645 = NOVALUE;
    int _7644 = NOVALUE;
    int _7643 = NOVALUE;
    int _7642 = NOVALUE;
    int _7641 = NOVALUE;
    int _7640 = NOVALUE;
    int _7638 = NOVALUE;
    int _7637 = NOVALUE;
    int _7636 = NOVALUE;
    int _7635 = NOVALUE;
    int _7634 = NOVALUE;
    int _7633 = NOVALUE;
    int _7632 = NOVALUE;
    int _7631 = NOVALUE;
    int _7630 = NOVALUE;
    int _7629 = NOVALUE;
    int _7628 = NOVALUE;
    int _7626 = NOVALUE;
    int _7624 = NOVALUE;
    int _7622 = NOVALUE;
    int _7621 = NOVALUE;
    int _7620 = NOVALUE;
    int _7618 = NOVALUE;
    int _7617 = NOVALUE;
    int _7616 = NOVALUE;
    int _7615 = NOVALUE;
    int _7614 = NOVALUE;
    int _7611 = NOVALUE;
    int _7610 = NOVALUE;
    int _7609 = NOVALUE;
    int _7608 = NOVALUE;
    int _7606 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13418);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13414)){
        _temp_map__13418 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13414)->dbl));
    }
    else{
        _temp_map__13418 = (int)*(((s1_ptr)_2)->base + _the_map_p_13414);
    }
    Ref(_temp_map__13418);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13414);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7606 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7606, 76)){
        _7606 = NOVALUE;
        goto L1; // [25] 303
    }
    _7606 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7608 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7608)){
            _7609 = SEQ_PTR(_7608)->length;
    }
    else {
        _7609 = 1;
    }
    _7608 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_13427 = _7609;
    _7609 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13428);
    _ret__inlined_calc_hash_at_40_13428 = calc_hash(_the_key_p_13415, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13428)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13428)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13428);
        _ret__inlined_calc_hash_at_40_13428 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13430 = (_ret__inlined_calc_hash_at_40_13428 % _max_hash_p_inlined_calc_hash_at_37_13427);
    _bucket__13417 = _calc_hash_1__tmp_at40_13430 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13428);
    _ret__inlined_calc_hash_at_40_13428 = NOVALUE;

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7610 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7610);
    _7611 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7610 = NOVALUE;
    _index__13416 = find_from(_the_key_p_13415, _7611, 1);
    _7611 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__13416 == 0)
    goto L2; // [81] 429

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7614 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7614)) {
        _7615 = _7614 - 1;
        if ((long)((unsigned long)_7615 +(unsigned long) HIGH_BITS) >= 0){
            _7615 = NewDouble((double)_7615);
        }
    }
    else {
        _7615 = binary_op(MINUS, _7614, 1);
    }
    _7614 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7615;
    if( _1 != _7615 ){
        DeRef(_1);
    }
    _7615 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7616 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7616);
    _7617 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7616 = NOVALUE;
    if (IS_SEQUENCE(_7617)){
            _7618 = SEQ_PTR(_7617)->length;
    }
    else {
        _7618 = 1;
    }
    _7617 = NOVALUE;
    if (_7618 != 1)
    goto L3; // [112] 155

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7620 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7620)) {
        _7621 = _7620 - 1;
        if ((long)((unsigned long)_7621 +(unsigned long) HIGH_BITS) >= 0){
            _7621 = NewDouble((double)_7621);
        }
    }
    else {
        _7621 = binary_op(MINUS, _7620, 1);
    }
    _7620 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7621;
    if( _1 != _7621 ){
        DeRef(_1);
    }
    _7621 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13417);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7622 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13417);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7624 = NOVALUE;
    goto L4; // [152] 260
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7628 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7628);
    _7629 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7628 = NOVALUE;
    _7630 = _index__13416 - 1;
    rhs_slice_target = (object_ptr)&_7631;
    RHS_Slice(_7629, 1, _7630);
    _7629 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7632 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7632);
    _7633 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7632 = NOVALUE;
    _7634 = _index__13416 + 1;
    if (_7634 > MAXINT){
        _7634 = NewDouble((double)_7634);
    }
    if (IS_SEQUENCE(_7633)){
            _7635 = SEQ_PTR(_7633)->length;
    }
    else {
        _7635 = 1;
    }
    rhs_slice_target = (object_ptr)&_7636;
    RHS_Slice(_7633, _7634, _7635);
    _7633 = NOVALUE;
    Concat((object_ptr)&_7637, _7631, _7636);
    DeRefDS(_7631);
    _7631 = NOVALUE;
    DeRef(_7631);
    _7631 = NOVALUE;
    DeRefDS(_7636);
    _7636 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13417);
    _1 = *(int *)_2;
    *(int *)_2 = _7637;
    if( _1 != _7637 ){
        DeRef(_1);
    }
    _7637 = NOVALUE;
    _7626 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7640 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7640);
    _7641 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7640 = NOVALUE;
    _7642 = _index__13416 - 1;
    rhs_slice_target = (object_ptr)&_7643;
    RHS_Slice(_7641, 1, _7642);
    _7641 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7644 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7644);
    _7645 = (int)*(((s1_ptr)_2)->base + _bucket__13417);
    _7644 = NOVALUE;
    _7646 = _index__13416 + 1;
    if (_7646 > MAXINT){
        _7646 = NewDouble((double)_7646);
    }
    if (IS_SEQUENCE(_7645)){
            _7647 = SEQ_PTR(_7645)->length;
    }
    else {
        _7647 = 1;
    }
    rhs_slice_target = (object_ptr)&_7648;
    RHS_Slice(_7645, _7646, _7647);
    _7645 = NOVALUE;
    Concat((object_ptr)&_7649, _7643, _7648);
    DeRefDS(_7643);
    _7643 = NOVALUE;
    DeRef(_7643);
    _7643 = NOVALUE;
    DeRefDS(_7648);
    _7648 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13417);
    _1 = *(int *)_2;
    *(int *)_2 = _7649;
    if( _1 != _7649 ){
        DeRef(_1);
    }
    _7649 = NOVALUE;
    _7638 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7650 = (int)*(((s1_ptr)_2)->base + 2);
    if (_33threshold_size_12820 <= INT15 && _33threshold_size_12820 >= -INT15)
    _7651 = 51 * _33threshold_size_12820;
    else
    _7651 = NewDouble(51 * (double)_33threshold_size_12820);
    if (IS_ATOM_INT(_7651)) {
        if (100 > 0 && _7651 >= 0) {
            _7652 = _7651 / 100;
        }
        else {
            temp_dbl = floor((double)_7651 / (double)100);
            if (_7651 != MININT)
            _7652 = (long)temp_dbl;
            else
            _7652 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7651, 100);
        _7652 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7651);
    _7651 = NOVALUE;
    if (binary_op_a(GREATEREQ, _7650, _7652)){
        _7650 = NOVALUE;
        DeRef(_7652);
        _7652 = NOVALUE;
        goto L2; // [276] 429
    }
    _7650 = NOVALUE;
    DeRef(_7652);
    _7652 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13418);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13414);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13418;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_13414);
    _33convert_to_small_map(_the_map_p_13414);

    /** 				return*/
    DeRef(_the_map_p_13414);
    DeRef(_the_key_p_13415);
    DeRefDS(_temp_map__13418);
    _7608 = NOVALUE;
    _7617 = NOVALUE;
    DeRef(_7630);
    _7630 = NOVALUE;
    DeRef(_7642);
    _7642 = NOVALUE;
    DeRef(_7634);
    _7634 = NOVALUE;
    DeRef(_7646);
    _7646 = NOVALUE;
    return;
    goto L2; // [300] 429
L1: 

    /** 		from_ = 1*/
    _from__13419 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__13419 <= 0)
    goto L6; // [313] 428

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7655 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13416 = find_from(_the_key_p_13415, _7655, _from__13419);
    _7655 = NOVALUE;

    /** 			if index_ then*/
    if (_index__13416 == 0)
    {
        goto L6; // [330] 428
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7657 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7657);
    _7658 = (int)*(((s1_ptr)_2)->base + _index__13416);
    _7657 = NOVALUE;
    if (binary_op_a(NOTEQ, _7658, 1)){
        _7658 = NOVALUE;
        goto L7; // [343] 417
    }
    _7658 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13416);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7660 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_33init_small_map_key_12821);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13416);
    _1 = *(int *)_2;
    *(int *)_2 = _33init_small_map_key_12821;
    DeRef(_1);
    _7662 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13416);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7664 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7666 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7666)) {
        _7667 = _7666 - 1;
        if ((long)((unsigned long)_7667 +(unsigned long) HIGH_BITS) >= 0){
            _7667 = NewDouble((double)_7667);
        }
    }
    else {
        _7667 = binary_op(MINUS, _7666, 1);
    }
    _7666 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7667;
    if( _1 != _7667 ){
        DeRef(_1);
    }
    _7667 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13418);
    _7668 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7668)) {
        _7669 = _7668 - 1;
        if ((long)((unsigned long)_7669 +(unsigned long) HIGH_BITS) >= 0){
            _7669 = NewDouble((double)_7669);
        }
    }
    else {
        _7669 = binary_op(MINUS, _7668, 1);
    }
    _7668 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13418);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13418 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7669;
    if( _1 != _7669 ){
        DeRef(_1);
    }
    _7669 = NOVALUE;
    goto L7; // [409] 417

    /** 				exit*/
    goto L6; // [414] 428
L7: 

    /** 			from_ = index_ + 1*/
    _from__13419 = _index__13416 + 1;

    /** 		end while*/
    goto L5; // [425] 313
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13418);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13414);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13418;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13414);
    DeRef(_the_key_p_13415);
    DeRefDS(_temp_map__13418);
    _7608 = NOVALUE;
    _7617 = NOVALUE;
    DeRef(_7630);
    _7630 = NOVALUE;
    DeRef(_7642);
    _7642 = NOVALUE;
    DeRef(_7634);
    _7634 = NOVALUE;
    DeRef(_7646);
    _7646 = NOVALUE;
    return;
    ;
}


void _33clear(int _the_map_p_13504)
{
    int _temp_map__13505 = NOVALUE;
    int _7688 = NOVALUE;
    int _7687 = NOVALUE;
    int _7686 = NOVALUE;
    int _7685 = NOVALUE;
    int _7684 = NOVALUE;
    int _7683 = NOVALUE;
    int _7682 = NOVALUE;
    int _7681 = NOVALUE;
    int _7680 = NOVALUE;
    int _7679 = NOVALUE;
    int _7678 = NOVALUE;
    int _7677 = NOVALUE;
    int _7676 = NOVALUE;
    int _7675 = NOVALUE;
    int _7674 = NOVALUE;
    int _7672 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13505);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13504)){
        _temp_map__13505 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13504)->dbl));
    }
    else{
        _temp_map__13505 = (int)*(((s1_ptr)_2)->base + _the_map_p_13504);
    }
    Ref(_temp_map__13505);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7672 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7672, 76)){
        _7672 = NOVALUE;
        goto L1; // [17] 70
    }
    _7672 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7674 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7674)){
            _7675 = SEQ_PTR(_7674)->length;
    }
    else {
        _7675 = 1;
    }
    _7674 = NOVALUE;
    _7676 = Repeat(_5, _7675);
    _7675 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7676;
    if( _1 != _7676 ){
        DeRef(_1);
    }
    _7676 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7677 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7677)){
            _7678 = SEQ_PTR(_7677)->length;
    }
    else {
        _7678 = 1;
    }
    _7677 = NOVALUE;
    _7679 = Repeat(_5, _7678);
    _7678 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7679;
    if( _1 != _7679 ){
        DeRef(_1);
    }
    _7679 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7680 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7680)){
            _7681 = SEQ_PTR(_7680)->length;
    }
    else {
        _7681 = 1;
    }
    _7680 = NOVALUE;
    _7682 = Repeat(_33init_small_map_key_12821, _7681);
    _7681 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7682;
    if( _1 != _7682 ){
        DeRef(_1);
    }
    _7682 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7683 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7683)){
            _7684 = SEQ_PTR(_7683)->length;
    }
    else {
        _7684 = 1;
    }
    _7683 = NOVALUE;
    _7685 = Repeat(0, _7684);
    _7684 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7685;
    if( _1 != _7685 ){
        DeRef(_1);
    }
    _7685 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13505);
    _7686 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7686)){
            _7687 = SEQ_PTR(_7686)->length;
    }
    else {
        _7687 = 1;
    }
    _7686 = NOVALUE;
    _7688 = Repeat(0, _7687);
    _7687 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13505);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13505 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7688;
    if( _1 != _7688 ){
        DeRef(_1);
    }
    _7688 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13505);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13504))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13504)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13504);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13505;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13504);
    DeRefDS(_temp_map__13505);
    _7674 = NOVALUE;
    _7677 = NOVALUE;
    _7680 = NOVALUE;
    _7683 = NOVALUE;
    _7686 = NOVALUE;
    return;
    ;
}


int _33size(int _the_map_p_13528)
{
    int _7690 = NOVALUE;
    int _7689 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13528)){
        _7689 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13528)->dbl));
    }
    else{
        _7689 = (int)*(((s1_ptr)_2)->base + _the_map_p_13528);
    }
    _2 = (int)SEQ_PTR(_7689);
    _7690 = (int)*(((s1_ptr)_2)->base + 2);
    _7689 = NOVALUE;
    Ref(_7690);
    DeRef(_the_map_p_13528);
    return _7690;
    ;
}


int _33statistics(int _the_map_p_13540)
{
    int _statistic_set__13541 = NOVALUE;
    int _lengths__13542 = NOVALUE;
    int _length__13543 = NOVALUE;
    int _temp_map__13544 = NOVALUE;
    int _7721 = NOVALUE;
    int _7720 = NOVALUE;
    int _7719 = NOVALUE;
    int _7718 = NOVALUE;
    int _7717 = NOVALUE;
    int _7716 = NOVALUE;
    int _7715 = NOVALUE;
    int _7714 = NOVALUE;
    int _7713 = NOVALUE;
    int _7712 = NOVALUE;
    int _7711 = NOVALUE;
    int _7710 = NOVALUE;
    int _7707 = NOVALUE;
    int _7705 = NOVALUE;
    int _7702 = NOVALUE;
    int _7701 = NOVALUE;
    int _7700 = NOVALUE;
    int _7699 = NOVALUE;
    int _7697 = NOVALUE;
    int _7696 = NOVALUE;
    int _7695 = NOVALUE;
    int _7694 = NOVALUE;
    int _7692 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13544);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13540)){
        _temp_map__13544 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13540)->dbl));
    }
    else{
        _temp_map__13544 = (int)*(((s1_ptr)_2)->base + _the_map_p_13540);
    }
    Ref(_temp_map__13544);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7692 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7692, 76)){
        _7692 = NOVALUE;
        goto L1; // [17] 164
    }
    _7692 = NOVALUE;

    /** 		statistic_set_ = { */
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7694 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7695 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7696 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7696)){
            _7697 = SEQ_PTR(_7696)->length;
    }
    else {
        _7697 = 1;
    }
    _7696 = NOVALUE;
    _0 = _statistic_set__13541;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7694);
    *((int *)(_2+4)) = _7694;
    Ref(_7695);
    *((int *)(_2+8)) = _7695;
    *((int *)(_2+12)) = _7697;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 1073741823;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    _statistic_set__13541 = MAKE_SEQ(_1);
    DeRef(_0);
    _7697 = NOVALUE;
    _7695 = NOVALUE;
    _7694 = NOVALUE;

    /** 		lengths_ = {}*/
    RefDS(_5);
    DeRefi(_lengths__13542);
    _lengths__13542 = _5;

    /** 		for i = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7699 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7699)){
            _7700 = SEQ_PTR(_7699)->length;
    }
    else {
        _7700 = 1;
    }
    _7699 = NOVALUE;
    {
        int _i_13555;
        _i_13555 = 1;
L2: 
        if (_i_13555 > _7700){
            goto L3; // [64] 138
        }

        /** 			length_ = length(temp_map_[KEY_BUCKETS][i])*/
        _2 = (int)SEQ_PTR(_temp_map__13544);
        _7701 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7701);
        _7702 = (int)*(((s1_ptr)_2)->base + _i_13555);
        _7701 = NOVALUE;
        if (IS_SEQUENCE(_7702)){
                _length__13543 = SEQ_PTR(_7702)->length;
        }
        else {
            _length__13543 = 1;
        }
        _7702 = NOVALUE;

        /** 			if length_ > 0 then*/
        if (_length__13543 <= 0)
        goto L4; // [86] 131

        /** 				if length_ > statistic_set_[LARGEST_BUCKET] then*/
        _2 = (int)SEQ_PTR(_statistic_set__13541);
        _7705 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(LESSEQ, _length__13543, _7705)){
            _7705 = NOVALUE;
            goto L5; // [96] 107
        }
        _7705 = NOVALUE;

        /** 					statistic_set_[LARGEST_BUCKET] = length_*/
        _2 = (int)SEQ_PTR(_statistic_set__13541);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _statistic_set__13541 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _length__13543;
        DeRef(_1);
L5: 

        /** 				if length_ < statistic_set_[SMALLEST_BUCKET] then*/
        _2 = (int)SEQ_PTR(_statistic_set__13541);
        _7707 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _length__13543, _7707)){
            _7707 = NOVALUE;
            goto L6; // [113] 124
        }
        _7707 = NOVALUE;

        /** 					statistic_set_[SMALLEST_BUCKET] = length_*/
        _2 = (int)SEQ_PTR(_statistic_set__13541);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _statistic_set__13541 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _length__13543;
        DeRef(_1);
L6: 

        /** 				lengths_ &= length_*/
        Append(&_lengths__13542, _lengths__13542, _length__13543);
L4: 

        /** 		end for*/
        _i_13555 = _i_13555 + 1;
        goto L2; // [133] 71
L3: 
        ;
    }

    /** 		statistic_set_[AVERAGE_BUCKET] = stats:average(lengths_)*/
    RefDS(_lengths__13542);
    _7710 = _35average(_lengths__13542, 1);
    _2 = (int)SEQ_PTR(_statistic_set__13541);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _statistic_set__13541 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7710;
    if( _1 != _7710 ){
        DeRef(_1);
    }
    _7710 = NOVALUE;

    /** 		statistic_set_[STDEV_BUCKET] = stats:stdev(lengths_)*/
    RefDS(_lengths__13542);
    _7711 = _35stdev(_lengths__13542, 1, 2);
    _2 = (int)SEQ_PTR(_statistic_set__13541);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _statistic_set__13541 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7711;
    if( _1 != _7711 ){
        DeRef(_1);
    }
    _7711 = NOVALUE;
    goto L7; // [161] 213
L1: 

    /** 		statistic_set_ = {*/
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7712 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7713 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7714 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7714)){
            _7715 = SEQ_PTR(_7714)->length;
    }
    else {
        _7715 = 1;
    }
    _7714 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7716 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7716)){
            _7717 = SEQ_PTR(_7716)->length;
    }
    else {
        _7717 = 1;
    }
    _7716 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7718 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7718)){
            _7719 = SEQ_PTR(_7718)->length;
    }
    else {
        _7719 = 1;
    }
    _7718 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13544);
    _7720 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7720)){
            _7721 = SEQ_PTR(_7720)->length;
    }
    else {
        _7721 = 1;
    }
    _7720 = NOVALUE;
    _0 = _statistic_set__13541;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7712);
    *((int *)(_2+4)) = _7712;
    Ref(_7713);
    *((int *)(_2+8)) = _7713;
    *((int *)(_2+12)) = _7715;
    *((int *)(_2+16)) = _7717;
    *((int *)(_2+20)) = _7719;
    *((int *)(_2+24)) = _7721;
    *((int *)(_2+28)) = 0;
    _statistic_set__13541 = MAKE_SEQ(_1);
    DeRef(_0);
    _7721 = NOVALUE;
    _7719 = NOVALUE;
    _7717 = NOVALUE;
    _7715 = NOVALUE;
    _7713 = NOVALUE;
    _7712 = NOVALUE;
L7: 

    /** 	return statistic_set_*/
    DeRef(_the_map_p_13540);
    DeRefi(_lengths__13542);
    DeRef(_temp_map__13544);
    _7699 = NOVALUE;
    _7702 = NOVALUE;
    _7696 = NOVALUE;
    _7714 = NOVALUE;
    _7716 = NOVALUE;
    _7718 = NOVALUE;
    _7720 = NOVALUE;
    return _statistic_set__13541;
    ;
}
int statistics() __attribute__ ((alias ("_33statistics")));


int _33keys(int _the_map_p_13586, int _sorted_result_13587)
{
    int _buckets__13588 = NOVALUE;
    int _current_bucket__13589 = NOVALUE;
    int _results__13590 = NOVALUE;
    int _pos__13591 = NOVALUE;
    int _temp_map__13592 = NOVALUE;
    int _7746 = NOVALUE;
    int _7744 = NOVALUE;
    int _7743 = NOVALUE;
    int _7741 = NOVALUE;
    int _7740 = NOVALUE;
    int _7739 = NOVALUE;
    int _7738 = NOVALUE;
    int _7736 = NOVALUE;
    int _7735 = NOVALUE;
    int _7734 = NOVALUE;
    int _7733 = NOVALUE;
    int _7731 = NOVALUE;
    int _7729 = NOVALUE;
    int _7726 = NOVALUE;
    int _7724 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sorted_result_13587)) {
        _1 = (long)(DBL_PTR(_sorted_result_13587)->dbl);
        DeRefDS(_sorted_result_13587);
        _sorted_result_13587 = _1;
    }

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13592);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13586)){
        _temp_map__13592 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13586)->dbl));
    }
    else{
        _temp_map__13592 = (int)*(((s1_ptr)_2)->base + _the_map_p_13586);
    }
    Ref(_temp_map__13592);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13592);
    _7724 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13590);
    _results__13590 = Repeat(0, _7724);
    _7724 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13591 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13592);
    _7726 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7726, 76)){
        _7726 = NOVALUE;
        goto L1; // [34] 113
    }
    _7726 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__13588);
    _2 = (int)SEQ_PTR(_temp_map__13592);
    _buckets__13588 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__13588);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13588)){
            _7729 = SEQ_PTR(_buckets__13588)->length;
    }
    else {
        _7729 = 1;
    }
    {
        int _index_13601;
        _index_13601 = 1;
L2: 
        if (_index_13601 > _7729){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__13589);
        _2 = (int)SEQ_PTR(_buckets__13588);
        _current_bucket__13589 = (int)*(((s1_ptr)_2)->base + _index_13601);
        Ref(_current_bucket__13589);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__13589)){
                _7731 = SEQ_PTR(_current_bucket__13589)->length;
        }
        else {
            _7731 = 1;
        }
        if (_7731 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__13589)){
                _7733 = SEQ_PTR(_current_bucket__13589)->length;
        }
        else {
            _7733 = 1;
        }
        _7734 = _pos__13591 + _7733;
        if ((long)((unsigned long)_7734 + (unsigned long)HIGH_BITS) >= 0) 
        _7734 = NewDouble((double)_7734);
        _7733 = NOVALUE;
        if (IS_ATOM_INT(_7734)) {
            _7735 = _7734 - 1;
        }
        else {
            _7735 = NewDouble(DBL_PTR(_7734)->dbl - (double)1);
        }
        DeRef(_7734);
        _7734 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13590;
        AssignSlice(_pos__13591, _7735, _current_bucket__13589);
        DeRef(_7735);
        _7735 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__13589)){
                _7736 = SEQ_PTR(_current_bucket__13589)->length;
        }
        else {
            _7736 = 1;
        }
        _pos__13591 = _pos__13591 + _7736;
        _7736 = NOVALUE;
L4: 

        /** 		end for*/
        _index_13601 = _index_13601 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13592);
    _7738 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7738)){
            _7739 = SEQ_PTR(_7738)->length;
    }
    else {
        _7739 = 1;
    }
    _7738 = NOVALUE;
    {
        int _index_13614;
        _index_13614 = 1;
L6: 
        if (_index_13614 > _7739){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13592);
        _7740 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7740);
        _7741 = (int)*(((s1_ptr)_2)->base + _index_13614);
        _7740 = NOVALUE;
        if (binary_op_a(EQUALS, _7741, 0)){
            _7741 = NOVALUE;
            goto L8; // [139] 164
        }
        _7741 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13592);
        _7743 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7743);
        _7744 = (int)*(((s1_ptr)_2)->base + _index_13614);
        _7743 = NOVALUE;
        Ref(_7744);
        _2 = (int)SEQ_PTR(_results__13590);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13590 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13591);
        _1 = *(int *)_2;
        *(int *)_2 = _7744;
        if( _1 != _7744 ){
            DeRef(_1);
        }
        _7744 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13591 = _pos__13591 + 1;
L8: 

        /** 		end for*/
        _index_13614 = _index_13614 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_13587 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13590);
    _7746 = _24sort(_results__13590, 1);
    DeRef(_the_map_p_13586);
    DeRef(_buckets__13588);
    DeRef(_current_bucket__13589);
    DeRefDS(_results__13590);
    DeRef(_temp_map__13592);
    _7738 = NOVALUE;
    return _7746;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_13586);
    DeRef(_buckets__13588);
    DeRef(_current_bucket__13589);
    DeRef(_temp_map__13592);
    _7738 = NOVALUE;
    DeRef(_7746);
    _7746 = NOVALUE;
    return _results__13590;
LA: 
    ;
}
int keys() __attribute__ ((alias ("_33keys")));


int _33values(int _the_map_13629, int _keys_13630, int _default_values_13631)
{
    int _buckets__13655 = NOVALUE;
    int _bucket__13656 = NOVALUE;
    int _results__13657 = NOVALUE;
    int _pos__13658 = NOVALUE;
    int _temp_map__13659 = NOVALUE;
    int _7786 = NOVALUE;
    int _7785 = NOVALUE;
    int _7783 = NOVALUE;
    int _7782 = NOVALUE;
    int _7781 = NOVALUE;
    int _7780 = NOVALUE;
    int _7778 = NOVALUE;
    int _7777 = NOVALUE;
    int _7776 = NOVALUE;
    int _7775 = NOVALUE;
    int _7773 = NOVALUE;
    int _7771 = NOVALUE;
    int _7768 = NOVALUE;
    int _7766 = NOVALUE;
    int _7764 = NOVALUE;
    int _7763 = NOVALUE;
    int _7762 = NOVALUE;
    int _7761 = NOVALUE;
    int _7759 = NOVALUE;
    int _7758 = NOVALUE;
    int _7757 = NOVALUE;
    int _7756 = NOVALUE;
    int _7755 = NOVALUE;
    int _7754 = NOVALUE;
    int _7752 = NOVALUE;
    int _7751 = NOVALUE;
    int _7749 = NOVALUE;
    int _7748 = NOVALUE;
    int _7747 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _7747 = IS_SEQUENCE(_keys_13630);
    if (_7747 == 0)
    {
        _7747 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _7747 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _7748 = IS_ATOM(_default_values_13631);
    if (_7748 == 0)
    {
        _7748 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _7748 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    if (IS_SEQUENCE(_keys_13630)){
            _7749 = SEQ_PTR(_keys_13630)->length;
    }
    else {
        _7749 = 1;
    }
    _0 = _default_values_13631;
    _default_values_13631 = Repeat(_default_values_13631, _7749);
    DeRef(_0);
    _7749 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_13631)){
            _7751 = SEQ_PTR(_default_values_13631)->length;
    }
    else {
        _7751 = 1;
    }
    if (IS_SEQUENCE(_keys_13630)){
            _7752 = SEQ_PTR(_keys_13630)->length;
    }
    else {
        _7752 = 1;
    }
    if (_7751 >= _7752)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_13631)){
            _7754 = SEQ_PTR(_default_values_13631)->length;
    }
    else {
        _7754 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_13631);
    _7755 = (int)*(((s1_ptr)_2)->base + _7754);
    if (IS_SEQUENCE(_keys_13630)){
            _7756 = SEQ_PTR(_keys_13630)->length;
    }
    else {
        _7756 = 1;
    }
    if (IS_SEQUENCE(_default_values_13631)){
            _7757 = SEQ_PTR(_default_values_13631)->length;
    }
    else {
        _7757 = 1;
    }
    _7758 = _7756 - _7757;
    _7756 = NOVALUE;
    _7757 = NOVALUE;
    _7759 = Repeat(_7755, _7758);
    _7755 = NOVALUE;
    _7758 = NOVALUE;
    if (IS_SEQUENCE(_default_values_13631) && IS_ATOM(_7759)) {
    }
    else if (IS_ATOM(_default_values_13631) && IS_SEQUENCE(_7759)) {
        Ref(_default_values_13631);
        Prepend(&_default_values_13631, _7759, _default_values_13631);
    }
    else {
        Concat((object_ptr)&_default_values_13631, _default_values_13631, _7759);
    }
    DeRefDS(_7759);
    _7759 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_13630)){
            _7761 = SEQ_PTR(_keys_13630)->length;
    }
    else {
        _7761 = 1;
    }
    {
        int _i_13650;
        _i_13650 = 1;
L5: 
        if (_i_13650 > _7761){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_13630);
        _7762 = (int)*(((s1_ptr)_2)->base + _i_13650);
        _2 = (int)SEQ_PTR(_default_values_13631);
        _7763 = (int)*(((s1_ptr)_2)->base + _i_13650);
        Ref(_the_map_13629);
        Ref(_7762);
        Ref(_7763);
        _7764 = _33get(_the_map_13629, _7762, _7763);
        _7762 = NOVALUE;
        _7763 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_13630);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_13630 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13650);
        _1 = *(int *)_2;
        *(int *)_2 = _7764;
        if( _1 != _7764 ){
            DeRef(_1);
        }
        _7764 = NOVALUE;

        /** 		end for*/
        _i_13650 = _i_13650 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_the_map_13629);
    DeRef(_default_values_13631);
    DeRef(_buckets__13655);
    DeRef(_bucket__13656);
    DeRef(_results__13657);
    DeRef(_temp_map__13659);
    return _keys_13630;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__13659);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_13629)){
        _temp_map__13659 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_13629)->dbl));
    }
    else{
        _temp_map__13659 = (int)*(((s1_ptr)_2)->base + _the_map_13629);
    }
    Ref(_temp_map__13659);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13659);
    _7766 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13657);
    _results__13657 = Repeat(0, _7766);
    _7766 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13658 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13659);
    _7768 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7768, 76)){
        _7768 = NOVALUE;
        goto L7; // [157] 236
    }
    _7768 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__13655);
    _2 = (int)SEQ_PTR(_temp_map__13659);
    _buckets__13655 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__13655);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13655)){
            _7771 = SEQ_PTR(_buckets__13655)->length;
    }
    else {
        _7771 = 1;
    }
    {
        int _index_13668;
        _index_13668 = 1;
L8: 
        if (_index_13668 > _7771){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__13656);
        _2 = (int)SEQ_PTR(_buckets__13655);
        _bucket__13656 = (int)*(((s1_ptr)_2)->base + _index_13668);
        Ref(_bucket__13656);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__13656)){
                _7773 = SEQ_PTR(_bucket__13656)->length;
        }
        else {
            _7773 = 1;
        }
        if (_7773 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__13656)){
                _7775 = SEQ_PTR(_bucket__13656)->length;
        }
        else {
            _7775 = 1;
        }
        _7776 = _pos__13658 + _7775;
        if ((long)((unsigned long)_7776 + (unsigned long)HIGH_BITS) >= 0) 
        _7776 = NewDouble((double)_7776);
        _7775 = NOVALUE;
        if (IS_ATOM_INT(_7776)) {
            _7777 = _7776 - 1;
        }
        else {
            _7777 = NewDouble(DBL_PTR(_7776)->dbl - (double)1);
        }
        DeRef(_7776);
        _7776 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13657;
        AssignSlice(_pos__13658, _7777, _bucket__13656);
        DeRef(_7777);
        _7777 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__13656)){
                _7778 = SEQ_PTR(_bucket__13656)->length;
        }
        else {
            _7778 = 1;
        }
        _pos__13658 = _pos__13658 + _7778;
        _7778 = NOVALUE;
LA: 

        /** 		end for*/
        _index_13668 = _index_13668 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13659);
    _7780 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7780)){
            _7781 = SEQ_PTR(_7780)->length;
    }
    else {
        _7781 = 1;
    }
    _7780 = NOVALUE;
    {
        int _index_13681;
        _index_13681 = 1;
LC: 
        if (_index_13681 > _7781){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13659);
        _7782 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7782);
        _7783 = (int)*(((s1_ptr)_2)->base + _index_13681);
        _7782 = NOVALUE;
        if (binary_op_a(EQUALS, _7783, 0)){
            _7783 = NOVALUE;
            goto LE; // [262] 287
        }
        _7783 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13659);
        _7785 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7785);
        _7786 = (int)*(((s1_ptr)_2)->base + _index_13681);
        _7785 = NOVALUE;
        Ref(_7786);
        _2 = (int)SEQ_PTR(_results__13657);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13657 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13658);
        _1 = *(int *)_2;
        *(int *)_2 = _7786;
        if( _1 != _7786 ){
            DeRef(_1);
        }
        _7786 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13658 = _pos__13658 + 1;
LE: 

        /** 		end for*/
        _index_13681 = _index_13681 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_the_map_13629);
    DeRef(_keys_13630);
    DeRef(_default_values_13631);
    DeRef(_buckets__13655);
    DeRef(_bucket__13656);
    DeRef(_temp_map__13659);
    _7780 = NOVALUE;
    return _results__13657;
    ;
}
int values() __attribute__ ((alias ("_33values")));


int _33pairs(int _the_map_p_13693, int _sorted_result_13694)
{
    int _key_bucket__13695 = NOVALUE;
    int _value_bucket__13696 = NOVALUE;
    int _results__13697 = NOVALUE;
    int _pos__13698 = NOVALUE;
    int _temp_map__13699 = NOVALUE;
    int _7822 = NOVALUE;
    int _7820 = NOVALUE;
    int _7819 = NOVALUE;
    int _7817 = NOVALUE;
    int _7816 = NOVALUE;
    int _7815 = NOVALUE;
    int _7813 = NOVALUE;
    int _7811 = NOVALUE;
    int _7810 = NOVALUE;
    int _7809 = NOVALUE;
    int _7808 = NOVALUE;
    int _7806 = NOVALUE;
    int _7804 = NOVALUE;
    int _7803 = NOVALUE;
    int _7801 = NOVALUE;
    int _7800 = NOVALUE;
    int _7798 = NOVALUE;
    int _7796 = NOVALUE;
    int _7795 = NOVALUE;
    int _7794 = NOVALUE;
    int _7792 = NOVALUE;
    int _7790 = NOVALUE;
    int _7789 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sorted_result_13694)) {
        _1 = (long)(DBL_PTR(_sorted_result_13694)->dbl);
        DeRefDS(_sorted_result_13694);
        _sorted_result_13694 = _1;
    }

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13699);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13693)){
        _temp_map__13699 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13693)->dbl));
    }
    else{
        _temp_map__13699 = (int)*(((s1_ptr)_2)->base + _the_map_p_13693);
    }
    Ref(_temp_map__13699);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7789 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__13699);
    _7790 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13697);
    _results__13697 = Repeat(_7789, _7790);
    DeRefDS(_7789);
    _7789 = NOVALUE;
    _7790 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13698 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13699);
    _7792 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7792, 76)){
        _7792 = NOVALUE;
        goto L1; // [38] 147
    }
    _7792 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13699);
    _7794 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7794)){
            _7795 = SEQ_PTR(_7794)->length;
    }
    else {
        _7795 = 1;
    }
    _7794 = NOVALUE;
    {
        int _index_13708;
        _index_13708 = 1;
L2: 
        if (_index_13708 > _7795){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13699);
        _7796 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__13695);
        _2 = (int)SEQ_PTR(_7796);
        _key_bucket__13695 = (int)*(((s1_ptr)_2)->base + _index_13708);
        Ref(_key_bucket__13695);
        _7796 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13699);
        _7798 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__13696);
        _2 = (int)SEQ_PTR(_7798);
        _value_bucket__13696 = (int)*(((s1_ptr)_2)->base + _index_13708);
        Ref(_value_bucket__13696);
        _7798 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__13695)){
                _7800 = SEQ_PTR(_key_bucket__13695)->length;
        }
        else {
            _7800 = 1;
        }
        {
            int _j_13716;
            _j_13716 = 1;
L4: 
            if (_j_13716 > _7800){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13697);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13697 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13698 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__13695);
            _7803 = (int)*(((s1_ptr)_2)->base + _j_13716);
            Ref(_7803);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _7803;
            if( _1 != _7803 ){
                DeRef(_1);
            }
            _7803 = NOVALUE;
            _7801 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13697);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13697 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13698 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__13696);
            _7806 = (int)*(((s1_ptr)_2)->base + _j_13716);
            Ref(_7806);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _7806;
            if( _1 != _7806 ){
                DeRef(_1);
            }
            _7806 = NOVALUE;
            _7804 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__13698 = _pos__13698 + 1;

            /** 			end for*/
            _j_13716 = _j_13716 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_13708 = _index_13708 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13699);
    _7808 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7808)){
            _7809 = SEQ_PTR(_7808)->length;
    }
    else {
        _7809 = 1;
    }
    _7808 = NOVALUE;
    {
        int _index_13727;
        _index_13727 = 1;
L7: 
        if (_index_13727 > _7809){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13699);
        _7810 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7810);
        _7811 = (int)*(((s1_ptr)_2)->base + _index_13727);
        _7810 = NOVALUE;
        if (binary_op_a(EQUALS, _7811, 0)){
            _7811 = NOVALUE;
            goto L9; // [173] 222
        }
        _7811 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13697);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13697 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13698 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13699);
        _7815 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7815);
        _7816 = (int)*(((s1_ptr)_2)->base + _index_13727);
        _7815 = NOVALUE;
        Ref(_7816);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7816;
        if( _1 != _7816 ){
            DeRef(_1);
        }
        _7816 = NOVALUE;
        _7813 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13697);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13697 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13698 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13699);
        _7819 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7819);
        _7820 = (int)*(((s1_ptr)_2)->base + _index_13727);
        _7819 = NOVALUE;
        Ref(_7820);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7820;
        if( _1 != _7820 ){
            DeRef(_1);
        }
        _7820 = NOVALUE;
        _7817 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13698 = _pos__13698 + 1;
L9: 

        /** 		end for	*/
        _index_13727 = _index_13727 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_13694 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13697);
    _7822 = _24sort(_results__13697, 1);
    DeRef(_the_map_p_13693);
    DeRef(_key_bucket__13695);
    DeRef(_value_bucket__13696);
    DeRefDS(_results__13697);
    DeRef(_temp_map__13699);
    _7794 = NOVALUE;
    _7808 = NOVALUE;
    return _7822;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_13693);
    DeRef(_key_bucket__13695);
    DeRef(_value_bucket__13696);
    DeRef(_temp_map__13699);
    _7794 = NOVALUE;
    _7808 = NOVALUE;
    DeRef(_7822);
    _7822 = NOVALUE;
    return _results__13697;
LB: 
    ;
}
int pairs() __attribute__ ((alias ("_33pairs")));


void _33optimize(int _the_map_p_13748, int _max_p_13749, int _grow_p_13750)
{
    int _stats__13752 = NOVALUE;
    int _next_guess__13753 = NOVALUE;
    int _prev_guess_13754 = NOVALUE;
    int _7843 = NOVALUE;
    int _7842 = NOVALUE;
    int _7840 = NOVALUE;
    int _7839 = NOVALUE;
    int _7838 = NOVALUE;
    int _7837 = NOVALUE;
    int _7836 = NOVALUE;
    int _7834 = NOVALUE;
    int _7832 = NOVALUE;
    int _7831 = NOVALUE;
    int _7830 = NOVALUE;
    int _7829 = NOVALUE;
    int _7825 = NOVALUE;
    int _7824 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_p_13749)) {
        _1 = (long)(DBL_PTR(_max_p_13749)->dbl);
        DeRefDS(_max_p_13749);
        _max_p_13749 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13748)){
        _7824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13748)->dbl));
    }
    else{
        _7824 = (int)*(((s1_ptr)_2)->base + _the_map_p_13748);
    }
    _2 = (int)SEQ_PTR(_7824);
    _7825 = (int)*(((s1_ptr)_2)->base + 4);
    _7824 = NOVALUE;
    if (binary_op_a(NOTEQ, _7825, 76)){
        _7825 = NOVALUE;
        goto L1; // [15] 178
    }
    _7825 = NOVALUE;

    /** 		if grow_p < 1 then*/
    if (binary_op_a(GREATEREQ, _grow_p_13750, 1)){
        goto L2; // [21] 31
    }

    /** 			grow_p = 1.333*/
    RefDS(_7823);
    DeRef(_grow_p_13750);
    _grow_p_13750 = _7823;
L2: 

    /** 		if max_p < 3 then*/
    if (_max_p_13749 >= 3)
    goto L3; // [33] 43

    /** 			max_p = 3*/
    _max_p_13749 = 3;
L3: 

    /** 		next_guess_ = math:max({1, floor(eumem:ram_space[the_map_p][ELEMENT_COUNT] / max_p)})*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_the_map_p_13748)){
        _7829 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13748)->dbl));
    }
    else{
        _7829 = (int)*(((s1_ptr)_2)->base + _the_map_p_13748);
    }
    _2 = (int)SEQ_PTR(_7829);
    _7830 = (int)*(((s1_ptr)_2)->base + 2);
    _7829 = NOVALUE;
    if (IS_ATOM_INT(_7830)) {
        if (_max_p_13749 > 0 && _7830 >= 0) {
            _7831 = _7830 / _max_p_13749;
        }
        else {
            temp_dbl = floor((double)_7830 / (double)_max_p_13749);
            if (_7830 != MININT)
            _7831 = (long)temp_dbl;
            else
            _7831 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7830, _max_p_13749);
        _7831 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _7830 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _7831;
    _7832 = MAKE_SEQ(_1);
    _7831 = NOVALUE;
    _next_guess__13753 = _20max(_7832);
    _7832 = NOVALUE;
    if (!IS_ATOM_INT(_next_guess__13753)) {
        _1 = (long)(DBL_PTR(_next_guess__13753)->dbl);
        DeRefDS(_next_guess__13753);
        _next_guess__13753 = _1;
    }

    /** 		while 1 with entry do*/
    goto L4; // [71] 158
L5: 

    /** 			if stats_[LARGEST_BUCKET] <= max_p then*/
    _2 = (int)SEQ_PTR(_stats__13752);
    _7834 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(GREATER, _7834, _max_p_13749)){
        _7834 = NOVALUE;
        goto L6; // [82] 91
    }
    _7834 = NOVALUE;

    /** 				exit -- Largest is now smaller than the maximum I wanted.*/
    goto L7; // [88] 177
L6: 

    /** 			if stats_[LARGEST_BUCKET] <= (stats_[STDEV_BUCKET]*3 + stats_[AVERAGE_BUCKET]) then*/
    _2 = (int)SEQ_PTR(_stats__13752);
    _7836 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_stats__13752);
    _7837 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_ATOM_INT(_7837)) {
        if (_7837 == (short)_7837)
        _7838 = _7837 * 3;
        else
        _7838 = NewDouble(_7837 * (double)3);
    }
    else {
        _7838 = binary_op(MULTIPLY, _7837, 3);
    }
    _7837 = NOVALUE;
    _2 = (int)SEQ_PTR(_stats__13752);
    _7839 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_7838) && IS_ATOM_INT(_7839)) {
        _7840 = _7838 + _7839;
        if ((long)((unsigned long)_7840 + (unsigned long)HIGH_BITS) >= 0) 
        _7840 = NewDouble((double)_7840);
    }
    else {
        _7840 = binary_op(PLUS, _7838, _7839);
    }
    DeRef(_7838);
    _7838 = NOVALUE;
    _7839 = NOVALUE;
    if (binary_op_a(GREATER, _7836, _7840)){
        _7836 = NOVALUE;
        DeRef(_7840);
        _7840 = NOVALUE;
        goto L8; // [113] 122
    }
    _7836 = NOVALUE;
    DeRef(_7840);
    _7840 = NOVALUE;

    /** 				exit -- Largest is smaller than is statistically expected.*/
    goto L7; // [119] 177
L8: 

    /** 			prev_guess = next_guess_*/
    _prev_guess_13754 = _next_guess__13753;

    /** 			next_guess_ = floor(stats_[NUM_BUCKETS] * grow_p)*/
    _2 = (int)SEQ_PTR(_stats__13752);
    _7842 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7842) && IS_ATOM_INT(_grow_p_13750)) {
        if (_7842 == (short)_7842 && _grow_p_13750 <= INT15 && _grow_p_13750 >= -INT15)
        _7843 = _7842 * _grow_p_13750;
        else
        _7843 = NewDouble(_7842 * (double)_grow_p_13750);
    }
    else {
        _7843 = binary_op(MULTIPLY, _7842, _grow_p_13750);
    }
    _7842 = NOVALUE;
    if (IS_ATOM_INT(_7843))
    _next_guess__13753 = e_floor(_7843);
    else
    _next_guess__13753 = unary_op(FLOOR, _7843);
    DeRef(_7843);
    _7843 = NOVALUE;
    if (!IS_ATOM_INT(_next_guess__13753)) {
        _1 = (long)(DBL_PTR(_next_guess__13753)->dbl);
        DeRefDS(_next_guess__13753);
        _next_guess__13753 = _1;
    }

    /** 			if prev_guess = next_guess_ then*/
    if (_prev_guess_13754 != _next_guess__13753)
    goto L9; // [144] 155

    /** 				next_guess_ += 1*/
    _next_guess__13753 = _next_guess__13753 + 1;
L9: 

    /** 		entry*/
L4: 

    /** 			rehash(the_map_p, next_guess_)*/
    Ref(_the_map_p_13748);
    _33rehash(_the_map_p_13748, _next_guess__13753);

    /** 			stats_ = statistics(the_map_p)*/
    Ref(_the_map_p_13748);
    _0 = _stats__13752;
    _stats__13752 = _33statistics(_the_map_p_13748);
    DeRef(_0);

    /** 		end while*/
    goto L5; // [174] 74
L7: 
L1: 

    /** end procedure*/
    DeRef(_the_map_p_13748);
    DeRef(_grow_p_13750);
    DeRef(_stats__13752);
    return;
    ;
}
void optimize() __attribute__ ((alias ("_33optimize")));


int _33load_map(int _input_file_name_13788)
{
    int _file_handle_13789 = NOVALUE;
    int _line_in_13790 = NOVALUE;
    int _logical_line_13791 = NOVALUE;
    int _has_comment_13792 = NOVALUE;
    int _delim_pos_13793 = NOVALUE;
    int _data_value_13794 = NOVALUE;
    int _data_key_13795 = NOVALUE;
    int _conv_res_13796 = NOVALUE;
    int _new_map_13797 = NOVALUE;
    int _line_conts_13798 = NOVALUE;
    int _value_inlined_value_at_217_13843 = NOVALUE;
    int _value_inlined_value_at_297_13858 = NOVALUE;
    int _seek_1__tmp_at517_13896 = NOVALUE;
    int _seek_inlined_seek_at_517_13895 = NOVALUE;
    int _7924 = NOVALUE;
    int _7923 = NOVALUE;
    int _7922 = NOVALUE;
    int _7921 = NOVALUE;
    int _7916 = NOVALUE;
    int _7914 = NOVALUE;
    int _7913 = NOVALUE;
    int _7905 = NOVALUE;
    int _7904 = NOVALUE;
    int _7903 = NOVALUE;
    int _7902 = NOVALUE;
    int _7898 = NOVALUE;
    int _7897 = NOVALUE;
    int _7894 = NOVALUE;
    int _7893 = NOVALUE;
    int _7892 = NOVALUE;
    int _7889 = NOVALUE;
    int _7888 = NOVALUE;
    int _7886 = NOVALUE;
    int _7883 = NOVALUE;
    int _7882 = NOVALUE;
    int _7881 = NOVALUE;
    int _7878 = NOVALUE;
    int _7877 = NOVALUE;
    int _7875 = NOVALUE;
    int _7873 = NOVALUE;
    int _7872 = NOVALUE;
    int _7867 = NOVALUE;
    int _7865 = NOVALUE;
    int _7864 = NOVALUE;
    int _7861 = NOVALUE;
    int _7857 = NOVALUE;
    int _7855 = NOVALUE;
    int _7849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence line_conts =   ",${"*/
    RefDS(_7848);
    DeRefi(_line_conts_13798);
    _line_conts_13798 = _7848;

    /** 	if sequence(input_file_name) then*/
    _7849 = IS_SEQUENCE(_input_file_name_13788);
    if (_7849 == 0)
    {
        _7849 = NOVALUE;
        goto L1; // [13] 26
    }
    else{
        _7849 = NOVALUE;
    }

    /** 		file_handle = open(input_file_name, "rb")*/
    _file_handle_13789 = EOpen(_input_file_name_13788, _1284, 0);
    goto L2; // [23] 34
L1: 

    /** 		file_handle = input_file_name*/
    Ref(_input_file_name_13788);
    _file_handle_13789 = _input_file_name_13788;
    if (!IS_ATOM_INT(_file_handle_13789)) {
        _1 = (long)(DBL_PTR(_file_handle_13789)->dbl);
        DeRefDS(_file_handle_13789);
        _file_handle_13789 = _1;
    }
L2: 

    /** 	if file_handle = -1 then*/
    if (_file_handle_13789 != -1)
    goto L3; // [38] 49

    /** 		return -1*/
    DeRef(_input_file_name_13788);
    DeRef(_line_in_13790);
    DeRef(_logical_line_13791);
    DeRef(_data_value_13794);
    DeRef(_data_key_13795);
    DeRef(_conv_res_13796);
    DeRef(_new_map_13797);
    DeRefi(_line_conts_13798);
    return -1;
L3: 

    /** 	new_map = new(threshold_size) -- Assume a small map initially.*/
    _0 = _new_map_13797;
    _new_map_13797 = _33new(_33threshold_size_12820);
    DeRef(_0);

    /** 	for i = 1 to 10 do*/
    {
        int _i_13808;
        _i_13808 = 1;
L4: 
        if (_i_13808 > 10){
            goto L5; // [59] 118
        }

        /** 		delim_pos = getc(file_handle)*/
        if (_file_handle_13789 != last_r_file_no) {
            last_r_file_ptr = which_file(_file_handle_13789, EF_READ);
            last_r_file_no = _file_handle_13789;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _delim_pos_13793 = getc((FILE*)xstdin);
            }
            else
            _delim_pos_13793 = getc(last_r_file_ptr);
        }
        else
        _delim_pos_13793 = getc(last_r_file_ptr);

        /** 		if delim_pos = -1 then */
        if (_delim_pos_13793 != -1)
        goto L6; // [73] 82

        /** 			exit*/
        goto L5; // [79] 118
L6: 

        /** 		if not t_print(delim_pos) then */
        _7855 = _7t_print(_delim_pos_13793);
        if (IS_ATOM_INT(_7855)) {
            if (_7855 != 0){
                DeRef(_7855);
                _7855 = NOVALUE;
                goto L7; // [88] 106
            }
        }
        else {
            if (DBL_PTR(_7855)->dbl != 0.0){
                DeRef(_7855);
                _7855 = NOVALUE;
                goto L7; // [88] 106
            }
        }
        DeRef(_7855);
        _7855 = NOVALUE;

        /** 	    	if not t_space(delim_pos) then*/
        _7857 = _7t_space(_delim_pos_13793);
        if (IS_ATOM_INT(_7857)) {
            if (_7857 != 0){
                DeRef(_7857);
                _7857 = NOVALUE;
                goto L8; // [97] 105
            }
        }
        else {
            if (DBL_PTR(_7857)->dbl != 0.0){
                DeRef(_7857);
                _7857 = NOVALUE;
                goto L8; // [97] 105
            }
        }
        DeRef(_7857);
        _7857 = NOVALUE;

        /** 	    		exit*/
        goto L5; // [102] 118
L8: 
L7: 

        /** 	    delim_pos = -1*/
        _delim_pos_13793 = -1;

        /** 	end for*/
        _i_13808 = _i_13808 + 1;
        goto L4; // [113] 66
L5: 
        ;
    }

    /** 	if delim_pos = -1 then*/
    if (_delim_pos_13793 != -1)
    goto L9; // [122] 513

    /** 		close(file_handle)*/
    EClose(_file_handle_13789);

    /** 		file_handle = open(input_file_name, "r")*/
    _file_handle_13789 = EOpen(_input_file_name_13788, _1217, 0);

    /** 		while sequence(logical_line) with entry do*/
    goto LA; // [139] 357
LB: 
    _7861 = IS_SEQUENCE(_logical_line_13791);
    if (_7861 == 0)
    {
        _7861 = NOVALUE;
        goto LC; // [147] 652
    }
    else{
        _7861 = NOVALUE;
    }

    /** 			delim_pos = find('=', logical_line)*/
    _delim_pos_13793 = find_from(61, _logical_line_13791, 1);

    /** 			if delim_pos > 0 then*/
    if (_delim_pos_13793 <= 0)
    goto LD; // [159] 354

    /** 				data_key = text:trim(logical_line[1..delim_pos-1])*/
    _7864 = _delim_pos_13793 - 1;
    rhs_slice_target = (object_ptr)&_7865;
    RHS_Slice(_logical_line_13791, 1, _7864);
    RefDS(_4498);
    _0 = _data_key_13795;
    _data_key_13795 = _6trim(_7865, _4498, 0);
    DeRef(_0);
    _7865 = NOVALUE;

    /** 				if length(data_key) > 0 then*/
    if (IS_SEQUENCE(_data_key_13795)){
            _7867 = SEQ_PTR(_data_key_13795)->length;
    }
    else {
        _7867 = 1;
    }
    if (_7867 <= 0)
    goto LE; // [185] 353

    /** 					data_key = search:match_replace("\\-", data_key, "-")*/
    RefDS(_7869);
    Ref(_data_key_13795);
    RefDS(_7870);
    _0 = _data_key_13795;
    _data_key_13795 = _9match_replace(_7869, _data_key_13795, _7870, 0);
    DeRef(_0);

    /** 					if not t_alpha(data_key[1]) then*/
    _2 = (int)SEQ_PTR(_data_key_13795);
    _7872 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7872);
    _7873 = _7t_alpha(_7872);
    _7872 = NOVALUE;
    if (IS_ATOM_INT(_7873)) {
        if (_7873 != 0){
            DeRef(_7873);
            _7873 = NOVALUE;
            goto LF; // [208] 262
        }
    }
    else {
        if (DBL_PTR(_7873)->dbl != 0.0){
            DeRef(_7873);
            _7873 = NOVALUE;
            goto LF; // [208] 262
        }
    }
    DeRef(_7873);
    _7873 = NOVALUE;

    /** 						conv_res = stdget:value(data_key,,stdget:GET_LONG_ANSWER)*/
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3241)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3241)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3241);
        _17GET_LONG_ANSWER_3241 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_data_key_13795);
    _0 = _conv_res_13796;
    _conv_res_13796 = _17get_value(_data_key_13795, 1, _17GET_LONG_ANSWER_3241);
    DeRef(_0);

    /** 						if conv_res[1] = stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _7875 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _7875, 0)){
        _7875 = NOVALUE;
        goto L10; // [236] 261
    }
    _7875 = NOVALUE;

    /** 							if conv_res[3] = length(data_key) then*/
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _7877 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_data_key_13795)){
            _7878 = SEQ_PTR(_data_key_13795)->length;
    }
    else {
        _7878 = 1;
    }
    if (binary_op_a(NOTEQ, _7877, _7878)){
        _7877 = NOVALUE;
        _7878 = NOVALUE;
        goto L11; // [249] 260
    }
    _7877 = NOVALUE;
    _7878 = NOVALUE;

    /** 								data_key = conv_res[2]*/
    DeRef(_data_key_13795);
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _data_key_13795 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_key_13795);
L11: 
L10: 
LF: 

    /** 					data_value = text:trim(logical_line[delim_pos+1..$])*/
    _7881 = _delim_pos_13793 + 1;
    if (_7881 > MAXINT){
        _7881 = NewDouble((double)_7881);
    }
    if (IS_SEQUENCE(_logical_line_13791)){
            _7882 = SEQ_PTR(_logical_line_13791)->length;
    }
    else {
        _7882 = 1;
    }
    rhs_slice_target = (object_ptr)&_7883;
    RHS_Slice(_logical_line_13791, _7881, _7882);
    RefDS(_4498);
    _0 = _data_value_13794;
    _data_value_13794 = _6trim(_7883, _4498, 0);
    DeRef(_0);
    _7883 = NOVALUE;

    /** 					data_value = search:match_replace("\\-", data_value, "-")*/
    RefDS(_7869);
    Ref(_data_value_13794);
    RefDS(_7870);
    _0 = _data_value_13794;
    _data_value_13794 = _9match_replace(_7869, _data_value_13794, _7870, 0);
    DeRef(_0);

    /** 					conv_res = stdget:value(data_value,,stdget:GET_LONG_ANSWER)*/
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3241)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3241)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3241);
        _17GET_LONG_ANSWER_3241 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_data_value_13794);
    _0 = _conv_res_13796;
    _conv_res_13796 = _17get_value(_data_value_13794, 1, _17GET_LONG_ANSWER_3241);
    DeRef(_0);

    /** 					if conv_res[1] = stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _7886 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _7886, 0)){
        _7886 = NOVALUE;
        goto L12; // [316] 341
    }
    _7886 = NOVALUE;

    /** 						if conv_res[3] = length(data_value) then*/
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _7888 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_data_value_13794)){
            _7889 = SEQ_PTR(_data_value_13794)->length;
    }
    else {
        _7889 = 1;
    }
    if (binary_op_a(NOTEQ, _7888, _7889)){
        _7888 = NOVALUE;
        _7889 = NOVALUE;
        goto L13; // [329] 340
    }
    _7888 = NOVALUE;
    _7889 = NOVALUE;

    /** 							data_value = conv_res[2]*/
    DeRef(_data_value_13794);
    _2 = (int)SEQ_PTR(_conv_res_13796);
    _data_value_13794 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_value_13794);
L13: 
L12: 

    /** 					put(new_map, data_key, data_value)*/
    Ref(_new_map_13797);
    Ref(_data_key_13795);
    Ref(_data_value_13794);
    _33put(_new_map_13797, _data_key_13795, _data_value_13794, 1, _33threshold_size_12820);
LE: 
LD: 

    /** 		entry*/
LA: 

    /** 			logical_line = -1*/
    DeRef(_logical_line_13791);
    _logical_line_13791 = -1;

    /** 			while sequence(line_in) with entry do*/
    goto L14; // [364] 495
L15: 
    _7892 = IS_SEQUENCE(_line_in_13790);
    if (_7892 == 0)
    {
        _7892 = NOVALUE;
        goto LB; // [372] 142
    }
    else{
        _7892 = NOVALUE;
    }

    /** 				if atom(logical_line) then*/
    _7893 = IS_ATOM(_logical_line_13791);
    if (_7893 == 0)
    {
        _7893 = NOVALUE;
        goto L16; // [380] 389
    }
    else{
        _7893 = NOVALUE;
    }

    /** 					logical_line = ""*/
    RefDS(_5);
    DeRef(_logical_line_13791);
    _logical_line_13791 = _5;
L16: 

    /** 				has_comment = search:rmatch("--", line_in)*/
    if (IS_SEQUENCE(_line_in_13790)){
            _7894 = SEQ_PTR(_line_in_13790)->length;
    }
    else {
        _7894 = 1;
    }
    RefDS(_6651);
    Ref(_line_in_13790);
    _has_comment_13792 = _9rmatch(_6651, _line_in_13790, _7894);
    _7894 = NOVALUE;
    if (!IS_ATOM_INT(_has_comment_13792)) {
        _1 = (long)(DBL_PTR(_has_comment_13792)->dbl);
        DeRefDS(_has_comment_13792);
        _has_comment_13792 = _1;
    }

    /** 				if has_comment != 0 then*/
    if (_has_comment_13792 == 0)
    goto L17; // [404] 428

    /** 					line_in = text:trim(line_in[1..has_comment-1])*/
    _7897 = _has_comment_13792 - 1;
    rhs_slice_target = (object_ptr)&_7898;
    RHS_Slice(_line_in_13790, 1, _7897);
    RefDS(_4498);
    _0 = _line_in_13790;
    _line_in_13790 = _6trim(_7898, _4498, 0);
    DeRef(_0);
    _7898 = NOVALUE;
    goto L18; // [425] 437
L17: 

    /** 					line_in = text:trim(line_in)*/
    Ref(_line_in_13790);
    RefDS(_4498);
    _0 = _line_in_13790;
    _line_in_13790 = _6trim(_line_in_13790, _4498, 0);
    DeRef(_0);
L18: 

    /** 				logical_line &= line_in*/
    if (IS_SEQUENCE(_logical_line_13791) && IS_ATOM(_line_in_13790)) {
        Ref(_line_in_13790);
        Append(&_logical_line_13791, _logical_line_13791, _line_in_13790);
    }
    else if (IS_ATOM(_logical_line_13791) && IS_SEQUENCE(_line_in_13790)) {
        Ref(_logical_line_13791);
        Prepend(&_logical_line_13791, _line_in_13790, _logical_line_13791);
    }
    else {
        Concat((object_ptr)&_logical_line_13791, _logical_line_13791, _line_in_13790);
    }

    /** 				if length(line_in) then*/
    if (IS_SEQUENCE(_line_in_13790)){
            _7902 = SEQ_PTR(_line_in_13790)->length;
    }
    else {
        _7902 = 1;
    }
    if (_7902 == 0)
    {
        _7902 = NOVALUE;
        goto L19; // [448] 492
    }
    else{
        _7902 = NOVALUE;
    }

    /** 					if not find(line_in[$], line_conts) then*/
    if (IS_SEQUENCE(_line_in_13790)){
            _7903 = SEQ_PTR(_line_in_13790)->length;
    }
    else {
        _7903 = 1;
    }
    _2 = (int)SEQ_PTR(_line_in_13790);
    _7904 = (int)*(((s1_ptr)_2)->base + _7903);
    _7905 = find_from(_7904, _line_conts_13798, 1);
    _7904 = NOVALUE;
    if (_7905 != 0)
    goto L1A; // [465] 491
    _7905 = NOVALUE;

    /** 						logical_line = search:match_replace(`",$"`, logical_line, "")*/
    RefDS(_7907);
    RefDS(_logical_line_13791);
    RefDS(_5);
    _0 = _logical_line_13791;
    _logical_line_13791 = _9match_replace(_7907, _logical_line_13791, _5, 0);
    DeRefDS(_0);

    /** 						logical_line = search:match_replace(`,$`, logical_line, "")*/
    RefDS(_7909);
    Ref(_logical_line_13791);
    RefDS(_5);
    _0 = _logical_line_13791;
    _logical_line_13791 = _9match_replace(_7909, _logical_line_13791, _5, 0);
    DeRef(_0);

    /** 						exit*/
    goto LB; // [488] 142
L1A: 
L19: 

    /** 			entry*/
L14: 

    /** 				line_in = gets(file_handle)*/
    DeRef(_line_in_13790);
    _line_in_13790 = EGets(_file_handle_13789);

    /** 			end while*/
    goto L15; // [502] 367

    /** 		end while*/
    goto LB; // [507] 142
    goto LC; // [510] 652
L9: 

    /** 		io:seek(file_handle, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at517_13896);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_handle_13789;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at517_13896 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_517_13895 = machine(19, _seek_1__tmp_at517_13896);
    DeRefi(_seek_1__tmp_at517_13896);
    _seek_1__tmp_at517_13896 = NOVALUE;

    /** 		line_in  = serialize:deserialize(file_handle)*/
    _0 = _line_in_13790;
    _line_in_13790 = _27deserialize(_file_handle_13789, 1);
    DeRef(_0);

    /** 		if atom(line_in) then*/
    _7913 = IS_ATOM(_line_in_13790);
    if (_7913 == 0)
    {
        _7913 = NOVALUE;
        goto L1B; // [540] 550
    }
    else{
        _7913 = NOVALUE;
    }

    /** 			return -2*/
    DeRef(_input_file_name_13788);
    DeRef(_line_in_13790);
    DeRef(_logical_line_13791);
    DeRef(_data_value_13794);
    DeRef(_data_key_13795);
    DeRef(_conv_res_13796);
    DeRef(_new_map_13797);
    DeRefi(_line_conts_13798);
    DeRef(_7864);
    _7864 = NOVALUE;
    DeRef(_7881);
    _7881 = NOVALUE;
    DeRef(_7897);
    _7897 = NOVALUE;
    return -2;
L1B: 

    /** 		if length(line_in) > 1 then*/
    if (IS_SEQUENCE(_line_in_13790)){
            _7914 = SEQ_PTR(_line_in_13790)->length;
    }
    else {
        _7914 = 1;
    }
    if (_7914 <= 1)
    goto L1C; // [555] 644

    /** 			switch line_in[1] do*/
    _2 = (int)SEQ_PTR(_line_in_13790);
    _7916 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_7916) ){
        goto L1D; // [565] 632
    }
    if(!IS_ATOM_INT(_7916)){
        if( (DBL_PTR(_7916)->dbl != (double) ((int) DBL_PTR(_7916)->dbl) ) ){
            goto L1D; // [565] 632
        }
        _0 = (int) DBL_PTR(_7916)->dbl;
    }
    else {
        _0 = _7916;
    };
    _7916 = NOVALUE;
    switch ( _0 ){ 

        /** 				case 1, 2 then*/
        case 1:
        case 2:

        /** 					data_key   = serialize:deserialize(file_handle)*/
        _0 = _data_key_13795;
        _data_key_13795 = _27deserialize(_file_handle_13789, 1);
        DeRef(_0);

        /** 					data_value =  serialize:deserialize(file_handle)*/
        _0 = _data_value_13794;
        _data_value_13794 = _27deserialize(_file_handle_13789, 1);
        DeRef(_0);

        /** 					for i = 1 to length(data_key) do*/
        if (IS_SEQUENCE(_data_key_13795)){
                _7921 = SEQ_PTR(_data_key_13795)->length;
        }
        else {
            _7921 = 1;
        }
        {
            int _i_13910;
            _i_13910 = 1;
L1E: 
            if (_i_13910 > _7921){
                goto L1F; // [595] 628
            }

            /** 						put(new_map, data_key[i], data_value[i])*/
            _2 = (int)SEQ_PTR(_data_key_13795);
            _7922 = (int)*(((s1_ptr)_2)->base + _i_13910);
            _2 = (int)SEQ_PTR(_data_value_13794);
            _7923 = (int)*(((s1_ptr)_2)->base + _i_13910);
            Ref(_new_map_13797);
            Ref(_7922);
            Ref(_7923);
            _33put(_new_map_13797, _7922, _7923, 1, _33threshold_size_12820);
            _7922 = NOVALUE;
            _7923 = NOVALUE;

            /** 					end for*/
            _i_13910 = _i_13910 + 1;
            goto L1E; // [623] 602
L1F: 
            ;
        }
        goto L20; // [628] 651

        /** 				case else*/
        default:
L1D: 

        /** 					return -2*/
        DeRef(_input_file_name_13788);
        DeRef(_line_in_13790);
        DeRef(_logical_line_13791);
        DeRef(_data_value_13794);
        DeRef(_data_key_13795);
        DeRef(_conv_res_13796);
        DeRef(_new_map_13797);
        DeRefi(_line_conts_13798);
        DeRef(_7864);
        _7864 = NOVALUE;
        DeRef(_7881);
        _7881 = NOVALUE;
        DeRef(_7897);
        _7897 = NOVALUE;
        return -2;
    ;}    goto L20; // [641] 651
L1C: 

    /** 			return -2*/
    DeRef(_input_file_name_13788);
    DeRef(_line_in_13790);
    DeRef(_logical_line_13791);
    DeRef(_data_value_13794);
    DeRef(_data_key_13795);
    DeRef(_conv_res_13796);
    DeRef(_new_map_13797);
    DeRefi(_line_conts_13798);
    DeRef(_7864);
    _7864 = NOVALUE;
    DeRef(_7881);
    _7881 = NOVALUE;
    DeRef(_7897);
    _7897 = NOVALUE;
    return -2;
L20: 
LC: 

    /** 	if sequence(input_file_name) then*/
    _7924 = IS_SEQUENCE(_input_file_name_13788);
    if (_7924 == 0)
    {
        _7924 = NOVALUE;
        goto L21; // [657] 665
    }
    else{
        _7924 = NOVALUE;
    }

    /** 		close(file_handle)*/
    EClose(_file_handle_13789);
L21: 

    /** 	optimize(new_map)*/
    Ref(_new_map_13797);
    RefDS(_7823);
    _33optimize(_new_map_13797, _33threshold_size_12820, _7823);

    /** 	return new_map*/
    DeRef(_input_file_name_13788);
    DeRef(_line_in_13790);
    DeRef(_logical_line_13791);
    DeRef(_data_value_13794);
    DeRef(_data_key_13795);
    DeRef(_conv_res_13796);
    DeRefi(_line_conts_13798);
    DeRef(_7864);
    _7864 = NOVALUE;
    DeRef(_7881);
    _7881 = NOVALUE;
    DeRef(_7897);
    _7897 = NOVALUE;
    return _new_map_13797;
    ;
}
int load_map() __attribute__ ((alias ("_33load_map")));


int _33save_map(int _the_map__13922, int _file_name_p_13923, int _type__13924)
{
    int _file_handle__13925 = NOVALUE;
    int _keys__13926 = NOVALUE;
    int _values__13927 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_174_13960 = NOVALUE;
    int _options_inlined_pretty_sprint_at_171_13959 = NOVALUE;
    int _x_inlined_pretty_sprint_at_168_13958 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_243_13968 = NOVALUE;
    int _options_inlined_pretty_sprint_at_240_13967 = NOVALUE;
    int _x_inlined_pretty_sprint_at_237_13966 = NOVALUE;
    int _7955 = NOVALUE;
    int _7954 = NOVALUE;
    int _7953 = NOVALUE;
    int _7952 = NOVALUE;
    int _7951 = NOVALUE;
    int _7949 = NOVALUE;
    int _7948 = NOVALUE;
    int _7947 = NOVALUE;
    int _7946 = NOVALUE;
    int _7945 = NOVALUE;
    int _7944 = NOVALUE;
    int _7943 = NOVALUE;
    int _7942 = NOVALUE;
    int _7941 = NOVALUE;
    int _7940 = NOVALUE;
    int _7939 = NOVALUE;
    int _7938 = NOVALUE;
    int _7937 = NOVALUE;
    int _7936 = NOVALUE;
    int _7935 = NOVALUE;
    int _7933 = NOVALUE;
    int _7925 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type__13924)) {
        _1 = (long)(DBL_PTR(_type__13924)->dbl);
        DeRefDS(_type__13924);
        _type__13924 = _1;
    }

    /** 	integer file_handle_ = -2*/
    _file_handle__13925 = -2;

    /** 	if sequence(file_name_p) then*/
    _7925 = IS_SEQUENCE(_file_name_p_13923);
    if (_7925 == 0)
    {
        _7925 = NOVALUE;
        goto L1; // [13] 43
    }
    else{
        _7925 = NOVALUE;
    }

    /** 		if type_ = SM_TEXT then*/
    if (_type__13924 != 1)
    goto L2; // [18] 32

    /** 			file_handle_ = open(file_name_p, "w")*/
    _file_handle__13925 = EOpen(_file_name_p_13923, _1272, 0);
    goto L3; // [29] 51
L2: 

    /** 			file_handle_ = open(file_name_p, "wb")*/
    _file_handle__13925 = EOpen(_file_name_p_13923, _1325, 0);
    goto L3; // [40] 51
L1: 

    /** 		file_handle_ = file_name_p*/
    Ref(_file_name_p_13923);
    _file_handle__13925 = _file_name_p_13923;
    if (!IS_ATOM_INT(_file_handle__13925)) {
        _1 = (long)(DBL_PTR(_file_handle__13925)->dbl);
        DeRefDS(_file_handle__13925);
        _file_handle__13925 = _1;
    }
L3: 

    /** 	if file_handle_ < 0 then*/
    if (_file_handle__13925 >= 0)
    goto L4; // [53] 64

    /** 		return -1*/
    DeRef(_the_map__13922);
    DeRef(_file_name_p_13923);
    DeRef(_keys__13926);
    DeRef(_values__13927);
    return -1;
L4: 

    /** 	keys_ = keys(the_map_)*/
    Ref(_the_map__13922);
    _0 = _keys__13926;
    _keys__13926 = _33keys(_the_map__13922, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    Ref(_the_map__13922);
    _0 = _values__13927;
    _values__13927 = _33values(_the_map__13922, 0, 0);
    DeRef(_0);

    /** 	if type_ = SM_RAW then*/
    if (_type__13924 != 2)
    goto L5; // [85] 137

    /** 		puts(file_handle_, serialize:serialize({*/
    _7933 = _12now_gmt();
    RefDS(_7934);
    _7935 = _12format(_7933, _7934);
    _7933 = NOVALUE;
    _7936 = _3version_string(0);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = _7935;
    *((int *)(_2+12)) = _7936;
    _7937 = MAKE_SEQ(_1);
    _7936 = NOVALUE;
    _7935 = NOVALUE;
    _7938 = _27serialize(_7937);
    _7937 = NOVALUE;
    EPuts(_file_handle__13925, _7938); // DJP 
    DeRef(_7938);
    _7938 = NOVALUE;

    /** 		puts(file_handle_, serialize:serialize(keys_))*/
    RefDS(_keys__13926);
    _7939 = _27serialize(_keys__13926);
    EPuts(_file_handle__13925, _7939); // DJP 
    DeRef(_7939);
    _7939 = NOVALUE;

    /** 		puts(file_handle_, serialize:serialize(values_))*/
    RefDS(_values__13927);
    _7940 = _27serialize(_values__13927);
    EPuts(_file_handle__13925, _7940); // DJP 
    DeRef(_7940);
    _7940 = NOVALUE;
    goto L6; // [134] 313
L5: 

    /** 		for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__13926)){
            _7941 = SEQ_PTR(_keys__13926)->length;
    }
    else {
        _7941 = 1;
    }
    {
        int _i_13953;
        _i_13953 = 1;
L7: 
        if (_i_13953 > _7941){
            goto L8; // [142] 312
        }

        /** 			keys_[i] = pretty:pretty_sprint(keys_[i], {2,0,1,0,"%d","%.15g",32,127,1,0})*/
        _2 = (int)SEQ_PTR(_keys__13926);
        _7942 = (int)*(((s1_ptr)_2)->base + _i_13953);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 2;
        *((int *)(_2+8)) = 0;
        *((int *)(_2+12)) = 1;
        *((int *)(_2+16)) = 0;
        RefDS(_919);
        *((int *)(_2+20)) = _919;
        RefDS(_5942);
        *((int *)(_2+24)) = _5942;
        *((int *)(_2+28)) = 32;
        *((int *)(_2+32)) = 127;
        *((int *)(_2+36)) = 1;
        *((int *)(_2+40)) = 0;
        _7943 = MAKE_SEQ(_1);
        Ref(_7942);
        DeRef(_x_inlined_pretty_sprint_at_168_13958);
        _x_inlined_pretty_sprint_at_168_13958 = _7942;
        _7942 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_171_13959);
        _options_inlined_pretty_sprint_at_171_13959 = _7943;
        _7943 = NOVALUE;

        /** 	pretty_printing = 0*/
        _26pretty_printing_8582 = 0;

        /** 	pretty( x, options )*/
        Ref(_x_inlined_pretty_sprint_at_168_13958);
        RefDS(_options_inlined_pretty_sprint_at_171_13959);
        _26pretty(_x_inlined_pretty_sprint_at_168_13958, _options_inlined_pretty_sprint_at_171_13959);

        /** 	return pretty_line*/
        RefDS(_26pretty_line_8585);
        DeRef(_pretty_sprint_inlined_pretty_sprint_at_174_13960);
        _pretty_sprint_inlined_pretty_sprint_at_174_13960 = _26pretty_line_8585;
        DeRef(_x_inlined_pretty_sprint_at_168_13958);
        _x_inlined_pretty_sprint_at_168_13958 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_171_13959);
        _options_inlined_pretty_sprint_at_171_13959 = NOVALUE;
        RefDS(_pretty_sprint_inlined_pretty_sprint_at_174_13960);
        _2 = (int)SEQ_PTR(_keys__13926);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys__13926 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13953);
        _1 = *(int *)_2;
        *(int *)_2 = _pretty_sprint_inlined_pretty_sprint_at_174_13960;
        DeRef(_1);

        /** 			keys_[i] = search:match_replace("-", keys_[i], "\\-")*/
        _2 = (int)SEQ_PTR(_keys__13926);
        _7944 = (int)*(((s1_ptr)_2)->base + _i_13953);
        RefDS(_7870);
        Ref(_7944);
        RefDS(_7869);
        _7945 = _9match_replace(_7870, _7944, _7869, 0);
        _7944 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys__13926);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys__13926 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13953);
        _1 = *(int *)_2;
        *(int *)_2 = _7945;
        if( _1 != _7945 ){
            DeRef(_1);
        }
        _7945 = NOVALUE;

        /** 			values_[i] = pretty:pretty_sprint(values_[i], {2,0,1,0,"%d","%.15g",32,127,1,0})*/
        _2 = (int)SEQ_PTR(_values__13927);
        _7946 = (int)*(((s1_ptr)_2)->base + _i_13953);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 2;
        *((int *)(_2+8)) = 0;
        *((int *)(_2+12)) = 1;
        *((int *)(_2+16)) = 0;
        RefDS(_919);
        *((int *)(_2+20)) = _919;
        RefDS(_5942);
        *((int *)(_2+24)) = _5942;
        *((int *)(_2+28)) = 32;
        *((int *)(_2+32)) = 127;
        *((int *)(_2+36)) = 1;
        *((int *)(_2+40)) = 0;
        _7947 = MAKE_SEQ(_1);
        Ref(_7946);
        DeRef(_x_inlined_pretty_sprint_at_237_13966);
        _x_inlined_pretty_sprint_at_237_13966 = _7946;
        _7946 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_240_13967);
        _options_inlined_pretty_sprint_at_240_13967 = _7947;
        _7947 = NOVALUE;

        /** 	pretty_printing = 0*/
        _26pretty_printing_8582 = 0;

        /** 	pretty( x, options )*/
        Ref(_x_inlined_pretty_sprint_at_237_13966);
        RefDS(_options_inlined_pretty_sprint_at_240_13967);
        _26pretty(_x_inlined_pretty_sprint_at_237_13966, _options_inlined_pretty_sprint_at_240_13967);

        /** 	return pretty_line*/
        RefDS(_26pretty_line_8585);
        DeRef(_pretty_sprint_inlined_pretty_sprint_at_243_13968);
        _pretty_sprint_inlined_pretty_sprint_at_243_13968 = _26pretty_line_8585;
        DeRef(_x_inlined_pretty_sprint_at_237_13966);
        _x_inlined_pretty_sprint_at_237_13966 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_240_13967);
        _options_inlined_pretty_sprint_at_240_13967 = NOVALUE;
        RefDS(_pretty_sprint_inlined_pretty_sprint_at_243_13968);
        _2 = (int)SEQ_PTR(_values__13927);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values__13927 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13953);
        _1 = *(int *)_2;
        *(int *)_2 = _pretty_sprint_inlined_pretty_sprint_at_243_13968;
        DeRef(_1);

        /** 			values_[i] = search:match_replace("-", values_[i], "\\-")*/
        _2 = (int)SEQ_PTR(_values__13927);
        _7948 = (int)*(((s1_ptr)_2)->base + _i_13953);
        RefDS(_7870);
        Ref(_7948);
        RefDS(_7869);
        _7949 = _9match_replace(_7870, _7948, _7869, 0);
        _7948 = NOVALUE;
        _2 = (int)SEQ_PTR(_values__13927);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values__13927 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13953);
        _1 = *(int *)_2;
        *(int *)_2 = _7949;
        if( _1 != _7949 ){
            DeRef(_1);
        }
        _7949 = NOVALUE;

        /** 			printf(file_handle_, "%s = %s\n", {keys_[i], values_[i]})*/
        _2 = (int)SEQ_PTR(_keys__13926);
        _7951 = (int)*(((s1_ptr)_2)->base + _i_13953);
        _2 = (int)SEQ_PTR(_values__13927);
        _7952 = (int)*(((s1_ptr)_2)->base + _i_13953);
        Ref(_7952);
        Ref(_7951);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _7951;
        ((int *)_2)[2] = _7952;
        _7953 = MAKE_SEQ(_1);
        _7952 = NOVALUE;
        _7951 = NOVALUE;
        EPrintf(_file_handle__13925, _7950, _7953);
        DeRefDS(_7953);
        _7953 = NOVALUE;

        /** 		end for*/
        _i_13953 = _i_13953 + 1;
        goto L7; // [307] 149
L8: 
        ;
    }
L6: 

    /** 	if sequence(file_name_p) then*/
    _7954 = IS_SEQUENCE(_file_name_p_13923);
    if (_7954 == 0)
    {
        _7954 = NOVALUE;
        goto L9; // [318] 326
    }
    else{
        _7954 = NOVALUE;
    }

    /** 		close(file_handle_)*/
    EClose(_file_handle__13925);
L9: 

    /** 	return length(keys_)*/
    if (IS_SEQUENCE(_keys__13926)){
            _7955 = SEQ_PTR(_keys__13926)->length;
    }
    else {
        _7955 = 1;
    }
    DeRef(_the_map__13922);
    DeRef(_file_name_p_13923);
    DeRefDS(_keys__13926);
    DeRef(_values__13927);
    return _7955;
    ;
}
int save_map() __attribute__ ((alias ("_33save_map")));


int _33copy(int _source_map_13980, int _dest_map_13981, int _put_operation_13982)
{
    int _keys_set_13985 = NOVALUE;
    int _value_set_13986 = NOVALUE;
    int _source_data_13987 = NOVALUE;
    int _temp_map_14019 = NOVALUE;
    int _7979 = NOVALUE;
    int _7977 = NOVALUE;
    int _7976 = NOVALUE;
    int _7975 = NOVALUE;
    int _7974 = NOVALUE;
    int _7972 = NOVALUE;
    int _7971 = NOVALUE;
    int _7970 = NOVALUE;
    int _7969 = NOVALUE;
    int _7968 = NOVALUE;
    int _7967 = NOVALUE;
    int _7966 = NOVALUE;
    int _7964 = NOVALUE;
    int _7962 = NOVALUE;
    int _7961 = NOVALUE;
    int _7960 = NOVALUE;
    int _7958 = NOVALUE;
    int _7956 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_put_operation_13982)) {
        _1 = (long)(DBL_PTR(_put_operation_13982)->dbl);
        DeRefDS(_put_operation_13982);
        _put_operation_13982 = _1;
    }

    /** 	if map(dest_map) then*/
    Ref(_dest_map_13981);
    _7956 = _33map(_dest_map_13981);
    if (_7956 == 0) {
        DeRef(_7956);
        _7956 = NOVALUE;
        goto L1; // [9] 203
    }
    else {
        if (!IS_ATOM_INT(_7956) && DBL_PTR(_7956)->dbl == 0.0){
            DeRef(_7956);
            _7956 = NOVALUE;
            goto L1; // [9] 203
        }
        DeRef(_7956);
        _7956 = NOVALUE;
    }
    DeRef(_7956);
    _7956 = NOVALUE;

    /** 		sequence keys_set*/

    /** 		sequence value_set		*/

    /** 		sequence source_data*/

    /** 		source_data = eumem:ram_space[source_map]	*/
    DeRef(_source_data_13987);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_source_map_13980)){
        _source_data_13987 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_source_map_13980)->dbl));
    }
    else{
        _source_data_13987 = (int)*(((s1_ptr)_2)->base + _source_map_13980);
    }
    Ref(_source_data_13987);

    /** 		if source_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_source_data_13987);
    _7958 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7958, 76)){
        _7958 = NOVALUE;
        goto L2; // [34] 126
    }
    _7958 = NOVALUE;

    /** 			for index = 1 to length(source_data[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_source_data_13987);
    _7960 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7960)){
            _7961 = SEQ_PTR(_7960)->length;
    }
    else {
        _7961 = 1;
    }
    _7960 = NOVALUE;
    {
        int _index_13993;
        _index_13993 = 1;
L3: 
        if (_index_13993 > _7961){
            goto L4; // [47] 123
        }

        /** 				keys_set = source_data[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_source_data_13987);
        _7962 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_keys_set_13985);
        _2 = (int)SEQ_PTR(_7962);
        _keys_set_13985 = (int)*(((s1_ptr)_2)->base + _index_13993);
        Ref(_keys_set_13985);
        _7962 = NOVALUE;

        /** 				value_set = source_data[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_source_data_13987);
        _7964 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_set_13986);
        _2 = (int)SEQ_PTR(_7964);
        _value_set_13986 = (int)*(((s1_ptr)_2)->base + _index_13993);
        Ref(_value_set_13986);
        _7964 = NOVALUE;

        /** 				for j = 1 to length(keys_set) do*/
        if (IS_SEQUENCE(_keys_set_13985)){
                _7966 = SEQ_PTR(_keys_set_13985)->length;
        }
        else {
            _7966 = 1;
        }
        {
            int _j_14001;
            _j_14001 = 1;
L5: 
            if (_j_14001 > _7966){
                goto L6; // [83] 116
            }

            /** 					put(dest_map, keys_set[j], value_set[j], put_operation)*/
            _2 = (int)SEQ_PTR(_keys_set_13985);
            _7967 = (int)*(((s1_ptr)_2)->base + _j_14001);
            _2 = (int)SEQ_PTR(_value_set_13986);
            _7968 = (int)*(((s1_ptr)_2)->base + _j_14001);
            Ref(_dest_map_13981);
            Ref(_7967);
            Ref(_7968);
            _33put(_dest_map_13981, _7967, _7968, _put_operation_13982, _33threshold_size_12820);
            _7967 = NOVALUE;
            _7968 = NOVALUE;

            /** 				end for*/
            _j_14001 = _j_14001 + 1;
            goto L5; // [111] 90
L6: 
            ;
        }

        /** 			end for*/
        _index_13993 = _index_13993 + 1;
        goto L3; // [118] 54
L4: 
        ;
    }
    goto L7; // [123] 192
L2: 

    /** 			for index = 1 to length(source_data[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_source_data_13987);
    _7969 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7969)){
            _7970 = SEQ_PTR(_7969)->length;
    }
    else {
        _7970 = 1;
    }
    _7969 = NOVALUE;
    {
        int _index_14007;
        _index_14007 = 1;
L8: 
        if (_index_14007 > _7970){
            goto L9; // [135] 191
        }

        /** 				if source_data[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_source_data_13987);
        _7971 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7971);
        _7972 = (int)*(((s1_ptr)_2)->base + _index_14007);
        _7971 = NOVALUE;
        if (binary_op_a(EQUALS, _7972, 0)){
            _7972 = NOVALUE;
            goto LA; // [152] 184
        }
        _7972 = NOVALUE;

        /** 					put(dest_map, source_data[KEY_LIST][index], */
        _2 = (int)SEQ_PTR(_source_data_13987);
        _7974 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7974);
        _7975 = (int)*(((s1_ptr)_2)->base + _index_14007);
        _7974 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_data_13987);
        _7976 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7976);
        _7977 = (int)*(((s1_ptr)_2)->base + _index_14007);
        _7976 = NOVALUE;
        Ref(_dest_map_13981);
        Ref(_7975);
        Ref(_7977);
        _33put(_dest_map_13981, _7975, _7977, _put_operation_13982, _33threshold_size_12820);
        _7975 = NOVALUE;
        _7977 = NOVALUE;
LA: 

        /** 			end for*/
        _index_14007 = _index_14007 + 1;
        goto L8; // [186] 142
L9: 
        ;
    }
L7: 

    /** 		return dest_map*/
    DeRef(_keys_set_13985);
    DeRef(_value_set_13986);
    DeRef(_source_data_13987);
    DeRef(_source_map_13980);
    _7960 = NOVALUE;
    _7969 = NOVALUE;
    return _dest_map_13981;
    goto LB; // [200] 233
L1: 

    /** 		atom temp_map = eumem:malloc()*/
    _0 = _temp_map_14019;
    _temp_map_14019 = _28malloc(1, 1);
    DeRef(_0);

    /** 	 	eumem:ram_space[temp_map] = eumem:ram_space[source_map]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_source_map_13980)){
        _7979 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_source_map_13980)->dbl));
    }
    else{
        _7979 = (int)*(((s1_ptr)_2)->base + _source_map_13980);
    }
    Ref(_7979);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map_14019))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map_14019)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map_14019);
    _1 = *(int *)_2;
    *(int *)_2 = _7979;
    if( _1 != _7979 ){
        DeRef(_1);
    }
    _7979 = NOVALUE;

    /** 		return temp_map*/
    DeRef(_source_map_13980);
    DeRef(_dest_map_13981);
    _7960 = NOVALUE;
    _7969 = NOVALUE;
    return _temp_map_14019;
    DeRef(_temp_map_14019);
    _temp_map_14019 = NOVALUE;
LB: 
    ;
}
int copy() __attribute__ ((alias ("_33copy")));


int _33new_from_kvpairs(int _kv_pairs_14024)
{
    int _new_map_14025 = NOVALUE;
    int _7991 = NOVALUE;
    int _7990 = NOVALUE;
    int _7989 = NOVALUE;
    int _7988 = NOVALUE;
    int _7986 = NOVALUE;
    int _7985 = NOVALUE;
    int _7984 = NOVALUE;
    int _7982 = NOVALUE;
    int _7981 = NOVALUE;
    int _7980 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_map = new( floor(7 * length(kv_pairs) / 2) )*/
    if (IS_SEQUENCE(_kv_pairs_14024)){
            _7980 = SEQ_PTR(_kv_pairs_14024)->length;
    }
    else {
        _7980 = 1;
    }
    if (_7980 <= INT15)
    _7981 = 7 * _7980;
    else
    _7981 = NewDouble(7 * (double)_7980);
    _7980 = NOVALUE;
    if (IS_ATOM_INT(_7981)) {
        _7982 = _7981 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _7981, 2);
        _7982 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_7981);
    _7981 = NOVALUE;
    _0 = _new_map_14025;
    _new_map_14025 = _33new(_7982);
    DeRef(_0);
    _7982 = NOVALUE;

    /** 	for i = 1 to length(kv_pairs) do*/
    if (IS_SEQUENCE(_kv_pairs_14024)){
            _7984 = SEQ_PTR(_kv_pairs_14024)->length;
    }
    else {
        _7984 = 1;
    }
    {
        int _i_14031;
        _i_14031 = 1;
L1: 
        if (_i_14031 > _7984){
            goto L2; // [25] 80
        }

        /** 		if length(kv_pairs[i]) = 2 then*/
        _2 = (int)SEQ_PTR(_kv_pairs_14024);
        _7985 = (int)*(((s1_ptr)_2)->base + _i_14031);
        if (IS_SEQUENCE(_7985)){
                _7986 = SEQ_PTR(_7985)->length;
        }
        else {
            _7986 = 1;
        }
        _7985 = NOVALUE;
        if (_7986 != 2)
        goto L3; // [41] 73

        /** 			put(new_map, kv_pairs[i][1], kv_pairs[i][2])*/
        _2 = (int)SEQ_PTR(_kv_pairs_14024);
        _7988 = (int)*(((s1_ptr)_2)->base + _i_14031);
        _2 = (int)SEQ_PTR(_7988);
        _7989 = (int)*(((s1_ptr)_2)->base + 1);
        _7988 = NOVALUE;
        _2 = (int)SEQ_PTR(_kv_pairs_14024);
        _7990 = (int)*(((s1_ptr)_2)->base + _i_14031);
        _2 = (int)SEQ_PTR(_7990);
        _7991 = (int)*(((s1_ptr)_2)->base + 2);
        _7990 = NOVALUE;
        Ref(_new_map_14025);
        Ref(_7989);
        Ref(_7991);
        _33put(_new_map_14025, _7989, _7991, 1, _33threshold_size_12820);
        _7989 = NOVALUE;
        _7991 = NOVALUE;
L3: 

        /** 	end for*/
        _i_14031 = _i_14031 + 1;
        goto L1; // [75] 32
L2: 
        ;
    }

    /** 	return new_map	*/
    DeRefDS(_kv_pairs_14024);
    _7985 = NOVALUE;
    return _new_map_14025;
    ;
}
int new_from_kvpairs() __attribute__ ((alias ("_33new_from_kvpairs")));


int _33new_from_string(int _kv_string_14043)
{
    int _7993 = NOVALUE;
    int _7992 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return new_from_kvpairs( text:keyvalues (kv_string) )*/
    RefDS(_kv_string_14043);
    RefDS(_5298);
    RefDS(_5299);
    RefDS(_5300);
    RefDS(_307);
    _7992 = _6keyvalues(_kv_string_14043, _5298, _5299, _5300, _307, 1);
    _7993 = _33new_from_kvpairs(_7992);
    _7992 = NOVALUE;
    DeRefDS(_kv_string_14043);
    return _7993;
    ;
}
int new_from_string() __attribute__ ((alias ("_33new_from_string")));


int _33for_each(int _source_map_14048, int _user_rid_14049, int _user_data_14050, int _in_sorted_order_14051, int _signal_boundary_14052)
{
    int _lKV_14053 = NOVALUE;
    int _lRes_14054 = NOVALUE;
    int _progress_code_14055 = NOVALUE;
    int _8012 = NOVALUE;
    int _8010 = NOVALUE;
    int _8009 = NOVALUE;
    int _8008 = NOVALUE;
    int _8007 = NOVALUE;
    int _8006 = NOVALUE;
    int _8004 = NOVALUE;
    int _8003 = NOVALUE;
    int _8002 = NOVALUE;
    int _8001 = NOVALUE;
    int _8000 = NOVALUE;
    int _7999 = NOVALUE;
    int _7998 = NOVALUE;
    int _7997 = NOVALUE;
    int _7996 = NOVALUE;
    int _7995 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_user_rid_14049)) {
        _1 = (long)(DBL_PTR(_user_rid_14049)->dbl);
        DeRefDS(_user_rid_14049);
        _user_rid_14049 = _1;
    }
    if (!IS_ATOM_INT(_in_sorted_order_14051)) {
        _1 = (long)(DBL_PTR(_in_sorted_order_14051)->dbl);
        DeRefDS(_in_sorted_order_14051);
        _in_sorted_order_14051 = _1;
    }
    if (!IS_ATOM_INT(_signal_boundary_14052)) {
        _1 = (long)(DBL_PTR(_signal_boundary_14052)->dbl);
        DeRefDS(_signal_boundary_14052);
        _signal_boundary_14052 = _1;
    }

    /** 	lKV = pairs(source_map, in_sorted_order)	*/
    Ref(_source_map_14048);
    _0 = _lKV_14053;
    _lKV_14053 = _33pairs(_source_map_14048, _in_sorted_order_14051);
    DeRef(_0);

    /** 	if length(lKV) = 0 and signal_boundary != 0 then*/
    if (IS_SEQUENCE(_lKV_14053)){
            _7995 = SEQ_PTR(_lKV_14053)->length;
    }
    else {
        _7995 = 1;
    }
    _7996 = (_7995 == 0);
    _7995 = NOVALUE;
    if (_7996 == 0) {
        goto L1; // [25] 55
    }
    _7998 = (_signal_boundary_14052 != 0);
    if (_7998 == 0)
    {
        DeRef(_7998);
        _7998 = NOVALUE;
        goto L1; // [34] 55
    }
    else{
        DeRef(_7998);
        _7998 = NOVALUE;
    }

    /** 		return call_func(user_rid, {0,0,user_data,0} )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    Ref(_user_data_14050);
    *((int *)(_2+12)) = _user_data_14050;
    *((int *)(_2+16)) = 0;
    _7999 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_7999);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_user_rid_14049].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    Ref(*(int *)(_2+16));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4), 
                        *(int *)(_2+8), 
                        *(int *)(_2+12), 
                        *(int *)(_2+16)
                         );
    DeRef(_8000);
    _8000 = _1;
    DeRefDS(_7999);
    _7999 = NOVALUE;
    DeRef(_source_map_14048);
    DeRef(_user_data_14050);
    DeRef(_lKV_14053);
    DeRef(_lRes_14054);
    DeRef(_7996);
    _7996 = NOVALUE;
    return _8000;
L1: 

    /** 	for i = 1 to length(lKV) do*/
    if (IS_SEQUENCE(_lKV_14053)){
            _8001 = SEQ_PTR(_lKV_14053)->length;
    }
    else {
        _8001 = 1;
    }
    {
        int _i_14065;
        _i_14065 = 1;
L2: 
        if (_i_14065 > _8001){
            goto L3; // [60] 154
        }

        /** 		if i = length(lKV) and signal_boundary then*/
        if (IS_SEQUENCE(_lKV_14053)){
                _8002 = SEQ_PTR(_lKV_14053)->length;
        }
        else {
            _8002 = 1;
        }
        _8003 = (_i_14065 == _8002);
        _8002 = NOVALUE;
        if (_8003 == 0) {
            goto L4; // [76] 94
        }
        if (_signal_boundary_14052 == 0)
        {
            goto L4; // [81] 94
        }
        else{
        }

        /** 			progress_code = -i*/
        _progress_code_14055 = - _i_14065;
        goto L5; // [91] 100
L4: 

        /** 			progress_code = i*/
        _progress_code_14055 = _i_14065;
L5: 

        /** 		lRes = call_func(user_rid, {lKV[i][1], lKV[i][2], user_data, progress_code})*/
        _2 = (int)SEQ_PTR(_lKV_14053);
        _8006 = (int)*(((s1_ptr)_2)->base + _i_14065);
        _2 = (int)SEQ_PTR(_8006);
        _8007 = (int)*(((s1_ptr)_2)->base + 1);
        _8006 = NOVALUE;
        _2 = (int)SEQ_PTR(_lKV_14053);
        _8008 = (int)*(((s1_ptr)_2)->base + _i_14065);
        _2 = (int)SEQ_PTR(_8008);
        _8009 = (int)*(((s1_ptr)_2)->base + 2);
        _8008 = NOVALUE;
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_8007);
        *((int *)(_2+4)) = _8007;
        Ref(_8009);
        *((int *)(_2+8)) = _8009;
        Ref(_user_data_14050);
        *((int *)(_2+12)) = _user_data_14050;
        *((int *)(_2+16)) = _progress_code_14055;
        _8010 = MAKE_SEQ(_1);
        _8009 = NOVALUE;
        _8007 = NOVALUE;
        _1 = (int)SEQ_PTR(_8010);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_user_rid_14049].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        Ref(*(int *)(_2+12));
        Ref(*(int *)(_2+16));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12), 
                            *(int *)(_2+16)
                             );
        DeRef(_lRes_14054);
        _lRes_14054 = _1;
        DeRefDS(_8010);
        _8010 = NOVALUE;

        /** 		if not equal(lRes, 0) then*/
        if (_lRes_14054 == 0)
        _8012 = 1;
        else if (IS_ATOM_INT(_lRes_14054) && IS_ATOM_INT(0))
        _8012 = 0;
        else
        _8012 = (compare(_lRes_14054, 0) == 0);
        if (_8012 != 0)
        goto L6; // [137] 147
        _8012 = NOVALUE;

        /** 			return lRes*/
        DeRef(_source_map_14048);
        DeRef(_user_data_14050);
        DeRefDS(_lKV_14053);
        DeRef(_7996);
        _7996 = NOVALUE;
        DeRef(_8003);
        _8003 = NOVALUE;
        DeRef(_8000);
        _8000 = NOVALUE;
        return _lRes_14054;
L6: 

        /** 	end for*/
        _i_14065 = _i_14065 + 1;
        goto L2; // [149] 67
L3: 
        ;
    }

    /** 	return 0*/
    DeRef(_source_map_14048);
    DeRef(_user_data_14050);
    DeRef(_lKV_14053);
    DeRef(_lRes_14054);
    DeRef(_7996);
    _7996 = NOVALUE;
    DeRef(_8003);
    _8003 = NOVALUE;
    DeRef(_8000);
    _8000 = NOVALUE;
    return 0;
    ;
}
int for_each() __attribute__ ((alias ("_33for_each")));


void _33convert_to_large_map(int _the_map__14084)
{
    int _temp_map__14085 = NOVALUE;
    int _map_handle__14086 = NOVALUE;
    int _8025 = NOVALUE;
    int _8024 = NOVALUE;
    int _8023 = NOVALUE;
    int _8022 = NOVALUE;
    int _8021 = NOVALUE;
    int _8019 = NOVALUE;
    int _8018 = NOVALUE;
    int _8017 = NOVALUE;
    int _8016 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__14085);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _temp_map__14085 = (int)*(((s1_ptr)_2)->base + _the_map__14084);
    Ref(_temp_map__14085);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__14086;
    _map_handle__14086 = _33new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__14085);
    _8016 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_8016)){
            _8017 = SEQ_PTR(_8016)->length;
    }
    else {
        _8017 = 1;
    }
    _8016 = NOVALUE;
    {
        int _index_14090;
        _index_14090 = 1;
L1: 
        if (_index_14090 > _8017){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__14085);
        _8018 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_8018);
        _8019 = (int)*(((s1_ptr)_2)->base + _index_14090);
        _8018 = NOVALUE;
        if (binary_op_a(EQUALS, _8019, 0)){
            _8019 = NOVALUE;
            goto L3; // [45] 77
        }
        _8019 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__14085);
        _8021 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_8021);
        _8022 = (int)*(((s1_ptr)_2)->base + _index_14090);
        _8021 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__14085);
        _8023 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_8023);
        _8024 = (int)*(((s1_ptr)_2)->base + _index_14090);
        _8023 = NOVALUE;
        Ref(_map_handle__14086);
        Ref(_8022);
        Ref(_8024);
        _33put(_map_handle__14086, _8022, _8024, 1, _33threshold_size_12820);
        _8022 = NOVALUE;
        _8024 = NOVALUE;
L3: 

        /** 	end for*/
        _index_14090 = _index_14090 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_map_handle__14086)){
        _8025 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__14086)->dbl));
    }
    else{
        _8025 = (int)*(((s1_ptr)_2)->base + _map_handle__14086);
    }
    Ref(_8025);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14084);
    _1 = *(int *)_2;
    *(int *)_2 = _8025;
    if( _1 != _8025 ){
        DeRef(_1);
    }
    _8025 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__14085);
    DeRef(_map_handle__14086);
    _8016 = NOVALUE;
    return;
    ;
}


void _33convert_to_small_map(int _the_map__14104)
{
    int _keys__14105 = NOVALUE;
    int _values__14106 = NOVALUE;
    int _8034 = NOVALUE;
    int _8033 = NOVALUE;
    int _8032 = NOVALUE;
    int _8031 = NOVALUE;
    int _8030 = NOVALUE;
    int _8029 = NOVALUE;
    int _8028 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__14104)) {
        _1 = (long)(DBL_PTR(_the_map__14104)->dbl);
        DeRefDS(_the_map__14104);
        _the_map__14104 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__14105;
    _keys__14105 = _33keys(_the_map__14104, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__14106;
    _values__14106 = _33values(_the_map__14104, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _8028 = Repeat(_33init_small_map_key_12821, _33threshold_size_12820);
    _8029 = Repeat(0, _33threshold_size_12820);
    _8030 = Repeat(0, _33threshold_size_12820);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12806);
    *((int *)(_2+4)) = _33type_is_map_12806;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _8028;
    *((int *)(_2+24)) = _8029;
    *((int *)(_2+28)) = _8030;
    _8031 = MAKE_SEQ(_1);
    _8030 = NOVALUE;
    _8029 = NOVALUE;
    _8028 = NOVALUE;
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14104);
    _1 = *(int *)_2;
    *(int *)_2 = _8031;
    if( _1 != _8031 ){
        DeRef(_1);
    }
    _8031 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__14105)){
            _8032 = SEQ_PTR(_keys__14105)->length;
    }
    else {
        _8032 = 1;
    }
    {
        int _i_14114;
        _i_14114 = 1;
L1: 
        if (_i_14114 > _8032){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__14105);
        _8033 = (int)*(((s1_ptr)_2)->base + _i_14114);
        _2 = (int)SEQ_PTR(_values__14106);
        _8034 = (int)*(((s1_ptr)_2)->base + _i_14114);
        Ref(_8033);
        Ref(_8034);
        _33put(_the_map__14104, _8033, _8034, 1, 0);
        _8033 = NOVALUE;
        _8034 = NOVALUE;

        /** 	end for*/
        _i_14114 = _i_14114 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__14105);
    DeRef(_values__14106);
    return;
    ;
}



// 0x94B289BC
