// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _1set_return_linked_list(int _i_23966)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_23966)) {
        _1 = (long)(DBL_PTR(_i_23966)->dbl);
        DeRefDS(_i_23966);
        _i_23966 = _1;
    }

    /** 	always_linked_list = i*/
    _58always_linked_list_23632 = _i_23966;

    /** end procedure*/
    return;
    ;
}
void set_return_linked_list() __attribute__ ((alias ("_1set_return_linked_list")));


int _1get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _58always_linked_list_23632;
    ;
}
int get_return_linked_list() __attribute__ ((alias ("_1get_return_linked_list")));


int _1get_version()
{
    int _0, _1, _2;
    

    /** 	return VERSION*/
    return 3;
    ;
}
int get_version() __attribute__ ((alias ("_1get_version")));


void _1init()
{
    int _0, _1, _2;
    

    /** 	high_address = 0*/
    _1high_address_23974 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef(_1data_23975);
    _1data_23975 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef(_1free_list_23976);
    _1free_list_23976 = _5;

    /** end procedure*/
    return;
    ;
}
void init() __attribute__ ((alias ("_1init")));


int _1get_high_address()
{
    int _0, _1, _2;
    

    /** 	return high_address*/
    return _1high_address_23974;
    ;
}
int get_high_address() __attribute__ ((alias ("_1get_high_address")));


int _1set_high_address(int _ma_23984)
{
    int _13272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_23984)) {
        if (65536 > 0 && _ma_23984 >= 0) {
            _1high_address_23974 = _ma_23984 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_23984 / (double)65536);
            _1high_address_23974 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_23984, 65536);
        _1high_address_23974 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_23974)) {
        _1 = (long)(DBL_PTR(_1high_address_23974)->dbl);
        DeRefDS(_1high_address_23974);
        _1high_address_23974 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    if (IS_ATOM_INT(_ma_23984)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_23984 & (unsigned long)65535;
             _13272 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _13272 = Dand_bits(DBL_PTR(_ma_23984), &temp_d);
    }
    DeRef(_ma_23984);
    return _13272;
    ;
}


int _1get_address(int _low_23989, int _high_23990)
{
    int _13274 = NOVALUE;
    int _13273 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_23989)) {
        _1 = (long)(DBL_PTR(_low_23989)->dbl);
        DeRefDS(_low_23989);
        _low_23989 = _1;
    }
    if (!IS_ATOM_INT(_high_23990)) {
        _1 = (long)(DBL_PTR(_high_23990)->dbl);
        DeRefDS(_high_23990);
        _high_23990 = _1;
    }

    /** 	return high * #00010000 + low*/
    _13273 = NewDouble(_high_23990 * (double)65536);
    if (IS_ATOM_INT(_13273)) {
        _13274 = _13273 + _low_23989;
        if ((long)((unsigned long)_13274 + (unsigned long)HIGH_BITS) >= 0) 
        _13274 = NewDouble((double)_13274);
    }
    else {
        _13274 = NewDouble(DBL_PTR(_13273)->dbl + (double)_low_23989);
    }
    DeRef(_13273);
    _13273 = NOVALUE;
    return _13274;
    ;
}


int _1register_data(int _ob_23995)
{
    int _i_23996 = NOVALUE;
    int _ret_23997 = NOVALUE;
    int _a_23998 = NOVALUE;
    int _s_23999 = NOVALUE;
    int _13286 = NOVALUE;
    int _13283 = NOVALUE;
    int _13281 = NOVALUE;
    int _13280 = NOVALUE;
    int _13279 = NOVALUE;
    int _13277 = NOVALUE;
    int _13275 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_23976)){
            _13275 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13275 = 1;
    }
    if (_13275 == 0)
    {
        _13275 = NOVALUE;
        goto L1; // [8] 106
    }
    else{
        _13275 = NOVALUE;
    }

    /** 		ret = free_list[1]*/
    _2 = (int)SEQ_PTR(_1free_list_23976);
    _ret_23997 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_ret_23997))
    _ret_23997 = (long)DBL_PTR(_ret_23997)->dbl;

    /** 		free_list = free_list[2..length(free_list)]*/
    if (IS_SEQUENCE(_1free_list_23976)){
            _13277 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13277 = 1;
    }
    rhs_slice_target = (object_ptr)&_1free_list_23976;
    RHS_Slice(_1free_list_23976, 2, _13277);

    /** 		if integer(ob) then*/
    if (IS_ATOM_INT(_ob_23995))
    _13279 = 1;
    else if (IS_ATOM_DBL(_ob_23995))
    _13279 = IS_ATOM_INT(DoubleToInt(_ob_23995));
    else
    _13279 = 0;
    if (_13279 == 0)
    {
        _13279 = NOVALUE;
        goto L2; // [38] 59
    }
    else{
        _13279 = NOVALUE;
    }

    /** 			i = ob*/
    Ref(_ob_23995);
    _i_23996 = _ob_23995;
    if (!IS_ATOM_INT(_i_23996)) {
        _1 = (long)(DBL_PTR(_i_23996)->dbl);
        DeRefDS(_i_23996);
        _i_23996 = _1;
    }

    /** 			data[ret] = i*/
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_23997);
    _1 = *(int *)_2;
    *(int *)_2 = _i_23996;
    DeRef(_1);
    goto L3; // [56] 99
L2: 

    /** 		elsif atom(ob) then*/
    _13280 = IS_ATOM(_ob_23995);
    if (_13280 == 0)
    {
        _13280 = NOVALUE;
        goto L4; // [64] 83
    }
    else{
        _13280 = NOVALUE;
    }

    /** 			a = ob*/
    Ref(_ob_23995);
    DeRef(_a_23998);
    _a_23998 = _ob_23995;

    /** 			data[ret] = a*/
    Ref(_a_23998);
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_23997);
    _1 = *(int *)_2;
    *(int *)_2 = _a_23998;
    DeRef(_1);
    goto L3; // [80] 99
L4: 

    /** 			s = ob*/
    Ref(_ob_23995);
    DeRef(_s_23999);
    _s_23999 = _ob_23995;

    /** 			data[ret] = s*/
    RefDS(_s_23999);
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_23997);
    _1 = *(int *)_2;
    *(int *)_2 = _s_23999;
    DeRef(_1);
L3: 

    /** 		return ret*/
    DeRef(_ob_23995);
    DeRef(_a_23998);
    DeRef(_s_23999);
    return _ret_23997;
L1: 

    /** 	if integer(ob) then*/
    if (IS_ATOM_INT(_ob_23995))
    _13281 = 1;
    else if (IS_ATOM_DBL(_ob_23995))
    _13281 = IS_ATOM_INT(DoubleToInt(_ob_23995));
    else
    _13281 = 0;
    if (_13281 == 0)
    {
        _13281 = NOVALUE;
        goto L5; // [111] 132
    }
    else{
        _13281 = NOVALUE;
    }

    /** 		i = ob*/
    Ref(_ob_23995);
    _i_23996 = _ob_23995;
    if (!IS_ATOM_INT(_i_23996)) {
        _1 = (long)(DBL_PTR(_i_23996)->dbl);
        DeRefDS(_i_23996);
        _i_23996 = _1;
    }

    /** 		data = append(data, i)*/
    Append(&_1data_23975, _1data_23975, _i_23996);
    goto L6; // [129] 172
L5: 

    /** 	elsif atom(ob) then*/
    _13283 = IS_ATOM(_ob_23995);
    if (_13283 == 0)
    {
        _13283 = NOVALUE;
        goto L7; // [137] 156
    }
    else{
        _13283 = NOVALUE;
    }

    /** 		a = ob*/
    Ref(_ob_23995);
    DeRef(_a_23998);
    _a_23998 = _ob_23995;

    /** 		data = append(data, a)*/
    Ref(_a_23998);
    Append(&_1data_23975, _1data_23975, _a_23998);
    goto L6; // [153] 172
L7: 

    /** 		s = ob*/
    Ref(_ob_23995);
    DeRef(_s_23999);
    _s_23999 = _ob_23995;

    /** 		data = append(data, s)*/
    RefDS(_s_23999);
    Append(&_1data_23975, _1data_23975, _s_23999);
L6: 

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_23975)){
            _13286 = SEQ_PTR(_1data_23975)->length;
    }
    else {
        _13286 = 1;
    }
    DeRef(_ob_23995);
    DeRef(_a_23998);
    DeRef(_s_23999);
    return _13286;
    ;
}


int _1retval(int _ob_24021)
{
    int _13287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return register_data(ob)*/
    Ref(_ob_24021);
    _13287 = _1register_data(_ob_24021);
    DeRef(_ob_24021);
    return _13287;
    ;
}


int _1length_of_data()
{
    int _13288 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(data)*/
    if (IS_SEQUENCE(_1data_23975)){
            _13288 = SEQ_PTR(_1data_23975)->length;
    }
    else {
        _13288 = 1;
    }
    return _13288;
    ;
}
int length_of_data() __attribute__ ((alias ("_1length_of_data")));


int _1is_free(int _id_24028)
{
    int _13290 = NOVALUE;
    int _13289 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24028)) {
        _1 = (long)(DBL_PTR(_id_24028)->dbl);
        DeRefDS(_id_24028);
        _id_24028 = _1;
    }

    /** 	return find(id, free_list) and 1 -- boolean*/
    _13289 = find_from(_id_24028, _1free_list_23976, 1);
    _13290 = (_13289 != 0 && 1 != 0);
    _13289 = NOVALUE;
    return _13290;
    ;
}
int is_free() __attribute__ ((alias ("_1is_free")));


int _1access_free_list()
{
    int _set_high_address_inlined_set_high_address_at_41_24041 = NOVALUE;
    int _ma_24033 = NOVALUE;
    int _13293 = NOVALUE;
    int _13292 = NOVALUE;
    int _13291 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = 0*/
    DeRef(_ma_24033);
    _ma_24033 = 0;

    /** 	if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_23976)){
            _13291 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13291 = 1;
    }
    if (_13291 == 0)
    {
        _13291 = NOVALUE;
        goto L1; // [13] 40
    }
    else{
        _13291 = NOVALUE;
    }

    /** 		ma = allocate(length(free_list) * 4)*/
    if (IS_SEQUENCE(_1free_list_23976)){
            _13292 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13292 = 1;
    }
    if (_13292 == (short)_13292)
    _13293 = _13292 * 4;
    else
    _13293 = NewDouble(_13292 * (double)4);
    _13292 = NOVALUE;
    _ma_24033 = _14allocate(_13293, 0);
    _13293 = NOVALUE;

    /** 		poke4(ma, free_list)*/
    if (IS_ATOM_INT(_ma_24033)){
        poke4_addr = (unsigned long *)_ma_24033;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_24033)->dbl);
    }
    _1 = (int)SEQ_PTR(_1free_list_23976);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
L1: 

    /** 	return set_high_address(ma)*/

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_24033)) {
        if (65536 > 0 && _ma_24033 >= 0) {
            _1high_address_23974 = _ma_24033 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_24033 / (double)65536);
            _1high_address_23974 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_24033, 65536);
        _1high_address_23974 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_23974)) {
        _1 = (long)(DBL_PTR(_1high_address_23974)->dbl);
        DeRefDS(_1high_address_23974);
        _1high_address_23974 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_41_24041);
    if (IS_ATOM_INT(_ma_24033)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_24033 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_41_24041 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)65535;
        _set_high_address_inlined_set_high_address_at_41_24041 = Dand_bits(DBL_PTR(_ma_24033), &temp_d);
    }
    DeRef(_ma_24033);
    return _set_high_address_inlined_set_high_address_at_41_24041;
    ;
}
int access_free_list() __attribute__ ((alias ("_1access_free_list")));


void _1generic_free(int _low_24044, int _high_24045)
{
    int _ma_24046 = NOVALUE;
    int _get_address_1__tmp_at6_24049 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24048 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24044)) {
        _1 = (long)(DBL_PTR(_low_24044)->dbl);
        DeRefDS(_low_24044);
        _low_24044 = _1;
    }
    if (!IS_ATOM_INT(_high_24045)) {
        _1 = (long)(DBL_PTR(_high_24045)->dbl);
        DeRefDS(_high_24045);
        _high_24045 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24049);
    _get_address_1__tmp_at6_24049 = NewDouble(_high_24045 * (double)65536);
    DeRef(_ma_24046);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24049)) {
        _ma_24046 = _get_address_1__tmp_at6_24049 + _low_24044;
        if ((long)((unsigned long)_ma_24046 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_24046 = NewDouble((double)_ma_24046);
    }
    else {
        _ma_24046 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24049)->dbl + (double)_low_24044);
    }
    DeRef(_get_address_1__tmp_at6_24049);
    _get_address_1__tmp_at6_24049 = NOVALUE;

    /** 	if ma then*/
    if (_ma_24046 == 0) {
        goto L1; // [22] 31
    }
    else {
        if (!IS_ATOM_INT(_ma_24046) && DBL_PTR(_ma_24046)->dbl == 0.0){
            goto L1; // [22] 31
        }
    }

    /** 		free(ma)*/
    Ref(_ma_24046);
    _14free(_ma_24046);
L1: 

    /** end procedure*/
    DeRef(_ma_24046);
    return;
    ;
}
void generic_free() __attribute__ ((alias ("_1generic_free")));


void _1delete_linked_list(int _id_24054)
{
    int _pos_24055 = NOVALUE;
    int _13313 = NOVALUE;
    int _13312 = NOVALUE;
    int _13310 = NOVALUE;
    int _13309 = NOVALUE;
    int _13307 = NOVALUE;
    int _13306 = NOVALUE;
    int _13305 = NOVALUE;
    int _13304 = NOVALUE;
    int _13302 = NOVALUE;
    int _13301 = NOVALUE;
    int _13300 = NOVALUE;
    int _13299 = NOVALUE;
    int _13298 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24054)) {
        _1 = (long)(DBL_PTR(_id_24054)->dbl);
        DeRefDS(_id_24054);
        _id_24054 = _1;
    }

    /** 	pos = binary_search(id, free_list)*/
    RefDS(_1free_list_23976);
    _pos_24055 = _9binary_search(_id_24054, _1free_list_23976, 1, 0);
    if (!IS_ATOM_INT(_pos_24055)) {
        _1 = (long)(DBL_PTR(_pos_24055)->dbl);
        DeRefDS(_pos_24055);
        _pos_24055 = _1;
    }

    /** 	if pos < 0 then -- if not in free_list, insert*/
    if (_pos_24055 >= 0)
    goto L1; // [18] 152

    /** 		data[id] = {}*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_24054);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 		pos = -pos*/
    _pos_24055 = - _pos_24055;

    /** 		free_list = free_list[1..pos-1] & {id} & free_list[pos..$]*/
    _13298 = _pos_24055 - 1;
    rhs_slice_target = (object_ptr)&_13299;
    RHS_Slice(_1free_list_23976, 1, _13298);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _id_24054;
    _13300 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_1free_list_23976)){
            _13301 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13301 = 1;
    }
    rhs_slice_target = (object_ptr)&_13302;
    RHS_Slice(_1free_list_23976, _pos_24055, _13301);
    {
        int concat_list[3];

        concat_list[0] = _13302;
        concat_list[1] = _13300;
        concat_list[2] = _13299;
        Concat_N((object_ptr)&_1free_list_23976, concat_list, 3);
    }
    DeRefDS(_13302);
    _13302 = NOVALUE;
    DeRefDS(_13300);
    _13300 = NOVALUE;
    DeRefDS(_13299);
    _13299 = NOVALUE;

    /** 		for i = length(free_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_1free_list_23976)){
            _13304 = SEQ_PTR(_1free_list_23976)->length;
    }
    else {
        _13304 = 1;
    }
    {
        int _i_24068;
        _i_24068 = _13304;
L2: 
        if (_i_24068 < 1){
            goto L3; // [77] 151
        }

        /** 			if free_list[$] = length(data) then*/
        if (IS_SEQUENCE(_1free_list_23976)){
                _13305 = SEQ_PTR(_1free_list_23976)->length;
        }
        else {
            _13305 = 1;
        }
        _2 = (int)SEQ_PTR(_1free_list_23976);
        _13306 = (int)*(((s1_ptr)_2)->base + _13305);
        if (IS_SEQUENCE(_1data_23975)){
                _13307 = SEQ_PTR(_1data_23975)->length;
        }
        else {
            _13307 = 1;
        }
        if (binary_op_a(NOTEQ, _13306, _13307)){
            _13306 = NOVALUE;
            _13307 = NOVALUE;
            goto L3; // [100] 151
        }
        _13306 = NOVALUE;
        _13307 = NOVALUE;

        /** 				data = data[1..$-1]*/
        if (IS_SEQUENCE(_1data_23975)){
                _13309 = SEQ_PTR(_1data_23975)->length;
        }
        else {
            _13309 = 1;
        }
        _13310 = _13309 - 1;
        _13309 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1data_23975;
        RHS_Slice(_1data_23975, 1, _13310);

        /** 				free_list = free_list[1..$-1]*/
        if (IS_SEQUENCE(_1free_list_23976)){
                _13312 = SEQ_PTR(_1free_list_23976)->length;
        }
        else {
            _13312 = 1;
        }
        _13313 = _13312 - 1;
        _13312 = NOVALUE;
        rhs_slice_target = (object_ptr)&_1free_list_23976;
        RHS_Slice(_1free_list_23976, 1, _13313);
        goto L4; // [136] 144

        /** 				exit*/
        goto L3; // [141] 151
L4: 

        /** 		end for*/
        _i_24068 = _i_24068 + -1;
        goto L2; // [146] 84
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_13298);
    _13298 = NOVALUE;
    DeRef(_13310);
    _13310 = NOVALUE;
    DeRef(_13313);
    _13313 = NOVALUE;
    return;
    ;
}
void delete_linked_list() __attribute__ ((alias ("_1delete_linked_list")));


void _1free_linked_lists(int _low_24084, int _high_24085, int _len_24086)
{
    int _array_24087 = NOVALUE;
    int _ma_24088 = NOVALUE;
    int _get_address_1__tmp_at8_24091 = NOVALUE;
    int _get_address_inlined_get_address_at_8_24090 = NOVALUE;
    int _13318 = NOVALUE;
    int _13317 = NOVALUE;
    int _13315 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24084)) {
        _1 = (long)(DBL_PTR(_low_24084)->dbl);
        DeRefDS(_low_24084);
        _low_24084 = _1;
    }
    if (!IS_ATOM_INT(_high_24085)) {
        _1 = (long)(DBL_PTR(_high_24085)->dbl);
        DeRefDS(_high_24085);
        _high_24085 = _1;
    }
    if (!IS_ATOM_INT(_len_24086)) {
        _1 = (long)(DBL_PTR(_len_24086)->dbl);
        DeRefDS(_len_24086);
        _len_24086 = _1;
    }

    /** 	ma = get_address(low, high)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_24091);
    _get_address_1__tmp_at8_24091 = NewDouble(_high_24085 * (double)65536);
    DeRef(_ma_24088);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_24091)) {
        _ma_24088 = _get_address_1__tmp_at8_24091 + _low_24084;
        if ((long)((unsigned long)_ma_24088 + (unsigned long)HIGH_BITS) >= 0) 
        _ma_24088 = NewDouble((double)_ma_24088);
    }
    else {
        _ma_24088 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_24091)->dbl + (double)_low_24084);
    }
    DeRef(_get_address_1__tmp_at8_24091);
    _get_address_1__tmp_at8_24091 = NOVALUE;

    /** 	array = peek4u({ma, len})*/
    Ref(_ma_24088);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ma_24088;
    ((int *)_2)[2] = _len_24086;
    _13315 = MAKE_SEQ(_1);
    DeRef(_array_24087);
    _1 = (int)SEQ_PTR(_13315);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _array_24087 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13315);
    _13315 = NOVALUE;

    /** 	for i = 1 to length(array) do*/
    if (IS_SEQUENCE(_array_24087)){
            _13317 = SEQ_PTR(_array_24087)->length;
    }
    else {
        _13317 = 1;
    }
    {
        int _i_24095;
        _i_24095 = 1;
L1: 
        if (_i_24095 > _13317){
            goto L2; // [38] 61
        }

        /** 		delete_linked_list(array[i])*/
        _2 = (int)SEQ_PTR(_array_24087);
        _13318 = (int)*(((s1_ptr)_2)->base + _i_24095);
        Ref(_13318);
        _1delete_linked_list(_13318);
        _13318 = NOVALUE;

        /** 	end for*/
        _i_24095 = _i_24095 + 1;
        goto L1; // [56] 45
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_array_24087);
    DeRef(_ma_24088);
    return;
    ;
}
void free_linked_lists() __attribute__ ((alias ("_1free_linked_lists")));


int _1register_linked_list(int _low_24100, int _high_24101)
{
    int _get_address_1__tmp_at6_24105 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24104 = NOVALUE;
    int _13320 = NOVALUE;
    int _13319 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24100)) {
        _1 = (long)(DBL_PTR(_low_24100)->dbl);
        DeRefDS(_low_24100);
        _low_24100 = _1;
    }
    if (!IS_ATOM_INT(_high_24101)) {
        _1 = (long)(DBL_PTR(_high_24101)->dbl);
        DeRefDS(_high_24101);
        _high_24101 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24105);
    _get_address_1__tmp_at6_24105 = NewDouble(_high_24101 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24104);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24105)) {
        _get_address_inlined_get_address_at_6_24104 = _get_address_1__tmp_at6_24105 + _low_24100;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24104 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24104 = NewDouble((double)_get_address_inlined_get_address_at_6_24104);
    }
    else {
        _get_address_inlined_get_address_at_6_24104 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24105)->dbl + (double)_low_24100);
    }
    DeRef(_get_address_1__tmp_at6_24105);
    _get_address_1__tmp_at6_24105 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24104);
    _13319 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_6_24104);
    _13320 = _1register_data(_13319);
    _13319 = NOVALUE;
    return _13320;
    ;
}
int register_linked_list() __attribute__ ((alias ("_1register_linked_list")));


int _1new_linked_list(int _low_24110, int _high_24111)
{
    int _get_address_1__tmp_at6_24115 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24114 = NOVALUE;
    int _13322 = NOVALUE;
    int _13321 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24110)) {
        _1 = (long)(DBL_PTR(_low_24110)->dbl);
        DeRefDS(_low_24110);
        _low_24110 = _1;
    }
    if (!IS_ATOM_INT(_high_24111)) {
        _1 = (long)(DBL_PTR(_high_24111)->dbl);
        DeRefDS(_high_24111);
        _high_24111 = _1;
    }

    /** 	return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24115);
    _get_address_1__tmp_at6_24115 = NewDouble(_high_24111 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24114);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24115)) {
        _get_address_inlined_get_address_at_6_24114 = _get_address_1__tmp_at6_24115 + _low_24110;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24114 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24114 = NewDouble((double)_get_address_inlined_get_address_at_6_24114);
    }
    else {
        _get_address_inlined_get_address_at_6_24114 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24115)->dbl + (double)_low_24110);
    }
    DeRef(_get_address_1__tmp_at6_24115);
    _get_address_1__tmp_at6_24115 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24114);
    _13321 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_6_24114);
    _13322 = _1register_data(_13321);
    _13321 = NOVALUE;
    return _13322;
    ;
}
int new_linked_list() __attribute__ ((alias ("_1new_linked_list")));


void _1store_linked_list(int _id_24120, int _low_24121, int _high_24122)
{
    int _get_address_1__tmp_at10_24126 = NOVALUE;
    int _get_address_inlined_get_address_at_10_24125 = NOVALUE;
    int _13323 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24120)) {
        _1 = (long)(DBL_PTR(_id_24120)->dbl);
        DeRefDS(_id_24120);
        _id_24120 = _1;
    }
    if (!IS_ATOM_INT(_low_24121)) {
        _1 = (long)(DBL_PTR(_low_24121)->dbl);
        DeRefDS(_low_24121);
        _low_24121 = _1;
    }
    if (!IS_ATOM_INT(_high_24122)) {
        _1 = (long)(DBL_PTR(_high_24122)->dbl);
        DeRefDS(_high_24122);
        _high_24122 = _1;
    }

    /** 	data[id] = linked_list_to_sequence(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_24126);
    _get_address_1__tmp_at10_24126 = NewDouble(_high_24122 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_24125);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_24126)) {
        _get_address_inlined_get_address_at_10_24125 = _get_address_1__tmp_at10_24126 + _low_24121;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_24125 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_24125 = NewDouble((double)_get_address_inlined_get_address_at_10_24125);
    }
    else {
        _get_address_inlined_get_address_at_10_24125 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_24126)->dbl + (double)_low_24121);
    }
    DeRef(_get_address_1__tmp_at10_24126);
    _get_address_1__tmp_at10_24126 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_10_24125);
    _13323 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_10_24125);
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id_24120);
    _1 = *(int *)_2;
    *(int *)_2 = _13323;
    if( _1 != _13323 ){
        DeRef(_1);
    }
    _13323 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void store_linked_list() __attribute__ ((alias ("_1store_linked_list")));


int _1access_linked_list(int _id_24130)
{
    int _set_high_address_inlined_set_high_address_at_18_24136 = NOVALUE;
    int _ma_inlined_set_high_address_at_15_24135 = NOVALUE;
    int _13325 = NOVALUE;
    int _13324 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24130)) {
        _1 = (long)(DBL_PTR(_id_24130)->dbl);
        DeRefDS(_id_24130);
        _id_24130 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13324 = (int)*(((s1_ptr)_2)->base + _id_24130);
    Ref(_13324);
    _13325 = _58sequence_to_linked_list(_13324);
    _13324 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_15_24135);
    _ma_inlined_set_high_address_at_15_24135 = _13325;
    _13325 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_24135)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_15_24135 >= 0) {
            _1high_address_23974 = _ma_inlined_set_high_address_at_15_24135 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_15_24135 / (double)65536);
            _1high_address_23974 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_15_24135, 65536);
        _1high_address_23974 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_23974)) {
        _1 = (long)(DBL_PTR(_1high_address_23974)->dbl);
        DeRefDS(_1high_address_23974);
        _1high_address_23974 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_18_24136);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_24135)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_15_24135 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_18_24136 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_18_24136 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_15_24135, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_15_24135);
    _ma_inlined_set_high_address_at_15_24135 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_18_24136;
    ;
}
int access_linked_list() __attribute__ ((alias ("_1access_linked_list")));


int _1at_linked_list(int _id_24139, int _index_24140)
{
    int _set_high_address_inlined_set_high_address_at_24_24147 = NOVALUE;
    int _ma_inlined_set_high_address_at_21_24146 = NOVALUE;
    int _13328 = NOVALUE;
    int _13327 = NOVALUE;
    int _13326 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24139)) {
        _1 = (long)(DBL_PTR(_id_24139)->dbl);
        DeRefDS(_id_24139);
        _id_24139 = _1;
    }
    if (!IS_ATOM_INT(_index_24140)) {
        _1 = (long)(DBL_PTR(_index_24140)->dbl);
        DeRefDS(_index_24140);
        _index_24140 = _1;
    }

    /** 	return set_high_address(sequence_to_linked_list(data[id][index]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13326 = (int)*(((s1_ptr)_2)->base + _id_24139);
    _2 = (int)SEQ_PTR(_13326);
    _13327 = (int)*(((s1_ptr)_2)->base + _index_24140);
    _13326 = NOVALUE;
    Ref(_13327);
    _13328 = _58sequence_to_linked_list(_13327);
    _13327 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_21_24146);
    _ma_inlined_set_high_address_at_21_24146 = _13328;
    _13328 = NOVALUE;

    /** 	high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_24146)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_21_24146 >= 0) {
            _1high_address_23974 = _ma_inlined_set_high_address_at_21_24146 / 65536;
        }
        else {
            temp_dbl = floor((double)_ma_inlined_set_high_address_at_21_24146 / (double)65536);
            _1high_address_23974 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_21_24146, 65536);
        _1high_address_23974 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_23974)) {
        _1 = (long)(DBL_PTR(_1high_address_23974)->dbl);
        DeRefDS(_1high_address_23974);
        _1high_address_23974 = _1;
    }

    /** 	return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_24_24147);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_24146)) {
        {unsigned long tu;
             tu = (unsigned long)_ma_inlined_set_high_address_at_21_24146 & (unsigned long)65535;
             _set_high_address_inlined_set_high_address_at_24_24147 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_24_24147 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_21_24146, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_21_24146);
    _ma_inlined_set_high_address_at_21_24146 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_24_24147;
    ;
}
int at_linked_list() __attribute__ ((alias ("_1at_linked_list")));


void _1free_linked_list_dll(int _low_24150, int _high_24151)
{
    int _get_address_1__tmp_at6_24155 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24154 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24150)) {
        _1 = (long)(DBL_PTR(_low_24150)->dbl);
        DeRefDS(_low_24150);
        _low_24150 = _1;
    }
    if (!IS_ATOM_INT(_high_24151)) {
        _1 = (long)(DBL_PTR(_high_24151)->dbl);
        DeRefDS(_high_24151);
        _high_24151 = _1;
    }

    /** 	free_linked_list(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24155);
    _get_address_1__tmp_at6_24155 = NewDouble(_high_24151 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24154);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24155)) {
        _get_address_inlined_get_address_at_6_24154 = _get_address_1__tmp_at6_24155 + _low_24150;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24154 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24154 = NewDouble((double)_get_address_inlined_get_address_at_6_24154);
    }
    else {
        _get_address_inlined_get_address_at_6_24154 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24155)->dbl + (double)_low_24150);
    }
    DeRef(_get_address_1__tmp_at6_24155);
    _get_address_1__tmp_at6_24155 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_24154);
    _58free_linked_list(_get_address_inlined_get_address_at_6_24154);

    /** end procedure*/
    return;
    ;
}
void free_linked_list_dll() __attribute__ ((alias ("_1free_linked_list_dll")));


int _1length_linked_list(int _id_24158)
{
    int _13332 = NOVALUE;
    int _13331 = NOVALUE;
    int _13330 = NOVALUE;
    int _13329 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24158)) {
        _1 = (long)(DBL_PTR(_id_24158)->dbl);
        DeRefDS(_id_24158);
        _id_24158 = _1;
    }

    /** 	if atom(data[id]) then*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13329 = (int)*(((s1_ptr)_2)->base + _id_24158);
    _13330 = IS_ATOM(_13329);
    _13329 = NOVALUE;
    if (_13330 == 0)
    {
        _13330 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _13330 = NOVALUE;
    }

    /** 		return -1*/
    return -1;
L1: 

    /** 	return length(data[id])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13331 = (int)*(((s1_ptr)_2)->base + _id_24158);
    if (IS_SEQUENCE(_13331)){
            _13332 = SEQ_PTR(_13331)->length;
    }
    else {
        _13332 = 1;
    }
    _13331 = NOVALUE;
    _13331 = NOVALUE;
    return _13332;
    ;
}
int length_linked_list() __attribute__ ((alias ("_1length_linked_list")));


void _1store_at_linked_list(int _id_24166, int _index_24167, int _low_24168, int _high_24169)
{
    int _get_address_1__tmp_at17_24175 = NOVALUE;
    int _get_address_inlined_get_address_at_17_24174 = NOVALUE;
    int _13335 = NOVALUE;
    int _13333 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id_24166)) {
        _1 = (long)(DBL_PTR(_id_24166)->dbl);
        DeRefDS(_id_24166);
        _id_24166 = _1;
    }
    if (!IS_ATOM_INT(_index_24167)) {
        _1 = (long)(DBL_PTR(_index_24167)->dbl);
        DeRefDS(_index_24167);
        _index_24167 = _1;
    }
    if (!IS_ATOM_INT(_low_24168)) {
        _1 = (long)(DBL_PTR(_low_24168)->dbl);
        DeRefDS(_low_24168);
        _low_24168 = _1;
    }
    if (!IS_ATOM_INT(_high_24169)) {
        _1 = (long)(DBL_PTR(_high_24169)->dbl);
        DeRefDS(_high_24169);
        _high_24169 = _1;
    }

    /** 	data[id][index] = linked_list_to_sequence(get_address(low, high))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data_23975 = MAKE_SEQ(_2);
    }
    _3 = (int)(_id_24166 + ((s1_ptr)_2)->base);

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at17_24175);
    _get_address_1__tmp_at17_24175 = NewDouble(_high_24169 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_17_24174);
    if (IS_ATOM_INT(_get_address_1__tmp_at17_24175)) {
        _get_address_inlined_get_address_at_17_24174 = _get_address_1__tmp_at17_24175 + _low_24168;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_17_24174 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_17_24174 = NewDouble((double)_get_address_inlined_get_address_at_17_24174);
    }
    else {
        _get_address_inlined_get_address_at_17_24174 = NewDouble(DBL_PTR(_get_address_1__tmp_at17_24175)->dbl + (double)_low_24168);
    }
    DeRef(_get_address_1__tmp_at17_24175);
    _get_address_1__tmp_at17_24175 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_17_24174);
    _13335 = _58linked_list_to_sequence(_get_address_inlined_get_address_at_17_24174);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_24167);
    _1 = *(int *)_2;
    *(int *)_2 = _13335;
    if( _1 != _13335 ){
        DeRef(_1);
    }
    _13335 = NOVALUE;
    _13333 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void store_at_linked_list() __attribute__ ((alias ("_1store_at_linked_list")));


int _1eu_repeat(int _id_24179, int _len_24180)
{
    int _retval_inlined_retval_at_19_24185 = NOVALUE;
    int _ob_inlined_retval_at_16_24184 = NOVALUE;
    int _13337 = NOVALUE;
    int _13336 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24179)) {
        _1 = (long)(DBL_PTR(_id_24179)->dbl);
        DeRefDS(_id_24179);
        _id_24179 = _1;
    }
    if (!IS_ATOM_INT(_len_24180)) {
        _1 = (long)(DBL_PTR(_len_24180)->dbl);
        DeRefDS(_len_24180);
        _len_24180 = _1;
    }

    /** 	return retval(repeat(data[id], len))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13336 = (int)*(((s1_ptr)_2)->base + _id_24179);
    _13337 = Repeat(_13336, _len_24180);
    _13336 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24184);
    _ob_inlined_retval_at_16_24184 = _13337;
    _13337 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_24184);
    _0 = _retval_inlined_retval_at_19_24185;
    _retval_inlined_retval_at_19_24185 = _1register_data(_ob_inlined_retval_at_16_24184);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24184);
    _ob_inlined_retval_at_16_24184 = NOVALUE;
    return _retval_inlined_retval_at_19_24185;
    ;
}
int eu_repeat() __attribute__ ((alias ("_1eu_repeat")));


void _1eu_mem_set(int _low_24188, int _high_24189, int _byte_val_24190, int _how_many_24191)
{
    int _get_address_1__tmp_at10_24194 = NOVALUE;
    int _get_address_inlined_get_address_at_10_24193 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24188)) {
        _1 = (long)(DBL_PTR(_low_24188)->dbl);
        DeRefDS(_low_24188);
        _low_24188 = _1;
    }
    if (!IS_ATOM_INT(_high_24189)) {
        _1 = (long)(DBL_PTR(_high_24189)->dbl);
        DeRefDS(_high_24189);
        _high_24189 = _1;
    }
    if (!IS_ATOM_INT(_byte_val_24190)) {
        _1 = (long)(DBL_PTR(_byte_val_24190)->dbl);
        DeRefDS(_byte_val_24190);
        _byte_val_24190 = _1;
    }
    if (!IS_ATOM_INT(_how_many_24191)) {
        _1 = (long)(DBL_PTR(_how_many_24191)->dbl);
        DeRefDS(_how_many_24191);
        _how_many_24191 = _1;
    }

    /** 	mem_set(get_address(low, high), byte_val, how_many)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_24194);
    _get_address_1__tmp_at10_24194 = NewDouble(_high_24189 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_10_24193);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_24194)) {
        _get_address_inlined_get_address_at_10_24193 = _get_address_1__tmp_at10_24194 + _low_24188;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_10_24193 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_10_24193 = NewDouble((double)_get_address_inlined_get_address_at_10_24193);
    }
    else {
        _get_address_inlined_get_address_at_10_24193 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_24194)->dbl + (double)_low_24188);
    }
    DeRef(_get_address_1__tmp_at10_24194);
    _get_address_1__tmp_at10_24194 = NOVALUE;
    memory_set(_get_address_inlined_get_address_at_10_24193, _byte_val_24190, _how_many_24191);

    /** end procedure*/
    return;
    ;
}
void eu_mem_set() __attribute__ ((alias ("_1eu_mem_set")));


void _1eu_mem_copy(int _dstlow_24197, int _dsthigh_24198, int _srclow_24199, int _srchigh_24200, int _len_24201)
{
    int _get_address_1__tmp_at12_24204 = NOVALUE;
    int _get_address_inlined_get_address_at_12_24203 = NOVALUE;
    int _get_address_1__tmp_at25_24207 = NOVALUE;
    int _get_address_inlined_get_address_at_25_24206 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow_24197)) {
        _1 = (long)(DBL_PTR(_dstlow_24197)->dbl);
        DeRefDS(_dstlow_24197);
        _dstlow_24197 = _1;
    }
    if (!IS_ATOM_INT(_dsthigh_24198)) {
        _1 = (long)(DBL_PTR(_dsthigh_24198)->dbl);
        DeRefDS(_dsthigh_24198);
        _dsthigh_24198 = _1;
    }
    if (!IS_ATOM_INT(_srclow_24199)) {
        _1 = (long)(DBL_PTR(_srclow_24199)->dbl);
        DeRefDS(_srclow_24199);
        _srclow_24199 = _1;
    }
    if (!IS_ATOM_INT(_srchigh_24200)) {
        _1 = (long)(DBL_PTR(_srchigh_24200)->dbl);
        DeRefDS(_srchigh_24200);
        _srchigh_24200 = _1;
    }
    if (!IS_ATOM_INT(_len_24201)) {
        _1 = (long)(DBL_PTR(_len_24201)->dbl);
        DeRefDS(_len_24201);
        _len_24201 = _1;
    }

    /** 	mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at12_24204);
    _get_address_1__tmp_at12_24204 = NewDouble(_dsthigh_24198 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_12_24203);
    if (IS_ATOM_INT(_get_address_1__tmp_at12_24204)) {
        _get_address_inlined_get_address_at_12_24203 = _get_address_1__tmp_at12_24204 + _dstlow_24197;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_12_24203 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_12_24203 = NewDouble((double)_get_address_inlined_get_address_at_12_24203);
    }
    else {
        _get_address_inlined_get_address_at_12_24203 = NewDouble(DBL_PTR(_get_address_1__tmp_at12_24204)->dbl + (double)_dstlow_24197);
    }
    DeRef(_get_address_1__tmp_at12_24204);
    _get_address_1__tmp_at12_24204 = NOVALUE;

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at25_24207);
    _get_address_1__tmp_at25_24207 = NewDouble(_srchigh_24200 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_25_24206);
    if (IS_ATOM_INT(_get_address_1__tmp_at25_24207)) {
        _get_address_inlined_get_address_at_25_24206 = _get_address_1__tmp_at25_24207 + _srclow_24199;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_25_24206 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_25_24206 = NewDouble((double)_get_address_inlined_get_address_at_25_24206);
    }
    else {
        _get_address_inlined_get_address_at_25_24206 = NewDouble(DBL_PTR(_get_address_1__tmp_at25_24207)->dbl + (double)_srclow_24199);
    }
    DeRef(_get_address_1__tmp_at25_24207);
    _get_address_1__tmp_at25_24207 = NOVALUE;
    memory_copy(_get_address_inlined_get_address_at_12_24203, _get_address_inlined_get_address_at_25_24206, _len_24201);

    /** end procedure*/
    return;
    ;
}
void eu_mem_copy() __attribute__ ((alias ("_1eu_mem_copy")));


int _1eu_add(int _id1_24210, int _id2_24211)
{
    int _retval_inlined_retval_at_25_24217 = NOVALUE;
    int _ob_inlined_retval_at_22_24216 = NOVALUE;
    int _13340 = NOVALUE;
    int _13339 = NOVALUE;
    int _13338 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24210)) {
        _1 = (long)(DBL_PTR(_id1_24210)->dbl);
        DeRefDS(_id1_24210);
        _id1_24210 = _1;
    }
    if (!IS_ATOM_INT(_id2_24211)) {
        _1 = (long)(DBL_PTR(_id2_24211)->dbl);
        DeRefDS(_id2_24211);
        _id2_24211 = _1;
    }

    /** 	return retval(data[id1] + data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13338 = (int)*(((s1_ptr)_2)->base + _id1_24210);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13339 = (int)*(((s1_ptr)_2)->base + _id2_24211);
    if (IS_ATOM_INT(_13338) && IS_ATOM_INT(_13339)) {
        _13340 = _13338 + _13339;
        if ((long)((unsigned long)_13340 + (unsigned long)HIGH_BITS) >= 0) 
        _13340 = NewDouble((double)_13340);
    }
    else {
        _13340 = binary_op(PLUS, _13338, _13339);
    }
    _13338 = NOVALUE;
    _13339 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24216);
    _ob_inlined_retval_at_22_24216 = _13340;
    _13340 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24216);
    _0 = _retval_inlined_retval_at_25_24217;
    _retval_inlined_retval_at_25_24217 = _1register_data(_ob_inlined_retval_at_22_24216);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24216);
    _ob_inlined_retval_at_22_24216 = NOVALUE;
    return _retval_inlined_retval_at_25_24217;
    ;
}
int eu_add() __attribute__ ((alias ("_1eu_add")));


int _1eu_subtract(int _id1_24220, int _id2_24221)
{
    int _retval_inlined_retval_at_25_24227 = NOVALUE;
    int _ob_inlined_retval_at_22_24226 = NOVALUE;
    int _13343 = NOVALUE;
    int _13342 = NOVALUE;
    int _13341 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24220)) {
        _1 = (long)(DBL_PTR(_id1_24220)->dbl);
        DeRefDS(_id1_24220);
        _id1_24220 = _1;
    }
    if (!IS_ATOM_INT(_id2_24221)) {
        _1 = (long)(DBL_PTR(_id2_24221)->dbl);
        DeRefDS(_id2_24221);
        _id2_24221 = _1;
    }

    /** 	return retval(data[id1] - data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13341 = (int)*(((s1_ptr)_2)->base + _id1_24220);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13342 = (int)*(((s1_ptr)_2)->base + _id2_24221);
    if (IS_ATOM_INT(_13341) && IS_ATOM_INT(_13342)) {
        _13343 = _13341 - _13342;
        if ((long)((unsigned long)_13343 +(unsigned long) HIGH_BITS) >= 0){
            _13343 = NewDouble((double)_13343);
        }
    }
    else {
        _13343 = binary_op(MINUS, _13341, _13342);
    }
    _13341 = NOVALUE;
    _13342 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24226);
    _ob_inlined_retval_at_22_24226 = _13343;
    _13343 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24226);
    _0 = _retval_inlined_retval_at_25_24227;
    _retval_inlined_retval_at_25_24227 = _1register_data(_ob_inlined_retval_at_22_24226);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24226);
    _ob_inlined_retval_at_22_24226 = NOVALUE;
    return _retval_inlined_retval_at_25_24227;
    ;
}
int eu_subtract() __attribute__ ((alias ("_1eu_subtract")));


int _1eu_multiply(int _id1_24230, int _id2_24231)
{
    int _retval_inlined_retval_at_25_24237 = NOVALUE;
    int _ob_inlined_retval_at_22_24236 = NOVALUE;
    int _13346 = NOVALUE;
    int _13345 = NOVALUE;
    int _13344 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24230)) {
        _1 = (long)(DBL_PTR(_id1_24230)->dbl);
        DeRefDS(_id1_24230);
        _id1_24230 = _1;
    }
    if (!IS_ATOM_INT(_id2_24231)) {
        _1 = (long)(DBL_PTR(_id2_24231)->dbl);
        DeRefDS(_id2_24231);
        _id2_24231 = _1;
    }

    /** 	return retval(data[id1] * data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13344 = (int)*(((s1_ptr)_2)->base + _id1_24230);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13345 = (int)*(((s1_ptr)_2)->base + _id2_24231);
    if (IS_ATOM_INT(_13344) && IS_ATOM_INT(_13345)) {
        if (_13344 == (short)_13344 && _13345 <= INT15 && _13345 >= -INT15)
        _13346 = _13344 * _13345;
        else
        _13346 = NewDouble(_13344 * (double)_13345);
    }
    else {
        _13346 = binary_op(MULTIPLY, _13344, _13345);
    }
    _13344 = NOVALUE;
    _13345 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24236);
    _ob_inlined_retval_at_22_24236 = _13346;
    _13346 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24236);
    _0 = _retval_inlined_retval_at_25_24237;
    _retval_inlined_retval_at_25_24237 = _1register_data(_ob_inlined_retval_at_22_24236);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24236);
    _ob_inlined_retval_at_22_24236 = NOVALUE;
    return _retval_inlined_retval_at_25_24237;
    ;
}
int eu_multiply() __attribute__ ((alias ("_1eu_multiply")));


int _1eu_divide(int _id1_24240, int _id2_24241)
{
    int _retval_inlined_retval_at_25_24247 = NOVALUE;
    int _ob_inlined_retval_at_22_24246 = NOVALUE;
    int _13349 = NOVALUE;
    int _13348 = NOVALUE;
    int _13347 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24240)) {
        _1 = (long)(DBL_PTR(_id1_24240)->dbl);
        DeRefDS(_id1_24240);
        _id1_24240 = _1;
    }
    if (!IS_ATOM_INT(_id2_24241)) {
        _1 = (long)(DBL_PTR(_id2_24241)->dbl);
        DeRefDS(_id2_24241);
        _id2_24241 = _1;
    }

    /** 	return retval(data[id1] / data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13347 = (int)*(((s1_ptr)_2)->base + _id1_24240);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13348 = (int)*(((s1_ptr)_2)->base + _id2_24241);
    if (IS_ATOM_INT(_13347) && IS_ATOM_INT(_13348)) {
        _13349 = (_13347 % _13348) ? NewDouble((double)_13347 / _13348) : (_13347 / _13348);
    }
    else {
        _13349 = binary_op(DIVIDE, _13347, _13348);
    }
    _13347 = NOVALUE;
    _13348 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24246);
    _ob_inlined_retval_at_22_24246 = _13349;
    _13349 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24246);
    _0 = _retval_inlined_retval_at_25_24247;
    _retval_inlined_retval_at_25_24247 = _1register_data(_ob_inlined_retval_at_22_24246);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24246);
    _ob_inlined_retval_at_22_24246 = NOVALUE;
    return _retval_inlined_retval_at_25_24247;
    ;
}
int eu_divide() __attribute__ ((alias ("_1eu_divide")));


int _1eu_negate(int _id_24250)
{
    int _retval_inlined_retval_at_16_24255 = NOVALUE;
    int _ob_inlined_retval_at_13_24254 = NOVALUE;
    int _13351 = NOVALUE;
    int _13350 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24250)) {
        _1 = (long)(DBL_PTR(_id_24250)->dbl);
        DeRefDS(_id_24250);
        _id_24250 = _1;
    }

    /** 	return retval(-data[id])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13350 = (int)*(((s1_ptr)_2)->base + _id_24250);
    if (IS_ATOM_INT(_13350)) {
        if ((unsigned long)_13350 == 0xC0000000)
        _13351 = (int)NewDouble((double)-0xC0000000);
        else
        _13351 = - _13350;
    }
    else {
        _13351 = unary_op(UMINUS, _13350);
    }
    _13350 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24254);
    _ob_inlined_retval_at_13_24254 = _13351;
    _13351 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24254);
    _0 = _retval_inlined_retval_at_16_24255;
    _retval_inlined_retval_at_16_24255 = _1register_data(_ob_inlined_retval_at_13_24254);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24254);
    _ob_inlined_retval_at_13_24254 = NOVALUE;
    return _retval_inlined_retval_at_16_24255;
    ;
}
int eu_negate() __attribute__ ((alias ("_1eu_negate")));


int _1eu_not(int _id_24258)
{
    int _retval_inlined_retval_at_16_24263 = NOVALUE;
    int _ob_inlined_retval_at_13_24262 = NOVALUE;
    int _13353 = NOVALUE;
    int _13352 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24258)) {
        _1 = (long)(DBL_PTR(_id_24258)->dbl);
        DeRefDS(_id_24258);
        _id_24258 = _1;
    }

    /** 	return retval(not data[id])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13352 = (int)*(((s1_ptr)_2)->base + _id_24258);
    if (IS_ATOM_INT(_13352)) {
        _13353 = (_13352 == 0);
    }
    else {
        _13353 = unary_op(NOT, _13352);
    }
    _13352 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24262);
    _ob_inlined_retval_at_13_24262 = _13353;
    _13353 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24262);
    _0 = _retval_inlined_retval_at_16_24263;
    _retval_inlined_retval_at_16_24263 = _1register_data(_ob_inlined_retval_at_13_24262);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24262);
    _ob_inlined_retval_at_13_24262 = NOVALUE;
    return _retval_inlined_retval_at_16_24263;
    ;
}
int eu_not() __attribute__ ((alias ("_1eu_not")));


int _1eu_equals(int _id1_24266, int _id2_24267)
{
    int _retval_inlined_retval_at_25_24273 = NOVALUE;
    int _ob_inlined_retval_at_22_24272 = NOVALUE;
    int _13356 = NOVALUE;
    int _13355 = NOVALUE;
    int _13354 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24266)) {
        _1 = (long)(DBL_PTR(_id1_24266)->dbl);
        DeRefDS(_id1_24266);
        _id1_24266 = _1;
    }
    if (!IS_ATOM_INT(_id2_24267)) {
        _1 = (long)(DBL_PTR(_id2_24267)->dbl);
        DeRefDS(_id2_24267);
        _id2_24267 = _1;
    }

    /** 	return retval(data[id1] = data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13354 = (int)*(((s1_ptr)_2)->base + _id1_24266);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13355 = (int)*(((s1_ptr)_2)->base + _id2_24267);
    if (IS_ATOM_INT(_13354) && IS_ATOM_INT(_13355)) {
        _13356 = (_13354 == _13355);
    }
    else {
        _13356 = binary_op(EQUALS, _13354, _13355);
    }
    _13354 = NOVALUE;
    _13355 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24272);
    _ob_inlined_retval_at_22_24272 = _13356;
    _13356 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24272);
    _0 = _retval_inlined_retval_at_25_24273;
    _retval_inlined_retval_at_25_24273 = _1register_data(_ob_inlined_retval_at_22_24272);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24272);
    _ob_inlined_retval_at_22_24272 = NOVALUE;
    return _retval_inlined_retval_at_25_24273;
    ;
}
int eu_equals() __attribute__ ((alias ("_1eu_equals")));


int _1eu_and(int _id1_24276, int _id2_24277)
{
    int _retval_inlined_retval_at_25_24283 = NOVALUE;
    int _ob_inlined_retval_at_22_24282 = NOVALUE;
    int _13359 = NOVALUE;
    int _13358 = NOVALUE;
    int _13357 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24276)) {
        _1 = (long)(DBL_PTR(_id1_24276)->dbl);
        DeRefDS(_id1_24276);
        _id1_24276 = _1;
    }
    if (!IS_ATOM_INT(_id2_24277)) {
        _1 = (long)(DBL_PTR(_id2_24277)->dbl);
        DeRefDS(_id2_24277);
        _id2_24277 = _1;
    }

    /** 	return retval(data[id1] and data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13357 = (int)*(((s1_ptr)_2)->base + _id1_24276);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13358 = (int)*(((s1_ptr)_2)->base + _id2_24277);
    if (IS_ATOM_INT(_13357) && IS_ATOM_INT(_13358)) {
        _13359 = (_13357 != 0 && _13358 != 0);
    }
    else {
        _13359 = binary_op(AND, _13357, _13358);
    }
    _13357 = NOVALUE;
    _13358 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24282);
    _ob_inlined_retval_at_22_24282 = _13359;
    _13359 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24282);
    _0 = _retval_inlined_retval_at_25_24283;
    _retval_inlined_retval_at_25_24283 = _1register_data(_ob_inlined_retval_at_22_24282);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24282);
    _ob_inlined_retval_at_22_24282 = NOVALUE;
    return _retval_inlined_retval_at_25_24283;
    ;
}
int eu_and() __attribute__ ((alias ("_1eu_and")));


int _1eu_or(int _id1_24286, int _id2_24287)
{
    int _retval_inlined_retval_at_25_24293 = NOVALUE;
    int _ob_inlined_retval_at_22_24292 = NOVALUE;
    int _13362 = NOVALUE;
    int _13361 = NOVALUE;
    int _13360 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24286)) {
        _1 = (long)(DBL_PTR(_id1_24286)->dbl);
        DeRefDS(_id1_24286);
        _id1_24286 = _1;
    }
    if (!IS_ATOM_INT(_id2_24287)) {
        _1 = (long)(DBL_PTR(_id2_24287)->dbl);
        DeRefDS(_id2_24287);
        _id2_24287 = _1;
    }

    /** 	return retval(data[id1] or data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13360 = (int)*(((s1_ptr)_2)->base + _id1_24286);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13361 = (int)*(((s1_ptr)_2)->base + _id2_24287);
    if (IS_ATOM_INT(_13360) && IS_ATOM_INT(_13361)) {
        _13362 = (_13360 != 0 || _13361 != 0);
    }
    else {
        _13362 = binary_op(OR, _13360, _13361);
    }
    _13360 = NOVALUE;
    _13361 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24292);
    _ob_inlined_retval_at_22_24292 = _13362;
    _13362 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24292);
    _0 = _retval_inlined_retval_at_25_24293;
    _retval_inlined_retval_at_25_24293 = _1register_data(_ob_inlined_retval_at_22_24292);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24292);
    _ob_inlined_retval_at_22_24292 = NOVALUE;
    return _retval_inlined_retval_at_25_24293;
    ;
}
int eu_or() __attribute__ ((alias ("_1eu_or")));


int _1eu_xor(int _id1_24296, int _id2_24297)
{
    int _retval_inlined_retval_at_25_24303 = NOVALUE;
    int _ob_inlined_retval_at_22_24302 = NOVALUE;
    int _13365 = NOVALUE;
    int _13364 = NOVALUE;
    int _13363 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24296)) {
        _1 = (long)(DBL_PTR(_id1_24296)->dbl);
        DeRefDS(_id1_24296);
        _id1_24296 = _1;
    }
    if (!IS_ATOM_INT(_id2_24297)) {
        _1 = (long)(DBL_PTR(_id2_24297)->dbl);
        DeRefDS(_id2_24297);
        _id2_24297 = _1;
    }

    /** 	return retval(data[id1] xor data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13363 = (int)*(((s1_ptr)_2)->base + _id1_24296);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13364 = (int)*(((s1_ptr)_2)->base + _id2_24297);
    if (IS_ATOM_INT(_13363) && IS_ATOM_INT(_13364)) {
        _13365 = ((_13363 != 0) != (_13364 != 0));
    }
    else {
        _13365 = binary_op(XOR, _13363, _13364);
    }
    _13363 = NOVALUE;
    _13364 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24302);
    _ob_inlined_retval_at_22_24302 = _13365;
    _13365 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24302);
    _0 = _retval_inlined_retval_at_25_24303;
    _retval_inlined_retval_at_25_24303 = _1register_data(_ob_inlined_retval_at_22_24302);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24302);
    _ob_inlined_retval_at_22_24302 = NOVALUE;
    return _retval_inlined_retval_at_25_24303;
    ;
}
int eu_xor() __attribute__ ((alias ("_1eu_xor")));


void _1eu_question_mark(int _id_24306)
{
    int _13366 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24306)) {
        _1 = (long)(DBL_PTR(_id_24306)->dbl);
        DeRefDS(_id_24306);
        _id_24306 = _1;
    }

    /** 	? data[id]*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13366 = (int)*(((s1_ptr)_2)->base + _id_24306);
    StdPrint(1, _13366, 1);
    _13366 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_question_mark() __attribute__ ((alias ("_1eu_question_mark")));


void _1eu_abort(int _ret_24310)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_24310)) {
        _1 = (long)(DBL_PTR(_ret_24310)->dbl);
        DeRefDS(_ret_24310);
        _ret_24310 = _1;
    }

    /** 	abort(ret)*/
    UserCleanup(_ret_24310);

    /** end procedure*/
    return;
    ;
}
void eu_abort() __attribute__ ((alias ("_1eu_abort")));


int _1eu_and_bits(int _id1_24313, int _id2_24314)
{
    int _retval_inlined_retval_at_25_24320 = NOVALUE;
    int _ob_inlined_retval_at_22_24319 = NOVALUE;
    int _13369 = NOVALUE;
    int _13368 = NOVALUE;
    int _13367 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24313)) {
        _1 = (long)(DBL_PTR(_id1_24313)->dbl);
        DeRefDS(_id1_24313);
        _id1_24313 = _1;
    }
    if (!IS_ATOM_INT(_id2_24314)) {
        _1 = (long)(DBL_PTR(_id2_24314)->dbl);
        DeRefDS(_id2_24314);
        _id2_24314 = _1;
    }

    /** 	return retval(and_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13367 = (int)*(((s1_ptr)_2)->base + _id1_24313);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13368 = (int)*(((s1_ptr)_2)->base + _id2_24314);
    if (IS_ATOM_INT(_13367) && IS_ATOM_INT(_13368)) {
        {unsigned long tu;
             tu = (unsigned long)_13367 & (unsigned long)_13368;
             _13369 = MAKE_UINT(tu);
        }
    }
    else {
        _13369 = binary_op(AND_BITS, _13367, _13368);
    }
    _13367 = NOVALUE;
    _13368 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24319);
    _ob_inlined_retval_at_22_24319 = _13369;
    _13369 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24319);
    _0 = _retval_inlined_retval_at_25_24320;
    _retval_inlined_retval_at_25_24320 = _1register_data(_ob_inlined_retval_at_22_24319);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24319);
    _ob_inlined_retval_at_22_24319 = NOVALUE;
    return _retval_inlined_retval_at_25_24320;
    ;
}
int eu_and_bits() __attribute__ ((alias ("_1eu_and_bits")));


int _1eu_append(int _id1_24323, int _id2_24324)
{
    int _retval_inlined_retval_at_25_24330 = NOVALUE;
    int _ob_inlined_retval_at_22_24329 = NOVALUE;
    int _13372 = NOVALUE;
    int _13371 = NOVALUE;
    int _13370 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24323)) {
        _1 = (long)(DBL_PTR(_id1_24323)->dbl);
        DeRefDS(_id1_24323);
        _id1_24323 = _1;
    }
    if (!IS_ATOM_INT(_id2_24324)) {
        _1 = (long)(DBL_PTR(_id2_24324)->dbl);
        DeRefDS(_id2_24324);
        _id2_24324 = _1;
    }

    /** 	return retval(append(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13370 = (int)*(((s1_ptr)_2)->base + _id1_24323);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13371 = (int)*(((s1_ptr)_2)->base + _id2_24324);
    Ref(_13371);
    Append(&_13372, _13370, _13371);
    _13370 = NOVALUE;
    _13371 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24329);
    _ob_inlined_retval_at_22_24329 = _13372;
    _13372 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24329);
    _0 = _retval_inlined_retval_at_25_24330;
    _retval_inlined_retval_at_25_24330 = _1register_data(_ob_inlined_retval_at_22_24329);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24329);
    _ob_inlined_retval_at_22_24329 = NOVALUE;
    return _retval_inlined_retval_at_25_24330;
    ;
}
int eu_append() __attribute__ ((alias ("_1eu_append")));


int _1eu_arctan(int _id_24333)
{
    int _retval_inlined_retval_at_16_24338 = NOVALUE;
    int _ob_inlined_retval_at_13_24337 = NOVALUE;
    int _13374 = NOVALUE;
    int _13373 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24333)) {
        _1 = (long)(DBL_PTR(_id_24333)->dbl);
        DeRefDS(_id_24333);
        _id_24333 = _1;
    }

    /** 	return retval(arctan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13373 = (int)*(((s1_ptr)_2)->base + _id_24333);
    if (IS_ATOM_INT(_13373))
    _13374 = e_arctan(_13373);
    else
    _13374 = unary_op(ARCTAN, _13373);
    _13373 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24337);
    _ob_inlined_retval_at_13_24337 = _13374;
    _13374 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24337);
    _0 = _retval_inlined_retval_at_16_24338;
    _retval_inlined_retval_at_16_24338 = _1register_data(_ob_inlined_retval_at_13_24337);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24337);
    _ob_inlined_retval_at_13_24337 = NOVALUE;
    return _retval_inlined_retval_at_16_24338;
    ;
}
int eu_arctan() __attribute__ ((alias ("_1eu_arctan")));


int _1eu_atom(int _id_24341)
{
    int _13376 = NOVALUE;
    int _13375 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24341)) {
        _1 = (long)(DBL_PTR(_id_24341)->dbl);
        DeRefDS(_id_24341);
        _id_24341 = _1;
    }

    /** 	return atom(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13375 = (int)*(((s1_ptr)_2)->base + _id_24341);
    _13376 = IS_ATOM(_13375);
    _13375 = NOVALUE;
    return _13376;
    ;
}
int eu_atom() __attribute__ ((alias ("_1eu_atom")));


int _1eu_c_func(int _rid_24346, int _id1_24347)
{
    int _retval_inlined_retval_at_20_24352 = NOVALUE;
    int _ob_inlined_retval_at_17_24351 = NOVALUE;
    int _13378 = NOVALUE;
    int _13377 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24346)) {
        _1 = (long)(DBL_PTR(_rid_24346)->dbl);
        DeRefDS(_rid_24346);
        _rid_24346 = _1;
    }
    if (!IS_ATOM_INT(_id1_24347)) {
        _1 = (long)(DBL_PTR(_id1_24347)->dbl);
        DeRefDS(_id1_24347);
        _id1_24347 = _1;
    }

    /** 	return retval(c_func(rid, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13377 = (int)*(((s1_ptr)_2)->base + _id1_24347);
    _13378 = call_c(1, _rid_24346, _13377);
    _13377 = NOVALUE;
    DeRef(_ob_inlined_retval_at_17_24351);
    _ob_inlined_retval_at_17_24351 = _13378;
    _13378 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_17_24351);
    _0 = _retval_inlined_retval_at_20_24352;
    _retval_inlined_retval_at_20_24352 = _1register_data(_ob_inlined_retval_at_17_24351);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_17_24351);
    _ob_inlined_retval_at_17_24351 = NOVALUE;
    return _retval_inlined_retval_at_20_24352;
    ;
}
int eu_c_func() __attribute__ ((alias ("_1eu_c_func")));


void _1eu_c_proc(int _rid_24355, int _id1_24356)
{
    int _13379 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24355)) {
        _1 = (long)(DBL_PTR(_rid_24355)->dbl);
        DeRefDS(_rid_24355);
        _rid_24355 = _1;
    }
    if (!IS_ATOM_INT(_id1_24356)) {
        _1 = (long)(DBL_PTR(_id1_24356)->dbl);
        DeRefDS(_id1_24356);
        _id1_24356 = _1;
    }

    /** 	c_proc(rid, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13379 = (int)*(((s1_ptr)_2)->base + _id1_24356);
    call_c(0, _rid_24355, _13379);
    _13379 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_c_proc() __attribute__ ((alias ("_1eu_c_proc")));


void _1eu_call(int _low_24360, int _high_24361)
{
    int _get_address_1__tmp_at6_24364 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24363 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24360)) {
        _1 = (long)(DBL_PTR(_low_24360)->dbl);
        DeRefDS(_low_24360);
        _low_24360 = _1;
    }
    if (!IS_ATOM_INT(_high_24361)) {
        _1 = (long)(DBL_PTR(_high_24361)->dbl);
        DeRefDS(_high_24361);
        _high_24361 = _1;
    }

    /** 	call(get_address(low, high))*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24364);
    _get_address_1__tmp_at6_24364 = NewDouble(_high_24361 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24363);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24364)) {
        _get_address_inlined_get_address_at_6_24363 = _get_address_1__tmp_at6_24364 + _low_24360;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24363 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24363 = NewDouble((double)_get_address_inlined_get_address_at_6_24363);
    }
    else {
        _get_address_inlined_get_address_at_6_24363 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24364)->dbl + (double)_low_24360);
    }
    DeRef(_get_address_1__tmp_at6_24364);
    _get_address_1__tmp_at6_24364 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_24363))
    _0 = (int)_get_address_inlined_get_address_at_6_24363;
    else
    _0 = (int)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_24363)->dbl);
    (*(void(*)())_0)();

    /** end procedure*/
    return;
    ;
}
void eu_call() __attribute__ ((alias ("_1eu_call")));


void _1eu_clear_screen()
{
    int _0, _1, _2;
    

    /** 	clear_screen()*/
    ClearScreen();

    /** end procedure*/
    return;
    ;
}
void eu_clear_screen() __attribute__ ((alias ("_1eu_clear_screen")));


void _1eu_close(int _fn_id_24369)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24369)) {
        _1 = (long)(DBL_PTR(_fn_id_24369)->dbl);
        DeRefDS(_fn_id_24369);
        _fn_id_24369 = _1;
    }

    /** 	close(fn_id)*/
    EClose(_fn_id_24369);

    /** end procedure*/
    return;
    ;
}
void eu_close() __attribute__ ((alias ("_1eu_close")));


int _1eu_command_line()
{
    int _retval_inlined_retval_at_7_24375 = NOVALUE;
    int _ob_inlined_retval_at_4_24374 = NOVALUE;
    int _13380 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(command_line())*/
    _13380 = Command_Line();
    DeRef(_ob_inlined_retval_at_4_24374);
    _ob_inlined_retval_at_4_24374 = _13380;
    _13380 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_24374);
    _0 = _retval_inlined_retval_at_7_24375;
    _retval_inlined_retval_at_7_24375 = _1register_data(_ob_inlined_retval_at_4_24374);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_24374);
    _ob_inlined_retval_at_4_24374 = NOVALUE;
    return _retval_inlined_retval_at_7_24375;
    ;
}
int eu_command_line() __attribute__ ((alias ("_1eu_command_line")));


int _1eu_compare(int _id1_24378, int _id2_24379)
{
    int _13383 = NOVALUE;
    int _13382 = NOVALUE;
    int _13381 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24378)) {
        _1 = (long)(DBL_PTR(_id1_24378)->dbl);
        DeRefDS(_id1_24378);
        _id1_24378 = _1;
    }
    if (!IS_ATOM_INT(_id2_24379)) {
        _1 = (long)(DBL_PTR(_id2_24379)->dbl);
        DeRefDS(_id2_24379);
        _id2_24379 = _1;
    }

    /** 	return compare(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13381 = (int)*(((s1_ptr)_2)->base + _id1_24378);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13382 = (int)*(((s1_ptr)_2)->base + _id2_24379);
    if (IS_ATOM_INT(_13381) && IS_ATOM_INT(_13382)){
        _13383 = (_13381 < _13382) ? -1 : (_13381 > _13382);
    }
    else{
        _13383 = compare(_13381, _13382);
    }
    _13381 = NOVALUE;
    _13382 = NOVALUE;
    return _13383;
    ;
}
int eu_compare() __attribute__ ((alias ("_1eu_compare")));


int _1eu_concat(int _id1_24385, int _id2_24386)
{
    int _retval_inlined_retval_at_25_24392 = NOVALUE;
    int _ob_inlined_retval_at_22_24391 = NOVALUE;
    int _13386 = NOVALUE;
    int _13385 = NOVALUE;
    int _13384 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24385)) {
        _1 = (long)(DBL_PTR(_id1_24385)->dbl);
        DeRefDS(_id1_24385);
        _id1_24385 = _1;
    }
    if (!IS_ATOM_INT(_id2_24386)) {
        _1 = (long)(DBL_PTR(_id2_24386)->dbl);
        DeRefDS(_id2_24386);
        _id2_24386 = _1;
    }

    /** 	return retval(data[id1] & data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13384 = (int)*(((s1_ptr)_2)->base + _id1_24385);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13385 = (int)*(((s1_ptr)_2)->base + _id2_24386);
    if (IS_SEQUENCE(_13384) && IS_ATOM(_13385)) {
        Ref(_13385);
        Append(&_13386, _13384, _13385);
    }
    else if (IS_ATOM(_13384) && IS_SEQUENCE(_13385)) {
        Ref(_13384);
        Prepend(&_13386, _13385, _13384);
    }
    else {
        Concat((object_ptr)&_13386, _13384, _13385);
        _13384 = NOVALUE;
    }
    _13384 = NOVALUE;
    _13385 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24391);
    _ob_inlined_retval_at_22_24391 = _13386;
    _13386 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24391);
    _0 = _retval_inlined_retval_at_25_24392;
    _retval_inlined_retval_at_25_24392 = _1register_data(_ob_inlined_retval_at_22_24391);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24391);
    _ob_inlined_retval_at_22_24391 = NOVALUE;
    return _retval_inlined_retval_at_25_24392;
    ;
}
int eu_concat() __attribute__ ((alias ("_1eu_concat")));


int _1eu_cos(int _id_24395)
{
    int _retval_inlined_retval_at_16_24400 = NOVALUE;
    int _ob_inlined_retval_at_13_24399 = NOVALUE;
    int _13388 = NOVALUE;
    int _13387 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24395)) {
        _1 = (long)(DBL_PTR(_id_24395)->dbl);
        DeRefDS(_id_24395);
        _id_24395 = _1;
    }

    /** 	return retval(cos(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13387 = (int)*(((s1_ptr)_2)->base + _id_24395);
    if (IS_ATOM_INT(_13387))
    _13388 = e_cos(_13387);
    else
    _13388 = unary_op(COS, _13387);
    _13387 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24399);
    _ob_inlined_retval_at_13_24399 = _13388;
    _13388 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24399);
    _0 = _retval_inlined_retval_at_16_24400;
    _retval_inlined_retval_at_16_24400 = _1register_data(_ob_inlined_retval_at_13_24399);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24399);
    _ob_inlined_retval_at_13_24399 = NOVALUE;
    return _retval_inlined_retval_at_16_24400;
    ;
}
int eu_cos() __attribute__ ((alias ("_1eu_cos")));


int _1eu_date()
{
    int _retval_inlined_retval_at_7_24406 = NOVALUE;
    int _ob_inlined_retval_at_4_24405 = NOVALUE;
    int _13389 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(date())*/
    _13389 = Date();
    DeRefi(_ob_inlined_retval_at_4_24405);
    _ob_inlined_retval_at_4_24405 = _13389;
    _13389 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_24405);
    _0 = _retval_inlined_retval_at_7_24406;
    _retval_inlined_retval_at_7_24406 = _1register_data(_ob_inlined_retval_at_4_24405);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_4_24405);
    _ob_inlined_retval_at_4_24405 = NOVALUE;
    return _retval_inlined_retval_at_7_24406;
    ;
}
int eu_date() __attribute__ ((alias ("_1eu_date")));


int _1eu_equal(int _id1_24409, int _id2_24410)
{
    int _13392 = NOVALUE;
    int _13391 = NOVALUE;
    int _13390 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24409)) {
        _1 = (long)(DBL_PTR(_id1_24409)->dbl);
        DeRefDS(_id1_24409);
        _id1_24409 = _1;
    }
    if (!IS_ATOM_INT(_id2_24410)) {
        _1 = (long)(DBL_PTR(_id2_24410)->dbl);
        DeRefDS(_id2_24410);
        _id2_24410 = _1;
    }

    /** 	return equal(data[id1], data[id2]) -- boolean, returns 0 or 1*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13390 = (int)*(((s1_ptr)_2)->base + _id1_24409);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13391 = (int)*(((s1_ptr)_2)->base + _id2_24410);
    if (_13390 == _13391)
    _13392 = 1;
    else if (IS_ATOM_INT(_13390) && IS_ATOM_INT(_13391))
    _13392 = 0;
    else
    _13392 = (compare(_13390, _13391) == 0);
    _13390 = NOVALUE;
    _13391 = NOVALUE;
    return _13392;
    ;
}
int eu_equal() __attribute__ ((alias ("_1eu_equal")));


int _1eu_find_from(int _id1_24416, int _id2_24417, int _start_24418)
{
    int _13395 = NOVALUE;
    int _13394 = NOVALUE;
    int _13393 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24416)) {
        _1 = (long)(DBL_PTR(_id1_24416)->dbl);
        DeRefDS(_id1_24416);
        _id1_24416 = _1;
    }
    if (!IS_ATOM_INT(_id2_24417)) {
        _1 = (long)(DBL_PTR(_id2_24417)->dbl);
        DeRefDS(_id2_24417);
        _id2_24417 = _1;
    }
    if (!IS_ATOM_INT(_start_24418)) {
        _1 = (long)(DBL_PTR(_start_24418)->dbl);
        DeRefDS(_start_24418);
        _start_24418 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13393 = (int)*(((s1_ptr)_2)->base + _id1_24416);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13394 = (int)*(((s1_ptr)_2)->base + _id2_24417);
    _13395 = find_from(_13393, _13394, _start_24418);
    _13393 = NOVALUE;
    _13394 = NOVALUE;
    return _13395;
    ;
}
int eu_find_from() __attribute__ ((alias ("_1eu_find_from")));


int _1eu_find(int _id1_24424, int _id2_24425, int _start_24426)
{
    int _13398 = NOVALUE;
    int _13397 = NOVALUE;
    int _13396 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24424)) {
        _1 = (long)(DBL_PTR(_id1_24424)->dbl);
        DeRefDS(_id1_24424);
        _id1_24424 = _1;
    }
    if (!IS_ATOM_INT(_id2_24425)) {
        _1 = (long)(DBL_PTR(_id2_24425)->dbl);
        DeRefDS(_id2_24425);
        _id2_24425 = _1;
    }
    if (!IS_ATOM_INT(_start_24426)) {
        _1 = (long)(DBL_PTR(_start_24426)->dbl);
        DeRefDS(_start_24426);
        _start_24426 = _1;
    }

    /** 	return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13396 = (int)*(((s1_ptr)_2)->base + _id1_24424);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13397 = (int)*(((s1_ptr)_2)->base + _id2_24425);
    _13398 = find_from(_13396, _13397, _start_24426);
    _13396 = NOVALUE;
    _13397 = NOVALUE;
    return _13398;
    ;
}
int eu_find() __attribute__ ((alias ("_1eu_find")));


int _1eu_floor(int _id1_24432)
{
    int _retval_inlined_retval_at_16_24437 = NOVALUE;
    int _ob_inlined_retval_at_13_24436 = NOVALUE;
    int _13400 = NOVALUE;
    int _13399 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24432)) {
        _1 = (long)(DBL_PTR(_id1_24432)->dbl);
        DeRefDS(_id1_24432);
        _id1_24432 = _1;
    }

    /** 	return retval(floor(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13399 = (int)*(((s1_ptr)_2)->base + _id1_24432);
    if (IS_ATOM_INT(_13399))
    _13400 = e_floor(_13399);
    else
    _13400 = unary_op(FLOOR, _13399);
    _13399 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24436);
    _ob_inlined_retval_at_13_24436 = _13400;
    _13400 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24436);
    _0 = _retval_inlined_retval_at_16_24437;
    _retval_inlined_retval_at_16_24437 = _1register_data(_ob_inlined_retval_at_13_24436);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24436);
    _ob_inlined_retval_at_13_24436 = NOVALUE;
    return _retval_inlined_retval_at_16_24437;
    ;
}
int eu_floor() __attribute__ ((alias ("_1eu_floor")));


int _1eu_integer_division(int _id1_24440, int _id2_24441)
{
    int _retval_inlined_retval_at_25_24447 = NOVALUE;
    int _ob_inlined_retval_at_22_24446 = NOVALUE;
    int _13403 = NOVALUE;
    int _13402 = NOVALUE;
    int _13401 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24440)) {
        _1 = (long)(DBL_PTR(_id1_24440)->dbl);
        DeRefDS(_id1_24440);
        _id1_24440 = _1;
    }
    if (!IS_ATOM_INT(_id2_24441)) {
        _1 = (long)(DBL_PTR(_id2_24441)->dbl);
        DeRefDS(_id2_24441);
        _id2_24441 = _1;
    }

    /** 	return retval(floor(data[id1] / data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13401 = (int)*(((s1_ptr)_2)->base + _id1_24440);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13402 = (int)*(((s1_ptr)_2)->base + _id2_24441);
    if (IS_ATOM_INT(_13401) && IS_ATOM_INT(_13402)) {
        if (_13402 > 0 && _13401 >= 0) {
            _13403 = _13401 / _13402;
        }
        else {
            temp_dbl = floor((double)_13401 / (double)_13402);
            if (_13401 != MININT)
            _13403 = (long)temp_dbl;
            else
            _13403 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _13401, _13402);
        _13403 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _13401 = NOVALUE;
    _13402 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24446);
    _ob_inlined_retval_at_22_24446 = _13403;
    _13403 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24446);
    _0 = _retval_inlined_retval_at_25_24447;
    _retval_inlined_retval_at_25_24447 = _1register_data(_ob_inlined_retval_at_22_24446);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24446);
    _ob_inlined_retval_at_22_24446 = NOVALUE;
    return _retval_inlined_retval_at_25_24447;
    ;
}
int eu_integer_division() __attribute__ ((alias ("_1eu_integer_division")));


int _1eu_get_key()
{
    int _13404 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return get_key() -- returns an integer*/
    _13404 = get_key(0);
    return _13404;
    ;
}
int eu_get_key() __attribute__ ((alias ("_1eu_get_key")));


int _1eu_getc(int _fn_id_24453)
{
    int _13405 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24453)) {
        _1 = (long)(DBL_PTR(_fn_id_24453)->dbl);
        DeRefDS(_fn_id_24453);
        _fn_id_24453 = _1;
    }

    /** 	return getc(fn_id) -- returns a character or byte*/
    if (_fn_id_24453 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id_24453, EF_READ);
        last_r_file_no = _fn_id_24453;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _13405 = getc((FILE*)xstdin);
        }
        else
        _13405 = getc(last_r_file_ptr);
    }
    else
    _13405 = getc(last_r_file_ptr);
    return _13405;
    ;
}
int eu_getc() __attribute__ ((alias ("_1eu_getc")));


int _1eu_getenv(int _id1_24457)
{
    int _retval_inlined_retval_at_16_24462 = NOVALUE;
    int _ob_inlined_retval_at_13_24461 = NOVALUE;
    int _13407 = NOVALUE;
    int _13406 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24457)) {
        _1 = (long)(DBL_PTR(_id1_24457)->dbl);
        DeRefDS(_id1_24457);
        _id1_24457 = _1;
    }

    /** 	return retval(getenv(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13406 = (int)*(((s1_ptr)_2)->base + _id1_24457);
    _13407 = EGetEnv(_13406);
    _13406 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_13_24461);
    _ob_inlined_retval_at_13_24461 = _13407;
    _13407 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24461);
    _0 = _retval_inlined_retval_at_16_24462;
    _retval_inlined_retval_at_16_24462 = _1register_data(_ob_inlined_retval_at_13_24461);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_13_24461);
    _ob_inlined_retval_at_13_24461 = NOVALUE;
    return _retval_inlined_retval_at_16_24462;
    ;
}
int eu_getenv() __attribute__ ((alias ("_1eu_getenv")));


int _1eu_gets(int _fn_id_24465)
{
    int _retval_inlined_retval_at_10_24469 = NOVALUE;
    int _ob_inlined_retval_at_7_24468 = NOVALUE;
    int _13408 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24465)) {
        _1 = (long)(DBL_PTR(_fn_id_24465)->dbl);
        DeRefDS(_fn_id_24465);
        _fn_id_24465 = _1;
    }

    /** 	return retval(gets(fn_id))*/
    _13408 = EGets(_fn_id_24465);
    DeRefi(_ob_inlined_retval_at_7_24468);
    _ob_inlined_retval_at_7_24468 = _13408;
    _13408 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_7_24468);
    _0 = _retval_inlined_retval_at_10_24469;
    _retval_inlined_retval_at_10_24469 = _1register_data(_ob_inlined_retval_at_7_24468);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_7_24468);
    _ob_inlined_retval_at_7_24468 = NOVALUE;
    return _retval_inlined_retval_at_10_24469;
    ;
}
int eu_gets() __attribute__ ((alias ("_1eu_gets")));


int _1eu_integer(int _id_24472)
{
    int _13410 = NOVALUE;
    int _13409 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24472)) {
        _1 = (long)(DBL_PTR(_id_24472)->dbl);
        DeRefDS(_id_24472);
        _id_24472 = _1;
    }

    /** 	return integer(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13409 = (int)*(((s1_ptr)_2)->base + _id_24472);
    if (IS_ATOM_INT(_13409))
    _13410 = 1;
    else if (IS_ATOM_DBL(_13409))
    _13410 = IS_ATOM_INT(DoubleToInt(_13409));
    else
    _13410 = 0;
    _13409 = NOVALUE;
    return _13410;
    ;
}
int eu_integer() __attribute__ ((alias ("_1eu_integer")));


int _1eu_length(int _id_24477)
{
    int _13412 = NOVALUE;
    int _13411 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24477)) {
        _1 = (long)(DBL_PTR(_id_24477)->dbl);
        DeRefDS(_id_24477);
        _id_24477 = _1;
    }

    /** 	return length(data[id]) -- small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13411 = (int)*(((s1_ptr)_2)->base + _id_24477);
    if (IS_SEQUENCE(_13411)){
            _13412 = SEQ_PTR(_13411)->length;
    }
    else {
        _13412 = 1;
    }
    _13411 = NOVALUE;
    _13411 = NOVALUE;
    return _13412;
    ;
}
int eu_length() __attribute__ ((alias ("_1eu_length")));


int _1eu_log(int _id_24482)
{
    int _retval_inlined_retval_at_16_24487 = NOVALUE;
    int _ob_inlined_retval_at_13_24486 = NOVALUE;
    int _13414 = NOVALUE;
    int _13413 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24482)) {
        _1 = (long)(DBL_PTR(_id_24482)->dbl);
        DeRefDS(_id_24482);
        _id_24482 = _1;
    }

    /** 	return retval(log(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13413 = (int)*(((s1_ptr)_2)->base + _id_24482);
    if (IS_ATOM_INT(_13413))
    _13414 = e_log(_13413);
    else
    _13414 = unary_op(LOG, _13413);
    _13413 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24486);
    _ob_inlined_retval_at_13_24486 = _13414;
    _13414 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24486);
    _0 = _retval_inlined_retval_at_16_24487;
    _retval_inlined_retval_at_16_24487 = _1register_data(_ob_inlined_retval_at_13_24486);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24486);
    _ob_inlined_retval_at_13_24486 = NOVALUE;
    return _retval_inlined_retval_at_16_24487;
    ;
}
int eu_log() __attribute__ ((alias ("_1eu_log")));


int _1eu_machine_func(int _machine_id_24490, int _id1_24491)
{
    int _retval_inlined_retval_at_19_24496 = NOVALUE;
    int _ob_inlined_retval_at_16_24495 = NOVALUE;
    int _13416 = NOVALUE;
    int _13415 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_24490)) {
        _1 = (long)(DBL_PTR(_machine_id_24490)->dbl);
        DeRefDS(_machine_id_24490);
        _machine_id_24490 = _1;
    }
    if (!IS_ATOM_INT(_id1_24491)) {
        _1 = (long)(DBL_PTR(_id1_24491)->dbl);
        DeRefDS(_id1_24491);
        _id1_24491 = _1;
    }

    /** 	return retval(machine_func(machine_id, data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13415 = (int)*(((s1_ptr)_2)->base + _id1_24491);
    _13416 = machine(_machine_id_24490, _13415);
    _13415 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24495);
    _ob_inlined_retval_at_16_24495 = _13416;
    _13416 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_24495);
    _0 = _retval_inlined_retval_at_19_24496;
    _retval_inlined_retval_at_19_24496 = _1register_data(_ob_inlined_retval_at_16_24495);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24495);
    _ob_inlined_retval_at_16_24495 = NOVALUE;
    return _retval_inlined_retval_at_19_24496;
    ;
}
int eu_machine_func() __attribute__ ((alias ("_1eu_machine_func")));


void _1eu_machine_proc(int _machine_id_24499, int _id1_24500)
{
    int _13417 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_24499)) {
        _1 = (long)(DBL_PTR(_machine_id_24499)->dbl);
        DeRefDS(_machine_id_24499);
        _machine_id_24499 = _1;
    }
    if (!IS_ATOM_INT(_id1_24500)) {
        _1 = (long)(DBL_PTR(_id1_24500)->dbl);
        DeRefDS(_id1_24500);
        _id1_24500 = _1;
    }

    /** 	machine_proc(machine_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13417 = (int)*(((s1_ptr)_2)->base + _id1_24500);
    machine(_machine_id_24499, _13417);
    _13417 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_machine_proc() __attribute__ ((alias ("_1eu_machine_proc")));


int _1eu_match_from(int _id1_24504, int _id2_24505, int _start_24506)
{
    int _13420 = NOVALUE;
    int _13419 = NOVALUE;
    int _13418 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24504)) {
        _1 = (long)(DBL_PTR(_id1_24504)->dbl);
        DeRefDS(_id1_24504);
        _id1_24504 = _1;
    }
    if (!IS_ATOM_INT(_id2_24505)) {
        _1 = (long)(DBL_PTR(_id2_24505)->dbl);
        DeRefDS(_id2_24505);
        _id2_24505 = _1;
    }
    if (!IS_ATOM_INT(_start_24506)) {
        _1 = (long)(DBL_PTR(_start_24506)->dbl);
        DeRefDS(_start_24506);
        _start_24506 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13418 = (int)*(((s1_ptr)_2)->base + _id1_24504);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13419 = (int)*(((s1_ptr)_2)->base + _id2_24505);
    _13420 = e_match_from(_13418, _13419, _start_24506);
    _13418 = NOVALUE;
    _13419 = NOVALUE;
    return _13420;
    ;
}
int eu_match_from() __attribute__ ((alias ("_1eu_match_from")));


int _1eu_match(int _id1_24512, int _id2_24513, int _start_24514)
{
    int _13423 = NOVALUE;
    int _13422 = NOVALUE;
    int _13421 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24512)) {
        _1 = (long)(DBL_PTR(_id1_24512)->dbl);
        DeRefDS(_id1_24512);
        _id1_24512 = _1;
    }
    if (!IS_ATOM_INT(_id2_24513)) {
        _1 = (long)(DBL_PTR(_id2_24513)->dbl);
        DeRefDS(_id2_24513);
        _id2_24513 = _1;
    }
    if (!IS_ATOM_INT(_start_24514)) {
        _1 = (long)(DBL_PTR(_start_24514)->dbl);
        DeRefDS(_start_24514);
        _start_24514 = _1;
    }

    /** 	return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13421 = (int)*(((s1_ptr)_2)->base + _id1_24512);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13422 = (int)*(((s1_ptr)_2)->base + _id2_24513);
    _13423 = e_match_from(_13421, _13422, _start_24514);
    _13421 = NOVALUE;
    _13422 = NOVALUE;
    return _13423;
    ;
}
int eu_match() __attribute__ ((alias ("_1eu_match")));


int _1eu_not_bits(int _id1_24520)
{
    int _retval_inlined_retval_at_16_24525 = NOVALUE;
    int _ob_inlined_retval_at_13_24524 = NOVALUE;
    int _13425 = NOVALUE;
    int _13424 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24520)) {
        _1 = (long)(DBL_PTR(_id1_24520)->dbl);
        DeRefDS(_id1_24520);
        _id1_24520 = _1;
    }

    /** 	return retval(not_bits(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13424 = (int)*(((s1_ptr)_2)->base + _id1_24520);
    if (IS_ATOM_INT(_13424))
    _13425 = not_bits(_13424);
    else
    _13425 = unary_op(NOT_BITS, _13424);
    _13424 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24524);
    _ob_inlined_retval_at_13_24524 = _13425;
    _13425 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24524);
    _0 = _retval_inlined_retval_at_16_24525;
    _retval_inlined_retval_at_16_24525 = _1register_data(_ob_inlined_retval_at_13_24524);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24524);
    _ob_inlined_retval_at_13_24524 = NOVALUE;
    return _retval_inlined_retval_at_16_24525;
    ;
}
int eu_not_bits() __attribute__ ((alias ("_1eu_not_bits")));


int _1eu_object(int _id_24528)
{
    int _13427 = NOVALUE;
    int _13426 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24528)) {
        _1 = (long)(DBL_PTR(_id_24528)->dbl);
        DeRefDS(_id_24528);
        _id_24528 = _1;
    }

    /** 	return not find(id, free_list)*/
    _13426 = find_from(_id_24528, _1free_list_23976, 1);
    _13427 = (_13426 == 0);
    _13426 = NOVALUE;
    return _13427;
    ;
}
int eu_object() __attribute__ ((alias ("_1eu_object")));


int _1eu_open(int _id1_24533, int _id2_24534)
{
    int _13430 = NOVALUE;
    int _13429 = NOVALUE;
    int _13428 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24533)) {
        _1 = (long)(DBL_PTR(_id1_24533)->dbl);
        DeRefDS(_id1_24533);
        _id1_24533 = _1;
    }
    if (!IS_ATOM_INT(_id2_24534)) {
        _1 = (long)(DBL_PTR(_id2_24534)->dbl);
        DeRefDS(_id2_24534);
        _id2_24534 = _1;
    }

    /** 	return open(data[id1], data[id2]) -- returns a small integer*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13428 = (int)*(((s1_ptr)_2)->base + _id1_24533);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13429 = (int)*(((s1_ptr)_2)->base + _id2_24534);
    _13430 = EOpen(_13428, _13429, 0);
    _13428 = NOVALUE;
    _13429 = NOVALUE;
    return _13430;
    ;
}
int eu_open() __attribute__ ((alias ("_1eu_open")));


int _1eu_open_str(int _low_24540, int _high_24541, int _did_24542)
{
    int _get_address_1__tmp_at8_24545 = NOVALUE;
    int _get_address_inlined_get_address_at_8_24544 = NOVALUE;
    int _13433 = NOVALUE;
    int _13432 = NOVALUE;
    int _13431 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24540)) {
        _1 = (long)(DBL_PTR(_low_24540)->dbl);
        DeRefDS(_low_24540);
        _low_24540 = _1;
    }
    if (!IS_ATOM_INT(_high_24541)) {
        _1 = (long)(DBL_PTR(_high_24541)->dbl);
        DeRefDS(_high_24541);
        _high_24541 = _1;
    }
    if (!IS_ATOM_INT(_did_24542)) {
        _1 = (long)(DBL_PTR(_did_24542)->dbl);
        DeRefDS(_did_24542);
        _did_24542 = _1;
    }

    /** 	return open(peek_string(get_address(low, high)), data[did])*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_24545);
    _get_address_1__tmp_at8_24545 = NewDouble(_high_24541 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_8_24544);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_24545)) {
        _get_address_inlined_get_address_at_8_24544 = _get_address_1__tmp_at8_24545 + _low_24540;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_8_24544 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_8_24544 = NewDouble((double)_get_address_inlined_get_address_at_8_24544);
    }
    else {
        _get_address_inlined_get_address_at_8_24544 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_24545)->dbl + (double)_low_24540);
    }
    DeRef(_get_address_1__tmp_at8_24545);
    _get_address_1__tmp_at8_24545 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_8_24544)) {
        _13431 =  NewString((char *)_get_address_inlined_get_address_at_8_24544);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_8_24544)) {
        _13431 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_8_24544)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_8_24544);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13431 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _2 = (int)SEQ_PTR(_1data_23975);
    _13432 = (int)*(((s1_ptr)_2)->base + _did_24542);
    _13433 = EOpen(_13431, _13432, 0);
    DeRef(_13431);
    _13431 = NOVALUE;
    _13432 = NOVALUE;
    return _13433;
    ;
}
int eu_open_str() __attribute__ ((alias ("_1eu_open_str")));


int _1eu_or_bits(int _id1_24551, int _id2_24552)
{
    int _retval_inlined_retval_at_25_24558 = NOVALUE;
    int _ob_inlined_retval_at_22_24557 = NOVALUE;
    int _13436 = NOVALUE;
    int _13435 = NOVALUE;
    int _13434 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24551)) {
        _1 = (long)(DBL_PTR(_id1_24551)->dbl);
        DeRefDS(_id1_24551);
        _id1_24551 = _1;
    }
    if (!IS_ATOM_INT(_id2_24552)) {
        _1 = (long)(DBL_PTR(_id2_24552)->dbl);
        DeRefDS(_id2_24552);
        _id2_24552 = _1;
    }

    /** 	return retval(or_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13434 = (int)*(((s1_ptr)_2)->base + _id1_24551);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13435 = (int)*(((s1_ptr)_2)->base + _id2_24552);
    if (IS_ATOM_INT(_13434) && IS_ATOM_INT(_13435)) {
        {unsigned long tu;
             tu = (unsigned long)_13434 | (unsigned long)_13435;
             _13436 = MAKE_UINT(tu);
        }
    }
    else {
        _13436 = binary_op(OR_BITS, _13434, _13435);
    }
    _13434 = NOVALUE;
    _13435 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24557);
    _ob_inlined_retval_at_22_24557 = _13436;
    _13436 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24557);
    _0 = _retval_inlined_retval_at_25_24558;
    _retval_inlined_retval_at_25_24558 = _1register_data(_ob_inlined_retval_at_22_24557);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24557);
    _ob_inlined_retval_at_22_24557 = NOVALUE;
    return _retval_inlined_retval_at_25_24558;
    ;
}
int eu_or_bits() __attribute__ ((alias ("_1eu_or_bits")));


int _1eu_peek(int _id1_24561)
{
    int _retval_inlined_retval_at_16_24566 = NOVALUE;
    int _ob_inlined_retval_at_13_24565 = NOVALUE;
    int _13438 = NOVALUE;
    int _13437 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24561)) {
        _1 = (long)(DBL_PTR(_id1_24561)->dbl);
        DeRefDS(_id1_24561);
        _id1_24561 = _1;
    }

    /** 	return retval(peek(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13437 = (int)*(((s1_ptr)_2)->base + _id1_24561);
    if (IS_ATOM_INT(_13437)) {
        _13438 = *(unsigned char *)_13437;
    }
    else if (IS_ATOM(_13437)) {
        _13438 = *(unsigned char *)(unsigned long)(DBL_PTR(_13437)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13437);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13438 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13437 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24565);
    _ob_inlined_retval_at_13_24565 = _13438;
    _13438 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24565);
    _0 = _retval_inlined_retval_at_16_24566;
    _retval_inlined_retval_at_16_24566 = _1register_data(_ob_inlined_retval_at_13_24565);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24565);
    _ob_inlined_retval_at_13_24565 = NOVALUE;
    return _retval_inlined_retval_at_16_24566;
    ;
}
int eu_peek() __attribute__ ((alias ("_1eu_peek")));


int _1eu_peek4s(int _id1_24569)
{
    int _retval_inlined_retval_at_16_24574 = NOVALUE;
    int _ob_inlined_retval_at_13_24573 = NOVALUE;
    int _13440 = NOVALUE;
    int _13439 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24569)) {
        _1 = (long)(DBL_PTR(_id1_24569)->dbl);
        DeRefDS(_id1_24569);
        _id1_24569 = _1;
    }

    /** 	return retval(peek4s(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13439 = (int)*(((s1_ptr)_2)->base + _id1_24569);
    if (IS_ATOM_INT(_13439)) {
        _13440 = *(unsigned long *)_13439;
        if (_13440 < MININT || _13440 > MAXINT)
        _13440 = NewDouble((double)(long)_13440);
    }
    else if (IS_ATOM(_13439)) {
        _13440 = *(unsigned long *)(unsigned long)(DBL_PTR(_13439)->dbl);
        if (_13440 < MININT || _13440 > MAXINT)
        _13440 = NewDouble((double)(long)_13440);
    }
    else {
        _1 = (int)SEQ_PTR(_13439);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13440 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13439 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24573);
    _ob_inlined_retval_at_13_24573 = _13440;
    _13440 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24573);
    _0 = _retval_inlined_retval_at_16_24574;
    _retval_inlined_retval_at_16_24574 = _1register_data(_ob_inlined_retval_at_13_24573);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24573);
    _ob_inlined_retval_at_13_24573 = NOVALUE;
    return _retval_inlined_retval_at_16_24574;
    ;
}
int eu_peek4s() __attribute__ ((alias ("_1eu_peek4s")));


int _1eu_peek4u(int _id1_24577)
{
    int _retval_inlined_retval_at_16_24582 = NOVALUE;
    int _ob_inlined_retval_at_13_24581 = NOVALUE;
    int _13442 = NOVALUE;
    int _13441 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24577)) {
        _1 = (long)(DBL_PTR(_id1_24577)->dbl);
        DeRefDS(_id1_24577);
        _id1_24577 = _1;
    }

    /** 	return retval(peek4u(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13441 = (int)*(((s1_ptr)_2)->base + _id1_24577);
    if (IS_ATOM_INT(_13441)) {
        _13442 = *(unsigned long *)_13441;
        if ((unsigned)_13442 > (unsigned)MAXINT)
        _13442 = NewDouble((double)(unsigned long)_13442);
    }
    else if (IS_ATOM(_13441)) {
        _13442 = *(unsigned long *)(unsigned long)(DBL_PTR(_13441)->dbl);
        if ((unsigned)_13442 > (unsigned)MAXINT)
        _13442 = NewDouble((double)(unsigned long)_13442);
    }
    else {
        _1 = (int)SEQ_PTR(_13441);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13442 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13441 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24581);
    _ob_inlined_retval_at_13_24581 = _13442;
    _13442 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24581);
    _0 = _retval_inlined_retval_at_16_24582;
    _retval_inlined_retval_at_16_24582 = _1register_data(_ob_inlined_retval_at_13_24581);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24581);
    _ob_inlined_retval_at_13_24581 = NOVALUE;
    return _retval_inlined_retval_at_16_24582;
    ;
}
int eu_peek4u() __attribute__ ((alias ("_1eu_peek4u")));


int _1eu_platform()
{
    int _0, _1, _2;
    

    /** 	return platform() -- returns an integer*/
    return 3;
    ;
}
int eu_platform() __attribute__ ((alias ("_1eu_platform")));


void _1eu_poke(int _id1_24587, int _id2_24588)
{
    int _13444 = NOVALUE;
    int _13443 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24587)) {
        _1 = (long)(DBL_PTR(_id1_24587)->dbl);
        DeRefDS(_id1_24587);
        _id1_24587 = _1;
    }
    if (!IS_ATOM_INT(_id2_24588)) {
        _1 = (long)(DBL_PTR(_id2_24588)->dbl);
        DeRefDS(_id2_24588);
        _id2_24588 = _1;
    }

    /** 	poke(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13443 = (int)*(((s1_ptr)_2)->base + _id1_24587);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13444 = (int)*(((s1_ptr)_2)->base + _id2_24588);
    if (IS_ATOM_INT(_13443)){
        poke_addr = (unsigned char *)_13443;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13443)->dbl);
    }
    if (IS_ATOM_INT(_13444)) {
        *poke_addr = (unsigned char)_13444;
    }
    else if (IS_ATOM(_13444)) {
        *poke_addr = (signed char)DBL_PTR(_13444)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13444);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13443 = NOVALUE;
    _13444 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke() __attribute__ ((alias ("_1eu_poke")));


void _1eu_poke4(int _id1_24593, int _id2_24594)
{
    int _13446 = NOVALUE;
    int _13445 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24593)) {
        _1 = (long)(DBL_PTR(_id1_24593)->dbl);
        DeRefDS(_id1_24593);
        _id1_24593 = _1;
    }
    if (!IS_ATOM_INT(_id2_24594)) {
        _1 = (long)(DBL_PTR(_id2_24594)->dbl);
        DeRefDS(_id2_24594);
        _id2_24594 = _1;
    }

    /** 	poke4(data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13445 = (int)*(((s1_ptr)_2)->base + _id1_24593);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13446 = (int)*(((s1_ptr)_2)->base + _id2_24594);
    if (IS_ATOM_INT(_13445)){
        poke4_addr = (unsigned long *)_13445;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13445)->dbl);
    }
    if (IS_ATOM_INT(_13446)) {
        *poke4_addr = (unsigned long)_13446;
    }
    else if (IS_ATOM(_13446)) {
        *poke4_addr = (unsigned long)DBL_PTR(_13446)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13446);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13445 = NOVALUE;
    _13446 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke4() __attribute__ ((alias ("_1eu_poke4")));


void _1eu_position(int _row_24599, int _column_24600)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_row_24599)) {
        _1 = (long)(DBL_PTR(_row_24599)->dbl);
        DeRefDS(_row_24599);
        _row_24599 = _1;
    }
    if (!IS_ATOM_INT(_column_24600)) {
        _1 = (long)(DBL_PTR(_column_24600)->dbl);
        DeRefDS(_column_24600);
        _column_24600 = _1;
    }

    /** 	position(row, column)*/
    Position(_row_24599, _column_24600);

    /** end procedure*/
    return;
    ;
}
void eu_position() __attribute__ ((alias ("_1eu_position")));


int _1eu_power(int _id1_24603, int _id2_24604)
{
    int _retval_inlined_retval_at_25_24610 = NOVALUE;
    int _ob_inlined_retval_at_22_24609 = NOVALUE;
    int _13449 = NOVALUE;
    int _13448 = NOVALUE;
    int _13447 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24603)) {
        _1 = (long)(DBL_PTR(_id1_24603)->dbl);
        DeRefDS(_id1_24603);
        _id1_24603 = _1;
    }
    if (!IS_ATOM_INT(_id2_24604)) {
        _1 = (long)(DBL_PTR(_id2_24604)->dbl);
        DeRefDS(_id2_24604);
        _id2_24604 = _1;
    }

    /** 	return retval(power(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13447 = (int)*(((s1_ptr)_2)->base + _id1_24603);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13448 = (int)*(((s1_ptr)_2)->base + _id2_24604);
    if (IS_ATOM_INT(_13447) && IS_ATOM_INT(_13448)) {
        _13449 = power(_13447, _13448);
    }
    else {
        _13449 = binary_op(POWER, _13447, _13448);
    }
    _13447 = NOVALUE;
    _13448 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24609);
    _ob_inlined_retval_at_22_24609 = _13449;
    _13449 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24609);
    _0 = _retval_inlined_retval_at_25_24610;
    _retval_inlined_retval_at_25_24610 = _1register_data(_ob_inlined_retval_at_22_24609);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24609);
    _ob_inlined_retval_at_22_24609 = NOVALUE;
    return _retval_inlined_retval_at_25_24610;
    ;
}
int eu_power() __attribute__ ((alias ("_1eu_power")));


int _1eu_prepend(int _id1_24613, int _id2_24614)
{
    int _retval_inlined_retval_at_25_24620 = NOVALUE;
    int _ob_inlined_retval_at_22_24619 = NOVALUE;
    int _13452 = NOVALUE;
    int _13451 = NOVALUE;
    int _13450 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24613)) {
        _1 = (long)(DBL_PTR(_id1_24613)->dbl);
        DeRefDS(_id1_24613);
        _id1_24613 = _1;
    }
    if (!IS_ATOM_INT(_id2_24614)) {
        _1 = (long)(DBL_PTR(_id2_24614)->dbl);
        DeRefDS(_id2_24614);
        _id2_24614 = _1;
    }

    /** 	return retval(prepend(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13450 = (int)*(((s1_ptr)_2)->base + _id1_24613);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13451 = (int)*(((s1_ptr)_2)->base + _id2_24614);
    Ref(_13451);
    Prepend(&_13452, _13450, _13451);
    _13450 = NOVALUE;
    _13451 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24619);
    _ob_inlined_retval_at_22_24619 = _13452;
    _13452 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24619);
    _0 = _retval_inlined_retval_at_25_24620;
    _retval_inlined_retval_at_25_24620 = _1register_data(_ob_inlined_retval_at_22_24619);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24619);
    _ob_inlined_retval_at_22_24619 = NOVALUE;
    return _retval_inlined_retval_at_25_24620;
    ;
}
int eu_prepend() __attribute__ ((alias ("_1eu_prepend")));


void _1eu_print(int _fn_id_24623, int _id1_24624)
{
    int _13453 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24623)) {
        _1 = (long)(DBL_PTR(_fn_id_24623)->dbl);
        DeRefDS(_fn_id_24623);
        _fn_id_24623 = _1;
    }
    if (!IS_ATOM_INT(_id1_24624)) {
        _1 = (long)(DBL_PTR(_id1_24624)->dbl);
        DeRefDS(_id1_24624);
        _id1_24624 = _1;
    }

    /** 	print(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13453 = (int)*(((s1_ptr)_2)->base + _id1_24624);
    StdPrint(_fn_id_24623, _13453, 0);
    _13453 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_print() __attribute__ ((alias ("_1eu_print")));


void _1eu_printf(int _fn_id_24628, int _id1_24629, int _id2_24630)
{
    int _13455 = NOVALUE;
    int _13454 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24628)) {
        _1 = (long)(DBL_PTR(_fn_id_24628)->dbl);
        DeRefDS(_fn_id_24628);
        _fn_id_24628 = _1;
    }
    if (!IS_ATOM_INT(_id1_24629)) {
        _1 = (long)(DBL_PTR(_id1_24629)->dbl);
        DeRefDS(_id1_24629);
        _id1_24629 = _1;
    }
    if (!IS_ATOM_INT(_id2_24630)) {
        _1 = (long)(DBL_PTR(_id2_24630)->dbl);
        DeRefDS(_id2_24630);
        _id2_24630 = _1;
    }

    /** 	printf(fn_id, data[id1], data[id2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13454 = (int)*(((s1_ptr)_2)->base + _id1_24629);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13455 = (int)*(((s1_ptr)_2)->base + _id2_24630);
    EPrintf(_fn_id_24628, _13454, _13455);
    _13454 = NOVALUE;
    _13455 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_printf() __attribute__ ((alias ("_1eu_printf")));


void _1eu_puts(int _fn_id_24635, int _id1_24636)
{
    int _13456 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_24635)) {
        _1 = (long)(DBL_PTR(_fn_id_24635)->dbl);
        DeRefDS(_fn_id_24635);
        _fn_id_24635 = _1;
    }
    if (!IS_ATOM_INT(_id1_24636)) {
        _1 = (long)(DBL_PTR(_id1_24636)->dbl);
        DeRefDS(_id1_24636);
        _id1_24636 = _1;
    }

    /** 	puts(fn_id, data[id1])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13456 = (int)*(((s1_ptr)_2)->base + _id1_24636);
    EPuts(_fn_id_24635, _13456); // DJP 
    _13456 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_puts() __attribute__ ((alias ("_1eu_puts")));


int _1eu_rand(int _id1_24640)
{
    int _retval_inlined_retval_at_16_24645 = NOVALUE;
    int _ob_inlined_retval_at_13_24644 = NOVALUE;
    int _13458 = NOVALUE;
    int _13457 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24640)) {
        _1 = (long)(DBL_PTR(_id1_24640)->dbl);
        DeRefDS(_id1_24640);
        _id1_24640 = _1;
    }

    /** 	return retval(rand(data[id1]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13457 = (int)*(((s1_ptr)_2)->base + _id1_24640);
    if (IS_ATOM_INT(_13457)) {
        _13458 = good_rand() % ((unsigned)_13457) + 1;
    }
    else {
        _13458 = unary_op(RAND, _13457);
    }
    _13457 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24644);
    _ob_inlined_retval_at_13_24644 = _13458;
    _13458 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24644);
    _0 = _retval_inlined_retval_at_16_24645;
    _retval_inlined_retval_at_16_24645 = _1register_data(_ob_inlined_retval_at_13_24644);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24644);
    _ob_inlined_retval_at_13_24644 = NOVALUE;
    return _retval_inlined_retval_at_16_24645;
    ;
}
int eu_rand() __attribute__ ((alias ("_1eu_rand")));


int _1eu_remainder(int _id1_24648, int _id2_24649)
{
    int _retval_inlined_retval_at_25_24655 = NOVALUE;
    int _ob_inlined_retval_at_22_24654 = NOVALUE;
    int _13461 = NOVALUE;
    int _13460 = NOVALUE;
    int _13459 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24648)) {
        _1 = (long)(DBL_PTR(_id1_24648)->dbl);
        DeRefDS(_id1_24648);
        _id1_24648 = _1;
    }
    if (!IS_ATOM_INT(_id2_24649)) {
        _1 = (long)(DBL_PTR(_id2_24649)->dbl);
        DeRefDS(_id2_24649);
        _id2_24649 = _1;
    }

    /** 	return retval(remainder(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13459 = (int)*(((s1_ptr)_2)->base + _id1_24648);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13460 = (int)*(((s1_ptr)_2)->base + _id2_24649);
    if (IS_ATOM_INT(_13459) && IS_ATOM_INT(_13460)) {
        _13461 = (_13459 % _13460);
    }
    else {
        _13461 = binary_op(REMAINDER, _13459, _13460);
    }
    _13459 = NOVALUE;
    _13460 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24654);
    _ob_inlined_retval_at_22_24654 = _13461;
    _13461 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24654);
    _0 = _retval_inlined_retval_at_25_24655;
    _retval_inlined_retval_at_25_24655 = _1register_data(_ob_inlined_retval_at_22_24654);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24654);
    _ob_inlined_retval_at_22_24654 = NOVALUE;
    return _retval_inlined_retval_at_25_24655;
    ;
}
int eu_remainder() __attribute__ ((alias ("_1eu_remainder")));


int _1eu_sequence(int _id_24658)
{
    int _13463 = NOVALUE;
    int _13462 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24658)) {
        _1 = (long)(DBL_PTR(_id_24658)->dbl);
        DeRefDS(_id_24658);
        _id_24658 = _1;
    }

    /** 	return sequence(data[id]) -- boolean*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13462 = (int)*(((s1_ptr)_2)->base + _id_24658);
    _13463 = IS_SEQUENCE(_13462);
    _13462 = NOVALUE;
    return _13463;
    ;
}
int eu_sequence() __attribute__ ((alias ("_1eu_sequence")));


int _1eu_sin(int _id_24663)
{
    int _retval_inlined_retval_at_16_24668 = NOVALUE;
    int _ob_inlined_retval_at_13_24667 = NOVALUE;
    int _13465 = NOVALUE;
    int _13464 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24663)) {
        _1 = (long)(DBL_PTR(_id_24663)->dbl);
        DeRefDS(_id_24663);
        _id_24663 = _1;
    }

    /** 	return retval(sin(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13464 = (int)*(((s1_ptr)_2)->base + _id_24663);
    if (IS_ATOM_INT(_13464))
    _13465 = e_sin(_13464);
    else
    _13465 = unary_op(SIN, _13464);
    _13464 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24667);
    _ob_inlined_retval_at_13_24667 = _13465;
    _13465 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24667);
    _0 = _retval_inlined_retval_at_16_24668;
    _retval_inlined_retval_at_16_24668 = _1register_data(_ob_inlined_retval_at_13_24667);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24667);
    _ob_inlined_retval_at_13_24667 = NOVALUE;
    return _retval_inlined_retval_at_16_24668;
    ;
}
int eu_sin() __attribute__ ((alias ("_1eu_sin")));


int _1eu_sprintf(int _id1_24671, int _id2_24672)
{
    int _retval_inlined_retval_at_25_24678 = NOVALUE;
    int _ob_inlined_retval_at_22_24677 = NOVALUE;
    int _13468 = NOVALUE;
    int _13467 = NOVALUE;
    int _13466 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24671)) {
        _1 = (long)(DBL_PTR(_id1_24671)->dbl);
        DeRefDS(_id1_24671);
        _id1_24671 = _1;
    }
    if (!IS_ATOM_INT(_id2_24672)) {
        _1 = (long)(DBL_PTR(_id2_24672)->dbl);
        DeRefDS(_id2_24672);
        _id2_24672 = _1;
    }

    /** 	return retval(sprintf(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13466 = (int)*(((s1_ptr)_2)->base + _id1_24671);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13467 = (int)*(((s1_ptr)_2)->base + _id2_24672);
    _13468 = EPrintf(-9999999, _13466, _13467);
    _13466 = NOVALUE;
    _13467 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_22_24677);
    _ob_inlined_retval_at_22_24677 = _13468;
    _13468 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_24677);
    _0 = _retval_inlined_retval_at_25_24678;
    _retval_inlined_retval_at_25_24678 = _1register_data(_ob_inlined_retval_at_22_24677);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_22_24677);
    _ob_inlined_retval_at_22_24677 = NOVALUE;
    return _retval_inlined_retval_at_25_24678;
    ;
}
int eu_sprintf() __attribute__ ((alias ("_1eu_sprintf")));


int _1eu_sqrt(int _id_24681)
{
    int _retval_inlined_retval_at_16_24686 = NOVALUE;
    int _ob_inlined_retval_at_13_24685 = NOVALUE;
    int _13470 = NOVALUE;
    int _13469 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24681)) {
        _1 = (long)(DBL_PTR(_id_24681)->dbl);
        DeRefDS(_id_24681);
        _id_24681 = _1;
    }

    /** 	return retval(sqrt(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13469 = (int)*(((s1_ptr)_2)->base + _id_24681);
    if (IS_ATOM_INT(_13469))
    _13470 = e_sqrt(_13469);
    else
    _13470 = unary_op(SQRT, _13469);
    _13469 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24685);
    _ob_inlined_retval_at_13_24685 = _13470;
    _13470 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24685);
    _0 = _retval_inlined_retval_at_16_24686;
    _retval_inlined_retval_at_16_24686 = _1register_data(_ob_inlined_retval_at_13_24685);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24685);
    _ob_inlined_retval_at_13_24685 = NOVALUE;
    return _retval_inlined_retval_at_16_24686;
    ;
}
int eu_sqrt() __attribute__ ((alias ("_1eu_sqrt")));


int _1eu_subscript(int _id_24689, int _start_24690, int _stop_24691)
{
    int _retval_inlined_retval_at_22_24696 = NOVALUE;
    int _ob_inlined_retval_at_19_24695 = NOVALUE;
    int _13472 = NOVALUE;
    int _13471 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24689)) {
        _1 = (long)(DBL_PTR(_id_24689)->dbl);
        DeRefDS(_id_24689);
        _id_24689 = _1;
    }
    if (!IS_ATOM_INT(_start_24690)) {
        _1 = (long)(DBL_PTR(_start_24690)->dbl);
        DeRefDS(_start_24690);
        _start_24690 = _1;
    }
    if (!IS_ATOM_INT(_stop_24691)) {
        _1 = (long)(DBL_PTR(_stop_24691)->dbl);
        DeRefDS(_stop_24691);
        _stop_24691 = _1;
    }

    /** 	return retval(data[id][start..stop])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13471 = (int)*(((s1_ptr)_2)->base + _id_24689);
    rhs_slice_target = (object_ptr)&_13472;
    RHS_Slice(_13471, _start_24690, _stop_24691);
    _13471 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_24695);
    _ob_inlined_retval_at_19_24695 = _13472;
    _13472 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_24695);
    _0 = _retval_inlined_retval_at_22_24696;
    _retval_inlined_retval_at_22_24696 = _1register_data(_ob_inlined_retval_at_19_24695);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_24695);
    _ob_inlined_retval_at_19_24695 = NOVALUE;
    return _retval_inlined_retval_at_22_24696;
    ;
}
int eu_subscript() __attribute__ ((alias ("_1eu_subscript")));


void _1eu_system(int _id1_24699, int _mode_24700)
{
    int _13473 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24699)) {
        _1 = (long)(DBL_PTR(_id1_24699)->dbl);
        DeRefDS(_id1_24699);
        _id1_24699 = _1;
    }
    if (!IS_ATOM_INT(_mode_24700)) {
        _1 = (long)(DBL_PTR(_mode_24700)->dbl);
        DeRefDS(_mode_24700);
        _mode_24700 = _1;
    }

    /** 	system(data[id1], mode)*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13473 = (int)*(((s1_ptr)_2)->base + _id1_24699);
    system_call(_13473, _mode_24700);
    _13473 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_system() __attribute__ ((alias ("_1eu_system")));


int _1eu_system_exec(int _id1_24704, int _mode_24705)
{
    int _13475 = NOVALUE;
    int _13474 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24704)) {
        _1 = (long)(DBL_PTR(_id1_24704)->dbl);
        DeRefDS(_id1_24704);
        _id1_24704 = _1;
    }
    if (!IS_ATOM_INT(_mode_24705)) {
        _1 = (long)(DBL_PTR(_mode_24705)->dbl);
        DeRefDS(_mode_24705);
        _mode_24705 = _1;
    }

    /** 	return system_exec(data[id1], mode) -- returns the exit code from the called process.*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13474 = (int)*(((s1_ptr)_2)->base + _id1_24704);
    _13475 = system_exec_call(_13474, _mode_24705);
    _13474 = NOVALUE;
    return _13475;
    ;
}
int eu_system_exec() __attribute__ ((alias ("_1eu_system_exec")));


int _1eu_tan(int _id_24710)
{
    int _retval_inlined_retval_at_16_24715 = NOVALUE;
    int _ob_inlined_retval_at_13_24714 = NOVALUE;
    int _13477 = NOVALUE;
    int _13476 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_24710)) {
        _1 = (long)(DBL_PTR(_id_24710)->dbl);
        DeRefDS(_id_24710);
        _id_24710 = _1;
    }

    /** 	return retval(tan(data[id]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13476 = (int)*(((s1_ptr)_2)->base + _id_24710);
    if (IS_ATOM_INT(_13476))
    _13477 = e_tan(_13476);
    else
    _13477 = unary_op(TAN, _13476);
    _13476 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24714);
    _ob_inlined_retval_at_13_24714 = _13477;
    _13477 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24714);
    _0 = _retval_inlined_retval_at_16_24715;
    _retval_inlined_retval_at_16_24715 = _1register_data(_ob_inlined_retval_at_13_24714);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24714);
    _ob_inlined_retval_at_13_24714 = NOVALUE;
    return _retval_inlined_retval_at_16_24715;
    ;
}
int eu_tan() __attribute__ ((alias ("_1eu_tan")));


int _1eu_time()
{
    int _retval_inlined_retval_at_7_24721 = NOVALUE;
    int _ob_inlined_retval_at_4_24720 = NOVALUE;
    int _13478 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return retval(time())*/
    _13478 = NewDouble(current_time());
    DeRef(_ob_inlined_retval_at_4_24720);
    _ob_inlined_retval_at_4_24720 = _13478;
    _13478 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_24720);
    _0 = _retval_inlined_retval_at_7_24721;
    _retval_inlined_retval_at_7_24721 = _1register_data(_ob_inlined_retval_at_4_24720);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_24720);
    _ob_inlined_retval_at_4_24720 = NOVALUE;
    return _retval_inlined_retval_at_7_24721;
    ;
}
int eu_time() __attribute__ ((alias ("_1eu_time")));


int _1eu_xor_bits(int _id1_24724, int _id2_24725)
{
    int _retval_inlined_retval_at_25_24731 = NOVALUE;
    int _ob_inlined_retval_at_22_24730 = NOVALUE;
    int _13481 = NOVALUE;
    int _13480 = NOVALUE;
    int _13479 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_24724)) {
        _1 = (long)(DBL_PTR(_id1_24724)->dbl);
        DeRefDS(_id1_24724);
        _id1_24724 = _1;
    }
    if (!IS_ATOM_INT(_id2_24725)) {
        _1 = (long)(DBL_PTR(_id2_24725)->dbl);
        DeRefDS(_id2_24725);
        _id2_24725 = _1;
    }

    /** 	return retval(xor_bits(data[id1], data[id2]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13479 = (int)*(((s1_ptr)_2)->base + _id1_24724);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13480 = (int)*(((s1_ptr)_2)->base + _id2_24725);
    if (IS_ATOM_INT(_13479) && IS_ATOM_INT(_13480)) {
        {unsigned long tu;
             tu = (unsigned long)_13479 ^ (unsigned long)_13480;
             _13481 = MAKE_UINT(tu);
        }
    }
    else {
        _13481 = binary_op(XOR_BITS, _13479, _13480);
    }
    _13479 = NOVALUE;
    _13480 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_24730);
    _ob_inlined_retval_at_22_24730 = _13481;
    _13481 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_24730);
    _0 = _retval_inlined_retval_at_25_24731;
    _retval_inlined_retval_at_25_24731 = _1register_data(_ob_inlined_retval_at_22_24730);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_24730);
    _ob_inlined_retval_at_22_24730 = NOVALUE;
    return _retval_inlined_retval_at_25_24731;
    ;
}
int eu_xor_bits() __attribute__ ((alias ("_1eu_xor_bits")));


int _1eu_hash(int _did_24734, int _algorithm_24735)
{
    int _retval_inlined_retval_at_19_24740 = NOVALUE;
    int _ob_inlined_retval_at_16_24739 = NOVALUE;
    int _13483 = NOVALUE;
    int _13482 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24734)) {
        _1 = (long)(DBL_PTR(_did_24734)->dbl);
        DeRefDS(_did_24734);
        _did_24734 = _1;
    }
    if (!IS_ATOM_INT(_algorithm_24735)) {
        _1 = (long)(DBL_PTR(_algorithm_24735)->dbl);
        DeRefDS(_algorithm_24735);
        _algorithm_24735 = _1;
    }

    /** 	return retval(hash(data[did], algorithm))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13482 = (int)*(((s1_ptr)_2)->base + _did_24734);
    _13483 = calc_hash(_13482, _algorithm_24735);
    _13482 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24739);
    _ob_inlined_retval_at_16_24739 = _13483;
    _13483 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_24739);
    _0 = _retval_inlined_retval_at_19_24740;
    _retval_inlined_retval_at_19_24740 = _1register_data(_ob_inlined_retval_at_16_24739);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24739);
    _ob_inlined_retval_at_16_24739 = NOVALUE;
    return _retval_inlined_retval_at_19_24740;
    ;
}
int eu_hash() __attribute__ ((alias ("_1eu_hash")));


int _1eu_head(int _did_24743, int _len_24744)
{
    int _retval_inlined_retval_at_19_24749 = NOVALUE;
    int _ob_inlined_retval_at_16_24748 = NOVALUE;
    int _13485 = NOVALUE;
    int _13484 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24743)) {
        _1 = (long)(DBL_PTR(_did_24743)->dbl);
        DeRefDS(_did_24743);
        _did_24743 = _1;
    }
    if (!IS_ATOM_INT(_len_24744)) {
        _1 = (long)(DBL_PTR(_len_24744)->dbl);
        DeRefDS(_len_24744);
        _len_24744 = _1;
    }

    /** 	return retval(head(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13484 = (int)*(((s1_ptr)_2)->base + _did_24743);
    {
        int len = SEQ_PTR(_13484)->length;
        int size = (IS_ATOM_INT(_len_24744)) ? _len_24744 : (object)(DBL_PTR(_len_24744)->dbl);
        if (size <= 0){
            DeRef( _13485 );
            _13485 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_13484);
            DeRef(_13485);
            _13485 = _13484;
        }
        else{
            Head(SEQ_PTR(_13484),size+1,&_13485);
        }
    }
    _13484 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24748);
    _ob_inlined_retval_at_16_24748 = _13485;
    _13485 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_24748);
    _0 = _retval_inlined_retval_at_19_24749;
    _retval_inlined_retval_at_19_24749 = _1register_data(_ob_inlined_retval_at_16_24748);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24748);
    _ob_inlined_retval_at_16_24748 = NOVALUE;
    return _retval_inlined_retval_at_19_24749;
    ;
}
int eu_head() __attribute__ ((alias ("_1eu_head")));


int _1eu_include_paths(int _convert_24752)
{
    int _retval_inlined_retval_at_13_24759 = NOVALUE;
    int _ob_inlined_retval_at_10_24758 = NOVALUE;
    int _13489 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_convert_24752)) {
        _1 = (long)(DBL_PTR(_convert_24752)->dbl);
        DeRefDS(_convert_24752);
        _convert_24752 = _1;
    }

    /** 	return retval(include_paths(convert))*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13488);
    *((int *)(_2+4)) = _13488;
    RefDS(_13487);
    *((int *)(_2+8)) = _13487;
    RefDS(_13486);
    *((int *)(_2+12)) = _13486;
    _13489 = MAKE_SEQ(_1);
    DeRef(_ob_inlined_retval_at_10_24758);
    _ob_inlined_retval_at_10_24758 = _13489;
    _13489 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_10_24758);
    _0 = _retval_inlined_retval_at_13_24759;
    _retval_inlined_retval_at_13_24759 = _1register_data(_ob_inlined_retval_at_10_24758);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_10_24758);
    _ob_inlined_retval_at_10_24758 = NOVALUE;
    return _retval_inlined_retval_at_13_24759;
    ;
}
int eu_include_paths() __attribute__ ((alias ("_1eu_include_paths")));


int _1eu_insert(int _did1_24762, int _did2_24763, int _index_24764)
{
    int _retval_inlined_retval_at_28_24770 = NOVALUE;
    int _ob_inlined_retval_at_25_24769 = NOVALUE;
    int _13492 = NOVALUE;
    int _13491 = NOVALUE;
    int _13490 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_24762)) {
        _1 = (long)(DBL_PTR(_did1_24762)->dbl);
        DeRefDS(_did1_24762);
        _did1_24762 = _1;
    }
    if (!IS_ATOM_INT(_did2_24763)) {
        _1 = (long)(DBL_PTR(_did2_24763)->dbl);
        DeRefDS(_did2_24763);
        _did2_24763 = _1;
    }
    if (!IS_ATOM_INT(_index_24764)) {
        _1 = (long)(DBL_PTR(_index_24764)->dbl);
        DeRefDS(_index_24764);
        _index_24764 = _1;
    }

    /** 	return retval(insert(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13490 = (int)*(((s1_ptr)_2)->base + _did1_24762);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13491 = (int)*(((s1_ptr)_2)->base + _did2_24763);
    {
        s1_ptr assign_space;
        insert_pos = _index_24764;
        if (insert_pos <= 0){
            Prepend(&_13492,_13490,_13491);
        }
        else if (insert_pos > SEQ_PTR(_13490)->length) {
            Ref( _13491 );
            Append(&_13492,_13490,_13491);
        }
        else {
            Ref( _13491 );
            RefDS( _13490 );
            _13492 = Insert(_13490,_13491,insert_pos);
        }
    }
    _13490 = NOVALUE;
    _13491 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_24769);
    _ob_inlined_retval_at_25_24769 = _13492;
    _13492 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_24769);
    _0 = _retval_inlined_retval_at_28_24770;
    _retval_inlined_retval_at_28_24770 = _1register_data(_ob_inlined_retval_at_25_24769);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_24769);
    _ob_inlined_retval_at_25_24769 = NOVALUE;
    return _retval_inlined_retval_at_28_24770;
    ;
}
int eu_insert() __attribute__ ((alias ("_1eu_insert")));


int _1eu_peek2s(int _did_24773)
{
    int _retval_inlined_retval_at_16_24778 = NOVALUE;
    int _ob_inlined_retval_at_13_24777 = NOVALUE;
    int _13494 = NOVALUE;
    int _13493 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24773)) {
        _1 = (long)(DBL_PTR(_did_24773)->dbl);
        DeRefDS(_did_24773);
        _did_24773 = _1;
    }

    /** 	return retval(peek2s(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13493 = (int)*(((s1_ptr)_2)->base + _did_24773);
    if (IS_ATOM_INT(_13493)) {
        _13494 = *(signed short *)_13493;
    }
    else if (IS_ATOM(_13493)) {
        _13494 = *(signed short *)(unsigned long)(DBL_PTR(_13493)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13493);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13494 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13493 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24777);
    _ob_inlined_retval_at_13_24777 = _13494;
    _13494 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24777);
    _0 = _retval_inlined_retval_at_16_24778;
    _retval_inlined_retval_at_16_24778 = _1register_data(_ob_inlined_retval_at_13_24777);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24777);
    _ob_inlined_retval_at_13_24777 = NOVALUE;
    return _retval_inlined_retval_at_16_24778;
    ;
}
int eu_peek2s() __attribute__ ((alias ("_1eu_peek2s")));


int _1eu_peek2u(int _did_24781)
{
    int _retval_inlined_retval_at_16_24786 = NOVALUE;
    int _ob_inlined_retval_at_13_24785 = NOVALUE;
    int _13496 = NOVALUE;
    int _13495 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24781)) {
        _1 = (long)(DBL_PTR(_did_24781)->dbl);
        DeRefDS(_did_24781);
        _did_24781 = _1;
    }

    /** 	return retval(peek2u(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13495 = (int)*(((s1_ptr)_2)->base + _did_24781);
    if (IS_ATOM_INT(_13495)) {
        _13496 = *(unsigned short *)_13495;
    }
    else if (IS_ATOM(_13495)) {
        _13496 = *(unsigned short *)(unsigned long)(DBL_PTR(_13495)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13495);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13496 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13495 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24785);
    _ob_inlined_retval_at_13_24785 = _13496;
    _13496 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24785);
    _0 = _retval_inlined_retval_at_16_24786;
    _retval_inlined_retval_at_16_24786 = _1register_data(_ob_inlined_retval_at_13_24785);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24785);
    _ob_inlined_retval_at_13_24785 = NOVALUE;
    return _retval_inlined_retval_at_16_24786;
    ;
}
int eu_peek2u() __attribute__ ((alias ("_1eu_peek2u")));


int _1eu_peek_string(int _did_24789)
{
    int _retval_inlined_retval_at_16_24794 = NOVALUE;
    int _ob_inlined_retval_at_13_24793 = NOVALUE;
    int _13498 = NOVALUE;
    int _13497 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24789)) {
        _1 = (long)(DBL_PTR(_did_24789)->dbl);
        DeRefDS(_did_24789);
        _did_24789 = _1;
    }

    /** 	return retval(peek_string(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13497 = (int)*(((s1_ptr)_2)->base + _did_24789);
    if (IS_ATOM_INT(_13497)) {
        _13498 =  NewString((char *)_13497);
    }
    else if (IS_ATOM(_13497)) {
        _13498 = NewString((char *)(unsigned long)(DBL_PTR(_13497)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_13497);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13498 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13497 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24793);
    _ob_inlined_retval_at_13_24793 = _13498;
    _13498 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24793);
    _0 = _retval_inlined_retval_at_16_24794;
    _retval_inlined_retval_at_16_24794 = _1register_data(_ob_inlined_retval_at_13_24793);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24793);
    _ob_inlined_retval_at_13_24793 = NOVALUE;
    return _retval_inlined_retval_at_16_24794;
    ;
}
int eu_peek_string() __attribute__ ((alias ("_1eu_peek_string")));


int _1eu_peeks(int _did_24797)
{
    int _retval_inlined_retval_at_16_24802 = NOVALUE;
    int _ob_inlined_retval_at_13_24801 = NOVALUE;
    int _13500 = NOVALUE;
    int _13499 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24797)) {
        _1 = (long)(DBL_PTR(_did_24797)->dbl);
        DeRefDS(_did_24797);
        _did_24797 = _1;
    }

    /** 	return retval(peeks(data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13499 = (int)*(((s1_ptr)_2)->base + _did_24797);
    if (IS_ATOM_INT(_13499)) {
        _13500 = *(signed char *)_13499;
    }
    else if (IS_ATOM(_13499)) {
        _13500 = *(signed char *)(unsigned long)(DBL_PTR(_13499)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_13499);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13500 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(signed char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _13499 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_24801);
    _ob_inlined_retval_at_13_24801 = _13500;
    _13500 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_24801);
    _0 = _retval_inlined_retval_at_16_24802;
    _retval_inlined_retval_at_16_24802 = _1register_data(_ob_inlined_retval_at_13_24801);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_24801);
    _ob_inlined_retval_at_13_24801 = NOVALUE;
    return _retval_inlined_retval_at_16_24802;
    ;
}
int eu_peeks() __attribute__ ((alias ("_1eu_peeks")));


void _1eu_poke2(int _did1_24805, int _did2_24806)
{
    int _13502 = NOVALUE;
    int _13501 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_24805)) {
        _1 = (long)(DBL_PTR(_did1_24805)->dbl);
        DeRefDS(_did1_24805);
        _did1_24805 = _1;
    }
    if (!IS_ATOM_INT(_did2_24806)) {
        _1 = (long)(DBL_PTR(_did2_24806)->dbl);
        DeRefDS(_did2_24806);
        _did2_24806 = _1;
    }

    /** 	poke2(data[did1], data[did2])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13501 = (int)*(((s1_ptr)_2)->base + _did1_24805);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13502 = (int)*(((s1_ptr)_2)->base + _did2_24806);
    if (IS_ATOM_INT(_13501)){
        poke2_addr = (unsigned short *)_13501;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_13501)->dbl);
    }
    if (IS_ATOM_INT(_13502)) {
        *poke2_addr = (unsigned short)_13502;
    }
    else if (IS_ATOM(_13502)) {
        *poke_addr = (signed char)DBL_PTR(_13502)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13502);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke2_addr++ = (unsigned short)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
            }
        }
    }
    _13501 = NOVALUE;
    _13502 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_poke2() __attribute__ ((alias ("_1eu_poke2")));


int _1eu_remove(int _did_24811, int _start_24812, int _stop_24813)
{
    int _retval_inlined_retval_at_22_24818 = NOVALUE;
    int _ob_inlined_retval_at_19_24817 = NOVALUE;
    int _13504 = NOVALUE;
    int _13503 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24811)) {
        _1 = (long)(DBL_PTR(_did_24811)->dbl);
        DeRefDS(_did_24811);
        _did_24811 = _1;
    }
    if (!IS_ATOM_INT(_start_24812)) {
        _1 = (long)(DBL_PTR(_start_24812)->dbl);
        DeRefDS(_start_24812);
        _start_24812 = _1;
    }
    if (!IS_ATOM_INT(_stop_24813)) {
        _1 = (long)(DBL_PTR(_stop_24813)->dbl);
        DeRefDS(_stop_24813);
        _stop_24813 = _1;
    }

    /** 	return retval(remove(data[did], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13503 = (int)*(((s1_ptr)_2)->base + _did_24811);
    {
        s1_ptr assign_space = SEQ_PTR(_13503);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_start_24812)) ? _start_24812 : (long)(DBL_PTR(_start_24812)->dbl);
        int stop = (IS_ATOM_INT(_stop_24813)) ? _stop_24813 : (long)(DBL_PTR(_stop_24813)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_13503);
            DeRef(_13504);
            _13504 = _13503;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_13503), start, &_13504 );
            }
            else Tail(SEQ_PTR(_13503), stop+1, &_13504);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_13503), start, &_13504);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_13504);
            _13504 = _1;
        }
    }
    _13503 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_24817);
    _ob_inlined_retval_at_19_24817 = _13504;
    _13504 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_24817);
    _0 = _retval_inlined_retval_at_22_24818;
    _retval_inlined_retval_at_22_24818 = _1register_data(_ob_inlined_retval_at_19_24817);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_24817);
    _ob_inlined_retval_at_19_24817 = NOVALUE;
    return _retval_inlined_retval_at_22_24818;
    ;
}
int eu_remove() __attribute__ ((alias ("_1eu_remove")));


int _1eu_replace(int _did1_24821, int _did2_24822, int _start_24823, int _stop_24824)
{
    int _retval_inlined_retval_at_31_24830 = NOVALUE;
    int _ob_inlined_retval_at_28_24829 = NOVALUE;
    int _13507 = NOVALUE;
    int _13506 = NOVALUE;
    int _13505 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_24821)) {
        _1 = (long)(DBL_PTR(_did1_24821)->dbl);
        DeRefDS(_did1_24821);
        _did1_24821 = _1;
    }
    if (!IS_ATOM_INT(_did2_24822)) {
        _1 = (long)(DBL_PTR(_did2_24822)->dbl);
        DeRefDS(_did2_24822);
        _did2_24822 = _1;
    }
    if (!IS_ATOM_INT(_start_24823)) {
        _1 = (long)(DBL_PTR(_start_24823)->dbl);
        DeRefDS(_start_24823);
        _start_24823 = _1;
    }
    if (!IS_ATOM_INT(_stop_24824)) {
        _1 = (long)(DBL_PTR(_stop_24824)->dbl);
        DeRefDS(_stop_24824);
        _stop_24824 = _1;
    }

    /** 	return retval(replace(data[did1], data[did2], start, stop))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13505 = (int)*(((s1_ptr)_2)->base + _did1_24821);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13506 = (int)*(((s1_ptr)_2)->base + _did2_24822);
    {
        int p1 = _13505;
        int p2 = _13506;
        int p3 = _start_24823;
        int p4 = _stop_24824;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_13507;
        Replace( &replace_params );
    }
    _13505 = NOVALUE;
    _13506 = NOVALUE;
    DeRef(_ob_inlined_retval_at_28_24829);
    _ob_inlined_retval_at_28_24829 = _13507;
    _13507 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_28_24829);
    _0 = _retval_inlined_retval_at_31_24830;
    _retval_inlined_retval_at_31_24830 = _1register_data(_ob_inlined_retval_at_28_24829);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_28_24829);
    _ob_inlined_retval_at_28_24829 = NOVALUE;
    return _retval_inlined_retval_at_31_24830;
    ;
}
int eu_replace() __attribute__ ((alias ("_1eu_replace")));


int _1eu_splice(int _did1_24833, int _did2_24834, int _index_24835)
{
    int _retval_inlined_retval_at_28_24841 = NOVALUE;
    int _ob_inlined_retval_at_25_24840 = NOVALUE;
    int _13510 = NOVALUE;
    int _13509 = NOVALUE;
    int _13508 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_24833)) {
        _1 = (long)(DBL_PTR(_did1_24833)->dbl);
        DeRefDS(_did1_24833);
        _did1_24833 = _1;
    }
    if (!IS_ATOM_INT(_did2_24834)) {
        _1 = (long)(DBL_PTR(_did2_24834)->dbl);
        DeRefDS(_did2_24834);
        _did2_24834 = _1;
    }
    if (!IS_ATOM_INT(_index_24835)) {
        _1 = (long)(DBL_PTR(_index_24835)->dbl);
        DeRefDS(_index_24835);
        _index_24835 = _1;
    }

    /** 	return retval(splice(data[did1], data[did2], index))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13508 = (int)*(((s1_ptr)_2)->base + _did1_24833);
    _2 = (int)SEQ_PTR(_1data_23975);
    _13509 = (int)*(((s1_ptr)_2)->base + _did2_24834);
    {
        s1_ptr assign_space;
        insert_pos = _index_24835;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_13509)) {
                Concat(&_13510,_13509,_13508);
            }
            else{
                Prepend(&_13510,_13508,_13509);
            }
        }
        else if (insert_pos > SEQ_PTR(_13508)->length){
            if (IS_SEQUENCE(_13509)) {
                Concat(&_13510,_13508,_13509);
            }
            else{
                Append(&_13510,_13508,_13509);
            }
        }
        else if (IS_SEQUENCE(_13509)) {
            if( _13510 != _13508 || SEQ_PTR( _13508 )->ref != 1 ){
                DeRef( _13510 );
                RefDS( _13508 );
            }
            assign_space = Add_internal_space( _13508, insert_pos,((s1_ptr)SEQ_PTR(_13509))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_13509), _13508 == _13510 );
            _13510 = MAKE_SEQ( assign_space );
        }
        else {
            if( _13510 != _13508 && SEQ_PTR( _13508 )->ref != 1 ){
                _13510 = Insert( _13508, _13509, insert_pos);
            }
            else {
                DeRef( _13510 );
                RefDS( _13508 );
                _13510 = Insert( _13508, _13509, insert_pos);
            }
        }
    }
    _13508 = NOVALUE;
    _13509 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_24840);
    _ob_inlined_retval_at_25_24840 = _13510;
    _13510 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_24840);
    _0 = _retval_inlined_retval_at_28_24841;
    _retval_inlined_retval_at_28_24841 = _1register_data(_ob_inlined_retval_at_25_24840);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_24840);
    _ob_inlined_retval_at_25_24840 = NOVALUE;
    return _retval_inlined_retval_at_28_24841;
    ;
}
int eu_splice() __attribute__ ((alias ("_1eu_splice")));


int _1eu_tail(int _did_24844, int _len_24845)
{
    int _retval_inlined_retval_at_19_24850 = NOVALUE;
    int _ob_inlined_retval_at_16_24849 = NOVALUE;
    int _13512 = NOVALUE;
    int _13511 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24844)) {
        _1 = (long)(DBL_PTR(_did_24844)->dbl);
        DeRefDS(_did_24844);
        _did_24844 = _1;
    }
    if (!IS_ATOM_INT(_len_24845)) {
        _1 = (long)(DBL_PTR(_len_24845)->dbl);
        DeRefDS(_len_24845);
        _len_24845 = _1;
    }

    /** 	return retval(tail(data[did], len))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13511 = (int)*(((s1_ptr)_2)->base + _did_24844);
    {
        int len = SEQ_PTR(_13511)->length;
        int size = (IS_ATOM_INT(_len_24845)) ? _len_24845 : (long)(DBL_PTR(_len_24845)->dbl);
        if (size <= 0) {
            DeRef(_13512);
            _13512 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_13511);
            DeRef(_13512);
            _13512 = _13511;
        }
        else Tail(SEQ_PTR(_13511), len-size+1, &_13512);
    }
    _13511 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24849);
    _ob_inlined_retval_at_16_24849 = _13512;
    _13512 = NOVALUE;

    /** 	return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_24849);
    _0 = _retval_inlined_retval_at_19_24850;
    _retval_inlined_retval_at_19_24850 = _1register_data(_ob_inlined_retval_at_16_24849);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24849);
    _ob_inlined_retval_at_16_24849 = NOVALUE;
    return _retval_inlined_retval_at_19_24850;
    ;
}
int eu_tail() __attribute__ ((alias ("_1eu_tail")));


int _1eu_call_func_std(int _rid_24853, int _did_24854)
{
    int _retval_inlined_retval_at_19_24859 = NOVALUE;
    int _ob_inlined_retval_at_16_24858 = NOVALUE;
    int _13514 = NOVALUE;
    int _13513 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24853)) {
        _1 = (long)(DBL_PTR(_rid_24853)->dbl);
        DeRefDS(_rid_24853);
        _rid_24853 = _1;
    }
    if (!IS_ATOM_INT(_did_24854)) {
        _1 = (long)(DBL_PTR(_did_24854)->dbl);
        DeRefDS(_did_24854);
        _did_24854 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13513 = (int)*(((s1_ptr)_2)->base + _did_24854);
    _1 = (int)SEQ_PTR(_13513);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_24853].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }
    _13514 = _1;
    _13513 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24858);
    _ob_inlined_retval_at_16_24858 = _13514;
    _13514 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_24858);
    _0 = _retval_inlined_retval_at_19_24859;
    _retval_inlined_retval_at_19_24859 = _1register_data(_ob_inlined_retval_at_16_24858);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24858);
    _ob_inlined_retval_at_16_24858 = NOVALUE;
    return _retval_inlined_retval_at_19_24859;
    ;
}
int eu_call_func_std() __attribute__ ((alias ("_1eu_call_func_std")));


int _1eu_call_func_val(int _rid_24862, int _did_24863)
{
    int _retval_inlined_retval_at_19_24868 = NOVALUE;
    int _ob_inlined_retval_at_16_24867 = NOVALUE;
    int _13516 = NOVALUE;
    int _13515 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24862)) {
        _1 = (long)(DBL_PTR(_rid_24862)->dbl);
        DeRefDS(_rid_24862);
        _rid_24862 = _1;
    }
    if (!IS_ATOM_INT(_did_24863)) {
        _1 = (long)(DBL_PTR(_did_24863)->dbl);
        DeRefDS(_did_24863);
        _did_24863 = _1;
    }

    /** 	return retval(call_func(rid, data[did]))*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13515 = (int)*(((s1_ptr)_2)->base + _did_24863);
    _1 = (int)SEQ_PTR(_13515);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_24862].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }
    _13516 = _1;
    _13515 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_24867);
    _ob_inlined_retval_at_16_24867 = _13516;
    _13516 = NOVALUE;

    /** 	return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_24867);
    _0 = _retval_inlined_retval_at_19_24868;
    _retval_inlined_retval_at_19_24868 = _1register_data(_ob_inlined_retval_at_16_24867);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_24867);
    _ob_inlined_retval_at_16_24867 = NOVALUE;
    return _retval_inlined_retval_at_19_24868;
    ;
}
int eu_call_func_val() __attribute__ ((alias ("_1eu_call_func_val")));


int _1eu_call_func(int _rid_24871, int _did_24872)
{
    int _i_24873 = NOVALUE;
    int _13517 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24871)) {
        _1 = (long)(DBL_PTR(_rid_24871)->dbl);
        DeRefDS(_rid_24871);
        _rid_24871 = _1;
    }
    if (!IS_ATOM_INT(_did_24872)) {
        _1 = (long)(DBL_PTR(_did_24872)->dbl);
        DeRefDS(_did_24872);
        _did_24872 = _1;
    }

    /** 	i = call_func(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13517 = (int)*(((s1_ptr)_2)->base + _did_24872);
    _1 = (int)SEQ_PTR(_13517);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_24871].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }
    _i_24873 = _1;
    _13517 = NOVALUE;
    if (!IS_ATOM_INT(_i_24873)) {
        _1 = (long)(DBL_PTR(_i_24873)->dbl);
        DeRefDS(_i_24873);
        _i_24873 = _1;
    }

    /** 	return i*/
    return _i_24873;
    ;
}
int eu_call_func() __attribute__ ((alias ("_1eu_call_func")));


void _1eu_call_proc(int _rid_24878, int _did_24879)
{
    int _13519 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_24878)) {
        _1 = (long)(DBL_PTR(_rid_24878)->dbl);
        DeRefDS(_rid_24878);
        _rid_24878 = _1;
    }
    if (!IS_ATOM_INT(_did_24879)) {
        _1 = (long)(DBL_PTR(_did_24879)->dbl);
        DeRefDS(_did_24879);
        _did_24879 = _1;
    }

    /** 	call_proc(rid, data[did])*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13519 = (int)*(((s1_ptr)_2)->base + _did_24879);
    _1 = (int)SEQ_PTR(_13519);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid_24878].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }
    _13519 = NOVALUE;

    /** end procedure*/
    return;
    ;
}
void eu_call_proc() __attribute__ ((alias ("_1eu_call_proc")));


int _1eu_routine_id(int _did_24883)
{
    int _13521 = NOVALUE;
    int _13520 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_24883)) {
        _1 = (long)(DBL_PTR(_did_24883)->dbl);
        DeRefDS(_did_24883);
        _did_24883 = _1;
    }

    /** 	return routine_id(data[did]) -- this is the only time it uses a string*/
    _2 = (int)SEQ_PTR(_1data_23975);
    _13520 = (int)*(((s1_ptr)_2)->base + _did_24883);
    _13521 = CRoutineId(962, 1, _13520);
    _13520 = NOVALUE;
    return _13521;
    ;
}
int eu_routine_id() __attribute__ ((alias ("_1eu_routine_id")));


int _1eu_routine_id_str(int _low_24888, int _high_24889)
{
    int _get_address_1__tmp_at6_24892 = NOVALUE;
    int _get_address_inlined_get_address_at_6_24891 = NOVALUE;
    int _13523 = NOVALUE;
    int _13522 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_24888)) {
        _1 = (long)(DBL_PTR(_low_24888)->dbl);
        DeRefDS(_low_24888);
        _low_24888 = _1;
    }
    if (!IS_ATOM_INT(_high_24889)) {
        _1 = (long)(DBL_PTR(_high_24889)->dbl);
        DeRefDS(_high_24889);
        _high_24889 = _1;
    }

    /** 	return routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string*/

    /** 	return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_24892);
    _get_address_1__tmp_at6_24892 = NewDouble(_high_24889 * (double)65536);
    DeRef(_get_address_inlined_get_address_at_6_24891);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_24892)) {
        _get_address_inlined_get_address_at_6_24891 = _get_address_1__tmp_at6_24892 + _low_24888;
        if ((long)((unsigned long)_get_address_inlined_get_address_at_6_24891 + (unsigned long)HIGH_BITS) >= 0) 
        _get_address_inlined_get_address_at_6_24891 = NewDouble((double)_get_address_inlined_get_address_at_6_24891);
    }
    else {
        _get_address_inlined_get_address_at_6_24891 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_24892)->dbl + (double)_low_24888);
    }
    DeRef(_get_address_1__tmp_at6_24892);
    _get_address_1__tmp_at6_24892 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_24891)) {
        _13522 =  NewString((char *)_get_address_inlined_get_address_at_6_24891);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_6_24891)) {
        _13522 = NewString((char *)(unsigned long)(DBL_PTR(_get_address_inlined_get_address_at_6_24891)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_get_address_inlined_get_address_at_6_24891);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13522 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _13523 = CRoutineId(963, 1, _13522);
    DeRef(_13522);
    _13522 = NOVALUE;
    return _13523;
    ;
}
int eu_routine_id_str() __attribute__ ((alias ("_1eu_routine_id_str")));



// 0xBFDA1D86
