// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _39which_bit(int _theValue_18747)
{
    int _10436 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:get(one_bit_numbers, theValue, 0)*/
    Ref(_39one_bit_numbers_18728);
    Ref(_theValue_18747);
    _10436 = _33get(_39one_bit_numbers_18728, _theValue_18747, 0);
    DeRef(_theValue_18747);
    return _10436;
    ;
}
int which_bit() __attribute__ ((alias ("_39which_bit")));


int _39flags_to_string(int _flag_bits_18751, int _flag_names_18752, int _expand_flags_18753)
{
    int _s_18754 = NOVALUE;
    int _has_one_bit_18771 = NOVALUE;
    int _which_bit_inlined_which_bit_at_100_18773 = NOVALUE;
    int _current_flag_18777 = NOVALUE;
    int _which_bit_inlined_which_bit_at_241_18803 = NOVALUE;
    int _10469 = NOVALUE;
    int _10467 = NOVALUE;
    int _10466 = NOVALUE;
    int _10464 = NOVALUE;
    int _10462 = NOVALUE;
    int _10461 = NOVALUE;
    int _10457 = NOVALUE;
    int _10456 = NOVALUE;
    int _10453 = NOVALUE;
    int _10452 = NOVALUE;
    int _10448 = NOVALUE;
    int _10447 = NOVALUE;
    int _10446 = NOVALUE;
    int _10445 = NOVALUE;
    int _10444 = NOVALUE;
    int _10443 = NOVALUE;
    int _10442 = NOVALUE;
    int _10440 = NOVALUE;
    int _10439 = NOVALUE;
    int _10438 = NOVALUE;
    int _10437 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_expand_flags_18753)) {
        _1 = (long)(DBL_PTR(_expand_flags_18753)->dbl);
        DeRefDS(_expand_flags_18753);
        _expand_flags_18753 = _1;
    }

    /**     sequence s = {}*/
    RefDS(_5);
    DeRef(_s_18754);
    _s_18754 = _5;

    /**     if sequence(flag_bits) then*/
    _10437 = IS_SEQUENCE(_flag_bits_18751);
    if (_10437 == 0)
    {
        _10437 = NOVALUE;
        goto L1; // [17] 97
    }
    else{
        _10437 = NOVALUE;
    }

    /** 		for i = 1 to length(flag_bits) do*/
    if (IS_SEQUENCE(_flag_bits_18751)){
            _10438 = SEQ_PTR(_flag_bits_18751)->length;
    }
    else {
        _10438 = 1;
    }
    {
        int _i_18758;
        _i_18758 = 1;
L2: 
        if (_i_18758 > _10438){
            goto L3; // [25] 87
        }

        /** 			if not sequence(flag_bits[i]) then*/
        _2 = (int)SEQ_PTR(_flag_bits_18751);
        _10439 = (int)*(((s1_ptr)_2)->base + _i_18758);
        _10440 = IS_SEQUENCE(_10439);
        _10439 = NOVALUE;
        if (_10440 != 0)
        goto L4; // [41] 69
        _10440 = NOVALUE;

        /** 				flag_bits[i] = flags_to_string(flag_bits[i], flag_names, expand_flags)*/
        _2 = (int)SEQ_PTR(_flag_bits_18751);
        _10442 = (int)*(((s1_ptr)_2)->base + _i_18758);
        RefDS(_flag_names_18752);
        DeRef(_10443);
        _10443 = _flag_names_18752;
        DeRef(_10444);
        _10444 = _expand_flags_18753;
        Ref(_10442);
        _10445 = _39flags_to_string(_10442, _10443, _10444);
        _10442 = NOVALUE;
        _10443 = NOVALUE;
        _10444 = NOVALUE;
        _2 = (int)SEQ_PTR(_flag_bits_18751);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _flag_bits_18751 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_18758);
        _1 = *(int *)_2;
        *(int *)_2 = _10445;
        if( _1 != _10445 ){
            DeRef(_1);
        }
        _10445 = NOVALUE;
        goto L5; // [66] 80
L4: 

        /** 				flag_bits[i] = {"?"}*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_8695);
        *((int *)(_2+4)) = _8695;
        _10446 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_flag_bits_18751);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _flag_bits_18751 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_18758);
        _1 = *(int *)_2;
        *(int *)_2 = _10446;
        if( _1 != _10446 ){
            DeRef(_1);
        }
        _10446 = NOVALUE;
L5: 

        /** 		end for*/
        _i_18758 = _i_18758 + 1;
        goto L2; // [82] 32
L3: 
        ;
    }

    /** 		s = flag_bits*/
    Ref(_flag_bits_18751);
    DeRef(_s_18754);
    _s_18754 = _flag_bits_18751;
    goto L6; // [94] 295
L1: 

    /** 		integer has_one_bit*/

    /** 		has_one_bit = which_bit(flag_bits)*/

    /** 	return map:get(one_bit_numbers, theValue, 0)*/
    Ref(_39one_bit_numbers_18728);
    Ref(_flag_bits_18751);
    _has_one_bit_18771 = _33get(_39one_bit_numbers_18728, _flag_bits_18751, 0);

    /** 		for i = 1 to length(flag_names) do*/
    if (IS_SEQUENCE(_flag_names_18752)){
            _10447 = SEQ_PTR(_flag_names_18752)->length;
    }
    else {
        _10447 = 1;
    }
    {
        int _i_18775;
        _i_18775 = 1;
L7: 
        if (_i_18775 > _10447){
            goto L8; // [117] 292
        }

        /** 			atom current_flag = flag_names[i][1]*/
        _2 = (int)SEQ_PTR(_flag_names_18752);
        _10448 = (int)*(((s1_ptr)_2)->base + _i_18775);
        DeRef(_current_flag_18777);
        _2 = (int)SEQ_PTR(_10448);
        _current_flag_18777 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_current_flag_18777);
        _10448 = NOVALUE;

        /** 			if flag_bits = 0 then*/
        if (binary_op_a(NOTEQ, _flag_bits_18751, 0)){
            goto L9; // [136] 170
        }

        /** 				if current_flag = 0 then*/
        if (binary_op_a(NOTEQ, _current_flag_18777, 0)){
            goto LA; // [142] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_18752);
        _10452 = (int)*(((s1_ptr)_2)->base + _i_18775);
        _2 = (int)SEQ_PTR(_10452);
        _10453 = (int)*(((s1_ptr)_2)->base + 2);
        _10452 = NOVALUE;
        Ref(_10453);
        Append(&_s_18754, _s_18754, _10453);
        _10453 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_18777);
        _current_flag_18777 = NOVALUE;
        goto L8; // [164] 292
        goto LA; // [167] 283
L9: 

        /** 			elsif has_one_bit then*/
        if (_has_one_bit_18771 == 0)
        {
            goto LB; // [172] 205
        }
        else{
        }

        /** 				if current_flag = flag_bits then*/
        if (binary_op_a(NOTEQ, _current_flag_18777, _flag_bits_18751)){
            goto LA; // [177] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_18752);
        _10456 = (int)*(((s1_ptr)_2)->base + _i_18775);
        _2 = (int)SEQ_PTR(_10456);
        _10457 = (int)*(((s1_ptr)_2)->base + 2);
        _10456 = NOVALUE;
        Ref(_10457);
        Append(&_s_18754, _s_18754, _10457);
        _10457 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_18777);
        _current_flag_18777 = NOVALUE;
        goto L8; // [199] 292
        goto LA; // [202] 283
LB: 

        /** 			elsif not expand_flags then*/
        if (_expand_flags_18753 != 0)
        goto LC; // [207] 240

        /** 				if current_flag = flag_bits then*/
        if (binary_op_a(NOTEQ, _current_flag_18777, _flag_bits_18751)){
            goto LA; // [212] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_18752);
        _10461 = (int)*(((s1_ptr)_2)->base + _i_18775);
        _2 = (int)SEQ_PTR(_10461);
        _10462 = (int)*(((s1_ptr)_2)->base + 2);
        _10461 = NOVALUE;
        Ref(_10462);
        Append(&_s_18754, _s_18754, _10462);
        _10462 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_18777);
        _current_flag_18777 = NOVALUE;
        goto L8; // [234] 292
        goto LA; // [237] 283
LC: 

        /** 				if which_bit(current_flag) then*/

        /** 	return map:get(one_bit_numbers, theValue, 0)*/
        Ref(_39one_bit_numbers_18728);
        Ref(_current_flag_18777);
        _0 = _which_bit_inlined_which_bit_at_241_18803;
        _which_bit_inlined_which_bit_at_241_18803 = _33get(_39one_bit_numbers_18728, _current_flag_18777, 0);
        DeRef(_0);
        if (_which_bit_inlined_which_bit_at_241_18803 == 0) {
            goto LD; // [253] 282
        }
        else {
            if (!IS_ATOM_INT(_which_bit_inlined_which_bit_at_241_18803) && DBL_PTR(_which_bit_inlined_which_bit_at_241_18803)->dbl == 0.0){
                goto LD; // [253] 282
            }
        }

        /** 					if and_bits( current_flag, flag_bits ) = current_flag then*/
        if (IS_ATOM_INT(_current_flag_18777) && IS_ATOM_INT(_flag_bits_18751)) {
            {unsigned long tu;
                 tu = (unsigned long)_current_flag_18777 & (unsigned long)_flag_bits_18751;
                 _10464 = MAKE_UINT(tu);
            }
        }
        else {
            _10464 = binary_op(AND_BITS, _current_flag_18777, _flag_bits_18751);
        }
        if (binary_op_a(NOTEQ, _10464, _current_flag_18777)){
            DeRef(_10464);
            _10464 = NOVALUE;
            goto LE; // [262] 281
        }
        DeRef(_10464);
        _10464 = NOVALUE;

        /** 						s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_18752);
        _10466 = (int)*(((s1_ptr)_2)->base + _i_18775);
        _2 = (int)SEQ_PTR(_10466);
        _10467 = (int)*(((s1_ptr)_2)->base + 2);
        _10466 = NOVALUE;
        Ref(_10467);
        Append(&_s_18754, _s_18754, _10467);
        _10467 = NOVALUE;
LE: 
LD: 
LA: 
        DeRef(_current_flag_18777);
        _current_flag_18777 = NOVALUE;

        /** 		end for*/
        _i_18775 = _i_18775 + 1;
        goto L7; // [287] 124
L8: 
        ;
    }
L6: 

    /**     if length(s) = 0 then*/
    if (IS_SEQUENCE(_s_18754)){
            _10469 = SEQ_PTR(_s_18754)->length;
    }
    else {
        _10469 = 1;
    }
    if (_10469 != 0)
    goto LF; // [300] 311

    /** 		s = append(s,"?")*/
    RefDS(_8695);
    Append(&_s_18754, _s_18754, _8695);
LF: 

    /**     return s*/
    DeRef(_flag_bits_18751);
    DeRefDS(_flag_names_18752);
    return _s_18754;
    ;
}
int flags_to_string() __attribute__ ((alias ("_39flags_to_string")));



// 0x5BE25262
