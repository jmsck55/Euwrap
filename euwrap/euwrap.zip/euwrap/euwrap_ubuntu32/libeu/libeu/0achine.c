// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _59allocate(int _n_23504)
{
    int _13039 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_23504)) {
        _1 = (long)(DBL_PTR(_n_23504)->dbl);
        DeRefDS(_n_23504);
        _n_23504 = _1;
    }

    /**     return machine_func(M_ALLOC, n)*/
    _13039 = machine(16, _n_23504);
    return _13039;
    ;
}


void _59free(int _a_23508)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_23508);

    /** end procedure*/
    DeRef(_a_23508);
    return;
    ;
}


int _59allocate_low(int _n_23511)
{
    int _allocate_inlined_allocate_at_4_23513 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_23511)) {
        _1 = (long)(DBL_PTR(_n_23511)->dbl);
        DeRefDS(_n_23511);
        _n_23511 = _1;
    }

    /**     return allocate( n )*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef(_allocate_inlined_allocate_at_4_23513);
    _allocate_inlined_allocate_at_4_23513 = machine(16, _n_23511);
    return _allocate_inlined_allocate_at_4_23513;
    ;
}


void _59free_low(int _a_23516)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_23516)) {
        _1 = (long)(DBL_PTR(_a_23516)->dbl);
        DeRefDS(_a_23516);
        _a_23516 = _1;
    }

    /**     free( a )*/

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_23516);

    /** end procedure*/
    goto L1; // [12] 15
L1: 

    /** end procedure*/
    return;
    ;
}


int _59int_to_bytes(int _x_23520)
{
    int _a_23521 = NOVALUE;
    int _b_23522 = NOVALUE;
    int _c_23523 = NOVALUE;
    int _d_23524 = NOVALUE;
    int _13047 = NOVALUE;
    int _0, _1, _2;
    

    /**     a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23520)) {
        _a_23521 = (_x_23520 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_23521 = Dremainder(DBL_PTR(_x_23520), &temp_d);
    }
    if (!IS_ATOM_INT(_a_23521)) {
        _1 = (long)(DBL_PTR(_a_23521)->dbl);
        DeRefDS(_a_23521);
        _a_23521 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23520;
    if (IS_ATOM_INT(_x_23520)) {
        if (256 > 0 && _x_23520 >= 0) {
            _x_23520 = _x_23520 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23520 / (double)256);
            if (_x_23520 != MININT)
            _x_23520 = (long)temp_dbl;
            else
            _x_23520 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23520, 256);
        _x_23520 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23520)) {
        _b_23522 = (_x_23520 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_23522 = Dremainder(DBL_PTR(_x_23520), &temp_d);
    }
    if (!IS_ATOM_INT(_b_23522)) {
        _1 = (long)(DBL_PTR(_b_23522)->dbl);
        DeRefDS(_b_23522);
        _b_23522 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23520;
    if (IS_ATOM_INT(_x_23520)) {
        if (256 > 0 && _x_23520 >= 0) {
            _x_23520 = _x_23520 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23520 / (double)256);
            if (_x_23520 != MININT)
            _x_23520 = (long)temp_dbl;
            else
            _x_23520 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23520, 256);
        _x_23520 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23520)) {
        _c_23523 = (_x_23520 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_23523 = Dremainder(DBL_PTR(_x_23520), &temp_d);
    }
    if (!IS_ATOM_INT(_c_23523)) {
        _1 = (long)(DBL_PTR(_c_23523)->dbl);
        DeRefDS(_c_23523);
        _c_23523 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23520;
    if (IS_ATOM_INT(_x_23520)) {
        if (256 > 0 && _x_23520 >= 0) {
            _x_23520 = _x_23520 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23520 / (double)256);
            if (_x_23520 != MININT)
            _x_23520 = (long)temp_dbl;
            else
            _x_23520 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23520, 256);
        _x_23520 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23520)) {
        _d_23524 = (_x_23520 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_23524 = Dremainder(DBL_PTR(_x_23520), &temp_d);
    }
    if (!IS_ATOM_INT(_d_23524)) {
        _1 = (long)(DBL_PTR(_d_23524)->dbl);
        DeRefDS(_d_23524);
        _d_23524 = _1;
    }

    /**     return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_23521;
    *((int *)(_2+8)) = _b_23522;
    *((int *)(_2+12)) = _c_23523;
    *((int *)(_2+16)) = _d_23524;
    _13047 = MAKE_SEQ(_1);
    DeRef(_x_23520);
    return _13047;
    ;
}


int _59bytes_to_int(int _s_23538)
{
    int _13051 = NOVALUE;
    int _13050 = NOVALUE;
    int _13048 = NOVALUE;
    int _0, _1, _2;
    

    /**     if length(s) = 4 then*/
    if (IS_SEQUENCE(_s_23538)){
            _13048 = SEQ_PTR(_s_23538)->length;
    }
    else {
        _13048 = 1;
    }
    if (_13048 != 4)
    goto L1; // [8] 22

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_59mem_23533)){
        poke_addr = (unsigned char *)_59mem_23533;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem_23533)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_23538);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    goto L2; // [19] 35
L1: 

    /** 	poke(mem, s[1..4]) -- avoid breaking old code*/
    rhs_slice_target = (object_ptr)&_13050;
    RHS_Slice(_s_23538, 1, 4);
    if (IS_ATOM_INT(_59mem_23533)){
        poke_addr = (unsigned char *)_59mem_23533;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem_23533)->dbl);
    }
    _1 = (int)SEQ_PTR(_13050);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_13050);
    _13050 = NOVALUE;
L2: 

    /**     return peek4u(mem)*/
    if (IS_ATOM_INT(_59mem_23533)) {
        _13051 = *(unsigned long *)_59mem_23533;
        if ((unsigned)_13051 > (unsigned)MAXINT)
        _13051 = NewDouble((double)(unsigned long)_13051);
    }
    else {
        _13051 = *(unsigned long *)(unsigned long)(DBL_PTR(_59mem_23533)->dbl);
        if ((unsigned)_13051 > (unsigned)MAXINT)
        _13051 = NewDouble((double)(unsigned long)_13051);
    }
    DeRefDS(_s_23538);
    return _13051;
    ;
}


int _59int_to_bits(int _x_23547, int _nbits_23548)
{
    int _bits_23549 = NOVALUE;
    int _mask_23550 = NOVALUE;
    int _13064 = NOVALUE;
    int _13063 = NOVALUE;
    int _13061 = NOVALUE;
    int _13058 = NOVALUE;
    int _13057 = NOVALUE;
    int _13056 = NOVALUE;
    int _13055 = NOVALUE;
    int _13054 = NOVALUE;
    int _13053 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nbits_23548)) {
        _1 = (long)(DBL_PTR(_nbits_23548)->dbl);
        DeRefDS(_nbits_23548);
        _nbits_23548 = _1;
    }

    /**     bits = repeat(0, nbits)*/
    DeRef(_bits_23549);
    _bits_23549 = Repeat(0, _nbits_23548);

    /**     if integer(x) and nbits < 30 then*/
    if (IS_ATOM_INT(_x_23547))
    _13053 = 1;
    else if (IS_ATOM_DBL(_x_23547))
    _13053 = IS_ATOM_INT(DoubleToInt(_x_23547));
    else
    _13053 = 0;
    if (_13053 == 0) {
        goto L1; // [14] 73
    }
    _13055 = (_nbits_23548 < 30);
    if (_13055 == 0)
    {
        DeRef(_13055);
        _13055 = NOVALUE;
        goto L1; // [23] 73
    }
    else{
        DeRef(_13055);
        _13055 = NOVALUE;
    }

    /** 	mask = 1*/
    _mask_23550 = 1;

    /** 	for i = 1 to nbits do*/
    _13056 = _nbits_23548;
    {
        int _i_23557;
        _i_23557 = 1;
L2: 
        if (_i_23557 > _13056){
            goto L3; // [36] 70
        }

        /** 	    bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_23547)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_23547 & (unsigned long)_mask_23550;
                 _13057 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_23550;
            _13057 = Dand_bits(DBL_PTR(_x_23547), &temp_d);
        }
        if (IS_ATOM_INT(_13057)) {
            _13058 = (_13057 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _13058 = Dand(DBL_PTR(_13057), &temp_d);
        }
        DeRef(_13057);
        _13057 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_23549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_23549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23557);
        _1 = *(int *)_2;
        *(int *)_2 = _13058;
        if( _1 != _13058 ){
            DeRef(_1);
        }
        _13058 = NOVALUE;

        /** 	    mask *= 2*/
        _mask_23550 = _mask_23550 + _mask_23550;

        /** 	end for*/
        _i_23557 = _i_23557 + 1;
        goto L2; // [65] 43
L3: 
        ;
    }
    goto L4; // [70] 126
L1: 

    /** 	if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_23547, 0)){
        goto L5; // [75] 90
    }

    /** 	    x += power(2, nbits) -- for 2's complement bit pattern*/
    _13061 = power(2, _nbits_23548);
    _0 = _x_23547;
    if (IS_ATOM_INT(_x_23547) && IS_ATOM_INT(_13061)) {
        _x_23547 = _x_23547 + _13061;
        if ((long)((unsigned long)_x_23547 + (unsigned long)HIGH_BITS) >= 0) 
        _x_23547 = NewDouble((double)_x_23547);
    }
    else {
        if (IS_ATOM_INT(_x_23547)) {
            _x_23547 = NewDouble((double)_x_23547 + DBL_PTR(_13061)->dbl);
        }
        else {
            if (IS_ATOM_INT(_13061)) {
                _x_23547 = NewDouble(DBL_PTR(_x_23547)->dbl + (double)_13061);
            }
            else
            _x_23547 = NewDouble(DBL_PTR(_x_23547)->dbl + DBL_PTR(_13061)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_13061);
    _13061 = NOVALUE;
L5: 

    /** 	for i = 1 to nbits do*/
    _13063 = _nbits_23548;
    {
        int _i_23568;
        _i_23568 = 1;
L6: 
        if (_i_23568 > _13063){
            goto L7; // [95] 125
        }

        /** 	    bits[i] = remainder(x, 2) */
        if (IS_ATOM_INT(_x_23547)) {
            _13064 = (_x_23547 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _13064 = Dremainder(DBL_PTR(_x_23547), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_23549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_23549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23568);
        _1 = *(int *)_2;
        *(int *)_2 = _13064;
        if( _1 != _13064 ){
            DeRef(_1);
        }
        _13064 = NOVALUE;

        /** 	    x = floor(x / 2)*/
        _0 = _x_23547;
        if (IS_ATOM_INT(_x_23547)) {
            _x_23547 = _x_23547 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_23547, 2);
            _x_23547 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 	end for*/
        _i_23568 = _i_23568 + 1;
        goto L6; // [120] 102
L7: 
        ;
    }
L4: 

    /**     return bits*/
    DeRef(_x_23547);
    return _bits_23549;
    ;
}


int _59bits_to_int(int _bits_23574)
{
    int _value_23575 = NOVALUE;
    int _p_23576 = NOVALUE;
    int _13067 = NOVALUE;
    int _13066 = NOVALUE;
    int _0, _1, _2;
    

    /**     value = 0*/
    DeRef(_value_23575);
    _value_23575 = 0;

    /**     p = 1*/
    DeRef(_p_23576);
    _p_23576 = 1;

    /**     for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_23574)){
            _13066 = SEQ_PTR(_bits_23574)->length;
    }
    else {
        _13066 = 1;
    }
    {
        int _i_23578;
        _i_23578 = 1;
L1: 
        if (_i_23578 > _13066){
            goto L2; // [18] 54
        }

        /** 	if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_23574);
        _13067 = (int)*(((s1_ptr)_2)->base + _i_23578);
        if (_13067 == 0) {
            _13067 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_13067) && DBL_PTR(_13067)->dbl == 0.0){
                _13067 = NOVALUE;
                goto L3; // [31] 41
            }
            _13067 = NOVALUE;
        }
        _13067 = NOVALUE;

        /** 	    value += p*/
        _0 = _value_23575;
        if (IS_ATOM_INT(_value_23575) && IS_ATOM_INT(_p_23576)) {
            _value_23575 = _value_23575 + _p_23576;
            if ((long)((unsigned long)_value_23575 + (unsigned long)HIGH_BITS) >= 0) 
            _value_23575 = NewDouble((double)_value_23575);
        }
        else {
            if (IS_ATOM_INT(_value_23575)) {
                _value_23575 = NewDouble((double)_value_23575 + DBL_PTR(_p_23576)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_23576)) {
                    _value_23575 = NewDouble(DBL_PTR(_value_23575)->dbl + (double)_p_23576);
                }
                else
                _value_23575 = NewDouble(DBL_PTR(_value_23575)->dbl + DBL_PTR(_p_23576)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 	p += p*/
        _0 = _p_23576;
        if (IS_ATOM_INT(_p_23576) && IS_ATOM_INT(_p_23576)) {
            _p_23576 = _p_23576 + _p_23576;
            if ((long)((unsigned long)_p_23576 + (unsigned long)HIGH_BITS) >= 0) 
            _p_23576 = NewDouble((double)_p_23576);
        }
        else {
            if (IS_ATOM_INT(_p_23576)) {
                _p_23576 = NewDouble((double)_p_23576 + DBL_PTR(_p_23576)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_23576)) {
                    _p_23576 = NewDouble(DBL_PTR(_p_23576)->dbl + (double)_p_23576);
                }
                else
                _p_23576 = NewDouble(DBL_PTR(_p_23576)->dbl + DBL_PTR(_p_23576)->dbl);
            }
        }
        DeRef(_0);

        /**     end for*/
        _i_23578 = _i_23578 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /**     return value*/
    DeRefDS(_bits_23574);
    DeRef(_p_23576);
    return _value_23575;
    ;
}


void _59set_rand(int _seed_23586)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_seed_23586)) {
        _1 = (long)(DBL_PTR(_seed_23586)->dbl);
        DeRefDS(_seed_23586);
        _seed_23586 = _1;
    }

    /**     machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_23586);

    /** end procedure*/
    return;
    ;
}


void _59crash_message(int _msg_23589)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_23589);

    /** end procedure*/
    DeRefDS(_msg_23589);
    return;
    ;
}


void _59crash_file(int _file_path_23592)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_23592);

    /** end procedure*/
    DeRefDS(_file_path_23592);
    return;
    ;
}


void _59crash_routine(int _proc_23595)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_23595)) {
        _1 = (long)(DBL_PTR(_proc_23595)->dbl);
        DeRefDS(_proc_23595);
        _proc_23595 = _1;
    }

    /**     machine_proc(M_CRASH_ROUTINE, proc)*/
    machine(66, _proc_23595);

    /** end procedure*/
    return;
    ;
}


int _59atom_to_float64(int _a_23598)
{
    int _13070 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F64, a)*/
    _13070 = machine(46, _a_23598);
    DeRef(_a_23598);
    return _13070;
    ;
}


int _59atom_to_float32(int _a_23602)
{
    int _13071 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F32, a)*/
    _13071 = machine(48, _a_23602);
    DeRef(_a_23602);
    return _13071;
    ;
}


int _59float64_to_atom(int _ieee64_23606)
{
    int _13072 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F64_TO_A, ieee64)*/
    _13072 = machine(47, _ieee64_23606);
    DeRefDS(_ieee64_23606);
    return _13072;
    ;
}


int _59float32_to_atom(int _ieee32_23610)
{
    int _13073 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F32_TO_A, ieee32)*/
    _13073 = machine(49, _ieee32_23610);
    DeRefDS(_ieee32_23610);
    return _13073;
    ;
}


int _59allocate_string(int _s_23614)
{
    int _mem_23615 = NOVALUE;
    int _13078 = NOVALUE;
    int _13077 = NOVALUE;
    int _13075 = NOVALUE;
    int _13074 = NOVALUE;
    int _0, _1, _2;
    

    /**     mem = machine_func(M_ALLOC, length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_23614)){
            _13074 = SEQ_PTR(_s_23614)->length;
    }
    else {
        _13074 = 1;
    }
    _13075 = _13074 + 1;
    _13074 = NOVALUE;
    DeRef(_mem_23615);
    _mem_23615 = machine(16, _13075);
    _13075 = NOVALUE;

    /**     if mem then*/
    if (_mem_23615 == 0) {
        goto L1; // [18] 39
    }
    else {
        if (!IS_ATOM_INT(_mem_23615) && DBL_PTR(_mem_23615)->dbl == 0.0){
            goto L1; // [18] 39
        }
    }

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_mem_23615)){
        poke_addr = (unsigned char *)_mem_23615;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_23615)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_23614);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_23614)){
            _13077 = SEQ_PTR(_s_23614)->length;
    }
    else {
        _13077 = 1;
    }
    if (IS_ATOM_INT(_mem_23615)) {
        _13078 = _mem_23615 + _13077;
        if ((long)((unsigned long)_13078 + (unsigned long)HIGH_BITS) >= 0) 
        _13078 = NewDouble((double)_13078);
    }
    else {
        _13078 = NewDouble(DBL_PTR(_mem_23615)->dbl + (double)_13077);
    }
    _13077 = NOVALUE;
    if (IS_ATOM_INT(_13078)){
        poke_addr = (unsigned char *)_13078;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13078)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13078);
    _13078 = NOVALUE;
L1: 

    /**     return mem*/
    DeRefDS(_s_23614);
    return _mem_23615;
    ;
}


void _59register_block(int _block_addr_23625, int _block_len_23626)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _59unregister_block(int _block_addr_23629)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _59check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}



// 0x7E3E6555
