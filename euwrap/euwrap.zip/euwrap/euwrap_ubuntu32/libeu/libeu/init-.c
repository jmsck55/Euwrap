#include "include/euphoria.h"
#include "main-.h"

int _5;
int _18;
int _21;
int _22;
int _23;
int _24;
int _25;
int _26;
int _27;
int _60;
int _69;
int _78;
int _82;
int _84;
int _86;
int _88;
int _89;
int _94;
int _95;
int _96;
int _97;
int _98;
int _99;
int _100;
int _101;
int _102;
int _103;
int _104;
int _105;
int _106;
int _107;
int _108;
int _109;
int _110;
int _111;
int _112;
int _113;
int _114;
int _115;
int _116;
int _117;
int _118;
int _119;
int _120;
int _121;
int _122;
int _123;
int _124;
int _125;
int _126;
int _127;
int _128;
int _129;
int _130;
int _131;
int _132;
int _133;
int _134;
int _135;
int _136;
int _137;
int _138;
int _140;
int _141;
int _142;
int _143;
int _144;
int _145;
int _146;
int _147;
int _148;
int _149;
int _150;
int _151;
int _152;
int _153;
int _154;
int _155;
int _156;
int _157;
int _158;
int _159;
int _160;
int _161;
int _162;
int _163;
int _164;
int _165;
int _166;
int _167;
int _168;
int _169;
int _170;
int _171;
int _172;
int _173;
int _174;
int _175;
int _176;
int _177;
int _178;
int _179;
int _180;
int _181;
int _182;
int _183;
int _184;
int _185;
int _186;
int _187;
int _188;
int _189;
int _190;
int _191;
int _192;
int _193;
int _194;
int _195;
int _196;
int _197;
int _198;
int _199;
int _200;
int _201;
int _202;
int _203;
int _204;
int _205;
int _206;
int _207;
int _208;
int _209;
int _210;
int _211;
int _212;
int _213;
int _214;
int _215;
int _216;
int _217;
int _218;
int _219;
int _220;
int _221;
int _222;
int _223;
int _224;
int _225;
int _226;
int _227;
int _258;
int _282;
int _285;
int _289;
int _292;
int _298;
int _300;
int _301;
int _302;
int _303;
int _304;
int _305;
int _307;
int _310;
int _311;
int _313;
int _315;
int _318;
int _321;
int _324;
int _326;
int _331;
int _337;
int _342;
int _476;
int _658;
int _661;
int _662;
int _663;
int _671;
int _679;
int _783;
int _802;
int _803;
int _804;
int _811;
int _812;
int _910;
int _911;
int _919;
int _921;
int _929;
int _937;
int _958;
int _978;
int _1034;
int _1035;
int _1036;
int _1037;
int _1038;
int _1039;
int _1040;
int _1041;
int _1043;
int _1064;
int _1065;
int _1066;
int _1078;
int _1083;
int _1085;
int _1089;
int _1124;
int _1217;
int _1272;
int _1278;
int _1284;
int _1296;
int _1297;
int _1325;
int _1343;
int _1353;
int _1354;
int _1356;
int _1371;
int _1372;
int _1608;
int _1610;
int _1615;
int _1616;
int _1617;
int _1621;
int _1632;
int _1638;
int _1639;
int _1640;
int _1642;
int _1656;
int _1657;
int _1721;
int _1738;
int _1743;
int _1791;
int _1792;
int _1793;
int _1794;
int _1795;
int _1796;
int _1797;
int _1798;
int _1799;
int _1800;
int _1801;
int _1802;
int _1804;
int _1805;
int _1806;
int _1807;
int _1808;
int _1809;
int _1810;
int _1811;
int _1812;
int _1813;
int _1814;
int _1816;
int _1817;
int _1818;
int _1819;
int _1820;
int _1821;
int _1822;
int _1824;
int _1825;
int _1826;
int _1827;
int _1828;
int _1829;
int _1830;
int _1832;
int _1833;
int _1931;
int _1951;
int _2030;
int _2051;
int _2065;
int _2066;
int _2185;
int _2193;
int _2223;
int _2224;
int _2225;
int _2226;
int _2227;
int _2228;
int _2229;
int _2230;
int _2231;
int _2232;
int _2233;
int _2234;
int _2235;
int _2236;
int _2237;
int _2238;
int _2239;
int _2240;
int _2241;
int _2242;
int _2245;
int _2326;
int _2359;
int _2403;
int _2439;
int _2490;
int _2492;
int _2533;
int _2539;
int _2637;
int _2700;
int _2784;
int _2787;
int _2884;
int _2885;
int _2912;
int _2913;
int _2920;
int _2941;
int _2971;
int _2981;
int _3054;
int _3055;
int _3056;
int _3057;
int _3064;
int _3065;
int _3072;
int _3073;
int _3074;
int _3081;
int _3082;
int _3089;
int _3090;
int _3097;
int _3098;
int _3105;
int _3106;
int _3107;
int _3157;
int _3158;
int _3159;
int _3226;
int _3232;
int _3294;
int _3319;
int _3543;
int _3606;
int _3667;
int _3733;
int _3735;
int _3738;
int _3739;
int _3742;
int _3745;
int _3748;
int _3751;
int _3754;
int _3755;
int _3756;
int _3757;
int _3758;
int _3759;
int _3760;
int _3761;
int _3762;
int _3763;
int _3764;
int _3765;
int _3766;
int _3767;
int _3780;
int _3842;
int _3847;
int _4055;
int _4057;
int _4058;
int _4084;
int _4131;
int _4404;
int _4407;
int _4410;
int _4413;
int _4418;
int _4421;
int _4424;
int _4426;
int _4428;
int _4429;
int _4430;
int _4433;
int _4438;
int _4486;
int _4489;
int _4491;
int _4492;
int _4498;
int _4576;
int _4589;
int _4592;
int _4595;
int _4597;
int _4599;
int _4601;
int _4602;
int _4615;
int _4683;
int _4708;
int _4709;
int _4710;
int _4711;
int _4712;
int _4713;
int _4722;
int _4752;
int _4765;
int _4772;
int _4864;
int _4865;
int _4930;
int _4954;
int _4955;
int _5152;
int _5153;
int _5163;
int _5169;
int _5177;
int _5207;
int _5217;
int _5218;
int _5239;
int _5250;
int _5251;
int _5252;
int _5298;
int _5299;
int _5300;
int _5314;
int _5315;
int _5432;
int _5475;
int _5659;
int _5660;
int _5828;
int _5858;
int _5865;
int _5942;
int _5953;
int _5954;
int _5958;
int _6062;
int _6119;
int _6120;
int _6121;
int _6124;
int _6127;
int _6130;
int _6133;
int _6136;
int _6139;
int _6173;
int _6176;
int _6179;
int _6202;
int _6219;
int _6239;
int _6250;
int _6258;
int _6279;
int _6315;
int _6316;
int _6319;
int _6320;
int _6321;
int _6322;
int _6323;
int _6324;
int _6325;
int _6326;
int _6327;
int _6328;
int _6329;
int _6416;
int _6531;
int _6549;
int _6550;
int _6551;
int _6555;
int _6643;
int _6651;
int _6694;
int _6695;
int _6696;
int _6697;
int _6698;
int _6699;
int _6700;
int _6701;
int _6702;
int _6703;
int _6704;
int _6705;
int _6706;
int _6707;
int _6708;
int _6709;
int _6710;
int _6711;
int _6712;
int _6713;
int _6714;
int _6715;
int _6716;
int _6717;
int _6718;
int _6719;
int _6720;
int _6721;
int _6722;
int _6723;
int _6724;
int _6725;
int _6726;
int _6727;
int _6728;
int _6729;
int _6730;
int _6731;
int _6732;
int _6734;
int _6735;
int _6736;
int _6737;
int _6738;
int _6739;
int _6740;
int _6741;
int _6742;
int _6747;
int _6748;
int _6749;
int _6762;
int _6765;
int _6770;
int _6779;
int _6783;
int _6805;
int _6809;
int _6810;
int _6811;
int _6812;
int _6814;
int _6815;
int _6883;
int _6903;
int _6919;
int _7013;
int _7014;
int _7238;
int _7246;
int _7247;
int _7248;
int _7249;
int _7389;
int _7390;
int _7468;
int _7469;
int _7498;
int _7501;
int _7564;
int _7565;
int _7823;
int _7848;
int _7869;
int _7870;
int _7907;
int _7909;
int _7917;
int _7918;
int _7934;
int _7950;
int _8049;
int _8244;
int _8245;
int _8246;
int _8247;
int _8248;
int _8249;
int _8250;
int _8251;
int _8252;
int _8253;
int _8254;
int _8255;
int _8256;
int _8257;
int _8258;
int _8259;
int _8260;
int _8261;
int _8262;
int _8263;
int _8264;
int _8265;
int _8266;
int _8267;
int _8268;
int _8269;
int _8270;
int _8271;
int _8272;
int _8273;
int _8274;
int _8275;
int _8276;
int _8277;
int _8278;
int _8279;
int _8280;
int _8281;
int _8282;
int _8283;
int _8284;
int _8285;
int _8286;
int _8287;
int _8288;
int _8289;
int _8290;
int _8291;
int _8292;
int _8293;
int _8294;
int _8295;
int _8296;
int _8297;
int _8298;
int _8299;
int _8300;
int _8301;
int _8302;
int _8303;
int _8304;
int _8305;
int _8306;
int _8307;
int _8308;
int _8309;
int _8310;
int _8311;
int _8312;
int _8313;
int _8314;
int _8315;
int _8316;
int _8317;
int _8318;
int _8319;
int _8320;
int _8321;
int _8322;
int _8323;
int _8324;
int _8325;
int _8326;
int _8327;
int _8328;
int _8329;
int _8330;
int _8331;
int _8332;
int _8333;
int _8334;
int _8335;
int _8336;
int _8337;
int _8338;
int _8339;
int _8340;
int _8341;
int _8342;
int _8343;
int _8344;
int _8345;
int _8346;
int _8347;
int _8348;
int _8349;
int _8350;
int _8351;
int _8352;
int _8353;
int _8354;
int _8355;
int _8356;
int _8357;
int _8358;
int _8359;
int _8360;
int _8361;
int _8362;
int _8363;
int _8364;
int _8365;
int _8366;
int _8367;
int _8368;
int _8369;
int _8370;
int _8371;
int _8372;
int _8373;
int _8374;
int _8375;
int _8376;
int _8377;
int _8378;
int _8384;
int _8394;
int _8405;
int _8512;
int _8529;
int _8531;
int _8536;
int _8539;
int _8540;
int _8541;
int _8543;
int _8544;
int _8545;
int _8546;
int _8547;
int _8548;
int _8549;
int _8550;
int _8551;
int _8552;
int _8553;
int _8554;
int _8555;
int _8556;
int _8557;
int _8558;
int _8559;
int _8560;
int _8561;
int _8562;
int _8563;
int _8566;
int _8572;
int _8603;
int _8612;
int _8622;
int _8627;
int _8632;
int _8637;
int _8642;
int _8674;
int _8685;
int _8691;
int _8695;
int _8699;
int _8704;
int _8759;
int _8760;
int _8765;
int _8835;
int _8885;
int _8900;
int _8917;
int _8926;
int _8961;
int _8967;
int _8997;
int _8998;
int _8999;
int _9000;
int _9001;
int _9002;
int _9003;
int _9007;
int _9008;
int _9009;
int _9010;
int _9011;
int _9034;
int _9043;
int _9051;
int _9052;
int _9061;
int _9062;
int _9119;
int _9123;
int _9222;
int _9247;
int _9282;
int _9295;
int _9299;
int _9300;
int _9318;
int _9323;
int _9347;
int _9348;
int _9349;
int _9350;
int _9351;
int _9355;
int _9371;
int _9372;
int _9382;
int _9406;
int _9407;
int _9490;
int _9491;
int _9494;
int _9497;
int _9501;
int _9507;
int _9508;
int _9510;
int _9511;
int _9517;
int _9518;
int _9522;
int _9527;
int _9528;
int _9538;
int _9541;
int _9544;
int _9556;
int _9561;
int _9564;
int _9569;
int _9570;
int _9575;
int _9586;
int _9589;
int _9598;
int _9602;
int _9603;
int _9604;
int _9607;
int _9608;
int _9609;
int _9611;
int _9615;
int _9616;
int _9620;
int _9622;
int _9629;
int _9632;
int _9638;
int _9644;
int _9647;
int _9651;
int _9793;
int _9794;
int _9808;
int _9811;
int _9836;
int _10058;
int _10059;
int _10063;
int _10089;
int _10090;
int _10093;
int _10158;
int _10207;
int _10215;
int _10267;
int _10281;
int _10290;
int _10311;
int _10323;
int _10324;
int _10365;
int _10397;
int _10434;
int _10435;
int _10663;
int _10923;
int _10924;
int _10925;
int _10926;
int _10927;
int _10928;
int _10929;
int _10930;
int _10931;
int _10932;
int _10933;
int _10934;
int _10935;
int _10936;
int _10937;
int _10938;
int _10939;
int _10940;
int _10941;
int _10942;
int _10943;
int _10944;
int _10945;
int _10946;
int _10947;
int _10948;
int _10949;
int _10950;
int _10951;
int _10952;
int _10953;
int _10954;
int _10955;
int _10956;
int _10957;
int _10958;
int _10959;
int _10960;
int _10961;
int _10962;
int _10963;
int _10964;
int _10965;
int _10966;
int _10967;
int _10968;
int _10969;
int _10970;
int _10971;
int _10972;
int _10973;
int _10974;
int _10975;
int _10976;
int _10977;
int _10978;
int _10979;
int _10980;
int _10981;
int _10982;
int _10983;
int _10984;
int _10985;
int _10986;
int _10987;
int _10988;
int _10989;
int _10990;
int _10991;
int _10992;
int _10993;
int _10994;
int _10995;
int _10996;
int _10997;
int _10998;
int _10999;
int _11000;
int _11001;
int _11002;
int _11003;
int _11004;
int _11005;
int _11006;
int _11007;
int _11008;
int _11009;
int _11010;
int _11011;
int _11012;
int _11013;
int _11014;
int _11015;
int _11016;
int _11017;
int _11018;
int _11019;
int _11020;
int _11021;
int _11022;
int _11023;
int _11024;
int _11025;
int _11026;
int _11027;
int _11028;
int _11029;
int _11030;
int _11031;
int _11032;
int _11033;
int _11034;
int _11035;
int _11036;
int _11037;
int _11038;
int _11039;
int _11040;
int _11041;
int _11042;
int _11043;
int _11044;
int _11045;
int _11046;
int _11047;
int _11048;
int _11049;
int _11050;
int _11051;
int _11052;
int _11053;
int _11054;
int _11055;
int _11056;
int _11057;
int _11058;
int _11059;
int _11060;
int _11061;
int _11062;
int _11063;
int _11064;
int _11065;
int _11066;
int _11067;
int _11068;
int _11069;
int _11070;
int _11071;
int _11072;
int _11073;
int _11074;
int _11075;
int _11076;
int _11077;
int _11078;
int _11079;
int _11080;
int _11081;
int _11082;
int _11083;
int _11084;
int _11085;
int _11086;
int _11087;
int _11088;
int _11089;
int _11090;
int _11091;
int _11092;
int _11093;
int _11094;
int _11095;
int _11096;
int _11097;
int _11098;
int _11099;
int _11100;
int _11101;
int _11102;
int _11103;
int _11104;
int _11105;
int _11106;
int _11107;
int _11108;
int _11109;
int _11110;
int _11111;
int _11112;
int _11113;
int _11114;
int _11115;
int _11116;
int _11117;
int _11118;
int _11119;
int _11120;
int _11121;
int _11122;
int _11123;
int _11124;
int _11125;
int _11126;
int _11127;
int _11128;
int _11129;
int _11130;
int _11131;
int _11132;
int _11133;
int _11134;
int _11135;
int _11136;
int _11137;
int _11138;
int _11139;
int _11140;
int _11141;
int _11142;
int _11143;
int _11144;
int _11145;
int _11146;
int _11147;
int _11148;
int _11149;
int _11150;
int _11151;
int _11152;
int _11153;
int _11154;
int _11155;
int _11156;
int _11157;
int _11158;
int _11159;
int _11160;
int _11161;
int _11162;
int _11163;
int _11164;
int _11165;
int _11166;
int _11167;
int _11168;
int _11169;
int _11170;
int _11171;
int _11172;
int _11173;
int _11174;
int _11175;
int _11176;
int _11177;
int _11178;
int _11179;
int _11180;
int _11181;
int _11182;
int _11183;
int _11184;
int _11185;
int _11186;
int _11187;
int _11188;
int _11189;
int _11190;
int _11191;
int _11192;
int _11193;
int _11194;
int _11195;
int _11196;
int _11197;
int _11198;
int _11199;
int _11200;
int _11201;
int _11202;
int _11203;
int _11204;
int _11205;
int _11206;
int _11207;
int _11208;
int _11209;
int _11210;
int _11211;
int _11212;
int _11213;
int _11214;
int _11215;
int _11216;
int _11217;
int _11218;
int _11219;
int _11220;
int _11221;
int _11222;
int _11223;
int _11224;
int _11225;
int _11226;
int _11227;
int _11228;
int _11229;
int _11230;
int _11231;
int _11232;
int _11233;
int _11234;
int _11235;
int _11236;
int _11237;
int _11238;
int _11239;
int _11240;
int _11241;
int _11242;
int _11243;
int _11244;
int _11245;
int _11246;
int _11247;
int _11248;
int _11249;
int _11250;
int _11251;
int _11252;
int _11253;
int _11254;
int _11255;
int _11256;
int _11257;
int _11258;
int _11259;
int _11260;
int _11261;
int _11262;
int _11263;
int _11264;
int _11265;
int _11266;
int _11267;
int _11268;
int _11269;
int _11270;
int _11271;
int _11272;
int _11273;
int _11274;
int _11275;
int _11276;
int _11277;
int _11278;
int _11279;
int _11280;
int _11281;
int _11282;
int _11283;
int _11284;
int _11285;
int _11286;
int _11287;
int _11288;
int _11289;
int _11290;
int _11291;
int _11292;
int _11293;
int _11294;
int _11295;
int _11296;
int _11297;
int _11298;
int _11299;
int _11300;
int _11301;
int _11302;
int _11303;
int _11304;
int _11305;
int _11306;
int _11307;
int _11308;
int _11309;
int _11310;
int _11311;
int _11312;
int _11313;
int _11314;
int _11315;
int _11316;
int _11317;
int _11318;
int _11319;
int _11320;
int _11321;
int _11322;
int _11323;
int _11324;
int _11325;
int _11326;
int _11327;
int _11328;
int _11329;
int _11330;
int _11331;
int _11332;
int _11333;
int _11334;
int _11335;
int _11336;
int _11337;
int _11338;
int _11340;
int _11341;
int _11342;
int _11343;
int _11344;
int _11345;
int _11346;
int _11347;
int _11348;
int _11349;
int _11350;
int _11351;
int _11352;
int _11353;
int _11354;
int _11355;
int _11356;
int _11357;
int _11358;
int _11360;
int _11381;
int _11457;
int _11468;
int _11469;
int _11470;
int _11471;
int _11472;
int _11473;
int _11475;
int _11482;
int _11483;
int _11503;
int _11508;
int _11510;
int _11516;
int _11518;
int _11523;
int _11525;
int _11526;
int _11539;
int _11580;
int _11587;
int _11589;
int _11594;
int _11624;
int _11625;
int _11626;
int _11627;
int _11628;
int _11629;
int _11630;
int _11631;
int _11632;
int _11633;
int _11636;
int _11639;
int _11642;
int _11645;
int _11648;
int _11651;
int _11654;
int _11656;
int _11659;
int _11662;
int _11697;
int _11809;
int _11810;
int _11818;
int _11820;
int _11822;
int _11824;
int _11826;
int _11828;
int _11830;
int _11832;
int _11834;
int _11836;
int _11838;
int _11840;
int _11842;
int _11844;
int _11846;
int _11848;
int _11850;
int _11852;
int _11854;
int _11856;
int _11858;
int _11860;
int _11862;
int _11864;
int _11866;
int _11868;
int _11870;
int _11872;
int _11874;
int _11893;
int _11895;
int _11897;
int _11899;
int _11901;
int _11904;
int _11906;
int _11908;
int _11910;
int _11912;
int _11914;
int _11916;
int _11918;
int _11920;
int _11922;
int _11924;
int _11926;
int _11928;
int _11930;
int _11932;
int _11934;
int _11936;
int _11938;
int _11958;
int _11966;
int _12139;
int _12141;
int _12143;
int _12168;
int _12361;
int _12426;
int _12438;
int _12464;
int _12468;
int _12469;
int _12480;
int _12488;
int _12497;
int _12509;
int _12510;
int _12532;
int _12533;
int _12547;
int _12548;
int _12558;
int _12573;
int _12590;
int _12600;
int _12607;
int _12620;
int _12621;
int _12622;
int _12631;
int _12649;
int _12652;
int _12685;
int _12692;
int _12700;
int _12701;
int _12702;
int _12716;
int _12740;
int _12763;
int _12773;
int _12774;
int _12779;
int _12790;
int _12794;
int _12797;
int _12804;
int _12807;
int _12809;
int _12815;
int _12821;
int _12824;
int _12832;
int _12834;
int _12837;
int _12839;
int _12844;
int _12846;
int _12849;
int _12854;
int _12855;
int _12856;
int _12865;
int _12867;
int _12894;
int _12910;
int _12922;
int _12929;
int _12939;
int _12959;
int _12963;
int _12968;
int _12982;
int _12997;
int _12998;
int _12999;
int _13000;
int _13001;
int _13016;
int _13099;
int _13100;
int _13102;
int _13105;
int _13109;
int _13110;
int _13111;
int _13112;
int _13113;
int _13486;
int _13487;
int _13488;

// 0xA5FF859A
// Declaring file vars
int _3M_EU_INFO_146 = 75;
int _3MAJ_VER_148 = 1;
int _3MIN_VER_149 = 2;
int _3PAT_VER_151 = 3;
int _3VER_TYPE_153 = 4;
int _3NODE_155 = 5;
int _3REVISION_157 = 6;
int _3REVISION_DATE_159 = 7;
int _3START_TIME_161 = 8;
int _3version_info_163 = NOVALUE;
int _3is_developmental_165 = NOVALUE;
int _3is_release_169 = NOVALUE;
int _4keywords_296 = NOVALUE;
int _4builtins_343 = NOVALUE;
int _7OBJ_UNASSIGNED_439 = 0;
int _7OBJ_INTEGER_440 = 1;
int _7OBJ_ATOM_441 = 2;
int _7OBJ_SEQUENCE_442 = 3;
int _7FALSE_443 = NOVALUE;
int _7TRUE_445 = NOVALUE;
int _7CS_FIRST_447 = 0;
int _7CS_Consonant_448 = 1;
int _7CS_Vowel_449 = 2;
int _7CS_Hexadecimal_450 = 3;
int _7CS_Whitespace_451 = 4;
int _7CS_Punctuation_452 = 5;
int _7CS_Printable_453 = 6;
int _7CS_Displayable_454 = 7;
int _7CS_Lowercase_455 = 8;
int _7CS_Uppercase_456 = 9;
int _7CS_Alphanumeric_458 = 10;
int _7CS_Identifier_459 = 11;
int _7CS_Alphabetic_461 = 12;
int _7CS_ASCII_462 = 13;
int _7CS_Control_464 = 14;
int _7CS_Digit_466 = 15;
int _7CS_Graphic_468 = 16;
int _7CS_Bytes_470 = 17;
int _7CS_SpecWord_472 = 18;
int _7CS_Boolean_474 = 19;
int _7CS_LAST_476 = 20;
int _7Defined_Sets_538 = NOVALUE;
int _7INVALID_ROUTINE_ID_872 = NOVALUE;
int _7NO_ROUTINE_ID_875 = -99999;
int _9NESTED_ANY_958 = 1;
int _9NESTED_ALL_959 = 2;
int _9NESTED_INDEX_960 = 4;
int _9NESTED_BACKWARD_961 = 8;
int _8M_A_TO_F64_1357 = 46;
int _8M_F64_TO_A_1359 = 47;
int _8M_A_TO_F32_1360 = 48;
int _8M_F32_TO_A_1361 = 49;
int _8M_ALLOC_1363 = 16;
int _8mem_1364 = NOVALUE;
int _8vDigits_1526 = NOVALUE;
int _8decimal_mark_1528 = NOVALUE;
int _10M_CRASH_MESSAGE_1778 = 37;
int _10M_CRASH_FILE_1779 = 57;
int _10M_CRASH_ROUTINE_1780 = 66;
int _10M_CRASH_1781 = 67;
int _10M_WARNING_FILE_1782 = 72;
int _15PROT_EXEC_1812 = 4;
int _15PROT_READ_1813 = 1;
int _15PROT_WRITE_1814 = 2;
int _15PROT_NONE_1815 = 0;
int _15PAGE_EXECUTE_1816 = 4;
int _15PAGE_EXECUTE_READ_1817 = NOVALUE;
int _15PAGE_EXECUTE_READWRITE_1819 = NOVALUE;
int _15PAGE_EXECUTE_WRITECOPY_1822 = NOVALUE;
int _15PAGE_WRITECOPY_1825 = NOVALUE;
int _15PAGE_READWRITE_1827 = NOVALUE;
int _15PAGE_READONLY_1829 = 1;
int _15PAGE_NOACCESS_1830 = 0;
int _15PAGE_NONE_1831 = 0;
int _15PAGE_READ_EXECUTE_1832 = NOVALUE;
int _15PAGE_READ_WRITE_1833 = NOVALUE;
int _15PAGE_READ_1834 = 1;
int _15PAGE_READ_WRITE_EXECUTE_1835 = NOVALUE;
int _15PAGE_WRITE_EXECUTE_COPY_1836 = NOVALUE;
int _15PAGE_WRITE_COPY_1837 = NOVALUE;
int _15MEMORY_PROTECTION_1838 = NOVALUE;
int _15DEP_really_works_1864 = NOVALUE;
int _15use_DEP_1865 = NOVALUE;
int _15MEM_COMMIT_1866 = 4096;
int _15MEM_RESERVE_1868 = 8192;
int _15MEM_RESET_1870 = 524288;
int _15MEM_RELEASE_1872 = 32768;
int _15FREE_RID_1874 = NOVALUE;
int _15A_READ_1875 = 1;
int _15A_WRITE_1876 = 2;
int _15A_EXECUTE_1877 = 3;
int _15M_ALLOC_1878 = 16;
int _15M_FREE_1879 = 17;
int _16MAX_ADDR_1891 = NOVALUE;
int _16check_calls_1923 = NOVALUE;
int _16BORDER_SPACE_1949 = 0;
int _16leader_1950 = NOVALUE;
int _16trailer_1952 = NOVALUE;
int _14FREE_ARRAY_RID_1969 = NOVALUE;
int _14ADDRESS_LENGTH_1970 = 4;
int _14page_size_2083 = NOVALUE;
int _14getpagesize_rid_2093 = NOVALUE;
int _14PAGE_SIZE_2099 = NOVALUE;
int _13C_CHAR_2249 = 16777217;
int _13C_BYTE_2251 = 16777217;
int _13C_UCHAR_2252 = 33554433;
int _13C_UBYTE_2254 = 33554433;
int _13C_SHORT_2255 = 16777218;
int _13C_WORD_2257 = 16777218;
int _13C_USHORT_2258 = 33554434;
int _13C_INT_2260 = 16777220;
int _13C_BOOL_2262 = 16777220;
int _13C_UINT_2263 = 33554436;
int _13C_SIZE_T_2265 = 33554436;
int _13C_LONG_2266 = 16777220;
int _13C_ULONG_2267 = 33554436;
int _13C_POINTER_2268 = 33554436;
int _13C_HANDLE_2269 = 33554436;
int _13C_HWND_2270 = 33554436;
int _13C_DWORD_2271 = 33554436;
int _13C_WPARAM_2272 = 16777220;
int _13C_LPARAM_2273 = 16777220;
int _13C_HRESULT_2274 = 16777220;
int _13C_FLOAT_2275 = 50331652;
int _13C_DOUBLE_2277 = 50331656;
int _13C_DWORDLONG_2279 = 50331656;
int _13E_INTEGER_2280 = 100663300;
int _13E_ATOM_2282 = 117440516;
int _13E_SEQUENCE_2284 = 134217732;
int _13E_OBJECT_2286 = 150994948;
int _13NULL_2288 = 0;
int _13M_OPEN_DLL_2289 = 50;
int _13M_DEFINE_C_2290 = 51;
int _13M_DEFINE_VAR_2291 = 56;
int _13M_CALL_BACK_2348 = 52;
int _18M_SEEK_2357 = 19;
int _18M_WHERE_2358 = 20;
int _18M_FLUSH_2359 = 60;
int _18M_LOCK_FILE_2361 = 61;
int _18M_UNLOCK_FILE_2363 = 62;
int _18STDIN_2365 = 0;
int _18STDOUT_2366 = 1;
int _18STDERR_2367 = 2;
int _18SCREEN_2368 = 1;
int _18EOF_2369 = -1;
int _18CHUNK_2370 = 100;
int _18mem0_2403 = NOVALUE;
int _18mem1_2404 = NOVALUE;
int _18mem2_2405 = NOVALUE;
int _18mem3_2406 = NOVALUE;
int _18LOCK_SHARED_2457 = 1;
int _18LOCK_EXCLUSIVE_2458 = 2;
int _18BINARY_MODE_2663 = 1;
int _18TEXT_MODE_2664 = 2;
int _18UNIX_TEXT_2665 = 3;
int _18DOS_TEXT_2666 = 4;
int _17GET_SUCCESS_2816 = 0;
int _17GET_EOF_2817 = -1;
int _17GET_FAIL_2818 = 1;
int _17GET_NOTHING_2819 = -2;
int _17DIGITS_2821 = NOVALUE;
int _17HEX_DIGITS_2823 = NOVALUE;
int _17START_NUMERIC_2826 = NOVALUE;
int _17TRUE_2829 = 1;
int _17input_file_2840 = NOVALUE;
int _17input_string_2841 = NOVALUE;
int _17string_next_2842 = NOVALUE;
int _17ch_2843 = NOVALUE;
int _17white_space_2859 = NOVALUE;
int _17ESCAPE_CHARS_2864 = NOVALUE;
int _17ESCAPED_CHARS_2866 = NOVALUE;
int _17GET_IGNORE_2921 = -2;
int _17leading_whitespace_3113 = NOVALUE;
int _17GET_SHORT_ANSWER_3238 = NOVALUE;
int _17GET_LONG_ANSWER_3241 = NOVALUE;
int _12gmtime__3303 = NOVALUE;
int _12time__3308 = NOVALUE;
int _12TM_SEC_3315 = 1;
int _12TM_MIN_3316 = 2;
int _12TM_HOUR_3317 = 3;
int _12TM_MDAY_3318 = 4;
int _12TM_MON_3319 = 5;
int _12TM_YEAR_3320 = 6;
int _12Gregorian_Reformation_3344 = 1752;
int _12Gregorian_Reformation00_3346 = 1700;
int _12DaysPerMonth_3348 = NOVALUE;
int _12EPOCH_1970_3351 = NOVALUE;
int _12DayLengthInSeconds_3353 = 86400;
int _12month_names_3560 = NOVALUE;
int _12month_abbrs_3574 = NOVALUE;
int _12day_names_3587 = NOVALUE;
int _12day_abbrs_3596 = NOVALUE;
int _12ampm_3605 = NOVALUE;
int _12YEAR_3609 = 1;
int _12MONTH_3610 = 2;
int _12DAY_3611 = 3;
int _12HOUR_3612 = 4;
int _12MINUTE_3613 = 5;
int _12SECOND_3614 = 6;
int _12YEARS_3615 = 1;
int _12MONTHS_3616 = 2;
int _12WEEKS_3617 = 3;
int _12DAYS_3618 = 4;
int _12HOURS_3619 = 5;
int _12MINUTES_3620 = 6;
int _12SECONDS_3621 = 7;
int _12DATE_3622 = 8;
int _12date_now_4001 = NOVALUE;
int _12now_inlined_now_at_555_4003 = NOVALUE;
int _12now_1__tmp_at555_4004 = NOVALUE;
int _19HSIEH30_4188 = -6;
int _19HSIEH32_4190 = -5;
int _19ADLER32_4192 = -4;
int _19FLETCHER32_4194 = -3;
int _19MD5_4196 = -2;
int _19SHA256_4197 = -1;
int _21M_SET_RAND_4224 = 35;
int _21M_GET_RAND_4225 = 98;
int _22PI_4313 = NOVALUE;
int _22QUARTPI_4315 = NOVALUE;
int _22HALFPI_4317 = NOVALUE;
int _22TWOPI_4319 = NOVALUE;
int _22PISQR_4321 = NOVALUE;
int _22INVSQ2PI_4323 = NOVALUE;
int _22PHI_4325 = NOVALUE;
int _22E_4327 = NOVALUE;
int _22LN2_4329 = NOVALUE;
int _22INVLN2_4331 = NOVALUE;
int _22LN10_4333 = NOVALUE;
int _22INVLN10_4335 = NOVALUE;
int _22SQRT2_4337 = NOVALUE;
int _22HALFSQRT2_4339 = NOVALUE;
int _22SQRT3_4341 = NOVALUE;
int _22DEGREES_TO_RADIANS_4343 = NOVALUE;
int _22RADIANS_TO_DEGREES_4345 = NOVALUE;
int _22EULER_GAMMA_4347 = NOVALUE;
int _22SQRTE_4349 = NOVALUE;
int _22PINF_4351 = NOVALUE;
int _22MINF_4354 = NOVALUE;
int _22SQRT5_4356 = NOVALUE;
int _24ASCENDING_4995 = 1;
int _24NORMAL_ORDER_4996 = 1;
int _24DESCENDING_4997 = -1;
int _24REVERSE_ORDER_4998 = -1;
int _23ADD_PREPEND_5273 = 1;
int _23ADD_APPEND_5274 = 2;
int _23ADD_SORT_UP_5275 = 3;
int _23ADD_SORT_DOWN_5276 = 4;
int _23ROTATE_LEFT_5277 = 1;
int _23ROTATE_RIGHT_5278 = -1;
int _23STDFLTR_ALPHA_6139 = NOVALUE;
int _23BK_LEN_6324 = 1;
int _23BK_PIECES_6325 = 2;
int _23SEQ_NOALT_6750 = NOVALUE;
int _23RD_INPLACE_6782 = 1;
int _23RD_PRESORTED_6783 = 2;
int _23RD_SORT_6784 = 3;
int _23COMBINE_UNSORTED_6823 = 0;
int _23COMBINE_SORTED_6824 = 1;
int _25END_MARKER_6907 = -1;
int _11M_DIR_6968 = 22;
int _11M_CURRENT_DIR_6970 = 23;
int _11M_CHDIR_6971 = 63;
int _11lib_6973 = NOVALUE;
int _11xStatFile_6975 = NOVALUE;
int _11xMoveFile_6980 = NOVALUE;
int _11xDeleteFile_6984 = NOVALUE;
int _11xCreateDirectory_6988 = NOVALUE;
int _11xRemoveDirectory_6992 = NOVALUE;
int _11xGetFileAttributes_6996 = NOVALUE;
int _11SLASH_7007 = 47;
int _11SLASHES_7008 = NOVALUE;
int _11EOLSEP_7010 = NOVALUE;
int _11PATHSEP_7011 = 58;
int _11NULLDEVICE_7012 = NOVALUE;
int _11SHARED_LIB_EXT_7015 = NOVALUE;
int _11EOL_7020 = 10;
int _11D_NAME_7021 = 1;
int _11D_ATTRIBUTES_7022 = 2;
int _11D_SIZE_7023 = 3;
int _11D_YEAR_7024 = 4;
int _11D_MONTH_7025 = 5;
int _11D_DAY_7026 = 6;
int _11D_HOUR_7027 = 7;
int _11D_MINUTE_7028 = 8;
int _11D_SECOND_7029 = 9;
int _11D_MILLISECOND_7030 = 10;
int _11D_ALTNAME_7031 = 11;
int _11W_BAD_PATH_7032 = -1;
int _11DEFAULT_DIR_SOURCE_7141 = -2;
int _11my_dir_7142 = NOVALUE;
int _11InitCurDir_7278 = NOVALUE;
int _11PATH_DIR_7396 = 1;
int _11PATH_FILENAME_7397 = 2;
int _11PATH_BASENAME_7398 = 3;
int _11PATH_FILEEXT_7399 = 4;
int _11PATH_DRIVEID_7400 = 5;
int _11AS_IS_7531 = 0;
int _11TO_LOWER_7532 = 1;
int _11CORRECT_7533 = 2;
int _11TO_SHORT_7534 = 4;
int _11FILETYPE_UNDEFINED_7869 = -1;
int _11FILETYPE_NOT_FOUND_7870 = 0;
int _11FILETYPE_FILE_7871 = 1;
int _11FILETYPE_DIRECTORY_7872 = 2;
int _11SECTORS_PER_CLUSTER_7899 = 1;
int _11BYTES_PER_SECTOR_7900 = 2;
int _11NUMBER_OF_FREE_CLUSTERS_7901 = 3;
int _11TOTAL_NUMBER_OF_CLUSTERS_7902 = 4;
int _11TOTAL_BYTES_7903 = 1;
int _11FREE_BYTES_7904 = 2;
int _11USED_BYTES_7905 = 3;
int _11COUNT_DIRS_7906 = 1;
int _11COUNT_FILES_7907 = 2;
int _11COUNT_SIZE_7908 = 3;
int _11COUNT_TYPES_7909 = 4;
int _11EXT_NAME_7910 = 1;
int _11EXT_COUNT_7911 = 2;
int _11EXT_SIZE_7912 = 3;
int _11file_counters_8296 = NOVALUE;
int _26pretty_end_col_8569 = NOVALUE;
int _26pretty_chars_8570 = NOVALUE;
int _26pretty_start_col_8571 = NOVALUE;
int _26pretty_level_8572 = NOVALUE;
int _26pretty_file_8573 = NOVALUE;
int _26pretty_ascii_8574 = NOVALUE;
int _26pretty_indent_8575 = NOVALUE;
int _26pretty_ascii_min_8576 = NOVALUE;
int _26pretty_ascii_max_8577 = NOVALUE;
int _26pretty_line_count_8578 = NOVALUE;
int _26pretty_line_max_8579 = NOVALUE;
int _26pretty_dots_8580 = NOVALUE;
int _26pretty_line_breaks_8581 = NOVALUE;
int _26pretty_printing_8582 = NOVALUE;
int _26pretty_fp_format_8583 = NOVALUE;
int _26pretty_int_format_8584 = NOVALUE;
int _26pretty_line_8585 = NOVALUE;
int _26PRETTY_DEFAULT_8726 = NOVALUE;
int _26DISPLAY_ASCII_8731 = 1;
int _26INDENT_8732 = 2;
int _26START_COLUMN_8733 = 3;
int _26WRAP_8734 = 4;
int _26INT_FORMAT_8735 = 5;
int _26FP_FORMAT_8736 = 6;
int _26MIN_ASCII_8737 = 7;
int _26MAX_ASCII_8738 = 8;
int _26MAX_LINES_8739 = 9;
int _26LINE_BREAKS_8740 = 10;
int _27I2B_8775 = 249;
int _27I3B_8777 = 250;
int _27I4B_8779 = 251;
int _27F4B_8781 = 252;
int _27F8B_8783 = 253;
int _27S1B_8785 = 254;
int _27S4B_8787 = 255;
int _27I8B_8788 = 0;
int _27F10B_8789 = 1;
int _27MIN1B_8790 = -9;
int _27MAX1B_8792 = 239;
int _27MIN2B_8794 = NOVALUE;
int _27MAX2B_8797 = NOVALUE;
int _27MIN3B_8800 = NOVALUE;
int _27MAX3B_8803 = NOVALUE;
int _27MIN4B_8806 = NOVALUE;
int _27mem0_8809 = NOVALUE;
int _27mem1_8810 = NOVALUE;
int _27mem2_8811 = NOVALUE;
int _27mem3_8812 = NOVALUE;
int _27f80_8817 = NOVALUE;
int _27f64_8818 = NOVALUE;
int _27F80_TO_ATOM_8819 = NOVALUE;
int _27i64_8857 = NOVALUE;
int _27PEEK8S_8858 = NOVALUE;
int _6TO_LOWER_9353 = NOVALUE;
int _6lower_case_SET_9355 = NOVALUE;
int _6upper_case_SET_9356 = NOVALUE;
int _6encoding_NAME_9357 = NOVALUE;
int _28ram_space_10764 = NOVALUE;
int _28ram_free_list_10765 = NOVALUE;
int _28free_rid_10766 = NOVALUE;
int _5NORMAL_COLOR_10820 = NOVALUE;
int _5COMMENT_COLOR_10821 = NOVALUE;
int _5KEYWORD_COLOR_10822 = NOVALUE;
int _5BUILTIN_COLOR_10823 = NOVALUE;
int _5STRING_COLOR_10824 = NOVALUE;
int _5BRACKET_COLOR_10825 = NOVALUE;
int _5S_STRING_TRIPLE_10826 = 1;
int _5S_STRING_BACKTICK_10827 = 2;
int _5S_MULTILINE_COMMENT_10828 = 3;
int _5S_BRACKET_LEVEL_10829 = 4;
int _5DIGIT_10830 = 1;
int _5OTHER_10831 = 2;
int _5LETTER_10832 = 3;
int _5BRACKET_10833 = 4;
int _5QUOTE_10834 = 5;
int _5BACKTICK_10835 = 6;
int _5DASH_10836 = 7;
int _5FORWARD_SLASH_10837 = 8;
int _5WHITE_SPACE_10838 = 9;
int _5NEW_LINE_10839 = 10;
int _5char_class_10840 = NOVALUE;
int _5DONT_CARE_10891 = -1;
int _5line_10892 = NOVALUE;
int _5color_segments_10893 = NOVALUE;
int _5current_color_10894 = NOVALUE;
int _5seg_start_10895 = NOVALUE;
int _5seg_end_10896 = NOVALUE;
int _5g_state_10913 = NOVALUE;
int _29EOL_11137 = 10;
int _29TRUE_11138 = 1;
int _29FALSE_11139 = 0;
int _29ET_TOKENS_11140 = 1;
int _29ET_ERROR_11141 = 2;
int _29ET_ERR_LINE_11142 = 3;
int _29ET_ERR_COLUMN_11143 = 4;
int _29T_EOF_11144 = 1;
int _29T_NULL_11145 = 2;
int _29T_SHBANG_11146 = 3;
int _29T_NEWLINE_11147 = 4;
int _29T_COMMENT_11148 = 5;
int _29T_NUMBER_11149 = 6;
int _29T_CHAR_11150 = 7;
int _29T_STRING_11151 = 8;
int _29T_IDENTIFIER_11152 = 9;
int _29T_KEYWORD_11153 = 10;
int _29T_DOUBLE_OPS_11154 = 11;
int _29T_PLUSEQ_11155 = 11;
int _29T_MINUSEQ_11156 = 12;
int _29T_MULTIPLYEQ_11157 = 13;
int _29T_DIVIDEEQ_11158 = 14;
int _29T_LTEQ_11159 = 15;
int _29T_GTEQ_11160 = 16;
int _29T_NOTEQ_11161 = 17;
int _29T_CONCATEQ_11162 = 18;
int _29T_DELIMITER_11163 = 19;
int _29T_PLUS_11164 = 19;
int _29T_MINUS_11165 = 20;
int _29T_MULTIPLY_11166 = 21;
int _29T_DIVIDE_11168 = 22;
int _29T_LT_11169 = 23;
int _29T_GT_11170 = 24;
int _29T_NOT_11171 = 25;
int _29T_CONCAT_11173 = 26;
int _29T_SINGLE_OPS_11174 = 27;
int _29T_EQ_11176 = 27;
int _29T_LPAREN_11177 = 28;
int _29T_RPAREN_11178 = 29;
int _29T_LBRACE_11179 = 30;
int _29T_RBRACE_11180 = 31;
int _29T_LBRACKET_11181 = 32;
int _29T_RBRACKET_11182 = 33;
int _29T_QPRINT_11183 = 34;
int _29T_COMMA_11184 = 35;
int _29T_PERIOD_11185 = 36;
int _29T_COLON_11186 = 37;
int _29T_DOLLAR_11187 = 38;
int _29T_SLICE_11189 = 39;
int _29TF_HEX_11190 = 1;
int _29TF_INT_11191 = 2;
int _29TF_ATOM_11192 = 3;
int _29TF_STRING_SINGLE_11193 = 4;
int _29TF_STRING_TRIPLE_11194 = 5;
int _29TF_STRING_BACKTICK_11195 = 6;
int _29TF_STRING_HEX_11196 = 7;
int _29TF_COMMENT_SINGLE_11197 = 8;
int _29TF_COMMENT_MULTIPLE_11198 = 9;
int _29Delimiters_11199 = NOVALUE;
int _29TTYPE_11203 = 1;
int _29TDATA_11204 = 2;
int _29TLNUM_11205 = 3;
int _29TLPOS_11206 = 4;
int _29TFORM_11207 = 5;
int _29Token_11208 = NOVALUE;
int _29source_text_11210 = NOVALUE;
int _29sti_11211 = NOVALUE;
int _29LNum_11212 = NOVALUE;
int _29LPos_11213 = NOVALUE;
int _29Look_11214 = NOVALUE;
int _29ERR_11215 = NOVALUE;
int _29ERR_LNUM_11216 = NOVALUE;
int _29ERR_LPOS_11217 = NOVALUE;
int _29ERR_NONE_11218 = 0;
int _29ERR_OPEN_11219 = 1;
int _29ERR_ESCAPE_11220 = 2;
int _29ERR_EOL_CHAR_11221 = 3;
int _29ERR_CLOSE_CHAR_11222 = 4;
int _29ERR_EOL_STRING_11223 = 5;
int _29ERR_HEX_11224 = 6;
int _29ERR_DECIMAL_11225 = 7;
int _29ERR_UNKNOWN_11226 = 8;
int _29ERR_EOF_11227 = 9;
int _29ERR_EOF_STRING_11228 = 10;
int _29ERR_HEX_STRING_11229 = 11;
int _29ERROR_STRING_11230 = NOVALUE;
int _29IGNORE_NEWLINES_11257 = NOVALUE;
int _29IGNORE_COMMENTS_11258 = NOVALUE;
int _29STRING_NUMBERS_11259 = NOVALUE;
int _29QFLAGS_11398 = NOVALUE;
int _29SUBSCRIPT_11504 = NOVALUE;
int _29INCLUDE_NEXT_11679 = NOVALUE;
int _29token_names_11865 = NOVALUE;
int _29token_forms_11906 = NOVALUE;
int _30aleph_11980 = NOVALUE;
int _30ediv_11997 = NOVALUE;
int _30erem_11999 = NOVALUE;
int _30emul_12001 = NOVALUE;
int _30drem_12003 = NOVALUE;
int _30dmul_12005 = NOVALUE;
int _30ddiv_12007 = NOVALUE;
int _30nc4_12009 = NOVALUE;
int _30next_12011 = NOVALUE;
int _30nc3_12013 = NOVALUE;
int _30ldrop_12015 = NOVALUE;
int _34list_of_primes_12132 = NOVALUE;
int _35ST_FULLPOP_12362 = 1;
int _35ST_SAMPLE_12363 = 2;
int _35ST_ALLNUM_12364 = 1;
int _35ST_IGNSTR_12365 = 2;
int _35ST_ZEROSTR_12366 = 3;
int _33TYPE_TAG_12797 = 1;
int _33ELEMENT_COUNT_12798 = 2;
int _33IN_USE_12799 = 3;
int _33MAP_TYPE_12800 = 4;
int _33KEY_BUCKETS_12801 = 5;
int _33VALUE_BUCKETS_12802 = 6;
int _33KEY_LIST_12803 = 5;
int _33VALUE_LIST_12804 = 6;
int _33FREE_LIST_12805 = 7;
int _33type_is_map_12806 = NOVALUE;
int _33PUT_12808 = 1;
int _33ADD_12809 = 2;
int _33SUBTRACT_12810 = 3;
int _33MULTIPLY_12811 = 4;
int _33DIVIDE_12812 = 5;
int _33APPEND_12813 = 6;
int _33CONCAT_12814 = 7;
int _33LEAVE_12815 = 8;
int _33INIT_OPERATIONS_12816 = NOVALUE;
int _33SMALLMAP_12818 = 115;
int _33LARGEMAP_12819 = 76;
int _33threshold_size_12820 = NOVALUE;
int _33init_small_map_key_12821 = NOVALUE;
int _33maxInt_12903 = 1073741823;
int _33NUM_ENTRIES_13531 = 1;
int _33NUM_IN_USE_13532 = 2;
int _33NUM_BUCKETS_13533 = 3;
int _33LARGEST_BUCKET_13534 = 4;
int _33SMALLEST_BUCKET_13535 = 5;
int _33AVERAGE_BUCKET_13536 = 6;
int _33STDEV_BUCKET_13537 = 7;
int _33SM_TEXT_13918 = 1;
int _33SM_RAW_13919 = 2;
int _36BMP_SUCCESS_14120 = 1;
int _36BMP_OPEN_FAILED_14121 = 2;
int _36BMP_UNEXPECTED_EOF_14122 = 3;
int _36BMP_UNSUPPORTED_FORMAT_14123 = 4;
int _36BMP_INVALID_MODE_14124 = 5;
int _36VC_COLOR_14125 = 1;
int _36VC_MODE_14126 = 2;
int _36VC_LINES_14127 = 3;
int _36VC_COLUMNS_14128 = 4;
int _36VC_XPIXELS_14129 = 5;
int _36VC_YPIXELS_14130 = 6;
int _36VC_NCOLORS_14131 = 7;
int _36VC_PAGES_14132 = 8;
int _36VC_SCRNLINES_14133 = 9;
int _36VC_SCRNCOLS_14134 = 10;
int _36BLACK_14135 = 0;
int _36BLUE_14136 = 1;
int _36GREEN_14137 = 2;
int _36CYAN_14138 = 3;
int _36RED_14139 = 4;
int _36MAGENTA_14140 = 5;
int _36BROWN_14141 = 6;
int _36WHITE_14142 = 7;
int _36GRAY_14143 = 8;
int _36BRIGHT_BLUE_14144 = 9;
int _36BRIGHT_GREEN_14145 = 10;
int _36BRIGHT_CYAN_14146 = 11;
int _36BRIGHT_RED_14147 = 12;
int _36BRIGHT_MAGENTA_14148 = 13;
int _36YELLOW_14149 = 14;
int _36BRIGHT_WHITE_14150 = 15;
int _36true_fgcolor_14151 = NOVALUE;
int _36true_bgcolor_14153 = NOVALUE;
int _36BLINKING_14155 = 16;
int _36BYTES_PER_CHAR_14156 = 2;
int _36M_VIDEO_CONFIG_14185 = 13;
int _36FGSET_14189 = 1;
int _36BGSET_14190 = 2;
int _32M_WAIT_KEY_14191 = 26;
int _32M_ALLOW_BREAK_14192 = 42;
int _32M_CHECK_BREAK_14193 = 43;
int _32M_CURSOR_14194 = 6;
int _32M_TEXTROWS_14195 = 12;
int _32M_FREE_CONSOLE_14196 = 54;
int _32M_GET_SCREEN_CHAR_14197 = 58;
int _32M_PUT_SCREEN_CHAR_14198 = 59;
int _32M_HAS_CONSOLE_14199 = 99;
int _32M_KEY_CODES_14200 = 100;
int _32KC_LBUTTON_14208 = NOVALUE;
int _32KC_RBUTTON_14210 = NOVALUE;
int _32KC_CANCEL_14212 = NOVALUE;
int _32KC_MBUTTON_14214 = NOVALUE;
int _32KC_XBUTTON1_14216 = NOVALUE;
int _32KC_XBUTTON2_14218 = NOVALUE;
int _32KC_BACK_14220 = NOVALUE;
int _32KC_TAB_14222 = NOVALUE;
int _32KC_CLEAR_14224 = NOVALUE;
int _32KC_RETURN_14226 = NOVALUE;
int _32KC_SHIFT_14228 = NOVALUE;
int _32KC_CONTROL_14230 = NOVALUE;
int _32KC_MENU_14232 = NOVALUE;
int _32KC_PAUSE_14234 = NOVALUE;
int _32KC_CAPITAL_14236 = NOVALUE;
int _32KC_KANA_14238 = NOVALUE;
int _32KC_JUNJA_14240 = NOVALUE;
int _32KC_FINAL_14242 = NOVALUE;
int _32KC_HANJA_14244 = NOVALUE;
int _32KC_ESCAPE_14246 = NOVALUE;
int _32KC_CONVERT_14248 = NOVALUE;
int _32KC_NONCONVERT_14250 = NOVALUE;
int _32KC_ACCEPT_14252 = NOVALUE;
int _32KC_MODECHANGE_14254 = NOVALUE;
int _32KC_SPACE_14256 = NOVALUE;
int _32KC_PRIOR_14258 = NOVALUE;
int _32KC_NEXT_14260 = NOVALUE;
int _32KC_END_14262 = NOVALUE;
int _32KC_HOME_14264 = NOVALUE;
int _32KC_LEFT_14266 = NOVALUE;
int _32KC_UP_14268 = NOVALUE;
int _32KC_RIGHT_14270 = NOVALUE;
int _32KC_DOWN_14272 = NOVALUE;
int _32KC_SELECT_14274 = NOVALUE;
int _32KC_PRINT_14276 = NOVALUE;
int _32KC_EXECUTE_14278 = NOVALUE;
int _32KC_SNAPSHOT_14280 = NOVALUE;
int _32KC_INSERT_14282 = NOVALUE;
int _32KC_DELETE_14284 = NOVALUE;
int _32KC_HELP_14286 = NOVALUE;
int _32KC_LWIN_14288 = NOVALUE;
int _32KC_RWIN_14290 = NOVALUE;
int _32KC_APPS_14292 = NOVALUE;
int _32KC_SLEEP_14294 = NOVALUE;
int _32KC_NUMPAD0_14296 = NOVALUE;
int _32KC_NUMPAD1_14298 = NOVALUE;
int _32KC_NUMPAD2_14300 = NOVALUE;
int _32KC_NUMPAD3_14302 = NOVALUE;
int _32KC_NUMPAD4_14304 = NOVALUE;
int _32KC_NUMPAD5_14306 = NOVALUE;
int _32KC_NUMPAD6_14308 = NOVALUE;
int _32KC_NUMPAD7_14310 = NOVALUE;
int _32KC_NUMPAD8_14312 = NOVALUE;
int _32KC_NUMPAD9_14314 = NOVALUE;
int _32KC_MULTIPLY_14316 = NOVALUE;
int _32KC_ADD_14318 = NOVALUE;
int _32KC_SEPARATOR_14320 = NOVALUE;
int _32KC_SUBTRACT_14322 = NOVALUE;
int _32KC_DECIMAL_14324 = NOVALUE;
int _32KC_DIVIDE_14326 = NOVALUE;
int _32KC_F1_14328 = NOVALUE;
int _32KC_F2_14330 = NOVALUE;
int _32KC_F3_14332 = NOVALUE;
int _32KC_F4_14334 = NOVALUE;
int _32KC_F5_14336 = NOVALUE;
int _32KC_F6_14338 = NOVALUE;
int _32KC_F7_14340 = NOVALUE;
int _32KC_F8_14342 = NOVALUE;
int _32KC_F9_14344 = NOVALUE;
int _32KC_F10_14346 = NOVALUE;
int _32KC_F11_14348 = NOVALUE;
int _32KC_F12_14350 = NOVALUE;
int _32KC_F13_14352 = NOVALUE;
int _32KC_F14_14355 = NOVALUE;
int _32KC_F15_14357 = NOVALUE;
int _32KC_F16_14359 = NOVALUE;
int _32KC_F17_14361 = NOVALUE;
int _32KC_F18_14363 = NOVALUE;
int _32KC_F19_14366 = NOVALUE;
int _32KC_F20_14369 = NOVALUE;
int _32KC_F21_14371 = NOVALUE;
int _32KC_F22_14374 = NOVALUE;
int _32KC_F23_14377 = NOVALUE;
int _32KC_F24_14380 = NOVALUE;
int _32KC_NUMLOCK_14383 = NOVALUE;
int _32KC_SCROLL_14386 = NOVALUE;
int _32KC_LSHIFT_14389 = NOVALUE;
int _32KC_RSHIFT_14391 = NOVALUE;
int _32KC_LCONTROL_14394 = NOVALUE;
int _32KC_RCONTROL_14397 = NOVALUE;
int _32KC_LMENU_14399 = NOVALUE;
int _32KC_RMENU_14401 = NOVALUE;
int _32KC_BROWSER_BACK_14403 = NOVALUE;
int _32KC_BROWSER_FORWARD_14406 = NOVALUE;
int _32KC_BROWSER_REFRESH_14409 = NOVALUE;
int _32KC_BROWSER_STOP_14412 = NOVALUE;
int _32KC_BROWSER_SEARCH_14414 = NOVALUE;
int _32KC_BROWSER_FAVORITES_14417 = NOVALUE;
int _32KC_BROWSER_HOME_14420 = NOVALUE;
int _32KC_VOLUME_MUTE_14423 = NOVALUE;
int _32KC_VOLUME_DOWN_14426 = NOVALUE;
int _32KC_VOLUME_UP_14429 = NOVALUE;
int _32KC_MEDIA_NEXT_TRACK_14432 = NOVALUE;
int _32KC_MEDIA_PREV_TRACK_14435 = NOVALUE;
int _32KC_MEDIA_STOP_14438 = NOVALUE;
int _32KC_MEDIA_PLAY_PAUSE_14441 = NOVALUE;
int _32KC_LAUNCH_MAIL_14444 = NOVALUE;
int _32KC_LAUNCH_MEDIA_SELECT_14447 = NOVALUE;
int _32KC_LAUNCH_APP1_14450 = NOVALUE;
int _32KC_LAUNCH_APP2_14453 = NOVALUE;
int _32KC_OEM_1_14456 = NOVALUE;
int _32KC_OEM_PLUS_14459 = NOVALUE;
int _32KC_OEM_COMMA_14462 = NOVALUE;
int _32KC_OEM_MINUS_14465 = NOVALUE;
int _32KC_OEM_PERIOD_14468 = NOVALUE;
int _32KC_OEM_2_14471 = NOVALUE;
int _32KC_OEM_3_14474 = NOVALUE;
int _32KC_OEM_4_14477 = NOVALUE;
int _32KC_OEM_5_14479 = NOVALUE;
int _32KC_OEM_6_14482 = NOVALUE;
int _32KC_OEM_7_14484 = NOVALUE;
int _32KC_OEM_8_14487 = NOVALUE;
int _32KC_OEM_102_14489 = NOVALUE;
int _32KC_PROCESSKEY_14492 = NOVALUE;
int _32KC_PACKET_14494 = NOVALUE;
int _32KC_ATTN_14497 = NOVALUE;
int _32KC_CRSEL_14500 = NOVALUE;
int _32KC_EXSEL_14503 = NOVALUE;
int _32KC_EREOF_14505 = NOVALUE;
int _32KC_PLAY_14507 = NOVALUE;
int _32KC_ZOOM_14509 = NOVALUE;
int _32KC_NONAME_14511 = NOVALUE;
int _32KC_PA1_14513 = NOVALUE;
int _32KC_OEM_CLEAR_14515 = NOVALUE;
int _32KM_CONTROL_14517 = 4096;
int _32KM_SHIFT_14518 = 8192;
int _32KM_ALT_14519 = 16384;
int _32NO_CURSOR_14823 = 8192;
int _32UNDERLINE_CURSOR_14824 = 1543;
int _32THICK_UNDERLINE_CURSOR_14826 = 1287;
int _32HALF_BLOCK_CURSOR_14828 = 1031;
int _32BLOCK_CURSOR_14830 = 7;
int _37CMD_SWITCHES_15121 = NOVALUE;
int _37M_SLEEP_15123 = 64;
int _37M_SET_ENV_15124 = 73;
int _37M_UNSET_ENV_15125 = 74;
int _37WIN32_15126 = 2;
int _37WINDOWS_15127 = 2;
int _37LINUX_15128 = 3;
int _37OSX_15129 = 4;
int _37OPENBSD_15130 = 6;
int _37NETBSD_15131 = 7;
int _37FREEBSD_15132 = 8;
int _37M_INSTANCE_15133 = 55;
int _37M_UNAME_15143 = 76;
int _31NO_PARAMETER_15193 = 110;
int _31HAS_PARAMETER_15194 = 112;
int _31NO_CASE_15195 = 105;
int _31HAS_CASE_15196 = 99;
int _31MANDATORY_15197 = 109;
int _31OPTIONAL_15198 = 111;
int _31ONCE_15199 = 49;
int _31MULTIPLE_15200 = 42;
int _31HELP_15201 = 104;
int _31VERSIONING_15202 = 118;
int _31HELP_RID_15203 = 1;
int _31VALIDATE_ALL_15204 = 2;
int _31NO_VALIDATION_15205 = 3;
int _31NO_VALIDATION_AFTER_FIRST_EXTRA_15206 = 4;
int _31SHOW_ONLY_OPTIONS_15207 = 5;
int _31AT_EXPANSION_15208 = 6;
int _31NO_AT_EXPANSION_15209 = 7;
int _31PAUSE_MSG_15210 = 8;
int _31NO_HELP_15211 = 9;
int _31NO_HELP_ON_ERROR_15212 = 10;
int _31OPT_IDX_15213 = 1;
int _31OPT_CNT_15214 = 2;
int _31OPT_VAL_15215 = 3;
int _31OPT_REV_15216 = 4;
int _31EXTRAS_15217 = NOVALUE;
int _31OPT_EXTRAS_15221 = NOVALUE;
int _31SHORTNAME_15222 = 1;
int _31LONGNAME_15223 = 2;
int _31DESCRIPTION_15224 = 3;
int _31OPTIONS_15225 = 4;
int _31CALLBACK_15226 = 5;
int _31MAPNAME_15227 = 6;
int _31pause_msg_15228 = NOVALUE;
int _38DB_OK_16373 = 0;
int _38DB_OPEN_FAIL_16374 = -1;
int _38DB_EXISTS_ALREADY_16375 = -2;
int _38DB_LOCK_FAIL_16376 = -3;
int _38DB_BAD_NAME_16377 = -4;
int _38DB_FATAL_FAIL_16378 = -404;
int _38DB_LOCK_NO_16381 = 0;
int _38DB_LOCK_SHARED_16382 = 1;
int _38DB_LOCK_EXCLUSIVE_16383 = 2;
int _38DB_LOCK_READ_ONLY_16384 = 3;
int _38MISSING_END_16385 = 900;
int _38NO_DATABASE_16387 = 901;
int _38BAD_SEEK_16389 = 902;
int _38NO_TABLE_16391 = 903;
int _38DUP_TABLE_16393 = 904;
int _38BAD_RECNO_16395 = 905;
int _38INSERT_FAILED_16397 = 906;
int _38LAST_ERROR_CODE_16399 = 907;
int _38BAD_FILE_16401 = 908;
int _38DB_MAGIC_16403 = 77;
int _38DB_MAJOR_16404 = 4;
int _38DB_MINOR_16405 = 0;
int _38SIZEOF_TABLE_HEADER_16406 = 16;
int _38TABLE_HEADERS_16407 = 3;
int _38FREE_COUNT_16408 = 7;
int _38FREE_LIST_16409 = 11;
int _38DEF_INIT_FREE_16410 = 5;
int _38DEF_INIT_TABLES_16411 = 5;
int _38MAX_INDEX_16412 = 10;
int _38DEF_INIT_RECORDS_16413 = 50;
int _38CONNECT_LOCK_16414 = 1;
int _38CONNECT_TABLES_16415 = 2;
int _38CONNECT_FREE_16416 = 3;
int _38TRUE_16417 = 1;
int _38current_db_16418 = NOVALUE;
int _38current_table_pos_16419 = NOVALUE;
int _38current_table_name_16420 = NOVALUE;
int _38db_names_16421 = NOVALUE;
int _38db_file_nums_16422 = NOVALUE;
int _38db_lock_methods_16423 = NOVALUE;
int _38current_lock_16424 = NOVALUE;
int _38key_pointers_16425 = NOVALUE;
int _38key_cache_16426 = NOVALUE;
int _38cache_index_16427 = NOVALUE;
int _38caching_option_16428 = NOVALUE;
int _38DISCONNECT_16429 = NOVALUE;
int _38LOCK_METHOD_16431 = NOVALUE;
int _38INIT_TABLES_16433 = NOVALUE;
int _38INIT_FREE_16435 = NOVALUE;
int _38CONNECTION_16437 = NOVALUE;
int _38Known_Aliases_16439 = NOVALUE;
int _38Alias_Details_16440 = NOVALUE;
int _38db_fatal_id_16441 = NOVALUE;
int _38vLastErrors_16442 = NOVALUE;
int _38mem0_16460 = NOVALUE;
int _38mem1_16461 = NOVALUE;
int _38mem2_16462 = NOVALUE;
int _38mem3_16463 = NOVALUE;
int _38I2B_16519 = 249;
int _38I3B_16520 = 250;
int _38I4B_16521 = 251;
int _38F4B_16522 = 252;
int _38F8B_16523 = 253;
int _38S1B_16524 = 254;
int _38S4B_16525 = 255;
int _38MIN1B_16526 = -9;
int _38MAX1B_16527 = 239;
int _38MIN2B_16528 = NOVALUE;
int _38MAX2B_16531 = NOVALUE;
int _38MIN3B_16534 = NOVALUE;
int _38MAX3B_16537 = NOVALUE;
int _38MIN4B_16540 = NOVALUE;
int _38memseq_16680 = NOVALUE;
int _39one_bit_numbers_18728 = NOVALUE;
int _40M_GRAPHICS_MODE_18823 = 5;
int _40M_WRAP_18824 = 7;
int _40M_SCROLL_18825 = 8;
int _40M_SET_T_COLOR_18826 = 9;
int _40M_SET_B_COLOR_18827 = 10;
int _40M_GET_POSITION_18828 = 25;
int _41BMPFILEHDRSIZE_18927 = 14;
int _41OLDHDRSIZE_18928 = 12;
int _41NEWHDRSIZE_18929 = 40;
int _41EOF_18930 = -1;
int _41fn_18931 = NOVALUE;
int _41error_code_18932 = NOVALUE;
int _41numXPixels_19235 = NOVALUE;
int _41numYPixels_19236 = NOVALUE;
int _41bitCount_19237 = NOVALUE;
int _41numRowBytes_19238 = NOVALUE;
int _44w32_names_19811 = NOVALUE;
int _44w32_name_canonical_20021 = NOVALUE;
int _44posix_names_20042 = NOVALUE;
int _44locale_canonical_20045 = NOVALUE;
int _44platform_locale_20046 = NOVALUE;
int _43P_20092 = 33554436;
int _43I_20093 = 16777220;
int _43def_lang_20094 = NOVALUE;
int _43lang_path_20095 = NOVALUE;
int _43lib_20256 = NOVALUE;
int _43f_strfmon_20258 = NOVALUE;
int _43f_strfnum_20262 = -1;
int _43f_setlocale_20263 = NOVALUE;
int _43f_strftime_20266 = NOVALUE;
int _43LC_ALL_20269 = 6;
int _43LC_NUMERIC_20270 = 1;
int _43LC_MONETARY_20271 = 4;
int _46STDLIB_20575 = NOVALUE;
int _46PIPE_20578 = NOVALUE;
int _46READ_20582 = NOVALUE;
int _46WRITE_20586 = NOVALUE;
int _46CLOSE_20590 = NOVALUE;
int _46DUP2_20594 = NOVALUE;
int _46KILL_20598 = NOVALUE;
int _46FORK_20602 = NOVALUE;
int _46EXECV_20605 = NOVALUE;
int _46SIGNAL_20609 = NOVALUE;
int _46ERRNO_20613 = NOVALUE;
int _46define_c_var_inlined_define_c_var_at_3239_20616 = NOVALUE;
int _46define_c_var_1__tmp_at3239_20617 = NOVALUE;
int _46FAIL_20618 = -1;
int _46os_stdin_20619 = 0;
int _46os_stdout_20620 = 1;
int _46os_stderr_20621 = 2;
int _46os_sig_dfl_20622 = 0;
int _46os_sig_ign_20623 = 1;
int _46STDIN_20624 = 1;
int _46STDOUT_20625 = 2;
int _46STDERR_20626 = 3;
int _46PID_20627 = 4;
int _46PARENT_20628 = 1;
int _46CHILD_20629 = 2;
int _46os_errno_20630 = NOVALUE;
int _47M_PCRE_COMPILE_20903 = 68;
int _47M_PCRE_EXEC_20904 = 70;
int _47M_PCRE_REPLACE_20905 = 71;
int _47M_PCRE_ERROR_MESSAGE_20906 = 95;
int _47M_PCRE_GET_OVECTOR_SIZE_20907 = 97;
int _47DEFAULT_20908 = 0;
int _47CASELESS_20909 = 1;
int _47MULTILINE_20910 = 2;
int _47DOTALL_20911 = 4;
int _47EXTENDED_20912 = 8;
int _47ANCHORED_20913 = 16;
int _47DOLLAR_ENDONLY_20914 = 32;
int _47EXTRA_20915 = 64;
int _47NOTBOL_20916 = 128;
int _47NOTEOL_20917 = 256;
int _47UNGREEDY_20918 = 512;
int _47NOTEMPTY_20919 = 1024;
int _47UTF8_20920 = 2048;
int _47NO_AUTO_CAPTURE_20921 = 4096;
int _47NO_UTF8_CHECK_20922 = 8192;
int _47AUTO_CALLOUT_20923 = 16384;
int _47PARTIAL_20924 = 32768;
int _47DFA_SHORTEST_20925 = 65536;
int _47DFA_RESTART_20926 = 131072;
int _47FIRSTLINE_20927 = 262144;
int _47DUPNAMES_20928 = 524288;
int _47NEWLINE_CR_20929 = 1048576;
int _47NEWLINE_LF_20930 = 2097152;
int _47NEWLINE_CRLF_20931 = 3145728;
int _47NEWLINE_ANY_20933 = 4194304;
int _47NEWLINE_ANYCRLF_20934 = 5242880;
int _47BSR_ANYCRLF_20936 = 8388608;
int _47BSR_UNICODE_20937 = 16777216;
int _47STRING_OFFSETS_20938 = 201326592;
int _47option_names_20940 = NOVALUE;
int _47ERROR_NOMATCH_21000 = -1;
int _47ERROR_NULL_21001 = -2;
int _47ERROR_BADOPTION_21002 = -3;
int _47ERROR_BADMAGIC_21003 = -4;
int _47ERROR_UNKNOWN_OPCODE_21004 = -5;
int _47ERROR_UNKNOWN_NODE_21005 = -5;
int _47ERROR_NOMEMORY_21006 = -6;
int _47ERROR_NOSUBSTRING_21007 = -7;
int _47ERROR_MATCHLIMIT_21009 = -8;
int _47ERROR_CALLOUT_21011 = -9;
int _47ERROR_BADUTF8_21012 = -10;
int _47ERROR_BADUTF8_OFFSET_21014 = -11;
int _47ERROR_PARTIAL_21016 = -12;
int _47ERROR_BADPARTIAL_21018 = -13;
int _47ERROR_INTERNAL_21020 = -14;
int _47ERROR_BADCOUNT_21022 = -15;
int _47ERROR_DFA_UITEM_21024 = -16;
int _47ERROR_DFA_UCOND_21026 = -17;
int _47ERROR_DFA_UMLIMIT_21028 = -18;
int _47ERROR_DFA_WSSIZE_21030 = -19;
int _47ERROR_DFA_RECURSE_21032 = -20;
int _47ERROR_RECURSIONLIMIT_21034 = -21;
int _47ERROR_NULLWSLIMIT_21036 = -22;
int _47ERROR_BADNEWLINE_21038 = -23;
int _47error_names_21040 = NOVALUE;
int _47all_options_21089 = NOVALUE;
int _49DEFAULT_PORT_21544 = 80;
int _49re_ip_21545 = NOVALUE;
int _49re_http_url_21548 = NOVALUE;
int _49re_mail_url_21551 = NOVALUE;
int _49URL_ENTIRE_21591 = 1;
int _49URL_PROTOCOL_21592 = 2;
int _49URL_HTTP_DOMAIN_21593 = 3;
int _49URL_HTTP_PATH_21594 = 4;
int _49URL_HTTP_QUERY_21595 = 5;
int _49URL_MAIL_ADDRESS_21596 = 3;
int _49URL_MAIL_USER_21597 = 4;
int _49URL_MAIL_DOMAIN_21598 = 5;
int _49URL_MAIL_QUERY_21599 = 6;
int _48M_SOCK_GETSERVBYNAME_21626 = 77;
int _48M_SOCK_GETSERVBYPORT_21627 = 78;
int _48M_SOCK_SOCKET_21628 = 81;
int _48M_SOCK_CLOSE_21629 = 82;
int _48M_SOCK_SHUTDOWN_21630 = 83;
int _48M_SOCK_CONNECT_21631 = 84;
int _48M_SOCK_SEND_21632 = 85;
int _48M_SOCK_RECV_21633 = 86;
int _48M_SOCK_BIND_21634 = 87;
int _48M_SOCK_LISTEN_21635 = 88;
int _48M_SOCK_ACCEPT_21636 = 89;
int _48M_SOCK_SETSOCKOPT_21637 = 90;
int _48M_SOCK_GETSOCKOPT_21638 = 91;
int _48M_SOCK_SELECT_21639 = 92;
int _48M_SOCK_SENDTO_21640 = 93;
int _48M_SOCK_RECVFROM_21641 = 94;
int _48M_SOCK_ERROR_CODE_21643 = 96;
int _48M_SOCK_INFO_21644 = 4;
int _48OK_21648 = 0;
int _48ERR_ACCESS_21649 = -1;
int _48ERR_ADDRINUSE_21650 = -2;
int _48ERR_ADDRNOTAVAIL_21651 = -3;
int _48ERR_AFNOSUPPORT_21652 = -4;
int _48ERR_AGAIN_21653 = -5;
int _48ERR_ALREADY_21654 = -6;
int _48ERR_CONNABORTED_21655 = -7;
int _48ERR_CONNREFUSED_21656 = -8;
int _48ERR_CONNRESET_21657 = -9;
int _48ERR_DESTADDRREQ_21658 = -10;
int _48ERR_FAULT_21659 = -11;
int _48ERR_HOSTUNREACH_21660 = -12;
int _48ERR_INPROGRESS_21661 = -13;
int _48ERR_INTR_21662 = -14;
int _48ERR_INVAL_21663 = -15;
int _48ERR_IO_21664 = -16;
int _48ERR_ISCONN_21665 = -17;
int _48ERR_ISDIR_21666 = -18;
int _48ERR_LOOP_21667 = -19;
int _48ERR_MFILE_21668 = -20;
int _48ERR_MSGSIZE_21669 = -21;
int _48ERR_NAMETOOLONG_21670 = -22;
int _48ERR_NETDOWN_21671 = -23;
int _48ERR_NETRESET_21672 = -24;
int _48ERR_NETUNREACH_21674 = -25;
int _48ERR_NFILE_21676 = -26;
int _48ERR_NOBUFS_21678 = -27;
int _48ERR_NOENT_21680 = -28;
int _48ERR_NOTCONN_21682 = -29;
int _48ERR_NOTDIR_21684 = -30;
int _48ERR_NOTINITIALISED_21686 = -31;
int _48ERR_NOTSOCK_21688 = -32;
int _48ERR_OPNOTSUPP_21691 = -33;
int _48ERR_PROTONOSUPPORT_21694 = -34;
int _48ERR_PROTOTYPE_21697 = -35;
int _48ERR_ROFS_21700 = -36;
int _48ERR_SHUTDOWN_21703 = -37;
int _48ERR_SOCKTNOSUPPORT_21706 = -38;
int _48ERR_TIMEDOUT_21709 = -39;
int _48ERR_WOULDBLOCK_21712 = -40;
int _48ESOCK_UNDEFINED_VALUE_21715 = -9999;
int _48ESOCK_UNKNOWN_FLAG_21718 = -9998;
int _48ESOCK_TYPE_AF_21721 = 1;
int _48ESOCK_TYPE_TYPE_21723 = 2;
int _48ESOCK_TYPE_OPTION_21725 = 3;
int _48EAF_UNSPEC_21727 = 6;
int _48EAF_UNIX_21729 = 1;
int _48EAF_INET_21730 = 2;
int _48EAF_INET6_21731 = 3;
int _48EAF_APPLETALK_21732 = 4;
int _48EAF_BTH_21734 = 5;
int _48ESOCK_STREAM_21736 = 1;
int _48ESOCK_DGRAM_21737 = 2;
int _48ESOCK_RAW_21738 = 3;
int _48ESOCK_RDM_21739 = 4;
int _48ESOCK_SEQPACKET_21740 = 5;
int _48sockinfo_21741 = NOVALUE;
int _48AF_UNSPEC_21744 = NOVALUE;
int _48AF_UNIX_21746 = NOVALUE;
int _48AF_INET_21748 = NOVALUE;
int _48AF_INET6_21750 = NOVALUE;
int _48AF_APPLETALK_21752 = NOVALUE;
int _48AF_BTH_21754 = NOVALUE;
int _48SOCK_STREAM_21758 = NOVALUE;
int _48SOCK_DGRAM_21760 = NOVALUE;
int _48SOCK_RAW_21762 = NOVALUE;
int _48SOCK_RDM_21764 = NOVALUE;
int _48SOCK_SEQPACKET_21766 = NOVALUE;
int _48SELECT_SOCKET_21768 = 1;
int _48SELECT_IS_READABLE_21769 = 2;
int _48SELECT_IS_WRITABLE_21770 = 3;
int _48SELECT_IS_ERROR_21771 = 4;
int _48SD_SEND_21772 = 0;
int _48SD_RECEIVE_21774 = 1;
int _48SD_BOTH_21775 = 2;
int _48ESOL_SOCKET_21776 = 1;
int _48ESO_DEBUG_21777 = 2;
int _48ESO_ACCEPTCONN_21778 = 3;
int _48ESO_REUSEADDR_21779 = 4;
int _48ESO_KEEPALIVE_21780 = 5;
int _48ESO_DONTROUTE_21781 = 6;
int _48ESO_BROADCAST_21782 = 7;
int _48ESO_LINGER_21784 = 8;
int _48ESO_SNDBUF_21786 = 9;
int _48ESO_RCVBUF_21788 = 10;
int _48ESO_SNDLOWAT_21790 = 11;
int _48ESO_RCVLOWAT_21792 = 12;
int _48ESO_SNDTIMEO_21794 = 13;
int _48ESO_RCVTIMEO_21796 = 14;
int _48ESO_ERROR_21798 = 15;
int _48ESO_TYPE_21800 = 16;
int _48ESO_OOBINLINE_21802 = 17;
int _48ESO_USELOOPBACK_21804 = 18;
int _48ESO_DONTLINGER_21806 = 19;
int _48ESO_REUSEPORT_21808 = 20;
int _48ESO_CONNDATA_21810 = 21;
int _48ESO_CONNOPT_21812 = 22;
int _48ESO_DISCDATA_21814 = 23;
int _48ESO_DISCOPT_21816 = 24;
int _48ESO_CONNDATALEN_21818 = 25;
int _48ESO_CONNOPTLEN_21820 = 26;
int _48ESO_DISCDATALEN_21822 = 27;
int _48ESO_DISCOPTLEN_21824 = 28;
int _48ESO_OPENTYPE_21826 = 29;
int _48ESO_MAXDG_21828 = 30;
int _48ESO_MAXPATHDG_21830 = 31;
int _48ESO_SYNCHRONOUS_ALTERT_21832 = 32;
int _48ESO_SYNCHRONOUS_NONALERT_21833 = 33;
int _48ESO_SNDBUFFORCE_21834 = 34;
int _48ESO_RCVBUFFORCE_21835 = 35;
int _48ESO_NO_CHECK_21836 = 36;
int _48ESO_PRIORITY_21837 = 37;
int _48ESO_BSDCOMPAT_21838 = 38;
int _48ESO_PASSCRED_21839 = 39;
int _48ESO_PEERCRED_21840 = 40;
int _48ESO_SECURITY_AUTHENTICATION_21841 = 41;
int _48ESO_SECURITY_ENCRYPTION_TRANSPORT_21843 = 42;
int _48ESO_SECURITY_ENCRYPTION_NETWORK_21845 = 43;
int _48ESO_BINDTODEVICE_21847 = 44;
int _48ESO_ATTACH_FILTER_21849 = 45;
int _48ESO_DETACH_FILTER_21851 = 46;
int _48ESO_PEERNAME_21853 = 47;
int _48ESO_TIMESTAMP_21855 = 48;
int _48ESCM_TIMESTAMP_21857 = 49;
int _48ESO_PEERSEC_21859 = 50;
int _48ESO_PASSSEC_21861 = 51;
int _48ESO_TIMESTAMPNS_21863 = 52;
int _48ESCM_TIMESTAMPNS_21865 = 53;
int _48ESO_MARK_21867 = 54;
int _48ESO_TIMESTAMPING_21869 = 55;
int _48ESCM_TIMESTAMPING_21871 = 56;
int _48ESO_PROTOCOL_21873 = 57;
int _48ESO_DOMAIN_21875 = 58;
int _48ESO_RXQ_OVFL_21877 = 59;
int _48SOL_SOCKET_21881 = NOVALUE;
int _48SO_DEBUG_21883 = NOVALUE;
int _48SO_ACCEPTCONN_21885 = NOVALUE;
int _48SO_REUSEADDR_21887 = NOVALUE;
int _48SO_KEEPALIVE_21889 = NOVALUE;
int _48SO_DONTROUTE_21891 = NOVALUE;
int _48SO_BROADCAST_21893 = NOVALUE;
int _48SO_LINGER_21895 = NOVALUE;
int _48SO_SNDBUF_21897 = NOVALUE;
int _48SO_RCVBUF_21899 = NOVALUE;
int _48SO_SNDLOWAT_21901 = NOVALUE;
int _48SO_RCVLOWAT_21903 = NOVALUE;
int _48SO_SNDTIMEO_21905 = NOVALUE;
int _48SO_RCVTIMEO_21907 = NOVALUE;
int _48SO_ERROR_21909 = NOVALUE;
int _48SO_TYPE_21911 = NOVALUE;
int _48SO_OOBINLINE_21913 = NOVALUE;
int _48SO_USELOOPBACK_21915 = NOVALUE;
int _48SO_DONTLINGER_21917 = NOVALUE;
int _48SO_REUSEPORT_21919 = NOVALUE;
int _48SO_CONNDATA_21921 = NOVALUE;
int _48SO_CONNOPT_21923 = NOVALUE;
int _48SO_DISCDATA_21925 = NOVALUE;
int _48SO_DISCOPT_21927 = NOVALUE;
int _48SO_CONNDATALEN_21929 = NOVALUE;
int _48SO_CONNOPTLEN_21931 = NOVALUE;
int _48SO_DISCDATALEN_21933 = NOVALUE;
int _48SO_DISCOPTLEN_21935 = NOVALUE;
int _48SO_OPENTYPE_21937 = NOVALUE;
int _48SO_MAXDG_21939 = NOVALUE;
int _48SO_MAXPATHDG_21941 = NOVALUE;
int _48SO_SYNCHRONOUS_ALTERT_21943 = NOVALUE;
int _48SO_SYNCHRONOUS_NONALERT_21945 = NOVALUE;
int _48SO_SNDBUFFORCE_21947 = NOVALUE;
int _48SO_RCVBUFFORCE_21949 = NOVALUE;
int _48SO_NO_CHECK_21951 = NOVALUE;
int _48SO_PRIORITY_21953 = NOVALUE;
int _48SO_BSDCOMPAT_21955 = NOVALUE;
int _48SO_PASSCRED_21957 = NOVALUE;
int _48SO_PEERCRED_21959 = NOVALUE;
int _48SO_SECURITY_AUTHENTICATION_21961 = NOVALUE;
int _48SO_SECURITY_ENCRYPTION_TRANSPORT_21963 = NOVALUE;
int _48SO_SECURITY_ENCRYPTION_NETWORK_21965 = NOVALUE;
int _48SO_BINDTODEVICE_21967 = NOVALUE;
int _48SO_ATTACH_FILTER_21969 = NOVALUE;
int _48SO_DETACH_FILTER_21971 = NOVALUE;
int _48SO_PEERNAME_21973 = NOVALUE;
int _48SO_TIMESTAMP_21975 = NOVALUE;
int _48SCM_TIMESTAMP_21977 = NOVALUE;
int _48SO_PEERSEC_21979 = NOVALUE;
int _48SO_PASSSEC_21981 = NOVALUE;
int _48SO_TIMESTAMPNS_21983 = NOVALUE;
int _48SCM_TIMESTAMPNS_21985 = NOVALUE;
int _48SO_MARK_21987 = NOVALUE;
int _48SO_TIMESTAMPING_21989 = NOVALUE;
int _48SCM_TIMESTAMPING_21991 = NOVALUE;
int _48SO_PROTOCOL_21993 = NOVALUE;
int _48SO_DOMAIN_21995 = NOVALUE;
int _48SO_RXQ_OVFL_21997 = NOVALUE;
int _48MSG_OOB_21999 = 1;
int _48MSG_PEEK_22000 = 2;
int _48MSG_DONTROUTE_22001 = 4;
int _48MSG_TRYHARD_22002 = 4;
int _48MSG_CTRUNC_22003 = 8;
int _48MSG_PROXY_22004 = 16;
int _48MSG_TRUNC_22005 = 32;
int _48MSG_DONTWAIT_22006 = 64;
int _48MSG_EOR_22008 = 128;
int _48MSG_WAITALL_22010 = 256;
int _48MSG_FIN_22012 = 512;
int _48MSG_SYN_22014 = 1024;
int _48MSG_CONFIRM_22016 = 2048;
int _48MSG_RST_22017 = 4096;
int _48MSG_ERRQUEUE_22019 = 8192;
int _48MSG_NOSIGNAL_22021 = 16384;
int _48MSG_MORE_22023 = 32768;
int _48SOCKET_SOCKET_22025 = 1;
int _48SOCKET_SOCKADDR_IN_22026 = 2;
int _48delete_socket_rid_22054 = NOVALUE;
int _50FIFO_22222 = 1;
int _50FILO_22223 = 2;
int _50type_tag_22224 = 1;
int _50stack_type_22225 = 2;
int _50data_22226 = 3;
int _50type_is_stack_22227 = NOVALUE;
int _51M_SLEEP_22554 = 64;
int _53M_SOCK_GETHOSTBYNAME_22604 = 79;
int _53M_SOCK_GETHOSTBYADDR_22606 = 80;
int _53ADDR_FLAGS_22608 = 1;
int _53ADDR_FAMILY_22609 = 2;
int _53ADDR_TYPE_22610 = 3;
int _53ADDR_PROTOCOL_22611 = 4;
int _53ADDR_ADDRESS_22612 = 5;
int _53HOST_OFFICIAL_NAME_22613 = 1;
int _53HOST_ALIASES_22614 = 2;
int _53HOST_IPS_22615 = 3;
int _53HOST_TYPE_22616 = 4;
int _53DNS_QUERY_STANDARD_22617 = 0;
int _53DNS_QUERY_ACCEPT_TRUNCATED_RESPONSE_22618 = 1;
int _53DNS_QUERY_USE_TCP_ONLY_22619 = 2;
int _53DNS_QUERY_NO_RECURSION_22620 = 4;
int _53DNS_QUERY_BYPASS_CACHE_22621 = 8;
int _53DNS_QUERY_NO_WIRE_QUERY_22622 = 16;
int _53DNS_QUERY_NO_LOCAL_NAME_22623 = 32;
int _53DNS_QUERY_NO_HOSTS_FILE_22624 = 64;
int _53DNS_QUERY_NO_NETBT_22625 = 128;
int _53DNS_QUERY_WIRE_ONLY_22626 = 256;
int _53DNS_QUERY_RETURN_MESSAGE_22627 = 512;
int _53DNS_QUERY_TREAT_AS_FQDN_22628 = 4096;
int _53DNS_QUERY_DONT_RESET_TTL_VALUES_22629 = 1048576;
int _53DNS_QUERY_RESERVED_22630 = NOVALUE;
int _53NS_C_IN_22632 = 1;
int _53NS_C_ANY_22633 = 255;
int _53NS_KT_RSA_22635 = 1;
int _53NS_KT_DH_22636 = 2;
int _53NS_KT_DSA_22637 = 3;
int _53NS_KT_PRIVATE_22638 = 254;
int _53NS_T_A_22640 = 1;
int _53NS_T_NS_22641 = 2;
int _53NS_T_PTR_22642 = 12;
int _53NS_T_MX_22643 = 15;
int _53NS_T_AAAA_22644 = 28;
int _53NS_T_A6_22645 = 38;
int _53NS_T_ANY_22646 = 255;
int _55PAIR_SEP_A_22663 = 38;
int _55PAIR_SEP_B_22664 = 59;
int _55HEX_SIG_22665 = 37;
int _55WHITESPACE_22666 = 43;
int _55VALUE_SEP_22667 = 61;
int _55URL_PROTOCOL_22710 = 1;
int _55URL_HOSTNAME_22711 = 2;
int _55URL_PORT_22712 = 3;
int _55URL_PATH_22713 = 4;
int _55URL_USER_22714 = 5;
int _55URL_PASSWORD_22715 = 6;
int _55URL_QUERY_STRING_22716 = 7;
int _55alphanum_22822 = NOVALUE;
int _55hexnums_22824 = NOVALUE;
int _54USER_AGENT_HEADER_22921 = NOVALUE;
int _54R_HOST_22929 = 1;
int _54R_PORT_22930 = 2;
int _54R_PATH_22931 = 3;
int _54R_REQUEST_22932 = 4;
int _54FR_SIZE_22933 = 4;
int _54ERR_MALFORMED_URL_22934 = -1;
int _54ERR_INVALID_PROTOCOL_22935 = -2;
int _54ERR_INVALID_DATA_22937 = -3;
int _54ERR_INVALID_DATA_ENCODING_22939 = -4;
int _54ERR_HOST_LOOKUP_FAILED_22941 = -5;
int _54ERR_CONNECT_FAILED_22943 = -6;
int _54ERR_SEND_FAILED_22945 = -7;
int _54ERR_RECEIVE_FAILED_22946 = -8;
int _54FORM_URLENCODED_22947 = 1;
int _54MULTIPART_FORM_DATA_22948 = 2;
int _54ENCODE_NONE_22949 = 0;
int _54ENCODE_BASE64_22950 = 1;
int _54ENCODING_STRINGS_22951 = NOVALUE;
int _54rand_chars_23106 = NOVALUE;
int _54rand_chars_len_23108 = NOVALUE;
int _56MB_ABORTRETRYIGNORE_23332 = 2;
int _56MB_APPLMODAL_23333 = 0;
int _56MB_DEFAULT_DESKTOP_ONLY_23334 = 131072;
int _56MB_DEFBUTTON1_23335 = 0;
int _56MB_DEFBUTTON2_23336 = 256;
int _56MB_DEFBUTTON3_23337 = 512;
int _56MB_DEFBUTTON4_23338 = 768;
int _56MB_HELP_23340 = 16384;
int _56MB_ICONASTERISK_23341 = 64;
int _56MB_ICONERROR_23342 = 16;
int _56MB_ICONEXCLAMATION_23343 = 48;
int _56MB_ICONHAND_23344 = 16;
int _56MB_ICONINFORMATION_23345 = 64;
int _56MB_ICONQUESTION_23346 = 32;
int _56MB_ICONSTOP_23347 = 16;
int _56MB_ICONWARNING_23348 = 48;
int _56MB_OK_23349 = 0;
int _56MB_OKCANCEL_23350 = 1;
int _56MB_RETRYCANCEL_23351 = 5;
int _56MB_RIGHT_23352 = 524288;
int _56MB_RTLREADING_23354 = 1048576;
int _56MB_SERVICE_NOTIFICATION_23355 = 262144;
int _56MB_SETFOREGROUND_23356 = 65536;
int _56MB_SYSTEMMODAL_23358 = 4096;
int _56MB_TASKMODAL_23359 = 8192;
int _56MB_YESNO_23360 = 4;
int _56MB_YESNOCANCEL_23361 = 3;
int _56IDABORT_23362 = 3;
int _56IDCANCEL_23363 = 2;
int _56IDIGNORE_23364 = 5;
int _56IDNO_23365 = 7;
int _56IDOK_23366 = 1;
int _56IDRETRY_23367 = 4;
int _56IDYES_23368 = 6;
int _56msgbox_id_23370 = NOVALUE;
int _56get_active_id_23371 = NOVALUE;
int _57SND_DEFAULT_23405 = 0;
int _57SND_STOP_23406 = 16;
int _57SND_QUESTION_23407 = 32;
int _57SND_EXCLAMATION_23408 = 48;
int _57SND_ASTERISK_23409 = 64;
int _57xMessageBeep_23410 = NOVALUE;
int _57xUser32_23411 = NOVALUE;
int _59M_ALLOC_23439 = 16;
int _59M_FREE_23440 = 17;
int _59M_ALLOC_LOW_23441 = 32;
int _59M_FREE_LOW_23442 = 33;
int _59M_INTERRUPT_23443 = 34;
int _59M_SET_RAND_23444 = 35;
int _59M_USE_VESA_23445 = 36;
int _59M_CRASH_MESSAGE_23446 = 37;
int _59M_TICK_RATE_23447 = 38;
int _59M_GET_VECTOR_23448 = 39;
int _59M_SET_VECTOR_23449 = 40;
int _59M_LOCK_MEMORY_23450 = 41;
int _59M_A_TO_F64_23451 = 46;
int _59M_F64_TO_A_23452 = 47;
int _59M_A_TO_F32_23453 = 48;
int _59M_F32_TO_A_23454 = 49;
int _59M_CRASH_FILE_23455 = 57;
int _59M_CRASH_ROUTINE_23456 = 66;
int _59MAX_ADDR_23458 = NOVALUE;
int _59LOW_ADDR_23461 = NOVALUE;
int _59REG_LIST_SIZE_23491 = 10;
int _59REG_DI_23492 = 1;
int _59REG_SI_23493 = 2;
int _59REG_BP_23494 = 3;
int _59REG_BX_23495 = 4;
int _59REG_DX_23496 = 5;
int _59REG_CX_23497 = 6;
int _59REG_AX_23498 = 7;
int _59REG_FLAGS_23499 = 8;
int _59REG_ES_23500 = 9;
int _59REG_DS_23501 = 10;
int _59mem_23533 = NOVALUE;
int _59allocate_inlined_allocate_at_4169_23535 = NOVALUE;
int _59check_calls_23622 = NOVALUE;
int _58always_linked_list_23632 = NOVALUE;
int _58NULL_23697 = 0;
int _58SIZE_OF_STRUCT_23698 = 16;
int _58MAX_LENGTH_23699 = 268435455;
int _58SIGN_MASK_23701 = NOVALUE;
int _58SIGN_FLAG_23703 = NOVALUE;
int _58DOUBLE_FLAG_23704 = NOVALUE;
int _58INT_FLAG_23706 = NOVALUE;
int _58UINT_FLAG_23708 = NOVALUE;
int _58FLOAT_FLAG_23710 = NOVALUE;
int _58CSTRING_23712 = NOVALUE;
int _58CBYTES_23713 = NOVALUE;
int _1VERSION_23971 = 3;
int _1high_address_23974 = NOVALUE;
int _1data_23975 = NOVALUE;
int _1free_list_23976 = NOVALUE;
int _1state_inlined_new_at_912_24900 = NOVALUE;
int _1new_inlined_new_at_912_24901 = NOVALUE;
int _1options_inlined_new_at_3594_24911 = NOVALUE;
int _1new_1__tmp_at3597_24912 = NOVALUE;
int _1new_2__tmp_at3597_24913 = NOVALUE;
int _1options_inlined_new_at_3625_24915 = NOVALUE;
int _1new_1__tmp_at3628_24916 = NOVALUE;
int _1new_2__tmp_at3628_24917 = NOVALUE;
int _1options_inlined_new_at_3656_24919 = NOVALUE;
int _1new_1__tmp_at3659_24920 = NOVALUE;
int _1new_2__tmp_at3659_24921 = NOVALUE;


struct routine_list _00[] = {
  {"set_return_linked_list", (int (*)())_1set_return_linked_list, 0, 1, 1, 0, 6, 0},
  {"get_return_linked_list", (int (*)())_1get_return_linked_list, 1, 1, 0, 0, 6, 0},
  {"get_version", (int (*)())_1get_version, 2, 1, 0, 0, 6, 0},
  {"init", (int (*)())_1init, 3, 1, 0, 0, 6, 0},
  {"get_high_address", (int (*)())_1get_high_address, 4, 1, 0, 0, 6, 0},
  {"set_high_address", (int (*)())_1set_high_address, 5, 1, 1, 0, 5, 0},
  {"get_address", (int (*)())_1get_address, 6, 1, 2, 0, 5, 0},
  {"register_data", (int (*)())_1register_data, 7, 1, 1, 0, 5, 0},
  {"retval", (int (*)())_1retval, 8, 1, 1, 0, 5, 0},
  {"length_of_data", (int (*)())_1length_of_data, 9, 1, 0, 0, 6, 0},
  {"is_free", (int (*)())_1is_free, 10, 1, 1, 0, 6, 0},
  {"access_free_list", (int (*)())_1access_free_list, 11, 1, 0, 0, 6, 0},
  {"generic_free", (int (*)())_1generic_free, 12, 1, 2, 0, 6, 0},
  {"delete_linked_list", (int (*)())_1delete_linked_list, 13, 1, 1, 0, 6, 0},
  {"free_linked_lists", (int (*)())_1free_linked_lists, 14, 1, 3, 0, 6, 0},
  {"register_linked_list", (int (*)())_1register_linked_list, 15, 1, 2, 0, 6, 0},
  {"new_linked_list", (int (*)())_1new_linked_list, 16, 1, 2, 0, 6, 0},
  {"store_linked_list", (int (*)())_1store_linked_list, 17, 1, 3, 0, 6, 0},
  {"access_linked_list", (int (*)())_1access_linked_list, 18, 1, 1, 0, 6, 0},
  {"at_linked_list", (int (*)())_1at_linked_list, 19, 1, 2, 0, 6, 0},
  {"free_linked_list_dll", (int (*)())_1free_linked_list_dll, 20, 1, 2, 0, 6, 0},
  {"length_linked_list", (int (*)())_1length_linked_list, 21, 1, 1, 0, 6, 0},
  {"store_at_linked_list", (int (*)())_1store_at_linked_list, 22, 1, 4, 0, 6, 0},
  {"eu_repeat", (int (*)())_1eu_repeat, 23, 1, 2, 0, 6, 0},
  {"eu_mem_set", (int (*)())_1eu_mem_set, 24, 1, 4, 0, 6, 0},
  {"eu_mem_copy", (int (*)())_1eu_mem_copy, 25, 1, 5, 0, 6, 0},
  {"eu_add", (int (*)())_1eu_add, 26, 1, 2, 0, 6, 0},
  {"eu_subtract", (int (*)())_1eu_subtract, 27, 1, 2, 0, 6, 0},
  {"eu_multiply", (int (*)())_1eu_multiply, 28, 1, 2, 0, 6, 0},
  {"eu_divide", (int (*)())_1eu_divide, 29, 1, 2, 0, 6, 0},
  {"eu_negate", (int (*)())_1eu_negate, 30, 1, 1, 0, 6, 0},
  {"eu_not", (int (*)())_1eu_not, 31, 1, 1, 0, 6, 0},
  {"eu_equals", (int (*)())_1eu_equals, 32, 1, 2, 0, 6, 0},
  {"eu_and", (int (*)())_1eu_and, 33, 1, 2, 0, 6, 0},
  {"eu_or", (int (*)())_1eu_or, 34, 1, 2, 0, 6, 0},
  {"eu_xor", (int (*)())_1eu_xor, 35, 1, 2, 0, 6, 0},
  {"eu_question_mark", (int (*)())_1eu_question_mark, 36, 1, 1, 0, 6, 0},
  {"eu_abort", (int (*)())_1eu_abort, 37, 1, 1, 0, 6, 0},
  {"eu_and_bits", (int (*)())_1eu_and_bits, 38, 1, 2, 0, 6, 0},
  {"eu_append", (int (*)())_1eu_append, 39, 1, 2, 0, 6, 0},
  {"eu_arctan", (int (*)())_1eu_arctan, 40, 1, 1, 0, 6, 0},
  {"eu_atom", (int (*)())_1eu_atom, 41, 1, 1, 0, 6, 0},
  {"eu_c_func", (int (*)())_1eu_c_func, 42, 1, 2, 0, 6, 0},
  {"eu_c_proc", (int (*)())_1eu_c_proc, 43, 1, 2, 0, 6, 0},
  {"eu_call", (int (*)())_1eu_call, 44, 1, 2, 0, 6, 0},
  {"eu_clear_screen", (int (*)())_1eu_clear_screen, 45, 1, 0, 0, 6, 0},
  {"eu_close", (int (*)())_1eu_close, 46, 1, 1, 0, 6, 0},
  {"eu_command_line", (int (*)())_1eu_command_line, 47, 1, 0, 0, 6, 0},
  {"eu_compare", (int (*)())_1eu_compare, 48, 1, 2, 0, 6, 0},
  {"eu_concat", (int (*)())_1eu_concat, 49, 1, 2, 0, 6, 0},
  {"eu_cos", (int (*)())_1eu_cos, 50, 1, 1, 0, 6, 0},
  {"eu_date", (int (*)())_1eu_date, 51, 1, 0, 0, 6, 0},
  {"eu_equal", (int (*)())_1eu_equal, 52, 1, 2, 0, 6, 0},
  {"eu_find_from", (int (*)())_1eu_find_from, 53, 1, 3, 0, 6, 0},
  {"eu_find", (int (*)())_1eu_find, 54, 1, 3, 0, 6, 0},
  {"eu_floor", (int (*)())_1eu_floor, 55, 1, 1, 0, 6, 0},
  {"eu_integer_division", (int (*)())_1eu_integer_division, 56, 1, 2, 0, 6, 0},
  {"eu_get_key", (int (*)())_1eu_get_key, 57, 1, 0, 0, 6, 0},
  {"eu_getc", (int (*)())_1eu_getc, 58, 1, 1, 0, 6, 0},
  {"eu_getenv", (int (*)())_1eu_getenv, 59, 1, 1, 0, 6, 0},
  {"eu_gets", (int (*)())_1eu_gets, 60, 1, 1, 0, 6, 0},
  {"eu_integer", (int (*)())_1eu_integer, 61, 1, 1, 0, 6, 0},
  {"eu_length", (int (*)())_1eu_length, 62, 1, 1, 0, 6, 0},
  {"eu_log", (int (*)())_1eu_log, 63, 1, 1, 0, 6, 0},
  {"eu_machine_func", (int (*)())_1eu_machine_func, 64, 1, 2, 0, 6, 0},
  {"eu_machine_proc", (int (*)())_1eu_machine_proc, 65, 1, 2, 0, 6, 0},
  {"eu_match_from", (int (*)())_1eu_match_from, 66, 1, 3, 0, 6, 0},
  {"eu_match", (int (*)())_1eu_match, 67, 1, 3, 0, 6, 0},
  {"eu_not_bits", (int (*)())_1eu_not_bits, 68, 1, 1, 0, 6, 0},
  {"eu_object", (int (*)())_1eu_object, 69, 1, 1, 0, 6, 0},
  {"eu_open", (int (*)())_1eu_open, 70, 1, 2, 0, 6, 0},
  {"eu_open_str", (int (*)())_1eu_open_str, 71, 1, 3, 0, 6, 0},
  {"eu_or_bits", (int (*)())_1eu_or_bits, 72, 1, 2, 0, 6, 0},
  {"eu_peek", (int (*)())_1eu_peek, 73, 1, 1, 0, 6, 0},
  {"eu_peek4s", (int (*)())_1eu_peek4s, 74, 1, 1, 0, 6, 0},
  {"eu_peek4u", (int (*)())_1eu_peek4u, 75, 1, 1, 0, 6, 0},
  {"eu_platform", (int (*)())_1eu_platform, 76, 1, 0, 0, 6, 0},
  {"eu_poke", (int (*)())_1eu_poke, 77, 1, 2, 0, 6, 0},
  {"eu_poke4", (int (*)())_1eu_poke4, 78, 1, 2, 0, 6, 0},
  {"eu_position", (int (*)())_1eu_position, 79, 1, 2, 0, 6, 0},
  {"eu_power", (int (*)())_1eu_power, 80, 1, 2, 0, 6, 0},
  {"eu_prepend", (int (*)())_1eu_prepend, 81, 1, 2, 0, 6, 0},
  {"eu_print", (int (*)())_1eu_print, 82, 1, 2, 0, 6, 0},
  {"eu_printf", (int (*)())_1eu_printf, 83, 1, 3, 0, 6, 0},
  {"eu_puts", (int (*)())_1eu_puts, 84, 1, 2, 0, 6, 0},
  {"eu_rand", (int (*)())_1eu_rand, 85, 1, 1, 0, 6, 0},
  {"eu_remainder", (int (*)())_1eu_remainder, 86, 1, 2, 0, 6, 0},
  {"eu_sequence", (int (*)())_1eu_sequence, 87, 1, 1, 0, 6, 0},
  {"eu_sin", (int (*)())_1eu_sin, 88, 1, 1, 0, 6, 0},
  {"eu_sprintf", (int (*)())_1eu_sprintf, 89, 1, 2, 0, 6, 0},
  {"eu_sqrt", (int (*)())_1eu_sqrt, 90, 1, 1, 0, 6, 0},
  {"eu_subscript", (int (*)())_1eu_subscript, 91, 1, 3, 0, 6, 0},
  {"eu_system", (int (*)())_1eu_system, 92, 1, 2, 0, 6, 0},
  {"eu_system_exec", (int (*)())_1eu_system_exec, 93, 1, 2, 0, 6, 0},
  {"eu_tan", (int (*)())_1eu_tan, 94, 1, 1, 0, 6, 0},
  {"eu_time", (int (*)())_1eu_time, 95, 1, 0, 0, 6, 0},
  {"eu_xor_bits", (int (*)())_1eu_xor_bits, 96, 1, 2, 0, 6, 0},
  {"eu_hash", (int (*)())_1eu_hash, 97, 1, 2, 0, 6, 0},
  {"eu_head", (int (*)())_1eu_head, 98, 1, 2, 0, 6, 0},
  {"eu_include_paths", (int (*)())_1eu_include_paths, 99, 1, 1, 0, 6, 0},
  {"eu_insert", (int (*)())_1eu_insert, 100, 1, 3, 0, 6, 0},
  {"eu_peek2s", (int (*)())_1eu_peek2s, 101, 1, 1, 0, 6, 0},
  {"eu_peek2u", (int (*)())_1eu_peek2u, 102, 1, 1, 0, 6, 0},
  {"eu_peek_string", (int (*)())_1eu_peek_string, 103, 1, 1, 0, 6, 0},
  {"eu_peeks", (int (*)())_1eu_peeks, 104, 1, 1, 0, 6, 0},
  {"eu_poke2", (int (*)())_1eu_poke2, 105, 1, 2, 0, 6, 0},
  {"eu_remove", (int (*)())_1eu_remove, 106, 1, 3, 0, 6, 0},
  {"eu_replace", (int (*)())_1eu_replace, 107, 1, 4, 0, 6, 0},
  {"eu_splice", (int (*)())_1eu_splice, 108, 1, 3, 0, 6, 0},
  {"eu_tail", (int (*)())_1eu_tail, 109, 1, 2, 0, 6, 0},
  {"eu_call_func_std", (int (*)())_1eu_call_func_std, 110, 1, 2, 0, 6, 0},
  {"eu_call_func_val", (int (*)())_1eu_call_func_val, 111, 1, 2, 0, 6, 0},
  {"eu_call_func", (int (*)())_1eu_call_func, 112, 1, 2, 0, 6, 0},
  {"eu_call_proc", (int (*)())_1eu_call_proc, 113, 1, 2, 0, 6, 0},
  {"eu_routine_id", (int (*)())_1eu_routine_id, 114, 1, 1, 0, 6, 0},
  {"eu_routine_id_str", (int (*)())_1eu_routine_id_str, 115, 1, 2, 0, 6, 0},
  {"syncolor_new", (int (*)())_2syncolor_new, 116, 2, 0, 0, 13, 0},
  {"base64_encode", (int (*)())_2base64_encode, 117, 2, 2, 0, 13, 0},
  {"base64_decode", (int (*)())_2base64_decode, 118, 2, 1, 0, 13, 0},
  {"console_allow_break", (int (*)())_2console_allow_break, 119, 2, 1, 0, 13, 0},
  {"console_has_console", (int (*)())_2console_has_console, 120, 2, 0, 0, 13, 0},
  {"datetime_format", (int (*)())_2datetime_format, 121, 2, 2, 0, 13, 0},
  {"datetime_new", (int (*)())_2datetime_new, 122, 2, 6, 0, 13, 0},
  {"datetime_datetime", (int (*)())_2datetime_datetime, 123, 2, 1, 0, 13, 0},
  {"datetime_parse", (int (*)())_2datetime_parse, 124, 2, 3, 0, 13, 0},
  {"datetime_add", (int (*)())_2datetime_add, 125, 2, 3, 0, 13, 0},
  {"stdget_get", (int (*)())_2stdget_get, 126, 2, 3, 0, 13, 0},
  {"graphics_wrap", (int (*)())_2graphics_wrap, 127, 2, 1, 0, 13, 0},
  {"locale_get", (int (*)())_2locale_get, 128, 2, 0, 0, 13, 0},
  {"locale_datetime", (int (*)())_2locale_datetime, 129, 2, 2, 0, 13, 0},
  {"locale_set", (int (*)())_2locale_set, 130, 2, 1, 0, 13, 0},
  {"map_new", (int (*)())_2map_new, 131, 2, 1, 0, 13, 0},
  {"map_get", (int (*)())_2map_get, 132, 2, 3, 0, 13, 0},
  {"map_size", (int (*)())_2map_size, 133, 2, 1, 0, 13, 0},
  {"map_clear", (int (*)())_2map_clear, 134, 2, 1, 0, 13, 0},
  {"map_remove", (int (*)())_2map_remove, 135, 2, 2, 0, 13, 0},
  {"map_calc_hash", (int (*)())_2map_calc_hash, 136, 2, 2, 0, 13, 0},
  {"map_compare", (int (*)())_2map_compare, 137, 2, 3, 0, 13, 0},
  {"math_sum", (int (*)())_2math_sum, 138, 2, 1, 0, 13, 0},
  {"pipeio_create", (int (*)())_2pipeio_create, 139, 2, 0, 0, 13, 0},
  {"pipeio_close", (int (*)())_2pipeio_close, 140, 2, 1, 0, 13, 0},
  {"regex_new", (int (*)())_2regex_new, 141, 2, 2, 0, 13, 0},
  {"regex_escape", (int (*)())_2regex_escape, 142, 2, 1, 0, 13, 0},
  {"regex_find_all", (int (*)())_2regex_find_all, 143, 2, 5, 0, 13, 0},
  {"regex_is_match", (int (*)())_2regex_is_match, 144, 2, 4, 0, 13, 0},
  {"regex_split", (int (*)())_2regex_split, 145, 2, 4, 0, 13, 0},
  {"regex_find_replace", (int (*)())_2regex_find_replace, 146, 2, 5, 0, 13, 0},
  {"regex_get_ovector_size", (int (*)())_2regex_get_ovector_size, 147, 2, 2, 0, 13, 0},
  {"regex_find", (int (*)())_2regex_find, 148, 2, 5, 0, 13, 0},
  {"search_find_all", (int (*)())_2search_find_all, 149, 2, 3, 0, 13, 0},
  {"search_find_replace", (int (*)())_2search_find_replace, 150, 2, 4, 0, 13, 0},
  {"stdseq_split", (int (*)())_2stdseq_split, 151, 2, 4, 0, 13, 0},
  {"sockets_create", (int (*)())_2sockets_create, 152, 2, 3, 0, 13, 0},
  {"sockets_close", (int (*)())_2sockets_close, 153, 2, 1, 0, 13, 0},
  {"stack_new", (int (*)())_2stack_new, 154, 2, 1, 0, 13, 0},
  {"stack_size", (int (*)())_2stack_size, 155, 2, 1, 0, 13, 0},
  {"stack_set", (int (*)())_2stack_set, 156, 2, 3, 0, 13, 0},
  {"stack_clear", (int (*)())_2stack_clear, 157, 2, 1, 0, 13, 0},
  {"stats_sum", (int (*)())_2stats_sum, 158, 2, 2, 0, 13, 0},
  {"text_format", (int (*)())_2text_format, 159, 2, 2, 0, 13, 0},
  {"text_wrap", (int (*)())_2text_wrap, 160, 2, 4, 0, 13, 0},
  {"text_escape", (int (*)())_2text_escape, 161, 2, 2, 0, 13, 0},
  {"wildcard_is_match", (int (*)())_2wildcard_is_match, 162, 2, 2, 0, 13, 0},
  {"url_parse", (int (*)())_2url_parse, 163, 2, 2, 0, 13, 0},
  {"url_encode", (int (*)())_2url_encode, 164, 2, 2, 0, 13, 0},
  {"url_decode", (int (*)())_2url_decode, 165, 2, 1, 0, 13, 0},
  {"lib_call_func", (int (*)())_2lib_call_func, 166, 2, 2, 0, 13, 0},
  {"lib_call_proc", (int (*)())_2lib_call_proc, 167, 2, 2, 0, 13, 0},
  {"lib_routine_id", (int (*)())_2lib_routine_id, 168, 2, 1, 0, 13, 0},
  {"platform_name", (int (*)())_3platform_name, 169, 3, 0, 0, 13, 0},
  {"version", (int (*)())_3version, 170, 3, 0, 0, 13, 0},
  {"version_major", (int (*)())_3version_major, 171, 3, 0, 0, 13, 0},
  {"version_minor", (int (*)())_3version_minor, 172, 3, 0, 0, 13, 0},
  {"version_patch", (int (*)())_3version_patch, 173, 3, 0, 0, 13, 0},
  {"version_node", (int (*)())_3version_node, 174, 3, 1, 0, 13, 0},
  {"version_revision", (int (*)())_3version_revision, 175, 3, 0, 0, 13, 0},
  {"version_date", (int (*)())_3version_date, 176, 3, 1, 0, 13, 0},
  {"version_type", (int (*)())_3version_type, 177, 3, 0, 0, 13, 0},
  {"version_string", (int (*)())_3version_string, 178, 3, 1, 0, 13, 0},
  {"version_string_short", (int (*)())_3version_string_short, 179, 3, 0, 0, 13, 0},
  {"version_string_long", (int (*)())_3version_string_long, 180, 3, 1, 0, 13, 0},
  {"euphoria_copyright", (int (*)())_3euphoria_copyright, 181, 3, 0, 0, 13, 0},
  {"pcre_copyright", (int (*)())_3pcre_copyright, 182, 3, 0, 0, 13, 0},
  {"all_copyrights", (int (*)())_3all_copyrights, 183, 3, 0, 0, 13, 0},
  {"start_time", (int (*)())_3start_time, 184, 3, 0, 0, 13, 0},
  {"set_colors", (int (*)())_5set_colors, 185, 5, 1, 0, 13, 0},
  {"init_class", (int (*)())_5init_class, 186, 5, 0, 0, 13, 0},
  {"new", (int (*)())_5new, 189, 5, 0, 0, 11, 0},
  {"reset", (int (*)())_5reset, 190, 5, 1, 0, 13, 0},
  {"SyntaxColor", (int (*)())_5SyntaxColor, 191, 5, 2, 0, 13, 0},
  {"sprint", (int (*)())_6sprint, 192, 6, 1, 0, 13, 0},
  {"trim_head", (int (*)())_6trim_head, 193, 6, 3, 0, 13, 0},
  {"trim_tail", (int (*)())_6trim_tail, 194, 6, 3, 0, 13, 0},
  {"trim", (int (*)())_6trim, 195, 6, 3, 0, 13, 0},
  {"set_encoding_properties", (int (*)())_6set_encoding_properties, 197, 6, 3, 0, 13, 0},
  {"get_encoding_properties", (int (*)())_6get_encoding_properties, 198, 6, 0, 0, 13, 0},
  {"lower", (int (*)())_6lower, 199, 6, 1, 0, 13, 0},
  {"upper", (int (*)())_6upper, 200, 6, 1, 0, 13, 0},
  {"proper", (int (*)())_6proper, 201, 6, 1, 0, 13, 0},
  {"keyvalues", (int (*)())_6keyvalues, 202, 6, 6, 0, 13, 0},
  {"escape", (int (*)())_6escape, 203, 6, 2, 0, 11, 0},
  {"quote", (int (*)())_6quote, 204, 6, 4, 0, 13, 0},
  {"dequote", (int (*)())_6dequote, 205, 6, 3, 0, 13, 0},
  {"format", (int (*)())_6format, 206, 6, 2, 0, 11, 0},
  {"wrap", (int (*)())_6wrap, 207, 6, 4, 0, 11, 0},
  {"char_test", (int (*)())_7char_test, 208, 7, 2, 0, 13, 0},
  {"set_default_charsets", (int (*)())_7set_default_charsets, 209, 7, 0, 0, 13, 0},
  {"get_charsets", (int (*)())_7get_charsets, 210, 7, 0, 0, 13, 0},
  {"set_charsets", (int (*)())_7set_charsets, 211, 7, 1, 0, 13, 0},
  {"boolean", (int (*)())_7boolean, 212, 7, 1, 0, 13, 0},
  {"t_boolean", (int (*)())_7t_boolean, 213, 7, 1, 0, 13, 0},
  {"t_alnum", (int (*)())_7t_alnum, 214, 7, 1, 0, 13, 0},
  {"t_identifier", (int (*)())_7t_identifier, 215, 7, 1, 0, 13, 0},
  {"t_alpha", (int (*)())_7t_alpha, 216, 7, 1, 0, 13, 0},
  {"t_ascii", (int (*)())_7t_ascii, 217, 7, 1, 0, 13, 0},
  {"t_cntrl", (int (*)())_7t_cntrl, 218, 7, 1, 0, 13, 0},
  {"t_digit", (int (*)())_7t_digit, 219, 7, 1, 0, 13, 0},
  {"t_graph", (int (*)())_7t_graph, 220, 7, 1, 0, 13, 0},
  {"t_specword", (int (*)())_7t_specword, 221, 7, 1, 0, 13, 0},
  {"t_bytearray", (int (*)())_7t_bytearray, 222, 7, 1, 0, 13, 0},
  {"t_lower", (int (*)())_7t_lower, 223, 7, 1, 0, 13, 0},
  {"t_print", (int (*)())_7t_print, 224, 7, 1, 0, 13, 0},
  {"t_display", (int (*)())_7t_display, 225, 7, 1, 0, 13, 0},
  {"t_punct", (int (*)())_7t_punct, 226, 7, 1, 0, 13, 0},
  {"t_space", (int (*)())_7t_space, 227, 7, 1, 0, 13, 0},
  {"t_upper", (int (*)())_7t_upper, 228, 7, 1, 0, 13, 0},
  {"t_xdigit", (int (*)())_7t_xdigit, 229, 7, 1, 0, 13, 0},
  {"t_vowel", (int (*)())_7t_vowel, 230, 7, 1, 0, 13, 0},
  {"t_consonant", (int (*)())_7t_consonant, 231, 7, 1, 0, 13, 0},
  {"integer_array", (int (*)())_7integer_array, 232, 7, 1, 0, 13, 0},
  {"t_text", (int (*)())_7t_text, 233, 7, 1, 0, 13, 0},
  {"number_array", (int (*)())_7number_array, 234, 7, 1, 0, 13, 0},
  {"sequence_array", (int (*)())_7sequence_array, 235, 7, 1, 0, 13, 0},
  {"ascii_string", (int (*)())_7ascii_string, 236, 7, 1, 0, 13, 0},
  {"string", (int (*)())_7string, 237, 7, 1, 0, 13, 0},
  {"cstring", (int (*)())_7cstring, 238, 7, 1, 0, 13, 0},
  {"int_to_bytes", (int (*)())_8int_to_bytes, 239, 8, 1, 0, 13, 0},
  {"bytes_to_int", (int (*)())_8bytes_to_int, 242, 8, 1, 0, 13, 0},
  {"int_to_bits", (int (*)())_8int_to_bits, 243, 8, 2, 0, 13, 0},
  {"bits_to_int", (int (*)())_8bits_to_int, 244, 8, 1, 0, 13, 0},
  {"atom_to_float64", (int (*)())_8atom_to_float64, 245, 8, 1, 0, 13, 0},
  {"atom_to_float32", (int (*)())_8atom_to_float32, 246, 8, 1, 0, 13, 0},
  {"float64_to_atom", (int (*)())_8float64_to_atom, 247, 8, 1, 0, 13, 0},
  {"float32_to_atom", (int (*)())_8float32_to_atom, 248, 8, 1, 0, 13, 0},
  {"hex_text", (int (*)())_8hex_text, 249, 8, 1, 0, 13, 0},
  {"set_decimal_mark", (int (*)())_8set_decimal_mark, 250, 8, 1, 0, 13, 0},
  {"to_number", (int (*)())_8to_number, 251, 8, 2, 0, 13, 0},
  {"to_integer", (int (*)())_8to_integer, 252, 8, 2, 0, 13, 0},
  {"to_string", (int (*)())_8to_string, 253, 8, 3, 0, 13, 0},
  {"find_any", (int (*)())_9find_any, 254, 9, 3, 0, 13, 0},
  {"match_any", (int (*)())_9match_any, 255, 9, 3, 0, 13, 0},
  {"find_each", (int (*)())_9find_each, 256, 9, 3, 0, 13, 0},
  {"find_all", (int (*)())_9find_all, 257, 9, 3, 0, 11, 0},
  {"find_all_but", (int (*)())_9find_all_but, 258, 9, 3, 0, 13, 0},
  {"find_nested", (int (*)())_9find_nested, 259, 9, 4, 0, 13, 0},
  {"rfind", (int (*)())_9rfind, 260, 9, 3, 0, 13, 0},
  {"find_replace", (int (*)())_9find_replace, 261, 9, 4, 0, 11, 0},
  {"match_replace", (int (*)())_9match_replace, 262, 9, 4, 0, 13, 0},
  {"binary_search", (int (*)())_9binary_search, 263, 9, 4, 0, 13, 0},
  {"match_all", (int (*)())_9match_all, 264, 9, 3, 0, 13, 0},
  {"rmatch", (int (*)())_9rmatch, 265, 9, 3, 0, 13, 0},
  {"begins", (int (*)())_9begins, 266, 9, 2, 0, 13, 0},
  {"ends", (int (*)())_9ends, 267, 9, 2, 0, 13, 0},
  {"is_in_range", (int (*)())_9is_in_range, 268, 9, 3, 0, 13, 0},
  {"is_in_list", (int (*)())_9is_in_list, 269, 9, 2, 0, 13, 0},
  {"lookup", (int (*)())_9lookup, 270, 9, 4, 0, 13, 0},
  {"vlookup", (int (*)())_9vlookup, 271, 9, 5, 0, 13, 0},
  {"crash", (int (*)())_10crash, 272, 10, 2, 0, 13, 0},
  {"crash_message", (int (*)())_10crash_message, 273, 10, 1, 0, 13, 0},
  {"crash_file", (int (*)())_10crash_file, 274, 10, 1, 0, 13, 0},
  {"warning_file", (int (*)())_10warning_file, 275, 10, 1, 0, 13, 0},
  {"crash_routine", (int (*)())_10crash_routine, 276, 10, 1, 0, 13, 0},
  {"dir", (int (*)())_11dir, 278, 11, 1, 0, 13, 0},
  {"current_dir", (int (*)())_11current_dir, 279, 11, 0, 0, 13, 0},
  {"chdir", (int (*)())_11chdir, 280, 11, 1, 0, 13, 0},
  {"walk_dir", (int (*)())_11walk_dir, 282, 11, 4, 0, 13, 0},
  {"create_directory", (int (*)())_11create_directory, 283, 11, 3, 0, 13, 0},
  {"create_file", (int (*)())_11create_file, 284, 11, 1, 0, 13, 0},
  {"delete_file", (int (*)())_11delete_file, 285, 11, 1, 0, 13, 0},
  {"curdir", (int (*)())_11curdir, 286, 11, 1, 0, 13, 0},
  {"init_curdir", (int (*)())_11init_curdir, 287, 11, 0, 0, 13, 0},
  {"clear_directory", (int (*)())_11clear_directory, 288, 11, 2, 0, 13, 0},
  {"remove_directory", (int (*)())_11remove_directory, 289, 11, 2, 0, 13, 0},
  {"pathinfo", (int (*)())_11pathinfo, 290, 11, 2, 0, 13, 0},
  {"dirname", (int (*)())_11dirname, 291, 11, 2, 0, 13, 0},
  {"pathname", (int (*)())_11pathname, 292, 11, 1, 0, 13, 0},
  {"filename", (int (*)())_11filename, 293, 11, 1, 0, 13, 0},
  {"filebase", (int (*)())_11filebase, 294, 11, 1, 0, 13, 0},
  {"fileext", (int (*)())_11fileext, 295, 11, 1, 0, 13, 0},
  {"driveid", (int (*)())_11driveid, 296, 11, 1, 0, 13, 0},
  {"defaultext", (int (*)())_11defaultext, 297, 11, 2, 0, 13, 0},
  {"absolute_path", (int (*)())_11absolute_path, 298, 11, 1, 0, 13, 0},
  {"case_flagset_type", (int (*)())_11case_flagset_type, 299, 11, 1, 0, 13, 0},
  {"canonical_path", (int (*)())_11canonical_path, 300, 11, 3, 0, 13, 0},
  {"abbreviate_path", (int (*)())_11abbreviate_path, 302, 11, 2, 0, 13, 0},
  {"split_path", (int (*)())_11split_path, 303, 11, 1, 0, 13, 0},
  {"join_path", (int (*)())_11join_path, 304, 11, 1, 0, 13, 0},
  {"file_type", (int (*)())_11file_type, 305, 11, 1, 0, 13, 0},
  {"file_exists", (int (*)())_11file_exists, 306, 11, 1, 0, 13, 0},
  {"file_timestamp", (int (*)())_11file_timestamp, 307, 11, 1, 0, 13, 0},
  {"copy_file", (int (*)())_11copy_file, 308, 11, 3, 0, 13, 0},
  {"rename_file", (int (*)())_11rename_file, 309, 11, 3, 0, 13, 0},
  {"move_file", (int (*)())_11move_file, 311, 11, 3, 0, 13, 0},
  {"file_length", (int (*)())_11file_length, 312, 11, 1, 0, 13, 0},
  {"locate_file", (int (*)())_11locate_file, 313, 11, 3, 0, 13, 0},
  {"disk_metrics", (int (*)())_11disk_metrics, 314, 11, 1, 0, 13, 0},
  {"disk_size", (int (*)())_11disk_size, 315, 11, 1, 0, 13, 0},
  {"count_files", (int (*)())_11count_files, 316, 11, 3, 0, 5, 0},
  {"dir_size", (int (*)())_11dir_size, 317, 11, 2, 0, 13, 0},
  {"temp_file", (int (*)())_11temp_file, 318, 11, 4, 0, 13, 0},
  {"checksum", (int (*)())_11checksum, 319, 11, 4, 0, 13, 0},
  {"datetime", (int (*)())_12datetime, 331, 12, 1, 0, 11, 0},
  {"from_date", (int (*)())_12from_date, 332, 12, 1, 0, 13, 0},
  {"now", (int (*)())_12now, 333, 12, 0, 0, 13, 0},
  {"now_gmt", (int (*)())_12now_gmt, 334, 12, 0, 0, 13, 0},
  {"new", (int (*)())_12new, 335, 12, 6, 0, 11, 0},
  {"new_time", (int (*)())_12new_time, 336, 12, 3, 0, 13, 0},
  {"weeks_day", (int (*)())_12weeks_day, 337, 12, 1, 0, 13, 0},
  {"years_day", (int (*)())_12years_day, 338, 12, 1, 0, 13, 0},
  {"is_leap_year", (int (*)())_12is_leap_year, 339, 12, 1, 0, 13, 0},
  {"days_in_month", (int (*)())_12days_in_month, 340, 12, 1, 0, 13, 0},
  {"days_in_year", (int (*)())_12days_in_year, 341, 12, 1, 0, 13, 0},
  {"to_unix", (int (*)())_12to_unix, 342, 12, 1, 0, 13, 0},
  {"from_unix", (int (*)())_12from_unix, 343, 12, 1, 0, 13, 0},
  {"format", (int (*)())_12format, 344, 12, 2, 0, 11, 0},
  {"parse", (int (*)())_12parse, 345, 12, 3, 0, 11, 0},
  {"add", (int (*)())_12add, 346, 12, 3, 0, 11, 0},
  {"subtract", (int (*)())_12subtract, 347, 12, 3, 0, 13, 0},
  {"diff", (int (*)())_12diff, 348, 12, 2, 0, 13, 0},
  {"open_dll", (int (*)())_13open_dll, 349, 13, 1, 0, 13, 0},
  {"define_c_var", (int (*)())_13define_c_var, 350, 13, 2, 0, 13, 0},
  {"define_c_proc", (int (*)())_13define_c_proc, 351, 13, 3, 0, 13, 0},
  {"define_c_func", (int (*)())_13define_c_func, 352, 13, 4, 0, 13, 0},
  {"call_back", (int (*)())_13call_back, 353, 13, 1, 0, 13, 0},
  {"allocate", (int (*)())_14allocate, 354, 14, 2, 0, 13, 0},
  {"allocate_data", (int (*)())_14allocate_data, 355, 14, 2, 0, 13, 0},
  {"allocate_pointer_array", (int (*)())_14allocate_pointer_array, 356, 14, 2, 0, 13, 0},
  {"allocate_string_pointer_array", (int (*)())_14allocate_string_pointer_array, 357, 14, 2, 0, 13, 0},
  {"allocate_wstring", (int (*)())_14allocate_wstring, 358, 14, 2, 0, 13, 0},
  {"peek_wstring", (int (*)())_14peek_wstring, 359, 14, 1, 0, 13, 0},
  {"poke_string", (int (*)())_14poke_string, 360, 14, 3, 0, 13, 0},
  {"poke_wstring", (int (*)())_14poke_wstring, 361, 14, 3, 0, 13, 0},
  {"is_DEP_supported", (int (*)())_14is_DEP_supported, 362, 14, 0, 0, 13, 0},
  {"is_using_DEP", (int (*)())_14is_using_DEP, 363, 14, 0, 0, 13, 0},
  {"DEP_on", (int (*)())_14DEP_on, 364, 14, 1, 0, 13, 0},
  {"allocate_code", (int (*)())_14allocate_code, 365, 14, 2, 0, 13, 0},
  {"allocate_string", (int (*)())_14allocate_string, 366, 14, 2, 0, 13, 0},
  {"allocate_protect", (int (*)())_14allocate_protect, 367, 14, 3, 0, 13, 0},
  {"free", (int (*)())_14free, 371, 14, 1, 0, 13, 0},
  {"free_pointer_array", (int (*)())_14free_pointer_array, 372, 14, 1, 0, 13, 0},
  {"std_library_address", (int (*)())_14std_library_address, 373, 14, 1, 0, 13, 0},
  {"valid_memory_protection_constant", (int (*)())_14valid_memory_protection_constant, 374, 14, 1, 0, 13, 0},
  {"page_aligned_address", (int (*)())_14page_aligned_address, 375, 14, 1, 0, 13, 0},
  {"valid_memory_protection_constant", (int (*)())_15valid_memory_protection_constant, 376, 15, 1, 0, 11, 0},
  {"test_read", (int (*)())_15test_read, 377, 15, 1, 0, 11, 0},
  {"test_write", (int (*)())_15test_write, 378, 15, 1, 0, 11, 0},
  {"test_exec", (int (*)())_15test_exec, 379, 15, 1, 0, 11, 0},
  {"valid_wordsize", (int (*)())_15valid_wordsize, 380, 15, 1, 0, 11, 0},
  {"positive_int", (int (*)())_16positive_int, 381, 16, 1, 0, 11, 0},
  {"machine_addr", (int (*)())_16machine_addr, 382, 16, 1, 0, 13, 0},
  {"deallocate", (int (*)())_16deallocate, 383, 16, 1, 0, 11, 0},
  {"register_block", (int (*)())_16register_block, 384, 16, 3, 0, 13, 0},
  {"unregister_block", (int (*)())_16unregister_block, 385, 16, 1, 0, 13, 0},
  {"safe_address", (int (*)())_16safe_address, 386, 16, 3, 0, 13, 0},
  {"check_all_blocks", (int (*)())_16check_all_blocks, 387, 16, 0, 0, 13, 0},
  {"prepare_block", (int (*)())_16prepare_block, 388, 16, 3, 0, 11, 0},
  {"bordered_address", (int (*)())_16bordered_address, 389, 16, 1, 0, 11, 0},
  {"dep_works", (int (*)())_16dep_works, 390, 16, 0, 0, 11, 0},
  {"free_code", (int (*)())_16free_code, 391, 16, 3, 0, 13, 0},
  {"Get", (int (*)())_17Get, 402, 17, 0, 0, 5, 0},
  {"Get2", (int (*)())_17Get2, 403, 17, 0, 0, 5, 0},
  {"get", (int (*)())_17get, 405, 17, 3, 0, 11, 0},
  {"value", (int (*)())_17value, 406, 17, 3, 0, 13, 0},
  {"defaulted_value", (int (*)())_17defaulted_value, 407, 17, 3, 0, 13, 0},
  {"get_bytes", (int (*)())_18get_bytes, 408, 18, 2, 0, 13, 0},
  {"get_integer32", (int (*)())_18get_integer32, 409, 18, 1, 0, 13, 0},
  {"get_integer16", (int (*)())_18get_integer16, 410, 18, 1, 0, 13, 0},
  {"put_integer32", (int (*)())_18put_integer32, 411, 18, 2, 0, 13, 0},
  {"put_integer16", (int (*)())_18put_integer16, 412, 18, 2, 0, 13, 0},
  {"get_dstring", (int (*)())_18get_dstring, 413, 18, 2, 0, 13, 0},
  {"file_number", (int (*)())_18file_number, 414, 18, 1, 0, 13, 0},
  {"file_position", (int (*)())_18file_position, 415, 18, 1, 0, 13, 0},
  {"lock_type", (int (*)())_18lock_type, 416, 18, 1, 0, 13, 0},
  {"byte_range", (int (*)())_18byte_range, 417, 18, 1, 0, 13, 0},
  {"seek", (int (*)())_18seek, 418, 18, 2, 0, 13, 0},
  {"where", (int (*)())_18where, 419, 18, 1, 0, 13, 0},
  {"flush", (int (*)())_18flush, 420, 18, 1, 0, 13, 0},
  {"lock_file", (int (*)())_18lock_file, 421, 18, 3, 0, 13, 0},
  {"unlock_file", (int (*)())_18unlock_file, 422, 18, 2, 0, 13, 0},
  {"read_lines", (int (*)())_18read_lines, 423, 18, 1, 0, 13, 0},
  {"process_lines", (int (*)())_18process_lines, 424, 18, 3, 0, 13, 0},
  {"write_lines", (int (*)())_18write_lines, 425, 18, 2, 0, 13, 0},
  {"append_lines", (int (*)())_18append_lines, 426, 18, 2, 0, 13, 0},
  {"read_file", (int (*)())_18read_file, 427, 18, 2, 0, 13, 0},
  {"write_file", (int (*)())_18write_file, 428, 18, 3, 0, 13, 0},
  {"writef", (int (*)())_18writef, 429, 18, 4, 0, 13, 0},
  {"writefln", (int (*)())_18writefln, 430, 18, 4, 0, 13, 0},
  {"abs", (int (*)())_20abs, 432, 20, 1, 0, 13, 0},
  {"sign", (int (*)())_20sign, 433, 20, 1, 0, 13, 0},
  {"larger_of", (int (*)())_20larger_of, 434, 20, 2, 0, 13, 0},
  {"smaller_of", (int (*)())_20smaller_of, 435, 20, 2, 0, 13, 0},
  {"max", (int (*)())_20max, 436, 20, 1, 0, 13, 0},
  {"min", (int (*)())_20min, 437, 20, 1, 0, 13, 0},
  {"ensure_in_range", (int (*)())_20ensure_in_range, 438, 20, 2, 0, 13, 0},
  {"ensure_in_list", (int (*)())_20ensure_in_list, 439, 20, 3, 0, 13, 0},
  {"mod", (int (*)())_20mod, 440, 20, 2, 0, 13, 0},
  {"trunc", (int (*)())_20trunc, 441, 20, 1, 0, 13, 0},
  {"frac", (int (*)())_20frac, 442, 20, 1, 0, 13, 0},
  {"intdiv", (int (*)())_20intdiv, 443, 20, 2, 0, 13, 0},
  {"ceil", (int (*)())_20ceil, 444, 20, 1, 0, 13, 0},
  {"round", (int (*)())_20round, 445, 20, 2, 0, 13, 0},
  {"arccos", (int (*)())_20arccos, 446, 20, 1, 0, 13, 0},
  {"arcsin", (int (*)())_20arcsin, 447, 20, 1, 0, 13, 0},
  {"atan2", (int (*)())_20atan2, 448, 20, 2, 0, 13, 0},
  {"rad2deg", (int (*)())_20rad2deg, 449, 20, 1, 0, 13, 0},
  {"deg2rad", (int (*)())_20deg2rad, 450, 20, 1, 0, 13, 0},
  {"log10", (int (*)())_20log10, 451, 20, 1, 0, 13, 0},
  {"exp", (int (*)())_20exp, 452, 20, 1, 0, 13, 0},
  {"fib", (int (*)())_20fib, 453, 20, 1, 0, 13, 0},
  {"cosh", (int (*)())_20cosh, 454, 20, 1, 0, 13, 0},
  {"sinh", (int (*)())_20sinh, 455, 20, 1, 0, 13, 0},
  {"tanh", (int (*)())_20tanh, 456, 20, 1, 0, 13, 0},
  {"arcsinh", (int (*)())_20arcsinh, 457, 20, 1, 0, 13, 0},
  {"arccosh", (int (*)())_20arccosh, 459, 20, 1, 0, 13, 0},
  {"arctanh", (int (*)())_20arctanh, 461, 20, 1, 0, 13, 0},
  {"sum", (int (*)())_20sum, 462, 20, 1, 0, 11, 0},
  {"product", (int (*)())_20product, 463, 20, 1, 0, 13, 0},
  {"or_all", (int (*)())_20or_all, 464, 20, 1, 0, 13, 0},
  {"shift_bits", (int (*)())_20shift_bits, 465, 20, 2, 0, 13, 0},
  {"rotate_bits", (int (*)())_20rotate_bits, 466, 20, 2, 0, 13, 0},
  {"gcd", (int (*)())_20gcd, 467, 20, 2, 0, 13, 0},
  {"approx", (int (*)())_20approx, 468, 20, 3, 0, 13, 0},
  {"powof2", (int (*)())_20powof2, 469, 20, 1, 0, 13, 0},
  {"is_even", (int (*)())_20is_even, 470, 20, 1, 0, 13, 0},
  {"is_even_obj", (int (*)())_20is_even_obj, 471, 20, 1, 0, 13, 0},
  {"rand_range", (int (*)())_21rand_range, 472, 21, 2, 0, 13, 0},
  {"rnd", (int (*)())_21rnd, 473, 21, 0, 0, 13, 0},
  {"rnd_1", (int (*)())_21rnd_1, 474, 21, 0, 0, 13, 0},
  {"set_rand", (int (*)())_21set_rand, 475, 21, 1, 0, 13, 0},
  {"get_rand", (int (*)())_21get_rand, 476, 21, 0, 0, 13, 0},
  {"chance", (int (*)())_21chance, 477, 21, 2, 0, 13, 0},
  {"roll", (int (*)())_21roll, 478, 21, 2, 0, 13, 0},
  {"sample", (int (*)())_21sample, 479, 21, 3, 0, 13, 0},
  {"binop_ok", (int (*)())_23binop_ok, 480, 23, 2, 0, 13, 0},
  {"fetch", (int (*)())_23fetch, 481, 23, 2, 0, 13, 0},
  {"store", (int (*)())_23store, 482, 23, 3, 0, 13, 0},
  {"valid_index", (int (*)())_23valid_index, 483, 23, 2, 0, 13, 0},
  {"rotate", (int (*)())_23rotate, 484, 23, 4, 0, 13, 0},
  {"columnize", (int (*)())_23columnize, 485, 23, 3, 0, 13, 0},
  {"apply", (int (*)())_23apply, 486, 23, 3, 0, 13, 0},
  {"mapping", (int (*)())_23mapping, 487, 23, 4, 0, 13, 0},
  {"reverse", (int (*)())_23reverse, 488, 23, 3, 0, 13, 0},
  {"shuffle", (int (*)())_23shuffle, 489, 23, 1, 0, 13, 0},
  {"series", (int (*)())_23series, 490, 23, 4, 0, 13, 0},
  {"repeat_pattern", (int (*)())_23repeat_pattern, 491, 23, 2, 0, 13, 0},
  {"pad_head", (int (*)())_23pad_head, 492, 23, 3, 0, 13, 0},
  {"pad_tail", (int (*)())_23pad_tail, 493, 23, 3, 0, 13, 0},
  {"add_item", (int (*)())_23add_item, 494, 23, 3, 0, 13, 0},
  {"remove_item", (int (*)())_23remove_item, 495, 23, 2, 0, 13, 0},
  {"mid", (int (*)())_23mid, 496, 23, 3, 0, 13, 0},
  {"slice", (int (*)())_23slice, 497, 23, 3, 0, 13, 0},
  {"vslice", (int (*)())_23vslice, 498, 23, 3, 0, 13, 0},
  {"patch", (int (*)())_23patch, 499, 23, 4, 0, 13, 0},
  {"remove_all", (int (*)())_23remove_all, 500, 23, 2, 0, 13, 0},
  {"retain_all", (int (*)())_23retain_all, 501, 23, 2, 0, 13, 0},
  {"filter", (int (*)())_23filter, 502, 23, 4, 0, 13, 0},
  {"filter_alpha", (int (*)())_23filter_alpha, 503, 23, 2, 0, 5, 0},
  {"extract", (int (*)())_23extract, 504, 23, 2, 0, 13, 0},
  {"project", (int (*)())_23project, 505, 23, 2, 0, 13, 0},
  {"split", (int (*)())_23split, 506, 23, 4, 0, 11, 0},
  {"split_any", (int (*)())_23split_any, 507, 23, 4, 0, 13, 0},
  {"join", (int (*)())_23join, 508, 23, 2, 0, 13, 0},
  {"breakup", (int (*)())_23breakup, 509, 23, 3, 0, 13, 0},
  {"flatten", (int (*)())_23flatten, 510, 23, 2, 0, 13, 0},
  {"pivot", (int (*)())_23pivot, 511, 23, 2, 0, 13, 0},
  {"build_list", (int (*)())_23build_list, 512, 23, 4, 0, 13, 0},
  {"transform", (int (*)())_23transform, 513, 23, 2, 0, 13, 0},
  {"transmute", (int (*)())_23transmute, 514, 23, 5, 0, 13, 0},
  {"sim_index", (int (*)())_23sim_index, 515, 23, 2, 0, 13, 0},
  {"remove_subseq", (int (*)())_23remove_subseq, 516, 23, 2, 0, 13, 0},
  {"remove_dups", (int (*)())_23remove_dups, 517, 23, 2, 0, 13, 0},
  {"combine", (int (*)())_23combine, 518, 23, 2, 0, 13, 0},
  {"minsize", (int (*)())_23minsize, 519, 23, 3, 0, 13, 0},
  {"sort", (int (*)())_24sort, 520, 24, 2, 0, 13, 0},
  {"custom_sort", (int (*)())_24custom_sort, 521, 24, 4, 0, 13, 0},
  {"column_compare", (int (*)())_24column_compare, 522, 24, 3, 0, 5, 0},
  {"sort_columns", (int (*)())_24sort_columns, 523, 24, 2, 0, 13, 0},
  {"merge", (int (*)())_24merge, 524, 24, 4, 0, 13, 0},
  {"insertion_sort", (int (*)())_24insertion_sort, 525, 24, 4, 0, 13, 0},
  {"is_match", (int (*)())_25is_match, 527, 25, 2, 0, 11, 0},
  {"pretty_print", (int (*)())_26pretty_print, 534, 26, 3, 0, 13, 0},
  {"pretty_sprint", (int (*)())_26pretty_sprint, 535, 26, 2, 0, 13, 0},
  {"deserialize", (int (*)())_27deserialize, 544, 27, 2, 0, 13, 0},
  {"serialize", (int (*)())_27serialize, 545, 27, 1, 0, 13, 0},
  {"dump", (int (*)())_27dump, 546, 27, 2, 0, 13, 0},
  {"load", (int (*)())_27load, 547, 27, 1, 0, 13, 0},
  {"malloc", (int (*)())_28malloc, 548, 28, 2, 0, 11, 0},
  {"free", (int (*)())_28free, 549, 28, 1, 0, 11, 0},
  {"valid", (int (*)())_28valid, 550, 28, 2, 0, 11, 0},
  {"error_string", (int (*)())_29error_string, 552, 29, 1, 0, 13, 0},
  {"keep_newlines", (int (*)())_29keep_newlines, 553, 29, 1, 0, 13, 0},
  {"keep_comments", (int (*)())_29keep_comments, 554, 29, 1, 0, 13, 0},
  {"string_numbers", (int (*)())_29string_numbers, 555, 29, 1, 0, 13, 0},
  {"tokenize_string", (int (*)())_29tokenize_string, 585, 29, 1, 0, 13, 0},
  {"tokenize_file", (int (*)())_29tokenize_file, 586, 29, 1, 0, 13, 0},
  {"show_tokens", (int (*)())_29show_tokens, 587, 29, 2, 0, 13, 0},
  {"encode", (int (*)())_30encode, 588, 30, 2, 0, 11, 0},
  {"decode", (int (*)())_30decode, 589, 30, 1, 0, 11, 0},
  {"show_help", (int (*)())_31show_help, 593, 31, 4, 0, 13, 0},
  {"cmd_parse", (int (*)())_31cmd_parse, 595, 31, 3, 0, 13, 0},
  {"build_commandline", (int (*)())_31build_commandline, 596, 31, 1, 0, 13, 0},
  {"parse_commandline", (int (*)())_31parse_commandline, 597, 31, 1, 0, 13, 0},
  {"has_console", (int (*)())_32has_console, 598, 32, 0, 0, 11, 0},
  {"key_codes", (int (*)())_32key_codes, 599, 32, 1, 0, 13, 0},
  {"set_keycodes", (int (*)())_32set_keycodes, 600, 32, 1, 0, 13, 0},
  {"allow_break", (int (*)())_32allow_break, 601, 32, 1, 0, 11, 0},
  {"check_break", (int (*)())_32check_break, 602, 32, 0, 0, 13, 0},
  {"wait_key", (int (*)())_32wait_key, 603, 32, 0, 0, 13, 0},
  {"any_key", (int (*)())_32any_key, 604, 32, 2, 0, 13, 0},
  {"maybe_any_key", (int (*)())_32maybe_any_key, 605, 32, 2, 0, 13, 0},
  {"prompt_number", (int (*)())_32prompt_number, 606, 32, 2, 0, 13, 0},
  {"prompt_string", (int (*)())_32prompt_string, 607, 32, 1, 0, 13, 0},
  {"positive_int", (int (*)())_32positive_int, 610, 32, 1, 0, 13, 0},
  {"get_screen_char", (int (*)())_32get_screen_char, 611, 32, 3, 0, 13, 0},
  {"put_screen_char", (int (*)())_32put_screen_char, 612, 32, 3, 0, 13, 0},
  {"attr_to_colors", (int (*)())_32attr_to_colors, 613, 32, 1, 0, 13, 0},
  {"colors_to_attr", (int (*)())_32colors_to_attr, 614, 32, 2, 0, 13, 0},
  {"display_text_image", (int (*)())_32display_text_image, 615, 32, 2, 0, 13, 0},
  {"save_text_image", (int (*)())_32save_text_image, 616, 32, 2, 0, 13, 0},
  {"text_rows", (int (*)())_32text_rows, 617, 32, 1, 0, 13, 0},
  {"cursor", (int (*)())_32cursor, 618, 32, 1, 0, 13, 0},
  {"free_console", (int (*)())_32free_console, 619, 32, 0, 0, 13, 0},
  {"display", (int (*)())_32display, 620, 32, 3, 0, 13, 0},
  {"map", (int (*)())_33map, 621, 33, 1, 0, 13, 0},
  {"calc_hash", (int (*)())_33calc_hash, 622, 33, 2, 0, 11, 0},
  {"threshold", (int (*)())_33threshold, 623, 33, 1, 0, 13, 0},
  {"type_of", (int (*)())_33type_of, 624, 33, 1, 0, 13, 0},
  {"rehash", (int (*)())_33rehash, 625, 33, 2, 0, 13, 0},
  {"new", (int (*)())_33new, 626, 33, 1, 0, 11, 0},
  {"new_extra", (int (*)())_33new_extra, 627, 33, 2, 0, 13, 0},
  {"compare", (int (*)())_33compare, 628, 33, 3, 0, 11, 0},
  {"has", (int (*)())_33has, 629, 33, 2, 0, 13, 0},
  {"get", (int (*)())_33get, 630, 33, 3, 0, 11, 0},
  {"nested_get", (int (*)())_33nested_get, 631, 33, 3, 0, 13, 0},
  {"put", (int (*)())_33put, 632, 33, 5, 0, 13, 0},
  {"nested_put", (int (*)())_33nested_put, 633, 33, 5, 0, 13, 0},
  {"remove", (int (*)())_33remove, 634, 33, 2, 0, 11, 0},
  {"clear", (int (*)())_33clear, 635, 33, 1, 0, 11, 0},
  {"size", (int (*)())_33size, 636, 33, 1, 0, 11, 0},
  {"statistics", (int (*)())_33statistics, 637, 33, 1, 0, 13, 0},
  {"keys", (int (*)())_33keys, 638, 33, 2, 0, 13, 0},
  {"values", (int (*)())_33values, 639, 33, 3, 0, 13, 0},
  {"pairs", (int (*)())_33pairs, 640, 33, 2, 0, 13, 0},
  {"optimize", (int (*)())_33optimize, 641, 33, 3, 0, 13, 0},
  {"load_map", (int (*)())_33load_map, 642, 33, 1, 0, 13, 0},
  {"save_map", (int (*)())_33save_map, 643, 33, 3, 0, 13, 0},
  {"copy", (int (*)())_33copy, 644, 33, 3, 0, 13, 0},
  {"new_from_kvpairs", (int (*)())_33new_from_kvpairs, 645, 33, 1, 0, 13, 0},
  {"new_from_string", (int (*)())_33new_from_string, 646, 33, 1, 0, 13, 0},
  {"for_each", (int (*)())_33for_each, 647, 33, 5, 0, 13, 0},
  {"calc_primes", (int (*)())_34calc_primes, 650, 34, 2, 0, 13, 0},
  {"next_prime", (int (*)())_34next_prime, 651, 34, 3, 0, 13, 0},
  {"prime_list", (int (*)())_34prime_list, 652, 34, 1, 0, 13, 0},
  {"small", (int (*)())_35small, 653, 35, 2, 0, 13, 0},
  {"largest", (int (*)())_35largest, 654, 35, 1, 0, 13, 0},
  {"smallest", (int (*)())_35smallest, 655, 35, 1, 0, 13, 0},
  {"range", (int (*)())_35range, 656, 35, 1, 0, 13, 0},
  {"stdev", (int (*)())_35stdev, 658, 35, 3, 0, 13, 0},
  {"avedev", (int (*)())_35avedev, 659, 35, 3, 0, 13, 0},
  {"sum", (int (*)())_35sum, 660, 35, 2, 0, 11, 0},
  {"count", (int (*)())_35count, 661, 35, 2, 0, 13, 0},
  {"average", (int (*)())_35average, 662, 35, 2, 0, 13, 0},
  {"geomean", (int (*)())_35geomean, 663, 35, 2, 0, 13, 0},
  {"harmean", (int (*)())_35harmean, 664, 35, 2, 0, 13, 0},
  {"movavg", (int (*)())_35movavg, 665, 35, 2, 0, 13, 0},
  {"emovavg", (int (*)())_35emovavg, 666, 35, 2, 0, 13, 0},
  {"median", (int (*)())_35median, 667, 35, 2, 0, 13, 0},
  {"raw_frequency", (int (*)())_35raw_frequency, 668, 35, 2, 0, 13, 0},
  {"mode", (int (*)())_35mode, 669, 35, 2, 0, 13, 0},
  {"central_moment", (int (*)())_35central_moment, 670, 35, 4, 0, 13, 0},
  {"sum_central_moments", (int (*)())_35sum_central_moments, 671, 35, 3, 0, 13, 0},
  {"skewness", (int (*)())_35skewness, 672, 35, 2, 0, 13, 0},
  {"kurtosis", (int (*)())_35kurtosis, 673, 35, 2, 0, 13, 0},
  {"color", (int (*)())_36color, 674, 36, 1, 0, 13, 0},
  {"mixture", (int (*)())_36mixture, 675, 36, 1, 0, 13, 0},
  {"video_config", (int (*)())_36video_config, 676, 36, 0, 0, 13, 0},
  {"instance", (int (*)())_37instance, 677, 37, 0, 0, 13, 0},
  {"get_pid", (int (*)())_37get_pid, 678, 37, 0, 0, 13, 0},
  {"uname", (int (*)())_37uname, 679, 37, 0, 0, 13, 0},
  {"is_win_nt", (int (*)())_37is_win_nt, 680, 37, 0, 0, 13, 0},
  {"setenv", (int (*)())_37setenv, 681, 37, 3, 0, 13, 0},
  {"unsetenv", (int (*)())_37unsetenv, 682, 37, 1, 0, 13, 0},
  {"sleep", (int (*)())_37sleep, 683, 37, 1, 0, 13, 0},
  {"db_get_errors", (int (*)())_38db_get_errors, 695, 38, 1, 0, 13, 0},
  {"db_dump", (int (*)())_38db_dump, 696, 38, 2, 0, 13, 0},
  {"check_free_list", (int (*)())_38check_free_list, 697, 38, 0, 0, 13, 0},
  {"db_connect", (int (*)())_38db_connect, 701, 38, 3, 0, 13, 0},
  {"db_create", (int (*)())_38db_create, 702, 38, 4, 0, 13, 0},
  {"db_open", (int (*)())_38db_open, 703, 38, 2, 0, 13, 0},
  {"db_select", (int (*)())_38db_select, 704, 38, 2, 0, 13, 0},
  {"db_close", (int (*)())_38db_close, 705, 38, 0, 0, 13, 0},
  {"db_select_table", (int (*)())_38db_select_table, 707, 38, 1, 0, 13, 0},
  {"db_current_table", (int (*)())_38db_current_table, 708, 38, 0, 0, 13, 0},
  {"db_create_table", (int (*)())_38db_create_table, 709, 38, 2, 0, 13, 0},
  {"db_delete_table", (int (*)())_38db_delete_table, 710, 38, 1, 0, 13, 0},
  {"db_clear_table", (int (*)())_38db_clear_table, 711, 38, 2, 0, 13, 0},
  {"db_rename_table", (int (*)())_38db_rename_table, 712, 38, 2, 0, 13, 0},
  {"db_table_list", (int (*)())_38db_table_list, 713, 38, 0, 0, 13, 0},
  {"db_find_key", (int (*)())_38db_find_key, 715, 38, 2, 0, 13, 0},
  {"db_insert", (int (*)())_38db_insert, 716, 38, 3, 0, 13, 0},
  {"db_delete_record", (int (*)())_38db_delete_record, 717, 38, 2, 0, 13, 0},
  {"db_replace_data", (int (*)())_38db_replace_data, 718, 38, 3, 0, 13, 0},
  {"db_table_size", (int (*)())_38db_table_size, 719, 38, 1, 0, 13, 0},
  {"db_record_data", (int (*)())_38db_record_data, 720, 38, 2, 0, 13, 0},
  {"db_fetch_record", (int (*)())_38db_fetch_record, 721, 38, 2, 0, 13, 0},
  {"db_record_key", (int (*)())_38db_record_key, 722, 38, 2, 0, 13, 0},
  {"db_compress", (int (*)())_38db_compress, 723, 38, 0, 0, 13, 0},
  {"db_current", (int (*)())_38db_current, 724, 38, 0, 0, 13, 0},
  {"db_cache_clear", (int (*)())_38db_cache_clear, 725, 38, 0, 0, 13, 0},
  {"db_set_caching", (int (*)())_38db_set_caching, 726, 38, 1, 0, 13, 0},
  {"db_replace_recid", (int (*)())_38db_replace_recid, 727, 38, 2, 0, 13, 0},
  {"db_record_recid", (int (*)())_38db_record_recid, 728, 38, 1, 0, 13, 0},
  {"db_get_recid", (int (*)())_38db_get_recid, 729, 38, 2, 0, 13, 0},
  {"which_bit", (int (*)())_39which_bit, 730, 39, 1, 0, 13, 0},
  {"flags_to_string", (int (*)())_39flags_to_string, 731, 39, 3, 0, 13, 0},
  {"get_position", (int (*)())_40get_position, 732, 40, 0, 0, 13, 0},
  {"text_color", (int (*)())_40text_color, 733, 40, 1, 0, 13, 0},
  {"bk_color", (int (*)())_40bk_color, 734, 40, 1, 0, 13, 0},
  {"console_colors", (int (*)())_40console_colors, 735, 40, 1, 0, 13, 0},
  {"wrap", (int (*)())_40wrap, 736, 40, 1, 0, 11, 0},
  {"scroll", (int (*)())_40scroll, 737, 40, 3, 0, 13, 0},
  {"graphics_mode", (int (*)())_40graphics_mode, 738, 40, 1, 0, 13, 0},
  {"graphics_point", (int (*)())_41graphics_point, 739, 41, 1, 0, 13, 0},
  {"read_bitmap", (int (*)())_41read_bitmap, 747, 41, 1, 0, 13, 0},
  {"save_bitmap", (int (*)())_41save_bitmap, 756, 41, 2, 0, 13, 0},
  {"set_lang_path", (int (*)())_43set_lang_path, 757, 43, 1, 0, 13, 0},
  {"get_lang_path", (int (*)())_43get_lang_path, 758, 43, 0, 0, 13, 0},
  {"lang_load", (int (*)())_43lang_load, 759, 43, 1, 0, 13, 0},
  {"set_def_lang", (int (*)())_43set_def_lang, 760, 43, 1, 0, 13, 0},
  {"get_def_lang", (int (*)())_43get_def_lang, 761, 43, 0, 0, 13, 0},
  {"translate", (int (*)())_43translate, 762, 43, 4, 0, 13, 0},
  {"trsprintf", (int (*)())_43trsprintf, 763, 43, 3, 0, 13, 0},
  {"set", (int (*)())_43set, 764, 43, 1, 0, 11, 0},
  {"get", (int (*)())_43get, 765, 43, 0, 0, 11, 0},
  {"money", (int (*)())_43money, 766, 43, 1, 0, 13, 0},
  {"number", (int (*)())_43number, 767, 43, 1, 0, 13, 0},
  {"datetime", (int (*)())_43datetime, 769, 43, 2, 0, 11, 0},
  {"get_text", (int (*)())_43get_text, 770, 43, 3, 0, 13, 0},
  {"canonical", (int (*)())_44canonical, 771, 44, 1, 0, 13, 0},
  {"decanonical", (int (*)())_44decanonical, 772, 44, 1, 0, 13, 0},
  {"canon2win", (int (*)())_44canon2win, 773, 44, 1, 0, 13, 0},
  {"process", (int (*)())_46process, 775, 46, 1, 0, 13, 0},
  {"close", (int (*)())_46close, 776, 46, 1, 0, 11, 0},
  {"kill", (int (*)())_46kill, 777, 46, 2, 0, 13, 0},
  {"read", (int (*)())_46read, 779, 46, 2, 0, 13, 0},
  {"write", (int (*)())_46write, 780, 46, 2, 0, 13, 0},
  {"error_no", (int (*)())_46error_no, 782, 46, 0, 0, 13, 0},
  {"create", (int (*)())_46create, 787, 46, 0, 0, 11, 0},
  {"exec", (int (*)())_46exec, 789, 46, 2, 0, 13, 0},
  {"regex", (int (*)())_47regex, 790, 47, 1, 0, 13, 0},
  {"option_spec", (int (*)())_47option_spec, 791, 47, 1, 0, 13, 0},
  {"option_spec_to_string", (int (*)())_47option_spec_to_string, 792, 47, 1, 0, 13, 0},
  {"error_to_string", (int (*)())_47error_to_string, 793, 47, 1, 0, 13, 0},
  {"new", (int (*)())_47new, 794, 47, 2, 0, 11, 0},
  {"error_message", (int (*)())_47error_message, 795, 47, 1, 0, 13, 0},
  {"escape", (int (*)())_47escape, 796, 47, 1, 0, 11, 0},
  {"get_ovector_size", (int (*)())_47get_ovector_size, 797, 47, 2, 0, 11, 0},
  {"find", (int (*)())_47find, 798, 47, 5, 0, 11, 0},
  {"find_all", (int (*)())_47find_all, 799, 47, 5, 0, 11, 0},
  {"has_match", (int (*)())_47has_match, 800, 47, 4, 0, 13, 0},
  {"is_match", (int (*)())_47is_match, 801, 47, 4, 0, 11, 0},
  {"matches", (int (*)())_47matches, 802, 47, 4, 0, 13, 0},
  {"all_matches", (int (*)())_47all_matches, 803, 47, 4, 0, 13, 0},
  {"split", (int (*)())_47split, 804, 47, 4, 0, 11, 0},
  {"split_limit", (int (*)())_47split_limit, 805, 47, 5, 0, 13, 0},
  {"find_replace", (int (*)())_47find_replace, 806, 47, 5, 0, 11, 0},
  {"find_replace_limit", (int (*)())_47find_replace_limit, 807, 47, 6, 0, 13, 0},
  {"find_replace_callback", (int (*)())_47find_replace_callback, 808, 47, 6, 0, 13, 0},
  {"error_code", (int (*)())_48error_code, 809, 48, 0, 0, 13, 0},
  {"socket", (int (*)())_48socket, 810, 48, 1, 0, 13, 0},
  {"delete_socket", (int (*)())_48delete_socket, 811, 48, 1, 0, 5, 0},
  {"create", (int (*)())_48create, 812, 48, 3, 0, 11, 0},
  {"close", (int (*)())_48close, 813, 48, 1, 0, 11, 0},
  {"shutdown", (int (*)())_48shutdown, 814, 48, 2, 0, 13, 0},
  {"select", (int (*)())_48select, 815, 48, 5, 0, 13, 0},
  {"send", (int (*)())_48send, 816, 48, 3, 0, 13, 0},
  {"receive", (int (*)())_48receive, 817, 48, 2, 0, 13, 0},
  {"get_option", (int (*)())_48get_option, 818, 48, 3, 0, 13, 0},
  {"set_option", (int (*)())_48set_option, 819, 48, 4, 0, 13, 0},
  {"connect", (int (*)())_48connect, 820, 48, 3, 0, 13, 0},
  {"bind", (int (*)())_48bind, 821, 48, 3, 0, 13, 0},
  {"listen", (int (*)())_48listen, 822, 48, 2, 0, 13, 0},
  {"accept", (int (*)())_48accept, 823, 48, 1, 0, 13, 0},
  {"send_to", (int (*)())_48send_to, 824, 48, 5, 0, 13, 0},
  {"receive_from", (int (*)())_48receive_from, 825, 48, 2, 0, 13, 0},
  {"service_by_name", (int (*)())_48service_by_name, 826, 48, 2, 0, 13, 0},
  {"service_by_port", (int (*)())_48service_by_port, 827, 48, 2, 0, 13, 0},
  {"info", (int (*)())_48info, 828, 48, 1, 0, 13, 0},
  {"is_inetaddr", (int (*)())_49is_inetaddr, 829, 49, 1, 0, 13, 0},
  {"parse_ip_address", (int (*)())_49parse_ip_address, 830, 49, 2, 0, 13, 0},
  {"parse_url", (int (*)())_49parse_url, 831, 49, 1, 0, 13, 0},
  {"stack", (int (*)())_50stack, 832, 50, 1, 0, 13, 0},
  {"new", (int (*)())_50new, 833, 50, 1, 0, 11, 0},
  {"is_empty", (int (*)())_50is_empty, 834, 50, 1, 0, 13, 0},
  {"size", (int (*)())_50size, 835, 50, 1, 0, 11, 0},
  {"at", (int (*)())_50at, 836, 50, 2, 0, 13, 0},
  {"push", (int (*)())_50push, 837, 50, 2, 0, 13, 0},
  {"top", (int (*)())_50top, 838, 50, 1, 0, 13, 0},
  {"last", (int (*)())_50last, 839, 50, 1, 0, 13, 0},
  {"pop", (int (*)())_50pop, 840, 50, 2, 0, 13, 0},
  {"peek_top", (int (*)())_50peek_top, 841, 50, 2, 0, 13, 0},
  {"peek_end", (int (*)())_50peek_end, 842, 50, 2, 0, 13, 0},
  {"swap", (int (*)())_50swap, 843, 50, 1, 0, 13, 0},
  {"dup", (int (*)())_50dup, 844, 50, 1, 0, 13, 0},
  {"set", (int (*)())_50set, 845, 50, 3, 0, 11, 0},
  {"clear", (int (*)())_50clear, 846, 50, 1, 0, 11, 0},
  {"task_delay", (int (*)())_51task_delay, 847, 51, 1, 0, 13, 0},
  {"iif", (int (*)())_52iif, 848, 52, 3, 0, 13, 0},
  {"iff", (int (*)())_52iff, 849, 52, 3, 0, 13, 0},
  {"host_by_name", (int (*)())_53host_by_name, 850, 53, 1, 0, 13, 0},
  {"host_by_addr", (int (*)())_53host_by_addr, 851, 53, 1, 0, 13, 0},
  {"http_post", (int (*)())_54http_post, 857, 54, 5, 0, 13, 0},
  {"http_get", (int (*)())_54http_get, 858, 54, 4, 0, 13, 0},
  {"parse_querystring", (int (*)())_55parse_querystring, 859, 55, 1, 0, 13, 0},
  {"parse", (int (*)())_55parse, 860, 55, 2, 0, 11, 0},
  {"encode", (int (*)())_55encode, 861, 55, 2, 0, 11, 0},
  {"decode", (int (*)())_55decode, 862, 55, 1, 0, 11, 0},
  {"message_box", (int (*)())_56message_box, 863, 56, 3, 0, 13, 0},
  {"sound", (int (*)())_57sound, 864, 57, 1, 0, 13, 0},
  {"set_return_linked_list", (int (*)())_58set_return_linked_list, 865, 58, 1, 0, 13, 0},
  {"get_return_linked_list", (int (*)())_58get_return_linked_list, 866, 58, 0, 0, 13, 0},
  {"mystring", (int (*)())_58mystring, 867, 58, 1, 0, 13, 0},
  {"myarray", (int (*)())_58myarray, 868, 58, 1, 0, 13, 0},
  {"sequence_to_linked_list", (int (*)())_58sequence_to_linked_list, 869, 58, 1, 0, 13, 0},
  {"free_linked_list", (int (*)())_58free_linked_list, 870, 58, 1, 0, 13, 0},
  {"linked_list_to_sequence", (int (*)())_58linked_list_to_sequence, 871, 58, 1, 0, 13, 0},
  {"allocate", (int (*)())_59allocate, 877, 59, 1, 0, 6, 0},
  {"free", (int (*)())_59free, 878, 59, 1, 0, 6, 0},
  {"allocate_low", (int (*)())_59allocate_low, 879, 59, 1, 0, 6, 0},
  {"free_low", (int (*)())_59free_low, 880, 59, 1, 0, 6, 0},
  {"int_to_bytes", (int (*)())_59int_to_bytes, 881, 59, 1, 0, 6, 0},
  {"bytes_to_int", (int (*)())_59bytes_to_int, 882, 59, 1, 0, 6, 0},
  {"int_to_bits", (int (*)())_59int_to_bits, 883, 59, 2, 0, 6, 0},
  {"bits_to_int", (int (*)())_59bits_to_int, 884, 59, 1, 0, 6, 0},
  {"set_rand", (int (*)())_59set_rand, 885, 59, 1, 0, 6, 0},
  {"crash_message", (int (*)())_59crash_message, 886, 59, 1, 0, 6, 0},
  {"crash_file", (int (*)())_59crash_file, 887, 59, 1, 0, 6, 0},
  {"crash_routine", (int (*)())_59crash_routine, 888, 59, 1, 0, 6, 0},
  {"atom_to_float64", (int (*)())_59atom_to_float64, 889, 59, 1, 0, 6, 0},
  {"atom_to_float32", (int (*)())_59atom_to_float32, 890, 59, 1, 0, 6, 0},
  {"float64_to_atom", (int (*)())_59float64_to_atom, 891, 59, 1, 0, 6, 0},
  {"float32_to_atom", (int (*)())_59float32_to_atom, 892, 59, 1, 0, 6, 0},
  {"allocate_string", (int (*)())_59allocate_string, 893, 59, 1, 0, 6, 0},
  {"register_block", (int (*)())_59register_block, 894, 59, 2, 0, 6, 0},
  {"unregister_block", (int (*)())_59unregister_block, 895, 59, 1, 0, 6, 0},
  {"check_all_blocks", (int (*)())_59check_all_blocks, 896, 59, 0, 0, 6, 0},
  {"", 0, 999999999, 0, 0, 0, 0}
};

unsigned char ** _02;
object _0switches;
struct ns_list _01[] = {
  {"eu", 0, 0, 1},
  {"libeu", 1, 1, 1},
  {"all", 2, 2, 2},
  {"info", 3, 3, 3},
  {"keywords", 4, 20, 4},
  {"syncolor", 5, 21, 5},
  {"text", 6, 22, 6},
  {"types", 7, 23, 7},
  {"convert", 8, 55, 8},
  {"search", 9, 56, 9},
  {"error", 10, 90, 10},
  {"filesys", 11, 96, 11},
  {"datetime", 12, 97, 12},
  {"dll", 13, 98, 13},
  {"machine", 14, 99, 14},
  {"memconst", 15, 100, 15},
  {"memory", 16, 106, 14},
  {"memory", 16, 107, 16},
  {"stdget", 17, 146, 17},
  {"io", 18, 147, 18},
  {"stdhash", 19, 216, 19},
  {"math", 20, 217, 20},
  {"random", 21, 218, 21},
  {"mathcons", 22, 227, 22},
  {"stdseq", 23, 269, 23},
  {"stdsort", 24, 270, 24},
  {"wildcard", 25, 317, 25},
  {"pretty", 26, 363, 26},
  {"serialize", 27, 372, 27},
  {"eumem", 28, 401, 28},
  {"tokenize", 29, 413, 29},
  {"base64", 30, 451, 30},
  {"cmdline", 31, 456, 31},
  {"console", 32, 457, 32},
  {"map", 33, 458, 33},
  {"primes", 34, 459, 34},
  {"stats", 35, 463, 33},
  {"stats", 35, 464, 35},
  {"graphcst", 36, 515, 36},
  {"os", 37, 542, 37},
  {"eds", 38, 565, 38},
  {"flags", 39, 612, 39},
  {"graphics", 40, 616, 40},
  {"image", 41, 625, 41},
  {"lcid", 42, 644, 42},
  {"locale", 43, 645, 43},
  {"dt", 12, 646, 43},
  {"lcid", 42, 647, 43},
  {"lcc", 44, 648, 43},
  {"localconv", 44, 649, 44},
  {"pipeio", 46, 678, 46},
  {"regex", 47, 697, 47},
  {"flags", 39, 698, 47},
  {"sockets", 48, 729, 48},
  {"common", 49, 730, 49},
  {"seq", 23, 731, 49},
  {"stack", 50, 757, 50},
  {"task", 51, 778, 51},
  {"utils", 52, 783, 52},
  {"dns", 53, 787, 53},
  {"http", 54, 790, 54},
  {"sock", 48, 791, 54},
  {"url", 55, 792, 54},
  {"url", 55, 793, 55},
  {"msgbox", 56, 808, 56},
  {"sound", 57, 810, 57},
  {"list", 58, 815, 58},
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern unsigned char *string_ptr;
    extern object decompress(unsigned int c);
    extern double sqrt();
    setran(); /* initialize random generator seeds */
    _13488 = NewString("/usr/share/euphoria/include/");
    _13487 = NewString("/home/owner/euphoria/euwrap_ubuntu32/libeu");
    _13486 = NewString("/usr/share/euphoria/include");
    _5 = NewString("");
    _13100 = NewDouble((double)-2.1474836480000000e+09);
    _13099 = NewDouble((double)2.1474836480000000e+09);
    _13105 = NewDouble((double)2.1474836470000000e+09);
    _13102 = NewDouble((double)4.2949672950000000e+09);
    _13113 = NewDouble((double)3.4896609280000000e+09);
    _13112 = NewDouble((double)2.9527900160000000e+09);
    _13111 = NewDouble((double)2.6843545600000000e+09);
    _13110 = NewDouble((double)2.4159191040000000e+09);
    _13109 = NewDouble((double)4.0265318400000000e+09);
    _13016 = NewString("MessageBeep");
    _12997 = NewString("user32.dll");
    _13001 = NewString("couldn't find GetActiveWindow\n");
    _13000 = NewString("GetActiveWindow");
    _12999 = NewString("couldn't find MessageBoxA\n");
    _12998 = NewString("MessageBoxA");
    _12832 = NewString("\r\n");
    _12982 = NewString("GET");
    _12968 = NewString("Content-Length: %d\r\n");
    _12963 = NewString("Content-Type: %s\r\n");
    _12959 = NewString("; boundary=");
    _12939 = NewString("POST");
    _12929 = NewString("content-length");
    _12922 = NewString(": ");
    _12631 = NewString(" ");
    _12910 = NewString("\r\n\r\n");
    _12894 = NewString("top");
    _12867 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
    _12834 = NewString("--");
    _12865 = NewString("\r\n--");
    _12856 = NewString("Content-Transfer-Encoding: base64\r\n");
    _12855 = NewString("\x07\x0D");
    string_ptr = "\xFE\x02\x02\x03";
	_12854 = decompress( 0 );
    _12849 = NewString("Content-Type: ");
    _12846 = NewString("\"\r\n");
    _12844 = NewString("; filename=\"");
    _12839 = NewString("\"");
    _12837 = NewString("Content-Disposition: form-data; name=\"");
    _12824 = NewString("=");
    _12821 = NewString("&");
    _12815 = NewString("Connection: close\r\n");
    _12809 = NewString("%s: %s\r\n");
    _12807 = NewString("Connection");
    _12804 = NewString("User-Agent");
    _12797 = NewString("%s %s HTTP/1.0\r\nHost: %s:%d\r\n");
    _12794 = NewString("%s %s HTTP/1.0\r\nHost: %s\r\n");
    _12790 = NewString("?");
    _12168 = NewString("/");
    _12779 = NewString("http");
    _12774 = NewString("multipart/form-data");
    _12773 = NewString("application/x-www-form-urlencoded");
    _12763 = NewString("User-Agent: Euphoria-HTTP/%d.%d\r\n");
    _12622 = NewString("#");
    _12740 = NewString("#0");
    _12716 = NewString("%");
    _12702 = NewString("+");
    _12701 = NewString("0123456789ABCDEF");
    _12700 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234567890");
    _12685 = NewString("parse_done");
    _12692 = NewString("parse_query_string");
    _12649 = NewString("parse_path");
    _12652 = NewString("parse_domain");
    _12621 = NewString("\x07\x49\x55\x69\x6B");
    _12620 = NewString("%+=&;");
    _12607 = NewDouble((double)4.2781900800000000e+09);
    _12600 = NewDouble((double)1.0000000000000000e-02);
    _12590 = NewString("stack index (%d) out of bounds for set()");
    _12573 = NewString("dup() needs at least one item in the stack");
    _12558 = NewString("swap() needs at least 2 items in the stack");
    _12548 = NewString("stack idx (%d) out of bounds in peek_end()");
    _12547 = NewString("stack is empty, cannot peek_end");
    _12533 = NewString("stack idx (%d) out of bounds in peek_top()");
    _12532 = NewString("stack is empty, cannot peek_top");
    _12510 = NewString("stack idx (%d) out of bounds in pop()");
    _12509 = NewString("stack is empty, cannot pop");
    _12497 = NewString("stack is empty so there is no last()");
    _12488 = NewString("stack is empty so there is no top()");
    _12480 = NewString("Internal error in stack.e: Stack %d has invalid stack type %d");
    _12469 = NewString("\x07\x28");
    _12468 = NewString("\x01\x02");
    _12464 = NewString("stack index (%d) out of bounds for at()");
    _12438 = NewString("\x01\x02");
    _12426 = NewString("Eu:StdStack");
    _12361 = NewString("delete_socket");
    _12143 = NewString("(mailto):(([^@]+)@([^?]+))(\\?.*)?");
    _12141 = NewString("(http|https|ftp|ftps|gopher|gophers)://([^/]+)(/[^?]+)?(\\?.*)?");
    _12139 = NewString("^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])(\\:[0-9]+)?$");
    _11966 = NewString(".\\+*?[^]$(){}=!<>|:-");
    _11958 = NewString("Unknown Error");
    _11525 = NewString("%d");
    _11938 = NewString("ERROR_BADNEWLINE");
    _11936 = NewString("ERROR_NULLWSLIMIT");
    _11934 = NewString("ERROR_RECURSIONLIMIT");
    _11932 = NewString("ERROR_DFA_RECURSE");
    _11930 = NewString("ERROR_DFA_WSSIZE");
    _11928 = NewString("ERROR_DFA_UMLIMIT");
    _11926 = NewString("ERROR_DFA_UCOND");
    _11924 = NewString("ERROR_DFA_UITEM");
    _11922 = NewString("ERROR_BADCOUNT");
    _11920 = NewString("ERROR_INTERNAL");
    _11918 = NewString("ERROR_BADPARTIAL");
    _11916 = NewString("ERROR_PARTIAL");
    _11914 = NewString("ERROR_BADUTF8_OFFSET");
    _11912 = NewString("ERROR_BADUTF8");
    _11910 = NewString("ERROR_CALLOUT");
    _11908 = NewString("ERROR_MATCHLIMIT");
    _11906 = NewString("ERROR_NOSUBSTRING");
    _11904 = NewString("ERROR_NOMEMORY");
    _11901 = NewString("ERROR_UNKNOWN_OPCODE/NODE");
    _11899 = NewString("ERROR_BADMAGIC");
    _11897 = NewString("ERROR_BADOPTION");
    _11895 = NewString("ERROR_NULL");
    _11893 = NewString("ERROR_NOMATCH");
    _11874 = NewString("STRING_OFFSETS");
    _11872 = NewString("BSR_UNICODE");
    _11870 = NewString("BSR_ANYCRLF");
    _11868 = NewString("NEWLINE_ANYCRLF");
    _11866 = NewString("NEWLINE_ANY");
    _11864 = NewString("NEWLINE_CRLF");
    _11862 = NewString("NEWLINE_LF");
    _11860 = NewString("NEWLINE_CR");
    _11858 = NewString("DUPNAMES");
    _11856 = NewString("FIRSTLINE");
    _11854 = NewString("DFA_RESTART");
    _11852 = NewString("DFA_SHORTEST");
    _11850 = NewString("PARTIAL");
    _11848 = NewString("AUTO_CALLOUT");
    _11846 = NewString("NO_UTF8_CHECK");
    _11844 = NewString("NO_AUTO_CAPTURE");
    _11842 = NewString("UTF8");
    _11840 = NewString("NOTEMPTY");
    _11838 = NewString("UNGREEDY");
    _11836 = NewString("NOTEOL");
    _11834 = NewString("NOTBOL");
    _11832 = NewString("EXTRA");
    _11830 = NewString("DOLLAR_ENDONLY");
    _11828 = NewString("ANCHORED");
    _11826 = NewString("EXTENDED");
    _11824 = NewString("DOTALL");
    _11822 = NewString("MULTILINE");
    _11820 = NewString("CASELESS");
    _11818 = NewString("DEFAULT");
    _11810 = NewString("-c");
    _11809 = NewString("/bin/sh");
    _11697 = NewString("Errno = %d");
    _11662 = NewString("errno");
    _11659 = NewString("signal");
    _11656 = NewString("execv");
    _11654 = NewString("fork");
    _11651 = NewString("kill");
    _11648 = NewString("dup2");
    _11645 = NewString("close");
    _11642 = NewString("write");
    _11639 = NewString("read");
    _11636 = NewString("pipe");
    _11483 = NewString("libc.dylib");
    _11482 = NewString("libc.so");
    _11633 = NewString("CreateProcessA");
    _11632 = NewString("SetHandleInformation");
    _11631 = NewString("GetStdHandle");
    _11630 = NewString("GetLastError");
    _11629 = NewString("TerminateProcess");
    _11628 = NewString("CloseHandle");
    _11627 = NewString("WriteFile");
    _11626 = NewString("ReadFile");
    _11625 = NewString("CreatePipe");
    _11624 = NewString("kernel32.dll");
    _11594 = NewString("1");
    _11589 = NewString(".edb");
    _11587 = NewString("_");
    _11580 = NewString("teksto");
    _11539 = NewString("1234567890");
    _11526 = NewString("%.15f");
    _11523 = NewString("[,,]");
    _11518 = NewString("%!n");
    _11516 = NewString("%!.0n");
    _11510 = NewString("$[,,.2]");
    _11508 = NewString("%.8f");
    _11503 = NewString("%n");
    _11473 = NewString("strftime");
    _11472 = NewString("setlocale");
    _11475 = NewString("strfmon");
    _11471 = NewString("GetNumberFormatA");
    _11470 = NewString("GetCurrencyFormatA");
    _11469 = NewString("KERNEL32.DLL");
    _11468 = NewString("MSVCRT.DLL");
    _11457 = NewString("__");
    _11381 = NewString("lng");
    _11130 = NewString("C");
    _11129 = NewString("zu_ZA");
    _11128 = NewString("yo_NG");
    _11127 = NewString("ii_CN");
    _11126 = NewString("sah_RU");
    _11125 = NewString("xh_ZA");
    _11124 = NewString("wo_SN");
    _11123 = NewString("cy_GB");
    _11122 = NewString("vi_VN");
    _11121 = NewString("uz_Latn_UZ");
    _11120 = NewString("uz_Cyrl_UZ");
    _11119 = NewString("ur_PK");
    _11118 = NewString("tr_IN");
    _11117 = NewString("wen_DE");
    _11116 = NewString("uk_UA");
    _11115 = NewString("ug_CN");
    _11114 = NewString("tk_TM");
    _11113 = NewString("tr_TR");
    _11112 = NewString("bo_CN");
    _11111 = NewString("bo_BT");
    _11110 = NewString("th_TH");
    _11109 = NewString("te_IN");
    _11108 = NewString("tt_RU");
    _11107 = NewString("ta_IN");
    _11106 = NewString("tmz_Latn_DZ");
    _11105 = NewString("tg_Cyrl_TJ");
    _11104 = NewString("syr_SY");
    _11103 = NewString("sv_SE");
    _11102 = NewString("sv_FI");
    _11101 = NewString("sw_KE");
    _11100 = NewString("es_VE");
    _11099 = NewString("es_UY");
    _11098 = NewString("es_US");
    _11097 = NewString("es_ES_tradnl");
    _11096 = NewString("es_ES");
    _11095 = NewString("es_PR");
    _11094 = NewString("es_PE");
    _11093 = NewString("es_PY");
    _11092 = NewString("es_PA");
    _11091 = NewString("es_NI");
    _11090 = NewString("es_MX");
    _11089 = NewString("es_HN");
    _11088 = NewString("es_GT");
    _11087 = NewString("es_SV");
    _11086 = NewString("es_EC");
    _11085 = NewString("es_DO");
    _11084 = NewString("es_CR");
    _11083 = NewString("es_CO");
    _11082 = NewString("es_CL");
    _11081 = NewString("es_BO");
    _11080 = NewString("es_AR");
    _11079 = NewString("sl_SI");
    _11078 = NewString("sk_SK");
    _11077 = NewString("si_LK");
    _11076 = NewString("tn_ZA");
    _11075 = NewString("ns_ZA");
    _11074 = NewString("sr_Latn_CS");
    _11073 = NewString("sr_Cyrl_CS");
    _11072 = NewString("sr_Latn_BA");
    _11071 = NewString("sr_Cyrl_BA");
    _11070 = NewString("sa_IN");
    _11069 = NewString("sma_SE");
    _11068 = NewString("sma_NO");
    _11067 = NewString("sms_FI");
    _11066 = NewString("se_SE");
    _11065 = NewString("se_NO");
    _11064 = NewString("se_FI");
    _11063 = NewString("smj_SE");
    _11062 = NewString("smj_NO");
    _11061 = NewString("smn_FI");
    _11060 = NewString("ru_RU");
    _11059 = NewString("rm_CH");
    _11058 = NewString("ro_RO");
    _11057 = NewString("quz_PE");
    _11056 = NewString("quz_EC");
    _11055 = NewString("quz_BO");
    _11054 = NewString("pa_IN");
    _11053 = NewString("pt_PT");
    _11052 = NewString("pt_BR");
    _11051 = NewString("pl_PL");
    _11050 = NewString("fa_IR");
    _11049 = NewString("ps_AF");
    _11048 = NewString("or_IN");
    _11047 = NewString("oc_FR");
    _11046 = NewString("nn_NO");
    _11045 = NewString("nb_NO");
    _11044 = NewString("ne_NP");
    _11043 = NewString("ne_IN");
    _11042 = NewString("mn_Mong_CN");
    _11041 = NewString("mn_Cyrl_MN");
    _11040 = NewString("moh_CA");
    _11039 = NewString("mr_IN");
    _11038 = NewString("arn_CL");
    _11037 = NewString("mi_NZ");
    _11036 = NewString("mt_MT");
    _11035 = NewString("ml_IN");
    _11034 = NewString("ms_MY");
    _11033 = NewString("ms_BN");
    _11032 = NewString("mk_MK");
    _11031 = NewString("lb_LU");
    _11030 = NewString("dsb_DE");
    _11029 = NewString("lt_LT");
    _11028 = NewString("lv_LV");
    _11027 = NewString("lo_LA");
    _11026 = NewString("ky_KG");
    _11025 = NewString("ko_KR");
    _11024 = NewString("kok_IN");
    _11023 = NewString("rw_RW");
    _11022 = NewString("qut_GT");
    _11021 = NewString("kh_KH");
    _11020 = NewString("kk_KZ");
    _11019 = NewString("kn_IN");
    _11018 = NewString("ja_JP");
    _11017 = NewString("it_CH");
    _11016 = NewString("it_IT");
    _11015 = NewString("ga_IE");
    _11014 = NewString("iu_Cans_CA");
    _11013 = NewString("iu_Latn_CA");
    _11012 = NewString("id_ID");
    _11011 = NewString("ig_NG");
    _11010 = NewString("is_IS");
    _11009 = NewString("hu_HU");
    _11008 = NewString("hi_IN");
    _11007 = NewString("he_IL");
    _11006 = NewString("ha_Latn_NG");
    _11005 = NewString("gu_IN");
    _11004 = NewString("kl_GL");
    _11003 = NewString("el_GR");
    _11002 = NewString("de_CH");
    _11001 = NewString("de_LU");
    _11000 = NewString("de_LI");
    _10999 = NewString("de_DE");
    _10998 = NewString("de_AT");
    _10997 = NewString("ka_GE");
    _10996 = NewString("gl_ES");
    _10995 = NewString("fy_NL");
    _10994 = NewString("fr_CH");
    _10993 = NewString("fr_MC");
    _10992 = NewString("fr_LU");
    _10991 = NewString("fr_FR");
    _10990 = NewString("fr_CA");
    _10989 = NewString("fr_BE");
    _10988 = NewString("fi_FI");
    _10987 = NewString("fil_PH");
    _10986 = NewString("fo_FO");
    _10985 = NewString("et_EE");
    _10984 = NewString("en_ZW");
    _10983 = NewString("en_US");
    _10982 = NewString("en_GB");
    _10981 = NewString("en_TT");
    _10980 = NewString("en_ZA");
    _10979 = NewString("en_SG");
    _10978 = NewString("en_PH");
    _10977 = NewString("en_NZ");
    _10976 = NewString("en_MY");
    _10975 = NewString("en_JM");
    _10974 = NewString("en_IE");
    _10973 = NewString("en_IN");
    _10972 = NewString("en_029");
    _10971 = NewString("en_CA");
    _10970 = NewString("en_BZ");
    _10969 = NewString("en_AU");
    _10968 = NewString("nl_NL");
    _10967 = NewString("nl_BE");
    _10966 = NewString("dv_MV");
    _10965 = NewString("prs_AF");
    _10964 = NewString("da_DK");
    _10963 = NewString("cs_CZ");
    _10962 = NewString("hr_HR");
    _10961 = NewString("hr_BA");
    _11360 = NewString("co_FR");
    _10960 = NewString("zh_TW");
    _10959 = NewString("zh_SG");
    _10958 = NewString("zh_CN");
    _10957 = NewString("zh_MO");
    _10956 = NewString("zh_HK");
    _10955 = NewString("ca_ES");
    _10954 = NewString("bg_BG");
    _10953 = NewString("br_FR");
    _10952 = NewString("bs_Latn_BA");
    _10951 = NewString("bs_Cyrl_BA");
    _10950 = NewString("bn_IN");
    _10949 = NewString("be_BY");
    _10948 = NewString("eu_ES");
    _10947 = NewString("ba_RU");
    _10946 = NewString("az_Latn_AZ");
    _10945 = NewString("az_Cyrl_AZ");
    _10944 = NewString("as_IN");
    _10943 = NewString("hy_AM");
    _10942 = NewString("ar_YE");
    _10941 = NewString("ar_AE");
    _10940 = NewString("ar_TN");
    _10939 = NewString("ar_SY");
    _10938 = NewString("ar_SA");
    _10937 = NewString("ar_QA");
    _10936 = NewString("ar_OM");
    _10935 = NewString("ar_MA");
    _10934 = NewString("ar_LY");
    _10933 = NewString("ar_LB");
    _10932 = NewString("ar_KW");
    _10931 = NewString("ar_JO");
    _10930 = NewString("ar_IQ");
    _10929 = NewString("ar_EG");
    _10928 = NewString("ar_BH");
    _10927 = NewString("ar_DZ");
    _10926 = NewString("am_ET");
    _10925 = NewString("gsw_FR");
    _10924 = NewString("sq_AL");
    _10923 = NewString("af_ZA");
    _11358 = NewString("Ukrainian_Ukraine");
    _11357 = NewString("Swedish_Sweden");
    _11347 = NewString("Estonian_Estonia");
    _11356 = NewString("Spanish_Spain");
    _11355 = NewString("Slovak_Slovakia");
    _11354 = NewString("Serbian (Cyrillic)_Serbia");
    _11353 = NewString("Russian_Russia");
    _11352 = NewString("Romanian_Romania");
    _11351 = NewString("Italian_Italy");
    _11350 = NewString("Hungarian_Hungary");
    _11349 = NewString("French_France");
    _11348 = NewString("Finnish_Finland");
    _11346 = NewString("English_United States");
    _11345 = NewString("English_Australia");
    _11344 = NewString("Danish_Denmark");
    _11343 = NewString("Catalan_Spain");
    _11342 = NewString("Belarusian_Belarus");
    _11341 = NewString("Basque_Spain");
    _11340 = NewString("Afrikaans_South Africa");
    _11338 = NewString("zu-ZA");
    _11337 = NewString("yo-NG");
    _11336 = NewString("ii-CN");
    _11335 = NewString("sah-RU");
    _11334 = NewString("xh-ZA");
    _11333 = NewString("wo-SN");
    _11332 = NewString("cy-GB");
    _11331 = NewString("vi-VN");
    _11330 = NewString("uz-Latn-UZ");
    _11329 = NewString("uz-Cyrl-UZ");
    _11328 = NewString("ur-PK");
    _11327 = NewString("tr-IN");
    _11326 = NewString("wen-DE");
    _11325 = NewString("uk-UA");
    _11324 = NewString("ug-CN");
    _11323 = NewString("tk-TM");
    _11322 = NewString("tr-TR");
    _11321 = NewString("bo-CN");
    _11320 = NewString("bo-BT");
    _11319 = NewString("th-TH");
    _11318 = NewString("te-IN");
    _11317 = NewString("tt-RU");
    _11316 = NewString("ta-IN");
    _11315 = NewString("tmz-Latn-DZ");
    _11314 = NewString("tg-Cyrl-TJ");
    _11313 = NewString("syr-SY");
    _11312 = NewString("sv-SE");
    _11311 = NewString("sv-FI");
    _11310 = NewString("sw-KE");
    _11309 = NewString("es-VE");
    _11308 = NewString("es-UY");
    _11307 = NewString("es-US");
    _11306 = NewString("es-ES_tradnl");
    _11305 = NewString("es-ES");
    _11304 = NewString("es-PR");
    _11303 = NewString("es-PE");
    _11302 = NewString("es-PY");
    _11301 = NewString("es-PA");
    _11300 = NewString("es-NI");
    _11299 = NewString("es-MX");
    _11298 = NewString("es-HN");
    _11297 = NewString("es-GT");
    _11296 = NewString("es-SV");
    _11295 = NewString("es-EC");
    _11294 = NewString("es-DO");
    _11293 = NewString("es-CR");
    _11292 = NewString("es-CO");
    _11291 = NewString("es-CL");
    _11290 = NewString("es-BO");
    _11289 = NewString("es-AR");
    _11288 = NewString("sl-SI");
    _11287 = NewString("sk-SK");
    _11286 = NewString("si-LK");
    _11285 = NewString("tn-ZA");
    _11284 = NewString("ns-ZA");
    _11283 = NewString("sr-Latn-CS");
    _11282 = NewString("sr-Cyrl-CS");
    _11281 = NewString("sr-Latn-BA");
    _11280 = NewString("sr-Cyrl-BA");
    _11279 = NewString("sa-IN");
    _11278 = NewString("sma-SE");
    _11277 = NewString("sma-NO");
    _11276 = NewString("sms-FI");
    _11275 = NewString("se-SE");
    _11274 = NewString("se-NO");
    _11273 = NewString("se-FI");
    _11272 = NewString("smj-SE");
    _11271 = NewString("smj-NO");
    _11270 = NewString("smn-FI");
    _11269 = NewString("ru-RU");
    _11268 = NewString("rm-CH");
    _11267 = NewString("ro-RO");
    _11266 = NewString("quz-PE");
    _11265 = NewString("quz-EC");
    _11264 = NewString("quz-BO");
    _11263 = NewString("pa-IN");
    _11262 = NewString("pt-PT");
    _11261 = NewString("pt-BR");
    _11260 = NewString("pl-PL");
    _11259 = NewString("fa-IR");
    _11258 = NewString("ps-AF");
    _11257 = NewString("or-IN");
    _11256 = NewString("oc-FR");
    _11255 = NewString("nn-NO");
    _11254 = NewString("nb-NO");
    _11253 = NewString("ne-NP");
    _11252 = NewString("ne-IN");
    _11251 = NewString("mn-Mong-CN");
    _11250 = NewString("mn-Cyrl-MN");
    _11249 = NewString("moh-CA");
    _11248 = NewString("mr-IN");
    _11247 = NewString("arn-CL");
    _11246 = NewString("mi-NZ");
    _11245 = NewString("mt-MT");
    _11244 = NewString("ml-IN");
    _11243 = NewString("ms-MY");
    _11242 = NewString("ms-BN");
    _11241 = NewString("mk-MK");
    _11240 = NewString("lb-LU");
    _11239 = NewString("dsb-DE");
    _11238 = NewString("lt-LT");
    _11237 = NewString("lv-LV");
    _11236 = NewString("lo-LA");
    _11235 = NewString("ky-KG");
    _11234 = NewString("ko-KR");
    _11233 = NewString("kok-IN");
    _11232 = NewString("rw-RW");
    _11231 = NewString("qut-GT");
    _11230 = NewString("kh-KH");
    _11229 = NewString("kk-KZ");
    _11228 = NewString("kn-IN");
    _11227 = NewString("ja-JP");
    _11226 = NewString("it-CH");
    _11225 = NewString("it-IT");
    _11224 = NewString("ga-IE");
    _11223 = NewString("iu-Cans-CA");
    _11222 = NewString("iu-Latn-CA");
    _11221 = NewString("id-ID");
    _11220 = NewString("ig-NG");
    _11219 = NewString("is-IS");
    _11218 = NewString("hu-HU");
    _11217 = NewString("hi-IN");
    _11216 = NewString("he-IL");
    _11215 = NewString("ha-Latn-NG");
    _11214 = NewString("gu-IN");
    _11213 = NewString("kl-GL");
    _11212 = NewString("el-GR");
    _11211 = NewString("de-CH");
    _11210 = NewString("de-LU");
    _11209 = NewString("de-LI");
    _11208 = NewString("de-DE");
    _11207 = NewString("de-AT");
    _11206 = NewString("ka-GE");
    _11205 = NewString("gl-ES");
    _11204 = NewString("fy-NL");
    _11203 = NewString("fr-CH");
    _11202 = NewString("fr-MC");
    _11201 = NewString("fr-LU");
    _11200 = NewString("fr-FR");
    _11199 = NewString("fr-CA");
    _11198 = NewString("fr-BE");
    _11197 = NewString("fi-FI");
    _11196 = NewString("fil-PH");
    _11195 = NewString("fo-FO");
    _11194 = NewString("et-EE");
    _11193 = NewString("en-ZW");
    _11192 = NewString("en-US");
    _11191 = NewString("en-GB");
    _11190 = NewString("en-TT");
    _11189 = NewString("en-ZA");
    _11188 = NewString("en-SG");
    _11187 = NewString("en-PH");
    _11186 = NewString("en-NZ");
    _11185 = NewString("en-MY");
    _11184 = NewString("en-JM");
    _11183 = NewString("en-IE");
    _11182 = NewString("en-IN");
    _11181 = NewString("en-029");
    _11180 = NewString("en-CA");
    _11179 = NewString("en-BZ");
    _11178 = NewString("en-AU");
    _11177 = NewString("nl-NL");
    _11176 = NewString("nl-BE");
    _11175 = NewString("dv-MV");
    _11174 = NewString("prs-AF");
    _11173 = NewString("da-DK");
    _11172 = NewString("cs-CZ");
    _11171 = NewString("hr-HR");
    _11170 = NewString("hr-BA");
    _11169 = NewString("co-FR");
    _11168 = NewString("zh-TW");
    _11167 = NewString("zh-SG");
    _11166 = NewString("zh-CN");
    _11165 = NewString("zh-MO");
    _11164 = NewString("zh-HK");
    _11163 = NewString("ca-ES");
    _11162 = NewString("bg-BG");
    _11161 = NewString("br-FR");
    _11160 = NewString("bs-Latn-BA");
    _11159 = NewString("bs-Cyrl-BA");
    _11158 = NewString("bn-IN");
    _11157 = NewString("be-BY");
    _11156 = NewString("eu-ES");
    _11155 = NewString("ba-RU");
    _11154 = NewString("az-Latn-AZ");
    _11153 = NewString("az-Cyrl-AZ");
    _11152 = NewString("as-IN");
    _11151 = NewString("hy-AM");
    _11150 = NewString("ar-YE");
    _11149 = NewString("ar-AE");
    _11148 = NewString("ar-TN");
    _11147 = NewString("ar-SY");
    _11146 = NewString("ar-SA");
    _11145 = NewString("ar-QA");
    _11144 = NewString("ar-OM");
    _11143 = NewString("ar-MA");
    _11142 = NewString("ar-LY");
    _11141 = NewString("ar-LB");
    _11140 = NewString("ar-KW");
    _11139 = NewString("ar-JO");
    _11138 = NewString("ar-IQ");
    _11137 = NewString("ar-EG");
    _11136 = NewString("ar-BH");
    _11135 = NewString("ar-DZ");
    _11134 = NewString("am-ET");
    _11133 = NewString("gsw-FR");
    _11132 = NewString("sq-AL");
    _11131 = NewString("af-ZA");
    _1325 = NewString("wb");
    _10663 = NewString("BM");
    _1284 = NewString("rb");
    _8695 = NewString("?");
    _10435 = NewDouble((double)2.1474836480000000e+09);
    _10434 = NewDouble((double)1.0737418240000000e+09);
    _10397 = NewString("db_get_recid");
    _10093 = NewString("no table selected");
    _10089 = NewString("invalid table name given");
    _10324 = NewString("db_compress");
    _10365 = NewString("couldn't insert into new database");
    _1217 = NewString("r");
    _10323 = NewString("no current database");
    _10311 = NewString("db_record_key");
    _10215 = NewString("bad record number");
    _10290 = NewString("db_record_data");
    _10281 = NewString("db_table_size");
    _10267 = NewString("db_replace_data");
    _10207 = NewString("db_delete_record");
    _10158 = NewDouble((double)1.5000000000000000e+00);
    _10090 = NewString("db_find_key");
    _10059 = NewString("db_rename_table");
    _10063 = NewString("target table name already exists");
    _10058 = NewString("source table doesn't exist");
    _9811 = NewString("edb");
    _9836 = NewString("ub");
    _9808 = NewString("\x05\x0A");
    _9794 = NewString("\x07\x1B\x2F");
    string_ptr = "\xFE\x03\xFE\x0B\x6E\x71\x65\x6D\x61\x6F\x67\x76\x6A\x71\x66"
"\xFE\x0B\x6B\x70\x6B\x76\x61\x76\x63\x64\x6E\x67\x75\xFE\x09"
"\x6B\x70\x6B\x76\x61\x68\x74\x67\x67";
	_9793 = decompress( 0 );
    _9651 = NewString("bad size in front of free block");
    _9647 = NewString("block size too big");
    _9644 = NewString("bad block address");
    _9638 = NewString("free list space is bad");
    _9632 = NewString("bad free list pointer");
    _9629 = NewString("free count is too high");
    _9622 = NewString("No free blocks available.\n");
    _9620 = NewString("%08x: %6d bytes\n");
    _9616 = NewString(" [#%08x]:");
    _9615 = NewString("Number of Free blocks: %d ");
    _9611 = NewString("[free blocks:#%08x]\n");
    _9609 = NewString("\nblock #%d (empty)\n\n");
    _9556 = NewString("\n\n");
    _9608 = NewString("\x02\x02\x09");
    _9607 = NewString("  data: ");
    _9604 = NewString("[data %d:#%08x]\n");
    _9603 = NewString("\x02\x02\x08");
    _9602 = NewString("  key: ");
    _9598 = NewString("[key %d:#%08x]\n");
    _9589 = NewString("[record %d:#%08x]\n");
    _9586 = NewString("\n--------------------------\nblock #%d, ptrs:%d\n--------------------------\n");
    _9575 = NewString("[table block %d:#%08x]\n");
    _9570 = NewString("\ntable \"%s\", records:%d    indexblks: %d\n\n\n");
    _9569 = NewString("[table name:#%08x]\n");
    _9564 = NewString("\n---------------\n[table header:#%08x]\n");
    _9561 = NewString("[tables:#%08x]\n");
    _9295 = NewString("%s\n");
    _9544 = NewString("\x13\x1C\x26");
    _9541 = NewString("%02x");
    _9538 = NewString("%08x");
    _9528 = NewString("            Disk Dump\nDiskAddr ");
    _9527 = NewString("s\n");
    _1297 = NewString("\n");
    _9522 = NewString("The \"%s\" database has %d table");
    _9518 = NewString("Euphoria Database System Version %d.%d\n\n");
    _9517 = NewString("This is not a Euphoria Database file.\n");
    _9511 = NewString("%Y-%m-%d %H:%M:%S");
    _9510 = NewString("Database dump as at %s\n");
    _9508 = NewString("db_dump");
    _9507 = NewString("bad file");
    _1272 = NewString("w");
    _9491 = NewString("safe_seek");
    _9501 = NewString("io:seek not in position");
    _9497 = NewString("io:seek to position failed");
    _9494 = NewString("io:seeking past EOF");
    _9490 = NewString("no current database defined");
    _9407 = NewString("\x07\x29\x58\x6B\x9E");
    _9406 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _9382 = NewString("equal_string");
    _9371 = NewString("string is missing 0 terminator");
    _9372 = NewString("get_string");
    _9355 = NewString("Error Code %d: %s, from %s");
    _9351 = NewString("?connection?");
    _9350 = NewString("init_free");
    _9349 = NewString("init_tables");
    _9348 = NewString("lock_method");
    _9347 = NewString("!disconnect!");
    _4498 = NewString(" \t\r\n");
    _5300 = NewString("\"'`");
    _5299 = NewString(":=");
    _3319 = NewString(" ");
    _9123 = NewString("Try '--help' for more information.\n");
    _9323 = NewString("option '%s' is mandatory but was not supplied.\n");
    _9318 = NewString("Additional arguments were expected.\n");
    _9300 = NewString("VERSIONING was used with no version string supplied");
    _9299 = NewString("help options are incorrect,\n");
    _9282 = NewString("option '%s' must not occur more than once in the command line.\n");
    _9247 = NewString("option '%s' must have a parameter\n");
    _8536 = NewString("-/");
    _9222 = NewString("option '%s': %s\n");
    _3761 = NewString("/");
    _7870 = NewString("-");
    _6651 = NewString("--");
    _9119 = NewString("Cannot access '@' argument file '%s'\n");
    _9062 = NewString("Unrecognised cmdline PARSE OPTION - %d");
    _9061 = NewString("PAUSE_MSG was given to cmd_parse with no actually message text");
    _8765 = NewString("HELP_RID was given to cmd_parse with no routine_id");
    _9052 = NewString("\x07\x3A\x45\x50\x5B\x66\x71\x7C\x87");
    _9051 = NewString("\x01\x09\x0A\x02\x03\x04\x07\x06\x08");
    _9043 = NewString("Unrecognised");
    _9034 = NewString("Option should not have a parameter");
    _9011 = NewString("false");
    _9010 = NewString("n");
    _9009 = NewString("no");
    _9008 = NewString("off");
    _9007 = NewString("0");
    _9003 = NewString("+");
    _9002 = NewString("ok");
    _9001 = NewString("true");
    _9000 = NewString("y");
    _8999 = NewString("yes");
    _8998 = NewString("on");
    _8997 = NewString("1");
    _8967 = NewString("Empty command text");
    _8961 = NewString("!-");
    _8926 = NewString("One or more additional arguments can be supplied.\n");
    _8917 = NewString("One or more additional arguments are also required\n");
    _8900 = NewString("   ");
    _8885 = NewString(", ");
    _8612 = NewString("x");
    _8835 = NewString("%s options:\n");
    _8760 = NewString("\x07\x3A");
    _8759 = NewString("\x01\x09");
    _8691 = NewString("h");
    _8704 = NewString("Display the command options");
    _8699 = NewString("help");
    _8685 = NewString("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n");
    _8674 = NewString("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n");
    _8642 = NewString("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n");
    _8637 = NewString("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n");
    _8632 = NewString("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n");
    _8627 = NewString("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n");
    _8622 = NewString("cmd_opts: Duplicate processing options are not allowed in an option record.\n");
    _8603 = NewString("cmd_opts: There must be less than two 'extras' option records.\n");
    _8572 = NewString("extras");
    _8550 = NewString("WinNT");
    _8566 = NewString("UNKNOWN");
    _8563 = NewString("Version %d.%d");
    _8562 = NewString("Unknown Windows");
    _8561 = NewString("WinCE %d.%d");
    _8560 = NewString("WinCE");
    _8559 = NewString("WinNT %d.%d");
    _8558 = NewString("WinNT 3.1");
    _8557 = NewString("WinNT 3.5");
    _8556 = NewString("WinNT 3.51");
    _8555 = NewString("WinNT 4.0");
    _8554 = NewString("Win2K");
    _8553 = NewString("WinXP");
    _8552 = NewString("Vista");
    _8551 = NewString("Windows7");
    _8549 = NewString("Unknown");
    _8548 = NewString("WinME");
    _8547 = NewString("Win98");
    _8546 = NewString("Win95");
    _8545 = NewString("Win9x");
    _8544 = NewString("Windows %d.%d");
    _8543 = NewString("Win32s");
    _8541 = NewString("GetVersionExA");
    _8539 = NewString("kernel32.dll");
    _8540 = NewString("GetCurrentProcessId");
    _8531 = NewString("\"\"");
    _8529 = NewString("\x02");
    _8512 = NewString("%15.15f");
    _919 = NewString("%d");
    _8405 = NewString("A number from %g to %g is expected here - try again\n");
    _8394 = NewString("A number is expected - try again\n");
    _8384 = NewString("Press Any Key to continue...");
    _7917 = NewString("\x01\x02");
    _8378 = NewString("OEM_CLEAR");
    _8377 = NewString("PA1");
    _8376 = NewString("NONAME");
    _8375 = NewString("ZOOM");
    _8374 = NewString("PLAY");
    _8373 = NewString("EREOF");
    _8372 = NewString("EXSEL");
    _8371 = NewString("CRSEL");
    _8370 = NewString("ATTN");
    _8369 = NewString("PACKET");
    _8368 = NewString("PROCESSKEY");
    _8367 = NewString("OEM_102");
    _8366 = NewString("OEM_8");
    _8365 = NewString("OEM_7");
    _8364 = NewString("OEM_6");
    _8363 = NewString("OEM_5");
    _8362 = NewString("OEM_4");
    _8361 = NewString("OEM_3");
    _8360 = NewString("OEM_2");
    _8359 = NewString("OEM_PERIOD");
    _8358 = NewString("OEM_MINUS");
    _8357 = NewString("OEM_COMMA");
    _8356 = NewString("OEM_PLUS");
    _8355 = NewString("OEM_1");
    _8354 = NewString("LAUNCH_APP2");
    _8353 = NewString("LAUNCH_APP1");
    _8352 = NewString("LAUNCH_MEDIA_SELECT");
    _8351 = NewString("LAUNCH_MAIL");
    _8350 = NewString("MEDIA_PLAY_PAUSE");
    _8349 = NewString("MEDIA_STOP");
    _8348 = NewString("MEDIA_PREV_TRACK");
    _8347 = NewString("MEDIA_NEXT_TRACK");
    _8346 = NewString("VOLUME_UP");
    _8345 = NewString("VOLUME_DOWN");
    _8344 = NewString("VOLUME_MUTE");
    _8343 = NewString("BROWSER_HOME");
    _8342 = NewString("BROWSER_FAVORITES");
    _8341 = NewString("BROWSER_SEARCH");
    _8340 = NewString("BROWSER_STOP");
    _8339 = NewString("BROWSER_REFRESH");
    _8338 = NewString("BROWSER_FORWARD");
    _8337 = NewString("BROWSER_BACK");
    _8336 = NewString("RMENU");
    _8335 = NewString("LMENU");
    _8334 = NewString("RCONTROL");
    _8333 = NewString("LCONTROL");
    _8332 = NewString("RSHIFT");
    _8331 = NewString("LSHIFT");
    _8330 = NewString("SCROLL");
    _8329 = NewString("NUMLOCK");
    _8328 = NewString("F24");
    _8327 = NewString("F23");
    _8326 = NewString("F22");
    _8325 = NewString("F21");
    _8324 = NewString("F20");
    _8323 = NewString("F19");
    _8322 = NewString("F18");
    _8321 = NewString("F17");
    _8320 = NewString("F16");
    _8319 = NewString("F15");
    _8318 = NewString("F14");
    _8317 = NewString("F13");
    _8316 = NewString("F12");
    _8315 = NewString("F11");
    _8314 = NewString("F10");
    _8313 = NewString("F9");
    _8312 = NewString("F8");
    _8311 = NewString("F7");
    _8310 = NewString("F6");
    _8309 = NewString("F5");
    _8308 = NewString("F4");
    _8307 = NewString("F3");
    _8306 = NewString("F2");
    _8305 = NewString("F1");
    _8304 = NewString("DIVIDE");
    _8303 = NewString("DECIMAL");
    _8302 = NewString("SUBTRACT");
    _8301 = NewString("SEPARATOR");
    _8300 = NewString("ADD");
    _8299 = NewString("MULTIPLY");
    _8298 = NewString("NUMPAD9");
    _8297 = NewString("NUMPAD8");
    _8296 = NewString("NUMPAD7");
    _8295 = NewString("NUMPAD6");
    _8294 = NewString("NUMPAD5");
    _8293 = NewString("NUMPAD4");
    _8292 = NewString("NUMPAD3");
    _8291 = NewString("NUMPAD2");
    _8290 = NewString("NUMPAD1");
    _8289 = NewString("NUMPAD0");
    _8288 = NewString("SLEEP");
    _8287 = NewString("APPS");
    _8286 = NewString("RWIN");
    _8285 = NewString("LWIN");
    _8284 = NewString("HELP");
    _8283 = NewString("DELETE");
    _8282 = NewString("INSERT");
    _8281 = NewString("SNAPSHOT");
    _8280 = NewString("EXECUTE");
    _8279 = NewString("PRINT");
    _8278 = NewString("SELECT");
    _8277 = NewString("DOWN");
    _8276 = NewString("RIGHT");
    _8275 = NewString("UP");
    _8274 = NewString("LEFT");
    _4055 = NewString("HOME");
    _8273 = NewString("END");
    _8272 = NewString("NEXT");
    _8271 = NewString("PRIOR");
    _8270 = NewString("SPACE");
    _8269 = NewString("MODECHANGE");
    _8268 = NewString("ACCEPT");
    _8267 = NewString("NONCONVERT");
    _8266 = NewString("CONVERT");
    _8265 = NewString("ESCAPE");
    _8264 = NewString("HANJA");
    _8263 = NewString("FINAL");
    _8262 = NewString("JUNJA");
    _8261 = NewString("KANA");
    _8260 = NewString("CAPITAL");
    _8259 = NewString("PAUSE");
    _8258 = NewString("MENU");
    _8257 = NewString("CONTROL");
    _8256 = NewString("SHIFT");
    _8255 = NewString("RETURN");
    _8254 = NewString("CLEAR");
    _8253 = NewString("TAB");
    _8252 = NewString("BACK");
    _8251 = NewString("XBUTTON2");
    _8250 = NewString("XBUTTON1");
    _8249 = NewString("MBUTTON");
    _8248 = NewString("CANCEL");
    _8247 = NewString("RBUTTON");
    _8246 = NewString("LBUTTON");
    string_ptr = "\xFE\x86\x09\x17\x25\x33\x41\x4F\x5D\x6B\x79\x87\x95\xA3\xB1"
"\xBF\xCD\xDB\xE9\xF7\xF9\x03\x81\xF9\x11\x81\xF9\x1F\x81\xF9"
"\x2D\x81\xF9\x3B\x81\xF9\x49\x81\xF9\x57\x81\xF9\x65\x81\xF9"
"\x73\x81\xF9\x81\x81\xF9\x8F\x81\xF9\x9D\x81\xF9\xAB\x81\xF9"
"\xB9\x81\xF9\xC7\x81\xF9\xD5\x81\xF9\xE3\x81\xF9\xF1\x81\xF9"
"\xFF\x81\xF9\x0D\x82\xF9\x1B\x82\xF9\x29\x82\xF9\x37\x82\xF9"
"\x45\x82\xF9\x53\x82\xF9\x61\x82\xF9\x6F\x82\xF9\x7D\x82\xF9"
"\x8B\x82\xF9\x99\x82\xF9\xA7\x82\xF9\xB5\x82\xF9\xC3\x82\xF9"
"\xD1\x82\xF9\xDF\x82\xF9\xED\x82\xF9\xFB\x82\xF9\x09\x83\xF9"
"\x17\x83\xF9\x25\x83\xF9\x33\x83\xF9\x41\x83\xF9\x4F\x83\xF9"
"\x5D\x83\xF9\x6B\x83\xF9\x79\x83\xF9\x87\x83\xF9\x95\x83\xF9"
"\xA3\x83\xF9\xB1\x83\xF9\xBF\x83\xF9\xCD\x83\xF9\xDB\x83\xF9"
"\xE9\x83\xF9\xF7\x83\xF9\x05\x84\xF9\x13\x84\xF9\x21\x84\xF9"
"\x2F\x84\xF9\x3D\x84\xF9\x4B\x84\xF9\x59\x84\xF9\x67\x84\xF9"
"\x75\x84\xF9\x83\x84\xF9\x91\x84\xF9\x9F\x84\xF9\xAD\x84\xF9"
"\xBB\x84\xF9\xC9\x84\xF9\xD7\x84\xF9\xE5\x84\xF9\xF3\x84\xF9"
"\x01\x85\xF9\x0F\x85\xF9\x1D\x85\xF9\x2B\x85\xF9\x39\x85\xF9"
"\x47\x85\xF9\x55\x85\xF9\x63\x85\xF9\x71\x85\xF9\x7F\x85\xF9"
"\x8D\x85\xF9\x9B\x85\xF9\xA9\x85\xF9\xB7\x85\xF9\xC5\x85\xF9"
"\xD3\x85\xF9\xE1\x85\xF9\xEF\x85\xF9\xFD\x85\xF9\x0B\x86\xF9"
"\x19\x86\xF9\x27\x86\xF9\x35\x86\xF9\x43\x86\xF9\x51\x86\xF9"
"\x5F\x86\xF9\x6D\x86\xF9\x7B\x86\xF9\x89\x86\xF9\x97\x86\xF9"
"\xA5\x86\xF9\xB3\x86\xF9\xC1\x86\xF9\xCF\x86\xF9\xDD\x86\xF9"
"\xEB\x86\xF9\xF9\x86\xF9\x07\x87\xF9\x15\x87\xF9\x23\x87\xF9"
"\x31\x87\xF9\x3F\x87\xF9\x4D\x87";
	_8245 = decompress( 0 );
    string_ptr = "\xFE\x86\xFE\x07\x4E\x44\x57\x56\x56\x51\x50\xFE\x07\x54\x44"
"\x57\x56\x56\x51\x50\xFE\x06\x45\x43\x50\x45\x47\x4E\xFE\x07"
"\x4F\x44\x57\x56\x56\x51\x50\xFE\x08\x5A\x44\x57\x56\x56\x51"
"\x50\x33\xFE\x08\x5A\x44\x57\x56\x56\x51\x50\x34\xFE\x04\x44"
"\x43\x45\x4D\xFE\x03\x56\x43\x44\xFE\x05\x45\x4E\x47\x43\x54"
"\xFE\x06\x54\x47\x56\x57\x54\x50\xFE\x05\x55\x4A\x4B\x48\x56"
"\xFE\x07\x45\x51\x50\x56\x54\x51\x4E\xFE\x04\x4F\x47\x50\x57"
"\xFE\x05\x52\x43\x57\x55\x47\xFE\x07\x45\x43\x52\x4B\x56\x43"
"\x4E\xFE\x04\x4D\x43\x50\x43\xFE\x05\x4C\x57\x50\x4C\x43\xFE"
"\x05\x48\x4B\x50\x43\x4E\xFE\x05\x4A\x43\x50\x4C\x43\xFE\x06"
"\x47\x55\x45\x43\x52\x47\xFE\x07\x45\x51\x50\x58\x47\x54\x56"
"\xFE\x0A\x50\x51\x50\x45\x51\x50\x58\x47\x54\x56\xFE\x06\x43"
"\x45\x45\x47\x52\x56\xFE\x0A\x4F\x51\x46\x47\x45\x4A\x43\x50"
"\x49\x47\xFE\x05\x55\x52\x43\x45\x47\xFE\x05\x52\x54\x4B\x51"
"\x54\xFE\x04\x50\x47\x5A\x56\xFE\x03\x47\x50\x46\xFE\x04\x4A"
"\x51\x4F\x47\xFE\x04\x4E\x47\x48\x56\xFE\x02\x57\x52\xFE\x05"
"\x54\x4B\x49\x4A\x56\xFE\x04\x46\x51\x59\x50\xFE\x06\x55\x47"
"\x4E\x47\x45\x56\xFE\x05\x52\x54\x4B\x50\x56\xFE\x07\x47\x5A"
"\x47\x45\x57\x56\x47\xFE\x08\x55\x50\x43\x52\x55\x4A\x51\x56"
"\xFE\x06\x4B\x50\x55\x47\x54\x56\xFE\x06\x46\x47\x4E\x47\x56"
"\x47\xFE\x04\x4A\x47\x4E\x52\xFE\x04\x4E\x59\x4B\x50\xFE\x04"
"\x54\x59\x4B\x50\xFE\x04\x43\x52\x52\x55\xFE\x05\x55\x4E\x47"
"\x47\x52\xFE\x07\x50\x57\x4F\x52\x43\x46\x32\xFE\x07\x50\x57"
"\x4F\x52\x43\x46\x33\xFE\x07\x50\x57\x4F\x52\x43\x46\x34\xFE"
"\x07\x50\x57\x4F\x52\x43\x46\x35\xFE\x07\x50\x57\x4F\x52\x43"
"\x46\x36\xFE\x07\x50\x57\x4F\x52\x43\x46\x37\xFE\x07\x50\x57"
"\x4F\x52\x43\x46\x38\xFE\x07\x50\x57\x4F\x52\x43\x46\x39\xFE"
"\x07\x50\x57\x4F\x52\x43\x46\x3A\xFE\x07\x50\x57\x4F\x52\x43"
"\x46\x3B\xFE\x08\x4F\x57\x4E\x56\x4B\x52\x4E\x5B\xFE\x03\x43"
"\x46\x46\xFE\x09\x55\x47\x52\x43\x54\x43\x56\x51\x54\xFE\x08"
"\x55\x57\x44\x56\x54\x43\x45\x56\xFE\x07\x46\x47\x45\x4B\x4F"
"\x43\x4E\xFE\x06\x46\x4B\x58\x4B\x46\x47\xFE\x02\x48\x33\xFE"
"\x02\x48\x34\xFE\x02\x48\x35\xFE\x02\x48\x36\xFE\x02\x48\x37"
"\xFE\x02\x48\x38\xFE\x02\x48\x39\xFE\x02\x48\x3A\xFE\x02\x48"
"\x3B\xFE\x03\x48\x33\x32\xFE\x03\x48\x33\x33\xFE\x03\x48\x33"
"\x34\xFE\x03\x48\x33\x35\xFE\x03\x48\x33\x36\xFE\x03\x48\x33"
"\x37\xFE\x03\x48\x33\x38\xFE\x03\x48\x33\x39\xFE\x03\x48\x33"
"\x3A\xFE\x03\x48\x33\x3B\xFE\x03\x48\x34\x32\xFE\x03\x48\x34"
"\x33\xFE\x03\x48\x34\x34\xFE\x03\x48\x34\x35\xFE\x03\x48\x34"
"\x36\xFE\x07\x50\x57\x4F\x4E\x51\x45\x4D\xFE\x06\x55\x45\x54"
"\x51\x4E\x4E\xFE\x06\x4E\x55\x4A\x4B\x48\x56\xFE\x06\x54\x55"
"\x4A\x4B\x48\x56\xFE\x08\x4E\x45\x51\x50\x56\x54\x51\x4E\xFE"
"\x08\x54\x45\x51\x50\x56\x54\x51\x4E\xFE\x05\x4E\x4F\x47\x50"
"\x57\xFE\x05\x54\x4F\x47\x50\x57\xFE\x0C\x44\x54\x51\x59\x55"
"\x47\x54\x61\x44\x43\x45\x4D\xFE\x0F\x44\x54\x51\x59\x55\x47"
"\x54\x61\x48\x51\x54\x59\x43\x54\x46\xFE\x0F\x44\x54\x51\x59"
"\x55\x47\x54\x61\x54\x47\x48\x54\x47\x55\x4A\xFE\x0C\x44\x54"
"\x51\x59\x55\x47\x54\x61\x55\x56\x51\x52\xFE\x0E\x44\x54\x51"
"\x59\x55\x47\x54\x61\x55\x47\x43\x54\x45\x4A\xFE\x11\x44\x54"
"\x51\x59\x55\x47\x54\x61\x48\x43\x58\x51\x54\x4B\x56\x47\x55"
"\xFE\x0C\x44\x54\x51\x59\x55\x47\x54\x61\x4A\x51\x4F\x47\xFE"
"\x0B\x58\x51\x4E\x57\x4F\x47\x61\x4F\x57\x56\x47\xFE\x0B\x58"
"\x51\x4E\x57\x4F\x47\x61\x46\x51\x59\x50\xFE\x09\x58\x51\x4E"
"\x57\x4F\x47\x61\x57\x52\xFE\x10\x4F\x47\x46\x4B\x43\x61\x50"
"\x47\x5A\x56\x61\x56\x54\x43\x45\x4D\xFE\x10\x4F\x47\x46\x4B"
"\x43\x61\x52\x54\x47\x58\x61\x56\x54\x43\x45\x4D\xFE\x0A\x4F"
"\x47\x46\x4B\x43\x61\x55\x56\x51\x52\xFE\x10\x4F\x47\x46\x4B"
"\x43\x61\x52\x4E\x43\x5B\x61\x52\x43\x57\x55\x47\xFE\x0B\x4E"
"\x43\x57\x50\x45\x4A\x61\x4F\x43\x4B\x4E\xFE\x13\x4E\x43\x57"
"\x50\x45\x4A\x61\x4F\x47\x46\x4B\x43\x61\x55\x47\x4E\x47\x45"
"\x56\xFE\x0B\x4E\x43\x57\x50\x45\x4A\x61\x43\x52\x52\x33\xFE"
"\x0B\x4E\x43\x57\x50\x45\x4A\x61\x43\x52\x52\x34\xFE\x05\x51"
"\x47\x4F\x61\x33\xFE\x08\x51\x47\x4F\x61\x52\x4E\x57\x55\xFE"
"\x09\x51\x47\x4F\x61\x45\x51\x4F\x4F\x43\xFE\x09\x51\x47\x4F"
"\x61\x4F\x4B\x50\x57\x55\xFE\x0A\x51\x47\x4F\x61\x52\x47\x54"
"\x4B\x51\x46\xFE\x05\x51\x47\x4F\x61\x34\xFE\x05\x51\x47\x4F"
"\x61\x35\xFE\x05\x51\x47\x4F\x61\x36\xFE\x05\x51\x47\x4F\x61"
"\x37\xFE\x05\x51\x47\x4F\x61\x38\xFE\x05\x51\x47\x4F\x61\x39"
"\xFE\x05\x51\x47\x4F\x61\x3A\xFE\x07\x51\x47\x4F\x61\x33\x32"
"\x34\xFE\x0A\x52\x54\x51\x45\x47\x55\x55\x4D\x47\x5B\xFE\x06"
"\x52\x43\x45\x4D\x47\x56\xFE\x04\x43\x56\x56\x50\xFE\x05\x45"
"\x54\x55\x47\x4E\xFE\x05\x47\x5A\x55\x47\x4E\xFE\x05\x47\x54"
"\x47\x51\x48\xFE\x04\x52\x4E\x43\x5B\xFE\x04\x5C\x51\x51\x4F"
"\xFE\x06\x50\x51\x50\x43\x4F\x47\xFE\x03\x52\x43\x33\xFE\x09"
"\x51\x47\x4F\x61\x45\x4E\x47\x43\x54";
	_8244 = decompress( 0 );
    _8049 = NewDouble((double)4.2949672320000000e+09);
    _7950 = NewString("%s = %s\n");
    _7869 = NewString("\\-");
    _5942 = NewString("%.15g");
    _7934 = NewString("%Y%m%d%H%M%S");
    _7918 = NewString("\x07\x09");
    _7909 = NewString(",$");
    _7907 = NewString("\",$\"");
    _7848 = NewString(",${");
    _7823 = NewDouble((double)1.3330000000000000e+00);
    _7498 = NewString("Unknown operation given to map.e:put()");
    _7565 = NewString("\x07\x18\x31\x4A\x63\x7C\x99\xB2");
    _7564 = NewString("\x01\x02\x03\x04\x05\x06\x07\x08");
    _7501 = NewString("Inappropriate initial operation given to map.e:put()");
    _7469 = NewString("\x07\x1D\x3B\x59\x77\x95\xC3\xE1");
    _7468 = NewString("\x01\x02\x03\x04\x05\x06\x07\x08");
    _7390 = NewString("\x07\x09\x2D\x2F");
    _7389 = NewString("vVkK");
    _6903 = NewDouble((double)3.5000000000000000e+00);
    _7249 = NewDouble((double)-7.5960358940999999e+04);
    _7248 = NewDouble((double)7.5960358940999999e+04);
    _7247 = NewString("\x01\x06\x07\x02\x03\x08");
    _7246 = NewString("Eu:StdMap");
    _7238 = NewString("\x01");
    _2193 = NewDouble((double)1.0000000000000000e+00);
    _2326 = NewDouble((double)5.0000000000000000e-01);
    _7014 = NewString("\x07\x1A");
    _7013 = NewString("\x02\x03");
    _6919 = NewString("MW");
    _6883 = NewString("\x02\x03");
    _1296 = NewString("\r\n");
    _6815 = NewString("\x02\x01\x01");
    _6814 = NewString("\x03\x01\x02");
    _6812 = NewString("\x02\x03\x04\x01");
    _6811 = NewString("\x10\x04\x01");
    _6810 = NewString("\x04\x10\x40");
    _6809 = NewString("\x40\x10\x04");
    _6805 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
    _6783 = NewString("%-29s : %s\n");
    _6779 = NewString("UNKNOWN                       : %d\n");
    _6770 = NewString("T_NEWLINE                     : \\n\n");
    _6765 = NewString("T_NUMBER %20s : %s\n");
    _6762 = NewString("%f");
    _6749 = NewString("T_STRING %20s : [[[%s]]]\n");
    _6748 = NewString("\x07\x2D\x80");
    _6747 = NewString("\x08\x06\x04");
    _6742 = NewString("TF_COMMENT_MULTIPLE");
    _6741 = NewString("TF_COMMENT_SINGLE");
    _6740 = NewString("TF_STRING_HEX");
    _6739 = NewString("TF_STRING_BACKTICK");
    _6738 = NewString("TF_STRING_TRIPPLE");
    _6737 = NewString("TF_STRING_SINGLE");
    _6736 = NewString("TF_ATOM");
    _6735 = NewString("TF_INT");
    _6734 = NewString("TF_HEX");
    _6732 = NewString("T_SLICE");
    _6731 = NewString("T_DOLLAR");
    _6730 = NewString("T_COLON");
    _6729 = NewString("T_PERIOD");
    _6728 = NewString("T_COMMA");
    _6727 = NewString("T_QPRINT");
    _6726 = NewString("T_RBRACKET");
    _6725 = NewString("T_LBRACKET");
    _6724 = NewString("T_RBRACE");
    _6723 = NewString("T_LBRACE");
    _6722 = NewString("T_RPAREN");
    _6721 = NewString("T_LPAREN");
    _6720 = NewString("T_EQ");
    _6719 = NewString("T_CONCAT");
    _6718 = NewString("T_NOT");
    _6717 = NewString("T_GT");
    _6716 = NewString("T_LT");
    _6715 = NewString("T_DIVIDE");
    _6714 = NewString("T_MULTIPLY");
    _6713 = NewString("T_MINUS");
    _6712 = NewString("T_PLUS");
    _6711 = NewString("T_CONCATEQ");
    _6710 = NewString("T_NOTEQ");
    _6709 = NewString("T_GTEQ");
    _6708 = NewString("T_LTEQ");
    _6707 = NewString("T_DIVIDEEQ");
    _6706 = NewString("T_MULTIPLYEQ");
    _6705 = NewString("T_MINUSEQ");
    _6704 = NewString("T_PLUSEQ");
    _6703 = NewString("T_KEYWORD");
    _6702 = NewString("T_IDENTIFIER");
    _6701 = NewString("T_STRING");
    _6700 = NewString("T_CHAR");
    _6699 = NewString("T_NUMBER");
    _6698 = NewString("T_COMMENT");
    _6697 = NewString("T_NEWLINE");
    _6696 = NewString("T_SHBANG");
    _6695 = NewString("T_NULL");
    _6694 = NewString("T_EOF");
    _6643 = NewString("%g");
    _118 = NewString("include");
    _6549 = NewString("xuU");
    _6555 = NewString("0123456789ABCDEFabcdef _\t\n\r");
    _6551 = NewString("tokenize.e: Unknown base code '%s', ignored.\n");
    _6550 = NewString("\x07\x12\x1D");
    _6531 = NewString("btdx");
    _6279 = NewString("\"\"\"");
    _6416 = NewString("t\\r'n\"");
    _6239 = NewString("*/");
    _6329 = NewString("Invalid hexadecimal or unicode string");
    _6328 = NewString("End of file reached without closing \" char");
    _6327 = NewString("Expected EOF");
    _6326 = NewString("Unknown token type");
    _6325 = NewString("Expected a decimal value");
    _6324 = NewString("Expected a hex value");
    _6323 = NewString("End of line reached without closing \" char");
    _6322 = NewString("Expected a closing ' char");
    _6321 = NewString("End of line reached without closing ' char");
    _6320 = NewString("Expected an escape character");
    _6319 = NewString("Failed to open file");
    _6316 = NewString("=(){}[]?,.:$");
    _6315 = NewString("+-*/<>!&");
    _6176 = NewString("MULTILINE_STRING");
    _6258 = NewString("`");
    _6179 = NewString("BACKTICK_STRING");
    _6173 = NewString("MULTILINE_COMMENT");
    _6250 = NewString("/*");
    _6219 = NewString(")]}");
    _6202 = NewString("([{");
    _6139 = NewString("syncolor.e: Unknown color name '%s', ignored.\n");
    _6136 = NewString("BRACKET");
    _6133 = NewString("STRING");
    _6130 = NewString("BUILTIN");
    _6127 = NewString("KEYWORD");
    _6124 = NewString("COMMENT");
    _6121 = NewString("NORMAL");
    _6120 = NewString("\x07\x19\x2B\x3D\x4F\x61");
    string_ptr = "\xFE\x06\xFE\x06\x50\x51\x54\x4F\x43\x4E\xFE\x07\x45\x51\x4F"
"\x4F\x47\x50\x56\xFE\x07\x4D\x47\x5B\x59\x51\x54\x46\xFE\x07"
"\x44\x57\x4B\x4E\x56\x4B\x50\xFE\x06\x55\x56\x54\x4B\x50\x49"
"\xFE\x07\x44\x54\x43\x45\x4D\x47\x56";
	_6119 = decompress( 0 );
    _1085 = NewString("free");
    _6062 = NewString(" \t");
    _5958 = NewString("logic error: 'cap' mode in format.");
    _5954 = NewString("\x07\x15\x23\x31");
    string_ptr = "\xFE\x04\x77\x6E\x79\x02";
	_5953 = decompress( 0 );
    _5865 = NewString("e+0");
    _5858 = NewString("%15.15g");
    _2185 = NewDouble((double)4.2949672950000000e+09);
    _5828 = NewString("%x");
    _1353 = NewString("0123456789");
    string_ptr = "\xFE\x21\x09\x19\x55\x57\x59\x64\x6F\x7A\x85\x90\x9B\xA6\xA8"
"\xAA\xB5\xC0\xCB\xD6\xE1\xF9\x38\x81\xF9\x88\x81\xF9\x4F\x82"
"\xF9\xD3\x82\xF9\xD5\x82\xF9\xD7\x82\xF9\xD9\x82\xF9\xDB\x82"
"\xF9\xDD\x82\xF9\xDF\x82\xF9\xE1\x82\xF9\xE3\x82\xF9\xE5\x82"
"\xF9\x3D\x83";
	_5660 = decompress( 0 );
    _5659 = NewString("][wulbstzXBc<>+(?T:.{%0123456789,");
    _5475 = NewString("\"");
    _910 = NewString("\\");
    _5432 = NewString("p[%d]");
    _5315 = NewString("}])");
    _5314 = NewString("{[(");
    _307 = NewString(" \t\n\r");
    _5298 = NewString(";,");
    _5252 = NewString("CharUpperBuffA");
    _5251 = NewString("CharLowerBuffA");
    _5250 = NewString("user32.dll");
    _5152 = NewString("ASCII");
    _5239 = NewString("Failed to load code page '%s'. Error # %d\n");
    _5218 = NewString("\x07\x09");
    _5217 = NewString("\x01\x02");
    _5207 = NewString("ecp.dat");
    _5177 = NewString("title");
    _5169 = NewString("--CASE--");
    _5163 = NewString("--HEAD--");
    _5153 = NewString(".ecp");
    _4772 = NewString("%.10g");
    _929 = NewString("{");
    _4930 = NewString("Invalid sequence serialization");
    _4955 = NewString("\x07\x33\x6F\x8C\xCF");
    _4954 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _4865 = NewString("\x07\x25\x4E\x62\x8D");
    _4864 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _4765 = NewString(" ...");
    _4752 = NewString("\t\r\n\\");
    _4722 = NewString("\t\n\r\\");
    _4713 = NewString("\\\"");
    _911 = NewString("\\\\");
    _4712 = NewString("\\r");
    _4711 = NewString("\\n");
    _4710 = NewString("\\t");
    _4709 = NewString("\x07\x13\x1F\x2B\x37");
    _4708 = NewString("\t\n\r\\\"");
    _4683 = NewString("[:08X]");
    _4615 = NewString("%s%s%06d%s");
    _3780 = NewString(".");
    _4602 = NewString("\x07\x16\x23");
    string_ptr = "\xFE\x03\x03\x04\x02";
	_4601 = decompress( 0 );
    _4599 = NewString("/tmp/");
    _4597 = NewString("C:\\temp\\");
    _4595 = NewString("TMP");
    _4592 = NewString("TEMP");
    _4589 = NewString("_T_");
    _4576 = NewString("count_files");
    _3847 = NewString("..");
    _4492 = NewString(" > ");
    _4491 = NewString("df -k ");
    _4489 = NewString(".tmp");
    _4486 = NewString("/tmp/eudf");
    _4438 = NewString("PATH");
    _4433 = NewString("USERPATH");
    _4430 = NewString("/usr/share/euphoria/include/");
    _4429 = NewString("/home/owner/euphoria/euwrap_ubuntu32/libeu");
    _4428 = NewString("/usr/share/euphoria/include");
    _4426 = NewString("/usr/share/euphoria/bin/");
    _4424 = NewString("/usr/local/share/euphoria/bin/");
    _4421 = NewString("data");
    _4418 = NewString("etc");
    _4413 = NewString("EUDIST");
    _4410 = NewString("docs");
    _4407 = NewString("bin");
    _4404 = NewString("EUDIR");
    _4058 = NewString("HOMEPATH");
    _4057 = NewString("HOMEDRIVE");
    _4131 = NewString("partloop");
    _4084 = NewString("/\\");
    _300 = NewString("  ");
    _3842 = NewString(" /\n");
    _3767 = NewString("dll");
    _3766 = NewString("NUL:");
    _3765 = NewString("\\/:");
    _3764 = NewString("so");
    _3763 = NewString("dylib");
    _3762 = NewString("/dev/null");
    _3760 = NewString("GetDiskFreeSpaceA");
    _3759 = NewString("GetFileAttributesA");
    _3758 = NewString("RemoveDirectoryA");
    _3757 = NewString("CreateDirectoryA");
    _3756 = NewString("DeleteFileA");
    _3755 = NewString("MoveFileA");
    _3754 = NewString("CopyFileA");
    _3751 = NewString("access");
    _3748 = NewString("rmdir");
    _3745 = NewString("mkdir");
    _3742 = NewString("unlink");
    _3739 = NewString("rename");
    _3738 = NewString("stat");
    _3735 = NewString("__xstat");
    _1040 = NewString("libc.so");
    _1638 = NewString("libc.dylib");
    _3733 = NewString("kernel32");
    _3667 = NewDouble((double)1.5000000000000000e+00);
    _3606 = NewDouble((double)1.2345600000000001e+00);
    _3543 = NewString("DoA");
    _3294 = NewString(", \t|");
    _3232 = NewString("%d is not a valid index for the input sequence");
    _3226 = NewString("filter_alpha");
    _663 = NewString("()");
    _679 = NewString("(]");
    _671 = NewString("[)");
    _658 = NewString("[]");
    string_ptr = "\xFE\x05\x09\x41\xA3\xF9\x03\x81\xF9\x65\x81";
	_3159 = decompress( 0 );
    string_ptr = "\xFE\x05\xFE\x00\xFE\x02\x5D\x5F\xFE\x02\x5D\x2B\xFE\x02\x2A"
"\x5F\xFE\x02\x2A\x2B";
	_3158 = decompress( 0 );
    _3157 = NewString("out");
    string_ptr = "\xFE\x05\x09\x41\x90\xDF\xF9\x2C\x81";
	_3107 = decompress( 0 );
    string_ptr = "\xFE\x05\xFE\x00\xFE\x02\x5D\x5F\xFE\x02\x5D\x2B\xFE\x02\x2A"
"\x5F\xFE\x02\x2A\x2B";
	_3106 = decompress( 0 );
    _3105 = NewString("in");
    _3098 = NewString("ge");
    _3097 = NewString(">=");
    _3090 = NewString("gt");
    _3089 = NewString(">");
    _3082 = NewString("ne");
    _3081 = NewString("!=");
    _3074 = NewString("eq");
    _3073 = NewString("==");
    _3072 = NewString("=");
    _3065 = NewString("le");
    _3064 = NewString("<=");
    _3057 = NewString("lt");
    _3056 = NewString("<");
    string_ptr = "\xFE\x0F\x09\x0B\x43\x45\x7D\x7F\x81\xB9\xBB\xF3\xF5\xF9\x2B"
"\x81\xF9\x2D\x81\xF9\x65\x81\xF9\xEB\x82";
	_3055 = decompress( 0 );
    string_ptr = "\xFE\x0F\xFE\x01\x3E\xFE\x02\x6E\x76\xFE\x02\x3E\x3F\xFE\x02"
"\x6E\x67\xFE\x01\x3F\xFE\x02\x3F\x3F\xFE\x02\x67\x73\xFE\x02"
"\x23\x3F\xFE\x02\x70\x67\xFE\x01\x40\xFE\x02\x69\x76\xFE\x02"
"\x40\x3F\xFE\x02\x69\x67\xFE\x02\x6B\x70\xFE\x03\x71\x77\x76";
	_3054 = decompress( 0 );
    _2981 = NewString("sequence:vslice(): colno should be a valid index on the %d-th element, but was %d");
    _2971 = NewString("sequence:vslice(): colno should be a valid index, but was %d");
    _2941 = NewString("mid(): len was %d and should be greater than %d.");
    _2920 = NewString("sequence.e:add_item() invalid Order argument '%d'");
    _2913 = NewString("\x07\x17\x27\x3C");
    _2912 = NewString("\x01\x02\x03\x04");
    _2885 = NewString("\x07\x2C");
    _2884 = NewString("+*");
    _2787 = NewString("sequence:rotate(): invalid 'stop' parameter %d");
    _2784 = NewString("sequence:rotate(): invalid 'start' parameter %d");
    _2700 = NewString("outer");
    _2637 = NewString("column_compare");
    _2539 = NewString("approx(): Sequence arguments must be the same length");
    _2533 = NewDouble((double)5.0000000000000001e-03);
    _2492 = NewDouble((double)2.1474836470000000e+09);
    _2490 = NewDouble((double)2.1474836480000000e+09);
    _2439 = NewDouble((double)-1.0000000000000000e+00);
    _2403 = NewDouble((double)-1.5707963267948966e+00);
    _2359 = NewString("The lengths of the two supplied sequences do not match.");
    _2245 = NewDouble((double)2.2360679774997898e+00);
    _2242 = NewDouble((double)1.0000000000000000e+308);
    _2241 = NewDouble((double)1.6487212707001282e+00);
    _2240 = NewDouble((double)5.7721566490153287e-01);
    _2239 = NewDouble((double)5.7295779513082323e+01);
    _2238 = NewDouble((double)1.7453292519943295e-02);
    _2237 = NewDouble((double)1.7320508075688772e+00);
    _2236 = NewDouble((double)7.0710678118654757e-01);
    _2235 = NewDouble((double)1.4142135623730949e+00);
    _2234 = NewDouble((double)4.3429448190325187e-01);
    _2233 = NewDouble((double)2.3025850929940459e+00);
    _2232 = NewDouble((double)1.4426950408889634e+00);
    _2231 = NewDouble((double)6.9314718055994529e-01);
    _2230 = NewDouble((double)2.7182818284590455e+00);
    _2229 = NewDouble((double)1.6180339887498949e+00);
    _2228 = NewDouble((double)3.9894228040143365e-01);
    _2227 = NewDouble((double)9.8696044010893580e+00);
    _2226 = NewDouble((double)6.2831853071795862e+00);
    _2225 = NewDouble((double)1.5707963267948966e+00);
    _2224 = NewDouble((double)7.8539816339744839e-01);
    _2223 = NewDouble((double)3.1415926535897931e+00);
    _2066 = NewString("\x07\x17\x27\x37\x47\x57\x67");
    _2065 = NewString("YymdHMS");
    _1931 = NewString("%Y-%m-%d %H:%M:%S");
    _2051 = NewString("%04d");
    _1951 = NewString("%02d");
    _2030 = NewString("7");
    _1833 = NewString("PM");
    _1832 = NewString("AM");
    _1830 = NewString("Sat");
    _1829 = NewString("Fri");
    _1828 = NewString("Thu");
    _1827 = NewString("Wed");
    _1826 = NewString("Tue");
    _1825 = NewString("Mon");
    _1824 = NewString("Sun");
    _1822 = NewString("Saturday");
    _1821 = NewString("Friday");
    _1820 = NewString("Thursday");
    _1819 = NewString("Wednesday");
    _1818 = NewString("Tuesday");
    _1817 = NewString("Monday");
    _1816 = NewString("Sunday");
    _1814 = NewString("Dec");
    _1813 = NewString("Nov");
    _1812 = NewString("Oct");
    _1811 = NewString("Sep");
    _1810 = NewString("Aug");
    _1809 = NewString("Jul");
    _1808 = NewString("Jun");
    _1795 = NewString("May");
    _1807 = NewString("Apr");
    _1806 = NewString("Mar");
    _1805 = NewString("Feb");
    _1804 = NewString("Jan");
    _1802 = NewString("December");
    _1801 = NewString("November");
    _1800 = NewString("October");
    _1799 = NewString("September");
    _1798 = NewString("August");
    _1797 = NewString("July");
    _1796 = NewString("June");
    _1794 = NewString("April");
    _1793 = NewString("March");
    _1792 = NewString("February");
    _1791 = NewString("January");
    _1743 = NewDouble((double)3.6525000000000000e+02);
    _1738 = NewDouble((double)3.0436876040000001e+01);
    _1721 = NewDouble((double)2.5000000000000000e-01);
    _1657 = NewDouble((double)6.2135856000000000e+10);
    _1656 = NewString("\x1F\x1C\x1F\x1E\x1F\x1E\x1F\x1F\x1E\x1F\x1E\x1F");
    _1642 = NewDouble((double)3.5776430080000000e+09);
    _225 = NewString("time");
    _1632 = NewString("gmtime");
    _1640 = NewString("GetSystemTimeAsFileTime");
    _1034 = NewString("kernel32.dll");
    _1639 = NewString("msvcrt.dll");
    _1621 = NewString("Initial seek() for get() failed!");
    _1617 = NewString("GET_LONG_ANSWER");
    _1616 = NewString("GET_SHORT_ANSWER");
    _1615 = NewString("Invalid type of answer, please only use %s (the default) or %s.");
    _1610 = NewString("Get2");
    _1608 = NewString("Get");
    _1372 = NewString("\n'\"\t\\\r");
    _1371 = NewString("n'\"t\\r");
    _1356 = NewString("-+.#");
    _1354 = NewString("ABCDEF");
    _1343 = NewString("Unable to write to '%s'");
    _1278 = NewString("a");
    _1124 = NewString("A C function is being defined from Non-executable memory.");
    _1089 = NewString("free_pointer_array");
    _1083 = NewString("free() called with nested sequence");
    _1078 = NewString("free(\"%s\") is not a valid address");
    _1066 = NewString("Parameter error: Wrong word size %d in allocate_protect().");
    _1065 = NewString("\x07\x12\x1D");
    _1064 = NewString("\x01\x02\x04");
    _1043 = NewString("getpagesize");
    _1041 = NewString("sysconf");
    _1039 = NewString("GetSystemInfo");
    _1038 = NewString("GetLastError");
    _1037 = NewString("VirtualFree");
    _1036 = NewString("VirtualProtect");
    _1035 = NewString("VirtualAlloc");
    _978 = NewString("deallocate");
    _958 = NewString("\x01\x02\x04");
    _937 = NewString(", ");
    _921 = NewString("%.15f");
    string_ptr = "\xFE\x27\x09\x28\x47\x6D\x93\xB9\xBB\xBD\xBF\xC1\xE0\xF9\xFD"
"\x80\xF9\xFF\x80\xF9\x34\x81\xF9\x6D\x81\xF9\x6F\x81\xF9\x71"
"\x81\xF9\x86\x81\xF9\x88\x81\xF9\x8A\x81\xF9\x8C\x81\xF9\x8E"
"\x81\xF9\x90\x81\xF9\x92\x81\xF9\x94\x81\xF9\x96\x81\xF9\x98"
"\x81\xF9\x9A\x81\xF9\x9C\x81\xF9\x9E\x81\xF9\xA0\x81\xF9\xA2"
"\x81\xF9\xA4\x81\xF9\xA6\x81\xF9\xA8\x81\xF9\xAA\x81\xF9\xAC"
"\x81\xF9\xAE\x81\xF9\xB0\x81";
	_812 = decompress( 0 );
    _811 = NewString("\x2D\x2B\x23\x40\x21\x24\xA3\xA4\xA5\x80\x5F\x2E\x2C\x25\x09"
"\x20\xA0\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43"
"\x44\x45\x46\x61\x62\x63\x64\x65\x66");
    _804 = NewString("\x07\x09");
    _803 = NewString(",.");
    _802 = NewString("0123456789ABCDEFabcdef");
    _783 = NewString("0123456789abcdefABCDEF");
    _662 = NewString("\x07\x3A\x6D");
    string_ptr = "\xFE\x03\xFE\x02\x2A\x2B\xFE\x02\x5D\x2B\xFE\x02\x2A\x5F";
	_661 = decompress( 0 );
    _476 = NewString("#");
    _342 = NewString("_");
    _337 = NewString("!~");
    _289 = NewString("09");
    _331 = NewString("");
    _326 = NewString("{~");
    _324 = NewString("[`");
    _321 = NewString(":?");
    _318 = NewString(" /");
    _315 = NewString("af");
    _313 = NewString("AF");
    _311 = NewString("aeiouAEIOU");
    _310 = NewString("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ");
    _305 = NewString("\x07\x07");
    _304 = NewString("\x08\x08");
    _303 = NewString("\r\r");
    _302 = NewString("\n\n");
    _301 = NewString("\t\t");
    _298 = NewString(" ~");
    _282 = NewString("az");
    _285 = NewString("AZ");
    _292 = NewString("__");
    _258 = NewString("NXTCHR");
    _227 = NewString("xor_bits");
    _226 = NewString("trace");
    _224 = NewString("task_yield");
    _223 = NewString("task_suspend");
    _222 = NewString("task_status");
    _221 = NewString("task_self");
    _220 = NewString("task_schedule");
    _219 = NewString("task_list");
    _218 = NewString("task_create");
    _217 = NewString("task_clock_stop");
    _216 = NewString("task_clock_start");
    _215 = NewString("tan");
    _214 = NewString("tail");
    _213 = NewString("system_exec");
    _212 = NewString("system");
    _211 = NewString("sqrt");
    _210 = NewString("sprintf");
    _209 = NewString("splice");
    _208 = NewString("sin");
    _207 = NewString("sequence");
    _206 = NewString("routine_id");
    _205 = NewString("replace");
    _204 = NewString("repeat");
    _203 = NewString("remove");
    _202 = NewString("remainder");
    _201 = NewString("rand");
    _200 = NewString("puts");
    _199 = NewString("printf");
    _198 = NewString("print");
    _197 = NewString("prepend");
    _196 = NewString("power");
    _195 = NewString("position");
    _194 = NewString("poke4");
    _193 = NewString("poke2");
    _192 = NewString("poke");
    _191 = NewString("platform");
    _190 = NewString("pixel");
    _189 = NewString("peeks");
    _188 = NewString("peek_string");
    _187 = NewString("peek4u");
    _186 = NewString("peek4s");
    _185 = NewString("peek2u");
    _184 = NewString("peek2s");
    _183 = NewString("peek");
    _182 = NewString("or_bits");
    _181 = NewString("option_switches");
    _180 = NewString("open");
    _179 = NewString("object");
    _178 = NewString("not_bits");
    _177 = NewString("mem_set");
    _176 = NewString("mem_copy");
    _175 = NewString("match");
    _174 = NewString("machine_proc");
    _173 = NewString("machine_func");
    _172 = NewString("log");
    _171 = NewString("length");
    _170 = NewString("integer");
    _169 = NewString("insert");
    _168 = NewString("include_paths");
    _167 = NewString("head");
    _166 = NewString("hash");
    _165 = NewString("gets");
    _164 = NewString("getenv");
    _163 = NewString("getc");
    _162 = NewString("get_key");
    _161 = NewString("floor");
    _160 = NewString("find");
    _159 = NewString("equal");
    _158 = NewString("delete_routine");
    _157 = NewString("delete");
    _156 = NewString("date");
    _155 = NewString("cos");
    _154 = NewString("compare");
    _153 = NewString("command_line");
    _152 = NewString("close");
    _151 = NewString("clear_screen");
    _150 = NewString("call_proc");
    _149 = NewString("call_func");
    _148 = NewString("call");
    _147 = NewString("c_proc");
    _146 = NewString("c_func");
    _145 = NewString("atom");
    _144 = NewString("arctan");
    _143 = NewString("append");
    _142 = NewString("and_bits");
    _141 = NewString("abort");
    _140 = NewString("?");
    _138 = NewString("xor");
    _137 = NewString("without");
    _136 = NewString("with");
    _135 = NewString("while");
    _134 = NewString("until");
    _133 = NewString("type");
    _132 = NewString("to");
    _131 = NewString("then");
    _130 = NewString("switch");
    _129 = NewString("routine");
    _128 = NewString("return");
    _127 = NewString("retry");
    _126 = NewString("public");
    _125 = NewString("procedure");
    _124 = NewString("override");
    _123 = NewString("or");
    _122 = NewString("not");
    _121 = NewString("namespace");
    _120 = NewString("loop");
    _119 = NewString("label");
    _117 = NewString("ifdef");
    _116 = NewString("if");
    _115 = NewString("goto");
    _114 = NewString("global");
    _113 = NewString("function");
    _112 = NewString("for");
    _111 = NewString("fallthru");
    _110 = NewString("export");
    _109 = NewString("exit");
    _108 = NewString("enum");
    _107 = NewString("entry");
    _106 = NewString("end");
    _105 = NewString("elsifdef");
    _104 = NewString("elsif");
    _103 = NewString("elsedef");
    _102 = NewString("else");
    _101 = NewString("do");
    _100 = NewString("continue");
    _99 = NewString("constant");
    _98 = NewString("case");
    _97 = NewString("by");
    _96 = NewString("break");
    _95 = NewString("as");
    _94 = NewString("and");
    _89 = NewString("Copyright (c) 1997-2010 University of Cambridge\nAll Rights Reserved\n");
    _88 = NewString("PCRE v8.10");
    _86 = NewString("Copyright (c) 2007-2011 by OpenEuphoria Group.\nCopyright (c) 1993-2006 by Rapid Deployment Software.\nAll Rights Reserved.");
    _84 = NewString("Euphoria v");
    _82 = NewString(" for ");
    _78 = NewString("%d.%d.%d");
    _69 = NewString("%d.%d.%d %s (%s, %s)");
    _60 = NewString("%d.%d.%d %s (%d:%s, %s)");
    _27 = NewString("Unknown");
    _26 = NewString("NetBSD");
    _25 = NewString("OpenBSD");
    _24 = NewString("FreeBSD");
    _23 = NewString("OS X");
    _22 = NewString("Linux");
    _21 = NewString("Windows");
    _18 = NewString("development");
	_8vDigits_1526 = NewString("0123456789ABCDEFabcdef");
	_17DIGITS_2821 = NewString("0123456789");
	_17white_space_2859 = NewString(" \t\n\r");
	_17ESCAPE_CHARS_2864 = NewString("n'\"t\\r");
	_17ESCAPED_CHARS_2866 = NewString("\n'\"\t\\\r");
	_12DaysPerMonth_3348 = NewString("\x1F\x1C\x1F\x1E\x1F\x1E\x1F\x1F\x1E\x1F\x1E\x1F");
	_12EPOCH_1970_3351 = NewDouble( 62135856000.0000000000000000 );
	_22PI_4313 = NewDouble( 3.1415926535897931 );
	_22QUARTPI_4315 = NewDouble( 0.7853981633974484 );
	_22HALFPI_4317 = NewDouble( 1.5707963267948966 );
	_22TWOPI_4319 = NewDouble( 6.2831853071795862 );
	_22PISQR_4321 = NewDouble( 9.8696044010893580 );
	_22INVSQ2PI_4323 = NewDouble( 0.3989422804014336 );
	_22PHI_4325 = NewDouble( 1.6180339887498949 );
	_22E_4327 = NewDouble( 2.7182818284590455 );
	_22LN2_4329 = NewDouble( 0.6931471805599453 );
	_22INVLN2_4331 = NewDouble( 1.4426950408889634 );
	_22LN10_4333 = NewDouble( 2.3025850929940459 );
	_22INVLN10_4335 = NewDouble( 0.4342944819032519 );
	_22SQRT2_4337 = NewDouble( 1.4142135623730949 );
	_22HALFSQRT2_4339 = NewDouble( 0.7071067811865476 );
	_22SQRT3_4341 = NewDouble( 1.7320508075688772 );
	_22DEGREES_TO_RADIANS_4343 = NewDouble( 0.0174532925199433 );
	_22RADIANS_TO_DEGREES_4345 = NewDouble( 57.2957795130823229 );
	_22EULER_GAMMA_4347 = NewDouble( 0.5772156649015329 );
	_22SQRTE_4349 = NewDouble( 1.6487212707001282 );
	_22SQRT5_4356 = NewDouble( 2.2360679774997898 );
	_11SLASHES_7008 = NewString("/");
	_11EOLSEP_7010 = NewString("\n");
	_11NULLDEVICE_7012 = NewString("/dev/null");
	_11SHARED_LIB_EXT_7015 = NewString("so");
	_29QFLAGS_11398 = NewString("t\\r'n\"");
	_30aleph_11980 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
	_30drem_12003 = NewString("\x40\x10\x04");
	_30dmul_12005 = NewString("\x04\x10\x40");
	_30ddiv_12007 = NewString("\x10\x04\x01");
	_30nc4_12009 = NewString("\x02\x03\x04\x01");
	_30nc3_12013 = NewString("\x03\x01\x02");
	_30ldrop_12015 = NewString("\x02\x01\x01");
	_33type_is_map_12806 = NewString("Eu:StdMap");
	_33INIT_OPERATIONS_12816 = NewString("\x01\x06\x07\x02\x03\x08");
	_33init_small_map_key_12821 = NewDouble( -75960.3589409999985946 );
	_37CMD_SWITCHES_15121 = NewString("-");
	_38DISCONNECT_16429 = NewString("!disconnect!");
	_38LOCK_METHOD_16431 = NewString("lock_method");
	_38INIT_TABLES_16433 = NewString("init_tables");
	_38INIT_FREE_16435 = NewString("init_free");
	_38CONNECTION_16437 = NewString("?connection?");
	_50type_is_stack_22227 = NewString("Eu:StdStack");
	_53DNS_QUERY_RESERVED_22630 = NewDouble( 4278190080.0000000000000000 );
	_55alphanum_22822 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234567890");
	_55hexnums_22824 = NewString("0123456789ABCDEF");
	_54rand_chars_23106 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
	_58SIGN_MASK_23701 = NewDouble( 4026531840.0000000000000000 );
	_58SIGN_FLAG_23703 = NewDouble( 2147483648.0000000000000000 );
	_58DOUBLE_FLAG_23704 = NewDouble( 2415919104.0000000000000000 );
	_58INT_FLAG_23706 = NewDouble( 2684354560.0000000000000000 );
	_58UINT_FLAG_23708 = NewDouble( 2952790016.0000000000000000 );
	_58FLOAT_FLAG_23710 = NewDouble( 3489660928.0000000000000000 );
	_58CSTRING_23712 = NewDouble( 4294967295.0000000000000000 );
	_58CBYTES_23713 = NewDouble( 2147483648.0000000000000000 );
}
