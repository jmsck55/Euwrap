// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _38fatal(int _errcode_16445, int _msg_16446, int _routine_name_16447, int _parms_16448)
{
    int _9352 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_16445;
    RefDS(_msg_16446);
    *((int *)(_2+8)) = _msg_16446;
    RefDS(_routine_name_16447);
    *((int *)(_2+12)) = _routine_name_16447;
    RefDS(_parms_16448);
    *((int *)(_2+16)) = _parms_16448;
    _9352 = MAKE_SEQ(_1);
    RefDS(_9352);
    Append(&_38vLastErrors_16442, _38vLastErrors_16442, _9352);
    DeRefDS(_9352);
    _9352 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_16446);
    DeRefDSi(_routine_name_16447);
    DeRefDS(_parms_16448);
    return;
    ;
}


int _38get4()
{
    int _9368 = NOVALUE;
    int _9367 = NOVALUE;
    int _9366 = NOVALUE;
    int _9365 = NOVALUE;
    int _9364 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9364 = getc((FILE*)xstdin);
        }
        else
        _9364 = getc(last_r_file_ptr);
    }
    else
    _9364 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem0_16460)){
        poke_addr = (unsigned char *)_38mem0_16460;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke_addr = (unsigned char)_9364;
    _9364 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9365 = getc((FILE*)xstdin);
        }
        else
        _9365 = getc(last_r_file_ptr);
    }
    else
    _9365 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem1_16461)){
        poke_addr = (unsigned char *)_38mem1_16461;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem1_16461)->dbl);
    }
    *poke_addr = (unsigned char)_9365;
    _9365 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9366 = getc((FILE*)xstdin);
        }
        else
        _9366 = getc(last_r_file_ptr);
    }
    else
    _9366 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem2_16462)){
        poke_addr = (unsigned char *)_38mem2_16462;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem2_16462)->dbl);
    }
    *poke_addr = (unsigned char)_9366;
    _9366 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9367 = getc((FILE*)xstdin);
        }
        else
        _9367 = getc(last_r_file_ptr);
    }
    else
    _9367 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem3_16463)){
        poke_addr = (unsigned char *)_38mem3_16463;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem3_16463)->dbl);
    }
    *poke_addr = (unsigned char)_9367;
    _9367 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_38mem0_16460)) {
        _9368 = *(unsigned long *)_38mem0_16460;
        if ((unsigned)_9368 > (unsigned)MAXINT)
        _9368 = NewDouble((double)(unsigned long)_9368);
    }
    else {
        _9368 = *(unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        if ((unsigned)_9368 > (unsigned)MAXINT)
        _9368 = NewDouble((double)(unsigned long)_9368);
    }
    return _9368;
    ;
}


int _38get_string()
{
    int _where_inlined_where_at_31_16487 = NOVALUE;
    int _s_16477 = NOVALUE;
    int _c_16478 = NOVALUE;
    int _i_16479 = NOVALUE;
    int _9380 = NOVALUE;
    int _9377 = NOVALUE;
    int _9375 = NOVALUE;
    int _9373 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_16477);
    _s_16477 = Repeat(0, 256);

    /** 	i = 0*/
    _i_16479 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_16478 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_16478 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_16487);
    _where_inlined_where_at_31_16487 = machine(20, _38current_db_16418);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_16487);
    *((int *)(_2+4)) = _where_inlined_where_at_31_16487;
    _9373 = MAKE_SEQ(_1);
    RefDS(_9371);
    RefDS(_9372);
    _38fatal(900, _9371, _9372, _9373);
    _9373 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_16479 = _i_16479 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_16477)){
            _9375 = SEQ_PTR(_s_16477)->length;
    }
    else {
        _9375 = 1;
    }
    if (_i_16479 <= _9375)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9377 = Repeat(0, 256);
    Concat((object_ptr)&_s_16477, _s_16477, _9377);
    DeRefDS(_9377);
    _9377 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_16477);
    _2 = (int)(((s1_ptr)_2)->base + _i_16479);
    *(int *)_2 = _c_16478;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16478 = getc((FILE*)xstdin);
        }
        else
        _c_16478 = getc(last_r_file_ptr);
    }
    else
    _c_16478 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9380;
    RHS_Slice(_s_16477, 1, _i_16479);
    DeRefDSi(_s_16477);
    return _9380;
    ;
}


int _38equal_string(int _target_16499)
{
    int _c_16500 = NOVALUE;
    int _i_16501 = NOVALUE;
    int _where_inlined_where_at_27_16507 = NOVALUE;
    int _9391 = NOVALUE;
    int _9390 = NOVALUE;
    int _9387 = NOVALUE;
    int _9385 = NOVALUE;
    int _9383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_16501 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_16500 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_16500 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_16507);
    _where_inlined_where_at_27_16507 = machine(20, _38current_db_16418);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_16507);
    *((int *)(_2+4)) = _where_inlined_where_at_27_16507;
    _9383 = MAKE_SEQ(_1);
    RefDS(_9371);
    RefDS(_9382);
    _38fatal(900, _9371, _9382, _9383);
    _9383 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_16499);
    return -404;
L4: 

    /** 		i += 1*/
    _i_16501 = _i_16501 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_16499)){
            _9385 = SEQ_PTR(_target_16499)->length;
    }
    else {
        _9385 = 1;
    }
    if (_i_16501 <= _9385)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_16499);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_16499);
    _9387 = (int)*(((s1_ptr)_2)->base + _i_16501);
    if (binary_op_a(EQUALS, _9387, _c_16500)){
        _9387 = NOVALUE;
        goto L6; // [80] 91
    }
    _9387 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_16499);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16500 = getc((FILE*)xstdin);
        }
        else
        _c_16500 = getc(last_r_file_ptr);
    }
    else
    _c_16500 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_16499)){
            _9390 = SEQ_PTR(_target_16499)->length;
    }
    else {
        _9390 = 1;
    }
    _9391 = (_i_16501 == _9390);
    _9390 = NOVALUE;
    DeRefDS(_target_16499);
    return _9391;
    ;
}


int _38decompress(int _c_16545)
{
    int _s_16546 = NOVALUE;
    int _len_16547 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_16582 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_16581 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_16595 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_16594 = NOVALUE;
    int _9446 = NOVALUE;
    int _9445 = NOVALUE;
    int _9444 = NOVALUE;
    int _9441 = NOVALUE;
    int _9436 = NOVALUE;
    int _9435 = NOVALUE;
    int _9434 = NOVALUE;
    int _9433 = NOVALUE;
    int _9432 = NOVALUE;
    int _9431 = NOVALUE;
    int _9430 = NOVALUE;
    int _9429 = NOVALUE;
    int _9428 = NOVALUE;
    int _9427 = NOVALUE;
    int _9426 = NOVALUE;
    int _9425 = NOVALUE;
    int _9424 = NOVALUE;
    int _9423 = NOVALUE;
    int _9422 = NOVALUE;
    int _9421 = NOVALUE;
    int _9420 = NOVALUE;
    int _9419 = NOVALUE;
    int _9418 = NOVALUE;
    int _9417 = NOVALUE;
    int _9416 = NOVALUE;
    int _9415 = NOVALUE;
    int _9414 = NOVALUE;
    int _9413 = NOVALUE;
    int _9412 = NOVALUE;
    int _9411 = NOVALUE;
    int _9410 = NOVALUE;
    int _9409 = NOVALUE;
    int _9408 = NOVALUE;
    int _9405 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_16545 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16545 = getc((FILE*)xstdin);
        }
        else
        _c_16545 = getc(last_r_file_ptr);
    }
    else
    _c_16545 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_16545 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9405 = _c_16545 + -9;
    DeRef(_s_16546);
    return _9405;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_16545;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9408 = getc((FILE*)xstdin);
            }
            else
            _9408 = getc(last_r_file_ptr);
        }
        else
        _9408 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9409 = getc((FILE*)xstdin);
            }
            else
            _9409 = getc(last_r_file_ptr);
        }
        else
        _9409 = getc(last_r_file_ptr);
        _9410 = 256 * _9409;
        _9409 = NOVALUE;
        _9411 = _9408 + _9410;
        _9408 = NOVALUE;
        _9410 = NOVALUE;
        _9412 = _9411 + _38MIN2B_16528;
        if ((long)((unsigned long)_9412 + (unsigned long)HIGH_BITS) >= 0) 
        _9412 = NewDouble((double)_9412);
        _9411 = NOVALUE;
        DeRef(_s_16546);
        DeRef(_9405);
        _9405 = NOVALUE;
        return _9412;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9413 = getc((FILE*)xstdin);
            }
            else
            _9413 = getc(last_r_file_ptr);
        }
        else
        _9413 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9414 = getc((FILE*)xstdin);
            }
            else
            _9414 = getc(last_r_file_ptr);
        }
        else
        _9414 = getc(last_r_file_ptr);
        _9415 = 256 * _9414;
        _9414 = NOVALUE;
        _9416 = _9413 + _9415;
        _9413 = NOVALUE;
        _9415 = NOVALUE;
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9417 = getc((FILE*)xstdin);
            }
            else
            _9417 = getc(last_r_file_ptr);
        }
        else
        _9417 = getc(last_r_file_ptr);
        _9418 = 65536 * _9417;
        _9417 = NOVALUE;
        _9419 = _9416 + _9418;
        _9416 = NOVALUE;
        _9418 = NOVALUE;
        _9420 = _9419 + _38MIN3B_16534;
        if ((long)((unsigned long)_9420 + (unsigned long)HIGH_BITS) >= 0) 
        _9420 = NewDouble((double)_9420);
        _9419 = NOVALUE;
        DeRef(_s_16546);
        DeRef(_9405);
        _9405 = NOVALUE;
        DeRef(_9412);
        _9412 = NOVALUE;
        return _9420;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9421 = _38get4();
        if (IS_ATOM_INT(_9421) && IS_ATOM_INT(_38MIN4B_16540)) {
            _9422 = _9421 + _38MIN4B_16540;
            if ((long)((unsigned long)_9422 + (unsigned long)HIGH_BITS) >= 0) 
            _9422 = NewDouble((double)_9422);
        }
        else {
            _9422 = binary_op(PLUS, _9421, _38MIN4B_16540);
        }
        DeRef(_9421);
        _9421 = NOVALUE;
        DeRef(_s_16546);
        DeRef(_9405);
        _9405 = NOVALUE;
        DeRef(_9412);
        _9412 = NOVALUE;
        DeRef(_9420);
        _9420 = NOVALUE;
        return _9422;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9423 = getc((FILE*)xstdin);
            }
            else
            _9423 = getc(last_r_file_ptr);
        }
        else
        _9423 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9424 = getc((FILE*)xstdin);
            }
            else
            _9424 = getc(last_r_file_ptr);
        }
        else
        _9424 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9425 = getc((FILE*)xstdin);
            }
            else
            _9425 = getc(last_r_file_ptr);
        }
        else
        _9425 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9426 = getc((FILE*)xstdin);
            }
            else
            _9426 = getc(last_r_file_ptr);
        }
        else
        _9426 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9423;
        *((int *)(_2+8)) = _9424;
        *((int *)(_2+12)) = _9425;
        *((int *)(_2+16)) = _9426;
        _9427 = MAKE_SEQ(_1);
        _9426 = NOVALUE;
        _9425 = NOVALUE;
        _9424 = NOVALUE;
        _9423 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16581);
        _ieee32_inlined_float32_to_atom_at_173_16581 = _9427;
        _9427 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_16582);
        _float32_to_atom_inlined_float32_to_atom_at_176_16582 = machine(49, _ieee32_inlined_float32_to_atom_at_173_16581);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16581);
        _ieee32_inlined_float32_to_atom_at_173_16581 = NOVALUE;
        DeRef(_s_16546);
        DeRef(_9405);
        _9405 = NOVALUE;
        DeRef(_9412);
        _9412 = NOVALUE;
        DeRef(_9420);
        _9420 = NOVALUE;
        DeRef(_9422);
        _9422 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_16582;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9428 = getc((FILE*)xstdin);
            }
            else
            _9428 = getc(last_r_file_ptr);
        }
        else
        _9428 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9429 = getc((FILE*)xstdin);
            }
            else
            _9429 = getc(last_r_file_ptr);
        }
        else
        _9429 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9430 = getc((FILE*)xstdin);
            }
            else
            _9430 = getc(last_r_file_ptr);
        }
        else
        _9430 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9431 = getc((FILE*)xstdin);
            }
            else
            _9431 = getc(last_r_file_ptr);
        }
        else
        _9431 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9432 = getc((FILE*)xstdin);
            }
            else
            _9432 = getc(last_r_file_ptr);
        }
        else
        _9432 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9433 = getc((FILE*)xstdin);
            }
            else
            _9433 = getc(last_r_file_ptr);
        }
        else
        _9433 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9434 = getc((FILE*)xstdin);
            }
            else
            _9434 = getc(last_r_file_ptr);
        }
        else
        _9434 = getc(last_r_file_ptr);
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9435 = getc((FILE*)xstdin);
            }
            else
            _9435 = getc(last_r_file_ptr);
        }
        else
        _9435 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9428;
        *((int *)(_2+8)) = _9429;
        *((int *)(_2+12)) = _9430;
        *((int *)(_2+16)) = _9431;
        *((int *)(_2+20)) = _9432;
        *((int *)(_2+24)) = _9433;
        *((int *)(_2+28)) = _9434;
        *((int *)(_2+32)) = _9435;
        _9436 = MAKE_SEQ(_1);
        _9435 = NOVALUE;
        _9434 = NOVALUE;
        _9433 = NOVALUE;
        _9432 = NOVALUE;
        _9431 = NOVALUE;
        _9430 = NOVALUE;
        _9429 = NOVALUE;
        _9428 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16594);
        _ieee64_inlined_float64_to_atom_at_248_16594 = _9436;
        _9436 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_16595);
        _float64_to_atom_inlined_float64_to_atom_at_251_16595 = machine(47, _ieee64_inlined_float64_to_atom_at_248_16594);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16594);
        _ieee64_inlined_float64_to_atom_at_248_16594 = NOVALUE;
        DeRef(_s_16546);
        DeRef(_9405);
        _9405 = NOVALUE;
        DeRef(_9412);
        _9412 = NOVALUE;
        DeRef(_9420);
        _9420 = NOVALUE;
        DeRef(_9422);
        _9422 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_16595;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_16545 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_38current_db_16418 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
            last_r_file_no = _38current_db_16418;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_16547 = getc((FILE*)xstdin);
            }
            else
            _len_16547 = getc(last_r_file_ptr);
        }
        else
        _len_16547 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_16547 = _38get4();
        if (!IS_ATOM_INT(_len_16547)) {
            _1 = (long)(DBL_PTR(_len_16547)->dbl);
            DeRefDS(_len_16547);
            _len_16547 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_16546);
        _s_16546 = Repeat(0, _len_16547);

        /** 			for i = 1 to len do*/
        _9441 = _len_16547;
        {
            int _i_16604;
            _i_16604 = 1;
L5: 
            if (_i_16604 > _9441){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_38current_db_16418 != last_r_file_no) {
                last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
                last_r_file_no = _38current_db_16418;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_16545 = getc((FILE*)xstdin);
                }
                else
                _c_16545 = getc(last_r_file_ptr);
            }
            else
            _c_16545 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_16545 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9444 = _c_16545 + -9;
            _2 = (int)SEQ_PTR(_s_16546);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_16546 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_16604);
            _1 = *(int *)_2;
            *(int *)_2 = _9444;
            if( _1 != _9444 ){
                DeRef(_1);
            }
            _9444 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9445);
            _9445 = _c_16545;
            _9446 = _38decompress(_9445);
            _9445 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_16546);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_16546 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_16604);
            _1 = *(int *)_2;
            *(int *)_2 = _9446;
            if( _1 != _9446 ){
                DeRef(_1);
            }
            _9446 = NOVALUE;
L8: 

            /** 			end for*/
            _i_16604 = _i_16604 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9405);
        _9405 = NOVALUE;
        DeRef(_9412);
        _9412 = NOVALUE;
        DeRef(_9420);
        _9420 = NOVALUE;
        DeRef(_9422);
        _9422 = NOVALUE;
        return _s_16546;
    ;}    ;
}


int _38compress(int _x_16615)
{
    int _x4_16616 = NOVALUE;
    int _s_16617 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_16651 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_16654 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_16659 = NOVALUE;
    int _9485 = NOVALUE;
    int _9484 = NOVALUE;
    int _9483 = NOVALUE;
    int _9481 = NOVALUE;
    int _9480 = NOVALUE;
    int _9478 = NOVALUE;
    int _9476 = NOVALUE;
    int _9475 = NOVALUE;
    int _9474 = NOVALUE;
    int _9472 = NOVALUE;
    int _9471 = NOVALUE;
    int _9470 = NOVALUE;
    int _9469 = NOVALUE;
    int _9468 = NOVALUE;
    int _9467 = NOVALUE;
    int _9466 = NOVALUE;
    int _9465 = NOVALUE;
    int _9464 = NOVALUE;
    int _9462 = NOVALUE;
    int _9461 = NOVALUE;
    int _9460 = NOVALUE;
    int _9459 = NOVALUE;
    int _9458 = NOVALUE;
    int _9457 = NOVALUE;
    int _9455 = NOVALUE;
    int _9454 = NOVALUE;
    int _9453 = NOVALUE;
    int _9452 = NOVALUE;
    int _9451 = NOVALUE;
    int _9450 = NOVALUE;
    int _9449 = NOVALUE;
    int _9448 = NOVALUE;
    int _9447 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_16615))
    _9447 = 1;
    else if (IS_ATOM_DBL(_x_16615))
    _9447 = IS_ATOM_INT(DoubleToInt(_x_16615));
    else
    _9447 = 0;
    if (_9447 == 0)
    {
        _9447 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9447 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_16615)) {
        _9448 = (_x_16615 >= -9);
    }
    else {
        _9448 = binary_op(GREATEREQ, _x_16615, -9);
    }
    if (IS_ATOM_INT(_9448)) {
        if (_9448 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9448)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_16615)) {
        _9450 = (_x_16615 <= 239);
    }
    else {
        _9450 = binary_op(LESSEQ, _x_16615, 239);
    }
    if (_9450 == 0) {
        DeRef(_9450);
        _9450 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9450) && DBL_PTR(_9450)->dbl == 0.0){
            DeRef(_9450);
            _9450 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9450);
        _9450 = NOVALUE;
    }
    DeRef(_9450);
    _9450 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_16615)) {
        _9451 = _x_16615 - -9;
        if ((long)((unsigned long)_9451 +(unsigned long) HIGH_BITS) >= 0){
            _9451 = NewDouble((double)_9451);
        }
    }
    else {
        _9451 = binary_op(MINUS, _x_16615, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9451;
    _9452 = MAKE_SEQ(_1);
    _9451 = NOVALUE;
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    return _9452;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_16615)) {
        _9453 = (_x_16615 >= _38MIN2B_16528);
    }
    else {
        _9453 = binary_op(GREATEREQ, _x_16615, _38MIN2B_16528);
    }
    if (IS_ATOM_INT(_9453)) {
        if (_9453 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9453)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_16615)) {
        _9455 = (_x_16615 <= 32767);
    }
    else {
        _9455 = binary_op(LESSEQ, _x_16615, 32767);
    }
    if (_9455 == 0) {
        DeRef(_9455);
        _9455 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9455) && DBL_PTR(_9455)->dbl == 0.0){
            DeRef(_9455);
            _9455 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9455);
        _9455 = NOVALUE;
    }
    DeRef(_9455);
    _9455 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_16615;
    if (IS_ATOM_INT(_x_16615)) {
        _x_16615 = _x_16615 - _38MIN2B_16528;
        if ((long)((unsigned long)_x_16615 +(unsigned long) HIGH_BITS) >= 0){
            _x_16615 = NewDouble((double)_x_16615);
        }
    }
    else {
        _x_16615 = binary_op(MINUS, _x_16615, _38MIN2B_16528);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_16615)) {
        {unsigned long tu;
             tu = (unsigned long)_x_16615 & (unsigned long)255;
             _9457 = MAKE_UINT(tu);
        }
    }
    else {
        _9457 = binary_op(AND_BITS, _x_16615, 255);
    }
    if (IS_ATOM_INT(_x_16615)) {
        if (256 > 0 && _x_16615 >= 0) {
            _9458 = _x_16615 / 256;
        }
        else {
            temp_dbl = floor((double)_x_16615 / (double)256);
            if (_x_16615 != MININT)
            _9458 = (long)temp_dbl;
            else
            _9458 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16615, 256);
        _9458 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _9457;
    *((int *)(_2+12)) = _9458;
    _9459 = MAKE_SEQ(_1);
    _9458 = NOVALUE;
    _9457 = NOVALUE;
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    return _9459;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_16615)) {
        _9460 = (_x_16615 >= _38MIN3B_16534);
    }
    else {
        _9460 = binary_op(GREATEREQ, _x_16615, _38MIN3B_16534);
    }
    if (IS_ATOM_INT(_9460)) {
        if (_9460 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9460)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_16615)) {
        _9462 = (_x_16615 <= 8388607);
    }
    else {
        _9462 = binary_op(LESSEQ, _x_16615, 8388607);
    }
    if (_9462 == 0) {
        DeRef(_9462);
        _9462 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9462) && DBL_PTR(_9462)->dbl == 0.0){
            DeRef(_9462);
            _9462 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9462);
        _9462 = NOVALUE;
    }
    DeRef(_9462);
    _9462 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_16615;
    if (IS_ATOM_INT(_x_16615)) {
        _x_16615 = _x_16615 - _38MIN3B_16534;
        if ((long)((unsigned long)_x_16615 +(unsigned long) HIGH_BITS) >= 0){
            _x_16615 = NewDouble((double)_x_16615);
        }
    }
    else {
        _x_16615 = binary_op(MINUS, _x_16615, _38MIN3B_16534);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_16615)) {
        {unsigned long tu;
             tu = (unsigned long)_x_16615 & (unsigned long)255;
             _9464 = MAKE_UINT(tu);
        }
    }
    else {
        _9464 = binary_op(AND_BITS, _x_16615, 255);
    }
    if (IS_ATOM_INT(_x_16615)) {
        if (256 > 0 && _x_16615 >= 0) {
            _9465 = _x_16615 / 256;
        }
        else {
            temp_dbl = floor((double)_x_16615 / (double)256);
            if (_x_16615 != MININT)
            _9465 = (long)temp_dbl;
            else
            _9465 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16615, 256);
        _9465 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9465)) {
        {unsigned long tu;
             tu = (unsigned long)_9465 & (unsigned long)255;
             _9466 = MAKE_UINT(tu);
        }
    }
    else {
        _9466 = binary_op(AND_BITS, _9465, 255);
    }
    DeRef(_9465);
    _9465 = NOVALUE;
    if (IS_ATOM_INT(_x_16615)) {
        if (65536 > 0 && _x_16615 >= 0) {
            _9467 = _x_16615 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_16615 / (double)65536);
            if (_x_16615 != MININT)
            _9467 = (long)temp_dbl;
            else
            _9467 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16615, 65536);
        _9467 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _9464;
    *((int *)(_2+12)) = _9466;
    *((int *)(_2+16)) = _9467;
    _9468 = MAKE_SEQ(_1);
    _9467 = NOVALUE;
    _9466 = NOVALUE;
    _9464 = NOVALUE;
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    DeRef(_9459);
    _9459 = NOVALUE;
    DeRef(_9460);
    _9460 = NOVALUE;
    return _9468;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_16615) && IS_ATOM_INT(_38MIN4B_16540)) {
        _9469 = _x_16615 - _38MIN4B_16540;
        if ((long)((unsigned long)_9469 +(unsigned long) HIGH_BITS) >= 0){
            _9469 = NewDouble((double)_9469);
        }
    }
    else {
        _9469 = binary_op(MINUS, _x_16615, _38MIN4B_16540);
    }
    _9470 = _8int_to_bytes(_9469);
    _9469 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9470)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9470)) {
        Prepend(&_9471, _9470, 251);
    }
    else {
        Concat((object_ptr)&_9471, 251, _9470);
    }
    DeRef(_9470);
    _9470 = NOVALUE;
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    DeRef(_9459);
    _9459 = NOVALUE;
    DeRef(_9460);
    _9460 = NOVALUE;
    DeRef(_9468);
    _9468 = NOVALUE;
    return _9471;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _9472 = IS_ATOM(_x_16615);
    if (_9472 == 0)
    {
        _9472 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _9472 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_16616);
    _x4_16616 = machine(48, _x_16615);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_16654);
    _float32_to_atom_inlined_float32_to_atom_at_203_16654 = machine(49, _x4_16616);
    if (binary_op_a(NOTEQ, _x_16615, _float32_to_atom_inlined_float32_to_atom_at_203_16654)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_9474, _x4_16616, 252);
    DeRef(_x_16615);
    DeRefDSi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    DeRef(_9459);
    _9459 = NOVALUE;
    DeRef(_9460);
    _9460 = NOVALUE;
    DeRef(_9468);
    _9468 = NOVALUE;
    DeRef(_9471);
    _9471 = NOVALUE;
    return _9474;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_16659);
    _atom_to_float64_inlined_atom_to_float64_at_229_16659 = machine(46, _x_16615);
    Prepend(&_9475, _atom_to_float64_inlined_atom_to_float64_at_229_16659, 253);
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_s_16617);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    DeRef(_9459);
    _9459 = NOVALUE;
    DeRef(_9460);
    _9460 = NOVALUE;
    DeRef(_9468);
    _9468 = NOVALUE;
    DeRef(_9471);
    _9471 = NOVALUE;
    DeRef(_9474);
    _9474 = NOVALUE;
    return _9475;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_16615)){
            _9476 = SEQ_PTR(_x_16615)->length;
    }
    else {
        _9476 = 1;
    }
    if (_9476 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_16615)){
            _9478 = SEQ_PTR(_x_16615)->length;
    }
    else {
        _9478 = 1;
    }
    DeRef(_s_16617);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _9478;
    _s_16617 = MAKE_SEQ(_1);
    _9478 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_16615)){
            _9480 = SEQ_PTR(_x_16615)->length;
    }
    else {
        _9480 = 1;
    }
    _9481 = _8int_to_bytes(_9480);
    _9480 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9481)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9481)) {
        Prepend(&_s_16617, _9481, 255);
    }
    else {
        Concat((object_ptr)&_s_16617, 255, _9481);
    }
    DeRef(_9481);
    _9481 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_16615)){
            _9483 = SEQ_PTR(_x_16615)->length;
    }
    else {
        _9483 = 1;
    }
    {
        int _i_16672;
        _i_16672 = 1;
LA: 
        if (_i_16672 > _9483){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_16615);
        _9484 = (int)*(((s1_ptr)_2)->base + _i_16672);
        Ref(_9484);
        _9485 = _38compress(_9484);
        _9484 = NOVALUE;
        if (IS_SEQUENCE(_s_16617) && IS_ATOM(_9485)) {
            Ref(_9485);
            Append(&_s_16617, _s_16617, _9485);
        }
        else if (IS_ATOM(_s_16617) && IS_SEQUENCE(_9485)) {
        }
        else {
            Concat((object_ptr)&_s_16617, _s_16617, _9485);
        }
        DeRef(_9485);
        _9485 = NOVALUE;

        /** 		end for*/
        _i_16672 = _i_16672 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_16615);
    DeRefi(_x4_16616);
    DeRef(_9448);
    _9448 = NOVALUE;
    DeRef(_9452);
    _9452 = NOVALUE;
    DeRef(_9453);
    _9453 = NOVALUE;
    DeRef(_9459);
    _9459 = NOVALUE;
    DeRef(_9460);
    _9460 = NOVALUE;
    DeRef(_9468);
    _9468 = NOVALUE;
    DeRef(_9471);
    _9471 = NOVALUE;
    DeRef(_9474);
    _9474 = NOVALUE;
    DeRef(_9475);
    _9475 = NOVALUE;
    return _s_16617;
L3: 
    ;
}


void _38safe_seek(int _pos_16691, int _msg_16692)
{
    int _eofpos_16693 = NOVALUE;
    int _seek_1__tmp_at32_16701 = NOVALUE;
    int _seek_inlined_seek_at_32_16700 = NOVALUE;
    int _where_inlined_where_at_49_16703 = NOVALUE;
    int _seek_1__tmp_at84_16711 = NOVALUE;
    int _seek_inlined_seek_at_84_16710 = NOVALUE;
    int _where_inlined_where_at_129_16719 = NOVALUE;
    int _9502 = NOVALUE;
    int _9498 = NOVALUE;
    int _9495 = NOVALUE;
    int _9492 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16418 != -1)
    goto L1; // [7] 29

    /** 		fatal(NO_DATABASE, "no current database defined", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16691);
    *((int *)(_2+4)) = _pos_16691;
    _9492 = MAKE_SEQ(_1);
    RefDS(_9490);
    RefDS(_9491);
    _38fatal(901, _9490, _9491, _9492);
    _9492 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16691);
    DeRef(_eofpos_16693);
    return;
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at32_16701);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at32_16701 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_32_16700 = machine(19, _seek_1__tmp_at32_16701);
    DeRefi(_seek_1__tmp_at32_16701);
    _seek_1__tmp_at32_16701 = NOVALUE;

    /** 	eofpos = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_eofpos_16693);
    _eofpos_16693 = machine(20, _38current_db_16418);

    /** 	if pos > eofpos then*/
    if (binary_op_a(LESSEQ, _pos_16691, _eofpos_16693)){
        goto L2; // [59] 81
    }

    /** 		fatal(BAD_SEEK, "io:seeking past EOF", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16691);
    *((int *)(_2+4)) = _pos_16691;
    _9495 = MAKE_SEQ(_1);
    RefDS(_9494);
    RefDS(_9491);
    _38fatal(902, _9494, _9491, _9495);
    _9495 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16691);
    DeRef(_eofpos_16693);
    return;
L2: 

    /** 	if io:seek(current_db, pos) != 0 then*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_16691);
    DeRef(_seek_1__tmp_at84_16711);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_16691;
    _seek_1__tmp_at84_16711 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_84_16710 = machine(19, _seek_1__tmp_at84_16711);
    DeRef(_seek_1__tmp_at84_16711);
    _seek_1__tmp_at84_16711 = NOVALUE;
    if (_seek_inlined_seek_at_84_16710 == 0)
    goto L3; // [98] 120

    /** 		fatal(BAD_SEEK, "io:seek to position failed", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16691);
    *((int *)(_2+4)) = _pos_16691;
    _9498 = MAKE_SEQ(_1);
    RefDS(_9497);
    RefDS(_9491);
    _38fatal(902, _9497, _9491, _9498);
    _9498 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16691);
    DeRef(_eofpos_16693);
    return;
L3: 

    /** 	if pos != -1 then*/
    if (binary_op_a(EQUALS, _pos_16691, -1)){
        goto L4; // [122] 160
    }

    /** 		if io:where(current_db) != pos then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_129_16719);
    _where_inlined_where_at_129_16719 = machine(20, _38current_db_16418);
    if (binary_op_a(EQUALS, _where_inlined_where_at_129_16719, _pos_16691)){
        goto L5; // [137] 159
    }

    /** 			fatal(BAD_SEEK, "io:seek not in position", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16691);
    *((int *)(_2+4)) = _pos_16691;
    _9502 = MAKE_SEQ(_1);
    RefDS(_9501);
    RefDS(_9491);
    _38fatal(902, _9501, _9491, _9502);
    _9502 = NOVALUE;

    /** 			return*/
    DeRef(_pos_16691);
    DeRef(_eofpos_16693);
    return;
L5: 
L4: 

    /** end procedure*/
    DeRef(_pos_16691);
    DeRef(_eofpos_16693);
    return;
    ;
}


int _38db_get_errors(int _clearing_16725)
{
    int _lErrors_16726 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_clearing_16725)) {
        _1 = (long)(DBL_PTR(_clearing_16725)->dbl);
        DeRefDS(_clearing_16725);
        _clearing_16725 = _1;
    }

    /** 	lErrors = vLastErrors*/
    RefDS(_38vLastErrors_16442);
    DeRef(_lErrors_16726);
    _lErrors_16726 = _38vLastErrors_16442;

    /** 	if clearing then*/
    if (_clearing_16725 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		vLastErrors = {}*/
    RefDS(_5);
    DeRefDS(_38vLastErrors_16442);
    _38vLastErrors_16442 = _5;
L1: 

    /** 	return lErrors*/
    return _lErrors_16726;
    ;
}
int db_get_errors() __attribute__ ((alias ("_38db_get_errors")));


void _38db_dump(int _file_id_16730, int _low_level_too_16731)
{
    int _magic_16732 = NOVALUE;
    int _minor_16733 = NOVALUE;
    int _major_16734 = NOVALUE;
    int _fn_16735 = NOVALUE;
    int _tables_16736 = NOVALUE;
    int _ntables_16737 = NOVALUE;
    int _tname_16738 = NOVALUE;
    int _trecords_16739 = NOVALUE;
    int _t_header_16740 = NOVALUE;
    int _tnrecs_16741 = NOVALUE;
    int _key_ptr_16742 = NOVALUE;
    int _data_ptr_16743 = NOVALUE;
    int _size_16744 = NOVALUE;
    int _addr_16745 = NOVALUE;
    int _tindex_16746 = NOVALUE;
    int _fbp_16747 = NOVALUE;
    int _key_16748 = NOVALUE;
    int _data_16749 = NOVALUE;
    int _c_16750 = NOVALUE;
    int _n_16751 = NOVALUE;
    int _tblocks_16752 = NOVALUE;
    int _a_16753 = NOVALUE;
    int _ll_line_16754 = NOVALUE;
    int _hi_16755 = NOVALUE;
    int _ci_16756 = NOVALUE;
    int _now_1__tmp_at77_16771 = NOVALUE;
    int _now_inlined_now_at_77_16770 = NOVALUE;
    int _seek_1__tmp_at105_16777 = NOVALUE;
    int _seek_inlined_seek_at_105_16776 = NOVALUE;
    int _get1_inlined_get1_at_135_16782 = NOVALUE;
    int _get1_inlined_get1_at_159_16788 = NOVALUE;
    int _get1_inlined_get1_at_169_16790 = NOVALUE;
    int _seek_1__tmp_at196_16796 = NOVALUE;
    int _seek_inlined_seek_at_196_16795 = NOVALUE;
    int _seek_1__tmp_at282_16812 = NOVALUE;
    int _seek_inlined_seek_at_282_16811 = NOVALUE;
    int _seek_1__tmp_at556_16851 = NOVALUE;
    int _seek_inlined_seek_at_556_16850 = NOVALUE;
    int _get1_inlined_get1_at_571_16853 = NOVALUE;
    int _get1_inlined_get1_at_606_16859 = NOVALUE;
    int _get1_inlined_get1_at_616_16861 = NOVALUE;
    int _seek_1__tmp_at643_16867 = NOVALUE;
    int _seek_inlined_seek_at_643_16866 = NOVALUE;
    int _where_inlined_where_at_665_16870 = NOVALUE;
    int _seek_1__tmp_at730_16884 = NOVALUE;
    int _seek_inlined_seek_at_730_16883 = NOVALUE;
    int _seek_1__tmp_at821_16905 = NOVALUE;
    int _seek_inlined_seek_at_821_16904 = NOVALUE;
    int _pos_inlined_seek_at_818_16903 = NOVALUE;
    int _seek_1__tmp_at917_16927 = NOVALUE;
    int _seek_inlined_seek_at_917_16926 = NOVALUE;
    int _pos_inlined_seek_at_914_16925 = NOVALUE;
    int _seek_1__tmp_at953_16934 = NOVALUE;
    int _seek_inlined_seek_at_953_16933 = NOVALUE;
    int _seek_1__tmp_at1012_16944 = NOVALUE;
    int _seek_inlined_seek_at_1012_16943 = NOVALUE;
    int _seek_1__tmp_at1083_16953 = NOVALUE;
    int _seek_inlined_seek_at_1083_16952 = NOVALUE;
    int _seek_1__tmp_at1117_16958 = NOVALUE;
    int _seek_inlined_seek_at_1117_16957 = NOVALUE;
    int _seek_1__tmp_at1178_16968 = NOVALUE;
    int _seek_inlined_seek_at_1178_16967 = NOVALUE;
    int _9623 = NOVALUE;
    int _9621 = NOVALUE;
    int _9617 = NOVALUE;
    int _9605 = NOVALUE;
    int _9599 = NOVALUE;
    int _9596 = NOVALUE;
    int _9595 = NOVALUE;
    int _9594 = NOVALUE;
    int _9593 = NOVALUE;
    int _9592 = NOVALUE;
    int _9591 = NOVALUE;
    int _9590 = NOVALUE;
    int _9588 = NOVALUE;
    int _9587 = NOVALUE;
    int _9582 = NOVALUE;
    int _9581 = NOVALUE;
    int _9580 = NOVALUE;
    int _9579 = NOVALUE;
    int _9578 = NOVALUE;
    int _9577 = NOVALUE;
    int _9576 = NOVALUE;
    int _9574 = NOVALUE;
    int _9572 = NOVALUE;
    int _9571 = NOVALUE;
    int _9563 = NOVALUE;
    int _9559 = NOVALUE;
    int _9557 = NOVALUE;
    int _9555 = NOVALUE;
    int _9554 = NOVALUE;
    int _9550 = NOVALUE;
    int _9549 = NOVALUE;
    int _9548 = NOVALUE;
    int _9545 = NOVALUE;
    int _9542 = NOVALUE;
    int _9540 = NOVALUE;
    int _9539 = NOVALUE;
    int _9536 = NOVALUE;
    int _9533 = NOVALUE;
    int _9530 = NOVALUE;
    int _9529 = NOVALUE;
    int _9525 = NOVALUE;
    int _9524 = NOVALUE;
    int _9523 = NOVALUE;
    int _9519 = NOVALUE;
    int _9514 = NOVALUE;
    int _9513 = NOVALUE;
    int _9512 = NOVALUE;
    int _9509 = NOVALUE;
    int _9503 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_level_too_16731)) {
        _1 = (long)(DBL_PTR(_low_level_too_16731)->dbl);
        DeRefDS(_low_level_too_16731);
        _low_level_too_16731 = _1;
    }

    /** 	if sequence(file_id) then*/
    _9503 = IS_SEQUENCE(_file_id_16730);
    if (_9503 == 0)
    {
        _9503 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _9503 = NOVALUE;
    }

    /** 		fn = open(file_id, "w")*/
    _fn_16735 = EOpen(_file_id_16730, _1272, 0);
    goto L2; // [18] 50
L1: 

    /** 	elsif file_id > 0 then*/
    if (binary_op_a(LESSEQ, _file_id_16730, 0)){
        goto L3; // [23] 42
    }

    /** 		fn = file_id*/
    Ref(_file_id_16730);
    _fn_16735 = _file_id_16730;
    if (!IS_ATOM_INT(_fn_16735)) {
        _1 = (long)(DBL_PTR(_fn_16735)->dbl);
        DeRefDS(_fn_16735);
        _fn_16735 = _1;
    }

    /** 		puts(fn, '\n')*/
    EPuts(_fn_16735, 10); // DJP 
    goto L2; // [39] 50
L3: 

    /** 		fn = file_id*/
    Ref(_file_id_16730);
    _fn_16735 = _file_id_16730;
    if (!IS_ATOM_INT(_fn_16735)) {
        _1 = (long)(DBL_PTR(_fn_16735)->dbl);
        DeRefDS(_fn_16735);
        _fn_16735 = _1;
    }
L2: 

    /** 	if fn <= 0 then*/
    if (_fn_16735 > 0)
    goto L4; // [54] 76

    /** 		fatal( BAD_FILE, "bad file", "db_dump", {file_id, low_level_too})*/
    Ref(_file_id_16730);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_id_16730;
    ((int *)_2)[2] = _low_level_too_16731;
    _9509 = MAKE_SEQ(_1);
    RefDS(_9507);
    RefDS(_9508);
    _38fatal(908, _9507, _9508, _9509);
    _9509 = NOVALUE;

    /** 		return*/
    DeRef(_file_id_16730);
    DeRef(_tables_16736);
    DeRef(_ntables_16737);
    DeRef(_tname_16738);
    DeRef(_trecords_16739);
    DeRef(_t_header_16740);
    DeRef(_tnrecs_16741);
    DeRef(_key_ptr_16742);
    DeRef(_data_ptr_16743);
    DeRef(_size_16744);
    DeRef(_addr_16745);
    DeRef(_tindex_16746);
    DeRef(_fbp_16747);
    DeRef(_key_16748);
    DeRef(_data_16749);
    DeRef(_a_16753);
    DeRef(_ll_line_16754);
    return;
L4: 

    /** 	printf(fn, "Database dump as at %s\n", {datetime:format( datetime:now(), "%Y-%m-%d %H:%M:%S")})*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at77_16771);
    _now_1__tmp_at77_16771 = Date();
    RefDS(_now_1__tmp_at77_16771);
    _0 = _now_inlined_now_at_77_16770;
    _now_inlined_now_at_77_16770 = _12from_date(_now_1__tmp_at77_16771);
    DeRef(_0);
    DeRefi(_now_1__tmp_at77_16771);
    _now_1__tmp_at77_16771 = NOVALUE;
    Ref(_now_inlined_now_at_77_16770);
    RefDS(_9511);
    _9512 = _12format(_now_inlined_now_at_77_16770, _9511);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9512;
    _9513 = MAKE_SEQ(_1);
    _9512 = NOVALUE;
    EPrintf(_fn_16735, _9510, _9513);
    DeRefDS(_9513);
    _9513 = NOVALUE;

    /** 	io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at105_16777);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at105_16777 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_105_16776 = machine(19, _seek_1__tmp_at105_16777);
    DeRefi(_seek_1__tmp_at105_16777);
    _seek_1__tmp_at105_16777 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _9514 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _9514 = 1;
    }
    if (_9514 <= 0)
    goto L5; // [126] 134
    DeRef(_file_id_16730);
    DeRef(_tables_16736);
    DeRef(_ntables_16737);
    DeRef(_tname_16738);
    DeRef(_trecords_16739);
    DeRef(_t_header_16740);
    DeRef(_tnrecs_16741);
    DeRef(_key_ptr_16742);
    DeRef(_data_ptr_16743);
    DeRef(_size_16744);
    DeRef(_addr_16745);
    DeRef(_tindex_16746);
    DeRef(_fbp_16747);
    DeRef(_key_16748);
    DeRef(_data_16749);
    DeRef(_a_16753);
    DeRef(_ll_line_16754);
    return;
L5: 

    /** 	magic = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_16732 = getc((FILE*)xstdin);
        }
        else
        _magic_16732 = getc(last_r_file_ptr);
    }
    else
    _magic_16732 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_16732 == 77)
    goto L6; // [146] 158

    /** 		puts(fn, "This is not a Euphoria Database file.\n")*/
    EPuts(_fn_16735, _9517); // DJP 
    goto L7; // [155] 261
L6: 

    /** 		major = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _major_16734 = getc((FILE*)xstdin);
        }
        else
        _major_16734 = getc(last_r_file_ptr);
    }
    else
    _major_16734 = getc(last_r_file_ptr);

    /** 		minor = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _minor_16733 = getc((FILE*)xstdin);
        }
        else
        _minor_16733 = getc(last_r_file_ptr);
    }
    else
    _minor_16733 = getc(last_r_file_ptr);

    /** 		printf(fn, "Euphoria Database System Version %d.%d\n\n", {major, minor})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _major_16734;
    ((int *)_2)[2] = _minor_16733;
    _9519 = MAKE_SEQ(_1);
    EPrintf(_fn_16735, _9518, _9519);
    DeRefDS(_9519);
    _9519 = NOVALUE;

    /** 		tables = get4()*/
    _0 = _tables_16736;
    _tables_16736 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_16736);
    DeRef(_seek_1__tmp_at196_16796);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_16736;
    _seek_1__tmp_at196_16796 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_16795 = machine(19, _seek_1__tmp_at196_16796);
    DeRef(_seek_1__tmp_at196_16796);
    _seek_1__tmp_at196_16796 = NOVALUE;

    /** 		ntables = get4()*/
    _0 = _ntables_16737;
    _ntables_16737 = _38get4();
    DeRef(_0);

    /** 		printf(fn, "The \"%s\" database has %d table",*/
    _9523 = find_from(_38current_db_16418, _38db_file_nums_16422, 1);
    _2 = (int)SEQ_PTR(_38db_names_16421);
    _9524 = (int)*(((s1_ptr)_2)->base + _9523);
    Ref(_ntables_16737);
    Ref(_9524);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9524;
    ((int *)_2)[2] = _ntables_16737;
    _9525 = MAKE_SEQ(_1);
    _9524 = NOVALUE;
    EPrintf(_fn_16735, _9522, _9525);
    DeRefDS(_9525);
    _9525 = NOVALUE;

    /** 		if ntables = 1 then*/
    if (binary_op_a(NOTEQ, _ntables_16737, 1)){
        goto L8; // [242] 254
    }

    /** 			puts(fn, "\n")*/
    EPuts(_fn_16735, _1297); // DJP 
    goto L9; // [251] 260
L8: 

    /** 			puts(fn, "s\n")*/
    EPuts(_fn_16735, _9527); // DJP 
L9: 
L7: 

    /** 	if low_level_too then*/
    if (_low_level_too_16731 == 0)
    {
        goto LA; // [263] 553
    }
    else{
    }

    /** 		puts(fn, "            Disk Dump\nDiskAddr " & repeat('-', 58))*/
    _9529 = Repeat(45, 58);
    Concat((object_ptr)&_9530, _9528, _9529);
    DeRefDS(_9529);
    _9529 = NOVALUE;
    EPuts(_fn_16735, _9530); // DJP 
    DeRefDS(_9530);
    _9530 = NOVALUE;

    /** 		io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at282_16812);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at282_16812 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_282_16811 = machine(19, _seek_1__tmp_at282_16812);
    DeRefi(_seek_1__tmp_at282_16812);
    _seek_1__tmp_at282_16812 = NOVALUE;

    /** 		a = 0*/
    DeRef(_a_16753);
    _a_16753 = 0;

    /** 		while c >= 0 with entry do*/
    goto LB; // [303] 515
LC: 
    if (_c_16750 < 0)
    goto LD; // [308] 527

    /** 			if c = -1 then*/
    if (_c_16750 != -1)
    goto LE; // [314] 323

    /** 				exit*/
    goto LD; // [320] 527
LE: 

    /** 			if remainder(a, 16) = 0 then*/
    if (IS_ATOM_INT(_a_16753)) {
        _9533 = (_a_16753 % 16);
    }
    else {
        temp_d.dbl = (double)16;
        _9533 = Dremainder(DBL_PTR(_a_16753), &temp_d);
    }
    if (binary_op_a(NOTEQ, _9533, 0)){
        DeRef(_9533);
        _9533 = NOVALUE;
        goto LF; // [329] 406
    }
    DeRef(_9533);
    _9533 = NOVALUE;

    /** 				if a > 0 then*/
    if (binary_op_a(LESSEQ, _a_16753, 0)){
        goto L10; // [335] 354
    }

    /** 					printf(fn, "%s\n", {ll_line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ll_line_16754);
    *((int *)(_2+4)) = _ll_line_16754;
    _9536 = MAKE_SEQ(_1);
    EPrintf(_fn_16735, _9295, _9536);
    DeRefDS(_9536);
    _9536 = NOVALUE;
    goto L11; // [351] 360
L10: 

    /** 					puts(fn, '\n')*/
    EPuts(_fn_16735, 10); // DJP 
L11: 

    /** 				ll_line = repeat(' ', 67)*/
    DeRef(_ll_line_16754);
    _ll_line_16754 = Repeat(32, 67);

    /** 				ll_line[9] = ':'*/
    _2 = (int)SEQ_PTR(_ll_line_16754);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_16754 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = 58;

    /** 				ll_line[48] = '|'*/
    _2 = (int)SEQ_PTR(_ll_line_16754);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_16754 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    *(int *)_2 = 124;

    /** 				ll_line[67] = '|'*/
    _2 = (int)SEQ_PTR(_ll_line_16754);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_16754 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    *(int *)_2 = 124;

    /** 				hi = 11*/
    _hi_16755 = 11;

    /** 				ci = 50*/
    _ci_16756 = 50;

    /** 				ll_line[1..8] = sprintf("%08x", a)*/
    _9539 = EPrintf(-9999999, _9538, _a_16753);
    assign_slice_seq = (s1_ptr *)&_ll_line_16754;
    AssignSlice(1, 8, _9539);
    DeRefDS(_9539);
    _9539 = NOVALUE;
LF: 

    /** 			ll_line[hi .. hi + 1] = sprintf("%02x", c)*/
    _9540 = _hi_16755 + 1;
    if (_9540 > MAXINT){
        _9540 = NewDouble((double)_9540);
    }
    _9542 = EPrintf(-9999999, _9541, _c_16750);
    assign_slice_seq = (s1_ptr *)&_ll_line_16754;
    AssignSlice(_hi_16755, _9540, _9542);
    DeRef(_9540);
    _9540 = NOVALUE;
    DeRefDS(_9542);
    _9542 = NOVALUE;

    /** 			hi += 2*/
    _hi_16755 = _hi_16755 + 2;

    /** 			if eu:find(hi, {19, 28, 38}) then*/
    _9545 = find_from(_hi_16755, _9544, 1);
    if (_9545 == 0)
    {
        _9545 = NOVALUE;
        goto L12; // [438] 460
    }
    else{
        _9545 = NOVALUE;
    }

    /** 				hi += 1*/
    _hi_16755 = _hi_16755 + 1;

    /** 				if hi = 29 then*/
    if (_hi_16755 != 29)
    goto L13; // [449] 459

    /** 					hi = 30*/
    _hi_16755 = 30;
L13: 
L12: 

    /** 			if c > ' ' and c < '~' then*/
    _9548 = (_c_16750 > 32);
    if (_9548 == 0) {
        goto L14; // [466] 489
    }
    _9550 = (_c_16750 < 126);
    if (_9550 == 0)
    {
        DeRef(_9550);
        _9550 = NOVALUE;
        goto L14; // [475] 489
    }
    else{
        DeRef(_9550);
        _9550 = NOVALUE;
    }

    /** 				ll_line[ci] = c*/
    _2 = (int)SEQ_PTR(_ll_line_16754);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_16754 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ci_16756);
    _1 = *(int *)_2;
    *(int *)_2 = _c_16750;
    DeRef(_1);
    goto L15; // [486] 498
L14: 

    /** 				ll_line[ci] = '.'*/
    _2 = (int)SEQ_PTR(_ll_line_16754);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_16754 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ci_16756);
    _1 = *(int *)_2;
    *(int *)_2 = 46;
    DeRef(_1);
L15: 

    /** 			ci += 1*/
    _ci_16756 = _ci_16756 + 1;

    /** 			a += 1*/
    _0 = _a_16753;
    if (IS_ATOM_INT(_a_16753)) {
        _a_16753 = _a_16753 + 1;
        if (_a_16753 > MAXINT){
            _a_16753 = NewDouble((double)_a_16753);
        }
    }
    else
    _a_16753 = binary_op(PLUS, 1, _a_16753);
    DeRef(_0);

    /** 		  entry*/
LB: 

    /** 			c = getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16750 = getc((FILE*)xstdin);
        }
        else
        _c_16750 = getc(last_r_file_ptr);
    }
    else
    _c_16750 = getc(last_r_file_ptr);

    /** 		end while*/
    goto LC; // [524] 306
LD: 

    /** 		printf(fn, "%s\n", {ll_line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ll_line_16754);
    *((int *)(_2+4)) = _ll_line_16754;
    _9554 = MAKE_SEQ(_1);
    EPrintf(_fn_16735, _9295, _9554);
    DeRefDS(_9554);
    _9554 = NOVALUE;

    /** 		puts(fn, repeat('-', 67) & "\n\n")*/
    _9555 = Repeat(45, 67);
    Concat((object_ptr)&_9557, _9555, _9556);
    DeRefDS(_9555);
    _9555 = NOVALUE;
    DeRef(_9555);
    _9555 = NOVALUE;
    EPuts(_fn_16735, _9557); // DJP 
    DeRefDS(_9557);
    _9557 = NOVALUE;
LA: 

    /** 	io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at556_16851);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at556_16851 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_556_16850 = machine(19, _seek_1__tmp_at556_16851);
    DeRefi(_seek_1__tmp_at556_16851);
    _seek_1__tmp_at556_16851 = NOVALUE;

    /** 	magic = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_16732 = getc((FILE*)xstdin);
        }
        else
        _magic_16732 = getc(last_r_file_ptr);
    }
    else
    _magic_16732 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_16732 == 77)
    goto L16; // [582] 605

    /** 		if sequence(file_id) then*/
    _9559 = IS_SEQUENCE(_file_id_16730);
    if (_9559 == 0)
    {
        _9559 = NOVALUE;
        goto L17; // [591] 599
    }
    else{
        _9559 = NOVALUE;
    }

    /** 			close(fn)*/
    EClose(_fn_16735);
L17: 

    /** 		return*/
    DeRef(_file_id_16730);
    DeRef(_tables_16736);
    DeRef(_ntables_16737);
    DeRef(_tname_16738);
    DeRef(_trecords_16739);
    DeRef(_t_header_16740);
    DeRef(_tnrecs_16741);
    DeRef(_key_ptr_16742);
    DeRef(_data_ptr_16743);
    DeRef(_size_16744);
    DeRef(_addr_16745);
    DeRef(_tindex_16746);
    DeRef(_fbp_16747);
    DeRef(_key_16748);
    DeRef(_data_16749);
    DeRef(_a_16753);
    DeRef(_ll_line_16754);
    DeRef(_9548);
    _9548 = NOVALUE;
    return;
L16: 

    /** 	major = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _major_16734 = getc((FILE*)xstdin);
        }
        else
        _major_16734 = getc(last_r_file_ptr);
    }
    else
    _major_16734 = getc(last_r_file_ptr);

    /** 	minor = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16418 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16418, EF_READ);
        last_r_file_no = _38current_db_16418;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _minor_16733 = getc((FILE*)xstdin);
        }
        else
        _minor_16733 = getc(last_r_file_ptr);
    }
    else
    _minor_16733 = getc(last_r_file_ptr);

    /** 	tables = get4()*/
    _0 = _tables_16736;
    _tables_16736 = _38get4();
    DeRef(_0);

    /** 	if low_level_too then printf(fn, "[tables:#%08x]\n", tables) end if*/
    if (_low_level_too_16731 == 0)
    {
        goto L18; // [632] 640
    }
    else{
    }
    EPrintf(_fn_16735, _9561, _tables_16736);
L18: 

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_16736);
    DeRef(_seek_1__tmp_at643_16867);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_16736;
    _seek_1__tmp_at643_16867 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_643_16866 = machine(19, _seek_1__tmp_at643_16867);
    DeRef(_seek_1__tmp_at643_16867);
    _seek_1__tmp_at643_16867 = NOVALUE;

    /** 	ntables = get4()*/
    _0 = _ntables_16737;
    _ntables_16737 = _38get4();
    DeRef(_0);

    /** 	t_header = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_t_header_16740);
    _t_header_16740 = machine(20, _38current_db_16418);

    /** 	for t = 1 to ntables do*/
    Ref(_ntables_16737);
    DeRef(_9563);
    _9563 = _ntables_16737;
    {
        int _t_16872;
        _t_16872 = 1;
L19: 
        if (binary_op_a(GREATER, _t_16872, _9563)){
            goto L1A; // [678] 1104
        }

        /** 		if low_level_too then printf(fn, "\n---------------\n[table header:#%08x]\n", t_header) end if*/
        if (_low_level_too_16731 == 0)
        {
            goto L1B; // [687] 695
        }
        else{
        }
        EPrintf(_fn_16735, _9564, _t_header_16740);
L1B: 

        /** 		tname = get4()*/
        _0 = _tname_16738;
        _tname_16738 = _38get4();
        DeRef(_0);

        /** 		tnrecs = get4()*/
        _0 = _tnrecs_16741;
        _tnrecs_16741 = _38get4();
        DeRef(_0);

        /** 		tblocks = get4()*/
        _tblocks_16752 = _38get4();
        if (!IS_ATOM_INT(_tblocks_16752)) {
            _1 = (long)(DBL_PTR(_tblocks_16752)->dbl);
            DeRefDS(_tblocks_16752);
            _tblocks_16752 = _1;
        }

        /** 		tindex = get4()*/
        _0 = _tindex_16746;
        _tindex_16746 = _38get4();
        DeRef(_0);

        /** 		if low_level_too then printf(fn, "[table name:#%08x]\n", tname) end if*/
        if (_low_level_too_16731 == 0)
        {
            goto L1C; // [719] 727
        }
        else{
        }
        EPrintf(_fn_16735, _9569, _tname_16738);
L1C: 

        /** 		io:seek(current_db, tname)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_tname_16738);
        DeRef(_seek_1__tmp_at730_16884);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _tname_16738;
        _seek_1__tmp_at730_16884 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_730_16883 = machine(19, _seek_1__tmp_at730_16884);
        DeRef(_seek_1__tmp_at730_16884);
        _seek_1__tmp_at730_16884 = NOVALUE;

        /** 		printf(fn, "\ntable \"%s\", records:%d    indexblks: %d\n\n\n", {get_string(), tnrecs, tblocks})*/
        _9571 = _38get_string();
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9571;
        Ref(_tnrecs_16741);
        *((int *)(_2+8)) = _tnrecs_16741;
        *((int *)(_2+12)) = _tblocks_16752;
        _9572 = MAKE_SEQ(_1);
        _9571 = NOVALUE;
        EPrintf(_fn_16735, _9570, _9572);
        DeRefDS(_9572);
        _9572 = NOVALUE;

        /** 		if tnrecs > 0 then*/
        if (binary_op_a(LESSEQ, _tnrecs_16741, 0)){
            goto L1D; // [761] 1074
        }

        /** 			for b = 1 to tblocks do*/
        _9574 = _tblocks_16752;
        {
            int _b_16891;
            _b_16891 = 1;
L1E: 
            if (_b_16891 > _9574){
                goto L1F; // [770] 1073
            }

            /** 				if low_level_too then printf(fn, "[table block %d:#%08x]\n", {b, tindex+(b-1)*8}) end if*/
            if (_low_level_too_16731 == 0)
            {
                goto L20; // [779] 803
            }
            else{
            }
            _9576 = _b_16891 - 1;
            if (_9576 == (short)_9576)
            _9577 = _9576 * 8;
            else
            _9577 = NewDouble(_9576 * (double)8);
            _9576 = NOVALUE;
            if (IS_ATOM_INT(_tindex_16746) && IS_ATOM_INT(_9577)) {
                _9578 = _tindex_16746 + _9577;
                if ((long)((unsigned long)_9578 + (unsigned long)HIGH_BITS) >= 0) 
                _9578 = NewDouble((double)_9578);
            }
            else {
                if (IS_ATOM_INT(_tindex_16746)) {
                    _9578 = NewDouble((double)_tindex_16746 + DBL_PTR(_9577)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_9577)) {
                        _9578 = NewDouble(DBL_PTR(_tindex_16746)->dbl + (double)_9577);
                    }
                    else
                    _9578 = NewDouble(DBL_PTR(_tindex_16746)->dbl + DBL_PTR(_9577)->dbl);
                }
            }
            DeRef(_9577);
            _9577 = NOVALUE;
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _b_16891;
            ((int *)_2)[2] = _9578;
            _9579 = MAKE_SEQ(_1);
            _9578 = NOVALUE;
            EPrintf(_fn_16735, _9575, _9579);
            DeRefDS(_9579);
            _9579 = NOVALUE;
L20: 

            /** 				io:seek(current_db, tindex+(b-1)*8)*/
            _9580 = _b_16891 - 1;
            if (_9580 == (short)_9580)
            _9581 = _9580 * 8;
            else
            _9581 = NewDouble(_9580 * (double)8);
            _9580 = NOVALUE;
            if (IS_ATOM_INT(_tindex_16746) && IS_ATOM_INT(_9581)) {
                _9582 = _tindex_16746 + _9581;
                if ((long)((unsigned long)_9582 + (unsigned long)HIGH_BITS) >= 0) 
                _9582 = NewDouble((double)_9582);
            }
            else {
                if (IS_ATOM_INT(_tindex_16746)) {
                    _9582 = NewDouble((double)_tindex_16746 + DBL_PTR(_9581)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_9581)) {
                        _9582 = NewDouble(DBL_PTR(_tindex_16746)->dbl + (double)_9581);
                    }
                    else
                    _9582 = NewDouble(DBL_PTR(_tindex_16746)->dbl + DBL_PTR(_9581)->dbl);
                }
            }
            DeRef(_9581);
            _9581 = NOVALUE;
            DeRef(_pos_inlined_seek_at_818_16903);
            _pos_inlined_seek_at_818_16903 = _9582;
            _9582 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_818_16903);
            DeRef(_seek_1__tmp_at821_16905);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16418;
            ((int *)_2)[2] = _pos_inlined_seek_at_818_16903;
            _seek_1__tmp_at821_16905 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_821_16904 = machine(19, _seek_1__tmp_at821_16905);
            DeRef(_pos_inlined_seek_at_818_16903);
            _pos_inlined_seek_at_818_16903 = NOVALUE;
            DeRef(_seek_1__tmp_at821_16905);
            _seek_1__tmp_at821_16905 = NOVALUE;

            /** 				tnrecs = get4()*/
            _0 = _tnrecs_16741;
            _tnrecs_16741 = _38get4();
            DeRef(_0);

            /** 				trecords = get4()*/
            _0 = _trecords_16739;
            _trecords_16739 = _38get4();
            DeRef(_0);

            /** 				if tnrecs > 0 then*/
            if (binary_op_a(LESSEQ, _tnrecs_16741, 0)){
                goto L21; // [847] 1059
            }

            /** 					printf(fn, "\n--------------------------\nblock #%d, ptrs:%d\n--------------------------\n", {b, tnrecs})*/
            Ref(_tnrecs_16741);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _b_16891;
            ((int *)_2)[2] = _tnrecs_16741;
            _9587 = MAKE_SEQ(_1);
            EPrintf(_fn_16735, _9586, _9587);
            DeRefDS(_9587);
            _9587 = NOVALUE;

            /** 					for r = 1 to tnrecs do*/
            Ref(_tnrecs_16741);
            DeRef(_9588);
            _9588 = _tnrecs_16741;
            {
                int _r_16913;
                _r_16913 = 1;
L22: 
                if (binary_op_a(GREATER, _r_16913, _9588)){
                    goto L23; // [866] 1056
                }

                /** 						if low_level_too then printf(fn, "[record %d:#%08x]\n", {r, trecords+(r-1)*4}) end if*/
                if (_low_level_too_16731 == 0)
                {
                    goto L24; // [875] 899
                }
                else{
                }
                if (IS_ATOM_INT(_r_16913)) {
                    _9590 = _r_16913 - 1;
                    if ((long)((unsigned long)_9590 +(unsigned long) HIGH_BITS) >= 0){
                        _9590 = NewDouble((double)_9590);
                    }
                }
                else {
                    _9590 = NewDouble(DBL_PTR(_r_16913)->dbl - (double)1);
                }
                if (IS_ATOM_INT(_9590)) {
                    if (_9590 == (short)_9590)
                    _9591 = _9590 * 4;
                    else
                    _9591 = NewDouble(_9590 * (double)4);
                }
                else {
                    _9591 = NewDouble(DBL_PTR(_9590)->dbl * (double)4);
                }
                DeRef(_9590);
                _9590 = NOVALUE;
                if (IS_ATOM_INT(_trecords_16739) && IS_ATOM_INT(_9591)) {
                    _9592 = _trecords_16739 + _9591;
                    if ((long)((unsigned long)_9592 + (unsigned long)HIGH_BITS) >= 0) 
                    _9592 = NewDouble((double)_9592);
                }
                else {
                    if (IS_ATOM_INT(_trecords_16739)) {
                        _9592 = NewDouble((double)_trecords_16739 + DBL_PTR(_9591)->dbl);
                    }
                    else {
                        if (IS_ATOM_INT(_9591)) {
                            _9592 = NewDouble(DBL_PTR(_trecords_16739)->dbl + (double)_9591);
                        }
                        else
                        _9592 = NewDouble(DBL_PTR(_trecords_16739)->dbl + DBL_PTR(_9591)->dbl);
                    }
                }
                DeRef(_9591);
                _9591 = NOVALUE;
                Ref(_r_16913);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_16913;
                ((int *)_2)[2] = _9592;
                _9593 = MAKE_SEQ(_1);
                _9592 = NOVALUE;
                EPrintf(_fn_16735, _9589, _9593);
                DeRefDS(_9593);
                _9593 = NOVALUE;
L24: 

                /** 						io:seek(current_db, trecords+(r-1)*4)*/
                if (IS_ATOM_INT(_r_16913)) {
                    _9594 = _r_16913 - 1;
                    if ((long)((unsigned long)_9594 +(unsigned long) HIGH_BITS) >= 0){
                        _9594 = NewDouble((double)_9594);
                    }
                }
                else {
                    _9594 = NewDouble(DBL_PTR(_r_16913)->dbl - (double)1);
                }
                if (IS_ATOM_INT(_9594)) {
                    if (_9594 == (short)_9594)
                    _9595 = _9594 * 4;
                    else
                    _9595 = NewDouble(_9594 * (double)4);
                }
                else {
                    _9595 = NewDouble(DBL_PTR(_9594)->dbl * (double)4);
                }
                DeRef(_9594);
                _9594 = NOVALUE;
                if (IS_ATOM_INT(_trecords_16739) && IS_ATOM_INT(_9595)) {
                    _9596 = _trecords_16739 + _9595;
                    if ((long)((unsigned long)_9596 + (unsigned long)HIGH_BITS) >= 0) 
                    _9596 = NewDouble((double)_9596);
                }
                else {
                    if (IS_ATOM_INT(_trecords_16739)) {
                        _9596 = NewDouble((double)_trecords_16739 + DBL_PTR(_9595)->dbl);
                    }
                    else {
                        if (IS_ATOM_INT(_9595)) {
                            _9596 = NewDouble(DBL_PTR(_trecords_16739)->dbl + (double)_9595);
                        }
                        else
                        _9596 = NewDouble(DBL_PTR(_trecords_16739)->dbl + DBL_PTR(_9595)->dbl);
                    }
                }
                DeRef(_9595);
                _9595 = NOVALUE;
                DeRef(_pos_inlined_seek_at_914_16925);
                _pos_inlined_seek_at_914_16925 = _9596;
                _9596 = NOVALUE;

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_pos_inlined_seek_at_914_16925);
                DeRef(_seek_1__tmp_at917_16927);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16418;
                ((int *)_2)[2] = _pos_inlined_seek_at_914_16925;
                _seek_1__tmp_at917_16927 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_917_16926 = machine(19, _seek_1__tmp_at917_16927);
                DeRef(_pos_inlined_seek_at_914_16925);
                _pos_inlined_seek_at_914_16925 = NOVALUE;
                DeRef(_seek_1__tmp_at917_16927);
                _seek_1__tmp_at917_16927 = NOVALUE;

                /** 						key_ptr = get4()*/
                _0 = _key_ptr_16742;
                _key_ptr_16742 = _38get4();
                DeRef(_0);

                /** 						if low_level_too then printf(fn, "[key %d:#%08x]\n", {r, key_ptr}) end if*/
                if (_low_level_too_16731 == 0)
                {
                    goto L25; // [938] 950
                }
                else{
                }
                Ref(_key_ptr_16742);
                Ref(_r_16913);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_16913;
                ((int *)_2)[2] = _key_ptr_16742;
                _9599 = MAKE_SEQ(_1);
                EPrintf(_fn_16735, _9598, _9599);
                DeRefDS(_9599);
                _9599 = NOVALUE;
L25: 

                /** 						io:seek(current_db, key_ptr)*/

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_key_ptr_16742);
                DeRef(_seek_1__tmp_at953_16934);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16418;
                ((int *)_2)[2] = _key_ptr_16742;
                _seek_1__tmp_at953_16934 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_953_16933 = machine(19, _seek_1__tmp_at953_16934);
                DeRef(_seek_1__tmp_at953_16934);
                _seek_1__tmp_at953_16934 = NOVALUE;

                /** 						data_ptr = get4()*/
                _0 = _data_ptr_16743;
                _data_ptr_16743 = _38get4();
                DeRef(_0);

                /** 						key = decompress(0)*/
                _0 = _key_16748;
                _key_16748 = _38decompress(0);
                DeRef(_0);

                /** 						puts(fn, "  key: ")*/
                EPuts(_fn_16735, _9602); // DJP 

                /** 						pretty:pretty_print(fn, key, {2, 2, 8})*/
                Ref(_key_16748);
                RefDS(_9603);
                _26pretty_print(_fn_16735, _key_16748, _9603);

                /** 						puts(fn, '\n')*/
                EPuts(_fn_16735, 10); // DJP 

                /** 						if low_level_too then printf(fn, "[data %d:#%08x]\n", {r, data_ptr}) end if*/
                if (_low_level_too_16731 == 0)
                {
                    goto L26; // [997] 1009
                }
                else{
                }
                Ref(_data_ptr_16743);
                Ref(_r_16913);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_16913;
                ((int *)_2)[2] = _data_ptr_16743;
                _9605 = MAKE_SEQ(_1);
                EPrintf(_fn_16735, _9604, _9605);
                DeRefDS(_9605);
                _9605 = NOVALUE;
L26: 

                /** 						io:seek(current_db, data_ptr)*/

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_data_ptr_16743);
                DeRef(_seek_1__tmp_at1012_16944);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16418;
                ((int *)_2)[2] = _data_ptr_16743;
                _seek_1__tmp_at1012_16944 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_1012_16943 = machine(19, _seek_1__tmp_at1012_16944);
                DeRef(_seek_1__tmp_at1012_16944);
                _seek_1__tmp_at1012_16944 = NOVALUE;

                /** 						data = decompress(0)*/
                _0 = _data_16749;
                _data_16749 = _38decompress(0);
                DeRef(_0);

                /** 						puts(fn, "  data: ")*/
                EPuts(_fn_16735, _9607); // DJP 

                /** 						pretty:pretty_print(fn, data, {2, 2, 9})*/
                Ref(_data_16749);
                RefDS(_9608);
                _26pretty_print(_fn_16735, _data_16749, _9608);

                /** 						puts(fn, "\n\n")*/
                EPuts(_fn_16735, _9556); // DJP 

                /** 					end for*/
                _0 = _r_16913;
                if (IS_ATOM_INT(_r_16913)) {
                    _r_16913 = _r_16913 + 1;
                    if ((long)((unsigned long)_r_16913 +(unsigned long) HIGH_BITS) >= 0){
                        _r_16913 = NewDouble((double)_r_16913);
                    }
                }
                else {
                    _r_16913 = binary_op_a(PLUS, _r_16913, 1);
                }
                DeRef(_0);
                goto L22; // [1051] 873
L23: 
                ;
                DeRef(_r_16913);
            }
            goto L27; // [1056] 1066
L21: 

            /** 					printf(fn, "\nblock #%d (empty)\n\n", b)*/
            EPrintf(_fn_16735, _9609, _b_16891);
L27: 

            /** 			end for*/
            _b_16891 = _b_16891 + 1;
            goto L1E; // [1068] 777
L1F: 
            ;
        }
L1D: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_16740;
        if (IS_ATOM_INT(_t_header_16740)) {
            _t_header_16740 = _t_header_16740 + 16;
            if ((long)((unsigned long)_t_header_16740 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_16740 = NewDouble((double)_t_header_16740);
        }
        else {
            _t_header_16740 = NewDouble(DBL_PTR(_t_header_16740)->dbl + (double)16);
        }
        DeRef(_0);

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_16740);
        DeRef(_seek_1__tmp_at1083_16953);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _t_header_16740;
        _seek_1__tmp_at1083_16953 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_1083_16952 = machine(19, _seek_1__tmp_at1083_16953);
        DeRef(_seek_1__tmp_at1083_16953);
        _seek_1__tmp_at1083_16953 = NOVALUE;

        /** 	end for*/
        _0 = _t_16872;
        if (IS_ATOM_INT(_t_16872)) {
            _t_16872 = _t_16872 + 1;
            if ((long)((unsigned long)_t_16872 +(unsigned long) HIGH_BITS) >= 0){
                _t_16872 = NewDouble((double)_t_16872);
            }
        }
        else {
            _t_16872 = binary_op_a(PLUS, _t_16872, 1);
        }
        DeRef(_0);
        goto L19; // [1099] 685
L1A: 
        ;
        DeRef(_t_16872);
    }

    /** 	if low_level_too then printf(fn, "[free blocks:#%08x]\n", FREE_COUNT) end if*/
    if (_low_level_too_16731 == 0)
    {
        goto L28; // [1106] 1114
    }
    else{
    }
    EPrintf(_fn_16735, _9611, 7);
L28: 

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at1117_16958);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at1117_16958 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1117_16957 = machine(19, _seek_1__tmp_at1117_16958);
    DeRefi(_seek_1__tmp_at1117_16958);
    _seek_1__tmp_at1117_16958 = NOVALUE;

    /** 	n = get4()*/
    _n_16751 = _38get4();
    if (!IS_ATOM_INT(_n_16751)) {
        _1 = (long)(DBL_PTR(_n_16751)->dbl);
        DeRefDS(_n_16751);
        _n_16751 = _1;
    }

    /** 	puts(fn, '\n')*/
    EPuts(_fn_16735, 10); // DJP 

    /** 	if n > 0 then*/
    if (_n_16751 <= 0)
    goto L29; // [1145] 1234

    /** 		fbp = get4()*/
    _0 = _fbp_16747;
    _fbp_16747 = _38get4();
    DeRef(_0);

    /** 		printf(fn, "Number of Free blocks: %d ", n)*/
    EPrintf(_fn_16735, _9615, _n_16751);

    /** 		if low_level_too then printf(fn, " [#%08x]:", fbp) end if*/
    if (_low_level_too_16731 == 0)
    {
        goto L2A; // [1162] 1170
    }
    else{
    }
    EPrintf(_fn_16735, _9616, _fbp_16747);
L2A: 

    /** 		puts(fn, '\n')*/
    EPuts(_fn_16735, 10); // DJP 

    /** 		io:seek(current_db, fbp)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_fbp_16747);
    DeRef(_seek_1__tmp_at1178_16968);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _fbp_16747;
    _seek_1__tmp_at1178_16968 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1178_16967 = machine(19, _seek_1__tmp_at1178_16968);
    DeRef(_seek_1__tmp_at1178_16968);
    _seek_1__tmp_at1178_16968 = NOVALUE;

    /** 		for i = 1 to n do*/
    _9617 = _n_16751;
    {
        int _i_16970;
        _i_16970 = 1;
L2B: 
        if (_i_16970 > _9617){
            goto L2C; // [1197] 1231
        }

        /** 			addr = get4()*/
        _0 = _addr_16745;
        _addr_16745 = _38get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_16744;
        _size_16744 = _38get4();
        DeRef(_0);

        /** 			printf(fn, "%08x: %6d bytes\n", {addr, size})*/
        Ref(_size_16744);
        Ref(_addr_16745);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _addr_16745;
        ((int *)_2)[2] = _size_16744;
        _9621 = MAKE_SEQ(_1);
        EPrintf(_fn_16735, _9620, _9621);
        DeRefDS(_9621);
        _9621 = NOVALUE;

        /** 		end for*/
        _i_16970 = _i_16970 + 1;
        goto L2B; // [1226] 1204
L2C: 
        ;
    }
    goto L2D; // [1231] 1240
L29: 

    /** 		puts(fn, "No free blocks available.\n")*/
    EPuts(_fn_16735, _9622); // DJP 
L2D: 

    /** 	if sequence(file_id) then*/
    _9623 = IS_SEQUENCE(_file_id_16730);
    if (_9623 == 0)
    {
        _9623 = NOVALUE;
        goto L2E; // [1245] 1253
    }
    else{
        _9623 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_16735);
L2E: 

    /** end procedure*/
    DeRef(_file_id_16730);
    DeRef(_tables_16736);
    DeRef(_ntables_16737);
    DeRef(_tname_16738);
    DeRef(_trecords_16739);
    DeRef(_t_header_16740);
    DeRef(_tnrecs_16741);
    DeRef(_key_ptr_16742);
    DeRef(_data_ptr_16743);
    DeRef(_size_16744);
    DeRef(_addr_16745);
    DeRef(_tindex_16746);
    DeRef(_fbp_16747);
    DeRef(_key_16748);
    DeRef(_data_16749);
    DeRef(_a_16753);
    DeRef(_ll_line_16754);
    DeRef(_9548);
    _9548 = NOVALUE;
    return;
    ;
}
void db_dump() __attribute__ ((alias ("_38db_dump")));


void _38check_free_list()
{
    int _msg_inlined_crash_at_273_17038 = NOVALUE;
    int _msg_inlined_crash_at_233_17031 = NOVALUE;
    int _msg_inlined_crash_at_201_17025 = NOVALUE;
    int _msg_inlined_crash_at_142_17014 = NOVALUE;
    int _msg_inlined_crash_at_87_17005 = NOVALUE;
    int _msg_inlined_crash_at_55_16999 = NOVALUE;
    int _where_inlined_where_at_25_16992 = NOVALUE;
    int _free_count_16982 = NOVALUE;
    int _free_list_16983 = NOVALUE;
    int _addr_16984 = NOVALUE;
    int _size_16985 = NOVALUE;
    int _free_list_space_16986 = NOVALUE;
    int _max_16987 = NOVALUE;
    int _9649 = NOVALUE;
    int _9648 = NOVALUE;
    int _9641 = NOVALUE;
    int _9640 = NOVALUE;
    int _9639 = NOVALUE;
    int _9637 = NOVALUE;
    int _9635 = NOVALUE;
    int _9633 = NOVALUE;
    int _9627 = NOVALUE;
    int _9624 = NOVALUE;
    int _0, _1, _2;
    

    /** 	safe_seek(-1)*/
    RefDS(_5);
    _38safe_seek(-1, _5);

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _9624 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _9624 = 1;
    }
    if (_9624 <= 0)
    goto L1; // [14] 22
    DeRef(_free_count_16982);
    DeRef(_free_list_16983);
    DeRef(_addr_16984);
    DeRef(_size_16985);
    DeRef(_free_list_space_16986);
    DeRef(_max_16987);
    return;
L1: 

    /** 	max = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_max_16987);
    _max_16987 = machine(20, _38current_db_16418);

    /** 	safe_seek( FREE_COUNT)*/
    RefDS(_5);
    _38safe_seek(7, _5);

    /** 	free_count = get4()*/
    _0 = _free_count_16982;
    _free_count_16982 = _38get4();
    DeRef(_0);

    /** 	if free_count > max/13 then*/
    if (IS_ATOM_INT(_max_16987)) {
        _9627 = (_max_16987 % 13) ? NewDouble((double)_max_16987 / 13) : (_max_16987 / 13);
    }
    else {
        _9627 = NewDouble(DBL_PTR(_max_16987)->dbl / (double)13);
    }
    if (binary_op_a(LESSEQ, _free_count_16982, _9627)){
        DeRef(_9627);
        _9627 = NOVALUE;
        goto L2; // [50] 75
    }
    DeRef(_9627);
    _9627 = NOVALUE;

    /** 		error:crash("free count is too high")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_55_16999);
    _msg_inlined_crash_at_55_16999 = EPrintf(-9999999, _9629, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_55_16999);

    /** end procedure*/
    goto L3; // [69] 72
L3: 
    DeRefi(_msg_inlined_crash_at_55_16999);
    _msg_inlined_crash_at_55_16999 = NOVALUE;
L2: 

    /** 	free_list = get4()*/
    _0 = _free_list_16983;
    _free_list_16983 = _38get4();
    DeRef(_0);

    /** 	if free_list > max then*/
    if (binary_op_a(LESSEQ, _free_list_16983, _max_16987)){
        goto L4; // [82] 107
    }

    /** 		error:crash("bad free list pointer")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_87_17005);
    _msg_inlined_crash_at_87_17005 = EPrintf(-9999999, _9632, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_87_17005);

    /** end procedure*/
    goto L5; // [101] 104
L5: 
    DeRefi(_msg_inlined_crash_at_87_17005);
    _msg_inlined_crash_at_87_17005 = NOVALUE;
L4: 

    /** 	safe_seek( free_list - 4)*/
    if (IS_ATOM_INT(_free_list_16983)) {
        _9633 = _free_list_16983 - 4;
        if ((long)((unsigned long)_9633 +(unsigned long) HIGH_BITS) >= 0){
            _9633 = NewDouble((double)_9633);
        }
    }
    else {
        _9633 = NewDouble(DBL_PTR(_free_list_16983)->dbl - (double)4);
    }
    RefDS(_5);
    _38safe_seek(_9633, _5);
    _9633 = NOVALUE;

    /** 	free_list_space = get4()*/
    _0 = _free_list_space_16986;
    _free_list_space_16986 = _38get4();
    DeRef(_0);

    /** 	if free_list_space > max or free_list_space < 0 then*/
    if (IS_ATOM_INT(_free_list_space_16986) && IS_ATOM_INT(_max_16987)) {
        _9635 = (_free_list_space_16986 > _max_16987);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_16986)) {
            _9635 = ((double)_free_list_space_16986 > DBL_PTR(_max_16987)->dbl);
        }
        else {
            if (IS_ATOM_INT(_max_16987)) {
                _9635 = (DBL_PTR(_free_list_space_16986)->dbl > (double)_max_16987);
            }
            else
            _9635 = (DBL_PTR(_free_list_space_16986)->dbl > DBL_PTR(_max_16987)->dbl);
        }
    }
    if (_9635 != 0) {
        goto L6; // [128] 141
    }
    if (IS_ATOM_INT(_free_list_space_16986)) {
        _9637 = (_free_list_space_16986 < 0);
    }
    else {
        _9637 = (DBL_PTR(_free_list_space_16986)->dbl < (double)0);
    }
    if (_9637 == 0)
    {
        DeRef(_9637);
        _9637 = NOVALUE;
        goto L7; // [137] 162
    }
    else{
        DeRef(_9637);
        _9637 = NOVALUE;
    }
L6: 

    /** 		error:crash("free list space is bad")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_142_17014);
    _msg_inlined_crash_at_142_17014 = EPrintf(-9999999, _9638, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_142_17014);

    /** end procedure*/
    goto L8; // [156] 159
L8: 
    DeRefi(_msg_inlined_crash_at_142_17014);
    _msg_inlined_crash_at_142_17014 = NOVALUE;
L7: 

    /** 	for i = 0 to free_count - 1 do*/
    if (IS_ATOM_INT(_free_count_16982)) {
        _9639 = _free_count_16982 - 1;
        if ((long)((unsigned long)_9639 +(unsigned long) HIGH_BITS) >= 0){
            _9639 = NewDouble((double)_9639);
        }
    }
    else {
        _9639 = NewDouble(DBL_PTR(_free_count_16982)->dbl - (double)1);
    }
    {
        int _i_17016;
        _i_17016 = 0;
L9: 
        if (binary_op_a(GREATER, _i_17016, _9639)){
            goto LA; // [168] 300
        }

        /** 		safe_seek( free_list + i * 8)*/
        if (IS_ATOM_INT(_i_17016)) {
            if (_i_17016 == (short)_i_17016)
            _9640 = _i_17016 * 8;
            else
            _9640 = NewDouble(_i_17016 * (double)8);
        }
        else {
            _9640 = NewDouble(DBL_PTR(_i_17016)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_free_list_16983) && IS_ATOM_INT(_9640)) {
            _9641 = _free_list_16983 + _9640;
            if ((long)((unsigned long)_9641 + (unsigned long)HIGH_BITS) >= 0) 
            _9641 = NewDouble((double)_9641);
        }
        else {
            if (IS_ATOM_INT(_free_list_16983)) {
                _9641 = NewDouble((double)_free_list_16983 + DBL_PTR(_9640)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9640)) {
                    _9641 = NewDouble(DBL_PTR(_free_list_16983)->dbl + (double)_9640);
                }
                else
                _9641 = NewDouble(DBL_PTR(_free_list_16983)->dbl + DBL_PTR(_9640)->dbl);
            }
        }
        DeRef(_9640);
        _9640 = NOVALUE;
        RefDS(_5);
        _38safe_seek(_9641, _5);
        _9641 = NOVALUE;

        /** 		addr = get4()*/
        _0 = _addr_16984;
        _addr_16984 = _38get4();
        DeRef(_0);

        /** 		if addr > max then*/
        if (binary_op_a(LESSEQ, _addr_16984, _max_16987)){
            goto LB; // [196] 221
        }

        /** 			error:crash("bad block address")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_201_17025);
        _msg_inlined_crash_at_201_17025 = EPrintf(-9999999, _9644, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_201_17025);

        /** end procedure*/
        goto LC; // [215] 218
LC: 
        DeRefi(_msg_inlined_crash_at_201_17025);
        _msg_inlined_crash_at_201_17025 = NOVALUE;
LB: 

        /** 		size = get4()*/
        _0 = _size_16985;
        _size_16985 = _38get4();
        DeRef(_0);

        /** 		if size > max then*/
        if (binary_op_a(LESSEQ, _size_16985, _max_16987)){
            goto LD; // [228] 253
        }

        /** 			error:crash("block size too big")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_233_17031);
        _msg_inlined_crash_at_233_17031 = EPrintf(-9999999, _9647, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_233_17031);

        /** end procedure*/
        goto LE; // [247] 250
LE: 
        DeRefi(_msg_inlined_crash_at_233_17031);
        _msg_inlined_crash_at_233_17031 = NOVALUE;
LD: 

        /** 		safe_seek( addr - 4)*/
        if (IS_ATOM_INT(_addr_16984)) {
            _9648 = _addr_16984 - 4;
            if ((long)((unsigned long)_9648 +(unsigned long) HIGH_BITS) >= 0){
                _9648 = NewDouble((double)_9648);
            }
        }
        else {
            _9648 = NewDouble(DBL_PTR(_addr_16984)->dbl - (double)4);
        }
        RefDS(_5);
        _38safe_seek(_9648, _5);
        _9648 = NOVALUE;

        /** 		if get4() > size then*/
        _9649 = _38get4();
        if (binary_op_a(LESSEQ, _9649, _size_16985)){
            DeRef(_9649);
            _9649 = NOVALUE;
            goto LF; // [268] 293
        }
        DeRef(_9649);
        _9649 = NOVALUE;

        /** 			error:crash("bad size in front of free block")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_273_17038);
        _msg_inlined_crash_at_273_17038 = EPrintf(-9999999, _9651, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_273_17038);

        /** end procedure*/
        goto L10; // [287] 290
L10: 
        DeRefi(_msg_inlined_crash_at_273_17038);
        _msg_inlined_crash_at_273_17038 = NOVALUE;
LF: 

        /** 	end for*/
        _0 = _i_17016;
        if (IS_ATOM_INT(_i_17016)) {
            _i_17016 = _i_17016 + 1;
            if ((long)((unsigned long)_i_17016 +(unsigned long) HIGH_BITS) >= 0){
                _i_17016 = NewDouble((double)_i_17016);
            }
        }
        else {
            _i_17016 = binary_op_a(PLUS, _i_17016, 1);
        }
        DeRef(_0);
        goto L9; // [295] 175
LA: 
        ;
        DeRef(_i_17016);
    }

    /** end procedure*/
    DeRef(_free_count_16982);
    DeRef(_free_list_16983);
    DeRef(_addr_16984);
    DeRef(_size_16985);
    DeRef(_free_list_space_16986);
    DeRef(_max_16987);
    DeRef(_9635);
    _9635 = NOVALUE;
    DeRef(_9639);
    _9639 = NOVALUE;
    return;
    ;
}
void check_free_list() __attribute__ ((alias ("_38check_free_list")));


int _38db_allocate(int _n_17041)
{
    int _free_list_17042 = NOVALUE;
    int _size_17043 = NOVALUE;
    int _size_ptr_17044 = NOVALUE;
    int _addr_17045 = NOVALUE;
    int _free_count_17046 = NOVALUE;
    int _remaining_17047 = NOVALUE;
    int _seek_1__tmp_at4_17050 = NOVALUE;
    int _seek_inlined_seek_at_4_17049 = NOVALUE;
    int _seek_1__tmp_at39_17057 = NOVALUE;
    int _seek_inlined_seek_at_39_17056 = NOVALUE;
    int _seek_1__tmp_at111_17074 = NOVALUE;
    int _seek_inlined_seek_at_111_17073 = NOVALUE;
    int _pos_inlined_seek_at_108_17072 = NOVALUE;
    int _put4_1__tmp_at137_17079 = NOVALUE;
    int _x_inlined_put4_at_134_17078 = NOVALUE;
    int _seek_1__tmp_at167_17082 = NOVALUE;
    int _seek_inlined_seek_at_167_17081 = NOVALUE;
    int _put4_1__tmp_at193_17087 = NOVALUE;
    int _x_inlined_put4_at_190_17086 = NOVALUE;
    int _seek_1__tmp_at244_17095 = NOVALUE;
    int _seek_inlined_seek_at_244_17094 = NOVALUE;
    int _pos_inlined_seek_at_241_17093 = NOVALUE;
    int _put4_1__tmp_at266_17099 = NOVALUE;
    int _x_inlined_put4_at_263_17098 = NOVALUE;
    int _seek_1__tmp_at333_17110 = NOVALUE;
    int _seek_inlined_seek_at_333_17109 = NOVALUE;
    int _pos_inlined_seek_at_330_17108 = NOVALUE;
    int _seek_1__tmp_at364_17114 = NOVALUE;
    int _seek_inlined_seek_at_364_17113 = NOVALUE;
    int _put4_1__tmp_at386_17118 = NOVALUE;
    int _x_inlined_put4_at_383_17117 = NOVALUE;
    int _seek_1__tmp_at423_17123 = NOVALUE;
    int _seek_inlined_seek_at_423_17122 = NOVALUE;
    int _pos_inlined_seek_at_420_17121 = NOVALUE;
    int _put4_1__tmp_at438_17125 = NOVALUE;
    int _seek_1__tmp_at490_17129 = NOVALUE;
    int _seek_inlined_seek_at_490_17128 = NOVALUE;
    int _put4_1__tmp_at512_17133 = NOVALUE;
    int _x_inlined_put4_at_509_17132 = NOVALUE;
    int _where_inlined_where_at_542_17135 = NOVALUE;
    int _9682 = NOVALUE;
    int _9680 = NOVALUE;
    int _9679 = NOVALUE;
    int _9678 = NOVALUE;
    int _9677 = NOVALUE;
    int _9676 = NOVALUE;
    int _9674 = NOVALUE;
    int _9673 = NOVALUE;
    int _9672 = NOVALUE;
    int _9671 = NOVALUE;
    int _9669 = NOVALUE;
    int _9668 = NOVALUE;
    int _9667 = NOVALUE;
    int _9666 = NOVALUE;
    int _9665 = NOVALUE;
    int _9664 = NOVALUE;
    int _9663 = NOVALUE;
    int _9661 = NOVALUE;
    int _9659 = NOVALUE;
    int _9656 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17050);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_17050 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17049 = machine(19, _seek_1__tmp_at4_17050);
    DeRefi(_seek_1__tmp_at4_17050);
    _seek_1__tmp_at4_17050 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17046 = _38get4();
    if (!IS_ATOM_INT(_free_count_17046)) {
        _1 = (long)(DBL_PTR(_free_count_17046)->dbl);
        DeRefDS(_free_count_17046);
        _free_count_17046 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_17046 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_17042;
    _free_list_17042 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17042);
    DeRef(_seek_1__tmp_at39_17057);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _free_list_17042;
    _seek_1__tmp_at39_17057 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_17056 = machine(19, _seek_1__tmp_at39_17057);
    DeRef(_seek_1__tmp_at39_17057);
    _seek_1__tmp_at39_17057 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_17044);
    if (IS_ATOM_INT(_free_list_17042)) {
        _size_ptr_17044 = _free_list_17042 + 4;
        if ((long)((unsigned long)_size_ptr_17044 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_17044 = NewDouble((double)_size_ptr_17044);
    }
    else {
        _size_ptr_17044 = NewDouble(DBL_PTR(_free_list_17042)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _9656 = _free_count_17046;
    {
        int _i_17060;
        _i_17060 = 1;
L2: 
        if (_i_17060 > _9656){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_17045;
        _addr_17045 = _38get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_17043;
        _size_17043 = _38get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_17041)) {
            _9659 = _n_17041 + 4;
            if ((long)((unsigned long)_9659 + (unsigned long)HIGH_BITS) >= 0) 
            _9659 = NewDouble((double)_9659);
        }
        else {
            _9659 = NewDouble(DBL_PTR(_n_17041)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_17043, _9659)){
            DeRef(_9659);
            _9659 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_9659);
        _9659 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_17041)) {
            _9661 = _n_17041 + 16;
            if ((long)((unsigned long)_9661 + (unsigned long)HIGH_BITS) >= 0) 
            _9661 = NewDouble((double)_9661);
        }
        else {
            _9661 = NewDouble(DBL_PTR(_n_17041)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_17043, _9661)){
            DeRef(_9661);
            _9661 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_9661);
        _9661 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17045)) {
            _9663 = _addr_17045 - 4;
            if ((long)((unsigned long)_9663 +(unsigned long) HIGH_BITS) >= 0){
                _9663 = NewDouble((double)_9663);
            }
        }
        else {
            _9663 = NewDouble(DBL_PTR(_addr_17045)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_17072);
        _pos_inlined_seek_at_108_17072 = _9663;
        _9663 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_17072);
        DeRef(_seek_1__tmp_at111_17074);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_17072;
        _seek_1__tmp_at111_17074 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_17073 = machine(19, _seek_1__tmp_at111_17074);
        DeRef(_pos_inlined_seek_at_108_17072);
        _pos_inlined_seek_at_108_17072 = NOVALUE;
        DeRef(_seek_1__tmp_at111_17074);
        _seek_1__tmp_at111_17074 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_17043) && IS_ATOM_INT(_n_17041)) {
            _9664 = _size_17043 - _n_17041;
            if ((long)((unsigned long)_9664 +(unsigned long) HIGH_BITS) >= 0){
                _9664 = NewDouble((double)_9664);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17043)) {
                _9664 = NewDouble((double)_size_17043 - DBL_PTR(_n_17041)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17041)) {
                    _9664 = NewDouble(DBL_PTR(_size_17043)->dbl - (double)_n_17041);
                }
                else
                _9664 = NewDouble(DBL_PTR(_size_17043)->dbl - DBL_PTR(_n_17041)->dbl);
            }
        }
        if (IS_ATOM_INT(_9664)) {
            _9665 = _9664 - 4;
            if ((long)((unsigned long)_9665 +(unsigned long) HIGH_BITS) >= 0){
                _9665 = NewDouble((double)_9665);
            }
        }
        else {
            _9665 = NewDouble(DBL_PTR(_9664)->dbl - (double)4);
        }
        DeRef(_9664);
        _9664 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_17078);
        _x_inlined_put4_at_134_17078 = _9665;
        _9665 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_17078)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_17078;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_17078)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_17079);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_17079 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at137_17079); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_17078);
        _x_inlined_put4_at_134_17078 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_17079);
        _put4_1__tmp_at137_17079 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_17044);
        DeRef(_seek_1__tmp_at167_17082);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _size_ptr_17044;
        _seek_1__tmp_at167_17082 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_17081 = machine(19, _seek_1__tmp_at167_17082);
        DeRef(_seek_1__tmp_at167_17082);
        _seek_1__tmp_at167_17082 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_17043) && IS_ATOM_INT(_n_17041)) {
            _9666 = _size_17043 - _n_17041;
            if ((long)((unsigned long)_9666 +(unsigned long) HIGH_BITS) >= 0){
                _9666 = NewDouble((double)_9666);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17043)) {
                _9666 = NewDouble((double)_size_17043 - DBL_PTR(_n_17041)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17041)) {
                    _9666 = NewDouble(DBL_PTR(_size_17043)->dbl - (double)_n_17041);
                }
                else
                _9666 = NewDouble(DBL_PTR(_size_17043)->dbl - DBL_PTR(_n_17041)->dbl);
            }
        }
        if (IS_ATOM_INT(_9666)) {
            _9667 = _9666 - 4;
            if ((long)((unsigned long)_9667 +(unsigned long) HIGH_BITS) >= 0){
                _9667 = NewDouble((double)_9667);
            }
        }
        else {
            _9667 = NewDouble(DBL_PTR(_9666)->dbl - (double)4);
        }
        DeRef(_9666);
        _9666 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_17086);
        _x_inlined_put4_at_190_17086 = _9667;
        _9667 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_17086)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_17086;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_17086)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_17087);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_17087 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at193_17087); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_17086);
        _x_inlined_put4_at_190_17086 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_17087);
        _put4_1__tmp_at193_17087 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_17043) && IS_ATOM_INT(_n_17041)) {
            _9668 = _size_17043 - _n_17041;
            if ((long)((unsigned long)_9668 +(unsigned long) HIGH_BITS) >= 0){
                _9668 = NewDouble((double)_9668);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17043)) {
                _9668 = NewDouble((double)_size_17043 - DBL_PTR(_n_17041)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17041)) {
                    _9668 = NewDouble(DBL_PTR(_size_17043)->dbl - (double)_n_17041);
                }
                else
                _9668 = NewDouble(DBL_PTR(_size_17043)->dbl - DBL_PTR(_n_17041)->dbl);
            }
        }
        if (IS_ATOM_INT(_9668)) {
            _9669 = _9668 - 4;
            if ((long)((unsigned long)_9669 +(unsigned long) HIGH_BITS) >= 0){
                _9669 = NewDouble((double)_9669);
            }
        }
        else {
            _9669 = NewDouble(DBL_PTR(_9668)->dbl - (double)4);
        }
        DeRef(_9668);
        _9668 = NOVALUE;
        _0 = _addr_17045;
        if (IS_ATOM_INT(_addr_17045) && IS_ATOM_INT(_9669)) {
            _addr_17045 = _addr_17045 + _9669;
            if ((long)((unsigned long)_addr_17045 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_17045 = NewDouble((double)_addr_17045);
        }
        else {
            if (IS_ATOM_INT(_addr_17045)) {
                _addr_17045 = NewDouble((double)_addr_17045 + DBL_PTR(_9669)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9669)) {
                    _addr_17045 = NewDouble(DBL_PTR(_addr_17045)->dbl + (double)_9669);
                }
                else
                _addr_17045 = NewDouble(DBL_PTR(_addr_17045)->dbl + DBL_PTR(_9669)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_9669);
        _9669 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_17045)) {
            _9671 = _addr_17045 - 4;
            if ((long)((unsigned long)_9671 +(unsigned long) HIGH_BITS) >= 0){
                _9671 = NewDouble((double)_9671);
            }
        }
        else {
            _9671 = NewDouble(DBL_PTR(_addr_17045)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_17093);
        _pos_inlined_seek_at_241_17093 = _9671;
        _9671 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_17093);
        DeRef(_seek_1__tmp_at244_17095);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_17093;
        _seek_1__tmp_at244_17095 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_17094 = machine(19, _seek_1__tmp_at244_17095);
        DeRef(_pos_inlined_seek_at_241_17093);
        _pos_inlined_seek_at_241_17093 = NOVALUE;
        DeRef(_seek_1__tmp_at244_17095);
        _seek_1__tmp_at244_17095 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_17041)) {
            _9672 = _n_17041 + 4;
            if ((long)((unsigned long)_9672 + (unsigned long)HIGH_BITS) >= 0) 
            _9672 = NewDouble((double)_9672);
        }
        else {
            _9672 = NewDouble(DBL_PTR(_n_17041)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_17098);
        _x_inlined_put4_at_263_17098 = _9672;
        _9672 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_17098)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_17098;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_17098)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_17099);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_17099 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at266_17099); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_17098);
        _x_inlined_put4_at_263_17098 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_17099);
        _put4_1__tmp_at266_17099 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _9673 = _free_count_17046 - _i_17060;
        if ((long)((unsigned long)_9673 +(unsigned long) HIGH_BITS) >= 0){
            _9673 = NewDouble((double)_9673);
        }
        if (IS_ATOM_INT(_9673)) {
            if (_9673 == (short)_9673)
            _9674 = _9673 * 8;
            else
            _9674 = NewDouble(_9673 * (double)8);
        }
        else {
            _9674 = NewDouble(DBL_PTR(_9673)->dbl * (double)8);
        }
        DeRef(_9673);
        _9673 = NOVALUE;
        _0 = _remaining_17047;
        _remaining_17047 = _18get_bytes(_38current_db_16418, _9674);
        DeRef(_0);
        _9674 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _9676 = _i_17060 - 1;
        if (_9676 <= INT15)
        _9677 = 8 * _9676;
        else
        _9677 = NewDouble(8 * (double)_9676);
        _9676 = NOVALUE;
        if (IS_ATOM_INT(_free_list_17042) && IS_ATOM_INT(_9677)) {
            _9678 = _free_list_17042 + _9677;
            if ((long)((unsigned long)_9678 + (unsigned long)HIGH_BITS) >= 0) 
            _9678 = NewDouble((double)_9678);
        }
        else {
            if (IS_ATOM_INT(_free_list_17042)) {
                _9678 = NewDouble((double)_free_list_17042 + DBL_PTR(_9677)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9677)) {
                    _9678 = NewDouble(DBL_PTR(_free_list_17042)->dbl + (double)_9677);
                }
                else
                _9678 = NewDouble(DBL_PTR(_free_list_17042)->dbl + DBL_PTR(_9677)->dbl);
            }
        }
        DeRef(_9677);
        _9677 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_17108);
        _pos_inlined_seek_at_330_17108 = _9678;
        _9678 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_17108);
        DeRef(_seek_1__tmp_at333_17110);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_17108;
        _seek_1__tmp_at333_17110 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_17109 = machine(19, _seek_1__tmp_at333_17110);
        DeRef(_pos_inlined_seek_at_330_17108);
        _pos_inlined_seek_at_330_17108 = NOVALUE;
        DeRef(_seek_1__tmp_at333_17110);
        _seek_1__tmp_at333_17110 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_38current_db_16418, _remaining_17047); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_17114);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_17114 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_17113 = machine(19, _seek_1__tmp_at364_17114);
        DeRefi(_seek_1__tmp_at364_17114);
        _seek_1__tmp_at364_17114 = NOVALUE;

        /** 					put4(free_count-1)*/
        _9679 = _free_count_17046 - 1;
        if ((long)((unsigned long)_9679 +(unsigned long) HIGH_BITS) >= 0){
            _9679 = NewDouble((double)_9679);
        }
        DeRef(_x_inlined_put4_at_383_17117);
        _x_inlined_put4_at_383_17117 = _9679;
        _9679 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_17117)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_17117;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_17117)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_17118);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_17118 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at386_17118); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_17117);
        _x_inlined_put4_at_383_17117 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_17118);
        _put4_1__tmp_at386_17118 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17045)) {
            _9680 = _addr_17045 - 4;
            if ((long)((unsigned long)_9680 +(unsigned long) HIGH_BITS) >= 0){
                _9680 = NewDouble((double)_9680);
            }
        }
        else {
            _9680 = NewDouble(DBL_PTR(_addr_17045)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_17121);
        _pos_inlined_seek_at_420_17121 = _9680;
        _9680 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_17121);
        DeRef(_seek_1__tmp_at423_17123);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_17121;
        _seek_1__tmp_at423_17123 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_17122 = machine(19, _seek_1__tmp_at423_17123);
        DeRef(_pos_inlined_seek_at_420_17121);
        _pos_inlined_seek_at_420_17121 = NOVALUE;
        DeRef(_seek_1__tmp_at423_17123);
        _seek_1__tmp_at423_17123 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_size_17043)) {
            *poke4_addr = (unsigned long)_size_17043;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_17043)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_17125);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_17125 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at438_17125); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_17125);
        _put4_1__tmp_at438_17125 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_17041);
        DeRef(_free_list_17042);
        DeRef(_size_17043);
        DeRef(_size_ptr_17044);
        DeRef(_remaining_17047);
        return _addr_17045;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_17044;
        if (IS_ATOM_INT(_size_ptr_17044)) {
            _size_ptr_17044 = _size_ptr_17044 + 8;
            if ((long)((unsigned long)_size_ptr_17044 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_17044 = NewDouble((double)_size_ptr_17044);
        }
        else {
            _size_ptr_17044 = NewDouble(DBL_PTR(_size_ptr_17044)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_17060 = _i_17060 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_17129);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_17129 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_17128 = machine(19, _seek_1__tmp_at490_17129);
    DeRefi(_seek_1__tmp_at490_17129);
    _seek_1__tmp_at490_17129 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_17041)) {
        _9682 = _n_17041 + 4;
        if ((long)((unsigned long)_9682 + (unsigned long)HIGH_BITS) >= 0) 
        _9682 = NewDouble((double)_9682);
    }
    else {
        _9682 = NewDouble(DBL_PTR(_n_17041)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_17132);
    _x_inlined_put4_at_509_17132 = _9682;
    _9682 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_17132)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_17132;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_17132)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_17133);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_17133 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at512_17133); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_17132);
    _x_inlined_put4_at_509_17132 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_17133);
    _put4_1__tmp_at512_17133 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_17135);
    _where_inlined_where_at_542_17135 = machine(20, _38current_db_16418);
    DeRef(_n_17041);
    DeRef(_free_list_17042);
    DeRef(_size_17043);
    DeRef(_size_ptr_17044);
    DeRef(_addr_17045);
    DeRef(_remaining_17047);
    return _where_inlined_where_at_542_17135;
    ;
}


void _38db_free(int _p_17138)
{
    int _psize_17139 = NOVALUE;
    int _i_17140 = NOVALUE;
    int _size_17141 = NOVALUE;
    int _addr_17142 = NOVALUE;
    int _free_list_17143 = NOVALUE;
    int _free_list_space_17144 = NOVALUE;
    int _new_space_17145 = NOVALUE;
    int _to_be_freed_17146 = NOVALUE;
    int _prev_addr_17147 = NOVALUE;
    int _prev_size_17148 = NOVALUE;
    int _free_count_17149 = NOVALUE;
    int _remaining_17150 = NOVALUE;
    int _seek_1__tmp_at11_17155 = NOVALUE;
    int _seek_inlined_seek_at_11_17154 = NOVALUE;
    int _pos_inlined_seek_at_8_17153 = NOVALUE;
    int _seek_1__tmp_at33_17159 = NOVALUE;
    int _seek_inlined_seek_at_33_17158 = NOVALUE;
    int _seek_1__tmp_at69_17166 = NOVALUE;
    int _seek_inlined_seek_at_69_17165 = NOVALUE;
    int _pos_inlined_seek_at_66_17164 = NOVALUE;
    int _seek_1__tmp_at133_17179 = NOVALUE;
    int _seek_inlined_seek_at_133_17178 = NOVALUE;
    int _seek_1__tmp_at157_17183 = NOVALUE;
    int _seek_inlined_seek_at_157_17182 = NOVALUE;
    int _put4_1__tmp_at172_17185 = NOVALUE;
    int _seek_1__tmp_at202_17188 = NOVALUE;
    int _seek_inlined_seek_at_202_17187 = NOVALUE;
    int _seek_1__tmp_at234_17193 = NOVALUE;
    int _seek_inlined_seek_at_234_17192 = NOVALUE;
    int _s_inlined_putn_at_274_17199 = NOVALUE;
    int _seek_1__tmp_at297_17202 = NOVALUE;
    int _seek_inlined_seek_at_297_17201 = NOVALUE;
    int _seek_1__tmp_at430_17223 = NOVALUE;
    int _seek_inlined_seek_at_430_17222 = NOVALUE;
    int _pos_inlined_seek_at_427_17221 = NOVALUE;
    int _put4_1__tmp_at482_17233 = NOVALUE;
    int _x_inlined_put4_at_479_17232 = NOVALUE;
    int _seek_1__tmp_at523_17239 = NOVALUE;
    int _seek_inlined_seek_at_523_17238 = NOVALUE;
    int _pos_inlined_seek_at_520_17237 = NOVALUE;
    int _seek_1__tmp_at574_17249 = NOVALUE;
    int _seek_inlined_seek_at_574_17248 = NOVALUE;
    int _pos_inlined_seek_at_571_17247 = NOVALUE;
    int _seek_1__tmp_at611_17254 = NOVALUE;
    int _seek_inlined_seek_at_611_17253 = NOVALUE;
    int _put4_1__tmp_at626_17256 = NOVALUE;
    int _put4_1__tmp_at664_17261 = NOVALUE;
    int _x_inlined_put4_at_661_17260 = NOVALUE;
    int _seek_1__tmp_at737_17273 = NOVALUE;
    int _seek_inlined_seek_at_737_17272 = NOVALUE;
    int _pos_inlined_seek_at_734_17271 = NOVALUE;
    int _put4_1__tmp_at752_17275 = NOVALUE;
    int _put4_1__tmp_at789_17279 = NOVALUE;
    int _x_inlined_put4_at_786_17278 = NOVALUE;
    int _seek_1__tmp_at837_17287 = NOVALUE;
    int _seek_inlined_seek_at_837_17286 = NOVALUE;
    int _pos_inlined_seek_at_834_17285 = NOVALUE;
    int _seek_1__tmp_at883_17295 = NOVALUE;
    int _seek_inlined_seek_at_883_17294 = NOVALUE;
    int _put4_1__tmp_at898_17297 = NOVALUE;
    int _seek_1__tmp_at943_17304 = NOVALUE;
    int _seek_inlined_seek_at_943_17303 = NOVALUE;
    int _pos_inlined_seek_at_940_17302 = NOVALUE;
    int _put4_1__tmp_at958_17306 = NOVALUE;
    int _put4_1__tmp_at986_17308 = NOVALUE;
    int _9750 = NOVALUE;
    int _9749 = NOVALUE;
    int _9748 = NOVALUE;
    int _9745 = NOVALUE;
    int _9744 = NOVALUE;
    int _9743 = NOVALUE;
    int _9742 = NOVALUE;
    int _9741 = NOVALUE;
    int _9740 = NOVALUE;
    int _9739 = NOVALUE;
    int _9738 = NOVALUE;
    int _9737 = NOVALUE;
    int _9736 = NOVALUE;
    int _9735 = NOVALUE;
    int _9734 = NOVALUE;
    int _9733 = NOVALUE;
    int _9732 = NOVALUE;
    int _9731 = NOVALUE;
    int _9729 = NOVALUE;
    int _9728 = NOVALUE;
    int _9727 = NOVALUE;
    int _9725 = NOVALUE;
    int _9724 = NOVALUE;
    int _9723 = NOVALUE;
    int _9722 = NOVALUE;
    int _9721 = NOVALUE;
    int _9720 = NOVALUE;
    int _9719 = NOVALUE;
    int _9718 = NOVALUE;
    int _9717 = NOVALUE;
    int _9716 = NOVALUE;
    int _9715 = NOVALUE;
    int _9714 = NOVALUE;
    int _9713 = NOVALUE;
    int _9712 = NOVALUE;
    int _9711 = NOVALUE;
    int _9710 = NOVALUE;
    int _9709 = NOVALUE;
    int _9708 = NOVALUE;
    int _9702 = NOVALUE;
    int _9701 = NOVALUE;
    int _9700 = NOVALUE;
    int _9698 = NOVALUE;
    int _9694 = NOVALUE;
    int _9693 = NOVALUE;
    int _9691 = NOVALUE;
    int _9690 = NOVALUE;
    int _9688 = NOVALUE;
    int _9687 = NOVALUE;
    int _9683 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_17138)) {
        _9683 = _p_17138 - 4;
        if ((long)((unsigned long)_9683 +(unsigned long) HIGH_BITS) >= 0){
            _9683 = NewDouble((double)_9683);
        }
    }
    else {
        _9683 = NewDouble(DBL_PTR(_p_17138)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_17153);
    _pos_inlined_seek_at_8_17153 = _9683;
    _9683 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17153);
    DeRef(_seek_1__tmp_at11_17155);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_17153;
    _seek_1__tmp_at11_17155 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17154 = machine(19, _seek_1__tmp_at11_17155);
    DeRef(_pos_inlined_seek_at_8_17153);
    _pos_inlined_seek_at_8_17153 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17155);
    _seek_1__tmp_at11_17155 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_17139;
    _psize_17139 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_17159);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_17159 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_17158 = machine(19, _seek_1__tmp_at33_17159);
    DeRefi(_seek_1__tmp_at33_17159);
    _seek_1__tmp_at33_17159 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17149 = _38get4();
    if (!IS_ATOM_INT(_free_count_17149)) {
        _1 = (long)(DBL_PTR(_free_count_17149)->dbl);
        DeRefDS(_free_count_17149);
        _free_count_17149 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_17143;
    _free_list_17143 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_17143)) {
        _9687 = _free_list_17143 - 4;
        if ((long)((unsigned long)_9687 +(unsigned long) HIGH_BITS) >= 0){
            _9687 = NewDouble((double)_9687);
        }
    }
    else {
        _9687 = NewDouble(DBL_PTR(_free_list_17143)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_17164);
    _pos_inlined_seek_at_66_17164 = _9687;
    _9687 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_17164);
    DeRef(_seek_1__tmp_at69_17166);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_17164;
    _seek_1__tmp_at69_17166 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_17165 = machine(19, _seek_1__tmp_at69_17166);
    DeRef(_pos_inlined_seek_at_66_17164);
    _pos_inlined_seek_at_66_17164 = NOVALUE;
    DeRef(_seek_1__tmp_at69_17166);
    _seek_1__tmp_at69_17166 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _9688 = _38get4();
    DeRef(_free_list_space_17144);
    if (IS_ATOM_INT(_9688)) {
        _free_list_space_17144 = _9688 - 4;
        if ((long)((unsigned long)_free_list_space_17144 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_17144 = NewDouble((double)_free_list_space_17144);
        }
    }
    else {
        _free_list_space_17144 = binary_op(MINUS, _9688, 4);
    }
    DeRef(_9688);
    _9688 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _9690 = _free_count_17149 + 1;
    if (_9690 > MAXINT){
        _9690 = NewDouble((double)_9690);
    }
    if (IS_ATOM_INT(_9690)) {
        if (_9690 <= INT15 && _9690 >= -INT15)
        _9691 = 8 * _9690;
        else
        _9691 = NewDouble(8 * (double)_9690);
    }
    else {
        _9691 = NewDouble((double)8 * DBL_PTR(_9690)->dbl);
    }
    DeRef(_9690);
    _9690 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_17144, _9691)){
        DeRef(_9691);
        _9691 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_9691);
    _9691 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_17144)) {
        if (_free_list_space_17144 & 1) {
            _9693 = NewDouble((_free_list_space_17144 >> 1) + 0.5);
        }
        else
        _9693 = _free_list_space_17144 >> 1;
    }
    else {
        _9693 = binary_op(DIVIDE, _free_list_space_17144, 2);
    }
    if (IS_ATOM_INT(_free_list_space_17144) && IS_ATOM_INT(_9693)) {
        _9694 = _free_list_space_17144 + _9693;
        if ((long)((unsigned long)_9694 + (unsigned long)HIGH_BITS) >= 0) 
        _9694 = NewDouble((double)_9694);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_17144)) {
            _9694 = NewDouble((double)_free_list_space_17144 + DBL_PTR(_9693)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9693)) {
                _9694 = NewDouble(DBL_PTR(_free_list_space_17144)->dbl + (double)_9693);
            }
            else
            _9694 = NewDouble(DBL_PTR(_free_list_space_17144)->dbl + DBL_PTR(_9693)->dbl);
        }
    }
    DeRef(_9693);
    _9693 = NOVALUE;
    DeRef(_new_space_17145);
    if (IS_ATOM_INT(_9694))
    _new_space_17145 = e_floor(_9694);
    else
    _new_space_17145 = unary_op(FLOOR, _9694);
    DeRef(_9694);
    _9694 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_17143);
    DeRef(_to_be_freed_17146);
    _to_be_freed_17146 = _free_list_17143;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_17145);
    _0 = _free_list_17143;
    _free_list_17143 = _38db_allocate(_new_space_17145);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_17179);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_17179 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_17178 = machine(19, _seek_1__tmp_at133_17179);
    DeRefi(_seek_1__tmp_at133_17179);
    _seek_1__tmp_at133_17179 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_17149 = _38get4();
    if (!IS_ATOM_INT(_free_count_17149)) {
        _1 = (long)(DBL_PTR(_free_count_17149)->dbl);
        DeRefDS(_free_count_17149);
        _free_count_17149 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_17183);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_17183 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_17182 = machine(19, _seek_1__tmp_at157_17183);
    DeRefi(_seek_1__tmp_at157_17183);
    _seek_1__tmp_at157_17183 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_free_list_17143)) {
        *poke4_addr = (unsigned long)_free_list_17143;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_17143)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_17185);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_17185 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at172_17185); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_17185);
    _put4_1__tmp_at172_17185 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_17146);
    DeRef(_seek_1__tmp_at202_17188);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _to_be_freed_17146;
    _seek_1__tmp_at202_17188 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_17187 = machine(19, _seek_1__tmp_at202_17188);
    DeRef(_seek_1__tmp_at202_17188);
    _seek_1__tmp_at202_17188 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_17149 <= INT15 && _free_count_17149 >= -INT15)
    _9698 = 8 * _free_count_17149;
    else
    _9698 = NewDouble(8 * (double)_free_count_17149);
    _0 = _remaining_17150;
    _remaining_17150 = _18get_bytes(_38current_db_16418, _9698);
    DeRef(_0);
    _9698 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17143);
    DeRef(_seek_1__tmp_at234_17193);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _free_list_17143;
    _seek_1__tmp_at234_17193 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_17192 = machine(19, _seek_1__tmp_at234_17193);
    DeRef(_seek_1__tmp_at234_17193);
    _seek_1__tmp_at234_17193 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_17150); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_17150)){
            _9700 = SEQ_PTR(_remaining_17150)->length;
    }
    else {
        _9700 = 1;
    }
    if (IS_ATOM_INT(_new_space_17145)) {
        _9701 = _new_space_17145 - _9700;
    }
    else {
        _9701 = NewDouble(DBL_PTR(_new_space_17145)->dbl - (double)_9700);
    }
    _9700 = NOVALUE;
    _9702 = Repeat(0, _9701);
    DeRef(_9701);
    _9701 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_17199);
    _s_inlined_putn_at_274_17199 = _9702;
    _9702 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_274_17199); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_17199);
    _s_inlined_putn_at_274_17199 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17143);
    DeRef(_seek_1__tmp_at297_17202);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _free_list_17143;
    _seek_1__tmp_at297_17202 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_17201 = machine(19, _seek_1__tmp_at297_17202);
    DeRef(_seek_1__tmp_at297_17202);
    _seek_1__tmp_at297_17202 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_17145);
    _new_space_17145 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_17140);
    _i_17140 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_17147);
    _prev_addr_17147 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_17148);
    _prev_size_17148 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_17140, _free_count_17149)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_17142;
    _addr_17142 = _38get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_17141;
    _size_17141 = _38get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_17138, _addr_17142)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_17142);
    DeRef(_prev_addr_17147);
    _prev_addr_17147 = _addr_17142;

    /** 		prev_size = size*/
    Ref(_size_17141);
    DeRef(_prev_size_17148);
    _prev_size_17148 = _size_17141;

    /** 		i += 1*/
    _0 = _i_17140;
    if (IS_ATOM_INT(_i_17140)) {
        _i_17140 = _i_17140 + 1;
        if (_i_17140 > MAXINT){
            _i_17140 = NewDouble((double)_i_17140);
        }
    }
    else
    _i_17140 = binary_op(PLUS, 1, _i_17140);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_17140)) {
        _9708 = (_i_17140 > 1);
    }
    else {
        _9708 = (DBL_PTR(_i_17140)->dbl > (double)1);
    }
    if (_9708 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_17147) && IS_ATOM_INT(_prev_size_17148)) {
        _9710 = _prev_addr_17147 + _prev_size_17148;
        if ((long)((unsigned long)_9710 + (unsigned long)HIGH_BITS) >= 0) 
        _9710 = NewDouble((double)_9710);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_17147)) {
            _9710 = NewDouble((double)_prev_addr_17147 + DBL_PTR(_prev_size_17148)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_17148)) {
                _9710 = NewDouble(DBL_PTR(_prev_addr_17147)->dbl + (double)_prev_size_17148);
            }
            else
            _9710 = NewDouble(DBL_PTR(_prev_addr_17147)->dbl + DBL_PTR(_prev_size_17148)->dbl);
        }
    }
    if (IS_ATOM_INT(_9710) && IS_ATOM_INT(_p_17138)) {
        _9711 = (_9710 == _p_17138);
    }
    else {
        if (IS_ATOM_INT(_9710)) {
            _9711 = ((double)_9710 == DBL_PTR(_p_17138)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_17138)) {
                _9711 = (DBL_PTR(_9710)->dbl == (double)_p_17138);
            }
            else
            _9711 = (DBL_PTR(_9710)->dbl == DBL_PTR(_p_17138)->dbl);
        }
    }
    DeRef(_9710);
    _9710 = NOVALUE;
    if (_9711 == 0)
    {
        DeRef(_9711);
        _9711 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_9711);
        _9711 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9712 = _i_17140 - 2;
        if ((long)((unsigned long)_9712 +(unsigned long) HIGH_BITS) >= 0){
            _9712 = NewDouble((double)_9712);
        }
    }
    else {
        _9712 = NewDouble(DBL_PTR(_i_17140)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_9712)) {
        if (_9712 == (short)_9712)
        _9713 = _9712 * 8;
        else
        _9713 = NewDouble(_9712 * (double)8);
    }
    else {
        _9713 = NewDouble(DBL_PTR(_9712)->dbl * (double)8);
    }
    DeRef(_9712);
    _9712 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9713)) {
        _9714 = _free_list_17143 + _9713;
        if ((long)((unsigned long)_9714 + (unsigned long)HIGH_BITS) >= 0) 
        _9714 = NewDouble((double)_9714);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9714 = NewDouble((double)_free_list_17143 + DBL_PTR(_9713)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9713)) {
                _9714 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9713);
            }
            else
            _9714 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9713)->dbl);
        }
    }
    DeRef(_9713);
    _9713 = NOVALUE;
    if (IS_ATOM_INT(_9714)) {
        _9715 = _9714 + 4;
        if ((long)((unsigned long)_9715 + (unsigned long)HIGH_BITS) >= 0) 
        _9715 = NewDouble((double)_9715);
    }
    else {
        _9715 = NewDouble(DBL_PTR(_9714)->dbl + (double)4);
    }
    DeRef(_9714);
    _9714 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_17221);
    _pos_inlined_seek_at_427_17221 = _9715;
    _9715 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_17221);
    DeRef(_seek_1__tmp_at430_17223);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_17221;
    _seek_1__tmp_at430_17223 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_17222 = machine(19, _seek_1__tmp_at430_17223);
    DeRef(_pos_inlined_seek_at_427_17221);
    _pos_inlined_seek_at_427_17221 = NOVALUE;
    DeRef(_seek_1__tmp_at430_17223);
    _seek_1__tmp_at430_17223 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17140)) {
        _9716 = (_i_17140 < _free_count_17149);
    }
    else {
        _9716 = (DBL_PTR(_i_17140)->dbl < (double)_free_count_17149);
    }
    if (_9716 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_17138) && IS_ATOM_INT(_psize_17139)) {
        _9718 = _p_17138 + _psize_17139;
        if ((long)((unsigned long)_9718 + (unsigned long)HIGH_BITS) >= 0) 
        _9718 = NewDouble((double)_9718);
    }
    else {
        if (IS_ATOM_INT(_p_17138)) {
            _9718 = NewDouble((double)_p_17138 + DBL_PTR(_psize_17139)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17139)) {
                _9718 = NewDouble(DBL_PTR(_p_17138)->dbl + (double)_psize_17139);
            }
            else
            _9718 = NewDouble(DBL_PTR(_p_17138)->dbl + DBL_PTR(_psize_17139)->dbl);
        }
    }
    if (IS_ATOM_INT(_9718) && IS_ATOM_INT(_addr_17142)) {
        _9719 = (_9718 == _addr_17142);
    }
    else {
        if (IS_ATOM_INT(_9718)) {
            _9719 = ((double)_9718 == DBL_PTR(_addr_17142)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17142)) {
                _9719 = (DBL_PTR(_9718)->dbl == (double)_addr_17142);
            }
            else
            _9719 = (DBL_PTR(_9718)->dbl == DBL_PTR(_addr_17142)->dbl);
        }
    }
    DeRef(_9718);
    _9718 = NOVALUE;
    if (_9719 == 0)
    {
        DeRef(_9719);
        _9719 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_9719);
        _9719 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17148) && IS_ATOM_INT(_psize_17139)) {
        _9720 = _prev_size_17148 + _psize_17139;
        if ((long)((unsigned long)_9720 + (unsigned long)HIGH_BITS) >= 0) 
        _9720 = NewDouble((double)_9720);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17148)) {
            _9720 = NewDouble((double)_prev_size_17148 + DBL_PTR(_psize_17139)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17139)) {
                _9720 = NewDouble(DBL_PTR(_prev_size_17148)->dbl + (double)_psize_17139);
            }
            else
            _9720 = NewDouble(DBL_PTR(_prev_size_17148)->dbl + DBL_PTR(_psize_17139)->dbl);
        }
    }
    if (IS_ATOM_INT(_9720) && IS_ATOM_INT(_size_17141)) {
        _9721 = _9720 + _size_17141;
        if ((long)((unsigned long)_9721 + (unsigned long)HIGH_BITS) >= 0) 
        _9721 = NewDouble((double)_9721);
    }
    else {
        if (IS_ATOM_INT(_9720)) {
            _9721 = NewDouble((double)_9720 + DBL_PTR(_size_17141)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17141)) {
                _9721 = NewDouble(DBL_PTR(_9720)->dbl + (double)_size_17141);
            }
            else
            _9721 = NewDouble(DBL_PTR(_9720)->dbl + DBL_PTR(_size_17141)->dbl);
        }
    }
    DeRef(_9720);
    _9720 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_17232);
    _x_inlined_put4_at_479_17232 = _9721;
    _9721 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_17232)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_17232;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_17232)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_17233);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_17233 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at482_17233); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_17232);
    _x_inlined_put4_at_479_17232 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_17233);
    _put4_1__tmp_at482_17233 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        if (_i_17140 == (short)_i_17140)
        _9722 = _i_17140 * 8;
        else
        _9722 = NewDouble(_i_17140 * (double)8);
    }
    else {
        _9722 = NewDouble(DBL_PTR(_i_17140)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9722)) {
        _9723 = _free_list_17143 + _9722;
        if ((long)((unsigned long)_9723 + (unsigned long)HIGH_BITS) >= 0) 
        _9723 = NewDouble((double)_9723);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9723 = NewDouble((double)_free_list_17143 + DBL_PTR(_9722)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9722)) {
                _9723 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9722);
            }
            else
            _9723 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9722)->dbl);
        }
    }
    DeRef(_9722);
    _9722 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_17237);
    _pos_inlined_seek_at_520_17237 = _9723;
    _9723 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_17237);
    DeRef(_seek_1__tmp_at523_17239);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_17237;
    _seek_1__tmp_at523_17239 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_17238 = machine(19, _seek_1__tmp_at523_17239);
    DeRef(_pos_inlined_seek_at_520_17237);
    _pos_inlined_seek_at_520_17237 = NOVALUE;
    DeRef(_seek_1__tmp_at523_17239);
    _seek_1__tmp_at523_17239 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9724 = _free_count_17149 - _i_17140;
        if ((long)((unsigned long)_9724 +(unsigned long) HIGH_BITS) >= 0){
            _9724 = NewDouble((double)_9724);
        }
    }
    else {
        _9724 = NewDouble((double)_free_count_17149 - DBL_PTR(_i_17140)->dbl);
    }
    if (IS_ATOM_INT(_9724)) {
        if (_9724 == (short)_9724)
        _9725 = _9724 * 8;
        else
        _9725 = NewDouble(_9724 * (double)8);
    }
    else {
        _9725 = NewDouble(DBL_PTR(_9724)->dbl * (double)8);
    }
    DeRef(_9724);
    _9724 = NOVALUE;
    _0 = _remaining_17150;
    _remaining_17150 = _18get_bytes(_38current_db_16418, _9725);
    DeRef(_0);
    _9725 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9727 = _i_17140 - 1;
        if ((long)((unsigned long)_9727 +(unsigned long) HIGH_BITS) >= 0){
            _9727 = NewDouble((double)_9727);
        }
    }
    else {
        _9727 = NewDouble(DBL_PTR(_i_17140)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9727)) {
        if (_9727 == (short)_9727)
        _9728 = _9727 * 8;
        else
        _9728 = NewDouble(_9727 * (double)8);
    }
    else {
        _9728 = NewDouble(DBL_PTR(_9727)->dbl * (double)8);
    }
    DeRef(_9727);
    _9727 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9728)) {
        _9729 = _free_list_17143 + _9728;
        if ((long)((unsigned long)_9729 + (unsigned long)HIGH_BITS) >= 0) 
        _9729 = NewDouble((double)_9729);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9729 = NewDouble((double)_free_list_17143 + DBL_PTR(_9728)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9728)) {
                _9729 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9728);
            }
            else
            _9729 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9728)->dbl);
        }
    }
    DeRef(_9728);
    _9728 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_17247);
    _pos_inlined_seek_at_571_17247 = _9729;
    _9729 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_17247);
    DeRef(_seek_1__tmp_at574_17249);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_17247;
    _seek_1__tmp_at574_17249 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_17248 = machine(19, _seek_1__tmp_at574_17249);
    DeRef(_pos_inlined_seek_at_571_17247);
    _pos_inlined_seek_at_571_17247 = NOVALUE;
    DeRef(_seek_1__tmp_at574_17249);
    _seek_1__tmp_at574_17249 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_17150); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_17149 = _free_count_17149 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_17254);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_17254 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_17253 = machine(19, _seek_1__tmp_at611_17254);
    DeRefi(_seek_1__tmp_at611_17254);
    _seek_1__tmp_at611_17254 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17149;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_17256);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_17256 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at626_17256); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_17256);
    _put4_1__tmp_at626_17256 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17148) && IS_ATOM_INT(_psize_17139)) {
        _9731 = _prev_size_17148 + _psize_17139;
        if ((long)((unsigned long)_9731 + (unsigned long)HIGH_BITS) >= 0) 
        _9731 = NewDouble((double)_9731);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17148)) {
            _9731 = NewDouble((double)_prev_size_17148 + DBL_PTR(_psize_17139)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17139)) {
                _9731 = NewDouble(DBL_PTR(_prev_size_17148)->dbl + (double)_psize_17139);
            }
            else
            _9731 = NewDouble(DBL_PTR(_prev_size_17148)->dbl + DBL_PTR(_psize_17139)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_17260);
    _x_inlined_put4_at_661_17260 = _9731;
    _9731 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_17260)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_17260;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_17260)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_17261);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_17261 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at664_17261); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_17260);
    _x_inlined_put4_at_661_17260 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_17261);
    _put4_1__tmp_at664_17261 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17140)) {
        _9732 = (_i_17140 < _free_count_17149);
    }
    else {
        _9732 = (DBL_PTR(_i_17140)->dbl < (double)_free_count_17149);
    }
    if (_9732 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_17138) && IS_ATOM_INT(_psize_17139)) {
        _9734 = _p_17138 + _psize_17139;
        if ((long)((unsigned long)_9734 + (unsigned long)HIGH_BITS) >= 0) 
        _9734 = NewDouble((double)_9734);
    }
    else {
        if (IS_ATOM_INT(_p_17138)) {
            _9734 = NewDouble((double)_p_17138 + DBL_PTR(_psize_17139)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17139)) {
                _9734 = NewDouble(DBL_PTR(_p_17138)->dbl + (double)_psize_17139);
            }
            else
            _9734 = NewDouble(DBL_PTR(_p_17138)->dbl + DBL_PTR(_psize_17139)->dbl);
        }
    }
    if (IS_ATOM_INT(_9734) && IS_ATOM_INT(_addr_17142)) {
        _9735 = (_9734 == _addr_17142);
    }
    else {
        if (IS_ATOM_INT(_9734)) {
            _9735 = ((double)_9734 == DBL_PTR(_addr_17142)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17142)) {
                _9735 = (DBL_PTR(_9734)->dbl == (double)_addr_17142);
            }
            else
            _9735 = (DBL_PTR(_9734)->dbl == DBL_PTR(_addr_17142)->dbl);
        }
    }
    DeRef(_9734);
    _9734 = NOVALUE;
    if (_9735 == 0)
    {
        DeRef(_9735);
        _9735 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_9735);
        _9735 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9736 = _i_17140 - 1;
        if ((long)((unsigned long)_9736 +(unsigned long) HIGH_BITS) >= 0){
            _9736 = NewDouble((double)_9736);
        }
    }
    else {
        _9736 = NewDouble(DBL_PTR(_i_17140)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9736)) {
        if (_9736 == (short)_9736)
        _9737 = _9736 * 8;
        else
        _9737 = NewDouble(_9736 * (double)8);
    }
    else {
        _9737 = NewDouble(DBL_PTR(_9736)->dbl * (double)8);
    }
    DeRef(_9736);
    _9736 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9737)) {
        _9738 = _free_list_17143 + _9737;
        if ((long)((unsigned long)_9738 + (unsigned long)HIGH_BITS) >= 0) 
        _9738 = NewDouble((double)_9738);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9738 = NewDouble((double)_free_list_17143 + DBL_PTR(_9737)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9737)) {
                _9738 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9737);
            }
            else
            _9738 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9737)->dbl);
        }
    }
    DeRef(_9737);
    _9737 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_17271);
    _pos_inlined_seek_at_734_17271 = _9738;
    _9738 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_17271);
    DeRef(_seek_1__tmp_at737_17273);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_17271;
    _seek_1__tmp_at737_17273 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_17272 = machine(19, _seek_1__tmp_at737_17273);
    DeRef(_pos_inlined_seek_at_734_17271);
    _pos_inlined_seek_at_734_17271 = NOVALUE;
    DeRef(_seek_1__tmp_at737_17273);
    _seek_1__tmp_at737_17273 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_p_17138)) {
        *poke4_addr = (unsigned long)_p_17138;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17138)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_17275);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_17275 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at752_17275); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_17275);
    _put4_1__tmp_at752_17275 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_17139) && IS_ATOM_INT(_size_17141)) {
        _9739 = _psize_17139 + _size_17141;
        if ((long)((unsigned long)_9739 + (unsigned long)HIGH_BITS) >= 0) 
        _9739 = NewDouble((double)_9739);
    }
    else {
        if (IS_ATOM_INT(_psize_17139)) {
            _9739 = NewDouble((double)_psize_17139 + DBL_PTR(_size_17141)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17141)) {
                _9739 = NewDouble(DBL_PTR(_psize_17139)->dbl + (double)_size_17141);
            }
            else
            _9739 = NewDouble(DBL_PTR(_psize_17139)->dbl + DBL_PTR(_size_17141)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_17278);
    _x_inlined_put4_at_786_17278 = _9739;
    _9739 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_17278)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_17278;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_17278)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_17279);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_17279 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at789_17279); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_17278);
    _x_inlined_put4_at_786_17278 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_17279);
    _put4_1__tmp_at789_17279 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9740 = _i_17140 - 1;
        if ((long)((unsigned long)_9740 +(unsigned long) HIGH_BITS) >= 0){
            _9740 = NewDouble((double)_9740);
        }
    }
    else {
        _9740 = NewDouble(DBL_PTR(_i_17140)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9740)) {
        if (_9740 == (short)_9740)
        _9741 = _9740 * 8;
        else
        _9741 = NewDouble(_9740 * (double)8);
    }
    else {
        _9741 = NewDouble(DBL_PTR(_9740)->dbl * (double)8);
    }
    DeRef(_9740);
    _9740 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9741)) {
        _9742 = _free_list_17143 + _9741;
        if ((long)((unsigned long)_9742 + (unsigned long)HIGH_BITS) >= 0) 
        _9742 = NewDouble((double)_9742);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9742 = NewDouble((double)_free_list_17143 + DBL_PTR(_9741)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9741)) {
                _9742 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9741);
            }
            else
            _9742 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9741)->dbl);
        }
    }
    DeRef(_9741);
    _9741 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_17285);
    _pos_inlined_seek_at_834_17285 = _9742;
    _9742 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_17285);
    DeRef(_seek_1__tmp_at837_17287);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_17285;
    _seek_1__tmp_at837_17287 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_17286 = machine(19, _seek_1__tmp_at837_17287);
    DeRef(_pos_inlined_seek_at_834_17285);
    _pos_inlined_seek_at_834_17285 = NOVALUE;
    DeRef(_seek_1__tmp_at837_17287);
    _seek_1__tmp_at837_17287 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9743 = _free_count_17149 - _i_17140;
        if ((long)((unsigned long)_9743 +(unsigned long) HIGH_BITS) >= 0){
            _9743 = NewDouble((double)_9743);
        }
    }
    else {
        _9743 = NewDouble((double)_free_count_17149 - DBL_PTR(_i_17140)->dbl);
    }
    if (IS_ATOM_INT(_9743)) {
        _9744 = _9743 + 1;
        if (_9744 > MAXINT){
            _9744 = NewDouble((double)_9744);
        }
    }
    else
    _9744 = binary_op(PLUS, 1, _9743);
    DeRef(_9743);
    _9743 = NOVALUE;
    if (IS_ATOM_INT(_9744)) {
        if (_9744 == (short)_9744)
        _9745 = _9744 * 8;
        else
        _9745 = NewDouble(_9744 * (double)8);
    }
    else {
        _9745 = NewDouble(DBL_PTR(_9744)->dbl * (double)8);
    }
    DeRef(_9744);
    _9744 = NOVALUE;
    _0 = _remaining_17150;
    _remaining_17150 = _18get_bytes(_38current_db_16418, _9745);
    DeRef(_0);
    _9745 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_17149 = _free_count_17149 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_17295);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_17295 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_17294 = machine(19, _seek_1__tmp_at883_17295);
    DeRefi(_seek_1__tmp_at883_17295);
    _seek_1__tmp_at883_17295 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17149;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_17297);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_17297 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at898_17297); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_17297);
    _put4_1__tmp_at898_17297 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17140)) {
        _9748 = _i_17140 - 1;
        if ((long)((unsigned long)_9748 +(unsigned long) HIGH_BITS) >= 0){
            _9748 = NewDouble((double)_9748);
        }
    }
    else {
        _9748 = NewDouble(DBL_PTR(_i_17140)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9748)) {
        if (_9748 == (short)_9748)
        _9749 = _9748 * 8;
        else
        _9749 = NewDouble(_9748 * (double)8);
    }
    else {
        _9749 = NewDouble(DBL_PTR(_9748)->dbl * (double)8);
    }
    DeRef(_9748);
    _9748 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17143) && IS_ATOM_INT(_9749)) {
        _9750 = _free_list_17143 + _9749;
        if ((long)((unsigned long)_9750 + (unsigned long)HIGH_BITS) >= 0) 
        _9750 = NewDouble((double)_9750);
    }
    else {
        if (IS_ATOM_INT(_free_list_17143)) {
            _9750 = NewDouble((double)_free_list_17143 + DBL_PTR(_9749)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9749)) {
                _9750 = NewDouble(DBL_PTR(_free_list_17143)->dbl + (double)_9749);
            }
            else
            _9750 = NewDouble(DBL_PTR(_free_list_17143)->dbl + DBL_PTR(_9749)->dbl);
        }
    }
    DeRef(_9749);
    _9749 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_17302);
    _pos_inlined_seek_at_940_17302 = _9750;
    _9750 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_17302);
    DeRef(_seek_1__tmp_at943_17304);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_17302;
    _seek_1__tmp_at943_17304 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_17303 = machine(19, _seek_1__tmp_at943_17304);
    DeRef(_pos_inlined_seek_at_940_17302);
    _pos_inlined_seek_at_940_17302 = NOVALUE;
    DeRef(_seek_1__tmp_at943_17304);
    _seek_1__tmp_at943_17304 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_p_17138)) {
        *poke4_addr = (unsigned long)_p_17138;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17138)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_17306);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_17306 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at958_17306); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_17306);
    _put4_1__tmp_at958_17306 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_psize_17139)) {
        *poke4_addr = (unsigned long)_psize_17139;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_17139)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_17308);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_17308 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at986_17308); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_17308);
    _put4_1__tmp_at986_17308 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_17150); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_17145 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_17145) && DBL_PTR(_new_space_17145)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_17146);
    _38db_free(_to_be_freed_17146);
L17: 

    /** end procedure*/
    DeRef(_p_17138);
    DeRef(_psize_17139);
    DeRef(_i_17140);
    DeRef(_size_17141);
    DeRef(_addr_17142);
    DeRef(_free_list_17143);
    DeRef(_free_list_space_17144);
    DeRef(_new_space_17145);
    DeRef(_to_be_freed_17146);
    DeRef(_prev_addr_17147);
    DeRef(_prev_size_17148);
    DeRef(_remaining_17150);
    DeRef(_9708);
    _9708 = NOVALUE;
    DeRef(_9716);
    _9716 = NOVALUE;
    DeRef(_9732);
    _9732 = NOVALUE;
    return;
    ;
}


void _38save_keys()
{
    int _k_17313 = NOVALUE;
    int _9757 = NOVALUE;
    int _9753 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/
    if (_38caching_option_16428 != 1)
    goto L1; // [5] 82

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _38current_table_pos_16419, 0)){
        goto L2; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _9753 = MAKE_SEQ(_1);
    _k_17313 = find_from(_9753, _38cache_index_16427, 1);
    DeRefDS(_9753);
    _9753 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_17313 == 0)
    goto L3; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_38key_pointers_16425);
    _2 = (int)SEQ_PTR(_38key_cache_16426);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38key_cache_16426 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_17313);
    _1 = *(int *)_2;
    *(int *)_2 = _38key_pointers_16425;
    DeRef(_1);
    goto L4; // [50] 80
L3: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_38key_pointers_16425);
    Append(&_38key_cache_16426, _38key_cache_16426, _38key_pointers_16425);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_38current_table_pos_16419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _9757 = MAKE_SEQ(_1);
    RefDS(_9757);
    Append(&_38cache_index_16427, _38cache_index_16427, _9757);
    DeRefDS(_9757);
    _9757 = NOVALUE;
L4: 
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _38db_connect(int _dbalias_17328, int _path_17329, int _dboptions_17330)
{
    int _lPos_17331 = NOVALUE;
    int _lOptions_17332 = NOVALUE;
    int _9814 = NOVALUE;
    int _9813 = NOVALUE;
    int _9812 = NOVALUE;
    int _9809 = NOVALUE;
    int _9806 = NOVALUE;
    int _9805 = NOVALUE;
    int _9804 = NOVALUE;
    int _9803 = NOVALUE;
    int _9801 = NOVALUE;
    int _9800 = NOVALUE;
    int _9799 = NOVALUE;
    int _9798 = NOVALUE;
    int _9797 = NOVALUE;
    int _9796 = NOVALUE;
    int _9795 = NOVALUE;
    int _9792 = NOVALUE;
    int _9791 = NOVALUE;
    int _9790 = NOVALUE;
    int _9788 = NOVALUE;
    int _9787 = NOVALUE;
    int _9786 = NOVALUE;
    int _9784 = NOVALUE;
    int _9783 = NOVALUE;
    int _9782 = NOVALUE;
    int _9781 = NOVALUE;
    int _9780 = NOVALUE;
    int _9778 = NOVALUE;
    int _9776 = NOVALUE;
    int _9775 = NOVALUE;
    int _9773 = NOVALUE;
    int _9772 = NOVALUE;
    int _9771 = NOVALUE;
    int _9770 = NOVALUE;
    int _9769 = NOVALUE;
    int _9768 = NOVALUE;
    int _9767 = NOVALUE;
    int _9765 = NOVALUE;
    int _9762 = NOVALUE;
    int _9760 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	lPos = find(dbalias, Known_Aliases)*/
    _lPos_17331 = find_from(_dbalias_17328, _38Known_Aliases_16439, 1);

    /** 	if lPos then*/
    if (_lPos_17331 == 0)
    {
        goto L1; // [18] 108
    }
    else{
    }

    /** 		if equal(dboptions, DISCONNECT) or find(DISCONNECT, dboptions) then*/
    if (_dboptions_17330 == _38DISCONNECT_16429)
    _9760 = 1;
    else if (IS_ATOM_INT(_dboptions_17330) && IS_ATOM_INT(_38DISCONNECT_16429))
    _9760 = 0;
    else
    _9760 = (compare(_dboptions_17330, _38DISCONNECT_16429) == 0);
    if (_9760 != 0) {
        goto L2; // [27] 41
    }
    _9762 = find_from(_38DISCONNECT_16429, _dboptions_17330, 1);
    if (_9762 == 0)
    {
        _9762 = NOVALUE;
        goto L3; // [37] 66
    }
    else{
        _9762 = NOVALUE;
    }
L2: 

    /** 			Known_Aliases = remove(Known_Aliases, lPos)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38Known_Aliases_16439);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPos_17331)) ? _lPos_17331 : (long)(DBL_PTR(_lPos_17331)->dbl);
        int stop = (IS_ATOM_INT(_lPos_17331)) ? _lPos_17331 : (long)(DBL_PTR(_lPos_17331)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38Known_Aliases_16439), start, &_38Known_Aliases_16439 );
            }
            else Tail(SEQ_PTR(_38Known_Aliases_16439), stop+1, &_38Known_Aliases_16439);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38Known_Aliases_16439), start, &_38Known_Aliases_16439);
        }
        else {
            assign_slice_seq = &assign_space;
            _38Known_Aliases_16439 = Remove_elements(start, stop, (SEQ_PTR(_38Known_Aliases_16439)->ref == 1));
        }
    }

    /** 			Alias_Details = remove(Alias_Details, lPos)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38Alias_Details_16440);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPos_17331)) ? _lPos_17331 : (long)(DBL_PTR(_lPos_17331)->dbl);
        int stop = (IS_ATOM_INT(_lPos_17331)) ? _lPos_17331 : (long)(DBL_PTR(_lPos_17331)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38Alias_Details_16440), start, &_38Alias_Details_16440 );
            }
            else Tail(SEQ_PTR(_38Alias_Details_16440), stop+1, &_38Alias_Details_16440);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38Alias_Details_16440), start, &_38Alias_Details_16440);
        }
        else {
            assign_slice_seq = &assign_space;
            _38Alias_Details_16440 = Remove_elements(start, stop, (SEQ_PTR(_38Alias_Details_16440)->ref == 1));
        }
    }

    /** 			return DB_OK*/
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRef(_lOptions_17332);
    return 0;
L3: 

    /** 		if equal(dboptions, CONNECTION) or find(CONNECTION, dboptions) then*/
    if (_dboptions_17330 == _38CONNECTION_16437)
    _9765 = 1;
    else if (IS_ATOM_INT(_dboptions_17330) && IS_ATOM_INT(_38CONNECTION_16437))
    _9765 = 0;
    else
    _9765 = (compare(_dboptions_17330, _38CONNECTION_16437) == 0);
    if (_9765 != 0) {
        goto L4; // [72] 86
    }
    _9767 = find_from(_38CONNECTION_16437, _dboptions_17330, 1);
    if (_9767 == 0)
    {
        _9767 = NOVALUE;
        goto L5; // [82] 99
    }
    else{
        _9767 = NOVALUE;
    }
L4: 

    /** 			return Alias_Details[lPos]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9768 = (int)*(((s1_ptr)_2)->base + _lPos_17331);
    Ref(_9768);
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRef(_lOptions_17332);
    return _9768;
L5: 

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRef(_lOptions_17332);
    _9768 = NOVALUE;
    return -1;
    goto L6; // [105] 161
L1: 

    /** 		if equal(dboptions, DISCONNECT) or find(DISCONNECT, dboptions) or*/
    if (_dboptions_17330 == _38DISCONNECT_16429)
    _9769 = 1;
    else if (IS_ATOM_INT(_dboptions_17330) && IS_ATOM_INT(_38DISCONNECT_16429))
    _9769 = 0;
    else
    _9769 = (compare(_dboptions_17330, _38DISCONNECT_16429) == 0);
    if (_9769 != 0) {
        _9770 = 1;
        goto L7; // [114] 127
    }
    _9771 = find_from(_38DISCONNECT_16429, _dboptions_17330, 1);
    _9770 = (_9771 != 0);
L7: 
    if (_9770 != 0) {
        _9772 = 1;
        goto L8; // [127] 139
    }
    if (_dboptions_17330 == _38CONNECTION_16437)
    _9773 = 1;
    else if (IS_ATOM_INT(_dboptions_17330) && IS_ATOM_INT(_38CONNECTION_16437))
    _9773 = 0;
    else
    _9773 = (compare(_dboptions_17330, _38CONNECTION_16437) == 0);
    _9772 = (_9773 != 0);
L8: 
    if (_9772 != 0) {
        goto L9; // [139] 153
    }
    _9775 = find_from(_38CONNECTION_16437, _dboptions_17330, 1);
    if (_9775 == 0)
    {
        _9775 = NOVALUE;
        goto LA; // [149] 160
    }
    else{
        _9775 = NOVALUE;
    }
L9: 

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRef(_lOptions_17332);
    _9768 = NOVALUE;
    return -1;
LA: 
L6: 

    /** 	if length(path) = 0 then*/
    if (IS_SEQUENCE(_path_17329)){
            _9776 = SEQ_PTR(_path_17329)->length;
    }
    else {
        _9776 = 1;
    }
    if (_9776 != 0)
    goto LB; // [166] 177

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRef(_lOptions_17332);
    _9768 = NOVALUE;
    return -1;
LB: 

    /** 	if types:string(dboptions) then*/
    RefDS(_dboptions_17330);
    _9778 = _7string(_dboptions_17330);
    if (_9778 == 0) {
        DeRef(_9778);
        _9778 = NOVALUE;
        goto LC; // [183] 261
    }
    else {
        if (!IS_ATOM_INT(_9778) && DBL_PTR(_9778)->dbl == 0.0){
            DeRef(_9778);
            _9778 = NOVALUE;
            goto LC; // [183] 261
        }
        DeRef(_9778);
        _9778 = NOVALUE;
    }
    DeRef(_9778);
    _9778 = NOVALUE;

    /** 		dboptions = text:keyvalues(dboptions)*/
    RefDS(_dboptions_17330);
    RefDS(_5298);
    RefDS(_5299);
    RefDS(_5300);
    RefDS(_307);
    _0 = _dboptions_17330;
    _dboptions_17330 = _6keyvalues(_dboptions_17330, _5298, _5299, _5300, _307, 1);
    DeRefDS(_0);

    /** 		for i = 1 to length(dboptions) do*/
    if (IS_SEQUENCE(_dboptions_17330)){
            _9780 = SEQ_PTR(_dboptions_17330)->length;
    }
    else {
        _9780 = 1;
    }
    {
        int _i_17362;
        _i_17362 = 1;
LD: 
        if (_i_17362 > _9780){
            goto LE; // [204] 260
        }

        /** 			if types:string(dboptions[i][2]) then*/
        _2 = (int)SEQ_PTR(_dboptions_17330);
        _9781 = (int)*(((s1_ptr)_2)->base + _i_17362);
        _2 = (int)SEQ_PTR(_9781);
        _9782 = (int)*(((s1_ptr)_2)->base + 2);
        _9781 = NOVALUE;
        Ref(_9782);
        _9783 = _7string(_9782);
        _9782 = NOVALUE;
        if (_9783 == 0) {
            DeRef(_9783);
            _9783 = NOVALUE;
            goto LF; // [225] 253
        }
        else {
            if (!IS_ATOM_INT(_9783) && DBL_PTR(_9783)->dbl == 0.0){
                DeRef(_9783);
                _9783 = NOVALUE;
                goto LF; // [225] 253
            }
            DeRef(_9783);
            _9783 = NOVALUE;
        }
        DeRef(_9783);
        _9783 = NOVALUE;

        /** 				dboptions[i][2] = convert:to_number(dboptions[i][2])*/
        _2 = (int)SEQ_PTR(_dboptions_17330);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dboptions_17330 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_17362 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_dboptions_17330);
        _9786 = (int)*(((s1_ptr)_2)->base + _i_17362);
        _2 = (int)SEQ_PTR(_9786);
        _9787 = (int)*(((s1_ptr)_2)->base + 2);
        _9786 = NOVALUE;
        Ref(_9787);
        _9788 = _8to_number(_9787, 0);
        _9787 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _9788;
        if( _1 != _9788 ){
            DeRef(_1);
        }
        _9788 = NOVALUE;
        _9784 = NOVALUE;
LF: 

        /** 		end for*/
        _i_17362 = _i_17362 + 1;
        goto LD; // [255] 211
LE: 
        ;
    }
LC: 

    /** 	lOptions = {DB_LOCK_NO, DEF_INIT_TABLES, DEF_INIT_TABLES}*/
    _0 = _lOptions_17332;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 5;
    *((int *)(_2+12)) = 5;
    _lOptions_17332 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(dboptions) do*/
    if (IS_SEQUENCE(_dboptions_17330)){
            _9790 = SEQ_PTR(_dboptions_17330)->length;
    }
    else {
        _9790 = 1;
    }
    {
        int _i_17375;
        _i_17375 = 1;
L10: 
        if (_i_17375 > _9790){
            goto L11; // [274] 374
        }

        /** 		switch dboptions[i][1] do*/
        _2 = (int)SEQ_PTR(_dboptions_17330);
        _9791 = (int)*(((s1_ptr)_2)->base + _i_17375);
        _2 = (int)SEQ_PTR(_9791);
        _9792 = (int)*(((s1_ptr)_2)->base + 1);
        _9791 = NOVALUE;
        _1 = find(_9792, _9793);
        _9792 = NOVALUE;
        switch ( _1 ){ 

            /** 			case LOCK_METHOD then*/
            case 1:

            /** 				lOptions[CONNECT_LOCK] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17330);
            _9795 = (int)*(((s1_ptr)_2)->base + _i_17375);
            _2 = (int)SEQ_PTR(_9795);
            _9796 = (int)*(((s1_ptr)_2)->base + 2);
            _9795 = NOVALUE;
            Ref(_9796);
            _2 = (int)SEQ_PTR(_lOptions_17332);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17332 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _9796;
            if( _1 != _9796 ){
                DeRef(_1);
            }
            _9796 = NOVALUE;
            goto L12; // [314] 367

            /** 			case INIT_TABLES then*/
            case 2:

            /** 				lOptions[CONNECT_TABLES] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17330);
            _9797 = (int)*(((s1_ptr)_2)->base + _i_17375);
            _2 = (int)SEQ_PTR(_9797);
            _9798 = (int)*(((s1_ptr)_2)->base + 2);
            _9797 = NOVALUE;
            Ref(_9798);
            _2 = (int)SEQ_PTR(_lOptions_17332);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17332 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _9798;
            if( _1 != _9798 ){
                DeRef(_1);
            }
            _9798 = NOVALUE;
            goto L12; // [334] 367

            /** 			case INIT_FREE then*/
            case 3:

            /** 				lOptions[CONNECT_FREE] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17330);
            _9799 = (int)*(((s1_ptr)_2)->base + _i_17375);
            _2 = (int)SEQ_PTR(_9799);
            _9800 = (int)*(((s1_ptr)_2)->base + 2);
            _9799 = NOVALUE;
            Ref(_9800);
            _2 = (int)SEQ_PTR(_lOptions_17332);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17332 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 3);
            _1 = *(int *)_2;
            *(int *)_2 = _9800;
            if( _1 != _9800 ){
                DeRef(_1);
            }
            _9800 = NOVALUE;
            goto L12; // [354] 367

            /** 			case else				*/
            case 0:

            /** 				return DB_OPEN_FAIL*/
            DeRefDS(_dbalias_17328);
            DeRefDS(_path_17329);
            DeRefDS(_dboptions_17330);
            DeRef(_lOptions_17332);
            _9768 = NOVALUE;
            return -1;
        ;}L12: 

        /** 	end for*/
        _i_17375 = _i_17375 + 1;
        goto L10; // [369] 281
L11: 
        ;
    }

    /** 	if lOptions[CONNECT_TABLES] < 1 then*/
    _2 = (int)SEQ_PTR(_lOptions_17332);
    _9801 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _9801, 1)){
        _9801 = NOVALUE;
        goto L13; // [380] 391
    }
    _9801 = NOVALUE;

    /** 		lOptions[CONNECT_TABLES] = DEF_INIT_TABLES*/
    _2 = (int)SEQ_PTR(_lOptions_17332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
L13: 

    /** 	lOptions[CONNECT_FREE] = math:min({lOptions[CONNECT_TABLES], MAX_INDEX})*/
    _2 = (int)SEQ_PTR(_lOptions_17332);
    _9803 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9803);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9803;
    ((int *)_2)[2] = 10;
    _9804 = MAKE_SEQ(_1);
    _9803 = NOVALUE;
    _9805 = _20min(_9804);
    _9804 = NOVALUE;
    _2 = (int)SEQ_PTR(_lOptions_17332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _9805;
    if( _1 != _9805 ){
        DeRef(_1);
    }
    _9805 = NOVALUE;

    /** 	if lOptions[CONNECT_FREE] < 1 then*/
    _2 = (int)SEQ_PTR(_lOptions_17332);
    _9806 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _9806, 1)){
        _9806 = NOVALUE;
        goto L14; // [415] 430
    }
    _9806 = NOVALUE;

    /** 		lOptions[CONNECT_FREE] = math:min({DEF_INIT_TABLES, MAX_INDEX})*/
    RefDS(_9808);
    _9809 = _20min(_9808);
    _2 = (int)SEQ_PTR(_lOptions_17332);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17332 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _9809;
    if( _1 != _9809 ){
        DeRef(_1);
    }
    _9809 = NOVALUE;
L14: 

    /** 	Known_Aliases = append(Known_Aliases, dbalias)*/
    RefDS(_dbalias_17328);
    Append(&_38Known_Aliases_16439, _38Known_Aliases_16439, _dbalias_17328);

    /** 	Alias_Details = append(Alias_Details, { filesys:canonical_path( filesys:defaultext(path, "edb") ) , lOptions})*/
    RefDS(_path_17329);
    RefDS(_9811);
    _9812 = _11defaultext(_path_17329, _9811);
    _9813 = _11canonical_path(_9812, 0, 0);
    _9812 = NOVALUE;
    RefDS(_lOptions_17332);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9813;
    ((int *)_2)[2] = _lOptions_17332;
    _9814 = MAKE_SEQ(_1);
    _9813 = NOVALUE;
    RefDS(_9814);
    Append(&_38Alias_Details_16440, _38Alias_Details_16440, _9814);
    DeRefDS(_9814);
    _9814 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_dbalias_17328);
    DeRefDS(_path_17329);
    DeRefDS(_dboptions_17330);
    DeRefDS(_lOptions_17332);
    _9768 = NOVALUE;
    return 0;
    ;
}
int db_connect() __attribute__ ((alias ("_38db_connect")));


int _38db_create(int _path_17410, int _lock_method_17411, int _init_tables_17412, int _init_free_17413)
{
    int _db_17414 = NOVALUE;
    int _lock_file_1__tmp_at222_17453 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_17452 = NOVALUE;
    int _put4_1__tmp_at342_17462 = NOVALUE;
    int _put4_1__tmp_at370_17464 = NOVALUE;
    int _put4_1__tmp_at413_17470 = NOVALUE;
    int _x_inlined_put4_at_410_17469 = NOVALUE;
    int _put4_1__tmp_at452_17475 = NOVALUE;
    int _x_inlined_put4_at_449_17474 = NOVALUE;
    int _put4_1__tmp_at480_17477 = NOVALUE;
    int _s_inlined_putn_at_516_17481 = NOVALUE;
    int _put4_1__tmp_at548_17486 = NOVALUE;
    int _x_inlined_put4_at_545_17485 = NOVALUE;
    int _s_inlined_putn_at_584_17490 = NOVALUE;
    int _9855 = NOVALUE;
    int _9854 = NOVALUE;
    int _9853 = NOVALUE;
    int _9852 = NOVALUE;
    int _9851 = NOVALUE;
    int _9850 = NOVALUE;
    int _9849 = NOVALUE;
    int _9848 = NOVALUE;
    int _9847 = NOVALUE;
    int _9846 = NOVALUE;
    int _9845 = NOVALUE;
    int _9828 = NOVALUE;
    int _9826 = NOVALUE;
    int _9825 = NOVALUE;
    int _9823 = NOVALUE;
    int _9822 = NOVALUE;
    int _9820 = NOVALUE;
    int _9819 = NOVALUE;
    int _9817 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17411)) {
        _1 = (long)(DBL_PTR(_lock_method_17411)->dbl);
        DeRefDS(_lock_method_17411);
        _lock_method_17411 = _1;
    }
    if (!IS_ATOM_INT(_init_tables_17412)) {
        _1 = (long)(DBL_PTR(_init_tables_17412)->dbl);
        DeRefDS(_init_tables_17412);
        _init_tables_17412 = _1;
    }
    if (!IS_ATOM_INT(_init_free_17413)) {
        _1 = (long)(DBL_PTR(_init_free_17413)->dbl);
        DeRefDS(_init_free_17413);
        _init_free_17413 = _1;
    }

    /** 	db = find(path, Known_Aliases)*/
    _db_17414 = find_from(_path_17410, _38Known_Aliases_16439, 1);

    /** 	if db then*/
    if (_db_17414 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9817 = (int)*(((s1_ptr)_2)->base + _db_17414);
    DeRefDS(_path_17410);
    _2 = (int)SEQ_PTR(_9817);
    _path_17410 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17410);
    _9817 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9819 = (int)*(((s1_ptr)_2)->base + _db_17414);
    _2 = (int)SEQ_PTR(_9819);
    _9820 = (int)*(((s1_ptr)_2)->base + 2);
    _9819 = NOVALUE;
    _2 = (int)SEQ_PTR(_9820);
    _lock_method_17411 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17411)){
        _lock_method_17411 = (long)DBL_PTR(_lock_method_17411)->dbl;
    }
    _9820 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9822 = (int)*(((s1_ptr)_2)->base + _db_17414);
    _2 = (int)SEQ_PTR(_9822);
    _9823 = (int)*(((s1_ptr)_2)->base + 2);
    _9822 = NOVALUE;
    _2 = (int)SEQ_PTR(_9823);
    _init_tables_17412 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_17412)){
        _init_tables_17412 = (long)DBL_PTR(_init_tables_17412)->dbl;
    }
    _9823 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9825 = (int)*(((s1_ptr)_2)->base + _db_17414);
    _2 = (int)SEQ_PTR(_9825);
    _9826 = (int)*(((s1_ptr)_2)->base + 2);
    _9825 = NOVALUE;
    _2 = (int)SEQ_PTR(_9826);
    _init_free_17413 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_17413)){
        _init_free_17413 = (long)DBL_PTR(_init_free_17413)->dbl;
    }
    _9826 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_17410);
    RefDS(_9811);
    _9828 = _11defaultext(_path_17410, _9811);
    _0 = _path_17410;
    _path_17410 = _11canonical_path(_9828, 0, 0);
    DeRefDS(_0);
    _9828 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_17412 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_17412 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_17413 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_17413 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_17414 = EOpen(_path_17410, _1284, 0);

    /** 	if db != -1 then*/
    if (_db_17414 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_17414);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_17410);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_17414 = EOpen(_path_17410, _1325, 0);

    /** 	if db = -1 then*/
    if (_db_17414 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17410);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_17414);

    /** 	db = open(path, "ub")*/
    _db_17414 = EOpen(_path_17410, _9836, 0);

    /** 	if db = -1 then*/
    if (_db_17414 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17410);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17411 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_17411 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17411 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_17453;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17414;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_17453 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_17452 = machine(61, _lock_file_1__tmp_at222_17453);
    DeRef(_lock_file_1__tmp_at222_17453);
    _lock_file_1__tmp_at222_17453 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_17452 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17410);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db*/
    _38current_db_16418 = _db_17414;

    /** 	current_lock = lock_method*/
    _38current_lock_16424 = _lock_method_17411;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_17410);
    Append(&_38db_names_16421, _38db_names_16421, _path_17410);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_38db_lock_methods_16423, _38db_lock_methods_16423, _lock_method_17411);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_38db_file_nums_16422, _38db_file_nums_16422, _db_17414);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16418, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16418, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16418, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_17462);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_17462 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at342_17462); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_17462);
    _put4_1__tmp_at342_17462 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_17464);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_17464 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at370_17464); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_17464);
    _put4_1__tmp_at370_17464 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_17412 == (short)_init_tables_17412)
    _9845 = _init_tables_17412 * 16;
    else
    _9845 = NewDouble(_init_tables_17412 * (double)16);
    if (IS_ATOM_INT(_9845)) {
        _9846 = 23 + _9845;
        if ((long)((unsigned long)_9846 + (unsigned long)HIGH_BITS) >= 0) 
        _9846 = NewDouble((double)_9846);
    }
    else {
        _9846 = NewDouble((double)23 + DBL_PTR(_9845)->dbl);
    }
    DeRef(_9845);
    _9845 = NOVALUE;
    if (IS_ATOM_INT(_9846)) {
        _9847 = _9846 + 4;
        if ((long)((unsigned long)_9847 + (unsigned long)HIGH_BITS) >= 0) 
        _9847 = NewDouble((double)_9847);
    }
    else {
        _9847 = NewDouble(DBL_PTR(_9846)->dbl + (double)4);
    }
    DeRef(_9846);
    _9846 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_17469);
    _x_inlined_put4_at_410_17469 = _9847;
    _9847 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_17469)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_17469;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_17469)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_17470);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_17470 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at413_17470); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_17469);
    _x_inlined_put4_at_410_17469 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_17470);
    _put4_1__tmp_at413_17470 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_17412 == (short)_init_tables_17412)
    _9848 = _init_tables_17412 * 16;
    else
    _9848 = NewDouble(_init_tables_17412 * (double)16);
    if (IS_ATOM_INT(_9848)) {
        _9849 = 8 + _9848;
        if ((long)((unsigned long)_9849 + (unsigned long)HIGH_BITS) >= 0) 
        _9849 = NewDouble((double)_9849);
    }
    else {
        _9849 = NewDouble((double)8 + DBL_PTR(_9848)->dbl);
    }
    DeRef(_9848);
    _9848 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_17474);
    _x_inlined_put4_at_449_17474 = _9849;
    _9849 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_17474)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_17474;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_17474)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_17475);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_17475 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at452_17475); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_17474);
    _x_inlined_put4_at_449_17474 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_17475);
    _put4_1__tmp_at452_17475 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_17477);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_17477 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at480_17477); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_17477);
    _put4_1__tmp_at480_17477 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _9850 = _init_tables_17412 * 16;
    _9851 = Repeat(0, _9850);
    _9850 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_17481);
    _s_inlined_putn_at_516_17481 = _9851;
    _9851 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_516_17481); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_17481);
    _s_inlined_putn_at_516_17481 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_17413 == (short)_init_free_17413)
    _9852 = _init_free_17413 * 8;
    else
    _9852 = NewDouble(_init_free_17413 * (double)8);
    if (IS_ATOM_INT(_9852)) {
        _9853 = 4 + _9852;
        if ((long)((unsigned long)_9853 + (unsigned long)HIGH_BITS) >= 0) 
        _9853 = NewDouble((double)_9853);
    }
    else {
        _9853 = NewDouble((double)4 + DBL_PTR(_9852)->dbl);
    }
    DeRef(_9852);
    _9852 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_17485);
    _x_inlined_put4_at_545_17485 = _9853;
    _9853 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_17485)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_17485;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_17485)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_17486);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_17486 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at548_17486); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_17485);
    _x_inlined_put4_at_545_17485 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_17486);
    _put4_1__tmp_at548_17486 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _9854 = _init_free_17413 * 8;
    _9855 = Repeat(0, _9854);
    _9854 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_17490);
    _s_inlined_putn_at_584_17490 = _9855;
    _9855 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_584_17490); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_17490);
    _s_inlined_putn_at_584_17490 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_17410);
    return 0;
    ;
}
int db_create() __attribute__ ((alias ("_38db_create")));


int _38db_open(int _path_17493, int _lock_method_17494)
{
    int _db_17495 = NOVALUE;
    int _magic_17496 = NOVALUE;
    int _lock_file_1__tmp_at129_17521 = NOVALUE;
    int _lock_file_inlined_lock_file_at_129_17520 = NOVALUE;
    int _lock_file_1__tmp_at169_17528 = NOVALUE;
    int _lock_file_inlined_lock_file_at_169_17527 = NOVALUE;
    int _9866 = NOVALUE;
    int _9864 = NOVALUE;
    int _9862 = NOVALUE;
    int _9860 = NOVALUE;
    int _9859 = NOVALUE;
    int _9857 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17494)) {
        _1 = (long)(DBL_PTR(_lock_method_17494)->dbl);
        DeRefDS(_lock_method_17494);
        _lock_method_17494 = _1;
    }

    /** 	db = find(path, Known_Aliases)*/
    _db_17495 = find_from(_path_17493, _38Known_Aliases_16439, 1);

    /** 	if db then*/
    if (_db_17495 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9857 = (int)*(((s1_ptr)_2)->base + _db_17495);
    DeRefDS(_path_17493);
    _2 = (int)SEQ_PTR(_9857);
    _path_17493 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17493);
    _9857 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9859 = (int)*(((s1_ptr)_2)->base + _db_17495);
    _2 = (int)SEQ_PTR(_9859);
    _9860 = (int)*(((s1_ptr)_2)->base + 2);
    _9859 = NOVALUE;
    _2 = (int)SEQ_PTR(_9860);
    _lock_method_17494 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17494)){
        _lock_method_17494 = (long)DBL_PTR(_lock_method_17494)->dbl;
    }
    _9860 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17493);
    RefDS(_9811);
    _9862 = _11defaultext(_path_17493, _9811);
    _0 = _path_17493;
    _path_17493 = _11canonical_path(_9862, 0, 0);
    DeRefDS(_0);
    _9862 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _9864 = (_lock_method_17494 == 0);
    if (_9864 != 0) {
        goto L3; // [76] 89
    }
    _9866 = (_lock_method_17494 == 2);
    if (_9866 == 0)
    {
        DeRef(_9866);
        _9866 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_9866);
        _9866 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_17495 = EOpen(_path_17493, _9836, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_17495 = EOpen(_path_17493, _1284, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if db = -1 then*/
    if (_db_17495 != -1)
    goto L6; // [111] 122

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17493);
    DeRef(_9864);
    _9864 = NOVALUE;
    return -1;
L6: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17494 != 2)
    goto L7; // [124] 162

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at129_17521;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17495;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at129_17521 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_129_17520 = machine(61, _lock_file_1__tmp_at129_17521);
    DeRef(_lock_file_1__tmp_at129_17521);
    _lock_file_1__tmp_at129_17521 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_129_17520 != 0)
    goto L8; // [145] 201

    /** 			close(db)*/
    EClose(_db_17495);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17493);
    DeRef(_9864);
    _9864 = NOVALUE;
    return -3;
    goto L8; // [159] 201
L7: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17494 != 1)
    goto L9; // [164] 200

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at169_17528;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17495;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at169_17528 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_169_17527 = machine(61, _lock_file_1__tmp_at169_17528);
    DeRef(_lock_file_1__tmp_at169_17528);
    _lock_file_1__tmp_at169_17528 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_169_17527 != 0)
    goto LA; // [185] 199

    /** 			close(db)*/
    EClose(_db_17495);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17493);
    DeRef(_9864);
    _9864 = NOVALUE;
    return -3;
LA: 
L9: 
L8: 

    /** 	magic = getc(db)*/
    if (_db_17495 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_17495, EF_READ);
        last_r_file_no = _db_17495;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_17496 = getc((FILE*)xstdin);
        }
        else
        _magic_17496 = getc(last_r_file_ptr);
    }
    else
    _magic_17496 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_17496 == 77)
    goto LB; // [208] 223

    /** 		close(db)*/
    EClose(_db_17495);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17493);
    DeRef(_9864);
    _9864 = NOVALUE;
    return -1;
LB: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db */
    _38current_db_16418 = _db_17495;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _5;

    /** 	current_lock = lock_method*/
    _38current_lock_16424 = _lock_method_17494;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_17493);
    Append(&_38db_names_16421, _38db_names_16421, _path_17493);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_38db_lock_methods_16423, _38db_lock_methods_16423, _lock_method_17494);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_38db_file_nums_16422, _38db_file_nums_16422, _db_17495);

    /** 	return DB_OK*/
    DeRefDS(_path_17493);
    DeRef(_9864);
    _9864 = NOVALUE;
    return 0;
    ;
}
int db_open() __attribute__ ((alias ("_38db_open")));


int _38db_select(int _path_17538, int _lock_method_17539)
{
    int _index_17540 = NOVALUE;
    int _9885 = NOVALUE;
    int _9883 = NOVALUE;
    int _9882 = NOVALUE;
    int _9880 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17539)) {
        _1 = (long)(DBL_PTR(_lock_method_17539)->dbl);
        DeRefDS(_lock_method_17539);
        _lock_method_17539 = _1;
    }

    /** 	index = find(path, Known_Aliases)*/
    _index_17540 = find_from(_path_17538, _38Known_Aliases_16439, 1);

    /** 	if index then*/
    if (_index_17540 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9880 = (int)*(((s1_ptr)_2)->base + _index_17540);
    DeRefDS(_path_17538);
    _2 = (int)SEQ_PTR(_9880);
    _path_17538 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17538);
    _9880 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16440);
    _9882 = (int)*(((s1_ptr)_2)->base + _index_17540);
    _2 = (int)SEQ_PTR(_9882);
    _9883 = (int)*(((s1_ptr)_2)->base + 2);
    _9882 = NOVALUE;
    _2 = (int)SEQ_PTR(_9883);
    _lock_method_17539 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17539)){
        _lock_method_17539 = (long)DBL_PTR(_lock_method_17539)->dbl;
    }
    _9883 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17538);
    RefDS(_9811);
    _9885 = _11defaultext(_path_17538, _9811);
    _0 = _path_17538;
    _path_17538 = _11canonical_path(_9885, 0, 0);
    DeRefDS(_0);
    _9885 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_17540 = find_from(_path_17538, _38db_names_16421, 1);

    /** 	if index = 0 then*/
    if (_index_17540 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_17539 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_17538);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_17538);
    _index_17540 = _38db_open(_path_17538, _lock_method_17539);
    if (!IS_ATOM_INT(_index_17540)) {
        _1 = (long)(DBL_PTR(_index_17540)->dbl);
        DeRefDS(_index_17540);
        _index_17540 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_17540 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_17538);
    return _index_17540;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_17540 = find_from(_path_17538, _38db_names_16421, 1);
L3: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_38db_file_nums_16422);
    _38current_db_16418 = (int)*(((s1_ptr)_2)->base + _index_17540);
    if (!IS_ATOM_INT(_38current_db_16418))
    _38current_db_16418 = (long)DBL_PTR(_38current_db_16418)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_38db_lock_methods_16423);
    _38current_lock_16424 = (int)*(((s1_ptr)_2)->base + _index_17540);
    if (!IS_ATOM_INT(_38current_lock_16424))
    _38current_lock_16424 = (long)DBL_PTR(_38current_lock_16424)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16425);
    _38key_pointers_16425 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_17538);
    return 0;
    ;
}
int db_select() __attribute__ ((alias ("_38db_select")));


void _38db_close()
{
    int _unlock_file_1__tmp_at25_17569 = NOVALUE;
    int _index_17564 = NOVALUE;
    int _9902 = NOVALUE;
    int _9901 = NOVALUE;
    int _9900 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16418 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_38current_lock_16424 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_17569);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_17569 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_17569);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_17569);
    _unlock_file_1__tmp_at25_17569 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_38current_db_16418);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_17564 = find_from(_38current_db_16418, _38db_file_nums_16422, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_names_16421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        int stop = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_names_16421), start, &_38db_names_16421 );
            }
            else Tail(SEQ_PTR(_38db_names_16421), stop+1, &_38db_names_16421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_names_16421), start, &_38db_names_16421);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_names_16421 = Remove_elements(start, stop, (SEQ_PTR(_38db_names_16421)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_file_nums_16422);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        int stop = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_file_nums_16422), start, &_38db_file_nums_16422 );
            }
            else Tail(SEQ_PTR(_38db_file_nums_16422), stop+1, &_38db_file_nums_16422);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_file_nums_16422), start, &_38db_file_nums_16422);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_file_nums_16422 = Remove_elements(start, stop, (SEQ_PTR(_38db_file_nums_16422)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_lock_methods_16423);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        int stop = (IS_ATOM_INT(_index_17564)) ? _index_17564 : (long)(DBL_PTR(_index_17564)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_lock_methods_16423), start, &_38db_lock_methods_16423 );
            }
            else Tail(SEQ_PTR(_38db_lock_methods_16423), stop+1, &_38db_lock_methods_16423);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_lock_methods_16423), start, &_38db_lock_methods_16423);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_lock_methods_16423 = Remove_elements(start, stop, (SEQ_PTR(_38db_lock_methods_16423)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_38cache_index_16427)){
            _9900 = SEQ_PTR(_38cache_index_16427)->length;
    }
    else {
        _9900 = 1;
    }
    {
        int _i_17575;
        _i_17575 = _9900;
L4: 
        if (_i_17575 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_38cache_index_16427);
        _9901 = (int)*(((s1_ptr)_2)->base + _i_17575);
        _2 = (int)SEQ_PTR(_9901);
        _9902 = (int)*(((s1_ptr)_2)->base + 1);
        _9901 = NOVALUE;
        if (binary_op_a(NOTEQ, _9902, _38current_db_16418)){
            _9902 = NOVALUE;
            goto L6; // [115] 138
        }
        _9902 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_38cache_index_16427);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17575)) ? _i_17575 : (long)(DBL_PTR(_i_17575)->dbl);
            int stop = (IS_ATOM_INT(_i_17575)) ? _i_17575 : (long)(DBL_PTR(_i_17575)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427 );
                }
                else Tail(SEQ_PTR(_38cache_index_16427), stop+1, &_38cache_index_16427);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427);
            }
            else {
                assign_slice_seq = &assign_space;
                _38cache_index_16427 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16427)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_38key_cache_16426);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17575)) ? _i_17575 : (long)(DBL_PTR(_i_17575)->dbl);
            int stop = (IS_ATOM_INT(_i_17575)) ? _i_17575 : (long)(DBL_PTR(_i_17575)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426 );
                }
                else Tail(SEQ_PTR(_38key_cache_16426), stop+1, &_38key_cache_16426);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426);
            }
            else {
                assign_slice_seq = &assign_space;
                _38key_cache_16426 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16426)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_17575 = _i_17575 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _5;

    /** 	current_db = -1*/
    _38current_db_16418 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16425);
    _38key_pointers_16425 = _5;

    /** end procedure*/
    return;
    ;
}
void db_close() __attribute__ ((alias ("_38db_close")));


int _38table_find(int _name_17585)
{
    int _tables_17586 = NOVALUE;
    int _nt_17587 = NOVALUE;
    int _t_header_17588 = NOVALUE;
    int _name_ptr_17589 = NOVALUE;
    int _seek_1__tmp_at6_17592 = NOVALUE;
    int _seek_inlined_seek_at_6_17591 = NOVALUE;
    int _seek_1__tmp_at44_17599 = NOVALUE;
    int _seek_inlined_seek_at_44_17598 = NOVALUE;
    int _seek_1__tmp_at84_17607 = NOVALUE;
    int _seek_inlined_seek_at_84_17606 = NOVALUE;
    int _seek_1__tmp_at106_17611 = NOVALUE;
    int _seek_inlined_seek_at_106_17610 = NOVALUE;
    int _9913 = NOVALUE;
    int _9911 = NOVALUE;
    int _9906 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_17592);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_17592 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_17591 = machine(19, _seek_1__tmp_at6_17592);
    DeRefi(_seek_1__tmp_at6_17592);
    _seek_1__tmp_at6_17592 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _9906 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _9906 = 1;
    }
    if (_9906 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_17585);
    DeRef(_tables_17586);
    DeRef(_nt_17587);
    DeRef(_t_header_17588);
    DeRef(_name_ptr_17589);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_17586;
    _tables_17586 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17586);
    DeRef(_seek_1__tmp_at44_17599);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_17586;
    _seek_1__tmp_at44_17599 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_17598 = machine(19, _seek_1__tmp_at44_17599);
    DeRef(_seek_1__tmp_at44_17599);
    _seek_1__tmp_at44_17599 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_17587;
    _nt_17587 = _38get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_17588);
    if (IS_ATOM_INT(_tables_17586)) {
        _t_header_17588 = _tables_17586 + 4;
        if ((long)((unsigned long)_t_header_17588 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_17588 = NewDouble((double)_t_header_17588);
    }
    else {
        _t_header_17588 = NewDouble(DBL_PTR(_tables_17586)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_17587);
    DeRef(_9911);
    _9911 = _nt_17587;
    {
        int _i_17603;
        _i_17603 = 1;
L2: 
        if (binary_op_a(GREATER, _i_17603, _9911)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_17588);
        DeRef(_seek_1__tmp_at84_17607);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _t_header_17588;
        _seek_1__tmp_at84_17607 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_17606 = machine(19, _seek_1__tmp_at84_17607);
        DeRef(_seek_1__tmp_at84_17607);
        _seek_1__tmp_at84_17607 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_17589;
        _name_ptr_17589 = _38get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_17589);
        DeRef(_seek_1__tmp_at106_17611);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _name_ptr_17589;
        _seek_1__tmp_at106_17611 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_17610 = machine(19, _seek_1__tmp_at106_17611);
        DeRef(_seek_1__tmp_at106_17611);
        _seek_1__tmp_at106_17611 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_17585);
        _9913 = _38equal_string(_name_17585);
        if (binary_op_a(LESSEQ, _9913, 0)){
            DeRef(_9913);
            _9913 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_9913);
        _9913 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_17603);
        DeRefDS(_name_17585);
        DeRef(_tables_17586);
        DeRef(_nt_17587);
        DeRef(_name_ptr_17589);
        return _t_header_17588;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_17588;
        if (IS_ATOM_INT(_t_header_17588)) {
            _t_header_17588 = _t_header_17588 + 16;
            if ((long)((unsigned long)_t_header_17588 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_17588 = NewDouble((double)_t_header_17588);
        }
        else {
            _t_header_17588 = NewDouble(DBL_PTR(_t_header_17588)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_17603;
        if (IS_ATOM_INT(_i_17603)) {
            _i_17603 = _i_17603 + 1;
            if ((long)((unsigned long)_i_17603 +(unsigned long) HIGH_BITS) >= 0){
                _i_17603 = NewDouble((double)_i_17603);
            }
        }
        else {
            _i_17603 = binary_op_a(PLUS, _i_17603, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_17603);
    }

    /** 	return -1*/
    DeRefDS(_name_17585);
    DeRef(_tables_17586);
    DeRef(_nt_17587);
    DeRef(_t_header_17588);
    DeRef(_name_ptr_17589);
    return -1;
    ;
}


int _38db_select_table(int _name_17618)
{
    int _table_17619 = NOVALUE;
    int _nkeys_17620 = NOVALUE;
    int _index_17621 = NOVALUE;
    int _block_ptr_17622 = NOVALUE;
    int _block_size_17623 = NOVALUE;
    int _blocks_17624 = NOVALUE;
    int _k_17625 = NOVALUE;
    int _seek_1__tmp_at120_17644 = NOVALUE;
    int _seek_inlined_seek_at_120_17643 = NOVALUE;
    int _pos_inlined_seek_at_117_17642 = NOVALUE;
    int _seek_1__tmp_at178_17654 = NOVALUE;
    int _seek_inlined_seek_at_178_17653 = NOVALUE;
    int _seek_1__tmp_at205_17659 = NOVALUE;
    int _seek_inlined_seek_at_205_17658 = NOVALUE;
    int _9934 = NOVALUE;
    int _9933 = NOVALUE;
    int _9930 = NOVALUE;
    int _9925 = NOVALUE;
    int _9920 = NOVALUE;
    int _9916 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_38current_table_name_16420 == _name_17618)
    _9916 = 1;
    else if (IS_ATOM_INT(_38current_table_name_16420) && IS_ATOM_INT(_name_17618))
    _9916 = 0;
    else
    _9916 = (compare(_38current_table_name_16420, _name_17618) == 0);
    if (_9916 == 0)
    {
        _9916 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _9916 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_17618);
    DeRef(_table_17619);
    DeRef(_nkeys_17620);
    DeRef(_index_17621);
    DeRef(_block_ptr_17622);
    DeRef(_block_size_17623);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_17618);
    _0 = _table_17619;
    _table_17619 = _38table_find(_name_17618);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17619, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_17618);
    DeRef(_table_17619);
    DeRef(_nkeys_17620);
    DeRef(_index_17621);
    DeRef(_block_ptr_17622);
    DeRef(_block_size_17623);
    return -1;
L2: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_17619);
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = _table_17619;

    /** 	current_table_name = name*/
    RefDS(_name_17618);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _name_17618;

    /** 	k = 0*/
    _k_17625 = 0;

    /** 	if caching_option = 1 then*/
    if (_38caching_option_16428 != 1)
    goto L3; // [65] 104

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _9920 = MAKE_SEQ(_1);
    _k_17625 = find_from(_9920, _38cache_index_16427, 1);
    DeRefDS(_9920);
    _9920 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_17625 == 0)
    goto L4; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_38key_pointers_16425);
    _2 = (int)SEQ_PTR(_38key_cache_16426);
    _38key_pointers_16425 = (int)*(((s1_ptr)_2)->base + _k_17625);
    Ref(_38key_pointers_16425);
L4: 
L3: 

    /** 	if k = 0 then*/
    if (_k_17625 != 0)
    goto L5; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_17619)) {
        _9925 = _table_17619 + 4;
        if ((long)((unsigned long)_9925 + (unsigned long)HIGH_BITS) >= 0) 
        _9925 = NewDouble((double)_9925);
    }
    else {
        _9925 = NewDouble(DBL_PTR(_table_17619)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_17642);
    _pos_inlined_seek_at_117_17642 = _9925;
    _9925 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_17642);
    DeRef(_seek_1__tmp_at120_17644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_17642;
    _seek_1__tmp_at120_17644 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_17643 = machine(19, _seek_1__tmp_at120_17644);
    DeRef(_pos_inlined_seek_at_117_17642);
    _pos_inlined_seek_at_117_17642 = NOVALUE;
    DeRef(_seek_1__tmp_at120_17644);
    _seek_1__tmp_at120_17644 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_17620;
    _nkeys_17620 = _38get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_17624 = _38get4();
    if (!IS_ATOM_INT(_blocks_17624)) {
        _1 = (long)(DBL_PTR(_blocks_17624)->dbl);
        DeRefDS(_blocks_17624);
        _blocks_17624 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_17621;
    _index_17621 = _38get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_38key_pointers_16425);
    _38key_pointers_16425 = Repeat(0, _nkeys_17620);

    /** 		k = 1*/
    _k_17625 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _9930 = _blocks_17624 - 1;
    if ((long)((unsigned long)_9930 +(unsigned long) HIGH_BITS) >= 0){
        _9930 = NewDouble((double)_9930);
    }
    {
        int _b_17650;
        _b_17650 = 0;
L6: 
        if (binary_op_a(GREATER, _b_17650, _9930)){
            goto L7; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_17621);
        DeRef(_seek_1__tmp_at178_17654);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _index_17621;
        _seek_1__tmp_at178_17654 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_17653 = machine(19, _seek_1__tmp_at178_17654);
        DeRef(_seek_1__tmp_at178_17654);
        _seek_1__tmp_at178_17654 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_17623;
        _block_size_17623 = _38get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_17622;
        _block_ptr_17622 = _38get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_17622);
        DeRef(_seek_1__tmp_at205_17659);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _block_ptr_17622;
        _seek_1__tmp_at205_17659 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_17658 = machine(19, _seek_1__tmp_at205_17659);
        DeRef(_seek_1__tmp_at205_17659);
        _seek_1__tmp_at205_17659 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_17623);
        DeRef(_9933);
        _9933 = _block_size_17623;
        {
            int _j_17661;
            _j_17661 = 1;
L8: 
            if (binary_op_a(GREATER, _j_17661, _9933)){
                goto L9; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _9934 = _38get4();
            _2 = (int)SEQ_PTR(_38key_pointers_16425);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _38key_pointers_16425 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_17625);
            _1 = *(int *)_2;
            *(int *)_2 = _9934;
            if( _1 != _9934 ){
                DeRef(_1);
            }
            _9934 = NOVALUE;

            /** 				k += 1*/
            _k_17625 = _k_17625 + 1;

            /** 			end for*/
            _0 = _j_17661;
            if (IS_ATOM_INT(_j_17661)) {
                _j_17661 = _j_17661 + 1;
                if ((long)((unsigned long)_j_17661 +(unsigned long) HIGH_BITS) >= 0){
                    _j_17661 = NewDouble((double)_j_17661);
                }
            }
            else {
                _j_17661 = binary_op_a(PLUS, _j_17661, 1);
            }
            DeRef(_0);
            goto L8; // [250] 231
L9: 
            ;
            DeRef(_j_17661);
        }

        /** 			index += 8*/
        _0 = _index_17621;
        if (IS_ATOM_INT(_index_17621)) {
            _index_17621 = _index_17621 + 8;
            if ((long)((unsigned long)_index_17621 + (unsigned long)HIGH_BITS) >= 0) 
            _index_17621 = NewDouble((double)_index_17621);
        }
        else {
            _index_17621 = NewDouble(DBL_PTR(_index_17621)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_17650;
        if (IS_ATOM_INT(_b_17650)) {
            _b_17650 = _b_17650 + 1;
            if ((long)((unsigned long)_b_17650 +(unsigned long) HIGH_BITS) >= 0){
                _b_17650 = NewDouble((double)_b_17650);
            }
        }
        else {
            _b_17650 = binary_op_a(PLUS, _b_17650, 1);
        }
        DeRef(_0);
        goto L6; // [263] 175
L7: 
        ;
        DeRef(_b_17650);
    }
L5: 

    /** 	return DB_OK*/
    DeRefDS(_name_17618);
    DeRef(_table_17619);
    DeRef(_nkeys_17620);
    DeRef(_index_17621);
    DeRef(_block_ptr_17622);
    DeRef(_block_size_17623);
    DeRef(_9930);
    _9930 = NOVALUE;
    return 0;
    ;
}
int db_select_table() __attribute__ ((alias ("_38db_select_table")));


int _38db_current_table()
{
    int _0, _1, _2;
    

    /** 	return current_table_name*/
    RefDS(_38current_table_name_16420);
    return _38current_table_name_16420;
    ;
}
int db_current_table() __attribute__ ((alias ("_38db_current_table")));


int _38db_create_table(int _name_17670, int _init_records_17671)
{
    int _name_ptr_17672 = NOVALUE;
    int _nt_17673 = NOVALUE;
    int _tables_17674 = NOVALUE;
    int _newtables_17675 = NOVALUE;
    int _table_17676 = NOVALUE;
    int _records_ptr_17677 = NOVALUE;
    int _size_17678 = NOVALUE;
    int _newsize_17679 = NOVALUE;
    int _index_ptr_17680 = NOVALUE;
    int _remaining_17681 = NOVALUE;
    int _init_index_17682 = NOVALUE;
    int _seek_1__tmp_at68_17696 = NOVALUE;
    int _seek_inlined_seek_at_68_17695 = NOVALUE;
    int _seek_1__tmp_at97_17702 = NOVALUE;
    int _seek_inlined_seek_at_97_17701 = NOVALUE;
    int _pos_inlined_seek_at_94_17700 = NOVALUE;
    int _put4_1__tmp_at159_17715 = NOVALUE;
    int _seek_1__tmp_at196_17720 = NOVALUE;
    int _seek_inlined_seek_at_196_17719 = NOVALUE;
    int _pos_inlined_seek_at_193_17718 = NOVALUE;
    int _seek_1__tmp_at239_17728 = NOVALUE;
    int _seek_inlined_seek_at_239_17727 = NOVALUE;
    int _pos_inlined_seek_at_236_17726 = NOVALUE;
    int _s_inlined_putn_at_288_17736 = NOVALUE;
    int _seek_1__tmp_at316_17739 = NOVALUE;
    int _seek_inlined_seek_at_316_17738 = NOVALUE;
    int _put4_1__tmp_at331_17741 = NOVALUE;
    int _seek_1__tmp_at369_17745 = NOVALUE;
    int _seek_inlined_seek_at_369_17744 = NOVALUE;
    int _put4_1__tmp_at384_17747 = NOVALUE;
    int _s_inlined_putn_at_431_17753 = NOVALUE;
    int _put4_1__tmp_at462_17757 = NOVALUE;
    int _put4_1__tmp_at490_17759 = NOVALUE;
    int _s_inlined_putn_at_530_17764 = NOVALUE;
    int _s_inlined_putn_at_568_17770 = NOVALUE;
    int _seek_1__tmp_at610_17778 = NOVALUE;
    int _seek_inlined_seek_at_610_17777 = NOVALUE;
    int _pos_inlined_seek_at_607_17776 = NOVALUE;
    int _put4_1__tmp_at625_17780 = NOVALUE;
    int _put4_1__tmp_at653_17782 = NOVALUE;
    int _put4_1__tmp_at681_17784 = NOVALUE;
    int _put4_1__tmp_at709_17786 = NOVALUE;
    int _9983 = NOVALUE;
    int _9982 = NOVALUE;
    int _9981 = NOVALUE;
    int _9980 = NOVALUE;
    int _9979 = NOVALUE;
    int _9978 = NOVALUE;
    int _9976 = NOVALUE;
    int _9975 = NOVALUE;
    int _9974 = NOVALUE;
    int _9973 = NOVALUE;
    int _9972 = NOVALUE;
    int _9970 = NOVALUE;
    int _9969 = NOVALUE;
    int _9968 = NOVALUE;
    int _9966 = NOVALUE;
    int _9965 = NOVALUE;
    int _9964 = NOVALUE;
    int _9963 = NOVALUE;
    int _9962 = NOVALUE;
    int _9961 = NOVALUE;
    int _9960 = NOVALUE;
    int _9958 = NOVALUE;
    int _9957 = NOVALUE;
    int _9956 = NOVALUE;
    int _9953 = NOVALUE;
    int _9952 = NOVALUE;
    int _9950 = NOVALUE;
    int _9949 = NOVALUE;
    int _9947 = NOVALUE;
    int _9945 = NOVALUE;
    int _9942 = NOVALUE;
    int _9937 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_init_records_17671)) {
        _1 = (long)(DBL_PTR(_init_records_17671)->dbl);
        DeRefDS(_init_records_17671);
        _init_records_17671 = _1;
    }

    /** 	if not cstring(name) then*/
    RefDS(_name_17670);
    _9937 = _7cstring(_name_17670);
    if (IS_ATOM_INT(_9937)) {
        if (_9937 != 0){
            DeRef(_9937);
            _9937 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_9937)->dbl != 0.0){
            DeRef(_9937);
            _9937 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_9937);
    _9937 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_17670);
    DeRef(_name_ptr_17672);
    DeRef(_nt_17673);
    DeRef(_tables_17674);
    DeRef(_newtables_17675);
    DeRef(_table_17676);
    DeRef(_records_ptr_17677);
    DeRef(_size_17678);
    DeRef(_newsize_17679);
    DeRef(_index_ptr_17680);
    DeRef(_remaining_17681);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_17670);
    _0 = _table_17676;
    _table_17676 = _38table_find(_name_17670);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_17676, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_17670);
    DeRef(_name_ptr_17672);
    DeRef(_nt_17673);
    DeRef(_tables_17674);
    DeRef(_newtables_17675);
    DeRef(_table_17676);
    DeRef(_records_ptr_17677);
    DeRef(_size_17678);
    DeRef(_newsize_17679);
    DeRef(_index_ptr_17680);
    DeRef(_remaining_17681);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_17671 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_17671 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_17671;
    ((int *)_2)[2] = 10;
    _9942 = MAKE_SEQ(_1);
    _init_index_17682 = _20min(_9942);
    _9942 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_17682)) {
        _1 = (long)(DBL_PTR(_init_index_17682)->dbl);
        DeRefDS(_init_index_17682);
        _init_index_17682 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_17696);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_17696 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_17695 = machine(19, _seek_1__tmp_at68_17696);
    DeRefi(_seek_1__tmp_at68_17696);
    _seek_1__tmp_at68_17696 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_17674;
    _tables_17674 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_17674)) {
        _9945 = _tables_17674 - 4;
        if ((long)((unsigned long)_9945 +(unsigned long) HIGH_BITS) >= 0){
            _9945 = NewDouble((double)_9945);
        }
    }
    else {
        _9945 = NewDouble(DBL_PTR(_tables_17674)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_17700);
    _pos_inlined_seek_at_94_17700 = _9945;
    _9945 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_17700);
    DeRef(_seek_1__tmp_at97_17702);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_17700;
    _seek_1__tmp_at97_17702 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_17701 = machine(19, _seek_1__tmp_at97_17702);
    DeRef(_pos_inlined_seek_at_94_17700);
    _pos_inlined_seek_at_94_17700 = NOVALUE;
    DeRef(_seek_1__tmp_at97_17702);
    _seek_1__tmp_at97_17702 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_17678;
    _size_17678 = _38get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _9947 = _38get4();
    DeRef(_nt_17673);
    if (IS_ATOM_INT(_9947)) {
        _nt_17673 = _9947 + 1;
        if (_nt_17673 > MAXINT){
            _nt_17673 = NewDouble((double)_nt_17673);
        }
    }
    else
    _nt_17673 = binary_op(PLUS, 1, _9947);
    DeRef(_9947);
    _9947 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_17673)) {
        if (_nt_17673 == (short)_nt_17673)
        _9949 = _nt_17673 * 16;
        else
        _9949 = NewDouble(_nt_17673 * (double)16);
    }
    else {
        _9949 = NewDouble(DBL_PTR(_nt_17673)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_9949)) {
        _9950 = _9949 + 8;
        if ((long)((unsigned long)_9950 + (unsigned long)HIGH_BITS) >= 0) 
        _9950 = NewDouble((double)_9950);
    }
    else {
        _9950 = NewDouble(DBL_PTR(_9949)->dbl + (double)8);
    }
    DeRef(_9949);
    _9949 = NOVALUE;
    if (binary_op_a(LESSEQ, _9950, _size_17678)){
        DeRef(_9950);
        _9950 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_9950);
    _9950 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_17678)) {
        if (_size_17678 & 1) {
            _9952 = NewDouble((_size_17678 >> 1) + 0.5);
        }
        else
        _9952 = _size_17678 >> 1;
    }
    else {
        _9952 = binary_op(DIVIDE, _size_17678, 2);
    }
    if (IS_ATOM_INT(_size_17678) && IS_ATOM_INT(_9952)) {
        _9953 = _size_17678 + _9952;
        if ((long)((unsigned long)_9953 + (unsigned long)HIGH_BITS) >= 0) 
        _9953 = NewDouble((double)_9953);
    }
    else {
        if (IS_ATOM_INT(_size_17678)) {
            _9953 = NewDouble((double)_size_17678 + DBL_PTR(_9952)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9952)) {
                _9953 = NewDouble(DBL_PTR(_size_17678)->dbl + (double)_9952);
            }
            else
            _9953 = NewDouble(DBL_PTR(_size_17678)->dbl + DBL_PTR(_9952)->dbl);
        }
    }
    DeRef(_9952);
    _9952 = NOVALUE;
    DeRef(_newsize_17679);
    if (IS_ATOM_INT(_9953))
    _newsize_17679 = e_floor(_9953);
    else
    _newsize_17679 = unary_op(FLOOR, _9953);
    DeRef(_9953);
    _9953 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_17679);
    _0 = _newtables_17675;
    _newtables_17675 = _38db_allocate(_newsize_17679);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nt_17673)) {
        *poke4_addr = (unsigned long)_nt_17673;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_17673)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_17715);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_17715 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at159_17715); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_17715);
    _put4_1__tmp_at159_17715 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_17674)) {
        _9956 = _tables_17674 + 4;
        if ((long)((unsigned long)_9956 + (unsigned long)HIGH_BITS) >= 0) 
        _9956 = NewDouble((double)_9956);
    }
    else {
        _9956 = NewDouble(DBL_PTR(_tables_17674)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_17718);
    _pos_inlined_seek_at_193_17718 = _9956;
    _9956 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_17718);
    DeRef(_seek_1__tmp_at196_17720);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_17718;
    _seek_1__tmp_at196_17720 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_17719 = machine(19, _seek_1__tmp_at196_17720);
    DeRef(_pos_inlined_seek_at_193_17718);
    _pos_inlined_seek_at_193_17718 = NOVALUE;
    DeRef(_seek_1__tmp_at196_17720);
    _seek_1__tmp_at196_17720 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_17673)) {
        _9957 = _nt_17673 - 1;
        if ((long)((unsigned long)_9957 +(unsigned long) HIGH_BITS) >= 0){
            _9957 = NewDouble((double)_9957);
        }
    }
    else {
        _9957 = NewDouble(DBL_PTR(_nt_17673)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9957)) {
        if (_9957 == (short)_9957)
        _9958 = _9957 * 16;
        else
        _9958 = NewDouble(_9957 * (double)16);
    }
    else {
        _9958 = NewDouble(DBL_PTR(_9957)->dbl * (double)16);
    }
    DeRef(_9957);
    _9957 = NOVALUE;
    _0 = _remaining_17681;
    _remaining_17681 = _18get_bytes(_38current_db_16418, _9958);
    DeRef(_0);
    _9958 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_17675)) {
        _9960 = _newtables_17675 + 4;
        if ((long)((unsigned long)_9960 + (unsigned long)HIGH_BITS) >= 0) 
        _9960 = NewDouble((double)_9960);
    }
    else {
        _9960 = NewDouble(DBL_PTR(_newtables_17675)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_17726);
    _pos_inlined_seek_at_236_17726 = _9960;
    _9960 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_17726);
    DeRef(_seek_1__tmp_at239_17728);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_17726;
    _seek_1__tmp_at239_17728 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_17727 = machine(19, _seek_1__tmp_at239_17728);
    DeRef(_pos_inlined_seek_at_236_17726);
    _pos_inlined_seek_at_236_17726 = NOVALUE;
    DeRef(_seek_1__tmp_at239_17728);
    _seek_1__tmp_at239_17728 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_17681); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_17679)) {
        _9961 = _newsize_17679 - 4;
        if ((long)((unsigned long)_9961 +(unsigned long) HIGH_BITS) >= 0){
            _9961 = NewDouble((double)_9961);
        }
    }
    else {
        _9961 = NewDouble(DBL_PTR(_newsize_17679)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_17673)) {
        _9962 = _nt_17673 - 1;
        if ((long)((unsigned long)_9962 +(unsigned long) HIGH_BITS) >= 0){
            _9962 = NewDouble((double)_9962);
        }
    }
    else {
        _9962 = NewDouble(DBL_PTR(_nt_17673)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9962)) {
        if (_9962 == (short)_9962)
        _9963 = _9962 * 16;
        else
        _9963 = NewDouble(_9962 * (double)16);
    }
    else {
        _9963 = NewDouble(DBL_PTR(_9962)->dbl * (double)16);
    }
    DeRef(_9962);
    _9962 = NOVALUE;
    if (IS_ATOM_INT(_9961) && IS_ATOM_INT(_9963)) {
        _9964 = _9961 - _9963;
    }
    else {
        if (IS_ATOM_INT(_9961)) {
            _9964 = NewDouble((double)_9961 - DBL_PTR(_9963)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9963)) {
                _9964 = NewDouble(DBL_PTR(_9961)->dbl - (double)_9963);
            }
            else
            _9964 = NewDouble(DBL_PTR(_9961)->dbl - DBL_PTR(_9963)->dbl);
        }
    }
    DeRef(_9961);
    _9961 = NOVALUE;
    DeRef(_9963);
    _9963 = NOVALUE;
    _9965 = Repeat(0, _9964);
    DeRef(_9964);
    _9964 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_17736);
    _s_inlined_putn_at_288_17736 = _9965;
    _9965 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_288_17736); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_17736);
    _s_inlined_putn_at_288_17736 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_17674);
    _38db_free(_tables_17674);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_17739);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_17739 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_17738 = machine(19, _seek_1__tmp_at316_17739);
    DeRefi(_seek_1__tmp_at316_17739);
    _seek_1__tmp_at316_17739 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_newtables_17675)) {
        *poke4_addr = (unsigned long)_newtables_17675;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_17675)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_17741);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_17741 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at331_17741); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_17741);
    _put4_1__tmp_at331_17741 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_17675);
    DeRef(_tables_17674);
    _tables_17674 = _newtables_17675;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17674);
    DeRef(_seek_1__tmp_at369_17745);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_17674;
    _seek_1__tmp_at369_17745 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_17744 = machine(19, _seek_1__tmp_at369_17745);
    DeRef(_seek_1__tmp_at369_17745);
    _seek_1__tmp_at369_17745 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nt_17673)) {
        *poke4_addr = (unsigned long)_nt_17673;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_17673)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_17747);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_17747 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at384_17747); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_17747);
    _put4_1__tmp_at384_17747 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_17671 == (short)_init_records_17671)
    _9966 = _init_records_17671 * 4;
    else
    _9966 = NewDouble(_init_records_17671 * (double)4);
    _0 = _records_ptr_17677;
    _records_ptr_17677 = _38db_allocate(_9966);
    DeRef(_0);
    _9966 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _9968 = _init_records_17671 * 4;
    _9969 = Repeat(0, _9968);
    _9968 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_17753);
    _s_inlined_putn_at_431_17753 = _9969;
    _9969 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_431_17753); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_17753);
    _s_inlined_putn_at_431_17753 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_17682 == (short)_init_index_17682)
    _9970 = _init_index_17682 * 8;
    else
    _9970 = NewDouble(_init_index_17682 * (double)8);
    _0 = _index_ptr_17680;
    _index_ptr_17680 = _38db_allocate(_9970);
    DeRef(_0);
    _9970 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_17757);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_17757 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at462_17757); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_17757);
    _put4_1__tmp_at462_17757 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_17677)) {
        *poke4_addr = (unsigned long)_records_ptr_17677;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_17677)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_17759);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_17759 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at490_17759); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_17759);
    _put4_1__tmp_at490_17759 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _9972 = _init_index_17682 - 1;
    if ((long)((unsigned long)_9972 +(unsigned long) HIGH_BITS) >= 0){
        _9972 = NewDouble((double)_9972);
    }
    if (IS_ATOM_INT(_9972)) {
        _9973 = _9972 * 8;
    }
    else {
        _9973 = NewDouble(DBL_PTR(_9972)->dbl * (double)8);
    }
    DeRef(_9972);
    _9972 = NOVALUE;
    _9974 = Repeat(0, _9973);
    DeRef(_9973);
    _9973 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_17764);
    _s_inlined_putn_at_530_17764 = _9974;
    _9974 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_530_17764); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_17764);
    _s_inlined_putn_at_530_17764 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_17670)){
            _9975 = SEQ_PTR(_name_17670)->length;
    }
    else {
        _9975 = 1;
    }
    _9976 = _9975 + 1;
    _9975 = NOVALUE;
    _0 = _name_ptr_17672;
    _name_ptr_17672 = _38db_allocate(_9976);
    DeRef(_0);
    _9976 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_9978, _name_17670, 0);
    DeRef(_s_inlined_putn_at_568_17770);
    _s_inlined_putn_at_568_17770 = _9978;
    _9978 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_568_17770); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_17770);
    _s_inlined_putn_at_568_17770 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_17674)) {
        _9979 = _tables_17674 + 4;
        if ((long)((unsigned long)_9979 + (unsigned long)HIGH_BITS) >= 0) 
        _9979 = NewDouble((double)_9979);
    }
    else {
        _9979 = NewDouble(DBL_PTR(_tables_17674)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_17673)) {
        _9980 = _nt_17673 - 1;
        if ((long)((unsigned long)_9980 +(unsigned long) HIGH_BITS) >= 0){
            _9980 = NewDouble((double)_9980);
        }
    }
    else {
        _9980 = NewDouble(DBL_PTR(_nt_17673)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9980)) {
        if (_9980 == (short)_9980)
        _9981 = _9980 * 16;
        else
        _9981 = NewDouble(_9980 * (double)16);
    }
    else {
        _9981 = NewDouble(DBL_PTR(_9980)->dbl * (double)16);
    }
    DeRef(_9980);
    _9980 = NOVALUE;
    if (IS_ATOM_INT(_9979) && IS_ATOM_INT(_9981)) {
        _9982 = _9979 + _9981;
        if ((long)((unsigned long)_9982 + (unsigned long)HIGH_BITS) >= 0) 
        _9982 = NewDouble((double)_9982);
    }
    else {
        if (IS_ATOM_INT(_9979)) {
            _9982 = NewDouble((double)_9979 + DBL_PTR(_9981)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9981)) {
                _9982 = NewDouble(DBL_PTR(_9979)->dbl + (double)_9981);
            }
            else
            _9982 = NewDouble(DBL_PTR(_9979)->dbl + DBL_PTR(_9981)->dbl);
        }
    }
    DeRef(_9979);
    _9979 = NOVALUE;
    DeRef(_9981);
    _9981 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_17776);
    _pos_inlined_seek_at_607_17776 = _9982;
    _9982 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_17776);
    DeRef(_seek_1__tmp_at610_17778);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_17776;
    _seek_1__tmp_at610_17778 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_17777 = machine(19, _seek_1__tmp_at610_17778);
    DeRef(_pos_inlined_seek_at_607_17776);
    _pos_inlined_seek_at_607_17776 = NOVALUE;
    DeRef(_seek_1__tmp_at610_17778);
    _seek_1__tmp_at610_17778 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_17672)) {
        *poke4_addr = (unsigned long)_name_ptr_17672;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_17672)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_17780);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_17780 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at625_17780); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_17780);
    _put4_1__tmp_at625_17780 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_17782);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_17782 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at653_17782); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_17782);
    _put4_1__tmp_at653_17782 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_17784);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_17784 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at681_17784); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_17784);
    _put4_1__tmp_at681_17784 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17680)) {
        *poke4_addr = (unsigned long)_index_ptr_17680;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_17680)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_17786);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_17786 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at709_17786); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_17786);
    _put4_1__tmp_at709_17786 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_17670);
    _9983 = _38db_select_table(_name_17670);
    if (_9983 == 0) {
        DeRef(_9983);
        _9983 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_9983) && DBL_PTR(_9983)->dbl == 0.0){
            DeRef(_9983);
            _9983 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_9983);
        _9983 = NOVALUE;
    }
    DeRef(_9983);
    _9983 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_17670);
    DeRef(_name_ptr_17672);
    DeRef(_nt_17673);
    DeRef(_tables_17674);
    DeRef(_newtables_17675);
    DeRef(_table_17676);
    DeRef(_records_ptr_17677);
    DeRef(_size_17678);
    DeRef(_newsize_17679);
    DeRef(_index_ptr_17680);
    DeRef(_remaining_17681);
    return 0;
    ;
}
int db_create_table() __attribute__ ((alias ("_38db_create_table")));


void _38db_delete_table(int _name_17791)
{
    int _table_17792 = NOVALUE;
    int _tables_17793 = NOVALUE;
    int _nt_17794 = NOVALUE;
    int _nrecs_17795 = NOVALUE;
    int _records_ptr_17796 = NOVALUE;
    int _blocks_17797 = NOVALUE;
    int _p_17798 = NOVALUE;
    int _data_ptr_17799 = NOVALUE;
    int _index_17800 = NOVALUE;
    int _remaining_17801 = NOVALUE;
    int _k_17802 = NOVALUE;
    int _seek_1__tmp_at24_17808 = NOVALUE;
    int _seek_inlined_seek_at_24_17807 = NOVALUE;
    int _seek_1__tmp_at56_17814 = NOVALUE;
    int _seek_inlined_seek_at_56_17813 = NOVALUE;
    int _pos_inlined_seek_at_53_17812 = NOVALUE;
    int _seek_1__tmp_at112_17826 = NOVALUE;
    int _seek_inlined_seek_at_112_17825 = NOVALUE;
    int _pos_inlined_seek_at_109_17824 = NOVALUE;
    int _seek_1__tmp_at163_17837 = NOVALUE;
    int _seek_inlined_seek_at_163_17836 = NOVALUE;
    int _pos_inlined_seek_at_160_17835 = NOVALUE;
    int _seek_1__tmp_at185_17841 = NOVALUE;
    int _seek_inlined_seek_at_185_17840 = NOVALUE;
    int _seek_1__tmp_at241_17845 = NOVALUE;
    int _seek_inlined_seek_at_241_17844 = NOVALUE;
    int _seek_1__tmp_at263_17849 = NOVALUE;
    int _seek_inlined_seek_at_263_17848 = NOVALUE;
    int _seek_1__tmp_at292_17855 = NOVALUE;
    int _seek_inlined_seek_at_292_17854 = NOVALUE;
    int _pos_inlined_seek_at_289_17853 = NOVALUE;
    int _seek_1__tmp_at340_17864 = NOVALUE;
    int _seek_inlined_seek_at_340_17863 = NOVALUE;
    int _seek_1__tmp_at377_17869 = NOVALUE;
    int _seek_inlined_seek_at_377_17868 = NOVALUE;
    int _put4_1__tmp_at392_17871 = NOVALUE;
    int _seek_1__tmp_at505_17885 = NOVALUE;
    int _seek_inlined_seek_at_505_17884 = NOVALUE;
    int _seek_1__tmp_at527_17889 = NOVALUE;
    int _seek_inlined_seek_at_527_17888 = NOVALUE;
    int _10011 = NOVALUE;
    int _10008 = NOVALUE;
    int _10007 = NOVALUE;
    int _10006 = NOVALUE;
    int _10005 = NOVALUE;
    int _10004 = NOVALUE;
    int _10003 = NOVALUE;
    int _9998 = NOVALUE;
    int _9997 = NOVALUE;
    int _9996 = NOVALUE;
    int _9993 = NOVALUE;
    int _9992 = NOVALUE;
    int _9991 = NOVALUE;
    int _9987 = NOVALUE;
    int _9986 = NOVALUE;
    int _0, _1, _2;
    

    /** 	table = table_find(name)*/
    RefDS(_name_17791);
    _0 = _table_17792;
    _table_17792 = _38table_find(_name_17791);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17792, -1)){
        goto L1; // [11] 21
    }

    /** 		return*/
    DeRefDS(_name_17791);
    DeRef(_table_17792);
    DeRef(_tables_17793);
    DeRef(_nt_17794);
    DeRef(_nrecs_17795);
    DeRef(_records_ptr_17796);
    DeRef(_blocks_17797);
    DeRef(_p_17798);
    DeRef(_data_ptr_17799);
    DeRef(_index_17800);
    DeRef(_remaining_17801);
    return;
L1: 

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_17792);
    DeRef(_seek_1__tmp_at24_17808);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _table_17792;
    _seek_1__tmp_at24_17808 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_24_17807 = machine(19, _seek_1__tmp_at24_17808);
    DeRef(_seek_1__tmp_at24_17808);
    _seek_1__tmp_at24_17808 = NOVALUE;

    /** 	db_free(get4())*/
    _9986 = _38get4();
    _38db_free(_9986);
    _9986 = NOVALUE;

    /** 	io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_17792)) {
        _9987 = _table_17792 + 4;
        if ((long)((unsigned long)_9987 + (unsigned long)HIGH_BITS) >= 0) 
        _9987 = NewDouble((double)_9987);
    }
    else {
        _9987 = NewDouble(DBL_PTR(_table_17792)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_53_17812);
    _pos_inlined_seek_at_53_17812 = _9987;
    _9987 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_53_17812);
    DeRef(_seek_1__tmp_at56_17814);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_53_17812;
    _seek_1__tmp_at56_17814 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_56_17813 = machine(19, _seek_1__tmp_at56_17814);
    DeRef(_pos_inlined_seek_at_53_17812);
    _pos_inlined_seek_at_53_17812 = NOVALUE;
    DeRef(_seek_1__tmp_at56_17814);
    _seek_1__tmp_at56_17814 = NOVALUE;

    /** 	nrecs = get4()*/
    _0 = _nrecs_17795;
    _nrecs_17795 = _38get4();
    DeRef(_0);

    /** 	blocks = get4()*/
    _0 = _blocks_17797;
    _blocks_17797 = _38get4();
    DeRef(_0);

    /** 	index = get4()*/
    _0 = _index_17800;
    _index_17800 = _38get4();
    DeRef(_0);

    /** 	for b = 0 to blocks-1 do*/
    if (IS_ATOM_INT(_blocks_17797)) {
        _9991 = _blocks_17797 - 1;
        if ((long)((unsigned long)_9991 +(unsigned long) HIGH_BITS) >= 0){
            _9991 = NewDouble((double)_9991);
        }
    }
    else {
        _9991 = NewDouble(DBL_PTR(_blocks_17797)->dbl - (double)1);
    }
    {
        int _b_17819;
        _b_17819 = 0;
L2: 
        if (binary_op_a(GREATER, _b_17819, _9991)){
            goto L3; // [91] 233
        }

        /** 		io:seek(current_db, index+b*8)*/
        if (IS_ATOM_INT(_b_17819)) {
            if (_b_17819 == (short)_b_17819)
            _9992 = _b_17819 * 8;
            else
            _9992 = NewDouble(_b_17819 * (double)8);
        }
        else {
            _9992 = NewDouble(DBL_PTR(_b_17819)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_index_17800) && IS_ATOM_INT(_9992)) {
            _9993 = _index_17800 + _9992;
            if ((long)((unsigned long)_9993 + (unsigned long)HIGH_BITS) >= 0) 
            _9993 = NewDouble((double)_9993);
        }
        else {
            if (IS_ATOM_INT(_index_17800)) {
                _9993 = NewDouble((double)_index_17800 + DBL_PTR(_9992)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9992)) {
                    _9993 = NewDouble(DBL_PTR(_index_17800)->dbl + (double)_9992);
                }
                else
                _9993 = NewDouble(DBL_PTR(_index_17800)->dbl + DBL_PTR(_9992)->dbl);
            }
        }
        DeRef(_9992);
        _9992 = NOVALUE;
        DeRef(_pos_inlined_seek_at_109_17824);
        _pos_inlined_seek_at_109_17824 = _9993;
        _9993 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_109_17824);
        DeRef(_seek_1__tmp_at112_17826);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_109_17824;
        _seek_1__tmp_at112_17826 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_112_17825 = machine(19, _seek_1__tmp_at112_17826);
        DeRef(_pos_inlined_seek_at_109_17824);
        _pos_inlined_seek_at_109_17824 = NOVALUE;
        DeRef(_seek_1__tmp_at112_17826);
        _seek_1__tmp_at112_17826 = NOVALUE;

        /** 		nrecs = get4()*/
        _0 = _nrecs_17795;
        _nrecs_17795 = _38get4();
        DeRef(_0);

        /** 		records_ptr = get4()*/
        _0 = _records_ptr_17796;
        _records_ptr_17796 = _38get4();
        DeRef(_0);

        /** 		for r = 0 to nrecs-1 do*/
        if (IS_ATOM_INT(_nrecs_17795)) {
            _9996 = _nrecs_17795 - 1;
            if ((long)((unsigned long)_9996 +(unsigned long) HIGH_BITS) >= 0){
                _9996 = NewDouble((double)_9996);
            }
        }
        else {
            _9996 = NewDouble(DBL_PTR(_nrecs_17795)->dbl - (double)1);
        }
        {
            int _r_17830;
            _r_17830 = 0;
L4: 
            if (binary_op_a(GREATER, _r_17830, _9996)){
                goto L5; // [142] 221
            }

            /** 			io:seek(current_db, records_ptr + r*4)*/
            if (IS_ATOM_INT(_r_17830)) {
                if (_r_17830 == (short)_r_17830)
                _9997 = _r_17830 * 4;
                else
                _9997 = NewDouble(_r_17830 * (double)4);
            }
            else {
                _9997 = NewDouble(DBL_PTR(_r_17830)->dbl * (double)4);
            }
            if (IS_ATOM_INT(_records_ptr_17796) && IS_ATOM_INT(_9997)) {
                _9998 = _records_ptr_17796 + _9997;
                if ((long)((unsigned long)_9998 + (unsigned long)HIGH_BITS) >= 0) 
                _9998 = NewDouble((double)_9998);
            }
            else {
                if (IS_ATOM_INT(_records_ptr_17796)) {
                    _9998 = NewDouble((double)_records_ptr_17796 + DBL_PTR(_9997)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_9997)) {
                        _9998 = NewDouble(DBL_PTR(_records_ptr_17796)->dbl + (double)_9997);
                    }
                    else
                    _9998 = NewDouble(DBL_PTR(_records_ptr_17796)->dbl + DBL_PTR(_9997)->dbl);
                }
            }
            DeRef(_9997);
            _9997 = NOVALUE;
            DeRef(_pos_inlined_seek_at_160_17835);
            _pos_inlined_seek_at_160_17835 = _9998;
            _9998 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_160_17835);
            DeRef(_seek_1__tmp_at163_17837);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16418;
            ((int *)_2)[2] = _pos_inlined_seek_at_160_17835;
            _seek_1__tmp_at163_17837 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_163_17836 = machine(19, _seek_1__tmp_at163_17837);
            DeRef(_pos_inlined_seek_at_160_17835);
            _pos_inlined_seek_at_160_17835 = NOVALUE;
            DeRef(_seek_1__tmp_at163_17837);
            _seek_1__tmp_at163_17837 = NOVALUE;

            /** 			p = get4()*/
            _0 = _p_17798;
            _p_17798 = _38get4();
            DeRef(_0);

            /** 			io:seek(current_db, p)*/

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_p_17798);
            DeRef(_seek_1__tmp_at185_17841);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16418;
            ((int *)_2)[2] = _p_17798;
            _seek_1__tmp_at185_17841 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_185_17840 = machine(19, _seek_1__tmp_at185_17841);
            DeRef(_seek_1__tmp_at185_17841);
            _seek_1__tmp_at185_17841 = NOVALUE;

            /** 			data_ptr = get4()*/
            _0 = _data_ptr_17799;
            _data_ptr_17799 = _38get4();
            DeRef(_0);

            /** 			db_free(data_ptr)*/
            Ref(_data_ptr_17799);
            _38db_free(_data_ptr_17799);

            /** 			db_free(p)*/
            Ref(_p_17798);
            _38db_free(_p_17798);

            /** 		end for*/
            _0 = _r_17830;
            if (IS_ATOM_INT(_r_17830)) {
                _r_17830 = _r_17830 + 1;
                if ((long)((unsigned long)_r_17830 +(unsigned long) HIGH_BITS) >= 0){
                    _r_17830 = NewDouble((double)_r_17830);
                }
            }
            else {
                _r_17830 = binary_op_a(PLUS, _r_17830, 1);
            }
            DeRef(_0);
            goto L4; // [216] 149
L5: 
            ;
            DeRef(_r_17830);
        }

        /** 		db_free(records_ptr)*/
        Ref(_records_ptr_17796);
        _38db_free(_records_ptr_17796);

        /** 	end for*/
        _0 = _b_17819;
        if (IS_ATOM_INT(_b_17819)) {
            _b_17819 = _b_17819 + 1;
            if ((long)((unsigned long)_b_17819 +(unsigned long) HIGH_BITS) >= 0){
                _b_17819 = NewDouble((double)_b_17819);
            }
        }
        else {
            _b_17819 = binary_op_a(PLUS, _b_17819, 1);
        }
        DeRef(_0);
        goto L2; // [228] 98
L3: 
        ;
        DeRef(_b_17819);
    }

    /** 	db_free(index)*/
    Ref(_index_17800);
    _38db_free(_index_17800);

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at241_17845);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at241_17845 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_241_17844 = machine(19, _seek_1__tmp_at241_17845);
    DeRefi(_seek_1__tmp_at241_17845);
    _seek_1__tmp_at241_17845 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_17793;
    _tables_17793 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17793);
    DeRef(_seek_1__tmp_at263_17849);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_17793;
    _seek_1__tmp_at263_17849 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_263_17848 = machine(19, _seek_1__tmp_at263_17849);
    DeRef(_seek_1__tmp_at263_17849);
    _seek_1__tmp_at263_17849 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_17794;
    _nt_17794 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, table+SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_table_17792)) {
        _10003 = _table_17792 + 16;
        if ((long)((unsigned long)_10003 + (unsigned long)HIGH_BITS) >= 0) 
        _10003 = NewDouble((double)_10003);
    }
    else {
        _10003 = NewDouble(DBL_PTR(_table_17792)->dbl + (double)16);
    }
    DeRef(_pos_inlined_seek_at_289_17853);
    _pos_inlined_seek_at_289_17853 = _10003;
    _10003 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_289_17853);
    DeRef(_seek_1__tmp_at292_17855);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_289_17853;
    _seek_1__tmp_at292_17855 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_292_17854 = machine(19, _seek_1__tmp_at292_17855);
    DeRef(_pos_inlined_seek_at_289_17853);
    _pos_inlined_seek_at_289_17853 = NOVALUE;
    DeRef(_seek_1__tmp_at292_17855);
    _seek_1__tmp_at292_17855 = NOVALUE;

    /** 	remaining = io:get_bytes(current_db,*/
    if (IS_ATOM_INT(_tables_17793)) {
        _10004 = _tables_17793 + 4;
        if ((long)((unsigned long)_10004 + (unsigned long)HIGH_BITS) >= 0) 
        _10004 = NewDouble((double)_10004);
    }
    else {
        _10004 = NewDouble(DBL_PTR(_tables_17793)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_17794)) {
        if (_nt_17794 == (short)_nt_17794)
        _10005 = _nt_17794 * 16;
        else
        _10005 = NewDouble(_nt_17794 * (double)16);
    }
    else {
        _10005 = NewDouble(DBL_PTR(_nt_17794)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10004) && IS_ATOM_INT(_10005)) {
        _10006 = _10004 + _10005;
        if ((long)((unsigned long)_10006 + (unsigned long)HIGH_BITS) >= 0) 
        _10006 = NewDouble((double)_10006);
    }
    else {
        if (IS_ATOM_INT(_10004)) {
            _10006 = NewDouble((double)_10004 + DBL_PTR(_10005)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10005)) {
                _10006 = NewDouble(DBL_PTR(_10004)->dbl + (double)_10005);
            }
            else
            _10006 = NewDouble(DBL_PTR(_10004)->dbl + DBL_PTR(_10005)->dbl);
        }
    }
    DeRef(_10004);
    _10004 = NOVALUE;
    DeRef(_10005);
    _10005 = NOVALUE;
    if (IS_ATOM_INT(_table_17792)) {
        _10007 = _table_17792 + 16;
        if ((long)((unsigned long)_10007 + (unsigned long)HIGH_BITS) >= 0) 
        _10007 = NewDouble((double)_10007);
    }
    else {
        _10007 = NewDouble(DBL_PTR(_table_17792)->dbl + (double)16);
    }
    if (IS_ATOM_INT(_10006) && IS_ATOM_INT(_10007)) {
        _10008 = _10006 - _10007;
        if ((long)((unsigned long)_10008 +(unsigned long) HIGH_BITS) >= 0){
            _10008 = NewDouble((double)_10008);
        }
    }
    else {
        if (IS_ATOM_INT(_10006)) {
            _10008 = NewDouble((double)_10006 - DBL_PTR(_10007)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10007)) {
                _10008 = NewDouble(DBL_PTR(_10006)->dbl - (double)_10007);
            }
            else
            _10008 = NewDouble(DBL_PTR(_10006)->dbl - DBL_PTR(_10007)->dbl);
        }
    }
    DeRef(_10006);
    _10006 = NOVALUE;
    DeRef(_10007);
    _10007 = NOVALUE;
    _0 = _remaining_17801;
    _remaining_17801 = _18get_bytes(_38current_db_16418, _10008);
    DeRef(_0);
    _10008 = NOVALUE;

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_17792);
    DeRef(_seek_1__tmp_at340_17864);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _table_17792;
    _seek_1__tmp_at340_17864 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_340_17863 = machine(19, _seek_1__tmp_at340_17864);
    DeRef(_seek_1__tmp_at340_17864);
    _seek_1__tmp_at340_17864 = NOVALUE;

    /** 	putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_17801); // DJP 

    /** end procedure*/
    goto L6; // [365] 368
L6: 

    /** 	nt -= 1*/
    _0 = _nt_17794;
    if (IS_ATOM_INT(_nt_17794)) {
        _nt_17794 = _nt_17794 - 1;
        if ((long)((unsigned long)_nt_17794 +(unsigned long) HIGH_BITS) >= 0){
            _nt_17794 = NewDouble((double)_nt_17794);
        }
    }
    else {
        _nt_17794 = NewDouble(DBL_PTR(_nt_17794)->dbl - (double)1);
    }
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17793);
    DeRef(_seek_1__tmp_at377_17869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_17793;
    _seek_1__tmp_at377_17869 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_377_17868 = machine(19, _seek_1__tmp_at377_17869);
    DeRef(_seek_1__tmp_at377_17869);
    _seek_1__tmp_at377_17869 = NOVALUE;

    /** 	put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nt_17794)) {
        *poke4_addr = (unsigned long)_nt_17794;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_17794)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at392_17871);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at392_17871 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at392_17871); // DJP 

    /** end procedure*/
    goto L7; // [414] 417
L7: 
    DeRefi(_put4_1__tmp_at392_17871);
    _put4_1__tmp_at392_17871 = NOVALUE;

    /** 	k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _10011 = MAKE_SEQ(_1);
    _k_17802 = find_from(_10011, _38cache_index_16427, 1);
    DeRefDS(_10011);
    _10011 = NOVALUE;

    /** 	if k != 0 then*/
    if (_k_17802 == 0)
    goto L8; // [438] 461

    /** 		cache_index = remove(cache_index, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38cache_index_16427);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_17802)) ? _k_17802 : (long)(DBL_PTR(_k_17802)->dbl);
        int stop = (IS_ATOM_INT(_k_17802)) ? _k_17802 : (long)(DBL_PTR(_k_17802)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427 );
            }
            else Tail(SEQ_PTR(_38cache_index_16427), stop+1, &_38cache_index_16427);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427);
        }
        else {
            assign_slice_seq = &assign_space;
            _38cache_index_16427 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16427)->ref == 1));
        }
    }

    /** 		key_cache = remove(key_cache, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38key_cache_16426);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_17802)) ? _k_17802 : (long)(DBL_PTR(_k_17802)->dbl);
        int stop = (IS_ATOM_INT(_k_17802)) ? _k_17802 : (long)(DBL_PTR(_k_17802)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426 );
            }
            else Tail(SEQ_PTR(_38key_cache_16426), stop+1, &_38key_cache_16426);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426);
        }
        else {
            assign_slice_seq = &assign_space;
            _38key_cache_16426 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16426)->ref == 1));
        }
    }
L8: 

    /** 	if table = current_table_pos then*/
    if (binary_op_a(NOTEQ, _table_17792, _38current_table_pos_16419)){
        goto L9; // [465] 484
    }

    /** 		current_table_pos = -1*/
    DeRef(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;

    /** 		current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _5;
    goto LA; // [481] 550
L9: 

    /** 	elsif table < current_table_pos then*/
    if (binary_op_a(GREATEREQ, _table_17792, _38current_table_pos_16419)){
        goto LB; // [488] 549
    }

    /** 		current_table_pos -= SIZEOF_TABLE_HEADER*/
    _0 = _38current_table_pos_16419;
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _38current_table_pos_16419 = _38current_table_pos_16419 - 16;
        if ((long)((unsigned long)_38current_table_pos_16419 +(unsigned long) HIGH_BITS) >= 0){
            _38current_table_pos_16419 = NewDouble((double)_38current_table_pos_16419);
        }
    }
    else {
        _38current_table_pos_16419 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl - (double)16);
    }
    DeRef(_0);

    /** 		io:seek(current_db, current_table_pos)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_38current_table_pos_16419);
    DeRef(_seek_1__tmp_at505_17885);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _seek_1__tmp_at505_17885 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_505_17884 = machine(19, _seek_1__tmp_at505_17885);
    DeRef(_seek_1__tmp_at505_17885);
    _seek_1__tmp_at505_17885 = NOVALUE;

    /** 		data_ptr = get4()*/
    _0 = _data_ptr_17799;
    _data_ptr_17799 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_17799);
    DeRef(_seek_1__tmp_at527_17889);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _data_ptr_17799;
    _seek_1__tmp_at527_17889 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_527_17888 = machine(19, _seek_1__tmp_at527_17889);
    DeRef(_seek_1__tmp_at527_17889);
    _seek_1__tmp_at527_17889 = NOVALUE;

    /** 		current_table_name = get_string()*/
    _0 = _38get_string();
    DeRef(_38current_table_name_16420);
    _38current_table_name_16420 = _0;
LB: 
LA: 

    /** end procedure*/
    DeRefDS(_name_17791);
    DeRef(_table_17792);
    DeRef(_tables_17793);
    DeRef(_nt_17794);
    DeRef(_nrecs_17795);
    DeRef(_records_ptr_17796);
    DeRef(_blocks_17797);
    DeRef(_p_17798);
    DeRef(_data_ptr_17799);
    DeRef(_index_17800);
    DeRef(_remaining_17801);
    DeRef(_9991);
    _9991 = NOVALUE;
    DeRef(_9996);
    _9996 = NOVALUE;
    return;
    ;
}
void db_delete_table() __attribute__ ((alias ("_38db_delete_table")));


void _38db_clear_table(int _name_17893, int _init_records_17894)
{
    int _table_17895 = NOVALUE;
    int _nrecs_17896 = NOVALUE;
    int _records_ptr_17897 = NOVALUE;
    int _blocks_17898 = NOVALUE;
    int _p_17899 = NOVALUE;
    int _data_ptr_17900 = NOVALUE;
    int _index_ptr_17901 = NOVALUE;
    int _k_17902 = NOVALUE;
    int _init_index_17903 = NOVALUE;
    int _seek_1__tmp_at57_17915 = NOVALUE;
    int _seek_inlined_seek_at_57_17914 = NOVALUE;
    int _pos_inlined_seek_at_54_17913 = NOVALUE;
    int _seek_1__tmp_at113_17927 = NOVALUE;
    int _seek_inlined_seek_at_113_17926 = NOVALUE;
    int _pos_inlined_seek_at_110_17925 = NOVALUE;
    int _seek_1__tmp_at164_17938 = NOVALUE;
    int _seek_inlined_seek_at_164_17937 = NOVALUE;
    int _pos_inlined_seek_at_161_17936 = NOVALUE;
    int _seek_1__tmp_at186_17942 = NOVALUE;
    int _seek_inlined_seek_at_186_17941 = NOVALUE;
    int _s_inlined_putn_at_258_17949 = NOVALUE;
    int _put4_1__tmp_at289_17953 = NOVALUE;
    int _put4_1__tmp_at317_17955 = NOVALUE;
    int _s_inlined_putn_at_357_17960 = NOVALUE;
    int _seek_1__tmp_at387_17965 = NOVALUE;
    int _seek_inlined_seek_at_387_17964 = NOVALUE;
    int _pos_inlined_seek_at_384_17963 = NOVALUE;
    int _put4_1__tmp_at402_17967 = NOVALUE;
    int _put4_1__tmp_at430_17969 = NOVALUE;
    int _put4_1__tmp_at458_17971 = NOVALUE;
    int _10050 = NOVALUE;
    int _10049 = NOVALUE;
    int _10048 = NOVALUE;
    int _10047 = NOVALUE;
    int _10046 = NOVALUE;
    int _10044 = NOVALUE;
    int _10043 = NOVALUE;
    int _10042 = NOVALUE;
    int _10040 = NOVALUE;
    int _10037 = NOVALUE;
    int _10036 = NOVALUE;
    int _10035 = NOVALUE;
    int _10032 = NOVALUE;
    int _10031 = NOVALUE;
    int _10030 = NOVALUE;
    int _10026 = NOVALUE;
    int _10024 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_init_records_17894)) {
        _1 = (long)(DBL_PTR(_init_records_17894)->dbl);
        DeRefDS(_init_records_17894);
        _init_records_17894 = _1;
    }

    /** 	table = table_find(name)*/
    RefDS(_name_17893);
    _0 = _table_17895;
    _table_17895 = _38table_find(_name_17893);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17895, -1)){
        goto L1; // [13] 23
    }

    /** 		return*/
    DeRefDS(_name_17893);
    DeRef(_table_17895);
    DeRef(_nrecs_17896);
    DeRef(_records_ptr_17897);
    DeRef(_blocks_17898);
    DeRef(_p_17899);
    DeRef(_data_ptr_17900);
    DeRef(_index_ptr_17901);
    return;
L1: 

    /** 	if init_records < 1 then*/
    if (_init_records_17894 >= 1)
    goto L2; // [25] 35

    /** 		init_records = 1*/
    _init_records_17894 = 1;
L2: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_17894;
    ((int *)_2)[2] = 10;
    _10024 = MAKE_SEQ(_1);
    _init_index_17903 = _20min(_10024);
    _10024 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_17903)) {
        _1 = (long)(DBL_PTR(_init_index_17903)->dbl);
        DeRefDS(_init_index_17903);
        _init_index_17903 = _1;
    }

    /** 	io:seek(current_db, table + 4)*/
    if (IS_ATOM_INT(_table_17895)) {
        _10026 = _table_17895 + 4;
        if ((long)((unsigned long)_10026 + (unsigned long)HIGH_BITS) >= 0) 
        _10026 = NewDouble((double)_10026);
    }
    else {
        _10026 = NewDouble(DBL_PTR(_table_17895)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_54_17913);
    _pos_inlined_seek_at_54_17913 = _10026;
    _10026 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_54_17913);
    DeRef(_seek_1__tmp_at57_17915);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_54_17913;
    _seek_1__tmp_at57_17915 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_57_17914 = machine(19, _seek_1__tmp_at57_17915);
    DeRef(_pos_inlined_seek_at_54_17913);
    _pos_inlined_seek_at_54_17913 = NOVALUE;
    DeRef(_seek_1__tmp_at57_17915);
    _seek_1__tmp_at57_17915 = NOVALUE;

    /** 	nrecs = get4()*/
    _0 = _nrecs_17896;
    _nrecs_17896 = _38get4();
    DeRef(_0);

    /** 	blocks = get4()*/
    _0 = _blocks_17898;
    _blocks_17898 = _38get4();
    DeRef(_0);

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_17901;
    _index_ptr_17901 = _38get4();
    DeRef(_0);

    /** 	for b = 0 to blocks-1 do*/
    if (IS_ATOM_INT(_blocks_17898)) {
        _10030 = _blocks_17898 - 1;
        if ((long)((unsigned long)_10030 +(unsigned long) HIGH_BITS) >= 0){
            _10030 = NewDouble((double)_10030);
        }
    }
    else {
        _10030 = NewDouble(DBL_PTR(_blocks_17898)->dbl - (double)1);
    }
    {
        int _b_17920;
        _b_17920 = 0;
L3: 
        if (binary_op_a(GREATER, _b_17920, _10030)){
            goto L4; // [92] 234
        }

        /** 		io:seek(current_db, index_ptr + b*8)*/
        if (IS_ATOM_INT(_b_17920)) {
            if (_b_17920 == (short)_b_17920)
            _10031 = _b_17920 * 8;
            else
            _10031 = NewDouble(_b_17920 * (double)8);
        }
        else {
            _10031 = NewDouble(DBL_PTR(_b_17920)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_index_ptr_17901) && IS_ATOM_INT(_10031)) {
            _10032 = _index_ptr_17901 + _10031;
            if ((long)((unsigned long)_10032 + (unsigned long)HIGH_BITS) >= 0) 
            _10032 = NewDouble((double)_10032);
        }
        else {
            if (IS_ATOM_INT(_index_ptr_17901)) {
                _10032 = NewDouble((double)_index_ptr_17901 + DBL_PTR(_10031)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10031)) {
                    _10032 = NewDouble(DBL_PTR(_index_ptr_17901)->dbl + (double)_10031);
                }
                else
                _10032 = NewDouble(DBL_PTR(_index_ptr_17901)->dbl + DBL_PTR(_10031)->dbl);
            }
        }
        DeRef(_10031);
        _10031 = NOVALUE;
        DeRef(_pos_inlined_seek_at_110_17925);
        _pos_inlined_seek_at_110_17925 = _10032;
        _10032 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_110_17925);
        DeRef(_seek_1__tmp_at113_17927);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_110_17925;
        _seek_1__tmp_at113_17927 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_113_17926 = machine(19, _seek_1__tmp_at113_17927);
        DeRef(_pos_inlined_seek_at_110_17925);
        _pos_inlined_seek_at_110_17925 = NOVALUE;
        DeRef(_seek_1__tmp_at113_17927);
        _seek_1__tmp_at113_17927 = NOVALUE;

        /** 		nrecs = get4()*/
        _0 = _nrecs_17896;
        _nrecs_17896 = _38get4();
        DeRef(_0);

        /** 		records_ptr = get4()*/
        _0 = _records_ptr_17897;
        _records_ptr_17897 = _38get4();
        DeRef(_0);

        /** 		for r = 0 to nrecs-1 do*/
        if (IS_ATOM_INT(_nrecs_17896)) {
            _10035 = _nrecs_17896 - 1;
            if ((long)((unsigned long)_10035 +(unsigned long) HIGH_BITS) >= 0){
                _10035 = NewDouble((double)_10035);
            }
        }
        else {
            _10035 = NewDouble(DBL_PTR(_nrecs_17896)->dbl - (double)1);
        }
        {
            int _r_17931;
            _r_17931 = 0;
L5: 
            if (binary_op_a(GREATER, _r_17931, _10035)){
                goto L6; // [143] 222
            }

            /** 			io:seek(current_db, records_ptr + r*4)*/
            if (IS_ATOM_INT(_r_17931)) {
                if (_r_17931 == (short)_r_17931)
                _10036 = _r_17931 * 4;
                else
                _10036 = NewDouble(_r_17931 * (double)4);
            }
            else {
                _10036 = NewDouble(DBL_PTR(_r_17931)->dbl * (double)4);
            }
            if (IS_ATOM_INT(_records_ptr_17897) && IS_ATOM_INT(_10036)) {
                _10037 = _records_ptr_17897 + _10036;
                if ((long)((unsigned long)_10037 + (unsigned long)HIGH_BITS) >= 0) 
                _10037 = NewDouble((double)_10037);
            }
            else {
                if (IS_ATOM_INT(_records_ptr_17897)) {
                    _10037 = NewDouble((double)_records_ptr_17897 + DBL_PTR(_10036)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_10036)) {
                        _10037 = NewDouble(DBL_PTR(_records_ptr_17897)->dbl + (double)_10036);
                    }
                    else
                    _10037 = NewDouble(DBL_PTR(_records_ptr_17897)->dbl + DBL_PTR(_10036)->dbl);
                }
            }
            DeRef(_10036);
            _10036 = NOVALUE;
            DeRef(_pos_inlined_seek_at_161_17936);
            _pos_inlined_seek_at_161_17936 = _10037;
            _10037 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_161_17936);
            DeRef(_seek_1__tmp_at164_17938);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16418;
            ((int *)_2)[2] = _pos_inlined_seek_at_161_17936;
            _seek_1__tmp_at164_17938 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_164_17937 = machine(19, _seek_1__tmp_at164_17938);
            DeRef(_pos_inlined_seek_at_161_17936);
            _pos_inlined_seek_at_161_17936 = NOVALUE;
            DeRef(_seek_1__tmp_at164_17938);
            _seek_1__tmp_at164_17938 = NOVALUE;

            /** 			p = get4()*/
            _0 = _p_17899;
            _p_17899 = _38get4();
            DeRef(_0);

            /** 			io:seek(current_db, p)*/

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_p_17899);
            DeRef(_seek_1__tmp_at186_17942);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16418;
            ((int *)_2)[2] = _p_17899;
            _seek_1__tmp_at186_17942 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_186_17941 = machine(19, _seek_1__tmp_at186_17942);
            DeRef(_seek_1__tmp_at186_17942);
            _seek_1__tmp_at186_17942 = NOVALUE;

            /** 			data_ptr = get4()*/
            _0 = _data_ptr_17900;
            _data_ptr_17900 = _38get4();
            DeRef(_0);

            /** 			db_free(data_ptr)*/
            Ref(_data_ptr_17900);
            _38db_free(_data_ptr_17900);

            /** 			db_free(p)*/
            Ref(_p_17899);
            _38db_free(_p_17899);

            /** 		end for*/
            _0 = _r_17931;
            if (IS_ATOM_INT(_r_17931)) {
                _r_17931 = _r_17931 + 1;
                if ((long)((unsigned long)_r_17931 +(unsigned long) HIGH_BITS) >= 0){
                    _r_17931 = NewDouble((double)_r_17931);
                }
            }
            else {
                _r_17931 = binary_op_a(PLUS, _r_17931, 1);
            }
            DeRef(_0);
            goto L5; // [217] 150
L6: 
            ;
            DeRef(_r_17931);
        }

        /** 		db_free(records_ptr)*/
        Ref(_records_ptr_17897);
        _38db_free(_records_ptr_17897);

        /** 	end for*/
        _0 = _b_17920;
        if (IS_ATOM_INT(_b_17920)) {
            _b_17920 = _b_17920 + 1;
            if ((long)((unsigned long)_b_17920 +(unsigned long) HIGH_BITS) >= 0){
                _b_17920 = NewDouble((double)_b_17920);
            }
        }
        else {
            _b_17920 = binary_op_a(PLUS, _b_17920, 1);
        }
        DeRef(_0);
        goto L3; // [229] 99
L4: 
        ;
        DeRef(_b_17920);
    }

    /** 	db_free(index_ptr)*/
    Ref(_index_ptr_17901);
    _38db_free(_index_ptr_17901);

    /** 	data_ptr = db_allocate(init_records * 4)*/
    if (_init_records_17894 == (short)_init_records_17894)
    _10040 = _init_records_17894 * 4;
    else
    _10040 = NewDouble(_init_records_17894 * (double)4);
    _0 = _data_ptr_17900;
    _data_ptr_17900 = _38db_allocate(_10040);
    DeRef(_0);
    _10040 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10042 = _init_records_17894 * 4;
    _10043 = Repeat(0, _10042);
    _10042 = NOVALUE;
    DeRefi(_s_inlined_putn_at_258_17949);
    _s_inlined_putn_at_258_17949 = _10043;
    _10043 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_258_17949); // DJP 

    /** end procedure*/
    goto L7; // [273] 276
L7: 
    DeRefi(_s_inlined_putn_at_258_17949);
    _s_inlined_putn_at_258_17949 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_17903 == (short)_init_index_17903)
    _10044 = _init_index_17903 * 8;
    else
    _10044 = NewDouble(_init_index_17903 * (double)8);
    _0 = _index_ptr_17901;
    _index_ptr_17901 = _38db_allocate(_10044);
    DeRef(_0);
    _10044 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at289_17953);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at289_17953 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at289_17953); // DJP 

    /** end procedure*/
    goto L8; // [311] 314
L8: 
    DeRefi(_put4_1__tmp_at289_17953);
    _put4_1__tmp_at289_17953 = NOVALUE;

    /** 	put4(data_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_17900)) {
        *poke4_addr = (unsigned long)_data_ptr_17900;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_17900)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at317_17955);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at317_17955 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at317_17955); // DJP 

    /** end procedure*/
    goto L9; // [339] 342
L9: 
    DeRefi(_put4_1__tmp_at317_17955);
    _put4_1__tmp_at317_17955 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10046 = _init_index_17903 - 1;
    if ((long)((unsigned long)_10046 +(unsigned long) HIGH_BITS) >= 0){
        _10046 = NewDouble((double)_10046);
    }
    if (IS_ATOM_INT(_10046)) {
        _10047 = _10046 * 8;
    }
    else {
        _10047 = NewDouble(DBL_PTR(_10046)->dbl * (double)8);
    }
    DeRef(_10046);
    _10046 = NOVALUE;
    _10048 = Repeat(0, _10047);
    DeRef(_10047);
    _10047 = NOVALUE;
    DeRefi(_s_inlined_putn_at_357_17960);
    _s_inlined_putn_at_357_17960 = _10048;
    _10048 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_357_17960); // DJP 

    /** end procedure*/
    goto LA; // [372] 375
LA: 
    DeRefi(_s_inlined_putn_at_357_17960);
    _s_inlined_putn_at_357_17960 = NOVALUE;

    /** 	io:seek(current_db, table + 4)*/
    if (IS_ATOM_INT(_table_17895)) {
        _10049 = _table_17895 + 4;
        if ((long)((unsigned long)_10049 + (unsigned long)HIGH_BITS) >= 0) 
        _10049 = NewDouble((double)_10049);
    }
    else {
        _10049 = NewDouble(DBL_PTR(_table_17895)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_384_17963);
    _pos_inlined_seek_at_384_17963 = _10049;
    _10049 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_384_17963);
    DeRef(_seek_1__tmp_at387_17965);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_384_17963;
    _seek_1__tmp_at387_17965 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_387_17964 = machine(19, _seek_1__tmp_at387_17965);
    DeRef(_pos_inlined_seek_at_384_17963);
    _pos_inlined_seek_at_384_17963 = NOVALUE;
    DeRef(_seek_1__tmp_at387_17965);
    _seek_1__tmp_at387_17965 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at402_17967);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at402_17967 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at402_17967); // DJP 

    /** end procedure*/
    goto LB; // [424] 427
LB: 
    DeRefi(_put4_1__tmp_at402_17967);
    _put4_1__tmp_at402_17967 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at430_17969);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at430_17969 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at430_17969); // DJP 

    /** end procedure*/
    goto LC; // [452] 455
LC: 
    DeRefi(_put4_1__tmp_at430_17969);
    _put4_1__tmp_at430_17969 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17901)) {
        *poke4_addr = (unsigned long)_index_ptr_17901;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_17901)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at458_17971);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at458_17971 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at458_17971); // DJP 

    /** end procedure*/
    goto LD; // [480] 483
LD: 
    DeRefi(_put4_1__tmp_at458_17971);
    _put4_1__tmp_at458_17971 = NOVALUE;

    /** 	k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _38current_table_pos_16419;
    _10050 = MAKE_SEQ(_1);
    _k_17902 = find_from(_10050, _38cache_index_16427, 1);
    DeRefDS(_10050);
    _10050 = NOVALUE;

    /** 	if k != 0 then*/
    if (_k_17902 == 0)
    goto LE; // [504] 527

    /** 		cache_index = remove(cache_index, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38cache_index_16427);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_17902)) ? _k_17902 : (long)(DBL_PTR(_k_17902)->dbl);
        int stop = (IS_ATOM_INT(_k_17902)) ? _k_17902 : (long)(DBL_PTR(_k_17902)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427 );
            }
            else Tail(SEQ_PTR(_38cache_index_16427), stop+1, &_38cache_index_16427);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38cache_index_16427), start, &_38cache_index_16427);
        }
        else {
            assign_slice_seq = &assign_space;
            _38cache_index_16427 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16427)->ref == 1));
        }
    }

    /** 		key_cache = remove(key_cache, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38key_cache_16426);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_17902)) ? _k_17902 : (long)(DBL_PTR(_k_17902)->dbl);
        int stop = (IS_ATOM_INT(_k_17902)) ? _k_17902 : (long)(DBL_PTR(_k_17902)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426 );
            }
            else Tail(SEQ_PTR(_38key_cache_16426), stop+1, &_38key_cache_16426);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38key_cache_16426), start, &_38key_cache_16426);
        }
        else {
            assign_slice_seq = &assign_space;
            _38key_cache_16426 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16426)->ref == 1));
        }
    }
LE: 

    /** 	if table = current_table_pos then*/
    if (binary_op_a(NOTEQ, _table_17895, _38current_table_pos_16419)){
        goto LF; // [531] 543
    }

    /** 		key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16425);
    _38key_pointers_16425 = _5;
LF: 

    /** end procedure*/
    DeRefDS(_name_17893);
    DeRef(_table_17895);
    DeRef(_nrecs_17896);
    DeRef(_records_ptr_17897);
    DeRef(_blocks_17898);
    DeRef(_p_17899);
    DeRef(_data_ptr_17900);
    DeRef(_index_ptr_17901);
    DeRef(_10030);
    _10030 = NOVALUE;
    DeRef(_10035);
    _10035 = NOVALUE;
    return;
    ;
}
void db_clear_table() __attribute__ ((alias ("_38db_clear_table")));


void _38db_rename_table(int _name_17982, int _new_name_17983)
{
    int _table_17984 = NOVALUE;
    int _table_ptr_17985 = NOVALUE;
    int _seek_1__tmp_at66_17999 = NOVALUE;
    int _seek_inlined_seek_at_66_17998 = NOVALUE;
    int _s_inlined_putn_at_106_18006 = NOVALUE;
    int _seek_1__tmp_at129_18009 = NOVALUE;
    int _seek_inlined_seek_at_129_18008 = NOVALUE;
    int _put4_1__tmp_at144_18011 = NOVALUE;
    int _10070 = NOVALUE;
    int _10069 = NOVALUE;
    int _10067 = NOVALUE;
    int _10066 = NOVALUE;
    int _10065 = NOVALUE;
    int _10064 = NOVALUE;
    int _10061 = NOVALUE;
    int _10060 = NOVALUE;
    int _0, _1, _2;
    

    /** 	table = table_find(name)*/
    RefDS(_name_17982);
    _0 = _table_17984;
    _table_17984 = _38table_find(_name_17982);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17984, -1)){
        goto L1; // [13] 35
    }

    /** 		fatal(NO_TABLE, "source table doesn't exist", "db_rename_table", {name, new_name})*/
    RefDS(_new_name_17983);
    RefDS(_name_17982);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_17982;
    ((int *)_2)[2] = _new_name_17983;
    _10060 = MAKE_SEQ(_1);
    RefDS(_10058);
    RefDS(_10059);
    _38fatal(903, _10058, _10059, _10060);
    _10060 = NOVALUE;

    /** 		return*/
    DeRefDS(_name_17982);
    DeRefDS(_new_name_17983);
    DeRef(_table_17984);
    DeRef(_table_ptr_17985);
    return;
L1: 

    /** 	if table_find(new_name) != -1 then*/
    RefDS(_new_name_17983);
    _10061 = _38table_find(_new_name_17983);
    if (binary_op_a(EQUALS, _10061, -1)){
        DeRef(_10061);
        _10061 = NOVALUE;
        goto L2; // [41] 63
    }
    DeRef(_10061);
    _10061 = NOVALUE;

    /** 		fatal(DUP_TABLE, "target table name already exists", "db_rename_table", {name, new_name})*/
    RefDS(_new_name_17983);
    RefDS(_name_17982);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_17982;
    ((int *)_2)[2] = _new_name_17983;
    _10064 = MAKE_SEQ(_1);
    RefDS(_10063);
    RefDS(_10059);
    _38fatal(904, _10063, _10059, _10064);
    _10064 = NOVALUE;

    /** 		return*/
    DeRefDS(_name_17982);
    DeRefDS(_new_name_17983);
    DeRef(_table_17984);
    DeRef(_table_ptr_17985);
    return;
L2: 

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_17984);
    DeRef(_seek_1__tmp_at66_17999);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _table_17984;
    _seek_1__tmp_at66_17999 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_66_17998 = machine(19, _seek_1__tmp_at66_17999);
    DeRef(_seek_1__tmp_at66_17999);
    _seek_1__tmp_at66_17999 = NOVALUE;

    /** 	db_free(get4())*/
    _10065 = _38get4();
    _38db_free(_10065);
    _10065 = NOVALUE;

    /** 	table_ptr = db_allocate(length(new_name)+1)*/
    if (IS_SEQUENCE(_new_name_17983)){
            _10066 = SEQ_PTR(_new_name_17983)->length;
    }
    else {
        _10066 = 1;
    }
    _10067 = _10066 + 1;
    _10066 = NOVALUE;
    _0 = _table_ptr_17985;
    _table_ptr_17985 = _38db_allocate(_10067);
    DeRef(_0);
    _10067 = NOVALUE;

    /** 	putn(new_name & 0)*/
    Append(&_10069, _new_name_17983, 0);
    DeRef(_s_inlined_putn_at_106_18006);
    _s_inlined_putn_at_106_18006 = _10069;
    _10069 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_106_18006); // DJP 

    /** end procedure*/
    goto L3; // [121] 124
L3: 
    DeRef(_s_inlined_putn_at_106_18006);
    _s_inlined_putn_at_106_18006 = NOVALUE;

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_17984);
    DeRef(_seek_1__tmp_at129_18009);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _table_17984;
    _seek_1__tmp_at129_18009 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_129_18008 = machine(19, _seek_1__tmp_at129_18009);
    DeRef(_seek_1__tmp_at129_18009);
    _seek_1__tmp_at129_18009 = NOVALUE;

    /** 	put4(table_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_table_ptr_17985)) {
        *poke4_addr = (unsigned long)_table_ptr_17985;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_table_ptr_17985)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at144_18011);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at144_18011 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at144_18011); // DJP 

    /** end procedure*/
    goto L4; // [166] 169
L4: 
    DeRefi(_put4_1__tmp_at144_18011);
    _put4_1__tmp_at144_18011 = NOVALUE;

    /** 	if equal(current_table_name, name) then*/
    if (_38current_table_name_16420 == _name_17982)
    _10070 = 1;
    else if (IS_ATOM_INT(_38current_table_name_16420) && IS_ATOM_INT(_name_17982))
    _10070 = 0;
    else
    _10070 = (compare(_38current_table_name_16420, _name_17982) == 0);
    if (_10070 == 0)
    {
        _10070 = NOVALUE;
        goto L5; // [179] 190
    }
    else{
        _10070 = NOVALUE;
    }

    /** 		current_table_name = new_name*/
    RefDS(_new_name_17983);
    DeRefDS(_38current_table_name_16420);
    _38current_table_name_16420 = _new_name_17983;
L5: 

    /** end procedure*/
    DeRefDS(_name_17982);
    DeRefDS(_new_name_17983);
    DeRef(_table_17984);
    DeRef(_table_ptr_17985);
    return;
    ;
}
void db_rename_table() __attribute__ ((alias ("_38db_rename_table")));


int _38db_table_list()
{
    int _seek_1__tmp_at120_18045 = NOVALUE;
    int _seek_inlined_seek_at_120_18044 = NOVALUE;
    int _seek_1__tmp_at98_18041 = NOVALUE;
    int _seek_inlined_seek_at_98_18040 = NOVALUE;
    int _pos_inlined_seek_at_95_18039 = NOVALUE;
    int _seek_1__tmp_at42_18029 = NOVALUE;
    int _seek_inlined_seek_at_42_18028 = NOVALUE;
    int _seek_1__tmp_at4_18022 = NOVALUE;
    int _seek_inlined_seek_at_4_18021 = NOVALUE;
    int _table_names_18016 = NOVALUE;
    int _tables_18017 = NOVALUE;
    int _nt_18018 = NOVALUE;
    int _name_18019 = NOVALUE;
    int _10082 = NOVALUE;
    int _10081 = NOVALUE;
    int _10079 = NOVALUE;
    int _10078 = NOVALUE;
    int _10077 = NOVALUE;
    int _10076 = NOVALUE;
    int _10071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18022);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_18022 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18021 = machine(19, _seek_1__tmp_at4_18022);
    DeRefi(_seek_1__tmp_at4_18022);
    _seek_1__tmp_at4_18022 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _10071 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _10071 = 1;
    }
    if (_10071 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18016);
    DeRef(_tables_18017);
    DeRef(_nt_18018);
    DeRef(_name_18019);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18017;
    _tables_18017 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18017);
    DeRef(_seek_1__tmp_at42_18029);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _tables_18017;
    _seek_1__tmp_at42_18029 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18028 = machine(19, _seek_1__tmp_at42_18029);
    DeRef(_seek_1__tmp_at42_18029);
    _seek_1__tmp_at42_18029 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18018;
    _nt_18018 = _38get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_18016);
    _table_names_18016 = Repeat(0, _nt_18018);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18018)) {
        _10076 = _nt_18018 - 1;
        if ((long)((unsigned long)_10076 +(unsigned long) HIGH_BITS) >= 0){
            _10076 = NewDouble((double)_10076);
        }
    }
    else {
        _10076 = NewDouble(DBL_PTR(_nt_18018)->dbl - (double)1);
    }
    {
        int _i_18033;
        _i_18033 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18033, _10076)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18017)) {
            _10077 = _tables_18017 + 4;
            if ((long)((unsigned long)_10077 + (unsigned long)HIGH_BITS) >= 0) 
            _10077 = NewDouble((double)_10077);
        }
        else {
            _10077 = NewDouble(DBL_PTR(_tables_18017)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_18033)) {
            if (_i_18033 == (short)_i_18033)
            _10078 = _i_18033 * 16;
            else
            _10078 = NewDouble(_i_18033 * (double)16);
        }
        else {
            _10078 = NewDouble(DBL_PTR(_i_18033)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10077) && IS_ATOM_INT(_10078)) {
            _10079 = _10077 + _10078;
            if ((long)((unsigned long)_10079 + (unsigned long)HIGH_BITS) >= 0) 
            _10079 = NewDouble((double)_10079);
        }
        else {
            if (IS_ATOM_INT(_10077)) {
                _10079 = NewDouble((double)_10077 + DBL_PTR(_10078)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10078)) {
                    _10079 = NewDouble(DBL_PTR(_10077)->dbl + (double)_10078);
                }
                else
                _10079 = NewDouble(DBL_PTR(_10077)->dbl + DBL_PTR(_10078)->dbl);
            }
        }
        DeRef(_10077);
        _10077 = NOVALUE;
        DeRef(_10078);
        _10078 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18039);
        _pos_inlined_seek_at_95_18039 = _10079;
        _10079 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18039);
        DeRef(_seek_1__tmp_at98_18041);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_18039;
        _seek_1__tmp_at98_18041 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18040 = machine(19, _seek_1__tmp_at98_18041);
        DeRef(_pos_inlined_seek_at_95_18039);
        _pos_inlined_seek_at_95_18039 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18041);
        _seek_1__tmp_at98_18041 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_18019;
        _name_18019 = _38get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18019);
        DeRef(_seek_1__tmp_at120_18045);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16418;
        ((int *)_2)[2] = _name_18019;
        _seek_1__tmp_at120_18045 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18044 = machine(19, _seek_1__tmp_at120_18045);
        DeRef(_seek_1__tmp_at120_18045);
        _seek_1__tmp_at120_18045 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18033)) {
            _10081 = _i_18033 + 1;
            if (_10081 > MAXINT){
                _10081 = NewDouble((double)_10081);
            }
        }
        else
        _10081 = binary_op(PLUS, 1, _i_18033);
        _10082 = _38get_string();
        _2 = (int)SEQ_PTR(_table_names_18016);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_18016 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10081))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10081)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10081);
        _1 = *(int *)_2;
        *(int *)_2 = _10082;
        if( _1 != _10082 ){
            DeRef(_1);
        }
        _10082 = NOVALUE;

        /** 	end for*/
        _0 = _i_18033;
        if (IS_ATOM_INT(_i_18033)) {
            _i_18033 = _i_18033 + 1;
            if ((long)((unsigned long)_i_18033 +(unsigned long) HIGH_BITS) >= 0){
                _i_18033 = NewDouble((double)_i_18033);
            }
        }
        else {
            _i_18033 = binary_op_a(PLUS, _i_18033, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18033);
    }

    /** 	return table_names*/
    DeRef(_tables_18017);
    DeRef(_nt_18018);
    DeRef(_name_18019);
    DeRef(_10076);
    _10076 = NOVALUE;
    DeRef(_10081);
    _10081 = NOVALUE;
    return _table_names_18016;
    ;
}
int db_table_list() __attribute__ ((alias ("_38db_table_list")));


int _38key_value(int _ptr_18050)
{
    int _seek_1__tmp_at11_18055 = NOVALUE;
    int _seek_inlined_seek_at_11_18054 = NOVALUE;
    int _pos_inlined_seek_at_8_18053 = NOVALUE;
    int _10084 = NOVALUE;
    int _10083 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18050)) {
        _10083 = _ptr_18050 + 4;
        if ((long)((unsigned long)_10083 + (unsigned long)HIGH_BITS) >= 0) 
        _10083 = NewDouble((double)_10083);
    }
    else {
        _10083 = NewDouble(DBL_PTR(_ptr_18050)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18053);
    _pos_inlined_seek_at_8_18053 = _10083;
    _10083 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18053);
    DeRef(_seek_1__tmp_at11_18055);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18053;
    _seek_1__tmp_at11_18055 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18054 = machine(19, _seek_1__tmp_at11_18055);
    DeRef(_pos_inlined_seek_at_8_18053);
    _pos_inlined_seek_at_8_18053 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18055);
    _seek_1__tmp_at11_18055 = NOVALUE;

    /** 	return decompress(0)*/
    _10084 = _38decompress(0);
    DeRef(_ptr_18050);
    return _10084;
    ;
}


int _38db_find_key(int _key_18059, int _table_name_18060)
{
    int _lo_18061 = NOVALUE;
    int _hi_18062 = NOVALUE;
    int _mid_18063 = NOVALUE;
    int _c_18064 = NOVALUE;
    int _10108 = NOVALUE;
    int _10100 = NOVALUE;
    int _10099 = NOVALUE;
    int _10097 = NOVALUE;
    int _10094 = NOVALUE;
    int _10091 = NOVALUE;
    int _10087 = NOVALUE;
    int _10085 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18060 == _38current_table_name_16420)
    _10085 = 1;
    else if (IS_ATOM_INT(_table_name_18060) && IS_ATOM_INT(_38current_table_name_16420))
    _10085 = 0;
    else
    _10085 = (compare(_table_name_18060, _38current_table_name_16420) == 0);
    if (_10085 != 0)
    goto L1; // [9] 42
    _10085 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18060);
    _10087 = _38db_select_table(_table_name_18060);
    if (binary_op_a(EQUALS, _10087, 0)){
        DeRef(_10087);
        _10087 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10087);
    _10087 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    Ref(_table_name_18060);
    Ref(_key_18059);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18059;
    ((int *)_2)[2] = _table_name_18060;
    _10091 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10090);
    _38fatal(903, _10089, _10090, _10091);
    _10091 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18059);
    DeRef(_table_name_18060);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18060);
    Ref(_key_18059);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18059;
    ((int *)_2)[2] = _table_name_18060;
    _10094 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10090);
    _38fatal(903, _10093, _10090, _10094);
    _10094 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18059);
    DeRef(_table_name_18060);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18061 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _hi_18062 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _hi_18062 = 1;
    }

    /** 	mid = 1*/
    _mid_18063 = 1;

    /** 	c = 0*/
    _c_18064 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18061 > _hi_18062)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10097 = _lo_18061 + _hi_18062;
    if ((long)((unsigned long)_10097 + (unsigned long)HIGH_BITS) >= 0) 
    _10097 = NewDouble((double)_10097);
    if (IS_ATOM_INT(_10097)) {
        _mid_18063 = _10097 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10097, 2);
        _mid_18063 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10097);
    _10097 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18063)) {
        _1 = (long)(DBL_PTR(_mid_18063)->dbl);
        DeRefDS(_mid_18063);
        _mid_18063 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10099 = (int)*(((s1_ptr)_2)->base + _mid_18063);
    Ref(_10099);
    _10100 = _38key_value(_10099);
    _10099 = NOVALUE;
    if (IS_ATOM_INT(_key_18059) && IS_ATOM_INT(_10100)){
        _c_18064 = (_key_18059 < _10100) ? -1 : (_key_18059 > _10100);
    }
    else{
        _c_18064 = compare(_key_18059, _10100);
    }
    DeRef(_10100);
    _10100 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18064 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18062 = _mid_18063 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18064 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18061 = _mid_18063 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_18059);
    DeRef(_table_name_18060);
    return _mid_18063;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_18064 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_18063 = _mid_18063 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_18063 == 0xC0000000)
    _10108 = (int)NewDouble((double)-0xC0000000);
    else
    _10108 = - _mid_18063;
    DeRef(_key_18059);
    DeRef(_table_name_18060);
    return _10108;
    ;
}
int db_find_key() __attribute__ ((alias ("_38db_find_key")));


int _38db_insert(int _key_18099, int _data_18100, int _table_name_18101)
{
    int _key_string_18102 = NOVALUE;
    int _data_string_18103 = NOVALUE;
    int _last_part_18104 = NOVALUE;
    int _remaining_18105 = NOVALUE;
    int _key_ptr_18106 = NOVALUE;
    int _data_ptr_18107 = NOVALUE;
    int _records_ptr_18108 = NOVALUE;
    int _nrecs_18109 = NOVALUE;
    int _current_block_18110 = NOVALUE;
    int _size_18111 = NOVALUE;
    int _new_size_18112 = NOVALUE;
    int _key_location_18113 = NOVALUE;
    int _new_block_18114 = NOVALUE;
    int _index_ptr_18115 = NOVALUE;
    int _new_index_ptr_18116 = NOVALUE;
    int _total_recs_18117 = NOVALUE;
    int _r_18118 = NOVALUE;
    int _blocks_18119 = NOVALUE;
    int _new_recs_18120 = NOVALUE;
    int _n_18121 = NOVALUE;
    int _put4_1__tmp_at79_18135 = NOVALUE;
    int _seek_1__tmp_at132_18141 = NOVALUE;
    int _seek_inlined_seek_at_132_18140 = NOVALUE;
    int _pos_inlined_seek_at_129_18139 = NOVALUE;
    int _seek_1__tmp_at174_18149 = NOVALUE;
    int _seek_inlined_seek_at_174_18148 = NOVALUE;
    int _pos_inlined_seek_at_171_18147 = NOVALUE;
    int _put4_1__tmp_at189_18151 = NOVALUE;
    int _seek_1__tmp_at317_18168 = NOVALUE;
    int _seek_inlined_seek_at_317_18167 = NOVALUE;
    int _pos_inlined_seek_at_314_18166 = NOVALUE;
    int _seek_1__tmp_at339_18172 = NOVALUE;
    int _seek_inlined_seek_at_339_18171 = NOVALUE;
    int _where_inlined_where_at_404_18181 = NOVALUE;
    int _seek_1__tmp_at448_18191 = NOVALUE;
    int _seek_inlined_seek_at_448_18190 = NOVALUE;
    int _pos_inlined_seek_at_445_18189 = NOVALUE;
    int _put4_1__tmp_at493_18200 = NOVALUE;
    int _x_inlined_put4_at_490_18199 = NOVALUE;
    int _seek_1__tmp_at530_18203 = NOVALUE;
    int _seek_inlined_seek_at_530_18202 = NOVALUE;
    int _put4_1__tmp_at551_18206 = NOVALUE;
    int _seek_1__tmp_at588_18211 = NOVALUE;
    int _seek_inlined_seek_at_588_18210 = NOVALUE;
    int _pos_inlined_seek_at_585_18209 = NOVALUE;
    int _seek_1__tmp_at690_18235 = NOVALUE;
    int _seek_inlined_seek_at_690_18234 = NOVALUE;
    int _pos_inlined_seek_at_687_18233 = NOVALUE;
    int _s_inlined_putn_at_751_18244 = NOVALUE;
    int _seek_1__tmp_at774_18247 = NOVALUE;
    int _seek_inlined_seek_at_774_18246 = NOVALUE;
    int _put4_1__tmp_at796_18251 = NOVALUE;
    int _x_inlined_put4_at_793_18250 = NOVALUE;
    int _seek_1__tmp_at833_18256 = NOVALUE;
    int _seek_inlined_seek_at_833_18255 = NOVALUE;
    int _pos_inlined_seek_at_830_18254 = NOVALUE;
    int _seek_1__tmp_at884_18266 = NOVALUE;
    int _seek_inlined_seek_at_884_18265 = NOVALUE;
    int _pos_inlined_seek_at_881_18264 = NOVALUE;
    int _put4_1__tmp_at899_18268 = NOVALUE;
    int _put4_1__tmp_at927_18270 = NOVALUE;
    int _seek_1__tmp_at980_18276 = NOVALUE;
    int _seek_inlined_seek_at_980_18275 = NOVALUE;
    int _pos_inlined_seek_at_977_18274 = NOVALUE;
    int _put4_1__tmp_at1001_18279 = NOVALUE;
    int _seek_1__tmp_at1038_18284 = NOVALUE;
    int _seek_inlined_seek_at_1038_18283 = NOVALUE;
    int _pos_inlined_seek_at_1035_18282 = NOVALUE;
    int _s_inlined_putn_at_1136_18302 = NOVALUE;
    int _seek_1__tmp_at1173_18307 = NOVALUE;
    int _seek_inlined_seek_at_1173_18306 = NOVALUE;
    int _pos_inlined_seek_at_1170_18305 = NOVALUE;
    int _put4_1__tmp_at1188_18309 = NOVALUE;
    int _10202 = NOVALUE;
    int _10201 = NOVALUE;
    int _10200 = NOVALUE;
    int _10199 = NOVALUE;
    int _10196 = NOVALUE;
    int _10195 = NOVALUE;
    int _10193 = NOVALUE;
    int _10191 = NOVALUE;
    int _10190 = NOVALUE;
    int _10188 = NOVALUE;
    int _10187 = NOVALUE;
    int _10185 = NOVALUE;
    int _10184 = NOVALUE;
    int _10182 = NOVALUE;
    int _10181 = NOVALUE;
    int _10180 = NOVALUE;
    int _10179 = NOVALUE;
    int _10178 = NOVALUE;
    int _10177 = NOVALUE;
    int _10176 = NOVALUE;
    int _10175 = NOVALUE;
    int _10174 = NOVALUE;
    int _10171 = NOVALUE;
    int _10170 = NOVALUE;
    int _10169 = NOVALUE;
    int _10168 = NOVALUE;
    int _10165 = NOVALUE;
    int _10162 = NOVALUE;
    int _10161 = NOVALUE;
    int _10160 = NOVALUE;
    int _10159 = NOVALUE;
    int _10156 = NOVALUE;
    int _10155 = NOVALUE;
    int _10153 = NOVALUE;
    int _10152 = NOVALUE;
    int _10150 = NOVALUE;
    int _10149 = NOVALUE;
    int _10148 = NOVALUE;
    int _10147 = NOVALUE;
    int _10146 = NOVALUE;
    int _10145 = NOVALUE;
    int _10144 = NOVALUE;
    int _10142 = NOVALUE;
    int _10139 = NOVALUE;
    int _10134 = NOVALUE;
    int _10133 = NOVALUE;
    int _10132 = NOVALUE;
    int _10130 = NOVALUE;
    int _10129 = NOVALUE;
    int _10128 = NOVALUE;
    int _10125 = NOVALUE;
    int _10123 = NOVALUE;
    int _10120 = NOVALUE;
    int _10119 = NOVALUE;
    int _10117 = NOVALUE;
    int _10116 = NOVALUE;
    int _10114 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_18099);
    Ref(_table_name_18101);
    _0 = _key_location_18113;
    _key_location_18113 = _38db_find_key(_key_18099, _table_name_18101);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_18113, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_18099);
    DeRef(_data_18100);
    DeRef(_table_name_18101);
    DeRef(_key_string_18102);
    DeRef(_data_string_18103);
    DeRef(_last_part_18104);
    DeRef(_remaining_18105);
    DeRef(_key_ptr_18106);
    DeRef(_data_ptr_18107);
    DeRef(_records_ptr_18108);
    DeRef(_nrecs_18109);
    DeRef(_current_block_18110);
    DeRef(_size_18111);
    DeRef(_new_size_18112);
    DeRef(_key_location_18113);
    DeRef(_new_block_18114);
    DeRef(_index_ptr_18115);
    DeRef(_new_index_ptr_18116);
    DeRef(_total_recs_18117);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_18113;
    if (IS_ATOM_INT(_key_location_18113)) {
        if ((unsigned long)_key_location_18113 == 0xC0000000)
        _key_location_18113 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_18113 = - _key_location_18113;
    }
    else {
        _key_location_18113 = unary_op(UMINUS, _key_location_18113);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    Ref(_data_18100);
    _0 = _data_string_18103;
    _data_string_18103 = _38compress(_data_18100);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_18099);
    _0 = _key_string_18102;
    _key_string_18102 = _38compress(_key_18099);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_18103)){
            _10114 = SEQ_PTR(_data_string_18103)->length;
    }
    else {
        _10114 = 1;
    }
    _0 = _data_ptr_18107;
    _data_ptr_18107 = _38db_allocate(_10114);
    DeRef(_0);
    _10114 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _data_string_18103); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_18102)){
            _10116 = SEQ_PTR(_key_string_18102)->length;
    }
    else {
        _10116 = 1;
    }
    _10117 = 4 + _10116;
    _10116 = NOVALUE;
    _0 = _key_ptr_18106;
    _key_ptr_18106 = _38db_allocate(_10117);
    DeRef(_0);
    _10117 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18107)) {
        *poke4_addr = (unsigned long)_data_ptr_18107;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18107)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_18135);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_18135 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at79_18135); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_18135);
    _put4_1__tmp_at79_18135 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _key_string_18102); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10119 = _38current_table_pos_16419 + 4;
        if ((long)((unsigned long)_10119 + (unsigned long)HIGH_BITS) >= 0) 
        _10119 = NewDouble((double)_10119);
    }
    else {
        _10119 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_18139);
    _pos_inlined_seek_at_129_18139 = _10119;
    _10119 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_18139);
    DeRef(_seek_1__tmp_at132_18141);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_18139;
    _seek_1__tmp_at132_18141 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_18140 = machine(19, _seek_1__tmp_at132_18141);
    DeRef(_pos_inlined_seek_at_129_18139);
    _pos_inlined_seek_at_129_18139 = NOVALUE;
    DeRef(_seek_1__tmp_at132_18141);
    _seek_1__tmp_at132_18141 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10120 = _38get4();
    DeRef(_total_recs_18117);
    if (IS_ATOM_INT(_10120)) {
        _total_recs_18117 = _10120 + 1;
        if (_total_recs_18117 > MAXINT){
            _total_recs_18117 = NewDouble((double)_total_recs_18117);
        }
    }
    else
    _total_recs_18117 = binary_op(PLUS, 1, _10120);
    DeRef(_10120);
    _10120 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18119 = _38get4();
    if (!IS_ATOM_INT(_blocks_18119)) {
        _1 = (long)(DBL_PTR(_blocks_18119)->dbl);
        DeRefDS(_blocks_18119);
        _blocks_18119 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10123 = _38current_table_pos_16419 + 4;
        if ((long)((unsigned long)_10123 + (unsigned long)HIGH_BITS) >= 0) 
        _10123 = NewDouble((double)_10123);
    }
    else {
        _10123 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_18147);
    _pos_inlined_seek_at_171_18147 = _10123;
    _10123 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_18147);
    DeRef(_seek_1__tmp_at174_18149);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_18147;
    _seek_1__tmp_at174_18149 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_18148 = machine(19, _seek_1__tmp_at174_18149);
    DeRef(_pos_inlined_seek_at_171_18147);
    _pos_inlined_seek_at_171_18147 = NOVALUE;
    DeRef(_seek_1__tmp_at174_18149);
    _seek_1__tmp_at174_18149 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_18117)) {
        *poke4_addr = (unsigned long)_total_recs_18117;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_18117)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_18151);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_18151 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at189_18151); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_18151);
    _put4_1__tmp_at189_18151 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _n_18121 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _n_18121 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10125 = _n_18121 >> 1;
    if (binary_op_a(LESS, _key_location_18113, _10125)){
        _10125 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10125);
    _10125 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_38key_pointers_16425, _38key_pointers_16425, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_18113)) {
        _10128 = _key_location_18113 + 1;
        if (_10128 > MAXINT){
            _10128 = NewDouble((double)_10128);
        }
    }
    else
    _10128 = binary_op(PLUS, 1, _key_location_18113);
    _10129 = _n_18121 + 1;
    rhs_slice_target = (object_ptr)&_10130;
    RHS_Slice(_38key_pointers_16425, _key_location_18113, _n_18121);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16425;
    AssignSlice(_10128, _10129, _10130);
    DeRef(_10128);
    _10128 = NOVALUE;
    _10129 = NOVALUE;
    DeRefDS(_10130);
    _10130 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_38key_pointers_16425, _38key_pointers_16425, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_18113)) {
        _10132 = _key_location_18113 - 1;
        if ((long)((unsigned long)_10132 +(unsigned long) HIGH_BITS) >= 0){
            _10132 = NewDouble((double)_10132);
        }
    }
    else {
        _10132 = NewDouble(DBL_PTR(_key_location_18113)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10133;
    RHS_Slice(_38key_pointers_16425, 2, _key_location_18113);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16425;
    AssignSlice(1, _10132, _10133);
    DeRef(_10132);
    _10132 = NOVALUE;
    DeRefDS(_10133);
    _10133 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_18106);
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38key_pointers_16425 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_18113))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_18113)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_18113);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_18106;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10134 = _38current_table_pos_16419 + 12;
        if ((long)((unsigned long)_10134 + (unsigned long)HIGH_BITS) >= 0) 
        _10134 = NewDouble((double)_10134);
    }
    else {
        _10134 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_18166);
    _pos_inlined_seek_at_314_18166 = _10134;
    _10134 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_18166);
    DeRef(_seek_1__tmp_at317_18168);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_18166;
    _seek_1__tmp_at317_18168 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_18167 = machine(19, _seek_1__tmp_at317_18168);
    DeRef(_pos_inlined_seek_at_314_18166);
    _pos_inlined_seek_at_314_18166 = NOVALUE;
    DeRef(_seek_1__tmp_at317_18168);
    _seek_1__tmp_at317_18168 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18115;
    _index_ptr_18115 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18115);
    DeRef(_seek_1__tmp_at339_18172);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _index_ptr_18115;
    _seek_1__tmp_at339_18172 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_18171 = machine(19, _seek_1__tmp_at339_18172);
    DeRef(_seek_1__tmp_at339_18172);
    _seek_1__tmp_at339_18172 = NOVALUE;

    /** 	r = 0*/
    _r_18118 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18109;
    _nrecs_18109 = _38get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18108;
    _records_ptr_18108 = _38get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _r_18118 = _r_18118 + _nrecs_18109;
    }
    else {
        _r_18118 = NewDouble((double)_r_18118 + DBL_PTR(_nrecs_18109)->dbl);
    }
    if (!IS_ATOM_INT(_r_18118)) {
        _1 = (long)(DBL_PTR(_r_18118)->dbl);
        DeRefDS(_r_18118);
        _r_18118 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10139 = _r_18118 + 1;
    if (_10139 > MAXINT){
        _10139 = NewDouble((double)_10139);
    }
    if (binary_op_a(LESS, _10139, _key_location_18113)){
        DeRef(_10139);
        _10139 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10139);
    _10139 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_18181);
    _where_inlined_where_at_404_18181 = machine(20, _38current_db_16418);
    DeRef(_current_block_18110);
    if (IS_ATOM_INT(_where_inlined_where_at_404_18181)) {
        _current_block_18110 = _where_inlined_where_at_404_18181 - 8;
        if ((long)((unsigned long)_current_block_18110 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18110 = NewDouble((double)_current_block_18110);
        }
    }
    else {
        _current_block_18110 = NewDouble(DBL_PTR(_where_inlined_where_at_404_18181)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _10142 = _r_18118 - _nrecs_18109;
        if ((long)((unsigned long)_10142 +(unsigned long) HIGH_BITS) >= 0){
            _10142 = NewDouble((double)_10142);
        }
    }
    else {
        _10142 = NewDouble((double)_r_18118 - DBL_PTR(_nrecs_18109)->dbl);
    }
    _0 = _key_location_18113;
    if (IS_ATOM_INT(_key_location_18113) && IS_ATOM_INT(_10142)) {
        _key_location_18113 = _key_location_18113 - _10142;
        if ((long)((unsigned long)_key_location_18113 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_18113 = NewDouble((double)_key_location_18113);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_18113)) {
            _key_location_18113 = NewDouble((double)_key_location_18113 - DBL_PTR(_10142)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10142)) {
                _key_location_18113 = NewDouble(DBL_PTR(_key_location_18113)->dbl - (double)_10142);
            }
            else
            _key_location_18113 = NewDouble(DBL_PTR(_key_location_18113)->dbl - DBL_PTR(_10142)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10142);
    _10142 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_18113)) {
        _10144 = _key_location_18113 - 1;
        if ((long)((unsigned long)_10144 +(unsigned long) HIGH_BITS) >= 0){
            _10144 = NewDouble((double)_10144);
        }
    }
    else {
        _10144 = NewDouble(DBL_PTR(_key_location_18113)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10144)) {
        if (_10144 <= INT15 && _10144 >= -INT15)
        _10145 = 4 * _10144;
        else
        _10145 = NewDouble(4 * (double)_10144);
    }
    else {
        _10145 = NewDouble((double)4 * DBL_PTR(_10144)->dbl);
    }
    DeRef(_10144);
    _10144 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18108) && IS_ATOM_INT(_10145)) {
        _10146 = _records_ptr_18108 + _10145;
        if ((long)((unsigned long)_10146 + (unsigned long)HIGH_BITS) >= 0) 
        _10146 = NewDouble((double)_10146);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18108)) {
            _10146 = NewDouble((double)_records_ptr_18108 + DBL_PTR(_10145)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10145)) {
                _10146 = NewDouble(DBL_PTR(_records_ptr_18108)->dbl + (double)_10145);
            }
            else
            _10146 = NewDouble(DBL_PTR(_records_ptr_18108)->dbl + DBL_PTR(_10145)->dbl);
        }
    }
    DeRef(_10145);
    _10145 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_18189);
    _pos_inlined_seek_at_445_18189 = _10146;
    _10146 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_18189);
    DeRef(_seek_1__tmp_at448_18191);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_18189;
    _seek_1__tmp_at448_18191 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_18190 = machine(19, _seek_1__tmp_at448_18191);
    DeRef(_pos_inlined_seek_at_445_18189);
    _pos_inlined_seek_at_445_18189 = NOVALUE;
    DeRef(_seek_1__tmp_at448_18191);
    _seek_1__tmp_at448_18191 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _10147 = _nrecs_18109 + 1;
        if (_10147 > MAXINT){
            _10147 = NewDouble((double)_10147);
        }
    }
    else
    _10147 = binary_op(PLUS, 1, _nrecs_18109);
    {
        int _i_18193;
        Ref(_key_location_18113);
        _i_18193 = _key_location_18113;
LA: 
        if (binary_op_a(GREATER, _i_18193, _10147)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_18193)) {
            _10148 = _i_18193 + _r_18118;
            if ((long)((unsigned long)_10148 + (unsigned long)HIGH_BITS) >= 0) 
            _10148 = NewDouble((double)_10148);
        }
        else {
            _10148 = NewDouble(DBL_PTR(_i_18193)->dbl + (double)_r_18118);
        }
        if (IS_ATOM_INT(_10148) && IS_ATOM_INT(_nrecs_18109)) {
            _10149 = _10148 - _nrecs_18109;
        }
        else {
            if (IS_ATOM_INT(_10148)) {
                _10149 = NewDouble((double)_10148 - DBL_PTR(_nrecs_18109)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_18109)) {
                    _10149 = NewDouble(DBL_PTR(_10148)->dbl - (double)_nrecs_18109);
                }
                else
                _10149 = NewDouble(DBL_PTR(_10148)->dbl - DBL_PTR(_nrecs_18109)->dbl);
            }
        }
        DeRef(_10148);
        _10148 = NOVALUE;
        _2 = (int)SEQ_PTR(_38key_pointers_16425);
        if (!IS_ATOM_INT(_10149)){
            _10150 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10149)->dbl));
        }
        else{
            _10150 = (int)*(((s1_ptr)_2)->base + _10149);
        }
        Ref(_10150);
        DeRef(_x_inlined_put4_at_490_18199);
        _x_inlined_put4_at_490_18199 = _10150;
        _10150 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_18199)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_18199;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_18199)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_18199)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_18199);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_18200);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_18200 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at493_18200); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_18199);
        _x_inlined_put4_at_490_18199 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_18200);
        _put4_1__tmp_at493_18200 = NOVALUE;

        /** 	end for*/
        _0 = _i_18193;
        if (IS_ATOM_INT(_i_18193)) {
            _i_18193 = _i_18193 + 1;
            if ((long)((unsigned long)_i_18193 +(unsigned long) HIGH_BITS) >= 0){
                _i_18193 = NewDouble((double)_i_18193);
            }
        }
        else {
            _i_18193 = binary_op_a(PLUS, _i_18193, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_18193);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18110);
    DeRef(_seek_1__tmp_at530_18203);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _current_block_18110;
    _seek_1__tmp_at530_18203 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_18202 = machine(19, _seek_1__tmp_at530_18203);
    DeRef(_seek_1__tmp_at530_18203);
    _seek_1__tmp_at530_18203 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_18109;
    if (IS_ATOM_INT(_nrecs_18109)) {
        _nrecs_18109 = _nrecs_18109 + 1;
        if (_nrecs_18109 > MAXINT){
            _nrecs_18109 = NewDouble((double)_nrecs_18109);
        }
    }
    else
    _nrecs_18109 = binary_op(PLUS, 1, _nrecs_18109);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18109)) {
        *poke4_addr = (unsigned long)_nrecs_18109;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18109)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_18206);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_18206 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at551_18206); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_18206);
    _put4_1__tmp_at551_18206 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_18108)) {
        _10152 = _records_ptr_18108 - 4;
        if ((long)((unsigned long)_10152 +(unsigned long) HIGH_BITS) >= 0){
            _10152 = NewDouble((double)_10152);
        }
    }
    else {
        _10152 = NewDouble(DBL_PTR(_records_ptr_18108)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_18209);
    _pos_inlined_seek_at_585_18209 = _10152;
    _10152 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_18209);
    DeRef(_seek_1__tmp_at588_18211);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_18209;
    _seek_1__tmp_at588_18211 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_18210 = machine(19, _seek_1__tmp_at588_18211);
    DeRef(_pos_inlined_seek_at_585_18209);
    _pos_inlined_seek_at_585_18209 = NOVALUE;
    DeRef(_seek_1__tmp_at588_18211);
    _seek_1__tmp_at588_18211 = NOVALUE;

    /** 	size = get4() - 4*/
    _10153 = _38get4();
    DeRef(_size_18111);
    if (IS_ATOM_INT(_10153)) {
        _size_18111 = _10153 - 4;
        if ((long)((unsigned long)_size_18111 +(unsigned long) HIGH_BITS) >= 0){
            _size_18111 = NewDouble((double)_size_18111);
        }
    }
    else {
        _size_18111 = binary_op(MINUS, _10153, 4);
    }
    DeRef(_10153);
    _10153 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        if (_nrecs_18109 == (short)_nrecs_18109)
        _10155 = _nrecs_18109 * 4;
        else
        _10155 = NewDouble(_nrecs_18109 * (double)4);
    }
    else {
        _10155 = NewDouble(DBL_PTR(_nrecs_18109)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_18111)) {
        _10156 = _size_18111 - 4;
        if ((long)((unsigned long)_10156 +(unsigned long) HIGH_BITS) >= 0){
            _10156 = NewDouble((double)_10156);
        }
    }
    else {
        _10156 = NewDouble(DBL_PTR(_size_18111)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10155, _10156)){
        DeRef(_10155);
        _10155 = NOVALUE;
        DeRef(_10156);
        _10156 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10155);
    _10155 = NOVALUE;
    DeRef(_10156);
    _10156 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_18117)) {
        _10159 = NewDouble(DBL_PTR(_10158)->dbl * (double)_total_recs_18117);
    }
    else
    _10159 = NewDouble(DBL_PTR(_10158)->dbl * DBL_PTR(_total_recs_18117)->dbl);
    _10160 = unary_op(SQRT, _10159);
    DeRefDS(_10159);
    _10159 = NOVALUE;
    _10161 = unary_op(FLOOR, _10160);
    DeRefDS(_10160);
    _10160 = NOVALUE;
    if (IS_ATOM_INT(_10161)) {
        _10162 = 20 + _10161;
        if ((long)((unsigned long)_10162 + (unsigned long)HIGH_BITS) >= 0) 
        _10162 = NewDouble((double)_10162);
    }
    else {
        _10162 = NewDouble((double)20 + DBL_PTR(_10161)->dbl);
    }
    DeRef(_10161);
    _10161 = NOVALUE;
    DeRef(_new_size_18112);
    if (IS_ATOM_INT(_10162)) {
        if (_10162 <= INT15 && _10162 >= -INT15)
        _new_size_18112 = 8 * _10162;
        else
        _new_size_18112 = NewDouble(8 * (double)_10162);
    }
    else {
        _new_size_18112 = NewDouble((double)8 * DBL_PTR(_10162)->dbl);
    }
    DeRef(_10162);
    _10162 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_18112)) {
        if (8 > 0 && _new_size_18112 >= 0) {
            _new_recs_18120 = _new_size_18112 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_18112 / (double)8);
            _new_recs_18120 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_18112, 8);
        _new_recs_18120 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_18120)) {
        _1 = (long)(DBL_PTR(_new_recs_18120)->dbl);
        DeRefDS(_new_recs_18120);
        _new_recs_18120 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _10165 = _nrecs_18109 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18109, 2);
        _10165 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_18120, _10165)){
        DeRef(_10165);
        _10165 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10165);
    _10165 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _new_recs_18120 = _nrecs_18109 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18109, 2);
        _new_recs_18120 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_18120)) {
        _1 = (long)(DBL_PTR(_new_recs_18120)->dbl);
        DeRefDS(_new_recs_18120);
        _new_recs_18120 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _10168 = _nrecs_18109 - _new_recs_18120;
        if ((long)((unsigned long)_10168 +(unsigned long) HIGH_BITS) >= 0){
            _10168 = NewDouble((double)_10168);
        }
    }
    else {
        _10168 = NewDouble(DBL_PTR(_nrecs_18109)->dbl - (double)_new_recs_18120);
    }
    if (IS_ATOM_INT(_10168)) {
        if (_10168 == (short)_10168)
        _10169 = _10168 * 4;
        else
        _10169 = NewDouble(_10168 * (double)4);
    }
    else {
        _10169 = NewDouble(DBL_PTR(_10168)->dbl * (double)4);
    }
    DeRef(_10168);
    _10168 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18108) && IS_ATOM_INT(_10169)) {
        _10170 = _records_ptr_18108 + _10169;
        if ((long)((unsigned long)_10170 + (unsigned long)HIGH_BITS) >= 0) 
        _10170 = NewDouble((double)_10170);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18108)) {
            _10170 = NewDouble((double)_records_ptr_18108 + DBL_PTR(_10169)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10169)) {
                _10170 = NewDouble(DBL_PTR(_records_ptr_18108)->dbl + (double)_10169);
            }
            else
            _10170 = NewDouble(DBL_PTR(_records_ptr_18108)->dbl + DBL_PTR(_10169)->dbl);
        }
    }
    DeRef(_10169);
    _10169 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_18233);
    _pos_inlined_seek_at_687_18233 = _10170;
    _10170 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_18233);
    DeRef(_seek_1__tmp_at690_18235);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_18233;
    _seek_1__tmp_at690_18235 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_18234 = machine(19, _seek_1__tmp_at690_18235);
    DeRef(_pos_inlined_seek_at_687_18233);
    _pos_inlined_seek_at_687_18233 = NOVALUE;
    DeRef(_seek_1__tmp_at690_18235);
    _seek_1__tmp_at690_18235 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_18120 == (short)_new_recs_18120)
    _10171 = _new_recs_18120 * 4;
    else
    _10171 = NewDouble(_new_recs_18120 * (double)4);
    _0 = _last_part_18104;
    _last_part_18104 = _18get_bytes(_38current_db_16418, _10171);
    DeRef(_0);
    _10171 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_18112);
    _0 = _new_block_18114;
    _new_block_18114 = _38db_allocate(_new_size_18112);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _last_part_18104); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_18104)){
            _10174 = SEQ_PTR(_last_part_18104)->length;
    }
    else {
        _10174 = 1;
    }
    if (IS_ATOM_INT(_new_size_18112)) {
        _10175 = _new_size_18112 - _10174;
    }
    else {
        _10175 = NewDouble(DBL_PTR(_new_size_18112)->dbl - (double)_10174);
    }
    _10174 = NOVALUE;
    _10176 = Repeat(0, _10175);
    DeRef(_10175);
    _10175 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_18244);
    _s_inlined_putn_at_751_18244 = _10176;
    _10176 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_751_18244); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_18244);
    _s_inlined_putn_at_751_18244 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18110);
    DeRef(_seek_1__tmp_at774_18247);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _current_block_18110;
    _seek_1__tmp_at774_18247 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_18246 = machine(19, _seek_1__tmp_at774_18247);
    DeRef(_seek_1__tmp_at774_18247);
    _seek_1__tmp_at774_18247 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_18109)) {
        _10177 = _nrecs_18109 - _new_recs_18120;
        if ((long)((unsigned long)_10177 +(unsigned long) HIGH_BITS) >= 0){
            _10177 = NewDouble((double)_10177);
        }
    }
    else {
        _10177 = NewDouble(DBL_PTR(_nrecs_18109)->dbl - (double)_new_recs_18120);
    }
    DeRef(_x_inlined_put4_at_793_18250);
    _x_inlined_put4_at_793_18250 = _10177;
    _10177 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_18250)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_18250;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_18250)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_18251);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_18251 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at796_18251); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_18250);
    _x_inlined_put4_at_793_18250 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_18251);
    _put4_1__tmp_at796_18251 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18110)) {
        _10178 = _current_block_18110 + 8;
        if ((long)((unsigned long)_10178 + (unsigned long)HIGH_BITS) >= 0) 
        _10178 = NewDouble((double)_10178);
    }
    else {
        _10178 = NewDouble(DBL_PTR(_current_block_18110)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_18254);
    _pos_inlined_seek_at_830_18254 = _10178;
    _10178 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_18254);
    DeRef(_seek_1__tmp_at833_18256);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_18254;
    _seek_1__tmp_at833_18256 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_18255 = machine(19, _seek_1__tmp_at833_18256);
    DeRef(_pos_inlined_seek_at_830_18254);
    _pos_inlined_seek_at_830_18254 = NOVALUE;
    DeRef(_seek_1__tmp_at833_18256);
    _seek_1__tmp_at833_18256 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18119 == (short)_blocks_18119)
    _10179 = _blocks_18119 * 8;
    else
    _10179 = NewDouble(_blocks_18119 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18115) && IS_ATOM_INT(_10179)) {
        _10180 = _index_ptr_18115 + _10179;
        if ((long)((unsigned long)_10180 + (unsigned long)HIGH_BITS) >= 0) 
        _10180 = NewDouble((double)_10180);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18115)) {
            _10180 = NewDouble((double)_index_ptr_18115 + DBL_PTR(_10179)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10179)) {
                _10180 = NewDouble(DBL_PTR(_index_ptr_18115)->dbl + (double)_10179);
            }
            else
            _10180 = NewDouble(DBL_PTR(_index_ptr_18115)->dbl + DBL_PTR(_10179)->dbl);
        }
    }
    DeRef(_10179);
    _10179 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18110)) {
        _10181 = _current_block_18110 + 8;
        if ((long)((unsigned long)_10181 + (unsigned long)HIGH_BITS) >= 0) 
        _10181 = NewDouble((double)_10181);
    }
    else {
        _10181 = NewDouble(DBL_PTR(_current_block_18110)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10180) && IS_ATOM_INT(_10181)) {
        _10182 = _10180 - _10181;
        if ((long)((unsigned long)_10182 +(unsigned long) HIGH_BITS) >= 0){
            _10182 = NewDouble((double)_10182);
        }
    }
    else {
        if (IS_ATOM_INT(_10180)) {
            _10182 = NewDouble((double)_10180 - DBL_PTR(_10181)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10181)) {
                _10182 = NewDouble(DBL_PTR(_10180)->dbl - (double)_10181);
            }
            else
            _10182 = NewDouble(DBL_PTR(_10180)->dbl - DBL_PTR(_10181)->dbl);
        }
    }
    DeRef(_10180);
    _10180 = NOVALUE;
    DeRef(_10181);
    _10181 = NOVALUE;
    _0 = _remaining_18105;
    _remaining_18105 = _18get_bytes(_38current_db_16418, _10182);
    DeRef(_0);
    _10182 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18110)) {
        _10184 = _current_block_18110 + 8;
        if ((long)((unsigned long)_10184 + (unsigned long)HIGH_BITS) >= 0) 
        _10184 = NewDouble((double)_10184);
    }
    else {
        _10184 = NewDouble(DBL_PTR(_current_block_18110)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_18264);
    _pos_inlined_seek_at_881_18264 = _10184;
    _10184 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_18264);
    DeRef(_seek_1__tmp_at884_18266);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_18264;
    _seek_1__tmp_at884_18266 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_18265 = machine(19, _seek_1__tmp_at884_18266);
    DeRef(_pos_inlined_seek_at_881_18264);
    _pos_inlined_seek_at_881_18264 = NOVALUE;
    DeRef(_seek_1__tmp_at884_18266);
    _seek_1__tmp_at884_18266 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_18120;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_18268);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_18268 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at899_18268); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_18268);
    _put4_1__tmp_at899_18268 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_new_block_18114)) {
        *poke4_addr = (unsigned long)_new_block_18114;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_18114)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_18270);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_18270 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at927_18270); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_18270);
    _put4_1__tmp_at927_18270 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_18105); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10185 = _38current_table_pos_16419 + 8;
        if ((long)((unsigned long)_10185 + (unsigned long)HIGH_BITS) >= 0) 
        _10185 = NewDouble((double)_10185);
    }
    else {
        _10185 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_18274);
    _pos_inlined_seek_at_977_18274 = _10185;
    _10185 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_18274);
    DeRef(_seek_1__tmp_at980_18276);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_18274;
    _seek_1__tmp_at980_18276 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_18275 = machine(19, _seek_1__tmp_at980_18276);
    DeRef(_pos_inlined_seek_at_977_18274);
    _pos_inlined_seek_at_977_18274 = NOVALUE;
    DeRef(_seek_1__tmp_at980_18276);
    _seek_1__tmp_at980_18276 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_18119 = _blocks_18119 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_18119;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_18279);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_18279 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at1001_18279); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_18279);
    _put4_1__tmp_at1001_18279 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_18115)) {
        _10187 = _index_ptr_18115 - 4;
        if ((long)((unsigned long)_10187 +(unsigned long) HIGH_BITS) >= 0){
            _10187 = NewDouble((double)_10187);
        }
    }
    else {
        _10187 = NewDouble(DBL_PTR(_index_ptr_18115)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_18282);
    _pos_inlined_seek_at_1035_18282 = _10187;
    _10187 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_18282);
    DeRef(_seek_1__tmp_at1038_18284);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_18282;
    _seek_1__tmp_at1038_18284 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_18283 = machine(19, _seek_1__tmp_at1038_18284);
    DeRef(_pos_inlined_seek_at_1035_18282);
    _pos_inlined_seek_at_1035_18282 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_18284);
    _seek_1__tmp_at1038_18284 = NOVALUE;

    /** 		size = get4() - 4*/
    _10188 = _38get4();
    DeRef(_size_18111);
    if (IS_ATOM_INT(_10188)) {
        _size_18111 = _10188 - 4;
        if ((long)((unsigned long)_size_18111 +(unsigned long) HIGH_BITS) >= 0){
            _size_18111 = NewDouble((double)_size_18111);
        }
    }
    else {
        _size_18111 = binary_op(MINUS, _10188, 4);
    }
    DeRef(_10188);
    _10188 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_18119 == (short)_blocks_18119)
    _10190 = _blocks_18119 * 8;
    else
    _10190 = NewDouble(_blocks_18119 * (double)8);
    if (IS_ATOM_INT(_size_18111)) {
        _10191 = _size_18111 - 8;
        if ((long)((unsigned long)_10191 +(unsigned long) HIGH_BITS) >= 0){
            _10191 = NewDouble((double)_10191);
        }
    }
    else {
        _10191 = NewDouble(DBL_PTR(_size_18111)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10190, _10191)){
        DeRef(_10190);
        _10190 = NOVALUE;
        DeRef(_10191);
        _10191 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10190);
    _10190 = NOVALUE;
    DeRef(_10191);
    _10191 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_18119 == (short)_blocks_18119)
    _10193 = _blocks_18119 * 8;
    else
    _10193 = NewDouble(_blocks_18119 * (double)8);
    _0 = _remaining_18105;
    _remaining_18105 = _18get_bytes(_38current_db_16418, _10193);
    DeRef(_0);
    _10193 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_18111)) {
        if (_size_18111 & 1) {
            _10195 = NewDouble((_size_18111 >> 1) + 0.5);
        }
        else
        _10195 = _size_18111 >> 1;
    }
    else {
        _10195 = binary_op(DIVIDE, _size_18111, 2);
    }
    if (IS_ATOM_INT(_size_18111) && IS_ATOM_INT(_10195)) {
        _10196 = _size_18111 + _10195;
        if ((long)((unsigned long)_10196 + (unsigned long)HIGH_BITS) >= 0) 
        _10196 = NewDouble((double)_10196);
    }
    else {
        if (IS_ATOM_INT(_size_18111)) {
            _10196 = NewDouble((double)_size_18111 + DBL_PTR(_10195)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10195)) {
                _10196 = NewDouble(DBL_PTR(_size_18111)->dbl + (double)_10195);
            }
            else
            _10196 = NewDouble(DBL_PTR(_size_18111)->dbl + DBL_PTR(_10195)->dbl);
        }
    }
    DeRef(_10195);
    _10195 = NOVALUE;
    DeRef(_new_size_18112);
    if (IS_ATOM_INT(_10196))
    _new_size_18112 = e_floor(_10196);
    else
    _new_size_18112 = unary_op(FLOOR, _10196);
    DeRef(_10196);
    _10196 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_18112);
    _0 = _new_index_ptr_18116;
    _new_index_ptr_18116 = _38db_allocate(_new_size_18112);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_18105); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_18119 == (short)_blocks_18119)
    _10199 = _blocks_18119 * 8;
    else
    _10199 = NewDouble(_blocks_18119 * (double)8);
    if (IS_ATOM_INT(_new_size_18112) && IS_ATOM_INT(_10199)) {
        _10200 = _new_size_18112 - _10199;
    }
    else {
        if (IS_ATOM_INT(_new_size_18112)) {
            _10200 = NewDouble((double)_new_size_18112 - DBL_PTR(_10199)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10199)) {
                _10200 = NewDouble(DBL_PTR(_new_size_18112)->dbl - (double)_10199);
            }
            else
            _10200 = NewDouble(DBL_PTR(_new_size_18112)->dbl - DBL_PTR(_10199)->dbl);
        }
    }
    DeRef(_10199);
    _10199 = NOVALUE;
    _10201 = Repeat(0, _10200);
    DeRef(_10200);
    _10200 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_18302);
    _s_inlined_putn_at_1136_18302 = _10201;
    _10201 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _s_inlined_putn_at_1136_18302); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_18302);
    _s_inlined_putn_at_1136_18302 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_18115);
    _38db_free(_index_ptr_18115);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10202 = _38current_table_pos_16419 + 12;
        if ((long)((unsigned long)_10202 + (unsigned long)HIGH_BITS) >= 0) 
        _10202 = NewDouble((double)_10202);
    }
    else {
        _10202 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_18305);
    _pos_inlined_seek_at_1170_18305 = _10202;
    _10202 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_18305);
    DeRef(_seek_1__tmp_at1173_18307);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_18305;
    _seek_1__tmp_at1173_18307 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_18306 = machine(19, _seek_1__tmp_at1173_18307);
    DeRef(_pos_inlined_seek_at_1170_18305);
    _pos_inlined_seek_at_1170_18305 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_18307);
    _seek_1__tmp_at1173_18307 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_18116)) {
        *poke4_addr = (unsigned long)_new_index_ptr_18116;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_18116)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_18309);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_18309 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at1188_18309); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_18309);
    _put4_1__tmp_at1188_18309 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_18099);
    DeRef(_data_18100);
    DeRef(_table_name_18101);
    DeRef(_key_string_18102);
    DeRef(_data_string_18103);
    DeRef(_last_part_18104);
    DeRef(_remaining_18105);
    DeRef(_key_ptr_18106);
    DeRef(_data_ptr_18107);
    DeRef(_records_ptr_18108);
    DeRef(_nrecs_18109);
    DeRef(_current_block_18110);
    DeRef(_size_18111);
    DeRef(_new_size_18112);
    DeRef(_key_location_18113);
    DeRef(_new_block_18114);
    DeRef(_index_ptr_18115);
    DeRef(_new_index_ptr_18116);
    DeRef(_total_recs_18117);
    DeRef(_10147);
    _10147 = NOVALUE;
    DeRef(_10149);
    _10149 = NOVALUE;
    return 0;
    ;
}
int db_insert() __attribute__ ((alias ("_38db_insert")));


void _38db_delete_record(int _key_location_18312, int _table_name_18313)
{
    int _key_ptr_18314 = NOVALUE;
    int _nrecs_18315 = NOVALUE;
    int _records_ptr_18316 = NOVALUE;
    int _data_ptr_18317 = NOVALUE;
    int _index_ptr_18318 = NOVALUE;
    int _current_block_18319 = NOVALUE;
    int _r_18320 = NOVALUE;
    int _blocks_18321 = NOVALUE;
    int _n_18322 = NOVALUE;
    int _remaining_18323 = NOVALUE;
    int _seek_1__tmp_at122_18345 = NOVALUE;
    int _seek_inlined_seek_at_122_18344 = NOVALUE;
    int _seek_1__tmp_at265_18367 = NOVALUE;
    int _seek_inlined_seek_at_265_18366 = NOVALUE;
    int _pos_inlined_seek_at_262_18365 = NOVALUE;
    int _seek_1__tmp_at307_18375 = NOVALUE;
    int _seek_inlined_seek_at_307_18374 = NOVALUE;
    int _pos_inlined_seek_at_304_18373 = NOVALUE;
    int _put4_1__tmp_at322_18377 = NOVALUE;
    int _seek_1__tmp_at361_18382 = NOVALUE;
    int _seek_inlined_seek_at_361_18381 = NOVALUE;
    int _pos_inlined_seek_at_358_18380 = NOVALUE;
    int _seek_1__tmp_at383_18386 = NOVALUE;
    int _seek_inlined_seek_at_383_18385 = NOVALUE;
    int _where_inlined_where_at_452_18395 = NOVALUE;
    int _seek_1__tmp_at518_18409 = NOVALUE;
    int _seek_inlined_seek_at_518_18408 = NOVALUE;
    int _seek_1__tmp_at558_18415 = NOVALUE;
    int _seek_inlined_seek_at_558_18414 = NOVALUE;
    int _pos_inlined_seek_at_555_18413 = NOVALUE;
    int _put4_1__tmp_at580_18419 = NOVALUE;
    int _x_inlined_put4_at_577_18418 = NOVALUE;
    int _seek_1__tmp_at626_18424 = NOVALUE;
    int _seek_inlined_seek_at_626_18423 = NOVALUE;
    int _put4_1__tmp_at641_18426 = NOVALUE;
    int _seek_1__tmp_at688_18433 = NOVALUE;
    int _seek_inlined_seek_at_688_18432 = NOVALUE;
    int _pos_inlined_seek_at_685_18431 = NOVALUE;
    int _put4_1__tmp_at728_18441 = NOVALUE;
    int _x_inlined_put4_at_725_18440 = NOVALUE;
    int _10262 = NOVALUE;
    int _10261 = NOVALUE;
    int _10260 = NOVALUE;
    int _10259 = NOVALUE;
    int _10258 = NOVALUE;
    int _10257 = NOVALUE;
    int _10255 = NOVALUE;
    int _10254 = NOVALUE;
    int _10252 = NOVALUE;
    int _10251 = NOVALUE;
    int _10250 = NOVALUE;
    int _10249 = NOVALUE;
    int _10248 = NOVALUE;
    int _10247 = NOVALUE;
    int _10246 = NOVALUE;
    int _10237 = NOVALUE;
    int _10236 = NOVALUE;
    int _10233 = NOVALUE;
    int _10232 = NOVALUE;
    int _10230 = NOVALUE;
    int _10229 = NOVALUE;
    int _10227 = NOVALUE;
    int _10226 = NOVALUE;
    int _10225 = NOVALUE;
    int _10224 = NOVALUE;
    int _10222 = NOVALUE;
    int _10218 = NOVALUE;
    int _10216 = NOVALUE;
    int _10214 = NOVALUE;
    int _10213 = NOVALUE;
    int _10211 = NOVALUE;
    int _10210 = NOVALUE;
    int _10208 = NOVALUE;
    int _10205 = NOVALUE;
    int _10203 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18312)) {
        _1 = (long)(DBL_PTR(_key_location_18312)->dbl);
        DeRefDS(_key_location_18312);
        _key_location_18312 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18313 == _38current_table_name_16420)
    _10203 = 1;
    else if (IS_ATOM_INT(_table_name_18313) && IS_ATOM_INT(_38current_table_name_16420))
    _10203 = 0;
    else
    _10203 = (compare(_table_name_18313, _38current_table_name_16420) == 0);
    if (_10203 != 0)
    goto L1; // [11] 43
    _10203 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18313);
    _10205 = _38db_select_table(_table_name_18313);
    if (binary_op_a(EQUALS, _10205, 0)){
        DeRef(_10205);
        _10205 = NOVALUE;
        goto L2; // [20] 42
    }
    DeRef(_10205);
    _10205 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18313);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18312;
    ((int *)_2)[2] = _table_name_18313;
    _10208 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10207);
    _38fatal(903, _10089, _10207, _10208);
    _10208 = NOVALUE;

    /** 			return*/
    DeRef(_table_name_18313);
    DeRef(_key_ptr_18314);
    DeRef(_nrecs_18315);
    DeRef(_records_ptr_18316);
    DeRef(_data_ptr_18317);
    DeRef(_index_ptr_18318);
    DeRef(_current_block_18319);
    DeRef(_remaining_18323);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [47] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18313);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18312;
    ((int *)_2)[2] = _table_name_18313;
    _10210 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10207);
    _38fatal(903, _10093, _10207, _10210);
    _10210 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_18313);
    DeRef(_key_ptr_18314);
    DeRef(_nrecs_18315);
    DeRef(_records_ptr_18316);
    DeRef(_data_ptr_18317);
    DeRef(_index_ptr_18318);
    DeRef(_current_block_18319);
    DeRef(_remaining_18323);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10211 = (_key_location_18312 < 1);
    if (_10211 != 0) {
        goto L4; // [75] 93
    }
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _10213 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _10213 = 1;
    }
    _10214 = (_key_location_18312 > _10213);
    _10213 = NOVALUE;
    if (_10214 == 0)
    {
        DeRef(_10214);
        _10214 = NOVALUE;
        goto L5; // [89] 111
    }
    else{
        DeRef(_10214);
        _10214 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18313);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18312;
    ((int *)_2)[2] = _table_name_18313;
    _10216 = MAKE_SEQ(_1);
    RefDS(_10215);
    RefDS(_10207);
    _38fatal(905, _10215, _10207, _10216);
    _10216 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_18313);
    DeRef(_key_ptr_18314);
    DeRef(_nrecs_18315);
    DeRef(_records_ptr_18316);
    DeRef(_data_ptr_18317);
    DeRef(_index_ptr_18318);
    DeRef(_current_block_18319);
    DeRef(_remaining_18323);
    DeRef(_10211);
    _10211 = NOVALUE;
    return;
L5: 

    /** 	key_ptr = key_pointers[key_location]*/
    DeRef(_key_ptr_18314);
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _key_ptr_18314 = (int)*(((s1_ptr)_2)->base + _key_location_18312);
    Ref(_key_ptr_18314);

    /** 	io:seek(current_db, key_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_key_ptr_18314);
    DeRef(_seek_1__tmp_at122_18345);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _key_ptr_18314;
    _seek_1__tmp_at122_18345 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_122_18344 = machine(19, _seek_1__tmp_at122_18345);
    DeRef(_seek_1__tmp_at122_18345);
    _seek_1__tmp_at122_18345 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _10218 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _10218 = 1;
    }
    if (_10218 <= 0)
    goto L6; // [143] 151
    DeRef(_table_name_18313);
    DeRef(_key_ptr_18314);
    DeRef(_nrecs_18315);
    DeRef(_records_ptr_18316);
    DeRef(_data_ptr_18317);
    DeRef(_index_ptr_18318);
    DeRef(_current_block_18319);
    DeRef(_remaining_18323);
    DeRef(_10211);
    _10211 = NOVALUE;
    return;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18317;
    _data_ptr_18317 = _38get4();
    DeRef(_0);

    /** 	db_free(key_ptr)*/
    Ref(_key_ptr_18314);
    _38db_free(_key_ptr_18314);

    /** 	db_free(data_ptr)*/
    Ref(_data_ptr_18317);
    _38db_free(_data_ptr_18317);

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _n_18322 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _n_18322 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10222 = _n_18322 >> 1;
    if (_key_location_18312 < _10222)
    goto L7; // [179] 223

    /** 		key_pointers[key_location..n-1] = key_pointers[key_location+1..n]*/
    _10224 = _n_18322 - 1;
    _10225 = _key_location_18312 + 1;
    rhs_slice_target = (object_ptr)&_10226;
    RHS_Slice(_38key_pointers_16425, _10225, _n_18322);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16425;
    AssignSlice(_key_location_18312, _10224, _10226);
    _10224 = NOVALUE;
    DeRefDS(_10226);
    _10226 = NOVALUE;

    /** 		key_pointers = key_pointers[1..n-1]*/
    _10227 = _n_18322 - 1;
    rhs_slice_target = (object_ptr)&_38key_pointers_16425;
    RHS_Slice(_38key_pointers_16425, 1, _10227);
    goto L8; // [220] 253
L7: 

    /** 		key_pointers[2..key_location] = key_pointers[1..key_location-1]*/
    _10229 = _key_location_18312 - 1;
    rhs_slice_target = (object_ptr)&_10230;
    RHS_Slice(_38key_pointers_16425, 1, _10229);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16425;
    AssignSlice(2, _key_location_18312, _10230);
    DeRefDS(_10230);
    _10230 = NOVALUE;

    /** 		key_pointers = key_pointers[2..n]*/
    rhs_slice_target = (object_ptr)&_38key_pointers_16425;
    RHS_Slice(_38key_pointers_16425, 2, _n_18322);
L8: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10232 = _38current_table_pos_16419 + 4;
        if ((long)((unsigned long)_10232 + (unsigned long)HIGH_BITS) >= 0) 
        _10232 = NewDouble((double)_10232);
    }
    else {
        _10232 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_262_18365);
    _pos_inlined_seek_at_262_18365 = _10232;
    _10232 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_262_18365);
    DeRef(_seek_1__tmp_at265_18367);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_262_18365;
    _seek_1__tmp_at265_18367 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_265_18366 = machine(19, _seek_1__tmp_at265_18367);
    DeRef(_pos_inlined_seek_at_262_18365);
    _pos_inlined_seek_at_262_18365 = NOVALUE;
    DeRef(_seek_1__tmp_at265_18367);
    _seek_1__tmp_at265_18367 = NOVALUE;

    /** 	nrecs = get4()-1*/
    _10233 = _38get4();
    DeRef(_nrecs_18315);
    if (IS_ATOM_INT(_10233)) {
        _nrecs_18315 = _10233 - 1;
        if ((long)((unsigned long)_nrecs_18315 +(unsigned long) HIGH_BITS) >= 0){
            _nrecs_18315 = NewDouble((double)_nrecs_18315);
        }
    }
    else {
        _nrecs_18315 = binary_op(MINUS, _10233, 1);
    }
    DeRef(_10233);
    _10233 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18321 = _38get4();
    if (!IS_ATOM_INT(_blocks_18321)) {
        _1 = (long)(DBL_PTR(_blocks_18321)->dbl);
        DeRefDS(_blocks_18321);
        _blocks_18321 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10236 = _38current_table_pos_16419 + 4;
        if ((long)((unsigned long)_10236 + (unsigned long)HIGH_BITS) >= 0) 
        _10236 = NewDouble((double)_10236);
    }
    else {
        _10236 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_304_18373);
    _pos_inlined_seek_at_304_18373 = _10236;
    _10236 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_304_18373);
    DeRef(_seek_1__tmp_at307_18375);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_304_18373;
    _seek_1__tmp_at307_18375 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_307_18374 = machine(19, _seek_1__tmp_at307_18375);
    DeRef(_pos_inlined_seek_at_304_18373);
    _pos_inlined_seek_at_304_18373 = NOVALUE;
    DeRef(_seek_1__tmp_at307_18375);
    _seek_1__tmp_at307_18375 = NOVALUE;

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18315)) {
        *poke4_addr = (unsigned long)_nrecs_18315;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18315)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at322_18377);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at322_18377 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at322_18377); // DJP 

    /** end procedure*/
    goto L9; // [344] 347
L9: 
    DeRefi(_put4_1__tmp_at322_18377);
    _put4_1__tmp_at322_18377 = NOVALUE;

    /** 	io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10237 = _38current_table_pos_16419 + 12;
        if ((long)((unsigned long)_10237 + (unsigned long)HIGH_BITS) >= 0) 
        _10237 = NewDouble((double)_10237);
    }
    else {
        _10237 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_358_18380);
    _pos_inlined_seek_at_358_18380 = _10237;
    _10237 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_358_18380);
    DeRef(_seek_1__tmp_at361_18382);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_358_18380;
    _seek_1__tmp_at361_18382 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_361_18381 = machine(19, _seek_1__tmp_at361_18382);
    DeRef(_pos_inlined_seek_at_358_18380);
    _pos_inlined_seek_at_358_18380 = NOVALUE;
    DeRef(_seek_1__tmp_at361_18382);
    _seek_1__tmp_at361_18382 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18318;
    _index_ptr_18318 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18318);
    DeRef(_seek_1__tmp_at383_18386);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _index_ptr_18318;
    _seek_1__tmp_at383_18386 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_383_18385 = machine(19, _seek_1__tmp_at383_18386);
    DeRef(_seek_1__tmp_at383_18386);
    _seek_1__tmp_at383_18386 = NOVALUE;

    /** 	r = 0*/
    _r_18320 = 0;

    /** 	while TRUE do*/
LA: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18315;
    _nrecs_18315 = _38get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18316;
    _records_ptr_18316 = _38get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18315)) {
        _r_18320 = _r_18320 + _nrecs_18315;
    }
    else {
        _r_18320 = NewDouble((double)_r_18320 + DBL_PTR(_nrecs_18315)->dbl);
    }
    if (!IS_ATOM_INT(_r_18320)) {
        _1 = (long)(DBL_PTR(_r_18320)->dbl);
        DeRefDS(_r_18320);
        _r_18320 = _1;
    }

    /** 		if r >= key_location then*/
    if (_r_18320 < _key_location_18312)
    goto LA; // [427] 407

    /** 			exit*/
    goto LB; // [433] 441

    /** 	end while*/
    goto LA; // [438] 407
LB: 

    /** 	r -= nrecs*/
    if (IS_ATOM_INT(_nrecs_18315)) {
        _r_18320 = _r_18320 - _nrecs_18315;
    }
    else {
        _r_18320 = NewDouble((double)_r_18320 - DBL_PTR(_nrecs_18315)->dbl);
    }
    if (!IS_ATOM_INT(_r_18320)) {
        _1 = (long)(DBL_PTR(_r_18320)->dbl);
        DeRefDS(_r_18320);
        _r_18320 = _1;
    }

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_452_18395);
    _where_inlined_where_at_452_18395 = machine(20, _38current_db_16418);
    DeRef(_current_block_18319);
    if (IS_ATOM_INT(_where_inlined_where_at_452_18395)) {
        _current_block_18319 = _where_inlined_where_at_452_18395 - 8;
        if ((long)((unsigned long)_current_block_18319 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18319 = NewDouble((double)_current_block_18319);
        }
    }
    else {
        _current_block_18319 = NewDouble(DBL_PTR(_where_inlined_where_at_452_18395)->dbl - (double)8);
    }

    /** 	nrecs -= 1*/
    _0 = _nrecs_18315;
    if (IS_ATOM_INT(_nrecs_18315)) {
        _nrecs_18315 = _nrecs_18315 - 1;
        if ((long)((unsigned long)_nrecs_18315 +(unsigned long) HIGH_BITS) >= 0){
            _nrecs_18315 = NewDouble((double)_nrecs_18315);
        }
    }
    else {
        _nrecs_18315 = NewDouble(DBL_PTR(_nrecs_18315)->dbl - (double)1);
    }
    DeRef(_0);

    /** 	if nrecs = 0 and blocks > 1 then*/
    if (IS_ATOM_INT(_nrecs_18315)) {
        _10246 = (_nrecs_18315 == 0);
    }
    else {
        _10246 = (DBL_PTR(_nrecs_18315)->dbl == (double)0);
    }
    if (_10246 == 0) {
        goto LC; // [476] 617
    }
    _10248 = (_blocks_18321 > 1);
    if (_10248 == 0)
    {
        DeRef(_10248);
        _10248 = NOVALUE;
        goto LC; // [485] 617
    }
    else{
        DeRef(_10248);
        _10248 = NOVALUE;
    }

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18321 == (short)_blocks_18321)
    _10249 = _blocks_18321 * 8;
    else
    _10249 = NewDouble(_blocks_18321 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18318) && IS_ATOM_INT(_10249)) {
        _10250 = _index_ptr_18318 + _10249;
        if ((long)((unsigned long)_10250 + (unsigned long)HIGH_BITS) >= 0) 
        _10250 = NewDouble((double)_10250);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18318)) {
            _10250 = NewDouble((double)_index_ptr_18318 + DBL_PTR(_10249)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10249)) {
                _10250 = NewDouble(DBL_PTR(_index_ptr_18318)->dbl + (double)_10249);
            }
            else
            _10250 = NewDouble(DBL_PTR(_index_ptr_18318)->dbl + DBL_PTR(_10249)->dbl);
        }
    }
    DeRef(_10249);
    _10249 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18319)) {
        _10251 = _current_block_18319 + 8;
        if ((long)((unsigned long)_10251 + (unsigned long)HIGH_BITS) >= 0) 
        _10251 = NewDouble((double)_10251);
    }
    else {
        _10251 = NewDouble(DBL_PTR(_current_block_18319)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10250) && IS_ATOM_INT(_10251)) {
        _10252 = _10250 - _10251;
        if ((long)((unsigned long)_10252 +(unsigned long) HIGH_BITS) >= 0){
            _10252 = NewDouble((double)_10252);
        }
    }
    else {
        if (IS_ATOM_INT(_10250)) {
            _10252 = NewDouble((double)_10250 - DBL_PTR(_10251)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10251)) {
                _10252 = NewDouble(DBL_PTR(_10250)->dbl - (double)_10251);
            }
            else
            _10252 = NewDouble(DBL_PTR(_10250)->dbl - DBL_PTR(_10251)->dbl);
        }
    }
    DeRef(_10250);
    _10250 = NOVALUE;
    DeRef(_10251);
    _10251 = NOVALUE;
    _0 = _remaining_18323;
    _remaining_18323 = _18get_bytes(_38current_db_16418, _10252);
    DeRef(_0);
    _10252 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18319);
    DeRef(_seek_1__tmp_at518_18409);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _current_block_18319;
    _seek_1__tmp_at518_18409 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_518_18408 = machine(19, _seek_1__tmp_at518_18409);
    DeRef(_seek_1__tmp_at518_18409);
    _seek_1__tmp_at518_18409 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _remaining_18323); // DJP 

    /** end procedure*/
    goto LD; // [543] 546
LD: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_38current_table_pos_16419)) {
        _10254 = _38current_table_pos_16419 + 8;
        if ((long)((unsigned long)_10254 + (unsigned long)HIGH_BITS) >= 0) 
        _10254 = NewDouble((double)_10254);
    }
    else {
        _10254 = NewDouble(DBL_PTR(_38current_table_pos_16419)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_555_18413);
    _pos_inlined_seek_at_555_18413 = _10254;
    _10254 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_555_18413);
    DeRef(_seek_1__tmp_at558_18415);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_555_18413;
    _seek_1__tmp_at558_18415 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_558_18414 = machine(19, _seek_1__tmp_at558_18415);
    DeRef(_pos_inlined_seek_at_555_18413);
    _pos_inlined_seek_at_555_18413 = NOVALUE;
    DeRef(_seek_1__tmp_at558_18415);
    _seek_1__tmp_at558_18415 = NOVALUE;

    /** 		put4(blocks-1)*/
    _10255 = _blocks_18321 - 1;
    if ((long)((unsigned long)_10255 +(unsigned long) HIGH_BITS) >= 0){
        _10255 = NewDouble((double)_10255);
    }
    DeRef(_x_inlined_put4_at_577_18418);
    _x_inlined_put4_at_577_18418 = _10255;
    _10255 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_577_18418)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_577_18418;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_577_18418)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at580_18419);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at580_18419 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at580_18419); // DJP 

    /** end procedure*/
    goto LE; // [602] 605
LE: 
    DeRef(_x_inlined_put4_at_577_18418);
    _x_inlined_put4_at_577_18418 = NOVALUE;
    DeRefi(_put4_1__tmp_at580_18419);
    _put4_1__tmp_at580_18419 = NOVALUE;

    /** 		db_free(records_ptr)*/
    Ref(_records_ptr_18316);
    _38db_free(_records_ptr_18316);
    goto LF; // [614] 763
LC: 

    /** 		key_location -= r*/
    _key_location_18312 = _key_location_18312 - _r_18320;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18319);
    DeRef(_seek_1__tmp_at626_18424);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _current_block_18319;
    _seek_1__tmp_at626_18424 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_626_18423 = machine(19, _seek_1__tmp_at626_18424);
    DeRef(_seek_1__tmp_at626_18424);
    _seek_1__tmp_at626_18424 = NOVALUE;

    /** 		put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18315)) {
        *poke4_addr = (unsigned long)_nrecs_18315;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18315)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at641_18426);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at641_18426 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at641_18426); // DJP 

    /** end procedure*/
    goto L10; // [663] 666
L10: 
    DeRefi(_put4_1__tmp_at641_18426);
    _put4_1__tmp_at641_18426 = NOVALUE;

    /** 		io:seek(current_db, records_ptr+4*(key_location-1))*/
    _10257 = _key_location_18312 - 1;
    if ((long)((unsigned long)_10257 +(unsigned long) HIGH_BITS) >= 0){
        _10257 = NewDouble((double)_10257);
    }
    if (IS_ATOM_INT(_10257)) {
        if (_10257 <= INT15 && _10257 >= -INT15)
        _10258 = 4 * _10257;
        else
        _10258 = NewDouble(4 * (double)_10257);
    }
    else {
        _10258 = NewDouble((double)4 * DBL_PTR(_10257)->dbl);
    }
    DeRef(_10257);
    _10257 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18316) && IS_ATOM_INT(_10258)) {
        _10259 = _records_ptr_18316 + _10258;
        if ((long)((unsigned long)_10259 + (unsigned long)HIGH_BITS) >= 0) 
        _10259 = NewDouble((double)_10259);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18316)) {
            _10259 = NewDouble((double)_records_ptr_18316 + DBL_PTR(_10258)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10258)) {
                _10259 = NewDouble(DBL_PTR(_records_ptr_18316)->dbl + (double)_10258);
            }
            else
            _10259 = NewDouble(DBL_PTR(_records_ptr_18316)->dbl + DBL_PTR(_10258)->dbl);
        }
    }
    DeRef(_10258);
    _10258 = NOVALUE;
    DeRef(_pos_inlined_seek_at_685_18431);
    _pos_inlined_seek_at_685_18431 = _10259;
    _10259 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_685_18431);
    DeRef(_seek_1__tmp_at688_18433);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_685_18431;
    _seek_1__tmp_at688_18433 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_688_18432 = machine(19, _seek_1__tmp_at688_18433);
    DeRef(_pos_inlined_seek_at_685_18431);
    _pos_inlined_seek_at_685_18431 = NOVALUE;
    DeRef(_seek_1__tmp_at688_18433);
    _seek_1__tmp_at688_18433 = NOVALUE;

    /** 		for i = key_location to nrecs do*/
    Ref(_nrecs_18315);
    DeRef(_10260);
    _10260 = _nrecs_18315;
    {
        int _i_18435;
        _i_18435 = _key_location_18312;
L11: 
        if (binary_op_a(GREATER, _i_18435, _10260)){
            goto L12; // [707] 762
        }

        /** 			put4(key_pointers[i+r])*/
        if (IS_ATOM_INT(_i_18435)) {
            _10261 = _i_18435 + _r_18320;
        }
        else {
            _10261 = NewDouble(DBL_PTR(_i_18435)->dbl + (double)_r_18320);
        }
        _2 = (int)SEQ_PTR(_38key_pointers_16425);
        if (!IS_ATOM_INT(_10261)){
            _10262 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10261)->dbl));
        }
        else{
            _10262 = (int)*(((s1_ptr)_2)->base + _10261);
        }
        Ref(_10262);
        DeRef(_x_inlined_put4_at_725_18440);
        _x_inlined_put4_at_725_18440 = _10262;
        _10262 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16460)){
            poke4_addr = (unsigned long *)_38mem0_16460;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_725_18440)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_725_18440;
        }
        else if (IS_ATOM(_x_inlined_put4_at_725_18440)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_725_18440)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_725_18440);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at728_18441);
        _1 = (int)SEQ_PTR(_38memseq_16680);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at728_18441 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16418, _put4_1__tmp_at728_18441); // DJP 

        /** end procedure*/
        goto L13; // [750] 753
L13: 
        DeRef(_x_inlined_put4_at_725_18440);
        _x_inlined_put4_at_725_18440 = NOVALUE;
        DeRefi(_put4_1__tmp_at728_18441);
        _put4_1__tmp_at728_18441 = NOVALUE;

        /** 		end for*/
        _0 = _i_18435;
        if (IS_ATOM_INT(_i_18435)) {
            _i_18435 = _i_18435 + 1;
            if ((long)((unsigned long)_i_18435 +(unsigned long) HIGH_BITS) >= 0){
                _i_18435 = NewDouble((double)_i_18435);
            }
        }
        else {
            _i_18435 = binary_op_a(PLUS, _i_18435, 1);
        }
        DeRef(_0);
        goto L11; // [757] 714
L12: 
        ;
        DeRef(_i_18435);
    }
LF: 

    /** end procedure*/
    DeRef(_table_name_18313);
    DeRef(_key_ptr_18314);
    DeRef(_nrecs_18315);
    DeRef(_records_ptr_18316);
    DeRef(_data_ptr_18317);
    DeRef(_index_ptr_18318);
    DeRef(_current_block_18319);
    DeRef(_remaining_18323);
    DeRef(_10211);
    _10211 = NOVALUE;
    DeRef(_10222);
    _10222 = NOVALUE;
    DeRef(_10227);
    _10227 = NOVALUE;
    DeRef(_10225);
    _10225 = NOVALUE;
    DeRef(_10229);
    _10229 = NOVALUE;
    DeRef(_10246);
    _10246 = NOVALUE;
    DeRef(_10261);
    _10261 = NOVALUE;
    return;
    ;
}
void db_delete_record() __attribute__ ((alias ("_38db_delete_record")));


void _38db_replace_data(int _key_location_18444, int _data_18445, int _table_name_18446)
{
    int _10276 = NOVALUE;
    int _10275 = NOVALUE;
    int _10274 = NOVALUE;
    int _10273 = NOVALUE;
    int _10271 = NOVALUE;
    int _10270 = NOVALUE;
    int _10268 = NOVALUE;
    int _10265 = NOVALUE;
    int _10263 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18444)) {
        _1 = (long)(DBL_PTR(_key_location_18444)->dbl);
        DeRefDS(_key_location_18444);
        _key_location_18444 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18446 == _38current_table_name_16420)
    _10263 = 1;
    else if (IS_ATOM_INT(_table_name_18446) && IS_ATOM_INT(_38current_table_name_16420))
    _10263 = 0;
    else
    _10263 = (compare(_table_name_18446, _38current_table_name_16420) == 0);
    if (_10263 != 0)
    goto L1; // [11] 45
    _10263 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18446);
    _10265 = _38db_select_table(_table_name_18446);
    if (binary_op_a(EQUALS, _10265, 0)){
        DeRef(_10265);
        _10265 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10265);
    _10265 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18444;
    Ref(_data_18445);
    *((int *)(_2+8)) = _data_18445;
    Ref(_table_name_18446);
    *((int *)(_2+12)) = _table_name_18446;
    _10268 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10267);
    _38fatal(903, _10089, _10267, _10268);
    _10268 = NOVALUE;

    /** 			return*/
    DeRef(_data_18445);
    DeRef(_table_name_18446);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18444;
    Ref(_data_18445);
    *((int *)(_2+8)) = _data_18445;
    Ref(_table_name_18446);
    *((int *)(_2+12)) = _table_name_18446;
    _10270 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10267);
    _38fatal(903, _10093, _10267, _10270);
    _10270 = NOVALUE;

    /** 		return*/
    DeRef(_data_18445);
    DeRef(_table_name_18446);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10271 = (_key_location_18444 < 1);
    if (_10271 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _10273 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _10273 = 1;
    }
    _10274 = (_key_location_18444 > _10273);
    _10273 = NOVALUE;
    if (_10274 == 0)
    {
        DeRef(_10274);
        _10274 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10274);
        _10274 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18444;
    Ref(_data_18445);
    *((int *)(_2+8)) = _data_18445;
    Ref(_table_name_18446);
    *((int *)(_2+12)) = _table_name_18446;
    _10275 = MAKE_SEQ(_1);
    RefDS(_10215);
    RefDS(_10267);
    _38fatal(905, _10215, _10267, _10275);
    _10275 = NOVALUE;

    /** 		return*/
    DeRef(_data_18445);
    DeRef(_table_name_18446);
    DeRef(_10271);
    _10271 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10276 = (int)*(((s1_ptr)_2)->base + _key_location_18444);
    Ref(_10276);
    Ref(_data_18445);
    _38db_replace_recid(_10276, _data_18445);
    _10276 = NOVALUE;

    /** end procedure*/
    DeRef(_data_18445);
    DeRef(_table_name_18446);
    DeRef(_10271);
    _10271 = NOVALUE;
    return;
    ;
}
void db_replace_data() __attribute__ ((alias ("_38db_replace_data")));


int _38db_table_size(int _table_name_18468)
{
    int _10285 = NOVALUE;
    int _10284 = NOVALUE;
    int _10282 = NOVALUE;
    int _10279 = NOVALUE;
    int _10277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18468 == _38current_table_name_16420)
    _10277 = 1;
    else if (IS_ATOM_INT(_table_name_18468) && IS_ATOM_INT(_38current_table_name_16420))
    _10277 = 0;
    else
    _10277 = (compare(_table_name_18468, _38current_table_name_16420) == 0);
    if (_10277 != 0)
    goto L1; // [9] 42
    _10277 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18468);
    _10279 = _38db_select_table(_table_name_18468);
    if (binary_op_a(EQUALS, _10279, 0)){
        DeRef(_10279);
        _10279 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10279);
    _10279 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_18468);
    *((int *)(_2+4)) = _table_name_18468;
    _10282 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10281);
    _38fatal(903, _10089, _10281, _10282);
    _10282 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18468);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_18468);
    *((int *)(_2+4)) = _table_name_18468;
    _10284 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10281);
    _38fatal(903, _10093, _10281, _10284);
    _10284 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18468);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _10285 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _10285 = 1;
    }
    DeRef(_table_name_18468);
    return _10285;
    ;
}
int db_table_size() __attribute__ ((alias ("_38db_table_size")));


int _38db_record_data(int _key_location_18483, int _table_name_18484)
{
    int _data_ptr_18485 = NOVALUE;
    int _data_value_18486 = NOVALUE;
    int _seek_1__tmp_at126_18508 = NOVALUE;
    int _seek_inlined_seek_at_126_18507 = NOVALUE;
    int _pos_inlined_seek_at_123_18506 = NOVALUE;
    int _seek_1__tmp_at164_18515 = NOVALUE;
    int _seek_inlined_seek_at_164_18514 = NOVALUE;
    int _10300 = NOVALUE;
    int _10299 = NOVALUE;
    int _10298 = NOVALUE;
    int _10297 = NOVALUE;
    int _10296 = NOVALUE;
    int _10294 = NOVALUE;
    int _10293 = NOVALUE;
    int _10291 = NOVALUE;
    int _10288 = NOVALUE;
    int _10286 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18483)) {
        _1 = (long)(DBL_PTR(_key_location_18483)->dbl);
        DeRefDS(_key_location_18483);
        _key_location_18483 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18484 == _38current_table_name_16420)
    _10286 = 1;
    else if (IS_ATOM_INT(_table_name_18484) && IS_ATOM_INT(_38current_table_name_16420))
    _10286 = 0;
    else
    _10286 = (compare(_table_name_18484, _38current_table_name_16420) == 0);
    if (_10286 != 0)
    goto L1; // [11] 44
    _10286 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18484);
    _10288 = _38db_select_table(_table_name_18484);
    if (binary_op_a(EQUALS, _10288, 0)){
        DeRef(_10288);
        _10288 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10288);
    _10288 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18484);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18483;
    ((int *)_2)[2] = _table_name_18484;
    _10291 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10290);
    _38fatal(903, _10089, _10290, _10291);
    _10291 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18484);
    DeRef(_data_ptr_18485);
    DeRef(_data_value_18486);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18484);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18483;
    ((int *)_2)[2] = _table_name_18484;
    _10293 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10290);
    _38fatal(903, _10093, _10290, _10293);
    _10293 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18484);
    DeRef(_data_ptr_18485);
    DeRef(_data_value_18486);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10294 = (_key_location_18483 < 1);
    if (_10294 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _10296 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _10296 = 1;
    }
    _10297 = (_key_location_18483 > _10296);
    _10296 = NOVALUE;
    if (_10297 == 0)
    {
        DeRef(_10297);
        _10297 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10297);
        _10297 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18484);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18483;
    ((int *)_2)[2] = _table_name_18484;
    _10298 = MAKE_SEQ(_1);
    RefDS(_10215);
    RefDS(_10290);
    _38fatal(905, _10215, _10290, _10298);
    _10298 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18484);
    DeRef(_data_ptr_18485);
    DeRef(_data_value_18486);
    DeRef(_10294);
    _10294 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10299 = (int)*(((s1_ptr)_2)->base + _key_location_18483);
    Ref(_10299);
    DeRef(_pos_inlined_seek_at_123_18506);
    _pos_inlined_seek_at_123_18506 = _10299;
    _10299 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_18506);
    DeRef(_seek_1__tmp_at126_18508);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_18506;
    _seek_1__tmp_at126_18508 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_18507 = machine(19, _seek_1__tmp_at126_18508);
    DeRef(_pos_inlined_seek_at_123_18506);
    _pos_inlined_seek_at_123_18506 = NOVALUE;
    DeRef(_seek_1__tmp_at126_18508);
    _seek_1__tmp_at126_18508 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_38vLastErrors_16442)){
            _10300 = SEQ_PTR(_38vLastErrors_16442)->length;
    }
    else {
        _10300 = 1;
    }
    if (_10300 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_18484);
    DeRef(_data_ptr_18485);
    DeRef(_data_value_18486);
    DeRef(_10294);
    _10294 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18485;
    _data_ptr_18485 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18485);
    DeRef(_seek_1__tmp_at164_18515);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16418;
    ((int *)_2)[2] = _data_ptr_18485;
    _seek_1__tmp_at164_18515 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_18514 = machine(19, _seek_1__tmp_at164_18515);
    DeRef(_seek_1__tmp_at164_18515);
    _seek_1__tmp_at164_18515 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_18486;
    _data_value_18486 = _38decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_18484);
    DeRef(_data_ptr_18485);
    DeRef(_10294);
    _10294 = NOVALUE;
    return _data_value_18486;
    ;
}
int db_record_data() __attribute__ ((alias ("_38db_record_data")));


int _38db_fetch_record(int _key_18519, int _table_name_18520)
{
    int _pos_18521 = NOVALUE;
    int _10306 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_18519);
    Ref(_table_name_18520);
    _pos_18521 = _38db_find_key(_key_18519, _table_name_18520);
    if (!IS_ATOM_INT(_pos_18521)) {
        _1 = (long)(DBL_PTR(_pos_18521)->dbl);
        DeRefDS(_pos_18521);
        _pos_18521 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_18521 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    Ref(_table_name_18520);
    _10306 = _38db_record_data(_pos_18521, _table_name_18520);
    DeRef(_key_18519);
    DeRef(_table_name_18520);
    return _10306;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_18519);
    DeRef(_table_name_18520);
    DeRef(_10306);
    _10306 = NOVALUE;
    return _pos_18521;
L2: 
    ;
}
int db_fetch_record() __attribute__ ((alias ("_38db_fetch_record")));


int _38db_record_key(int _key_location_18529, int _table_name_18530)
{
    int _10321 = NOVALUE;
    int _10320 = NOVALUE;
    int _10319 = NOVALUE;
    int _10318 = NOVALUE;
    int _10317 = NOVALUE;
    int _10315 = NOVALUE;
    int _10314 = NOVALUE;
    int _10312 = NOVALUE;
    int _10309 = NOVALUE;
    int _10307 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18529)) {
        _1 = (long)(DBL_PTR(_key_location_18529)->dbl);
        DeRefDS(_key_location_18529);
        _key_location_18529 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18530 == _38current_table_name_16420)
    _10307 = 1;
    else if (IS_ATOM_INT(_table_name_18530) && IS_ATOM_INT(_38current_table_name_16420))
    _10307 = 0;
    else
    _10307 = (compare(_table_name_18530, _38current_table_name_16420) == 0);
    if (_10307 != 0)
    goto L1; // [11] 44
    _10307 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18530);
    _10309 = _38db_select_table(_table_name_18530);
    if (binary_op_a(EQUALS, _10309, 0)){
        DeRef(_10309);
        _10309 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10309);
    _10309 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18530);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18529;
    ((int *)_2)[2] = _table_name_18530;
    _10312 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10311);
    _38fatal(903, _10089, _10311, _10312);
    _10312 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18530);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18530);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18529;
    ((int *)_2)[2] = _table_name_18530;
    _10314 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10311);
    _38fatal(903, _10093, _10311, _10314);
    _10314 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18530);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10315 = (_key_location_18529 < 1);
    if (_10315 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _10317 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _10317 = 1;
    }
    _10318 = (_key_location_18529 > _10317);
    _10317 = NOVALUE;
    if (_10318 == 0)
    {
        DeRef(_10318);
        _10318 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10318);
        _10318 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18530);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18529;
    ((int *)_2)[2] = _table_name_18530;
    _10319 = MAKE_SEQ(_1);
    RefDS(_10215);
    RefDS(_10311);
    _38fatal(905, _10215, _10311, _10319);
    _10319 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18530);
    DeRef(_10315);
    _10315 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10320 = (int)*(((s1_ptr)_2)->base + _key_location_18529);
    Ref(_10320);
    _10321 = _38key_value(_10320);
    _10320 = NOVALUE;
    DeRef(_table_name_18530);
    DeRef(_10315);
    _10315 = NOVALUE;
    return _10321;
    ;
}
int db_record_key() __attribute__ ((alias ("_38db_record_key")));


int _38db_compress()
{
    int _index_18552 = NOVALUE;
    int _chunk_size_18553 = NOVALUE;
    int _nrecs_18554 = NOVALUE;
    int _r_18555 = NOVALUE;
    int _fn_18556 = NOVALUE;
    int _new_path_18557 = NOVALUE;
    int _table_list_18558 = NOVALUE;
    int _record_18559 = NOVALUE;
    int _chunk_18560 = NOVALUE;
    int _temp_path_18568 = NOVALUE;
    int _10367 = NOVALUE;
    int _10363 = NOVALUE;
    int _10362 = NOVALUE;
    int _10361 = NOVALUE;
    int _10360 = NOVALUE;
    int _10359 = NOVALUE;
    int _10358 = NOVALUE;
    int _10356 = NOVALUE;
    int _10351 = NOVALUE;
    int _10350 = NOVALUE;
    int _10349 = NOVALUE;
    int _10346 = NOVALUE;
    int _10342 = NOVALUE;
    int _10339 = NOVALUE;
    int _10337 = NOVALUE;
    int _10334 = NOVALUE;
    int _10331 = NOVALUE;
    int _10326 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16418 != -1)
    goto L1; // [5] 24

    /** 		fatal(NO_DATABASE, "no current database", "db_compress", {})*/
    RefDS(_10323);
    RefDS(_10324);
    RefDS(_5);
    _38fatal(901, _10323, _10324, _5);

    /** 		return -1*/
    DeRef(_new_path_18557);
    DeRef(_table_list_18558);
    DeRef(_record_18559);
    DeRef(_chunk_18560);
    DeRef(_temp_path_18568);
    return -1;
L1: 

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18552 = find_from(_38current_db_16418, _38db_file_nums_16422, 1);

    /** 	new_path = text:trim(db_names[index])*/
    _2 = (int)SEQ_PTR(_38db_names_16421);
    _10326 = (int)*(((s1_ptr)_2)->base + _index_18552);
    Ref(_10326);
    RefDS(_4498);
    _0 = _new_path_18557;
    _new_path_18557 = _6trim(_10326, _4498, 0);
    DeRef(_0);
    _10326 = NOVALUE;

    /** 	db_close()*/
    _38db_close();

    /** 	fn = -1*/
    _fn_18556 = -1;

    /** 	sequence temp_path = filesys:temp_file()*/
    RefDS(_5);
    RefDS(_5);
    RefDS(_4589);
    _0 = _temp_path_18568;
    _temp_path_18568 = _11temp_file(_5, _5, _4589, 0);
    DeRef(_0);

    /** 	fn = open( temp_path, "r" )*/
    _fn_18556 = EOpen(_temp_path_18568, _1217, 0);

    /** 	if fn != -1 then*/
    if (_fn_18556 == -1)
    goto L2; // [80] 91

    /** 		return DB_EXISTS_ALREADY -- you better delete some temp files*/
    DeRefDS(_new_path_18557);
    DeRef(_table_list_18558);
    DeRef(_record_18559);
    DeRef(_chunk_18560);
    DeRefDS(_temp_path_18568);
    return -2;
L2: 

    /** 	filesys:move_file( new_path, temp_path )*/
    RefDS(_new_path_18557);
    RefDS(_temp_path_18568);
    _10331 = _11move_file(_new_path_18557, _temp_path_18568, 0);

    /** 	index = db_create(new_path, DB_LOCK_NO)*/
    RefDS(_new_path_18557);
    _index_18552 = _38db_create(_new_path_18557, 0, 5, 5);
    if (!IS_ATOM_INT(_index_18552)) {
        _1 = (long)(DBL_PTR(_index_18552)->dbl);
        DeRefDS(_index_18552);
        _index_18552 = _1;
    }

    /** 	if index != DB_OK then*/
    if (_index_18552 == 0)
    goto L3; // [112] 131

    /** 		filesys:move_file( temp_path, new_path )*/
    RefDS(_temp_path_18568);
    RefDS(_new_path_18557);
    _10334 = _11move_file(_temp_path_18568, _new_path_18557, 0);

    /** 		return index*/
    DeRefDS(_new_path_18557);
    DeRef(_table_list_18558);
    DeRef(_record_18559);
    DeRef(_chunk_18560);
    DeRefDS(_temp_path_18568);
    DeRef(_10331);
    _10331 = NOVALUE;
    DeRef(_10334);
    _10334 = NOVALUE;
    return _index_18552;
L3: 

    /** 	index = db_open(temp_path, DB_LOCK_NO)*/
    RefDS(_temp_path_18568);
    _index_18552 = _38db_open(_temp_path_18568, 0);
    if (!IS_ATOM_INT(_index_18552)) {
        _1 = (long)(DBL_PTR(_index_18552)->dbl);
        DeRefDS(_index_18552);
        _index_18552 = _1;
    }

    /** 	table_list = db_table_list()*/
    _0 = _table_list_18558;
    _table_list_18558 = _38db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length(table_list) do*/
    if (IS_SEQUENCE(_table_list_18558)){
            _10337 = SEQ_PTR(_table_list_18558)->length;
    }
    else {
        _10337 = 1;
    }
    {
        int _i_18581;
        _i_18581 = 1;
L4: 
        if (_i_18581 > _10337){
            goto L5; // [152] 424
        }

        /** 		index = db_select(new_path)*/
        RefDS(_new_path_18557);
        _index_18552 = _38db_select(_new_path_18557, -1);
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 		index = db_create_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18558);
        _10339 = (int)*(((s1_ptr)_2)->base + _i_18581);
        Ref(_10339);
        _index_18552 = _38db_create_table(_10339, 50);
        _10339 = NOVALUE;
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 		index = db_select(temp_path)*/
        RefDS(_temp_path_18568);
        _index_18552 = _38db_select(_temp_path_18568, -1);
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 		index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18558);
        _10342 = (int)*(((s1_ptr)_2)->base + _i_18581);
        Ref(_10342);
        _index_18552 = _38db_select_table(_10342);
        _10342 = NOVALUE;
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 		nrecs = db_table_size()*/
        RefDS(_38current_table_name_16420);
        _nrecs_18554 = _38db_table_size(_38current_table_name_16420);
        if (!IS_ATOM_INT(_nrecs_18554)) {
            _1 = (long)(DBL_PTR(_nrecs_18554)->dbl);
            DeRefDS(_nrecs_18554);
            _nrecs_18554 = _1;
        }

        /** 		r = 1*/
        _r_18555 = 1;

        /** 		while r <= nrecs do*/
L6: 
        if (_r_18555 > _nrecs_18554)
        goto L7; // [222] 417

        /** 			chunk_size = nrecs - r + 1*/
        _10346 = _nrecs_18554 - _r_18555;
        if ((long)((unsigned long)_10346 +(unsigned long) HIGH_BITS) >= 0){
            _10346 = NewDouble((double)_10346);
        }
        if (IS_ATOM_INT(_10346)) {
            _chunk_size_18553 = _10346 + 1;
        }
        else
        { // coercing _chunk_size_18553 to an integer 1
            _chunk_size_18553 = 1+(long)(DBL_PTR(_10346)->dbl);
            if( !IS_ATOM_INT(_chunk_size_18553) ){
                _chunk_size_18553 = (object)DBL_PTR(_chunk_size_18553)->dbl;
            }
        }
        DeRef(_10346);
        _10346 = NOVALUE;

        /** 			if chunk_size > 20 then*/
        if (_chunk_size_18553 <= 20)
        goto L8; // [238] 248

        /** 				chunk_size = 20  -- copy up to 20 records at a time*/
        _chunk_size_18553 = 20;
L8: 

        /** 			chunk = {}*/
        RefDS(_5);
        DeRef(_chunk_18560);
        _chunk_18560 = _5;

        /** 			for j = 1 to chunk_size do*/
        _10349 = _chunk_size_18553;
        {
            int _j_18597;
            _j_18597 = 1;
L9: 
            if (_j_18597 > _10349){
                goto LA; // [260] 306
            }

            /** 				record = {db_record_key(r), db_record_data(r)}*/
            RefDS(_38current_table_name_16420);
            _10350 = _38db_record_key(_r_18555, _38current_table_name_16420);
            RefDS(_38current_table_name_16420);
            _10351 = _38db_record_data(_r_18555, _38current_table_name_16420);
            DeRef(_record_18559);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _10350;
            ((int *)_2)[2] = _10351;
            _record_18559 = MAKE_SEQ(_1);
            _10351 = NOVALUE;
            _10350 = NOVALUE;

            /** 				r += 1*/
            _r_18555 = _r_18555 + 1;

            /** 				chunk = append(chunk, record)*/
            RefDS(_record_18559);
            Append(&_chunk_18560, _chunk_18560, _record_18559);

            /** 			end for*/
            _j_18597 = _j_18597 + 1;
            goto L9; // [301] 267
LA: 
            ;
        }

        /** 			index = db_select(new_path)*/
        RefDS(_new_path_18557);
        _index_18552 = _38db_select(_new_path_18557, -1);
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 			index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18558);
        _10356 = (int)*(((s1_ptr)_2)->base + _i_18581);
        Ref(_10356);
        _index_18552 = _38db_select_table(_10356);
        _10356 = NOVALUE;
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 			for j = 1 to chunk_size do*/
        _10358 = _chunk_size_18553;
        {
            int _j_18608;
            _j_18608 = 1;
LB: 
            if (_j_18608 > _10358){
                goto LC; // [332] 391
            }

            /** 				if db_insert(chunk[j][1], chunk[j][2]) != DB_OK then*/
            _2 = (int)SEQ_PTR(_chunk_18560);
            _10359 = (int)*(((s1_ptr)_2)->base + _j_18608);
            _2 = (int)SEQ_PTR(_10359);
            _10360 = (int)*(((s1_ptr)_2)->base + 1);
            _10359 = NOVALUE;
            _2 = (int)SEQ_PTR(_chunk_18560);
            _10361 = (int)*(((s1_ptr)_2)->base + _j_18608);
            _2 = (int)SEQ_PTR(_10361);
            _10362 = (int)*(((s1_ptr)_2)->base + 2);
            _10361 = NOVALUE;
            Ref(_10360);
            Ref(_10362);
            RefDS(_38current_table_name_16420);
            _10363 = _38db_insert(_10360, _10362, _38current_table_name_16420);
            _10360 = NOVALUE;
            _10362 = NOVALUE;
            if (binary_op_a(EQUALS, _10363, 0)){
                DeRef(_10363);
                _10363 = NOVALUE;
                goto LD; // [365] 384
            }
            DeRef(_10363);
            _10363 = NOVALUE;

            /** 					fatal(INSERT_FAILED, "couldn't insert into new database", "db_compress", {})*/
            RefDS(_10365);
            RefDS(_10324);
            RefDS(_5);
            _38fatal(906, _10365, _10324, _5);

            /** 					return DB_FATAL_FAIL*/
            DeRef(_new_path_18557);
            DeRef(_table_list_18558);
            DeRef(_record_18559);
            DeRefDS(_chunk_18560);
            DeRef(_temp_path_18568);
            DeRef(_10331);
            _10331 = NOVALUE;
            DeRef(_10334);
            _10334 = NOVALUE;
            return -404;
LD: 

            /** 			end for*/
            _j_18608 = _j_18608 + 1;
            goto LB; // [386] 339
LC: 
            ;
        }

        /** 			index = db_select(temp_path)*/
        RefDS(_temp_path_18568);
        _index_18552 = _38db_select(_temp_path_18568, -1);
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 			index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18558);
        _10367 = (int)*(((s1_ptr)_2)->base + _i_18581);
        Ref(_10367);
        _index_18552 = _38db_select_table(_10367);
        _10367 = NOVALUE;
        if (!IS_ATOM_INT(_index_18552)) {
            _1 = (long)(DBL_PTR(_index_18552)->dbl);
            DeRefDS(_index_18552);
            _index_18552 = _1;
        }

        /** 		end while*/
        goto L6; // [414] 222
L7: 

        /** 	end for*/
        _i_18581 = _i_18581 + 1;
        goto L4; // [419] 159
L5: 
        ;
    }

    /** 	db_close()*/
    _38db_close();

    /** 	index = db_select(new_path)*/
    RefDS(_new_path_18557);
    _index_18552 = _38db_select(_new_path_18557, -1);
    if (!IS_ATOM_INT(_index_18552)) {
        _1 = (long)(DBL_PTR(_index_18552)->dbl);
        DeRefDS(_index_18552);
        _index_18552 = _1;
    }

    /** 	return DB_OK*/
    DeRefDS(_new_path_18557);
    DeRef(_table_list_18558);
    DeRef(_record_18559);
    DeRef(_chunk_18560);
    DeRef(_temp_path_18568);
    DeRef(_10331);
    _10331 = NOVALUE;
    DeRef(_10334);
    _10334 = NOVALUE;
    return 0;
    ;
}
int db_compress() __attribute__ ((alias ("_38db_compress")));


int _38db_current()
{
    int _index_18624 = NOVALUE;
    int _10372 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find (current_db, db_file_nums)*/
    _index_18624 = find_from(_38current_db_16418, _38db_file_nums_16422, 1);

    /** 	if index != 0 then*/
    if (_index_18624 == 0)
    goto L1; // [14] 33

    /** 		return db_names [index]*/
    _2 = (int)SEQ_PTR(_38db_names_16421);
    _10372 = (int)*(((s1_ptr)_2)->base + _index_18624);
    Ref(_10372);
    return _10372;
    goto L2; // [30] 40
L1: 

    /** 		return ""*/
    RefDS(_5);
    _10372 = NOVALUE;
    return _5;
L2: 
    ;
}
int db_current() __attribute__ ((alias ("_38db_current")));


void _38db_cache_clear()
{
    int _0, _1, _2;
    

    /** 	cache_index = {}*/
    RefDS(_5);
    DeRef(_38cache_index_16427);
    _38cache_index_16427 = _5;

    /** 	key_cache = {}*/
    RefDS(_5);
    DeRef(_38key_cache_16426);
    _38key_cache_16426 = _5;

    /** end procedure*/
    return;
    ;
}
void db_cache_clear() __attribute__ ((alias ("_38db_cache_clear")));


int _38db_set_caching(int _new_setting_18634)
{
    int _lOldVal_18635 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lOldVal = caching_option*/
    _lOldVal_18635 = _38caching_option_16428;

    /** 	caching_option = (new_setting != 0)*/
    if (IS_ATOM_INT(_new_setting_18634)) {
        _38caching_option_16428 = (_new_setting_18634 != 0);
    }
    else {
        _38caching_option_16428 = (DBL_PTR(_new_setting_18634)->dbl != (double)0);
    }

    /** 	if caching_option = 0 then*/
    if (_38caching_option_16428 != 0)
    goto L1; // [20] 46

    /** 		db_cache_clear()*/

    /** 	cache_index = {}*/
    RefDS(_5);
    DeRef(_38cache_index_16427);
    _38cache_index_16427 = _5;

    /** 	key_cache = {}*/
    RefDS(_5);
    DeRef(_38key_cache_16426);
    _38key_cache_16426 = _5;

    /** end procedure*/
    goto L2; // [42] 45
L2: 
L1: 

    /** 	return lOldVal*/
    DeRef(_new_setting_18634);
    return _lOldVal_18635;
    ;
}
int db_set_caching() __attribute__ ((alias ("_38db_set_caching")));


void _38db_replace_recid(int _recid_18642, int _data_18643)
{
    int _old_size_18644 = NOVALUE;
    int _new_size_18645 = NOVALUE;
    int _data_ptr_18646 = NOVALUE;
    int _data_string_18647 = NOVALUE;
    int _put4_1__tmp_at111_18667 = NOVALUE;
    int _10419 = NOVALUE;
    int _10418 = NOVALUE;
    int _10417 = NOVALUE;
    int _10416 = NOVALUE;
    int _10415 = NOVALUE;
    int _10387 = NOVALUE;
    int _10385 = NOVALUE;
    int _10384 = NOVALUE;
    int _10383 = NOVALUE;
    int _10382 = NOVALUE;
    int _10381 = NOVALUE;
    int _10377 = NOVALUE;
    int _10376 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18642)) {
        _1 = (long)(DBL_PTR(_recid_18642)->dbl);
        DeRefDS(_recid_18642);
        _recid_18642 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10419 = _18seek(_38current_db_16418, _recid_18642);
    DeRef(_10419);
    _10419 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18646;
    _data_ptr_18646 = _38get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_18646)) {
        _10376 = _data_ptr_18646 - 4;
        if ((long)((unsigned long)_10376 +(unsigned long) HIGH_BITS) >= 0){
            _10376 = NewDouble((double)_10376);
        }
    }
    else {
        _10376 = NewDouble(DBL_PTR(_data_ptr_18646)->dbl - (double)4);
    }
    _10418 = _18seek(_38current_db_16418, _10376);
    _10376 = NOVALUE;
    DeRef(_10418);
    _10418 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10377 = _38get4();
    DeRef(_old_size_18644);
    if (IS_ATOM_INT(_10377)) {
        _old_size_18644 = _10377 - 4;
        if ((long)((unsigned long)_old_size_18644 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_18644 = NewDouble((double)_old_size_18644);
        }
    }
    else {
        _old_size_18644 = binary_op(MINUS, _10377, 4);
    }
    DeRef(_10377);
    _10377 = NOVALUE;

    /** 	data_string = compress(data)*/
    Ref(_data_18643);
    _0 = _data_string_18647;
    _data_string_18647 = _38compress(_data_18643);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_18647)){
            _new_size_18645 = SEQ_PTR(_data_string_18647)->length;
    }
    else {
        _new_size_18645 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_18644)) {
        _10381 = (_new_size_18645 <= _old_size_18644);
    }
    else {
        _10381 = ((double)_new_size_18645 <= DBL_PTR(_old_size_18644)->dbl);
    }
    if (_10381 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_18644)) {
        _10383 = _old_size_18644 - 16;
        if ((long)((unsigned long)_10383 +(unsigned long) HIGH_BITS) >= 0){
            _10383 = NewDouble((double)_10383);
        }
    }
    else {
        _10383 = NewDouble(DBL_PTR(_old_size_18644)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10383)) {
        _10384 = (_new_size_18645 >= _10383);
    }
    else {
        _10384 = ((double)_new_size_18645 >= DBL_PTR(_10383)->dbl);
    }
    DeRef(_10383);
    _10383 = NOVALUE;
    if (_10384 == 0)
    {
        DeRef(_10384);
        _10384 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10384);
        _10384 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_18646);
    _10417 = _18seek(_38current_db_16418, _data_ptr_18646);
    DeRef(_10417);
    _10417 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_18646);
    _38db_free(_data_ptr_18646);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10385 = _new_size_18645 + 8;
    if ((long)((unsigned long)_10385 + (unsigned long)HIGH_BITS) >= 0) 
    _10385 = NewDouble((double)_10385);
    _0 = _data_ptr_18646;
    _data_ptr_18646 = _38db_allocate(_10385);
    DeRef(_0);
    _10385 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10416 = _18seek(_38current_db_16418, _recid_18642);
    DeRef(_10416);
    _10416 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16460)){
        poke4_addr = (unsigned long *)_38mem0_16460;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16460)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18646)) {
        *poke4_addr = (unsigned long)_data_ptr_18646;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18646)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_18667);
    _1 = (int)SEQ_PTR(_38memseq_16680);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_18667 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16418, _put4_1__tmp_at111_18667); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_18667);
    _put4_1__tmp_at111_18667 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_18646);
    _10415 = _18seek(_38current_db_16418, _data_ptr_18646);
    DeRef(_10415);
    _10415 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10387 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_18647, _data_string_18647, _10387);
    DeRefDS(_10387);
    _10387 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16418, _data_string_18647); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_data_18643);
    DeRef(_old_size_18644);
    DeRef(_data_ptr_18646);
    DeRef(_data_string_18647);
    DeRef(_10381);
    _10381 = NOVALUE;
    return;
    ;
}
void db_replace_recid() __attribute__ ((alias ("_38db_replace_recid")));


int _38db_record_recid(int _recid_18674)
{
    int _data_ptr_18675 = NOVALUE;
    int _data_value_18676 = NOVALUE;
    int _key_value_18677 = NOVALUE;
    int _10414 = NOVALUE;
    int _10413 = NOVALUE;
    int _10392 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18674)) {
        _1 = (long)(DBL_PTR(_recid_18674)->dbl);
        DeRefDS(_recid_18674);
        _recid_18674 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10414 = _18seek(_38current_db_16418, _recid_18674);
    DeRef(_10414);
    _10414 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18675;
    _data_ptr_18675 = _38get4();
    DeRef(_0);

    /** 	key_value = decompress(0)*/
    _0 = _key_value_18677;
    _key_value_18677 = _38decompress(0);
    DeRef(_0);

    /** 	seek(current_db, data_ptr)*/
    Ref(_data_ptr_18675);
    _10413 = _18seek(_38current_db_16418, _data_ptr_18675);
    DeRef(_10413);
    _10413 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_18676;
    _data_value_18676 = _38decompress(0);
    DeRef(_0);

    /** 	return {key_value, data_value}*/
    Ref(_data_value_18676);
    Ref(_key_value_18677);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_value_18677;
    ((int *)_2)[2] = _data_value_18676;
    _10392 = MAKE_SEQ(_1);
    DeRef(_data_ptr_18675);
    DeRef(_data_value_18676);
    DeRef(_key_value_18677);
    return _10392;
    ;
}
int db_record_recid() __attribute__ ((alias ("_38db_record_recid")));


int _38db_get_recid(int _key_18686, int _table_name_18687)
{
    int _lo_18688 = NOVALUE;
    int _hi_18689 = NOVALUE;
    int _mid_18690 = NOVALUE;
    int _c_18691 = NOVALUE;
    int _10412 = NOVALUE;
    int _10406 = NOVALUE;
    int _10405 = NOVALUE;
    int _10403 = NOVALUE;
    int _10400 = NOVALUE;
    int _10398 = NOVALUE;
    int _10395 = NOVALUE;
    int _10393 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18687 == _38current_table_name_16420)
    _10393 = 1;
    else if (IS_ATOM_INT(_table_name_18687) && IS_ATOM_INT(_38current_table_name_16420))
    _10393 = 0;
    else
    _10393 = (compare(_table_name_18687, _38current_table_name_16420) == 0);
    if (_10393 != 0)
    goto L1; // [9] 42
    _10393 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18687);
    _10395 = _38db_select_table(_table_name_18687);
    if (binary_op_a(EQUALS, _10395, 0)){
        DeRef(_10395);
        _10395 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10395);
    _10395 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_get_recid", {key, table_name})*/
    Ref(_table_name_18687);
    Ref(_key_18686);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18686;
    ((int *)_2)[2] = _table_name_18687;
    _10398 = MAKE_SEQ(_1);
    RefDS(_10089);
    RefDS(_10397);
    _38fatal(903, _10089, _10397, _10398);
    _10398 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18686);
    DeRef(_table_name_18687);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16419, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_get_recid", {key, table_name})*/
    Ref(_table_name_18687);
    Ref(_key_18686);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18686;
    ((int *)_2)[2] = _table_name_18687;
    _10400 = MAKE_SEQ(_1);
    RefDS(_10093);
    RefDS(_10397);
    _38fatal(903, _10093, _10397, _10400);
    _10400 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18686);
    DeRef(_table_name_18687);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18688 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16425)){
            _hi_18689 = SEQ_PTR(_38key_pointers_16425)->length;
    }
    else {
        _hi_18689 = 1;
    }

    /** 	mid = 1*/
    _mid_18690 = 1;

    /** 	c = 0*/
    _c_18691 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18688 > _hi_18689)
    goto L5; // [96] 176

    /** 		mid = floor((lo + hi) / 2)*/
    _10403 = _lo_18688 + _hi_18689;
    if ((long)((unsigned long)_10403 + (unsigned long)HIGH_BITS) >= 0) 
    _10403 = NewDouble((double)_10403);
    if (IS_ATOM_INT(_10403)) {
        _mid_18690 = _10403 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10403, 2);
        _mid_18690 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10403);
    _10403 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18690)) {
        _1 = (long)(DBL_PTR(_mid_18690)->dbl);
        DeRefDS(_mid_18690);
        _mid_18690 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10405 = (int)*(((s1_ptr)_2)->base + _mid_18690);
    Ref(_10405);
    _10406 = _38key_value(_10405);
    _10405 = NOVALUE;
    if (IS_ATOM_INT(_key_18686) && IS_ATOM_INT(_10406)){
        _c_18691 = (_key_18686 < _10406) ? -1 : (_key_18686 > _10406);
    }
    else{
        _c_18691 = compare(_key_18686, _10406);
    }
    DeRef(_10406);
    _10406 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18691 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18689 = _mid_18690 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18691 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18688 = _mid_18690 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return key_pointers[mid]*/
    _2 = (int)SEQ_PTR(_38key_pointers_16425);
    _10412 = (int)*(((s1_ptr)_2)->base + _mid_18690);
    Ref(_10412);
    DeRef(_key_18686);
    DeRef(_table_name_18687);
    return _10412;

    /** 	end while*/
    goto L4; // [173] 96
L5: 

    /** 	return -1*/
    DeRef(_key_18686);
    DeRef(_table_name_18687);
    _10412 = NOVALUE;
    return -1;
    ;
}
int db_get_recid() __attribute__ ((alias ("_38db_get_recid")));



// 0xBC3D34D9
