// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _18get_bytes(int _fn_2373, int _n_2374)
{
    int _s_2375 = NOVALUE;
    int _c_2376 = NOVALUE;
    int _first_2377 = NOVALUE;
    int _last_2378 = NOVALUE;
    int _1151 = NOVALUE;
    int _1148 = NOVALUE;
    int _1146 = NOVALUE;
    int _1145 = NOVALUE;
    int _1144 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_2373)) {
        _1 = (long)(DBL_PTR(_fn_2373)->dbl);
        DeRefDS(_fn_2373);
        _fn_2373 = _1;
    }
    if (!IS_ATOM_INT(_n_2374)) {
        _1 = (long)(DBL_PTR(_n_2374)->dbl);
        DeRefDS(_n_2374);
        _n_2374 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_2374 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2375);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_2373 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_2373, EF_READ);
        last_r_file_no = _fn_2373;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_2376 = getc((FILE*)xstdin);
        }
        else
        _c_2376 = getc(last_r_file_ptr);
    }
    else
    _c_2376 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_2376 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_2375);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_2375);
    _s_2375 = Repeat(_c_2376, _n_2374);

    /** 	last = 1*/
    _last_2378 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_2378 >= _n_2374)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_2377 = _last_2378 + 1;

    /** 		last  = last+CHUNK*/
    _last_2378 = _last_2378 + 100;

    /** 		if last > n then*/
    if (_last_2378 <= _n_2374)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_2378 = _n_2374;
L5: 

    /** 		for i = first to last do*/
    _1144 = _last_2378;
    {
        int _i_2392;
        _i_2392 = _first_2377;
L6: 
        if (_i_2392 > _1144){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_2373 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_2373, EF_READ);
            last_r_file_no = _fn_2373;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _1145 = getc((FILE*)xstdin);
            }
            else
            _1145 = getc(last_r_file_ptr);
        }
        else
        _1145 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_2375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_2375 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2392);
        *(int *)_2 = _1145;
        if( _1 != _1145 ){
        }
        _1145 = NOVALUE;

        /** 		end for*/
        _i_2392 = _i_2392 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_2375);
    _1146 = (int)*(((s1_ptr)_2)->base + _last_2378);
    if (_1146 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_2375);
    _1148 = (int)*(((s1_ptr)_2)->base + _last_2378);
    if (_1148 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_2378 = _last_2378 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_1151;
    RHS_Slice(_s_2375, 1, _last_2378);
    DeRefDSi(_s_2375);
    _1146 = NOVALUE;
    _1148 = NOVALUE;
    return _1151;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _1146 = NOVALUE;
    _1148 = NOVALUE;
    DeRef(_1151);
    _1151 = NOVALUE;
    return _s_2375;
    ;
}
int get_bytes() __attribute__ ((alias ("_18get_bytes")));


int _18get_integer32(int _fh_2413)
{
    int _1160 = NOVALUE;
    int _1159 = NOVALUE;
    int _1158 = NOVALUE;
    int _1157 = NOVALUE;
    int _1156 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2413)) {
        _1 = (long)(DBL_PTR(_fh_2413)->dbl);
        DeRefDS(_fh_2413);
        _fh_2413 = _1;
    }

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2413 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2413, EF_READ);
        last_r_file_no = _fh_2413;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1156 = getc((FILE*)xstdin);
        }
        else
        _1156 = getc(last_r_file_ptr);
    }
    else
    _1156 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2403)){
        poke_addr = (unsigned char *)_18mem0_2403;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
    }
    *poke_addr = (unsigned char)_1156;
    _1156 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2413 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2413, EF_READ);
        last_r_file_no = _fh_2413;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1157 = getc((FILE*)xstdin);
        }
        else
        _1157 = getc(last_r_file_ptr);
    }
    else
    _1157 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2404)){
        poke_addr = (unsigned char *)_18mem1_2404;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2404)->dbl);
    }
    *poke_addr = (unsigned char)_1157;
    _1157 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_2413 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2413, EF_READ);
        last_r_file_no = _fh_2413;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1158 = getc((FILE*)xstdin);
        }
        else
        _1158 = getc(last_r_file_ptr);
    }
    else
    _1158 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem2_2405)){
        poke_addr = (unsigned char *)_18mem2_2405;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem2_2405)->dbl);
    }
    *poke_addr = (unsigned char)_1158;
    _1158 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_2413 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2413, EF_READ);
        last_r_file_no = _fh_2413;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1159 = getc((FILE*)xstdin);
        }
        else
        _1159 = getc(last_r_file_ptr);
    }
    else
    _1159 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem3_2406)){
        poke_addr = (unsigned char *)_18mem3_2406;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem3_2406)->dbl);
    }
    *poke_addr = (unsigned char)_1159;
    _1159 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2403)) {
        _1160 = *(unsigned long *)_18mem0_2403;
        if ((unsigned)_1160 > (unsigned)MAXINT)
        _1160 = NewDouble((double)(unsigned long)_1160);
    }
    else {
        _1160 = *(unsigned long *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
        if ((unsigned)_1160 > (unsigned)MAXINT)
        _1160 = NewDouble((double)(unsigned long)_1160);
    }
    return _1160;
    ;
}
int get_integer32() __attribute__ ((alias ("_18get_integer32")));


int _18get_integer16(int _fh_2421)
{
    int _1163 = NOVALUE;
    int _1162 = NOVALUE;
    int _1161 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2421)) {
        _1 = (long)(DBL_PTR(_fh_2421)->dbl);
        DeRefDS(_fh_2421);
        _fh_2421 = _1;
    }

    /** 	poke(mem0, getc(fh))*/
    if (_fh_2421 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2421, EF_READ);
        last_r_file_no = _fh_2421;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1161 = getc((FILE*)xstdin);
        }
        else
        _1161 = getc(last_r_file_ptr);
    }
    else
    _1161 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem0_2403)){
        poke_addr = (unsigned char *)_18mem0_2403;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
    }
    *poke_addr = (unsigned char)_1161;
    _1161 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_2421 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2421, EF_READ);
        last_r_file_no = _fh_2421;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _1162 = getc((FILE*)xstdin);
        }
        else
        _1162 = getc(last_r_file_ptr);
    }
    else
    _1162 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_18mem1_2404)){
        poke_addr = (unsigned char *)_18mem1_2404;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_18mem1_2404)->dbl);
    }
    *poke_addr = (unsigned char)_1162;
    _1162 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_18mem0_2403)) {
        _1163 = *(unsigned short *)_18mem0_2403;
    }
    else {
        _1163 = *(unsigned short *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
    }
    return _1163;
    ;
}
int get_integer16() __attribute__ ((alias ("_18get_integer16")));


void _18put_integer32(int _fh_2427, int _val_2428)
{
    int _1165 = NOVALUE;
    int _1164 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2427)) {
        _1 = (long)(DBL_PTR(_fh_2427)->dbl);
        DeRefDS(_fh_2427);
        _fh_2427 = _1;
    }

    /** 	poke4(mem0, val)*/
    if (IS_ATOM_INT(_18mem0_2403)){
        poke4_addr = (unsigned long *)_18mem0_2403;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
    }
    if (IS_ATOM_INT(_val_2428)) {
        *poke4_addr = (unsigned long)_val_2428;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_val_2428)->dbl;
    }

    /** 	puts(fh, peek({mem0,4}))*/
    Ref(_18mem0_2403);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _18mem0_2403;
    ((int *)_2)[2] = 4;
    _1164 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1164);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1165 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1164);
    _1164 = NOVALUE;
    EPuts(_fh_2427, _1165); // DJP 
    DeRefDS(_1165);
    _1165 = NOVALUE;

    /** end procedure*/
    DeRef(_val_2428);
    return;
    ;
}
void put_integer32() __attribute__ ((alias ("_18put_integer32")));


void _18put_integer16(int _fh_2433, int _val_2434)
{
    int _1167 = NOVALUE;
    int _1166 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2433)) {
        _1 = (long)(DBL_PTR(_fh_2433)->dbl);
        DeRefDS(_fh_2433);
        _fh_2433 = _1;
    }

    /** 	poke2(mem0, val)*/
    if (IS_ATOM_INT(_18mem0_2403)){
        poke2_addr = (unsigned short *)_18mem0_2403;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_18mem0_2403)->dbl);
    }
    if (IS_ATOM_INT(_val_2434)) {
        *poke2_addr = (unsigned short)_val_2434;
    }
    else {
        *poke_addr = (signed char)DBL_PTR(_val_2434)->dbl;
    }

    /** 	puts(fh, peek({mem0,2}))*/
    Ref(_18mem0_2403);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _18mem0_2403;
    ((int *)_2)[2] = 2;
    _1166 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1166);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1167 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1166);
    _1166 = NOVALUE;
    EPuts(_fh_2433, _1167); // DJP 
    DeRefDS(_1167);
    _1167 = NOVALUE;

    /** end procedure*/
    DeRef(_val_2434);
    return;
    ;
}
void put_integer16() __attribute__ ((alias ("_18put_integer16")));


int _18get_dstring(int _fh_2439, int _delim_2440)
{
    int _s_2441 = NOVALUE;
    int _c_2442 = NOVALUE;
    int _i_2443 = NOVALUE;
    int _1177 = NOVALUE;
    int _1173 = NOVALUE;
    int _1171 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_2439)) {
        _1 = (long)(DBL_PTR(_fh_2439)->dbl);
        DeRefDS(_fh_2439);
        _fh_2439 = _1;
    }
    if (!IS_ATOM_INT(_delim_2440)) {
        _1 = (long)(DBL_PTR(_delim_2440)->dbl);
        DeRefDS(_delim_2440);
        _delim_2440 = _1;
    }

    /** 	s = repeat(-1, 256)*/
    DeRefi(_s_2441);
    _s_2441 = Repeat(-1, 256);

    /** 	i = 0*/
    _i_2443 = 0;

    /** 	while c != delim with entry do*/
    goto L1; // [18] 73
L2: 
    if (_c_2442 == _delim_2440)
    goto L3; // [23] 83

    /** 		i += 1*/
    _i_2443 = _i_2443 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_2441)){
            _1171 = SEQ_PTR(_s_2441)->length;
    }
    else {
        _1171 = 1;
    }
    if (_i_2443 <= _1171)
    goto L4; // [38] 53

    /** 			s &= repeat(-1, 256)*/
    _1173 = Repeat(-1, 256);
    Concat((object_ptr)&_s_2441, _s_2441, _1173);
    DeRefDS(_1173);
    _1173 = NOVALUE;
L4: 

    /** 		if c = -1 then*/
    if (_c_2442 != -1)
    goto L5; // [55] 64

    /** 			exit*/
    goto L3; // [61] 83
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_2441);
    _2 = (int)(((s1_ptr)_2)->base + _i_2443);
    *(int *)_2 = _c_2442;

    /** 	  entry*/
L1: 

    /** 		c = getc(fh)*/
    if (_fh_2439 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_2439, EF_READ);
        last_r_file_no = _fh_2439;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_2442 = getc((FILE*)xstdin);
        }
        else
        _c_2442 = getc(last_r_file_ptr);
    }
    else
    _c_2442 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [80] 21
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_1177;
    RHS_Slice(_s_2441, 1, _i_2443);
    DeRefDSi(_s_2441);
    return _1177;
    ;
}
int get_dstring() __attribute__ ((alias ("_18get_dstring")));


int _18file_number(int _f_2461)
{
    int _1180 = NOVALUE;
    int _1179 = NOVALUE;
    int _1178 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(f) and f >= 0 then*/
    if (IS_ATOM_INT(_f_2461))
    _1178 = 1;
    else if (IS_ATOM_DBL(_f_2461))
    _1178 = IS_ATOM_INT(DoubleToInt(_f_2461));
    else
    _1178 = 0;
    if (_1178 == 0) {
        goto L1; // [6] 27
    }
    if (IS_ATOM_INT(_f_2461)) {
        _1180 = (_f_2461 >= 0);
    }
    else {
        _1180 = binary_op(GREATEREQ, _f_2461, 0);
    }
    if (_1180 == 0) {
        DeRef(_1180);
        _1180 = NOVALUE;
        goto L1; // [15] 27
    }
    else {
        if (!IS_ATOM_INT(_1180) && DBL_PTR(_1180)->dbl == 0.0){
            DeRef(_1180);
            _1180 = NOVALUE;
            goto L1; // [15] 27
        }
        DeRef(_1180);
        _1180 = NOVALUE;
    }
    DeRef(_1180);
    _1180 = NOVALUE;

    /** 		return 1*/
    DeRef(_f_2461);
    return 1;
    goto L2; // [24] 34
L1: 

    /** 		return 0*/
    DeRef(_f_2461);
    return 0;
L2: 
    ;
}
int file_number() __attribute__ ((alias ("_18file_number")));


int _18file_position(int _p_2469)
{
    int _1183 = NOVALUE;
    int _1182 = NOVALUE;
    int _1181 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(p) and p >= -1 then*/
    _1181 = IS_ATOM(_p_2469);
    if (_1181 == 0) {
        goto L1; // [6] 27
    }
    if (IS_ATOM_INT(_p_2469)) {
        _1183 = (_p_2469 >= -1);
    }
    else {
        _1183 = binary_op(GREATEREQ, _p_2469, -1);
    }
    if (_1183 == 0) {
        DeRef(_1183);
        _1183 = NOVALUE;
        goto L1; // [15] 27
    }
    else {
        if (!IS_ATOM_INT(_1183) && DBL_PTR(_1183)->dbl == 0.0){
            DeRef(_1183);
            _1183 = NOVALUE;
            goto L1; // [15] 27
        }
        DeRef(_1183);
        _1183 = NOVALUE;
    }
    DeRef(_1183);
    _1183 = NOVALUE;

    /** 		return 1*/
    DeRef(_p_2469);
    return 1;
    goto L2; // [24] 34
L1: 

    /** 		return 0*/
    DeRef(_p_2469);
    return 0;
L2: 
    ;
}
int file_position() __attribute__ ((alias ("_18file_position")));


int _18lock_type(int _t_2477)
{
    int _1188 = NOVALUE;
    int _1187 = NOVALUE;
    int _1186 = NOVALUE;
    int _1185 = NOVALUE;
    int _1184 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(t) and (t = LOCK_SHARED or t = LOCK_EXCLUSIVE) then*/
    if (IS_ATOM_INT(_t_2477))
    _1184 = 1;
    else if (IS_ATOM_DBL(_t_2477))
    _1184 = IS_ATOM_INT(DoubleToInt(_t_2477));
    else
    _1184 = 0;
    if (_1184 == 0) {
        goto L1; // [6] 39
    }
    if (IS_ATOM_INT(_t_2477)) {
        _1186 = (_t_2477 == 1);
    }
    else {
        _1186 = binary_op(EQUALS, _t_2477, 1);
    }
    if (IS_ATOM_INT(_1186)) {
        if (_1186 != 0) {
            _1187 = 1;
            goto L2; // [14] 26
        }
    }
    else {
        if (DBL_PTR(_1186)->dbl != 0.0) {
            _1187 = 1;
            goto L2; // [14] 26
        }
    }
    if (IS_ATOM_INT(_t_2477)) {
        _1188 = (_t_2477 == 2);
    }
    else {
        _1188 = binary_op(EQUALS, _t_2477, 2);
    }
    DeRef(_1187);
    if (IS_ATOM_INT(_1188))
    _1187 = (_1188 != 0);
    else
    _1187 = DBL_PTR(_1188)->dbl != 0.0;
L2: 
    if (_1187 == 0)
    {
        _1187 = NOVALUE;
        goto L1; // [27] 39
    }
    else{
        _1187 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_t_2477);
    DeRef(_1186);
    _1186 = NOVALUE;
    DeRef(_1188);
    _1188 = NOVALUE;
    return 1;
    goto L3; // [36] 46
L1: 

    /** 		return 0*/
    DeRef(_t_2477);
    DeRef(_1186);
    _1186 = NOVALUE;
    DeRef(_1188);
    _1188 = NOVALUE;
    return 0;
L3: 
    ;
}
int lock_type() __attribute__ ((alias ("_18lock_type")));


int _18byte_range(int _r_2487)
{
    int _1207 = NOVALUE;
    int _1206 = NOVALUE;
    int _1205 = NOVALUE;
    int _1204 = NOVALUE;
    int _1203 = NOVALUE;
    int _1201 = NOVALUE;
    int _1200 = NOVALUE;
    int _1198 = NOVALUE;
    int _1197 = NOVALUE;
    int _1196 = NOVALUE;
    int _1195 = NOVALUE;
    int _1194 = NOVALUE;
    int _1192 = NOVALUE;
    int _1190 = NOVALUE;
    int _1189 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(r) then*/
    _1189 = IS_ATOM(_r_2487);
    if (_1189 == 0)
    {
        _1189 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1189 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_r_2487);
    return 0;
L1: 

    /** 	if length(r) = 0 then*/
    if (IS_SEQUENCE(_r_2487)){
            _1190 = SEQ_PTR(_r_2487)->length;
    }
    else {
        _1190 = 1;
    }
    if (_1190 != 0)
    goto L2; // [21] 32

    /** 		return 1*/
    DeRef(_r_2487);
    return 1;
L2: 

    /** 	if length(r) != 2 then*/
    if (IS_SEQUENCE(_r_2487)){
            _1192 = SEQ_PTR(_r_2487)->length;
    }
    else {
        _1192 = 1;
    }
    if (_1192 == 2)
    goto L3; // [37] 48

    /** 		return 0*/
    DeRef(_r_2487);
    return 0;
L3: 

    /** 	if not (atom(r[1]) and atom(r[2])) then*/
    _2 = (int)SEQ_PTR(_r_2487);
    _1194 = (int)*(((s1_ptr)_2)->base + 1);
    _1195 = IS_ATOM(_1194);
    _1194 = NOVALUE;
    if (_1195 == 0) {
        DeRef(_1196);
        _1196 = 0;
        goto L4; // [57] 72
    }
    _2 = (int)SEQ_PTR(_r_2487);
    _1197 = (int)*(((s1_ptr)_2)->base + 2);
    _1198 = IS_ATOM(_1197);
    _1197 = NOVALUE;
    _1196 = (_1198 != 0);
L4: 
    if (_1196 != 0)
    goto L5; // [72] 82
    _1196 = NOVALUE;

    /** 		return 0*/
    DeRef(_r_2487);
    return 0;
L5: 

    /** 	if r[1] < 0 or r[2] < 0 then*/
    _2 = (int)SEQ_PTR(_r_2487);
    _1200 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1200)) {
        _1201 = (_1200 < 0);
    }
    else {
        _1201 = binary_op(LESS, _1200, 0);
    }
    _1200 = NOVALUE;
    if (IS_ATOM_INT(_1201)) {
        if (_1201 != 0) {
            goto L6; // [92] 109
        }
    }
    else {
        if (DBL_PTR(_1201)->dbl != 0.0) {
            goto L6; // [92] 109
        }
    }
    _2 = (int)SEQ_PTR(_r_2487);
    _1203 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1203)) {
        _1204 = (_1203 < 0);
    }
    else {
        _1204 = binary_op(LESS, _1203, 0);
    }
    _1203 = NOVALUE;
    if (_1204 == 0) {
        DeRef(_1204);
        _1204 = NOVALUE;
        goto L7; // [105] 116
    }
    else {
        if (!IS_ATOM_INT(_1204) && DBL_PTR(_1204)->dbl == 0.0){
            DeRef(_1204);
            _1204 = NOVALUE;
            goto L7; // [105] 116
        }
        DeRef(_1204);
        _1204 = NOVALUE;
    }
    DeRef(_1204);
    _1204 = NOVALUE;
L6: 

    /** 		return 0*/
    DeRef(_r_2487);
    DeRef(_1201);
    _1201 = NOVALUE;
    return 0;
L7: 

    /** 	return r[1] <= r[2]*/
    _2 = (int)SEQ_PTR(_r_2487);
    _1205 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_r_2487);
    _1206 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1205) && IS_ATOM_INT(_1206)) {
        _1207 = (_1205 <= _1206);
    }
    else {
        _1207 = binary_op(LESSEQ, _1205, _1206);
    }
    _1205 = NOVALUE;
    _1206 = NOVALUE;
    DeRef(_r_2487);
    DeRef(_1201);
    _1201 = NOVALUE;
    return _1207;
    ;
}
int byte_range() __attribute__ ((alias ("_18byte_range")));


int _18seek(int _fn_2514, int _pos_2515)
{
    int _1209 = NOVALUE;
    int _1208 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_2515);
    Ref(_fn_2514);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2514;
    ((int *)_2)[2] = _pos_2515;
    _1208 = MAKE_SEQ(_1);
    _1209 = machine(19, _1208);
    DeRefDS(_1208);
    _1208 = NOVALUE;
    DeRef(_fn_2514);
    DeRef(_pos_2515);
    return _1209;
    ;
}
int seek() __attribute__ ((alias ("_18seek")));


int _18where(int _fn_2520)
{
    int _1210 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _1210 = machine(20, _fn_2520);
    DeRef(_fn_2520);
    return _1210;
    ;
}
int where() __attribute__ ((alias ("_18where")));


void _18flush(int _fn_2524)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_FLUSH, fn)*/
    machine(60, _fn_2524);

    /** end procedure*/
    DeRef(_fn_2524);
    return;
    ;
}
void flush() __attribute__ ((alias ("_18flush")));


int _18lock_file(int _fn_2527, int _t_2528, int _r_2529)
{
    int _1212 = NOVALUE;
    int _1211 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_2527);
    *((int *)(_2+4)) = _fn_2527;
    Ref(_t_2528);
    *((int *)(_2+8)) = _t_2528;
    Ref(_r_2529);
    *((int *)(_2+12)) = _r_2529;
    _1211 = MAKE_SEQ(_1);
    _1212 = machine(61, _1211);
    DeRefDS(_1211);
    _1211 = NOVALUE;
    DeRef(_fn_2527);
    DeRef(_t_2528);
    DeRef(_r_2529);
    return _1212;
    ;
}
int lock_file() __attribute__ ((alias ("_18lock_file")));


void _18unlock_file(int _fn_2534, int _r_2535)
{
    int _1213 = NOVALUE;
    int _0, _1, _2;
    

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    Ref(_r_2535);
    Ref(_fn_2534);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2534;
    ((int *)_2)[2] = _r_2535;
    _1213 = MAKE_SEQ(_1);
    machine(62, _1213);
    DeRefDS(_1213);
    _1213 = NOVALUE;

    /** end procedure*/
    DeRef(_fn_2534);
    DeRef(_r_2535);
    return;
    ;
}
void unlock_file() __attribute__ ((alias ("_18unlock_file")));


int _18read_lines(int _file_2539)
{
    int _fn_2540 = NOVALUE;
    int _ret_2541 = NOVALUE;
    int _y_2542 = NOVALUE;
    int _1240 = NOVALUE;
    int _1239 = NOVALUE;
    int _1238 = NOVALUE;
    int _1237 = NOVALUE;
    int _1232 = NOVALUE;
    int _1231 = NOVALUE;
    int _1229 = NOVALUE;
    int _1228 = NOVALUE;
    int _1227 = NOVALUE;
    int _1225 = NOVALUE;
    int _1224 = NOVALUE;
    int _1222 = NOVALUE;
    int _1221 = NOVALUE;
    int _1220 = NOVALUE;
    int _1215 = NOVALUE;
    int _1214 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1214 = IS_SEQUENCE(_file_2539);
    if (_1214 == 0)
    {
        _1214 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _1214 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_2539)){
            _1215 = SEQ_PTR(_file_2539)->length;
    }
    else {
        _1215 = 1;
    }
    if (_1215 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_2540);
    _fn_2540 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_2540);
    _fn_2540 = EOpen(_file_2539, _1217, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_2539);
    DeRef(_fn_2540);
    _fn_2540 = _file_2539;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2540, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_2539);
    DeRef(_fn_2540);
    DeRef(_ret_2541);
    DeRefi(_y_2542);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_2541);
    _ret_2541 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 162
L6: 
    _1220 = IS_SEQUENCE(_y_2542);
    if (_1220 == 0)
    {
        _1220 = NOVALUE;
        goto L7; // [71] 172
    }
    else{
        _1220 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_2542)){
            _1221 = SEQ_PTR(_y_2542)->length;
    }
    else {
        _1221 = 1;
    }
    _2 = (int)SEQ_PTR(_y_2542);
    _1222 = (int)*(((s1_ptr)_2)->base + _1221);
    if (_1222 != 10)
    goto L8; // [83] 141

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_2542)){
            _1224 = SEQ_PTR(_y_2542)->length;
    }
    else {
        _1224 = 1;
    }
    _1225 = _1224 - 1;
    _1224 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_2542;
    RHS_Slice(_y_2542, 1, _1225);

    /** 			ifdef UNIX then*/

    /** 				if length(y) then*/
    if (IS_SEQUENCE(_y_2542)){
            _1227 = SEQ_PTR(_y_2542)->length;
    }
    else {
        _1227 = 1;
    }
    if (_1227 == 0)
    {
        _1227 = NOVALUE;
        goto L9; // [108] 140
    }
    else{
        _1227 = NOVALUE;
    }

    /** 					if y[$] = '\r' then*/
    if (IS_SEQUENCE(_y_2542)){
            _1228 = SEQ_PTR(_y_2542)->length;
    }
    else {
        _1228 = 1;
    }
    _2 = (int)SEQ_PTR(_y_2542);
    _1229 = (int)*(((s1_ptr)_2)->base + _1228);
    if (_1229 != 13)
    goto LA; // [120] 139

    /** 						y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_2542)){
            _1231 = SEQ_PTR(_y_2542)->length;
    }
    else {
        _1231 = 1;
    }
    _1232 = _1231 - 1;
    _1231 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_2542;
    RHS_Slice(_y_2542, 1, _1232);
LA: 
L9: 
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_2542);
    Append(&_ret_2541, _ret_2541, _y_2542);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_2540, 0)){
        goto LB; // [149] 159
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
LB: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_2542);
    _y_2542 = EGets(_fn_2540);

    /** 	end while*/
    goto L6; // [169] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _1237 = IS_SEQUENCE(_file_2539);
    if (_1237 == 0) {
        goto LC; // [177] 197
    }
    if (IS_SEQUENCE(_file_2539)){
            _1239 = SEQ_PTR(_file_2539)->length;
    }
    else {
        _1239 = 1;
    }
    _1240 = (_1239 != 0);
    _1239 = NOVALUE;
    if (_1240 == 0)
    {
        DeRef(_1240);
        _1240 = NOVALUE;
        goto LC; // [189] 197
    }
    else{
        DeRef(_1240);
        _1240 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2540))
    EClose(_fn_2540);
    else
    EClose((int)DBL_PTR(_fn_2540)->dbl);
LC: 

    /** 	return ret*/
    DeRef(_file_2539);
    DeRef(_fn_2540);
    DeRefi(_y_2542);
    _1222 = NOVALUE;
    DeRef(_1225);
    _1225 = NOVALUE;
    _1229 = NOVALUE;
    DeRef(_1232);
    _1232 = NOVALUE;
    return _ret_2541;
    ;
}
int read_lines() __attribute__ ((alias ("_18read_lines")));


int _18process_lines(int _file_2583, int _proc_2584, int _user_data_2585)
{
    int _fh_2586 = NOVALUE;
    int _aLine_2587 = NOVALUE;
    int _res_2588 = NOVALUE;
    int _line_no_2589 = NOVALUE;
    int _1270 = NOVALUE;
    int _1269 = NOVALUE;
    int _1268 = NOVALUE;
    int _1267 = NOVALUE;
    int _1264 = NOVALUE;
    int _1262 = NOVALUE;
    int _1260 = NOVALUE;
    int _1259 = NOVALUE;
    int _1257 = NOVALUE;
    int _1256 = NOVALUE;
    int _1255 = NOVALUE;
    int _1253 = NOVALUE;
    int _1252 = NOVALUE;
    int _1250 = NOVALUE;
    int _1249 = NOVALUE;
    int _1248 = NOVALUE;
    int _1246 = NOVALUE;
    int _1242 = NOVALUE;
    int _1241 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_2584)) {
        _1 = (long)(DBL_PTR(_proc_2584)->dbl);
        DeRefDS(_proc_2584);
        _proc_2584 = _1;
    }

    /** 	integer line_no = 0*/
    _line_no_2589 = 0;

    /** 	res = 0*/
    DeRef(_res_2588);
    _res_2588 = 0;

    /** 	if sequence(file) then*/
    _1241 = IS_SEQUENCE(_file_2583);
    if (_1241 == 0)
    {
        _1241 = NOVALUE;
        goto L1; // [18] 49
    }
    else{
        _1241 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_2583)){
            _1242 = SEQ_PTR(_file_2583)->length;
    }
    else {
        _1242 = 1;
    }
    if (_1242 != 0)
    goto L2; // [26] 38

    /** 			fh = 0*/
    _fh_2586 = 0;
    goto L3; // [35] 57
L2: 

    /** 			fh = open(file, "r")*/
    _fh_2586 = EOpen(_file_2583, _1217, 0);
    goto L3; // [46] 57
L1: 

    /** 		fh = file*/
    Ref(_file_2583);
    _fh_2586 = _file_2583;
    if (!IS_ATOM_INT(_fh_2586)) {
        _1 = (long)(DBL_PTR(_fh_2586)->dbl);
        DeRefDS(_fh_2586);
        _fh_2586 = _1;
    }
L3: 

    /** 	if fh < 0 then */
    if (_fh_2586 >= 0)
    goto L4; // [61] 196

    /** 		return -1 */
    DeRef(_file_2583);
    DeRef(_user_data_2585);
    DeRefi(_aLine_2587);
    DeRef(_res_2588);
    return -1;

    /** 	while sequence(aLine) with entry do*/
    goto L4; // [74] 196
L5: 
    _1246 = IS_SEQUENCE(_aLine_2587);
    if (_1246 == 0)
    {
        _1246 = NOVALUE;
        goto L6; // [82] 206
    }
    else{
        _1246 = NOVALUE;
    }

    /** 		line_no += 1*/
    _line_no_2589 = _line_no_2589 + 1;

    /** 		if length(aLine) then*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1248 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1248 = 1;
    }
    if (_1248 == 0)
    {
        _1248 = NOVALUE;
        goto L7; // [96] 167
    }
    else{
        _1248 = NOVALUE;
    }

    /** 			if aLine[$] = '\n' then*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1249 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1249 = 1;
    }
    _2 = (int)SEQ_PTR(_aLine_2587);
    _1250 = (int)*(((s1_ptr)_2)->base + _1249);
    if (_1250 != 10)
    goto L8; // [108] 166

    /** 				aLine = aLine[1 .. $-1]*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1252 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1252 = 1;
    }
    _1253 = _1252 - 1;
    _1252 = NOVALUE;
    rhs_slice_target = (object_ptr)&_aLine_2587;
    RHS_Slice(_aLine_2587, 1, _1253);

    /** 				ifdef UNIX then*/

    /** 					if length(aLine) then*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1255 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1255 = 1;
    }
    if (_1255 == 0)
    {
        _1255 = NOVALUE;
        goto L9; // [133] 165
    }
    else{
        _1255 = NOVALUE;
    }

    /** 						if aLine[$] = '\r' then*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1256 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1256 = 1;
    }
    _2 = (int)SEQ_PTR(_aLine_2587);
    _1257 = (int)*(((s1_ptr)_2)->base + _1256);
    if (_1257 != 13)
    goto LA; // [145] 164

    /** 							aLine = aLine[1 .. $-1]*/
    if (IS_SEQUENCE(_aLine_2587)){
            _1259 = SEQ_PTR(_aLine_2587)->length;
    }
    else {
        _1259 = 1;
    }
    _1260 = _1259 - 1;
    _1259 = NOVALUE;
    rhs_slice_target = (object_ptr)&_aLine_2587;
    RHS_Slice(_aLine_2587, 1, _1260);
LA: 
L9: 
L8: 
L7: 

    /** 		res = call_func(proc, {aLine, line_no, user_data})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_aLine_2587);
    *((int *)(_2+4)) = _aLine_2587;
    *((int *)(_2+8)) = _line_no_2589;
    Ref(_user_data_2585);
    *((int *)(_2+12)) = _user_data_2585;
    _1262 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_1262);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_proc_2584].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4), 
                        *(int *)(_2+8), 
                        *(int *)(_2+12)
                         );
    DeRef(_res_2588);
    _res_2588 = _1;
    DeRefDS(_1262);
    _1262 = NOVALUE;

    /** 		if not equal(res, 0) then*/
    if (_res_2588 == 0)
    _1264 = 1;
    else if (IS_ATOM_INT(_res_2588) && IS_ATOM_INT(0))
    _1264 = 0;
    else
    _1264 = (compare(_res_2588, 0) == 0);
    if (_1264 != 0)
    goto LB; // [185] 193
    _1264 = NOVALUE;

    /** 			exit*/
    goto L6; // [190] 206
LB: 

    /** 	entry*/
L4: 

    /** 		aLine = gets(fh)*/
    DeRefi(_aLine_2587);
    _aLine_2587 = EGets(_fh_2586);

    /** 	end while*/
    goto L5; // [203] 77
L6: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _1267 = IS_SEQUENCE(_file_2583);
    if (_1267 == 0) {
        goto LC; // [211] 231
    }
    if (IS_SEQUENCE(_file_2583)){
            _1269 = SEQ_PTR(_file_2583)->length;
    }
    else {
        _1269 = 1;
    }
    _1270 = (_1269 != 0);
    _1269 = NOVALUE;
    if (_1270 == 0)
    {
        DeRef(_1270);
        _1270 = NOVALUE;
        goto LC; // [223] 231
    }
    else{
        DeRef(_1270);
        _1270 = NOVALUE;
    }

    /** 		close(fh)*/
    EClose(_fh_2586);
LC: 

    /** 	return res*/
    DeRef(_file_2583);
    DeRef(_user_data_2585);
    DeRefi(_aLine_2587);
    _1250 = NOVALUE;
    DeRef(_1253);
    _1253 = NOVALUE;
    _1257 = NOVALUE;
    DeRef(_1260);
    _1260 = NOVALUE;
    return _res_2588;
    ;
}
int process_lines() __attribute__ ((alias ("_18process_lines")));


int _18write_lines(int _file_2634, int _lines_2635)
{
    int _fn_2636 = NOVALUE;
    int _1277 = NOVALUE;
    int _1276 = NOVALUE;
    int _1275 = NOVALUE;
    int _1271 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _1271 = IS_SEQUENCE(_file_2634);
    if (_1271 == 0)
    {
        _1271 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _1271 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_2636);
    _fn_2636 = EOpen(_file_2634, _1272, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_2634);
    DeRef(_fn_2636);
    _fn_2636 = _file_2634;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_2636, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_2634);
    DeRefDS(_lines_2635);
    DeRef(_fn_2636);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_2635)){
            _1275 = SEQ_PTR(_lines_2635)->length;
    }
    else {
        _1275 = 1;
    }
    {
        int _i_2645;
        _i_2645 = 1;
L4: 
        if (_i_2645 > _1275){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_2635);
        _1276 = (int)*(((s1_ptr)_2)->base + _i_2645);
        EPuts(_fn_2636, _1276); // DJP 
        _1276 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_2636, 10); // DJP 

        /** 	end for*/
        _i_2645 = _i_2645 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _1277 = IS_SEQUENCE(_file_2634);
    if (_1277 == 0)
    {
        _1277 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _1277 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_2636))
    EClose(_fn_2636);
    else
    EClose((int)DBL_PTR(_fn_2636)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_2634);
    DeRefDS(_lines_2635);
    DeRef(_fn_2636);
    return 1;
    ;
}
int write_lines() __attribute__ ((alias ("_18write_lines")));


int _18append_lines(int _file_2652, int _lines_2653)
{
    int _fn_2654 = NOVALUE;
    int _1282 = NOVALUE;
    int _1281 = NOVALUE;
    int _0, _1, _2;
    

    /**   	fn = open(file, "a")*/
    _fn_2654 = EOpen(_file_2652, _1278, 0);

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2654 >= 0)
    goto L1; // [14] 23
    DeRefDS(_file_2652);
    DeRefDS(_lines_2653);
    return -1;
L1: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_2653)){
            _1281 = SEQ_PTR(_lines_2653)->length;
    }
    else {
        _1281 = 1;
    }
    {
        int _i_2660;
        _i_2660 = 1;
L2: 
        if (_i_2660 > _1281){
            goto L3; // [28] 56
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_2653);
        _1282 = (int)*(((s1_ptr)_2)->base + _i_2660);
        EPuts(_fn_2654, _1282); // DJP 
        _1282 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_2654, 10); // DJP 

        /** 	end for*/
        _i_2660 = _i_2660 + 1;
        goto L2; // [51] 35
L3: 
        ;
    }

    /** 	close(fn)*/
    EClose(_fn_2654);

    /** 	return 1*/
    DeRefDS(_file_2652);
    DeRefDS(_lines_2653);
    return 1;
    ;
}
int append_lines() __attribute__ ((alias ("_18append_lines")));


int _18read_file(int _file_2669, int _as_text_2670)
{
    int _fn_2671 = NOVALUE;
    int _len_2672 = NOVALUE;
    int _ret_2673 = NOVALUE;
    int _seek_1__tmp_at43_2683 = NOVALUE;
    int _seek_inlined_seek_at_43_2682 = NOVALUE;
    int _where_inlined_where_at_58_2685 = NOVALUE;
    int _seek_1__tmp_at67_2688 = NOVALUE;
    int _seek_inlined_seek_at_67_2687 = NOVALUE;
    int _1302 = NOVALUE;
    int _1301 = NOVALUE;
    int _1299 = NOVALUE;
    int _1294 = NOVALUE;
    int _1290 = NOVALUE;
    int _1289 = NOVALUE;
    int _1288 = NOVALUE;
    int _1283 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_as_text_2670)) {
        _1 = (long)(DBL_PTR(_as_text_2670)->dbl);
        DeRefDS(_as_text_2670);
        _as_text_2670 = _1;
    }

    /** 	if sequence(file) then*/
    _1283 = IS_SEQUENCE(_file_2669);
    if (_1283 == 0)
    {
        _1283 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _1283 = NOVALUE;
    }

    /** 		fn = open(file, "rb")*/
    _fn_2671 = EOpen(_file_2669, _1284, 0);
    goto L2; // [18] 29
L1: 

    /** 		fn = file*/
    Ref(_file_2669);
    _fn_2671 = _file_2669;
    if (!IS_ATOM_INT(_fn_2671)) {
        _1 = (long)(DBL_PTR(_fn_2671)->dbl);
        DeRefDS(_fn_2671);
        _fn_2671 = _1;
    }
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2671 >= 0)
    goto L3; // [33] 42
    DeRef(_file_2669);
    DeRef(_ret_2673);
    return -1;
L3: 

    /** 	seek(fn, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at43_2683);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2671;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at43_2683 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_43_2682 = machine(19, _seek_1__tmp_at43_2683);
    DeRefi(_seek_1__tmp_at43_2683);
    _seek_1__tmp_at43_2683 = NOVALUE;

    /** 	len = where(fn)*/

    /** 	return machine_func(M_WHERE, fn)*/
    _len_2672 = machine(20, _fn_2671);

    /** 	seek(fn, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at67_2688);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_2671;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at67_2688 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_67_2687 = machine(19, _seek_1__tmp_at67_2688);
    DeRefi(_seek_1__tmp_at67_2688);
    _seek_1__tmp_at67_2688 = NOVALUE;

    /** 	ret = repeat(0, len)*/
    DeRef(_ret_2673);
    _ret_2673 = Repeat(0, _len_2672);

    /** 	for i = 1 to len do*/
    _1288 = _len_2672;
    {
        int _i_2691;
        _i_2691 = 1;
L4: 
        if (_i_2691 > _1288){
            goto L5; // [92] 115
        }

        /** 		ret[i] = getc(fn)*/
        if (_fn_2671 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_2671, EF_READ);
            last_r_file_no = _fn_2671;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _1289 = getc((FILE*)xstdin);
            }
            else
            _1289 = getc(last_r_file_ptr);
        }
        else
        _1289 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_ret_2673);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_2673 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2691);
        _1 = *(int *)_2;
        *(int *)_2 = _1289;
        if( _1 != _1289 ){
            DeRef(_1);
        }
        _1289 = NOVALUE;

        /** 	end for*/
        _i_2691 = _i_2691 + 1;
        goto L4; // [110] 99
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _1290 = IS_SEQUENCE(_file_2669);
    if (_1290 == 0)
    {
        _1290 = NOVALUE;
        goto L6; // [120] 128
    }
    else{
        _1290 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_2671);
L6: 

    /** 	ifdef WINDOWS then*/

    /** 	if as_text = BINARY_MODE then*/
    if (_as_text_2670 != 1)
    goto L7; // [132] 143

    /** 		return ret*/
    DeRef(_file_2669);
    return _ret_2673;
L7: 

    /** 	fn = find(26, ret) -- Any Ctrl-Z found?*/
    _fn_2671 = find_from(26, _ret_2673, 1);

    /** 	if fn then*/
    if (_fn_2671 == 0)
    {
        goto L8; // [152] 167
    }
    else{
    }

    /** 		ret = ret[1 .. fn - 1]*/
    _1294 = _fn_2671 - 1;
    rhs_slice_target = (object_ptr)&_ret_2673;
    RHS_Slice(_ret_2673, 1, _1294);
L8: 

    /** 	ret = search:match_replace({13,10}, ret, {10})*/
    RefDS(_1296);
    RefDS(_ret_2673);
    RefDS(_1297);
    _0 = _ret_2673;
    _ret_2673 = _9match_replace(_1296, _ret_2673, _1297, 0);
    DeRefDS(_0);

    /** 	if length(ret) > 0 then*/
    if (IS_SEQUENCE(_ret_2673)){
            _1299 = SEQ_PTR(_ret_2673)->length;
    }
    else {
        _1299 = 1;
    }
    if (_1299 <= 0)
    goto L9; // [183] 210

    /** 		if ret[$] != 10 then*/
    if (IS_SEQUENCE(_ret_2673)){
            _1301 = SEQ_PTR(_ret_2673)->length;
    }
    else {
        _1301 = 1;
    }
    _2 = (int)SEQ_PTR(_ret_2673);
    _1302 = (int)*(((s1_ptr)_2)->base + _1301);
    if (binary_op_a(EQUALS, _1302, 10)){
        _1302 = NOVALUE;
        goto LA; // [196] 218
    }
    _1302 = NOVALUE;

    /** 			ret &= 10*/
    Append(&_ret_2673, _ret_2673, 10);
    goto LA; // [207] 218
L9: 

    /** 		ret = {10}*/
    RefDS(_1297);
    DeRef(_ret_2673);
    _ret_2673 = _1297;
LA: 

    /** 	return ret*/
    DeRef(_file_2669);
    DeRef(_1294);
    _1294 = NOVALUE;
    return _ret_2673;
    ;
}
int read_file() __attribute__ ((alias ("_18read_file")));


int _18write_file(int _file_2717, int _data_2718, int _as_text_2719)
{
    int _fn_2720 = NOVALUE;
    int _1328 = NOVALUE;
    int _1322 = NOVALUE;
    int _1312 = NOVALUE;
    int _1311 = NOVALUE;
    int _1309 = NOVALUE;
    int _1307 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_as_text_2719)) {
        _1 = (long)(DBL_PTR(_as_text_2719)->dbl);
        DeRefDS(_as_text_2719);
        _as_text_2719 = _1;
    }

    /** 	if as_text != BINARY_MODE then*/
    if (_as_text_2719 == 1)
    goto L1; // [7] 146

    /** 		fn = find(26, data)*/
    _fn_2720 = find_from(26, _data_2718, 1);

    /** 		if fn then*/
    if (_fn_2720 == 0)
    {
        goto L2; // [20] 35
    }
    else{
    }

    /** 			data = data[1 .. fn-1]*/
    _1307 = _fn_2720 - 1;
    rhs_slice_target = (object_ptr)&_data_2718;
    RHS_Slice(_data_2718, 1, _1307);
L2: 

    /** 		if length(data) > 0 then*/
    if (IS_SEQUENCE(_data_2718)){
            _1309 = SEQ_PTR(_data_2718)->length;
    }
    else {
        _1309 = 1;
    }
    if (_1309 <= 0)
    goto L3; // [40] 67

    /** 			if data[$] != 10 then*/
    if (IS_SEQUENCE(_data_2718)){
            _1311 = SEQ_PTR(_data_2718)->length;
    }
    else {
        _1311 = 1;
    }
    _2 = (int)SEQ_PTR(_data_2718);
    _1312 = (int)*(((s1_ptr)_2)->base + _1311);
    if (binary_op_a(EQUALS, _1312, 10)){
        _1312 = NOVALUE;
        goto L4; // [53] 75
    }
    _1312 = NOVALUE;

    /** 				data &= 10*/
    Append(&_data_2718, _data_2718, 10);
    goto L4; // [64] 75
L3: 

    /** 			data = {10}*/
    RefDS(_1297);
    DeRefDS(_data_2718);
    _data_2718 = _1297;
L4: 

    /** 		if as_text = TEXT_MODE then*/
    if (_as_text_2719 != 2)
    goto L5; // [77] 95

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1296);
    RefDS(_data_2718);
    RefDS(_1297);
    _0 = _data_2718;
    _data_2718 = _9match_replace(_1296, _data_2718, _1297, 0);
    DeRefDS(_0);
    goto L6; // [92] 145
L5: 

    /** 		elsif as_text = UNIX_TEXT then*/
    if (_as_text_2719 != 3)
    goto L7; // [97] 115

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1296);
    RefDS(_data_2718);
    RefDS(_1297);
    _0 = _data_2718;
    _data_2718 = _9match_replace(_1296, _data_2718, _1297, 0);
    DeRefDS(_0);
    goto L6; // [112] 145
L7: 

    /** 		elsif as_text = DOS_TEXT then*/
    if (_as_text_2719 != 4)
    goto L8; // [117] 144

    /** 			data = search:match_replace({13,10}, data, {10})*/
    RefDS(_1296);
    RefDS(_data_2718);
    RefDS(_1297);
    _0 = _data_2718;
    _data_2718 = _9match_replace(_1296, _data_2718, _1297, 0);
    DeRefDS(_0);

    /** 			data = search:match_replace({10}, data, {13,10})*/
    RefDS(_1297);
    RefDS(_data_2718);
    RefDS(_1296);
    _0 = _data_2718;
    _data_2718 = _9match_replace(_1297, _data_2718, _1296, 0);
    DeRefDS(_0);
L8: 
L6: 
L1: 

    /** 	if sequence(file) then*/
    _1322 = IS_SEQUENCE(_file_2717);
    if (_1322 == 0)
    {
        _1322 = NOVALUE;
        goto L9; // [151] 181
    }
    else{
        _1322 = NOVALUE;
    }

    /** 		if as_text = TEXT_MODE then*/
    if (_as_text_2719 != 2)
    goto LA; // [156] 170

    /** 			fn = open(file, "w")*/
    _fn_2720 = EOpen(_file_2717, _1272, 0);
    goto LB; // [167] 189
LA: 

    /** 			fn = open(file, "wb")*/
    _fn_2720 = EOpen(_file_2717, _1325, 0);
    goto LB; // [178] 189
L9: 

    /** 		fn = file*/
    Ref(_file_2717);
    _fn_2720 = _file_2717;
    if (!IS_ATOM_INT(_fn_2720)) {
        _1 = (long)(DBL_PTR(_fn_2720)->dbl);
        DeRefDS(_fn_2720);
        _fn_2720 = _1;
    }
LB: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_2720 >= 0)
    goto LC; // [193] 202
    DeRef(_file_2717);
    DeRefDS(_data_2718);
    DeRef(_1307);
    _1307 = NOVALUE;
    return -1;
LC: 

    /** 	puts(fn, data)*/
    EPuts(_fn_2720, _data_2718); // DJP 

    /** 	if sequence(file) then*/
    _1328 = IS_SEQUENCE(_file_2717);
    if (_1328 == 0)
    {
        _1328 = NOVALUE;
        goto LD; // [212] 220
    }
    else{
        _1328 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_2720);
LD: 

    /** 	return 1*/
    DeRef(_file_2717);
    DeRefDS(_data_2718);
    DeRef(_1307);
    _1307 = NOVALUE;
    return 1;
    ;
}
int write_file() __attribute__ ((alias ("_18write_file")));


void _18writef(int _fm_2761, int _data_2762, int _fn_2763, int _data_not_string_2764)
{
    int _real_fn_2765 = NOVALUE;
    int _close_fn_2766 = NOVALUE;
    int _out_style_2767 = NOVALUE;
    int _ts_2770 = NOVALUE;
    int _msg_inlined_crash_at_163_2795 = NOVALUE;
    int _data_inlined_crash_at_160_2794 = NOVALUE;
    int _1348 = NOVALUE;
    int _1346 = NOVALUE;
    int _1345 = NOVALUE;
    int _1344 = NOVALUE;
    int _1338 = NOVALUE;
    int _1337 = NOVALUE;
    int _1336 = NOVALUE;
    int _1335 = NOVALUE;
    int _1334 = NOVALUE;
    int _1333 = NOVALUE;
    int _1331 = NOVALUE;
    int _1330 = NOVALUE;
    int _1329 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_2765 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_2766 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_1272);
    DeRefi(_out_style_2767);
    _out_style_2767 = _1272;

    /** 	if integer(fm) then*/
    if (IS_ATOM_INT(_fm_2761))
    _1329 = 1;
    else if (IS_ATOM_DBL(_fm_2761))
    _1329 = IS_ATOM_INT(DoubleToInt(_fm_2761));
    else
    _1329 = 0;
    if (_1329 == 0)
    {
        _1329 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _1329 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    Ref(_fm_2761);
    DeRef(_ts_2770);
    _ts_2770 = _fm_2761;

    /** 		fm = data*/
    Ref(_data_2762);
    DeRef(_fm_2761);
    _fm_2761 = _data_2762;

    /** 		data = fn*/
    Ref(_fn_2763);
    DeRef(_data_2762);
    _data_2762 = _fn_2763;

    /** 		fn = ts*/
    Ref(_ts_2770);
    DeRef(_fn_2763);
    _fn_2763 = _ts_2770;
L1: 
    DeRef(_ts_2770);
    _ts_2770 = NOVALUE;

    /** 	if sequence(fn) then*/
    _1330 = IS_SEQUENCE(_fn_2763);
    if (_1330 == 0)
    {
        _1330 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _1330 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_2763)){
            _1331 = SEQ_PTR(_fn_2763)->length;
    }
    else {
        _1331 = 1;
    }
    if (_1331 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_2763);
    _1333 = (int)*(((s1_ptr)_2)->base + 1);
    _1334 = IS_SEQUENCE(_1333);
    _1333 = NOVALUE;
    if (_1334 == 0)
    {
        _1334 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _1334 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_2763);
    _1335 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1335 == 97)
    _1336 = 1;
    else if (IS_ATOM_INT(_1335) && IS_ATOM_INT(97))
    _1336 = 0;
    else
    _1336 = (compare(_1335, 97) == 0);
    _1335 = NOVALUE;
    if (_1336 == 0)
    {
        _1336 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _1336 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_1278);
    DeRefi(_out_style_2767);
    _out_style_2767 = _1278;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_2763);
    _1337 = (int)*(((s1_ptr)_2)->base + 2);
    if (_1337 == _1278)
    _1338 = 1;
    else if (IS_ATOM_INT(_1337) && IS_ATOM_INT(_1278))
    _1338 = 0;
    else
    _1338 = (compare(_1337, _1278) == 0);
    _1337 = NOVALUE;
    if (_1338 != 0)
    goto L7; // [113] 126
    _1338 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_1272);
    DeRefi(_out_style_2767);
    _out_style_2767 = _1272;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_1278);
    DeRefi(_out_style_2767);
    _out_style_2767 = _1278;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_2763;
    _2 = (int)SEQ_PTR(_fn_2763);
    _fn_2763 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_2763);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_2765 = EOpen(_fn_2763, _out_style_2767, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_2765 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_2763);
    *((int *)(_2+4)) = _fn_2763;
    _1344 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_2794);
    _data_inlined_crash_at_160_2794 = _1344;
    _1344 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_2795);
    _msg_inlined_crash_at_163_2795 = EPrintf(-9999999, _1343, _data_inlined_crash_at_160_2794);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_2795);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_2794);
    _data_inlined_crash_at_160_2794 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_2795);
    _msg_inlined_crash_at_163_2795 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_2766 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_2763);
    _real_fn_2765 = _fn_2763;
    if (!IS_ATOM_INT(_real_fn_2765)) {
        _1 = (long)(DBL_PTR(_real_fn_2765)->dbl);
        DeRefDS(_real_fn_2765);
        _real_fn_2765 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_2764 == 0)
    _1345 = 1;
    else if (IS_ATOM_INT(_data_not_string_2764) && IS_ATOM_INT(0))
    _1345 = 0;
    else
    _1345 = (compare(_data_not_string_2764, 0) == 0);
    if (_1345 == 0)
    {
        _1345 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _1345 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_2762);
    _1346 = _7t_display(_data_2762);
    if (_1346 == 0) {
        DeRef(_1346);
        _1346 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_1346) && DBL_PTR(_1346)->dbl == 0.0){
            DeRef(_1346);
            _1346 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_1346);
        _1346 = NOVALUE;
    }
    DeRef(_1346);
    _1346 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_2762;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_2762);
    *((int *)(_2+4)) = _data_2762;
    _data_2762 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_2761);
    Ref(_data_2762);
    _1348 = _6format(_fm_2761, _data_2762);
    EPuts(_real_fn_2765, _1348); // DJP 
    DeRef(_1348);
    _1348 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_2766 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_2765);
LD: 

    /** end procedure*/
    DeRef(_fm_2761);
    DeRef(_data_2762);
    DeRef(_fn_2763);
    DeRef(_data_not_string_2764);
    DeRefi(_out_style_2767);
    return;
    ;
}
void writef() __attribute__ ((alias ("_18writef")));


void _18writefln(int _fm_2807, int _data_2808, int _fn_2809, int _data_not_string_2810)
{
    int _1351 = NOVALUE;
    int _1350 = NOVALUE;
    int _1349 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(fm) then*/
    if (IS_ATOM_INT(_fm_2807))
    _1349 = 1;
    else if (IS_ATOM_DBL(_fm_2807))
    _1349 = IS_ATOM_INT(DoubleToInt(_fm_2807));
    else
    _1349 = 0;
    if (_1349 == 0)
    {
        _1349 = NOVALUE;
        goto L1; // [6] 24
    }
    else{
        _1349 = NOVALUE;
    }

    /** 		writef(data & '\n', fn, fm, data_not_string)*/
    if (IS_SEQUENCE(_data_2808) && IS_ATOM(10)) {
        Append(&_1350, _data_2808, 10);
    }
    else if (IS_ATOM(_data_2808) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_1350, _data_2808, 10);
    }
    Ref(_fn_2809);
    Ref(_fm_2807);
    Ref(_data_not_string_2810);
    _18writef(_1350, _fn_2809, _fm_2807, _data_not_string_2810);
    _1350 = NOVALUE;
    goto L2; // [21] 37
L1: 

    /** 		writef(fm & '\n', data, fn, data_not_string)*/
    if (IS_SEQUENCE(_fm_2807) && IS_ATOM(10)) {
        Append(&_1351, _fm_2807, 10);
    }
    else if (IS_ATOM(_fm_2807) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_1351, _fm_2807, 10);
    }
    Ref(_data_2808);
    Ref(_fn_2809);
    Ref(_data_not_string_2810);
    _18writef(_1351, _data_2808, _fn_2809, _data_not_string_2810);
    _1351 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_fm_2807);
    DeRef(_data_2808);
    DeRef(_fn_2809);
    DeRef(_data_not_string_2810);
    return;
    ;
}
void writefln() __attribute__ ((alias ("_18writefln")));



// 0xD59AF08F
