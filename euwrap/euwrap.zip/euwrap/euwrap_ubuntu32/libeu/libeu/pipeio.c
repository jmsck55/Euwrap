// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _46process(int _o_20636)
{
    int _11665 = NOVALUE;
    int _11664 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(o) then*/
    _11664 = IS_ATOM(_o_20636);
    if (_11664 == 0)
    {
        _11664 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _11664 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_o_20636);
    return 0;
L1: 

    /** 	if length(o) != 4 then*/
    if (IS_SEQUENCE(_o_20636)){
            _11665 = SEQ_PTR(_o_20636)->length;
    }
    else {
        _11665 = 1;
    }
    if (_11665 == 4)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_o_20636);
    return 0;
L2: 

    /** 	return 1*/
    DeRef(_o_20636);
    return 1;
    ;
}
int process() __attribute__ ((alias ("_46process")));


int _46close(int _fd_20644)
{
    int _ret_20645 = NOVALUE;
    int _get_errno_inlined_get_errno_at_25_20651 = NOVALUE;
    int _11667 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		ret=c_func(CLOSE, {fd})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_20644);
    *((int *)(_2+4)) = _fd_20644;
    _11667 = MAKE_SEQ(_1);
    DeRef(_ret_20645);
    _ret_20645 = call_c(1, _46CLOSE_20590, _11667);
    DeRefDS(_11667);
    _11667 = NOVALUE;

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_20645, -1)){
        goto L1; // [20] 43
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 		return -1*/
    DeRef(_fd_20644);
    DeRef(_ret_20645);
    return -1;
L1: 

    /** 	return 0*/
    DeRef(_fd_20644);
    DeRef(_ret_20645);
    return 0;
    ;
}


void _46kill(int _p_20654, int _signal_20655)
{
    int _11678 = NOVALUE;
    int _11677 = NOVALUE;
    int _11676 = NOVALUE;
    int _11675 = NOVALUE;
    int _11674 = NOVALUE;
    int _11673 = NOVALUE;
    int _11672 = NOVALUE;
    int _11671 = NOVALUE;
    int _11670 = NOVALUE;
    int _0, _1, _2;
    

    /** 	close(p[STDIN])*/
    _2 = (int)SEQ_PTR(_p_20654);
    _11670 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11670);
    _11671 = _46close(_11670);
    _11670 = NOVALUE;

    /** 	close(p[STDOUT])*/
    _2 = (int)SEQ_PTR(_p_20654);
    _11672 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11672);
    _11673 = _46close(_11672);
    _11672 = NOVALUE;

    /** 	close(p[STDERR])*/
    _2 = (int)SEQ_PTR(_p_20654);
    _11674 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_11674);
    _11675 = _46close(_11674);
    _11674 = NOVALUE;

    /** 	ifdef WINDOWS then*/

    /** 		c_func(KILL, {p[PID], signal})*/
    _2 = (int)SEQ_PTR(_p_20654);
    _11676 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_signal_20655);
    Ref(_11676);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11676;
    ((int *)_2)[2] = _signal_20655;
    _11677 = MAKE_SEQ(_1);
    _11676 = NOVALUE;
    _11678 = call_c(1, _46KILL_20598, _11677);
    DeRefDS(_11677);
    _11677 = NOVALUE;

    /** end procedure*/
    DeRef(_p_20654);
    DeRef(_signal_20655);
    DeRef(_11678);
    _11678 = NOVALUE;
    DeRef(_11671);
    _11671 = NOVALUE;
    DeRef(_11673);
    _11673 = NOVALUE;
    DeRef(_11675);
    _11675 = NOVALUE;
    return;
    ;
}
void kill() __attribute__ ((alias ("_46kill")));


int _46os_pipe()
{
    int _get_errno_inlined_get_errno_at_48_20678 = NOVALUE;
    int _handles_20667 = NOVALUE;
    int _ret_20668 = NOVALUE;
    int _cmd_20669 = NOVALUE;
    int _11682 = NOVALUE;
    int _11680 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		atom cmd = machine:allocate(8)*/
    _0 = _cmd_20669;
    _cmd_20669 = _14allocate(8, 0);
    DeRef(_0);

    /** 		ret = c_func(PIPE,{cmd})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_cmd_20669);
    *((int *)(_2+4)) = _cmd_20669;
    _11680 = MAKE_SEQ(_1);
    DeRef(_ret_20668);
    _ret_20668 = call_c(1, _46PIPE_20578, _11680);
    DeRefDS(_11680);
    _11680 = NOVALUE;

    /** 		handles = peek4u({cmd,2})*/
    Ref(_cmd_20669);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_20669;
    ((int *)_2)[2] = 2;
    _11682 = MAKE_SEQ(_1);
    DeRef(_handles_20667);
    _1 = (int)SEQ_PTR(_11682);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _handles_20667 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_11682);
    _11682 = NOVALUE;

    /** 		machine:free(cmd)*/
    Ref(_cmd_20669);
    _14free(_cmd_20669);

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_20668, -1)){
        goto L1; // [43] 66
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 		return -1*/
    DeRef(_handles_20667);
    DeRef(_ret_20668);
    DeRef(_cmd_20669);
    return -1;
L1: 

    /** 	return handles*/
    DeRef(_ret_20668);
    DeRef(_cmd_20669);
    return _handles_20667;
    ;
}


int _46read(int _fd_20681, int _bytes_20682)
{
    int _data_20685 = NOVALUE;
    int _ret_20686 = NOVALUE;
    int _ReadCount_20687 = NOVALUE;
    int _buf_20688 = NOVALUE;
    int _get_errno_inlined_get_errno_at_56_20696 = NOVALUE;
    int _11690 = NOVALUE;
    int _11687 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_bytes_20682)) {
        _1 = (long)(DBL_PTR(_bytes_20682)->dbl);
        DeRefDS(_bytes_20682);
        _bytes_20682 = _1;
    }

    /** 	if bytes=0 then return "" end if*/
    if (_bytes_20682 != 0)
    goto L1; // [5] 14
    RefDS(_5);
    DeRef(_fd_20681);
    DeRefi(_data_20685);
    DeRef(_ret_20686);
    DeRef(_ReadCount_20687);
    DeRef(_buf_20688);
    return _5;
L1: 

    /** 	sequence data*/

    /** 	atom*/

    /** 		buf = allocate(bytes)*/
    _0 = _buf_20688;
    _buf_20688 = _14allocate(_bytes_20682, 0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		ret = c_func(READ, {fd, buf, bytes})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_20681);
    *((int *)(_2+4)) = _fd_20681;
    Ref(_buf_20688);
    *((int *)(_2+8)) = _buf_20688;
    *((int *)(_2+12)) = _bytes_20682;
    _11687 = MAKE_SEQ(_1);
    DeRef(_ret_20686);
    _ret_20686 = call_c(1, _46READ_20582, _11687);
    DeRefDS(_11687);
    _11687 = NOVALUE;

    /** 		ReadCount=ret*/
    Ref(_ret_20686);
    DeRef(_ReadCount_20687);
    _ReadCount_20687 = _ret_20686;

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_20686, -1)){
        goto L2; // [51] 79
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 		machine:free(buf)*/
    Ref(_buf_20688);
    _14free(_buf_20688);

    /** 		return ""*/
    RefDS(_5);
    DeRef(_fd_20681);
    DeRefi(_data_20685);
    DeRef(_ret_20686);
    DeRef(_ReadCount_20687);
    DeRef(_buf_20688);
    return _5;
L2: 

    /** 	data=peek({buf,ReadCount})*/
    Ref(_ReadCount_20687);
    Ref(_buf_20688);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _buf_20688;
    ((int *)_2)[2] = _ReadCount_20687;
    _11690 = MAKE_SEQ(_1);
    DeRefi(_data_20685);
    _1 = (int)SEQ_PTR(_11690);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _data_20685 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_11690);
    _11690 = NOVALUE;

    /** 	machine:free(buf)*/
    Ref(_buf_20688);
    _14free(_buf_20688);

    /** 	return data*/
    DeRef(_fd_20681);
    DeRef(_ret_20686);
    DeRef(_ReadCount_20687);
    DeRef(_buf_20688);
    return _data_20685;
    ;
}
int read() __attribute__ ((alias ("_46read")));


int _46write(int _fd_20701, int _str_20702)
{
    int _buf_20703 = NOVALUE;
    int _ret_20706 = NOVALUE;
    int _WrittenCount_20707 = NOVALUE;
    int _get_errno_inlined_get_errno_at_49_20714 = NOVALUE;
    int _11694 = NOVALUE;
    int _11693 = NOVALUE;
    int _0, _1, _2;
    

    /** 		buf = allocate_string(str),*/
    RefDS(_str_20702);
    _0 = _buf_20703;
    _buf_20703 = _14allocate_string(_str_20702, 0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		ret = c_func(WRITE, {fd, buf, length(str)})*/
    if (IS_SEQUENCE(_str_20702)){
            _11693 = SEQ_PTR(_str_20702)->length;
    }
    else {
        _11693 = 1;
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fd_20701);
    *((int *)(_2+4)) = _fd_20701;
    Ref(_buf_20703);
    *((int *)(_2+8)) = _buf_20703;
    *((int *)(_2+12)) = _11693;
    _11694 = MAKE_SEQ(_1);
    _11693 = NOVALUE;
    DeRef(_ret_20706);
    _ret_20706 = call_c(1, _46WRITE_20586, _11694);
    DeRefDS(_11694);
    _11694 = NOVALUE;

    /** 		WrittenCount=ret*/
    Ref(_ret_20706);
    DeRef(_WrittenCount_20707);
    _WrittenCount_20707 = _ret_20706;

    /** 	machine:free(buf)*/
    Ref(_buf_20703);
    _14free(_buf_20703);

    /** 	if ret = FAIL then*/
    if (binary_op_a(NOTEQ, _ret_20706, -1)){
        goto L1; // [44] 67
    }

    /** 		os_errno = get_errno()*/

    /** 	ifdef WINDOWS then*/

    /** 		return peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 		return -1*/
    DeRef(_fd_20701);
    DeRefDS(_str_20702);
    DeRef(_buf_20703);
    DeRef(_ret_20706);
    DeRef(_WrittenCount_20707);
    return -1;
L1: 

    /** 	return WrittenCount*/
    DeRef(_fd_20701);
    DeRefDS(_str_20702);
    DeRef(_buf_20703);
    DeRef(_ret_20706);
    return _WrittenCount_20707;
    ;
}
int write() __attribute__ ((alias ("_46write")));


void _46error()
{
    int _msg_inlined_crash_at_11_20721 = NOVALUE;
    int _fmt_inlined_crash_at_8_20720 = NOVALUE;
    int _11698 = NOVALUE;
    int _0, _1, _2;
    

    /**     error:crash(sprintf("Errno = %d", os_errno))*/
    _11698 = EPrintf(-9999999, _11697, _46os_errno_20630);
    DeRefi(_fmt_inlined_crash_at_8_20720);
    _fmt_inlined_crash_at_8_20720 = _11698;
    _11698 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_11_20721);
    _msg_inlined_crash_at_11_20721 = EPrintf(-9999999, _fmt_inlined_crash_at_8_20720, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_11_20721);

    /** end procedure*/
    goto L1; // [27] 30
L1: 
    DeRefi(_fmt_inlined_crash_at_8_20720);
    _fmt_inlined_crash_at_8_20720 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_11_20721);
    _msg_inlined_crash_at_11_20721 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _46error_no()
{
    int _0, _1, _2;
    

    /** 	return os_errno*/
    Ref(_46os_errno_20630);
    return _46os_errno_20630;
    ;
}
int error_no() __attribute__ ((alias ("_46error_no")));


int _46os_dup2(int _oldfd_20726, int _newfd_20727)
{
    int _r_20728 = NOVALUE;
    int _11699 = NOVALUE;
    int _0, _1, _2;
    

    /** 		atom r = c_func(DUP2, {oldfd, newfd})*/
    Ref(_oldfd_20726);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _oldfd_20726;
    ((int *)_2)[2] = _newfd_20727;
    _11699 = MAKE_SEQ(_1);
    DeRef(_r_20728);
    _r_20728 = call_c(1, _46DUP2_20594, _11699);
    DeRefDS(_11699);
    _11699 = NOVALUE;

    /** 		if r = -1 then*/
    if (binary_op_a(NOTEQ, _r_20728, -1)){
        goto L1; // [16] 34
    }

    /** 			os_errno = peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 			return -1*/
    DeRef(_oldfd_20726);
    DeRef(_r_20728);
    return -1;
L1: 

    /** 		return r*/
    DeRef(_oldfd_20726);
    return _r_20728;
    ;
}


int _46os_fork()
{
    int _pid_20736 = NOVALUE;
    int _0, _1, _2;
    

    /** 		atom pid = c_func(FORK, {})*/
    DeRef(_pid_20736);
    _pid_20736 = call_c(1, _46FORK_20602, _5);

    /** 		if pid = -1 then*/
    if (binary_op_a(NOTEQ, _pid_20736, -1)){
        goto L1; // [12] 30
    }

    /** 			os_errno = peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 			return -1*/
    DeRef(_pid_20736);
    return -1;
L1: 

    /** 		return pid*/
    return _pid_20736;
    ;
}


int _46os_execv(int _s_20743, int _v_20744)
{
    int _sbuf_20745 = NOVALUE;
    int _vbuf_20746 = NOVALUE;
    int _vbufseq_20747 = NOVALUE;
    int _r_20748 = NOVALUE;
    int _11716 = NOVALUE;
    int _11714 = NOVALUE;
    int _11713 = NOVALUE;
    int _11710 = NOVALUE;
    int _11709 = NOVALUE;
    int _11708 = NOVALUE;
    int _0, _1, _2;
    

    /** 		sbuf = machine:allocate_string(s)*/
    RefDS(_s_20743);
    _0 = _sbuf_20745;
    _sbuf_20745 = _14allocate_string(_s_20743, 0);
    DeRef(_0);

    /** 		vbufseq = {sbuf}*/
    _0 = _vbufseq_20747;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sbuf_20745);
    *((int *)(_2+4)) = _sbuf_20745;
    _vbufseq_20747 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		for i = 1 to length(v) do*/
    _11708 = 2;
    {
        int _i_20752;
        _i_20752 = 1;
L1: 
        if (_i_20752 > 2){
            goto L2; // [23] 52
        }

        /** 			vbufseq &= machine:allocate_string(v[i])*/
        _2 = (int)SEQ_PTR(_v_20744);
        _11709 = (int)*(((s1_ptr)_2)->base + _i_20752);
        RefDS(_11709);
        _11710 = _14allocate_string(_11709, 0);
        _11709 = NOVALUE;
        if (IS_SEQUENCE(_vbufseq_20747) && IS_ATOM(_11710)) {
            Ref(_11710);
            Append(&_vbufseq_20747, _vbufseq_20747, _11710);
        }
        else if (IS_ATOM(_vbufseq_20747) && IS_SEQUENCE(_11710)) {
        }
        else {
            Concat((object_ptr)&_vbufseq_20747, _vbufseq_20747, _11710);
        }
        DeRef(_11710);
        _11710 = NOVALUE;

        /** 		end for*/
        _i_20752 = _i_20752 + 1;
        goto L1; // [47] 30
L2: 
        ;
    }

    /** 		vbufseq &= 0*/
    Append(&_vbufseq_20747, _vbufseq_20747, 0);

    /** 		vbuf = machine:allocate(length(vbufseq)*4)*/
    if (IS_SEQUENCE(_vbufseq_20747)){
            _11713 = SEQ_PTR(_vbufseq_20747)->length;
    }
    else {
        _11713 = 1;
    }
    if (_11713 == (short)_11713)
    _11714 = _11713 * 4;
    else
    _11714 = NewDouble(_11713 * (double)4);
    _11713 = NOVALUE;
    _0 = _vbuf_20746;
    _vbuf_20746 = _14allocate(_11714, 0);
    DeRef(_0);
    _11714 = NOVALUE;

    /** 		poke4(vbuf, vbufseq)*/
    if (IS_ATOM_INT(_vbuf_20746)){
        poke4_addr = (unsigned long *)_vbuf_20746;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_vbuf_20746)->dbl);
    }
    _1 = (int)SEQ_PTR(_vbufseq_20747);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    /** 		r = c_func(EXECV, {sbuf, vbuf})*/
    Ref(_vbuf_20746);
    Ref(_sbuf_20745);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sbuf_20745;
    ((int *)_2)[2] = _vbuf_20746;
    _11716 = MAKE_SEQ(_1);
    DeRef(_r_20748);
    _r_20748 = call_c(1, _46EXECV_20605, _11716);
    DeRefDS(_11716);
    _11716 = NOVALUE;

    /** 		os_errno = peek4u(ERRNO)*/
    DeRef(_46os_errno_20630);
    if (IS_ATOM_INT(_46ERRNO_20613)) {
        _46os_errno_20630 = *(unsigned long *)_46ERRNO_20613;
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }
    else {
        _46os_errno_20630 = *(unsigned long *)(unsigned long)(DBL_PTR(_46ERRNO_20613)->dbl);
        if ((unsigned)_46os_errno_20630 > (unsigned)MAXINT)
        _46os_errno_20630 = NewDouble((double)(unsigned long)_46os_errno_20630);
    }

    /** 		return -1*/
    DeRefDSi(_s_20743);
    DeRefDS(_v_20744);
    DeRef(_sbuf_20745);
    DeRef(_vbuf_20746);
    DeRefDS(_vbufseq_20747);
    DeRef(_r_20748);
    return -1;
    ;
}


int _46create()
{
    int _ipipe_20772 = NOVALUE;
    int _opipe_20773 = NOVALUE;
    int _epipe_20774 = NOVALUE;
    int _ret_20775 = NOVALUE;
    int _11747 = NOVALUE;
    int _11746 = NOVALUE;
    int _11745 = NOVALUE;
    int _11744 = NOVALUE;
    int _11743 = NOVALUE;
    int _11742 = NOVALUE;
    int _11741 = NOVALUE;
    int _11740 = NOVALUE;
    int _11739 = NOVALUE;
    int _11737 = NOVALUE;
    int _11735 = NOVALUE;
    int _11733 = NOVALUE;
    int _11731 = NOVALUE;
    int _11730 = NOVALUE;
    int _11727 = NOVALUE;
    int _11725 = NOVALUE;
    int _11724 = NOVALUE;
    int _11722 = NOVALUE;
    int _0, _1, _2;
    

    /** 		ipipe=os_pipe()*/
    _0 = _ipipe_20772;
    _ipipe_20772 = _46os_pipe();
    DeRef(_0);

    /** 		if atom(ipipe) then*/
    _11722 = IS_ATOM(_ipipe_20772);
    if (_11722 == 0)
    {
        _11722 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _11722 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_ipipe_20772);
    DeRef(_opipe_20773);
    DeRef(_epipe_20774);
    return -1;
L1: 

    /** 		opipe=os_pipe()*/
    _0 = _opipe_20773;
    _opipe_20773 = _46os_pipe();
    DeRef(_0);

    /** 		if atom(opipe) then*/
    _11724 = IS_ATOM(_opipe_20773);
    if (_11724 == 0)
    {
        _11724 = NOVALUE;
        goto L2; // [31] 65
    }
    else{
        _11724 = NOVALUE;
    }

    /** 			ret=close(ipipe[1])*/
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11725 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11725);
    _ret_20775 = _46close(_11725);
    _11725 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			ret=close(ipipe[2])*/
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11727 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11727);
    _ret_20775 = _46close(_11727);
    _11727 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			return -1*/
    DeRef(_ipipe_20772);
    DeRef(_opipe_20773);
    DeRef(_epipe_20774);
    return -1;
L2: 

    /** 	    epipe=os_pipe()*/
    _0 = _epipe_20774;
    _epipe_20774 = _46os_pipe();
    DeRef(_0);

    /** 		if atom(epipe) then*/
    _11730 = IS_ATOM(_epipe_20774);
    if (_11730 == 0)
    {
        _11730 = NOVALUE;
        goto L3; // [75] 133
    }
    else{
        _11730 = NOVALUE;
    }

    /** 			ret=close(ipipe[1])*/
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11731 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11731);
    _ret_20775 = _46close(_11731);
    _11731 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			ret=close(ipipe[2])*/
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11733 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11733);
    _ret_20775 = _46close(_11733);
    _11733 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			ret=close(opipe[1])*/
    _2 = (int)SEQ_PTR(_opipe_20773);
    _11735 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11735);
    _ret_20775 = _46close(_11735);
    _11735 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			ret=close(opipe[2])*/
    _2 = (int)SEQ_PTR(_opipe_20773);
    _11737 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11737);
    _ret_20775 = _46close(_11737);
    _11737 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20775)) {
        _1 = (long)(DBL_PTR(_ret_20775)->dbl);
        DeRefDS(_ret_20775);
        _ret_20775 = _1;
    }

    /** 			return -1*/
    DeRef(_ipipe_20772);
    DeRef(_opipe_20773);
    DeRef(_epipe_20774);
    return -1;
L3: 

    /** 	    return {{ipipe[2],opipe[1],epipe[1]},{ipipe[1],opipe[2],epipe[2]}}*/
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11739 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_opipe_20773);
    _11740 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_epipe_20774);
    _11741 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_11739);
    *((int *)(_2+4)) = _11739;
    Ref(_11740);
    *((int *)(_2+8)) = _11740;
    Ref(_11741);
    *((int *)(_2+12)) = _11741;
    _11742 = MAKE_SEQ(_1);
    _11741 = NOVALUE;
    _11740 = NOVALUE;
    _11739 = NOVALUE;
    _2 = (int)SEQ_PTR(_ipipe_20772);
    _11743 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_opipe_20773);
    _11744 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_epipe_20774);
    _11745 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_11743);
    *((int *)(_2+4)) = _11743;
    Ref(_11744);
    *((int *)(_2+8)) = _11744;
    Ref(_11745);
    *((int *)(_2+12)) = _11745;
    _11746 = MAKE_SEQ(_1);
    _11745 = NOVALUE;
    _11744 = NOVALUE;
    _11743 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11742;
    ((int *)_2)[2] = _11746;
    _11747 = MAKE_SEQ(_1);
    _11746 = NOVALUE;
    _11742 = NOVALUE;
    DeRef(_ipipe_20772);
    DeRef(_opipe_20773);
    DeRef(_epipe_20774);
    return _11747;
    ;
}


int _46exec_args(int _command_20808, int _args_20809, int _pipe_20810)
{
    int _pid_20811 = NOVALUE;
    int _ret_20812 = NOVALUE;
    int _p_20813 = NOVALUE;
    int _ipipe_20814 = NOVALUE;
    int _opipe_20815 = NOVALUE;
    int _epipe_20816 = NOVALUE;
    int _os_signal_1__tmp_at121_20843 = NOVALUE;
    int _os_signal_inlined_os_signal_at_121_20842 = NOVALUE;
    int _11807 = NOVALUE;
    int _11806 = NOVALUE;
    int _11804 = NOVALUE;
    int _11803 = NOVALUE;
    int _11801 = NOVALUE;
    int _11799 = NOVALUE;
    int _11798 = NOVALUE;
    int _11797 = NOVALUE;
    int _11795 = NOVALUE;
    int _11793 = NOVALUE;
    int _11791 = NOVALUE;
    int _11789 = NOVALUE;
    int _11787 = NOVALUE;
    int _11785 = NOVALUE;
    int _11781 = NOVALUE;
    int _11779 = NOVALUE;
    int _11777 = NOVALUE;
    int _11775 = NOVALUE;
    int _11773 = NOVALUE;
    int _11771 = NOVALUE;
    int _11769 = NOVALUE;
    int _11767 = NOVALUE;
    int _11765 = NOVALUE;
    int _11761 = NOVALUE;
    int _11760 = NOVALUE;
    int _11759 = NOVALUE;
    int _11758 = NOVALUE;
    int _11756 = NOVALUE;
    int _11755 = NOVALUE;
    int _11754 = NOVALUE;
    int _11753 = NOVALUE;
    int _11751 = NOVALUE;
    int _11750 = NOVALUE;
    int _11749 = NOVALUE;
    int _11748 = NOVALUE;
    int _0, _1, _2;
    

    /** 	    ipipe = pipe[2][1] & pipe[1][1]*/
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11748 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11748);
    _11749 = (int)*(((s1_ptr)_2)->base + 1);
    _11748 = NOVALUE;
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11750 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_11750);
    _11751 = (int)*(((s1_ptr)_2)->base + 1);
    _11750 = NOVALUE;
    if (IS_SEQUENCE(_11749) && IS_ATOM(_11751)) {
        Ref(_11751);
        Append(&_ipipe_20814, _11749, _11751);
    }
    else if (IS_ATOM(_11749) && IS_SEQUENCE(_11751)) {
        Ref(_11749);
        Prepend(&_ipipe_20814, _11751, _11749);
    }
    else {
        Concat((object_ptr)&_ipipe_20814, _11749, _11751);
        _11749 = NOVALUE;
    }
    _11749 = NOVALUE;
    _11751 = NOVALUE;

    /** 	    opipe = pipe[1][2] & pipe[2][2]*/
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11753 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_11753);
    _11754 = (int)*(((s1_ptr)_2)->base + 2);
    _11753 = NOVALUE;
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11755 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11755);
    _11756 = (int)*(((s1_ptr)_2)->base + 2);
    _11755 = NOVALUE;
    if (IS_SEQUENCE(_11754) && IS_ATOM(_11756)) {
        Ref(_11756);
        Append(&_opipe_20815, _11754, _11756);
    }
    else if (IS_ATOM(_11754) && IS_SEQUENCE(_11756)) {
        Ref(_11754);
        Prepend(&_opipe_20815, _11756, _11754);
    }
    else {
        Concat((object_ptr)&_opipe_20815, _11754, _11756);
        _11754 = NOVALUE;
    }
    _11754 = NOVALUE;
    _11756 = NOVALUE;

    /** 	    epipe = pipe[1][3] & pipe[2][3]*/
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11758 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_11758);
    _11759 = (int)*(((s1_ptr)_2)->base + 3);
    _11758 = NOVALUE;
    _2 = (int)SEQ_PTR(_pipe_20810);
    _11760 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11760);
    _11761 = (int)*(((s1_ptr)_2)->base + 3);
    _11760 = NOVALUE;
    if (IS_SEQUENCE(_11759) && IS_ATOM(_11761)) {
        Ref(_11761);
        Append(&_epipe_20816, _11759, _11761);
    }
    else if (IS_ATOM(_11759) && IS_SEQUENCE(_11761)) {
        Ref(_11759);
        Prepend(&_epipe_20816, _11761, _11759);
    }
    else {
        Concat((object_ptr)&_epipe_20816, _11759, _11761);
        _11759 = NOVALUE;
    }
    _11759 = NOVALUE;
    _11761 = NOVALUE;

    /** 	    pid=os_fork()*/
    _0 = _pid_20811;
    _pid_20811 = _46os_fork();
    DeRef(_0);

    /** 	    if pid=0 then*/
    if (binary_op_a(NOTEQ, _pid_20811, 0)){
        goto L1; // [80] 229
    }

    /** 			ret=close(ipipe[2])*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11765 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11765);
    _ret_20812 = _46close(_11765);
    _11765 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(opipe[1])*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11767 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11767);
    _ret_20812 = _46close(_11767);
    _11767 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(epipe[1])*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11769 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11769);
    _ret_20812 = _46close(_11769);
    _11769 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=os_signal(15, os_sig_dfl)*/

    /** 		return c_func(SIGNAL, {signal, handler})*/
    DeRefi(_os_signal_1__tmp_at121_20843);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 15;
    ((int *)_2)[2] = 0;
    _os_signal_1__tmp_at121_20843 = MAKE_SEQ(_1);
    _ret_20812 = call_c(1, _46SIGNAL_20609, _os_signal_1__tmp_at121_20843);
    DeRefi(_os_signal_1__tmp_at121_20843);
    _os_signal_1__tmp_at121_20843 = NOVALUE;

    /** 			ret=os_dup2(ipipe[1], os_stdin)*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11771 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11771);
    _ret_20812 = _46os_dup2(_11771, 0);
    _11771 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(ipipe[1])*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11773 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11773);
    _ret_20812 = _46close(_11773);
    _11773 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=os_dup2(opipe[2], os_stdout)*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11775 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11775);
    _ret_20812 = _46os_dup2(_11775, 1);
    _11775 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(opipe[2])*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11777 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11777);
    _ret_20812 = _46close(_11777);
    _11777 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=os_dup2(epipe[2], os_stderr)*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11779 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11779);
    _ret_20812 = _46os_dup2(_11779, 2);
    _11779 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(epipe[2])*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11781 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11781);
    _ret_20812 = _46close(_11781);
    _11781 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=os_execv(command,args)*/
    RefDS(_command_20808);
    RefDS(_args_20809);
    _ret_20812 = _46os_execv(_command_20808, _args_20809);
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			error()*/
    _46error();
    goto L2; // [226] 406
L1: 

    /** 	    elsif pid=-1 then*/
    if (binary_op_a(NOTEQ, _pid_20811, -1)){
        goto L3; // [231] 316
    }

    /** 			ret=close(ipipe[1])*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11785 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11785);
    _ret_20812 = _46close(_11785);
    _11785 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(ipipe[2])*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11787 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11787);
    _ret_20812 = _46close(_11787);
    _11787 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(opipe[1])*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11789 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11789);
    _ret_20812 = _46close(_11789);
    _11789 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(opipe[2])*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11791 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11791);
    _ret_20812 = _46close(_11791);
    _11791 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(epipe[1])*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11793 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11793);
    _ret_20812 = _46close(_11793);
    _11793 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(epipe[2])*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11795 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11795);
    _ret_20812 = _46close(_11795);
    _11795 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			return -1*/
    DeRefDSi(_command_20808);
    DeRefDS(_args_20809);
    DeRefDS(_pipe_20810);
    DeRef(_pid_20811);
    DeRef(_p_20813);
    DeRef(_ipipe_20814);
    DeRef(_opipe_20815);
    DeRef(_epipe_20816);
    return -1;
    goto L2; // [313] 406
L3: 

    /** 			p={ipipe[2], opipe[1], epipe[1], pid}*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11797 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11798 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11799 = (int)*(((s1_ptr)_2)->base + 1);
    _0 = _p_20813;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_11797);
    *((int *)(_2+4)) = _11797;
    Ref(_11798);
    *((int *)(_2+8)) = _11798;
    Ref(_11799);
    *((int *)(_2+12)) = _11799;
    Ref(_pid_20811);
    *((int *)(_2+16)) = _pid_20811;
    _p_20813 = MAKE_SEQ(_1);
    DeRef(_0);
    _11799 = NOVALUE;
    _11798 = NOVALUE;
    _11797 = NOVALUE;

    /** 			ret=close(ipipe[1])*/
    _2 = (int)SEQ_PTR(_ipipe_20814);
    _11801 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11801);
    _ret_20812 = _46close(_11801);
    _11801 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(opipe[2]) or ret*/
    _2 = (int)SEQ_PTR(_opipe_20815);
    _11803 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11803);
    _11804 = _46close(_11803);
    _11803 = NOVALUE;
    if (IS_ATOM_INT(_11804)) {
        _ret_20812 = (_11804 != 0 || _ret_20812 != 0);
    }
    else {
        _ret_20812 = binary_op(OR, _11804, _ret_20812);
    }
    DeRef(_11804);
    _11804 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			ret=close(epipe[2]) or ret*/
    _2 = (int)SEQ_PTR(_epipe_20816);
    _11806 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11806);
    _11807 = _46close(_11806);
    _11806 = NOVALUE;
    if (IS_ATOM_INT(_11807)) {
        _ret_20812 = (_11807 != 0 || _ret_20812 != 0);
    }
    else {
        _ret_20812 = binary_op(OR, _11807, _ret_20812);
    }
    DeRef(_11807);
    _11807 = NOVALUE;
    if (!IS_ATOM_INT(_ret_20812)) {
        _1 = (long)(DBL_PTR(_ret_20812)->dbl);
        DeRefDS(_ret_20812);
        _ret_20812 = _1;
    }

    /** 			if ret then*/
    if (_ret_20812 == 0)
    {
        goto L4; // [383] 399
    }
    else{
    }

    /** 				kill(p)*/
    RefDS(_p_20813);
    _46kill(_p_20813, 15);

    /** 				return -1*/
    DeRefDSi(_command_20808);
    DeRefDS(_args_20809);
    DeRefDS(_pipe_20810);
    DeRef(_pid_20811);
    DeRefDS(_p_20813);
    DeRef(_ipipe_20814);
    DeRef(_opipe_20815);
    DeRef(_epipe_20816);
    return -1;
L4: 

    /** 		    return p*/
    DeRefDSi(_command_20808);
    DeRefDS(_args_20809);
    DeRefDS(_pipe_20810);
    DeRef(_pid_20811);
    DeRef(_ipipe_20814);
    DeRef(_opipe_20815);
    DeRef(_epipe_20816);
    return _p_20813;
L2: 
    ;
}


int _46exec(int _cmd_20887, int _pipe_20888)
{
    int _11812 = NOVALUE;
    int _11811 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return exec_args("/bin/sh",{"-c", cmd}, pipe)*/
    RefDS(_cmd_20887);
    RefDS(_11810);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _11810;
    ((int *)_2)[2] = _cmd_20887;
    _11811 = MAKE_SEQ(_1);
    RefDS(_11809);
    RefDS(_pipe_20888);
    _11812 = _46exec_args(_11809, _11811, _pipe_20888);
    _11811 = NOVALUE;
    DeRefDS(_cmd_20887);
    DeRefDS(_pipe_20888);
    return _11812;
    ;
}
int exec() __attribute__ ((alias ("_46exec")));



// 0x80A45D3A
