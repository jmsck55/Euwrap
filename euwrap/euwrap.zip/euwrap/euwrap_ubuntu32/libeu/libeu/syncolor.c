// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _5set_colors(int _pColorList_10843)
{
    int _lColorName_10844 = NOVALUE;
    int _6140 = NOVALUE;
    int _6137 = NOVALUE;
    int _6134 = NOVALUE;
    int _6131 = NOVALUE;
    int _6128 = NOVALUE;
    int _6125 = NOVALUE;
    int _6122 = NOVALUE;
    int _6117 = NOVALUE;
    int _6116 = NOVALUE;
    int _6115 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(pColorList) do*/
    if (IS_SEQUENCE(_pColorList_10843)){
            _6115 = SEQ_PTR(_pColorList_10843)->length;
    }
    else {
        _6115 = 1;
    }
    {
        int _i_10846;
        _i_10846 = 1;
L1: 
        if (_i_10846 > _6115){
            goto L2; // [8] 168
        }

        /** 		lColorName = text:upper(pColorList[i][1])*/
        _2 = (int)SEQ_PTR(_pColorList_10843);
        _6116 = (int)*(((s1_ptr)_2)->base + _i_10846);
        _2 = (int)SEQ_PTR(_6116);
        _6117 = (int)*(((s1_ptr)_2)->base + 1);
        _6116 = NOVALUE;
        Ref(_6117);
        _0 = _lColorName_10844;
        _lColorName_10844 = _6upper(_6117);
        DeRef(_0);
        _6117 = NOVALUE;

        /** 		switch lColorName do*/
        _1 = find(_lColorName_10844, _6119);
        switch ( _1 ){ 

            /** 			case "NORMAL" then*/
            case 1:

            /** 				NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6122 = (int)*(((s1_ptr)_2)->base + _i_10846);
            _2 = (int)SEQ_PTR(_6122);
            _5NORMAL_COLOR_10820 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5NORMAL_COLOR_10820)){
                _5NORMAL_COLOR_10820 = (long)DBL_PTR(_5NORMAL_COLOR_10820)->dbl;
            }
            _6122 = NOVALUE;
            goto L3; // [54] 161

            /** 			case "COMMENT" then*/
            case 2:

            /** 				COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6125 = (int)*(((s1_ptr)_2)->base + _i_10846);
            _2 = (int)SEQ_PTR(_6125);
            _5COMMENT_COLOR_10821 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5COMMENT_COLOR_10821)){
                _5COMMENT_COLOR_10821 = (long)DBL_PTR(_5COMMENT_COLOR_10821)->dbl;
            }
            _6125 = NOVALUE;
            goto L3; // [72] 161

            /** 			case "KEYWORD" then*/
            case 3:

            /** 				KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6128 = (int)*(((s1_ptr)_2)->base + _i_10846);
            _2 = (int)SEQ_PTR(_6128);
            _5KEYWORD_COLOR_10822 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5KEYWORD_COLOR_10822)){
                _5KEYWORD_COLOR_10822 = (long)DBL_PTR(_5KEYWORD_COLOR_10822)->dbl;
            }
            _6128 = NOVALUE;
            goto L3; // [90] 161

            /** 			case "BUILTIN" then*/
            case 4:

            /** 				BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6131 = (int)*(((s1_ptr)_2)->base + _i_10846);
            _2 = (int)SEQ_PTR(_6131);
            _5BUILTIN_COLOR_10823 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5BUILTIN_COLOR_10823)){
                _5BUILTIN_COLOR_10823 = (long)DBL_PTR(_5BUILTIN_COLOR_10823)->dbl;
            }
            _6131 = NOVALUE;
            goto L3; // [108] 161

            /** 			case "STRING" then*/
            case 5:

            /** 				STRING_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6134 = (int)*(((s1_ptr)_2)->base + _i_10846);
            _2 = (int)SEQ_PTR(_6134);
            _5STRING_COLOR_10824 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5STRING_COLOR_10824)){
                _5STRING_COLOR_10824 = (long)DBL_PTR(_5STRING_COLOR_10824)->dbl;
            }
            _6134 = NOVALUE;
            goto L3; // [126] 161

            /** 			case "BRACKET" then*/
            case 6:

            /** 				BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_10843);
            _6137 = (int)*(((s1_ptr)_2)->base + _i_10846);
            DeRef(_5BRACKET_COLOR_10825);
            _2 = (int)SEQ_PTR(_6137);
            _5BRACKET_COLOR_10825 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_5BRACKET_COLOR_10825);
            _6137 = NOVALUE;
            goto L3; // [144] 161

            /** 			case else*/
            case 0:

            /** 				printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_lColorName_10844);
            *((int *)(_2+4)) = _lColorName_10844;
            _6140 = MAKE_SEQ(_1);
            EPrintf(2, _6139, _6140);
            DeRefDS(_6140);
            _6140 = NOVALUE;
        ;}L3: 

        /** 	end for*/
        _i_10846 = _i_10846 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_pColorList_10843);
    DeRef(_lColorName_10844);
    return;
    ;
}
void set_colors() __attribute__ ((alias ("_5set_colors")));


void _5init_class()
{
    int _0, _1, _2;
    

    /** 	NORMAL_COLOR  = #330033*/
    _5NORMAL_COLOR_10820 = 3342387;

    /** 	COMMENT_COLOR = #FF0055*/
    _5COMMENT_COLOR_10821 = 16711765;

    /** 	KEYWORD_COLOR = #0000FF*/
    _5KEYWORD_COLOR_10822 = 255;

    /** 	BUILTIN_COLOR = #FF00FF*/
    _5BUILTIN_COLOR_10823 = 16711935;

    /** 	STRING_COLOR  = #00A033*/
    _5STRING_COLOR_10824 = 41011;

    /** 	BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _5BRACKET_COLOR_10825;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3342387;
    *((int *)(_2+8)) = 10040115;
    *((int *)(_2+12)) = 255;
    *((int *)(_2+16)) = 5570815;
    *((int *)(_2+20)) = 65280;
    _5BRACKET_COLOR_10825 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	char_class = repeat(OTHER, 255)*/
    DeRefi(_5char_class_10840);
    _5char_class_10840 = Repeat(2, 255);

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_5char_class_10840;
    AssignSlice(97, 122, 3);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_5char_class_10840;
    AssignSlice(65, 90, 3);

    /** 	char_class['_'] = LETTER*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = 3;

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_5char_class_10840;
    AssignSlice(48, 57, 1);

    /** 	char_class['['] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = 4;

    /** 	char_class[']'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = 4;

    /** 	char_class['('] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = 4;

    /** 	char_class[')'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = 4;

    /** 	char_class['{'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = 4;

    /** 	char_class['}'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = 4;

    /** 	char_class['\''] = QUOTE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = 5;

    /** 	char_class['"'] = QUOTE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = 5;

    /** 	char_class['`'] = BACKTICK*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = 6;

    /** 	char_class[' '] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = 9;

    /** 	char_class['\t'] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = 9;

    /** 	char_class['\r'] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = 9;

    /** 	char_class['\n'] = NEW_LINE*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = 10;

    /** 	char_class['-'] = DASH*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 7;

    /** 	char_class['/'] = FORWARD_SLASH*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 8;

    /** end procedure*/
    return;
    ;
}
void init_class() __attribute__ ((alias ("_5init_class")));


void _5seg_flush(int _new_color_10899)
{
    int _6154 = NOVALUE;
    int _6153 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_color_10899)) {
        _1 = (long)(DBL_PTR(_new_color_10899)->dbl);
        DeRefDS(_new_color_10899);
        _new_color_10899 = _1;
    }

    /** 	if new_color != current_color then*/
    if (_new_color_10899 == _5current_color_10894)
    goto L1; // [7] 70

    /** 		if seg_start <= seg_end then*/
    if (_5seg_start_10895 > _5seg_end_10896)
    goto L2; // [17] 64

    /** 			if current_color != DONT_CARE then*/
    if (_5current_color_10894 == -1)
    goto L3; // [25] 63

    /** 				color_segments = append(color_segments,*/
    rhs_slice_target = (object_ptr)&_6153;
    RHS_Slice(_5line_10892, _5seg_start_10895, _5seg_end_10896);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5current_color_10894;
    ((int *)_2)[2] = _6153;
    _6154 = MAKE_SEQ(_1);
    _6153 = NOVALUE;
    RefDS(_6154);
    Append(&_5color_segments_10893, _5color_segments_10893, _6154);
    DeRefDS(_6154);
    _6154 = NOVALUE;

    /** 				seg_start = seg_end + 1*/
    _5seg_start_10895 = _5seg_end_10896 + 1;
L3: 
L2: 

    /** 		current_color = new_color*/
    _5current_color_10894 = _new_color_10899;
L1: 

    /** end procedure*/
    return;
    ;
}


int _5default_state()
{
    int _6157 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _6157 = MAKE_SEQ(_1);
    return _6157;
    ;
}


int _5new()
{
    int _state_10918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom state = eumem:malloc()*/
    _0 = _state_10918;
    _state_10918 = _28malloc(1, 1);
    DeRef(_0);

    /** 	reset(state)*/
    Ref(_state_10918);
    _5reset(_state_10918);

    /** 	return state*/
    return _state_10918;
    ;
}


void _5reset(int _state_10923)
{
    int _6161 = NOVALUE;
    int _0, _1, _2;
    

    /** 	eumem:ram_space[state] = default_state()*/
    _6161 = _5default_state();
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10923))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10923)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _state_10923);
    _1 = *(int *)_2;
    *(int *)_2 = _6161;
    if( _1 != _6161 ){
        DeRef(_1);
    }
    _6161 = NOVALUE;

    /** end procedure*/
    DeRef(_state_10923);
    return;
    ;
}
void reset() __attribute__ ((alias ("_5reset")));


int _5SyntaxColor(int _pline_10927, int _state_10928)
{
    int _class_10929 = NOVALUE;
    int _last_10930 = NOVALUE;
    int _i_10931 = NOVALUE;
    int _c_10932 = NOVALUE;
    int _word_10933 = NOVALUE;
    int _old_seg_end_11048 = NOVALUE;
    int _6308 = NOVALUE;
    int _6307 = NOVALUE;
    int _6306 = NOVALUE;
    int _6300 = NOVALUE;
    int _6299 = NOVALUE;
    int _6297 = NOVALUE;
    int _6294 = NOVALUE;
    int _6292 = NOVALUE;
    int _6289 = NOVALUE;
    int _6285 = NOVALUE;
    int _6283 = NOVALUE;
    int _6280 = NOVALUE;
    int _6277 = NOVALUE;
    int _6276 = NOVALUE;
    int _6274 = NOVALUE;
    int _6273 = NOVALUE;
    int _6272 = NOVALUE;
    int _6271 = NOVALUE;
    int _6270 = NOVALUE;
    int _6269 = NOVALUE;
    int _6268 = NOVALUE;
    int _6266 = NOVALUE;
    int _6264 = NOVALUE;
    int _6262 = NOVALUE;
    int _6259 = NOVALUE;
    int _6253 = NOVALUE;
    int _6252 = NOVALUE;
    int _6251 = NOVALUE;
    int _6249 = NOVALUE;
    int _6248 = NOVALUE;
    int _6244 = NOVALUE;
    int _6242 = NOVALUE;
    int _6236 = NOVALUE;
    int _6235 = NOVALUE;
    int _6231 = NOVALUE;
    int _6229 = NOVALUE;
    int _6228 = NOVALUE;
    int _6224 = NOVALUE;
    int _6223 = NOVALUE;
    int _6221 = NOVALUE;
    int _6220 = NOVALUE;
    int _6218 = NOVALUE;
    int _6217 = NOVALUE;
    int _6216 = NOVALUE;
    int _6215 = NOVALUE;
    int _6214 = NOVALUE;
    int _6213 = NOVALUE;
    int _6212 = NOVALUE;
    int _6211 = NOVALUE;
    int _6210 = NOVALUE;
    int _6209 = NOVALUE;
    int _6208 = NOVALUE;
    int _6207 = NOVALUE;
    int _6206 = NOVALUE;
    int _6204 = NOVALUE;
    int _6203 = NOVALUE;
    int _6198 = NOVALUE;
    int _6197 = NOVALUE;
    int _6195 = NOVALUE;
    int _6189 = NOVALUE;
    int _6188 = NOVALUE;
    int _6186 = NOVALUE;
    int _6180 = NOVALUE;
    int _6178 = NOVALUE;
    int _6177 = NOVALUE;
    int _6175 = NOVALUE;
    int _6174 = NOVALUE;
    int _6172 = NOVALUE;
    int _6171 = NOVALUE;
    int _6169 = NOVALUE;
    int _6167 = NOVALUE;
    int _6166 = NOVALUE;
    int _6165 = NOVALUE;
    int _6164 = NOVALUE;
    int _6163 = NOVALUE;
    int _6162 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length(pline) > 0 and pline[$] != '\n' then*/
    if (IS_SEQUENCE(_pline_10927)){
            _6162 = SEQ_PTR(_pline_10927)->length;
    }
    else {
        _6162 = 1;
    }
    _6163 = (_6162 > 0);
    _6162 = NOVALUE;
    if (_6163 == 0) {
        goto L1; // [12] 38
    }
    if (IS_SEQUENCE(_pline_10927)){
            _6165 = SEQ_PTR(_pline_10927)->length;
    }
    else {
        _6165 = 1;
    }
    _2 = (int)SEQ_PTR(_pline_10927);
    _6166 = (int)*(((s1_ptr)_2)->base + _6165);
    if (IS_ATOM_INT(_6166)) {
        _6167 = (_6166 != 10);
    }
    else {
        _6167 = binary_op(NOTEQ, _6166, 10);
    }
    _6166 = NOVALUE;
    if (_6167 == 0) {
        DeRef(_6167);
        _6167 = NOVALUE;
        goto L1; // [28] 38
    }
    else {
        if (!IS_ATOM_INT(_6167) && DBL_PTR(_6167)->dbl == 0.0){
            DeRef(_6167);
            _6167 = NOVALUE;
            goto L1; // [28] 38
        }
        DeRef(_6167);
        _6167 = NOVALUE;
    }
    DeRef(_6167);
    _6167 = NOVALUE;

    /** 		pline &= '\n'*/
    Append(&_pline_10927, _pline_10927, 10);
L1: 

    /** 	if length(pline) < 2 then*/
    if (IS_SEQUENCE(_pline_10927)){
            _6169 = SEQ_PTR(_pline_10927)->length;
    }
    else {
        _6169 = 1;
    }
    if (_6169 >= 2)
    goto L2; // [43] 54

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_pline_10927);
    DeRef(_state_10928);
    DeRef(_word_10933);
    DeRef(_6163);
    _6163 = NOVALUE;
    return _5;
L2: 

    /** 	line = pline*/
    RefDS(_pline_10927);
    DeRef(_5line_10892);
    _5line_10892 = _pline_10927;

    /** 	current_color = DONT_CARE*/
    _5current_color_10894 = -1;

    /** 	seg_start = 1*/
    _5seg_start_10895 = 1;

    /** 	seg_end = 0*/
    _5seg_end_10896 = 0;

    /** 	color_segments = {}*/
    RefDS(_5);
    DeRef(_5color_segments_10893);
    _5color_segments_10893 = _5;

    /** 	if eumem:ram_space[state][S_MULTILINE_COMMENT] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6171 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6171 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6171);
    _6172 = (int)*(((s1_ptr)_2)->base + 3);
    _6171 = NOVALUE;
    if (_6172 == 0) {
        _6172 = NOVALUE;
        goto L3; // [95] 107
    }
    else {
        if (!IS_ATOM_INT(_6172) && DBL_PTR(_6172)->dbl == 0.0){
            _6172 = NOVALUE;
            goto L3; // [95] 107
        }
        _6172 = NOVALUE;
    }
    _6172 = NOVALUE;

    /** 		goto "MULTILINE_COMMENT"*/
    goto G4;
    goto L5; // [104] 154
L3: 

    /** 	elsif eumem:ram_space[state][S_STRING_TRIPLE] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6174 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6174 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6174);
    _6175 = (int)*(((s1_ptr)_2)->base + 1);
    _6174 = NOVALUE;
    if (_6175 == 0) {
        _6175 = NOVALUE;
        goto L6; // [119] 131
    }
    else {
        if (!IS_ATOM_INT(_6175) && DBL_PTR(_6175)->dbl == 0.0){
            _6175 = NOVALUE;
            goto L6; // [119] 131
        }
        _6175 = NOVALUE;
    }
    _6175 = NOVALUE;

    /** 		goto "MULTILINE_STRING"*/
    goto G7;
    goto L5; // [128] 154
L6: 

    /** 	elsif eumem:ram_space[state][S_STRING_BACKTICK] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6177 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6177 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6177);
    _6178 = (int)*(((s1_ptr)_2)->base + 2);
    _6177 = NOVALUE;
    if (_6178 == 0) {
        _6178 = NOVALUE;
        goto L8; // [143] 153
    }
    else {
        if (!IS_ATOM_INT(_6178) && DBL_PTR(_6178)->dbl == 0.0){
            _6178 = NOVALUE;
            goto L8; // [143] 153
        }
        _6178 = NOVALUE;
    }
    _6178 = NOVALUE;

    /** 		goto "BACKTICK_STRING"*/
    goto G9;
L8: 
L5: 

    /** 	while 1 do*/
LA: 

    /** 		c = line[seg_end + 1]*/
    _6180 = _5seg_end_10896 + 1;
    _2 = (int)SEQ_PTR(_5line_10892);
    _c_10932 = (int)*(((s1_ptr)_2)->base + _6180);
    if (!IS_ATOM_INT(_c_10932))
    _c_10932 = (long)DBL_PTR(_c_10932)->dbl;

    /** 		class = char_class[c]*/
    _2 = (int)SEQ_PTR(_5char_class_10840);
    _class_10929 = (int)*(((s1_ptr)_2)->base + _c_10932);

    /** 		if class = WHITE_SPACE then*/
    if (_class_10929 != 9)
    goto LB; // [183] 198

    /** 			seg_end += 1  -- continue with current color*/
    _5seg_end_10896 = _5seg_end_10896 + 1;
    goto LA; // [195] 159
LB: 

    /** 		elsif class = LETTER then*/
    if (_class_10929 != 3)
    goto LC; // [200] 357

    /** 			last = length(line)-1*/
    if (IS_SEQUENCE(_5line_10892)){
            _6186 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6186 = 1;
    }
    _last_10930 = _6186 - 1;
    _6186 = NOVALUE;

    /** 			for j = seg_end + 2 to last do*/
    _6188 = _5seg_end_10896 + 2;
    if ((long)((unsigned long)_6188 + (unsigned long)HIGH_BITS) >= 0) 
    _6188 = NewDouble((double)_6188);
    _6189 = _last_10930;
    {
        int _j_10969;
        Ref(_6188);
        _j_10969 = _6188;
LD: 
        if (binary_op_a(GREATER, _j_10969, _6189)){
            goto LE; // [226] 282
        }

        /** 				c = line[j]*/
        _2 = (int)SEQ_PTR(_5line_10892);
        if (!IS_ATOM_INT(_j_10969)){
            _c_10932 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_j_10969)->dbl));
        }
        else{
            _c_10932 = (int)*(((s1_ptr)_2)->base + _j_10969);
        }
        if (!IS_ATOM_INT(_c_10932))
        _c_10932 = (long)DBL_PTR(_c_10932)->dbl;

        /** 				class = char_class[c]*/
        _2 = (int)SEQ_PTR(_5char_class_10840);
        _class_10929 = (int)*(((s1_ptr)_2)->base + _c_10932);

        /** 				if class != LETTER then*/
        if (_class_10929 == 3)
        goto LF; // [251] 275

        /** 					if class != DIGIT then*/
        if (_class_10929 == 1)
        goto L10; // [257] 274

        /** 						last = j - 1*/
        if (IS_ATOM_INT(_j_10969)) {
            _last_10930 = _j_10969 - 1;
        }
        else {
            _last_10930 = NewDouble(DBL_PTR(_j_10969)->dbl - (double)1);
        }
        if (!IS_ATOM_INT(_last_10930)) {
            _1 = (long)(DBL_PTR(_last_10930)->dbl);
            DeRefDS(_last_10930);
            _last_10930 = _1;
        }

        /** 						exit*/
        goto LE; // [271] 282
L10: 
LF: 

        /** 			end for*/
        _0 = _j_10969;
        if (IS_ATOM_INT(_j_10969)) {
            _j_10969 = _j_10969 + 1;
            if ((long)((unsigned long)_j_10969 +(unsigned long) HIGH_BITS) >= 0){
                _j_10969 = NewDouble((double)_j_10969);
            }
        }
        else {
            _j_10969 = binary_op_a(PLUS, _j_10969, 1);
        }
        DeRef(_0);
        goto LD; // [277] 233
LE: 
        ;
        DeRef(_j_10969);
    }

    /** 			word = line[seg_end+1..last]*/
    _6195 = _5seg_end_10896 + 1;
    rhs_slice_target = (object_ptr)&_word_10933;
    RHS_Slice(_5line_10892, _6195, _last_10930);

    /** 			if find(word, keywords) then*/
    _6197 = find_from(_word_10933, _4keywords_296, 1);
    if (_6197 == 0)
    {
        _6197 = NOVALUE;
        goto L11; // [306] 319
    }
    else{
        _6197 = NOVALUE;
    }

    /** 				seg_flush(KEYWORD_COLOR)*/
    _5seg_flush(_5KEYWORD_COLOR_10822);
    goto L12; // [316] 349
L11: 

    /** 			elsif find(word, builtins) then*/
    _6198 = find_from(_word_10933, _4builtins_343, 1);
    if (_6198 == 0)
    {
        _6198 = NOVALUE;
        goto L13; // [328] 341
    }
    else{
        _6198 = NOVALUE;
    }

    /** 				seg_flush(BUILTIN_COLOR)*/
    _5seg_flush(_5BUILTIN_COLOR_10823);
    goto L12; // [338] 349
L13: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10820);
L12: 

    /** 			seg_end = last*/
    _5seg_end_10896 = _last_10930;
    goto LA; // [354] 159
LC: 

    /** 		elsif class <= OTHER then -- DIGIT too*/
    if (_class_10929 > 2)
    goto L14; // [359] 381

    /** 			seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10820);

    /** 			seg_end += 1*/
    _5seg_end_10896 = _5seg_end_10896 + 1;
    goto LA; // [378] 159
L14: 

    /** 		elsif class = BRACKET then*/
    if (_class_10929 != 4)
    goto L15; // [383] 537

    /** 			if find(c, "([{") then*/
    _6203 = find_from(_c_10932, _6202, 1);
    if (_6203 == 0)
    {
        _6203 = NOVALUE;
        goto L16; // [394] 419
    }
    else{
        _6203 = NOVALUE;
    }

    /** 				eumem:ram_space[state][S_BRACKET_LEVEL] += 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _6206 = (int)*(((s1_ptr)_2)->base + 4);
    _6204 = NOVALUE;
    if (IS_ATOM_INT(_6206)) {
        _6207 = _6206 + 1;
        if (_6207 > MAXINT){
            _6207 = NewDouble((double)_6207);
        }
    }
    else
    _6207 = binary_op(PLUS, 1, _6206);
    _6206 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _6207;
    if( _1 != _6207 ){
        DeRef(_1);
    }
    _6207 = NOVALUE;
    _6204 = NOVALUE;
L16: 

    /** 			if eumem:ram_space[state][S_BRACKET_LEVEL] >= 1 and*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6208 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6208 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6208);
    _6209 = (int)*(((s1_ptr)_2)->base + 4);
    _6208 = NOVALUE;
    if (IS_ATOM_INT(_6209)) {
        _6210 = (_6209 >= 1);
    }
    else {
        _6210 = binary_op(GREATEREQ, _6209, 1);
    }
    _6209 = NOVALUE;
    if (IS_ATOM_INT(_6210)) {
        if (_6210 == 0) {
            goto L17; // [435] 486
        }
    }
    else {
        if (DBL_PTR(_6210)->dbl == 0.0) {
            goto L17; // [435] 486
        }
    }
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6212 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6212 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6212);
    _6213 = (int)*(((s1_ptr)_2)->base + 4);
    _6212 = NOVALUE;
    if (IS_SEQUENCE(_5BRACKET_COLOR_10825)){
            _6214 = SEQ_PTR(_5BRACKET_COLOR_10825)->length;
    }
    else {
        _6214 = 1;
    }
    if (IS_ATOM_INT(_6213)) {
        _6215 = (_6213 <= _6214);
    }
    else {
        _6215 = binary_op(LESSEQ, _6213, _6214);
    }
    _6213 = NOVALUE;
    _6214 = NOVALUE;
    if (_6215 == 0) {
        DeRef(_6215);
        _6215 = NOVALUE;
        goto L17; // [459] 486
    }
    else {
        if (!IS_ATOM_INT(_6215) && DBL_PTR(_6215)->dbl == 0.0){
            DeRef(_6215);
            _6215 = NOVALUE;
            goto L17; // [459] 486
        }
        DeRef(_6215);
        _6215 = NOVALUE;
    }
    DeRef(_6215);
    _6215 = NOVALUE;

    /** 				seg_flush(BRACKET_COLOR[eumem:ram_space[state][S_BRACKET_LEVEL]])*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_state_10928)){
        _6216 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    }
    else{
        _6216 = (int)*(((s1_ptr)_2)->base + _state_10928);
    }
    _2 = (int)SEQ_PTR(_6216);
    _6217 = (int)*(((s1_ptr)_2)->base + 4);
    _6216 = NOVALUE;
    _2 = (int)SEQ_PTR(_5BRACKET_COLOR_10825);
    if (!IS_ATOM_INT(_6217)){
        _6218 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6217)->dbl));
    }
    else{
        _6218 = (int)*(((s1_ptr)_2)->base + _6217);
    }
    Ref(_6218);
    _5seg_flush(_6218);
    _6218 = NOVALUE;
    goto L18; // [483] 494
L17: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10820);
L18: 

    /** 			if find(c, ")]}") then*/
    _6220 = find_from(_c_10932, _6219, 1);
    if (_6220 == 0)
    {
        _6220 = NOVALUE;
        goto L19; // [501] 526
    }
    else{
        _6220 = NOVALUE;
    }

    /** 				eumem:ram_space[state][S_BRACKET_LEVEL] -= 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _6223 = (int)*(((s1_ptr)_2)->base + 4);
    _6221 = NOVALUE;
    if (IS_ATOM_INT(_6223)) {
        _6224 = _6223 - 1;
        if ((long)((unsigned long)_6224 +(unsigned long) HIGH_BITS) >= 0){
            _6224 = NewDouble((double)_6224);
        }
    }
    else {
        _6224 = binary_op(MINUS, _6223, 1);
    }
    _6223 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _6224;
    if( _1 != _6224 ){
        DeRef(_1);
    }
    _6224 = NOVALUE;
    _6221 = NOVALUE;
L19: 

    /** 			seg_end += 1*/
    _5seg_end_10896 = _5seg_end_10896 + 1;
    goto LA; // [534] 159
L15: 

    /** 		elsif class = NEW_LINE then*/
    if (_class_10929 != 10)
    goto L1A; // [539] 550

    /** 			exit  -- end of line*/
    goto L1B; // [545] 1181
    goto LA; // [547] 159
L1A: 

    /** 		elsif class = DASH then*/
    if (_class_10929 != 7)
    goto L1C; // [552] 615

    /** 			if line[seg_end+2] = '-' then*/
    _6228 = _5seg_end_10896 + 2;
    _2 = (int)SEQ_PTR(_5line_10892);
    _6229 = (int)*(((s1_ptr)_2)->base + _6228);
    if (binary_op_a(NOTEQ, _6229, 45)){
        _6229 = NOVALUE;
        goto L1D; // [570] 597
    }
    _6229 = NOVALUE;

    /** 				seg_flush(COMMENT_COLOR)*/
    _5seg_flush(_5COMMENT_COLOR_10821);

    /** 				seg_end = length(line)-1*/
    if (IS_SEQUENCE(_5line_10892)){
            _6231 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6231 = 1;
    }
    _5seg_end_10896 = _6231 - 1;
    _6231 = NOVALUE;

    /** 				exit*/
    goto L1B; // [594] 1181
L1D: 

    /** 			seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10820);

    /** 			seg_end += 1*/
    _5seg_end_10896 = _5seg_end_10896 + 1;
    goto LA; // [612] 159
L1C: 

    /** 		elsif class = FORWARD_SLASH then*/
    if (_class_10929 != 8)
    goto L1E; // [617] 794

    /** 			if line[seg_end + 2] = '*' then*/
    _6235 = _5seg_end_10896 + 2;
    _2 = (int)SEQ_PTR(_5line_10892);
    _6236 = (int)*(((s1_ptr)_2)->base + _6235);
    if (binary_op_a(NOTEQ, _6236, 42)){
        _6236 = NOVALUE;
        goto L1F; // [635] 775
    }
    _6236 = NOVALUE;

    /** label "MULTILINE_COMMENT"*/
G4:

    /** 				if seg_end = 0 then*/
    if (_5seg_end_10896 != 0)
    goto L20; // [647] 657

    /** 					seg_end = 1*/
    _5seg_end_10896 = 1;
L20: 

    /** 				seg_flush(COMMENT_COLOR)*/
    _5seg_flush(_5COMMENT_COLOR_10821);

    //				i = match("*/", line, seg_end)
    _i_10931 = e_match_from(_6239, _5line_10892, _5seg_end_10896);

    /** 				if i = 0 then*/
    if (_i_10931 != 0)
    goto L21; // [677] 710

    /** 					eumem:ram_space[state][S_MULTILINE_COMMENT] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6242 = NOVALUE;

    /** 					seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_10892)){
            _6244 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6244 = 1;
    }
    _5seg_end_10896 = _6244 - 1;
    _6244 = NOVALUE;

    /** 					exit*/
    goto L1B; // [707] 1181
L21: 

    /** 				integer old_seg_end = seg_end + 2*/
    _old_seg_end_11048 = _5seg_end_10896 + 2;

    /** 				seg_end = i + 1*/
    _5seg_end_10896 = _i_10931 + 1;

    //				if old_seg_end < i and match("/*", line[old_seg_end..i]) then
    _6248 = (_old_seg_end_11048 < _i_10931);
    if (_6248 == 0) {
        goto L22; // [730] 757
    }
    rhs_slice_target = (object_ptr)&_6251;
    RHS_Slice(_5line_10892, _old_seg_end_11048, _i_10931);
    _6252 = e_match_from(_6250, _6251, 1);
    DeRefDS(_6251);
    _6251 = NOVALUE;
    if (_6252 == 0)
    {
        _6252 = NOVALUE;
        goto L22; // [747] 757
    }
    else{
        _6252 = NOVALUE;
    }

    /** 					goto "MULTILINE_COMMENT"*/
    goto G4;
L22: 

    /** 				eumem:ram_space[state][S_MULTILINE_COMMENT] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6253 = NOVALUE;
    goto LA; // [772] 159
L1F: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10820);

    /** 				seg_end += 1*/
    _5seg_end_10896 = _5seg_end_10896 + 1;
    goto LA; // [791] 159
L1E: 

    /** 		elsif class = BACKTICK then*/
    if (_class_10929 != 6)
    goto L23; // [798] 898

    /** label "BACKTICK_STRING"*/
G9:

    /** 			if seg_end = 0 then*/
    if (_5seg_end_10896 != 0)
    goto L24; // [810] 820

    /** 				seg_end = 1*/
    _5seg_end_10896 = 1;
L24: 

    /** 			seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10824);

    /** 			i = match("`", line, seg_end + 2)*/
    _6259 = _5seg_end_10896 + 2;
    if ((long)((unsigned long)_6259 + (unsigned long)HIGH_BITS) >= 0) 
    _6259 = NewDouble((double)_6259);
    _i_10931 = e_match_from(_6258, _5line_10892, _6259);
    DeRef(_6259);
    _6259 = NOVALUE;

    /** 			if i = 0 then*/
    if (_i_10931 != 0)
    goto L25; // [844] 877

    /** 				eumem:ram_space[state][S_STRING_BACKTICK] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6262 = NOVALUE;

    /** 				seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_10892)){
            _6264 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6264 = 1;
    }
    _5seg_end_10896 = _6264 - 1;
    _6264 = NOVALUE;

    /** 				exit*/
    goto L1B; // [874] 1181
L25: 

    /** 			seg_end = i*/
    _5seg_end_10896 = _i_10931;

    /** 			eumem:ram_space[state][S_STRING_BACKTICK] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6266 = NOVALUE;
    goto LA; // [895] 159
L23: 

    /** 			if line[seg_end + 2] = '"' and line[seg_end + 3] = '"' then*/
    _6268 = _5seg_end_10896 + 2;
    _2 = (int)SEQ_PTR(_5line_10892);
    _6269 = (int)*(((s1_ptr)_2)->base + _6268);
    if (IS_ATOM_INT(_6269)) {
        _6270 = (_6269 == 34);
    }
    else {
        _6270 = binary_op(EQUALS, _6269, 34);
    }
    _6269 = NOVALUE;
    if (IS_ATOM_INT(_6270)) {
        if (_6270 == 0) {
            goto L26; // [916] 1065
        }
    }
    else {
        if (DBL_PTR(_6270)->dbl == 0.0) {
            goto L26; // [916] 1065
        }
    }
    _6272 = _5seg_end_10896 + 3;
    _2 = (int)SEQ_PTR(_5line_10892);
    _6273 = (int)*(((s1_ptr)_2)->base + _6272);
    if (IS_ATOM_INT(_6273)) {
        _6274 = (_6273 == 34);
    }
    else {
        _6274 = binary_op(EQUALS, _6273, 34);
    }
    _6273 = NOVALUE;
    if (_6274 == 0) {
        DeRef(_6274);
        _6274 = NOVALUE;
        goto L26; // [937] 1065
    }
    else {
        if (!IS_ATOM_INT(_6274) && DBL_PTR(_6274)->dbl == 0.0){
            DeRef(_6274);
            _6274 = NOVALUE;
            goto L26; // [937] 1065
        }
        DeRef(_6274);
        _6274 = NOVALUE;
    }
    DeRef(_6274);
    _6274 = NOVALUE;

    /** label "MULTILINE_STRING"*/
G7:

    /** 				seg_end += 1*/
    _5seg_end_10896 = _5seg_end_10896 + 1;

    /** 				seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10824);

    /** 				if seg_end + 3 < length(line) then*/
    _6276 = _5seg_end_10896 + 3;
    if ((long)((unsigned long)_6276 + (unsigned long)HIGH_BITS) >= 0) 
    _6276 = NewDouble((double)_6276);
    if (IS_SEQUENCE(_5line_10892)){
            _6277 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6277 = 1;
    }
    if (binary_op_a(GREATEREQ, _6276, _6277)){
        DeRef(_6276);
        _6276 = NOVALUE;
        _6277 = NOVALUE;
        goto L27; // [972] 1029
    }
    DeRef(_6276);
    _6276 = NOVALUE;
    _6277 = NOVALUE;

    /** 					i = match(`"""`, line, seg_end + 3)*/
    _6280 = _5seg_end_10896 + 3;
    if ((long)((unsigned long)_6280 + (unsigned long)HIGH_BITS) >= 0) 
    _6280 = NewDouble((double)_6280);
    _i_10931 = e_match_from(_6279, _5line_10892, _6280);
    DeRef(_6280);
    _6280 = NOVALUE;

    /** 					if i = 0 then*/
    if (_i_10931 != 0)
    goto L28; // [993] 1041

    /** 						eumem:ram_space[state][S_STRING_TRIPLE] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6283 = NOVALUE;

    /** 						seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_10892)){
            _6285 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6285 = 1;
    }
    _5seg_end_10896 = _6285 - 1;
    _6285 = NOVALUE;

    /** 						exit*/
    goto L1B; // [1023] 1181
    goto L28; // [1026] 1041
L27: 

    /** 					i = length(line)*/
    if (IS_SEQUENCE(_5line_10892)){
            _i_10931 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _i_10931 = 1;
    }

    /** 					exit*/
    goto L1B; // [1038] 1181
L28: 

    /** 				seg_end = i + 2*/
    _5seg_end_10896 = _i_10931 + 2;

    /** 				eumem:ram_space[state][S_STRING_TRIPLE] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_10928))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_10928)->dbl));
    else
    _3 = (int)(_state_10928 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6289 = NOVALUE;
    goto LA; // [1062] 159
L26: 

    /** 				i = seg_end + 2*/
    _i_10931 = _5seg_end_10896 + 2;

    /** 				while i < length(line) do*/
L29: 
    if (IS_SEQUENCE(_5line_10892)){
            _6292 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6292 = 1;
    }
    if (_i_10931 >= _6292)
    goto L2A; // [1083] 1161

    /** 					if line[i] = c then*/
    _2 = (int)SEQ_PTR(_5line_10892);
    _6294 = (int)*(((s1_ptr)_2)->base + _i_10931);
    if (binary_op_a(NOTEQ, _6294, _c_10932)){
        _6294 = NOVALUE;
        goto L2B; // [1097] 1114
    }
    _6294 = NOVALUE;

    /** 						i += 1*/
    _i_10931 = _i_10931 + 1;

    /** 						exit*/
    goto L2A; // [1109] 1161
    goto L2C; // [1111] 1150
L2B: 

    /** 					elsif line[i] = '\\' then*/
    _2 = (int)SEQ_PTR(_5line_10892);
    _6297 = (int)*(((s1_ptr)_2)->base + _i_10931);
    if (binary_op_a(NOTEQ, _6297, 92)){
        _6297 = NOVALUE;
        goto L2D; // [1122] 1149
    }
    _6297 = NOVALUE;

    /** 						if i < length(line)-1 then*/
    if (IS_SEQUENCE(_5line_10892)){
            _6299 = SEQ_PTR(_5line_10892)->length;
    }
    else {
        _6299 = 1;
    }
    _6300 = _6299 - 1;
    _6299 = NOVALUE;
    if (_i_10931 >= _6300)
    goto L2E; // [1137] 1148

    /** 							i += 1 -- ignore escaped char*/
    _i_10931 = _i_10931 + 1;
L2E: 
L2D: 
L2C: 

    /** 					i += 1*/
    _i_10931 = _i_10931 + 1;

    /** 				end while*/
    goto L29; // [1158] 1078
L2A: 

    /** 				seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10824);

    /** 				seg_end = i - 1*/
    _5seg_end_10896 = _i_10931 - 1;

    /** 	end while*/
    goto LA; // [1178] 159
L1B: 

    /** 	if current_color = DONT_CARE then*/
    if (_5current_color_10894 != -1)
    goto L2F; // [1185] 1197

    /** 		current_color = NORMAL_COLOR*/
    _5current_color_10894 = _5NORMAL_COLOR_10820;
L2F: 

    /** 	return append(color_segments, {current_color, line[seg_start..seg_end]})*/
    rhs_slice_target = (object_ptr)&_6306;
    RHS_Slice(_5line_10892, _5seg_start_10895, _5seg_end_10896);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5current_color_10894;
    ((int *)_2)[2] = _6306;
    _6307 = MAKE_SEQ(_1);
    _6306 = NOVALUE;
    RefDS(_6307);
    Append(&_6308, _5color_segments_10893, _6307);
    DeRefDS(_6307);
    _6307 = NOVALUE;
    DeRefDS(_pline_10927);
    DeRef(_state_10928);
    DeRef(_word_10933);
    DeRef(_6163);
    _6163 = NOVALUE;
    DeRef(_6180);
    _6180 = NOVALUE;
    DeRef(_6188);
    _6188 = NOVALUE;
    DeRef(_6195);
    _6195 = NOVALUE;
    _6217 = NOVALUE;
    DeRef(_6210);
    _6210 = NOVALUE;
    DeRef(_6228);
    _6228 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6248);
    _6248 = NOVALUE;
    DeRef(_6268);
    _6268 = NOVALUE;
    DeRef(_6272);
    _6272 = NOVALUE;
    DeRef(_6270);
    _6270 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    return _6308;
    ;
}
int SyntaxColor() __attribute__ ((alias ("_5SyntaxColor")));



// 0xBAD0249D
