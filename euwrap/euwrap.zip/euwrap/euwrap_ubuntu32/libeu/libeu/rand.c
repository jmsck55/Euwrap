// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _21rand_range(int _lo_4204, int _hi_4205)
{
    int _temp_4208 = NOVALUE;
    int _2184 = NOVALUE;
    int _2182 = NOVALUE;
    int _2179 = NOVALUE;
    int _2178 = NOVALUE;
    int _2177 = NOVALUE;
    int _2176 = NOVALUE;
    int _2174 = NOVALUE;
    int _2173 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if lo > hi then*/
    if (binary_op_a(LESSEQ, _lo_4204, _hi_4205)){
        goto L1; // [3] 23
    }

    /** 		atom temp = hi*/
    Ref(_hi_4205);
    DeRef(_temp_4208);
    _temp_4208 = _hi_4205;

    /** 		hi = lo*/
    Ref(_lo_4204);
    DeRef(_hi_4205);
    _hi_4205 = _lo_4204;

    /** 		lo = temp*/
    Ref(_temp_4208);
    DeRef(_lo_4204);
    _lo_4204 = _temp_4208;
L1: 
    DeRef(_temp_4208);
    _temp_4208 = NOVALUE;

    /** 	if not integer(lo) or not integer(hi) then*/
    if (IS_ATOM_INT(_lo_4204))
    _2173 = 1;
    else if (IS_ATOM_DBL(_lo_4204))
    _2173 = IS_ATOM_INT(DoubleToInt(_lo_4204));
    else
    _2173 = 0;
    _2174 = (_2173 == 0);
    _2173 = NOVALUE;
    if (_2174 != 0) {
        goto L2; // [33] 48
    }
    if (IS_ATOM_INT(_hi_4205))
    _2176 = 1;
    else if (IS_ATOM_DBL(_hi_4205))
    _2176 = IS_ATOM_INT(DoubleToInt(_hi_4205));
    else
    _2176 = 0;
    _2177 = (_2176 == 0);
    _2176 = NOVALUE;
    if (_2177 == 0)
    {
        DeRef(_2177);
        _2177 = NOVALUE;
        goto L3; // [44] 64
    }
    else{
        DeRef(_2177);
        _2177 = NOVALUE;
    }
L2: 

    /**    		hi = rnd() * (hi - lo)*/
    _2178 = _21rnd();
    if (IS_ATOM_INT(_hi_4205) && IS_ATOM_INT(_lo_4204)) {
        _2179 = _hi_4205 - _lo_4204;
        if ((long)((unsigned long)_2179 +(unsigned long) HIGH_BITS) >= 0){
            _2179 = NewDouble((double)_2179);
        }
    }
    else {
        if (IS_ATOM_INT(_hi_4205)) {
            _2179 = NewDouble((double)_hi_4205 - DBL_PTR(_lo_4204)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lo_4204)) {
                _2179 = NewDouble(DBL_PTR(_hi_4205)->dbl - (double)_lo_4204);
            }
            else
            _2179 = NewDouble(DBL_PTR(_hi_4205)->dbl - DBL_PTR(_lo_4204)->dbl);
        }
    }
    DeRef(_hi_4205);
    if (IS_ATOM_INT(_2178) && IS_ATOM_INT(_2179)) {
        if (_2178 == (short)_2178 && _2179 <= INT15 && _2179 >= -INT15)
        _hi_4205 = _2178 * _2179;
        else
        _hi_4205 = NewDouble(_2178 * (double)_2179);
    }
    else {
        _hi_4205 = binary_op(MULTIPLY, _2178, _2179);
    }
    DeRef(_2178);
    _2178 = NOVALUE;
    DeRef(_2179);
    _2179 = NOVALUE;
    goto L4; // [61] 80
L3: 

    /** 		lo -= 1*/
    _0 = _lo_4204;
    if (IS_ATOM_INT(_lo_4204)) {
        _lo_4204 = _lo_4204 - 1;
        if ((long)((unsigned long)_lo_4204 +(unsigned long) HIGH_BITS) >= 0){
            _lo_4204 = NewDouble((double)_lo_4204);
        }
    }
    else {
        _lo_4204 = NewDouble(DBL_PTR(_lo_4204)->dbl - (double)1);
    }
    DeRef(_0);

    /**    		hi = rand(hi - lo)*/
    if (IS_ATOM_INT(_hi_4205) && IS_ATOM_INT(_lo_4204)) {
        _2182 = _hi_4205 - _lo_4204;
        if ((long)((unsigned long)_2182 +(unsigned long) HIGH_BITS) >= 0){
            _2182 = NewDouble((double)_2182);
        }
    }
    else {
        if (IS_ATOM_INT(_hi_4205)) {
            _2182 = NewDouble((double)_hi_4205 - DBL_PTR(_lo_4204)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lo_4204)) {
                _2182 = NewDouble(DBL_PTR(_hi_4205)->dbl - (double)_lo_4204);
            }
            else
            _2182 = NewDouble(DBL_PTR(_hi_4205)->dbl - DBL_PTR(_lo_4204)->dbl);
        }
    }
    DeRef(_hi_4205);
    if (IS_ATOM_INT(_2182)) {
        _hi_4205 = good_rand() % ((unsigned)_2182) + 1;
    }
    else {
        _hi_4205 = unary_op(RAND, _2182);
    }
    DeRef(_2182);
    _2182 = NOVALUE;
L4: 

    /**    	return lo + hi*/
    if (IS_ATOM_INT(_lo_4204) && IS_ATOM_INT(_hi_4205)) {
        _2184 = _lo_4204 + _hi_4205;
        if ((long)((unsigned long)_2184 + (unsigned long)HIGH_BITS) >= 0) 
        _2184 = NewDouble((double)_2184);
    }
    else {
        if (IS_ATOM_INT(_lo_4204)) {
            _2184 = NewDouble((double)_lo_4204 + DBL_PTR(_hi_4205)->dbl);
        }
        else {
            if (IS_ATOM_INT(_hi_4205)) {
                _2184 = NewDouble(DBL_PTR(_lo_4204)->dbl + (double)_hi_4205);
            }
            else
            _2184 = NewDouble(DBL_PTR(_lo_4204)->dbl + DBL_PTR(_hi_4205)->dbl);
        }
    }
    DeRef(_lo_4204);
    DeRef(_hi_4205);
    DeRef(_2174);
    _2174 = NOVALUE;
    return _2184;
    ;
}
int rand_range() __attribute__ ((alias ("_21rand_range")));


int _21rnd()
{
    int _a_4228 = NOVALUE;
    int _b_4229 = NOVALUE;
    int _r_4230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	 a = rand(#FFFFFFFF)*/
    DeRef(_a_4228);
    _a_4228 = unary_op(RAND, _2185);

    /** 	 if a = 1 then return 0 end if*/
    if (binary_op_a(NOTEQ, _a_4228, 1)){
        goto L1; // [8] 17
    }
    DeRef(_a_4228);
    DeRef(_b_4229);
    DeRef(_r_4230);
    return 0;
L1: 

    /** 	 b = rand(#FFFFFFFF)*/
    DeRef(_b_4229);
    _b_4229 = unary_op(RAND, _2185);

    /** 	 if b = 1 then return 0 end if*/
    if (binary_op_a(NOTEQ, _b_4229, 1)){
        goto L2; // [24] 33
    }
    DeRef(_a_4228);
    DeRef(_b_4229);
    DeRef(_r_4230);
    return 0;
L2: 

    /** 	 if a > b then*/
    if (binary_op_a(LESSEQ, _a_4228, _b_4229)){
        goto L3; // [35] 48
    }

    /** 	 	r = b / a*/
    DeRef(_r_4230);
    if (IS_ATOM_INT(_b_4229) && IS_ATOM_INT(_a_4228)) {
        _r_4230 = (_b_4229 % _a_4228) ? NewDouble((double)_b_4229 / _a_4228) : (_b_4229 / _a_4228);
    }
    else {
        if (IS_ATOM_INT(_b_4229)) {
            _r_4230 = NewDouble((double)_b_4229 / DBL_PTR(_a_4228)->dbl);
        }
        else {
            if (IS_ATOM_INT(_a_4228)) {
                _r_4230 = NewDouble(DBL_PTR(_b_4229)->dbl / (double)_a_4228);
            }
            else
            _r_4230 = NewDouble(DBL_PTR(_b_4229)->dbl / DBL_PTR(_a_4228)->dbl);
        }
    }
    goto L4; // [45] 55
L3: 

    /** 	 	r = a / b*/
    DeRef(_r_4230);
    if (IS_ATOM_INT(_a_4228) && IS_ATOM_INT(_b_4229)) {
        _r_4230 = (_a_4228 % _b_4229) ? NewDouble((double)_a_4228 / _b_4229) : (_a_4228 / _b_4229);
    }
    else {
        if (IS_ATOM_INT(_a_4228)) {
            _r_4230 = NewDouble((double)_a_4228 / DBL_PTR(_b_4229)->dbl);
        }
        else {
            if (IS_ATOM_INT(_b_4229)) {
                _r_4230 = NewDouble(DBL_PTR(_a_4228)->dbl / (double)_b_4229);
            }
            else
            _r_4230 = NewDouble(DBL_PTR(_a_4228)->dbl / DBL_PTR(_b_4229)->dbl);
        }
    }
L4: 

    /** 	 return r*/
    DeRef(_a_4228);
    DeRef(_b_4229);
    return _r_4230;
    ;
}
int rnd() __attribute__ ((alias ("_21rnd")));


int _21rnd_1()
{
    int _r_4245 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while r >= 1.0 with entry do*/
    goto L1; // [3] 15
L2: 
    if (binary_op_a(LESS, _r_4245, _2193)){
        goto L3; // [8] 25
    }

    /** 	entry*/
L1: 

    /** 		r = rnd()*/
    _0 = _r_4245;
    _r_4245 = _21rnd();
    DeRef(_0);

    /** 	end while	 */
    goto L2; // [22] 6
L3: 

    /** 	return r*/
    return _r_4245;
    ;
}
int rnd_1() __attribute__ ((alias ("_21rnd_1")));


void _21set_rand(int _seed_4252)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_4252);

    /** end procedure*/
    DeRef(_seed_4252);
    return;
    ;
}
void set_rand() __attribute__ ((alias ("_21set_rand")));


int _21get_rand()
{
    int _2196 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_GET_RAND, {})*/
    _2196 = machine(98, _5);
    return _2196;
    ;
}
int get_rand() __attribute__ ((alias ("_21get_rand")));


int _21chance(int _my_limit_4258, int _top_limit_4259)
{
    int _2199 = NOVALUE;
    int _2198 = NOVALUE;
    int _2197 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (rnd_1() * top_limit) <= my_limit*/
    _2197 = _21rnd_1();
    if (IS_ATOM_INT(_2197) && IS_ATOM_INT(_top_limit_4259)) {
        if (_2197 == (short)_2197 && _top_limit_4259 <= INT15 && _top_limit_4259 >= -INT15)
        _2198 = _2197 * _top_limit_4259;
        else
        _2198 = NewDouble(_2197 * (double)_top_limit_4259);
    }
    else {
        _2198 = binary_op(MULTIPLY, _2197, _top_limit_4259);
    }
    DeRef(_2197);
    _2197 = NOVALUE;
    if (IS_ATOM_INT(_2198) && IS_ATOM_INT(_my_limit_4258)) {
        _2199 = (_2198 <= _my_limit_4258);
    }
    else {
        _2199 = binary_op(LESSEQ, _2198, _my_limit_4258);
    }
    DeRef(_2198);
    _2198 = NOVALUE;
    DeRef(_my_limit_4258);
    DeRef(_top_limit_4259);
    return _2199;
    ;
}
int chance() __attribute__ ((alias ("_21chance")));


int _21roll(int _desired_4265, int _sides_4266)
{
    int _rolled_4267 = NOVALUE;
    int _2204 = NOVALUE;
    int _2201 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sides_4266)) {
        _1 = (long)(DBL_PTR(_sides_4266)->dbl);
        DeRefDS(_sides_4266);
        _sides_4266 = _1;
    }

    /** 	if sides < 2 then*/
    if (_sides_4266 >= 2)
    goto L1; // [5] 16

    /** 		return 0*/
    DeRef(_desired_4265);
    return 0;
L1: 

    /** 	if atom(desired) then*/
    _2201 = IS_ATOM(_desired_4265);
    if (_2201 == 0)
    {
        _2201 = NOVALUE;
        goto L2; // [21] 31
    }
    else{
        _2201 = NOVALUE;
    }

    /** 		desired = {desired}*/
    _0 = _desired_4265;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_desired_4265);
    *((int *)(_2+4)) = _desired_4265;
    _desired_4265 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	rolled =  rand(sides)*/
    _rolled_4267 = good_rand() % ((unsigned)_sides_4266) + 1;

    /** 	if find(rolled, desired) then*/
    _2204 = find_from(_rolled_4267, _desired_4265, 1);
    if (_2204 == 0)
    {
        _2204 = NOVALUE;
        goto L3; // [43] 55
    }
    else{
        _2204 = NOVALUE;
    }

    /** 		return rolled*/
    DeRef(_desired_4265);
    return _rolled_4267;
    goto L4; // [52] 62
L3: 

    /** 		return 0*/
    DeRef(_desired_4265);
    return 0;
L4: 
    ;
}
int roll() __attribute__ ((alias ("_21roll")));


int _21sample(int _population_4279, int _sample_size_4280, int _sampling_method_4281)
{
    int _lResult_4282 = NOVALUE;
    int _lIdx_4283 = NOVALUE;
    int _lChoice_4284 = NOVALUE;
    int _2222 = NOVALUE;
    int _2218 = NOVALUE;
    int _2215 = NOVALUE;
    int _2211 = NOVALUE;
    int _2210 = NOVALUE;
    int _2209 = NOVALUE;
    int _2208 = NOVALUE;
    int _2207 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sample_size_4280)) {
        _1 = (long)(DBL_PTR(_sample_size_4280)->dbl);
        DeRefDS(_sample_size_4280);
        _sample_size_4280 = _1;
    }
    if (!IS_ATOM_INT(_sampling_method_4281)) {
        _1 = (long)(DBL_PTR(_sampling_method_4281)->dbl);
        DeRefDS(_sampling_method_4281);
        _sampling_method_4281 = _1;
    }

    /** 	if sample_size < 1 then*/
    if (_sample_size_4280 >= 1)
    goto L1; // [9] 40

    /** 		if sampling_method > 0 then*/
    if (_sampling_method_4281 <= 0)
    goto L2; // [15] 32

    /** 			return {{}, population}	*/
    RefDS(_population_4279);
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _population_4279;
    _2207 = MAKE_SEQ(_1);
    DeRefDS(_population_4279);
    DeRef(_lResult_4282);
    return _2207;
    goto L3; // [29] 39
L2: 

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_population_4279);
    DeRef(_lResult_4282);
    DeRef(_2207);
    _2207 = NOVALUE;
    return _5;
L3: 
L1: 

    /** 	if sampling_method >= 0 and sample_size >= length(population) then*/
    _2208 = (_sampling_method_4281 >= 0);
    if (_2208 == 0) {
        goto L4; // [46] 67
    }
    if (IS_SEQUENCE(_population_4279)){
            _2210 = SEQ_PTR(_population_4279)->length;
    }
    else {
        _2210 = 1;
    }
    _2211 = (_sample_size_4280 >= _2210);
    _2210 = NOVALUE;
    if (_2211 == 0)
    {
        DeRef(_2211);
        _2211 = NOVALUE;
        goto L4; // [58] 67
    }
    else{
        DeRef(_2211);
        _2211 = NOVALUE;
    }

    /** 		sample_size = length(population)*/
    if (IS_SEQUENCE(_population_4279)){
            _sample_size_4280 = SEQ_PTR(_population_4279)->length;
    }
    else {
        _sample_size_4280 = 1;
    }
L4: 

    /** 	lResult = repeat(0, sample_size)*/
    DeRef(_lResult_4282);
    _lResult_4282 = Repeat(0, _sample_size_4280);

    /** 	lIdx = 0*/
    _lIdx_4283 = 0;

    /** 	while lIdx < sample_size do*/
L5: 
    if (_lIdx_4283 >= _sample_size_4280)
    goto L6; // [83] 130

    /** 		lChoice = rand(length(population))*/
    if (IS_SEQUENCE(_population_4279)){
            _2215 = SEQ_PTR(_population_4279)->length;
    }
    else {
        _2215 = 1;
    }
    _lChoice_4284 = good_rand() % ((unsigned)_2215) + 1;
    _2215 = NOVALUE;

    /** 		lIdx += 1*/
    _lIdx_4283 = _lIdx_4283 + 1;

    /** 		lResult[lIdx] = population[lChoice]*/
    _2 = (int)SEQ_PTR(_population_4279);
    _2218 = (int)*(((s1_ptr)_2)->base + _lChoice_4284);
    Ref(_2218);
    _2 = (int)SEQ_PTR(_lResult_4282);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lResult_4282 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lIdx_4283);
    _1 = *(int *)_2;
    *(int *)_2 = _2218;
    if( _1 != _2218 ){
        DeRef(_1);
    }
    _2218 = NOVALUE;

    /** 		if sampling_method >= 0 then*/
    if (_sampling_method_4281 < 0)
    goto L5; // [113] 83

    /** 			population = remove(population, lChoice)*/
    {
        s1_ptr assign_space = SEQ_PTR(_population_4279);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lChoice_4284)) ? _lChoice_4284 : (long)(DBL_PTR(_lChoice_4284)->dbl);
        int stop = (IS_ATOM_INT(_lChoice_4284)) ? _lChoice_4284 : (long)(DBL_PTR(_lChoice_4284)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_population_4279), start, &_population_4279 );
            }
            else Tail(SEQ_PTR(_population_4279), stop+1, &_population_4279);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_population_4279), start, &_population_4279);
        }
        else {
            assign_slice_seq = &assign_space;
            _population_4279 = Remove_elements(start, stop, (SEQ_PTR(_population_4279)->ref == 1));
        }
    }

    /** 	end while*/
    goto L5; // [127] 83
L6: 

    /** 	if sampling_method > 0 then*/
    if (_sampling_method_4281 <= 0)
    goto L7; // [132] 149

    /** 		return {lResult, population}	*/
    RefDS(_population_4279);
    RefDS(_lResult_4282);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_4282;
    ((int *)_2)[2] = _population_4279;
    _2222 = MAKE_SEQ(_1);
    DeRefDS(_population_4279);
    DeRefDS(_lResult_4282);
    DeRef(_2207);
    _2207 = NOVALUE;
    DeRef(_2208);
    _2208 = NOVALUE;
    return _2222;
    goto L8; // [146] 156
L7: 

    /** 		return lResult*/
    DeRefDS(_population_4279);
    DeRef(_2207);
    _2207 = NOVALUE;
    DeRef(_2208);
    _2208 = NOVALUE;
    DeRef(_2222);
    _2222 = NOVALUE;
    return _lResult_4282;
L8: 
    ;
}
int sample() __attribute__ ((alias ("_21sample")));



// 0x4FB5D312
