// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _24sort(int _x_5001, int _order_5002)
{
    int _gap_5003 = NOVALUE;
    int _j_5004 = NOVALUE;
    int _first_5005 = NOVALUE;
    int _last_5006 = NOVALUE;
    int _tempi_5007 = NOVALUE;
    int _tempj_5008 = NOVALUE;
    int _2585 = NOVALUE;
    int _2581 = NOVALUE;
    int _2578 = NOVALUE;
    int _2574 = NOVALUE;
    int _2571 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_5002)) {
        _1 = (long)(DBL_PTR(_order_5002)->dbl);
        DeRefDS(_order_5002);
        _order_5002 = _1;
    }

    /** 	if order >= 0 then*/
    if (_order_5002 < 0)
    goto L1; // [7] 19

    /** 		order = -1*/
    _order_5002 = -1;
    goto L2; // [16] 25
L1: 

    /** 		order = 1*/
    _order_5002 = 1;
L2: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5001)){
            _last_5006 = SEQ_PTR(_x_5001)->length;
    }
    else {
        _last_5006 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5006 >= 0) {
        _2571 = _last_5006 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5006 / (double)10);
        _2571 = (long)temp_dbl;
    }
    _gap_5003 = _2571 + 1;
    _2571 = NOVALUE;

    /** 	while 1 do*/
L3: 

    /** 		first = gap + 1*/
    _first_5005 = _gap_5003 + 1;

    /** 		for i = first to last do*/
    _2574 = _last_5006;
    {
        int _i_5018;
        _i_5018 = _first_5005;
L4: 
        if (_i_5018 > _2574){
            goto L5; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5007);
        _2 = (int)SEQ_PTR(_x_5001);
        _tempi_5007 = (int)*(((s1_ptr)_2)->base + _i_5018);
        Ref(_tempi_5007);

        /** 			j = i - gap*/
        _j_5004 = _i_5018 - _gap_5003;

        /** 			while 1 do*/
L6: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5008);
        _2 = (int)SEQ_PTR(_x_5001);
        _tempj_5008 = (int)*(((s1_ptr)_2)->base + _j_5004);
        Ref(_tempj_5008);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_5007) && IS_ATOM_INT(_tempj_5008)){
            _2578 = (_tempi_5007 < _tempj_5008) ? -1 : (_tempi_5007 > _tempj_5008);
        }
        else{
            _2578 = compare(_tempi_5007, _tempj_5008);
        }
        if (_2578 == _order_5002)
        goto L7; // [92] 107

        /** 					j += gap*/
        _j_5004 = _j_5004 + _gap_5003;

        /** 					exit*/
        goto L8; // [104] 139
L7: 

        /** 				x[j+gap] = tempj*/
        _2581 = _j_5004 + _gap_5003;
        Ref(_tempj_5008);
        _2 = (int)SEQ_PTR(_x_5001);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5001 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2581);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5008;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5004 > _gap_5003)
        goto L9; // [119] 128

        /** 					exit*/
        goto L8; // [125] 139
L9: 

        /** 				j -= gap*/
        _j_5004 = _j_5004 - _gap_5003;

        /** 			end while*/
        goto L6; // [136] 80
L8: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5007);
        _2 = (int)SEQ_PTR(_x_5001);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5001 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5004);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5007;
        DeRef(_1);

        /** 		end for*/
        _i_5018 = _i_5018 + 1;
        goto L4; // [147] 63
L5: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5003 != 1)
    goto LA; // [154] 167

    /** 			return x*/
    DeRef(_tempi_5007);
    DeRef(_tempj_5008);
    DeRef(_2581);
    _2581 = NOVALUE;
    return _x_5001;
    goto L3; // [164] 45
LA: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5003 >= 0) {
        _2585 = _gap_5003 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5003 / (double)7);
        _2585 = (long)temp_dbl;
    }
    _gap_5003 = _2585 + 1;
    _2585 = NOVALUE;

    /** 	end while*/
    goto L3; // [180] 45
    ;
}
int sort() __attribute__ ((alias ("_24sort")));


int _24custom_sort(int _custom_compare_5039, int _x_5040, int _data_5041, int _order_5042)
{
    int _gap_5043 = NOVALUE;
    int _j_5044 = NOVALUE;
    int _first_5045 = NOVALUE;
    int _last_5046 = NOVALUE;
    int _tempi_5047 = NOVALUE;
    int _tempj_5048 = NOVALUE;
    int _result_5049 = NOVALUE;
    int _args_5050 = NOVALUE;
    int _2613 = NOVALUE;
    int _2609 = NOVALUE;
    int _2606 = NOVALUE;
    int _2604 = NOVALUE;
    int _2603 = NOVALUE;
    int _2598 = NOVALUE;
    int _2595 = NOVALUE;
    int _2592 = NOVALUE;
    int _2591 = NOVALUE;
    int _2589 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_custom_compare_5039)) {
        _1 = (long)(DBL_PTR(_custom_compare_5039)->dbl);
        DeRefDS(_custom_compare_5039);
        _custom_compare_5039 = _1;
    }
    if (!IS_ATOM_INT(_order_5042)) {
        _1 = (long)(DBL_PTR(_order_5042)->dbl);
        DeRefDS(_order_5042);
        _order_5042 = _1;
    }

    /** 	sequence args = {0, 0}*/
    DeRef(_args_5050);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_5050 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/
    if (_order_5042 < 0)
    goto L1; // [15] 27

    /** 		order = -1*/
    _order_5042 = -1;
    goto L2; // [24] 33
L1: 

    /** 		order = 1*/
    _order_5042 = 1;
L2: 

    /** 	if atom(data) then*/
    _2589 = IS_ATOM(_data_5041);
    if (_2589 == 0)
    {
        _2589 = NOVALUE;
        goto L3; // [38] 50
    }
    else{
        _2589 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_5050) && IS_ATOM(_data_5041)) {
        Ref(_data_5041);
        Append(&_args_5050, _args_5050, _data_5041);
    }
    else if (IS_ATOM(_args_5050) && IS_SEQUENCE(_data_5041)) {
    }
    else {
        Concat((object_ptr)&_args_5050, _args_5050, _data_5041);
    }
    goto L4; // [47] 70
L3: 

    /** 	elsif length(data) then*/
    if (IS_SEQUENCE(_data_5041)){
            _2591 = SEQ_PTR(_data_5041)->length;
    }
    else {
        _2591 = 1;
    }
    if (_2591 == 0)
    {
        _2591 = NOVALUE;
        goto L5; // [55] 69
    }
    else{
        _2591 = NOVALUE;
    }

    /** 		args = append(args, data[1])*/
    _2 = (int)SEQ_PTR(_data_5041);
    _2592 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2592);
    Append(&_args_5050, _args_5050, _2592);
    _2592 = NOVALUE;
L5: 
L4: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5040)){
            _last_5046 = SEQ_PTR(_x_5040)->length;
    }
    else {
        _last_5046 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5046 >= 0) {
        _2595 = _last_5046 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5046 / (double)10);
        _2595 = (long)temp_dbl;
    }
    _gap_5043 = _2595 + 1;
    _2595 = NOVALUE;

    /** 	while 1 do*/
L6: 

    /** 		first = gap + 1*/
    _first_5045 = _gap_5043 + 1;

    /** 		for i = first to last do*/
    _2598 = _last_5046;
    {
        int _i_5068;
        _i_5068 = _first_5045;
L7: 
        if (_i_5068 > _2598){
            goto L8; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5047);
        _2 = (int)SEQ_PTR(_x_5040);
        _tempi_5047 = (int)*(((s1_ptr)_2)->base + _i_5068);
        Ref(_tempi_5047);

        /** 			args[1] = tempi*/
        Ref(_tempi_5047);
        _2 = (int)SEQ_PTR(_args_5050);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5047;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_5044 = _i_5068 - _gap_5043;

        /** 			while 1 do*/
L9: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5048);
        _2 = (int)SEQ_PTR(_x_5040);
        _tempj_5048 = (int)*(((s1_ptr)_2)->base + _j_5044);
        Ref(_tempj_5048);

        /** 				args[2] = tempj*/
        Ref(_tempj_5048);
        _2 = (int)SEQ_PTR(_args_5050);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5048;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_5050);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_5039].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
        }
        DeRef(_result_5049);
        _result_5049 = _1;

        /** 				if sequence(result) then*/
        _2603 = IS_SEQUENCE(_result_5049);
        if (_2603 == 0)
        {
            _2603 = NOVALUE;
            goto LA; // [154] 174
        }
        else{
            _2603 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_5049);
        _2604 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_2604);
        _2 = (int)SEQ_PTR(_args_5050);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _2604;
        if( _1 != _2604 ){
            DeRef(_1);
        }
        _2604 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_5049;
        _2 = (int)SEQ_PTR(_result_5049);
        _result_5049 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_5049);
        DeRef(_0);
LA: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_5049) && IS_ATOM_INT(0)){
            _2606 = (_result_5049 < 0) ? -1 : (_result_5049 > 0);
        }
        else{
            _2606 = compare(_result_5049, 0);
        }
        if (_2606 == _order_5042)
        goto LB; // [180] 195

        /** 					j += gap*/
        _j_5044 = _j_5044 + _gap_5043;

        /** 					exit*/
        goto LC; // [192] 227
LB: 

        /** 				x[j+gap] = tempj*/
        _2609 = _j_5044 + _gap_5043;
        Ref(_tempj_5048);
        _2 = (int)SEQ_PTR(_x_5040);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5040 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2609);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5048;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5044 > _gap_5043)
        goto LD; // [207] 216

        /** 					exit*/
        goto LC; // [213] 227
LD: 

        /** 				j -= gap*/
        _j_5044 = _j_5044 - _gap_5043;

        /** 			end while*/
        goto L9; // [224] 131
LC: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5047);
        _2 = (int)SEQ_PTR(_x_5040);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5040 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5044);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5047;
        DeRef(_1);

        /** 		end for*/
        _i_5068 = _i_5068 + 1;
        goto L7; // [235] 108
L8: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5043 != 1)
    goto LE; // [242] 255

    /** 			return x*/
    DeRef(_data_5041);
    DeRef(_tempi_5047);
    DeRef(_tempj_5048);
    DeRef(_result_5049);
    DeRef(_args_5050);
    DeRef(_2609);
    _2609 = NOVALUE;
    return _x_5040;
    goto L6; // [252] 90
LE: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5043 >= 0) {
        _2613 = _gap_5043 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5043 / (double)7);
        _2613 = (long)temp_dbl;
    }
    _gap_5043 = _2613 + 1;
    _2613 = NOVALUE;

    /** 	end while*/
    goto L6; // [268] 90
    ;
}
int custom_sort() __attribute__ ((alias ("_24custom_sort")));


int _24column_compare(int _a_5094, int _b_5095, int _cols_5096)
{
    int _sign_5097 = NOVALUE;
    int _column_5098 = NOVALUE;
    int _2636 = NOVALUE;
    int _2634 = NOVALUE;
    int _2633 = NOVALUE;
    int _2632 = NOVALUE;
    int _2631 = NOVALUE;
    int _2630 = NOVALUE;
    int _2629 = NOVALUE;
    int _2627 = NOVALUE;
    int _2626 = NOVALUE;
    int _2625 = NOVALUE;
    int _2623 = NOVALUE;
    int _2621 = NOVALUE;
    int _2618 = NOVALUE;
    int _2616 = NOVALUE;
    int _2615 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_5096)){
            _2615 = SEQ_PTR(_cols_5096)->length;
    }
    else {
        _2615 = 1;
    }
    {
        int _i_5100;
        _i_5100 = 1;
L1: 
        if (_i_5100 > _2615){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_5096);
        _2616 = (int)*(((s1_ptr)_2)->base + _i_5100);
        if (binary_op_a(GREATEREQ, _2616, 0)){
            _2616 = NOVALUE;
            goto L3; // [19] 42
        }
        _2616 = NOVALUE;

        /** 			sign = -1*/
        _sign_5097 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5096);
        _2618 = (int)*(((s1_ptr)_2)->base + _i_5100);
        if (IS_ATOM_INT(_2618)) {
            if ((unsigned long)_2618 == 0xC0000000)
            _column_5098 = (int)NewDouble((double)-0xC0000000);
            else
            _column_5098 = - _2618;
        }
        else {
            _column_5098 = unary_op(UMINUS, _2618);
        }
        _2618 = NOVALUE;
        if (!IS_ATOM_INT(_column_5098)) {
            _1 = (long)(DBL_PTR(_column_5098)->dbl);
            DeRefDS(_column_5098);
            _column_5098 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_5097 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5096);
        _column_5098 = (int)*(((s1_ptr)_2)->base + _i_5100);
        if (!IS_ATOM_INT(_column_5098)){
            _column_5098 = (long)DBL_PTR(_column_5098)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_5094)){
                _2621 = SEQ_PTR(_a_5094)->length;
        }
        else {
            _2621 = 1;
        }
        if (_column_5098 > _2621)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5095)){
                _2623 = SEQ_PTR(_b_5095)->length;
        }
        else {
            _2623 = 1;
        }
        if (_column_5098 > _2623)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_5094);
        _2625 = (int)*(((s1_ptr)_2)->base + _column_5098);
        _2 = (int)SEQ_PTR(_b_5095);
        _2626 = (int)*(((s1_ptr)_2)->base + _column_5098);
        if (_2625 == _2626)
        _2627 = 1;
        else if (IS_ATOM_INT(_2625) && IS_ATOM_INT(_2626))
        _2627 = 0;
        else
        _2627 = (compare(_2625, _2626) == 0);
        _2625 = NOVALUE;
        _2626 = NOVALUE;
        if (_2627 != 0)
        goto L7; // [90] 169
        _2627 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_5094);
        _2629 = (int)*(((s1_ptr)_2)->base + _column_5098);
        _2 = (int)SEQ_PTR(_b_5095);
        _2630 = (int)*(((s1_ptr)_2)->base + _column_5098);
        if (IS_ATOM_INT(_2629) && IS_ATOM_INT(_2630)){
            _2631 = (_2629 < _2630) ? -1 : (_2629 > _2630);
        }
        else{
            _2631 = compare(_2629, _2630);
        }
        _2629 = NOVALUE;
        _2630 = NOVALUE;
        if (_sign_5097 == (short)_sign_5097)
        _2632 = _sign_5097 * _2631;
        else
        _2632 = NewDouble(_sign_5097 * (double)_2631);
        _2631 = NOVALUE;
        DeRef(_a_5094);
        DeRef(_b_5095);
        DeRef(_cols_5096);
        return _2632;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_5097 == (short)_sign_5097)
        _2633 = _sign_5097 * -1;
        else
        _2633 = NewDouble(_sign_5097 * (double)-1);
        DeRef(_a_5094);
        DeRef(_b_5095);
        DeRef(_cols_5096);
        DeRef(_2632);
        _2632 = NOVALUE;
        return _2633;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5095)){
                _2634 = SEQ_PTR(_b_5095)->length;
        }
        else {
            _2634 = 1;
        }
        if (_column_5098 > _2634)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _2636 = _sign_5097 * 1;
        DeRef(_a_5094);
        DeRef(_b_5095);
        DeRef(_cols_5096);
        DeRef(_2632);
        _2632 = NOVALUE;
        DeRef(_2633);
        _2633 = NOVALUE;
        return _2636;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_5094);
        DeRef(_b_5095);
        DeRef(_cols_5096);
        DeRef(_2632);
        _2632 = NOVALUE;
        DeRef(_2633);
        _2633 = NOVALUE;
        DeRef(_2636);
        _2636 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_5100 = _i_5100 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_5094);
    DeRef(_b_5095);
    DeRef(_cols_5096);
    DeRef(_2632);
    _2632 = NOVALUE;
    DeRef(_2633);
    _2633 = NOVALUE;
    DeRef(_2636);
    _2636 = NOVALUE;
    return 0;
    ;
}


int _24sort_columns(int _x_5134, int _column_list_5135)
{
    int _2640 = NOVALUE;
    int _2639 = NOVALUE;
    int _2638 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return custom_sort(routine_id("column_compare"), x, {column_list})*/
    _2638 = CRoutineId(274, 24, _2637);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_column_list_5135);
    *((int *)(_2+4)) = _column_list_5135;
    _2639 = MAKE_SEQ(_1);
    RefDS(_x_5134);
    _2640 = _24custom_sort(_2638, _x_5134, _2639, 1);
    _2638 = NOVALUE;
    _2639 = NOVALUE;
    DeRefDS(_x_5134);
    DeRefDS(_column_list_5135);
    return _2640;
    ;
}
int sort_columns() __attribute__ ((alias ("_24sort_columns")));


int _24merge(int _a_5142, int _b_5143, int _compfunc_5144, int _userdata_5145)
{
    int _al_5146 = NOVALUE;
    int _bl_5147 = NOVALUE;
    int _n_5148 = NOVALUE;
    int _r_5149 = NOVALUE;
    int _s_5150 = NOVALUE;
    int _2684 = NOVALUE;
    int _2683 = NOVALUE;
    int _2682 = NOVALUE;
    int _2680 = NOVALUE;
    int _2679 = NOVALUE;
    int _2678 = NOVALUE;
    int _2677 = NOVALUE;
    int _2675 = NOVALUE;
    int _2672 = NOVALUE;
    int _2670 = NOVALUE;
    int _2667 = NOVALUE;
    int _2666 = NOVALUE;
    int _2665 = NOVALUE;
    int _2664 = NOVALUE;
    int _2663 = NOVALUE;
    int _2662 = NOVALUE;
    int _2661 = NOVALUE;
    int _2658 = NOVALUE;
    int _2656 = NOVALUE;
    int _2653 = NOVALUE;
    int _2652 = NOVALUE;
    int _2651 = NOVALUE;
    int _2650 = NOVALUE;
    int _2649 = NOVALUE;
    int _2648 = NOVALUE;
    int _2647 = NOVALUE;
    int _2646 = NOVALUE;
    int _2643 = NOVALUE;
    int _2642 = NOVALUE;
    int _2641 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_compfunc_5144)) {
        _1 = (long)(DBL_PTR(_compfunc_5144)->dbl);
        DeRefDS(_compfunc_5144);
        _compfunc_5144 = _1;
    }

    /** 	al = 1*/
    _al_5146 = 1;

    /** 	bl = 1*/
    _bl_5147 = 1;

    /** 	n = 1*/
    _n_5148 = 1;

    /** 	s = repeat(0, length(a) + length(b))*/
    if (IS_SEQUENCE(_a_5142)){
            _2641 = SEQ_PTR(_a_5142)->length;
    }
    else {
        _2641 = 1;
    }
    if (IS_SEQUENCE(_b_5143)){
            _2642 = SEQ_PTR(_b_5143)->length;
    }
    else {
        _2642 = 1;
    }
    _2643 = _2641 + _2642;
    _2641 = NOVALUE;
    _2642 = NOVALUE;
    DeRef(_s_5150);
    _s_5150 = Repeat(0, _2643);
    _2643 = NOVALUE;

    /** 	if compfunc >= 0 then*/
    if (_compfunc_5144 < 0)
    goto L1; // [40] 149

    /** 		while al <= length(a) and bl <= length(b) do*/
L2: 
    if (IS_SEQUENCE(_a_5142)){
            _2646 = SEQ_PTR(_a_5142)->length;
    }
    else {
        _2646 = 1;
    }
    _2647 = (_al_5146 <= _2646);
    _2646 = NOVALUE;
    if (_2647 == 0) {
        goto L3; // [56] 244
    }
    if (IS_SEQUENCE(_b_5143)){
            _2649 = SEQ_PTR(_b_5143)->length;
    }
    else {
        _2649 = 1;
    }
    _2650 = (_bl_5147 <= _2649);
    _2649 = NOVALUE;
    if (_2650 == 0)
    {
        DeRef(_2650);
        _2650 = NOVALUE;
        goto L3; // [68] 244
    }
    else{
        DeRef(_2650);
        _2650 = NOVALUE;
    }

    /** 			r = call_func(compfunc,{a[al], b[bl], userdata})*/
    _2 = (int)SEQ_PTR(_a_5142);
    _2651 = (int)*(((s1_ptr)_2)->base + _al_5146);
    _2 = (int)SEQ_PTR(_b_5143);
    _2652 = (int)*(((s1_ptr)_2)->base + _bl_5147);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_2651);
    *((int *)(_2+4)) = _2651;
    Ref(_2652);
    *((int *)(_2+8)) = _2652;
    Ref(_userdata_5145);
    *((int *)(_2+12)) = _userdata_5145;
    _2653 = MAKE_SEQ(_1);
    _2652 = NOVALUE;
    _2651 = NOVALUE;
    _1 = (int)SEQ_PTR(_2653);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_compfunc_5144].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4), 
                        *(int *)(_2+8), 
                        *(int *)(_2+12)
                         );
    _r_5149 = _1;
    DeRefDS(_2653);
    _2653 = NOVALUE;
    if (!IS_ATOM_INT(_r_5149)) {
        _1 = (long)(DBL_PTR(_r_5149)->dbl);
        DeRefDS(_r_5149);
        _r_5149 = _1;
    }

    /** 			if r <= 0 then*/
    if (_r_5149 > 0)
    goto L4; // [95] 118

    /** 				s[n] = a[al]*/
    _2 = (int)SEQ_PTR(_a_5142);
    _2656 = (int)*(((s1_ptr)_2)->base + _al_5146);
    Ref(_2656);
    _2 = (int)SEQ_PTR(_s_5150);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5150 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5148);
    _1 = *(int *)_2;
    *(int *)_2 = _2656;
    if( _1 != _2656 ){
        DeRef(_1);
    }
    _2656 = NOVALUE;

    /** 				al += 1*/
    _al_5146 = _al_5146 + 1;
    goto L5; // [115] 135
L4: 

    /** 				s[n] = b[bl]*/
    _2 = (int)SEQ_PTR(_b_5143);
    _2658 = (int)*(((s1_ptr)_2)->base + _bl_5147);
    Ref(_2658);
    _2 = (int)SEQ_PTR(_s_5150);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5150 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5148);
    _1 = *(int *)_2;
    *(int *)_2 = _2658;
    if( _1 != _2658 ){
        DeRef(_1);
    }
    _2658 = NOVALUE;

    /** 				bl += 1*/
    _bl_5147 = _bl_5147 + 1;
L5: 

    /** 			n += 1*/
    _n_5148 = _n_5148 + 1;

    /** 		end while*/
    goto L2; // [143] 49
    goto L3; // [146] 244
L1: 

    /** 		while al <= length(a) and bl <= length(b) do*/
L6: 
    if (IS_SEQUENCE(_a_5142)){
            _2661 = SEQ_PTR(_a_5142)->length;
    }
    else {
        _2661 = 1;
    }
    _2662 = (_al_5146 <= _2661);
    _2661 = NOVALUE;
    if (_2662 == 0) {
        goto L7; // [161] 243
    }
    if (IS_SEQUENCE(_b_5143)){
            _2664 = SEQ_PTR(_b_5143)->length;
    }
    else {
        _2664 = 1;
    }
    _2665 = (_bl_5147 <= _2664);
    _2664 = NOVALUE;
    if (_2665 == 0)
    {
        DeRef(_2665);
        _2665 = NOVALUE;
        goto L7; // [173] 243
    }
    else{
        DeRef(_2665);
        _2665 = NOVALUE;
    }

    /** 			r = compare(a[al], b[bl])*/
    _2 = (int)SEQ_PTR(_a_5142);
    _2666 = (int)*(((s1_ptr)_2)->base + _al_5146);
    _2 = (int)SEQ_PTR(_b_5143);
    _2667 = (int)*(((s1_ptr)_2)->base + _bl_5147);
    if (IS_ATOM_INT(_2666) && IS_ATOM_INT(_2667)){
        _r_5149 = (_2666 < _2667) ? -1 : (_2666 > _2667);
    }
    else{
        _r_5149 = compare(_2666, _2667);
    }
    _2666 = NOVALUE;
    _2667 = NOVALUE;

    /** 			if r <= 0 then*/
    if (_r_5149 > 0)
    goto L8; // [192] 215

    /** 				s[n] = a[al]*/
    _2 = (int)SEQ_PTR(_a_5142);
    _2670 = (int)*(((s1_ptr)_2)->base + _al_5146);
    Ref(_2670);
    _2 = (int)SEQ_PTR(_s_5150);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5150 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5148);
    _1 = *(int *)_2;
    *(int *)_2 = _2670;
    if( _1 != _2670 ){
        DeRef(_1);
    }
    _2670 = NOVALUE;

    /** 				al += 1*/
    _al_5146 = _al_5146 + 1;
    goto L9; // [212] 232
L8: 

    /** 				s[n] = b[bl]*/
    _2 = (int)SEQ_PTR(_b_5143);
    _2672 = (int)*(((s1_ptr)_2)->base + _bl_5147);
    Ref(_2672);
    _2 = (int)SEQ_PTR(_s_5150);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5150 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_5148);
    _1 = *(int *)_2;
    *(int *)_2 = _2672;
    if( _1 != _2672 ){
        DeRef(_1);
    }
    _2672 = NOVALUE;

    /** 				bl += 1*/
    _bl_5147 = _bl_5147 + 1;
L9: 

    /** 			n += 1*/
    _n_5148 = _n_5148 + 1;

    /** 		end while*/
    goto L6; // [240] 154
L7: 
L3: 

    /** 	if al > length(a) then*/
    if (IS_SEQUENCE(_a_5142)){
            _2675 = SEQ_PTR(_a_5142)->length;
    }
    else {
        _2675 = 1;
    }
    if (_al_5146 <= _2675)
    goto LA; // [249] 274

    /** 		s[n .. $] = b[bl .. $]*/
    if (IS_SEQUENCE(_s_5150)){
            _2677 = SEQ_PTR(_s_5150)->length;
    }
    else {
        _2677 = 1;
    }
    if (IS_SEQUENCE(_b_5143)){
            _2678 = SEQ_PTR(_b_5143)->length;
    }
    else {
        _2678 = 1;
    }
    rhs_slice_target = (object_ptr)&_2679;
    RHS_Slice(_b_5143, _bl_5147, _2678);
    assign_slice_seq = (s1_ptr *)&_s_5150;
    AssignSlice(_n_5148, _2677, _2679);
    _2677 = NOVALUE;
    DeRefDS(_2679);
    _2679 = NOVALUE;
    goto LB; // [271] 303
LA: 

    /** 	elsif bl > length(b) then*/
    if (IS_SEQUENCE(_b_5143)){
            _2680 = SEQ_PTR(_b_5143)->length;
    }
    else {
        _2680 = 1;
    }
    if (_bl_5147 <= _2680)
    goto LC; // [279] 302

    /** 		s[n .. $] = a[al .. $]*/
    if (IS_SEQUENCE(_s_5150)){
            _2682 = SEQ_PTR(_s_5150)->length;
    }
    else {
        _2682 = 1;
    }
    if (IS_SEQUENCE(_a_5142)){
            _2683 = SEQ_PTR(_a_5142)->length;
    }
    else {
        _2683 = 1;
    }
    rhs_slice_target = (object_ptr)&_2684;
    RHS_Slice(_a_5142, _al_5146, _2683);
    assign_slice_seq = (s1_ptr *)&_s_5150;
    AssignSlice(_n_5148, _2682, _2684);
    _2682 = NOVALUE;
    DeRefDS(_2684);
    _2684 = NOVALUE;
LC: 
LB: 

    /** 	return s*/
    DeRefDS(_a_5142);
    DeRefDS(_b_5143);
    DeRef(_userdata_5145);
    DeRef(_2647);
    _2647 = NOVALUE;
    DeRef(_2662);
    _2662 = NOVALUE;
    return _s_5150;
    ;
}
int merge() __attribute__ ((alias ("_24merge")));


int _24insertion_sort(int _s_5207, int _e_5208, int _compfunc_5209, int _userdata_5210)
{
    int _key_5211 = NOVALUE;
    int _a_5212 = NOVALUE;
    int _2728 = NOVALUE;
    int _2727 = NOVALUE;
    int _2726 = NOVALUE;
    int _2725 = NOVALUE;
    int _2724 = NOVALUE;
    int _2723 = NOVALUE;
    int _2719 = NOVALUE;
    int _2718 = NOVALUE;
    int _2717 = NOVALUE;
    int _2716 = NOVALUE;
    int _2714 = NOVALUE;
    int _2713 = NOVALUE;
    int _2712 = NOVALUE;
    int _2711 = NOVALUE;
    int _2710 = NOVALUE;
    int _2709 = NOVALUE;
    int _2708 = NOVALUE;
    int _2704 = NOVALUE;
    int _2703 = NOVALUE;
    int _2702 = NOVALUE;
    int _2699 = NOVALUE;
    int _2697 = NOVALUE;
    int _2696 = NOVALUE;
    int _2695 = NOVALUE;
    int _2694 = NOVALUE;
    int _2693 = NOVALUE;
    int _2692 = NOVALUE;
    int _2691 = NOVALUE;
    int _2690 = NOVALUE;
    int _2689 = NOVALUE;
    int _2687 = NOVALUE;
    int _2685 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_compfunc_5209)) {
        _1 = (long)(DBL_PTR(_compfunc_5209)->dbl);
        DeRefDS(_compfunc_5209);
        _compfunc_5209 = _1;
    }

    /** 	if atom(e) then*/
    _2685 = IS_ATOM(_e_5208);
    if (_2685 == 0)
    {
        _2685 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _2685 = NOVALUE;
    }

    /** 		s &= e*/
    if (IS_SEQUENCE(_s_5207) && IS_ATOM(_e_5208)) {
        Ref(_e_5208);
        Append(&_s_5207, _s_5207, _e_5208);
    }
    else if (IS_ATOM(_s_5207) && IS_SEQUENCE(_e_5208)) {
    }
    else {
        Concat((object_ptr)&_s_5207, _s_5207, _e_5208);
    }
    goto L2; // [19] 78
L1: 

    /** 	elsif length(e) > 1 then*/
    if (IS_SEQUENCE(_e_5208)){
            _2687 = SEQ_PTR(_e_5208)->length;
    }
    else {
        _2687 = 1;
    }
    if (_2687 <= 1)
    goto L3; // [27] 77

    /** 		return merge(insertion_sort(s,,compfunc, userdata), insertion_sort(e,,compfunc, userdata), compfunc, userdata)*/
    RefDS(_s_5207);
    DeRef(_2689);
    _2689 = _s_5207;
    DeRef(_2690);
    _2690 = _compfunc_5209;
    Ref(_userdata_5210);
    DeRef(_2691);
    _2691 = _userdata_5210;
    RefDS(_5);
    _2692 = _24insertion_sort(_2689, _5, _2690, _2691);
    _2689 = NOVALUE;
    _2690 = NOVALUE;
    _2691 = NOVALUE;
    Ref(_e_5208);
    DeRef(_2693);
    _2693 = _e_5208;
    DeRef(_2694);
    _2694 = _compfunc_5209;
    Ref(_userdata_5210);
    DeRef(_2695);
    _2695 = _userdata_5210;
    RefDS(_5);
    _2696 = _24insertion_sort(_2693, _5, _2694, _2695);
    _2693 = NOVALUE;
    _2694 = NOVALUE;
    _2695 = NOVALUE;
    Ref(_userdata_5210);
    _2697 = _24merge(_2692, _2696, _compfunc_5209, _userdata_5210);
    _2692 = NOVALUE;
    _2696 = NOVALUE;
    DeRefDS(_s_5207);
    DeRef(_e_5208);
    DeRef(_userdata_5210);
    DeRef(_key_5211);
    return _2697;
L3: 
L2: 

    /** 	if compfunc = -1 then*/
    if (_compfunc_5209 != -1)
    goto L4; // [80] 225

    /** 		for j = 2 to length(s) label "outer" do*/
    if (IS_SEQUENCE(_s_5207)){
            _2699 = SEQ_PTR(_s_5207)->length;
    }
    else {
        _2699 = 1;
    }
    {
        int _j_5231;
        _j_5231 = 2;
L5: 
        if (_j_5231 > _2699){
            goto L6; // [89] 222
        }

        /** 			key = s[j]*/
        DeRef(_key_5211);
        _2 = (int)SEQ_PTR(_s_5207);
        _key_5211 = (int)*(((s1_ptr)_2)->base + _j_5231);
        Ref(_key_5211);

        /** 			for i = j - 1 to 1 by -1 do*/
        _2702 = _j_5231 - 1;
        {
            int _i_5236;
            _i_5236 = _2702;
L7: 
            if (_i_5236 < 1){
                goto L8; // [108] 187
            }

            /** 				if compare(s[i], key) <= 0 then*/
            _2 = (int)SEQ_PTR(_s_5207);
            _2703 = (int)*(((s1_ptr)_2)->base + _i_5236);
            if (IS_ATOM_INT(_2703) && IS_ATOM_INT(_key_5211)){
                _2704 = (_2703 < _key_5211) ? -1 : (_2703 > _key_5211);
            }
            else{
                _2704 = compare(_2703, _key_5211);
            }
            _2703 = NOVALUE;
            if (_2704 > 0)
            goto L9; // [125] 173

            /** 					a = i+1*/
            _a_5212 = _i_5236 + 1;

            /** 					if a != j then*/
            if (_a_5212 == _j_5231)
            goto LA; // [137] 217

            /** 						s[a+1 .. j] = s[a .. j-1]*/
            _2708 = _a_5212 + 1;
            _2709 = _j_5231 - 1;
            rhs_slice_target = (object_ptr)&_2710;
            RHS_Slice(_s_5207, _a_5212, _2709);
            assign_slice_seq = (s1_ptr *)&_s_5207;
            AssignSlice(_2708, _j_5231, _2710);
            _2708 = NOVALUE;
            DeRefDS(_2710);
            _2710 = NOVALUE;

            /** 						s[a] = key*/
            Ref(_key_5211);
            _2 = (int)SEQ_PTR(_s_5207);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_5207 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _a_5212);
            _1 = *(int *)_2;
            *(int *)_2 = _key_5211;
            DeRef(_1);

            /** 					continue "outer"*/
            goto LA; // [170] 217
L9: 

            /** 				a = i*/
            _a_5212 = _i_5236;

            /** 			end for*/
            _i_5236 = _i_5236 + -1;
            goto L7; // [182] 115
L8: 
            ;
        }

        /** 			s[a+1 .. j] = s[a .. j-1]*/
        _2711 = _a_5212 + 1;
        if (_2711 > MAXINT){
            _2711 = NewDouble((double)_2711);
        }
        _2712 = _j_5231 - 1;
        rhs_slice_target = (object_ptr)&_2713;
        RHS_Slice(_s_5207, _a_5212, _2712);
        assign_slice_seq = (s1_ptr *)&_s_5207;
        AssignSlice(_2711, _j_5231, _2713);
        DeRef(_2711);
        _2711 = NOVALUE;
        DeRefDS(_2713);
        _2713 = NOVALUE;

        /** 			s[a] = key*/
        Ref(_key_5211);
        _2 = (int)SEQ_PTR(_s_5207);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_5207 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5212);
        _1 = *(int *)_2;
        *(int *)_2 = _key_5211;
        DeRef(_1);

        /** 		end for*/
LA: 
        _j_5231 = _j_5231 + 1;
        goto L5; // [217] 96
L6: 
        ;
    }
    goto LB; // [222] 370
L4: 

    /** 		for j = 2 to length(s) label "outer" do*/
    if (IS_SEQUENCE(_s_5207)){
            _2714 = SEQ_PTR(_s_5207)->length;
    }
    else {
        _2714 = 1;
    }
    {
        int _j_5253;
        _j_5253 = 2;
LC: 
        if (_j_5253 > _2714){
            goto LD; // [230] 369
        }

        /** 			key = s[j]*/
        DeRef(_key_5211);
        _2 = (int)SEQ_PTR(_s_5207);
        _key_5211 = (int)*(((s1_ptr)_2)->base + _j_5253);
        Ref(_key_5211);

        /** 			for i = j - 1 to 1 by -1 do*/
        _2716 = _j_5253 - 1;
        {
            int _i_5257;
            _i_5257 = _2716;
LE: 
            if (_i_5257 < 1){
                goto LF; // [249] 334
            }

            /** 				if call_func(compfunc,{s[i], key, userdata}) <= 0 then*/
            _2 = (int)SEQ_PTR(_s_5207);
            _2717 = (int)*(((s1_ptr)_2)->base + _i_5257);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_2717);
            *((int *)(_2+4)) = _2717;
            Ref(_key_5211);
            *((int *)(_2+8)) = _key_5211;
            Ref(_userdata_5210);
            *((int *)(_2+12)) = _userdata_5210;
            _2718 = MAKE_SEQ(_1);
            _2717 = NOVALUE;
            _1 = (int)SEQ_PTR(_2718);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_compfunc_5209].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            DeRef(_2719);
            _2719 = _1;
            DeRefDS(_2718);
            _2718 = NOVALUE;
            if (binary_op_a(GREATER, _2719, 0)){
                DeRef(_2719);
                _2719 = NOVALUE;
                goto L10; // [272] 320
            }
            DeRef(_2719);
            _2719 = NOVALUE;

            /** 					a = i+1*/
            _a_5212 = _i_5257 + 1;

            /** 					if a != j then*/
            if (_a_5212 == _j_5253)
            goto L11; // [284] 364

            /** 						s[a+1 .. j] = s[a .. j-1]*/
            _2723 = _a_5212 + 1;
            _2724 = _j_5253 - 1;
            rhs_slice_target = (object_ptr)&_2725;
            RHS_Slice(_s_5207, _a_5212, _2724);
            assign_slice_seq = (s1_ptr *)&_s_5207;
            AssignSlice(_2723, _j_5253, _2725);
            _2723 = NOVALUE;
            DeRefDS(_2725);
            _2725 = NOVALUE;

            /** 						s[a] = key*/
            Ref(_key_5211);
            _2 = (int)SEQ_PTR(_s_5207);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_5207 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _a_5212);
            _1 = *(int *)_2;
            *(int *)_2 = _key_5211;
            DeRef(_1);

            /** 					continue "outer"*/
            goto L11; // [317] 364
L10: 

            /** 				a = i*/
            _a_5212 = _i_5257;

            /** 			end for*/
            _i_5257 = _i_5257 + -1;
            goto LE; // [329] 256
LF: 
            ;
        }

        /** 			s[a+1 .. j] = s[a .. j-1]*/
        _2726 = _a_5212 + 1;
        if (_2726 > MAXINT){
            _2726 = NewDouble((double)_2726);
        }
        _2727 = _j_5253 - 1;
        rhs_slice_target = (object_ptr)&_2728;
        RHS_Slice(_s_5207, _a_5212, _2727);
        assign_slice_seq = (s1_ptr *)&_s_5207;
        AssignSlice(_2726, _j_5253, _2728);
        DeRef(_2726);
        _2726 = NOVALUE;
        DeRefDS(_2728);
        _2728 = NOVALUE;

        /** 			s[a] = key*/
        Ref(_key_5211);
        _2 = (int)SEQ_PTR(_s_5207);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_5207 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5212);
        _1 = *(int *)_2;
        *(int *)_2 = _key_5211;
        DeRef(_1);

        /** 		end for*/
L11: 
        _j_5253 = _j_5253 + 1;
        goto LC; // [364] 237
LD: 
        ;
    }
LB: 

    /** 	return s*/
    DeRef(_e_5208);
    DeRef(_userdata_5210);
    DeRef(_key_5211);
    DeRef(_2702);
    _2702 = NOVALUE;
    DeRef(_2716);
    _2716 = NOVALUE;
    DeRef(_2697);
    _2697 = NOVALUE;
    DeRef(_2709);
    _2709 = NOVALUE;
    DeRef(_2712);
    _2712 = NOVALUE;
    DeRef(_2724);
    _2724 = NOVALUE;
    DeRef(_2727);
    _2727 = NOVALUE;
    return _s_5207;
    ;
}
int insertion_sort() __attribute__ ((alias ("_24insertion_sort")));



// 0xC8FC35B6
