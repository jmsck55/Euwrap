// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _54format_base_request(int _request_type_22957, int _url_22958, int _headers_22959)
{
    int _request_22960 = NOVALUE;
    int _formatted_request_22961 = NOVALUE;
    int _noport_22962 = NOVALUE;
    int _parsedUrl_22963 = NOVALUE;
    int _host_22973 = NOVALUE;
    int _port_22976 = NOVALUE;
    int _path_22981 = NOVALUE;
    int _has_user_agent_23006 = NOVALUE;
    int _has_connection_23007 = NOVALUE;
    int _header_23013 = NOVALUE;
    int _12810 = NOVALUE;
    int _12808 = NOVALUE;
    int _12806 = NOVALUE;
    int _12805 = NOVALUE;
    int _12803 = NOVALUE;
    int _12801 = NOVALUE;
    int _12800 = NOVALUE;
    int _12798 = NOVALUE;
    int _12795 = NOVALUE;
    int _12792 = NOVALUE;
    int _12791 = NOVALUE;
    int _12789 = NOVALUE;
    int _12788 = NOVALUE;
    int _12786 = NOVALUE;
    int _12785 = NOVALUE;
    int _12780 = NOVALUE;
    int _12778 = NOVALUE;
    int _12777 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence request = ""*/
    RefDS(_5);
    DeRefi(_request_22960);
    _request_22960 = _5;

    /** 	integer noport = 0*/
    _noport_22962 = 0;

    /** 	object parsedUrl = url:parse(url)*/
    RefDS(_url_22958);
    _0 = _parsedUrl_22963;
    _parsedUrl_22963 = _55parse(_url_22958, 0);
    DeRef(_0);

    /** 	if atom(parsedUrl) then*/
    _12777 = IS_ATOM(_parsedUrl_22963);
    if (_12777 == 0)
    {
        _12777 = NOVALUE;
        goto L1; // [29] 41
    }
    else{
        _12777 = NOVALUE;
    }

    /** 		return ERR_MALFORMED_URL*/
    DeRefDSi(_request_type_22957);
    DeRefDS(_url_22958);
    DeRef(_headers_22959);
    DeRefDSi(_request_22960);
    DeRef(_formatted_request_22961);
    DeRef(_parsedUrl_22963);
    DeRef(_host_22973);
    DeRef(_path_22981);
    return -1;
    goto L2; // [38] 64
L1: 

    /** 	elsif not equal(parsedUrl[URL_PROTOCOL], "http") then*/
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _12778 = (int)*(((s1_ptr)_2)->base + 1);
    if (_12778 == _12779)
    _12780 = 1;
    else if (IS_ATOM_INT(_12778) && IS_ATOM_INT(_12779))
    _12780 = 0;
    else
    _12780 = (compare(_12778, _12779) == 0);
    _12778 = NOVALUE;
    if (_12780 != 0)
    goto L3; // [53] 63
    _12780 = NOVALUE;

    /** 		return ERR_INVALID_PROTOCOL*/
    DeRefDSi(_request_type_22957);
    DeRefDS(_url_22958);
    DeRef(_headers_22959);
    DeRefi(_request_22960);
    DeRef(_formatted_request_22961);
    DeRef(_parsedUrl_22963);
    DeRef(_host_22973);
    DeRef(_path_22981);
    return -2;
L3: 
L2: 

    /** 	sequence host = parsedUrl[URL_HOSTNAME]*/
    DeRef(_host_22973);
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _host_22973 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_host_22973);

    /** 	integer port = parsedUrl[URL_PORT]*/
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _port_22976 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_port_22976)){
        _port_22976 = (long)DBL_PTR(_port_22976)->dbl;
    }

    /** 	if port = 0 then*/
    if (_port_22976 != 0)
    goto L4; // [86] 101

    /** 		port = 80*/
    _port_22976 = 80;

    /** 		noport = 1*/
    _noport_22962 = 1;
L4: 

    /** 	sequence path*/

    /** 	if sequence(parsedUrl[URL_PATH]) then*/
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _12785 = (int)*(((s1_ptr)_2)->base + 4);
    _12786 = IS_SEQUENCE(_12785);
    _12785 = NOVALUE;
    if (_12786 == 0)
    {
        _12786 = NOVALUE;
        goto L5; // [114] 130
    }
    else{
        _12786 = NOVALUE;
    }

    /** 		path = parsedUrl[URL_PATH]*/
    DeRef(_path_22981);
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _path_22981 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_path_22981);
    goto L6; // [127] 138
L5: 

    /** 		path = "/"*/
    RefDS(_12168);
    DeRef(_path_22981);
    _path_22981 = _12168;
L6: 

    /** 	if sequence(parsedUrl[URL_QUERY_STRING]) then*/
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _12788 = (int)*(((s1_ptr)_2)->base + 7);
    _12789 = IS_SEQUENCE(_12788);
    _12788 = NOVALUE;
    if (_12789 == 0)
    {
        _12789 = NOVALUE;
        goto L7; // [149] 171
    }
    else{
        _12789 = NOVALUE;
    }

    /** 		path &= "?" & parsedUrl[URL_QUERY_STRING]*/
    _2 = (int)SEQ_PTR(_parsedUrl_22963);
    _12791 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_12790) && IS_ATOM(_12791)) {
        Ref(_12791);
        Append(&_12792, _12790, _12791);
    }
    else if (IS_ATOM(_12790) && IS_SEQUENCE(_12791)) {
    }
    else {
        Concat((object_ptr)&_12792, _12790, _12791);
    }
    _12791 = NOVALUE;
    Concat((object_ptr)&_path_22981, _path_22981, _12792);
    DeRefDS(_12792);
    _12792 = NOVALUE;
L7: 

    /** 	if noport then*/
    if (_noport_22962 == 0)
    {
        goto L8; // [173] 193
    }
    else{
    }

    /** 	request = sprintf("%s %s HTTP/1.0\r\nHost: %s\r\n", {*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_request_type_22957);
    *((int *)(_2+4)) = _request_type_22957;
    RefDS(_path_22981);
    *((int *)(_2+8)) = _path_22981;
    RefDS(_host_22973);
    *((int *)(_2+12)) = _host_22973;
    _12795 = MAKE_SEQ(_1);
    DeRefi(_request_22960);
    _request_22960 = EPrintf(-9999999, _12794, _12795);
    DeRefDS(_12795);
    _12795 = NOVALUE;
    goto L9; // [190] 209
L8: 

    /** 	request = sprintf("%s %s HTTP/1.0\r\nHost: %s:%d\r\n", {*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_request_type_22957);
    *((int *)(_2+4)) = _request_type_22957;
    RefDS(_path_22981);
    *((int *)(_2+8)) = _path_22981;
    RefDS(_host_22973);
    *((int *)(_2+12)) = _host_22973;
    *((int *)(_2+16)) = _port_22976;
    _12798 = MAKE_SEQ(_1);
    DeRefi(_request_22960);
    _request_22960 = EPrintf(-9999999, _12797, _12798);
    DeRefDS(_12798);
    _12798 = NOVALUE;
L9: 

    /** 	integer has_user_agent = 0*/
    _has_user_agent_23006 = 0;

    /** 	integer has_connection = 0*/
    _has_connection_23007 = 0;

    /** 	if sequence(headers) then*/
    _12800 = IS_SEQUENCE(_headers_22959);
    if (_12800 == 0)
    {
        _12800 = NOVALUE;
        goto LA; // [224] 306
    }
    else{
        _12800 = NOVALUE;
    }

    /** 		for i = 1 to length(headers) do*/
    if (IS_SEQUENCE(_headers_22959)){
            _12801 = SEQ_PTR(_headers_22959)->length;
    }
    else {
        _12801 = 1;
    }
    {
        int _i_23011;
        _i_23011 = 1;
LB: 
        if (_i_23011 > _12801){
            goto LC; // [232] 305
        }

        /** 			object header = headers[i]*/
        DeRef(_header_23013);
        _2 = (int)SEQ_PTR(_headers_22959);
        _header_23013 = (int)*(((s1_ptr)_2)->base + _i_23011);
        Ref(_header_23013);

        /** 			if equal(header[1], "User-Agent") then*/
        _2 = (int)SEQ_PTR(_header_23013);
        _12803 = (int)*(((s1_ptr)_2)->base + 1);
        if (_12803 == _12804)
        _12805 = 1;
        else if (IS_ATOM_INT(_12803) && IS_ATOM_INT(_12804))
        _12805 = 0;
        else
        _12805 = (compare(_12803, _12804) == 0);
        _12803 = NOVALUE;
        if (_12805 == 0)
        {
            _12805 = NOVALUE;
            goto LD; // [255] 266
        }
        else{
            _12805 = NOVALUE;
        }

        /** 				has_user_agent = 1*/
        _has_user_agent_23006 = 1;
        goto LE; // [263] 286
LD: 

        /** 			elsif equal(header[1], "Connection") then*/
        _2 = (int)SEQ_PTR(_header_23013);
        _12806 = (int)*(((s1_ptr)_2)->base + 1);
        if (_12806 == _12807)
        _12808 = 1;
        else if (IS_ATOM_INT(_12806) && IS_ATOM_INT(_12807))
        _12808 = 0;
        else
        _12808 = (compare(_12806, _12807) == 0);
        _12806 = NOVALUE;
        if (_12808 == 0)
        {
            _12808 = NOVALUE;
            goto LF; // [276] 285
        }
        else{
            _12808 = NOVALUE;
        }

        /** 				has_connection = 1*/
        _has_connection_23007 = 1;
LF: 
LE: 

        /** 			request &= sprintf("%s: %s\r\n", header)*/
        _12810 = EPrintf(-9999999, _12809, _header_23013);
        Concat((object_ptr)&_request_22960, _request_22960, _12810);
        DeRefDS(_12810);
        _12810 = NOVALUE;
        DeRef(_header_23013);
        _header_23013 = NOVALUE;

        /** 		end for*/
        _i_23011 = _i_23011 + 1;
        goto LB; // [300] 239
LC: 
        ;
    }
LA: 

    /** 	if not has_user_agent then*/
    if (_has_user_agent_23006 != 0)
    goto L10; // [308] 320

    /** 		request &= USER_AGENT_HEADER*/
    Concat((object_ptr)&_request_22960, _request_22960, _54USER_AGENT_HEADER_22921);
L10: 

    /** 	if not has_connection then*/
    if (_has_connection_23007 != 0)
    goto L11; // [322] 332

    /** 		request &= "Connection: close\r\n"*/
    Concat((object_ptr)&_request_22960, _request_22960, _12815);
L11: 

    /** 	formatted_request = repeat(0, FR_SIZE)*/
    DeRef(_formatted_request_22961);
    _formatted_request_22961 = Repeat(0, 4);

    /** 	formatted_request[R_HOST] = host*/
    RefDS(_host_22973);
    _2 = (int)SEQ_PTR(_formatted_request_22961);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_22961 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _host_22973;

    /** 	formatted_request[R_PORT] = port*/
    _2 = (int)SEQ_PTR(_formatted_request_22961);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_22961 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _port_22976;
    DeRef(_1);

    /** 	formatted_request[R_PATH] = path*/
    RefDS(_path_22981);
    _2 = (int)SEQ_PTR(_formatted_request_22961);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_22961 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _path_22981;
    DeRef(_1);

    /** 	formatted_request[R_REQUEST] = request*/
    RefDS(_request_22960);
    _2 = (int)SEQ_PTR(_formatted_request_22961);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _formatted_request_22961 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _request_22960;
    DeRef(_1);

    /** 	return formatted_request*/
    DeRefDSi(_request_type_22957);
    DeRefDS(_url_22958);
    DeRef(_headers_22959);
    DeRefDSi(_request_22960);
    DeRef(_parsedUrl_22963);
    DeRefDS(_host_22973);
    DeRefDS(_path_22981);
    return _formatted_request_22961;
    ;
}


int _54form_urlencode(int _kvpairs_23036)
{
    int _data_23037 = NOVALUE;
    int _kvpair_23041 = NOVALUE;
    int _12827 = NOVALUE;
    int _12826 = NOVALUE;
    int _12825 = NOVALUE;
    int _12823 = NOVALUE;
    int _12818 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence data = ""*/
    RefDS(_5);
    DeRef(_data_23037);
    _data_23037 = _5;

    /** 	for i = 1 to length(kvpairs) do*/
    if (IS_SEQUENCE(_kvpairs_23036)){
            _12818 = SEQ_PTR(_kvpairs_23036)->length;
    }
    else {
        _12818 = 1;
    }
    {
        int _i_23039;
        _i_23039 = 1;
L1: 
        if (_i_23039 > _12818){
            goto L2; // [15] 75
        }

        /** 		object kvpair = kvpairs[i]*/
        DeRef(_kvpair_23041);
        _2 = (int)SEQ_PTR(_kvpairs_23036);
        _kvpair_23041 = (int)*(((s1_ptr)_2)->base + _i_23039);
        Ref(_kvpair_23041);

        /** 		if i > 1 then*/
        if (_i_23039 <= 1)
        goto L3; // [30] 41

        /** 			data &= "&"*/
        Concat((object_ptr)&_data_23037, _data_23037, _12821);
L3: 

        /** 		data &= kvpair[1] & "=" & url:encode(kvpair[2])*/
        _2 = (int)SEQ_PTR(_kvpair_23041);
        _12823 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_kvpair_23041);
        _12825 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_12825);
        RefDS(_12702);
        _12826 = _55encode(_12825, _12702);
        _12825 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _12826;
            concat_list[1] = _12824;
            concat_list[2] = _12823;
            Concat_N((object_ptr)&_12827, concat_list, 3);
        }
        DeRef(_12826);
        _12826 = NOVALUE;
        _12823 = NOVALUE;
        Concat((object_ptr)&_data_23037, _data_23037, _12827);
        DeRefDS(_12827);
        _12827 = NOVALUE;
        DeRef(_kvpair_23041);
        _kvpair_23041 = NOVALUE;

        /** 	end for*/
        _i_23039 = _i_23039 + 1;
        goto L1; // [70] 22
L2: 
        ;
    }

    /** 	return data*/
    DeRefDS(_kvpairs_23036);
    return _data_23037;
    ;
}


int _54multipart_form_data_encode(int _kvpairs_23055, int _boundary_23056)
{
    int _data_23057 = NOVALUE;
    int _kvpair_23061 = NOVALUE;
    int _enctyp_23063 = NOVALUE;
    int _mimetyp_23064 = NOVALUE;
    int _12866 = NOVALUE;
    int _12863 = NOVALUE;
    int _12862 = NOVALUE;
    int _12860 = NOVALUE;
    int _12858 = NOVALUE;
    int _12853 = NOVALUE;
    int _12851 = NOVALUE;
    int _12850 = NOVALUE;
    int _12847 = NOVALUE;
    int _12845 = NOVALUE;
    int _12842 = NOVALUE;
    int _12840 = NOVALUE;
    int _12838 = NOVALUE;
    int _12835 = NOVALUE;
    int _12829 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence data = ""*/
    RefDS(_5);
    DeRef(_data_23057);
    _data_23057 = _5;

    /** 	for i = 1 to length(kvpairs) do*/
    if (IS_SEQUENCE(_kvpairs_23055)){
            _12829 = SEQ_PTR(_kvpairs_23055)->length;
    }
    else {
        _12829 = 1;
    }
    {
        int _i_23059;
        _i_23059 = 1;
L1: 
        if (_i_23059 > _12829){
            goto L2; // [17] 200
        }

        /** 		object kvpair = kvpairs[i]*/
        DeRef(_kvpair_23061);
        _2 = (int)SEQ_PTR(_kvpairs_23055);
        _kvpair_23061 = (int)*(((s1_ptr)_2)->base + _i_23059);
        Ref(_kvpair_23061);

        /** 		integer enctyp = ENCODE_NONE*/
        _enctyp_23063 = 0;

        /** 		sequence mimetyp = ""*/
        RefDS(_5);
        DeRef(_mimetyp_23064);
        _mimetyp_23064 = _5;

        /** 		if i > 1 then*/
        if (_i_23059 <= 1)
        goto L3; // [44] 55

        /** 			data &= "\r\n"*/
        Concat((object_ptr)&_data_23057, _data_23057, _12832);
L3: 

        /** 		data &= "--" & boundary & "\r\n"*/
        {
            int concat_list[3];

            concat_list[0] = _12832;
            concat_list[1] = _boundary_23056;
            concat_list[2] = _12834;
            Concat_N((object_ptr)&_12835, concat_list, 3);
        }
        Concat((object_ptr)&_data_23057, _data_23057, _12835);
        DeRefDS(_12835);
        _12835 = NOVALUE;

        /** 		data &= "Content-Disposition: form-data; name=\"" & kvpair[1] & "\""*/
        _2 = (int)SEQ_PTR(_kvpair_23061);
        _12838 = (int)*(((s1_ptr)_2)->base + 1);
        {
            int concat_list[3];

            concat_list[0] = _12839;
            concat_list[1] = _12838;
            concat_list[2] = _12837;
            Concat_N((object_ptr)&_12840, concat_list, 3);
        }
        _12838 = NOVALUE;
        Concat((object_ptr)&_data_23057, _data_23057, _12840);
        DeRefDS(_12840);
        _12840 = NOVALUE;

        /** 		if length(kvpair) = 5 then*/
        if (IS_SEQUENCE(_kvpair_23061)){
                _12842 = SEQ_PTR(_kvpair_23061)->length;
        }
        else {
            _12842 = 1;
        }
        if (_12842 != 5)
        goto L4; // [88] 170

        /** 			data &= "; filename=\"" & kvpair[3] & "\"\r\n"*/
        _2 = (int)SEQ_PTR(_kvpair_23061);
        _12845 = (int)*(((s1_ptr)_2)->base + 3);
        {
            int concat_list[3];

            concat_list[0] = _12846;
            concat_list[1] = _12845;
            concat_list[2] = _12844;
            Concat_N((object_ptr)&_12847, concat_list, 3);
        }
        _12845 = NOVALUE;
        Concat((object_ptr)&_data_23057, _data_23057, _12847);
        DeRefDS(_12847);
        _12847 = NOVALUE;

        /** 			data &= "Content-Type: " & kvpair[4] & "\r\n"*/
        _2 = (int)SEQ_PTR(_kvpair_23061);
        _12850 = (int)*(((s1_ptr)_2)->base + 4);
        {
            int concat_list[3];

            concat_list[0] = _12832;
            concat_list[1] = _12850;
            concat_list[2] = _12849;
            Concat_N((object_ptr)&_12851, concat_list, 3);
        }
        _12850 = NOVALUE;
        Concat((object_ptr)&_data_23057, _data_23057, _12851);
        DeRefDS(_12851);
        _12851 = NOVALUE;

        /** 			switch kvpair[5] do*/
        _2 = (int)SEQ_PTR(_kvpair_23061);
        _12853 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_SEQUENCE(_12853) ){
            goto L5; // [130] 177
        }
        if(!IS_ATOM_INT(_12853)){
            if( (DBL_PTR(_12853)->dbl != (double) ((int) DBL_PTR(_12853)->dbl) ) ){
                goto L5; // [130] 177
            }
            _0 = (int) DBL_PTR(_12853)->dbl;
        }
        else {
            _0 = _12853;
        };
        _12853 = NOVALUE;
        switch ( _0 ){ 

            /** 				case ENCODE_NONE then*/
            case 0:

            /** 				case ENCODE_BASE64 then*/
            goto L5; // [141] 177
            case 1:

            /** 					data &= "Content-Transfer-Encoding: base64\r\n"*/
            Concat((object_ptr)&_data_23057, _data_23057, _12856);

            /** 					kvpair[2] = base64:encode(kvpair[2], 76)*/
            _2 = (int)SEQ_PTR(_kvpair_23061);
            _12858 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_12858);
            _12860 = _30encode(_12858, 76);
            _12858 = NOVALUE;
            _2 = (int)SEQ_PTR(_kvpair_23061);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _kvpair_23061 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _12860;
            if( _1 != _12860 ){
                DeRef(_1);
            }
            _12860 = NOVALUE;
        ;}        goto L5; // [167] 177
L4: 

        /** 			data &= "\r\n"*/
        Concat((object_ptr)&_data_23057, _data_23057, _12832);
L5: 

        /** 		data &= "\r\n" & kvpair[2]*/
        _2 = (int)SEQ_PTR(_kvpair_23061);
        _12862 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_12832) && IS_ATOM(_12862)) {
            Ref(_12862);
            Append(&_12863, _12832, _12862);
        }
        else if (IS_ATOM(_12832) && IS_SEQUENCE(_12862)) {
        }
        else {
            Concat((object_ptr)&_12863, _12832, _12862);
        }
        _12862 = NOVALUE;
        Concat((object_ptr)&_data_23057, _data_23057, _12863);
        DeRefDS(_12863);
        _12863 = NOVALUE;
        DeRef(_kvpair_23061);
        _kvpair_23061 = NOVALUE;
        DeRef(_mimetyp_23064);
        _mimetyp_23064 = NOVALUE;

        /** 	end for*/
        _i_23059 = _i_23059 + 1;
        goto L1; // [195] 24
L2: 
        ;
    }

    /** 	return data & "\r\n--" & boundary & "--"*/
    {
        int concat_list[4];

        concat_list[0] = _12834;
        concat_list[1] = _boundary_23056;
        concat_list[2] = _12865;
        concat_list[3] = _data_23057;
        Concat_N((object_ptr)&_12866, concat_list, 4);
    }
    DeRefDS(_kvpairs_23055);
    DeRefDS(_boundary_23056);
    DeRefDS(_data_23057);
    return _12866;
    ;
}


int _54random_boundary(int _len_23112)
{
    int _boundary_23113 = NOVALUE;
    int _12872 = NOVALUE;
    int _12871 = NOVALUE;
    int _12870 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence boundary = repeat(0, len)*/
    DeRef(_boundary_23113);
    _boundary_23113 = Repeat(0, 20);

    /** 	for i = 1 to len do*/
    _12870 = 20;
    {
        int _i_23116;
        _i_23116 = 1;
L1: 
        if (_i_23116 > 20){
            goto L2; // [14] 43
        }

        /** 		boundary[i] = rand_chars[rand(rand_chars_len)]*/
        _12871 = good_rand() % ((unsigned)_54rand_chars_len_23108) + 1;
        _2 = (int)SEQ_PTR(_54rand_chars_23106);
        _12872 = (int)*(((s1_ptr)_2)->base + _12871);
        Ref(_12872);
        _2 = (int)SEQ_PTR(_boundary_23113);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _boundary_23113 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23116);
        _1 = *(int *)_2;
        *(int *)_2 = _12872;
        if( _1 != _12872 ){
            DeRef(_1);
        }
        _12872 = NOVALUE;

        /** 	end for*/
        _i_23116 = _i_23116 + 1;
        goto L1; // [38] 21
L2: 
        ;
    }

    /** 	return boundary*/
    DeRef(_12871);
    _12871 = NOVALUE;
    return _boundary_23113;
    ;
}


int _54execute_request(int _host_23122, int _port_23123, int _request_23124, int _timeout_23125)
{
    int _addrinfo_23126 = NOVALUE;
    int _sock_23138 = NOVALUE;
    int _send_1__tmp_at103_23148 = NOVALUE;
    int _send_inlined_send_at_103_23147 = NOVALUE;
    int _close_1__tmp_at130_23154 = NOVALUE;
    int _close_inlined_close_at_130_23153 = NOVALUE;
    int _start_time_23155 = NOVALUE;
    int _got_header_23157 = NOVALUE;
    int _content_length_23158 = NOVALUE;
    int _content_23159 = NOVALUE;
    int _headers_23160 = NOVALUE;
    int _has_data_23170 = NOVALUE;
    int _data_23180 = NOVALUE;
    int _receive_1__tmp_at258_23183 = NOVALUE;
    int _receive_inlined_receive_at_258_23182 = NOVALUE;
    int _header_end_pos_23192 = NOVALUE;
    int _raw_header_23196 = NOVALUE;
    int _header_lines_23201 = NOVALUE;
    int _header_23211 = NOVALUE;
    int _this_header_23213 = NOVALUE;
    int _12933 = NOVALUE;
    int _12931 = NOVALUE;
    int _12930 = NOVALUE;
    int _12928 = NOVALUE;
    int _12927 = NOVALUE;
    int _12925 = NOVALUE;
    int _12924 = NOVALUE;
    int _12920 = NOVALUE;
    int _12918 = NOVALUE;
    int _12917 = NOVALUE;
    int _12914 = NOVALUE;
    int _12913 = NOVALUE;
    int _12906 = NOVALUE;
    int _12905 = NOVALUE;
    int _12904 = NOVALUE;
    int _12903 = NOVALUE;
    int _12902 = NOVALUE;
    int _12901 = NOVALUE;
    int _12900 = NOVALUE;
    int _12899 = NOVALUE;
    int _12897 = NOVALUE;
    int _12896 = NOVALUE;
    int _12895 = NOVALUE;
    int _12892 = NOVALUE;
    int _12891 = NOVALUE;
    int _12888 = NOVALUE;
    int _12887 = NOVALUE;
    int _12885 = NOVALUE;
    int _12884 = NOVALUE;
    int _12883 = NOVALUE;
    int _12881 = NOVALUE;
    int _12880 = NOVALUE;
    int _12879 = NOVALUE;
    int _12877 = NOVALUE;
    int _12876 = NOVALUE;
    int _12875 = NOVALUE;
    int _12874 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_23123)) {
        _1 = (long)(DBL_PTR(_port_23123)->dbl);
        DeRefDS(_port_23123);
        _port_23123 = _1;
    }

    /** 	object addrinfo = host_by_name(host)*/
    RefDS(_host_23122);
    _0 = _addrinfo_23126;
    _addrinfo_23126 = _53host_by_name(_host_23122);
    DeRef(_0);

    /** 	if atom(addrinfo) or length(addrinfo) < 3 or length(addrinfo[3]) = 0 then*/
    _12874 = IS_ATOM(_addrinfo_23126);
    if (_12874 != 0) {
        _12875 = 1;
        goto L1; // [20] 35
    }
    if (IS_SEQUENCE(_addrinfo_23126)){
            _12876 = SEQ_PTR(_addrinfo_23126)->length;
    }
    else {
        _12876 = 1;
    }
    _12877 = (_12876 < 3);
    _12876 = NOVALUE;
    _12875 = (_12877 != 0);
L1: 
    if (_12875 != 0) {
        goto L2; // [35] 55
    }
    _2 = (int)SEQ_PTR(_addrinfo_23126);
    _12879 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_12879)){
            _12880 = SEQ_PTR(_12879)->length;
    }
    else {
        _12880 = 1;
    }
    _12879 = NOVALUE;
    _12881 = (_12880 == 0);
    _12880 = NOVALUE;
    if (_12881 == 0)
    {
        DeRef(_12881);
        _12881 = NOVALUE;
        goto L3; // [51] 62
    }
    else{
        DeRef(_12881);
        _12881 = NOVALUE;
    }
L2: 

    /** 		return ERR_HOST_LOOKUP_FAILED*/
    DeRefDS(_host_23122);
    DeRefDS(_request_23124);
    DeRef(_addrinfo_23126);
    DeRef(_sock_23138);
    DeRef(_start_time_23155);
    DeRef(_content_23159);
    DeRef(_headers_23160);
    DeRef(_12877);
    _12877 = NOVALUE;
    _12879 = NOVALUE;
    return -5;
L3: 

    /** 	sock:socket sock = sock:create(sock:AF_INET, sock:SOCK_STREAM, 0)*/
    Ref(_48AF_INET_21748);
    Ref(_48SOCK_STREAM_21758);
    _0 = _sock_23138;
    _sock_23138 = _48create(_48AF_INET_21748, _48SOCK_STREAM_21758, 0);
    DeRef(_0);

    /** 	if sock:connect(sock, addrinfo[3][1], port) != sock:OK then*/
    _2 = (int)SEQ_PTR(_addrinfo_23126);
    _12883 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_12883);
    _12884 = (int)*(((s1_ptr)_2)->base + 1);
    _12883 = NOVALUE;
    Ref(_sock_23138);
    Ref(_12884);
    _12885 = _48connect(_sock_23138, _12884, _port_23123);
    _12884 = NOVALUE;
    if (binary_op_a(EQUALS, _12885, 0)){
        DeRef(_12885);
        _12885 = NOVALUE;
        goto L4; // [90] 101
    }
    DeRef(_12885);
    _12885 = NOVALUE;

    /** 		return ERR_CONNECT_FAILED*/
    DeRefDS(_host_23122);
    DeRefDS(_request_23124);
    DeRef(_addrinfo_23126);
    DeRef(_sock_23138);
    DeRef(_start_time_23155);
    DeRef(_content_23159);
    DeRef(_headers_23160);
    DeRef(_12877);
    _12877 = NOVALUE;
    _12879 = NOVALUE;
    return -6;
L4: 

    /** 	if not sock:send(sock, request, 0) = length(request) then*/

    /** 	return machine_func(M_SOCK_SEND, { sock, data, flags })*/
    _0 = _send_1__tmp_at103_23148;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_23138);
    *((int *)(_2+4)) = _sock_23138;
    RefDS(_request_23124);
    *((int *)(_2+8)) = _request_23124;
    *((int *)(_2+12)) = 0;
    _send_1__tmp_at103_23148 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_send_inlined_send_at_103_23147);
    _send_inlined_send_at_103_23147 = machine(85, _send_1__tmp_at103_23148);
    DeRef(_send_1__tmp_at103_23148);
    _send_1__tmp_at103_23148 = NOVALUE;
    if (IS_ATOM_INT(_send_inlined_send_at_103_23147)) {
        _12887 = (_send_inlined_send_at_103_23147 == 0);
    }
    else {
        _12887 = unary_op(NOT, _send_inlined_send_at_103_23147);
    }
    if (IS_SEQUENCE(_request_23124)){
            _12888 = SEQ_PTR(_request_23124)->length;
    }
    else {
        _12888 = 1;
    }
    if (binary_op_a(NOTEQ, _12887, _12888)){
        DeRef(_12887);
        _12887 = NOVALUE;
        _12888 = NOVALUE;
        goto L5; // [124] 150
    }
    DeRef(_12887);
    _12887 = NOVALUE;
    _12888 = NOVALUE;

    /** 		sock:close(sock)*/

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _0 = _close_1__tmp_at130_23154;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_23138);
    *((int *)(_2+4)) = _sock_23138;
    _close_1__tmp_at130_23154 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_close_inlined_close_at_130_23153);
    _close_inlined_close_at_130_23153 = machine(82, _close_1__tmp_at130_23154);
    DeRef(_close_1__tmp_at130_23154);
    _close_1__tmp_at130_23154 = NOVALUE;

    /** 		return ERR_SEND_FAILED*/
    DeRefDS(_host_23122);
    DeRefDS(_request_23124);
    DeRef(_addrinfo_23126);
    DeRef(_sock_23138);
    DeRef(_start_time_23155);
    DeRef(_content_23159);
    DeRef(_headers_23160);
    DeRef(_12877);
    _12877 = NOVALUE;
    _12879 = NOVALUE;
    return -7;
L5: 

    /** 	atom start_time = time()*/
    DeRef(_start_time_23155);
    _start_time_23155 = NewDouble(current_time());

    /** 	integer got_header = 0, content_length = -1*/
    _got_header_23157 = 0;
    _content_length_23158 = -1;

    /** 	sequence content = ""*/
    RefDS(_5);
    DeRef(_content_23159);
    _content_23159 = _5;

    /** 	sequence headers = {}*/
    RefDS(_5);
    DeRef(_headers_23160);
    _headers_23160 = _5;

    /** 	while time() - start_time < timeout label "top" do*/
L6: 
    DeRef(_12891);
    _12891 = NewDouble(current_time());
    if (IS_ATOM_INT(_start_time_23155)) {
        _12892 = NewDouble(DBL_PTR(_12891)->dbl - (double)_start_time_23155);
    }
    else
    _12892 = NewDouble(DBL_PTR(_12891)->dbl - DBL_PTR(_start_time_23155)->dbl);
    DeRefDS(_12891);
    _12891 = NOVALUE;
    if (binary_op_a(GREATEREQ, _12892, _timeout_23125)){
        DeRefDS(_12892);
        _12892 = NOVALUE;
        goto L7; // [187] 486
    }
    DeRef(_12892);
    _12892 = NOVALUE;

    /** 		if got_header and length(content) = content_length then*/
    if (_got_header_23157 == 0) {
        goto L8; // [193] 213
    }
    if (IS_SEQUENCE(_content_23159)){
            _12896 = SEQ_PTR(_content_23159)->length;
    }
    else {
        _12896 = 1;
    }
    _12897 = (_12896 == _content_length_23158);
    _12896 = NOVALUE;
    if (_12897 == 0)
    {
        DeRef(_12897);
        _12897 = NOVALUE;
        goto L8; // [205] 213
    }
    else{
        DeRef(_12897);
        _12897 = NOVALUE;
    }

    /** 			exit*/
    goto L7; // [210] 486
L8: 

    /** 		object has_data = sock:select(sock, {}, {}, timeout)*/
    Ref(_sock_23138);
    RefDS(_5);
    RefDS(_5);
    _0 = _has_data_23170;
    _has_data_23170 = _48select(_sock_23138, _5, _5, _timeout_23125, 0);
    DeRef(_0);

    /** 		if (length(has_data[1]) > 2) and equal(has_data[1][2],1) then*/
    _2 = (int)SEQ_PTR(_has_data_23170);
    _12899 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_12899)){
            _12900 = SEQ_PTR(_12899)->length;
    }
    else {
        _12900 = 1;
    }
    _12899 = NOVALUE;
    _12901 = (_12900 > 2);
    _12900 = NOVALUE;
    if (_12901 == 0) {
        goto L9; // [236] 477
    }
    _2 = (int)SEQ_PTR(_has_data_23170);
    _12903 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_12903);
    _12904 = (int)*(((s1_ptr)_2)->base + 2);
    _12903 = NOVALUE;
    if (_12904 == 1)
    _12905 = 1;
    else if (IS_ATOM_INT(_12904) && IS_ATOM_INT(1))
    _12905 = 0;
    else
    _12905 = (compare(_12904, 1) == 0);
    _12904 = NOVALUE;
    if (_12905 == 0)
    {
        _12905 = NOVALUE;
        goto L9; // [253] 477
    }
    else{
        _12905 = NOVALUE;
    }

    /** 			object data = sock:receive(sock, 0)*/

    /** 	return machine_func(M_SOCK_RECV, { sock, flags })*/
    Ref(_sock_23138);
    DeRef(_receive_1__tmp_at258_23183);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_23138;
    ((int *)_2)[2] = 0;
    _receive_1__tmp_at258_23183 = MAKE_SEQ(_1);
    DeRef(_data_23180);
    _data_23180 = machine(86, _receive_1__tmp_at258_23183);
    DeRef(_receive_1__tmp_at258_23183);
    _receive_1__tmp_at258_23183 = NOVALUE;

    /** 			if atom(data) then*/
    _12906 = IS_ATOM(_data_23180);
    if (_12906 == 0)
    {
        _12906 = NOVALUE;
        goto LA; // [276] 304
    }
    else{
        _12906 = NOVALUE;
    }

    /** 				if data = 0 then*/
    if (binary_op_a(NOTEQ, _data_23180, 0)){
        goto LB; // [281] 296
    }

    /** 					exit "top"*/
    DeRef(_data_23180);
    _data_23180 = NOVALUE;
    DeRef(_has_data_23170);
    _has_data_23170 = NOVALUE;
    goto L7; // [291] 486
    goto LC; // [293] 303
LB: 

    /** 					return ERR_RECEIVE_FAILED*/
    DeRef(_data_23180);
    DeRef(_has_data_23170);
    DeRefDS(_host_23122);
    DeRefDS(_request_23124);
    DeRef(_addrinfo_23126);
    DeRef(_sock_23138);
    DeRef(_start_time_23155);
    DeRef(_content_23159);
    DeRef(_headers_23160);
    DeRef(_12877);
    _12877 = NOVALUE;
    _12879 = NOVALUE;
    _12899 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    return -8;
LC: 
LA: 

    /** 			content &= data*/
    if (IS_SEQUENCE(_content_23159) && IS_ATOM(_data_23180)) {
        Ref(_data_23180);
        Append(&_content_23159, _content_23159, _data_23180);
    }
    else if (IS_ATOM(_content_23159) && IS_SEQUENCE(_data_23180)) {
    }
    else {
        Concat((object_ptr)&_content_23159, _content_23159, _data_23180);
    }

    /** 			if not got_header then*/
    if (_got_header_23157 != 0)
    goto LD; // [312] 474

    /** 				integer header_end_pos = match("\r\n\r\n", content)*/
    _header_end_pos_23192 = e_match_from(_12910, _content_23159, 1);

    /** 				if header_end_pos then*/
    if (_header_end_pos_23192 == 0)
    {
        goto LE; // [324] 471
    }
    else{
    }

    /** 					sequence raw_header = content[1..header_end_pos]*/
    rhs_slice_target = (object_ptr)&_raw_header_23196;
    RHS_Slice(_content_23159, 1, _header_end_pos_23192);

    /** 					content = content[header_end_pos + 4..$]*/
    _12913 = _header_end_pos_23192 + 4;
    if (IS_SEQUENCE(_content_23159)){
            _12914 = SEQ_PTR(_content_23159)->length;
    }
    else {
        _12914 = 1;
    }
    rhs_slice_target = (object_ptr)&_content_23159;
    RHS_Slice(_content_23159, _12913, _12914);

    /** 					sequence header_lines = split(raw_header, "\r\n")*/
    RefDS(_raw_header_23196);
    RefDS(_12832);
    _0 = _header_lines_23201;
    _header_lines_23201 = _23split(_raw_header_23196, _12832, 0, 0);
    DeRef(_0);

    /** 					headers = append(headers, split(header_lines[1], " "))*/
    _2 = (int)SEQ_PTR(_header_lines_23201);
    _12917 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_12917);
    RefDS(_12631);
    _12918 = _23split(_12917, _12631, 0, 0);
    _12917 = NOVALUE;
    Ref(_12918);
    Append(&_headers_23160, _headers_23160, _12918);
    DeRef(_12918);
    _12918 = NOVALUE;

    /** 					for i = 2 to length(header_lines) do*/
    if (IS_SEQUENCE(_header_lines_23201)){
            _12920 = SEQ_PTR(_header_lines_23201)->length;
    }
    else {
        _12920 = 1;
    }
    {
        int _i_23209;
        _i_23209 = 2;
LF: 
        if (_i_23209 > _12920){
            goto L10; // [381] 465
        }

        /** 						object header = header_lines[i]*/
        DeRef(_header_23211);
        _2 = (int)SEQ_PTR(_header_lines_23201);
        _header_23211 = (int)*(((s1_ptr)_2)->base + _i_23209);
        Ref(_header_23211);

        /** 						sequence this_header = split(header, ": ", , 1)*/
        Ref(_header_23211);
        RefDS(_12922);
        _0 = _this_header_23213;
        _this_header_23213 = _23split(_header_23211, _12922, 0, 1);
        DeRef(_0);

        /** 						this_header[1] = lower(this_header[1])*/
        _2 = (int)SEQ_PTR(_this_header_23213);
        _12924 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_12924);
        _12925 = _6lower(_12924);
        _12924 = NOVALUE;
        _2 = (int)SEQ_PTR(_this_header_23213);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _this_header_23213 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _12925;
        if( _1 != _12925 ){
            DeRef(_1);
        }
        _12925 = NOVALUE;

        /** 						headers = append(headers, this_header)*/
        RefDS(_this_header_23213);
        Append(&_headers_23160, _headers_23160, _this_header_23213);

        /** 						if equal(lower(this_header[1]), "content-length") then*/
        _2 = (int)SEQ_PTR(_this_header_23213);
        _12927 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_12927);
        _12928 = _6lower(_12927);
        _12927 = NOVALUE;
        if (_12928 == _12929)
        _12930 = 1;
        else if (IS_ATOM_INT(_12928) && IS_ATOM_INT(_12929))
        _12930 = 0;
        else
        _12930 = (compare(_12928, _12929) == 0);
        DeRef(_12928);
        _12928 = NOVALUE;
        if (_12930 == 0)
        {
            _12930 = NOVALUE;
            goto L11; // [439] 456
        }
        else{
            _12930 = NOVALUE;
        }

        /** 							content_length = to_number(this_header[2])*/
        _2 = (int)SEQ_PTR(_this_header_23213);
        _12931 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_12931);
        _content_length_23158 = _8to_number(_12931, 0);
        _12931 = NOVALUE;
        if (!IS_ATOM_INT(_content_length_23158)) {
            _1 = (long)(DBL_PTR(_content_length_23158)->dbl);
            DeRefDS(_content_length_23158);
            _content_length_23158 = _1;
        }
L11: 
        DeRef(_header_23211);
        _header_23211 = NOVALUE;
        DeRef(_this_header_23213);
        _this_header_23213 = NOVALUE;

        /** 					end for*/
        _i_23209 = _i_23209 + 1;
        goto LF; // [460] 388
L10: 
        ;
    }

    /** 					got_header = 1*/
    _got_header_23157 = 1;
LE: 
    DeRef(_raw_header_23196);
    _raw_header_23196 = NOVALUE;
    DeRef(_header_lines_23201);
    _header_lines_23201 = NOVALUE;
LD: 
L9: 
    DeRef(_data_23180);
    _data_23180 = NOVALUE;
    DeRef(_has_data_23170);
    _has_data_23170 = NOVALUE;

    /** 	end while*/
    goto L6; // [483] 181
L7: 

    /** 	return { headers, content }*/
    RefDS(_content_23159);
    RefDS(_headers_23160);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _headers_23160;
    ((int *)_2)[2] = _content_23159;
    _12933 = MAKE_SEQ(_1);
    DeRefDS(_host_23122);
    DeRefDS(_request_23124);
    DeRef(_addrinfo_23126);
    DeRef(_sock_23138);
    DeRef(_start_time_23155);
    DeRefDS(_content_23159);
    DeRefDS(_headers_23160);
    DeRef(_12877);
    _12877 = NOVALUE;
    _12879 = NOVALUE;
    _12899 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12913);
    _12913 = NOVALUE;
    return _12933;
    ;
}


int _54http_post(int _url_23233, int _data_23234, int _headers_23235, int _follow_redirects_23236, int _timeout_23237)
{
    int _request_23244 = NOVALUE;
    int _data_type_23249 = NOVALUE;
    int _content_type_23265 = NOVALUE;
    int _boundary_23274 = NOVALUE;
    int _12981 = NOVALUE;
    int _12980 = NOVALUE;
    int _12979 = NOVALUE;
    int _12978 = NOVALUE;
    int _12977 = NOVALUE;
    int _12976 = NOVALUE;
    int _12975 = NOVALUE;
    int _12974 = NOVALUE;
    int _12973 = NOVALUE;
    int _12972 = NOVALUE;
    int _12971 = NOVALUE;
    int _12970 = NOVALUE;
    int _12969 = NOVALUE;
    int _12967 = NOVALUE;
    int _12966 = NOVALUE;
    int _12965 = NOVALUE;
    int _12964 = NOVALUE;
    int _12960 = NOVALUE;
    int _12955 = NOVALUE;
    int _12954 = NOVALUE;
    int _12950 = NOVALUE;
    int _12949 = NOVALUE;
    int _12947 = NOVALUE;
    int _12946 = NOVALUE;
    int _12945 = NOVALUE;
    int _12944 = NOVALUE;
    int _12942 = NOVALUE;
    int _12941 = NOVALUE;
    int _12938 = NOVALUE;
    int _12937 = NOVALUE;
    int _12935 = NOVALUE;
    int _12934 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_follow_redirects_23236)) {
        _1 = (long)(DBL_PTR(_follow_redirects_23236)->dbl);
        DeRefDS(_follow_redirects_23236);
        _follow_redirects_23236 = _1;
    }
    if (!IS_ATOM_INT(_timeout_23237)) {
        _1 = (long)(DBL_PTR(_timeout_23237)->dbl);
        DeRefDS(_timeout_23237);
        _timeout_23237 = _1;
    }

    /** 	follow_redirects = follow_redirects -- Not used yet.*/
    _follow_redirects_23236 = _follow_redirects_23236;

    /** 	if not sequence(data) or length(data) = 0 then*/
    _12934 = IS_SEQUENCE(_data_23234);
    _12935 = (_12934 == 0);
    _12934 = NOVALUE;
    if (_12935 != 0) {
        goto L1; // [20] 36
    }
    if (IS_SEQUENCE(_data_23234)){
            _12937 = SEQ_PTR(_data_23234)->length;
    }
    else {
        _12937 = 1;
    }
    _12938 = (_12937 == 0);
    _12937 = NOVALUE;
    if (_12938 == 0)
    {
        DeRef(_12938);
        _12938 = NOVALUE;
        goto L2; // [32] 43
    }
    else{
        DeRef(_12938);
        _12938 = NOVALUE;
    }
L1: 

    /** 		return ERR_INVALID_DATA*/
    DeRefDS(_url_23233);
    DeRef(_data_23234);
    DeRef(_headers_23235);
    DeRef(_request_23244);
    DeRef(_content_type_23265);
    DeRef(_12935);
    _12935 = NOVALUE;
    return -3;
L2: 

    /** 	object request = format_base_request("POST", url, headers)*/
    RefDS(_12939);
    RefDS(_url_23233);
    Ref(_headers_23235);
    _0 = _request_23244;
    _request_23244 = _54format_base_request(_12939, _url_23233, _headers_23235);
    DeRef(_0);

    /** 	if atom(request) then*/
    _12941 = IS_ATOM(_request_23244);
    if (_12941 == 0)
    {
        _12941 = NOVALUE;
        goto L3; // [56] 66
    }
    else{
        _12941 = NOVALUE;
    }

    /** 		return request*/
    DeRefDS(_url_23233);
    DeRef(_data_23234);
    DeRef(_headers_23235);
    DeRef(_content_type_23265);
    DeRef(_12935);
    _12935 = NOVALUE;
    return _request_23244;
L3: 

    /** 	integer data_type*/

    /** 	if ascii_string(data) or sequence(data[1]) then*/
    Ref(_data_23234);
    _12942 = _7ascii_string(_data_23234);
    if (IS_ATOM_INT(_12942)) {
        if (_12942 != 0) {
            goto L4; // [74] 90
        }
    }
    else {
        if (DBL_PTR(_12942)->dbl != 0.0) {
            goto L4; // [74] 90
        }
    }
    _2 = (int)SEQ_PTR(_data_23234);
    _12944 = (int)*(((s1_ptr)_2)->base + 1);
    _12945 = IS_SEQUENCE(_12944);
    _12944 = NOVALUE;
    if (_12945 == 0)
    {
        _12945 = NOVALUE;
        goto L5; // [86] 98
    }
    else{
        _12945 = NOVALUE;
    }
L4: 

    /** 		data_type = FORM_URLENCODED*/
    _data_type_23249 = 1;
    goto L6; // [95] 147
L5: 

    /** 		if data[1] < 1 or data[1] > 2 then*/
    _2 = (int)SEQ_PTR(_data_23234);
    _12946 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12946)) {
        _12947 = (_12946 < 1);
    }
    else {
        _12947 = binary_op(LESS, _12946, 1);
    }
    _12946 = NOVALUE;
    if (IS_ATOM_INT(_12947)) {
        if (_12947 != 0) {
            goto L7; // [108] 125
        }
    }
    else {
        if (DBL_PTR(_12947)->dbl != 0.0) {
            goto L7; // [108] 125
        }
    }
    _2 = (int)SEQ_PTR(_data_23234);
    _12949 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12949)) {
        _12950 = (_12949 > 2);
    }
    else {
        _12950 = binary_op(GREATER, _12949, 2);
    }
    _12949 = NOVALUE;
    if (_12950 == 0) {
        DeRef(_12950);
        _12950 = NOVALUE;
        goto L8; // [121] 132
    }
    else {
        if (!IS_ATOM_INT(_12950) && DBL_PTR(_12950)->dbl == 0.0){
            DeRef(_12950);
            _12950 = NOVALUE;
            goto L8; // [121] 132
        }
        DeRef(_12950);
        _12950 = NOVALUE;
    }
    DeRef(_12950);
    _12950 = NOVALUE;
L7: 

    /** 			return ERR_INVALID_DATA_ENCODING*/
    DeRefDS(_url_23233);
    DeRef(_data_23234);
    DeRef(_headers_23235);
    DeRef(_request_23244);
    DeRef(_content_type_23265);
    DeRef(_12935);
    _12935 = NOVALUE;
    DeRef(_12942);
    _12942 = NOVALUE;
    DeRef(_12947);
    _12947 = NOVALUE;
    return -4;
L8: 

    /** 		data_type = data[1]*/
    _2 = (int)SEQ_PTR(_data_23234);
    _data_type_23249 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_data_type_23249)){
        _data_type_23249 = (long)DBL_PTR(_data_type_23249)->dbl;
    }

    /** 		data = data[2]*/
    _0 = _data_23234;
    _2 = (int)SEQ_PTR(_data_23234);
    _data_23234 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_23234);
    DeRef(_0);
L6: 

    /** 	sequence content_type = ENCODING_STRINGS[data_type]*/
    DeRef(_content_type_23265);
    _2 = (int)SEQ_PTR(_54ENCODING_STRINGS_22951);
    _content_type_23265 = (int)*(((s1_ptr)_2)->base + _data_type_23249);
    RefDS(_content_type_23265);

    /** 	if sequence(data[1]) then*/
    _2 = (int)SEQ_PTR(_data_23234);
    _12954 = (int)*(((s1_ptr)_2)->base + 1);
    _12955 = IS_SEQUENCE(_12954);
    _12954 = NOVALUE;
    if (_12955 == 0)
    {
        _12955 = NOVALUE;
        goto L9; // [168] 215
    }
    else{
        _12955 = NOVALUE;
    }

    /** 		if data_type = FORM_URLENCODED then*/
    if (_data_type_23249 != 1)
    goto LA; // [173] 186

    /** 			data = form_urlencode(data)*/
    Ref(_data_23234);
    _0 = _data_23234;
    _data_23234 = _54form_urlencode(_data_23234);
    DeRef(_0);
    goto LB; // [183] 214
LA: 

    /** 			sequence boundary = random_boundary(20)*/
    _0 = _boundary_23274;
    _boundary_23274 = _54random_boundary(20);
    DeRef(_0);

    /** 			content_type &= "; boundary=" & boundary*/
    Concat((object_ptr)&_12960, _12959, _boundary_23274);
    Concat((object_ptr)&_content_type_23265, _content_type_23265, _12960);
    DeRefDS(_12960);
    _12960 = NOVALUE;

    /** 			data = multipart_form_data_encode(data, boundary)*/
    Ref(_data_23234);
    RefDS(_boundary_23274);
    _0 = _data_23234;
    _data_23234 = _54multipart_form_data_encode(_data_23234, _boundary_23274);
    DeRef(_0);
    DeRefDS(_boundary_23274);
    _boundary_23274 = NOVALUE;
LB: 
L9: 

    /** 	request[R_REQUEST] &= sprintf("Content-Type: %s\r\n", { content_type })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_content_type_23265);
    *((int *)(_2+4)) = _content_type_23265;
    _12964 = MAKE_SEQ(_1);
    _12965 = EPrintf(-9999999, _12963, _12964);
    DeRefDS(_12964);
    _12964 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    _12966 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12966) && IS_ATOM(_12965)) {
    }
    else if (IS_ATOM(_12966) && IS_SEQUENCE(_12965)) {
        Ref(_12966);
        Prepend(&_12967, _12965, _12966);
    }
    else {
        Concat((object_ptr)&_12967, _12966, _12965);
        _12966 = NOVALUE;
    }
    _12966 = NOVALUE;
    DeRefDS(_12965);
    _12965 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23244 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12967;
    if( _1 != _12967 ){
        DeRef(_1);
    }
    _12967 = NOVALUE;

    /** 	request[R_REQUEST] &= sprintf("Content-Length: %d\r\n", { length(data) })*/
    if (IS_SEQUENCE(_data_23234)){
            _12969 = SEQ_PTR(_data_23234)->length;
    }
    else {
        _12969 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12969;
    _12970 = MAKE_SEQ(_1);
    _12969 = NOVALUE;
    _12971 = EPrintf(-9999999, _12968, _12970);
    DeRefDS(_12970);
    _12970 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    _12972 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12972) && IS_ATOM(_12971)) {
    }
    else if (IS_ATOM(_12972) && IS_SEQUENCE(_12971)) {
        Ref(_12972);
        Prepend(&_12973, _12971, _12972);
    }
    else {
        Concat((object_ptr)&_12973, _12972, _12971);
        _12972 = NOVALUE;
    }
    _12972 = NOVALUE;
    DeRefDS(_12971);
    _12971 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23244 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12973;
    if( _1 != _12973 ){
        DeRef(_1);
    }
    _12973 = NOVALUE;

    /** 	request[R_REQUEST] &= "\r\n"*/
    _2 = (int)SEQ_PTR(_request_23244);
    _12974 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12974) && IS_ATOM(_12832)) {
    }
    else if (IS_ATOM(_12974) && IS_SEQUENCE(_12832)) {
        Ref(_12974);
        Prepend(&_12975, _12832, _12974);
    }
    else {
        Concat((object_ptr)&_12975, _12974, _12832);
        _12974 = NOVALUE;
    }
    _12974 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23244 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12975;
    if( _1 != _12975 ){
        DeRef(_1);
    }
    _12975 = NOVALUE;

    /** 	request[R_REQUEST] &= data*/
    _2 = (int)SEQ_PTR(_request_23244);
    _12976 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12976) && IS_ATOM(_data_23234)) {
        Ref(_data_23234);
        Append(&_12977, _12976, _data_23234);
    }
    else if (IS_ATOM(_12976) && IS_SEQUENCE(_data_23234)) {
        Ref(_12976);
        Prepend(&_12977, _data_23234, _12976);
    }
    else {
        Concat((object_ptr)&_12977, _12976, _data_23234);
        _12976 = NOVALUE;
    }
    _12976 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23244);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23244 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12977;
    if( _1 != _12977 ){
        DeRef(_1);
    }
    _12977 = NOVALUE;

    /** 	return execute_request(request[R_HOST], request[R_PORT], request[R_REQUEST], timeout)*/
    _2 = (int)SEQ_PTR(_request_23244);
    _12978 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_request_23244);
    _12979 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_request_23244);
    _12980 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_12978);
    Ref(_12979);
    Ref(_12980);
    _12981 = _54execute_request(_12978, _12979, _12980, _timeout_23237);
    _12978 = NOVALUE;
    _12979 = NOVALUE;
    _12980 = NOVALUE;
    DeRefDS(_url_23233);
    DeRef(_data_23234);
    DeRef(_headers_23235);
    DeRefDS(_request_23244);
    DeRefDS(_content_type_23265);
    DeRef(_12935);
    _12935 = NOVALUE;
    DeRef(_12942);
    _12942 = NOVALUE;
    DeRef(_12947);
    _12947 = NOVALUE;
    return _12981;
    ;
}
int http_post() __attribute__ ((alias ("_54http_post")));


int _54http_get(int _url_23301, int _headers_23302, int _follow_redirects_23303, int _timeout_23304)
{
    int _request_23305 = NOVALUE;
    int _12990 = NOVALUE;
    int _12989 = NOVALUE;
    int _12988 = NOVALUE;
    int _12987 = NOVALUE;
    int _12986 = NOVALUE;
    int _12985 = NOVALUE;
    int _12984 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_follow_redirects_23303)) {
        _1 = (long)(DBL_PTR(_follow_redirects_23303)->dbl);
        DeRefDS(_follow_redirects_23303);
        _follow_redirects_23303 = _1;
    }
    if (!IS_ATOM_INT(_timeout_23304)) {
        _1 = (long)(DBL_PTR(_timeout_23304)->dbl);
        DeRefDS(_timeout_23304);
        _timeout_23304 = _1;
    }

    /** 	object request = format_base_request("GET", url, headers)*/
    RefDS(_12982);
    RefDS(_url_23301);
    Ref(_headers_23302);
    _0 = _request_23305;
    _request_23305 = _54format_base_request(_12982, _url_23301, _headers_23302);
    DeRef(_0);

    /** 	follow_redirects = follow_redirects -- Not used yet.*/
    _follow_redirects_23303 = _follow_redirects_23303;

    /** 	if atom(request) then*/
    _12984 = IS_ATOM(_request_23305);
    if (_12984 == 0)
    {
        _12984 = NOVALUE;
        goto L1; // [25] 35
    }
    else{
        _12984 = NOVALUE;
    }

    /** 		return request*/
    DeRefDS(_url_23301);
    DeRef(_headers_23302);
    return _request_23305;
L1: 

    /** 	request[R_REQUEST] &= "\r\n"*/
    _2 = (int)SEQ_PTR(_request_23305);
    _12985 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12985) && IS_ATOM(_12832)) {
    }
    else if (IS_ATOM(_12985) && IS_SEQUENCE(_12832)) {
        Ref(_12985);
        Prepend(&_12986, _12832, _12985);
    }
    else {
        Concat((object_ptr)&_12986, _12985, _12832);
        _12985 = NOVALUE;
    }
    _12985 = NOVALUE;
    _2 = (int)SEQ_PTR(_request_23305);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _request_23305 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12986;
    if( _1 != _12986 ){
        DeRef(_1);
    }
    _12986 = NOVALUE;

    /** 	return execute_request(request[R_HOST], request[R_PORT], request[R_REQUEST], timeout)*/
    _2 = (int)SEQ_PTR(_request_23305);
    _12987 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_request_23305);
    _12988 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_request_23305);
    _12989 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_12987);
    Ref(_12988);
    Ref(_12989);
    _12990 = _54execute_request(_12987, _12988, _12989, _timeout_23304);
    _12987 = NOVALUE;
    _12988 = NOVALUE;
    _12989 = NOVALUE;
    DeRefDS(_url_23301);
    DeRef(_headers_23302);
    DeRefDS(_request_23305);
    return _12990;
    ;
}
int http_get() __attribute__ ((alias ("_54http_get")));



// 0x4CC9973F
