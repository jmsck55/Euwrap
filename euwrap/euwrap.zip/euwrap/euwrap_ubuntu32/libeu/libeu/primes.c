// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _34calc_primes(int _approx_limit_12136, int _time_limit_p_12137)
{
    int _result__12138 = NOVALUE;
    int _candidate__12139 = NOVALUE;
    int _pos__12140 = NOVALUE;
    int _time_out__12141 = NOVALUE;
    int _maxp__12142 = NOVALUE;
    int _maxf__12143 = NOVALUE;
    int _maxf_idx_12144 = NOVALUE;
    int _next_trigger_12145 = NOVALUE;
    int _growth_12146 = NOVALUE;
    int _6938 = NOVALUE;
    int _6935 = NOVALUE;
    int _6933 = NOVALUE;
    int _6930 = NOVALUE;
    int _6927 = NOVALUE;
    int _6924 = NOVALUE;
    int _6917 = NOVALUE;
    int _6915 = NOVALUE;
    int _6912 = NOVALUE;
    int _6909 = NOVALUE;
    int _6905 = NOVALUE;
    int _6904 = NOVALUE;
    int _6900 = NOVALUE;
    int _6894 = NOVALUE;
    int _6892 = NOVALUE;
    int _6890 = NOVALUE;
    int _6885 = NOVALUE;
    int _6884 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_approx_limit_12136)) {
        _1 = (long)(DBL_PTR(_approx_limit_12136)->dbl);
        DeRefDS(_approx_limit_12136);
        _approx_limit_12136 = _1;
    }

    /** 	if approx_limit <= list_of_primes[$] then*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6884 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6884 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6885 = (int)*(((s1_ptr)_2)->base + _6884);
    if (binary_op_a(GREATER, _approx_limit_12136, _6885)){
        _6885 = NOVALUE;
        goto L1; // [14] 59
    }
    _6885 = NOVALUE;

    /** 		pos_ = search:binary_search(approx_limit, list_of_primes)*/
    RefDS(_34list_of_primes_12132);
    _pos__12140 = _9binary_search(_approx_limit_12136, _34list_of_primes_12132, 1, 0);
    if (!IS_ATOM_INT(_pos__12140)) {
        _1 = (long)(DBL_PTR(_pos__12140)->dbl);
        DeRefDS(_pos__12140);
        _pos__12140 = _1;
    }

    /** 		if pos_ < 0 then*/
    if (_pos__12140 >= 0)
    goto L2; // [33] 45

    /** 			pos_ = (-pos_)*/
    _pos__12140 = - _pos__12140;
L2: 

    /** 		return list_of_primes[1..pos_]*/
    rhs_slice_target = (object_ptr)&_6890;
    RHS_Slice(_34list_of_primes_12132, 1, _pos__12140);
    DeRef(_time_limit_p_12137);
    DeRef(_result__12138);
    DeRef(_time_out__12141);
    return _6890;
L1: 

    /** 	pos_ = length(list_of_primes)*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _pos__12140 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _pos__12140 = 1;
    }

    /** 	candidate_ = list_of_primes[$]*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6892 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6892 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _candidate__12139 = (int)*(((s1_ptr)_2)->base + _6892);
    if (!IS_ATOM_INT(_candidate__12139))
    _candidate__12139 = (long)DBL_PTR(_candidate__12139)->dbl;

    /** 	maxf_ = floor(power(candidate_, 0.5))*/
    temp_d.dbl = (double)_candidate__12139;
    _6894 = Dpower(&temp_d, DBL_PTR(_2326));
    _maxf__12143 = unary_op(FLOOR, _6894);
    DeRefDS(_6894);
    _6894 = NOVALUE;
    if (!IS_ATOM_INT(_maxf__12143)) {
        _1 = (long)(DBL_PTR(_maxf__12143)->dbl);
        DeRefDS(_maxf__12143);
        _maxf__12143 = _1;
    }

    /** 	maxf_idx = search:binary_search(maxf_, list_of_primes)*/
    RefDS(_34list_of_primes_12132);
    _maxf_idx_12144 = _9binary_search(_maxf__12143, _34list_of_primes_12132, 1, 0);
    if (!IS_ATOM_INT(_maxf_idx_12144)) {
        _1 = (long)(DBL_PTR(_maxf_idx_12144)->dbl);
        DeRefDS(_maxf_idx_12144);
        _maxf_idx_12144 = _1;
    }

    /** 	if maxf_idx < 0 then*/
    if (_maxf_idx_12144 >= 0)
    goto L3; // [103] 123

    /** 		maxf_idx = (-maxf_idx)*/
    _maxf_idx_12144 = - _maxf_idx_12144;

    /** 		maxf_ = list_of_primes[maxf_idx]*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _maxf__12143 = (int)*(((s1_ptr)_2)->base + _maxf_idx_12144);
    if (!IS_ATOM_INT(_maxf__12143))
    _maxf__12143 = (long)DBL_PTR(_maxf__12143)->dbl;
L3: 

    /** 	next_trigger = list_of_primes[maxf_idx+1]*/
    _6900 = _maxf_idx_12144 + 1;
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _next_trigger_12145 = (int)*(((s1_ptr)_2)->base + _6900);
    if (!IS_ATOM_INT(_next_trigger_12145))
    _next_trigger_12145 = (long)DBL_PTR(_next_trigger_12145)->dbl;

    /** 	next_trigger *= next_trigger*/
    _next_trigger_12145 = _next_trigger_12145 * _next_trigger_12145;

    /** 	growth = floor(approx_limit  / 3.5) - length(list_of_primes)*/
    _2 = binary_op(DIVIDE, _approx_limit_12136, _6903);
    _6904 = unary_op(FLOOR, _2);
    DeRef(_2);
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6905 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6905 = 1;
    }
    if (IS_ATOM_INT(_6904)) {
        _growth_12146 = _6904 - _6905;
    }
    else {
        _growth_12146 = NewDouble(DBL_PTR(_6904)->dbl - (double)_6905);
    }
    DeRef(_6904);
    _6904 = NOVALUE;
    _6905 = NOVALUE;
    if (!IS_ATOM_INT(_growth_12146)) {
        _1 = (long)(DBL_PTR(_growth_12146)->dbl);
        DeRefDS(_growth_12146);
        _growth_12146 = _1;
    }

    /** 	if growth <= 0 then*/
    if (_growth_12146 > 0)
    goto L4; // [162] 174

    /** 		growth = length(list_of_primes)*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _growth_12146 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _growth_12146 = 1;
    }
L4: 

    /** 	result_ = list_of_primes & repeat(0, growth)*/
    _6909 = Repeat(0, _growth_12146);
    Concat((object_ptr)&_result__12138, _34list_of_primes_12132, _6909);
    DeRefDS(_6909);
    _6909 = NOVALUE;

    /** 	if time_limit_p < 0 then*/
    if (binary_op_a(GREATEREQ, _time_limit_p_12137, 0)){
        goto L5; // [188] 203
    }

    /** 		time_out_ = time() + 100_000_000*/
    DeRef(_6912);
    _6912 = NewDouble(current_time());
    DeRef(_time_out__12141);
    _time_out__12141 = NewDouble(DBL_PTR(_6912)->dbl + (double)100000000);
    DeRefDS(_6912);
    _6912 = NOVALUE;
    goto L6; // [200] 212
L5: 

    /** 		time_out_ = time() + time_limit_p*/
    DeRef(_6915);
    _6915 = NewDouble(current_time());
    DeRef(_time_out__12141);
    if (IS_ATOM_INT(_time_limit_p_12137)) {
        _time_out__12141 = NewDouble(DBL_PTR(_6915)->dbl + (double)_time_limit_p_12137);
    }
    else
    _time_out__12141 = NewDouble(DBL_PTR(_6915)->dbl + DBL_PTR(_time_limit_p_12137)->dbl);
    DeRefDS(_6915);
    _6915 = NOVALUE;
L6: 

    /** 	while time_out_ >= time()  label "MW" do*/
L7: 
    DeRef(_6917);
    _6917 = NewDouble(current_time());
    if (binary_op_a(LESS, _time_out__12141, _6917)){
        DeRefDS(_6917);
        _6917 = NOVALUE;
        goto L8; // [221] 370
    }
    DeRef(_6917);
    _6917 = NOVALUE;

    /** 		task_yield()*/

    /** 		candidate_ += 2*/
    _candidate__12139 = _candidate__12139 + 2;

    /** 		if candidate_ >= next_trigger then*/
    if (_candidate__12139 < _next_trigger_12145)
    goto L9; // [236] 271

    /** 			maxf_idx += 1*/
    _maxf_idx_12144 = _maxf_idx_12144 + 1;

    /** 			maxf_ = result_[maxf_idx]*/
    _2 = (int)SEQ_PTR(_result__12138);
    _maxf__12143 = (int)*(((s1_ptr)_2)->base + _maxf_idx_12144);
    if (!IS_ATOM_INT(_maxf__12143))
    _maxf__12143 = (long)DBL_PTR(_maxf__12143)->dbl;

    /** 			next_trigger = result_[maxf_idx+1]*/
    _6924 = _maxf_idx_12144 + 1;
    _2 = (int)SEQ_PTR(_result__12138);
    _next_trigger_12145 = (int)*(((s1_ptr)_2)->base + _6924);
    if (!IS_ATOM_INT(_next_trigger_12145))
    _next_trigger_12145 = (long)DBL_PTR(_next_trigger_12145)->dbl;

    /** 			next_trigger *= next_trigger*/
    _next_trigger_12145 = _next_trigger_12145 * _next_trigger_12145;
L9: 

    /** 		for i = 2 to pos_ do*/
    _6927 = _pos__12140;
    {
        int _i_12199;
        _i_12199 = 2;
LA: 
        if (_i_12199 > _6927){
            goto LB; // [276] 322
        }

        /** 			maxp_ = result_[i]*/
        _2 = (int)SEQ_PTR(_result__12138);
        _maxp__12142 = (int)*(((s1_ptr)_2)->base + _i_12199);
        if (!IS_ATOM_INT(_maxp__12142))
        _maxp__12142 = (long)DBL_PTR(_maxp__12142)->dbl;

        /** 			if maxp_ > maxf_ then*/
        if (_maxp__12142 <= _maxf__12143)
        goto LC; // [291] 300

        /** 				exit*/
        goto LB; // [297] 322
LC: 

        /** 			if remainder(candidate_, maxp_) = 0 then*/
        _6930 = (_candidate__12139 % _maxp__12142);
        if (_6930 != 0)
        goto LD; // [306] 315

        /** 				continue "MW"*/
        goto L7; // [312] 217
LD: 

        /** 		end for*/
        _i_12199 = _i_12199 + 1;
        goto LA; // [317] 283
LB: 
        ;
    }

    /** 		pos_ += 1*/
    _pos__12140 = _pos__12140 + 1;

    /** 		if pos_ >= length(result_) then*/
    if (IS_SEQUENCE(_result__12138)){
            _6933 = SEQ_PTR(_result__12138)->length;
    }
    else {
        _6933 = 1;
    }
    if (_pos__12140 < _6933)
    goto LE; // [333] 348

    /** 			result_ &= repeat(0, 1000)*/
    _6935 = Repeat(0, 1000);
    Concat((object_ptr)&_result__12138, _result__12138, _6935);
    DeRefDS(_6935);
    _6935 = NOVALUE;
LE: 

    /** 		result_[pos_] = candidate_*/
    _2 = (int)SEQ_PTR(_result__12138);
    _2 = (int)(((s1_ptr)_2)->base + _pos__12140);
    _1 = *(int *)_2;
    *(int *)_2 = _candidate__12139;
    DeRef(_1);

    /** 		if candidate_ >= approx_limit then*/
    if (_candidate__12139 < _approx_limit_12136)
    goto L7; // [356] 217

    /** 			exit*/
    goto L8; // [362] 370

    /** 	end while*/
    goto L7; // [367] 217
L8: 

    /** 	return result_[1..pos_]*/
    rhs_slice_target = (object_ptr)&_6938;
    RHS_Slice(_result__12138, 1, _pos__12140);
    DeRef(_time_limit_p_12137);
    DeRefDS(_result__12138);
    DeRef(_time_out__12141);
    DeRef(_6890);
    _6890 = NOVALUE;
    DeRef(_6900);
    _6900 = NOVALUE;
    DeRef(_6924);
    _6924 = NOVALUE;
    DeRef(_6930);
    _6930 = NOVALUE;
    return _6938;
    ;
}
int calc_primes() __attribute__ ((alias ("_34calc_primes")));


int _34next_prime(int _n_12218, int _fail_signal_p_12219, int _time_out_p_12220)
{
    int _i_12221 = NOVALUE;
    int _6958 = NOVALUE;
    int _6952 = NOVALUE;
    int _6951 = NOVALUE;
    int _6950 = NOVALUE;
    int _6949 = NOVALUE;
    int _6948 = NOVALUE;
    int _6945 = NOVALUE;
    int _6944 = NOVALUE;
    int _6941 = NOVALUE;
    int _6940 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_12218)) {
        _1 = (long)(DBL_PTR(_n_12218)->dbl);
        DeRefDS(_n_12218);
        _n_12218 = _1;
    }

    /** 	if n < 0 then*/
    if (_n_12218 >= 0)
    goto L1; // [5] 16

    /** 		return fail_signal_p*/
    DeRef(_time_out_p_12220);
    return _fail_signal_p_12219;
L1: 

    /** 	if list_of_primes[$] < n then*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6940 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6940 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6941 = (int)*(((s1_ptr)_2)->base + _6940);
    if (binary_op_a(GREATEREQ, _6941, _n_12218)){
        _6941 = NOVALUE;
        goto L2; // [27] 41
    }
    _6941 = NOVALUE;

    /** 		list_of_primes = calc_primes(n,time_out_p)*/
    Ref(_time_out_p_12220);
    _0 = _34calc_primes(_n_12218, _time_out_p_12220);
    DeRefDS(_34list_of_primes_12132);
    _34list_of_primes_12132 = _0;
L2: 

    /** 	if n > list_of_primes[$] then*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6944 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6944 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6945 = (int)*(((s1_ptr)_2)->base + _6944);
    if (binary_op_a(LESSEQ, _n_12218, _6945)){
        _6945 = NOVALUE;
        goto L3; // [52] 63
    }
    _6945 = NOVALUE;

    /** 		return fail_signal_p*/
    DeRef(_time_out_p_12220);
    return _fail_signal_p_12219;
L3: 

    /** 	if n < 1009 and 1009 <= list_of_primes[$] then*/
    _6948 = (_n_12218 < 1009);
    if (_6948 == 0) {
        goto L4; // [69] 106
    }
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6950 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6950 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6951 = (int)*(((s1_ptr)_2)->base + _6950);
    if (IS_ATOM_INT(_6951)) {
        _6952 = (1009 <= _6951);
    }
    else {
        _6952 = binary_op(LESSEQ, 1009, _6951);
    }
    _6951 = NOVALUE;
    if (_6952 == 0) {
        DeRef(_6952);
        _6952 = NOVALUE;
        goto L4; // [87] 106
    }
    else {
        if (!IS_ATOM_INT(_6952) && DBL_PTR(_6952)->dbl == 0.0){
            DeRef(_6952);
            _6952 = NOVALUE;
            goto L4; // [87] 106
        }
        DeRef(_6952);
        _6952 = NOVALUE;
    }
    DeRef(_6952);
    _6952 = NOVALUE;

    /** 		i = search:binary_search(n, list_of_primes, ,169)*/
    RefDS(_34list_of_primes_12132);
    _i_12221 = _9binary_search(_n_12218, _34list_of_primes_12132, 1, 169);
    if (!IS_ATOM_INT(_i_12221)) {
        _1 = (long)(DBL_PTR(_i_12221)->dbl);
        DeRefDS(_i_12221);
        _i_12221 = _1;
    }
    goto L5; // [103] 120
L4: 

    /** 		i = search:binary_search(n, list_of_primes)*/
    RefDS(_34list_of_primes_12132);
    _i_12221 = _9binary_search(_n_12218, _34list_of_primes_12132, 1, 0);
    if (!IS_ATOM_INT(_i_12221)) {
        _1 = (long)(DBL_PTR(_i_12221)->dbl);
        DeRefDS(_i_12221);
        _i_12221 = _1;
    }
L5: 

    /** 	if i < 0 then*/
    if (_i_12221 >= 0)
    goto L6; // [124] 136

    /** 		i = (-i)*/
    _i_12221 = - _i_12221;
L6: 

    /** 	return list_of_primes[i]*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6958 = (int)*(((s1_ptr)_2)->base + _i_12221);
    Ref(_6958);
    DeRef(_fail_signal_p_12219);
    DeRef(_time_out_p_12220);
    DeRef(_6948);
    _6948 = NOVALUE;
    return _6958;
    ;
}
int next_prime() __attribute__ ((alias ("_34next_prime")));


int _34prime_list(int _top_prime_p_12250)
{
    int _index__12251 = NOVALUE;
    int _6970 = NOVALUE;
    int _6967 = NOVALUE;
    int _6961 = NOVALUE;
    int _6960 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_top_prime_p_12250)) {
        _1 = (long)(DBL_PTR(_top_prime_p_12250)->dbl);
        DeRefDS(_top_prime_p_12250);
        _top_prime_p_12250 = _1;
    }

    /** 	if top_prime_p <= 0 then*/
    if (_top_prime_p_12250 > 0)
    goto L1; // [5] 18

    /** 		return list_of_primes*/
    RefDS(_34list_of_primes_12132);
    return _34list_of_primes_12132;
L1: 

    /** 	if list_of_primes[$] < top_prime_p then*/
    if (IS_SEQUENCE(_34list_of_primes_12132)){
            _6960 = SEQ_PTR(_34list_of_primes_12132)->length;
    }
    else {
        _6960 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6961 = (int)*(((s1_ptr)_2)->base + _6960);
    if (binary_op_a(GREATEREQ, _6961, _top_prime_p_12250)){
        _6961 = NOVALUE;
        goto L2; // [29] 43
    }
    _6961 = NOVALUE;

    /** 		list_of_primes = calc_primes(top_prime_p, 5)*/
    _0 = _34calc_primes(_top_prime_p_12250, 5);
    DeRefDS(_34list_of_primes_12132);
    _34list_of_primes_12132 = _0;
L2: 

    /** 	index_ = search:binary_search(top_prime_p, list_of_primes)*/
    RefDS(_34list_of_primes_12132);
    _index__12251 = _9binary_search(_top_prime_p_12250, _34list_of_primes_12132, 1, 0);
    if (!IS_ATOM_INT(_index__12251)) {
        _1 = (long)(DBL_PTR(_index__12251)->dbl);
        DeRefDS(_index__12251);
        _index__12251 = _1;
    }

    /** 	if index_ < 0 then*/
    if (_index__12251 >= 0)
    goto L3; // [58] 70

    /** 		index_ = - index_*/
    _index__12251 = - _index__12251;
L3: 

    /** 	if list_of_primes[index_] > top_prime_p then*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12132);
    _6967 = (int)*(((s1_ptr)_2)->base + _index__12251);
    if (binary_op_a(LESSEQ, _6967, _top_prime_p_12250)){
        _6967 = NOVALUE;
        goto L4; // [78] 89
    }
    _6967 = NOVALUE;

    /** 		index_ -= 1*/
    _index__12251 = _index__12251 - 1;
L4: 

    /** 	return list_of_primes[1 .. index_]*/
    rhs_slice_target = (object_ptr)&_6970;
    RHS_Slice(_34list_of_primes_12132, 1, _index__12251);
    return _6970;
    ;
}
int prime_list() __attribute__ ((alias ("_34prime_list")));



// 0xCF4EA024
