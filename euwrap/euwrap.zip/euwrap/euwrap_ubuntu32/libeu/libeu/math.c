// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _20abs(int _a_4376)
{
    int _t_4377 = NOVALUE;
    int _2263 = NOVALUE;
    int _2262 = NOVALUE;
    int _2261 = NOVALUE;
    int _2259 = NOVALUE;
    int _2257 = NOVALUE;
    int _2256 = NOVALUE;
    int _2254 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2254 = IS_ATOM(_a_4376);
    if (_2254 == 0)
    {
        _2254 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _2254 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_4376, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_4377);
    return _a_4376;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_4376)) {
        if ((unsigned long)_a_4376 == 0xC0000000)
        _2256 = (int)NewDouble((double)-0xC0000000);
        else
        _2256 = - _a_4376;
    }
    else {
        _2256 = unary_op(UMINUS, _a_4376);
    }
    DeRef(_a_4376);
    DeRef(_t_4377);
    return _2256;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4376)){
            _2257 = SEQ_PTR(_a_4376)->length;
    }
    else {
        _2257 = 1;
    }
    {
        int _i_4385;
        _i_4385 = 1;
L4: 
        if (_i_4385 > _2257){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_4377);
        _2 = (int)SEQ_PTR(_a_4376);
        _t_4377 = (int)*(((s1_ptr)_2)->base + _i_4385);
        Ref(_t_4377);

        /** 		if atom(t) then*/
        _2259 = IS_ATOM(_t_4377);
        if (_2259 == 0)
        {
            _2259 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _2259 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_4377, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_4377)) {
            if ((unsigned long)_t_4377 == 0xC0000000)
            _2261 = (int)NewDouble((double)-0xC0000000);
            else
            _2261 = - _t_4377;
        }
        else {
            _2261 = unary_op(UMINUS, _t_4377);
        }
        _2 = (int)SEQ_PTR(_a_4376);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4376 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4385);
        _1 = *(int *)_2;
        *(int *)_2 = _2261;
        if( _1 != _2261 ){
            DeRef(_1);
        }
        _2261 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_4377);
        DeRef(_2262);
        _2262 = _t_4377;
        _2263 = _20abs(_2262);
        _2262 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_4376);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4376 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4385);
        _1 = *(int *)_2;
        *(int *)_2 = _2263;
        if( _1 != _2263 ){
            DeRef(_1);
        }
        _2263 = NOVALUE;
L7: 

        /** 	end for*/
        _i_4385 = _i_4385 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_4377);
    DeRef(_2256);
    _2256 = NOVALUE;
    return _a_4376;
    ;
}
int abs() __attribute__ ((alias ("_20abs")));


int _20sign(int _a_4398)
{
    int _2266 = NOVALUE;
    int _2265 = NOVALUE;
    int _2264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (a > 0) - (a < 0)*/
    if (IS_ATOM_INT(_a_4398)) {
        _2264 = (_a_4398 > 0);
    }
    else {
        _2264 = binary_op(GREATER, _a_4398, 0);
    }
    if (IS_ATOM_INT(_a_4398)) {
        _2265 = (_a_4398 < 0);
    }
    else {
        _2265 = binary_op(LESS, _a_4398, 0);
    }
    if (IS_ATOM_INT(_2264) && IS_ATOM_INT(_2265)) {
        _2266 = _2264 - _2265;
        if ((long)((unsigned long)_2266 +(unsigned long) HIGH_BITS) >= 0){
            _2266 = NewDouble((double)_2266);
        }
    }
    else {
        _2266 = binary_op(MINUS, _2264, _2265);
    }
    DeRef(_2264);
    _2264 = NOVALUE;
    DeRef(_2265);
    _2265 = NOVALUE;
    DeRef(_a_4398);
    return _2266;
    ;
}
int sign() __attribute__ ((alias ("_20sign")));


int _20larger_of(int _objA_4404, int _objB_4405)
{
    int _2267 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compare(objA, objB) > 0 then*/
    if (IS_ATOM_INT(_objA_4404) && IS_ATOM_INT(_objB_4405)){
        _2267 = (_objA_4404 < _objB_4405) ? -1 : (_objA_4404 > _objB_4405);
    }
    else{
        _2267 = compare(_objA_4404, _objB_4405);
    }
    if (_2267 <= 0)
    goto L1; // [7] 20

    /** 		return objA*/
    DeRef(_objB_4405);
    return _objA_4404;
    goto L2; // [17] 27
L1: 

    /** 		return objB*/
    DeRef(_objA_4404);
    return _objB_4405;
L2: 
    ;
}
int larger_of() __attribute__ ((alias ("_20larger_of")));


int _20smaller_of(int _objA_4412, int _objB_4413)
{
    int _2269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compare(objA, objB) < 0 then*/
    if (IS_ATOM_INT(_objA_4412) && IS_ATOM_INT(_objB_4413)){
        _2269 = (_objA_4412 < _objB_4413) ? -1 : (_objA_4412 > _objB_4413);
    }
    else{
        _2269 = compare(_objA_4412, _objB_4413);
    }
    if (_2269 >= 0)
    goto L1; // [7] 20

    /** 		return objA*/
    DeRef(_objB_4413);
    return _objA_4412;
    goto L2; // [17] 27
L1: 

    /** 		return objB*/
    DeRef(_objA_4412);
    return _objB_4413;
L2: 
    ;
}
int smaller_of() __attribute__ ((alias ("_20smaller_of")));


int _20max(int _a_4420)
{
    int _b_4421 = NOVALUE;
    int _c_4422 = NOVALUE;
    int _2273 = NOVALUE;
    int _2272 = NOVALUE;
    int _2271 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2271 = IS_ATOM(_a_4420);
    if (_2271 == 0)
    {
        _2271 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2271 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4421);
    DeRef(_c_4422);
    return _a_4420;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_22MINF_4354);
    DeRef(_b_4421);
    _b_4421 = _22MINF_4354;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4420)){
            _2272 = SEQ_PTR(_a_4420)->length;
    }
    else {
        _2272 = 1;
    }
    {
        int _i_4426;
        _i_4426 = 1;
L2: 
        if (_i_4426 > _2272){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_4420);
        _2273 = (int)*(((s1_ptr)_2)->base + _i_4426);
        Ref(_2273);
        _0 = _c_4422;
        _c_4422 = _20max(_2273);
        DeRef(_0);
        _2273 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_4422, _b_4421)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_4422);
        DeRef(_b_4421);
        _b_4421 = _c_4422;
L4: 

        /** 	end for*/
        _i_4426 = _i_4426 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4420);
    DeRef(_c_4422);
    return _b_4421;
    ;
}
int max() __attribute__ ((alias ("_20max")));


int _20min(int _a_4434)
{
    int _b_4435 = NOVALUE;
    int _c_4436 = NOVALUE;
    int _2278 = NOVALUE;
    int _2277 = NOVALUE;
    int _2276 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2276 = IS_ATOM(_a_4434);
    if (_2276 == 0)
    {
        _2276 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2276 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_4435);
    DeRef(_c_4436);
    return _a_4434;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_22PINF_4351);
    DeRef(_b_4435);
    _b_4435 = _22PINF_4351;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4434)){
            _2277 = SEQ_PTR(_a_4434)->length;
    }
    else {
        _2277 = 1;
    }
    {
        int _i_4440;
        _i_4440 = 1;
L2: 
        if (_i_4440 > _2277){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_4434);
        _2278 = (int)*(((s1_ptr)_2)->base + _i_4440);
        Ref(_2278);
        _0 = _c_4436;
        _c_4436 = _20min(_2278);
        DeRef(_0);
        _2278 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_4436, _b_4435)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_4436);
        DeRef(_b_4435);
        _b_4435 = _c_4436;
L4: 

        /** 	end for*/
        _i_4440 = _i_4440 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4434);
    DeRef(_c_4436);
    return _b_4435;
    ;
}
int min() __attribute__ ((alias ("_20min")));


int _20ensure_in_range(int _item_4448, int _range_limits_4449)
{
    int _2292 = NOVALUE;
    int _2291 = NOVALUE;
    int _2289 = NOVALUE;
    int _2288 = NOVALUE;
    int _2287 = NOVALUE;
    int _2286 = NOVALUE;
    int _2284 = NOVALUE;
    int _2283 = NOVALUE;
    int _2281 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(range_limits) < 2 then*/
    if (IS_SEQUENCE(_range_limits_4449)){
            _2281 = SEQ_PTR(_range_limits_4449)->length;
    }
    else {
        _2281 = 1;
    }
    if (_2281 >= 2)
    goto L1; // [8] 19

    /** 		return item*/
    DeRefDS(_range_limits_4449);
    return _item_4448;
L1: 

    /** 	if eu:compare(item, range_limits[1]) < 0 then*/
    _2 = (int)SEQ_PTR(_range_limits_4449);
    _2283 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_item_4448) && IS_ATOM_INT(_2283)){
        _2284 = (_item_4448 < _2283) ? -1 : (_item_4448 > _2283);
    }
    else{
        _2284 = compare(_item_4448, _2283);
    }
    _2283 = NOVALUE;
    if (_2284 >= 0)
    goto L2; // [29] 44

    /** 		return range_limits[1]*/
    _2 = (int)SEQ_PTR(_range_limits_4449);
    _2286 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2286);
    DeRef(_item_4448);
    DeRefDS(_range_limits_4449);
    return _2286;
L2: 

    /** 	if eu:compare(item, range_limits[$]) > 0 then*/
    if (IS_SEQUENCE(_range_limits_4449)){
            _2287 = SEQ_PTR(_range_limits_4449)->length;
    }
    else {
        _2287 = 1;
    }
    _2 = (int)SEQ_PTR(_range_limits_4449);
    _2288 = (int)*(((s1_ptr)_2)->base + _2287);
    if (IS_ATOM_INT(_item_4448) && IS_ATOM_INT(_2288)){
        _2289 = (_item_4448 < _2288) ? -1 : (_item_4448 > _2288);
    }
    else{
        _2289 = compare(_item_4448, _2288);
    }
    _2288 = NOVALUE;
    if (_2289 <= 0)
    goto L3; // [57] 75

    /** 		return range_limits[$]*/
    if (IS_SEQUENCE(_range_limits_4449)){
            _2291 = SEQ_PTR(_range_limits_4449)->length;
    }
    else {
        _2291 = 1;
    }
    _2 = (int)SEQ_PTR(_range_limits_4449);
    _2292 = (int)*(((s1_ptr)_2)->base + _2291);
    Ref(_2292);
    DeRef(_item_4448);
    DeRefDS(_range_limits_4449);
    _2286 = NOVALUE;
    return _2292;
L3: 

    /** 	return item*/
    DeRefDS(_range_limits_4449);
    _2286 = NOVALUE;
    _2292 = NOVALUE;
    return _item_4448;
    ;
}
int ensure_in_range() __attribute__ ((alias ("_20ensure_in_range")));


int _20ensure_in_list(int _item_4467, int _list_4468, int _default_4469)
{
    int _2302 = NOVALUE;
    int _2301 = NOVALUE;
    int _2300 = NOVALUE;
    int _2299 = NOVALUE;
    int _2298 = NOVALUE;
    int _2297 = NOVALUE;
    int _2295 = NOVALUE;
    int _2293 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_default_4469)) {
        _1 = (long)(DBL_PTR(_default_4469)->dbl);
        DeRefDS(_default_4469);
        _default_4469 = _1;
    }

    /** 	if length(list) = 0 then*/
    if (IS_SEQUENCE(_list_4468)){
            _2293 = SEQ_PTR(_list_4468)->length;
    }
    else {
        _2293 = 1;
    }
    if (_2293 != 0)
    goto L1; // [10] 21

    /** 		return item*/
    DeRefDS(_list_4468);
    return _item_4467;
L1: 

    /** 	if find(item, list) = 0 then*/
    _2295 = find_from(_item_4467, _list_4468, 1);
    if (_2295 != 0)
    goto L2; // [28] 78

    /** 		if default>=1 and default<=length(list) then*/
    _2297 = (_default_4469 >= 1);
    if (_2297 == 0) {
        goto L3; // [38] 66
    }
    if (IS_SEQUENCE(_list_4468)){
            _2299 = SEQ_PTR(_list_4468)->length;
    }
    else {
        _2299 = 1;
    }
    _2300 = (_default_4469 <= _2299);
    _2299 = NOVALUE;
    if (_2300 == 0)
    {
        DeRef(_2300);
        _2300 = NOVALUE;
        goto L3; // [50] 66
    }
    else{
        DeRef(_2300);
        _2300 = NOVALUE;
    }

    /** 		    return list[default]*/
    _2 = (int)SEQ_PTR(_list_4468);
    _2301 = (int)*(((s1_ptr)_2)->base + _default_4469);
    Ref(_2301);
    DeRef(_item_4467);
    DeRefDS(_list_4468);
    DeRef(_2297);
    _2297 = NOVALUE;
    return _2301;
    goto L4; // [63] 77
L3: 

    /** 			return list[1]*/
    _2 = (int)SEQ_PTR(_list_4468);
    _2302 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2302);
    DeRef(_item_4467);
    DeRefDS(_list_4468);
    DeRef(_2297);
    _2297 = NOVALUE;
    _2301 = NOVALUE;
    return _2302;
L4: 
L2: 

    /** 	return item*/
    DeRefDS(_list_4468);
    DeRef(_2297);
    _2297 = NOVALUE;
    _2301 = NOVALUE;
    _2302 = NOVALUE;
    return _item_4467;
    ;
}
int ensure_in_list() __attribute__ ((alias ("_20ensure_in_list")));


int _20mod(int _x_4486, int _y_4487)
{
    int _sign_2__tmp_at2_4492 = NOVALUE;
    int _sign_1__tmp_at2_4491 = NOVALUE;
    int _sign_inlined_sign_at_2_4490 = NOVALUE;
    int _sign_2__tmp_at19_4496 = NOVALUE;
    int _sign_1__tmp_at19_4495 = NOVALUE;
    int _sign_inlined_sign_at_19_4494 = NOVALUE;
    int _2307 = NOVALUE;
    int _2306 = NOVALUE;
    int _2305 = NOVALUE;
    int _2304 = NOVALUE;
    int _2303 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(sign(x), sign(y)) then*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4491);
    if (IS_ATOM_INT(_x_4486)) {
        _sign_1__tmp_at2_4491 = (_x_4486 > 0);
    }
    else {
        _sign_1__tmp_at2_4491 = binary_op(GREATER, _x_4486, 0);
    }
    DeRef(_sign_2__tmp_at2_4492);
    if (IS_ATOM_INT(_x_4486)) {
        _sign_2__tmp_at2_4492 = (_x_4486 < 0);
    }
    else {
        _sign_2__tmp_at2_4492 = binary_op(LESS, _x_4486, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4490);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4491) && IS_ATOM_INT(_sign_2__tmp_at2_4492)) {
        _sign_inlined_sign_at_2_4490 = _sign_1__tmp_at2_4491 - _sign_2__tmp_at2_4492;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4490 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4490 = NewDouble((double)_sign_inlined_sign_at_2_4490);
        }
    }
    else {
        _sign_inlined_sign_at_2_4490 = binary_op(MINUS, _sign_1__tmp_at2_4491, _sign_2__tmp_at2_4492);
    }
    DeRef(_sign_1__tmp_at2_4491);
    _sign_1__tmp_at2_4491 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4492);
    _sign_2__tmp_at2_4492 = NOVALUE;

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at19_4495);
    if (IS_ATOM_INT(_y_4487)) {
        _sign_1__tmp_at19_4495 = (_y_4487 > 0);
    }
    else {
        _sign_1__tmp_at19_4495 = binary_op(GREATER, _y_4487, 0);
    }
    DeRef(_sign_2__tmp_at19_4496);
    if (IS_ATOM_INT(_y_4487)) {
        _sign_2__tmp_at19_4496 = (_y_4487 < 0);
    }
    else {
        _sign_2__tmp_at19_4496 = binary_op(LESS, _y_4487, 0);
    }
    DeRef(_sign_inlined_sign_at_19_4494);
    if (IS_ATOM_INT(_sign_1__tmp_at19_4495) && IS_ATOM_INT(_sign_2__tmp_at19_4496)) {
        _sign_inlined_sign_at_19_4494 = _sign_1__tmp_at19_4495 - _sign_2__tmp_at19_4496;
        if ((long)((unsigned long)_sign_inlined_sign_at_19_4494 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_19_4494 = NewDouble((double)_sign_inlined_sign_at_19_4494);
        }
    }
    else {
        _sign_inlined_sign_at_19_4494 = binary_op(MINUS, _sign_1__tmp_at19_4495, _sign_2__tmp_at19_4496);
    }
    DeRef(_sign_1__tmp_at19_4495);
    _sign_1__tmp_at19_4495 = NOVALUE;
    DeRef(_sign_2__tmp_at19_4496);
    _sign_2__tmp_at19_4496 = NOVALUE;
    if (_sign_inlined_sign_at_2_4490 == _sign_inlined_sign_at_19_4494)
    _2303 = 1;
    else if (IS_ATOM_INT(_sign_inlined_sign_at_2_4490) && IS_ATOM_INT(_sign_inlined_sign_at_19_4494))
    _2303 = 0;
    else
    _2303 = (compare(_sign_inlined_sign_at_2_4490, _sign_inlined_sign_at_19_4494) == 0);
    if (_2303 == 0)
    {
        _2303 = NOVALUE;
        goto L1; // [41] 55
    }
    else{
        _2303 = NOVALUE;
    }

    /** 		return remainder(x,y)*/
    if (IS_ATOM_INT(_x_4486) && IS_ATOM_INT(_y_4487)) {
        _2304 = (_x_4486 % _y_4487);
    }
    else {
        _2304 = binary_op(REMAINDER, _x_4486, _y_4487);
    }
    DeRef(_x_4486);
    DeRef(_y_4487);
    return _2304;
L1: 

    /** 	return x - y * floor(x / y)*/
    if (IS_ATOM_INT(_x_4486) && IS_ATOM_INT(_y_4487)) {
        if (_y_4487 > 0 && _x_4486 >= 0) {
            _2305 = _x_4486 / _y_4487;
        }
        else {
            temp_dbl = floor((double)_x_4486 / (double)_y_4487);
            if (_x_4486 != MININT)
            _2305 = (long)temp_dbl;
            else
            _2305 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_4486, _y_4487);
        _2305 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_y_4487) && IS_ATOM_INT(_2305)) {
        if (_y_4487 == (short)_y_4487 && _2305 <= INT15 && _2305 >= -INT15)
        _2306 = _y_4487 * _2305;
        else
        _2306 = NewDouble(_y_4487 * (double)_2305);
    }
    else {
        _2306 = binary_op(MULTIPLY, _y_4487, _2305);
    }
    DeRef(_2305);
    _2305 = NOVALUE;
    if (IS_ATOM_INT(_x_4486) && IS_ATOM_INT(_2306)) {
        _2307 = _x_4486 - _2306;
        if ((long)((unsigned long)_2307 +(unsigned long) HIGH_BITS) >= 0){
            _2307 = NewDouble((double)_2307);
        }
    }
    else {
        _2307 = binary_op(MINUS, _x_4486, _2306);
    }
    DeRef(_2306);
    _2306 = NOVALUE;
    DeRef(_x_4486);
    DeRef(_y_4487);
    DeRef(_2304);
    _2304 = NOVALUE;
    return _2307;
    ;
}
int mod() __attribute__ ((alias ("_20mod")));


int _20trunc(int _x_4504)
{
    int _sign_2__tmp_at2_4508 = NOVALUE;
    int _sign_1__tmp_at2_4507 = NOVALUE;
    int _sign_inlined_sign_at_2_4506 = NOVALUE;
    int _2310 = NOVALUE;
    int _2309 = NOVALUE;
    int _2308 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sign(x) * floor(abs(x))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4507);
    if (IS_ATOM_INT(_x_4504)) {
        _sign_1__tmp_at2_4507 = (_x_4504 > 0);
    }
    else {
        _sign_1__tmp_at2_4507 = binary_op(GREATER, _x_4504, 0);
    }
    DeRef(_sign_2__tmp_at2_4508);
    if (IS_ATOM_INT(_x_4504)) {
        _sign_2__tmp_at2_4508 = (_x_4504 < 0);
    }
    else {
        _sign_2__tmp_at2_4508 = binary_op(LESS, _x_4504, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4506);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4507) && IS_ATOM_INT(_sign_2__tmp_at2_4508)) {
        _sign_inlined_sign_at_2_4506 = _sign_1__tmp_at2_4507 - _sign_2__tmp_at2_4508;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4506 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4506 = NewDouble((double)_sign_inlined_sign_at_2_4506);
        }
    }
    else {
        _sign_inlined_sign_at_2_4506 = binary_op(MINUS, _sign_1__tmp_at2_4507, _sign_2__tmp_at2_4508);
    }
    DeRef(_sign_1__tmp_at2_4507);
    _sign_1__tmp_at2_4507 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4508);
    _sign_2__tmp_at2_4508 = NOVALUE;
    Ref(_x_4504);
    _2308 = _20abs(_x_4504);
    if (IS_ATOM_INT(_2308))
    _2309 = e_floor(_2308);
    else
    _2309 = unary_op(FLOOR, _2308);
    DeRef(_2308);
    _2308 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_2_4506) && IS_ATOM_INT(_2309)) {
        if (_sign_inlined_sign_at_2_4506 == (short)_sign_inlined_sign_at_2_4506 && _2309 <= INT15 && _2309 >= -INT15)
        _2310 = _sign_inlined_sign_at_2_4506 * _2309;
        else
        _2310 = NewDouble(_sign_inlined_sign_at_2_4506 * (double)_2309);
    }
    else {
        _2310 = binary_op(MULTIPLY, _sign_inlined_sign_at_2_4506, _2309);
    }
    DeRef(_2309);
    _2309 = NOVALUE;
    DeRef(_x_4504);
    return _2310;
    ;
}
int trunc() __attribute__ ((alias ("_20trunc")));


int _20frac(int _x_4514)
{
    int _temp_4515 = NOVALUE;
    int _sign_2__tmp_at8_4520 = NOVALUE;
    int _sign_1__tmp_at8_4519 = NOVALUE;
    int _sign_inlined_sign_at_8_4518 = NOVALUE;
    int _2314 = NOVALUE;
    int _2313 = NOVALUE;
    int _2312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object temp = abs(x)*/
    Ref(_x_4514);
    _0 = _temp_4515;
    _temp_4515 = _20abs(_x_4514);
    DeRef(_0);

    /** 	return sign(x) * (temp - floor(temp))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at8_4519);
    if (IS_ATOM_INT(_x_4514)) {
        _sign_1__tmp_at8_4519 = (_x_4514 > 0);
    }
    else {
        _sign_1__tmp_at8_4519 = binary_op(GREATER, _x_4514, 0);
    }
    DeRef(_sign_2__tmp_at8_4520);
    if (IS_ATOM_INT(_x_4514)) {
        _sign_2__tmp_at8_4520 = (_x_4514 < 0);
    }
    else {
        _sign_2__tmp_at8_4520 = binary_op(LESS, _x_4514, 0);
    }
    DeRef(_sign_inlined_sign_at_8_4518);
    if (IS_ATOM_INT(_sign_1__tmp_at8_4519) && IS_ATOM_INT(_sign_2__tmp_at8_4520)) {
        _sign_inlined_sign_at_8_4518 = _sign_1__tmp_at8_4519 - _sign_2__tmp_at8_4520;
        if ((long)((unsigned long)_sign_inlined_sign_at_8_4518 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_8_4518 = NewDouble((double)_sign_inlined_sign_at_8_4518);
        }
    }
    else {
        _sign_inlined_sign_at_8_4518 = binary_op(MINUS, _sign_1__tmp_at8_4519, _sign_2__tmp_at8_4520);
    }
    DeRef(_sign_1__tmp_at8_4519);
    _sign_1__tmp_at8_4519 = NOVALUE;
    DeRef(_sign_2__tmp_at8_4520);
    _sign_2__tmp_at8_4520 = NOVALUE;
    if (IS_ATOM_INT(_temp_4515))
    _2312 = e_floor(_temp_4515);
    else
    _2312 = unary_op(FLOOR, _temp_4515);
    if (IS_ATOM_INT(_temp_4515) && IS_ATOM_INT(_2312)) {
        _2313 = _temp_4515 - _2312;
        if ((long)((unsigned long)_2313 +(unsigned long) HIGH_BITS) >= 0){
            _2313 = NewDouble((double)_2313);
        }
    }
    else {
        _2313 = binary_op(MINUS, _temp_4515, _2312);
    }
    DeRef(_2312);
    _2312 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_8_4518) && IS_ATOM_INT(_2313)) {
        if (_sign_inlined_sign_at_8_4518 == (short)_sign_inlined_sign_at_8_4518 && _2313 <= INT15 && _2313 >= -INT15)
        _2314 = _sign_inlined_sign_at_8_4518 * _2313;
        else
        _2314 = NewDouble(_sign_inlined_sign_at_8_4518 * (double)_2313);
    }
    else {
        _2314 = binary_op(MULTIPLY, _sign_inlined_sign_at_8_4518, _2313);
    }
    DeRef(_2313);
    _2313 = NOVALUE;
    DeRef(_x_4514);
    DeRef(_temp_4515);
    return _2314;
    ;
}
int frac() __attribute__ ((alias ("_20frac")));


int _20intdiv(int _a_4526, int _b_4527)
{
    int _sign_2__tmp_at2_4531 = NOVALUE;
    int _sign_1__tmp_at2_4530 = NOVALUE;
    int _sign_inlined_sign_at_2_4529 = NOVALUE;
    int _2319 = NOVALUE;
    int _2318 = NOVALUE;
    int _2317 = NOVALUE;
    int _2316 = NOVALUE;
    int _2315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sign(a)*ceil(abs(a)/abs(b))*/

    /** 	return (a > 0) - (a < 0)*/
    DeRef(_sign_1__tmp_at2_4530);
    if (IS_ATOM_INT(_a_4526)) {
        _sign_1__tmp_at2_4530 = (_a_4526 > 0);
    }
    else {
        _sign_1__tmp_at2_4530 = binary_op(GREATER, _a_4526, 0);
    }
    DeRef(_sign_2__tmp_at2_4531);
    if (IS_ATOM_INT(_a_4526)) {
        _sign_2__tmp_at2_4531 = (_a_4526 < 0);
    }
    else {
        _sign_2__tmp_at2_4531 = binary_op(LESS, _a_4526, 0);
    }
    DeRef(_sign_inlined_sign_at_2_4529);
    if (IS_ATOM_INT(_sign_1__tmp_at2_4530) && IS_ATOM_INT(_sign_2__tmp_at2_4531)) {
        _sign_inlined_sign_at_2_4529 = _sign_1__tmp_at2_4530 - _sign_2__tmp_at2_4531;
        if ((long)((unsigned long)_sign_inlined_sign_at_2_4529 +(unsigned long) HIGH_BITS) >= 0){
            _sign_inlined_sign_at_2_4529 = NewDouble((double)_sign_inlined_sign_at_2_4529);
        }
    }
    else {
        _sign_inlined_sign_at_2_4529 = binary_op(MINUS, _sign_1__tmp_at2_4530, _sign_2__tmp_at2_4531);
    }
    DeRef(_sign_1__tmp_at2_4530);
    _sign_1__tmp_at2_4530 = NOVALUE;
    DeRef(_sign_2__tmp_at2_4531);
    _sign_2__tmp_at2_4531 = NOVALUE;
    Ref(_a_4526);
    _2315 = _20abs(_a_4526);
    Ref(_b_4527);
    _2316 = _20abs(_b_4527);
    if (IS_ATOM_INT(_2315) && IS_ATOM_INT(_2316)) {
        _2317 = (_2315 % _2316) ? NewDouble((double)_2315 / _2316) : (_2315 / _2316);
    }
    else {
        _2317 = binary_op(DIVIDE, _2315, _2316);
    }
    DeRef(_2315);
    _2315 = NOVALUE;
    DeRef(_2316);
    _2316 = NOVALUE;
    _2318 = _20ceil(_2317);
    _2317 = NOVALUE;
    if (IS_ATOM_INT(_sign_inlined_sign_at_2_4529) && IS_ATOM_INT(_2318)) {
        if (_sign_inlined_sign_at_2_4529 == (short)_sign_inlined_sign_at_2_4529 && _2318 <= INT15 && _2318 >= -INT15)
        _2319 = _sign_inlined_sign_at_2_4529 * _2318;
        else
        _2319 = NewDouble(_sign_inlined_sign_at_2_4529 * (double)_2318);
    }
    else {
        _2319 = binary_op(MULTIPLY, _sign_inlined_sign_at_2_4529, _2318);
    }
    DeRef(_2318);
    _2318 = NOVALUE;
    DeRef(_a_4526);
    DeRef(_b_4527);
    return _2319;
    ;
}
int intdiv() __attribute__ ((alias ("_20intdiv")));


int _20ceil(int _a_4540)
{
    int _2322 = NOVALUE;
    int _2321 = NOVALUE;
    int _2320 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return -floor(-a)*/
    if (IS_ATOM_INT(_a_4540)) {
        if ((unsigned long)_a_4540 == 0xC0000000)
        _2320 = (int)NewDouble((double)-0xC0000000);
        else
        _2320 = - _a_4540;
    }
    else {
        _2320 = unary_op(UMINUS, _a_4540);
    }
    if (IS_ATOM_INT(_2320))
    _2321 = e_floor(_2320);
    else
    _2321 = unary_op(FLOOR, _2320);
    DeRef(_2320);
    _2320 = NOVALUE;
    if (IS_ATOM_INT(_2321)) {
        if ((unsigned long)_2321 == 0xC0000000)
        _2322 = (int)NewDouble((double)-0xC0000000);
        else
        _2322 = - _2321;
    }
    else {
        _2322 = unary_op(UMINUS, _2321);
    }
    DeRef(_2321);
    _2321 = NOVALUE;
    DeRef(_a_4540);
    return _2322;
    ;
}
int ceil() __attribute__ ((alias ("_20ceil")));


int _20round(int _a_4546, int _precision_4547)
{
    int _len_4548 = NOVALUE;
    int _s_4549 = NOVALUE;
    int _t_4550 = NOVALUE;
    int _u_4551 = NOVALUE;
    int _msg_inlined_crash_at_257_4602 = NOVALUE;
    int _2374 = NOVALUE;
    int _2373 = NOVALUE;
    int _2372 = NOVALUE;
    int _2371 = NOVALUE;
    int _2370 = NOVALUE;
    int _2369 = NOVALUE;
    int _2368 = NOVALUE;
    int _2367 = NOVALUE;
    int _2366 = NOVALUE;
    int _2365 = NOVALUE;
    int _2363 = NOVALUE;
    int _2361 = NOVALUE;
    int _2357 = NOVALUE;
    int _2355 = NOVALUE;
    int _2354 = NOVALUE;
    int _2353 = NOVALUE;
    int _2352 = NOVALUE;
    int _2351 = NOVALUE;
    int _2350 = NOVALUE;
    int _2349 = NOVALUE;
    int _2348 = NOVALUE;
    int _2346 = NOVALUE;
    int _2343 = NOVALUE;
    int _2342 = NOVALUE;
    int _2341 = NOVALUE;
    int _2340 = NOVALUE;
    int _2339 = NOVALUE;
    int _2338 = NOVALUE;
    int _2337 = NOVALUE;
    int _2336 = NOVALUE;
    int _2335 = NOVALUE;
    int _2333 = NOVALUE;
    int _2330 = NOVALUE;
    int _2329 = NOVALUE;
    int _2328 = NOVALUE;
    int _2327 = NOVALUE;
    int _2325 = NOVALUE;
    int _2324 = NOVALUE;
    int _0, _1, _2;
    

    /** 	precision = abs(precision)*/
    Ref(_precision_4547);
    _0 = _precision_4547;
    _precision_4547 = _20abs(_precision_4547);
    DeRef(_0);

    /** 	if atom(a) then*/
    _2324 = IS_ATOM(_a_4546);
    if (_2324 == 0)
    {
        _2324 = NOVALUE;
        goto L1; // [12] 140
    }
    else{
        _2324 = NOVALUE;
    }

    /** 		if atom(precision) then*/
    _2325 = IS_ATOM(_precision_4547);
    if (_2325 == 0)
    {
        _2325 = NOVALUE;
        goto L2; // [20] 45
    }
    else{
        _2325 = NOVALUE;
    }

    /** 			return floor(0.5 + (a * precision )) / precision*/
    if (IS_ATOM_INT(_a_4546) && IS_ATOM_INT(_precision_4547)) {
        if (_a_4546 == (short)_a_4546 && _precision_4547 <= INT15 && _precision_4547 >= -INT15)
        _2327 = _a_4546 * _precision_4547;
        else
        _2327 = NewDouble(_a_4546 * (double)_precision_4547);
    }
    else {
        _2327 = binary_op(MULTIPLY, _a_4546, _precision_4547);
    }
    _2328 = binary_op(PLUS, _2326, _2327);
    DeRef(_2327);
    _2327 = NOVALUE;
    if (IS_ATOM_INT(_2328))
    _2329 = e_floor(_2328);
    else
    _2329 = unary_op(FLOOR, _2328);
    DeRef(_2328);
    _2328 = NOVALUE;
    if (IS_ATOM_INT(_2329) && IS_ATOM_INT(_precision_4547)) {
        _2330 = (_2329 % _precision_4547) ? NewDouble((double)_2329 / _precision_4547) : (_2329 / _precision_4547);
    }
    else {
        _2330 = binary_op(DIVIDE, _2329, _precision_4547);
    }
    DeRef(_2329);
    _2329 = NOVALUE;
    DeRef(_a_4546);
    DeRef(_precision_4547);
    DeRef(_s_4549);
    DeRef(_t_4550);
    DeRef(_u_4551);
    return _2330;
L2: 

    /** 		len = length(precision)*/
    if (IS_SEQUENCE(_precision_4547)){
            _len_4548 = SEQ_PTR(_precision_4547)->length;
    }
    else {
        _len_4548 = 1;
    }

    /** 		s = repeat(0, len)*/
    DeRef(_s_4549);
    _s_4549 = Repeat(0, _len_4548);

    /** 		for i = 1 to len do*/
    _2333 = _len_4548;
    {
        int _i_4565;
        _i_4565 = 1;
L3: 
        if (_i_4565 > _2333){
            goto L4; // [61] 131
        }

        /** 			t = precision[i]*/
        DeRef(_t_4550);
        _2 = (int)SEQ_PTR(_precision_4547);
        _t_4550 = (int)*(((s1_ptr)_2)->base + _i_4565);
        Ref(_t_4550);

        /** 			if atom (t) then*/
        _2335 = IS_ATOM(_t_4550);
        if (_2335 == 0)
        {
            _2335 = NOVALUE;
            goto L5; // [79] 106
        }
        else{
            _2335 = NOVALUE;
        }

        /** 				s[i] = floor( 0.5 + (a * t)) / t*/
        if (IS_ATOM_INT(_a_4546) && IS_ATOM_INT(_t_4550)) {
            if (_a_4546 == (short)_a_4546 && _t_4550 <= INT15 && _t_4550 >= -INT15)
            _2336 = _a_4546 * _t_4550;
            else
            _2336 = NewDouble(_a_4546 * (double)_t_4550);
        }
        else {
            _2336 = binary_op(MULTIPLY, _a_4546, _t_4550);
        }
        _2337 = binary_op(PLUS, _2326, _2336);
        DeRef(_2336);
        _2336 = NOVALUE;
        if (IS_ATOM_INT(_2337))
        _2338 = e_floor(_2337);
        else
        _2338 = unary_op(FLOOR, _2337);
        DeRef(_2337);
        _2337 = NOVALUE;
        if (IS_ATOM_INT(_2338) && IS_ATOM_INT(_t_4550)) {
            _2339 = (_2338 % _t_4550) ? NewDouble((double)_2338 / _t_4550) : (_2338 / _t_4550);
        }
        else {
            _2339 = binary_op(DIVIDE, _2338, _t_4550);
        }
        DeRef(_2338);
        _2338 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4565);
        _1 = *(int *)_2;
        *(int *)_2 = _2339;
        if( _1 != _2339 ){
            DeRef(_1);
        }
        _2339 = NOVALUE;
        goto L6; // [103] 124
L5: 

        /** 				s[i] = round(a, t)*/
        Ref(_a_4546);
        DeRef(_2340);
        _2340 = _a_4546;
        Ref(_t_4550);
        DeRef(_2341);
        _2341 = _t_4550;
        _2342 = _20round(_2340, _2341);
        _2340 = NOVALUE;
        _2341 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4565);
        _1 = *(int *)_2;
        *(int *)_2 = _2342;
        if( _1 != _2342 ){
            DeRef(_1);
        }
        _2342 = NOVALUE;
L6: 

        /** 		end for*/
        _i_4565 = _i_4565 + 1;
        goto L3; // [126] 68
L4: 
        ;
    }

    /** 		return s*/
    DeRef(_a_4546);
    DeRef(_precision_4547);
    DeRef(_t_4550);
    DeRef(_u_4551);
    DeRef(_2330);
    _2330 = NOVALUE;
    return _s_4549;
    goto L7; // [137] 242
L1: 

    /** 	elsif atom(precision) then*/
    _2343 = IS_ATOM(_precision_4547);
    if (_2343 == 0)
    {
        _2343 = NOVALUE;
        goto L8; // [145] 241
    }
    else{
        _2343 = NOVALUE;
    }

    /** 		len = length(a)*/
    if (IS_SEQUENCE(_a_4546)){
            _len_4548 = SEQ_PTR(_a_4546)->length;
    }
    else {
        _len_4548 = 1;
    }

    /** 		s = repeat(0, len)*/
    DeRef(_s_4549);
    _s_4549 = Repeat(0, _len_4548);

    /** 		for i = 1 to len do*/
    _2346 = _len_4548;
    {
        int _i_4583;
        _i_4583 = 1;
L9: 
        if (_i_4583 > _2346){
            goto LA; // [164] 234
        }

        /** 			t = a[i]*/
        DeRef(_t_4550);
        _2 = (int)SEQ_PTR(_a_4546);
        _t_4550 = (int)*(((s1_ptr)_2)->base + _i_4583);
        Ref(_t_4550);

        /** 			if atom(t) then*/
        _2348 = IS_ATOM(_t_4550);
        if (_2348 == 0)
        {
            _2348 = NOVALUE;
            goto LB; // [182] 209
        }
        else{
            _2348 = NOVALUE;
        }

        /** 				s[i] = floor(0.5 + (t * precision)) / precision*/
        if (IS_ATOM_INT(_t_4550) && IS_ATOM_INT(_precision_4547)) {
            if (_t_4550 == (short)_t_4550 && _precision_4547 <= INT15 && _precision_4547 >= -INT15)
            _2349 = _t_4550 * _precision_4547;
            else
            _2349 = NewDouble(_t_4550 * (double)_precision_4547);
        }
        else {
            _2349 = binary_op(MULTIPLY, _t_4550, _precision_4547);
        }
        _2350 = binary_op(PLUS, _2326, _2349);
        DeRef(_2349);
        _2349 = NOVALUE;
        if (IS_ATOM_INT(_2350))
        _2351 = e_floor(_2350);
        else
        _2351 = unary_op(FLOOR, _2350);
        DeRef(_2350);
        _2350 = NOVALUE;
        if (IS_ATOM_INT(_2351) && IS_ATOM_INT(_precision_4547)) {
            _2352 = (_2351 % _precision_4547) ? NewDouble((double)_2351 / _precision_4547) : (_2351 / _precision_4547);
        }
        else {
            _2352 = binary_op(DIVIDE, _2351, _precision_4547);
        }
        DeRef(_2351);
        _2351 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4583);
        _1 = *(int *)_2;
        *(int *)_2 = _2352;
        if( _1 != _2352 ){
            DeRef(_1);
        }
        _2352 = NOVALUE;
        goto LC; // [206] 227
LB: 

        /** 				s[i] = round(t, precision)*/
        Ref(_t_4550);
        DeRef(_2353);
        _2353 = _t_4550;
        Ref(_precision_4547);
        DeRef(_2354);
        _2354 = _precision_4547;
        _2355 = _20round(_2353, _2354);
        _2353 = NOVALUE;
        _2354 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4583);
        _1 = *(int *)_2;
        *(int *)_2 = _2355;
        if( _1 != _2355 ){
            DeRef(_1);
        }
        _2355 = NOVALUE;
LC: 

        /** 		end for*/
        _i_4583 = _i_4583 + 1;
        goto L9; // [229] 171
LA: 
        ;
    }

    /** 		return s*/
    DeRef(_a_4546);
    DeRef(_precision_4547);
    DeRef(_t_4550);
    DeRef(_u_4551);
    DeRef(_2330);
    _2330 = NOVALUE;
    return _s_4549;
L8: 
L7: 

    /** 	len = length(a)*/
    if (IS_SEQUENCE(_a_4546)){
            _len_4548 = SEQ_PTR(_a_4546)->length;
    }
    else {
        _len_4548 = 1;
    }

    /** 	if len != length(precision) then*/
    if (IS_SEQUENCE(_precision_4547)){
            _2357 = SEQ_PTR(_precision_4547)->length;
    }
    else {
        _2357 = 1;
    }
    if (_len_4548 == _2357)
    goto LD; // [252] 277

    /** 		error:crash("The lengths of the two supplied sequences do not match.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_257_4602);
    _msg_inlined_crash_at_257_4602 = EPrintf(-9999999, _2359, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_257_4602);

    /** end procedure*/
    goto LE; // [271] 274
LE: 
    DeRefi(_msg_inlined_crash_at_257_4602);
    _msg_inlined_crash_at_257_4602 = NOVALUE;
LD: 

    /** 	s = repeat(0, len)*/
    DeRef(_s_4549);
    _s_4549 = Repeat(0, _len_4548);

    /** 	for i = 1 to len do*/
    _2361 = _len_4548;
    {
        int _i_4605;
        _i_4605 = 1;
LF: 
        if (_i_4605 > _2361){
            goto L10; // [288] 391
        }

        /** 		t = precision[i]*/
        DeRef(_t_4550);
        _2 = (int)SEQ_PTR(_precision_4547);
        _t_4550 = (int)*(((s1_ptr)_2)->base + _i_4605);
        Ref(_t_4550);

        /** 		if atom(t) then*/
        _2363 = IS_ATOM(_t_4550);
        if (_2363 == 0)
        {
            _2363 = NOVALUE;
            goto L11; // [306] 365
        }
        else{
            _2363 = NOVALUE;
        }

        /** 			u = a[i]*/
        DeRef(_u_4551);
        _2 = (int)SEQ_PTR(_a_4546);
        _u_4551 = (int)*(((s1_ptr)_2)->base + _i_4605);
        Ref(_u_4551);

        /** 			if atom(u) then*/
        _2365 = IS_ATOM(_u_4551);
        if (_2365 == 0)
        {
            _2365 = NOVALUE;
            goto L12; // [320] 347
        }
        else{
            _2365 = NOVALUE;
        }

        /** 				s[i] = floor(0.5 + (u * t)) / t*/
        if (IS_ATOM_INT(_u_4551) && IS_ATOM_INT(_t_4550)) {
            if (_u_4551 == (short)_u_4551 && _t_4550 <= INT15 && _t_4550 >= -INT15)
            _2366 = _u_4551 * _t_4550;
            else
            _2366 = NewDouble(_u_4551 * (double)_t_4550);
        }
        else {
            _2366 = binary_op(MULTIPLY, _u_4551, _t_4550);
        }
        _2367 = binary_op(PLUS, _2326, _2366);
        DeRef(_2366);
        _2366 = NOVALUE;
        if (IS_ATOM_INT(_2367))
        _2368 = e_floor(_2367);
        else
        _2368 = unary_op(FLOOR, _2367);
        DeRef(_2367);
        _2367 = NOVALUE;
        if (IS_ATOM_INT(_2368) && IS_ATOM_INT(_t_4550)) {
            _2369 = (_2368 % _t_4550) ? NewDouble((double)_2368 / _t_4550) : (_2368 / _t_4550);
        }
        else {
            _2369 = binary_op(DIVIDE, _2368, _t_4550);
        }
        DeRef(_2368);
        _2368 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4605);
        _1 = *(int *)_2;
        *(int *)_2 = _2369;
        if( _1 != _2369 ){
            DeRef(_1);
        }
        _2369 = NOVALUE;
        goto L13; // [344] 384
L12: 

        /** 				s[i] = round(u, t)*/
        Ref(_t_4550);
        DeRef(_2370);
        _2370 = _t_4550;
        Ref(_u_4551);
        _2371 = _20round(_u_4551, _2370);
        _2370 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4605);
        _1 = *(int *)_2;
        *(int *)_2 = _2371;
        if( _1 != _2371 ){
            DeRef(_1);
        }
        _2371 = NOVALUE;
        goto L13; // [362] 384
L11: 

        /** 			s[i] = round(a[i], t)*/
        _2 = (int)SEQ_PTR(_a_4546);
        _2372 = (int)*(((s1_ptr)_2)->base + _i_4605);
        Ref(_t_4550);
        DeRef(_2373);
        _2373 = _t_4550;
        Ref(_2372);
        _2374 = _20round(_2372, _2373);
        _2372 = NOVALUE;
        _2373 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_4549);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_4549 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4605);
        _1 = *(int *)_2;
        *(int *)_2 = _2374;
        if( _1 != _2374 ){
            DeRef(_1);
        }
        _2374 = NOVALUE;
L13: 

        /** 	end for*/
        _i_4605 = _i_4605 + 1;
        goto LF; // [386] 295
L10: 
        ;
    }

    /** 	return s*/
    DeRef(_a_4546);
    DeRef(_precision_4547);
    DeRef(_t_4550);
    DeRef(_u_4551);
    DeRef(_2330);
    _2330 = NOVALUE;
    return _s_4549;
    ;
}
int round() __attribute__ ((alias ("_20round")));


int _20arccos(int _x_4626)
{
    int _2382 = NOVALUE;
    int _2381 = NOVALUE;
    int _2380 = NOVALUE;
    int _2379 = NOVALUE;
    int _2378 = NOVALUE;
    int _2377 = NOVALUE;
    int _2376 = NOVALUE;
    int _2375 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return mathcons:HALFPI - 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))*/
    if (IS_ATOM_INT(_x_4626) && IS_ATOM_INT(_x_4626)) {
        if (_x_4626 == (short)_x_4626 && _x_4626 <= INT15 && _x_4626 >= -INT15)
        _2375 = _x_4626 * _x_4626;
        else
        _2375 = NewDouble(_x_4626 * (double)_x_4626);
    }
    else {
        _2375 = binary_op(MULTIPLY, _x_4626, _x_4626);
    }
    _2376 = binary_op(MINUS, _2193, _2375);
    DeRef(_2375);
    _2375 = NOVALUE;
    if (IS_ATOM_INT(_2376))
    _2377 = e_sqrt(_2376);
    else
    _2377 = unary_op(SQRT, _2376);
    DeRef(_2376);
    _2376 = NOVALUE;
    _2378 = binary_op(PLUS, _2193, _2377);
    DeRef(_2377);
    _2377 = NOVALUE;
    if (IS_ATOM_INT(_x_4626) && IS_ATOM_INT(_2378)) {
        _2379 = (_x_4626 % _2378) ? NewDouble((double)_x_4626 / _2378) : (_x_4626 / _2378);
    }
    else {
        _2379 = binary_op(DIVIDE, _x_4626, _2378);
    }
    DeRef(_2378);
    _2378 = NOVALUE;
    if (IS_ATOM_INT(_2379))
    _2380 = e_arctan(_2379);
    else
    _2380 = unary_op(ARCTAN, _2379);
    DeRef(_2379);
    _2379 = NOVALUE;
    if (IS_ATOM_INT(_2380) && IS_ATOM_INT(_2380)) {
        _2381 = _2380 + _2380;
        if ((long)((unsigned long)_2381 + (unsigned long)HIGH_BITS) >= 0) 
        _2381 = NewDouble((double)_2381);
    }
    else {
        _2381 = binary_op(PLUS, _2380, _2380);
    }
    DeRef(_2380);
    _2380 = NOVALUE;
    _2380 = NOVALUE;
    _2382 = binary_op(MINUS, _22HALFPI_4317, _2381);
    DeRef(_2381);
    _2381 = NOVALUE;
    DeRef(_x_4626);
    return _2382;
    ;
}
int arccos() __attribute__ ((alias ("_20arccos")));


int _20arcsin(int _x_4637)
{
    int _2389 = NOVALUE;
    int _2388 = NOVALUE;
    int _2387 = NOVALUE;
    int _2386 = NOVALUE;
    int _2385 = NOVALUE;
    int _2384 = NOVALUE;
    int _2383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return 2 * arctan(x / (1.0 + sqrt(1.0 - x * x)))*/
    if (IS_ATOM_INT(_x_4637) && IS_ATOM_INT(_x_4637)) {
        if (_x_4637 == (short)_x_4637 && _x_4637 <= INT15 && _x_4637 >= -INT15)
        _2383 = _x_4637 * _x_4637;
        else
        _2383 = NewDouble(_x_4637 * (double)_x_4637);
    }
    else {
        _2383 = binary_op(MULTIPLY, _x_4637, _x_4637);
    }
    _2384 = binary_op(MINUS, _2193, _2383);
    DeRef(_2383);
    _2383 = NOVALUE;
    if (IS_ATOM_INT(_2384))
    _2385 = e_sqrt(_2384);
    else
    _2385 = unary_op(SQRT, _2384);
    DeRef(_2384);
    _2384 = NOVALUE;
    _2386 = binary_op(PLUS, _2193, _2385);
    DeRef(_2385);
    _2385 = NOVALUE;
    if (IS_ATOM_INT(_x_4637) && IS_ATOM_INT(_2386)) {
        _2387 = (_x_4637 % _2386) ? NewDouble((double)_x_4637 / _2386) : (_x_4637 / _2386);
    }
    else {
        _2387 = binary_op(DIVIDE, _x_4637, _2386);
    }
    DeRef(_2386);
    _2386 = NOVALUE;
    if (IS_ATOM_INT(_2387))
    _2388 = e_arctan(_2387);
    else
    _2388 = unary_op(ARCTAN, _2387);
    DeRef(_2387);
    _2387 = NOVALUE;
    if (IS_ATOM_INT(_2388) && IS_ATOM_INT(_2388)) {
        _2389 = _2388 + _2388;
        if ((long)((unsigned long)_2389 + (unsigned long)HIGH_BITS) >= 0) 
        _2389 = NewDouble((double)_2389);
    }
    else {
        _2389 = binary_op(PLUS, _2388, _2388);
    }
    DeRef(_2388);
    _2388 = NOVALUE;
    _2388 = NOVALUE;
    DeRef(_x_4637);
    return _2389;
    ;
}
int arcsin() __attribute__ ((alias ("_20arcsin")));


int _20atan2(int _y_4647, int _x_4648)
{
    int _2400 = NOVALUE;
    int _2399 = NOVALUE;
    int _2398 = NOVALUE;
    int _2397 = NOVALUE;
    int _2396 = NOVALUE;
    int _2395 = NOVALUE;
    int _2392 = NOVALUE;
    int _2391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if x > 0 then*/
    if (binary_op_a(LESSEQ, _x_4648, 0)){
        goto L1; // [3] 23
    }

    /** 		return arctan(y/x)*/
    if (IS_ATOM_INT(_y_4647) && IS_ATOM_INT(_x_4648)) {
        _2391 = (_y_4647 % _x_4648) ? NewDouble((double)_y_4647 / _x_4648) : (_y_4647 / _x_4648);
    }
    else {
        if (IS_ATOM_INT(_y_4647)) {
            _2391 = NewDouble((double)_y_4647 / DBL_PTR(_x_4648)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4648)) {
                _2391 = NewDouble(DBL_PTR(_y_4647)->dbl / (double)_x_4648);
            }
            else
            _2391 = NewDouble(DBL_PTR(_y_4647)->dbl / DBL_PTR(_x_4648)->dbl);
        }
    }
    if (IS_ATOM_INT(_2391))
    _2392 = e_arctan(_2391);
    else
    _2392 = unary_op(ARCTAN, _2391);
    DeRef(_2391);
    _2391 = NOVALUE;
    DeRef(_y_4647);
    DeRef(_x_4648);
    return _2392;
    goto L2; // [20] 113
L1: 

    /** 	elsif x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_4648, 0)){
        goto L3; // [25] 76
    }

    /** 		if y < 0 then*/
    if (binary_op_a(GREATEREQ, _y_4647, 0)){
        goto L4; // [31] 55
    }

    /** 			return arctan(y/x) - mathcons:PI*/
    if (IS_ATOM_INT(_y_4647) && IS_ATOM_INT(_x_4648)) {
        _2395 = (_y_4647 % _x_4648) ? NewDouble((double)_y_4647 / _x_4648) : (_y_4647 / _x_4648);
    }
    else {
        if (IS_ATOM_INT(_y_4647)) {
            _2395 = NewDouble((double)_y_4647 / DBL_PTR(_x_4648)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4648)) {
                _2395 = NewDouble(DBL_PTR(_y_4647)->dbl / (double)_x_4648);
            }
            else
            _2395 = NewDouble(DBL_PTR(_y_4647)->dbl / DBL_PTR(_x_4648)->dbl);
        }
    }
    if (IS_ATOM_INT(_2395))
    _2396 = e_arctan(_2395);
    else
    _2396 = unary_op(ARCTAN, _2395);
    DeRef(_2395);
    _2395 = NOVALUE;
    _2397 = NewDouble(DBL_PTR(_2396)->dbl - DBL_PTR(_22PI_4313)->dbl);
    DeRefDS(_2396);
    _2396 = NOVALUE;
    DeRef(_y_4647);
    DeRef(_x_4648);
    DeRef(_2392);
    _2392 = NOVALUE;
    return _2397;
    goto L2; // [52] 113
L4: 

    /** 			return arctan(y/x) + mathcons:PI*/
    if (IS_ATOM_INT(_y_4647) && IS_ATOM_INT(_x_4648)) {
        _2398 = (_y_4647 % _x_4648) ? NewDouble((double)_y_4647 / _x_4648) : (_y_4647 / _x_4648);
    }
    else {
        if (IS_ATOM_INT(_y_4647)) {
            _2398 = NewDouble((double)_y_4647 / DBL_PTR(_x_4648)->dbl);
        }
        else {
            if (IS_ATOM_INT(_x_4648)) {
                _2398 = NewDouble(DBL_PTR(_y_4647)->dbl / (double)_x_4648);
            }
            else
            _2398 = NewDouble(DBL_PTR(_y_4647)->dbl / DBL_PTR(_x_4648)->dbl);
        }
    }
    if (IS_ATOM_INT(_2398))
    _2399 = e_arctan(_2398);
    else
    _2399 = unary_op(ARCTAN, _2398);
    DeRef(_2398);
    _2398 = NOVALUE;
    _2400 = NewDouble(DBL_PTR(_2399)->dbl + DBL_PTR(_22PI_4313)->dbl);
    DeRefDS(_2399);
    _2399 = NOVALUE;
    DeRef(_y_4647);
    DeRef(_x_4648);
    DeRef(_2392);
    _2392 = NOVALUE;
    DeRef(_2397);
    _2397 = NOVALUE;
    return _2400;
    goto L2; // [73] 113
L3: 

    /** 	elsif y > 0 then*/
    if (binary_op_a(LESSEQ, _y_4647, 0)){
        goto L5; // [78] 91
    }

    /** 		return mathcons:HALFPI*/
    RefDS(_22HALFPI_4317);
    DeRef(_y_4647);
    DeRef(_x_4648);
    DeRef(_2392);
    _2392 = NOVALUE;
    DeRef(_2397);
    _2397 = NOVALUE;
    DeRef(_2400);
    _2400 = NOVALUE;
    return _22HALFPI_4317;
    goto L2; // [88] 113
L5: 

    /** 	elsif y < 0 then*/
    if (binary_op_a(GREATEREQ, _y_4647, 0)){
        goto L6; // [93] 106
    }

    /** 		return -(mathcons:HALFPI)*/
    RefDS(_2403);
    DeRef(_y_4647);
    DeRef(_x_4648);
    DeRef(_2392);
    _2392 = NOVALUE;
    DeRef(_2397);
    _2397 = NOVALUE;
    DeRef(_2400);
    _2400 = NOVALUE;
    return _2403;
    goto L2; // [103] 113
L6: 

    /** 		return 0*/
    DeRef(_y_4647);
    DeRef(_x_4648);
    DeRef(_2392);
    _2392 = NOVALUE;
    DeRef(_2397);
    _2397 = NOVALUE;
    DeRef(_2400);
    _2400 = NOVALUE;
    return 0;
L2: 
    ;
}
int atan2() __attribute__ ((alias ("_20atan2")));


int _20rad2deg(int _x_4672)
{
    int _2404 = NOVALUE;
    int _0, _1, _2;
    

    /**    return x * mathcons:RADIANS_TO_DEGREES*/
    _2404 = binary_op(MULTIPLY, _x_4672, _22RADIANS_TO_DEGREES_4345);
    DeRef(_x_4672);
    return _2404;
    ;
}
int rad2deg() __attribute__ ((alias ("_20rad2deg")));


int _20deg2rad(int _x_4676)
{
    int _2405 = NOVALUE;
    int _0, _1, _2;
    

    /**    return x * mathcons:DEGREES_TO_RADIANS*/
    _2405 = binary_op(MULTIPLY, _x_4676, _22DEGREES_TO_RADIANS_4343);
    DeRef(_x_4676);
    return _2405;
    ;
}
int deg2rad() __attribute__ ((alias ("_20deg2rad")));


int _20log10(int _x1_4680)
{
    int _2407 = NOVALUE;
    int _2406 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return log(x1) * mathcons:INVLN10*/
    if (IS_ATOM_INT(_x1_4680))
    _2406 = e_log(_x1_4680);
    else
    _2406 = unary_op(LOG, _x1_4680);
    _2407 = binary_op(MULTIPLY, _2406, _22INVLN10_4335);
    DeRef(_2406);
    _2406 = NOVALUE;
    DeRef(_x1_4680);
    return _2407;
    ;
}
int log10() __attribute__ ((alias ("_20log10")));


int _20exp(int _x_4685)
{
    int _2408 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return power( mathcons:E, x)*/
    if (IS_ATOM_INT(_x_4685)) {
        temp_d.dbl = (double)_x_4685;
        _2408 = Dpower(DBL_PTR(_22E_4327), &temp_d);
    }
    else
    _2408 = Dpower(DBL_PTR(_22E_4327), DBL_PTR(_x_4685));
    DeRef(_x_4685);
    return _2408;
    ;
}
int exp() __attribute__ ((alias ("_20exp")));


int _20fib(int _i_4689)
{
    int _2412 = NOVALUE;
    int _2411 = NOVALUE;
    int _2410 = NOVALUE;
    int _2409 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_4689)) {
        _1 = (long)(DBL_PTR(_i_4689)->dbl);
        DeRefDS(_i_4689);
        _i_4689 = _1;
    }

    /** 	return floor((power( mathcons:PHI, i) / mathcons:SQRT5) + 0.5)*/
    temp_d.dbl = (double)_i_4689;
    _2409 = Dpower(DBL_PTR(_22PHI_4325), &temp_d);
    _2410 = NewDouble(DBL_PTR(_2409)->dbl / DBL_PTR(_22SQRT5_4356)->dbl);
    DeRefDS(_2409);
    _2409 = NOVALUE;
    _2411 = NewDouble(DBL_PTR(_2410)->dbl + DBL_PTR(_2326)->dbl);
    DeRefDS(_2410);
    _2410 = NOVALUE;
    _2412 = unary_op(FLOOR, _2411);
    DeRefDS(_2411);
    _2411 = NOVALUE;
    return _2412;
    ;
}
int fib() __attribute__ ((alias ("_20fib")));


int _20cosh(int _a_4696)
{
    int _exp_inlined_exp_at_2_4698 = NOVALUE;
    int _exp_inlined_exp_at_15_4702 = NOVALUE;
    int _x_inlined_exp_at_12_4701 = NOVALUE;
    int _2415 = NOVALUE;
    int _2414 = NOVALUE;
    int _2413 = NOVALUE;
    int _0, _1, _2;
    

    /**     return (exp(a)+exp(-a))/2*/

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_2_4698);
    _exp_inlined_exp_at_2_4698 = binary_op(POWER, _22E_4327, _a_4696);
    if (IS_ATOM_INT(_a_4696)) {
        if ((unsigned long)_a_4696 == 0xC0000000)
        _2413 = (int)NewDouble((double)-0xC0000000);
        else
        _2413 = - _a_4696;
    }
    else {
        _2413 = unary_op(UMINUS, _a_4696);
    }
    DeRef(_x_inlined_exp_at_12_4701);
    _x_inlined_exp_at_12_4701 = _2413;
    _2413 = NOVALUE;

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_15_4702);
    _exp_inlined_exp_at_15_4702 = binary_op(POWER, _22E_4327, _x_inlined_exp_at_12_4701);
    DeRef(_x_inlined_exp_at_12_4701);
    _x_inlined_exp_at_12_4701 = NOVALUE;
    if (IS_ATOM_INT(_exp_inlined_exp_at_2_4698) && IS_ATOM_INT(_exp_inlined_exp_at_15_4702)) {
        _2414 = _exp_inlined_exp_at_2_4698 + _exp_inlined_exp_at_15_4702;
        if ((long)((unsigned long)_2414 + (unsigned long)HIGH_BITS) >= 0) 
        _2414 = NewDouble((double)_2414);
    }
    else {
        _2414 = binary_op(PLUS, _exp_inlined_exp_at_2_4698, _exp_inlined_exp_at_15_4702);
    }
    if (IS_ATOM_INT(_2414)) {
        if (_2414 & 1) {
            _2415 = NewDouble((_2414 >> 1) + 0.5);
        }
        else
        _2415 = _2414 >> 1;
    }
    else {
        _2415 = binary_op(DIVIDE, _2414, 2);
    }
    DeRef(_2414);
    _2414 = NOVALUE;
    DeRef(_a_4696);
    return _2415;
    ;
}
int cosh() __attribute__ ((alias ("_20cosh")));


int _20sinh(int _a_4707)
{
    int _exp_inlined_exp_at_2_4709 = NOVALUE;
    int _exp_inlined_exp_at_15_4713 = NOVALUE;
    int _x_inlined_exp_at_12_4712 = NOVALUE;
    int _2418 = NOVALUE;
    int _2417 = NOVALUE;
    int _2416 = NOVALUE;
    int _0, _1, _2;
    

    /**     return (exp(a)-exp(-a))/2*/

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_2_4709);
    _exp_inlined_exp_at_2_4709 = binary_op(POWER, _22E_4327, _a_4707);
    if (IS_ATOM_INT(_a_4707)) {
        if ((unsigned long)_a_4707 == 0xC0000000)
        _2416 = (int)NewDouble((double)-0xC0000000);
        else
        _2416 = - _a_4707;
    }
    else {
        _2416 = unary_op(UMINUS, _a_4707);
    }
    DeRef(_x_inlined_exp_at_12_4712);
    _x_inlined_exp_at_12_4712 = _2416;
    _2416 = NOVALUE;

    /** 	return power( mathcons:E, x)*/
    DeRef(_exp_inlined_exp_at_15_4713);
    _exp_inlined_exp_at_15_4713 = binary_op(POWER, _22E_4327, _x_inlined_exp_at_12_4712);
    DeRef(_x_inlined_exp_at_12_4712);
    _x_inlined_exp_at_12_4712 = NOVALUE;
    if (IS_ATOM_INT(_exp_inlined_exp_at_2_4709) && IS_ATOM_INT(_exp_inlined_exp_at_15_4713)) {
        _2417 = _exp_inlined_exp_at_2_4709 - _exp_inlined_exp_at_15_4713;
        if ((long)((unsigned long)_2417 +(unsigned long) HIGH_BITS) >= 0){
            _2417 = NewDouble((double)_2417);
        }
    }
    else {
        _2417 = binary_op(MINUS, _exp_inlined_exp_at_2_4709, _exp_inlined_exp_at_15_4713);
    }
    if (IS_ATOM_INT(_2417)) {
        if (_2417 & 1) {
            _2418 = NewDouble((_2417 >> 1) + 0.5);
        }
        else
        _2418 = _2417 >> 1;
    }
    else {
        _2418 = binary_op(DIVIDE, _2417, 2);
    }
    DeRef(_2417);
    _2417 = NOVALUE;
    DeRef(_a_4707);
    return _2418;
    ;
}
int sinh() __attribute__ ((alias ("_20sinh")));


int _20tanh(int _a_4718)
{
    int _2421 = NOVALUE;
    int _2420 = NOVALUE;
    int _2419 = NOVALUE;
    int _0, _1, _2;
    

    /**     return sinh(a)/cosh(a)*/
    Ref(_a_4718);
    _2419 = _20sinh(_a_4718);
    Ref(_a_4718);
    _2420 = _20cosh(_a_4718);
    if (IS_ATOM_INT(_2419) && IS_ATOM_INT(_2420)) {
        _2421 = (_2419 % _2420) ? NewDouble((double)_2419 / _2420) : (_2419 / _2420);
    }
    else {
        _2421 = binary_op(DIVIDE, _2419, _2420);
    }
    DeRef(_2419);
    _2419 = NOVALUE;
    DeRef(_2420);
    _2420 = NOVALUE;
    DeRef(_a_4718);
    return _2421;
    ;
}
int tanh() __attribute__ ((alias ("_20tanh")));


int _20arcsinh(int _a_4724)
{
    int _2426 = NOVALUE;
    int _2425 = NOVALUE;
    int _2424 = NOVALUE;
    int _2423 = NOVALUE;
    int _2422 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log(a+sqrt(1+a*a))*/
    if (IS_ATOM_INT(_a_4724) && IS_ATOM_INT(_a_4724)) {
        if (_a_4724 == (short)_a_4724 && _a_4724 <= INT15 && _a_4724 >= -INT15)
        _2422 = _a_4724 * _a_4724;
        else
        _2422 = NewDouble(_a_4724 * (double)_a_4724);
    }
    else {
        _2422 = binary_op(MULTIPLY, _a_4724, _a_4724);
    }
    if (IS_ATOM_INT(_2422)) {
        _2423 = _2422 + 1;
        if (_2423 > MAXINT){
            _2423 = NewDouble((double)_2423);
        }
    }
    else
    _2423 = binary_op(PLUS, 1, _2422);
    DeRef(_2422);
    _2422 = NOVALUE;
    if (IS_ATOM_INT(_2423))
    _2424 = e_sqrt(_2423);
    else
    _2424 = unary_op(SQRT, _2423);
    DeRef(_2423);
    _2423 = NOVALUE;
    if (IS_ATOM_INT(_a_4724) && IS_ATOM_INT(_2424)) {
        _2425 = _a_4724 + _2424;
        if ((long)((unsigned long)_2425 + (unsigned long)HIGH_BITS) >= 0) 
        _2425 = NewDouble((double)_2425);
    }
    else {
        _2425 = binary_op(PLUS, _a_4724, _2424);
    }
    DeRef(_2424);
    _2424 = NOVALUE;
    if (IS_ATOM_INT(_2425))
    _2426 = e_log(_2425);
    else
    _2426 = unary_op(LOG, _2425);
    DeRef(_2425);
    _2425 = NOVALUE;
    DeRef(_a_4724);
    return _2426;
    ;
}
int arcsinh() __attribute__ ((alias ("_20arcsinh")));


int _20arccosh(int _a_4745)
{
    int _2437 = NOVALUE;
    int _2436 = NOVALUE;
    int _2435 = NOVALUE;
    int _2434 = NOVALUE;
    int _2433 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log(a+sqrt(a*a-1))*/
    if (IS_ATOM_INT(_a_4745) && IS_ATOM_INT(_a_4745)) {
        if (_a_4745 == (short)_a_4745 && _a_4745 <= INT15 && _a_4745 >= -INT15)
        _2433 = _a_4745 * _a_4745;
        else
        _2433 = NewDouble(_a_4745 * (double)_a_4745);
    }
    else {
        _2433 = binary_op(MULTIPLY, _a_4745, _a_4745);
    }
    if (IS_ATOM_INT(_2433)) {
        _2434 = _2433 - 1;
        if ((long)((unsigned long)_2434 +(unsigned long) HIGH_BITS) >= 0){
            _2434 = NewDouble((double)_2434);
        }
    }
    else {
        _2434 = binary_op(MINUS, _2433, 1);
    }
    DeRef(_2433);
    _2433 = NOVALUE;
    if (IS_ATOM_INT(_2434))
    _2435 = e_sqrt(_2434);
    else
    _2435 = unary_op(SQRT, _2434);
    DeRef(_2434);
    _2434 = NOVALUE;
    if (IS_ATOM_INT(_a_4745) && IS_ATOM_INT(_2435)) {
        _2436 = _a_4745 + _2435;
        if ((long)((unsigned long)_2436 + (unsigned long)HIGH_BITS) >= 0) 
        _2436 = NewDouble((double)_2436);
    }
    else {
        _2436 = binary_op(PLUS, _a_4745, _2435);
    }
    DeRef(_2435);
    _2435 = NOVALUE;
    if (IS_ATOM_INT(_2436))
    _2437 = e_log(_2436);
    else
    _2437 = unary_op(LOG, _2436);
    DeRef(_2436);
    _2436 = NOVALUE;
    DeRef(_a_4745);
    return _2437;
    ;
}
int arccosh() __attribute__ ((alias ("_20arccosh")));


int _20arctanh(int _a_4769)
{
    int _2451 = NOVALUE;
    int _2450 = NOVALUE;
    int _2449 = NOVALUE;
    int _2448 = NOVALUE;
    int _2447 = NOVALUE;
    int _0, _1, _2;
    

    /**     return log((1+a)/(1-a))/2*/
    if (IS_ATOM_INT(_a_4769)) {
        _2447 = _a_4769 + 1;
        if (_2447 > MAXINT){
            _2447 = NewDouble((double)_2447);
        }
    }
    else
    _2447 = binary_op(PLUS, 1, _a_4769);
    if (IS_ATOM_INT(_a_4769)) {
        _2448 = 1 - _a_4769;
        if ((long)((unsigned long)_2448 +(unsigned long) HIGH_BITS) >= 0){
            _2448 = NewDouble((double)_2448);
        }
    }
    else {
        _2448 = binary_op(MINUS, 1, _a_4769);
    }
    if (IS_ATOM_INT(_2447) && IS_ATOM_INT(_2448)) {
        _2449 = (_2447 % _2448) ? NewDouble((double)_2447 / _2448) : (_2447 / _2448);
    }
    else {
        _2449 = binary_op(DIVIDE, _2447, _2448);
    }
    DeRef(_2447);
    _2447 = NOVALUE;
    DeRef(_2448);
    _2448 = NOVALUE;
    if (IS_ATOM_INT(_2449))
    _2450 = e_log(_2449);
    else
    _2450 = unary_op(LOG, _2449);
    DeRef(_2449);
    _2449 = NOVALUE;
    if (IS_ATOM_INT(_2450)) {
        if (_2450 & 1) {
            _2451 = NewDouble((_2450 >> 1) + 0.5);
        }
        else
        _2451 = _2450 >> 1;
    }
    else {
        _2451 = binary_op(DIVIDE, _2450, 2);
    }
    DeRef(_2450);
    _2450 = NOVALUE;
    DeRef(_a_4769);
    return _2451;
    ;
}
int arctanh() __attribute__ ((alias ("_20arctanh")));


int _20sum(int _a_4777)
{
    int _b_4778 = NOVALUE;
    int _2459 = NOVALUE;
    int _2458 = NOVALUE;
    int _2456 = NOVALUE;
    int _2455 = NOVALUE;
    int _2454 = NOVALUE;
    int _2453 = NOVALUE;
    int _2452 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2452 = IS_ATOM(_a_4777);
    if (_2452 == 0)
    {
        _2452 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2452 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4778);
    return _a_4777;
L1: 

    /** 	b = 0*/
    DeRef(_b_4778);
    _b_4778 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4777)){
            _2453 = SEQ_PTR(_a_4777)->length;
    }
    else {
        _2453 = 1;
    }
    {
        int _i_4782;
        _i_4782 = 1;
L2: 
        if (_i_4782 > _2453){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4777);
        _2454 = (int)*(((s1_ptr)_2)->base + _i_4782);
        _2455 = IS_ATOM(_2454);
        _2454 = NOVALUE;
        if (_2455 == 0)
        {
            _2455 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2455 = NOVALUE;
        }

        /** 			b += a[i]*/
        _2 = (int)SEQ_PTR(_a_4777);
        _2456 = (int)*(((s1_ptr)_2)->base + _i_4782);
        _0 = _b_4778;
        if (IS_ATOM_INT(_b_4778) && IS_ATOM_INT(_2456)) {
            _b_4778 = _b_4778 + _2456;
            if ((long)((unsigned long)_b_4778 + (unsigned long)HIGH_BITS) >= 0) 
            _b_4778 = NewDouble((double)_b_4778);
        }
        else {
            _b_4778 = binary_op(PLUS, _b_4778, _2456);
        }
        DeRef(_0);
        _2456 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b += sum(a[i])*/
        _2 = (int)SEQ_PTR(_a_4777);
        _2458 = (int)*(((s1_ptr)_2)->base + _i_4782);
        Ref(_2458);
        _2459 = _20sum(_2458);
        _2458 = NOVALUE;
        _0 = _b_4778;
        if (IS_ATOM_INT(_b_4778) && IS_ATOM_INT(_2459)) {
            _b_4778 = _b_4778 + _2459;
            if ((long)((unsigned long)_b_4778 + (unsigned long)HIGH_BITS) >= 0) 
            _b_4778 = NewDouble((double)_b_4778);
        }
        else {
            _b_4778 = binary_op(PLUS, _b_4778, _2459);
        }
        DeRef(_0);
        DeRef(_2459);
        _2459 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4782 = _i_4782 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4777);
    return _b_4778;
    ;
}


int _20product(int _a_4795)
{
    int _b_4796 = NOVALUE;
    int _2468 = NOVALUE;
    int _2467 = NOVALUE;
    int _2465 = NOVALUE;
    int _2464 = NOVALUE;
    int _2463 = NOVALUE;
    int _2462 = NOVALUE;
    int _2461 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2461 = IS_ATOM(_a_4795);
    if (_2461 == 0)
    {
        _2461 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2461 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4796);
    return _a_4795;
L1: 

    /** 	b = 1*/
    DeRef(_b_4796);
    _b_4796 = 1;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4795)){
            _2462 = SEQ_PTR(_a_4795)->length;
    }
    else {
        _2462 = 1;
    }
    {
        int _i_4800;
        _i_4800 = 1;
L2: 
        if (_i_4800 > _2462){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4795);
        _2463 = (int)*(((s1_ptr)_2)->base + _i_4800);
        _2464 = IS_ATOM(_2463);
        _2463 = NOVALUE;
        if (_2464 == 0)
        {
            _2464 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2464 = NOVALUE;
        }

        /** 			b *= a[i]*/
        _2 = (int)SEQ_PTR(_a_4795);
        _2465 = (int)*(((s1_ptr)_2)->base + _i_4800);
        _0 = _b_4796;
        if (IS_ATOM_INT(_b_4796) && IS_ATOM_INT(_2465)) {
            if (_b_4796 == (short)_b_4796 && _2465 <= INT15 && _2465 >= -INT15)
            _b_4796 = _b_4796 * _2465;
            else
            _b_4796 = NewDouble(_b_4796 * (double)_2465);
        }
        else {
            _b_4796 = binary_op(MULTIPLY, _b_4796, _2465);
        }
        DeRef(_0);
        _2465 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b *= product(a[i])*/
        _2 = (int)SEQ_PTR(_a_4795);
        _2467 = (int)*(((s1_ptr)_2)->base + _i_4800);
        Ref(_2467);
        _2468 = _20product(_2467);
        _2467 = NOVALUE;
        _0 = _b_4796;
        if (IS_ATOM_INT(_b_4796) && IS_ATOM_INT(_2468)) {
            if (_b_4796 == (short)_b_4796 && _2468 <= INT15 && _2468 >= -INT15)
            _b_4796 = _b_4796 * _2468;
            else
            _b_4796 = NewDouble(_b_4796 * (double)_2468);
        }
        else {
            _b_4796 = binary_op(MULTIPLY, _b_4796, _2468);
        }
        DeRef(_0);
        DeRef(_2468);
        _2468 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4800 = _i_4800 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4795);
    return _b_4796;
    ;
}
int product() __attribute__ ((alias ("_20product")));


int _20or_all(int _a_4813)
{
    int _b_4814 = NOVALUE;
    int _2477 = NOVALUE;
    int _2476 = NOVALUE;
    int _2474 = NOVALUE;
    int _2473 = NOVALUE;
    int _2472 = NOVALUE;
    int _2471 = NOVALUE;
    int _2470 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2470 = IS_ATOM(_a_4813);
    if (_2470 == 0)
    {
        _2470 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2470 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4814);
    return _a_4813;
L1: 

    /** 	b = 0*/
    DeRef(_b_4814);
    _b_4814 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4813)){
            _2471 = SEQ_PTR(_a_4813)->length;
    }
    else {
        _2471 = 1;
    }
    {
        int _i_4818;
        _i_4818 = 1;
L2: 
        if (_i_4818 > _2471){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_4813);
        _2472 = (int)*(((s1_ptr)_2)->base + _i_4818);
        _2473 = IS_ATOM(_2472);
        _2472 = NOVALUE;
        if (_2473 == 0)
        {
            _2473 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2473 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_4813);
        _2474 = (int)*(((s1_ptr)_2)->base + _i_4818);
        _0 = _b_4814;
        if (IS_ATOM_INT(_b_4814) && IS_ATOM_INT(_2474)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_4814 | (unsigned long)_2474;
                 _b_4814 = MAKE_UINT(tu);
            }
        }
        else {
            _b_4814 = binary_op(OR_BITS, _b_4814, _2474);
        }
        DeRef(_0);
        _2474 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_4813);
        _2476 = (int)*(((s1_ptr)_2)->base + _i_4818);
        Ref(_2476);
        _2477 = _20or_all(_2476);
        _2476 = NOVALUE;
        _0 = _b_4814;
        if (IS_ATOM_INT(_b_4814) && IS_ATOM_INT(_2477)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_4814 | (unsigned long)_2477;
                 _b_4814 = MAKE_UINT(tu);
            }
        }
        else {
            _b_4814 = binary_op(OR_BITS, _b_4814, _2477);
        }
        DeRef(_0);
        DeRef(_2477);
        _2477 = NOVALUE;
L5: 

        /** 	end for*/
        _i_4818 = _i_4818 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4813);
    return _b_4814;
    ;
}
int or_all() __attribute__ ((alias ("_20or_all")));


int _20shift_bits(int _source_number_4831, int _shift_distance_4832)
{
    int _lSigned_4850 = NOVALUE;
    int _2501 = NOVALUE;
    int _2499 = NOVALUE;
    int _2498 = NOVALUE;
    int _2497 = NOVALUE;
    int _2496 = NOVALUE;
    int _2494 = NOVALUE;
    int _2491 = NOVALUE;
    int _2488 = NOVALUE;
    int _2487 = NOVALUE;
    int _2483 = NOVALUE;
    int _2482 = NOVALUE;
    int _2481 = NOVALUE;
    int _2480 = NOVALUE;
    int _2479 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_distance_4832)) {
        _1 = (long)(DBL_PTR(_shift_distance_4832)->dbl);
        DeRefDS(_shift_distance_4832);
        _shift_distance_4832 = _1;
    }

    /** 	if sequence(source_number) then*/
    _2479 = IS_SEQUENCE(_source_number_4831);
    if (_2479 == 0)
    {
        _2479 = NOVALUE;
        goto L1; // [8] 55
    }
    else{
        _2479 = NOVALUE;
    }

    /** 		for i = 1 to length(source_number) do*/
    if (IS_SEQUENCE(_source_number_4831)){
            _2480 = SEQ_PTR(_source_number_4831)->length;
    }
    else {
        _2480 = 1;
    }
    {
        int _i_4836;
        _i_4836 = 1;
L2: 
        if (_i_4836 > _2480){
            goto L3; // [16] 48
        }

        /** 			source_number[i] = shift_bits(source_number[i], shift_distance)*/
        _2 = (int)SEQ_PTR(_source_number_4831);
        _2481 = (int)*(((s1_ptr)_2)->base + _i_4836);
        DeRef(_2482);
        _2482 = _shift_distance_4832;
        Ref(_2481);
        _2483 = _20shift_bits(_2481, _2482);
        _2481 = NOVALUE;
        _2482 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_number_4831);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_number_4831 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4836);
        _1 = *(int *)_2;
        *(int *)_2 = _2483;
        if( _1 != _2483 ){
            DeRef(_1);
        }
        _2483 = NOVALUE;

        /** 		end for*/
        _i_4836 = _i_4836 + 1;
        goto L2; // [43] 23
L3: 
        ;
    }

    /** 		return source_number*/
    return _source_number_4831;
L1: 

    /** 	source_number = and_bits(source_number, 0xFFFFFFFF)*/
    _0 = _source_number_4831;
    _source_number_4831 = binary_op(AND_BITS, _source_number_4831, _2185);
    DeRef(_0);

    /** 	if shift_distance = 0 then*/
    if (_shift_distance_4832 != 0)
    goto L4; // [63] 74

    /** 		return source_number*/
    return _source_number_4831;
L4: 

    /** 	if shift_distance < 0 then*/
    if (_shift_distance_4832 >= 0)
    goto L5; // [76] 96

    /** 		source_number *= power(2, -shift_distance)*/
    if ((unsigned long)_shift_distance_4832 == 0xC0000000)
    _2487 = (int)NewDouble((double)-0xC0000000);
    else
    _2487 = - _shift_distance_4832;
    if (IS_ATOM_INT(_2487)) {
        _2488 = power(2, _2487);
    }
    else {
        temp_d.dbl = (double)2;
        _2488 = Dpower(&temp_d, DBL_PTR(_2487));
    }
    DeRef(_2487);
    _2487 = NOVALUE;
    _0 = _source_number_4831;
    if (IS_ATOM_INT(_source_number_4831) && IS_ATOM_INT(_2488)) {
        if (_source_number_4831 == (short)_source_number_4831 && _2488 <= INT15 && _2488 >= -INT15)
        _source_number_4831 = _source_number_4831 * _2488;
        else
        _source_number_4831 = NewDouble(_source_number_4831 * (double)_2488);
    }
    else {
        _source_number_4831 = binary_op(MULTIPLY, _source_number_4831, _2488);
    }
    DeRef(_0);
    DeRef(_2488);
    _2488 = NOVALUE;
    goto L6; // [93] 164
L5: 

    /** 		integer lSigned = 0*/
    _lSigned_4850 = 0;

    /** 		if and_bits(source_number, 0x80000000) then*/
    _2491 = binary_op(AND_BITS, _source_number_4831, _2490);
    if (_2491 == 0) {
        DeRef(_2491);
        _2491 = NOVALUE;
        goto L7; // [107] 122
    }
    else {
        if (!IS_ATOM_INT(_2491) && DBL_PTR(_2491)->dbl == 0.0){
            DeRef(_2491);
            _2491 = NOVALUE;
            goto L7; // [107] 122
        }
        DeRef(_2491);
        _2491 = NOVALUE;
    }
    DeRef(_2491);
    _2491 = NOVALUE;

    /** 			lSigned = 1*/
    _lSigned_4850 = 1;

    /** 			source_number = and_bits(source_number, 0x7FFFFFFF)*/
    _0 = _source_number_4831;
    _source_number_4831 = binary_op(AND_BITS, _source_number_4831, _2492);
    DeRef(_0);
L7: 

    /** 		source_number /= power(2, shift_distance)*/
    _2494 = power(2, _shift_distance_4832);
    _0 = _source_number_4831;
    if (IS_ATOM_INT(_source_number_4831) && IS_ATOM_INT(_2494)) {
        _source_number_4831 = (_source_number_4831 % _2494) ? NewDouble((double)_source_number_4831 / _2494) : (_source_number_4831 / _2494);
    }
    else {
        _source_number_4831 = binary_op(DIVIDE, _source_number_4831, _2494);
    }
    DeRef(_0);
    DeRef(_2494);
    _2494 = NOVALUE;

    /** 		if lSigned and shift_distance < 32 then*/
    if (_lSigned_4850 == 0) {
        goto L8; // [134] 161
    }
    _2497 = (_shift_distance_4832 < 32);
    if (_2497 == 0)
    {
        DeRef(_2497);
        _2497 = NOVALUE;
        goto L8; // [143] 161
    }
    else{
        DeRef(_2497);
        _2497 = NOVALUE;
    }

    /** 			source_number = or_bits(source_number, power(2, 31-shift_distance))*/
    _2498 = 31 - _shift_distance_4832;
    if ((long)((unsigned long)_2498 +(unsigned long) HIGH_BITS) >= 0){
        _2498 = NewDouble((double)_2498);
    }
    if (IS_ATOM_INT(_2498)) {
        _2499 = power(2, _2498);
    }
    else {
        temp_d.dbl = (double)2;
        _2499 = Dpower(&temp_d, DBL_PTR(_2498));
    }
    DeRef(_2498);
    _2498 = NOVALUE;
    _0 = _source_number_4831;
    if (IS_ATOM_INT(_source_number_4831) && IS_ATOM_INT(_2499)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4831 | (unsigned long)_2499;
             _source_number_4831 = MAKE_UINT(tu);
        }
    }
    else {
        _source_number_4831 = binary_op(OR_BITS, _source_number_4831, _2499);
    }
    DeRef(_0);
    DeRef(_2499);
    _2499 = NOVALUE;
L8: 
L6: 

    /** 	return and_bits(source_number, 0xFFFFFFFF)*/
    _2501 = binary_op(AND_BITS, _source_number_4831, _2185);
    DeRef(_source_number_4831);
    return _2501;
    ;
}
int shift_bits() __attribute__ ((alias ("_20shift_bits")));


int _20rotate_bits(int _source_number_4867, int _shift_distance_4868)
{
    int _lTemp_4869 = NOVALUE;
    int _lSave_4870 = NOVALUE;
    int _lRest_4871 = NOVALUE;
    int _2521 = NOVALUE;
    int _2518 = NOVALUE;
    int _2515 = NOVALUE;
    int _2512 = NOVALUE;
    int _2511 = NOVALUE;
    int _2510 = NOVALUE;
    int _2506 = NOVALUE;
    int _2505 = NOVALUE;
    int _2504 = NOVALUE;
    int _2503 = NOVALUE;
    int _2502 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_distance_4868)) {
        _1 = (long)(DBL_PTR(_shift_distance_4868)->dbl);
        DeRefDS(_shift_distance_4868);
        _shift_distance_4868 = _1;
    }

    /** 	if sequence(source_number) then*/
    _2502 = IS_SEQUENCE(_source_number_4867);
    if (_2502 == 0)
    {
        _2502 = NOVALUE;
        goto L1; // [8] 55
    }
    else{
        _2502 = NOVALUE;
    }

    /** 		for i = 1 to length(source_number) do*/
    if (IS_SEQUENCE(_source_number_4867)){
            _2503 = SEQ_PTR(_source_number_4867)->length;
    }
    else {
        _2503 = 1;
    }
    {
        int _i_4875;
        _i_4875 = 1;
L2: 
        if (_i_4875 > _2503){
            goto L3; // [16] 48
        }

        /** 			source_number[i] = rotate_bits(source_number[i], shift_distance)*/
        _2 = (int)SEQ_PTR(_source_number_4867);
        _2504 = (int)*(((s1_ptr)_2)->base + _i_4875);
        DeRef(_2505);
        _2505 = _shift_distance_4868;
        Ref(_2504);
        _2506 = _20rotate_bits(_2504, _2505);
        _2504 = NOVALUE;
        _2505 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_number_4867);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_number_4867 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4875);
        _1 = *(int *)_2;
        *(int *)_2 = _2506;
        if( _1 != _2506 ){
            DeRef(_1);
        }
        _2506 = NOVALUE;

        /** 		end for*/
        _i_4875 = _i_4875 + 1;
        goto L2; // [43] 23
L3: 
        ;
    }

    /** 		return source_number*/
    DeRef(_lTemp_4869);
    DeRef(_lSave_4870);
    return _source_number_4867;
L1: 

    /** 	source_number = and_bits(source_number, 0xFFFFFFFF)*/
    _0 = _source_number_4867;
    _source_number_4867 = binary_op(AND_BITS, _source_number_4867, _2185);
    DeRef(_0);

    /** 	if shift_distance = 0 then*/
    if (_shift_distance_4868 != 0)
    goto L4; // [63] 74

    /** 		return source_number*/
    DeRef(_lTemp_4869);
    DeRef(_lSave_4870);
    return _source_number_4867;
L4: 

    /** 	if shift_distance < 0 then*/
    if (_shift_distance_4868 >= 0)
    goto L5; // [76] 106

    /** 		lSave = not_bits(power(2, 32 + shift_distance) - 1) 	*/
    _2510 = 32 + _shift_distance_4868;
    if ((long)((unsigned long)_2510 + (unsigned long)HIGH_BITS) >= 0) 
    _2510 = NewDouble((double)_2510);
    if (IS_ATOM_INT(_2510)) {
        _2511 = power(2, _2510);
    }
    else {
        temp_d.dbl = (double)2;
        _2511 = Dpower(&temp_d, DBL_PTR(_2510));
    }
    DeRef(_2510);
    _2510 = NOVALUE;
    if (IS_ATOM_INT(_2511)) {
        _2512 = _2511 - 1;
        if ((long)((unsigned long)_2512 +(unsigned long) HIGH_BITS) >= 0){
            _2512 = NewDouble((double)_2512);
        }
    }
    else {
        _2512 = NewDouble(DBL_PTR(_2511)->dbl - (double)1);
    }
    DeRef(_2511);
    _2511 = NOVALUE;
    DeRef(_lSave_4870);
    if (IS_ATOM_INT(_2512))
    _lSave_4870 = not_bits(_2512);
    else
    _lSave_4870 = unary_op(NOT_BITS, _2512);
    DeRef(_2512);
    _2512 = NOVALUE;

    /** 		lRest = 32 + shift_distance*/
    _lRest_4871 = 32 + _shift_distance_4868;
    goto L6; // [103] 123
L5: 

    /** 		lSave = power(2, shift_distance) - 1*/
    _2515 = power(2, _shift_distance_4868);
    DeRef(_lSave_4870);
    if (IS_ATOM_INT(_2515)) {
        _lSave_4870 = _2515 - 1;
        if ((long)((unsigned long)_lSave_4870 +(unsigned long) HIGH_BITS) >= 0){
            _lSave_4870 = NewDouble((double)_lSave_4870);
        }
    }
    else {
        _lSave_4870 = NewDouble(DBL_PTR(_2515)->dbl - (double)1);
    }
    DeRef(_2515);
    _2515 = NOVALUE;

    /** 		lRest = shift_distance - 32*/
    _lRest_4871 = _shift_distance_4868 - 32;
L6: 

    /** 	lTemp = shift_bits(and_bits(source_number, lSave), lRest)*/
    if (IS_ATOM_INT(_source_number_4867) && IS_ATOM_INT(_lSave_4870)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4867 & (unsigned long)_lSave_4870;
             _2518 = MAKE_UINT(tu);
        }
    }
    else {
        _2518 = binary_op(AND_BITS, _source_number_4867, _lSave_4870);
    }
    _0 = _lTemp_4869;
    _lTemp_4869 = _20shift_bits(_2518, _lRest_4871);
    DeRef(_0);
    _2518 = NOVALUE;

    /** 	source_number = shift_bits(source_number, shift_distance)*/
    Ref(_source_number_4867);
    _0 = _source_number_4867;
    _source_number_4867 = _20shift_bits(_source_number_4867, _shift_distance_4868);
    DeRef(_0);

    /** 	return or_bits(source_number, lTemp)*/
    if (IS_ATOM_INT(_source_number_4867) && IS_ATOM_INT(_lTemp_4869)) {
        {unsigned long tu;
             tu = (unsigned long)_source_number_4867 | (unsigned long)_lTemp_4869;
             _2521 = MAKE_UINT(tu);
        }
    }
    else {
        _2521 = binary_op(OR_BITS, _source_number_4867, _lTemp_4869);
    }
    DeRef(_source_number_4867);
    DeRef(_lTemp_4869);
    DeRef(_lSave_4870);
    return _2521;
    ;
}
int rotate_bits() __attribute__ ((alias ("_20rotate_bits")));


int _20gcd(int _p_4900, int _q_4901)
{
    int _r_4902 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if p < 0 then*/
    if (binary_op_a(GREATEREQ, _p_4900, 0)){
        goto L1; // [3] 13
    }

    /** 		p = -p*/
    _0 = _p_4900;
    if (IS_ATOM_INT(_p_4900)) {
        if ((unsigned long)_p_4900 == 0xC0000000)
        _p_4900 = (int)NewDouble((double)-0xC0000000);
        else
        _p_4900 = - _p_4900;
    }
    else {
        _p_4900 = unary_op(UMINUS, _p_4900);
    }
    DeRef(_0);
L1: 

    /** 	if q < 0 then*/
    if (binary_op_a(GREATEREQ, _q_4901, 0)){
        goto L2; // [15] 25
    }

    /** 		q = -q*/
    _0 = _q_4901;
    if (IS_ATOM_INT(_q_4901)) {
        if ((unsigned long)_q_4901 == 0xC0000000)
        _q_4901 = (int)NewDouble((double)-0xC0000000);
        else
        _q_4901 = - _q_4901;
    }
    else {
        _q_4901 = unary_op(UMINUS, _q_4901);
    }
    DeRef(_0);
L2: 

    /** 	p = floor(p)*/
    _0 = _p_4900;
    if (IS_ATOM_INT(_p_4900))
    _p_4900 = e_floor(_p_4900);
    else
    _p_4900 = unary_op(FLOOR, _p_4900);
    DeRef(_0);

    /** 	q = floor(q)*/
    _0 = _q_4901;
    if (IS_ATOM_INT(_q_4901))
    _q_4901 = e_floor(_q_4901);
    else
    _q_4901 = unary_op(FLOOR, _q_4901);
    DeRef(_0);

    /** 	if p < q then*/
    if (binary_op_a(GREATEREQ, _p_4900, _q_4901)){
        goto L3; // [37] 57
    }

    /** 		r = p*/
    Ref(_p_4900);
    DeRef(_r_4902);
    _r_4902 = _p_4900;

    /** 		p = q*/
    Ref(_q_4901);
    DeRef(_p_4900);
    _p_4900 = _q_4901;

    /** 		q = r*/
    Ref(_r_4902);
    DeRef(_q_4901);
    _q_4901 = _r_4902;
L3: 

    /** 	if q = 0 then*/
    if (binary_op_a(NOTEQ, _q_4901, 0)){
        goto L4; // [59] 94
    }

    /** 		return p*/
    DeRef(_q_4901);
    DeRef(_r_4902);
    return _p_4900;

    /**     while r > 1 with entry do*/
    goto L4; // [72] 94
L5: 
    if (binary_op_a(LESSEQ, _r_4902, 1)){
        goto L6; // [77] 105
    }

    /** 		p = q*/
    Ref(_q_4901);
    DeRef(_p_4900);
    _p_4900 = _q_4901;

    /** 		q = r*/
    Ref(_r_4902);
    DeRef(_q_4901);
    _q_4901 = _r_4902;

    /** 	entry*/
L4: 

    /** 		r = remainder(p, q)*/
    DeRef(_r_4902);
    if (IS_ATOM_INT(_p_4900) && IS_ATOM_INT(_q_4901)) {
        _r_4902 = (_p_4900 % _q_4901);
    }
    else {
        if (IS_ATOM_INT(_p_4900)) {
            temp_d.dbl = (double)_p_4900;
            _r_4902 = Dremainder(&temp_d, DBL_PTR(_q_4901));
        }
        else {
            if (IS_ATOM_INT(_q_4901)) {
                temp_d.dbl = (double)_q_4901;
                _r_4902 = Dremainder(DBL_PTR(_p_4900), &temp_d);
            }
            else
            _r_4902 = Dremainder(DBL_PTR(_p_4900), DBL_PTR(_q_4901));
        }
    }

    /**     end while*/
    goto L5; // [102] 75
L6: 

    /** 	if r = 1 then*/
    if (binary_op_a(NOTEQ, _r_4902, 1)){
        goto L7; // [109] 122
    }

    /** 		return 1*/
    DeRef(_p_4900);
    DeRef(_q_4901);
    DeRef(_r_4902);
    return 1;
    goto L8; // [119] 129
L7: 

    /** 		return q*/
    DeRef(_p_4900);
    DeRef(_r_4902);
    return _q_4901;
L8: 
    ;
}
int gcd() __attribute__ ((alias ("_20gcd")));


int _20approx(int _p_4923, int _q_4924, int _epsilon_4925)
{
    int _msg_inlined_crash_at_30_4937 = NOVALUE;
    int _2555 = NOVALUE;
    int _2553 = NOVALUE;
    int _2552 = NOVALUE;
    int _2551 = NOVALUE;
    int _2550 = NOVALUE;
    int _2549 = NOVALUE;
    int _2548 = NOVALUE;
    int _2547 = NOVALUE;
    int _2546 = NOVALUE;
    int _2545 = NOVALUE;
    int _2544 = NOVALUE;
    int _2543 = NOVALUE;
    int _2542 = NOVALUE;
    int _2541 = NOVALUE;
    int _2540 = NOVALUE;
    int _2537 = NOVALUE;
    int _2536 = NOVALUE;
    int _2535 = NOVALUE;
    int _2534 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(p) then*/
    _2534 = IS_SEQUENCE(_p_4923);
    if (_2534 == 0)
    {
        _2534 = NOVALUE;
        goto L1; // [6] 146
    }
    else{
        _2534 = NOVALUE;
    }

    /** 		if sequence(q) then*/
    _2535 = IS_SEQUENCE(_q_4924);
    if (_2535 == 0)
    {
        _2535 = NOVALUE;
        goto L2; // [14] 98
    }
    else{
        _2535 = NOVALUE;
    }

    /** 			if length(p) != length(q) then*/
    if (IS_SEQUENCE(_p_4923)){
            _2536 = SEQ_PTR(_p_4923)->length;
    }
    else {
        _2536 = 1;
    }
    if (IS_SEQUENCE(_q_4924)){
            _2537 = SEQ_PTR(_q_4924)->length;
    }
    else {
        _2537 = 1;
    }
    if (_2536 == _2537)
    goto L3; // [25] 50

    /** 				error:crash("approx(): Sequence arguments must be the same length")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_30_4937);
    _msg_inlined_crash_at_30_4937 = EPrintf(-9999999, _2539, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_30_4937);

    /** end procedure*/
    goto L4; // [44] 47
L4: 
    DeRefi(_msg_inlined_crash_at_30_4937);
    _msg_inlined_crash_at_30_4937 = NOVALUE;
L3: 

    /** 			for i = 1 to length(p) do*/
    if (IS_SEQUENCE(_p_4923)){
            _2540 = SEQ_PTR(_p_4923)->length;
    }
    else {
        _2540 = 1;
    }
    {
        int _i_4939;
        _i_4939 = 1;
L5: 
        if (_i_4939 > _2540){
            goto L6; // [55] 89
        }

        /** 				p[i] = approx(p[i], q[i])*/
        _2 = (int)SEQ_PTR(_p_4923);
        _2541 = (int)*(((s1_ptr)_2)->base + _i_4939);
        _2 = (int)SEQ_PTR(_q_4924);
        _2542 = (int)*(((s1_ptr)_2)->base + _i_4939);
        Ref(_2541);
        Ref(_2542);
        RefDS(_2533);
        _2543 = _20approx(_2541, _2542, _2533);
        _2541 = NOVALUE;
        _2542 = NOVALUE;
        _2 = (int)SEQ_PTR(_p_4923);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _p_4923 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4939);
        _1 = *(int *)_2;
        *(int *)_2 = _2543;
        if( _1 != _2543 ){
            DeRef(_1);
        }
        _2543 = NOVALUE;

        /** 			end for*/
        _i_4939 = _i_4939 + 1;
        goto L5; // [84] 62
L6: 
        ;
    }

    /** 			return p*/
    DeRef(_q_4924);
    DeRef(_epsilon_4925);
    return _p_4923;
    goto L7; // [95] 242
L2: 

    /** 			for i = 1 to length(p) do*/
    if (IS_SEQUENCE(_p_4923)){
            _2544 = SEQ_PTR(_p_4923)->length;
    }
    else {
        _2544 = 1;
    }
    {
        int _i_4946;
        _i_4946 = 1;
L8: 
        if (_i_4946 > _2544){
            goto L9; // [103] 136
        }

        /** 				p[i] = approx(p[i], q)*/
        _2 = (int)SEQ_PTR(_p_4923);
        _2545 = (int)*(((s1_ptr)_2)->base + _i_4946);
        Ref(_q_4924);
        DeRef(_2546);
        _2546 = _q_4924;
        Ref(_2545);
        RefDS(_2533);
        _2547 = _20approx(_2545, _2546, _2533);
        _2545 = NOVALUE;
        _2546 = NOVALUE;
        _2 = (int)SEQ_PTR(_p_4923);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _p_4923 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4946);
        _1 = *(int *)_2;
        *(int *)_2 = _2547;
        if( _1 != _2547 ){
            DeRef(_1);
        }
        _2547 = NOVALUE;

        /** 			end for*/
        _i_4946 = _i_4946 + 1;
        goto L8; // [131] 110
L9: 
        ;
    }

    /** 			return p*/
    DeRef(_q_4924);
    DeRef(_epsilon_4925);
    return _p_4923;
    goto L7; // [143] 242
L1: 

    /** 	elsif sequence(q) then*/
    _2548 = IS_SEQUENCE(_q_4924);
    if (_2548 == 0)
    {
        _2548 = NOVALUE;
        goto LA; // [151] 201
    }
    else{
        _2548 = NOVALUE;
    }

    /** 			for i = 1 to length(q) do*/
    if (IS_SEQUENCE(_q_4924)){
            _2549 = SEQ_PTR(_q_4924)->length;
    }
    else {
        _2549 = 1;
    }
    {
        int _i_4954;
        _i_4954 = 1;
LB: 
        if (_i_4954 > _2549){
            goto LC; // [159] 192
        }

        /** 				q[i] = approx(p, q[i])*/
        _2 = (int)SEQ_PTR(_q_4924);
        _2550 = (int)*(((s1_ptr)_2)->base + _i_4954);
        Ref(_p_4923);
        DeRef(_2551);
        _2551 = _p_4923;
        Ref(_2550);
        RefDS(_2533);
        _2552 = _20approx(_2551, _2550, _2533);
        _2551 = NOVALUE;
        _2550 = NOVALUE;
        _2 = (int)SEQ_PTR(_q_4924);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _q_4924 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4954);
        _1 = *(int *)_2;
        *(int *)_2 = _2552;
        if( _1 != _2552 ){
            DeRef(_1);
        }
        _2552 = NOVALUE;

        /** 			end for*/
        _i_4954 = _i_4954 + 1;
        goto LB; // [187] 166
LC: 
        ;
    }

    /** 			return q*/
    DeRef(_p_4923);
    DeRef(_epsilon_4925);
    return _q_4924;
    goto L7; // [198] 242
LA: 

    /** 		if p > (q + epsilon) then*/
    if (IS_ATOM_INT(_q_4924) && IS_ATOM_INT(_epsilon_4925)) {
        _2553 = _q_4924 + _epsilon_4925;
        if ((long)((unsigned long)_2553 + (unsigned long)HIGH_BITS) >= 0) 
        _2553 = NewDouble((double)_2553);
    }
    else {
        _2553 = binary_op(PLUS, _q_4924, _epsilon_4925);
    }
    if (binary_op_a(LESSEQ, _p_4923, _2553)){
        DeRef(_2553);
        _2553 = NOVALUE;
        goto LD; // [207] 218
    }
    DeRef(_2553);
    _2553 = NOVALUE;

    /** 			return 1*/
    DeRef(_p_4923);
    DeRef(_q_4924);
    DeRef(_epsilon_4925);
    return 1;
LD: 

    /** 		if p < (q - epsilon) then*/
    if (IS_ATOM_INT(_q_4924) && IS_ATOM_INT(_epsilon_4925)) {
        _2555 = _q_4924 - _epsilon_4925;
        if ((long)((unsigned long)_2555 +(unsigned long) HIGH_BITS) >= 0){
            _2555 = NewDouble((double)_2555);
        }
    }
    else {
        _2555 = binary_op(MINUS, _q_4924, _epsilon_4925);
    }
    if (binary_op_a(GREATEREQ, _p_4923, _2555)){
        DeRef(_2555);
        _2555 = NOVALUE;
        goto LE; // [224] 235
    }
    DeRef(_2555);
    _2555 = NOVALUE;

    /** 			return -1*/
    DeRef(_p_4923);
    DeRef(_q_4924);
    DeRef(_epsilon_4925);
    return -1;
LE: 

    /** 		return 0*/
    DeRef(_p_4923);
    DeRef(_q_4924);
    DeRef(_epsilon_4925);
    return 0;
L7: 
    ;
}
int approx() __attribute__ ((alias ("_20approx")));


int _20powof2(int _p_4968)
{
    int _2559 = NOVALUE;
    int _2558 = NOVALUE;
    int _2557 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return not (and_bits(p, p-1))*/
    if (IS_ATOM_INT(_p_4968)) {
        _2557 = _p_4968 - 1;
        if ((long)((unsigned long)_2557 +(unsigned long) HIGH_BITS) >= 0){
            _2557 = NewDouble((double)_2557);
        }
    }
    else {
        _2557 = binary_op(MINUS, _p_4968, 1);
    }
    if (IS_ATOM_INT(_p_4968) && IS_ATOM_INT(_2557)) {
        {unsigned long tu;
             tu = (unsigned long)_p_4968 & (unsigned long)_2557;
             _2558 = MAKE_UINT(tu);
        }
    }
    else {
        _2558 = binary_op(AND_BITS, _p_4968, _2557);
    }
    DeRef(_2557);
    _2557 = NOVALUE;
    if (IS_ATOM_INT(_2558)) {
        _2559 = (_2558 == 0);
    }
    else {
        _2559 = unary_op(NOT, _2558);
    }
    DeRef(_2558);
    _2558 = NOVALUE;
    DeRef(_p_4968);
    return _2559;
    ;
}
int powof2() __attribute__ ((alias ("_20powof2")));


int _20is_even(int _test_integer_4974)
{
    int _2561 = NOVALUE;
    int _2560 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_test_integer_4974)) {
        _1 = (long)(DBL_PTR(_test_integer_4974)->dbl);
        DeRefDS(_test_integer_4974);
        _test_integer_4974 = _1;
    }

    /** 	return (and_bits(test_integer, 1) = 0)*/
    {unsigned long tu;
         tu = (unsigned long)_test_integer_4974 & (unsigned long)1;
         _2560 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_2560)) {
        _2561 = (_2560 == 0);
    }
    else {
        _2561 = (DBL_PTR(_2560)->dbl == (double)0);
    }
    DeRef(_2560);
    _2560 = NOVALUE;
    return _2561;
    ;
}
int is_even() __attribute__ ((alias ("_20is_even")));


int _20is_even_obj(int _test_object_4979)
{
    int _2568 = NOVALUE;
    int _2567 = NOVALUE;
    int _2566 = NOVALUE;
    int _2565 = NOVALUE;
    int _2564 = NOVALUE;
    int _2563 = NOVALUE;
    int _2562 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(test_object) then*/
    _2562 = IS_ATOM(_test_object_4979);
    if (_2562 == 0)
    {
        _2562 = NOVALUE;
        goto L1; // [6] 39
    }
    else{
        _2562 = NOVALUE;
    }

    /** 		if integer(test_object) then*/
    if (IS_ATOM_INT(_test_object_4979))
    _2563 = 1;
    else if (IS_ATOM_DBL(_test_object_4979))
    _2563 = IS_ATOM_INT(DoubleToInt(_test_object_4979));
    else
    _2563 = 0;
    if (_2563 == 0)
    {
        _2563 = NOVALUE;
        goto L2; // [14] 32
    }
    else{
        _2563 = NOVALUE;
    }

    /** 			return (and_bits(test_object, 1) = 0)*/
    if (IS_ATOM_INT(_test_object_4979)) {
        {unsigned long tu;
             tu = (unsigned long)_test_object_4979 & (unsigned long)1;
             _2564 = MAKE_UINT(tu);
        }
    }
    else {
        _2564 = binary_op(AND_BITS, _test_object_4979, 1);
    }
    if (IS_ATOM_INT(_2564)) {
        _2565 = (_2564 == 0);
    }
    else {
        _2565 = binary_op(EQUALS, _2564, 0);
    }
    DeRef(_2564);
    _2564 = NOVALUE;
    DeRef(_test_object_4979);
    return _2565;
L2: 

    /** 		return 0*/
    DeRef(_test_object_4979);
    DeRef(_2565);
    _2565 = NOVALUE;
    return 0;
L1: 

    /** 	for i = 1 to length(test_object) do*/
    if (IS_SEQUENCE(_test_object_4979)){
            _2566 = SEQ_PTR(_test_object_4979)->length;
    }
    else {
        _2566 = 1;
    }
    {
        int _i_4987;
        _i_4987 = 1;
L3: 
        if (_i_4987 > _2566){
            goto L4; // [44] 72
        }

        /** 		test_object[i] = is_even_obj(test_object[i])*/
        _2 = (int)SEQ_PTR(_test_object_4979);
        _2567 = (int)*(((s1_ptr)_2)->base + _i_4987);
        Ref(_2567);
        _2568 = _20is_even_obj(_2567);
        _2567 = NOVALUE;
        _2 = (int)SEQ_PTR(_test_object_4979);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _test_object_4979 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4987);
        _1 = *(int *)_2;
        *(int *)_2 = _2568;
        if( _1 != _2568 ){
            DeRef(_1);
        }
        _2568 = NOVALUE;

        /** 	end for*/
        _i_4987 = _i_4987 + 1;
        goto L3; // [67] 51
L4: 
        ;
    }

    /** 	return test_object*/
    DeRef(_2565);
    _2565 = NOVALUE;
    return _test_object_4979;
    ;
}
int is_even_obj() __attribute__ ((alias ("_20is_even_obj")));



// 0xD9ACBE65
