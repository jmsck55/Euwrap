// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _43set_lang_path(int _pp_20098)
{
    int _0, _1, _2;
    

    /** 	lang_path = pp*/
    Ref(_pp_20098);
    DeRef(_43lang_path_20095);
    _43lang_path_20095 = _pp_20098;

    /** end procedure*/
    DeRef(_pp_20098);
    return;
    ;
}
void set_lang_path() __attribute__ ((alias ("_43set_lang_path")));


int _43get_lang_path()
{
    int _0, _1, _2;
    

    /** 	return lang_path*/
    Ref(_43lang_path_20095);
    return _43lang_path_20095;
    ;
}
int get_lang_path() __attribute__ ((alias ("_43get_lang_path")));


int _43lang_load(int _filename_20103)
{
    int _lines_20104 = NOVALUE;
    int _line_20105 = NOVALUE;
    int _key_20106 = NOVALUE;
    int _msg_20107 = NOVALUE;
    int _delim_20108 = NOVALUE;
    int _cont_20109 = NOVALUE;
    int _keylang_20110 = NOVALUE;
    int _altlang_20111 = NOVALUE;
    int _tempname_20121 = NOVALUE;
    int _11434 = NOVALUE;
    int _11432 = NOVALUE;
    int _11431 = NOVALUE;
    int _11430 = NOVALUE;
    int _11427 = NOVALUE;
    int _11425 = NOVALUE;
    int _11424 = NOVALUE;
    int _11423 = NOVALUE;
    int _11422 = NOVALUE;
    int _11420 = NOVALUE;
    int _11419 = NOVALUE;
    int _11417 = NOVALUE;
    int _11416 = NOVALUE;
    int _11410 = NOVALUE;
    int _11408 = NOVALUE;
    int _11406 = NOVALUE;
    int _11403 = NOVALUE;
    int _11402 = NOVALUE;
    int _11401 = NOVALUE;
    int _11400 = NOVALUE;
    int _11398 = NOVALUE;
    int _11397 = NOVALUE;
    int _11395 = NOVALUE;
    int _11394 = NOVALUE;
    int _11393 = NOVALUE;
    int _11389 = NOVALUE;
    int _11387 = NOVALUE;
    int _11386 = NOVALUE;
    int _11385 = NOVALUE;
    int _11384 = NOVALUE;
    int _11383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	keylang = map:new()*/
    _0 = _keylang_20110;
    _keylang_20110 = _33new(690);
    DeRef(_0);

    /** 	altlang = map:new()*/
    _0 = _altlang_20111;
    _altlang_20111 = _33new(690);
    DeRef(_0);

    /** 	cont = 0*/
    _cont_20109 = 0;

    /** 	filename = filesys:defaultext(filename, "lng")*/
    RefDS(_filename_20103);
    RefDS(_11381);
    _0 = _filename_20103;
    _filename_20103 = _11defaultext(_filename_20103, _11381);
    DeRefDS(_0);

    /** 	if sequence(lang_path) and length(lang_path) > 0 then*/
    _11383 = IS_SEQUENCE(_43lang_path_20095);
    if (_11383 == 0) {
        goto L1; // [36] 106
    }
    if (IS_SEQUENCE(_43lang_path_20095)){
            _11385 = SEQ_PTR(_43lang_path_20095)->length;
    }
    else {
        _11385 = 1;
    }
    _11386 = (_11385 > 0);
    _11385 = NOVALUE;
    if (_11386 == 0)
    {
        DeRef(_11386);
        _11386 = NOVALUE;
        goto L1; // [50] 106
    }
    else{
        DeRef(_11386);
        _11386 = NOVALUE;
    }

    /** 		sequence tempname */

    /** 		tempname = filesys:locate_file(filename, {lang_path})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_43lang_path_20095);
    *((int *)(_2+4)) = _43lang_path_20095;
    _11387 = MAKE_SEQ(_1);
    RefDS(_filename_20103);
    RefDS(_5);
    _0 = _tempname_20121;
    _tempname_20121 = _11locate_file(_filename_20103, _11387, _5);
    DeRef(_0);
    _11387 = NOVALUE;

    /** 		if equal(tempname, filename) then*/
    if (_tempname_20121 == _filename_20103)
    _11389 = 1;
    else if (IS_ATOM_INT(_tempname_20121) && IS_ATOM_INT(_filename_20103))
    _11389 = 0;
    else
    _11389 = (compare(_tempname_20121, _filename_20103) == 0);
    if (_11389 == 0)
    {
        _11389 = NOVALUE;
        goto L2; // [77] 93
    }
    else{
        _11389 = NOVALUE;
    }

    /** 			filename = filesys:locate_file(filename)*/
    RefDS(_filename_20103);
    RefDS(_5);
    RefDS(_5);
    _0 = _filename_20103;
    _filename_20103 = _11locate_file(_filename_20103, _5, _5);
    DeRefDS(_0);
    goto L3; // [90] 101
L2: 

    /** 			filename = tempname*/
    RefDS(_tempname_20121);
    DeRefDS(_filename_20103);
    _filename_20103 = _tempname_20121;
L3: 
    DeRef(_tempname_20121);
    _tempname_20121 = NOVALUE;
    goto L4; // [103] 117
L1: 

    /** 		filename = filesys:locate_file(filename)*/
    RefDS(_filename_20103);
    RefDS(_5);
    RefDS(_5);
    _0 = _filename_20103;
    _filename_20103 = _11locate_file(_filename_20103, _5, _5);
    DeRefDS(_0);
L4: 

    /** 	lines = io:read_lines(filename)*/
    RefDS(_filename_20103);
    _0 = _lines_20104;
    _lines_20104 = _18read_lines(_filename_20103);
    DeRef(_0);

    /** 	if atom(lines) then*/
    _11393 = IS_ATOM(_lines_20104);
    if (_11393 == 0)
    {
        _11393 = NOVALUE;
        goto L5; // [128] 138
    }
    else{
        _11393 = NOVALUE;
    }

    /** 		return 0  -- Language maps unchanged.*/
    DeRefDS(_filename_20103);
    DeRef(_lines_20104);
    DeRef(_line_20105);
    DeRef(_key_20106);
    DeRef(_msg_20107);
    DeRef(_keylang_20110);
    DeRef(_altlang_20111);
    return 0;
L5: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_20104)){
            _11394 = SEQ_PTR(_lines_20104)->length;
    }
    else {
        _11394 = 1;
    }
    {
        int _i_20134;
        _i_20134 = 1;
L6: 
        if (_i_20134 > _11394){
            goto L7; // [143] 460
        }

        /** 		if cont then*/
        if (_cont_20109 == 0)
        {
            goto L8; // [152] 250
        }
        else{
        }

        /** 			line = text:trim_tail(lines[i])*/
        _2 = (int)SEQ_PTR(_lines_20104);
        _11395 = (int)*(((s1_ptr)_2)->base + _i_20134);
        Ref(_11395);
        RefDS(_4498);
        _0 = _line_20105;
        _line_20105 = _6trim_tail(_11395, _4498, 0);
        DeRef(_0);
        _11395 = NOVALUE;

        /** 			if line[$] = '&' then*/
        if (IS_SEQUENCE(_line_20105)){
                _11397 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11397 = 1;
        }
        _2 = (int)SEQ_PTR(_line_20105);
        _11398 = (int)*(((s1_ptr)_2)->base + _11397);
        if (binary_op_a(NOTEQ, _11398, 38)){
            _11398 = NOVALUE;
            goto L9; // [178] 209
        }
        _11398 = NOVALUE;

        /** 				msg &= line[1..$-1] & '\n'*/
        if (IS_SEQUENCE(_line_20105)){
                _11400 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11400 = 1;
        }
        _11401 = _11400 - 1;
        _11400 = NOVALUE;
        rhs_slice_target = (object_ptr)&_11402;
        RHS_Slice(_line_20105, 1, _11401);
        Append(&_11403, _11402, 10);
        DeRefDS(_11402);
        _11402 = NOVALUE;
        Concat((object_ptr)&_msg_20107, _msg_20107, _11403);
        DeRefDS(_11403);
        _11403 = NOVALUE;
        goto LA; // [206] 453
L9: 

        /** 				msg &= line*/
        Concat((object_ptr)&_msg_20107, _msg_20107, _line_20105);

        /** 				map:put(keylang, key, msg)*/
        Ref(_keylang_20110);
        RefDS(_key_20106);
        RefDS(_msg_20107);
        _33put(_keylang_20110, _key_20106, _msg_20107, 1, _33threshold_size_12820);

        /** 				map:put(altlang, msg, key)*/
        Ref(_altlang_20111);
        RefDS(_msg_20107);
        RefDS(_key_20106);
        _33put(_altlang_20111, _msg_20107, _key_20106, 1, _33threshold_size_12820);

        /** 				cont = 0*/
        _cont_20109 = 0;
        goto LA; // [247] 453
L8: 

        /** 			line = text:trim(lines[i])*/
        _2 = (int)SEQ_PTR(_lines_20104);
        _11406 = (int)*(((s1_ptr)_2)->base + _i_20134);
        Ref(_11406);
        RefDS(_4498);
        _0 = _line_20105;
        _line_20105 = _6trim(_11406, _4498, 0);
        DeRef(_0);
        _11406 = NOVALUE;

        /** 			if length(line) = 0 then*/
        if (IS_SEQUENCE(_line_20105)){
                _11408 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11408 = 1;
        }
        if (_11408 != 0)
        goto LB; // [269] 278

        /** 				continue*/
        goto LC; // [275] 455
LB: 

        /** 			if line[1] = '#' then*/
        _2 = (int)SEQ_PTR(_line_20105);
        _11410 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _11410, 35)){
            _11410 = NOVALUE;
            goto LD; // [284] 293
        }
        _11410 = NOVALUE;

        /** 				continue*/
        goto LC; // [290] 455
LD: 

        /** 			delim = find('=', line)*/
        _delim_20108 = find_from(61, _line_20105, 1);

        /** 			if delim = 0 then*/
        if (_delim_20108 != 0)
        goto LE; // [302] 314

        /** 				delim = find(' ', line)*/
        _delim_20108 = find_from(32, _line_20105, 1);
LE: 

        /** 			if delim = 0 then*/
        if (_delim_20108 != 0)
        goto LF; // [316] 325

        /** 				continue*/
        goto LC; // [322] 455
LF: 

        /** 			key = text:trim(line[1..delim-1])*/
        _11416 = _delim_20108 - 1;
        rhs_slice_target = (object_ptr)&_11417;
        RHS_Slice(_line_20105, 1, _11416);
        RefDS(_4498);
        _0 = _key_20106;
        _key_20106 = _6trim(_11417, _4498, 0);
        DeRef(_0);
        _11417 = NOVALUE;

        /** 			if line[$] = '&' then*/
        if (IS_SEQUENCE(_line_20105)){
                _11419 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11419 = 1;
        }
        _2 = (int)SEQ_PTR(_line_20105);
        _11420 = (int)*(((s1_ptr)_2)->base + _11419);
        if (binary_op_a(NOTEQ, _11420, 38)){
            _11420 = NOVALUE;
            goto L10; // [353] 407
        }
        _11420 = NOVALUE;

        /** 				cont = 1*/
        _cont_20109 = 1;

        /** 				msg = text:trim(line[delim+1..$-1])*/
        _11422 = _delim_20108 + 1;
        if (_11422 > MAXINT){
            _11422 = NewDouble((double)_11422);
        }
        if (IS_SEQUENCE(_line_20105)){
                _11423 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11423 = 1;
        }
        _11424 = _11423 - 1;
        _11423 = NOVALUE;
        rhs_slice_target = (object_ptr)&_11425;
        RHS_Slice(_line_20105, _11422, _11424);
        RefDS(_4498);
        _0 = _msg_20107;
        _msg_20107 = _6trim(_11425, _4498, 0);
        DeRef(_0);
        _11425 = NOVALUE;

        /** 				if length(msg) > 0 then*/
        if (IS_SEQUENCE(_msg_20107)){
                _11427 = SEQ_PTR(_msg_20107)->length;
        }
        else {
            _11427 = 1;
        }
        if (_11427 <= 0)
        goto L11; // [393] 452

        /** 					msg &= '\n'*/
        Append(&_msg_20107, _msg_20107, 10);
        goto L11; // [404] 452
L10: 

        /** 				msg = text:trim(line[delim+1..$])*/
        _11430 = _delim_20108 + 1;
        if (_11430 > MAXINT){
            _11430 = NewDouble((double)_11430);
        }
        if (IS_SEQUENCE(_line_20105)){
                _11431 = SEQ_PTR(_line_20105)->length;
        }
        else {
            _11431 = 1;
        }
        rhs_slice_target = (object_ptr)&_11432;
        RHS_Slice(_line_20105, _11430, _11431);
        RefDS(_4498);
        _0 = _msg_20107;
        _msg_20107 = _6trim(_11432, _4498, 0);
        DeRef(_0);
        _11432 = NOVALUE;

        /** 				map:put(keylang, key, msg)*/
        Ref(_keylang_20110);
        RefDS(_key_20106);
        RefDS(_msg_20107);
        _33put(_keylang_20110, _key_20106, _msg_20107, 1, _33threshold_size_12820);

        /** 				map:put(altlang, msg, key)*/
        Ref(_altlang_20111);
        RefDS(_msg_20107);
        RefDS(_key_20106);
        _33put(_altlang_20111, _msg_20107, _key_20106, 1, _33threshold_size_12820);
L11: 
LA: 

        /** 	end for*/
LC: 
        _i_20134 = _i_20134 + 1;
        goto L6; // [455] 150
L7: 
        ;
    }

    /** 	return {keylang, altlang}*/
    Ref(_altlang_20111);
    Ref(_keylang_20110);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keylang_20110;
    ((int *)_2)[2] = _altlang_20111;
    _11434 = MAKE_SEQ(_1);
    DeRefDS(_filename_20103);
    DeRef(_lines_20104);
    DeRef(_line_20105);
    DeRef(_key_20106);
    DeRef(_msg_20107);
    DeRef(_keylang_20110);
    DeRef(_altlang_20111);
    DeRef(_11401);
    _11401 = NOVALUE;
    DeRef(_11416);
    _11416 = NOVALUE;
    DeRef(_11422);
    _11422 = NOVALUE;
    DeRef(_11424);
    _11424 = NOVALUE;
    DeRef(_11430);
    _11430 = NOVALUE;
    return _11434;
    ;
}
int lang_load() __attribute__ ((alias ("_43lang_load")));


void _43set_def_lang(int _langmap_20189)
{
    int _11438 = NOVALUE;
    int _11437 = NOVALUE;
    int _11436 = NOVALUE;
    int _11435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(langmap) and langmap = 0 then*/
    _11435 = IS_ATOM(_langmap_20189);
    if (_11435 == 0) {
        goto L1; // [6] 26
    }
    if (IS_ATOM_INT(_langmap_20189)) {
        _11437 = (_langmap_20189 == 0);
    }
    else {
        _11437 = binary_op(EQUALS, _langmap_20189, 0);
    }
    if (_11437 == 0) {
        DeRef(_11437);
        _11437 = NOVALUE;
        goto L1; // [15] 26
    }
    else {
        if (!IS_ATOM_INT(_11437) && DBL_PTR(_11437)->dbl == 0.0){
            DeRef(_11437);
            _11437 = NOVALUE;
            goto L1; // [15] 26
        }
        DeRef(_11437);
        _11437 = NOVALUE;
    }
    DeRef(_11437);
    _11437 = NOVALUE;

    /** 		def_lang = langmap*/
    Ref(_langmap_20189);
    DeRef(_43def_lang_20094);
    _43def_lang_20094 = _langmap_20189;
    goto L2; // [23] 42
L1: 

    /** 	elsif length(langmap) = 2 then*/
    if (IS_SEQUENCE(_langmap_20189)){
            _11438 = SEQ_PTR(_langmap_20189)->length;
    }
    else {
        _11438 = 1;
    }
    if (_11438 != 2)
    goto L3; // [31] 41

    /** 		def_lang = langmap*/
    Ref(_langmap_20189);
    DeRef(_43def_lang_20094);
    _43def_lang_20094 = _langmap_20189;
L3: 
L2: 

    /** end procedure*/
    DeRef(_langmap_20189);
    return;
    ;
}
void set_def_lang() __attribute__ ((alias ("_43set_def_lang")));


int _43get_def_lang()
{
    int _0, _1, _2;
    

    /** 	return def_lang*/
    Ref(_43def_lang_20094);
    return _43def_lang_20094;
    ;
}
int get_def_lang() __attribute__ ((alias ("_43get_def_lang")));


int _43translate(int _word_20201, int _langmap_20202, int _defval_20203, int _mode_20204)
{
    int _11451 = NOVALUE;
    int _11450 = NOVALUE;
    int _11449 = NOVALUE;
    int _11448 = NOVALUE;
    int _11446 = NOVALUE;
    int _11445 = NOVALUE;
    int _11443 = NOVALUE;
    int _11442 = NOVALUE;
    int _11441 = NOVALUE;
    int _11440 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mode_20204)) {
        _1 = (long)(DBL_PTR(_mode_20204)->dbl);
        DeRefDS(_mode_20204);
        _mode_20204 = _1;
    }

    /** 	if equal(defval, mathcons:PINF) then*/
    if (_defval_20203 == _22PINF_4351)
    _11440 = 1;
    else if (IS_ATOM_INT(_defval_20203) && IS_ATOM_INT(_22PINF_4351))
    _11440 = 0;
    else
    _11440 = (compare(_defval_20203, _22PINF_4351) == 0);
    if (_11440 == 0)
    {
        _11440 = NOVALUE;
        goto L1; // [13] 22
    }
    else{
        _11440 = NOVALUE;
    }

    /** 		defval = word*/
    RefDS(_word_20201);
    DeRef(_defval_20203);
    _defval_20203 = _word_20201;
L1: 

    /** 	if equal(langmap, 0) then*/
    if (_langmap_20202 == 0)
    _11441 = 1;
    else if (IS_ATOM_INT(_langmap_20202) && IS_ATOM_INT(0))
    _11441 = 0;
    else
    _11441 = (compare(_langmap_20202, 0) == 0);
    if (_11441 == 0)
    {
        _11441 = NOVALUE;
        goto L2; // [28] 60
    }
    else{
        _11441 = NOVALUE;
    }

    /** 		if equal(def_lang, 0) then*/
    if (_43def_lang_20094 == 0)
    _11442 = 1;
    else if (IS_ATOM_INT(_43def_lang_20094) && IS_ATOM_INT(0))
    _11442 = 0;
    else
    _11442 = (compare(_43def_lang_20094, 0) == 0);
    if (_11442 == 0)
    {
        _11442 = NOVALUE;
        goto L3; // [39] 51
    }
    else{
        _11442 = NOVALUE;
    }

    /** 			return defval*/
    DeRefDS(_word_20201);
    DeRef(_langmap_20202);
    return _defval_20203;
    goto L4; // [48] 59
L3: 

    /** 			langmap = def_lang*/
    Ref(_43def_lang_20094);
    DeRef(_langmap_20202);
    _langmap_20202 = _43def_lang_20094;
L4: 
L2: 

    /** 	if atom(langmap) or length(langmap) != 2 then*/
    _11443 = IS_ATOM(_langmap_20202);
    if (_11443 != 0) {
        goto L5; // [65] 81
    }
    if (IS_SEQUENCE(_langmap_20202)){
            _11445 = SEQ_PTR(_langmap_20202)->length;
    }
    else {
        _11445 = 1;
    }
    _11446 = (_11445 != 2);
    _11445 = NOVALUE;
    if (_11446 == 0)
    {
        DeRef(_11446);
        _11446 = NOVALUE;
        goto L6; // [77] 88
    }
    else{
        DeRef(_11446);
        _11446 = NOVALUE;
    }
L5: 

    /** 		return defval*/
    DeRefDS(_word_20201);
    DeRef(_langmap_20202);
    return _defval_20203;
L6: 

    /** 	if mode = 0 then*/
    if (_mode_20204 != 0)
    goto L7; // [90] 113

    /** 		return map:get(langmap[1], word, defval)*/
    _2 = (int)SEQ_PTR(_langmap_20202);
    _11448 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11448);
    RefDS(_word_20201);
    Ref(_defval_20203);
    _11449 = _33get(_11448, _word_20201, _defval_20203);
    _11448 = NOVALUE;
    DeRefDS(_word_20201);
    DeRef(_langmap_20202);
    DeRef(_defval_20203);
    return _11449;
    goto L8; // [110] 130
L7: 

    /** 		return map:get(langmap[2], word, defval)*/
    _2 = (int)SEQ_PTR(_langmap_20202);
    _11450 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11450);
    RefDS(_word_20201);
    Ref(_defval_20203);
    _11451 = _33get(_11450, _word_20201, _defval_20203);
    _11450 = NOVALUE;
    DeRefDS(_word_20201);
    DeRef(_langmap_20202);
    DeRef(_defval_20203);
    DeRef(_11449);
    _11449 = NOVALUE;
    return _11451;
L8: 
    ;
}
int translate() __attribute__ ((alias ("_43translate")));


int _43trsprintf(int _fmt_20226, int _data_20227, int _langmap_20228)
{
    int _11467 = NOVALUE;
    int _11465 = NOVALUE;
    int _11464 = NOVALUE;
    int _11462 = NOVALUE;
    int _11461 = NOVALUE;
    int _11460 = NOVALUE;
    int _11459 = NOVALUE;
    int _11458 = NOVALUE;
    int _11456 = NOVALUE;
    int _11455 = NOVALUE;
    int _11454 = NOVALUE;
    int _11453 = NOVALUE;
    int _11452 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(data) do*/
    if (IS_SEQUENCE(_data_20227)){
            _11452 = SEQ_PTR(_data_20227)->length;
    }
    else {
        _11452 = 1;
    }
    {
        int _i_20230;
        _i_20230 = 1;
L1: 
        if (_i_20230 > _11452){
            goto L2; // [10] 89
        }

        /** 		if sequence(data[i]) then*/
        _2 = (int)SEQ_PTR(_data_20227);
        _11453 = (int)*(((s1_ptr)_2)->base + _i_20230);
        _11454 = IS_SEQUENCE(_11453);
        _11453 = NOVALUE;
        if (_11454 == 0)
        {
            _11454 = NOVALUE;
            goto L3; // [26] 82
        }
        else{
            _11454 = NOVALUE;
        }

        /** 			data[i] = translate(data[i], langmap, mathcons:PINF)*/
        _2 = (int)SEQ_PTR(_data_20227);
        _11455 = (int)*(((s1_ptr)_2)->base + _i_20230);
        Ref(_11455);
        Ref(_langmap_20228);
        RefDS(_22PINF_4351);
        _11456 = _43translate(_11455, _langmap_20228, _22PINF_4351, 0);
        _11455 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_20227);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_20227 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_20230);
        _1 = *(int *)_2;
        *(int *)_2 = _11456;
        if( _1 != _11456 ){
            DeRef(_1);
        }
        _11456 = NOVALUE;

        /** 			if search:begins("__", data[i]) then*/
        _2 = (int)SEQ_PTR(_data_20227);
        _11458 = (int)*(((s1_ptr)_2)->base + _i_20230);
        RefDS(_11457);
        Ref(_11458);
        _11459 = _9begins(_11457, _11458);
        _11458 = NOVALUE;
        if (_11459 == 0) {
            DeRef(_11459);
            _11459 = NOVALUE;
            goto L4; // [59] 81
        }
        else {
            if (!IS_ATOM_INT(_11459) && DBL_PTR(_11459)->dbl == 0.0){
                DeRef(_11459);
                _11459 = NOVALUE;
                goto L4; // [59] 81
            }
            DeRef(_11459);
            _11459 = NOVALUE;
        }
        DeRef(_11459);
        _11459 = NOVALUE;

        /** 				data[i] = data[i][3 .. $]*/
        _2 = (int)SEQ_PTR(_data_20227);
        _11460 = (int)*(((s1_ptr)_2)->base + _i_20230);
        if (IS_SEQUENCE(_11460)){
                _11461 = SEQ_PTR(_11460)->length;
        }
        else {
            _11461 = 1;
        }
        rhs_slice_target = (object_ptr)&_11462;
        RHS_Slice(_11460, 3, _11461);
        _11460 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_20227);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_20227 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_20230);
        _1 = *(int *)_2;
        *(int *)_2 = _11462;
        if( _1 != _11462 ){
            DeRef(_1);
        }
        _11462 = NOVALUE;
L4: 
L3: 

        /** 	end for*/
        _i_20230 = _i_20230 + 1;
        goto L1; // [84] 17
L2: 
        ;
    }

    /** 	fmt = translate(fmt, langmap, mathcons:PINF)*/
    RefDS(_fmt_20226);
    Ref(_langmap_20228);
    RefDS(_22PINF_4351);
    _0 = _fmt_20226;
    _fmt_20226 = _43translate(_fmt_20226, _langmap_20228, _22PINF_4351, 0);
    DeRefDS(_0);

    /** 	if search:begins("__", fmt) then*/
    RefDS(_11457);
    RefDS(_fmt_20226);
    _11464 = _9begins(_11457, _fmt_20226);
    if (_11464 == 0) {
        DeRef(_11464);
        _11464 = NOVALUE;
        goto L5; // [109] 123
    }
    else {
        if (!IS_ATOM_INT(_11464) && DBL_PTR(_11464)->dbl == 0.0){
            DeRef(_11464);
            _11464 = NOVALUE;
            goto L5; // [109] 123
        }
        DeRef(_11464);
        _11464 = NOVALUE;
    }
    DeRef(_11464);
    _11464 = NOVALUE;

    /** 		fmt = fmt[3 .. $]*/
    if (IS_SEQUENCE(_fmt_20226)){
            _11465 = SEQ_PTR(_fmt_20226)->length;
    }
    else {
        _11465 = 1;
    }
    rhs_slice_target = (object_ptr)&_fmt_20226;
    RHS_Slice(_fmt_20226, 3, _11465);
L5: 

    /** 	return sprintf(fmt, data)	*/
    _11467 = EPrintf(-9999999, _fmt_20226, _data_20227);
    DeRefDS(_fmt_20226);
    DeRefDS(_data_20227);
    DeRef(_langmap_20228);
    return _11467;
    ;
}
int trsprintf() __attribute__ ((alias ("_43trsprintf")));


int _43set(int _new_locale_20276)
{
    int _lAddr_localename_20277 = NOVALUE;
    int _ign_20278 = NOVALUE;
    int _nlocale_20279 = NOVALUE;
    int _11492 = NOVALUE;
    int _11490 = NOVALUE;
    int _11488 = NOVALUE;
    int _11486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	nlocale = lcc:decanonical(new_locale)*/
    RefDS(_new_locale_20276);
    _0 = _nlocale_20279;
    _nlocale_20279 = _44decanonical(_new_locale_20276);
    DeRef(_0);

    /** 	lAddr_localename = machine:allocate_string(nlocale)*/
    RefDS(_nlocale_20279);
    _0 = _lAddr_localename_20277;
    _lAddr_localename_20277 = _14allocate_string(_nlocale_20279, 0);
    DeRef(_0);

    /** 	ign = c_func(f_setlocale, {LC_MONETARY, lAddr_localename})*/
    Ref(_lAddr_localename_20277);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _lAddr_localename_20277;
    _11486 = MAKE_SEQ(_1);
    DeRef(_ign_20278);
    _ign_20278 = call_c(1, _43f_setlocale_20263, _11486);
    DeRefDS(_11486);
    _11486 = NOVALUE;

    /** 	ign = c_func(f_setlocale, {LC_NUMERIC, lAddr_localename})*/
    Ref(_lAddr_localename_20277);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _lAddr_localename_20277;
    _11488 = MAKE_SEQ(_1);
    DeRef(_ign_20278);
    _ign_20278 = call_c(1, _43f_setlocale_20263, _11488);
    DeRefDS(_11488);
    _11488 = NOVALUE;

    /** 	ign = c_func(f_setlocale, {LC_ALL, lAddr_localename})*/
    Ref(_lAddr_localename_20277);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = _lAddr_localename_20277;
    _11490 = MAKE_SEQ(_1);
    DeRef(_ign_20278);
    _ign_20278 = call_c(1, _43f_setlocale_20263, _11490);
    DeRefDS(_11490);
    _11490 = NOVALUE;

    /** 	machine:free(lAddr_localename)*/
    Ref(_lAddr_localename_20277);
    _14free(_lAddr_localename_20277);

    /** 	if sequence(lang_path) then*/
    _11492 = IS_SEQUENCE(_43lang_path_20095);
    if (_11492 == 0)
    {
        _11492 = NOVALUE;
        goto L1; // [69] 79
    }
    else{
        _11492 = NOVALUE;
    }

    /** 		def_lang = lang_load(nlocale)*/
    RefDS(_nlocale_20279);
    _0 = _43lang_load(_nlocale_20279);
    DeRef(_43def_lang_20094);
    _43def_lang_20094 = _0;
L1: 

    /** 	ign = (ign != dll:NULL)*/
    _0 = _ign_20278;
    if (IS_ATOM_INT(_ign_20278)) {
        _ign_20278 = (_ign_20278 != 0);
    }
    else {
        _ign_20278 = (DBL_PTR(_ign_20278)->dbl != (double)0);
    }
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 	return ign*/
    DeRefDS(_new_locale_20276);
    DeRef(_lAddr_localename_20277);
    DeRef(_nlocale_20279);
    return _ign_20278;
    ;
}


int _43get()
{
    int _r_20294 = NOVALUE;
    int _p_20295 = NOVALUE;
    int _11495 = NOVALUE;
    int _0, _1, _2;
    

    /** 	p = c_func(f_setlocale, {LC_ALL, dll:NULL})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = 0;
    _11495 = MAKE_SEQ(_1);
    DeRef(_p_20295);
    _p_20295 = call_c(1, _43f_setlocale_20263, _11495);
    DeRefDS(_11495);
    _11495 = NOVALUE;

    /** 	if p = dll:NULL then*/
    if (binary_op_a(NOTEQ, _p_20295, 0)){
        goto L1; // [16] 27
    }

    /** 		return ""*/
    RefDS(_5);
    DeRef(_r_20294);
    DeRef(_p_20295);
    return _5;
L1: 

    /** 	r = peek_string(p)*/
    DeRef(_r_20294);
    if (IS_ATOM_INT(_p_20295)) {
        _r_20294 =  NewString((char *)_p_20295);
    }
    else {
        _r_20294 = NewString((char *)(unsigned long)(DBL_PTR(_p_20295)->dbl));
    }

    /** 	ifdef WINDOWS then*/

    /** 	r = lcc:canonical(r)*/
    RefDS(_r_20294);
    _0 = _r_20294;
    _r_20294 = _44canonical(_r_20294);
    DeRefDSi(_0);

    /** 	return r*/
    DeRef(_p_20295);
    return _r_20294;
    ;
}


int _43money(int _amount_20304)
{
    int _result_20305 = NOVALUE;
    int _pResult_20306 = NOVALUE;
    int _pTmp_20307 = NOVALUE;
    int _11511 = NOVALUE;
    int _11507 = NOVALUE;
    int _11506 = NOVALUE;
    int _11505 = NOVALUE;
    int _11501 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if f_strfmon != -1 then*/
    if (binary_op_a(EQUALS, _43f_strfmon_20258, -1)){
        goto L1; // [5] 79
    }

    /** 		ifdef UNIX then*/

    /** 			pResult = machine:allocate(4 * 160)*/
    _11501 = 640;
    _0 = _pResult_20306;
    _pResult_20306 = _14allocate(640, 0);
    DeRef(_0);
    _11501 = NOVALUE;

    /** 			pTmp = machine:allocate_string("%n")*/
    RefDS(_11503);
    _0 = _pTmp_20307;
    _pTmp_20307 = _14allocate_string(_11503, 0);
    DeRef(_0);

    /** 			c_func(f_strfmon, {pResult, 4 * 160, pTmp, amount})*/
    _11505 = 640;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pResult_20306);
    *((int *)(_2+4)) = _pResult_20306;
    *((int *)(_2+8)) = 640;
    Ref(_pTmp_20307);
    *((int *)(_2+12)) = _pTmp_20307;
    Ref(_amount_20304);
    *((int *)(_2+16)) = _amount_20304;
    _11506 = MAKE_SEQ(_1);
    _11505 = NOVALUE;
    _11507 = call_c(1, _43f_strfmon_20258, _11506);
    DeRefDS(_11506);
    _11506 = NOVALUE;

    /** 		result = peek_string(pResult)*/
    DeRefi(_result_20305);
    if (IS_ATOM_INT(_pResult_20306)) {
        _result_20305 =  NewString((char *)_pResult_20306);
    }
    else {
        _result_20305 = NewString((char *)(unsigned long)(DBL_PTR(_pResult_20306)->dbl));
    }

    /** 		machine:free(pResult)*/
    Ref(_pResult_20306);
    _14free(_pResult_20306);

    /** 		machine:free(pTmp)*/
    Ref(_pTmp_20307);
    _14free(_pTmp_20307);

    /** 		return result*/
    DeRef(_amount_20304);
    DeRef(_pResult_20306);
    DeRef(_pTmp_20307);
    DeRef(_11507);
    _11507 = NOVALUE;
    return _result_20305;
    goto L2; // [76] 91
L1: 

    /** 		return text:format("$[,,.2]", amount)*/
    RefDS(_11510);
    Ref(_amount_20304);
    _11511 = _6format(_11510, _amount_20304);
    DeRef(_amount_20304);
    DeRefi(_result_20305);
    DeRef(_pResult_20306);
    DeRef(_pTmp_20307);
    DeRef(_11507);
    _11507 = NOVALUE;
    return _11511;
L2: 
    ;
}
int money() __attribute__ ((alias ("_43money")));


int _43number(int _num_20324)
{
    int _result_20325 = NOVALUE;
    int _pResult_20326 = NOVALUE;
    int _pTmp_20327 = NOVALUE;
    int _is_int_20348 = NOVALUE;
    int _float_20352 = NOVALUE;
    int _11548 = NOVALUE;
    int _11546 = NOVALUE;
    int _11545 = NOVALUE;
    int _11543 = NOVALUE;
    int _11542 = NOVALUE;
    int _11540 = NOVALUE;
    int _11538 = NOVALUE;
    int _11537 = NOVALUE;
    int _11534 = NOVALUE;
    int _11533 = NOVALUE;
    int _11532 = NOVALUE;
    int _11524 = NOVALUE;
    int _11522 = NOVALUE;
    int _11521 = NOVALUE;
    int _11520 = NOVALUE;
    int _11515 = NOVALUE;
    int _11513 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		if f_strfmon != -1 then*/
    if (binary_op_a(EQUALS, _43f_strfmon_20258, -1)){
        goto L1; // [7] 73
    }

    /** 			pResult = machine:allocate(4 * 160)*/
    _11513 = 640;
    _0 = _pResult_20326;
    _pResult_20326 = _14allocate(640, 0);
    DeRef(_0);
    _11513 = NOVALUE;

    /** 			if integer(num) then*/
    if (IS_ATOM_INT(_num_20324))
    _11515 = 1;
    else if (IS_ATOM_DBL(_num_20324))
    _11515 = IS_ATOM_INT(DoubleToInt(_num_20324));
    else
    _11515 = 0;
    if (_11515 == 0)
    {
        _11515 = NOVALUE;
        goto L2; // [27] 40
    }
    else{
        _11515 = NOVALUE;
    }

    /** 				pTmp = machine:allocate_string("%!.0n")*/
    RefDS(_11516);
    _0 = _pTmp_20327;
    _pTmp_20327 = _14allocate_string(_11516, 0);
    DeRef(_0);
    goto L3; // [37] 48
L2: 

    /** 				pTmp = machine:allocate_string("%!n")*/
    RefDS(_11518);
    _0 = _pTmp_20327;
    _pTmp_20327 = _14allocate_string(_11518, 0);
    DeRef(_0);
L3: 

    /** 			c_func(f_strfmon, {pResult, 4 * 160, pTmp, num})*/
    _11520 = 640;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pResult_20326);
    *((int *)(_2+4)) = _pResult_20326;
    *((int *)(_2+8)) = 640;
    Ref(_pTmp_20327);
    *((int *)(_2+12)) = _pTmp_20327;
    Ref(_num_20324);
    *((int *)(_2+16)) = _num_20324;
    _11521 = MAKE_SEQ(_1);
    _11520 = NOVALUE;
    _11522 = call_c(1, _43f_strfmon_20258, _11521);
    DeRefDS(_11521);
    _11521 = NOVALUE;
    goto L4; // [70] 85
L1: 

    /** 			return text:format("[,,]", num)*/
    RefDS(_11523);
    Ref(_num_20324);
    _11524 = _6format(_11523, _num_20324);
    DeRef(_num_20324);
    DeRef(_result_20325);
    DeRef(_pResult_20326);
    DeRef(_pTmp_20327);
    DeRef(_11522);
    _11522 = NOVALUE;
    return _11524;
L4: 

    /** 	result = peek_string(pResult)*/
    DeRef(_result_20325);
    if (IS_ATOM_INT(_pResult_20326)) {
        _result_20325 =  NewString((char *)_pResult_20326);
    }
    else {
        _result_20325 = NewString((char *)(unsigned long)(DBL_PTR(_pResult_20326)->dbl));
    }

    /** 	machine:free(pResult)*/
    Ref(_pResult_20326);
    _14free(_pResult_20326);

    /** 	machine:free(pTmp)*/
    Ref(_pTmp_20327);
    _14free(_pTmp_20327);

    /** 	integer is_int = integer(num)*/
    if (IS_ATOM_INT(_num_20324))
    _is_int_20348 = 1;
    else if (IS_ATOM_DBL(_num_20324))
    _is_int_20348 = IS_ATOM_INT(DoubleToInt(_num_20324));
    else
    _is_int_20348 = 0;

    /** 	if is_int = 0 then*/
    if (_is_int_20348 != 0)
    goto L5; // [113] 180

    /** 		sequence float = sprintf("%.15f", num)*/
    DeRefi(_float_20352);
    _float_20352 = EPrintf(-9999999, _11526, _num_20324);

    /** 		is_int = find('.', float)*/
    _is_int_20348 = find_from(46, _float_20352, 1);

    /** 		if is_int then*/
    if (_is_int_20348 == 0)
    {
        goto L6; // [132] 179
    }
    else{
    }

    /** 			for i = length(float) to is_int+1 by -1 do*/
    if (IS_SEQUENCE(_float_20352)){
            _11532 = SEQ_PTR(_float_20352)->length;
    }
    else {
        _11532 = 1;
    }
    _11533 = _is_int_20348 + 1;
    {
        int _i_20357;
        _i_20357 = _11532;
L7: 
        if (_i_20357 < _11533){
            goto L8; // [144] 178
        }

        /** 				if float[i] != '0' then*/
        _2 = (int)SEQ_PTR(_float_20352);
        _11534 = (int)*(((s1_ptr)_2)->base + _i_20357);
        if (_11534 == 48)
        goto L9; // [157] 171

        /** 					is_int = 0*/
        _is_int_20348 = 0;

        /** 					exit*/
        goto L8; // [168] 178
L9: 

        /** 			end for*/
        _i_20357 = _i_20357 + -1;
        goto L7; // [173] 151
L8: 
        ;
    }
L6: 
L5: 
    DeRefi(_float_20352);
    _float_20352 = NOVALUE;

    /** 	if is_int != 0 then -- The input was an integer*/
    if (_is_int_20348 == 0)
    goto LA; // [184] 299

    /** 		is_int = 0*/
    _is_int_20348 = 0;

    /** 		for i = length(result) to 1 by -1 do*/
    if (IS_SEQUENCE(_result_20325)){
            _11537 = SEQ_PTR(_result_20325)->length;
    }
    else {
        _11537 = 1;
    }
    {
        int _i_20366;
        _i_20366 = _11537;
LB: 
        if (_i_20366 < 1){
            goto LC; // [198] 237
        }

        /** 			if find(result[i], "1234567890") then*/
        _2 = (int)SEQ_PTR(_result_20325);
        _11538 = (int)*(((s1_ptr)_2)->base + _i_20366);
        _11540 = find_from(_11538, _11539, 1);
        _11538 = NOVALUE;
        if (_11540 == 0)
        {
            _11540 = NOVALUE;
            goto LD; // [216] 230
        }
        else{
            _11540 = NOVALUE;
        }

        /** 				is_int = i + 1*/
        _is_int_20348 = _i_20366 + 1;

        /** 				exit*/
        goto LC; // [227] 237
LD: 

        /** 		end for*/
        _i_20366 = _i_20366 + -1;
        goto LB; // [232] 205
LC: 
        ;
    }

    /** 		for i = is_int - 1 to 1 by -1 do*/
    _11542 = _is_int_20348 - 1;
    if ((long)((unsigned long)_11542 +(unsigned long) HIGH_BITS) >= 0){
        _11542 = NewDouble((double)_11542);
    }
    {
        int _i_20374;
        Ref(_11542);
        _i_20374 = _11542;
LE: 
        if (binary_op_a(LESS, _i_20374, 1)){
            goto LF; // [243] 298
        }

        /** 			if result[i] != '0' then*/
        _2 = (int)SEQ_PTR(_result_20325);
        if (!IS_ATOM_INT(_i_20374)){
            _11543 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_20374)->dbl));
        }
        else{
            _11543 = (int)*(((s1_ptr)_2)->base + _i_20374);
        }
        if (binary_op_a(EQUALS, _11543, 48)){
            _11543 = NOVALUE;
            goto L10; // [256] 291
        }
        _11543 = NOVALUE;

        /** 				if not find(result[i], "1234567890") then*/
        _2 = (int)SEQ_PTR(_result_20325);
        if (!IS_ATOM_INT(_i_20374)){
            _11545 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_20374)->dbl));
        }
        else{
            _11545 = (int)*(((s1_ptr)_2)->base + _i_20374);
        }
        _11546 = find_from(_11545, _11539, 1);
        _11545 = NOVALUE;
        if (_11546 != 0)
        goto LF; // [271] 298
        _11546 = NOVALUE;

        /** 					result = eu:remove(result, i, is_int - 1)*/
        _11548 = _is_int_20348 - 1;
        if ((long)((unsigned long)_11548 +(unsigned long) HIGH_BITS) >= 0){
            _11548 = NewDouble((double)_11548);
        }
        {
            s1_ptr assign_space = SEQ_PTR(_result_20325);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_20374)) ? _i_20374 : (long)(DBL_PTR(_i_20374)->dbl);
            int stop = (IS_ATOM_INT(_11548)) ? _11548 : (long)(DBL_PTR(_11548)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_result_20325), start, &_result_20325 );
                }
                else Tail(SEQ_PTR(_result_20325), stop+1, &_result_20325);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_result_20325), start, &_result_20325);
            }
            else {
                assign_slice_seq = &assign_space;
                _result_20325 = Remove_elements(start, stop, (SEQ_PTR(_result_20325)->ref == 1));
            }
        }
        DeRef(_11548);
        _11548 = NOVALUE;

        /** 				exit*/
        goto LF; // [288] 298
L10: 

        /** 		end for*/
        _0 = _i_20374;
        if (IS_ATOM_INT(_i_20374)) {
            _i_20374 = _i_20374 + -1;
            if ((long)((unsigned long)_i_20374 +(unsigned long) HIGH_BITS) >= 0){
                _i_20374 = NewDouble((double)_i_20374);
            }
        }
        else {
            _i_20374 = binary_op_a(PLUS, _i_20374, -1);
        }
        DeRef(_0);
        goto LE; // [293] 250
LF: 
        ;
        DeRef(_i_20374);
    }
LA: 

    /** 	return result*/
    DeRef(_num_20324);
    DeRef(_pResult_20326);
    DeRef(_pTmp_20327);
    DeRef(_11522);
    _11522 = NOVALUE;
    DeRef(_11524);
    _11524 = NOVALUE;
    DeRef(_11533);
    _11533 = NOVALUE;
    _11534 = NOVALUE;
    DeRef(_11542);
    _11542 = NOVALUE;
    return _result_20325;
    ;
}
int number() __attribute__ ((alias ("_43number")));


int _43mk_tm_struct(int _dtm_20387)
{
    int _pDtm_20388 = NOVALUE;
    int _weeks_day_4__tmp_at107_20415 = NOVALUE;
    int _weeks_day_3__tmp_at107_20414 = NOVALUE;
    int _weeks_day_2__tmp_at107_20413 = NOVALUE;
    int _weeks_day_1__tmp_at107_20412 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_107_20411 = NOVALUE;
    int _years_day_4__tmp_at145_20423 = NOVALUE;
    int _years_day_3__tmp_at145_20422 = NOVALUE;
    int _years_day_2__tmp_at145_20421 = NOVALUE;
    int _years_day_1__tmp_at145_20420 = NOVALUE;
    int _years_day_inlined_years_day_at_145_20419 = NOVALUE;
    int _11567 = NOVALUE;
    int _11566 = NOVALUE;
    int _11565 = NOVALUE;
    int _11564 = NOVALUE;
    int _11563 = NOVALUE;
    int _11562 = NOVALUE;
    int _11561 = NOVALUE;
    int _11560 = NOVALUE;
    int _11559 = NOVALUE;
    int _11558 = NOVALUE;
    int _11557 = NOVALUE;
    int _11556 = NOVALUE;
    int _11555 = NOVALUE;
    int _11554 = NOVALUE;
    int _11553 = NOVALUE;
    int _11552 = NOVALUE;
    int _11551 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pDtm = machine:allocate(36)*/
    _0 = _pDtm_20388;
    _pDtm_20388 = _14allocate(36, 0);
    DeRef(_0);

    /** 	poke4(pDtm,    dtm[SECOND])        -- int tm_sec*/
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11551 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_pDtm_20388)){
        poke4_addr = (unsigned long *)_pDtm_20388;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_pDtm_20388)->dbl);
    }
    if (IS_ATOM_INT(_11551)) {
        *poke4_addr = (unsigned long)_11551;
    }
    else if (IS_ATOM(_11551)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11551)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11551);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _11551 = NOVALUE;

    /** 	poke4(pDtm+4,  dtm[MINUTE])        -- int tm_min*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11552 = _pDtm_20388 + 4;
        if ((long)((unsigned long)_11552 + (unsigned long)HIGH_BITS) >= 0) 
        _11552 = NewDouble((double)_11552);
    }
    else {
        _11552 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)4);
    }
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11553 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_11552)){
        poke4_addr = (unsigned long *)_11552;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11552)->dbl);
    }
    if (IS_ATOM_INT(_11553)) {
        *poke4_addr = (unsigned long)_11553;
    }
    else if (IS_ATOM(_11553)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11553)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11553);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11552);
    _11552 = NOVALUE;
    _11553 = NOVALUE;

    /** 	poke4(pDtm+8,  dtm[HOUR])          -- int tm_hour*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11554 = _pDtm_20388 + 8;
        if ((long)((unsigned long)_11554 + (unsigned long)HIGH_BITS) >= 0) 
        _11554 = NewDouble((double)_11554);
    }
    else {
        _11554 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)8);
    }
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11555 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_11554)){
        poke4_addr = (unsigned long *)_11554;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11554)->dbl);
    }
    if (IS_ATOM_INT(_11555)) {
        *poke4_addr = (unsigned long)_11555;
    }
    else if (IS_ATOM(_11555)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11555)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11555);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11554);
    _11554 = NOVALUE;
    _11555 = NOVALUE;

    /** 	poke4(pDtm+12, dtm[DAY])           -- int tm_mday*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11556 = _pDtm_20388 + 12;
        if ((long)((unsigned long)_11556 + (unsigned long)HIGH_BITS) >= 0) 
        _11556 = NewDouble((double)_11556);
    }
    else {
        _11556 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)12);
    }
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11557 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_11556)){
        poke4_addr = (unsigned long *)_11556;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11556)->dbl);
    }
    if (IS_ATOM_INT(_11557)) {
        *poke4_addr = (unsigned long)_11557;
    }
    else if (IS_ATOM(_11557)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11557)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11557);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11556);
    _11556 = NOVALUE;
    _11557 = NOVALUE;

    /** 	poke4(pDtm+16, dtm[MONTH] - 1)     -- int tm_mon*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11558 = _pDtm_20388 + 16;
        if ((long)((unsigned long)_11558 + (unsigned long)HIGH_BITS) >= 0) 
        _11558 = NewDouble((double)_11558);
    }
    else {
        _11558 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)16);
    }
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11559 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_11559)) {
        _11560 = _11559 - 1;
        if ((long)((unsigned long)_11560 +(unsigned long) HIGH_BITS) >= 0){
            _11560 = NewDouble((double)_11560);
        }
    }
    else {
        _11560 = binary_op(MINUS, _11559, 1);
    }
    _11559 = NOVALUE;
    if (IS_ATOM_INT(_11558)){
        poke4_addr = (unsigned long *)_11558;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11558)->dbl);
    }
    if (IS_ATOM_INT(_11560)) {
        *poke4_addr = (unsigned long)_11560;
    }
    else if (IS_ATOM(_11560)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11560)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11560);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11558);
    _11558 = NOVALUE;
    DeRef(_11560);
    _11560 = NOVALUE;

    /** 	poke4(pDtm+20, dtm[YEAR] - 1900)   -- int tm_year*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11561 = _pDtm_20388 + 20;
        if ((long)((unsigned long)_11561 + (unsigned long)HIGH_BITS) >= 0) 
        _11561 = NewDouble((double)_11561);
    }
    else {
        _11561 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)20);
    }
    _2 = (int)SEQ_PTR(_dtm_20387);
    _11562 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11562)) {
        _11563 = _11562 - 1900;
        if ((long)((unsigned long)_11563 +(unsigned long) HIGH_BITS) >= 0){
            _11563 = NewDouble((double)_11563);
        }
    }
    else {
        _11563 = binary_op(MINUS, _11562, 1900);
    }
    _11562 = NOVALUE;
    if (IS_ATOM_INT(_11561)){
        poke4_addr = (unsigned long *)_11561;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11561)->dbl);
    }
    if (IS_ATOM_INT(_11563)) {
        *poke4_addr = (unsigned long)_11563;
    }
    else if (IS_ATOM(_11563)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11563)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11563);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11561);
    _11561 = NOVALUE;
    DeRef(_11563);
    _11563 = NOVALUE;

    /** 	poke4(pDtm+24, datetime:weeks_day(dtm) - 1)    -- int tm_wday*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11564 = _pDtm_20388 + 24;
        if ((long)((unsigned long)_11564 + (unsigned long)HIGH_BITS) >= 0) 
        _11564 = NewDouble((double)_11564);
    }
    else {
        _11564 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)24);
    }

    /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
    Ref(_dtm_20387);
    _0 = _weeks_day_1__tmp_at107_20412;
    _weeks_day_1__tmp_at107_20412 = _12julianDay(_dtm_20387);
    DeRef(_0);
    DeRef(_weeks_day_2__tmp_at107_20413);
    if (IS_ATOM_INT(_weeks_day_1__tmp_at107_20412)) {
        _weeks_day_2__tmp_at107_20413 = _weeks_day_1__tmp_at107_20412 - 1;
        if ((long)((unsigned long)_weeks_day_2__tmp_at107_20413 +(unsigned long) HIGH_BITS) >= 0){
            _weeks_day_2__tmp_at107_20413 = NewDouble((double)_weeks_day_2__tmp_at107_20413);
        }
    }
    else {
        _weeks_day_2__tmp_at107_20413 = binary_op(MINUS, _weeks_day_1__tmp_at107_20412, 1);
    }
    DeRef(_weeks_day_3__tmp_at107_20414);
    if (IS_ATOM_INT(_weeks_day_2__tmp_at107_20413)) {
        _weeks_day_3__tmp_at107_20414 = _weeks_day_2__tmp_at107_20413 + 4094;
        if ((long)((unsigned long)_weeks_day_3__tmp_at107_20414 + (unsigned long)HIGH_BITS) >= 0) 
        _weeks_day_3__tmp_at107_20414 = NewDouble((double)_weeks_day_3__tmp_at107_20414);
    }
    else {
        _weeks_day_3__tmp_at107_20414 = binary_op(PLUS, _weeks_day_2__tmp_at107_20413, 4094);
    }
    DeRef(_weeks_day_4__tmp_at107_20415);
    if (IS_ATOM_INT(_weeks_day_3__tmp_at107_20414)) {
        _weeks_day_4__tmp_at107_20415 = (_weeks_day_3__tmp_at107_20414 % 7);
    }
    else {
        _weeks_day_4__tmp_at107_20415 = binary_op(REMAINDER, _weeks_day_3__tmp_at107_20414, 7);
    }
    DeRef(_weeks_day_inlined_weeks_day_at_107_20411);
    if (IS_ATOM_INT(_weeks_day_4__tmp_at107_20415)) {
        _weeks_day_inlined_weeks_day_at_107_20411 = _weeks_day_4__tmp_at107_20415 + 1;
        if (_weeks_day_inlined_weeks_day_at_107_20411 > MAXINT){
            _weeks_day_inlined_weeks_day_at_107_20411 = NewDouble((double)_weeks_day_inlined_weeks_day_at_107_20411);
        }
    }
    else
    _weeks_day_inlined_weeks_day_at_107_20411 = binary_op(PLUS, 1, _weeks_day_4__tmp_at107_20415);
    DeRef(_weeks_day_1__tmp_at107_20412);
    _weeks_day_1__tmp_at107_20412 = NOVALUE;
    DeRef(_weeks_day_2__tmp_at107_20413);
    _weeks_day_2__tmp_at107_20413 = NOVALUE;
    DeRef(_weeks_day_3__tmp_at107_20414);
    _weeks_day_3__tmp_at107_20414 = NOVALUE;
    DeRef(_weeks_day_4__tmp_at107_20415);
    _weeks_day_4__tmp_at107_20415 = NOVALUE;
    if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_107_20411)) {
        _11565 = _weeks_day_inlined_weeks_day_at_107_20411 - 1;
        if ((long)((unsigned long)_11565 +(unsigned long) HIGH_BITS) >= 0){
            _11565 = NewDouble((double)_11565);
        }
    }
    else {
        _11565 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_107_20411, 1);
    }
    if (IS_ATOM_INT(_11564)){
        poke4_addr = (unsigned long *)_11564;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11564)->dbl);
    }
    if (IS_ATOM_INT(_11565)) {
        *poke4_addr = (unsigned long)_11565;
    }
    else if (IS_ATOM(_11565)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11565)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11565);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11564);
    _11564 = NOVALUE;
    DeRef(_11565);
    _11565 = NOVALUE;

    /** 	poke4(pDtm+28, datetime:years_day(dtm))        -- int tm_yday*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11566 = _pDtm_20388 + 28;
        if ((long)((unsigned long)_11566 + (unsigned long)HIGH_BITS) >= 0) 
        _11566 = NewDouble((double)_11566);
    }
    else {
        _11566 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)28);
    }

    /** 	return julianDayOfYear({dt[YEAR], dt[MONTH], dt[DAY]})*/
    DeRef(_years_day_1__tmp_at145_20420);
    _2 = (int)SEQ_PTR(_dtm_20387);
    _years_day_1__tmp_at145_20420 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_years_day_1__tmp_at145_20420);
    DeRef(_years_day_2__tmp_at145_20421);
    _2 = (int)SEQ_PTR(_dtm_20387);
    _years_day_2__tmp_at145_20421 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_years_day_2__tmp_at145_20421);
    DeRef(_years_day_3__tmp_at145_20422);
    _2 = (int)SEQ_PTR(_dtm_20387);
    _years_day_3__tmp_at145_20422 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_years_day_3__tmp_at145_20422);
    _0 = _years_day_4__tmp_at145_20423;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_years_day_1__tmp_at145_20420);
    *((int *)(_2+4)) = _years_day_1__tmp_at145_20420;
    Ref(_years_day_2__tmp_at145_20421);
    *((int *)(_2+8)) = _years_day_2__tmp_at145_20421;
    Ref(_years_day_3__tmp_at145_20422);
    *((int *)(_2+12)) = _years_day_3__tmp_at145_20422;
    _years_day_4__tmp_at145_20423 = MAKE_SEQ(_1);
    DeRef(_0);
    RefDS(_years_day_4__tmp_at145_20423);
    _0 = _years_day_inlined_years_day_at_145_20419;
    _years_day_inlined_years_day_at_145_20419 = _12julianDayOfYear(_years_day_4__tmp_at145_20423);
    DeRef(_0);
    DeRef(_years_day_1__tmp_at145_20420);
    _years_day_1__tmp_at145_20420 = NOVALUE;
    DeRef(_years_day_2__tmp_at145_20421);
    _years_day_2__tmp_at145_20421 = NOVALUE;
    DeRef(_years_day_3__tmp_at145_20422);
    _years_day_3__tmp_at145_20422 = NOVALUE;
    DeRef(_years_day_4__tmp_at145_20423);
    _years_day_4__tmp_at145_20423 = NOVALUE;
    if (IS_ATOM_INT(_11566)){
        poke4_addr = (unsigned long *)_11566;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11566)->dbl);
    }
    if (IS_ATOM_INT(_years_day_inlined_years_day_at_145_20419)) {
        *poke4_addr = (unsigned long)_years_day_inlined_years_day_at_145_20419;
    }
    else if (IS_ATOM(_years_day_inlined_years_day_at_145_20419)) {
        *poke4_addr = (unsigned long)DBL_PTR(_years_day_inlined_years_day_at_145_20419)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_years_day_inlined_years_day_at_145_20419);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11566);
    _11566 = NOVALUE;

    /** 	poke4(pDtm+32, 0)                  -- int tm_isdst*/
    if (IS_ATOM_INT(_pDtm_20388)) {
        _11567 = _pDtm_20388 + 32;
        if ((long)((unsigned long)_11567 + (unsigned long)HIGH_BITS) >= 0) 
        _11567 = NewDouble((double)_11567);
    }
    else {
        _11567 = NewDouble(DBL_PTR(_pDtm_20388)->dbl + (double)32);
    }
    if (IS_ATOM_INT(_11567)){
        poke4_addr = (unsigned long *)_11567;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11567)->dbl);
    }
    *poke4_addr = (unsigned long)0;
    DeRef(_11567);
    _11567 = NOVALUE;

    /** 	return pDtm*/
    DeRef(_dtm_20387);
    return _pDtm_20388;
    ;
}


int _43datetime(int _fmt_20427, int _dtm_20428)
{
    int _pFmt_20429 = NOVALUE;
    int _pRes_20430 = NOVALUE;
    int _pDtm_20431 = NOVALUE;
    int _res_20432 = NOVALUE;
    int _11578 = NOVALUE;
    int _11577 = NOVALUE;
    int _11576 = NOVALUE;
    int _11573 = NOVALUE;
    int _11572 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if f_strftime != -1 then*/
    if (binary_op_a(EQUALS, _43f_strftime_20266, -1)){
        goto L1; // [7] 72
    }

    /** 		pDtm = mk_tm_struct(dtm)*/
    Ref(_dtm_20428);
    _0 = _pDtm_20431;
    _pDtm_20431 = _43mk_tm_struct(_dtm_20428);
    DeRef(_0);

    /** 		pFmt = machine:allocate_string(fmt)*/
    RefDS(_fmt_20427);
    _0 = _pFmt_20429;
    _pFmt_20429 = _14allocate_string(_fmt_20427, 0);
    DeRef(_0);

    /** 		pRes = machine:allocate(1024)*/
    _0 = _pRes_20430;
    _pRes_20430 = _14allocate(1024, 0);
    DeRef(_0);

    /** 		c_func(f_strftime, {pRes, 256, pFmt, pDtm})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pRes_20430);
    *((int *)(_2+4)) = _pRes_20430;
    *((int *)(_2+8)) = 256;
    Ref(_pFmt_20429);
    *((int *)(_2+12)) = _pFmt_20429;
    Ref(_pDtm_20431);
    *((int *)(_2+16)) = _pDtm_20431;
    _11572 = MAKE_SEQ(_1);
    _11573 = call_c(1, _43f_strftime_20266, _11572);
    DeRefDS(_11572);
    _11572 = NOVALUE;

    /** 		res = peek_string(pRes)*/
    DeRef(_res_20432);
    if (IS_ATOM_INT(_pRes_20430)) {
        _res_20432 =  NewString((char *)_pRes_20430);
    }
    else {
        _res_20432 = NewString((char *)(unsigned long)(DBL_PTR(_pRes_20430)->dbl));
    }

    /** 		machine:free(pRes)*/
    Ref(_pRes_20430);
    _14free(_pRes_20430);

    /** 		machine:free(pFmt)*/
    Ref(_pFmt_20429);
    _14free(_pFmt_20429);

    /** 		machine:free(pDtm)*/
    Ref(_pDtm_20431);
    _14free(_pDtm_20431);
    goto L2; // [69] 107
L1: 

    /** 		res = date()*/
    DeRef(_res_20432);
    _res_20432 = Date();

    /** 		res[1] += 1900*/
    _2 = (int)SEQ_PTR(_res_20432);
    _11576 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11576)) {
        _11577 = _11576 + 1900;
        if ((long)((unsigned long)_11577 + (unsigned long)HIGH_BITS) >= 0) 
        _11577 = NewDouble((double)_11577);
    }
    else {
        _11577 = binary_op(PLUS, _11576, 1900);
    }
    _11576 = NOVALUE;
    _2 = (int)SEQ_PTR(_res_20432);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _res_20432 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _11577;
    if( _1 != _11577 ){
        DeRef(_1);
    }
    _11577 = NOVALUE;

    /** 		res = datetime:format(res[1..6], fmt)*/
    rhs_slice_target = (object_ptr)&_11578;
    RHS_Slice(_res_20432, 1, 6);
    RefDS(_fmt_20427);
    _0 = _res_20432;
    _res_20432 = _12format(_11578, _fmt_20427);
    DeRefDS(_0);
    _11578 = NOVALUE;
L2: 

    /** 	return res*/
    DeRefDS(_fmt_20427);
    DeRef(_dtm_20428);
    DeRef(_pFmt_20429);
    DeRef(_pRes_20430);
    DeRef(_pDtm_20431);
    DeRef(_11573);
    _11573 = NOVALUE;
    return _res_20432;
    ;
}


int _43get_text(int _MsgNum_20449, int _LocalQuals_20450, int _DBBase_20451)
{
    int _db_res_20453 = NOVALUE;
    int _lMsgText_20454 = NOVALUE;
    int _dbname_20455 = NOVALUE;
    int _11616 = NOVALUE;
    int _11614 = NOVALUE;
    int _11612 = NOVALUE;
    int _11611 = NOVALUE;
    int _11610 = NOVALUE;
    int _11608 = NOVALUE;
    int _11607 = NOVALUE;
    int _11606 = NOVALUE;
    int _11600 = NOVALUE;
    int _11599 = NOVALUE;
    int _11598 = NOVALUE;
    int _11591 = NOVALUE;
    int _11588 = NOVALUE;
    int _11586 = NOVALUE;
    int _11584 = NOVALUE;
    int _11583 = NOVALUE;
    int _11582 = NOVALUE;
    int _11581 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_20449)) {
        _1 = (long)(DBL_PTR(_MsgNum_20449)->dbl);
        DeRefDS(_MsgNum_20449);
        _MsgNum_20449 = _1;
    }

    /** 	db_res = -1*/
    _db_res_20453 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_20454);
    _lMsgText_20454 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_20450);
    _11581 = _7string(_LocalQuals_20450);
    if (IS_ATOM_INT(_11581)) {
        if (_11581 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11581)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_20450)){
            _11583 = SEQ_PTR(_LocalQuals_20450)->length;
    }
    else {
        _11583 = 1;
    }
    _11584 = (_11583 > 0);
    _11583 = NOVALUE;
    if (_11584 == 0)
    {
        DeRef(_11584);
        _11584 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11584);
        _11584 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_20450;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_20450);
    *((int *)(_2+4)) = _LocalQuals_20450;
    _LocalQuals_20450 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20450)){
            _11586 = SEQ_PTR(_LocalQuals_20450)->length;
    }
    else {
        _11586 = 1;
    }
    {
        int _i_20464;
        _i_20464 = 1;
L2: 
        if (_i_20464 > _11586){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_20450);
        _11588 = (int)*(((s1_ptr)_2)->base + _i_20464);
        {
            int concat_list[4];

            concat_list[0] = _11589;
            concat_list[1] = _11588;
            concat_list[2] = _11587;
            concat_list[3] = _DBBase_20451;
            Concat_N((object_ptr)&_dbname_20455, concat_list, 4);
        }
        _11588 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_20455);
        RefDS(_5);
        RefDS(_5);
        _11591 = _11locate_file(_dbname_20455, _5, _5);
        _db_res_20453 = _38db_select(_11591, 3);
        _11591 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_20453)) {
            _1 = (long)(DBL_PTR(_db_res_20453)->dbl);
            DeRefDS(_db_res_20453);
            _db_res_20453 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_20453 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11594);
        _db_res_20453 = _38db_select_table(_11594);
        if (!IS_ATOM_INT(_db_res_20453)) {
            _1 = (long)(DBL_PTR(_db_res_20453)->dbl);
            DeRefDS(_db_res_20453);
            _db_res_20453 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_20453 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_38current_table_name_16420);
        _0 = _lMsgText_20454;
        _lMsgText_20454 = _38db_fetch_record(_MsgNum_20449, _38current_table_name_16420);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11598 = IS_SEQUENCE(_lMsgText_20454);
        if (_11598 == 0)
        {
            _11598 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11598 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_20464 = _i_20464 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11599 = IS_ATOM(_lMsgText_20454);
    if (_11599 == 0)
    {
        _11599 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11599 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11600, _DBBase_20451, _11589);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_20455;
    _dbname_20455 = _11locate_file(_11600, _5, _5);
    DeRef(_0);
    _11600 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_20455);
    _db_res_20453 = _38db_select(_dbname_20455, 3);
    if (!IS_ATOM_INT(_db_res_20453)) {
        _1 = (long)(DBL_PTR(_db_res_20453)->dbl);
        DeRefDS(_db_res_20453);
        _db_res_20453 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_20453 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11594);
    _db_res_20453 = _38db_select_table(_11594);
    if (!IS_ATOM_INT(_db_res_20453)) {
        _1 = (long)(DBL_PTR(_db_res_20453)->dbl);
        DeRefDS(_db_res_20453);
        _db_res_20453 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_20453 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20450)){
            _11606 = SEQ_PTR(_LocalQuals_20450)->length;
    }
    else {
        _11606 = 1;
    }
    {
        int _i_20493;
        _i_20493 = 1;
LA: 
        if (_i_20493 > _11606){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_20450);
        _11607 = (int)*(((s1_ptr)_2)->base + _i_20493);
        Ref(_11607);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11607;
        ((int *)_2)[2] = _MsgNum_20449;
        _11608 = MAKE_SEQ(_1);
        _11607 = NOVALUE;
        RefDS(_38current_table_name_16420);
        _0 = _lMsgText_20454;
        _lMsgText_20454 = _38db_fetch_record(_11608, _38current_table_name_16420);
        DeRef(_0);
        _11608 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11610 = IS_SEQUENCE(_lMsgText_20454);
        if (_11610 == 0)
        {
            _11610 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11610 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_20493 = _i_20493 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11611 = IS_ATOM(_lMsgText_20454);
    if (_11611 == 0)
    {
        _11611 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11611 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_20449;
    _11612 = MAKE_SEQ(_1);
    RefDS(_38current_table_name_16420);
    _0 = _lMsgText_20454;
    _lMsgText_20454 = _38db_fetch_record(_11612, _38current_table_name_16420);
    DeRef(_0);
    _11612 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11614 = IS_ATOM(_lMsgText_20454);
    if (_11614 == 0)
    {
        _11614 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11614 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_38current_table_name_16420);
    _0 = _lMsgText_20454;
    _lMsgText_20454 = _38db_fetch_record(_MsgNum_20449, _38current_table_name_16420);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11616 = IS_ATOM(_lMsgText_20454);
    if (_11616 == 0)
    {
        _11616 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11616 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_20450);
    DeRefDS(_DBBase_20451);
    DeRef(_lMsgText_20454);
    DeRef(_dbname_20455);
    DeRef(_11581);
    _11581 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_20450);
    DeRefDS(_DBBase_20451);
    DeRef(_dbname_20455);
    DeRef(_11581);
    _11581 = NOVALUE;
    return _lMsgText_20454;
L10: 
    ;
}
int get_text() __attribute__ ((alias ("_43get_text")));



// 0xAF6FBE22
