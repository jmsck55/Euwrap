// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _48error_code()
{
    int _12182 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_ERROR_CODE, {})*/
    _12182 = machine(96, _5);
    return _12182;
    ;
}
int error_code() __attribute__ ((alias ("_48error_code")));


int _48socket(int _o_22029)
{
    int _12354 = NOVALUE;
    int _12353 = NOVALUE;
    int _12351 = NOVALUE;
    int _12350 = NOVALUE;
    int _12348 = NOVALUE;
    int _12346 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(o) then */
    _12346 = IS_SEQUENCE(_o_22029);
    if (_12346 != 0)
    goto L1; // [6] 16
    _12346 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22029);
    return 0;
L1: 

    /**     if length(o) != 2 then */
    if (IS_SEQUENCE(_o_22029)){
            _12348 = SEQ_PTR(_o_22029)->length;
    }
    else {
        _12348 = 1;
    }
    if (_12348 == 2)
    goto L2; // [21] 32

    /**         return 0 */
    DeRef(_o_22029);
    return 0;
L2: 

    /**     if not atom(o[1]) then */
    _2 = (int)SEQ_PTR(_o_22029);
    _12350 = (int)*(((s1_ptr)_2)->base + 1);
    _12351 = IS_ATOM(_12350);
    _12350 = NOVALUE;
    if (_12351 != 0)
    goto L3; // [41] 51
    _12351 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22029);
    return 0;
L3: 

    /**     if not atom(o[2]) then */
    _2 = (int)SEQ_PTR(_o_22029);
    _12353 = (int)*(((s1_ptr)_2)->base + 2);
    _12354 = IS_ATOM(_12353);
    _12353 = NOVALUE;
    if (_12354 != 0)
    goto L4; // [60] 70
    _12354 = NOVALUE;

    /**         return 0 */
    DeRef(_o_22029);
    return 0;
L4: 

    /** 	return 1*/
    DeRef(_o_22029);
    return 1;
    ;
}
int socket() __attribute__ ((alias ("_48socket")));


void _48delete_socket(int _o_22046)
{
    int _12360 = NOVALUE;
    int _12358 = NOVALUE;
    int _12356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not socket(o) then*/
    Ref(_o_22046);
    _12356 = _48socket(_o_22046);
    if (IS_ATOM_INT(_12356)) {
        if (_12356 != 0){
            DeRef(_12356);
            _12356 = NOVALUE;
            goto L1; // [7] 16
        }
    }
    else {
        if (DBL_PTR(_12356)->dbl != 0.0){
            DeRef(_12356);
            _12356 = NOVALUE;
            goto L1; // [7] 16
        }
    }
    DeRef(_12356);
    _12356 = NOVALUE;

    /** 		return*/
    DeRef(_o_22046);
    return;
L1: 

    /** 	if o[SOCKET_SOCKADDR_IN] = 0 then*/
    _2 = (int)SEQ_PTR(_o_22046);
    _12358 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _12358, 0)){
        _12358 = NOVALUE;
        goto L2; // [22] 32
    }
    _12358 = NOVALUE;

    /** 		return*/
    DeRef(_o_22046);
    return;
L2: 

    /** 	machine:free(o[SOCKET_SOCKADDR_IN])*/
    _2 = (int)SEQ_PTR(_o_22046);
    _12360 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_12360);
    _14free(_12360);
    _12360 = NOVALUE;

    /** end procedure*/
    DeRef(_o_22046);
    return;
    ;
}


int _48create(int _family_22059, int _sock_type_22060, int _protocol_22061)
{
    int _o_22062 = NOVALUE;
    int _12366 = NOVALUE;
    int _12365 = NOVALUE;
    int _12363 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_family_22059)) {
        _1 = (long)(DBL_PTR(_family_22059)->dbl);
        DeRefDS(_family_22059);
        _family_22059 = _1;
    }
    if (!IS_ATOM_INT(_sock_type_22060)) {
        _1 = (long)(DBL_PTR(_sock_type_22060)->dbl);
        DeRefDS(_sock_type_22060);
        _sock_type_22060 = _1;
    }
    if (!IS_ATOM_INT(_protocol_22061)) {
        _1 = (long)(DBL_PTR(_protocol_22061)->dbl);
        DeRefDS(_protocol_22061);
        _protocol_22061 = _1;
    }

    /** 	object o = machine_func(M_SOCK_SOCKET, { family, sock_type, protocol })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _family_22059;
    *((int *)(_2+8)) = _sock_type_22060;
    *((int *)(_2+12)) = _protocol_22061;
    _12363 = MAKE_SEQ(_1);
    DeRef(_o_22062);
    _o_22062 = machine(81, _12363);
    DeRefDS(_12363);
    _12363 = NOVALUE;

    /** 	if atom(o) then*/
    _12365 = IS_ATOM(_o_22062);
    if (_12365 == 0)
    {
        _12365 = NOVALUE;
        goto L1; // [24] 34
    }
    else{
        _12365 = NOVALUE;
    }

    /**         return o */
    return _o_22062;
L1: 

    /**     return delete_routine(o, delete_socket_rid)*/
    DeRef(_12366);
    if( IS_ATOM_INT(_o_22062) ){
        _12366 = NewDouble( (double) _o_22062 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_o_22062)) ){
            if( IS_ATOM_DBL( _o_22062 ) ){
                _12366 = NewDouble( DBL_PTR(_o_22062)->dbl );
            }
            else {
                RefDS(_o_22062);
                _12366 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_o_22062) ));
            }
        }
        else {
            _12366 = _o_22062;
        }
    }
    _1 = (int) _00[_48delete_socket_rid_22054].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_48delete_socket_rid_22054].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _48delete_socket_rid_22054;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_12366) ){
        if( IS_ATOM_INT(_12366) ){
            _12366 = NewDouble( (double) _o_22062 );
        }
        if(DBL_PTR(_12366)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_12366)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_12366)) ){
            DeRefDS(_12366);
            _12366 = NewDouble( DBL_PTR(_12366)->dbl );
        }
        DBL_PTR(_12366)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_12366)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_12366)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_12366)) ){
            _12366 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_12366) ));
        }
        SEQ_PTR(_12366)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_o_22062) ){
        RefDS(_12366);
    }
    DeRef(_o_22062);
    return _12366;
    ;
}


int _48close(int _sock_22070)
{
    int _12368 = NOVALUE;
    int _12367 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22070);
    *((int *)(_2+4)) = _sock_22070;
    _12367 = MAKE_SEQ(_1);
    _12368 = machine(82, _12367);
    DeRefDS(_12367);
    _12367 = NOVALUE;
    DeRef(_sock_22070);
    return _12368;
    ;
}


int _48shutdown(int _sock_22075, int _method_22076)
{
    int _12370 = NOVALUE;
    int _12369 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_SHUTDOWN, { sock, method })*/
    Ref(_method_22076);
    Ref(_sock_22075);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22075;
    ((int *)_2)[2] = _method_22076;
    _12369 = MAKE_SEQ(_1);
    _12370 = machine(83, _12369);
    DeRefDS(_12369);
    _12369 = NOVALUE;
    DeRef(_sock_22075);
    DeRef(_method_22076);
    return _12370;
    ;
}
int shutdown() __attribute__ ((alias ("_48shutdown")));


int _48select(int _sockets_read_22081, int _sockets_write_22082, int _sockets_err_22083, int _timeout_22084, int _timeout_micro_22085)
{
    int _sockets_all_22086 = NOVALUE;
    int _12389 = NOVALUE;
    int _12388 = NOVALUE;
    int _12386 = NOVALUE;
    int _12385 = NOVALUE;
    int _12384 = NOVALUE;
    int _12383 = NOVALUE;
    int _12381 = NOVALUE;
    int _12380 = NOVALUE;
    int _12379 = NOVALUE;
    int _12377 = NOVALUE;
    int _12376 = NOVALUE;
    int _12375 = NOVALUE;
    int _12373 = NOVALUE;
    int _12372 = NOVALUE;
    int _12371 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_timeout_22084)) {
        _1 = (long)(DBL_PTR(_timeout_22084)->dbl);
        DeRefDS(_timeout_22084);
        _timeout_22084 = _1;
    }
    if (!IS_ATOM_INT(_timeout_micro_22085)) {
        _1 = (long)(DBL_PTR(_timeout_micro_22085)->dbl);
        DeRefDS(_timeout_micro_22085);
        _timeout_micro_22085 = _1;
    }

    /** 	if length(sockets_read) and socket(sockets_read) then*/
    if (IS_SEQUENCE(_sockets_read_22081)){
            _12371 = SEQ_PTR(_sockets_read_22081)->length;
    }
    else {
        _12371 = 1;
    }
    if (_12371 == 0) {
        goto L1; // [10] 29
    }
    Ref(_sockets_read_22081);
    _12373 = _48socket(_sockets_read_22081);
    if (_12373 == 0) {
        DeRef(_12373);
        _12373 = NOVALUE;
        goto L1; // [19] 29
    }
    else {
        if (!IS_ATOM_INT(_12373) && DBL_PTR(_12373)->dbl == 0.0){
            DeRef(_12373);
            _12373 = NOVALUE;
            goto L1; // [19] 29
        }
        DeRef(_12373);
        _12373 = NOVALUE;
    }
    DeRef(_12373);
    _12373 = NOVALUE;

    /** 		sockets_read = { sockets_read }*/
    _0 = _sockets_read_22081;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_read_22081);
    *((int *)(_2+4)) = _sockets_read_22081;
    _sockets_read_22081 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if length(sockets_write) and socket(sockets_write) then*/
    if (IS_SEQUENCE(_sockets_write_22082)){
            _12375 = SEQ_PTR(_sockets_write_22082)->length;
    }
    else {
        _12375 = 1;
    }
    if (_12375 == 0) {
        goto L2; // [34] 53
    }
    Ref(_sockets_write_22082);
    _12377 = _48socket(_sockets_write_22082);
    if (_12377 == 0) {
        DeRef(_12377);
        _12377 = NOVALUE;
        goto L2; // [43] 53
    }
    else {
        if (!IS_ATOM_INT(_12377) && DBL_PTR(_12377)->dbl == 0.0){
            DeRef(_12377);
            _12377 = NOVALUE;
            goto L2; // [43] 53
        }
        DeRef(_12377);
        _12377 = NOVALUE;
    }
    DeRef(_12377);
    _12377 = NOVALUE;

    /** 		sockets_write = { sockets_write }*/
    _0 = _sockets_write_22082;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_write_22082);
    *((int *)(_2+4)) = _sockets_write_22082;
    _sockets_write_22082 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if length(sockets_err) and socket(sockets_err) then*/
    if (IS_SEQUENCE(_sockets_err_22083)){
            _12379 = SEQ_PTR(_sockets_err_22083)->length;
    }
    else {
        _12379 = 1;
    }
    if (_12379 == 0) {
        goto L3; // [58] 77
    }
    Ref(_sockets_err_22083);
    _12381 = _48socket(_sockets_err_22083);
    if (_12381 == 0) {
        DeRef(_12381);
        _12381 = NOVALUE;
        goto L3; // [67] 77
    }
    else {
        if (!IS_ATOM_INT(_12381) && DBL_PTR(_12381)->dbl == 0.0){
            DeRef(_12381);
            _12381 = NOVALUE;
            goto L3; // [67] 77
        }
        DeRef(_12381);
        _12381 = NOVALUE;
    }
    DeRef(_12381);
    _12381 = NOVALUE;

    /** 		sockets_err = { sockets_err }*/
    _0 = _sockets_err_22083;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_err_22083);
    *((int *)(_2+4)) = _sockets_err_22083;
    _sockets_err_22083 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	if equal(sockets_err, sockets_read) and*/
    if (_sockets_err_22083 == _sockets_read_22081)
    _12383 = 1;
    else if (IS_ATOM_INT(_sockets_err_22083) && IS_ATOM_INT(_sockets_read_22081))
    _12383 = 0;
    else
    _12383 = (compare(_sockets_err_22083, _sockets_read_22081) == 0);
    if (_12383 == 0) {
        goto L4; // [83] 105
    }
    if (_sockets_write_22082 == _sockets_read_22081)
    _12385 = 1;
    else if (IS_ATOM_INT(_sockets_write_22082) && IS_ATOM_INT(_sockets_read_22081))
    _12385 = 0;
    else
    _12385 = (compare(_sockets_write_22082, _sockets_read_22081) == 0);
    if (_12385 == 0)
    {
        _12385 = NOVALUE;
        goto L4; // [92] 105
    }
    else{
        _12385 = NOVALUE;
    }

    /** 		sockets_all = sockets_read*/
    Ref(_sockets_read_22081);
    DeRef(_sockets_all_22086);
    _sockets_all_22086 = _sockets_read_22081;
    goto L5; // [102] 121
L4: 

    /** 		sockets_all = stdseq:remove_dups(sockets_read & sockets_write*/
    {
        int concat_list[3];

        concat_list[0] = _sockets_err_22083;
        concat_list[1] = _sockets_write_22082;
        concat_list[2] = _sockets_read_22081;
        Concat_N((object_ptr)&_12386, concat_list, 3);
    }
    _0 = _sockets_all_22086;
    _sockets_all_22086 = _23remove_dups(_12386, 3);
    DeRef(_0);
    _12386 = NOVALUE;
L5: 

    /** 	return machine_func(M_SOCK_SELECT, { sockets_read, sockets_write,*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sockets_read_22081);
    *((int *)(_2+4)) = _sockets_read_22081;
    Ref(_sockets_write_22082);
    *((int *)(_2+8)) = _sockets_write_22082;
    Ref(_sockets_err_22083);
    *((int *)(_2+12)) = _sockets_err_22083;
    RefDS(_sockets_all_22086);
    *((int *)(_2+16)) = _sockets_all_22086;
    *((int *)(_2+20)) = _timeout_micro_22085;
    *((int *)(_2+24)) = _timeout_22084;
    _12388 = MAKE_SEQ(_1);
    _12389 = machine(92, _12388);
    DeRefDS(_12388);
    _12388 = NOVALUE;
    DeRef(_sockets_read_22081);
    DeRef(_sockets_write_22082);
    DeRef(_sockets_err_22083);
    DeRefDS(_sockets_all_22086);
    return _12389;
    ;
}
int select() __attribute__ ((alias ("_48select")));


int _48send(int _sock_22113, int _data_22114, int _flags_22115)
{
    int _12391 = NOVALUE;
    int _12390 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_SEND, { sock, data, flags })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22113);
    *((int *)(_2+4)) = _sock_22113;
    RefDS(_data_22114);
    *((int *)(_2+8)) = _data_22114;
    Ref(_flags_22115);
    *((int *)(_2+12)) = _flags_22115;
    _12390 = MAKE_SEQ(_1);
    _12391 = machine(85, _12390);
    DeRefDS(_12390);
    _12390 = NOVALUE;
    DeRef(_sock_22113);
    DeRefDS(_data_22114);
    DeRef(_flags_22115);
    return _12391;
    ;
}
int send() __attribute__ ((alias ("_48send")));


int _48receive(int _sock_22120, int _flags_22121)
{
    int _12393 = NOVALUE;
    int _12392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_RECV, { sock, flags })*/
    Ref(_flags_22121);
    Ref(_sock_22120);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22120;
    ((int *)_2)[2] = _flags_22121;
    _12392 = MAKE_SEQ(_1);
    _12393 = machine(86, _12392);
    DeRefDS(_12392);
    _12392 = NOVALUE;
    DeRef(_sock_22120);
    DeRef(_flags_22121);
    return _12393;
    ;
}
int receive() __attribute__ ((alias ("_48receive")));


int _48get_option(int _sock_22126, int _level_22127, int _optname_22128)
{
    int _12395 = NOVALUE;
    int _12394 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_level_22127)) {
        _1 = (long)(DBL_PTR(_level_22127)->dbl);
        DeRefDS(_level_22127);
        _level_22127 = _1;
    }
    if (!IS_ATOM_INT(_optname_22128)) {
        _1 = (long)(DBL_PTR(_optname_22128)->dbl);
        DeRefDS(_optname_22128);
        _optname_22128 = _1;
    }

    /** 	return machine_func(M_SOCK_GETSOCKOPT, { sock, level, optname })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22126);
    *((int *)(_2+4)) = _sock_22126;
    *((int *)(_2+8)) = _level_22127;
    *((int *)(_2+12)) = _optname_22128;
    _12394 = MAKE_SEQ(_1);
    _12395 = machine(91, _12394);
    DeRefDS(_12394);
    _12394 = NOVALUE;
    DeRef(_sock_22126);
    return _12395;
    ;
}
int get_option() __attribute__ ((alias ("_48get_option")));


int _48set_option(int _sock_22133, int _level_22134, int _optname_22135, int _val_22136)
{
    int _12397 = NOVALUE;
    int _12396 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_level_22134)) {
        _1 = (long)(DBL_PTR(_level_22134)->dbl);
        DeRefDS(_level_22134);
        _level_22134 = _1;
    }
    if (!IS_ATOM_INT(_optname_22135)) {
        _1 = (long)(DBL_PTR(_optname_22135)->dbl);
        DeRefDS(_optname_22135);
        _optname_22135 = _1;
    }

    /** 	return machine_func(M_SOCK_SETSOCKOPT, { sock, level, optname, val })*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22133);
    *((int *)(_2+4)) = _sock_22133;
    *((int *)(_2+8)) = _level_22134;
    *((int *)(_2+12)) = _optname_22135;
    Ref(_val_22136);
    *((int *)(_2+16)) = _val_22136;
    _12396 = MAKE_SEQ(_1);
    _12397 = machine(90, _12396);
    DeRefDS(_12396);
    _12396 = NOVALUE;
    DeRef(_sock_22133);
    DeRef(_val_22136);
    return _12397;
    ;
}
int set_option() __attribute__ ((alias ("_48set_option")));


int _48connect(int _sock_22141, int _address_22142, int _port_22143)
{
    int _sock_data_22145 = NOVALUE;
    int _12403 = NOVALUE;
    int _12402 = NOVALUE;
    int _12401 = NOVALUE;
    int _12400 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22143)) {
        _1 = (long)(DBL_PTR(_port_22143)->dbl);
        DeRefDS(_port_22143);
        _port_22143 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22142);
    _0 = _sock_data_22145;
    _sock_data_22145 = _49parse_ip_address(_address_22142, _port_22143);
    DeRef(_0);

    /** 	return machine_func(M_SOCK_CONNECT, { sock, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22145);
    _12400 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22145);
    _12401 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22141);
    *((int *)(_2+4)) = _sock_22141;
    Ref(_12400);
    *((int *)(_2+8)) = _12400;
    Ref(_12401);
    *((int *)(_2+12)) = _12401;
    _12402 = MAKE_SEQ(_1);
    _12401 = NOVALUE;
    _12400 = NOVALUE;
    _12403 = machine(84, _12402);
    DeRefDS(_12402);
    _12402 = NOVALUE;
    DeRef(_sock_22141);
    DeRefDS(_address_22142);
    DeRef(_sock_data_22145);
    return _12403;
    ;
}
int connect() __attribute__ ((alias ("_48connect")));


int _48bind(int _sock_22153, int _address_22154, int _port_22155)
{
    int _sock_data_22156 = NOVALUE;
    int _12408 = NOVALUE;
    int _12407 = NOVALUE;
    int _12406 = NOVALUE;
    int _12405 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22155)) {
        _1 = (long)(DBL_PTR(_port_22155)->dbl);
        DeRefDS(_port_22155);
        _port_22155 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22154);
    _0 = _sock_data_22156;
    _sock_data_22156 = _49parse_ip_address(_address_22154, _port_22155);
    DeRef(_0);

    /** 	return machine_func(M_SOCK_BIND, { sock, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22156);
    _12405 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22156);
    _12406 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22153);
    *((int *)(_2+4)) = _sock_22153;
    Ref(_12405);
    *((int *)(_2+8)) = _12405;
    Ref(_12406);
    *((int *)(_2+12)) = _12406;
    _12407 = MAKE_SEQ(_1);
    _12406 = NOVALUE;
    _12405 = NOVALUE;
    _12408 = machine(87, _12407);
    DeRefDS(_12407);
    _12407 = NOVALUE;
    DeRef(_sock_22153);
    DeRefDS(_address_22154);
    DeRef(_sock_data_22156);
    return _12408;
    ;
}
int bind() __attribute__ ((alias ("_48bind")));


int _48listen(int _sock_22164, int _backlog_22165)
{
    int _12410 = NOVALUE;
    int _12409 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_backlog_22165)) {
        _1 = (long)(DBL_PTR(_backlog_22165)->dbl);
        DeRefDS(_backlog_22165);
        _backlog_22165 = _1;
    }

    /** 	return machine_func(M_SOCK_LISTEN, { sock, backlog })*/
    Ref(_sock_22164);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22164;
    ((int *)_2)[2] = _backlog_22165;
    _12409 = MAKE_SEQ(_1);
    _12410 = machine(88, _12409);
    DeRefDS(_12409);
    _12409 = NOVALUE;
    DeRef(_sock_22164);
    return _12410;
    ;
}
int listen() __attribute__ ((alias ("_48listen")));


int _48accept(int _sock_22170)
{
    int _12412 = NOVALUE;
    int _12411 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_ACCEPT, { sock })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22170);
    *((int *)(_2+4)) = _sock_22170;
    _12411 = MAKE_SEQ(_1);
    _12412 = machine(89, _12411);
    DeRefDS(_12411);
    _12411 = NOVALUE;
    DeRef(_sock_22170);
    return _12412;
    ;
}
int accept() __attribute__ ((alias ("_48accept")));


int _48send_to(int _sock_22175, int _data_22176, int _address_22177, int _port_22178, int _flags_22179)
{
    int _sock_data_22180 = NOVALUE;
    int _12417 = NOVALUE;
    int _12416 = NOVALUE;
    int _12415 = NOVALUE;
    int _12414 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22178)) {
        _1 = (long)(DBL_PTR(_port_22178)->dbl);
        DeRefDS(_port_22178);
        _port_22178 = _1;
    }

    /** 	object sock_data = common:parse_ip_address(address, port)*/
    RefDS(_address_22177);
    _0 = _sock_data_22180;
    _sock_data_22180 = _49parse_ip_address(_address_22177, _port_22178);
    DeRef(_0);

    /**     return machine_func(M_SOCK_SENDTO, { sock, data, flags, sock_data[1], sock_data[2] })*/
    _2 = (int)SEQ_PTR(_sock_data_22180);
    _12414 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sock_data_22180);
    _12415 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sock_22175);
    *((int *)(_2+4)) = _sock_22175;
    RefDS(_data_22176);
    *((int *)(_2+8)) = _data_22176;
    Ref(_flags_22179);
    *((int *)(_2+12)) = _flags_22179;
    Ref(_12414);
    *((int *)(_2+16)) = _12414;
    Ref(_12415);
    *((int *)(_2+20)) = _12415;
    _12416 = MAKE_SEQ(_1);
    _12415 = NOVALUE;
    _12414 = NOVALUE;
    _12417 = machine(93, _12416);
    DeRefDS(_12416);
    _12416 = NOVALUE;
    DeRef(_sock_22175);
    DeRefDS(_data_22176);
    DeRefDS(_address_22177);
    DeRef(_flags_22179);
    DeRef(_sock_data_22180);
    return _12417;
    ;
}
int send_to() __attribute__ ((alias ("_48send_to")));


int _48receive_from(int _sock_22188, int _flags_22189)
{
    int _12419 = NOVALUE;
    int _12418 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_SOCK_RECVFROM, { sock, flags })*/
    Ref(_flags_22189);
    Ref(_sock_22188);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sock_22188;
    ((int *)_2)[2] = _flags_22189;
    _12418 = MAKE_SEQ(_1);
    _12419 = machine(94, _12418);
    DeRefDS(_12418);
    _12418 = NOVALUE;
    DeRef(_sock_22188);
    DeRef(_flags_22189);
    return _12419;
    ;
}
int receive_from() __attribute__ ((alias ("_48receive_from")));


int _48service_by_name(int _name_22194, int _protocol_22195)
{
    int _12421 = NOVALUE;
    int _12420 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETSERVBYNAME, { name, protocol })*/
    Ref(_protocol_22195);
    RefDS(_name_22194);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_22194;
    ((int *)_2)[2] = _protocol_22195;
    _12420 = MAKE_SEQ(_1);
    _12421 = machine(77, _12420);
    DeRefDS(_12420);
    _12420 = NOVALUE;
    DeRefDS(_name_22194);
    DeRef(_protocol_22195);
    return _12421;
    ;
}
int service_by_name() __attribute__ ((alias ("_48service_by_name")));


int _48service_by_port(int _port_22200, int _protocol_22201)
{
    int _12423 = NOVALUE;
    int _12422 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_22200)) {
        _1 = (long)(DBL_PTR(_port_22200)->dbl);
        DeRefDS(_port_22200);
        _port_22200 = _1;
    }

    /** 	return machine_func(M_SOCK_GETSERVBYPORT, { port, protocol })*/
    Ref(_protocol_22201);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _port_22200;
    ((int *)_2)[2] = _protocol_22201;
    _12422 = MAKE_SEQ(_1);
    _12423 = machine(78, _12422);
    DeRefDS(_12422);
    _12422 = NOVALUE;
    DeRef(_protocol_22201);
    return _12423;
    ;
}
int service_by_port() __attribute__ ((alias ("_48service_by_port")));


int _48info(int _Type_22206)
{
    int _12424 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_Type_22206)) {
        _1 = (long)(DBL_PTR(_Type_22206)->dbl);
        DeRefDS(_Type_22206);
        _Type_22206 = _1;
    }

    /** 	return machine_func(M_SOCK_INFO, Type)*/
    _12424 = machine(4, _Type_22206);
    return _12424;
    ;
}
int info() __attribute__ ((alias ("_48info")));



// 0x86414368
