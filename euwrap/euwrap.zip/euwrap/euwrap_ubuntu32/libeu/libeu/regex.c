// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _47regex(int _o_21094)
{
    int _11943 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _11943 = IS_SEQUENCE(_o_21094);
    DeRef(_o_21094);
    return _11943;
    ;
}
int regex() __attribute__ ((alias ("_47regex")));


int _47option_spec(int _o_21098)
{
    int _11950 = NOVALUE;
    int _11949 = NOVALUE;
    int _11947 = NOVALUE;
    int _11945 = NOVALUE;
    int _11944 = NOVALUE;
    int _0, _1, _2;
    
L1: 

    /** 	if atom(o) then*/
    _11944 = IS_ATOM(_o_21098);
    if (_11944 == 0)
    {
        _11944 = NOVALUE;
        goto L2; // [6] 60
    }
    else{
        _11944 = NOVALUE;
    }

    /** 		if not integer(o) then*/
    if (IS_ATOM_INT(_o_21098))
    _11945 = 1;
    else if (IS_ATOM_DBL(_o_21098))
    _11945 = IS_ATOM_INT(DoubleToInt(_o_21098));
    else
    _11945 = 0;
    if (_11945 != 0)
    goto L3; // [14] 26
    _11945 = NOVALUE;

    /** 			return 0*/
    DeRef(_o_21098);
    return 0;
    goto L4; // [23] 89
L3: 

    /** 			if (or_bits(o,all_options) != all_options) then*/
    if (IS_ATOM_INT(_o_21098) && IS_ATOM_INT(_47all_options_21089)) {
        {unsigned long tu;
             tu = (unsigned long)_o_21098 | (unsigned long)_47all_options_21089;
             _11947 = MAKE_UINT(tu);
        }
    }
    else {
        _11947 = binary_op(OR_BITS, _o_21098, _47all_options_21089);
    }
    if (binary_op_a(EQUALS, _11947, _47all_options_21089)){
        DeRef(_11947);
        _11947 = NOVALUE;
        goto L5; // [36] 49
    }
    DeRef(_11947);
    _11947 = NOVALUE;

    /** 				return 0*/
    DeRef(_o_21098);
    return 0;
    goto L4; // [46] 89
L5: 

    /** 				return 1*/
    DeRef(_o_21098);
    return 1;
    goto L4; // [57] 89
L2: 

    /** 	elsif integer_array(o) then*/
    Ref(_o_21098);
    _11949 = _7integer_array(_o_21098);
    if (_11949 == 0) {
        DeRef(_11949);
        _11949 = NOVALUE;
        goto L6; // [66] 82
    }
    else {
        if (!IS_ATOM_INT(_11949) && DBL_PTR(_11949)->dbl == 0.0){
            DeRef(_11949);
            _11949 = NOVALUE;
            goto L6; // [66] 82
        }
        DeRef(_11949);
        _11949 = NOVALUE;
    }
    DeRef(_11949);
    _11949 = NOVALUE;

    /** 		return option_spec( math:or_all(o) )*/
    Ref(_o_21098);
    _11950 = _20or_all(_o_21098);
    _0 = _o_21098;
    _o_21098 = _11950;
    Ref(_o_21098);
    DeRef(_0);
    DeRef(_11950);
    _11950 = NOVALUE;
    goto L1; // [75] 1
    goto L4; // [79] 89
L6: 

    /** 		return 0*/
    DeRef(_o_21098);
    return 0;
L4: 
    ;
}
int option_spec() __attribute__ ((alias ("_47option_spec")));


int _47option_spec_to_string(int _o_21117)
{
    int _11952 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return flags:flags_to_string(o, option_names)*/
    Ref(_o_21117);
    RefDS(_47option_names_20940);
    _11952 = _39flags_to_string(_o_21117, _47option_names_20940, 0);
    DeRef(_o_21117);
    return _11952;
    ;
}
int option_spec_to_string() __attribute__ ((alias ("_47option_spec_to_string")));


int _47error_to_string(int _i_21121)
{
    int _11959 = NOVALUE;
    int _11957 = NOVALUE;
    int _11956 = NOVALUE;
    int _11955 = NOVALUE;
    int _11953 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_21121)) {
        _1 = (long)(DBL_PTR(_i_21121)->dbl);
        DeRefDS(_i_21121);
        _i_21121 = _1;
    }

    /** 	if i >= 0 or i < -23 then*/
    _11953 = (_i_21121 >= 0);
    if (_11953 != 0) {
        goto L1; // [9] 22
    }
    _11955 = (_i_21121 < -23);
    if (_11955 == 0)
    {
        DeRef(_11955);
        _11955 = NOVALUE;
        goto L2; // [18] 39
    }
    else{
        DeRef(_11955);
        _11955 = NOVALUE;
    }
L1: 

    /** 		return sprintf("%d",{i})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _i_21121;
    _11956 = MAKE_SEQ(_1);
    _11957 = EPrintf(-9999999, _11525, _11956);
    DeRefDS(_11956);
    _11956 = NOVALUE;
    DeRef(_11953);
    _11953 = NOVALUE;
    return _11957;
    goto L3; // [36] 56
L2: 

    /** 		return search:vlookup(i, error_names, 1, 2, "Unknown Error")*/
    RefDS(_47error_names_21040);
    RefDS(_11958);
    _11959 = _9vlookup(_i_21121, _47error_names_21040, 1, 2, _11958);
    DeRef(_11953);
    _11953 = NOVALUE;
    DeRef(_11957);
    _11957 = NOVALUE;
    return _11959;
L3: 
    ;
}
int error_to_string() __attribute__ ((alias ("_47error_to_string")));


int _47new(int _pattern_21134, int _options_21135)
{
    int _11963 = NOVALUE;
    int _11962 = NOVALUE;
    int _11960 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _11960 = IS_SEQUENCE(_options_21135);
    if (_11960 == 0)
    {
        _11960 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _11960 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21135);
    _0 = _options_21135;
    _options_21135 = _20or_all(_options_21135);
    DeRef(_0);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21135);
    Ref(_pattern_21134);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21134;
    ((int *)_2)[2] = _options_21135;
    _11962 = MAKE_SEQ(_1);
    _11963 = machine(68, _11962);
    DeRefDS(_11962);
    _11962 = NOVALUE;
    DeRef(_pattern_21134);
    DeRef(_options_21135);
    return _11963;
    ;
}


int _47error_message(int _re_21143)
{
    int _11965 = NOVALUE;
    int _11964 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_PCRE_ERROR_MESSAGE, { re })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21143);
    *((int *)(_2+4)) = _re_21143;
    _11964 = MAKE_SEQ(_1);
    _11965 = machine(95, _11964);
    DeRefDS(_11964);
    _11964 = NOVALUE;
    DeRef(_re_21143);
    return _11965;
    ;
}
int error_message() __attribute__ ((alias ("_47error_message")));


int _47escape(int _s_21149)
{
    int _11967 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:escape(s, ".\\+*?[^]$(){}=!<>|:-")*/
    Ref(_s_21149);
    RefDS(_11966);
    _11967 = _6escape(_s_21149, _11966);
    DeRef(_s_21149);
    return _11967;
    ;
}


int _47get_ovector_size(int _ex_21154, int _maxsize_21155)
{
    int _m_21156 = NOVALUE;
    int _11971 = NOVALUE;
    int _11968 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_maxsize_21155)) {
        _1 = (long)(DBL_PTR(_maxsize_21155)->dbl);
        DeRefDS(_maxsize_21155);
        _maxsize_21155 = _1;
    }

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21154);
    *((int *)(_2+4)) = _ex_21154;
    _11968 = MAKE_SEQ(_1);
    _m_21156 = machine(97, _11968);
    DeRefDS(_11968);
    _11968 = NOVALUE;
    if (!IS_ATOM_INT(_m_21156)) {
        _1 = (long)(DBL_PTR(_m_21156)->dbl);
        DeRefDS(_m_21156);
        _m_21156 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21156 <= _maxsize_21155)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21154);
    return _maxsize_21155;
L1: 

    /** 	return m+1*/
    _11971 = _m_21156 + 1;
    if (_11971 > MAXINT){
        _11971 = NewDouble((double)_11971);
    }
    DeRef(_ex_21154);
    return _11971;
    ;
}


int _47find(int _re_21164, int _haystack_21166, int _from_21167, int _options_21168, int _size_21169)
{
    int _11978 = NOVALUE;
    int _11977 = NOVALUE;
    int _11976 = NOVALUE;
    int _11973 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21167)) {
        _1 = (long)(DBL_PTR(_from_21167)->dbl);
        DeRefDS(_from_21167);
        _from_21167 = _1;
    }
    if (!IS_ATOM_INT(_size_21169)) {
        _1 = (long)(DBL_PTR(_size_21169)->dbl);
        DeRefDS(_size_21169);
        _size_21169 = _1;
    }

    /** 	if sequence(options) then */
    _11973 = IS_SEQUENCE(_options_21168);
    if (_11973 == 0)
    {
        _11973 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _11973 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21168);
    _0 = _options_21168;
    _options_21168 = _20or_all(_options_21168);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21169 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21169 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21166)){
            _11976 = SEQ_PTR(_haystack_21166)->length;
    }
    else {
        _11976 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21164);
    *((int *)(_2+4)) = _re_21164;
    Ref(_haystack_21166);
    *((int *)(_2+8)) = _haystack_21166;
    *((int *)(_2+12)) = _11976;
    Ref(_options_21168);
    *((int *)(_2+16)) = _options_21168;
    *((int *)(_2+20)) = _from_21167;
    *((int *)(_2+24)) = _size_21169;
    _11977 = MAKE_SEQ(_1);
    _11976 = NOVALUE;
    _11978 = machine(70, _11977);
    DeRefDS(_11977);
    _11977 = NOVALUE;
    DeRef(_re_21164);
    DeRef(_haystack_21166);
    DeRef(_options_21168);
    return _11978;
    ;
}


int _47find_all(int _re_21181, int _haystack_21183, int _from_21184, int _options_21185, int _size_21186)
{
    int _result_21193 = NOVALUE;
    int _results_21194 = NOVALUE;
    int _pHaystack_21195 = NOVALUE;
    int _11991 = NOVALUE;
    int _11990 = NOVALUE;
    int _11988 = NOVALUE;
    int _11986 = NOVALUE;
    int _11984 = NOVALUE;
    int _11980 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21184)) {
        _1 = (long)(DBL_PTR(_from_21184)->dbl);
        DeRefDS(_from_21184);
        _from_21184 = _1;
    }
    if (!IS_ATOM_INT(_size_21186)) {
        _1 = (long)(DBL_PTR(_size_21186)->dbl);
        DeRefDS(_size_21186);
        _size_21186 = _1;
    }

    /** 	if sequence(options) then */
    _11980 = IS_SEQUENCE(_options_21185);
    if (_11980 == 0)
    {
        _11980 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _11980 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21185);
    _0 = _options_21185;
    _options_21185 = _20or_all(_options_21185);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21186 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21186 = 0;
L2: 

    /** 	object result*/

    /** 	sequence results = {}*/
    RefDS(_5);
    DeRef(_results_21194);
    _results_21194 = _5;

    /** 	atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_21183);
    _0 = _pHaystack_21195;
    _pHaystack_21195 = _14allocate_string(_haystack_21183, 0);
    DeRef(_0);

    /** 	while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _11984 = IS_SEQUENCE(_result_21193);
    if (_11984 == 0)
    {
        _11984 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _11984 = NOVALUE;
    }

    /** 		results = append(results, result)*/
    Ref(_result_21193);
    Append(&_results_21194, _results_21194, _result_21193);

    /** 		from = math:max(result) + 1*/
    Ref(_result_21193);
    _11986 = _20max(_result_21193);
    if (IS_ATOM_INT(_11986)) {
        _from_21184 = _11986 + 1;
    }
    else
    { // coercing _from_21184 to an integer 1
        _from_21184 = 1+(long)(DBL_PTR(_11986)->dbl);
        if( !IS_ATOM_INT(_from_21184) ){
            _from_21184 = (object)DBL_PTR(_from_21184)->dbl;
        }
    }
    DeRef(_11986);
    _11986 = NOVALUE;

    /** 		if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_21183)){
            _11988 = SEQ_PTR(_haystack_21183)->length;
    }
    else {
        _11988 = 1;
    }
    if (_from_21184 <= _11988)
    goto L6; // [82] 91

    /** 			exit*/
    goto L5; // [88] 117
L6: 

    /** 	entry*/
L3: 

    /** 		result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21183)){
            _11990 = SEQ_PTR(_haystack_21183)->length;
    }
    else {
        _11990 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21181);
    *((int *)(_2+4)) = _re_21181;
    Ref(_pHaystack_21195);
    *((int *)(_2+8)) = _pHaystack_21195;
    *((int *)(_2+12)) = _11990;
    Ref(_options_21185);
    *((int *)(_2+16)) = _options_21185;
    *((int *)(_2+20)) = _from_21184;
    *((int *)(_2+24)) = _size_21186;
    _11991 = MAKE_SEQ(_1);
    _11990 = NOVALUE;
    DeRef(_result_21193);
    _result_21193 = machine(70, _11991);
    DeRefDS(_11991);
    _11991 = NOVALUE;

    /** 	end while*/
    goto L4; // [114] 53
L5: 

    /** 	machine:free(pHaystack)*/
    Ref(_pHaystack_21195);
    _14free(_pHaystack_21195);

    /** 	return results*/
    DeRef(_re_21181);
    DeRef(_haystack_21183);
    DeRef(_options_21185);
    DeRef(_result_21193);
    DeRef(_pHaystack_21195);
    return _results_21194;
    ;
}


int _47has_match(int _re_21210, int _haystack_21212, int _from_21213, int _options_21214)
{
    int _11995 = NOVALUE;
    int _11994 = NOVALUE;
    int _11993 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21213)) {
        _1 = (long)(DBL_PTR(_from_21213)->dbl);
        DeRefDS(_from_21213);
        _from_21213 = _1;
    }

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21210);
    _11993 = _47get_ovector_size(_re_21210, 30);
    Ref(_re_21210);
    Ref(_haystack_21212);
    Ref(_options_21214);
    _11994 = _47find(_re_21210, _haystack_21212, _from_21213, _options_21214, _11993);
    _11993 = NOVALUE;
    _11995 = IS_SEQUENCE(_11994);
    DeRef(_11994);
    _11994 = NOVALUE;
    DeRef(_re_21210);
    DeRef(_haystack_21212);
    DeRef(_options_21214);
    return _11995;
    ;
}
int has_match() __attribute__ ((alias ("_47has_match")));


int _47is_match(int _re_21220, int _haystack_21222, int _from_21223, int _options_21224)
{
    int _m_21225 = NOVALUE;
    int _12010 = NOVALUE;
    int _12009 = NOVALUE;
    int _12008 = NOVALUE;
    int _12007 = NOVALUE;
    int _12006 = NOVALUE;
    int _12005 = NOVALUE;
    int _12004 = NOVALUE;
    int _12003 = NOVALUE;
    int _12002 = NOVALUE;
    int _12001 = NOVALUE;
    int _12000 = NOVALUE;
    int _11999 = NOVALUE;
    int _11998 = NOVALUE;
    int _11996 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21223)) {
        _1 = (long)(DBL_PTR(_from_21223)->dbl);
        DeRefDS(_from_21223);
        _from_21223 = _1;
    }

    /** 	object m = find(re, haystack, from, options)*/
    Ref(_re_21220);
    _11996 = _47get_ovector_size(_re_21220, 30);
    Ref(_re_21220);
    Ref(_haystack_21222);
    Ref(_options_21224);
    _0 = _m_21225;
    _m_21225 = _47find(_re_21220, _haystack_21222, _from_21223, _options_21224, _11996);
    DeRef(_0);
    _11996 = NOVALUE;

    /** 	if sequence(m) and length(m) > 0 and m[1][1] = from and m[1][2] = length(haystack) then*/
    _11998 = IS_SEQUENCE(_m_21225);
    if (_11998 == 0) {
        _11999 = 0;
        goto L1; // [23] 38
    }
    if (IS_SEQUENCE(_m_21225)){
            _12000 = SEQ_PTR(_m_21225)->length;
    }
    else {
        _12000 = 1;
    }
    _12001 = (_12000 > 0);
    _12000 = NOVALUE;
    _11999 = (_12001 != 0);
L1: 
    if (_11999 == 0) {
        _12002 = 0;
        goto L2; // [38] 58
    }
    _2 = (int)SEQ_PTR(_m_21225);
    _12003 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_12003);
    _12004 = (int)*(((s1_ptr)_2)->base + 1);
    _12003 = NOVALUE;
    if (IS_ATOM_INT(_12004)) {
        _12005 = (_12004 == _from_21223);
    }
    else {
        _12005 = binary_op(EQUALS, _12004, _from_21223);
    }
    _12004 = NOVALUE;
    if (IS_ATOM_INT(_12005))
    _12002 = (_12005 != 0);
    else
    _12002 = DBL_PTR(_12005)->dbl != 0.0;
L2: 
    if (_12002 == 0) {
        goto L3; // [58] 88
    }
    _2 = (int)SEQ_PTR(_m_21225);
    _12007 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_12007);
    _12008 = (int)*(((s1_ptr)_2)->base + 2);
    _12007 = NOVALUE;
    if (IS_SEQUENCE(_haystack_21222)){
            _12009 = SEQ_PTR(_haystack_21222)->length;
    }
    else {
        _12009 = 1;
    }
    if (IS_ATOM_INT(_12008)) {
        _12010 = (_12008 == _12009);
    }
    else {
        _12010 = binary_op(EQUALS, _12008, _12009);
    }
    _12008 = NOVALUE;
    _12009 = NOVALUE;
    if (_12010 == 0) {
        DeRef(_12010);
        _12010 = NOVALUE;
        goto L3; // [78] 88
    }
    else {
        if (!IS_ATOM_INT(_12010) && DBL_PTR(_12010)->dbl == 0.0){
            DeRef(_12010);
            _12010 = NOVALUE;
            goto L3; // [78] 88
        }
        DeRef(_12010);
        _12010 = NOVALUE;
    }
    DeRef(_12010);
    _12010 = NOVALUE;

    /** 		return 1*/
    DeRef(_re_21220);
    DeRef(_haystack_21222);
    DeRef(_options_21224);
    DeRef(_m_21225);
    DeRef(_12001);
    _12001 = NOVALUE;
    DeRef(_12005);
    _12005 = NOVALUE;
    return 1;
L3: 

    /** 	return 0*/
    DeRef(_re_21220);
    DeRef(_haystack_21222);
    DeRef(_options_21224);
    DeRef(_m_21225);
    DeRef(_12001);
    _12001 = NOVALUE;
    DeRef(_12005);
    _12005 = NOVALUE;
    return 0;
    ;
}


int _47matches(int _re_21244, int _haystack_21246, int _from_21247, int _options_21248)
{
    int _str_offsets_21252 = NOVALUE;
    int _match_data_21254 = NOVALUE;
    int _tmp_21264 = NOVALUE;
    int _12032 = NOVALUE;
    int _12031 = NOVALUE;
    int _12030 = NOVALUE;
    int _12029 = NOVALUE;
    int _12028 = NOVALUE;
    int _12026 = NOVALUE;
    int _12025 = NOVALUE;
    int _12024 = NOVALUE;
    int _12023 = NOVALUE;
    int _12021 = NOVALUE;
    int _12020 = NOVALUE;
    int _12019 = NOVALUE;
    int _12018 = NOVALUE;
    int _12016 = NOVALUE;
    int _12015 = NOVALUE;
    int _12014 = NOVALUE;
    int _12011 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21247)) {
        _1 = (long)(DBL_PTR(_from_21247)->dbl);
        DeRefDS(_from_21247);
        _from_21247 = _1;
    }

    /** 	if sequence(options) then */
    _12011 = IS_SEQUENCE(_options_21248);
    if (_12011 == 0)
    {
        _12011 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12011 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21248);
    _0 = _options_21248;
    _options_21248 = _20or_all(_options_21248);
    DeRef(_0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21248)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21248;
             _str_offsets_21252 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21252 = binary_op(AND_BITS, 201326592, _options_21248);
    }
    if (!IS_ATOM_INT(_str_offsets_21252)) {
        _1 = (long)(DBL_PTR(_str_offsets_21252)->dbl);
        DeRefDS(_str_offsets_21252);
        _str_offsets_21252 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12014 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21248) && IS_ATOM_INT(_12014)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21248 & (unsigned long)_12014;
             _12015 = MAKE_UINT(tu);
        }
    }
    else {
        _12015 = binary_op(AND_BITS, _options_21248, _12014);
    }
    DeRef(_12014);
    _12014 = NOVALUE;
    Ref(_re_21244);
    _12016 = _47get_ovector_size(_re_21244, 30);
    Ref(_re_21244);
    Ref(_haystack_21246);
    _0 = _match_data_21254;
    _match_data_21254 = _47find(_re_21244, _haystack_21246, _from_21247, _12015, _12016);
    DeRef(_0);
    _12015 = NOVALUE;
    _12016 = NOVALUE;

    /** 	if atom(match_data) then */
    _12018 = IS_ATOM(_match_data_21254);
    if (_12018 == 0)
    {
        _12018 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12018 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21244);
    DeRef(_haystack_21246);
    DeRef(_options_21248);
    DeRef(_match_data_21254);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21254)){
            _12019 = SEQ_PTR(_match_data_21254)->length;
    }
    else {
        _12019 = 1;
    }
    {
        int _i_21262;
        _i_21262 = 1;
L3: 
        if (_i_21262 > _12019){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21254);
        _12020 = (int)*(((s1_ptr)_2)->base + _i_21262);
        _2 = (int)SEQ_PTR(_12020);
        _12021 = (int)*(((s1_ptr)_2)->base + 1);
        _12020 = NOVALUE;
        if (binary_op_a(NOTEQ, _12021, 0)){
            _12021 = NOVALUE;
            goto L5; // [87] 101
        }
        _12021 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21264);
        _tmp_21264 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21254);
        _12023 = (int)*(((s1_ptr)_2)->base + _i_21262);
        _2 = (int)SEQ_PTR(_12023);
        _12024 = (int)*(((s1_ptr)_2)->base + 1);
        _12023 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21254);
        _12025 = (int)*(((s1_ptr)_2)->base + _i_21262);
        _2 = (int)SEQ_PTR(_12025);
        _12026 = (int)*(((s1_ptr)_2)->base + 2);
        _12025 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21264;
        RHS_Slice(_haystack_21246, _12024, _12026);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21252 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21254);
        _12028 = (int)*(((s1_ptr)_2)->base + _i_21262);
        _2 = (int)SEQ_PTR(_12028);
        _12029 = (int)*(((s1_ptr)_2)->base + 1);
        _12028 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21254);
        _12030 = (int)*(((s1_ptr)_2)->base + _i_21262);
        _2 = (int)SEQ_PTR(_12030);
        _12031 = (int)*(((s1_ptr)_2)->base + 2);
        _12030 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21264);
        *((int *)(_2+4)) = _tmp_21264;
        Ref(_12029);
        *((int *)(_2+8)) = _12029;
        Ref(_12031);
        *((int *)(_2+12)) = _12031;
        _12032 = MAKE_SEQ(_1);
        _12031 = NOVALUE;
        _12029 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21254);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21254 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21262);
        _1 = *(int *)_2;
        *(int *)_2 = _12032;
        if( _1 != _12032 ){
            DeRef(_1);
        }
        _12032 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21264);
        _2 = (int)SEQ_PTR(_match_data_21254);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21254 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21262);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21264;
        DeRef(_1);
L8: 
        DeRef(_tmp_21264);
        _tmp_21264 = NOVALUE;

        /** 	end for*/
        _i_21262 = _i_21262 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21244);
    DeRef(_haystack_21246);
    DeRef(_options_21248);
    _12024 = NOVALUE;
    _12026 = NOVALUE;
    return _match_data_21254;
    ;
}
int matches() __attribute__ ((alias ("_47matches")));


int _47all_matches(int _re_21284, int _haystack_21286, int _from_21287, int _options_21288)
{
    int _str_offsets_21292 = NOVALUE;
    int _match_data_21294 = NOVALUE;
    int _tmp_21309 = NOVALUE;
    int _a_21310 = NOVALUE;
    int _b_21311 = NOVALUE;
    int _12056 = NOVALUE;
    int _12055 = NOVALUE;
    int _12053 = NOVALUE;
    int _12050 = NOVALUE;
    int _12049 = NOVALUE;
    int _12046 = NOVALUE;
    int _12045 = NOVALUE;
    int _12044 = NOVALUE;
    int _12043 = NOVALUE;
    int _12042 = NOVALUE;
    int _12040 = NOVALUE;
    int _12038 = NOVALUE;
    int _12037 = NOVALUE;
    int _12036 = NOVALUE;
    int _12033 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_from_21287)) {
        _1 = (long)(DBL_PTR(_from_21287)->dbl);
        DeRefDS(_from_21287);
        _from_21287 = _1;
    }

    /** 	if sequence(options) then */
    _12033 = IS_SEQUENCE(_options_21288);
    if (_12033 == 0)
    {
        _12033 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12033 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21288);
    _0 = _options_21288;
    _options_21288 = _20or_all(_options_21288);
    DeRef(_0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21288)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21288;
             _str_offsets_21292 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21292 = binary_op(AND_BITS, 201326592, _options_21288);
    }
    if (!IS_ATOM_INT(_str_offsets_21292)) {
        _1 = (long)(DBL_PTR(_str_offsets_21292)->dbl);
        DeRefDS(_str_offsets_21292);
        _str_offsets_21292 = _1;
    }

    /** 	object match_data = find_all(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12036 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21288) && IS_ATOM_INT(_12036)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21288 & (unsigned long)_12036;
             _12037 = MAKE_UINT(tu);
        }
    }
    else {
        _12037 = binary_op(AND_BITS, _options_21288, _12036);
    }
    DeRef(_12036);
    _12036 = NOVALUE;
    Ref(_re_21284);
    _12038 = _47get_ovector_size(_re_21284, 30);
    Ref(_re_21284);
    Ref(_haystack_21286);
    _0 = _match_data_21294;
    _match_data_21294 = _47find_all(_re_21284, _haystack_21286, _from_21287, _12037, _12038);
    DeRef(_0);
    _12037 = NOVALUE;
    _12038 = NOVALUE;

    /** 	if length(match_data) = 0 then */
    if (IS_SEQUENCE(_match_data_21294)){
            _12040 = SEQ_PTR(_match_data_21294)->length;
    }
    else {
        _12040 = 1;
    }
    if (_12040 != 0)
    goto L2; // [53] 64

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21284);
    DeRef(_haystack_21286);
    DeRef(_options_21288);
    DeRef(_match_data_21294);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21294)){
            _12042 = SEQ_PTR(_match_data_21294)->length;
    }
    else {
        _12042 = 1;
    }
    {
        int _i_21303;
        _i_21303 = 1;
L3: 
        if (_i_21303 > _12042){
            goto L4; // [69] 211
        }

        /** 		for j = 1 to length(match_data[i]) do*/
        _2 = (int)SEQ_PTR(_match_data_21294);
        _12043 = (int)*(((s1_ptr)_2)->base + _i_21303);
        if (IS_SEQUENCE(_12043)){
                _12044 = SEQ_PTR(_12043)->length;
        }
        else {
            _12044 = 1;
        }
        _12043 = NOVALUE;
        {
            int _j_21306;
            _j_21306 = 1;
L5: 
            if (_j_21306 > _12044){
                goto L6; // [85] 204
            }

            /** 			sequence tmp*/

            /** 			integer a,b*/

            /** 			a = match_data[i][j][1]*/
            _2 = (int)SEQ_PTR(_match_data_21294);
            _12045 = (int)*(((s1_ptr)_2)->base + _i_21303);
            _2 = (int)SEQ_PTR(_12045);
            _12046 = (int)*(((s1_ptr)_2)->base + _j_21306);
            _12045 = NOVALUE;
            _2 = (int)SEQ_PTR(_12046);
            _a_21310 = (int)*(((s1_ptr)_2)->base + 1);
            if (!IS_ATOM_INT(_a_21310)){
                _a_21310 = (long)DBL_PTR(_a_21310)->dbl;
            }
            _12046 = NOVALUE;

            /** 			if a = 0 then*/
            if (_a_21310 != 0)
            goto L7; // [114] 128

            /** 				tmp = ""*/
            RefDS(_5);
            DeRef(_tmp_21309);
            _tmp_21309 = _5;
            goto L8; // [125] 152
L7: 

            /** 				b = match_data[i][j][2]*/
            _2 = (int)SEQ_PTR(_match_data_21294);
            _12049 = (int)*(((s1_ptr)_2)->base + _i_21303);
            _2 = (int)SEQ_PTR(_12049);
            _12050 = (int)*(((s1_ptr)_2)->base + _j_21306);
            _12049 = NOVALUE;
            _2 = (int)SEQ_PTR(_12050);
            _b_21311 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_b_21311)){
                _b_21311 = (long)DBL_PTR(_b_21311)->dbl;
            }
            _12050 = NOVALUE;

            /** 				tmp = haystack[a..b]*/
            rhs_slice_target = (object_ptr)&_tmp_21309;
            RHS_Slice(_haystack_21286, _a_21310, _b_21311);
L8: 

            /** 			if str_offsets then*/
            if (_str_offsets_21292 == 0)
            {
                goto L9; // [154] 181
            }
            else{
            }

            /** 				match_data[i][j] = { tmp, a, b }*/
            _2 = (int)SEQ_PTR(_match_data_21294);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _match_data_21294 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_21303 + ((s1_ptr)_2)->base);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_tmp_21309);
            *((int *)(_2+4)) = _tmp_21309;
            *((int *)(_2+8)) = _a_21310;
            *((int *)(_2+12)) = _b_21311;
            _12055 = MAKE_SEQ(_1);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21306);
            _1 = *(int *)_2;
            *(int *)_2 = _12055;
            if( _1 != _12055 ){
                DeRef(_1);
            }
            _12055 = NOVALUE;
            _12053 = NOVALUE;
            goto LA; // [178] 195
L9: 

            /** 				match_data[i][j] = tmp*/
            _2 = (int)SEQ_PTR(_match_data_21294);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _match_data_21294 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_21303 + ((s1_ptr)_2)->base);
            RefDS(_tmp_21309);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21306);
            _1 = *(int *)_2;
            *(int *)_2 = _tmp_21309;
            DeRef(_1);
            _12056 = NOVALUE;
LA: 
            DeRef(_tmp_21309);
            _tmp_21309 = NOVALUE;

            /** 		end for*/
            _j_21306 = _j_21306 + 1;
            goto L5; // [199] 92
L6: 
            ;
        }

        /** 	end for*/
        _i_21303 = _i_21303 + 1;
        goto L3; // [206] 76
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21284);
    DeRef(_haystack_21286);
    DeRef(_options_21288);
    _12043 = NOVALUE;
    return _match_data_21294;
    ;
}
int all_matches() __attribute__ ((alias ("_47all_matches")));


int _47split(int _re_21331, int _text_21333, int _from_21334, int _options_21335)
{
    int _12058 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21334)) {
        _1 = (long)(DBL_PTR(_from_21334)->dbl);
        DeRefDS(_from_21334);
        _from_21334 = _1;
    }

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_re_21331);
    Ref(_text_21333);
    Ref(_options_21335);
    _12058 = _47split_limit(_re_21331, _text_21333, 0, _from_21334, _options_21335);
    DeRef(_re_21331);
    DeRef(_text_21333);
    DeRef(_options_21335);
    return _12058;
    ;
}


int _47split_limit(int _re_21340, int _text_21342, int _limit_21343, int _from_21344, int _options_21345)
{
    int _match_data_21349 = NOVALUE;
    int _result_21352 = NOVALUE;
    int _last_21353 = NOVALUE;
    int _a_21364 = NOVALUE;
    int _12084 = NOVALUE;
    int _12083 = NOVALUE;
    int _12082 = NOVALUE;
    int _12080 = NOVALUE;
    int _12078 = NOVALUE;
    int _12077 = NOVALUE;
    int _12076 = NOVALUE;
    int _12075 = NOVALUE;
    int _12074 = NOVALUE;
    int _12071 = NOVALUE;
    int _12070 = NOVALUE;
    int _12069 = NOVALUE;
    int _12066 = NOVALUE;
    int _12065 = NOVALUE;
    int _12063 = NOVALUE;
    int _12061 = NOVALUE;
    int _12059 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_21343)) {
        _1 = (long)(DBL_PTR(_limit_21343)->dbl);
        DeRefDS(_limit_21343);
        _limit_21343 = _1;
    }
    if (!IS_ATOM_INT(_from_21344)) {
        _1 = (long)(DBL_PTR(_from_21344)->dbl);
        DeRefDS(_from_21344);
        _from_21344 = _1;
    }

    /** 	if sequence(options) then */
    _12059 = IS_SEQUENCE(_options_21345);
    if (_12059 == 0)
    {
        _12059 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12059 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21345);
    _0 = _options_21345;
    _options_21345 = _20or_all(_options_21345);
    DeRef(_0);
L1: 

    /** 	sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_21340);
    _12061 = _47get_ovector_size(_re_21340, 30);
    Ref(_re_21340);
    Ref(_text_21342);
    Ref(_options_21345);
    _0 = _match_data_21349;
    _match_data_21349 = _47find_all(_re_21340, _text_21342, _from_21344, _options_21345, _12061);
    DeRef(_0);
    _12061 = NOVALUE;

    /** 	integer last = 1*/
    _last_21353 = 1;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12063 = (_limit_21343 == 0);
    if (_12063 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_21349)){
            _12065 = SEQ_PTR(_match_data_21349)->length;
    }
    else {
        _12065 = 1;
    }
    _12066 = (_limit_21343 > _12065);
    _12065 = NOVALUE;
    if (_12066 == 0)
    {
        DeRef(_12066);
        _12066 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12066);
        _12066 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21349)){
            _limit_21343 = SEQ_PTR(_match_data_21349)->length;
    }
    else {
        _limit_21343 = 1;
    }
L3: 

    /** 	result = repeat(0, limit)*/
    DeRef(_result_21352);
    _result_21352 = Repeat(0, _limit_21343);

    /** 	for i = 1 to limit do*/
    _12069 = _limit_21343;
    {
        int _i_21362;
        _i_21362 = 1;
L4: 
        if (_i_21362 > _12069){
            goto L5; // [81] 164
        }

        /** 		integer a*/

        /** 		a = match_data[i][1][1]*/
        _2 = (int)SEQ_PTR(_match_data_21349);
        _12070 = (int)*(((s1_ptr)_2)->base + _i_21362);
        _2 = (int)SEQ_PTR(_12070);
        _12071 = (int)*(((s1_ptr)_2)->base + 1);
        _12070 = NOVALUE;
        _2 = (int)SEQ_PTR(_12071);
        _a_21364 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_a_21364)){
            _a_21364 = (long)DBL_PTR(_a_21364)->dbl;
        }
        _12071 = NOVALUE;

        /** 		if a = 0 then*/
        if (_a_21364 != 0)
        goto L6; // [108] 121

        /** 			result[i] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_result_21352);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21352 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21362);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** 			result[i] = text[last..a - 1]*/
        _12074 = _a_21364 - 1;
        rhs_slice_target = (object_ptr)&_12075;
        RHS_Slice(_text_21342, _last_21353, _12074);
        _2 = (int)SEQ_PTR(_result_21352);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21352 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21362);
        _1 = *(int *)_2;
        *(int *)_2 = _12075;
        if( _1 != _12075 ){
            DeRef(_1);
        }
        _12075 = NOVALUE;

        /** 			last = match_data[i][1][2] + 1*/
        _2 = (int)SEQ_PTR(_match_data_21349);
        _12076 = (int)*(((s1_ptr)_2)->base + _i_21362);
        _2 = (int)SEQ_PTR(_12076);
        _12077 = (int)*(((s1_ptr)_2)->base + 1);
        _12076 = NOVALUE;
        _2 = (int)SEQ_PTR(_12077);
        _12078 = (int)*(((s1_ptr)_2)->base + 2);
        _12077 = NOVALUE;
        if (IS_ATOM_INT(_12078)) {
            _last_21353 = _12078 + 1;
        }
        else
        { // coercing _last_21353 to an integer 1
            _last_21353 = 1+(long)(DBL_PTR(_12078)->dbl);
            if( !IS_ATOM_INT(_last_21353) ){
                _last_21353 = (object)DBL_PTR(_last_21353)->dbl;
            }
        }
        _12078 = NOVALUE;
L7: 

        /** 	end for*/
        _i_21362 = _i_21362 + 1;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** 	if last < length(text) then*/
    if (IS_SEQUENCE(_text_21342)){
            _12080 = SEQ_PTR(_text_21342)->length;
    }
    else {
        _12080 = 1;
    }
    if (_last_21353 >= _12080)
    goto L8; // [169] 192

    /** 		result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_21342)){
            _12082 = SEQ_PTR(_text_21342)->length;
    }
    else {
        _12082 = 1;
    }
    rhs_slice_target = (object_ptr)&_12083;
    RHS_Slice(_text_21342, _last_21353, _12082);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12083;
    _12084 = MAKE_SEQ(_1);
    _12083 = NOVALUE;
    Concat((object_ptr)&_result_21352, _result_21352, _12084);
    DeRefDS(_12084);
    _12084 = NOVALUE;
L8: 

    /** 	return result*/
    DeRef(_re_21340);
    DeRef(_text_21342);
    DeRef(_options_21345);
    DeRef(_match_data_21349);
    DeRef(_12063);
    _12063 = NOVALUE;
    DeRef(_12074);
    _12074 = NOVALUE;
    return _result_21352;
    ;
}
int split_limit() __attribute__ ((alias ("_47split_limit")));


int _47find_replace(int _ex_21386, int _text_21388, int _replacement_21389, int _from_21390, int _options_21391)
{
    int _12086 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_21390)) {
        _1 = (long)(DBL_PTR(_from_21390)->dbl);
        DeRefDS(_from_21390);
        _from_21390 = _1;
    }

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_21386);
    Ref(_text_21388);
    RefDS(_replacement_21389);
    Ref(_options_21391);
    _12086 = _47find_replace_limit(_ex_21386, _text_21388, _replacement_21389, -1, _from_21390, _options_21391);
    DeRef(_ex_21386);
    DeRef(_text_21388);
    DeRefDS(_replacement_21389);
    DeRef(_options_21391);
    return _12086;
    ;
}


int _47find_replace_limit(int _ex_21396, int _text_21398, int _replacement_21399, int _limit_21400, int _from_21401, int _options_21402)
{
    int _12090 = NOVALUE;
    int _12089 = NOVALUE;
    int _12087 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_21400)) {
        _1 = (long)(DBL_PTR(_limit_21400)->dbl);
        DeRefDS(_limit_21400);
        _limit_21400 = _1;
    }
    if (!IS_ATOM_INT(_from_21401)) {
        _1 = (long)(DBL_PTR(_from_21401)->dbl);
        DeRefDS(_from_21401);
        _from_21401 = _1;
    }

    /** 	if sequence(options) then */
    _12087 = IS_SEQUENCE(_options_21402);
    if (_12087 == 0)
    {
        _12087 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12087 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21402);
    _0 = _options_21402;
    _options_21402 = _20or_all(_options_21402);
    DeRef(_0);
L1: 

    /**     return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21396);
    *((int *)(_2+4)) = _ex_21396;
    Ref(_text_21398);
    *((int *)(_2+8)) = _text_21398;
    RefDS(_replacement_21399);
    *((int *)(_2+12)) = _replacement_21399;
    Ref(_options_21402);
    *((int *)(_2+16)) = _options_21402;
    *((int *)(_2+20)) = _from_21401;
    *((int *)(_2+24)) = _limit_21400;
    _12089 = MAKE_SEQ(_1);
    _12090 = machine(71, _12089);
    DeRefDS(_12089);
    _12089 = NOVALUE;
    DeRef(_ex_21396);
    DeRef(_text_21398);
    DeRefDS(_replacement_21399);
    DeRef(_options_21402);
    return _12090;
    ;
}
int find_replace_limit() __attribute__ ((alias ("_47find_replace_limit")));


int _47find_replace_callback(int _ex_21410, int _text_21412, int _rid_21413, int _limit_21414, int _from_21415, int _options_21416)
{
    int _match_data_21420 = NOVALUE;
    int _replace_data_21423 = NOVALUE;
    int _params_21434 = NOVALUE;
    int _12126 = NOVALUE;
    int _12125 = NOVALUE;
    int _12124 = NOVALUE;
    int _12123 = NOVALUE;
    int _12122 = NOVALUE;
    int _12121 = NOVALUE;
    int _12120 = NOVALUE;
    int _12119 = NOVALUE;
    int _12118 = NOVALUE;
    int _12117 = NOVALUE;
    int _12116 = NOVALUE;
    int _12115 = NOVALUE;
    int _12114 = NOVALUE;
    int _12113 = NOVALUE;
    int _12112 = NOVALUE;
    int _12111 = NOVALUE;
    int _12110 = NOVALUE;
    int _12109 = NOVALUE;
    int _12108 = NOVALUE;
    int _12107 = NOVALUE;
    int _12106 = NOVALUE;
    int _12105 = NOVALUE;
    int _12103 = NOVALUE;
    int _12102 = NOVALUE;
    int _12101 = NOVALUE;
    int _12098 = NOVALUE;
    int _12097 = NOVALUE;
    int _12095 = NOVALUE;
    int _12093 = NOVALUE;
    int _12091 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_21413)) {
        _1 = (long)(DBL_PTR(_rid_21413)->dbl);
        DeRefDS(_rid_21413);
        _rid_21413 = _1;
    }
    if (!IS_ATOM_INT(_limit_21414)) {
        _1 = (long)(DBL_PTR(_limit_21414)->dbl);
        DeRefDS(_limit_21414);
        _limit_21414 = _1;
    }
    if (!IS_ATOM_INT(_from_21415)) {
        _1 = (long)(DBL_PTR(_from_21415)->dbl);
        DeRefDS(_from_21415);
        _from_21415 = _1;
    }

    /** 	if sequence(options) then */
    _12091 = IS_SEQUENCE(_options_21416);
    if (_12091 == 0)
    {
        _12091 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12091 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21416);
    _0 = _options_21416;
    _options_21416 = _20or_all(_options_21416);
    DeRef(_0);
L1: 

    /** 	sequence match_data = find_all(ex, text, from, options), replace_data*/
    Ref(_ex_21410);
    _12093 = _47get_ovector_size(_ex_21410, 30);
    Ref(_ex_21410);
    Ref(_text_21412);
    Ref(_options_21416);
    _0 = _match_data_21420;
    _match_data_21420 = _47find_all(_ex_21410, _text_21412, _from_21415, _options_21416, _12093);
    DeRef(_0);
    _12093 = NOVALUE;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12095 = (_limit_21414 == 0);
    if (_12095 != 0) {
        goto L2; // [45] 61
    }
    if (IS_SEQUENCE(_match_data_21420)){
            _12097 = SEQ_PTR(_match_data_21420)->length;
    }
    else {
        _12097 = 1;
    }
    _12098 = (_limit_21414 > _12097);
    _12097 = NOVALUE;
    if (_12098 == 0)
    {
        DeRef(_12098);
        _12098 = NOVALUE;
        goto L3; // [57] 67
    }
    else{
        DeRef(_12098);
        _12098 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21420)){
            _limit_21414 = SEQ_PTR(_match_data_21420)->length;
    }
    else {
        _limit_21414 = 1;
    }
L3: 

    /** 	replace_data = repeat(0, limit)*/
    DeRef(_replace_data_21423);
    _replace_data_21423 = Repeat(0, _limit_21414);

    /** 	for i = 1 to limit do*/
    _12101 = _limit_21414;
    {
        int _i_21432;
        _i_21432 = 1;
L4: 
        if (_i_21432 > _12101){
            goto L5; // [78] 210
        }

        /** 		sequence params = repeat(0, length(match_data[i]))*/
        _2 = (int)SEQ_PTR(_match_data_21420);
        _12102 = (int)*(((s1_ptr)_2)->base + _i_21432);
        if (IS_SEQUENCE(_12102)){
                _12103 = SEQ_PTR(_12102)->length;
        }
        else {
            _12103 = 1;
        }
        _12102 = NOVALUE;
        DeRef(_params_21434);
        _params_21434 = Repeat(0, _12103);
        _12103 = NOVALUE;

        /** 		for j = 1 to length(match_data[i]) do*/
        _2 = (int)SEQ_PTR(_match_data_21420);
        _12105 = (int)*(((s1_ptr)_2)->base + _i_21432);
        if (IS_SEQUENCE(_12105)){
                _12106 = SEQ_PTR(_12105)->length;
        }
        else {
            _12106 = 1;
        }
        _12105 = NOVALUE;
        {
            int _j_21439;
            _j_21439 = 1;
L6: 
            if (_j_21439 > _12106){
                goto L7; // [107] 187
            }

            /** 			if equal(match_data[i][j],{0,0}) then*/
            _2 = (int)SEQ_PTR(_match_data_21420);
            _12107 = (int)*(((s1_ptr)_2)->base + _i_21432);
            _2 = (int)SEQ_PTR(_12107);
            _12108 = (int)*(((s1_ptr)_2)->base + _j_21439);
            _12107 = NOVALUE;
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = 0;
            ((int *)_2)[2] = 0;
            _12109 = MAKE_SEQ(_1);
            if (_12108 == _12109)
            _12110 = 1;
            else if (IS_ATOM_INT(_12108) && IS_ATOM_INT(_12109))
            _12110 = 0;
            else
            _12110 = (compare(_12108, _12109) == 0);
            _12108 = NOVALUE;
            DeRefDS(_12109);
            _12109 = NOVALUE;
            if (_12110 == 0)
            {
                _12110 = NOVALUE;
                goto L8; // [132] 144
            }
            else{
                _12110 = NOVALUE;
            }

            /** 				params[j] = 0*/
            _2 = (int)SEQ_PTR(_params_21434);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _params_21434 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21439);
            _1 = *(int *)_2;
            *(int *)_2 = 0;
            DeRef(_1);
            goto L9; // [141] 180
L8: 

            /** 				params[j] = text[match_data[i][j][1]..match_data[i][j][2]]*/
            _2 = (int)SEQ_PTR(_match_data_21420);
            _12111 = (int)*(((s1_ptr)_2)->base + _i_21432);
            _2 = (int)SEQ_PTR(_12111);
            _12112 = (int)*(((s1_ptr)_2)->base + _j_21439);
            _12111 = NOVALUE;
            _2 = (int)SEQ_PTR(_12112);
            _12113 = (int)*(((s1_ptr)_2)->base + 1);
            _12112 = NOVALUE;
            _2 = (int)SEQ_PTR(_match_data_21420);
            _12114 = (int)*(((s1_ptr)_2)->base + _i_21432);
            _2 = (int)SEQ_PTR(_12114);
            _12115 = (int)*(((s1_ptr)_2)->base + _j_21439);
            _12114 = NOVALUE;
            _2 = (int)SEQ_PTR(_12115);
            _12116 = (int)*(((s1_ptr)_2)->base + 2);
            _12115 = NOVALUE;
            rhs_slice_target = (object_ptr)&_12117;
            RHS_Slice(_text_21412, _12113, _12116);
            _2 = (int)SEQ_PTR(_params_21434);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _params_21434 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_21439);
            _1 = *(int *)_2;
            *(int *)_2 = _12117;
            if( _1 != _12117 ){
                DeRef(_1);
            }
            _12117 = NOVALUE;
L9: 

            /** 		end for*/
            _j_21439 = _j_21439 + 1;
            goto L6; // [182] 114
L7: 
            ;
        }

        /** 		replace_data[i] = call_func(rid, { params })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_params_21434);
        *((int *)(_2+4)) = _params_21434;
        _12118 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_12118);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_rid_21413].addr;
        Ref(*(int *)(_2+4));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
        DeRef(_12119);
        _12119 = _1;
        DeRefDS(_12118);
        _12118 = NOVALUE;
        _2 = (int)SEQ_PTR(_replace_data_21423);
        _2 = (int)(((s1_ptr)_2)->base + _i_21432);
        _1 = *(int *)_2;
        *(int *)_2 = _12119;
        if( _1 != _12119 ){
            DeRef(_1);
        }
        _12119 = NOVALUE;
        DeRefDS(_params_21434);
        _params_21434 = NOVALUE;

        /** 	end for*/
        _i_21432 = _i_21432 + 1;
        goto L4; // [205] 85
L5: 
        ;
    }

    /** 	for i = limit to 1 by -1 do*/
    {
        int _i_21458;
        _i_21458 = _limit_21414;
LA: 
        if (_i_21458 < 1){
            goto LB; // [212] 262
        }

        /** 		text = replace(text, replace_data[i], match_data[i][1][1], match_data[i][1][2])*/
        _2 = (int)SEQ_PTR(_replace_data_21423);
        _12120 = (int)*(((s1_ptr)_2)->base + _i_21458);
        _2 = (int)SEQ_PTR(_match_data_21420);
        _12121 = (int)*(((s1_ptr)_2)->base + _i_21458);
        _2 = (int)SEQ_PTR(_12121);
        _12122 = (int)*(((s1_ptr)_2)->base + 1);
        _12121 = NOVALUE;
        _2 = (int)SEQ_PTR(_12122);
        _12123 = (int)*(((s1_ptr)_2)->base + 1);
        _12122 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21420);
        _12124 = (int)*(((s1_ptr)_2)->base + _i_21458);
        _2 = (int)SEQ_PTR(_12124);
        _12125 = (int)*(((s1_ptr)_2)->base + 1);
        _12124 = NOVALUE;
        _2 = (int)SEQ_PTR(_12125);
        _12126 = (int)*(((s1_ptr)_2)->base + 2);
        _12125 = NOVALUE;
        {
            int p1 = _text_21412;
            int p2 = _12120;
            int p3 = _12123;
            int p4 = _12126;
            struct replace_block replace_params;
            replace_params.copy_to   = &p1;
            replace_params.copy_from = &p2;
            replace_params.start     = &p3;
            replace_params.stop      = &p4;
            replace_params.target    = &_text_21412;
            Replace( &replace_params );
        }
        _12120 = NOVALUE;
        _12123 = NOVALUE;
        _12126 = NOVALUE;

        /** 	end for*/
        _i_21458 = _i_21458 + -1;
        goto LA; // [257] 219
LB: 
        ;
    }

    /** 	return text*/
    DeRef(_ex_21410);
    DeRef(_options_21416);
    DeRef(_match_data_21420);
    DeRef(_replace_data_21423);
    DeRef(_12095);
    _12095 = NOVALUE;
    _12102 = NOVALUE;
    _12105 = NOVALUE;
    _12113 = NOVALUE;
    _12116 = NOVALUE;
    return _text_21412;
    ;
}
int find_replace_callback() __attribute__ ((alias ("_47find_replace_callback")));



// 0xDC3B0EC9
