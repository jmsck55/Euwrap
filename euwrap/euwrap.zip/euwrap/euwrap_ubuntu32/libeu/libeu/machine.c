// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _14allocate(int _n_1973, int _cleanup_1974)
{
    int _iaddr_1975 = NOVALUE;
    int _eaddr_1976 = NOVALUE;
    int _985 = NOVALUE;
    int _984 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _984 = 0;
    if (IS_ATOM_INT(_n_1973)) {
        _985 = _n_1973 + 0;
        if ((long)((unsigned long)_985 + (unsigned long)HIGH_BITS) >= 0) 
        _985 = NewDouble((double)_985);
    }
    else {
        _985 = binary_op(PLUS, _n_1973, 0);
    }
    _984 = NOVALUE;
    DeRef(_iaddr_1975);
    _iaddr_1975 = machine(16, _985);
    DeRef(_985);
    _985 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_1975);
    Ref(_n_1973);
    Ref(_15PAGE_READ_WRITE_1833);
    _0 = _eaddr_1976;
    _eaddr_1976 = _16prepare_block(_iaddr_1975, _n_1973, _15PAGE_READ_WRITE_1833);
    DeRef(_0);

    /** 	if cleanup then*/
    if (_cleanup_1974 == 0) {
        goto L1; // [29] 43
    }
    else {
        if (!IS_ATOM_INT(_cleanup_1974) && DBL_PTR(_cleanup_1974)->dbl == 0.0){
            goto L1; // [29] 43
        }
    }

    /** 		eaddr = delete_routine( eaddr, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1874].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1874].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1874;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_eaddr_1976) ){
        if( IS_ATOM_INT(_eaddr_1976) ){
            _eaddr_1976 = NewDouble( (double) _eaddr_1976 );
        }
        if(DBL_PTR(_eaddr_1976)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_eaddr_1976)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_eaddr_1976)) ){
            DeRefDS(_eaddr_1976);
            _eaddr_1976 = NewDouble( DBL_PTR(_eaddr_1976)->dbl );
        }
        DBL_PTR(_eaddr_1976)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_eaddr_1976)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_eaddr_1976)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_eaddr_1976)) ){
            _eaddr_1976 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_eaddr_1976) ));
        }
        SEQ_PTR(_eaddr_1976)->cleanup = (cleanup_ptr)_1;
    }
L1: 

    /** 	return eaddr*/
    DeRef(_n_1973);
    DeRef(_cleanup_1974);
    DeRef(_iaddr_1975);
    return _eaddr_1976;
    ;
}
int allocate() __attribute__ ((alias ("_14allocate")));


int _14allocate_data(int _n_1986, int _cleanup_1987)
{
    int _a_1988 = NOVALUE;
    int _sla_1990 = NOVALUE;
    int _993 = NOVALUE;
    int _990 = NOVALUE;
    int _989 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = eu:machine_func( memconst:M_ALLOC, n+BORDER_SPACE*2)*/
    _989 = 0;
    if (IS_ATOM_INT(_n_1986)) {
        _990 = _n_1986 + 0;
        if ((long)((unsigned long)_990 + (unsigned long)HIGH_BITS) >= 0) 
        _990 = NewDouble((double)_990);
    }
    else {
        _990 = binary_op(PLUS, _n_1986, 0);
    }
    _989 = NOVALUE;
    DeRef(_a_1988);
    _a_1988 = machine(16, _990);
    DeRef(_990);
    _990 = NOVALUE;

    /** 	sla = memory:prepare_block(a, n, PAGE_READ_WRITE )*/
    Ref(_a_1988);
    Ref(_n_1986);
    Ref(_15PAGE_READ_WRITE_1833);
    _0 = _sla_1990;
    _sla_1990 = _16prepare_block(_a_1988, _n_1986, _15PAGE_READ_WRITE_1833);
    DeRef(_0);

    /** 	if cleanup then*/
    if (_cleanup_1987 == 0) {
        goto L1; // [29] 47
    }
    else {
        if (!IS_ATOM_INT(_cleanup_1987) && DBL_PTR(_cleanup_1987)->dbl == 0.0){
            goto L1; // [29] 47
        }
    }

    /** 		return delete_routine( sla, memconst:FREE_RID )*/
    if( IS_ATOM_INT(_sla_1990) ){
        _993 = NewDouble( (double) _sla_1990 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_sla_1990)) ){
            if( IS_ATOM_DBL( _sla_1990 ) ){
                _993 = NewDouble( DBL_PTR(_sla_1990)->dbl );
            }
            else {
                RefDS(_sla_1990);
                _993 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_sla_1990) ));
            }
        }
        else {
            _993 = _sla_1990;
        }
    }
    _1 = (int) _00[_15FREE_RID_1874].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1874].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1874;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_993) ){
        if( IS_ATOM_INT(_993) ){
            _993 = NewDouble( (double) _sla_1990 );
        }
        if(DBL_PTR(_993)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_993)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_993)) ){
            DeRefDS(_993);
            _993 = NewDouble( DBL_PTR(_993)->dbl );
        }
        DBL_PTR(_993)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_993)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_993)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_993)) ){
            _993 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_993) ));
        }
        SEQ_PTR(_993)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_sla_1990) ){
        RefDS(_993);
    }
    DeRef(_n_1986);
    DeRef(_cleanup_1987);
    DeRef(_a_1988);
    DeRef(_sla_1990);
    return _993;
    goto L2; // [44] 54
L1: 

    /** 		return sla*/
    DeRef(_n_1986);
    DeRef(_cleanup_1987);
    DeRef(_a_1988);
    DeRef(_993);
    _993 = NOVALUE;
    return _sla_1990;
L2: 
    ;
}
int allocate_data() __attribute__ ((alias ("_14allocate_data")));


int _14allocate_pointer_array(int _pointers_2002, int _cleanup_2003)
{
    int _pList_2004 = NOVALUE;
    int _len_2005 = NOVALUE;
    int _999 = NOVALUE;
    int _998 = NOVALUE;
    int _996 = NOVALUE;
    int _994 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(pointers) * ADDRESS_LENGTH*/
    if (IS_SEQUENCE(_pointers_2002)){
            _994 = SEQ_PTR(_pointers_2002)->length;
    }
    else {
        _994 = 1;
    }
    _len_2005 = _994 * 4;
    _994 = NOVALUE;

    /**     pList = allocate( (len + ADDRESS_LENGTH ) )*/
    _996 = _len_2005 + 4;
    if ((long)((unsigned long)_996 + (unsigned long)HIGH_BITS) >= 0) 
    _996 = NewDouble((double)_996);
    _0 = _pList_2004;
    _pList_2004 = _14allocate(_996, 0);
    DeRef(_0);
    _996 = NOVALUE;

    /**     poke4(pList, pointers)*/
    if (IS_ATOM_INT(_pList_2004)){
        poke4_addr = (unsigned long *)_pList_2004;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_pList_2004)->dbl);
    }
    _1 = (int)SEQ_PTR(_pointers_2002);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    /**     poke4(pList + len, 0)*/
    if (IS_ATOM_INT(_pList_2004)) {
        _998 = _pList_2004 + _len_2005;
        if ((long)((unsigned long)_998 + (unsigned long)HIGH_BITS) >= 0) 
        _998 = NewDouble((double)_998);
    }
    else {
        _998 = NewDouble(DBL_PTR(_pList_2004)->dbl + (double)_len_2005);
    }
    if (IS_ATOM_INT(_998)){
        poke4_addr = (unsigned long *)_998;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_998)->dbl);
    }
    *poke4_addr = (unsigned long)0;
    DeRef(_998);
    _998 = NOVALUE;

    /** 	if cleanup then*/
    if (_cleanup_2003 == 0) {
        goto L1; // [41] 57
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2003) && DBL_PTR(_cleanup_2003)->dbl == 0.0){
            goto L1; // [41] 57
        }
    }

    /** 		return delete_routine( pList, FREE_ARRAY_RID )*/
    if( IS_ATOM_INT(_pList_2004) ){
        _999 = NewDouble( (double) _pList_2004 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_pList_2004)) ){
            if( IS_ATOM_DBL( _pList_2004 ) ){
                _999 = NewDouble( DBL_PTR(_pList_2004)->dbl );
            }
            else {
                RefDS(_pList_2004);
                _999 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_pList_2004) ));
            }
        }
        else {
            _999 = _pList_2004;
        }
    }
    _1 = (int) _00[_14FREE_ARRAY_RID_1969].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_14FREE_ARRAY_RID_1969].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _14FREE_ARRAY_RID_1969;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_999) ){
        if( IS_ATOM_INT(_999) ){
            _999 = NewDouble( (double) _pList_2004 );
        }
        if(DBL_PTR(_999)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_999)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_999)) ){
            DeRefDS(_999);
            _999 = NewDouble( DBL_PTR(_999)->dbl );
        }
        DBL_PTR(_999)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_999)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_999)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_999)) ){
            _999 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_999) ));
        }
        SEQ_PTR(_999)->cleanup = (cleanup_ptr)_1;
    }
    if( !IS_ATOM_INT(_pList_2004) ){
        RefDS(_999);
    }
    DeRefDS(_pointers_2002);
    DeRef(_cleanup_2003);
    DeRef(_pList_2004);
    return _999;
L1: 

    /**     return pList*/
    DeRefDS(_pointers_2002);
    DeRef(_cleanup_2003);
    DeRef(_999);
    _999 = NOVALUE;
    return _pList_2004;
    ;
}
int allocate_pointer_array() __attribute__ ((alias ("_14allocate_pointer_array")));


int _14allocate_string_pointer_array(int _string_list_2015, int _cleanup_2016)
{
    int _1005 = NOVALUE;
    int _1004 = NOVALUE;
    int _1003 = NOVALUE;
    int _1002 = NOVALUE;
    int _1001 = NOVALUE;
    int _1000 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(string_list) do*/
    if (IS_SEQUENCE(_string_list_2015)){
            _1000 = SEQ_PTR(_string_list_2015)->length;
    }
    else {
        _1000 = 1;
    }
    {
        int _i_2018;
        _i_2018 = 1;
L1: 
        if (_i_2018 > _1000){
            goto L2; // [6] 35
        }

        /** 		string_list[i] = allocate_string(string_list[i])*/
        _2 = (int)SEQ_PTR(_string_list_2015);
        _1001 = (int)*(((s1_ptr)_2)->base + _i_2018);
        Ref(_1001);
        _1002 = _14allocate_string(_1001, 0);
        _1001 = NOVALUE;
        _2 = (int)SEQ_PTR(_string_list_2015);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _string_list_2015 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2018);
        _1 = *(int *)_2;
        *(int *)_2 = _1002;
        if( _1 != _1002 ){
            DeRef(_1);
        }
        _1002 = NOVALUE;

        /** 	end for*/
        _i_2018 = _i_2018 + 1;
        goto L1; // [30] 13
L2: 
        ;
    }

    /** 	if cleanup then*/
    if (_cleanup_2016 == 0) {
        goto L3; // [37] 60
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2016) && DBL_PTR(_cleanup_2016)->dbl == 0.0){
            goto L3; // [37] 60
        }
    }

    /** 		return delete_routine( allocate_pointer_array(string_list), FREE_ARRAY_RID )*/
    Ref(_string_list_2015);
    _1003 = _14allocate_pointer_array(_string_list_2015, 0);
    DeRef(_1004);
    if( IS_ATOM_INT(_1003) ){
        _1004 = NewDouble( (double) _1003 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_1003)) ){
            if( IS_ATOM_DBL( _1003 ) ){
                _1004 = NewDouble( DBL_PTR(_1003)->dbl );
            }
            else {
                RefDS(_1003);
                _1004 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_1003) ));
            }
        }
        else {
            _1004 = _1003;
        }
    }
    _1 = (int) _00[_14FREE_ARRAY_RID_1969].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_14FREE_ARRAY_RID_1969].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _14FREE_ARRAY_RID_1969;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_1004) ){
        if( IS_ATOM_INT(_1004) ){
            _1004 = NewDouble( (double) _1003 );
        }
        if(DBL_PTR(_1004)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_1004)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_1004)) ){
            DeRefDS(_1004);
            _1004 = NewDouble( DBL_PTR(_1004)->dbl );
        }
        DBL_PTR(_1004)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_1004)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_1004)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_1004)) ){
            _1004 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_1004) ));
        }
        SEQ_PTR(_1004)->cleanup = (cleanup_ptr)_1;
    }
    _1003 = NOVALUE;
    DeRef(_string_list_2015);
    DeRef(_cleanup_2016);
    return _1004;
    goto L4; // [57] 72
L3: 

    /** 		return allocate_pointer_array(string_list)*/
    Ref(_string_list_2015);
    _1005 = _14allocate_pointer_array(_string_list_2015, 0);
    DeRef(_string_list_2015);
    DeRef(_cleanup_2016);
    DeRef(_1004);
    _1004 = NOVALUE;
    return _1005;
L4: 
    ;
}
int allocate_string_pointer_array() __attribute__ ((alias ("_14allocate_string_pointer_array")));


int _14allocate_wstring(int _s_2030, int _cleanup_2031)
{
    int _mem_2032 = NOVALUE;
    int _1012 = NOVALUE;
    int _1011 = NOVALUE;
    int _1010 = NOVALUE;
    int _1008 = NOVALUE;
    int _1007 = NOVALUE;
    int _1006 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( 2 * (length(s) + 1) )*/
    if (IS_SEQUENCE(_s_2030)){
            _1006 = SEQ_PTR(_s_2030)->length;
    }
    else {
        _1006 = 1;
    }
    _1007 = _1006 + 1;
    _1006 = NOVALUE;
    _1008 = _1007 + _1007;
    if ((long)((unsigned long)_1008 + (unsigned long)HIGH_BITS) >= 0) 
    _1008 = NewDouble((double)_1008);
    _1007 = NOVALUE;
    _1007 = NOVALUE;
    _0 = _mem_2032;
    _mem_2032 = _14allocate(_1008, 0);
    DeRef(_0);
    _1008 = NOVALUE;

    /** 	if mem then*/
    if (_mem_2032 == 0) {
        goto L1; // [23] 62
    }
    else {
        if (!IS_ATOM_INT(_mem_2032) && DBL_PTR(_mem_2032)->dbl == 0.0){
            goto L1; // [23] 62
        }
    }

    /** 		poke2(mem, s)*/
    if (IS_ATOM_INT(_mem_2032)){
        poke2_addr = (unsigned short *)_mem_2032;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_mem_2032)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2030);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke2_addr++ = (unsigned short)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke2(mem + length(s)*2, 0)*/
    if (IS_SEQUENCE(_s_2030)){
            _1010 = SEQ_PTR(_s_2030)->length;
    }
    else {
        _1010 = 1;
    }
    _1011 = _1010 + _1010;
    if ((long)((unsigned long)_1011 + (unsigned long)HIGH_BITS) >= 0) 
    _1011 = NewDouble((double)_1011);
    _1010 = NOVALUE;
    _1010 = NOVALUE;
    if (IS_ATOM_INT(_mem_2032) && IS_ATOM_INT(_1011)) {
        _1012 = _mem_2032 + _1011;
        if ((long)((unsigned long)_1012 + (unsigned long)HIGH_BITS) >= 0) 
        _1012 = NewDouble((double)_1012);
    }
    else {
        if (IS_ATOM_INT(_mem_2032)) {
            _1012 = NewDouble((double)_mem_2032 + DBL_PTR(_1011)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1011)) {
                _1012 = NewDouble(DBL_PTR(_mem_2032)->dbl + (double)_1011);
            }
            else
            _1012 = NewDouble(DBL_PTR(_mem_2032)->dbl + DBL_PTR(_1011)->dbl);
        }
    }
    DeRef(_1011);
    _1011 = NOVALUE;
    if (IS_ATOM_INT(_1012)){
        poke2_addr = (unsigned short *)_1012;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_1012)->dbl);
    }
    *poke2_addr = (unsigned short)0;
    DeRef(_1012);
    _1012 = NOVALUE;

    /** 		if cleanup then*/
    if (_cleanup_2031 == 0) {
        goto L2; // [49] 61
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2031) && DBL_PTR(_cleanup_2031)->dbl == 0.0){
            goto L2; // [49] 61
        }
    }

    /** 			mem = delete_routine( mem, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1874].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1874].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1874;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_mem_2032) ){
        if( IS_ATOM_INT(_mem_2032) ){
            _mem_2032 = NewDouble( (double) _mem_2032 );
        }
        if(DBL_PTR(_mem_2032)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_mem_2032)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_mem_2032)) ){
            DeRefDS(_mem_2032);
            _mem_2032 = NewDouble( DBL_PTR(_mem_2032)->dbl );
        }
        DBL_PTR(_mem_2032)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_mem_2032)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_mem_2032)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_mem_2032)) ){
            _mem_2032 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_mem_2032) ));
        }
        SEQ_PTR(_mem_2032)->cleanup = (cleanup_ptr)_1;
    }
L2: 
L1: 

    /** 	return mem*/
    DeRefDS(_s_2030);
    DeRef(_cleanup_2031);
    return _mem_2032;
    ;
}
int allocate_wstring() __attribute__ ((alias ("_14allocate_wstring")));


int _14peek_wstring(int _addr_2045)
{
    int _ptr_2046 = NOVALUE;
    int _1019 = NOVALUE;
    int _1018 = NOVALUE;
    int _1017 = NOVALUE;
    int _1016 = NOVALUE;
    int _1014 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom ptr = addr*/
    Ref(_addr_2045);
    DeRef(_ptr_2046);
    _ptr_2046 = _addr_2045;

    /** 	while peek2u(ptr) do*/
L1: 
    if (IS_ATOM_INT(_ptr_2046)) {
        _1014 = *(unsigned short *)_ptr_2046;
    }
    else {
        _1014 = *(unsigned short *)(unsigned long)(DBL_PTR(_ptr_2046)->dbl);
    }
    if (_1014 == 0)
    {
        _1014 = NOVALUE;
        goto L2; // [14] 28
    }
    else{
        DeRef(_1014);
        _1014 = NOVALUE;
    }

    /** 		ptr += 2*/
    _0 = _ptr_2046;
    if (IS_ATOM_INT(_ptr_2046)) {
        _ptr_2046 = _ptr_2046 + 2;
        if ((long)((unsigned long)_ptr_2046 + (unsigned long)HIGH_BITS) >= 0) 
        _ptr_2046 = NewDouble((double)_ptr_2046);
    }
    else {
        _ptr_2046 = NewDouble(DBL_PTR(_ptr_2046)->dbl + (double)2);
    }
    DeRef(_0);

    /** 	end while*/
    goto L1; // [25] 11
L2: 

    /** 	return peek2u({addr, (ptr - addr) / 2})*/
    if (IS_ATOM_INT(_ptr_2046) && IS_ATOM_INT(_addr_2045)) {
        _1016 = _ptr_2046 - _addr_2045;
        if ((long)((unsigned long)_1016 +(unsigned long) HIGH_BITS) >= 0){
            _1016 = NewDouble((double)_1016);
        }
    }
    else {
        if (IS_ATOM_INT(_ptr_2046)) {
            _1016 = NewDouble((double)_ptr_2046 - DBL_PTR(_addr_2045)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_2045)) {
                _1016 = NewDouble(DBL_PTR(_ptr_2046)->dbl - (double)_addr_2045);
            }
            else
            _1016 = NewDouble(DBL_PTR(_ptr_2046)->dbl - DBL_PTR(_addr_2045)->dbl);
        }
    }
    if (IS_ATOM_INT(_1016)) {
        if (_1016 & 1) {
            _1017 = NewDouble((_1016 >> 1) + 0.5);
        }
        else
        _1017 = _1016 >> 1;
    }
    else {
        _1017 = binary_op(DIVIDE, _1016, 2);
    }
    DeRef(_1016);
    _1016 = NOVALUE;
    Ref(_addr_2045);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _addr_2045;
    ((int *)_2)[2] = _1017;
    _1018 = MAKE_SEQ(_1);
    _1017 = NOVALUE;
    _1 = (int)SEQ_PTR(_1018);
    poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _1019 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned short)*poke2_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_1018);
    _1018 = NOVALUE;
    DeRef(_addr_2045);
    DeRef(_ptr_2046);
    return _1019;
    ;
}
int peek_wstring() __attribute__ ((alias ("_14peek_wstring")));


int _14poke_string(int _buffaddr_2056, int _buffsize_2057, int _s_2058)
{
    int _1025 = NOVALUE;
    int _1023 = NOVALUE;
    int _1021 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_buffsize_2057)) {
        _1 = (long)(DBL_PTR(_buffsize_2057)->dbl);
        DeRefDS(_buffsize_2057);
        _buffsize_2057 = _1;
    }

    /** 	if buffaddr <= 0 then*/
    if (binary_op_a(GREATER, _buffaddr_2056, 0)){
        goto L1; // [7] 18
    }

    /** 		return 0*/
    DeRef(_buffaddr_2056);
    DeRefDS(_s_2058);
    return 0;
L1: 

    /** 	if not types:string(s) then*/
    RefDS(_s_2058);
    _1021 = _7string(_s_2058);
    if (IS_ATOM_INT(_1021)) {
        if (_1021 != 0){
            DeRef(_1021);
            _1021 = NOVALUE;
            goto L2; // [24] 34
        }
    }
    else {
        if (DBL_PTR(_1021)->dbl != 0.0){
            DeRef(_1021);
            _1021 = NOVALUE;
            goto L2; // [24] 34
        }
    }
    DeRef(_1021);
    _1021 = NOVALUE;

    /** 		return 0*/
    DeRef(_buffaddr_2056);
    DeRefDS(_s_2058);
    return 0;
L2: 

    /** 	if buffsize <= length(s) then*/
    if (IS_SEQUENCE(_s_2058)){
            _1023 = SEQ_PTR(_s_2058)->length;
    }
    else {
        _1023 = 1;
    }
    if (_buffsize_2057 > _1023)
    goto L3; // [39] 50

    /** 		return 0*/
    DeRef(_buffaddr_2056);
    DeRefDS(_s_2058);
    return 0;
L3: 

    /** 	poke(buffaddr, s)*/
    if (IS_ATOM_INT(_buffaddr_2056)){
        poke_addr = (unsigned char *)_buffaddr_2056;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_buffaddr_2056)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2058);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	buffaddr += length(s)*/
    if (IS_SEQUENCE(_s_2058)){
            _1025 = SEQ_PTR(_s_2058)->length;
    }
    else {
        _1025 = 1;
    }
    _0 = _buffaddr_2056;
    if (IS_ATOM_INT(_buffaddr_2056)) {
        _buffaddr_2056 = _buffaddr_2056 + _1025;
        if ((long)((unsigned long)_buffaddr_2056 + (unsigned long)HIGH_BITS) >= 0) 
        _buffaddr_2056 = NewDouble((double)_buffaddr_2056);
    }
    else {
        _buffaddr_2056 = NewDouble(DBL_PTR(_buffaddr_2056)->dbl + (double)_1025);
    }
    DeRef(_0);
    _1025 = NOVALUE;

    /** 	poke(buffaddr, 0)*/
    if (IS_ATOM_INT(_buffaddr_2056)){
        poke_addr = (unsigned char *)_buffaddr_2056;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_buffaddr_2056)->dbl);
    }
    *poke_addr = (unsigned char)0;

    /** 	return buffaddr*/
    DeRefDS(_s_2058);
    return _buffaddr_2056;
    ;
}
int poke_string() __attribute__ ((alias ("_14poke_string")));


int _14poke_wstring(int _buffaddr_2071, int _buffsize_2072, int _s_2073)
{
    int _1032 = NOVALUE;
    int _1031 = NOVALUE;
    int _1029 = NOVALUE;
    int _1028 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_buffsize_2072)) {
        _1 = (long)(DBL_PTR(_buffsize_2072)->dbl);
        DeRefDS(_buffsize_2072);
        _buffsize_2072 = _1;
    }

    /** 	if buffaddr <= 0 then*/
    if (binary_op_a(GREATER, _buffaddr_2071, 0)){
        goto L1; // [7] 18
    }

    /** 		return 0*/
    DeRef(_buffaddr_2071);
    DeRefDS(_s_2073);
    return 0;
L1: 

    /** 	if buffsize <= 2 * length(s) then*/
    if (IS_SEQUENCE(_s_2073)){
            _1028 = SEQ_PTR(_s_2073)->length;
    }
    else {
        _1028 = 1;
    }
    _1029 = _1028 + _1028;
    if ((long)((unsigned long)_1029 + (unsigned long)HIGH_BITS) >= 0) 
    _1029 = NewDouble((double)_1029);
    _1028 = NOVALUE;
    _1028 = NOVALUE;
    if (binary_op_a(GREATER, _buffsize_2072, _1029)){
        DeRef(_1029);
        _1029 = NOVALUE;
        goto L2; // [27] 38
    }
    DeRef(_1029);
    _1029 = NOVALUE;

    /** 		return 0*/
    DeRef(_buffaddr_2071);
    DeRefDS(_s_2073);
    return 0;
L2: 

    /** 	poke2(buffaddr, s)*/
    if (IS_ATOM_INT(_buffaddr_2071)){
        poke2_addr = (unsigned short *)_buffaddr_2071;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_buffaddr_2071)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2073);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke2_addr++ = (unsigned short)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
        }
    }

    /** 	buffaddr += 2 * length(s)*/
    if (IS_SEQUENCE(_s_2073)){
            _1031 = SEQ_PTR(_s_2073)->length;
    }
    else {
        _1031 = 1;
    }
    _1032 = _1031 + _1031;
    if ((long)((unsigned long)_1032 + (unsigned long)HIGH_BITS) >= 0) 
    _1032 = NewDouble((double)_1032);
    _1031 = NOVALUE;
    _1031 = NOVALUE;
    _0 = _buffaddr_2071;
    if (IS_ATOM_INT(_buffaddr_2071) && IS_ATOM_INT(_1032)) {
        _buffaddr_2071 = _buffaddr_2071 + _1032;
        if ((long)((unsigned long)_buffaddr_2071 + (unsigned long)HIGH_BITS) >= 0) 
        _buffaddr_2071 = NewDouble((double)_buffaddr_2071);
    }
    else {
        if (IS_ATOM_INT(_buffaddr_2071)) {
            _buffaddr_2071 = NewDouble((double)_buffaddr_2071 + DBL_PTR(_1032)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1032)) {
                _buffaddr_2071 = NewDouble(DBL_PTR(_buffaddr_2071)->dbl + (double)_1032);
            }
            else
            _buffaddr_2071 = NewDouble(DBL_PTR(_buffaddr_2071)->dbl + DBL_PTR(_1032)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1032);
    _1032 = NOVALUE;

    /** 	poke2(buffaddr, 0)*/
    if (IS_ATOM_INT(_buffaddr_2071)){
        poke2_addr = (unsigned short *)_buffaddr_2071;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_buffaddr_2071)->dbl);
    }
    *poke2_addr = (unsigned short)0;

    /** 	return buffaddr*/
    DeRefDS(_s_2073);
    return _buffaddr_2071;
    ;
}
int poke_wstring() __attribute__ ((alias ("_14poke_wstring")));


int _14is_DEP_supported()
{
    int _0, _1, _2;
    

    /** 	return memconst:DEP_really_works*/
    return 0;
    ;
}
int is_DEP_supported() __attribute__ ((alias ("_14is_DEP_supported")));


int _14is_using_DEP()
{
    int _0, _1, _2;
    

    /** 	return memconst:use_DEP*/
    return _15use_DEP_1865;
    ;
}
int is_using_DEP() __attribute__ ((alias ("_14is_using_DEP")));


void _14DEP_on(int _value_2106)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_2106)) {
        _1 = (long)(DBL_PTR(_value_2106)->dbl);
        DeRefDS(_value_2106);
        _value_2106 = _1;
    }

    /** 	memconst:use_DEP = value*/
    _15use_DEP_1865 = _value_2106;

    /** end procedure*/
    return;
    ;
}
void DEP_on() __attribute__ ((alias ("_14DEP_on")));


int _14allocate_code(int _data_2109, int _wordsize_2110)
{
    int _1046 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    Ref(_data_2109);
    Ref(_wordsize_2110);
    _1046 = _14allocate_protect(_data_2109, _wordsize_2110, 4);
    DeRef(_data_2109);
    DeRef(_wordsize_2110);
    return _1046;
    ;
}
int allocate_code() __attribute__ ((alias ("_14allocate_code")));


int _14allocate_string(int _s_2116, int _cleanup_2117)
{
    int _mem_2118 = NOVALUE;
    int _1051 = NOVALUE;
    int _1050 = NOVALUE;
    int _1048 = NOVALUE;
    int _1047 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_2116)){
            _1047 = SEQ_PTR(_s_2116)->length;
    }
    else {
        _1047 = 1;
    }
    _1048 = _1047 + 1;
    _1047 = NOVALUE;
    _0 = _mem_2118;
    _mem_2118 = _14allocate(_1048, 0);
    DeRef(_0);
    _1048 = NOVALUE;

    /** 	if mem then*/
    if (_mem_2118 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_2118) && DBL_PTR(_mem_2118)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_2118)){
        poke_addr = (unsigned char *)_mem_2118;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_2118)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_2116);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_2116)){
            _1050 = SEQ_PTR(_s_2116)->length;
    }
    else {
        _1050 = 1;
    }
    if (IS_ATOM_INT(_mem_2118)) {
        _1051 = _mem_2118 + _1050;
        if ((long)((unsigned long)_1051 + (unsigned long)HIGH_BITS) >= 0) 
        _1051 = NewDouble((double)_1051);
    }
    else {
        _1051 = NewDouble(DBL_PTR(_mem_2118)->dbl + (double)_1050);
    }
    _1050 = NOVALUE;
    if (IS_ATOM_INT(_1051)){
        poke_addr = (unsigned char *)_1051;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_1051)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_1051);
    _1051 = NOVALUE;

    /** 		if cleanup then*/
    if (_cleanup_2117 == 0) {
        goto L2; // [41] 53
    }
    else {
        if (!IS_ATOM_INT(_cleanup_2117) && DBL_PTR(_cleanup_2117)->dbl == 0.0){
            goto L2; // [41] 53
        }
    }

    /** 			mem = delete_routine( mem, memconst:FREE_RID )*/
    _1 = (int) _00[_15FREE_RID_1874].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_15FREE_RID_1874].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _15FREE_RID_1874;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_mem_2118) ){
        if( IS_ATOM_INT(_mem_2118) ){
            _mem_2118 = NewDouble( (double) _mem_2118 );
        }
        if(DBL_PTR(_mem_2118)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_mem_2118)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_mem_2118)) ){
            DeRefDS(_mem_2118);
            _mem_2118 = NewDouble( DBL_PTR(_mem_2118)->dbl );
        }
        DBL_PTR(_mem_2118)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_mem_2118)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_mem_2118)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_mem_2118)) ){
            _mem_2118 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_mem_2118) ));
        }
        SEQ_PTR(_mem_2118)->cleanup = (cleanup_ptr)_1;
    }
L2: 
L1: 

    /** 	return mem*/
    DeRefDS(_s_2116);
    DeRef(_cleanup_2117);
    return _mem_2118;
    ;
}
int allocate_string() __attribute__ ((alias ("_14allocate_string")));


int _14allocate_protect(int _data_2129, int _wordsize_2130, int _protection_2132)
{
    int _iaddr_2133 = NOVALUE;
    int _eaddr_2135 = NOVALUE;
    int _size_2136 = NOVALUE;
    int _first_protection_2138 = NOVALUE;
    int _true_protection_2140 = NOVALUE;
    int _prepare_block_inlined_prepare_block_at_104_2155 = NOVALUE;
    int _msg_inlined_crash_at_186_2168 = NOVALUE;
    int _1072 = NOVALUE;
    int _1071 = NOVALUE;
    int _1069 = NOVALUE;
    int _1068 = NOVALUE;
    int _1067 = NOVALUE;
    int _1063 = NOVALUE;
    int _1061 = NOVALUE;
    int _1058 = NOVALUE;
    int _1057 = NOVALUE;
    int _1055 = NOVALUE;
    int _1053 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom iaddr = 0*/
    DeRef(_iaddr_2133);
    _iaddr_2133 = 0;

    /** 	integer size*/

    /** 	valid_memory_protection_constant true_protection = protection*/
    Ref(_protection_2132);
    DeRef(_true_protection_2140);
    _true_protection_2140 = _protection_2132;

    /** 	ifdef SAFE then	*/

    /** 	if atom(data) then*/
    _1053 = IS_ATOM(_data_2129);
    if (_1053 == 0)
    {
        _1053 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _1053 = NOVALUE;
    }

    /** 		size = data * wordsize*/
    if (IS_ATOM_INT(_data_2129) && IS_ATOM_INT(_wordsize_2130)) {
        _size_2136 = _data_2129 * _wordsize_2130;
    }
    else {
        _size_2136 = binary_op(MULTIPLY, _data_2129, _wordsize_2130);
    }
    if (!IS_ATOM_INT(_size_2136)) {
        _1 = (long)(DBL_PTR(_size_2136)->dbl);
        DeRefDS(_size_2136);
        _size_2136 = _1;
    }

    /** 		first_protection = true_protection*/
    Ref(_true_protection_2140);
    DeRef(_first_protection_2138);
    _first_protection_2138 = _true_protection_2140;
    goto L2; // [36] 58
L1: 

    /** 		size = length(data) * wordsize*/
    if (IS_SEQUENCE(_data_2129)){
            _1055 = SEQ_PTR(_data_2129)->length;
    }
    else {
        _1055 = 1;
    }
    if (IS_ATOM_INT(_wordsize_2130)) {
        _size_2136 = _1055 * _wordsize_2130;
    }
    else {
        _size_2136 = binary_op(MULTIPLY, _1055, _wordsize_2130);
    }
    _1055 = NOVALUE;
    if (!IS_ATOM_INT(_size_2136)) {
        _1 = (long)(DBL_PTR(_size_2136)->dbl);
        DeRefDS(_size_2136);
        _size_2136 = _1;
    }

    /** 		first_protection = PAGE_READ_WRITE*/
    Ref(_15PAGE_READ_WRITE_1833);
    DeRef(_first_protection_2138);
    _first_protection_2138 = _15PAGE_READ_WRITE_1833;
L2: 

    /** 	iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _1057 = 0;
    _1058 = _size_2136 + 0;
    _1057 = NOVALUE;
    Ref(_first_protection_2138);
    _0 = _iaddr_2133;
    _iaddr_2133 = _14local_allocate_protected_memory(_1058, _first_protection_2138);
    DeRef(_0);
    _1058 = NOVALUE;

    /** 	if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_2133, 0)){
        goto L3; // [79] 90
    }

    /** 		return 0*/
    DeRef(_data_2129);
    DeRef(_wordsize_2130);
    DeRef(_protection_2132);
    DeRef(_iaddr_2133);
    DeRef(_eaddr_2135);
    DeRef(_first_protection_2138);
    DeRef(_true_protection_2140);
    return 0;
L3: 

    /** 	eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_2132)) {
        _1 = (long)(DBL_PTR(_protection_2132)->dbl);
        DeRefDS(_protection_2132);
        _protection_2132 = _1;
    }

    /** 	return addr*/
    Ref(_iaddr_2133);
    DeRef(_eaddr_2135);
    _eaddr_2135 = _iaddr_2133;

    /** 	if eaddr = 0 or atom( data ) then*/
    if (IS_ATOM_INT(_eaddr_2135)) {
        _1061 = (_eaddr_2135 == 0);
    }
    else {
        _1061 = (DBL_PTR(_eaddr_2135)->dbl == (double)0);
    }
    if (_1061 != 0) {
        goto L4; // [106] 118
    }
    _1063 = IS_ATOM(_data_2129);
    if (_1063 == 0)
    {
        _1063 = NOVALUE;
        goto L5; // [114] 125
    }
    else{
        _1063 = NOVALUE;
    }
L4: 

    /** 		return eaddr*/
    DeRef(_data_2129);
    DeRef(_wordsize_2130);
    DeRef(_protection_2132);
    DeRef(_iaddr_2133);
    DeRef(_first_protection_2138);
    DeRef(_true_protection_2140);
    DeRef(_1061);
    _1061 = NOVALUE;
    return _eaddr_2135;
L5: 

    /** 	switch wordsize do*/
    if (IS_SEQUENCE(_wordsize_2130) ){
        goto L6; // [127] 167
    }
    if(!IS_ATOM_INT(_wordsize_2130)){
        if( (DBL_PTR(_wordsize_2130)->dbl != (double) ((int) DBL_PTR(_wordsize_2130)->dbl) ) ){
            goto L6; // [127] 167
        }
        _0 = (int) DBL_PTR(_wordsize_2130)->dbl;
    }
    else {
        _0 = _wordsize_2130;
    };
    switch ( _0 ){ 

        /** 		case 1 then*/
        case 1:

        /** 			eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2135)){
            poke_addr = (unsigned char *)_eaddr_2135;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_eaddr_2135)->dbl);
        }
        if (IS_ATOM_INT(_data_2129)) {
            *poke_addr = (unsigned char)_data_2129;
        }
        else if (IS_ATOM(_data_2129)) {
            *poke_addr = (signed char)DBL_PTR(_data_2129)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2129);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [141] 190

        /** 		case 2 then*/
        case 2:

        /** 			eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2135)){
            poke2_addr = (unsigned short *)_eaddr_2135;
        }
        else {
            poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_eaddr_2135)->dbl);
        }
        if (IS_ATOM_INT(_data_2129)) {
            *poke2_addr = (unsigned short)_data_2129;
        }
        else if (IS_ATOM(_data_2129)) {
            *poke_addr = (signed char)DBL_PTR(_data_2129)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2129);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke2_addr++ = (unsigned short)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [152] 190

        /** 		case 4 then*/
        case 4:

        /** 			eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_2135)){
            poke4_addr = (unsigned long *)_eaddr_2135;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_eaddr_2135)->dbl);
        }
        if (IS_ATOM_INT(_data_2129)) {
            *poke4_addr = (unsigned long)_data_2129;
        }
        else if (IS_ATOM(_data_2129)) {
            *poke4_addr = (unsigned long)DBL_PTR(_data_2129)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_data_2129);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }
        goto L7; // [163] 190

        /** 		case else*/
        default:
L6: 

        /** 			error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_186_2168);
        _msg_inlined_crash_at_186_2168 = EPrintf(-9999999, _1066, _wordsize_2130);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_186_2168);

        /** end procedure*/
        goto L8; // [184] 187
L8: 
        DeRefi(_msg_inlined_crash_at_186_2168);
        _msg_inlined_crash_at_186_2168 = NOVALUE;
    ;}L7: 

    /** 	ifdef SAFE then*/

    /** 	if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _1067 = 0;
    _1068 = _size_2136 + 0;
    _1067 = NOVALUE;
    Ref(_iaddr_2133);
    Ref(_true_protection_2140);
    _1069 = _14local_change_protection_on_protected_memory(_iaddr_2133, _1068, _true_protection_2140);
    _1068 = NOVALUE;
    if (binary_op_a(NOTEQ, _1069, -1)){
        DeRef(_1069);
        _1069 = NOVALUE;
        goto L9; // [208] 232
    }
    DeRef(_1069);
    _1069 = NOVALUE;

    /** 		local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _1071 = 0;
    _1072 = _size_2136 + 0;
    _1071 = NOVALUE;
    Ref(_iaddr_2133);
    _14local_free_protected_memory(_iaddr_2133, _1072);
    _1072 = NOVALUE;

    /** 		eaddr = 0*/
    DeRef(_eaddr_2135);
    _eaddr_2135 = 0;
L9: 

    /** 	return eaddr*/
    DeRef(_data_2129);
    DeRef(_wordsize_2130);
    DeRef(_protection_2132);
    DeRef(_iaddr_2133);
    DeRef(_first_protection_2138);
    DeRef(_true_protection_2140);
    DeRef(_1061);
    _1061 = NOVALUE;
    return _eaddr_2135;
    ;
}
int allocate_protect() __attribute__ ((alias ("_14allocate_protect")));


int _14local_allocate_protected_memory(int _s_2180, int _first_protection_2181)
{
    int _1073 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_first_protection_2181)) {
        _1 = (long)(DBL_PTR(_first_protection_2181)->dbl);
        DeRefDS(_first_protection_2181);
        _first_protection_2181 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func( memconst:M_ALLOC, PAGE_SIZE)*/
    _1073 = machine(16, _14PAGE_SIZE_2099);
    return _1073;
    ;
}


int _14local_change_protection_on_protected_memory(int _p_2185, int _s_2186, int _new_protection_2187)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_protection_2187)) {
        _1 = (long)(DBL_PTR(_new_protection_2187)->dbl);
        DeRefDS(_new_protection_2187);
        _new_protection_2187 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		return 0*/
    return 0;
    ;
}


void _14local_free_protected_memory(int _p_2190, int _s_2191)
{
    int _1075 = NOVALUE;
    int _1074 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 			machine_func( memconst:M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_2190);
    *((int *)(_2+4)) = _p_2190;
    _1074 = MAKE_SEQ(_1);
    _1075 = machine(17, _1074);
    DeRefDS(_1074);
    _1074 = NOVALUE;

    /** end procedure*/
    DeRef(_p_2190);
    DeRef(_1075);
    _1075 = NOVALUE;
    return;
    ;
}


void _14free(int _addr_2196)
{
    int _msg_inlined_crash_at_27_2205 = NOVALUE;
    int _data_inlined_crash_at_24_2204 = NOVALUE;
    int _addr_inlined_deallocate_at_64_2211 = NOVALUE;
    int _msg_inlined_crash_at_106_2216 = NOVALUE;
    int _1082 = NOVALUE;
    int _1081 = NOVALUE;
    int _1080 = NOVALUE;
    int _1079 = NOVALUE;
    int _1077 = NOVALUE;
    int _1076 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_2196);
    _1076 = _7number_array(_addr_2196);
    if (_1076 == 0) {
        DeRef(_1076);
        _1076 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_1076) && DBL_PTR(_1076)->dbl == 0.0){
            DeRef(_1076);
            _1076 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_1076);
        _1076 = NOVALUE;
    }
    DeRef(_1076);
    _1076 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_2196);
    _1077 = _7ascii_string(_addr_2196);
    if (_1077 == 0) {
        DeRef(_1077);
        _1077 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_1077) && DBL_PTR(_1077)->dbl == 0.0){
            DeRef(_1077);
            _1077 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_1077);
        _1077 = NOVALUE;
    }
    DeRef(_1077);
    _1077 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_2196);
    *((int *)(_2+4)) = _addr_2196;
    _1079 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_2204);
    _data_inlined_crash_at_24_2204 = _1079;
    _1079 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_2205);
    _msg_inlined_crash_at_27_2205 = EPrintf(-9999999, _1078, _data_inlined_crash_at_24_2204);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_2205);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_2204);
    _data_inlined_crash_at_24_2204 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_2205);
    _msg_inlined_crash_at_27_2205 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_2196)){
            _1080 = SEQ_PTR(_addr_2196)->length;
    }
    else {
        _1080 = 1;
    }
    {
        int _i_2207;
        _i_2207 = 1;
L4: 
        if (_i_2207 > _1080){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_2196);
        _1081 = (int)*(((s1_ptr)_2)->base + _i_2207);
        Ref(_1081);
        DeRef(_addr_inlined_deallocate_at_64_2211);
        _addr_inlined_deallocate_at_64_2211 = _1081;
        _1081 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_2211);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_2211);
        _addr_inlined_deallocate_at_64_2211 = NOVALUE;

        /** 		end for*/
        _i_2207 = _i_2207 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_2196);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _1082 = IS_SEQUENCE(_addr_2196);
    if (_1082 == 0)
    {
        _1082 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _1082 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_2216);
    _msg_inlined_crash_at_106_2216 = EPrintf(-9999999, _1083, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_2216);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_2216);
    _msg_inlined_crash_at_106_2216 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_2196, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_2196);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_2196);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_2196);
    return;
    ;
}
void free() __attribute__ ((alias ("_14free")));


void _14free_pointer_array(int _pointers_array_2224)
{
    int _saved_2225 = NOVALUE;
    int _ptr_2226 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_2224);
    DeRef(_saved_2225);
    _saved_2225 = _pointers_array_2224;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_2226 <= 0) {
        if (_ptr_2226 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_2226) && DBL_PTR(_ptr_2226)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_2226);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_2224;
    if (IS_ATOM_INT(_pointers_array_2224)) {
        _pointers_array_2224 = _pointers_array_2224 + 4;
        if ((long)((unsigned long)_pointers_array_2224 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_2224 = NewDouble((double)_pointers_array_2224);
    }
    else {
        _pointers_array_2224 = NewDouble(DBL_PTR(_pointers_array_2224)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_2226);
    if (IS_ATOM_INT(_pointers_array_2224)) {
        _ptr_2226 = *(unsigned long *)_pointers_array_2224;
        if ((unsigned)_ptr_2226 > (unsigned)MAXINT)
        _ptr_2226 = NewDouble((double)(unsigned long)_ptr_2226);
    }
    else {
        _ptr_2226 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_2224)->dbl);
        if ((unsigned)_ptr_2226 > (unsigned)MAXINT)
        _ptr_2226 = NewDouble((double)(unsigned long)_ptr_2226);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_2225);
    _14free(_saved_2225);

    /** end procedure*/
    DeRef(_pointers_array_2224);
    DeRef(_saved_2225);
    DeRef(_ptr_2226);
    return;
    ;
}
void free_pointer_array() __attribute__ ((alias ("_14free_pointer_array")));


int _14std_library_address(int _addr_2235)
{
    int _1091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef not SAFE then*/

    /** 		return atom(addr)*/
    _1091 = IS_ATOM(_addr_2235);
    DeRef(_addr_2235);
    return _1091;
    ;
}
int std_library_address() __attribute__ ((alias ("_14std_library_address")));


int _14valid_memory_protection_constant(int _x_2239)
{
    int _1092 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, memconst:MEMORY_PROTECTION )*/
    _1092 = find_from(_x_2239, _15MEMORY_PROTECTION_1838, 1);
    DeRef(_x_2239);
    return _1092;
    ;
}
int valid_memory_protection_constant() __attribute__ ((alias ("_14valid_memory_protection_constant")));


int _14page_aligned_address(int _a_2243)
{
    int _1096 = NOVALUE;
    int _1095 = NOVALUE;
    int _1093 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _1093 = IS_ATOM(_a_2243);
    if (_1093 != 0)
    goto L1; // [6] 16
    _1093 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_2243);
    return 0;
L1: 

    /** 	return remainder( a, PAGE_SIZE ) = 0*/
    if (IS_ATOM_INT(_a_2243)) {
        _1095 = (_a_2243 % _14PAGE_SIZE_2099);
    }
    else {
        _1095 = binary_op(REMAINDER, _a_2243, _14PAGE_SIZE_2099);
    }
    if (IS_ATOM_INT(_1095)) {
        _1096 = (_1095 == 0);
    }
    else {
        _1096 = binary_op(EQUALS, _1095, 0);
    }
    DeRef(_1095);
    _1095 = NOVALUE;
    DeRef(_a_2243);
    return _1096;
    ;
}
int page_aligned_address() __attribute__ ((alias ("_14page_aligned_address")));



// 0x9E2F74B2
