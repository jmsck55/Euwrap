// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _13open_dll(int _file_name_2294)
{
    int _fh_2304 = NOVALUE;
    int _1117 = NOVALUE;
    int _1115 = NOVALUE;
    int _1114 = NOVALUE;
    int _1113 = NOVALUE;
    int _1112 = NOVALUE;
    int _1111 = NOVALUE;
    int _1110 = NOVALUE;
    int _1109 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_2294)){
            _1109 = SEQ_PTR(_file_name_2294)->length;
    }
    else {
        _1109 = 1;
    }
    _1110 = (_1109 > 0);
    _1109 = NOVALUE;
    if (_1110 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_2294);
    _1112 = _7string(_file_name_2294);
    if (_1112 == 0) {
        DeRef(_1112);
        _1112 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_1112) && DBL_PTR(_1112)->dbl == 0.0){
            DeRef(_1112);
            _1112 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_1112);
        _1112 = NOVALUE;
    }
    DeRef(_1112);
    _1112 = NOVALUE;

    /** 		return machine_func(M_OPEN_DLL, file_name)*/
    _1113 = machine(50, _file_name_2294);
    DeRefDS(_file_name_2294);
    DeRef(_1110);
    _1110 = NOVALUE;
    return _1113;
L1: 

    /** 	for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_2294)){
            _1114 = SEQ_PTR(_file_name_2294)->length;
    }
    else {
        _1114 = 1;
    }
    {
        int _idx_2302;
        _idx_2302 = 1;
L2: 
        if (_idx_2302 > _1114){
            goto L3; // [40] 82
        }

        /** 		atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (int)SEQ_PTR(_file_name_2294);
        _1115 = (int)*(((s1_ptr)_2)->base + _idx_2302);
        DeRef(_fh_2304);
        _fh_2304 = machine(50, _1115);
        _1115 = NOVALUE;

        /** 		if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_2304)) {
            _1117 = (_fh_2304 == 0);
        }
        else {
            _1117 = unary_op(NOT, _fh_2304);
        }
        if (_1117 != 0)
        goto L4; // [62] 73

        /** 			return fh*/
        DeRefDS(_file_name_2294);
        DeRef(_1110);
        _1110 = NOVALUE;
        DeRef(_1113);
        _1113 = NOVALUE;
        _1117 = NOVALUE;
        return _fh_2304;
L4: 
        DeRef(_fh_2304);
        _fh_2304 = NOVALUE;

        /** 	end for*/
        _idx_2302 = _idx_2302 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_name_2294);
    DeRef(_1110);
    _1110 = NOVALUE;
    DeRef(_1113);
    _1113 = NOVALUE;
    DeRef(_1117);
    _1117 = NOVALUE;
    return 0;
    ;
}
int open_dll() __attribute__ ((alias ("_13open_dll")));


int _13define_c_var(int _lib_2312, int _variable_name_2313)
{
    int _1120 = NOVALUE;
    int _1119 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_DEFINE_VAR, {lib, variable_name})*/
    RefDS(_variable_name_2313);
    Ref(_lib_2312);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lib_2312;
    ((int *)_2)[2] = _variable_name_2313;
    _1119 = MAKE_SEQ(_1);
    _1120 = machine(56, _1119);
    DeRefDS(_1119);
    _1119 = NOVALUE;
    DeRef(_lib_2312);
    DeRefDS(_variable_name_2313);
    return _1120;
    ;
}
int define_c_var() __attribute__ ((alias ("_13define_c_var")));


int _13define_c_proc(int _lib_2318, int _routine_name_2319, int _arg_types_2320)
{
    int _safe_address_inlined_safe_address_at_11_2325 = NOVALUE;
    int _msg_inlined_crash_at_26_2329 = NOVALUE;
    int _1126 = NOVALUE;
    int _1125 = NOVALUE;
    int _1123 = NOVALUE;
    int _1122 = NOVALUE;
    int _1121 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _1121 = IS_ATOM(_routine_name_2319);
    if (_1121 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_2325 = 1;
    _1123 = (1 == 0);
    if (_1123 == 0)
    {
        DeRef(_1123);
        _1123 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_1123);
        _1123 = NOVALUE;
    }

    /**         error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_2329);
    _msg_inlined_crash_at_26_2329 = EPrintf(-9999999, _1124, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_2329);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_2329);
    _msg_inlined_crash_at_26_2329 = NOVALUE;
L1: 

    /** 	return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_2318);
    *((int *)(_2+4)) = _lib_2318;
    Ref(_routine_name_2319);
    *((int *)(_2+8)) = _routine_name_2319;
    RefDS(_arg_types_2320);
    *((int *)(_2+12)) = _arg_types_2320;
    *((int *)(_2+16)) = 0;
    _1125 = MAKE_SEQ(_1);
    _1126 = machine(51, _1125);
    DeRefDS(_1125);
    _1125 = NOVALUE;
    DeRef(_lib_2318);
    DeRef(_routine_name_2319);
    DeRefDS(_arg_types_2320);
    return _1126;
    ;
}
int define_c_proc() __attribute__ ((alias ("_13define_c_proc")));


int _13define_c_func(int _lib_2334, int _routine_name_2335, int _arg_types_2336, int _return_type_2337)
{
    int _safe_address_inlined_safe_address_at_11_2342 = NOVALUE;
    int _msg_inlined_crash_at_26_2345 = NOVALUE;
    int _1131 = NOVALUE;
    int _1130 = NOVALUE;
    int _1129 = NOVALUE;
    int _1128 = NOVALUE;
    int _1127 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _1127 = IS_ATOM(_routine_name_2335);
    if (_1127 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_2342 = 1;
    _1129 = (1 == 0);
    if (_1129 == 0)
    {
        DeRef(_1129);
        _1129 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_1129);
        _1129 = NOVALUE;
    }

    /** 	      error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_2345);
    _msg_inlined_crash_at_26_2345 = EPrintf(-9999999, _1124, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_2345);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_2345);
    _msg_inlined_crash_at_26_2345 = NOVALUE;
L1: 

    /** 	  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_2334);
    *((int *)(_2+4)) = _lib_2334;
    Ref(_routine_name_2335);
    *((int *)(_2+8)) = _routine_name_2335;
    RefDS(_arg_types_2336);
    *((int *)(_2+12)) = _arg_types_2336;
    Ref(_return_type_2337);
    *((int *)(_2+16)) = _return_type_2337;
    _1130 = MAKE_SEQ(_1);
    _1131 = machine(51, _1130);
    DeRefDS(_1130);
    _1130 = NOVALUE;
    DeRef(_lib_2334);
    DeRef(_routine_name_2335);
    DeRefDS(_arg_types_2336);
    DeRef(_return_type_2337);
    return _1131;
    ;
}
int define_c_func() __attribute__ ((alias ("_13define_c_func")));


int _13call_back(int _id_2351)
{
    int _1132 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return machine_func(M_CALL_BACK, id)*/
    _1132 = machine(52, _id_2351);
    DeRef(_id_2351);
    return _1132;
    ;
}
int call_back() __attribute__ ((alias ("_13call_back")));



// 0xF69323B4
