// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _3platform_name()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_22);
    return _22;
    ;
}
int platform_name() __attribute__ ((alias ("_3platform_name")));


int _3version()
{
    int _36 = NOVALUE;
    int _35 = NOVALUE;
    int _34 = NOVALUE;
    int _33 = NOVALUE;
    int _31 = NOVALUE;
    int _30 = NOVALUE;
    int _28 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (version_info[MAJ_VER] * 10000) +*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _28 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28)) {
        if (_28 == (short)_28)
        _30 = _28 * 10000;
        else
        _30 = NewDouble(_28 * (double)10000);
    }
    else {
        _30 = binary_op(MULTIPLY, _28, 10000);
    }
    _28 = NOVALUE;
    _2 = (int)SEQ_PTR(_3version_info_163);
    _31 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31)) {
        if (_31 == (short)_31)
        _33 = _31 * 100;
        else
        _33 = NewDouble(_31 * (double)100);
    }
    else {
        _33 = binary_op(MULTIPLY, _31, 100);
    }
    _31 = NOVALUE;
    if (IS_ATOM_INT(_30) && IS_ATOM_INT(_33)) {
        _34 = _30 + _33;
        if ((long)((unsigned long)_34 + (unsigned long)HIGH_BITS) >= 0) 
        _34 = NewDouble((double)_34);
    }
    else {
        _34 = binary_op(PLUS, _30, _33);
    }
    DeRef(_30);
    _30 = NOVALUE;
    DeRef(_33);
    _33 = NOVALUE;
    _2 = (int)SEQ_PTR(_3version_info_163);
    _35 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_34) && IS_ATOM_INT(_35)) {
        _36 = _34 + _35;
        if ((long)((unsigned long)_36 + (unsigned long)HIGH_BITS) >= 0) 
        _36 = NewDouble((double)_36);
    }
    else {
        _36 = binary_op(PLUS, _34, _35);
    }
    DeRef(_34);
    _34 = NOVALUE;
    _35 = NOVALUE;
    return _36;
    ;
}
int version() __attribute__ ((alias ("_3version")));


int _3version_major()
{
    int _37 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MAJ_VER]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _37 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_37);
    return _37;
    ;
}
int version_major() __attribute__ ((alias ("_3version_major")));


int _3version_minor()
{
    int _38 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MIN_VER]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _38 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_38);
    return _38;
    ;
}
int version_minor() __attribute__ ((alias ("_3version_minor")));


int _3version_patch()
{
    int _39 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[PAT_VER]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _39 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_39);
    return _39;
    ;
}
int version_patch() __attribute__ ((alias ("_3version_patch")));


int _3version_node(int _full_202)
{
    int _47 = NOVALUE;
    int _46 = NOVALUE;
    int _45 = NOVALUE;
    int _44 = NOVALUE;
    int _42 = NOVALUE;
    int _41 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_full_202)) {
        _1 = (long)(DBL_PTR(_full_202)->dbl);
        DeRefDS(_full_202);
        _full_202 = _1;
    }

    /** 	if full or length(version_info[NODE]) < 12 then*/
    if (_full_202 != 0) {
        goto L1; // [5] 27
    }
    _2 = (int)SEQ_PTR(_3version_info_163);
    _41 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_41)){
            _42 = SEQ_PTR(_41)->length;
    }
    else {
        _42 = 1;
    }
    _41 = NOVALUE;
    _44 = (_42 < 12);
    _42 = NOVALUE;
    if (_44 == 0)
    {
        DeRef(_44);
        _44 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_44);
        _44 = NOVALUE;
    }
L1: 

    /** 		return version_info[NODE]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _45 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_45);
    _41 = NOVALUE;
    return _45;
L2: 

    /** 	return version_info[NODE][1..12]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _46 = (int)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_47;
    RHS_Slice(_46, 1, 12);
    _46 = NOVALUE;
    _41 = NOVALUE;
    _45 = NOVALUE;
    return _47;
    ;
}
int version_node() __attribute__ ((alias ("_3version_node")));


int _3version_revision()
{
    int _48 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[REVISION]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _48 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_48);
    return _48;
    ;
}
int version_revision() __attribute__ ((alias ("_3version_revision")));


int _3version_date(int _full_217)
{
    int _57 = NOVALUE;
    int _56 = NOVALUE;
    int _55 = NOVALUE;
    int _54 = NOVALUE;
    int _52 = NOVALUE;
    int _51 = NOVALUE;
    int _49 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_full_217)) {
        _1 = (long)(DBL_PTR(_full_217)->dbl);
        DeRefDS(_full_217);
        _full_217 = _1;
    }

    /** 	if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_217 != 0) {
        _49 = 1;
        goto L1; // [5] 15
    }
    _49 = (_3is_developmental_165 != 0);
L1: 
    if (_49 != 0) {
        goto L2; // [15] 37
    }
    _2 = (int)SEQ_PTR(_3version_info_163);
    _51 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_51)){
            _52 = SEQ_PTR(_51)->length;
    }
    else {
        _52 = 1;
    }
    _51 = NOVALUE;
    _54 = (_52 < 10);
    _52 = NOVALUE;
    if (_54 == 0)
    {
        DeRef(_54);
        _54 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_54);
        _54 = NOVALUE;
    }
L2: 

    /** 		return version_info[REVISION_DATE]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _55 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_55);
    _51 = NOVALUE;
    return _55;
L3: 

    /** 	return version_info[REVISION_DATE][1..10]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _56 = (int)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_57;
    RHS_Slice(_56, 1, 10);
    _56 = NOVALUE;
    _51 = NOVALUE;
    _55 = NOVALUE;
    return _57;
    ;
}
int version_date() __attribute__ ((alias ("_3version_date")));


int _3version_type()
{
    int _58 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[VER_TYPE]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _58 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_58);
    return _58;
    ;
}
int version_type() __attribute__ ((alias ("_3version_type")));


int _3version_string(int _full_233)
{
    int _version_revision_inlined_version_revision_at_41_242 = NOVALUE;
    int _77 = NOVALUE;
    int _76 = NOVALUE;
    int _75 = NOVALUE;
    int _74 = NOVALUE;
    int _73 = NOVALUE;
    int _72 = NOVALUE;
    int _71 = NOVALUE;
    int _70 = NOVALUE;
    int _68 = NOVALUE;
    int _67 = NOVALUE;
    int _66 = NOVALUE;
    int _65 = NOVALUE;
    int _64 = NOVALUE;
    int _63 = NOVALUE;
    int _62 = NOVALUE;
    int _61 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_full_233)) {
        _1 = (long)(DBL_PTR(_full_233)->dbl);
        DeRefDS(_full_233);
        _full_233 = _1;
    }

    /** 	if full or is_developmental then*/
    if (_full_233 != 0) {
        goto L1; // [5] 16
    }
    if (_3is_developmental_165 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** 		return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _61 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _62 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _63 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _64 = (int)*(((s1_ptr)_2)->base + 4);

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_242);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _version_revision_inlined_version_revision_at_41_242 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_242);
    _65 = _3version_node(0);
    _66 = _3version_date(_full_233);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_61);
    *((int *)(_2+4)) = _61;
    Ref(_62);
    *((int *)(_2+8)) = _62;
    Ref(_63);
    *((int *)(_2+12)) = _63;
    Ref(_64);
    *((int *)(_2+16)) = _64;
    Ref(_version_revision_inlined_version_revision_at_41_242);
    *((int *)(_2+20)) = _version_revision_inlined_version_revision_at_41_242;
    *((int *)(_2+24)) = _65;
    *((int *)(_2+28)) = _66;
    _67 = MAKE_SEQ(_1);
    _66 = NOVALUE;
    _65 = NOVALUE;
    _64 = NOVALUE;
    _63 = NOVALUE;
    _62 = NOVALUE;
    _61 = NOVALUE;
    _68 = EPrintf(-9999999, _60, _67);
    DeRefDS(_67);
    _67 = NOVALUE;
    return _68;
    goto L3; // [77] 132
L2: 

    /** 		return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _70 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _71 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _72 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _73 = (int)*(((s1_ptr)_2)->base + 4);
    _74 = _3version_node(0);
    _75 = _3version_date(_full_233);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_70);
    *((int *)(_2+4)) = _70;
    Ref(_71);
    *((int *)(_2+8)) = _71;
    Ref(_72);
    *((int *)(_2+12)) = _72;
    Ref(_73);
    *((int *)(_2+16)) = _73;
    *((int *)(_2+20)) = _74;
    *((int *)(_2+24)) = _75;
    _76 = MAKE_SEQ(_1);
    _75 = NOVALUE;
    _74 = NOVALUE;
    _73 = NOVALUE;
    _72 = NOVALUE;
    _71 = NOVALUE;
    _70 = NOVALUE;
    _77 = EPrintf(-9999999, _69, _76);
    DeRefDS(_76);
    _76 = NOVALUE;
    DeRef(_68);
    _68 = NOVALUE;
    return _77;
L3: 
    ;
}
int version_string() __attribute__ ((alias ("_3version_string")));


int _3version_string_short()
{
    int _80 = NOVALUE;
    int _79 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_79;
    RHS_Slice(_3version_info_163, 1, 3);
    _80 = EPrintf(-9999999, _78, _79);
    DeRefDS(_79);
    _79 = NOVALUE;
    return _80;
    ;
}
int version_string_short() __attribute__ ((alias ("_3version_string_short")));


int _3version_string_long(int _full_264)
{
    int _platform_name_inlined_platform_name_at_8_268 = NOVALUE;
    int _83 = NOVALUE;
    int _81 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_full_264)) {
        _1 = (long)(DBL_PTR(_full_264)->dbl);
        DeRefDS(_full_264);
        _full_264 = _1;
    }

    /** 	return version_string(full) & " for " & platform_name()*/
    _81 = _3version_string(_full_264);

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_22);
    DeRefi(_platform_name_inlined_platform_name_at_8_268);
    _platform_name_inlined_platform_name_at_8_268 = _22;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_268;
        concat_list[1] = _82;
        concat_list[2] = _81;
        Concat_N((object_ptr)&_83, concat_list, 3);
    }
    DeRef(_81);
    _81 = NOVALUE;
    return _83;
    ;
}
int version_string_long() __attribute__ ((alias ("_3version_string_long")));


int _3euphoria_copyright()
{
    int _version_string_long_1__tmp_at2_276 = NOVALUE;
    int _version_string_long_inlined_version_string_long_at_2_275 = NOVALUE;
    int _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274 = NOVALUE;
    int _87 = NOVALUE;
    int _85 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/

    /** 	return version_string(full) & " for " & platform_name()*/
    _0 = _version_string_long_1__tmp_at2_276;
    _version_string_long_1__tmp_at2_276 = _3version_string(0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_22);
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274 = _22;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274;
        concat_list[1] = _82;
        concat_list[2] = _version_string_long_1__tmp_at2_276;
        Concat_N((object_ptr)&_version_string_long_inlined_version_string_long_at_2_275, concat_list, 3);
    }
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_274 = NOVALUE;
    DeRef(_version_string_long_1__tmp_at2_276);
    _version_string_long_1__tmp_at2_276 = NOVALUE;
    Concat((object_ptr)&_85, _84, _version_string_long_inlined_version_string_long_at_2_275);
    RefDS(_86);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _85;
    ((int *)_2)[2] = _86;
    _87 = MAKE_SEQ(_1);
    _85 = NOVALUE;
    return _87;
    ;
}
int euphoria_copyright() __attribute__ ((alias ("_3euphoria_copyright")));


int _3pcre_copyright()
{
    int _90 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    RefDS(_89);
    RefDS(_88);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _88;
    ((int *)_2)[2] = _89;
    _90 = MAKE_SEQ(_1);
    return _90;
    ;
}
int pcre_copyright() __attribute__ ((alias ("_3pcre_copyright")));


int _3all_copyrights()
{
    int _pcre_copyright_inlined_pcre_copyright_at_5_289 = NOVALUE;
    int _92 = NOVALUE;
    int _91 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _91 = _3euphoria_copyright();

    /** 	return {*/
    RefDS(_89);
    RefDS(_88);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_5_289);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _88;
    ((int *)_2)[2] = _89;
    _pcre_copyright_inlined_pcre_copyright_at_5_289 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_5_289);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _91;
    ((int *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_5_289;
    _92 = MAKE_SEQ(_1);
    _91 = NOVALUE;
    return _92;
    ;
}
int all_copyrights() __attribute__ ((alias ("_3all_copyrights")));


int _3start_time()
{
    int _93 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[START_TIME]*/
    _2 = (int)SEQ_PTR(_3version_info_163);
    _93 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_93);
    return _93;
    ;
}
int start_time() __attribute__ ((alias ("_3start_time")));



// 0xB744F3E8
