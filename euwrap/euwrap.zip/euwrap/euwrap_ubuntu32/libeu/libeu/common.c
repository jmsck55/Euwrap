// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _49is_inetaddr(int _address_21556)
{
    int _12145 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:is_match(re_ip, address)*/
    Ref(_49re_ip_21545);
    RefDS(_address_21556);
    _12145 = _47is_match(_49re_ip_21545, _address_21556, 1, 0);
    DeRefDS(_address_21556);
    return _12145;
    ;
}
int is_inetaddr() __attribute__ ((alias ("_49is_inetaddr")));


int _49parse_ip_address(int _address_21560, int _port_21561)
{
    int _value_inlined_value_at_92_21582 = NOVALUE;
    int _st_inlined_value_at_89_21581 = NOVALUE;
    int _12163 = NOVALUE;
    int _12162 = NOVALUE;
    int _12160 = NOVALUE;
    int _12159 = NOVALUE;
    int _12158 = NOVALUE;
    int _12157 = NOVALUE;
    int _12155 = NOVALUE;
    int _12152 = NOVALUE;
    int _12149 = NOVALUE;
    int _12147 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_port_21561)) {
        _1 = (long)(DBL_PTR(_port_21561)->dbl);
        DeRefDS(_port_21561);
        _port_21561 = _1;
    }

    /** 	address = seq:split(address, ':')*/
    RefDS(_address_21560);
    _0 = _address_21560;
    _address_21560 = _23split(_address_21560, 58, 0, 0);
    DeRefDS(_0);

    /** 	if length(address) = 1 then*/
    if (IS_SEQUENCE(_address_21560)){
            _12147 = SEQ_PTR(_address_21560)->length;
    }
    else {
        _12147 = 1;
    }
    if (_12147 != 1)
    goto L1; // [21] 63

    /** 		if port < 0 or port > 65_535 then*/
    _12149 = (_port_21561 < 0);
    if (_12149 != 0) {
        goto L2; // [31] 44
    }
    _12152 = (_port_21561 > 65535);
    if (_12152 == 0)
    {
        DeRef(_12152);
        _12152 = NOVALUE;
        goto L3; // [40] 53
    }
    else{
        DeRef(_12152);
        _12152 = NOVALUE;
    }
L2: 

    /** 			address &= DEFAULT_PORT*/
    Append(&_address_21560, _address_21560, 80);
    goto L4; // [50] 161
L3: 

    /** 			address &= port*/
    Append(&_address_21560, _address_21560, _port_21561);
    goto L4; // [60] 161
L1: 

    /** 		if port < 0 or port > 65_535 then*/
    _12155 = (_port_21561 < 0);
    if (_12155 != 0) {
        goto L5; // [69] 82
    }
    _12157 = (_port_21561 > 65535);
    if (_12157 == 0)
    {
        DeRef(_12157);
        _12157 = NOVALUE;
        goto L6; // [78] 153
    }
    else{
        DeRef(_12157);
        _12157 = NOVALUE;
    }
L5: 

    /** 			address[2] = stdget:value(address[2])*/
    _2 = (int)SEQ_PTR(_address_21560);
    _12158 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_12158);
    DeRef(_st_inlined_value_at_89_21581);
    _st_inlined_value_at_89_21581 = _12158;
    _12158 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_st_inlined_value_at_89_21581);
    _0 = _value_inlined_value_at_92_21582;
    _value_inlined_value_at_92_21582 = _17get_value(_st_inlined_value_at_89_21581, 1, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);
    DeRef(_st_inlined_value_at_89_21581);
    _st_inlined_value_at_89_21581 = NOVALUE;
    Ref(_value_inlined_value_at_92_21582);
    _2 = (int)SEQ_PTR(_address_21560);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21560 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_92_21582;
    DeRef(_1);

    /** 			if address[2][1] != stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_address_21560);
    _12159 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_12159);
    _12160 = (int)*(((s1_ptr)_2)->base + 1);
    _12159 = NOVALUE;
    if (binary_op_a(EQUALS, _12160, 0)){
        _12160 = NOVALUE;
        goto L7; // [122] 135
    }
    _12160 = NOVALUE;

    /** 				address[2] = DEFAULT_PORT*/
    _2 = (int)SEQ_PTR(_address_21560);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21560 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 80;
    DeRef(_1);
    goto L8; // [132] 160
L7: 

    /** 				address[2] = address[2][2]*/
    _2 = (int)SEQ_PTR(_address_21560);
    _12162 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_12162);
    _12163 = (int)*(((s1_ptr)_2)->base + 2);
    _12162 = NOVALUE;
    Ref(_12163);
    _2 = (int)SEQ_PTR(_address_21560);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21560 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _12163;
    if( _1 != _12163 ){
        DeRef(_1);
    }
    _12163 = NOVALUE;
    goto L8; // [150] 160
L6: 

    /** 			address[2] = port*/
    _2 = (int)SEQ_PTR(_address_21560);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _address_21560 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _port_21561;
    DeRef(_1);
L8: 
L4: 

    /** 	return address*/
    DeRef(_12149);
    _12149 = NOVALUE;
    DeRef(_12155);
    _12155 = NOVALUE;
    return _address_21560;
    ;
}
int parse_ip_address() __attribute__ ((alias ("_49parse_ip_address")));


int _49parse_url(int _url_21602)
{
    int _m_21603 = NOVALUE;
    int _12179 = NOVALUE;
    int _12177 = NOVALUE;
    int _12176 = NOVALUE;
    int _12173 = NOVALUE;
    int _12171 = NOVALUE;
    int _12169 = NOVALUE;
    int _12166 = NOVALUE;
    int _12165 = NOVALUE;
    int _0, _1, _2;
    

    /** 	m = regex:matches(re_http_url, url)*/
    Ref(_49re_http_url_21548);
    RefDS(_url_21602);
    _0 = _m_21603;
    _m_21603 = _47matches(_49re_http_url_21548, _url_21602, 1, 0);
    DeRef(_0);

    /** 	if sequence(m) then*/
    _12165 = IS_SEQUENCE(_m_21603);
    if (_12165 == 0)
    {
        _12165 = NOVALUE;
        goto L1; // [19] 69
    }
    else{
        _12165 = NOVALUE;
    }

    /** 		if length(m) < URL_HTTP_PATH then*/
    if (IS_SEQUENCE(_m_21603)){
            _12166 = SEQ_PTR(_m_21603)->length;
    }
    else {
        _12166 = 1;
    }
    if (_12166 >= 4)
    goto L2; // [27] 42

    /** 			m &= { "/" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_12168);
    *((int *)(_2+4)) = _12168;
    _12169 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21603) && IS_ATOM(_12169)) {
    }
    else if (IS_ATOM(_m_21603) && IS_SEQUENCE(_12169)) {
        Ref(_m_21603);
        Prepend(&_m_21603, _12169, _m_21603);
    }
    else {
        Concat((object_ptr)&_m_21603, _m_21603, _12169);
    }
    DeRefDS(_12169);
    _12169 = NOVALUE;
L2: 

    /** 		if length(m) < URL_HTTP_QUERY then*/
    if (IS_SEQUENCE(_m_21603)){
            _12171 = SEQ_PTR(_m_21603)->length;
    }
    else {
        _12171 = 1;
    }
    if (_12171 >= 5)
    goto L3; // [47] 62

    /** 			m &= { "" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    _12173 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21603) && IS_ATOM(_12173)) {
    }
    else if (IS_ATOM(_m_21603) && IS_SEQUENCE(_12173)) {
        Ref(_m_21603);
        Prepend(&_m_21603, _12173, _m_21603);
    }
    else {
        Concat((object_ptr)&_m_21603, _m_21603, _12173);
    }
    DeRefDS(_12173);
    _12173 = NOVALUE;
L3: 

    /** 		return m*/
    DeRefDS(_url_21602);
    return _m_21603;
L1: 

    /** 	m = regex:matches(re_mail_url, url)*/
    Ref(_49re_mail_url_21551);
    RefDS(_url_21602);
    _0 = _m_21603;
    _m_21603 = _47matches(_49re_mail_url_21551, _url_21602, 1, 0);
    DeRef(_0);

    /** 	if sequence(m) then*/
    _12176 = IS_SEQUENCE(_m_21603);
    if (_12176 == 0)
    {
        _12176 = NOVALUE;
        goto L4; // [85] 115
    }
    else{
        _12176 = NOVALUE;
    }

    /** 		if length(m) < URL_MAIL_QUERY then*/
    if (IS_SEQUENCE(_m_21603)){
            _12177 = SEQ_PTR(_m_21603)->length;
    }
    else {
        _12177 = 1;
    }
    if (_12177 >= 6)
    goto L5; // [93] 108

    /** 			m &= { "" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    _12179 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_m_21603) && IS_ATOM(_12179)) {
    }
    else if (IS_ATOM(_m_21603) && IS_SEQUENCE(_12179)) {
        Ref(_m_21603);
        Prepend(&_m_21603, _12179, _m_21603);
    }
    else {
        Concat((object_ptr)&_m_21603, _m_21603, _12179);
    }
    DeRefDS(_12179);
    _12179 = NOVALUE;
L5: 

    /** 		return m*/
    DeRefDS(_url_21602);
    return _m_21603;
L4: 

    /** 	return regex:ERROR_NOMATCH*/
    DeRefDS(_url_21602);
    DeRef(_m_21603);
    return -1;
    ;
}
int parse_url() __attribute__ ((alias ("_49parse_url")));



// 0xFB803BF9
