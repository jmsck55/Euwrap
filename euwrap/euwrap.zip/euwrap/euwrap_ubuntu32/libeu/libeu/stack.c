// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _50stack(int _obj_p_22231)
{
    int _o_22235 = NOVALUE;
    int _12442 = NOVALUE;
    int _12441 = NOVALUE;
    int _12439 = NOVALUE;
    int _12437 = NOVALUE;
    int _12435 = NOVALUE;
    int _12434 = NOVALUE;
    int _12432 = NOVALUE;
    int _12430 = NOVALUE;
    int _12427 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_22231);
    RefDS(_5);
    _12427 = _28valid(_obj_p_22231, _5);
    if (IS_ATOM_INT(_12427)) {
        if (_12427 != 0){
            DeRef(_12427);
            _12427 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_12427)->dbl != 0.0){
            DeRef(_12427);
            _12427 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_12427);
    _12427 = NOVALUE;
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L1: 

    /** 	object o = eumem:ram_space[obj_p]*/
    DeRef(_o_22235);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_obj_p_22231)){
        _o_22235 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_22231)->dbl));
    }
    else{
        _o_22235 = (int)*(((s1_ptr)_2)->base + _obj_p_22231);
    }
    Ref(_o_22235);

    /** 	if not sequence(o) then return 0 end if*/
    _12430 = IS_SEQUENCE(_o_22235);
    if (_12430 != 0)
    goto L2; // [29] 37
    _12430 = NOVALUE;
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L2: 

    /** 	if length(o) != data then return 0 end if*/
    if (IS_SEQUENCE(_o_22235)){
            _12432 = SEQ_PTR(_o_22235)->length;
    }
    else {
        _12432 = 1;
    }
    if (_12432 == 3)
    goto L3; // [42] 51
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L3: 

    /** 	if not equal(o[type_tag], type_is_stack) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22235);
    _12434 = (int)*(((s1_ptr)_2)->base + 1);
    if (_12434 == _50type_is_stack_22227)
    _12435 = 1;
    else if (IS_ATOM_INT(_12434) && IS_ATOM_INT(_50type_is_stack_22227))
    _12435 = 0;
    else
    _12435 = (compare(_12434, _50type_is_stack_22227) == 0);
    _12434 = NOVALUE;
    if (_12435 != 0)
    goto L4; // [61] 69
    _12435 = NOVALUE;
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L4: 

    /** 	if not find(o[stack_type], { FIFO, FILO }) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22235);
    _12437 = (int)*(((s1_ptr)_2)->base + 2);
    _12439 = find_from(_12437, _12438, 1);
    _12437 = NOVALUE;
    if (_12439 != 0)
    goto L5; // [80] 88
    _12439 = NOVALUE;
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L5: 

    /** 	if not sequence(o[data]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22235);
    _12441 = (int)*(((s1_ptr)_2)->base + 3);
    _12442 = IS_SEQUENCE(_12441);
    _12441 = NOVALUE;
    if (_12442 != 0)
    goto L6; // [97] 105
    _12442 = NOVALUE;
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 0;
L6: 

    /** 	return 1*/
    DeRef(_obj_p_22231);
    DeRef(_o_22235);
    return 1;
    ;
}
int stack() __attribute__ ((alias ("_50stack")));


int _50new(int _typ_22258)
{
    int _new_stack_22259 = NOVALUE;
    int _12445 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_typ_22258)) {
        _1 = (long)(DBL_PTR(_typ_22258)->dbl);
        DeRefDS(_typ_22258);
        _typ_22258 = _1;
    }

    /** 	atom new_stack = eumem:malloc()*/
    _0 = _new_stack_22259;
    _new_stack_22259 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[new_stack] = { type_is_stack, typ, {} }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50type_is_stack_22227);
    *((int *)(_2+4)) = _50type_is_stack_22227;
    *((int *)(_2+8)) = _typ_22258;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _12445 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_new_stack_22259))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_new_stack_22259)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _new_stack_22259);
    _1 = *(int *)_2;
    *(int *)_2 = _12445;
    if( _1 != _12445 ){
        DeRef(_1);
    }
    _12445 = NOVALUE;

    /** 	return new_stack*/
    return _new_stack_22259;
    ;
}


int _50is_empty(int _sk_22264)
{
    int _12449 = NOVALUE;
    int _12448 = NOVALUE;
    int _12447 = NOVALUE;
    int _12446 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(eumem:ram_space[sk][data]) = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22264)){
        _12446 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22264)->dbl));
    }
    else{
        _12446 = (int)*(((s1_ptr)_2)->base + _sk_22264);
    }
    _2 = (int)SEQ_PTR(_12446);
    _12447 = (int)*(((s1_ptr)_2)->base + 3);
    _12446 = NOVALUE;
    if (IS_SEQUENCE(_12447)){
            _12448 = SEQ_PTR(_12447)->length;
    }
    else {
        _12448 = 1;
    }
    _12447 = NOVALUE;
    _12449 = (_12448 == 0);
    _12448 = NOVALUE;
    DeRef(_sk_22264);
    _12447 = NOVALUE;
    return _12449;
    ;
}
int is_empty() __attribute__ ((alias ("_50is_empty")));


int _50size(int _sk_22271)
{
    int _12452 = NOVALUE;
    int _12451 = NOVALUE;
    int _12450 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(eumem:ram_space[sk][data])*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22271)){
        _12450 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22271)->dbl));
    }
    else{
        _12450 = (int)*(((s1_ptr)_2)->base + _sk_22271);
    }
    _2 = (int)SEQ_PTR(_12450);
    _12451 = (int)*(((s1_ptr)_2)->base + 3);
    _12450 = NOVALUE;
    if (IS_SEQUENCE(_12451)){
            _12452 = SEQ_PTR(_12451)->length;
    }
    else {
        _12452 = 1;
    }
    _12451 = NOVALUE;
    DeRef(_sk_22271);
    _12451 = NOVALUE;
    return _12452;
    ;
}


int _50at(int _sk_22277, int _idx_22278)
{
    int _o_22279 = NOVALUE;
    int _oidx_22282 = NOVALUE;
    int _msg_inlined_crash_at_74_22297 = NOVALUE;
    int _12465 = NOVALUE;
    int _12463 = NOVALUE;
    int _12462 = NOVALUE;
    int _12460 = NOVALUE;
    int _12458 = NOVALUE;
    int _12457 = NOVALUE;
    int _12453 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22278)) {
        _1 = (long)(DBL_PTR(_idx_22278)->dbl);
        DeRefDS(_idx_22278);
        _idx_22278 = _1;
    }

    /** 	sequence o = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22277)){
        _12453 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22277)->dbl));
    }
    else{
        _12453 = (int)*(((s1_ptr)_2)->base + _sk_22277);
    }
    DeRef(_o_22279);
    _2 = (int)SEQ_PTR(_12453);
    _o_22279 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_o_22279);
    _12453 = NOVALUE;

    /** 	integer oidx = idx*/
    _oidx_22282 = _idx_22278;

    /** 	if idx <= 0 then*/
    if (_idx_22278 > 0)
    goto L1; // [24] 37

    /** 		idx = 1 - idx*/
    _idx_22278 = 1 - _idx_22278;
    goto L2; // [34] 51
L1: 

    /** 		idx = length(o) - idx + 1*/
    if (IS_SEQUENCE(_o_22279)){
            _12457 = SEQ_PTR(_o_22279)->length;
    }
    else {
        _12457 = 1;
    }
    _12458 = _12457 - _idx_22278;
    if ((long)((unsigned long)_12458 +(unsigned long) HIGH_BITS) >= 0){
        _12458 = NewDouble((double)_12458);
    }
    _12457 = NOVALUE;
    if (IS_ATOM_INT(_12458)) {
        _idx_22278 = _12458 + 1;
    }
    else
    { // coercing _idx_22278 to an integer 1
        _idx_22278 = 1+(long)(DBL_PTR(_12458)->dbl);
        if( !IS_ATOM_INT(_idx_22278) ){
            _idx_22278 = (object)DBL_PTR(_idx_22278)->dbl;
        }
    }
    DeRef(_12458);
    _12458 = NOVALUE;
L2: 

    /** 	if idx < 1 or idx > length(o) then*/
    _12460 = (_idx_22278 < 1);
    if (_12460 != 0) {
        goto L3; // [57] 73
    }
    if (IS_SEQUENCE(_o_22279)){
            _12462 = SEQ_PTR(_o_22279)->length;
    }
    else {
        _12462 = 1;
    }
    _12463 = (_idx_22278 > _12462);
    _12462 = NOVALUE;
    if (_12463 == 0)
    {
        DeRef(_12463);
        _12463 = NOVALUE;
        goto L4; // [69] 94
    }
    else{
        DeRef(_12463);
        _12463 = NOVALUE;
    }
L3: 

    /** 		error:crash("stack index (%d) out of bounds for at()", oidx)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_74_22297);
    _msg_inlined_crash_at_74_22297 = EPrintf(-9999999, _12464, _oidx_22282);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_74_22297);

    /** end procedure*/
    goto L5; // [88] 91
L5: 
    DeRefi(_msg_inlined_crash_at_74_22297);
    _msg_inlined_crash_at_74_22297 = NOVALUE;
L4: 

    /** 	return o[idx]*/
    _2 = (int)SEQ_PTR(_o_22279);
    _12465 = (int)*(((s1_ptr)_2)->base + _idx_22278);
    Ref(_12465);
    DeRef(_sk_22277);
    DeRefDS(_o_22279);
    DeRef(_12460);
    _12460 = NOVALUE;
    return _12465;
    ;
}
int at() __attribute__ ((alias ("_50at")));


void _50push(int _sk_22301, int _value_22302)
{
    int _msg_inlined_crash_at_106_22326 = NOVALUE;
    int _data_inlined_crash_at_103_22325 = NOVALUE;
    int _12483 = NOVALUE;
    int _12482 = NOVALUE;
    int _12481 = NOVALUE;
    int _12479 = NOVALUE;
    int _12478 = NOVALUE;
    int _12477 = NOVALUE;
    int _12475 = NOVALUE;
    int _12474 = NOVALUE;
    int _12473 = NOVALUE;
    int _12472 = NOVALUE;
    int _12470 = NOVALUE;
    int _12467 = NOVALUE;
    int _12466 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch eumem:ram_space[sk][stack_type] do*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22301)){
        _12466 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
    }
    else{
        _12466 = (int)*(((s1_ptr)_2)->base + _sk_22301);
    }
    _2 = (int)SEQ_PTR(_12466);
    _12467 = (int)*(((s1_ptr)_2)->base + 2);
    _12466 = NOVALUE;
    if (IS_SEQUENCE(_12467) ){
        goto L1; // [13] 86
    }
    if(!IS_ATOM_INT(_12467)){
        if( (DBL_PTR(_12467)->dbl != (double) ((int) DBL_PTR(_12467)->dbl) ) ){
            goto L1; // [13] 86
        }
        _0 = (int) DBL_PTR(_12467)->dbl;
    }
    else {
        _0 = _12467;
    };
    _12467 = NOVALUE;
    switch ( _0 ){ 

        /** 		case FIFO then*/
        case 1:

        /** 			eumem:ram_space[sk][data] = prepend(eumem:ram_space[sk][data], value)*/
        _2 = (int)SEQ_PTR(_28ram_space_10764);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _28ram_space_10764 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_sk_22301))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
        else
        _3 = (int)(_sk_22301 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_28ram_space_10764);
        if (!IS_ATOM_INT(_sk_22301)){
            _12472 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
        }
        else{
            _12472 = (int)*(((s1_ptr)_2)->base + _sk_22301);
        }
        _2 = (int)SEQ_PTR(_12472);
        _12473 = (int)*(((s1_ptr)_2)->base + 3);
        _12472 = NOVALUE;
        Ref(_value_22302);
        Prepend(&_12474, _12473, _value_22302);
        _12473 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _12474;
        if( _1 != _12474 ){
            DeRef(_1);
        }
        _12474 = NOVALUE;
        _12470 = NOVALUE;
        goto L2; // [49] 126

        /** 		case FILO then*/
        case 2:

        /** 			eumem:ram_space[sk][data] = append(eumem:ram_space[sk][data], value)*/
        _2 = (int)SEQ_PTR(_28ram_space_10764);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _28ram_space_10764 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_sk_22301))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
        else
        _3 = (int)(_sk_22301 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_28ram_space_10764);
        if (!IS_ATOM_INT(_sk_22301)){
            _12477 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
        }
        else{
            _12477 = (int)*(((s1_ptr)_2)->base + _sk_22301);
        }
        _2 = (int)SEQ_PTR(_12477);
        _12478 = (int)*(((s1_ptr)_2)->base + 3);
        _12477 = NOVALUE;
        Ref(_value_22302);
        Append(&_12479, _12478, _value_22302);
        _12478 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _12479;
        if( _1 != _12479 ){
            DeRef(_1);
        }
        _12479 = NOVALUE;
        _12475 = NOVALUE;
        goto L2; // [82] 126

        /** 		case else*/
        default:
L1: 

        /** 			error:crash("Internal error in stack.e: Stack %d has invalid stack type %d", {sk,eumem:ram_space[sk][stack_type]})*/
        _2 = (int)SEQ_PTR(_28ram_space_10764);
        if (!IS_ATOM_INT(_sk_22301)){
            _12481 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22301)->dbl));
        }
        else{
            _12481 = (int)*(((s1_ptr)_2)->base + _sk_22301);
        }
        _2 = (int)SEQ_PTR(_12481);
        _12482 = (int)*(((s1_ptr)_2)->base + 2);
        _12481 = NOVALUE;
        Ref(_12482);
        Ref(_sk_22301);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _sk_22301;
        ((int *)_2)[2] = _12482;
        _12483 = MAKE_SEQ(_1);
        _12482 = NOVALUE;
        DeRef(_data_inlined_crash_at_103_22325);
        _data_inlined_crash_at_103_22325 = _12483;
        _12483 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_106_22326);
        _msg_inlined_crash_at_106_22326 = EPrintf(-9999999, _12480, _data_inlined_crash_at_103_22325);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_106_22326);

        /** end procedure*/
        goto L3; // [120] 123
L3: 
        DeRef(_data_inlined_crash_at_103_22325);
        _data_inlined_crash_at_103_22325 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_106_22326);
        _msg_inlined_crash_at_106_22326 = NOVALUE;
    ;}L2: 

    /** end procedure*/
    DeRef(_sk_22301);
    DeRef(_value_22302);
    return;
    ;
}
void push() __attribute__ ((alias ("_50push")));


int _50top(int _sk_22329)
{
    int _msg_inlined_crash_at_21_22337 = NOVALUE;
    int _12492 = NOVALUE;
    int _12491 = NOVALUE;
    int _12490 = NOVALUE;
    int _12489 = NOVALUE;
    int _12486 = NOVALUE;
    int _12485 = NOVALUE;
    int _12484 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(eumem:ram_space[sk][data]) = 0 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22329)){
        _12484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22329)->dbl));
    }
    else{
        _12484 = (int)*(((s1_ptr)_2)->base + _sk_22329);
    }
    _2 = (int)SEQ_PTR(_12484);
    _12485 = (int)*(((s1_ptr)_2)->base + 3);
    _12484 = NOVALUE;
    if (IS_SEQUENCE(_12485)){
            _12486 = SEQ_PTR(_12485)->length;
    }
    else {
        _12486 = 1;
    }
    _12485 = NOVALUE;
    if (_12486 != 0)
    goto L1; // [16] 41

    /** 		error:crash("stack is empty so there is no top()", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_21_22337);
    _msg_inlined_crash_at_21_22337 = EPrintf(-9999999, _12488, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_21_22337);

    /** end procedure*/
    goto L2; // [35] 38
L2: 
    DeRefi(_msg_inlined_crash_at_21_22337);
    _msg_inlined_crash_at_21_22337 = NOVALUE;
L1: 

    /** 	return eumem:ram_space[sk][data][$]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22329)){
        _12489 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22329)->dbl));
    }
    else{
        _12489 = (int)*(((s1_ptr)_2)->base + _sk_22329);
    }
    _2 = (int)SEQ_PTR(_12489);
    _12490 = (int)*(((s1_ptr)_2)->base + 3);
    _12489 = NOVALUE;
    if (IS_SEQUENCE(_12490)){
            _12491 = SEQ_PTR(_12490)->length;
    }
    else {
        _12491 = 1;
    }
    _2 = (int)SEQ_PTR(_12490);
    _12492 = (int)*(((s1_ptr)_2)->base + _12491);
    _12490 = NOVALUE;
    Ref(_12492);
    DeRef(_sk_22329);
    _12485 = NOVALUE;
    return _12492;
    ;
}
int top() __attribute__ ((alias ("_50top")));


int _50last(int _sk_22344)
{
    int _msg_inlined_crash_at_21_22352 = NOVALUE;
    int _12500 = NOVALUE;
    int _12499 = NOVALUE;
    int _12498 = NOVALUE;
    int _12495 = NOVALUE;
    int _12494 = NOVALUE;
    int _12493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(eumem:ram_space[sk][data]) = 0 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22344)){
        _12493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22344)->dbl));
    }
    else{
        _12493 = (int)*(((s1_ptr)_2)->base + _sk_22344);
    }
    _2 = (int)SEQ_PTR(_12493);
    _12494 = (int)*(((s1_ptr)_2)->base + 3);
    _12493 = NOVALUE;
    if (IS_SEQUENCE(_12494)){
            _12495 = SEQ_PTR(_12494)->length;
    }
    else {
        _12495 = 1;
    }
    _12494 = NOVALUE;
    if (_12495 != 0)
    goto L1; // [16] 41

    /** 		error:crash("stack is empty so there is no last()", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_21_22352);
    _msg_inlined_crash_at_21_22352 = EPrintf(-9999999, _12497, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_21_22352);

    /** end procedure*/
    goto L2; // [35] 38
L2: 
    DeRefi(_msg_inlined_crash_at_21_22352);
    _msg_inlined_crash_at_21_22352 = NOVALUE;
L1: 

    /** 	return eumem:ram_space[sk][data][1]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22344)){
        _12498 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22344)->dbl));
    }
    else{
        _12498 = (int)*(((s1_ptr)_2)->base + _sk_22344);
    }
    _2 = (int)SEQ_PTR(_12498);
    _12499 = (int)*(((s1_ptr)_2)->base + 3);
    _12498 = NOVALUE;
    _2 = (int)SEQ_PTR(_12499);
    _12500 = (int)*(((s1_ptr)_2)->base + 1);
    _12499 = NOVALUE;
    Ref(_12500);
    DeRef(_sk_22344);
    _12494 = NOVALUE;
    return _12500;
    ;
}
int last() __attribute__ ((alias ("_50last")));


int _50pop(int _sk_22358, int _idx_22359)
{
    int _t_22360 = NOVALUE;
    int _msg_inlined_crash_at_49_22373 = NOVALUE;
    int _msg_inlined_crash_at_79_22379 = NOVALUE;
    int _data_inlined_crash_at_76_22378 = NOVALUE;
    int _top_obj_22383 = NOVALUE;
    int _12523 = NOVALUE;
    int _12522 = NOVALUE;
    int _12521 = NOVALUE;
    int _12520 = NOVALUE;
    int _12519 = NOVALUE;
    int _12518 = NOVALUE;
    int _12516 = NOVALUE;
    int _12513 = NOVALUE;
    int _12512 = NOVALUE;
    int _12511 = NOVALUE;
    int _12507 = NOVALUE;
    int _12506 = NOVALUE;
    int _12505 = NOVALUE;
    int _12503 = NOVALUE;
    int _12501 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_idx_22359)) {
        _1 = (long)(DBL_PTR(_idx_22359)->dbl);
        DeRefDS(_idx_22359);
        _idx_22359 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22358)){
        _12501 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22358)->dbl));
    }
    else{
        _12501 = (int)*(((s1_ptr)_2)->base + _sk_22358);
    }
    DeRef(_t_22360);
    _2 = (int)SEQ_PTR(_12501);
    _t_22360 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22360);
    _12501 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12503 = (_idx_22359 < 0);
    if (_12503 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22360)){
            _12505 = SEQ_PTR(_t_22360)->length;
    }
    else {
        _12505 = 1;
    }
    _12506 = (_idx_22359 > _12505);
    _12505 = NOVALUE;
    if (_12506 == 0)
    {
        DeRef(_12506);
        _12506 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12506);
        _12506 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22360)){
            _12507 = SEQ_PTR(_t_22360)->length;
    }
    else {
        _12507 = 1;
    }
    if (_12507 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot pop")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22373);
    _msg_inlined_crash_at_49_22373 = EPrintf(-9999999, _12509, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22373);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22373);
    _msg_inlined_crash_at_49_22373 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in pop()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22359;
    _12511 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22378);
    _data_inlined_crash_at_76_22378 = _12511;
    _12511 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22379);
    _msg_inlined_crash_at_79_22379 = EPrintf(-9999999, _12510, _data_inlined_crash_at_76_22378);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22379);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22378);
    _data_inlined_crash_at_76_22378 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22379);
    _msg_inlined_crash_at_79_22379 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22360)){
            _12512 = SEQ_PTR(_t_22360)->length;
    }
    else {
        _12512 = 1;
    }
    _12513 = _12512 - _idx_22359;
    if ((long)((unsigned long)_12513 +(unsigned long) HIGH_BITS) >= 0){
        _12513 = NewDouble((double)_12513);
    }
    _12512 = NOVALUE;
    if (IS_ATOM_INT(_12513)) {
        _idx_22359 = _12513 + 1;
    }
    else
    { // coercing _idx_22359 to an integer 1
        _idx_22359 = 1+(long)(DBL_PTR(_12513)->dbl);
        if( !IS_ATOM_INT(_idx_22359) ){
            _idx_22359 = (object)DBL_PTR(_idx_22359)->dbl;
        }
    }
    DeRef(_12513);
    _12513 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22383);
    _2 = (int)SEQ_PTR(_t_22360);
    _top_obj_22383 = (int)*(((s1_ptr)_2)->base + _idx_22359);
    Ref(_top_obj_22383);

    /** 	eumem:ram_space[sk][data] = t[1 .. idx - 1] & t[idx + 1 .. $]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22358))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22358)->dbl));
    else
    _3 = (int)(_sk_22358 + ((s1_ptr)_2)->base);
    _12518 = _idx_22359 - 1;
    rhs_slice_target = (object_ptr)&_12519;
    RHS_Slice(_t_22360, 1, _12518);
    _12520 = _idx_22359 + 1;
    if (_12520 > MAXINT){
        _12520 = NewDouble((double)_12520);
    }
    if (IS_SEQUENCE(_t_22360)){
            _12521 = SEQ_PTR(_t_22360)->length;
    }
    else {
        _12521 = 1;
    }
    rhs_slice_target = (object_ptr)&_12522;
    RHS_Slice(_t_22360, _12520, _12521);
    Concat((object_ptr)&_12523, _12519, _12522);
    DeRefDS(_12519);
    _12519 = NOVALUE;
    DeRef(_12519);
    _12519 = NOVALUE;
    DeRefDS(_12522);
    _12522 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _12523;
    if( _1 != _12523 ){
        DeRef(_1);
    }
    _12523 = NOVALUE;
    _12516 = NOVALUE;

    /** 	return top_obj*/
    DeRef(_sk_22358);
    DeRefDS(_t_22360);
    DeRef(_12503);
    _12503 = NOVALUE;
    _12518 = NOVALUE;
    DeRef(_12520);
    _12520 = NOVALUE;
    return _top_obj_22383;
    ;
}
int pop() __attribute__ ((alias ("_50pop")));


int _50peek_top(int _sk_22395, int _idx_22396)
{
    int _t_22397 = NOVALUE;
    int _msg_inlined_crash_at_49_22410 = NOVALUE;
    int _msg_inlined_crash_at_79_22416 = NOVALUE;
    int _data_inlined_crash_at_76_22415 = NOVALUE;
    int _top_obj_22420 = NOVALUE;
    int _12536 = NOVALUE;
    int _12535 = NOVALUE;
    int _12534 = NOVALUE;
    int _12530 = NOVALUE;
    int _12529 = NOVALUE;
    int _12528 = NOVALUE;
    int _12526 = NOVALUE;
    int _12524 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22396)) {
        _1 = (long)(DBL_PTR(_idx_22396)->dbl);
        DeRefDS(_idx_22396);
        _idx_22396 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22395)){
        _12524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22395)->dbl));
    }
    else{
        _12524 = (int)*(((s1_ptr)_2)->base + _sk_22395);
    }
    DeRef(_t_22397);
    _2 = (int)SEQ_PTR(_12524);
    _t_22397 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22397);
    _12524 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12526 = (_idx_22396 < 0);
    if (_12526 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22397)){
            _12528 = SEQ_PTR(_t_22397)->length;
    }
    else {
        _12528 = 1;
    }
    _12529 = (_idx_22396 > _12528);
    _12528 = NOVALUE;
    if (_12529 == 0)
    {
        DeRef(_12529);
        _12529 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12529);
        _12529 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22397)){
            _12530 = SEQ_PTR(_t_22397)->length;
    }
    else {
        _12530 = 1;
    }
    if (_12530 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot peek_top")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22410);
    _msg_inlined_crash_at_49_22410 = EPrintf(-9999999, _12532, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22410);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22410);
    _msg_inlined_crash_at_49_22410 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in peek_top()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22396;
    _12534 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22415);
    _data_inlined_crash_at_76_22415 = _12534;
    _12534 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22416);
    _msg_inlined_crash_at_79_22416 = EPrintf(-9999999, _12533, _data_inlined_crash_at_76_22415);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22416);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22415);
    _data_inlined_crash_at_76_22415 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22416);
    _msg_inlined_crash_at_79_22416 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22397)){
            _12535 = SEQ_PTR(_t_22397)->length;
    }
    else {
        _12535 = 1;
    }
    _12536 = _12535 - _idx_22396;
    if ((long)((unsigned long)_12536 +(unsigned long) HIGH_BITS) >= 0){
        _12536 = NewDouble((double)_12536);
    }
    _12535 = NOVALUE;
    if (IS_ATOM_INT(_12536)) {
        _idx_22396 = _12536 + 1;
    }
    else
    { // coercing _idx_22396 to an integer 1
        _idx_22396 = 1+(long)(DBL_PTR(_12536)->dbl);
        if( !IS_ATOM_INT(_idx_22396) ){
            _idx_22396 = (object)DBL_PTR(_idx_22396)->dbl;
        }
    }
    DeRef(_12536);
    _12536 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22420);
    _2 = (int)SEQ_PTR(_t_22397);
    _top_obj_22420 = (int)*(((s1_ptr)_2)->base + _idx_22396);
    Ref(_top_obj_22420);

    /** 	return top_obj*/
    DeRef(_sk_22395);
    DeRefDS(_t_22397);
    DeRef(_12526);
    _12526 = NOVALUE;
    return _top_obj_22420;
    ;
}
int peek_top() __attribute__ ((alias ("_50peek_top")));


int _50peek_end(int _sk_22424, int _idx_22425)
{
    int _t_22426 = NOVALUE;
    int _msg_inlined_crash_at_49_22439 = NOVALUE;
    int _msg_inlined_crash_at_79_22445 = NOVALUE;
    int _data_inlined_crash_at_76_22444 = NOVALUE;
    int _top_obj_22449 = NOVALUE;
    int _12551 = NOVALUE;
    int _12550 = NOVALUE;
    int _12549 = NOVALUE;
    int _12545 = NOVALUE;
    int _12544 = NOVALUE;
    int _12543 = NOVALUE;
    int _12541 = NOVALUE;
    int _12539 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22425)) {
        _1 = (long)(DBL_PTR(_idx_22425)->dbl);
        DeRefDS(_idx_22425);
        _idx_22425 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22424)){
        _12539 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22424)->dbl));
    }
    else{
        _12539 = (int)*(((s1_ptr)_2)->base + _sk_22424);
    }
    DeRef(_t_22426);
    _2 = (int)SEQ_PTR(_12539);
    _t_22426 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22426);
    _12539 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12541 = (_idx_22425 < 0);
    if (_12541 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22426)){
            _12543 = SEQ_PTR(_t_22426)->length;
    }
    else {
        _12543 = 1;
    }
    _12544 = (_idx_22425 > _12543);
    _12543 = NOVALUE;
    if (_12544 == 0)
    {
        DeRef(_12544);
        _12544 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12544);
        _12544 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22426)){
            _12545 = SEQ_PTR(_t_22426)->length;
    }
    else {
        _12545 = 1;
    }
    if (_12545 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot peek_end")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22439);
    _msg_inlined_crash_at_49_22439 = EPrintf(-9999999, _12547, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22439);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22439);
    _msg_inlined_crash_at_49_22439 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in peek_end()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22425;
    _12549 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22444);
    _data_inlined_crash_at_76_22444 = _12549;
    _12549 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22445);
    _msg_inlined_crash_at_79_22445 = EPrintf(-9999999, _12548, _data_inlined_crash_at_76_22444);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22445);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22444);
    _data_inlined_crash_at_76_22444 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22445);
    _msg_inlined_crash_at_79_22445 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22426)){
            _12550 = SEQ_PTR(_t_22426)->length;
    }
    else {
        _12550 = 1;
    }
    _12551 = _12550 - _idx_22425;
    if ((long)((unsigned long)_12551 +(unsigned long) HIGH_BITS) >= 0){
        _12551 = NewDouble((double)_12551);
    }
    _12550 = NOVALUE;
    if (IS_ATOM_INT(_12551)) {
        _idx_22425 = _12551 + 1;
    }
    else
    { // coercing _idx_22425 to an integer 1
        _idx_22425 = 1+(long)(DBL_PTR(_12551)->dbl);
        if( !IS_ATOM_INT(_idx_22425) ){
            _idx_22425 = (object)DBL_PTR(_idx_22425)->dbl;
        }
    }
    DeRef(_12551);
    _12551 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22449);
    _2 = (int)SEQ_PTR(_t_22426);
    _top_obj_22449 = (int)*(((s1_ptr)_2)->base + _idx_22425);
    Ref(_top_obj_22449);

    /** 	return top_obj*/
    DeRef(_sk_22424);
    DeRefDS(_t_22426);
    DeRef(_12541);
    _12541 = NOVALUE;
    return _top_obj_22449;
    ;
}
int peek_end() __attribute__ ((alias ("_50peek_end")));


void _50swap(int _sk_22453)
{
    int _t_22454 = NOVALUE;
    int _msg_inlined_crash_at_25_22462 = NOVALUE;
    int _tmp_22463 = NOVALUE;
    int _12567 = NOVALUE;
    int _12566 = NOVALUE;
    int _12565 = NOVALUE;
    int _12564 = NOVALUE;
    int _12563 = NOVALUE;
    int _12562 = NOVALUE;
    int _12561 = NOVALUE;
    int _12559 = NOVALUE;
    int _12556 = NOVALUE;
    int _12554 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22453)){
        _12554 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22453)->dbl));
    }
    else{
        _12554 = (int)*(((s1_ptr)_2)->base + _sk_22453);
    }
    DeRef(_t_22454);
    _2 = (int)SEQ_PTR(_12554);
    _t_22454 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22454);
    _12554 = NOVALUE;

    /** 	if length(t) < 2 then*/
    if (IS_SEQUENCE(_t_22454)){
            _12556 = SEQ_PTR(_t_22454)->length;
    }
    else {
        _12556 = 1;
    }
    if (_12556 >= 2)
    goto L1; // [20] 45

    /** 		error:crash("swap() needs at least 2 items in the stack", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_25_22462);
    _msg_inlined_crash_at_25_22462 = EPrintf(-9999999, _12558, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_25_22462);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRefi(_msg_inlined_crash_at_25_22462);
    _msg_inlined_crash_at_25_22462 = NOVALUE;
L1: 

    /** 	object tmp = t[$]*/
    if (IS_SEQUENCE(_t_22454)){
            _12559 = SEQ_PTR(_t_22454)->length;
    }
    else {
        _12559 = 1;
    }
    DeRef(_tmp_22463);
    _2 = (int)SEQ_PTR(_t_22454);
    _tmp_22463 = (int)*(((s1_ptr)_2)->base + _12559);
    Ref(_tmp_22463);

    /** 	t[$] = t[$-1]*/
    if (IS_SEQUENCE(_t_22454)){
            _12561 = SEQ_PTR(_t_22454)->length;
    }
    else {
        _12561 = 1;
    }
    if (IS_SEQUENCE(_t_22454)){
            _12562 = SEQ_PTR(_t_22454)->length;
    }
    else {
        _12562 = 1;
    }
    _12563 = _12562 - 1;
    _12562 = NOVALUE;
    _2 = (int)SEQ_PTR(_t_22454);
    _12564 = (int)*(((s1_ptr)_2)->base + _12563);
    Ref(_12564);
    _2 = (int)SEQ_PTR(_t_22454);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_22454 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12561);
    _1 = *(int *)_2;
    *(int *)_2 = _12564;
    if( _1 != _12564 ){
        DeRef(_1);
    }
    _12564 = NOVALUE;

    /** 	t[$-1] = tmp*/
    if (IS_SEQUENCE(_t_22454)){
            _12565 = SEQ_PTR(_t_22454)->length;
    }
    else {
        _12565 = 1;
    }
    _12566 = _12565 - 1;
    _12565 = NOVALUE;
    Ref(_tmp_22463);
    _2 = (int)SEQ_PTR(_t_22454);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_22454 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12566);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_22463;
    DeRef(_1);

    /** 	eumem:ram_space[sk][data] = t*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22453))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22453)->dbl));
    else
    _3 = (int)(_sk_22453 + ((s1_ptr)_2)->base);
    RefDS(_t_22454);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _t_22454;
    DeRef(_1);
    _12567 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22453);
    DeRefDS(_t_22454);
    DeRef(_tmp_22463);
    _12563 = NOVALUE;
    _12566 = NOVALUE;
    return;
    ;
}
void swap() __attribute__ ((alias ("_50swap")));


void _50dup(int _sk_22476)
{
    int _t_22477 = NOVALUE;
    int _msg_inlined_crash_at_25_22485 = NOVALUE;
    int _12578 = NOVALUE;
    int _12577 = NOVALUE;
    int _12576 = NOVALUE;
    int _12574 = NOVALUE;
    int _12571 = NOVALUE;
    int _12569 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22476)){
        _12569 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22476)->dbl));
    }
    else{
        _12569 = (int)*(((s1_ptr)_2)->base + _sk_22476);
    }
    DeRef(_t_22477);
    _2 = (int)SEQ_PTR(_12569);
    _t_22477 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22477);
    _12569 = NOVALUE;

    /** 	if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22477)){
            _12571 = SEQ_PTR(_t_22477)->length;
    }
    else {
        _12571 = 1;
    }
    if (_12571 != 0)
    goto L1; // [20] 45

    /** 		error:crash("dup() needs at least one item in the stack", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_25_22485);
    _msg_inlined_crash_at_25_22485 = EPrintf(-9999999, _12573, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_25_22485);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRefi(_msg_inlined_crash_at_25_22485);
    _msg_inlined_crash_at_25_22485 = NOVALUE;
L1: 

    /** 	eumem:ram_space[sk][data] = append(t, t[$])*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22476))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22476)->dbl));
    else
    _3 = (int)(_sk_22476 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_t_22477)){
            _12576 = SEQ_PTR(_t_22477)->length;
    }
    else {
        _12576 = 1;
    }
    _2 = (int)SEQ_PTR(_t_22477);
    _12577 = (int)*(((s1_ptr)_2)->base + _12576);
    Ref(_12577);
    Append(&_12578, _t_22477, _12577);
    _12577 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _12578;
    if( _1 != _12578 ){
        DeRef(_1);
    }
    _12578 = NOVALUE;
    _12574 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22476);
    DeRefDS(_t_22477);
    return;
    ;
}
void dup() __attribute__ ((alias ("_50dup")));


void _50set(int _sk_22493, int _val_22494, int _idx_22495)
{
    int _o_22496 = NOVALUE;
    int _oidx_22499 = NOVALUE;
    int _msg_inlined_crash_at_74_22514 = NOVALUE;
    int _12591 = NOVALUE;
    int _12589 = NOVALUE;
    int _12588 = NOVALUE;
    int _12586 = NOVALUE;
    int _12584 = NOVALUE;
    int _12583 = NOVALUE;
    int _12579 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_idx_22495)) {
        _1 = (long)(DBL_PTR(_idx_22495)->dbl);
        DeRefDS(_idx_22495);
        _idx_22495 = _1;
    }

    /** 	sequence o = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_sk_22493)){
        _12579 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22493)->dbl));
    }
    else{
        _12579 = (int)*(((s1_ptr)_2)->base + _sk_22493);
    }
    DeRef(_o_22496);
    _2 = (int)SEQ_PTR(_12579);
    _o_22496 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_o_22496);
    _12579 = NOVALUE;

    /** 	integer oidx = idx*/
    _oidx_22499 = _idx_22495;

    /** 	if idx <= 0 then*/
    if (_idx_22495 > 0)
    goto L1; // [24] 37

    /** 		idx = 1 - idx*/
    _idx_22495 = 1 - _idx_22495;
    goto L2; // [34] 51
L1: 

    /** 		idx = length(o) - idx + 1*/
    if (IS_SEQUENCE(_o_22496)){
            _12583 = SEQ_PTR(_o_22496)->length;
    }
    else {
        _12583 = 1;
    }
    _12584 = _12583 - _idx_22495;
    if ((long)((unsigned long)_12584 +(unsigned long) HIGH_BITS) >= 0){
        _12584 = NewDouble((double)_12584);
    }
    _12583 = NOVALUE;
    if (IS_ATOM_INT(_12584)) {
        _idx_22495 = _12584 + 1;
    }
    else
    { // coercing _idx_22495 to an integer 1
        _idx_22495 = 1+(long)(DBL_PTR(_12584)->dbl);
        if( !IS_ATOM_INT(_idx_22495) ){
            _idx_22495 = (object)DBL_PTR(_idx_22495)->dbl;
        }
    }
    DeRef(_12584);
    _12584 = NOVALUE;
L2: 

    /** 	if idx < 1 or idx > length(o) then*/
    _12586 = (_idx_22495 < 1);
    if (_12586 != 0) {
        goto L3; // [57] 73
    }
    if (IS_SEQUENCE(_o_22496)){
            _12588 = SEQ_PTR(_o_22496)->length;
    }
    else {
        _12588 = 1;
    }
    _12589 = (_idx_22495 > _12588);
    _12588 = NOVALUE;
    if (_12589 == 0)
    {
        DeRef(_12589);
        _12589 = NOVALUE;
        goto L4; // [69] 94
    }
    else{
        DeRef(_12589);
        _12589 = NOVALUE;
    }
L3: 

    /** 		error:crash("stack index (%d) out of bounds for set()", oidx)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_74_22514);
    _msg_inlined_crash_at_74_22514 = EPrintf(-9999999, _12590, _oidx_22499);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_74_22514);

    /** end procedure*/
    goto L5; // [88] 91
L5: 
    DeRefi(_msg_inlined_crash_at_74_22514);
    _msg_inlined_crash_at_74_22514 = NOVALUE;
L4: 

    /** 	eumem:ram_space[sk][data][idx] = val*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22493))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22493)->dbl));
    else
    _3 = (int)(_sk_22493 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(3 + ((s1_ptr)_2)->base);
    _12591 = NOVALUE;
    Ref(_val_22494);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_22495);
    _1 = *(int *)_2;
    *(int *)_2 = _val_22494;
    DeRef(_1);
    _12591 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22493);
    DeRef(_val_22494);
    DeRef(_o_22496);
    DeRef(_12586);
    _12586 = NOVALUE;
    return;
    ;
}


void _50clear(int _sk_22519)
{
    int _12593 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eumem:ram_space[sk][data] = {}*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22519))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22519)->dbl));
    else
    _3 = (int)(_sk_22519 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _12593 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22519);
    return;
    ;
}



// 0x3A019098
