// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _30encode(int _in_12019, int _wrap_column_12020)
{
    int _len_12021 = NOVALUE;
    int _oidx_12022 = NOVALUE;
    int _prev_12023 = NOVALUE;
    int _case4_12024 = NOVALUE;
    int _tmp_12025 = NOVALUE;
    int _inch_12026 = NOVALUE;
    int _result_12027 = NOVALUE;
    int _6845 = NOVALUE;
    int _6842 = NOVALUE;
    int _6841 = NOVALUE;
    int _6839 = NOVALUE;
    int _6838 = NOVALUE;
    int _6837 = NOVALUE;
    int _6836 = NOVALUE;
    int _6834 = NOVALUE;
    int _6832 = NOVALUE;
    int _6831 = NOVALUE;
    int _6830 = NOVALUE;
    int _6829 = NOVALUE;
    int _6828 = NOVALUE;
    int _6827 = NOVALUE;
    int _6826 = NOVALUE;
    int _6824 = NOVALUE;
    int _6823 = NOVALUE;
    int _6821 = NOVALUE;
    int _6818 = NOVALUE;
    int _6817 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_wrap_column_12020)) {
        _1 = (long)(DBL_PTR(_wrap_column_12020)->dbl);
        DeRefDS(_wrap_column_12020);
        _wrap_column_12020 = _1;
    }

    /** 	len = length(in)*/
    if (IS_SEQUENCE(_in_12019)){
            _len_12021 = SEQ_PTR(_in_12019)->length;
    }
    else {
        _len_12021 = 1;
    }

    /** 	oidx = floor((len + 2) / 3) * 4*/
    _6817 = _len_12021 + 2;
    if (3 > 0 && _6817 >= 0) {
        _6818 = _6817 / 3;
    }
    else {
        temp_dbl = floor((double)_6817 / (double)3);
        _6818 = (long)temp_dbl;
    }
    _6817 = NOVALUE;
    _oidx_12022 = _6818 * 4;
    _6818 = NOVALUE;

    /** 	result = repeat('=', oidx)*/
    DeRef(_result_12027);
    _result_12027 = Repeat(61, _oidx_12022);

    /** 	if remainder(len, 3) != 0 then*/
    _6821 = (_len_12021 % 3);
    if (_6821 == 0)
    goto L1; // [38] 59

    /** 		oidx = oidx + remainder(len, 3) - 3*/
    _6823 = (_len_12021 % 3);
    _6824 = _oidx_12022 + _6823;
    if ((long)((unsigned long)_6824 + (unsigned long)HIGH_BITS) >= 0) 
    _6824 = NewDouble((double)_6824);
    _6823 = NOVALUE;
    if (IS_ATOM_INT(_6824)) {
        _oidx_12022 = _6824 - 3;
    }
    else {
        _oidx_12022 = NewDouble(DBL_PTR(_6824)->dbl - (double)3);
    }
    DeRef(_6824);
    _6824 = NOVALUE;
    if (!IS_ATOM_INT(_oidx_12022)) {
        _1 = (long)(DBL_PTR(_oidx_12022)->dbl);
        DeRefDS(_oidx_12022);
        _oidx_12022 = _1;
    }
L1: 

    /** 	case4 = 1*/
    _case4_12024 = 1;

    /** 	inch  = 1*/
    _inch_12026 = 1;

    /** 	for i = 1 to oidx do*/
    _6826 = _oidx_12022;
    {
        int _i_12040;
        _i_12040 = 1;
L2: 
        if (_i_12040 > _6826){
            goto L3; // [74] 226
        }

        /** 		tmp = 0*/
        _tmp_12025 = 0;

        /** 		if ediv[case4] > 0 and inch <= len then*/
        _2 = (int)SEQ_PTR(_30ediv_11997);
        _6827 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        _6828 = (_6827 > 0);
        _6827 = NOVALUE;
        if (_6828 == 0) {
            goto L4; // [98] 129
        }
        _6830 = (_inch_12026 <= _len_12021);
        if (_6830 == 0)
        {
            DeRef(_6830);
            _6830 = NOVALUE;
            goto L4; // [107] 129
        }
        else{
            DeRef(_6830);
            _6830 = NOVALUE;
        }

        /** 			tmp = floor(in[inch] / ediv[case4])*/
        _2 = (int)SEQ_PTR(_in_12019);
        _6831 = (int)*(((s1_ptr)_2)->base + _inch_12026);
        _2 = (int)SEQ_PTR(_30ediv_11997);
        _6832 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        if (IS_ATOM_INT(_6831)) {
            if (_6832 > 0 && _6831 >= 0) {
                _tmp_12025 = _6831 / _6832;
            }
            else {
                temp_dbl = floor((double)_6831 / (double)_6832);
                _tmp_12025 = (long)temp_dbl;
            }
        }
        else {
            _2 = binary_op(DIVIDE, _6831, _6832);
            _tmp_12025 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _6831 = NOVALUE;
        _6832 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12025)) {
            _1 = (long)(DBL_PTR(_tmp_12025)->dbl);
            DeRefDS(_tmp_12025);
            _tmp_12025 = _1;
        }
L4: 

        /** 		if erem[case4] > 0 then*/
        _2 = (int)SEQ_PTR(_30erem_11999);
        _6834 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        if (_6834 <= 0)
        goto L5; // [137] 172

        /** 			tmp += remainder(prev, erem[case4]) * emul[case4]*/
        _2 = (int)SEQ_PTR(_30erem_11999);
        _6836 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        _6837 = (_prev_12023 % _6836);
        _6836 = NOVALUE;
        _2 = (int)SEQ_PTR(_30emul_12001);
        _6838 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        if (_6837 == (short)_6837 && _6838 <= INT15 && _6838 >= -INT15)
        _6839 = _6837 * _6838;
        else
        _6839 = NewDouble(_6837 * (double)_6838);
        _6837 = NOVALUE;
        _6838 = NOVALUE;
        if (IS_ATOM_INT(_6839)) {
            _tmp_12025 = _tmp_12025 + _6839;
        }
        else {
            _tmp_12025 = NewDouble((double)_tmp_12025 + DBL_PTR(_6839)->dbl);
        }
        DeRef(_6839);
        _6839 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12025)) {
            _1 = (long)(DBL_PTR(_tmp_12025)->dbl);
            DeRefDS(_tmp_12025);
            _tmp_12025 = _1;
        }
L5: 

        /** 		result[i] = aleph[tmp + 1] --# and encode it*/
        _6841 = _tmp_12025 + 1;
        _2 = (int)SEQ_PTR(_30aleph_11980);
        _6842 = (int)*(((s1_ptr)_2)->base + _6841);
        Ref(_6842);
        _2 = (int)SEQ_PTR(_result_12027);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_12027 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12040);
        _1 = *(int *)_2;
        *(int *)_2 = _6842;
        if( _1 != _6842 ){
            DeRef(_1);
        }
        _6842 = NOVALUE;

        /** 		if inch <= len then*/
        if (_inch_12026 > _len_12021)
        goto L6; // [188] 199

        /** 			prev = in[inch]*/
        _2 = (int)SEQ_PTR(_in_12019);
        _prev_12023 = (int)*(((s1_ptr)_2)->base + _inch_12026);
        if (!IS_ATOM_INT(_prev_12023))
        _prev_12023 = (long)DBL_PTR(_prev_12023)->dbl;
L6: 

        /** 		inch += next[case4]*/
        _2 = (int)SEQ_PTR(_30next_12011);
        _6845 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        _inch_12026 = _inch_12026 + _6845;
        _6845 = NOVALUE;

        /** 		case4 = nc4[case4]*/
        _2 = (int)SEQ_PTR(_30nc4_12009);
        _case4_12024 = (int)*(((s1_ptr)_2)->base + _case4_12024);
        if (!IS_ATOM_INT(_case4_12024))
        _case4_12024 = (long)DBL_PTR(_case4_12024)->dbl;

        /** 	end for*/
        _i_12040 = _i_12040 + 1;
        goto L2; // [221] 81
L3: 
        ;
    }

    /** 	if wrap_column > 0 then*/
    if (_wrap_column_12020 <= 0)
    goto L7; // [228] 252

    /** 		result = stdseq:breakup(result, wrap_column)*/
    RefDS(_result_12027);
    _0 = _result_12027;
    _result_12027 = _23breakup(_result_12027, _wrap_column_12020, 1);
    DeRefDS(_0);

    /** 		result = stdseq:join(result, "\r\n")*/
    RefDS(_result_12027);
    RefDS(_1296);
    _0 = _result_12027;
    _result_12027 = _23join(_result_12027, _1296);
    DeRefDS(_0);
L7: 

    /** 	return result*/
    DeRefDS(_in_12019);
    DeRef(_6821);
    _6821 = NOVALUE;
    _6834 = NOVALUE;
    DeRef(_6828);
    _6828 = NOVALUE;
    DeRef(_6841);
    _6841 = NOVALUE;
    return _result_12027;
    ;
}


int _30decode(int _in_12072)
{
    int _len_12073 = NOVALUE;
    int _oidx_12074 = NOVALUE;
    int _case3_12075 = NOVALUE;
    int _tmp_12076 = NOVALUE;
    int _result_12077 = NOVALUE;
    int _ccha_12078 = NOVALUE;
    int _6878 = NOVALUE;
    int _6876 = NOVALUE;
    int _6875 = NOVALUE;
    int _6874 = NOVALUE;
    int _6873 = NOVALUE;
    int _6871 = NOVALUE;
    int _6870 = NOVALUE;
    int _6869 = NOVALUE;
    int _6868 = NOVALUE;
    int _6867 = NOVALUE;
    int _6866 = NOVALUE;
    int _6864 = NOVALUE;
    int _6863 = NOVALUE;
    int _6857 = NOVALUE;
    int _6855 = NOVALUE;
    int _6853 = NOVALUE;
    int _0, _1, _2;
    

    /** 	in = search:match_replace("\r\n", in, "")*/
    RefDS(_1296);
    RefDS(_in_12072);
    RefDS(_5);
    _0 = _in_12072;
    _in_12072 = _9match_replace(_1296, _in_12072, _5, 0);
    DeRefDS(_0);

    /** 	len = length(in)*/
    if (IS_SEQUENCE(_in_12072)){
            _len_12073 = SEQ_PTR(_in_12072)->length;
    }
    else {
        _len_12073 = 1;
    }

    /** 	if remainder(len, 4) != 0 then*/
    _6853 = (_len_12073 % 4);
    if (_6853 == 0)
    goto L1; // [25] 36

    /** 		return -1*/
    DeRefDS(_in_12072);
    DeRefi(_result_12077);
    DeRefi(_ccha_12078);
    _6853 = NOVALUE;
    return -1;
L1: 

    /** 	oidx = (len / 4) * 3*/
    _6855 = (_len_12073 % 4) ? NewDouble((double)_len_12073 / 4) : (_len_12073 / 4);
    if (IS_ATOM_INT(_6855)) {
        _oidx_12074 = _6855 * 3;
    }
    else {
        _oidx_12074 = NewDouble(DBL_PTR(_6855)->dbl * (double)3);
    }
    DeRef(_6855);
    _6855 = NOVALUE;
    if (!IS_ATOM_INT(_oidx_12074)) {
        _1 = (long)(DBL_PTR(_oidx_12074)->dbl);
        DeRefDS(_oidx_12074);
        _oidx_12074 = _1;
    }

    /** 	case3 = 3*/
    _case3_12075 = 3;

    /** 	while in[len] = '=' do	--# should only happen 0 1 or 2 times*/
L2: 
    _2 = (int)SEQ_PTR(_in_12072);
    _6857 = (int)*(((s1_ptr)_2)->base + _len_12073);
    if (binary_op_a(NOTEQ, _6857, 61)){
        _6857 = NOVALUE;
        goto L3; // [62] 89
    }
    _6857 = NOVALUE;

    /** 		oidx -= 1*/
    _oidx_12074 = _oidx_12074 - 1;

    /** 		case3 = nc3[case3]*/
    _2 = (int)SEQ_PTR(_30nc3_12013);
    _case3_12075 = (int)*(((s1_ptr)_2)->base + _case3_12075);
    if (!IS_ATOM_INT(_case3_12075))
    _case3_12075 = (long)DBL_PTR(_case3_12075)->dbl;

    /** 		len -= 1*/
    _len_12073 = _len_12073 - 1;

    /** 	end while*/
    goto L2; // [86] 58
L3: 

    /** 	ccha = repeat(0, 256)*/
    DeRefi(_ccha_12078);
    _ccha_12078 = Repeat(0, 256);

    /** 	for i = 1 to 64 do*/
    {
        int _i_12094;
        _i_12094 = 1;
L4: 
        if (_i_12094 > 64){
            goto L5; // [97] 125
        }

        /** 		ccha[aleph[i]] = i - 1*/
        _2 = (int)SEQ_PTR(_30aleph_11980);
        _6863 = (int)*(((s1_ptr)_2)->base + _i_12094);
        _6864 = _i_12094 - 1;
        _2 = (int)SEQ_PTR(_ccha_12078);
        if (!IS_ATOM_INT(_6863))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_6863)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _6863);
        *(int *)_2 = _6864;
        if( _1 != _6864 ){
        }
        _6864 = NOVALUE;

        /** 	end for	*/
        _i_12094 = _i_12094 + 1;
        goto L4; // [120] 104
L5: 
        ;
    }

    /** 	result = repeat('?', oidx)*/
    DeRefi(_result_12077);
    _result_12077 = Repeat(63, _oidx_12074);

    /** 	for i = oidx to 1 by -1 do*/
    {
        int _i_12099;
        _i_12099 = _oidx_12074;
L6: 
        if (_i_12099 < 1){
            goto L7; // [133] 227
        }

        /** 		tmp = remainder(ccha[in[len - 1]], drem[case3]) * dmul[case3]*/
        _6866 = _len_12073 - 1;
        _2 = (int)SEQ_PTR(_in_12072);
        _6867 = (int)*(((s1_ptr)_2)->base + _6866);
        _2 = (int)SEQ_PTR(_ccha_12078);
        if (!IS_ATOM_INT(_6867)){
            _6868 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6867)->dbl));
        }
        else{
            _6868 = (int)*(((s1_ptr)_2)->base + _6867);
        }
        _2 = (int)SEQ_PTR(_30drem_12003);
        _6869 = (int)*(((s1_ptr)_2)->base + _case3_12075);
        if (IS_ATOM_INT(_6869)) {
            _6870 = (_6868 % _6869);
        }
        else {
            _6870 = binary_op(REMAINDER, _6868, _6869);
        }
        _6868 = NOVALUE;
        _6869 = NOVALUE;
        _2 = (int)SEQ_PTR(_30dmul_12005);
        _6871 = (int)*(((s1_ptr)_2)->base + _case3_12075);
        if (IS_ATOM_INT(_6870) && IS_ATOM_INT(_6871)) {
            _tmp_12076 = _6870 * _6871;
        }
        else {
            _tmp_12076 = binary_op(MULTIPLY, _6870, _6871);
        }
        DeRef(_6870);
        _6870 = NOVALUE;
        _6871 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12076)) {
            _1 = (long)(DBL_PTR(_tmp_12076)->dbl);
            DeRefDS(_tmp_12076);
            _tmp_12076 = _1;
        }

        /** 		tmp += floor(ccha[in[len]] / ddiv[case3])*/
        _2 = (int)SEQ_PTR(_in_12072);
        _6873 = (int)*(((s1_ptr)_2)->base + _len_12073);
        _2 = (int)SEQ_PTR(_ccha_12078);
        if (!IS_ATOM_INT(_6873)){
            _6874 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6873)->dbl));
        }
        else{
            _6874 = (int)*(((s1_ptr)_2)->base + _6873);
        }
        _2 = (int)SEQ_PTR(_30ddiv_12007);
        _6875 = (int)*(((s1_ptr)_2)->base + _case3_12075);
        if (IS_ATOM_INT(_6875)) {
            if (_6875 > 0 && _6874 >= 0) {
                _6876 = _6874 / _6875;
            }
            else {
                temp_dbl = floor((double)_6874 / (double)_6875);
                if (_6874 != MININT)
                _6876 = (long)temp_dbl;
                else
                _6876 = NewDouble(temp_dbl);
            }
        }
        else {
            _2 = binary_op(DIVIDE, _6874, _6875);
            _6876 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _6874 = NOVALUE;
        _6875 = NOVALUE;
        if (IS_ATOM_INT(_6876)) {
            _tmp_12076 = _tmp_12076 + _6876;
        }
        else {
            _tmp_12076 = binary_op(PLUS, _tmp_12076, _6876);
        }
        DeRef(_6876);
        _6876 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_12076)) {
            _1 = (long)(DBL_PTR(_tmp_12076)->dbl);
            DeRefDS(_tmp_12076);
            _tmp_12076 = _1;
        }

        /** 		result[i] = tmp*/
        _2 = (int)SEQ_PTR(_result_12077);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_12077 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12099);
        *(int *)_2 = _tmp_12076;

        /** 		len -= ldrop[case3]*/
        _2 = (int)SEQ_PTR(_30ldrop_12015);
        _6878 = (int)*(((s1_ptr)_2)->base + _case3_12075);
        if (IS_ATOM_INT(_6878)) {
            _len_12073 = _len_12073 - _6878;
        }
        else {
            _len_12073 = binary_op(MINUS, _len_12073, _6878);
        }
        _6878 = NOVALUE;
        if (!IS_ATOM_INT(_len_12073)) {
            _1 = (long)(DBL_PTR(_len_12073)->dbl);
            DeRefDS(_len_12073);
            _len_12073 = _1;
        }

        /** 		case3 = nc3[case3]*/
        _2 = (int)SEQ_PTR(_30nc3_12013);
        _case3_12075 = (int)*(((s1_ptr)_2)->base + _case3_12075);
        if (!IS_ATOM_INT(_case3_12075))
        _case3_12075 = (long)DBL_PTR(_case3_12075)->dbl;

        /** 	end for*/
        _i_12099 = _i_12099 + -1;
        goto L6; // [222] 140
L7: 
        ;
    }

    /** 	return result*/
    DeRefDS(_in_12072);
    DeRefi(_ccha_12078);
    DeRef(_6853);
    _6853 = NOVALUE;
    _6863 = NOVALUE;
    DeRef(_6866);
    _6866 = NOVALUE;
    _6867 = NOVALUE;
    _6873 = NOVALUE;
    return _result_12077;
    ;
}



// 0x2E842BDD
