// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(int _text_8588)
{
    int _4696 = NOVALUE;
    int _4694 = NOVALUE;
    int _4692 = NOVALUE;
    int _4691 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_8585) && IS_ATOM(_text_8588)) {
        Ref(_text_8588);
        Append(&_26pretty_line_8585, _26pretty_line_8585, _text_8588);
    }
    else if (IS_ATOM(_26pretty_line_8585) && IS_SEQUENCE(_text_8588)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_8585, _26pretty_line_8585, _text_8588);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_8588 == 10)
    _4691 = 1;
    else if (IS_ATOM_INT(_text_8588) && IS_ATOM_INT(10))
    _4691 = 0;
    else
    _4691 = (compare(_text_8588, 10) == 0);
    if (_4691 == 0) {
        goto L1; // [15] 50
    }
    if (_26pretty_printing_8582 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_8573, _26pretty_line_8585); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_8585);
    _26pretty_line_8585 = _5;

    /** 		pretty_line_count += 1*/
    _26pretty_line_count_8578 = _26pretty_line_count_8578 + 1;
L1: 

    /** 	if atom(text) then*/
    _4694 = IS_ATOM(_text_8588);
    if (_4694 == 0)
    {
        _4694 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4694 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _26pretty_chars_8570 = _26pretty_chars_8570 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_8588)){
            _4696 = SEQ_PTR(_text_8588)->length;
    }
    else {
        _4696 = 1;
    }
    _26pretty_chars_8570 = _26pretty_chars_8570 + _4696;
    _4696 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_8588);
    return;
    ;
}


void _26cut_line(int _n_8602)
{
    int _4699 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_8581 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _26pretty_chars_8570 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _4699 = _26pretty_chars_8570 + _n_8602;
    if ((long)((unsigned long)_4699 + (unsigned long)HIGH_BITS) >= 0) 
    _4699 = NewDouble((double)_4699);
    if (binary_op_a(LESSEQ, _4699, _26pretty_end_col_8569)){
        DeRef(_4699);
        _4699 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4699);
    _4699 = NOVALUE;

    /** 		pretty_out('\n')*/
    _26pretty_out(10);

    /** 		pretty_chars = 0*/
    _26pretty_chars_8570 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _26indent()
{
    int _4707 = NOVALUE;
    int _4706 = NOVALUE;
    int _4705 = NOVALUE;
    int _4704 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_8581 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _26pretty_chars_8570 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_8581 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _26cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_26pretty_chars_8570 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _26pretty_out(10);

    /** 			pretty_chars = 0*/
    _26pretty_chars_8570 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4704 = _26pretty_start_col_8571 - 1;
    if ((long)((unsigned long)_4704 +(unsigned long) HIGH_BITS) >= 0){
        _4704 = NewDouble((double)_4704);
    }
    if (_26pretty_level_8572 == (short)_26pretty_level_8572 && _26pretty_indent_8575 <= INT15 && _26pretty_indent_8575 >= -INT15)
    _4705 = _26pretty_level_8572 * _26pretty_indent_8575;
    else
    _4705 = NewDouble(_26pretty_level_8572 * (double)_26pretty_indent_8575);
    if (IS_ATOM_INT(_4704) && IS_ATOM_INT(_4705)) {
        _4706 = _4704 + _4705;
    }
    else {
        if (IS_ATOM_INT(_4704)) {
            _4706 = NewDouble((double)_4704 + DBL_PTR(_4705)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4705)) {
                _4706 = NewDouble(DBL_PTR(_4704)->dbl + (double)_4705);
            }
            else
            _4706 = NewDouble(DBL_PTR(_4704)->dbl + DBL_PTR(_4705)->dbl);
        }
    }
    DeRef(_4704);
    _4704 = NOVALUE;
    DeRef(_4705);
    _4705 = NOVALUE;
    _4707 = Repeat(32, _4706);
    DeRef(_4706);
    _4706 = NOVALUE;
    _26pretty_out(_4707);
    _4707 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _26esc_char(int _a_8623)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_8623)) {
        _1 = (long)(DBL_PTR(_a_8623)->dbl);
        DeRefDS(_a_8623);
        _a_8623 = _1;
    }

    /** 	switch a do*/
    _0 = _a_8623;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_4710);
        return _4710;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_4711);
        return _4711;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_4712);
        return _4712;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_911);
        return _911;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_4713);
        return _4713;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_8623;
    ;}L1: 
    ;
}


void _26rPrint(int _a_8638)
{
    int _sbuff_8639 = NOVALUE;
    int _multi_line_8640 = NOVALUE;
    int _all_ascii_8641 = NOVALUE;
    int _4769 = NOVALUE;
    int _4768 = NOVALUE;
    int _4767 = NOVALUE;
    int _4766 = NOVALUE;
    int _4762 = NOVALUE;
    int _4761 = NOVALUE;
    int _4760 = NOVALUE;
    int _4759 = NOVALUE;
    int _4757 = NOVALUE;
    int _4756 = NOVALUE;
    int _4754 = NOVALUE;
    int _4753 = NOVALUE;
    int _4751 = NOVALUE;
    int _4750 = NOVALUE;
    int _4749 = NOVALUE;
    int _4748 = NOVALUE;
    int _4747 = NOVALUE;
    int _4746 = NOVALUE;
    int _4745 = NOVALUE;
    int _4744 = NOVALUE;
    int _4743 = NOVALUE;
    int _4742 = NOVALUE;
    int _4741 = NOVALUE;
    int _4740 = NOVALUE;
    int _4739 = NOVALUE;
    int _4738 = NOVALUE;
    int _4737 = NOVALUE;
    int _4736 = NOVALUE;
    int _4735 = NOVALUE;
    int _4731 = NOVALUE;
    int _4730 = NOVALUE;
    int _4729 = NOVALUE;
    int _4728 = NOVALUE;
    int _4727 = NOVALUE;
    int _4726 = NOVALUE;
    int _4724 = NOVALUE;
    int _4723 = NOVALUE;
    int _4720 = NOVALUE;
    int _4719 = NOVALUE;
    int _4718 = NOVALUE;
    int _4715 = NOVALUE;
    int _4714 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _4714 = IS_ATOM(_a_8638);
    if (_4714 == 0)
    {
        _4714 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4714 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_8638))
    _4715 = 1;
    else if (IS_ATOM_DBL(_a_8638))
    _4715 = IS_ATOM_INT(DoubleToInt(_a_8638));
    else
    _4715 = 0;
    if (_4715 == 0)
    {
        _4715 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4715 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_8639);
    _sbuff_8639 = EPrintf(-9999999, _26pretty_int_format_8584, _a_8638);

    /** 			if pretty_ascii then */
    if (_26pretty_ascii_8574 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_26pretty_ascii_8574 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_8638)) {
        _4718 = (_a_8638 >= _26pretty_ascii_min_8576);
    }
    else {
        _4718 = binary_op(GREATEREQ, _a_8638, _26pretty_ascii_min_8576);
    }
    if (IS_ATOM_INT(_4718)) {
        if (_4718 == 0) {
            _4719 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4718)->dbl == 0.0) {
            _4719 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_8638)) {
        _4720 = (_a_8638 <= _26pretty_ascii_max_8577);
    }
    else {
        _4720 = binary_op(LESSEQ, _a_8638, _26pretty_ascii_max_8577);
    }
    DeRef(_4719);
    if (IS_ATOM_INT(_4720))
    _4719 = (_4720 != 0);
    else
    _4719 = DBL_PTR(_4720)->dbl != 0.0;
L5: 
    if (_4719 == 0)
    {
        _4719 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4719 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_8638;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_8639, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _4723 = find_from(_a_8638, _4722, 1);
    if (_4723 == 0)
    {
        _4723 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4723 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_8638);
    _4724 = _26esc_char(_a_8638);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _4724;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_8639, concat_list, 3);
    }
    DeRef(_4724);
    _4724 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_8638)) {
        _4726 = (_a_8638 >= _26pretty_ascii_min_8576);
    }
    else {
        _4726 = binary_op(GREATEREQ, _a_8638, _26pretty_ascii_min_8576);
    }
    if (IS_ATOM_INT(_4726)) {
        if (_4726 == 0) {
            DeRef(_4727);
            _4727 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4726)->dbl == 0.0) {
            DeRef(_4727);
            _4727 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_8638)) {
        _4728 = (_a_8638 <= _26pretty_ascii_max_8577);
    }
    else {
        _4728 = binary_op(LESSEQ, _a_8638, _26pretty_ascii_max_8577);
    }
    DeRef(_4727);
    if (IS_ATOM_INT(_4728))
    _4727 = (_4728 != 0);
    else
    _4727 = DBL_PTR(_4728)->dbl != 0.0;
L7: 
    if (_4727 == 0) {
        goto L3; // [125] 166
    }
    _4730 = (_26pretty_ascii_8574 < 2);
    if (_4730 == 0)
    {
        DeRef(_4730);
        _4730 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4730);
        _4730 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_8638;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_4731, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_8639, _sbuff_8639, _4731);
    DeRefDS(_4731);
    _4731 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_8639);
    _sbuff_8639 = EPrintf(-9999999, _26pretty_fp_format_8583, _a_8638);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_8639);
    _26pretty_out(_sbuff_8639);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _26cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_8640 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_8641 = (_26pretty_ascii_8574 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_8638)){
            _4735 = SEQ_PTR(_a_8638)->length;
    }
    else {
        _4735 = 1;
    }
    {
        int _i_8674;
        _i_8674 = 1;
L9: 
        if (_i_8674 > _4735){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_8638);
        _4736 = (int)*(((s1_ptr)_2)->base + _i_8674);
        _4737 = IS_SEQUENCE(_4736);
        _4736 = NOVALUE;
        if (_4737 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_8638);
        _4739 = (int)*(((s1_ptr)_2)->base + _i_8674);
        if (IS_SEQUENCE(_4739)){
                _4740 = SEQ_PTR(_4739)->length;
        }
        else {
            _4740 = 1;
        }
        _4739 = NOVALUE;
        _4741 = (_4740 > 0);
        _4740 = NOVALUE;
        if (_4741 == 0)
        {
            DeRef(_4741);
            _4741 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4741);
            _4741 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_8640 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_8641 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_8638);
        _4742 = (int)*(((s1_ptr)_2)->base + _i_8674);
        if (IS_ATOM_INT(_4742))
        _4743 = 1;
        else if (IS_ATOM_DBL(_4742))
        _4743 = IS_ATOM_INT(DoubleToInt(_4742));
        else
        _4743 = 0;
        _4742 = NOVALUE;
        _4744 = (_4743 == 0);
        _4743 = NOVALUE;
        if (_4744 != 0) {
            _4745 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_8638);
        _4746 = (int)*(((s1_ptr)_2)->base + _i_8674);
        if (IS_ATOM_INT(_4746)) {
            _4747 = (_4746 < _26pretty_ascii_min_8576);
        }
        else {
            _4747 = binary_op(LESS, _4746, _26pretty_ascii_min_8576);
        }
        _4746 = NOVALUE;
        if (IS_ATOM_INT(_4747)) {
            if (_4747 == 0) {
                DeRef(_4748);
                _4748 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4747)->dbl == 0.0) {
                DeRef(_4748);
                _4748 = 0;
                goto LD; // [275] 309
            }
        }
        _4749 = (_26pretty_ascii_8574 < 2);
        if (_4749 != 0) {
            _4750 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_8638);
        _4751 = (int)*(((s1_ptr)_2)->base + _i_8674);
        _4753 = find_from(_4751, _4752, 1);
        _4751 = NOVALUE;
        _4754 = (_4753 == 0);
        _4753 = NOVALUE;
        _4750 = (_4754 != 0);
LE: 
        DeRef(_4748);
        _4748 = (_4750 != 0);
LD: 
        _4745 = (_4748 != 0);
LC: 
        if (_4745 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_8638);
        _4756 = (int)*(((s1_ptr)_2)->base + _i_8674);
        if (IS_ATOM_INT(_4756)) {
            _4757 = (_4756 > _26pretty_ascii_max_8577);
        }
        else {
            _4757 = binary_op(GREATER, _4756, _26pretty_ascii_max_8577);
        }
        _4756 = NOVALUE;
        if (_4757 == 0) {
            DeRef(_4757);
            _4757 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4757) && DBL_PTR(_4757)->dbl == 0.0){
                DeRef(_4757);
                _4757 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4757);
            _4757 = NOVALUE;
        }
        DeRef(_4757);
        _4757 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_8641 = 0;
L10: 

        /** 		end for*/
        _i_8674 = _i_8674 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_8641 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _26pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _26pretty_level_8572 = _26pretty_level_8572 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_8638)){
            _4759 = SEQ_PTR(_a_8638)->length;
    }
    else {
        _4759 = 1;
    }
    {
        int _i_8704;
        _i_8704 = 1;
L13: 
        if (_i_8704 > _4759){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_8640 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _26indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_8641 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_8638);
        _4760 = (int)*(((s1_ptr)_2)->base + _i_8704);
        Ref(_4760);
        _4761 = _26esc_char(_4760);
        _4760 = NOVALUE;
        _26pretty_out(_4761);
        _4761 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_8638);
        _4762 = (int)*(((s1_ptr)_2)->base + _i_8704);
        Ref(_4762);
        _26rPrint(_4762);
        _4762 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_8578 < _26pretty_line_max_8579)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_26pretty_dots_8580 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_4765);
        _26pretty_out(_4765);
L19: 

        /** 				pretty_dots = 1*/
        _26pretty_dots_8580 = 1;

        /** 				return*/
        DeRef(_a_8638);
        DeRef(_sbuff_8639);
        DeRef(_4718);
        _4718 = NOVALUE;
        DeRef(_4720);
        _4720 = NOVALUE;
        DeRef(_4726);
        _4726 = NOVALUE;
        DeRef(_4728);
        _4728 = NOVALUE;
        _4739 = NOVALUE;
        DeRef(_4744);
        _4744 = NOVALUE;
        DeRef(_4749);
        _4749 = NOVALUE;
        DeRef(_4747);
        _4747 = NOVALUE;
        DeRef(_4754);
        _4754 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_8638)){
                _4766 = SEQ_PTR(_a_8638)->length;
        }
        else {
            _4766 = 1;
        }
        _4767 = (_i_8704 != _4766);
        _4766 = NOVALUE;
        if (_4767 == 0) {
            goto L1A; // [468] 490
        }
        _4769 = (_all_ascii_8641 == 0);
        if (_4769 == 0)
        {
            DeRef(_4769);
            _4769 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4769);
            _4769 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _26pretty_out(44);

        /** 				cut_line(6)*/
        _26cut_line(6);
L1A: 

        /** 		end for*/
        _i_8704 = _i_8704 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _26pretty_level_8572 = _26pretty_level_8572 - 1;

    /** 		if multi_line then*/
    if (_multi_line_8640 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _26indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_8641 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _26pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_8638);
    DeRef(_sbuff_8639);
    DeRef(_4718);
    _4718 = NOVALUE;
    DeRef(_4720);
    _4720 = NOVALUE;
    DeRef(_4726);
    _4726 = NOVALUE;
    DeRef(_4728);
    _4728 = NOVALUE;
    _4739 = NOVALUE;
    DeRef(_4744);
    _4744 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4747);
    _4747 = NOVALUE;
    DeRef(_4754);
    _4754 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    return;
    ;
}


void _26pretty(int _x_8743, int _options_8744)
{
    int _4781 = NOVALUE;
    int _4780 = NOVALUE;
    int _4779 = NOVALUE;
    int _4778 = NOVALUE;
    int _4776 = NOVALUE;
    int _4775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_8744)){
            _4775 = SEQ_PTR(_options_8744)->length;
    }
    else {
        _4775 = 1;
    }
    _4776 = 10;
    if (_4775 >= 10)
    goto L1; // [13] 41

    /** 		options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_8744)){
            _4778 = SEQ_PTR(_options_8744)->length;
    }
    else {
        _4778 = 1;
    }
    _4779 = _4778 + 1;
    _4778 = NOVALUE;
    _4780 = 10;
    rhs_slice_target = (object_ptr)&_4781;
    RHS_Slice(_26PRETTY_DEFAULT_8726, _4779, 10);
    Concat((object_ptr)&_options_8744, _options_8744, _4781);
    DeRefDS(_4781);
    _4781 = NOVALUE;
L1: 

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_ascii_8574 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26pretty_ascii_8574))
    _26pretty_ascii_8574 = (long)DBL_PTR(_26pretty_ascii_8574)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_indent_8575 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26pretty_indent_8575))
    _26pretty_indent_8575 = (long)DBL_PTR(_26pretty_indent_8575)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_start_col_8571 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26pretty_start_col_8571))
    _26pretty_start_col_8571 = (long)DBL_PTR(_26pretty_start_col_8571)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_end_col_8569 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26pretty_end_col_8569))
    _26pretty_end_col_8569 = (long)DBL_PTR(_26pretty_end_col_8569)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_8584);
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_int_format_8584 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_26pretty_int_format_8584);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_8583);
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_fp_format_8583 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_26pretty_fp_format_8583);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_ascii_min_8576 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26pretty_ascii_min_8576))
    _26pretty_ascii_min_8576 = (long)DBL_PTR(_26pretty_ascii_min_8576)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_ascii_max_8577 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26pretty_ascii_max_8577))
    _26pretty_ascii_max_8577 = (long)DBL_PTR(_26pretty_ascii_max_8577)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_line_max_8579 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26pretty_line_max_8579))
    _26pretty_line_max_8579 = (long)DBL_PTR(_26pretty_line_max_8579)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_8744);
    _26pretty_line_breaks_8581 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_26pretty_line_breaks_8581))
    _26pretty_line_breaks_8581 = (long)DBL_PTR(_26pretty_line_breaks_8581)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _26pretty_chars_8570 = _26pretty_start_col_8571;

    /** 	pretty_level = 0 */
    _26pretty_level_8572 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_8585);
    _26pretty_line_8585 = _5;

    /** 	pretty_line_count = 0*/
    _26pretty_line_count_8578 = 0;

    /** 	pretty_dots = 0*/
    _26pretty_dots_8580 = 0;

    /** 	rPrint(x)*/
    Ref(_x_8743);
    _26rPrint(_x_8743);

    /** end procedure*/
    DeRef(_x_8743);
    DeRefDS(_options_8744);
    DeRef(_4779);
    _4779 = NOVALUE;
    return;
    ;
}


void _26pretty_print(int _fn_8766, int _x_8767, int _options_8768)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_8766)) {
        _1 = (long)(DBL_PTR(_fn_8766)->dbl);
        DeRefDS(_fn_8766);
        _fn_8766 = _1;
    }

    /** 	pretty_printing = 1*/
    _26pretty_printing_8582 = 1;

    /** 	pretty_file = fn*/
    _26pretty_file_8573 = _fn_8766;

    /** 	pretty( x, options )*/
    Ref(_x_8767);
    RefDS(_options_8768);
    _26pretty(_x_8767, _options_8768);

    /** 	puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_8573, _26pretty_line_8585); // DJP 

    /** end procedure*/
    DeRef(_x_8767);
    DeRefDS(_options_8768);
    return;
    ;
}
void pretty_print() __attribute__ ((alias ("_26pretty_print")));


int _26pretty_sprint(int _x_8771, int _options_8772)
{
    int _0, _1, _2;
    

    /** 	pretty_printing = 0*/
    _26pretty_printing_8582 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_8771);
    RefDS(_options_8772);
    _26pretty(_x_8771, _options_8772);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8585);
    DeRef(_x_8771);
    DeRefDS(_options_8772);
    return _26pretty_line_8585;
    ;
}
int pretty_sprint() __attribute__ ((alias ("_26pretty_sprint")));



// 0xD3E574AF
