// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _37instance()
{
    int _8537 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_INSTANCE, 0)*/
    _8537 = machine(55, 0);
    return _8537;
    ;
}
int instance() __attribute__ ((alias ("_37instance")));


int _37get_pid()
{
    int _8538 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return machine_func(M_INSTANCE, 0)*/
    _8538 = machine(55, 0);
    return _8538;
    ;
}
int get_pid() __attribute__ ((alias ("_37get_pid")));


int _37uname()
{
    int _o_15168 = NOVALUE;
    int _8565 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		object o = machine_func(M_UNAME, {})*/
    DeRef(_o_15168);
    _o_15168 = machine(76, _5);

    /** 		if atom(o) then*/
    _8565 = IS_ATOM(_o_15168);
    if (_8565 == 0)
    {
        _8565 = NOVALUE;
        goto L1; // [14] 26
    }
    else{
        _8565 = NOVALUE;
    }

    /** 			return {}*/
    RefDS(_5);
    DeRef(_o_15168);
    return _5;
    goto L2; // [23] 33
L1: 

    /** 			return o*/
    return _o_15168;
L2: 
    ;
}
int uname() __attribute__ ((alias ("_37uname")));


int _37is_win_nt()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return -1*/
    return -1;
    ;
}
int is_win_nt() __attribute__ ((alias ("_37is_win_nt")));


int _37setenv(int _name_15178, int _val_15179, int _overwrite_15180)
{
    int _8568 = NOVALUE;
    int _8567 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_15180)) {
        _1 = (long)(DBL_PTR(_overwrite_15180)->dbl);
        DeRefDS(_overwrite_15180);
        _overwrite_15180 = _1;
    }

    /** 	return machine_func(M_SET_ENV, {name, val, overwrite})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_15178);
    *((int *)(_2+4)) = _name_15178;
    RefDS(_val_15179);
    *((int *)(_2+8)) = _val_15179;
    *((int *)(_2+12)) = _overwrite_15180;
    _8567 = MAKE_SEQ(_1);
    _8568 = machine(73, _8567);
    DeRefDS(_8567);
    _8567 = NOVALUE;
    DeRefDS(_name_15178);
    DeRefDS(_val_15179);
    return _8568;
    ;
}
int setenv() __attribute__ ((alias ("_37setenv")));


int _37unsetenv(int _env_15185)
{
    int _8570 = NOVALUE;
    int _8569 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_UNSET_ENV, {env})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_env_15185);
    *((int *)(_2+4)) = _env_15185;
    _8569 = MAKE_SEQ(_1);
    _8570 = machine(74, _8569);
    DeRefDS(_8569);
    _8569 = NOVALUE;
    DeRefDS(_env_15185);
    return _8570;
    ;
}
int unsetenv() __attribute__ ((alias ("_37unsetenv")));


void _37sleep(int _t_15190)
{
    int _0, _1, _2;
    

    /** 	if t >= 0 then*/
    if (binary_op_a(LESS, _t_15190, 0)){
        goto L1; // [3] 13
    }

    /** 		machine_proc(M_SLEEP, t)*/
    machine(64, _t_15190);
L1: 

    /** end procedure*/
    DeRef(_t_15190);
    return;
    ;
}
void sleep() __attribute__ ((alias ("_37sleep")));



// 0x84399AD6
