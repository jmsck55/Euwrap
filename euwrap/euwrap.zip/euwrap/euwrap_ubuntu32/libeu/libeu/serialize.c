// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _27init_float80()
{
    int _data_inlined_allocate_code_at_55_24896 = NOVALUE;
    int _code_8828 = NOVALUE;
    int _4834 = NOVALUE;
    int _4833 = NOVALUE;
    int _4831 = NOVALUE;
    int _0, _1, _2;
    

    /** 	f80 = allocate( 10 )*/
    _0 = _14allocate(10, 0);
    DeRef(_27f80_8817);
    _27f80_8817 = _0;

    /** 	if f64 = 0 then*/
    if (binary_op_a(NOTEQ, _27f64_8818, 0)){
        goto L1; // [12] 24
    }

    /** 		f64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27f64_8818);
    _27f64_8818 = _0;
L1: 

    /** 	atom code*/

    /** 	code = machine:allocate_code(*/
    _1 = NewS1(25);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 85;
    *((int *)(_2+8)) = 137;
    *((int *)(_2+12)) = 229;
    *((int *)(_2+16)) = 131;
    *((int *)(_2+20)) = 236;
    *((int *)(_2+24)) = 8;
    *((int *)(_2+28)) = 139;
    *((int *)(_2+32)) = 69;
    *((int *)(_2+36)) = 12;
    *((int *)(_2+40)) = 139;
    *((int *)(_2+44)) = 85;
    *((int *)(_2+48)) = 8;
    *((int *)(_2+52)) = 219;
    *((int *)(_2+56)) = 42;
    *((int *)(_2+60)) = 221;
    *((int *)(_2+64)) = 93;
    *((int *)(_2+68)) = 248;
    *((int *)(_2+72)) = 221;
    *((int *)(_2+76)) = 69;
    *((int *)(_2+80)) = 248;
    *((int *)(_2+84)) = 221;
    *((int *)(_2+88)) = 24;
    *((int *)(_2+92)) = 201;
    *((int *)(_2+96)) = 195;
    *((int *)(_2+100)) = 0;
    _4831 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_allocate_code_at_55_24896);
    _data_inlined_allocate_code_at_55_24896 = _4831;
    _4831 = NOVALUE;

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    RefDS(_data_inlined_allocate_code_at_55_24896);
    _0 = _code_8828;
    _code_8828 = _14allocate_protect(_data_inlined_allocate_code_at_55_24896, 1, 4);
    DeRef(_0);
    DeRefi(_data_inlined_allocate_code_at_55_24896);
    _data_inlined_allocate_code_at_55_24896 = NOVALUE;

    /** 	F80_TO_ATOM = dll:define_c_proc( "", {'+', code}, { dll:C_POINTER, dll:C_POINTER } )*/
    Ref(_code_8828);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 43;
    ((int *)_2)[2] = _code_8828;
    _4833 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _4834 = MAKE_SEQ(_1);
    RefDS(_5);
    _0 = _13define_c_proc(_5, _4833, _4834);
    _27F80_TO_ATOM_8819 = _0;
    _4833 = NOVALUE;
    _4834 = NOVALUE;
    if (!IS_ATOM_INT(_27F80_TO_ATOM_8819)) {
        _1 = (long)(DBL_PTR(_27F80_TO_ATOM_8819)->dbl);
        DeRefDS(_27F80_TO_ATOM_8819);
        _27F80_TO_ATOM_8819 = _1;
    }

    /** end procedure*/
    DeRef(_code_8828);
    return;
    ;
}


int _27float80_to_atom(int _f_8849)
{
    int _4840 = NOVALUE;
    int _4839 = NOVALUE;
    int _4838 = NOVALUE;
    int _4837 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not f80 then*/
    if (IS_ATOM_INT(_27f80_8817)) {
        if (_27f80_8817 != 0){
            goto L1; // [7] 15
        }
    }
    else {
        if (DBL_PTR(_27f80_8817)->dbl != 0.0){
            goto L1; // [7] 15
        }
    }

    /** 		init_float80()*/
    _27init_float80();
L1: 

    /** 	poke( f80, f )*/
    if (IS_ATOM_INT(_27f80_8817)){
        poke_addr = (unsigned char *)_27f80_8817;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27f80_8817)->dbl);
    }
    _1 = (int)SEQ_PTR(_f_8849);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	c_proc( F80_TO_ATOM, { f80, f64 } )*/
    Ref(_27f64_8818);
    Ref(_27f80_8817);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27f80_8817;
    ((int *)_2)[2] = _27f64_8818;
    _4837 = MAKE_SEQ(_1);
    call_c(0, _27F80_TO_ATOM_8819, _4837);
    DeRefDS(_4837);
    _4837 = NOVALUE;

    /** 	return float64_to_atom( peek( { f64, 8 } ) )*/
    Ref(_27f64_8818);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27f64_8818;
    ((int *)_2)[2] = 8;
    _4838 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_4838);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _4839 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4838);
    _4838 = NOVALUE;
    _4840 = _8float64_to_atom(_4839);
    _4839 = NOVALUE;
    DeRefDS(_f_8849);
    return _4840;
    ;
}


void _27init_peek8s()
{
    int _data_inlined_allocate_code_at_58_24898 = NOVALUE;
    int _code_8867 = NOVALUE;
    int _4848 = NOVALUE;
    int _4847 = NOVALUE;
    int _4845 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27i64_8857);
    _27i64_8857 = _0;

    /** 	if f64 = 0 then*/
    if (binary_op_a(NOTEQ, _27f64_8818, 0)){
        goto L1; // [12] 24
    }

    /** 		f64 = allocate( 8 )*/
    _0 = _14allocate(8, 0);
    DeRef(_27f64_8818);
    _27f64_8818 = _0;
L1: 

    /** 	atom code = machine:allocate_code(	{*/
    _1 = NewS1(30);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 85;
    *((int *)(_2+8)) = 137;
    *((int *)(_2+12)) = 229;
    *((int *)(_2+16)) = 131;
    *((int *)(_2+20)) = 236;
    *((int *)(_2+24)) = 8;
    *((int *)(_2+28)) = 139;
    *((int *)(_2+32)) = 69;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 139;
    *((int *)(_2+44)) = 80;
    *((int *)(_2+48)) = 4;
    *((int *)(_2+52)) = 139;
    *((int *)(_2+56)) = 0;
    *((int *)(_2+60)) = 137;
    *((int *)(_2+64)) = 69;
    *((int *)(_2+68)) = 248;
    *((int *)(_2+72)) = 137;
    *((int *)(_2+76)) = 85;
    *((int *)(_2+80)) = 252;
    *((int *)(_2+84)) = 223;
    *((int *)(_2+88)) = 109;
    *((int *)(_2+92)) = 248;
    *((int *)(_2+96)) = 139;
    *((int *)(_2+100)) = 69;
    *((int *)(_2+104)) = 12;
    *((int *)(_2+108)) = 221;
    *((int *)(_2+112)) = 24;
    *((int *)(_2+116)) = 201;
    *((int *)(_2+120)) = 195;
    _4845 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_allocate_code_at_58_24898);
    _data_inlined_allocate_code_at_58_24898 = _4845;
    _4845 = NOVALUE;

    /** 	return allocate_protect( data, wordsize, PAGE_EXECUTE )*/
    RefDS(_data_inlined_allocate_code_at_58_24898);
    _0 = _code_8867;
    _code_8867 = _14allocate_protect(_data_inlined_allocate_code_at_58_24898, 1, 4);
    DeRef(_0);
    DeRefi(_data_inlined_allocate_code_at_58_24898);
    _data_inlined_allocate_code_at_58_24898 = NOVALUE;

    /** 	PEEK8S = define_c_proc( {}, {'+', code}, { C_POINTER, C_POINTER } )*/
    Ref(_code_8867);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 43;
    ((int *)_2)[2] = _code_8867;
    _4847 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _4848 = MAKE_SEQ(_1);
    RefDS(_5);
    _0 = _13define_c_proc(_5, _4847, _4848);
    _27PEEK8S_8858 = _0;
    _4847 = NOVALUE;
    _4848 = NOVALUE;
    if (!IS_ATOM_INT(_27PEEK8S_8858)) {
        _1 = (long)(DBL_PTR(_27PEEK8S_8858)->dbl);
        DeRefDS(_27PEEK8S_8858);
        _27PEEK8S_8858 = _1;
    }

    /** end procedure*/
    DeRef(_code_8867);
    return;
    ;
}


int _27int64_to_atom(int _s_8879)
{
    int _4854 = NOVALUE;
    int _4853 = NOVALUE;
    int _4852 = NOVALUE;
    int _4851 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if i64 = 0 then*/
    if (binary_op_a(NOTEQ, _27i64_8857, 0)){
        goto L1; // [7] 16
    }

    /** 		init_peek8s()*/
    _27init_peek8s();
L1: 

    /** 	poke( i64, s )*/
    if (IS_ATOM_INT(_27i64_8857)){
        poke_addr = (unsigned char *)_27i64_8857;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27i64_8857)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_8879);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	c_proc( PEEK8S, { i64, f64 } )*/
    Ref(_27f64_8818);
    Ref(_27i64_8857);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27i64_8857;
    ((int *)_2)[2] = _27f64_8818;
    _4851 = MAKE_SEQ(_1);
    call_c(0, _27PEEK8S_8858, _4851);
    DeRefDS(_4851);
    _4851 = NOVALUE;

    /** 	return float64_to_atom( peek( f64 & 8 ) )*/
    Concat((object_ptr)&_4852, _27f64_8818, 8);
    _1 = (int)SEQ_PTR(_4852);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _4853 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_4852);
    _4852 = NOVALUE;
    _4854 = _8float64_to_atom(_4853);
    _4853 = NOVALUE;
    DeRefDS(_s_8879);
    return _4854;
    ;
}


int _27get4(int _fh_8889)
{
    int _4859 = NOVALUE;
    int _4858 = NOVALUE;
    int _4857 = NOVALUE;
    int _4856 = NOVALUE;
    int _4855 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_8889 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_8889, EF_READ);
        last_r_file_no = _fh_8889;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _4855 = getc((FILE*)xstdin);
        }
        else
        _4855 = getc(last_r_file_ptr);
    }
    else
    _4855 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem0_8809)){
        poke_addr = (unsigned char *)_27mem0_8809;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem0_8809)->dbl);
    }
    *poke_addr = (unsigned char)_4855;
    _4855 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_8889 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_8889, EF_READ);
        last_r_file_no = _fh_8889;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _4856 = getc((FILE*)xstdin);
        }
        else
        _4856 = getc(last_r_file_ptr);
    }
    else
    _4856 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem1_8810)){
        poke_addr = (unsigned char *)_27mem1_8810;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem1_8810)->dbl);
    }
    *poke_addr = (unsigned char)_4856;
    _4856 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_8889 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_8889, EF_READ);
        last_r_file_no = _fh_8889;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _4857 = getc((FILE*)xstdin);
        }
        else
        _4857 = getc(last_r_file_ptr);
    }
    else
    _4857 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem2_8811)){
        poke_addr = (unsigned char *)_27mem2_8811;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem2_8811)->dbl);
    }
    *poke_addr = (unsigned char)_4857;
    _4857 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_8889 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_8889, EF_READ);
        last_r_file_no = _fh_8889;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _4858 = getc((FILE*)xstdin);
        }
        else
        _4858 = getc(last_r_file_ptr);
    }
    else
    _4858 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_27mem3_8812)){
        poke_addr = (unsigned char *)_27mem3_8812;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem3_8812)->dbl);
    }
    *poke_addr = (unsigned char)_4858;
    _4858 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_27mem0_8809)) {
        _4859 = *(unsigned long *)_27mem0_8809;
        if ((unsigned)_4859 > (unsigned)MAXINT)
        _4859 = NewDouble((double)(unsigned long)_4859);
    }
    else {
        _4859 = *(unsigned long *)(unsigned long)(DBL_PTR(_27mem0_8809)->dbl);
        if ((unsigned)_4859 > (unsigned)MAXINT)
        _4859 = NewDouble((double)(unsigned long)_4859);
    }
    return _4859;
    ;
}


int _27deserialize_file(int _fh_8897, int _c_8898)
{
    int _s_8899 = NOVALUE;
    int _len_8900 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_159_8936 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_156_8935 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_218_8949 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_215_8948 = NOVALUE;
    int _msg_inlined_crash_at_424_8994 = NOVALUE;
    int _4938 = NOVALUE;
    int _4937 = NOVALUE;
    int _4936 = NOVALUE;
    int _4935 = NOVALUE;
    int _4932 = NOVALUE;
    int _4929 = NOVALUE;
    int _4928 = NOVALUE;
    int _4927 = NOVALUE;
    int _4926 = NOVALUE;
    int _4925 = NOVALUE;
    int _4924 = NOVALUE;
    int _4923 = NOVALUE;
    int _4922 = NOVALUE;
    int _4921 = NOVALUE;
    int _4920 = NOVALUE;
    int _4919 = NOVALUE;
    int _4918 = NOVALUE;
    int _4916 = NOVALUE;
    int _4915 = NOVALUE;
    int _4914 = NOVALUE;
    int _4913 = NOVALUE;
    int _4912 = NOVALUE;
    int _4911 = NOVALUE;
    int _4910 = NOVALUE;
    int _4909 = NOVALUE;
    int _4908 = NOVALUE;
    int _4907 = NOVALUE;
    int _4905 = NOVALUE;
    int _4904 = NOVALUE;
    int _4903 = NOVALUE;
    int _4902 = NOVALUE;
    int _4901 = NOVALUE;
    int _4899 = NOVALUE;
    int _4895 = NOVALUE;
    int _4894 = NOVALUE;
    int _4893 = NOVALUE;
    int _4892 = NOVALUE;
    int _4891 = NOVALUE;
    int _4890 = NOVALUE;
    int _4889 = NOVALUE;
    int _4888 = NOVALUE;
    int _4887 = NOVALUE;
    int _4886 = NOVALUE;
    int _4885 = NOVALUE;
    int _4884 = NOVALUE;
    int _4883 = NOVALUE;
    int _4882 = NOVALUE;
    int _4881 = NOVALUE;
    int _4880 = NOVALUE;
    int _4879 = NOVALUE;
    int _4878 = NOVALUE;
    int _4877 = NOVALUE;
    int _4876 = NOVALUE;
    int _4874 = NOVALUE;
    int _4873 = NOVALUE;
    int _4872 = NOVALUE;
    int _4871 = NOVALUE;
    int _4870 = NOVALUE;
    int _4869 = NOVALUE;
    int _4868 = NOVALUE;
    int _4867 = NOVALUE;
    int _4866 = NOVALUE;
    int _4863 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_8897)) {
        _1 = (long)(DBL_PTR(_fh_8897)->dbl);
        DeRefDS(_fh_8897);
        _fh_8897 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_8898 != 0)
    goto L1; // [7] 34

    /** 		c = getc(fh)*/
    if (_fh_8897 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_8897, EF_READ);
        last_r_file_no = _fh_8897;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_8898 = getc((FILE*)xstdin);
        }
        else
        _c_8898 = getc(last_r_file_ptr);
    }
    else
    _c_8898 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_8898 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _4863 = _c_8898 + -9;
    DeRef(_s_8899);
    DeRef(_len_8900);
    return _4863;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_8898;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(fh) +*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4866 = getc((FILE*)xstdin);
            }
            else
            _4866 = getc(last_r_file_ptr);
        }
        else
        _4866 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4867 = getc((FILE*)xstdin);
            }
            else
            _4867 = getc(last_r_file_ptr);
        }
        else
        _4867 = getc(last_r_file_ptr);
        _4868 = 256 * _4867;
        _4867 = NOVALUE;
        _4869 = _4866 + _4868;
        _4866 = NOVALUE;
        _4868 = NOVALUE;
        _4870 = _4869 + _27MIN2B_8794;
        if ((long)((unsigned long)_4870 + (unsigned long)HIGH_BITS) >= 0) 
        _4870 = NewDouble((double)_4870);
        _4869 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        return _4870;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(fh) +*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4871 = getc((FILE*)xstdin);
            }
            else
            _4871 = getc(last_r_file_ptr);
        }
        else
        _4871 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4872 = getc((FILE*)xstdin);
            }
            else
            _4872 = getc(last_r_file_ptr);
        }
        else
        _4872 = getc(last_r_file_ptr);
        _4873 = 256 * _4872;
        _4872 = NOVALUE;
        _4874 = _4871 + _4873;
        _4871 = NOVALUE;
        _4873 = NOVALUE;
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4876 = getc((FILE*)xstdin);
            }
            else
            _4876 = getc(last_r_file_ptr);
        }
        else
        _4876 = getc(last_r_file_ptr);
        _4877 = 65536 * _4876;
        _4876 = NOVALUE;
        _4878 = _4874 + _4877;
        _4874 = NOVALUE;
        _4877 = NOVALUE;
        _4879 = _4878 + _27MIN3B_8800;
        if ((long)((unsigned long)_4879 + (unsigned long)HIGH_BITS) >= 0) 
        _4879 = NewDouble((double)_4879);
        _4878 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        return _4879;

        /** 		case I4B then*/
        case 251:

        /** 			return get4(fh) + MIN4B*/
        _4880 = _27get4(_fh_8897);
        if (IS_ATOM_INT(_4880) && IS_ATOM_INT(_27MIN4B_8806)) {
            _4881 = _4880 + _27MIN4B_8806;
            if ((long)((unsigned long)_4881 + (unsigned long)HIGH_BITS) >= 0) 
            _4881 = NewDouble((double)_4881);
        }
        else {
            _4881 = binary_op(PLUS, _4880, _27MIN4B_8806);
        }
        DeRef(_4880);
        _4880 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        return _4881;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(fh), getc(fh),*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4882 = getc((FILE*)xstdin);
            }
            else
            _4882 = getc(last_r_file_ptr);
        }
        else
        _4882 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4883 = getc((FILE*)xstdin);
            }
            else
            _4883 = getc(last_r_file_ptr);
        }
        else
        _4883 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4884 = getc((FILE*)xstdin);
            }
            else
            _4884 = getc(last_r_file_ptr);
        }
        else
        _4884 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4885 = getc((FILE*)xstdin);
            }
            else
            _4885 = getc(last_r_file_ptr);
        }
        else
        _4885 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4882;
        *((int *)(_2+8)) = _4883;
        *((int *)(_2+12)) = _4884;
        *((int *)(_2+16)) = _4885;
        _4886 = MAKE_SEQ(_1);
        _4885 = NOVALUE;
        _4884 = NOVALUE;
        _4883 = NOVALUE;
        _4882 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_156_8935);
        _ieee32_inlined_float32_to_atom_at_156_8935 = _4886;
        _4886 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_159_8936);
        _float32_to_atom_inlined_float32_to_atom_at_159_8936 = machine(49, _ieee32_inlined_float32_to_atom_at_156_8935);
        DeRefi(_ieee32_inlined_float32_to_atom_at_156_8935);
        _ieee32_inlined_float32_to_atom_at_156_8935 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_159_8936;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(fh), getc(fh),*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4887 = getc((FILE*)xstdin);
            }
            else
            _4887 = getc(last_r_file_ptr);
        }
        else
        _4887 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4888 = getc((FILE*)xstdin);
            }
            else
            _4888 = getc(last_r_file_ptr);
        }
        else
        _4888 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4889 = getc((FILE*)xstdin);
            }
            else
            _4889 = getc(last_r_file_ptr);
        }
        else
        _4889 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4890 = getc((FILE*)xstdin);
            }
            else
            _4890 = getc(last_r_file_ptr);
        }
        else
        _4890 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4891 = getc((FILE*)xstdin);
            }
            else
            _4891 = getc(last_r_file_ptr);
        }
        else
        _4891 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4892 = getc((FILE*)xstdin);
            }
            else
            _4892 = getc(last_r_file_ptr);
        }
        else
        _4892 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4893 = getc((FILE*)xstdin);
            }
            else
            _4893 = getc(last_r_file_ptr);
        }
        else
        _4893 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4894 = getc((FILE*)xstdin);
            }
            else
            _4894 = getc(last_r_file_ptr);
        }
        else
        _4894 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4887;
        *((int *)(_2+8)) = _4888;
        *((int *)(_2+12)) = _4889;
        *((int *)(_2+16)) = _4890;
        *((int *)(_2+20)) = _4891;
        *((int *)(_2+24)) = _4892;
        *((int *)(_2+28)) = _4893;
        *((int *)(_2+32)) = _4894;
        _4895 = MAKE_SEQ(_1);
        _4894 = NOVALUE;
        _4893 = NOVALUE;
        _4892 = NOVALUE;
        _4891 = NOVALUE;
        _4890 = NOVALUE;
        _4889 = NOVALUE;
        _4888 = NOVALUE;
        _4887 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_215_8948);
        _ieee64_inlined_float64_to_atom_at_215_8948 = _4895;
        _4895 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_218_8949);
        _float64_to_atom_inlined_float64_to_atom_at_218_8949 = machine(47, _ieee64_inlined_float64_to_atom_at_215_8948);
        DeRefi(_ieee64_inlined_float64_to_atom_at_215_8948);
        _ieee64_inlined_float64_to_atom_at_215_8948 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_218_8949;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_8898 != 254)
        goto L3; // [240] 252

        /** 				len = getc(fh)*/
        DeRef(_len_8900);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_8900 = getc((FILE*)xstdin);
            }
            else
            _len_8900 = getc(last_r_file_ptr);
        }
        else
        _len_8900 = getc(last_r_file_ptr);
        goto L4; // [249] 259
L3: 

        /** 				len = get4(fh)*/
        _0 = _len_8900;
        _len_8900 = _27get4(_fh_8897);
        DeRef(_0);
L4: 

        /** 			if len < 0  or not integer(len) then*/
        if (IS_ATOM_INT(_len_8900)) {
            _4899 = (_len_8900 < 0);
        }
        else {
            _4899 = (DBL_PTR(_len_8900)->dbl < (double)0);
        }
        if (_4899 != 0) {
            goto L5; // [267] 282
        }
        if (IS_ATOM_INT(_len_8900))
        _4901 = 1;
        else if (IS_ATOM_DBL(_len_8900))
        _4901 = IS_ATOM_INT(DoubleToInt(_len_8900));
        else
        _4901 = 0;
        _4902 = (_4901 == 0);
        _4901 = NOVALUE;
        if (_4902 == 0)
        {
            DeRef(_4902);
            _4902 = NOVALUE;
            goto L6; // [278] 289
        }
        else{
            DeRef(_4902);
            _4902 = NOVALUE;
        }
L5: 

        /** 				return 0*/
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4899);
        _4899 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        return 0;
L6: 

        /** 			if c = S4B and len < 256 then*/
        _4903 = (_c_8898 == 255);
        if (_4903 == 0) {
            goto L7; // [295] 447
        }
        if (IS_ATOM_INT(_len_8900)) {
            _4905 = (_len_8900 < 256);
        }
        else {
            _4905 = (DBL_PTR(_len_8900)->dbl < (double)256);
        }
        if (_4905 == 0)
        {
            DeRef(_4905);
            _4905 = NOVALUE;
            goto L7; // [304] 447
        }
        else{
            DeRef(_4905);
            _4905 = NOVALUE;
        }

        /** 				if len = I8B then*/
        if (binary_op_a(NOTEQ, _len_8900, 0)){
            goto L8; // [309] 361
        }

        /** 					return int64_to_atom( {*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4907 = getc((FILE*)xstdin);
            }
            else
            _4907 = getc(last_r_file_ptr);
        }
        else
        _4907 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4908 = getc((FILE*)xstdin);
            }
            else
            _4908 = getc(last_r_file_ptr);
        }
        else
        _4908 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4909 = getc((FILE*)xstdin);
            }
            else
            _4909 = getc(last_r_file_ptr);
        }
        else
        _4909 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4910 = getc((FILE*)xstdin);
            }
            else
            _4910 = getc(last_r_file_ptr);
        }
        else
        _4910 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4911 = getc((FILE*)xstdin);
            }
            else
            _4911 = getc(last_r_file_ptr);
        }
        else
        _4911 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4912 = getc((FILE*)xstdin);
            }
            else
            _4912 = getc(last_r_file_ptr);
        }
        else
        _4912 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4913 = getc((FILE*)xstdin);
            }
            else
            _4913 = getc(last_r_file_ptr);
        }
        else
        _4913 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4914 = getc((FILE*)xstdin);
            }
            else
            _4914 = getc(last_r_file_ptr);
        }
        else
        _4914 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4907;
        *((int *)(_2+8)) = _4908;
        *((int *)(_2+12)) = _4909;
        *((int *)(_2+16)) = _4910;
        *((int *)(_2+20)) = _4911;
        *((int *)(_2+24)) = _4912;
        *((int *)(_2+28)) = _4913;
        *((int *)(_2+32)) = _4914;
        _4915 = MAKE_SEQ(_1);
        _4914 = NOVALUE;
        _4913 = NOVALUE;
        _4912 = NOVALUE;
        _4911 = NOVALUE;
        _4910 = NOVALUE;
        _4909 = NOVALUE;
        _4908 = NOVALUE;
        _4907 = NOVALUE;
        _4916 = _27int64_to_atom(_4915);
        _4915 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4899);
        _4899 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        DeRef(_4903);
        _4903 = NOVALUE;
        return _4916;
        goto L9; // [358] 521
L8: 

        /** 				elsif len = F10B then*/
        if (binary_op_a(NOTEQ, _len_8900, 1)){
            goto LA; // [363] 423
        }

        /** 					return float80_to_atom(*/
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4918 = getc((FILE*)xstdin);
            }
            else
            _4918 = getc(last_r_file_ptr);
        }
        else
        _4918 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4919 = getc((FILE*)xstdin);
            }
            else
            _4919 = getc(last_r_file_ptr);
        }
        else
        _4919 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4920 = getc((FILE*)xstdin);
            }
            else
            _4920 = getc(last_r_file_ptr);
        }
        else
        _4920 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4921 = getc((FILE*)xstdin);
            }
            else
            _4921 = getc(last_r_file_ptr);
        }
        else
        _4921 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4922 = getc((FILE*)xstdin);
            }
            else
            _4922 = getc(last_r_file_ptr);
        }
        else
        _4922 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4923 = getc((FILE*)xstdin);
            }
            else
            _4923 = getc(last_r_file_ptr);
        }
        else
        _4923 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4924 = getc((FILE*)xstdin);
            }
            else
            _4924 = getc(last_r_file_ptr);
        }
        else
        _4924 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4925 = getc((FILE*)xstdin);
            }
            else
            _4925 = getc(last_r_file_ptr);
        }
        else
        _4925 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4926 = getc((FILE*)xstdin);
            }
            else
            _4926 = getc(last_r_file_ptr);
        }
        else
        _4926 = getc(last_r_file_ptr);
        if (_fh_8897 != last_r_file_no) {
            last_r_file_ptr = which_file(_fh_8897, EF_READ);
            last_r_file_no = _fh_8897;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4927 = getc((FILE*)xstdin);
            }
            else
            _4927 = getc(last_r_file_ptr);
        }
        else
        _4927 = getc(last_r_file_ptr);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _4918;
        *((int *)(_2+8)) = _4919;
        *((int *)(_2+12)) = _4920;
        *((int *)(_2+16)) = _4921;
        *((int *)(_2+20)) = _4922;
        *((int *)(_2+24)) = _4923;
        *((int *)(_2+28)) = _4924;
        *((int *)(_2+32)) = _4925;
        *((int *)(_2+36)) = _4926;
        *((int *)(_2+40)) = _4927;
        _4928 = MAKE_SEQ(_1);
        _4927 = NOVALUE;
        _4926 = NOVALUE;
        _4925 = NOVALUE;
        _4924 = NOVALUE;
        _4923 = NOVALUE;
        _4922 = NOVALUE;
        _4921 = NOVALUE;
        _4920 = NOVALUE;
        _4919 = NOVALUE;
        _4918 = NOVALUE;
        _4929 = _27float80_to_atom(_4928);
        _4928 = NOVALUE;
        DeRef(_s_8899);
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4899);
        _4899 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        DeRef(_4903);
        _4903 = NOVALUE;
        DeRef(_4916);
        _4916 = NOVALUE;
        return _4929;
        goto L9; // [420] 521
LA: 

        /** 					error:crash( "Invalid sequence serialization" )*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_424_8994);
        _msg_inlined_crash_at_424_8994 = EPrintf(-9999999, _4930, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_424_8994);

        /** end procedure*/
        goto LB; // [438] 441
LB: 
        DeRefi(_msg_inlined_crash_at_424_8994);
        _msg_inlined_crash_at_424_8994 = NOVALUE;
        goto L9; // [444] 521
L7: 

        /** 				s = repeat(0, len)*/
        DeRef(_s_8899);
        _s_8899 = Repeat(0, _len_8900);

        /** 				for i = 1 to len do*/
        Ref(_len_8900);
        DeRef(_4932);
        _4932 = _len_8900;
        {
            int _i_8998;
            _i_8998 = 1;
LC: 
            if (binary_op_a(GREATER, _i_8998, _4932)){
                goto LD; // [458] 514
            }

            /** 					c = getc(fh)*/
            if (_fh_8897 != last_r_file_no) {
                last_r_file_ptr = which_file(_fh_8897, EF_READ);
                last_r_file_no = _fh_8897;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_8898 = getc((FILE*)xstdin);
                }
                else
                _c_8898 = getc(last_r_file_ptr);
            }
            else
            _c_8898 = getc(last_r_file_ptr);

            /** 					if c < I2B then*/
            if (_c_8898 >= 249)
            goto LE; // [472] 489

            /** 						s[i] = c + MIN1B*/
            _4935 = _c_8898 + -9;
            _2 = (int)SEQ_PTR(_s_8899);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_8899 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_i_8998))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8998)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_8998);
            _1 = *(int *)_2;
            *(int *)_2 = _4935;
            if( _1 != _4935 ){
                DeRef(_1);
            }
            _4935 = NOVALUE;
            goto LF; // [486] 507
LE: 

            /** 						s[i] = deserialize_file(fh, c)*/
            DeRef(_4936);
            _4936 = _fh_8897;
            DeRef(_4937);
            _4937 = _c_8898;
            _4938 = _27deserialize_file(_4936, _4937);
            _4936 = NOVALUE;
            _4937 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_8899);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_8899 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_i_8998))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_8998)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_8998);
            _1 = *(int *)_2;
            *(int *)_2 = _4938;
            if( _1 != _4938 ){
                DeRef(_1);
            }
            _4938 = NOVALUE;
LF: 

            /** 				end for*/
            _0 = _i_8998;
            if (IS_ATOM_INT(_i_8998)) {
                _i_8998 = _i_8998 + 1;
                if ((long)((unsigned long)_i_8998 +(unsigned long) HIGH_BITS) >= 0){
                    _i_8998 = NewDouble((double)_i_8998);
                }
            }
            else {
                _i_8998 = binary_op_a(PLUS, _i_8998, 1);
            }
            DeRef(_0);
            goto LC; // [509] 465
LD: 
            ;
            DeRef(_i_8998);
        }

        /** 				return s*/
        DeRef(_len_8900);
        DeRef(_4863);
        _4863 = NOVALUE;
        DeRef(_4870);
        _4870 = NOVALUE;
        DeRef(_4879);
        _4879 = NOVALUE;
        DeRef(_4899);
        _4899 = NOVALUE;
        DeRef(_4881);
        _4881 = NOVALUE;
        DeRef(_4903);
        _4903 = NOVALUE;
        DeRef(_4916);
        _4916 = NOVALUE;
        DeRef(_4929);
        _4929 = NOVALUE;
        return _s_8899;
L9: 
    ;}    ;
}


int _27getp4(int _sdata_9010, int _pos_9011)
{
    int _4947 = NOVALUE;
    int _4946 = NOVALUE;
    int _4945 = NOVALUE;
    int _4944 = NOVALUE;
    int _4943 = NOVALUE;
    int _4942 = NOVALUE;
    int _4941 = NOVALUE;
    int _4940 = NOVALUE;
    int _4939 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, sdata[pos+0])*/
    _4939 = _pos_9011 + 0;
    _2 = (int)SEQ_PTR(_sdata_9010);
    _4940 = (int)*(((s1_ptr)_2)->base + _4939);
    if (IS_ATOM_INT(_27mem0_8809)){
        poke_addr = (unsigned char *)_27mem0_8809;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem0_8809)->dbl);
    }
    if (IS_ATOM_INT(_4940)) {
        *poke_addr = (unsigned char)_4940;
    }
    else if (IS_ATOM(_4940)) {
        *poke_addr = (signed char)DBL_PTR(_4940)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4940);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4940 = NOVALUE;

    /** 	poke(mem1, sdata[pos+1])*/
    _4941 = _pos_9011 + 1;
    _2 = (int)SEQ_PTR(_sdata_9010);
    _4942 = (int)*(((s1_ptr)_2)->base + _4941);
    if (IS_ATOM_INT(_27mem1_8810)){
        poke_addr = (unsigned char *)_27mem1_8810;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem1_8810)->dbl);
    }
    if (IS_ATOM_INT(_4942)) {
        *poke_addr = (unsigned char)_4942;
    }
    else if (IS_ATOM(_4942)) {
        *poke_addr = (signed char)DBL_PTR(_4942)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4942);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4942 = NOVALUE;

    /** 	poke(mem2, sdata[pos+2])*/
    _4943 = _pos_9011 + 2;
    _2 = (int)SEQ_PTR(_sdata_9010);
    _4944 = (int)*(((s1_ptr)_2)->base + _4943);
    if (IS_ATOM_INT(_27mem2_8811)){
        poke_addr = (unsigned char *)_27mem2_8811;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem2_8811)->dbl);
    }
    if (IS_ATOM_INT(_4944)) {
        *poke_addr = (unsigned char)_4944;
    }
    else if (IS_ATOM(_4944)) {
        *poke_addr = (signed char)DBL_PTR(_4944)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4944);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4944 = NOVALUE;

    /** 	poke(mem3, sdata[pos+3])*/
    _4945 = _pos_9011 + 3;
    _2 = (int)SEQ_PTR(_sdata_9010);
    _4946 = (int)*(((s1_ptr)_2)->base + _4945);
    if (IS_ATOM_INT(_27mem3_8812)){
        poke_addr = (unsigned char *)_27mem3_8812;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_27mem3_8812)->dbl);
    }
    if (IS_ATOM_INT(_4946)) {
        *poke_addr = (unsigned char)_4946;
    }
    else if (IS_ATOM(_4946)) {
        *poke_addr = (signed char)DBL_PTR(_4946)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_4946);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _4946 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_27mem0_8809)) {
        _4947 = *(unsigned long *)_27mem0_8809;
        if ((unsigned)_4947 > (unsigned)MAXINT)
        _4947 = NewDouble((double)(unsigned long)_4947);
    }
    else {
        _4947 = *(unsigned long *)(unsigned long)(DBL_PTR(_27mem0_8809)->dbl);
        if ((unsigned)_4947 > (unsigned)MAXINT)
        _4947 = NewDouble((double)(unsigned long)_4947);
    }
    DeRefDS(_sdata_9010);
    _4939 = NOVALUE;
    _4941 = NOVALUE;
    _4943 = NOVALUE;
    _4945 = NOVALUE;
    return _4947;
    ;
}


int _27deserialize_object(int _sdata_9023, int _pos_9024, int _c_9025)
{
    int _s_9026 = NOVALUE;
    int _len_9027 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_230_9076 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_227_9075 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_333_9098 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_330_9097 = NOVALUE;
    int _msg_inlined_crash_at_493_9129 = NOVALUE;
    int _temp_9141 = NOVALUE;
    int _5040 = NOVALUE;
    int _5038 = NOVALUE;
    int _5036 = NOVALUE;
    int _5035 = NOVALUE;
    int _5034 = NOVALUE;
    int _5033 = NOVALUE;
    int _5029 = NOVALUE;
    int _5027 = NOVALUE;
    int _5026 = NOVALUE;
    int _5025 = NOVALUE;
    int _5024 = NOVALUE;
    int _5023 = NOVALUE;
    int _5021 = NOVALUE;
    int _5020 = NOVALUE;
    int _5019 = NOVALUE;
    int _5018 = NOVALUE;
    int _5017 = NOVALUE;
    int _5015 = NOVALUE;
    int _5014 = NOVALUE;
    int _5013 = NOVALUE;
    int _5007 = NOVALUE;
    int _5006 = NOVALUE;
    int _5005 = NOVALUE;
    int _5004 = NOVALUE;
    int _5003 = NOVALUE;
    int _5002 = NOVALUE;
    int _5001 = NOVALUE;
    int _5000 = NOVALUE;
    int _4999 = NOVALUE;
    int _4998 = NOVALUE;
    int _4997 = NOVALUE;
    int _4996 = NOVALUE;
    int _4995 = NOVALUE;
    int _4994 = NOVALUE;
    int _4993 = NOVALUE;
    int _4992 = NOVALUE;
    int _4991 = NOVALUE;
    int _4990 = NOVALUE;
    int _4989 = NOVALUE;
    int _4988 = NOVALUE;
    int _4987 = NOVALUE;
    int _4986 = NOVALUE;
    int _4985 = NOVALUE;
    int _4984 = NOVALUE;
    int _4983 = NOVALUE;
    int _4982 = NOVALUE;
    int _4981 = NOVALUE;
    int _4980 = NOVALUE;
    int _4979 = NOVALUE;
    int _4978 = NOVALUE;
    int _4977 = NOVALUE;
    int _4976 = NOVALUE;
    int _4975 = NOVALUE;
    int _4974 = NOVALUE;
    int _4973 = NOVALUE;
    int _4972 = NOVALUE;
    int _4971 = NOVALUE;
    int _4970 = NOVALUE;
    int _4969 = NOVALUE;
    int _4968 = NOVALUE;
    int _4967 = NOVALUE;
    int _4966 = NOVALUE;
    int _4965 = NOVALUE;
    int _4964 = NOVALUE;
    int _4963 = NOVALUE;
    int _4962 = NOVALUE;
    int _4961 = NOVALUE;
    int _4960 = NOVALUE;
    int _4959 = NOVALUE;
    int _4958 = NOVALUE;
    int _4957 = NOVALUE;
    int _4956 = NOVALUE;
    int _4953 = NOVALUE;
    int _4952 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_9025 != 0)
    goto L1; // [9] 47

    /** 		c = sdata[pos]*/
    _2 = (int)SEQ_PTR(_sdata_9023);
    _c_9025 = (int)*(((s1_ptr)_2)->base + _pos_9024);
    if (!IS_ATOM_INT(_c_9025))
    _c_9025 = (long)DBL_PTR(_c_9025)->dbl;

    /** 		pos += 1*/
    _pos_9024 = _pos_9024 + 1;

    /** 		if c < I2B then*/
    if (_c_9025 >= 249)
    goto L2; // [27] 46

    /** 			return {c + MIN1B, pos}*/
    _4952 = _c_9025 + -9;
    if ((long)((unsigned long)_4952 + (unsigned long)HIGH_BITS) >= 0) 
    _4952 = NewDouble((double)_4952);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4952;
    ((int *)_2)[2] = _pos_9024;
    _4953 = MAKE_SEQ(_1);
    _4952 = NOVALUE;
    DeRefDS(_sdata_9023);
    DeRef(_s_9026);
    return _4953;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_9025;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return {sdata[pos] +*/
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4956 = (int)*(((s1_ptr)_2)->base + _pos_9024);
        _4957 = _pos_9024 + 1;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4958 = (int)*(((s1_ptr)_2)->base + _4957);
        if (IS_ATOM_INT(_4958)) {
            if (_4958 <= INT15 && _4958 >= -INT15)
            _4959 = 256 * _4958;
            else
            _4959 = NewDouble(256 * (double)_4958);
        }
        else {
            _4959 = binary_op(MULTIPLY, 256, _4958);
        }
        _4958 = NOVALUE;
        if (IS_ATOM_INT(_4956) && IS_ATOM_INT(_4959)) {
            _4960 = _4956 + _4959;
            if ((long)((unsigned long)_4960 + (unsigned long)HIGH_BITS) >= 0) 
            _4960 = NewDouble((double)_4960);
        }
        else {
            _4960 = binary_op(PLUS, _4956, _4959);
        }
        _4956 = NOVALUE;
        DeRef(_4959);
        _4959 = NOVALUE;
        if (IS_ATOM_INT(_4960)) {
            _4961 = _4960 + _27MIN2B_8794;
            if ((long)((unsigned long)_4961 + (unsigned long)HIGH_BITS) >= 0) 
            _4961 = NewDouble((double)_4961);
        }
        else {
            _4961 = binary_op(PLUS, _4960, _27MIN2B_8794);
        }
        DeRef(_4960);
        _4960 = NOVALUE;
        _4962 = _pos_9024 + 2;
        if ((long)((unsigned long)_4962 + (unsigned long)HIGH_BITS) >= 0) 
        _4962 = NewDouble((double)_4962);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _4961;
        ((int *)_2)[2] = _4962;
        _4963 = MAKE_SEQ(_1);
        _4962 = NOVALUE;
        _4961 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4953);
        _4953 = NOVALUE;
        _4957 = NOVALUE;
        return _4963;

        /** 		case I3B then*/
        case 250:

        /** 			return {sdata[pos] +*/
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4964 = (int)*(((s1_ptr)_2)->base + _pos_9024);
        _4965 = _pos_9024 + 1;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4966 = (int)*(((s1_ptr)_2)->base + _4965);
        if (IS_ATOM_INT(_4966)) {
            if (_4966 <= INT15 && _4966 >= -INT15)
            _4967 = 256 * _4966;
            else
            _4967 = NewDouble(256 * (double)_4966);
        }
        else {
            _4967 = binary_op(MULTIPLY, 256, _4966);
        }
        _4966 = NOVALUE;
        if (IS_ATOM_INT(_4964) && IS_ATOM_INT(_4967)) {
            _4968 = _4964 + _4967;
            if ((long)((unsigned long)_4968 + (unsigned long)HIGH_BITS) >= 0) 
            _4968 = NewDouble((double)_4968);
        }
        else {
            _4968 = binary_op(PLUS, _4964, _4967);
        }
        _4964 = NOVALUE;
        DeRef(_4967);
        _4967 = NOVALUE;
        _4969 = _pos_9024 + 2;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4970 = (int)*(((s1_ptr)_2)->base + _4969);
        if (IS_ATOM_INT(_4970)) {
            _4971 = NewDouble(65536 * (double)_4970);
        }
        else {
            _4971 = binary_op(MULTIPLY, 65536, _4970);
        }
        _4970 = NOVALUE;
        if (IS_ATOM_INT(_4968) && IS_ATOM_INT(_4971)) {
            _4972 = _4968 + _4971;
            if ((long)((unsigned long)_4972 + (unsigned long)HIGH_BITS) >= 0) 
            _4972 = NewDouble((double)_4972);
        }
        else {
            _4972 = binary_op(PLUS, _4968, _4971);
        }
        DeRef(_4968);
        _4968 = NOVALUE;
        DeRef(_4971);
        _4971 = NOVALUE;
        if (IS_ATOM_INT(_4972)) {
            _4973 = _4972 + _27MIN3B_8800;
            if ((long)((unsigned long)_4973 + (unsigned long)HIGH_BITS) >= 0) 
            _4973 = NewDouble((double)_4973);
        }
        else {
            _4973 = binary_op(PLUS, _4972, _27MIN3B_8800);
        }
        DeRef(_4972);
        _4972 = NOVALUE;
        _4974 = _pos_9024 + 3;
        if ((long)((unsigned long)_4974 + (unsigned long)HIGH_BITS) >= 0) 
        _4974 = NewDouble((double)_4974);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _4973;
        ((int *)_2)[2] = _4974;
        _4975 = MAKE_SEQ(_1);
        _4974 = NOVALUE;
        _4973 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        _4969 = NOVALUE;
        _4965 = NOVALUE;
        return _4975;

        /** 		case I4B then*/
        case 251:

        /** 			return {getp4(sdata, pos) + MIN4B, pos + 4}*/
        RefDS(_sdata_9023);
        _4976 = _27getp4(_sdata_9023, _pos_9024);
        if (IS_ATOM_INT(_4976) && IS_ATOM_INT(_27MIN4B_8806)) {
            _4977 = _4976 + _27MIN4B_8806;
            if ((long)((unsigned long)_4977 + (unsigned long)HIGH_BITS) >= 0) 
            _4977 = NewDouble((double)_4977);
        }
        else {
            _4977 = binary_op(PLUS, _4976, _27MIN4B_8806);
        }
        DeRef(_4976);
        _4976 = NOVALUE;
        _4978 = _pos_9024 + 4;
        if ((long)((unsigned long)_4978 + (unsigned long)HIGH_BITS) >= 0) 
        _4978 = NewDouble((double)_4978);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _4977;
        ((int *)_2)[2] = _4978;
        _4979 = MAKE_SEQ(_1);
        _4978 = NOVALUE;
        _4977 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        return _4979;

        /** 		case F4B then*/
        case 252:

        /** 			return {convert:float32_to_atom({sdata[pos], sdata[pos+1],*/
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4980 = (int)*(((s1_ptr)_2)->base + _pos_9024);
        _4981 = _pos_9024 + 1;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4982 = (int)*(((s1_ptr)_2)->base + _4981);
        _4983 = _pos_9024 + 2;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4984 = (int)*(((s1_ptr)_2)->base + _4983);
        _4985 = _pos_9024 + 3;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4986 = (int)*(((s1_ptr)_2)->base + _4985);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_4980);
        *((int *)(_2+4)) = _4980;
        Ref(_4982);
        *((int *)(_2+8)) = _4982;
        Ref(_4984);
        *((int *)(_2+12)) = _4984;
        Ref(_4986);
        *((int *)(_2+16)) = _4986;
        _4987 = MAKE_SEQ(_1);
        _4986 = NOVALUE;
        _4984 = NOVALUE;
        _4982 = NOVALUE;
        _4980 = NOVALUE;
        DeRef(_ieee32_inlined_float32_to_atom_at_227_9075);
        _ieee32_inlined_float32_to_atom_at_227_9075 = _4987;
        _4987 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_230_9076);
        _float32_to_atom_inlined_float32_to_atom_at_230_9076 = machine(49, _ieee32_inlined_float32_to_atom_at_227_9075);
        DeRef(_ieee32_inlined_float32_to_atom_at_227_9075);
        _ieee32_inlined_float32_to_atom_at_227_9075 = NOVALUE;
        _4988 = _pos_9024 + 4;
        if ((long)((unsigned long)_4988 + (unsigned long)HIGH_BITS) >= 0) 
        _4988 = NewDouble((double)_4988);
        Ref(_float32_to_atom_inlined_float32_to_atom_at_230_9076);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _float32_to_atom_inlined_float32_to_atom_at_230_9076;
        ((int *)_2)[2] = _4988;
        _4989 = MAKE_SEQ(_1);
        _4988 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        DeRef(_4979);
        _4979 = NOVALUE;
        DeRef(_4981);
        _4981 = NOVALUE;
        DeRef(_4983);
        _4983 = NOVALUE;
        DeRef(_4985);
        _4985 = NOVALUE;
        return _4989;

        /** 		case F8B then*/
        case 253:

        /** 			return {convert:float64_to_atom({sdata[pos], sdata[pos+1],*/
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4990 = (int)*(((s1_ptr)_2)->base + _pos_9024);
        _4991 = _pos_9024 + 1;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4992 = (int)*(((s1_ptr)_2)->base + _4991);
        _4993 = _pos_9024 + 2;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4994 = (int)*(((s1_ptr)_2)->base + _4993);
        _4995 = _pos_9024 + 3;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4996 = (int)*(((s1_ptr)_2)->base + _4995);
        _4997 = _pos_9024 + 4;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _4998 = (int)*(((s1_ptr)_2)->base + _4997);
        _4999 = _pos_9024 + 5;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _5000 = (int)*(((s1_ptr)_2)->base + _4999);
        _5001 = _pos_9024 + 6;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _5002 = (int)*(((s1_ptr)_2)->base + _5001);
        _5003 = _pos_9024 + 7;
        _2 = (int)SEQ_PTR(_sdata_9023);
        _5004 = (int)*(((s1_ptr)_2)->base + _5003);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_4990);
        *((int *)(_2+4)) = _4990;
        Ref(_4992);
        *((int *)(_2+8)) = _4992;
        Ref(_4994);
        *((int *)(_2+12)) = _4994;
        Ref(_4996);
        *((int *)(_2+16)) = _4996;
        Ref(_4998);
        *((int *)(_2+20)) = _4998;
        Ref(_5000);
        *((int *)(_2+24)) = _5000;
        Ref(_5002);
        *((int *)(_2+28)) = _5002;
        Ref(_5004);
        *((int *)(_2+32)) = _5004;
        _5005 = MAKE_SEQ(_1);
        _5004 = NOVALUE;
        _5002 = NOVALUE;
        _5000 = NOVALUE;
        _4998 = NOVALUE;
        _4996 = NOVALUE;
        _4994 = NOVALUE;
        _4992 = NOVALUE;
        _4990 = NOVALUE;
        DeRef(_ieee64_inlined_float64_to_atom_at_330_9097);
        _ieee64_inlined_float64_to_atom_at_330_9097 = _5005;
        _5005 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_333_9098);
        _float64_to_atom_inlined_float64_to_atom_at_333_9098 = machine(47, _ieee64_inlined_float64_to_atom_at_330_9097);
        DeRef(_ieee64_inlined_float64_to_atom_at_330_9097);
        _ieee64_inlined_float64_to_atom_at_330_9097 = NOVALUE;
        _5006 = _pos_9024 + 8;
        if ((long)((unsigned long)_5006 + (unsigned long)HIGH_BITS) >= 0) 
        _5006 = NewDouble((double)_5006);
        Ref(_float64_to_atom_inlined_float64_to_atom_at_333_9098);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _float64_to_atom_inlined_float64_to_atom_at_333_9098;
        ((int *)_2)[2] = _5006;
        _5007 = MAKE_SEQ(_1);
        _5006 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4989);
        _4989 = NOVALUE;
        DeRef(_4997);
        _4997 = NOVALUE;
        DeRef(_4993);
        _4993 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4979);
        _4979 = NOVALUE;
        DeRef(_4985);
        _4985 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        DeRef(_4983);
        _4983 = NOVALUE;
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_4981);
        _4981 = NOVALUE;
        DeRef(_5003);
        _5003 = NOVALUE;
        DeRef(_4991);
        _4991 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        DeRef(_4999);
        _4999 = NOVALUE;
        DeRef(_5001);
        _5001 = NOVALUE;
        DeRef(_4995);
        _4995 = NOVALUE;
        return _5007;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_9025 != 254)
        goto L3; // [363] 382

        /** 				len = sdata[pos]*/
        _2 = (int)SEQ_PTR(_sdata_9023);
        _len_9027 = (int)*(((s1_ptr)_2)->base + _pos_9024);
        if (!IS_ATOM_INT(_len_9027))
        _len_9027 = (long)DBL_PTR(_len_9027)->dbl;

        /** 				pos += 1*/
        _pos_9024 = _pos_9024 + 1;
        goto L4; // [379] 398
L3: 

        /** 				len = getp4(sdata, pos)*/
        RefDS(_sdata_9023);
        _len_9027 = _27getp4(_sdata_9023, _pos_9024);
        if (!IS_ATOM_INT(_len_9027)) {
            _1 = (long)(DBL_PTR(_len_9027)->dbl);
            DeRefDS(_len_9027);
            _len_9027 = _1;
        }

        /** 				pos += 4*/
        _pos_9024 = _pos_9024 + 4;
L4: 

        /** 			if c = S4B and len < 256 then*/
        _5013 = (_c_9025 == 255);
        if (_5013 == 0) {
            goto L5; // [404] 516
        }
        _5015 = (_len_9027 < 256);
        if (_5015 == 0)
        {
            DeRef(_5015);
            _5015 = NOVALUE;
            goto L5; // [415] 516
        }
        else{
            DeRef(_5015);
            _5015 = NOVALUE;
        }

        /** 				if len = I8B then*/
        if (_len_9027 != 0)
        goto L6; // [422] 456

        /** 					return {int64_to_atom( sdata[pos..pos+7] ), pos + 8 }*/
        _5017 = _pos_9024 + 7;
        rhs_slice_target = (object_ptr)&_5018;
        RHS_Slice(_sdata_9023, _pos_9024, _5017);
        _5019 = _27int64_to_atom(_5018);
        _5018 = NOVALUE;
        _5020 = _pos_9024 + 8;
        if ((long)((unsigned long)_5020 + (unsigned long)HIGH_BITS) >= 0) 
        _5020 = NewDouble((double)_5020);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5019;
        ((int *)_2)[2] = _5020;
        _5021 = MAKE_SEQ(_1);
        _5020 = NOVALUE;
        _5019 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4989);
        _4989 = NOVALUE;
        DeRef(_4997);
        _4997 = NOVALUE;
        DeRef(_4993);
        _4993 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_5013);
        _5013 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4979);
        _4979 = NOVALUE;
        DeRef(_4985);
        _4985 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        DeRef(_4983);
        _4983 = NOVALUE;
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_5007);
        _5007 = NOVALUE;
        _5017 = NOVALUE;
        DeRef(_4981);
        _4981 = NOVALUE;
        DeRef(_5003);
        _5003 = NOVALUE;
        DeRef(_4991);
        _4991 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        DeRef(_4999);
        _4999 = NOVALUE;
        DeRef(_5001);
        _5001 = NOVALUE;
        DeRef(_4995);
        _4995 = NOVALUE;
        return _5021;
        goto L7; // [453] 623
L6: 

        /** 				elsif len = F10B then*/
        if (_len_9027 != 1)
        goto L8; // [458] 492

        /** 					return { float80_to_atom( sdata[pos..pos+9] ), pos + 10 }*/
        _5023 = _pos_9024 + 9;
        rhs_slice_target = (object_ptr)&_5024;
        RHS_Slice(_sdata_9023, _pos_9024, _5023);
        _5025 = _27float80_to_atom(_5024);
        _5024 = NOVALUE;
        _5026 = _pos_9024 + 10;
        if ((long)((unsigned long)_5026 + (unsigned long)HIGH_BITS) >= 0) 
        _5026 = NewDouble((double)_5026);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _5025;
        ((int *)_2)[2] = _5026;
        _5027 = MAKE_SEQ(_1);
        _5026 = NOVALUE;
        _5025 = NOVALUE;
        DeRefDS(_sdata_9023);
        DeRef(_s_9026);
        DeRef(_4989);
        _4989 = NOVALUE;
        DeRef(_4997);
        _4997 = NOVALUE;
        DeRef(_4993);
        _4993 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_5013);
        _5013 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4979);
        _4979 = NOVALUE;
        DeRef(_4985);
        _4985 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        _5023 = NOVALUE;
        DeRef(_4983);
        _4983 = NOVALUE;
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_5007);
        _5007 = NOVALUE;
        DeRef(_5017);
        _5017 = NOVALUE;
        DeRef(_4981);
        _4981 = NOVALUE;
        DeRef(_5003);
        _5003 = NOVALUE;
        DeRef(_4991);
        _4991 = NOVALUE;
        DeRef(_5021);
        _5021 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        DeRef(_4999);
        _4999 = NOVALUE;
        DeRef(_5001);
        _5001 = NOVALUE;
        DeRef(_4995);
        _4995 = NOVALUE;
        return _5027;
        goto L7; // [489] 623
L8: 

        /** 					error:crash( "Invalid sequence serialization" )*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_493_9129);
        _msg_inlined_crash_at_493_9129 = EPrintf(-9999999, _4930, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_493_9129);

        /** end procedure*/
        goto L9; // [507] 510
L9: 
        DeRefi(_msg_inlined_crash_at_493_9129);
        _msg_inlined_crash_at_493_9129 = NOVALUE;
        goto L7; // [513] 623
L5: 

        /** 				s = repeat(0, len)*/
        DeRef(_s_9026);
        _s_9026 = Repeat(0, _len_9027);

        /** 				for i = 1 to len do*/
        _5029 = _len_9027;
        {
            int _i_9133;
            _i_9133 = 1;
LA: 
            if (_i_9133 > _5029){
                goto LB; // [529] 612
            }

            /** 					c = sdata[pos]*/
            _2 = (int)SEQ_PTR(_sdata_9023);
            _c_9025 = (int)*(((s1_ptr)_2)->base + _pos_9024);
            if (!IS_ATOM_INT(_c_9025))
            _c_9025 = (long)DBL_PTR(_c_9025)->dbl;

            /** 					pos += 1*/
            _pos_9024 = _pos_9024 + 1;

            /** 					if c < I2B then*/
            if (_c_9025 >= 249)
            goto LC; // [550] 567

            /** 						s[i] = c + MIN1B*/
            _5033 = _c_9025 + -9;
            if ((long)((unsigned long)_5033 + (unsigned long)HIGH_BITS) >= 0) 
            _5033 = NewDouble((double)_5033);
            _2 = (int)SEQ_PTR(_s_9026);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9026 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_9133);
            _1 = *(int *)_2;
            *(int *)_2 = _5033;
            if( _1 != _5033 ){
                DeRef(_1);
            }
            _5033 = NOVALUE;
            goto LD; // [564] 605
LC: 

            /** 						sequence temp = deserialize_object(sdata, pos, c)*/
            RefDS(_sdata_9023);
            DeRef(_5034);
            _5034 = _sdata_9023;
            DeRef(_5035);
            _5035 = _pos_9024;
            DeRef(_5036);
            _5036 = _c_9025;
            _0 = _temp_9141;
            _temp_9141 = _27deserialize_object(_5034, _5035, _5036);
            DeRef(_0);
            _5034 = NOVALUE;
            _5035 = NOVALUE;
            _5036 = NOVALUE;

            /** 						s[i] = temp[1]*/
            _2 = (int)SEQ_PTR(_temp_9141);
            _5038 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_5038);
            _2 = (int)SEQ_PTR(_s_9026);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_9026 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_9133);
            _1 = *(int *)_2;
            *(int *)_2 = _5038;
            if( _1 != _5038 ){
                DeRef(_1);
            }
            _5038 = NOVALUE;

            /** 						pos = temp[2]*/
            _2 = (int)SEQ_PTR(_temp_9141);
            _pos_9024 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_pos_9024))
            _pos_9024 = (long)DBL_PTR(_pos_9024)->dbl;
            DeRefDS(_temp_9141);
            _temp_9141 = NOVALUE;
LD: 

            /** 				end for*/
            _i_9133 = _i_9133 + 1;
            goto LA; // [607] 536
LB: 
            ;
        }

        /** 				return {s, pos}*/
        RefDS(_s_9026);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _s_9026;
        ((int *)_2)[2] = _pos_9024;
        _5040 = MAKE_SEQ(_1);
        DeRefDS(_sdata_9023);
        DeRefDS(_s_9026);
        DeRef(_4989);
        _4989 = NOVALUE;
        DeRef(_4997);
        _4997 = NOVALUE;
        DeRef(_4993);
        _4993 = NOVALUE;
        DeRef(_4963);
        _4963 = NOVALUE;
        DeRef(_5013);
        _5013 = NOVALUE;
        DeRef(_4957);
        _4957 = NOVALUE;
        DeRef(_4979);
        _4979 = NOVALUE;
        DeRef(_4985);
        _4985 = NOVALUE;
        DeRef(_4969);
        _4969 = NOVALUE;
        DeRef(_4965);
        _4965 = NOVALUE;
        DeRef(_5023);
        _5023 = NOVALUE;
        DeRef(_5027);
        _5027 = NOVALUE;
        DeRef(_4983);
        _4983 = NOVALUE;
        DeRef(_4953);
        _4953 = NOVALUE;
        DeRef(_5007);
        _5007 = NOVALUE;
        DeRef(_5017);
        _5017 = NOVALUE;
        DeRef(_4981);
        _4981 = NOVALUE;
        DeRef(_5003);
        _5003 = NOVALUE;
        DeRef(_4991);
        _4991 = NOVALUE;
        DeRef(_5021);
        _5021 = NOVALUE;
        DeRef(_4975);
        _4975 = NOVALUE;
        DeRef(_4999);
        _4999 = NOVALUE;
        DeRef(_5001);
        _5001 = NOVALUE;
        DeRef(_4995);
        _4995 = NOVALUE;
        return _5040;
L7: 
    ;}    ;
}


int _27deserialize(int _sdata_9151, int _pos_9152)
{
    int _5044 = NOVALUE;
    int _5043 = NOVALUE;
    int _5042 = NOVALUE;
    int _5041 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pos_9152)) {
        _1 = (long)(DBL_PTR(_pos_9152)->dbl);
        DeRefDS(_pos_9152);
        _pos_9152 = _1;
    }

    /** 	if integer(sdata) then*/
    if (IS_ATOM_INT(_sdata_9151))
    _5041 = 1;
    else if (IS_ATOM_DBL(_sdata_9151))
    _5041 = IS_ATOM_INT(DoubleToInt(_sdata_9151));
    else
    _5041 = 0;
    if (_5041 == 0)
    {
        _5041 = NOVALUE;
        goto L1; // [8] 23
    }
    else{
        _5041 = NOVALUE;
    }

    /** 		return deserialize_file(sdata, 0)*/
    Ref(_sdata_9151);
    _5042 = _27deserialize_file(_sdata_9151, 0);
    DeRef(_sdata_9151);
    return _5042;
L1: 

    /** 	if atom(sdata) then*/
    _5043 = IS_ATOM(_sdata_9151);
    if (_5043 == 0)
    {
        _5043 = NOVALUE;
        goto L2; // [28] 38
    }
    else{
        _5043 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_sdata_9151);
    DeRef(_5042);
    _5042 = NOVALUE;
    return 0;
L2: 

    /** 	return deserialize_object(sdata, pos, 0)*/
    Ref(_sdata_9151);
    _5044 = _27deserialize_object(_sdata_9151, _pos_9152, 0);
    DeRef(_sdata_9151);
    DeRef(_5042);
    _5042 = NOVALUE;
    return _5044;
    ;
}
int deserialize() __attribute__ ((alias ("_27deserialize")));


int _27serialize(int _x_9161)
{
    int _x4_9162 = NOVALUE;
    int _s_9163 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_9197 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_9200 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_9205 = NOVALUE;
    int _5083 = NOVALUE;
    int _5082 = NOVALUE;
    int _5081 = NOVALUE;
    int _5079 = NOVALUE;
    int _5078 = NOVALUE;
    int _5076 = NOVALUE;
    int _5074 = NOVALUE;
    int _5073 = NOVALUE;
    int _5072 = NOVALUE;
    int _5070 = NOVALUE;
    int _5069 = NOVALUE;
    int _5068 = NOVALUE;
    int _5067 = NOVALUE;
    int _5066 = NOVALUE;
    int _5065 = NOVALUE;
    int _5064 = NOVALUE;
    int _5063 = NOVALUE;
    int _5062 = NOVALUE;
    int _5060 = NOVALUE;
    int _5059 = NOVALUE;
    int _5058 = NOVALUE;
    int _5057 = NOVALUE;
    int _5056 = NOVALUE;
    int _5055 = NOVALUE;
    int _5053 = NOVALUE;
    int _5052 = NOVALUE;
    int _5051 = NOVALUE;
    int _5050 = NOVALUE;
    int _5049 = NOVALUE;
    int _5048 = NOVALUE;
    int _5047 = NOVALUE;
    int _5046 = NOVALUE;
    int _5045 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_9161))
    _5045 = 1;
    else if (IS_ATOM_DBL(_x_9161))
    _5045 = IS_ATOM_INT(DoubleToInt(_x_9161));
    else
    _5045 = 0;
    if (_5045 == 0)
    {
        _5045 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _5045 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_9161)) {
        _5046 = (_x_9161 >= -9);
    }
    else {
        _5046 = binary_op(GREATEREQ, _x_9161, -9);
    }
    if (IS_ATOM_INT(_5046)) {
        if (_5046 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_5046)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_9161)) {
        _5048 = (_x_9161 <= 239);
    }
    else {
        _5048 = binary_op(LESSEQ, _x_9161, 239);
    }
    if (_5048 == 0) {
        DeRef(_5048);
        _5048 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_5048) && DBL_PTR(_5048)->dbl == 0.0){
            DeRef(_5048);
            _5048 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_5048);
        _5048 = NOVALUE;
    }
    DeRef(_5048);
    _5048 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_9161)) {
        _5049 = _x_9161 - -9;
        if ((long)((unsigned long)_5049 +(unsigned long) HIGH_BITS) >= 0){
            _5049 = NewDouble((double)_5049);
        }
    }
    else {
        _5049 = binary_op(MINUS, _x_9161, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5049;
    _5050 = MAKE_SEQ(_1);
    _5049 = NOVALUE;
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    return _5050;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_9161)) {
        _5051 = (_x_9161 >= _27MIN2B_8794);
    }
    else {
        _5051 = binary_op(GREATEREQ, _x_9161, _27MIN2B_8794);
    }
    if (IS_ATOM_INT(_5051)) {
        if (_5051 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_5051)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_9161)) {
        _5053 = (_x_9161 <= 32767);
    }
    else {
        _5053 = binary_op(LESSEQ, _x_9161, 32767);
    }
    if (_5053 == 0) {
        DeRef(_5053);
        _5053 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_5053) && DBL_PTR(_5053)->dbl == 0.0){
            DeRef(_5053);
            _5053 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_5053);
        _5053 = NOVALUE;
    }
    DeRef(_5053);
    _5053 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_9161;
    if (IS_ATOM_INT(_x_9161)) {
        _x_9161 = _x_9161 - _27MIN2B_8794;
        if ((long)((unsigned long)_x_9161 +(unsigned long) HIGH_BITS) >= 0){
            _x_9161 = NewDouble((double)_x_9161);
        }
    }
    else {
        _x_9161 = binary_op(MINUS, _x_9161, _27MIN2B_8794);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_9161)) {
        {unsigned long tu;
             tu = (unsigned long)_x_9161 & (unsigned long)255;
             _5055 = MAKE_UINT(tu);
        }
    }
    else {
        _5055 = binary_op(AND_BITS, _x_9161, 255);
    }
    if (IS_ATOM_INT(_x_9161)) {
        if (256 > 0 && _x_9161 >= 0) {
            _5056 = _x_9161 / 256;
        }
        else {
            temp_dbl = floor((double)_x_9161 / (double)256);
            if (_x_9161 != MININT)
            _5056 = (long)temp_dbl;
            else
            _5056 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9161, 256);
        _5056 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _5055;
    *((int *)(_2+12)) = _5056;
    _5057 = MAKE_SEQ(_1);
    _5056 = NOVALUE;
    _5055 = NOVALUE;
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    return _5057;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_9161)) {
        _5058 = (_x_9161 >= _27MIN3B_8800);
    }
    else {
        _5058 = binary_op(GREATEREQ, _x_9161, _27MIN3B_8800);
    }
    if (IS_ATOM_INT(_5058)) {
        if (_5058 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_5058)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_9161)) {
        _5060 = (_x_9161 <= 8388607);
    }
    else {
        _5060 = binary_op(LESSEQ, _x_9161, 8388607);
    }
    if (_5060 == 0) {
        DeRef(_5060);
        _5060 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_5060) && DBL_PTR(_5060)->dbl == 0.0){
            DeRef(_5060);
            _5060 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_5060);
        _5060 = NOVALUE;
    }
    DeRef(_5060);
    _5060 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_9161;
    if (IS_ATOM_INT(_x_9161)) {
        _x_9161 = _x_9161 - _27MIN3B_8800;
        if ((long)((unsigned long)_x_9161 +(unsigned long) HIGH_BITS) >= 0){
            _x_9161 = NewDouble((double)_x_9161);
        }
    }
    else {
        _x_9161 = binary_op(MINUS, _x_9161, _27MIN3B_8800);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_9161)) {
        {unsigned long tu;
             tu = (unsigned long)_x_9161 & (unsigned long)255;
             _5062 = MAKE_UINT(tu);
        }
    }
    else {
        _5062 = binary_op(AND_BITS, _x_9161, 255);
    }
    if (IS_ATOM_INT(_x_9161)) {
        if (256 > 0 && _x_9161 >= 0) {
            _5063 = _x_9161 / 256;
        }
        else {
            temp_dbl = floor((double)_x_9161 / (double)256);
            if (_x_9161 != MININT)
            _5063 = (long)temp_dbl;
            else
            _5063 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9161, 256);
        _5063 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_5063)) {
        {unsigned long tu;
             tu = (unsigned long)_5063 & (unsigned long)255;
             _5064 = MAKE_UINT(tu);
        }
    }
    else {
        _5064 = binary_op(AND_BITS, _5063, 255);
    }
    DeRef(_5063);
    _5063 = NOVALUE;
    if (IS_ATOM_INT(_x_9161)) {
        if (65536 > 0 && _x_9161 >= 0) {
            _5065 = _x_9161 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_9161 / (double)65536);
            if (_x_9161 != MININT)
            _5065 = (long)temp_dbl;
            else
            _5065 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_9161, 65536);
        _5065 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _5062;
    *((int *)(_2+12)) = _5064;
    *((int *)(_2+16)) = _5065;
    _5066 = MAKE_SEQ(_1);
    _5065 = NOVALUE;
    _5064 = NOVALUE;
    _5062 = NOVALUE;
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    DeRef(_5057);
    _5057 = NOVALUE;
    DeRef(_5058);
    _5058 = NOVALUE;
    return _5066;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_9161) && IS_ATOM_INT(_27MIN4B_8806)) {
        _5067 = _x_9161 - _27MIN4B_8806;
        if ((long)((unsigned long)_5067 +(unsigned long) HIGH_BITS) >= 0){
            _5067 = NewDouble((double)_5067);
        }
    }
    else {
        _5067 = binary_op(MINUS, _x_9161, _27MIN4B_8806);
    }
    _5068 = _8int_to_bytes(_5067);
    _5067 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_5068)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_5068)) {
        Prepend(&_5069, _5068, 251);
    }
    else {
        Concat((object_ptr)&_5069, 251, _5068);
    }
    DeRef(_5068);
    _5068 = NOVALUE;
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    DeRef(_5057);
    _5057 = NOVALUE;
    DeRef(_5058);
    _5058 = NOVALUE;
    DeRef(_5066);
    _5066 = NOVALUE;
    return _5069;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _5070 = IS_ATOM(_x_9161);
    if (_5070 == 0)
    {
        _5070 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _5070 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_9162);
    _x4_9162 = machine(48, _x_9161);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_9200);
    _float32_to_atom_inlined_float32_to_atom_at_203_9200 = machine(49, _x4_9162);
    if (binary_op_a(NOTEQ, _x_9161, _float32_to_atom_inlined_float32_to_atom_at_203_9200)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_5072, _x4_9162, 252);
    DeRef(_x_9161);
    DeRefDSi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    DeRef(_5057);
    _5057 = NOVALUE;
    DeRef(_5058);
    _5058 = NOVALUE;
    DeRef(_5066);
    _5066 = NOVALUE;
    DeRef(_5069);
    _5069 = NOVALUE;
    return _5072;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_9205);
    _atom_to_float64_inlined_atom_to_float64_at_229_9205 = machine(46, _x_9161);
    Prepend(&_5073, _atom_to_float64_inlined_atom_to_float64_at_229_9205, 253);
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_s_9163);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    DeRef(_5057);
    _5057 = NOVALUE;
    DeRef(_5058);
    _5058 = NOVALUE;
    DeRef(_5066);
    _5066 = NOVALUE;
    DeRef(_5069);
    _5069 = NOVALUE;
    DeRef(_5072);
    _5072 = NOVALUE;
    return _5073;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_9161)){
            _5074 = SEQ_PTR(_x_9161)->length;
    }
    else {
        _5074 = 1;
    }
    if (_5074 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_9161)){
            _5076 = SEQ_PTR(_x_9161)->length;
    }
    else {
        _5076 = 1;
    }
    DeRef(_s_9163);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _5076;
    _s_9163 = MAKE_SEQ(_1);
    _5076 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_9161)){
            _5078 = SEQ_PTR(_x_9161)->length;
    }
    else {
        _5078 = 1;
    }
    _5079 = _8int_to_bytes(_5078);
    _5078 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_5079)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_5079)) {
        Prepend(&_s_9163, _5079, 255);
    }
    else {
        Concat((object_ptr)&_s_9163, 255, _5079);
    }
    DeRef(_5079);
    _5079 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9161)){
            _5081 = SEQ_PTR(_x_9161)->length;
    }
    else {
        _5081 = 1;
    }
    {
        int _i_9218;
        _i_9218 = 1;
LA: 
        if (_i_9218 > _5081){
            goto LB; // [289] 319
        }

        /** 			s &= serialize(x[i])*/
        _2 = (int)SEQ_PTR(_x_9161);
        _5082 = (int)*(((s1_ptr)_2)->base + _i_9218);
        Ref(_5082);
        _5083 = _27serialize(_5082);
        _5082 = NOVALUE;
        if (IS_SEQUENCE(_s_9163) && IS_ATOM(_5083)) {
            Ref(_5083);
            Append(&_s_9163, _s_9163, _5083);
        }
        else if (IS_ATOM(_s_9163) && IS_SEQUENCE(_5083)) {
        }
        else {
            Concat((object_ptr)&_s_9163, _s_9163, _5083);
        }
        DeRef(_5083);
        _5083 = NOVALUE;

        /** 		end for*/
        _i_9218 = _i_9218 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_9161);
    DeRefi(_x4_9162);
    DeRef(_5046);
    _5046 = NOVALUE;
    DeRef(_5050);
    _5050 = NOVALUE;
    DeRef(_5051);
    _5051 = NOVALUE;
    DeRef(_5057);
    _5057 = NOVALUE;
    DeRef(_5058);
    _5058 = NOVALUE;
    DeRef(_5066);
    _5066 = NOVALUE;
    DeRef(_5069);
    _5069 = NOVALUE;
    DeRef(_5072);
    _5072 = NOVALUE;
    DeRef(_5073);
    _5073 = NOVALUE;
    return _s_9163;
L3: 
    ;
}
int serialize() __attribute__ ((alias ("_27serialize")));


int _27dump(int _data_9225, int _filename_9226)
{
    int _fh_9227 = NOVALUE;
    int _sdata_9228 = NOVALUE;
    int _5088 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(filename, "wb")*/
    _fh_9227 = EOpen(_filename_9226, _1325, 0);

    /** 	if fh < 0 then*/
    if (_fh_9227 >= 0)
    goto L1; // [14] 25

    /** 		return 0*/
    DeRefDS(_data_9225);
    DeRefDS(_filename_9226);
    DeRef(_sdata_9228);
    return 0;
L1: 

    /** 	sdata = serialize(data)*/
    RefDS(_data_9225);
    _0 = _sdata_9228;
    _sdata_9228 = _27serialize(_data_9225);
    DeRef(_0);

    /** 	puts(fh, sdata)*/
    EPuts(_fh_9227, _sdata_9228); // DJP 

    /** 	close(fh)*/
    EClose(_fh_9227);

    /** 	return length(sdata) -- Length is always > 0*/
    if (IS_SEQUENCE(_sdata_9228)){
            _5088 = SEQ_PTR(_sdata_9228)->length;
    }
    else {
        _5088 = 1;
    }
    DeRefDS(_data_9225);
    DeRefDS(_filename_9226);
    DeRefDS(_sdata_9228);
    return _5088;
    ;
}
int dump() __attribute__ ((alias ("_27dump")));


int _27load(int _filename_9236)
{
    int _fh_9237 = NOVALUE;
    int _sdata_9238 = NOVALUE;
    int _5093 = NOVALUE;
    int _5091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(filename, "rb")*/
    _fh_9237 = EOpen(_filename_9236, _1284, 0);

    /** 	if fh < 0 then*/
    if (_fh_9237 >= 0)
    goto L1; // [12] 27

    /** 		return {0}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _5091 = MAKE_SEQ(_1);
    DeRefDS(_filename_9236);
    DeRef(_sdata_9238);
    return _5091;
L1: 

    /** 	sdata = deserialize(fh)*/
    _0 = _sdata_9238;
    _sdata_9238 = _27deserialize(_fh_9237, 1);
    DeRef(_0);

    /** 	close(fh)*/
    EClose(_fh_9237);

    /** 	return {1, sdata}*/
    RefDS(_sdata_9238);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _sdata_9238;
    _5093 = MAKE_SEQ(_1);
    DeRefDS(_filename_9236);
    DeRefDS(_sdata_9238);
    DeRef(_5091);
    _5091 = NOVALUE;
    return _5093;
    ;
}
int load() __attribute__ ((alias ("_27load")));



// 0x691F3DA4
