// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _52iif(int _test_22586, int _ifTrue_22587, int _ifFalse_22588)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_22586 == 0) {
        goto L1; // [3] 13
    }
    else {
        if (!IS_ATOM_INT(_test_22586) && DBL_PTR(_test_22586)->dbl == 0.0){
            goto L1; // [3] 13
        }
    }

    /** 		return ifTrue*/
    DeRef(_test_22586);
    DeRef(_ifFalse_22588);
    return _ifTrue_22587;
L1: 

    /** 	return ifFalse*/
    DeRef(_test_22586);
    DeRef(_ifTrue_22587);
    return _ifFalse_22588;
    ;
}
int iif() __attribute__ ((alias ("_52iif")));


int _52iff(int _test_22592, int _ifTrue_22593, int _ifFalse_22594)
{
    int _iif_inlined_iif_at_2_22596 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return iif(test, ifTrue, ifFalse)*/

    /** 	if test then*/
    if (_test_22592 == 0) {
        goto L1; // [5] 16
    }
    else {
        if (!IS_ATOM_INT(_test_22592) && DBL_PTR(_test_22592)->dbl == 0.0){
            goto L1; // [5] 16
        }
    }

    /** 		return ifTrue*/
    Ref(_ifTrue_22593);
    DeRef(_iif_inlined_iif_at_2_22596);
    _iif_inlined_iif_at_2_22596 = _ifTrue_22593;
    goto L2; // [13] 22
L1: 

    /** 	return ifFalse*/
    Ref(_ifFalse_22594);
    DeRef(_iif_inlined_iif_at_2_22596);
    _iif_inlined_iif_at_2_22596 = _ifFalse_22594;
L2: 
    DeRef(_test_22592);
    DeRef(_ifTrue_22593);
    DeRef(_ifFalse_22594);
    return _iif_inlined_iif_at_2_22596;
    ;
}
int iff() __attribute__ ((alias ("_52iff")));



// 0x5185F039
