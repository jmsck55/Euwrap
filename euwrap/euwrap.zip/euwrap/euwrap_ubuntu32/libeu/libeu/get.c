// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _17get_ch()
{
    int _1363 = NOVALUE;
    int _1362 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _1362 = IS_SEQUENCE(_17input_string_2841);
    if (_1362 == 0)
    {
        _1362 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _1362 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_17input_string_2841)){
            _1363 = SEQ_PTR(_17input_string_2841)->length;
    }
    else {
        _1363 = 1;
    }
    if (_17string_next_2842 > _1363)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_17input_string_2841);
    _17ch_2843 = (int)*(((s1_ptr)_2)->base + _17string_next_2842);
    if (!IS_ATOM_INT(_17ch_2843)){
        _17ch_2843 = (long)DBL_PTR(_17ch_2843)->dbl;
    }

    /** 			string_next += 1*/
    _17string_next_2842 = _17string_next_2842 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _17ch_2843 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_17input_file_2840 != last_r_file_no) {
        last_r_file_ptr = which_file(_17input_file_2840, EF_READ);
        last_r_file_no = _17input_file_2840;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _17ch_2843 = getc((FILE*)xstdin);
        }
        else
        _17ch_2843 = getc(last_r_file_ptr);
    }
    else
    _17ch_2843 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_17ch_2843 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _17string_next_2842 = _17string_next_2842 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _17escape_char(int _c_2870)
{
    int _i_2871 = NOVALUE;
    int _1375 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_2871 = find_from(_c_2870, _17ESCAPE_CHARS_2864, 1);

    /** 	if i = 0 then*/
    if (_i_2871 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_17ESCAPED_CHARS_2866);
    _1375 = (int)*(((s1_ptr)_2)->base + _i_2871);
    Ref(_1375);
    return _1375;
L2: 
    ;
}


int _17get_qchar()
{
    int _c_2879 = NOVALUE;
    int _1386 = NOVALUE;
    int _1385 = NOVALUE;
    int _1383 = NOVALUE;
    int _1380 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _17get_ch();

    /** 	c = ch*/
    _c_2879 = _17ch_2843;

    /** 	if ch = '\\' then*/
    if (_17ch_2843 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _17get_ch();

    /** 		c = escape_char(ch)*/
    _c_2879 = _17escape_char(_17ch_2843);
    if (!IS_ATOM_INT(_c_2879)) {
        _1 = (long)(DBL_PTR(_c_2879)->dbl);
        DeRefDS(_c_2879);
        _c_2879 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_2879 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1380 = MAKE_SEQ(_1);
    return _1380;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_17ch_2843 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1383 = MAKE_SEQ(_1);
    DeRef(_1380);
    _1380 = NOVALUE;
    return _1383;
L3: 
L2: 

    /** 	get_ch()*/
    _17get_ch();

    /** 	if ch != '\'' then*/
    if (_17ch_2843 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1385 = MAKE_SEQ(_1);
    DeRef(_1380);
    _1380 = NOVALUE;
    DeRef(_1383);
    _1383 = NOVALUE;
    return _1385;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_2879;
    _1386 = MAKE_SEQ(_1);
    DeRef(_1380);
    _1380 = NOVALUE;
    DeRef(_1383);
    _1383 = NOVALUE;
    DeRef(_1385);
    _1385 = NOVALUE;
    return _1386;
L5: 
    ;
}


int _17get_string()
{
    int _text_2898 = NOVALUE;
    int _1396 = NOVALUE;
    int _1392 = NOVALUE;
    int _1390 = NOVALUE;
    int _1389 = NOVALUE;
    int _1387 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_2898);
    _text_2898 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _1387 = (_17ch_2843 == -1);
    if (_1387 != 0) {
        goto L2; // [25] 40
    }
    _1389 = (_17ch_2843 == 10);
    if (_1389 == 0)
    {
        DeRef(_1389);
        _1389 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_1389);
        _1389 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1390 = MAKE_SEQ(_1);
    DeRefi(_text_2898);
    DeRef(_1387);
    _1387 = NOVALUE;
    return _1390;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_17ch_2843 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _17get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_2898);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_2898;
    _1392 = MAKE_SEQ(_1);
    DeRefDSi(_text_2898);
    DeRef(_1387);
    _1387 = NOVALUE;
    DeRef(_1390);
    _1390 = NOVALUE;
    return _1392;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_17ch_2843 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _17get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _17escape_char(_17ch_2843);
    _17ch_2843 = _0;
    if (!IS_ATOM_INT(_17ch_2843)) {
        _1 = (long)(DBL_PTR(_17ch_2843)->dbl);
        DeRefDS(_17ch_2843);
        _17ch_2843 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_17ch_2843 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1396 = MAKE_SEQ(_1);
    DeRefi(_text_2898);
    DeRef(_1387);
    _1387 = NOVALUE;
    DeRef(_1390);
    _1390 = NOVALUE;
    DeRef(_1392);
    _1392 = NOVALUE;
    return _1396;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_2898, _text_2898, _17ch_2843);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _17read_comment()
{
    int _1417 = NOVALUE;
    int _1416 = NOVALUE;
    int _1414 = NOVALUE;
    int _1412 = NOVALUE;
    int _1410 = NOVALUE;
    int _1409 = NOVALUE;
    int _1408 = NOVALUE;
    int _1406 = NOVALUE;
    int _1405 = NOVALUE;
    int _1404 = NOVALUE;
    int _1403 = NOVALUE;
    int _1402 = NOVALUE;
    int _1401 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _1401 = IS_ATOM(_17input_string_2841);
    if (_1401 == 0)
    {
        _1401 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _1401 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _1402 = (_17ch_2843 != 10);
    if (_1402 == 0) {
        _1403 = 0;
        goto L3; // [22] 36
    }
    _1404 = (_17ch_2843 != 13);
    _1403 = (_1404 != 0);
L3: 
    if (_1403 == 0) {
        goto L4; // [36] 59
    }
    _1406 = (_17ch_2843 != -1);
    if (_1406 == 0)
    {
        DeRef(_1406);
        _1406 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_1406);
        _1406 = NOVALUE;
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch=-1 then*/
    if (_17ch_2843 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1408 = MAKE_SEQ(_1);
    DeRef(_1402);
    _1402 = NOVALUE;
    DeRef(_1404);
    _1404 = NOVALUE;
    return _1408;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1409 = MAKE_SEQ(_1);
    DeRef(_1402);
    _1402 = NOVALUE;
    DeRef(_1404);
    _1404 = NOVALUE;
    DeRef(_1408);
    _1408 = NOVALUE;
    return _1409;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_17input_string_2841)){
            _1410 = SEQ_PTR(_17input_string_2841)->length;
    }
    else {
        _1410 = 1;
    }
    {
        int _i_2939;
        _i_2939 = _17string_next_2842;
L7: 
        if (_i_2939 > _1410){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_17input_string_2841);
        _17ch_2843 = (int)*(((s1_ptr)_2)->base + _i_2939);
        if (!IS_ATOM_INT(_17ch_2843)){
            _17ch_2843 = (long)DBL_PTR(_17ch_2843)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _1412 = (_17ch_2843 == 10);
        if (_1412 != 0) {
            goto L9; // [132] 147
        }
        _1414 = (_17ch_2843 == 13);
        if (_1414 == 0)
        {
            DeRef(_1414);
            _1414 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_1414);
            _1414 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _17string_next_2842 = _i_2939 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _1416 = MAKE_SEQ(_1);
        DeRef(_1402);
        _1402 = NOVALUE;
        DeRef(_1404);
        _1404 = NOVALUE;
        DeRef(_1408);
        _1408 = NOVALUE;
        DeRef(_1409);
        _1409 = NOVALUE;
        DeRef(_1412);
        _1412 = NOVALUE;
        return _1416;
LA: 

        /** 		end for*/
        _i_2939 = _i_2939 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1417 = MAKE_SEQ(_1);
    DeRef(_1402);
    _1402 = NOVALUE;
    DeRef(_1404);
    _1404 = NOVALUE;
    DeRef(_1408);
    _1408 = NOVALUE;
    DeRef(_1409);
    _1409 = NOVALUE;
    DeRef(_1412);
    _1412 = NOVALUE;
    DeRef(_1416);
    _1416 = NOVALUE;
    return _1417;
L6: 
    ;
}


int _17get_number()
{
    int _sign_2951 = NOVALUE;
    int _e_sign_2952 = NOVALUE;
    int _ndigits_2953 = NOVALUE;
    int _hex_digit_2954 = NOVALUE;
    int _mantissa_2955 = NOVALUE;
    int _dec_2956 = NOVALUE;
    int _e_mag_2957 = NOVALUE;
    int _1479 = NOVALUE;
    int _1477 = NOVALUE;
    int _1475 = NOVALUE;
    int _1471 = NOVALUE;
    int _1467 = NOVALUE;
    int _1465 = NOVALUE;
    int _1464 = NOVALUE;
    int _1463 = NOVALUE;
    int _1462 = NOVALUE;
    int _1461 = NOVALUE;
    int _1459 = NOVALUE;
    int _1458 = NOVALUE;
    int _1457 = NOVALUE;
    int _1454 = NOVALUE;
    int _1452 = NOVALUE;
    int _1450 = NOVALUE;
    int _1446 = NOVALUE;
    int _1445 = NOVALUE;
    int _1443 = NOVALUE;
    int _1442 = NOVALUE;
    int _1441 = NOVALUE;
    int _1438 = NOVALUE;
    int _1437 = NOVALUE;
    int _1435 = NOVALUE;
    int _1434 = NOVALUE;
    int _1433 = NOVALUE;
    int _1432 = NOVALUE;
    int _1431 = NOVALUE;
    int _1430 = NOVALUE;
    int _1427 = NOVALUE;
    int _1423 = NOVALUE;
    int _1420 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_2951 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_2955);
    _mantissa_2955 = 0;

    /** 	ndigits = 0*/
    _ndigits_2953 = 0;

    /** 	if ch = '-' then*/
    if (_17ch_2843 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_2951 = -1;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch='-' then*/
    if (_17ch_2843 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _1420 = _17read_comment();
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    return _1420;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_17ch_2843 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _17get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_17ch_2843 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _17get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _1423 = find_from(_17ch_2843, _17HEX_DIGITS_2823, 1);
    _hex_digit_2954 = _1423 - 1;
    _1423 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_2954 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_2953 = _ndigits_2953 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_2955)) {
        if (_mantissa_2955 == (short)_mantissa_2955)
        _1427 = _mantissa_2955 * 16;
        else
        _1427 = NewDouble(_mantissa_2955 * (double)16);
    }
    else {
        _1427 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * (double)16);
    }
    DeRef(_mantissa_2955);
    if (IS_ATOM_INT(_1427)) {
        _mantissa_2955 = _1427 + _hex_digit_2954;
        if ((long)((unsigned long)_mantissa_2955 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_2955 = NewDouble((double)_mantissa_2955);
    }
    else {
        _mantissa_2955 = NewDouble(DBL_PTR(_1427)->dbl + (double)_hex_digit_2954);
    }
    DeRef(_1427);
    _1427 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_2953 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_2955)) {
        if (_sign_2951 == (short)_sign_2951 && _mantissa_2955 <= INT15 && _mantissa_2955 >= -INT15)
        _1430 = _sign_2951 * _mantissa_2955;
        else
        _1430 = NewDouble(_sign_2951 * (double)_mantissa_2955);
    }
    else {
        _1430 = NewDouble((double)_sign_2951 * DBL_PTR(_mantissa_2955)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _1430;
    _1431 = MAKE_SEQ(_1);
    _1430 = NOVALUE;
    DeRef(_mantissa_2955);
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    DeRef(_1420);
    _1420 = NOVALUE;
    return _1431;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1432 = MAKE_SEQ(_1);
    DeRef(_mantissa_2955);
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    DeRef(_1420);
    _1420 = NOVALUE;
    DeRef(_1431);
    _1431 = NOVALUE;
    return _1432;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _1433 = (_17ch_2843 >= 48);
    if (_1433 == 0) {
        goto L9; // [181] 226
    }
    _1435 = (_17ch_2843 <= 57);
    if (_1435 == 0)
    {
        DeRef(_1435);
        _1435 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_1435);
        _1435 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_2953 = _ndigits_2953 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_2955)) {
        if (_mantissa_2955 == (short)_mantissa_2955)
        _1437 = _mantissa_2955 * 10;
        else
        _1437 = NewDouble(_mantissa_2955 * (double)10);
    }
    else {
        _1437 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * (double)10);
    }
    _1438 = _17ch_2843 - 48;
    if ((long)((unsigned long)_1438 +(unsigned long) HIGH_BITS) >= 0){
        _1438 = NewDouble((double)_1438);
    }
    DeRef(_mantissa_2955);
    if (IS_ATOM_INT(_1437) && IS_ATOM_INT(_1438)) {
        _mantissa_2955 = _1437 + _1438;
        if ((long)((unsigned long)_mantissa_2955 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_2955 = NewDouble((double)_mantissa_2955);
    }
    else {
        if (IS_ATOM_INT(_1437)) {
            _mantissa_2955 = NewDouble((double)_1437 + DBL_PTR(_1438)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1438)) {
                _mantissa_2955 = NewDouble(DBL_PTR(_1437)->dbl + (double)_1438);
            }
            else
            _mantissa_2955 = NewDouble(DBL_PTR(_1437)->dbl + DBL_PTR(_1438)->dbl);
        }
    }
    DeRef(_1437);
    _1437 = NOVALUE;
    DeRef(_1438);
    _1438 = NOVALUE;

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_17ch_2843 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _17get_ch();

    /** 		dec = 10*/
    DeRef(_dec_2956);
    _dec_2956 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _1441 = (_17ch_2843 >= 48);
    if (_1441 == 0) {
        goto LC; // [254] 305
    }
    _1443 = (_17ch_2843 <= 57);
    if (_1443 == 0)
    {
        DeRef(_1443);
        _1443 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_1443);
        _1443 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_2953 = _ndigits_2953 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _1445 = _17ch_2843 - 48;
    if ((long)((unsigned long)_1445 +(unsigned long) HIGH_BITS) >= 0){
        _1445 = NewDouble((double)_1445);
    }
    if (IS_ATOM_INT(_1445) && IS_ATOM_INT(_dec_2956)) {
        _1446 = (_1445 % _dec_2956) ? NewDouble((double)_1445 / _dec_2956) : (_1445 / _dec_2956);
    }
    else {
        if (IS_ATOM_INT(_1445)) {
            _1446 = NewDouble((double)_1445 / DBL_PTR(_dec_2956)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_2956)) {
                _1446 = NewDouble(DBL_PTR(_1445)->dbl / (double)_dec_2956);
            }
            else
            _1446 = NewDouble(DBL_PTR(_1445)->dbl / DBL_PTR(_dec_2956)->dbl);
        }
    }
    DeRef(_1445);
    _1445 = NOVALUE;
    _0 = _mantissa_2955;
    if (IS_ATOM_INT(_mantissa_2955) && IS_ATOM_INT(_1446)) {
        _mantissa_2955 = _mantissa_2955 + _1446;
        if ((long)((unsigned long)_mantissa_2955 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_2955 = NewDouble((double)_mantissa_2955);
    }
    else {
        if (IS_ATOM_INT(_mantissa_2955)) {
            _mantissa_2955 = NewDouble((double)_mantissa_2955 + DBL_PTR(_1446)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1446)) {
                _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl + (double)_1446);
            }
            else
            _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl + DBL_PTR(_1446)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1446);
    _1446 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_2956;
    if (IS_ATOM_INT(_dec_2956)) {
        if (_dec_2956 == (short)_dec_2956)
        _dec_2956 = _dec_2956 * 10;
        else
        _dec_2956 = NewDouble(_dec_2956 * (double)10);
    }
    else {
        _dec_2956 = NewDouble(DBL_PTR(_dec_2956)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_2953 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1450 = MAKE_SEQ(_1);
    DeRef(_mantissa_2955);
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    DeRef(_1420);
    _1420 = NOVALUE;
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1432);
    _1432 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    DeRef(_1441);
    _1441 = NOVALUE;
    return _1450;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_2955;
    if (IS_ATOM_INT(_mantissa_2955)) {
        if (_sign_2951 == (short)_sign_2951 && _mantissa_2955 <= INT15 && _mantissa_2955 >= -INT15)
        _mantissa_2955 = _sign_2951 * _mantissa_2955;
        else
        _mantissa_2955 = NewDouble(_sign_2951 * (double)_mantissa_2955);
    }
    else {
        _mantissa_2955 = NewDouble((double)_sign_2951 * DBL_PTR(_mantissa_2955)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _1452 = (_17ch_2843 == 101);
    if (_1452 != 0) {
        goto LE; // [337] 352
    }
    _1454 = (_17ch_2843 == 69);
    if (_1454 == 0)
    {
        DeRef(_1454);
        _1454 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_1454);
        _1454 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_2952 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_2957);
    _e_mag_2957 = 0;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = '-' then*/
    if (_17ch_2843 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_2952 = -1;

    /** 			get_ch()*/
    _17get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_17ch_2843 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _17get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _1457 = (_17ch_2843 >= 48);
    if (_1457 == 0) {
        goto L13; // [408] 487
    }
    _1459 = (_17ch_2843 <= 57);
    if (_1459 == 0)
    {
        DeRef(_1459);
        _1459 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_1459);
        _1459 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_2957);
    _e_mag_2957 = _17ch_2843 - 48;
    if ((long)((unsigned long)_e_mag_2957 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_2957 = NewDouble((double)_e_mag_2957);
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _1461 = (_17ch_2843 >= 48);
    if (_1461 == 0) {
        goto L15; // [445] 498
    }
    _1463 = (_17ch_2843 <= 57);
    if (_1463 == 0)
    {
        DeRef(_1463);
        _1463 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_1463);
        _1463 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_2957)) {
        if (_e_mag_2957 == (short)_e_mag_2957)
        _1464 = _e_mag_2957 * 10;
        else
        _1464 = NewDouble(_e_mag_2957 * (double)10);
    }
    else {
        _1464 = NewDouble(DBL_PTR(_e_mag_2957)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_1464)) {
        _1465 = _1464 + _17ch_2843;
        if ((long)((unsigned long)_1465 + (unsigned long)HIGH_BITS) >= 0) 
        _1465 = NewDouble((double)_1465);
    }
    else {
        _1465 = NewDouble(DBL_PTR(_1464)->dbl + (double)_17ch_2843);
    }
    DeRef(_1464);
    _1464 = NOVALUE;
    DeRef(_e_mag_2957);
    if (IS_ATOM_INT(_1465)) {
        _e_mag_2957 = _1465 - 48;
        if ((long)((unsigned long)_e_mag_2957 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_2957 = NewDouble((double)_e_mag_2957);
        }
    }
    else {
        _e_mag_2957 = NewDouble(DBL_PTR(_1465)->dbl - (double)48);
    }
    DeRef(_1465);
    _1465 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1467 = MAKE_SEQ(_1);
    DeRef(_mantissa_2955);
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    DeRef(_1420);
    _1420 = NOVALUE;
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1432);
    _1432 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    DeRef(_1441);
    _1441 = NOVALUE;
    DeRef(_1450);
    _1450 = NOVALUE;
    DeRef(_1452);
    _1452 = NOVALUE;
    DeRef(_1457);
    _1457 = NOVALUE;
    DeRef(_1461);
    _1461 = NOVALUE;
    return _1467;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_2957;
    if (IS_ATOM_INT(_e_mag_2957)) {
        if (_e_mag_2957 == (short)_e_mag_2957 && _e_sign_2952 <= INT15 && _e_sign_2952 >= -INT15)
        _e_mag_2957 = _e_mag_2957 * _e_sign_2952;
        else
        _e_mag_2957 = NewDouble(_e_mag_2957 * (double)_e_sign_2952);
    }
    else {
        _e_mag_2957 = NewDouble(DBL_PTR(_e_mag_2957)->dbl * (double)_e_sign_2952);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_2957, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _1471 = power(10, 308);
    _0 = _mantissa_2955;
    if (IS_ATOM_INT(_mantissa_2955) && IS_ATOM_INT(_1471)) {
        if (_mantissa_2955 == (short)_mantissa_2955 && _1471 <= INT15 && _1471 >= -INT15)
        _mantissa_2955 = _mantissa_2955 * _1471;
        else
        _mantissa_2955 = NewDouble(_mantissa_2955 * (double)_1471);
    }
    else {
        if (IS_ATOM_INT(_mantissa_2955)) {
            _mantissa_2955 = NewDouble((double)_mantissa_2955 * DBL_PTR(_1471)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1471)) {
                _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * (double)_1471);
            }
            else
            _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * DBL_PTR(_1471)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1471);
    _1471 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_2957, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_2957);
    _e_mag_2957 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_2957)) {
        _1475 = _e_mag_2957 - 308;
        if ((long)((unsigned long)_1475 +(unsigned long) HIGH_BITS) >= 0){
            _1475 = NewDouble((double)_1475);
        }
    }
    else {
        _1475 = NewDouble(DBL_PTR(_e_mag_2957)->dbl - (double)308);
    }
    {
        int _i_3037;
        _i_3037 = 1;
L18: 
        if (binary_op_a(GREATER, _i_3037, _1475)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_2955;
        if (IS_ATOM_INT(_mantissa_2955)) {
            if (_mantissa_2955 == (short)_mantissa_2955)
            _mantissa_2955 = _mantissa_2955 * 10;
            else
            _mantissa_2955 = NewDouble(_mantissa_2955 * (double)10);
        }
        else {
            _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_3037;
        if (IS_ATOM_INT(_i_3037)) {
            _i_3037 = _i_3037 + 1;
            if ((long)((unsigned long)_i_3037 +(unsigned long) HIGH_BITS) >= 0){
                _i_3037 = NewDouble((double)_i_3037);
            }
        }
        else {
            _i_3037 = binary_op_a(PLUS, _i_3037, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_3037);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_2957)) {
        _1477 = power(10, _e_mag_2957);
    }
    else {
        temp_d.dbl = (double)10;
        _1477 = Dpower(&temp_d, DBL_PTR(_e_mag_2957));
    }
    _0 = _mantissa_2955;
    if (IS_ATOM_INT(_mantissa_2955) && IS_ATOM_INT(_1477)) {
        if (_mantissa_2955 == (short)_mantissa_2955 && _1477 <= INT15 && _1477 >= -INT15)
        _mantissa_2955 = _mantissa_2955 * _1477;
        else
        _mantissa_2955 = NewDouble(_mantissa_2955 * (double)_1477);
    }
    else {
        if (IS_ATOM_INT(_mantissa_2955)) {
            _mantissa_2955 = NewDouble((double)_mantissa_2955 * DBL_PTR(_1477)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1477)) {
                _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * (double)_1477);
            }
            else
            _mantissa_2955 = NewDouble(DBL_PTR(_mantissa_2955)->dbl * DBL_PTR(_1477)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1477);
    _1477 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_2955);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_2955;
    _1479 = MAKE_SEQ(_1);
    DeRef(_mantissa_2955);
    DeRef(_dec_2956);
    DeRef(_e_mag_2957);
    DeRef(_1420);
    _1420 = NOVALUE;
    DeRef(_1431);
    _1431 = NOVALUE;
    DeRef(_1432);
    _1432 = NOVALUE;
    DeRef(_1433);
    _1433 = NOVALUE;
    DeRef(_1441);
    _1441 = NOVALUE;
    DeRef(_1450);
    _1450 = NOVALUE;
    DeRef(_1452);
    _1452 = NOVALUE;
    DeRef(_1457);
    _1457 = NOVALUE;
    DeRef(_1461);
    _1461 = NOVALUE;
    DeRef(_1467);
    _1467 = NOVALUE;
    DeRef(_1475);
    _1475 = NOVALUE;
    return _1479;
    ;
}


int _17Get()
{
    int _skip_blanks_1__tmp_at328_3090 = NOVALUE;
    int _skip_blanks_1__tmp_at177_3071 = NOVALUE;
    int _skip_blanks_1__tmp_at88_3062 = NOVALUE;
    int _s_3046 = NOVALUE;
    int _e_3047 = NOVALUE;
    int _e1_3048 = NOVALUE;
    int _1515 = NOVALUE;
    int _1514 = NOVALUE;
    int _1512 = NOVALUE;
    int _1510 = NOVALUE;
    int _1508 = NOVALUE;
    int _1506 = NOVALUE;
    int _1503 = NOVALUE;
    int _1501 = NOVALUE;
    int _1497 = NOVALUE;
    int _1493 = NOVALUE;
    int _1490 = NOVALUE;
    int _1489 = NOVALUE;
    int _1487 = NOVALUE;
    int _1485 = NOVALUE;
    int _1483 = NOVALUE;
    int _1482 = NOVALUE;
    int _1480 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _1480 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_1480 == 0)
    {
        _1480 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _1480 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_2843 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1482 = MAKE_SEQ(_1);
    DeRef(_s_3046);
    DeRef(_e_3047);
    return _1482;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1483 = find_from(_17ch_2843, _17START_NUMERIC_2826, 1);
    if (_1483 == 0)
    {
        _1483 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _1483 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3047;
    _e_3047 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3047);
    _1485 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1485, -2)){
        _1485 = NOVALUE;
        goto L6; // [76] 87
    }
    _1485 = NOVALUE;

    /** 				return e*/
    DeRef(_s_3046);
    DeRef(_1482);
    _1482 = NOVALUE;
    return _e_3047;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_3062 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_skip_blanks_1__tmp_at88_3062 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _1487 = (_17ch_2843 == -1);
    if (_1487 != 0) {
        goto L9; // [128] 143
    }
    _1489 = (_17ch_2843 == 125);
    if (_1489 == 0)
    {
        DeRef(_1489);
        _1489 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_1489);
        _1489 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1490 = MAKE_SEQ(_1);
    DeRef(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    return _1490;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_2843 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3046);
    _s_3046 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_3071 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_skip_blanks_1__tmp_at177_3071 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_2843 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3046);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3046;
    _1493 = MAKE_SEQ(_1);
    DeRefDS(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    return _1493;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3047;
    _e_3047 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3047);
    _e1_3048 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3048))
    _e1_3048 = (long)DBL_PTR(_e1_3048)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3048 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3047);
    _1497 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1497);
    Append(&_s_3046, _s_3046, _1497);
    _1497 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3048 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_3046);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    return _e_3047;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_17ch_2843 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3046);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3046;
    _1501 = MAKE_SEQ(_1);
    DeRefDS(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    return _1501;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_3090 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_skip_blanks_1__tmp_at328_3090 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_17ch_2843 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_3046);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3046;
    _1503 = MAKE_SEQ(_1);
    DeRefDS(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    return _1503;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_17ch_2843 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3047;
    _e_3047 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3047);
    _1506 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1506, -2)){
        _1506 = NOVALUE;
        goto L13; // [413] 327
    }
    _1506 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1508 = MAKE_SEQ(_1);
    DeRef(_s_3046);
    DeRefDS(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1503);
    _1503 = NOVALUE;
    return _1508;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_17ch_2843 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1510 = MAKE_SEQ(_1);
    DeRef(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1503);
    _1503 = NOVALUE;
    DeRef(_1508);
    _1508 = NOVALUE;
    return _1510;
L19: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_2843 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _1512 = _17get_string();
    DeRef(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1503);
    _1503 = NOVALUE;
    DeRef(_1508);
    _1508 = NOVALUE;
    DeRef(_1510);
    _1510 = NOVALUE;
    return _1512;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_2843 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _1514 = _17get_qchar();
    DeRef(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1503);
    _1503 = NOVALUE;
    DeRef(_1508);
    _1508 = NOVALUE;
    DeRef(_1510);
    _1510 = NOVALUE;
    DeRef(_1512);
    _1512 = NOVALUE;
    return _1514;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1515 = MAKE_SEQ(_1);
    DeRef(_s_3046);
    DeRef(_e_3047);
    DeRef(_1482);
    _1482 = NOVALUE;
    DeRef(_1487);
    _1487 = NOVALUE;
    DeRef(_1490);
    _1490 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1503);
    _1503 = NOVALUE;
    DeRef(_1508);
    _1508 = NOVALUE;
    DeRef(_1510);
    _1510 = NOVALUE;
    DeRef(_1512);
    _1512 = NOVALUE;
    DeRef(_1514);
    _1514 = NOVALUE;
    return _1515;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _17Get2()
{
    int _skip_blanks_1__tmp_at464_3187 = NOVALUE;
    int _skip_blanks_1__tmp_at233_3154 = NOVALUE;
    int _s_3116 = NOVALUE;
    int _e_3117 = NOVALUE;
    int _e1_3118 = NOVALUE;
    int _offset_3119 = NOVALUE;
    int _1607 = NOVALUE;
    int _1606 = NOVALUE;
    int _1605 = NOVALUE;
    int _1604 = NOVALUE;
    int _1603 = NOVALUE;
    int _1602 = NOVALUE;
    int _1601 = NOVALUE;
    int _1600 = NOVALUE;
    int _1599 = NOVALUE;
    int _1598 = NOVALUE;
    int _1597 = NOVALUE;
    int _1594 = NOVALUE;
    int _1593 = NOVALUE;
    int _1592 = NOVALUE;
    int _1591 = NOVALUE;
    int _1590 = NOVALUE;
    int _1589 = NOVALUE;
    int _1586 = NOVALUE;
    int _1585 = NOVALUE;
    int _1584 = NOVALUE;
    int _1583 = NOVALUE;
    int _1582 = NOVALUE;
    int _1580 = NOVALUE;
    int _1579 = NOVALUE;
    int _1578 = NOVALUE;
    int _1577 = NOVALUE;
    int _1576 = NOVALUE;
    int _1574 = NOVALUE;
    int _1571 = NOVALUE;
    int _1570 = NOVALUE;
    int _1569 = NOVALUE;
    int _1568 = NOVALUE;
    int _1567 = NOVALUE;
    int _1565 = NOVALUE;
    int _1564 = NOVALUE;
    int _1563 = NOVALUE;
    int _1562 = NOVALUE;
    int _1561 = NOVALUE;
    int _1559 = NOVALUE;
    int _1558 = NOVALUE;
    int _1557 = NOVALUE;
    int _1556 = NOVALUE;
    int _1555 = NOVALUE;
    int _1554 = NOVALUE;
    int _1551 = NOVALUE;
    int _1547 = NOVALUE;
    int _1546 = NOVALUE;
    int _1545 = NOVALUE;
    int _1544 = NOVALUE;
    int _1543 = NOVALUE;
    int _1540 = NOVALUE;
    int _1539 = NOVALUE;
    int _1538 = NOVALUE;
    int _1537 = NOVALUE;
    int _1536 = NOVALUE;
    int _1534 = NOVALUE;
    int _1533 = NOVALUE;
    int _1532 = NOVALUE;
    int _1531 = NOVALUE;
    int _1530 = NOVALUE;
    int _1529 = NOVALUE;
    int _1527 = NOVALUE;
    int _1525 = NOVALUE;
    int _1523 = NOVALUE;
    int _1522 = NOVALUE;
    int _1521 = NOVALUE;
    int _1520 = NOVALUE;
    int _1519 = NOVALUE;
    int _1517 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_3119 = _17string_next_2842 - 1;

    /** 	get_ch()*/
    _17get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _1517 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_1517 == 0)
    {
        _1517 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _1517 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_2843 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _1519 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1519 +(unsigned long) HIGH_BITS) >= 0){
        _1519 = NewDouble((double)_1519);
    }
    if (IS_ATOM_INT(_1519)) {
        _1520 = _1519 - _offset_3119;
        if ((long)((unsigned long)_1520 +(unsigned long) HIGH_BITS) >= 0){
            _1520 = NewDouble((double)_1520);
        }
    }
    else {
        _1520 = NewDouble(DBL_PTR(_1519)->dbl - (double)_offset_3119);
    }
    DeRef(_1519);
    _1519 = NOVALUE;
    _1521 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1521 +(unsigned long) HIGH_BITS) >= 0){
        _1521 = NewDouble((double)_1521);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1520;
    *((int *)(_2+16)) = _1521;
    _1522 = MAKE_SEQ(_1);
    _1521 = NOVALUE;
    _1520 = NOVALUE;
    DeRef(_s_3116);
    DeRef(_e_3117);
    return _1522;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _1523 = _17string_next_2842 - 2;
    if ((long)((unsigned long)_1523 +(unsigned long) HIGH_BITS) >= 0){
        _1523 = NewDouble((double)_1523);
    }
    if (IS_ATOM_INT(_1523)) {
        _17leading_whitespace_3113 = _1523 - _offset_3119;
    }
    else {
        _17leading_whitespace_3113 = NewDouble(DBL_PTR(_1523)->dbl - (double)_offset_3119);
    }
    DeRef(_1523);
    _1523 = NOVALUE;
    if (!IS_ATOM_INT(_17leading_whitespace_3113)) {
        _1 = (long)(DBL_PTR(_17leading_whitespace_3113)->dbl);
        DeRefDS(_17leading_whitespace_3113);
        _17leading_whitespace_3113 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1525 = find_from(_17ch_2843, _17START_NUMERIC_2826, 1);
    if (_1525 == 0)
    {
        _1525 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _1525 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3117;
    _e_3117 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3117);
    _1527 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1527, -2)){
        _1527 = NOVALUE;
        goto L6; // [121] 162
    }
    _1527 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1529 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1529 +(unsigned long) HIGH_BITS) >= 0){
        _1529 = NewDouble((double)_1529);
    }
    if (IS_ATOM_INT(_1529)) {
        _1530 = _1529 - _offset_3119;
        if ((long)((unsigned long)_1530 +(unsigned long) HIGH_BITS) >= 0){
            _1530 = NewDouble((double)_1530);
        }
    }
    else {
        _1530 = NewDouble(DBL_PTR(_1529)->dbl - (double)_offset_3119);
    }
    DeRef(_1529);
    _1529 = NOVALUE;
    _1531 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1530)) {
        _1532 = _1530 - _1531;
        if ((long)((unsigned long)_1532 +(unsigned long) HIGH_BITS) >= 0){
            _1532 = NewDouble((double)_1532);
        }
    }
    else {
        _1532 = NewDouble(DBL_PTR(_1530)->dbl - (double)_1531);
    }
    DeRef(_1530);
    _1530 = NOVALUE;
    _1531 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1532;
    ((int *)_2)[2] = _17leading_whitespace_3113;
    _1533 = MAKE_SEQ(_1);
    _1532 = NOVALUE;
    Concat((object_ptr)&_1534, _e_3117, _1533);
    DeRefDS(_1533);
    _1533 = NOVALUE;
    DeRef(_s_3116);
    DeRefDS(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    return _1534;
L6: 

    /** 			get_ch()*/
    _17get_ch();

    /** 			if ch=-1 then*/
    if (_17ch_2843 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1536 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1536 +(unsigned long) HIGH_BITS) >= 0){
        _1536 = NewDouble((double)_1536);
    }
    if (IS_ATOM_INT(_1536)) {
        _1537 = _1536 - _offset_3119;
        if ((long)((unsigned long)_1537 +(unsigned long) HIGH_BITS) >= 0){
            _1537 = NewDouble((double)_1537);
        }
    }
    else {
        _1537 = NewDouble(DBL_PTR(_1536)->dbl - (double)_offset_3119);
    }
    DeRef(_1536);
    _1536 = NOVALUE;
    _1538 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1537)) {
        _1539 = _1537 - _1538;
        if ((long)((unsigned long)_1539 +(unsigned long) HIGH_BITS) >= 0){
            _1539 = NewDouble((double)_1539);
        }
    }
    else {
        _1539 = NewDouble(DBL_PTR(_1537)->dbl - (double)_1538);
    }
    DeRef(_1537);
    _1537 = NOVALUE;
    _1538 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1539;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1540 = MAKE_SEQ(_1);
    _1539 = NOVALUE;
    DeRef(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    return _1540;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_2843 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3116);
    _s_3116 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_3154 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_skip_blanks_1__tmp_at233_3154 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_2843 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1543 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1543 +(unsigned long) HIGH_BITS) >= 0){
        _1543 = NewDouble((double)_1543);
    }
    if (IS_ATOM_INT(_1543)) {
        _1544 = _1543 - _offset_3119;
        if ((long)((unsigned long)_1544 +(unsigned long) HIGH_BITS) >= 0){
            _1544 = NewDouble((double)_1544);
        }
    }
    else {
        _1544 = NewDouble(DBL_PTR(_1543)->dbl - (double)_offset_3119);
    }
    DeRef(_1543);
    _1543 = NOVALUE;
    _1545 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1544)) {
        _1546 = _1544 - _1545;
        if ((long)((unsigned long)_1546 +(unsigned long) HIGH_BITS) >= 0){
            _1546 = NewDouble((double)_1546);
        }
    }
    else {
        _1546 = NewDouble(DBL_PTR(_1544)->dbl - (double)_1545);
    }
    DeRef(_1544);
    _1544 = NOVALUE;
    _1545 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3116);
    *((int *)(_2+8)) = _s_3116;
    *((int *)(_2+12)) = _1546;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1547 = MAKE_SEQ(_1);
    _1546 = NOVALUE;
    DeRefDS(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    return _1547;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3117;
    _e_3117 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3117);
    _e1_3118 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3118))
    _e1_3118 = (long)DBL_PTR(_e1_3118)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3118 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3117);
    _1551 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1551);
    Append(&_s_3116, _s_3116, _1551);
    _1551 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3118 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1554 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1554 +(unsigned long) HIGH_BITS) >= 0){
        _1554 = NewDouble((double)_1554);
    }
    if (IS_ATOM_INT(_1554)) {
        _1555 = _1554 - _offset_3119;
        if ((long)((unsigned long)_1555 +(unsigned long) HIGH_BITS) >= 0){
            _1555 = NewDouble((double)_1555);
        }
    }
    else {
        _1555 = NewDouble(DBL_PTR(_1554)->dbl - (double)_offset_3119);
    }
    DeRef(_1554);
    _1554 = NOVALUE;
    _1556 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1555)) {
        _1557 = _1555 - _1556;
        if ((long)((unsigned long)_1557 +(unsigned long) HIGH_BITS) >= 0){
            _1557 = NewDouble((double)_1557);
        }
    }
    else {
        _1557 = NewDouble(DBL_PTR(_1555)->dbl - (double)_1556);
    }
    DeRef(_1555);
    _1555 = NOVALUE;
    _1556 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1557;
    ((int *)_2)[2] = _17leading_whitespace_3113;
    _1558 = MAKE_SEQ(_1);
    _1557 = NOVALUE;
    Concat((object_ptr)&_1559, _e_3117, _1558);
    DeRefDS(_1558);
    _1558 = NOVALUE;
    DeRef(_s_3116);
    DeRefDS(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    return _1559;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_17ch_2843 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _1561 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1561 +(unsigned long) HIGH_BITS) >= 0){
        _1561 = NewDouble((double)_1561);
    }
    if (IS_ATOM_INT(_1561)) {
        _1562 = _1561 - _offset_3119;
        if ((long)((unsigned long)_1562 +(unsigned long) HIGH_BITS) >= 0){
            _1562 = NewDouble((double)_1562);
        }
    }
    else {
        _1562 = NewDouble(DBL_PTR(_1561)->dbl - (double)_offset_3119);
    }
    DeRef(_1561);
    _1561 = NOVALUE;
    _1563 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1562)) {
        _1564 = _1562 - _1563;
        if ((long)((unsigned long)_1564 +(unsigned long) HIGH_BITS) >= 0){
            _1564 = NewDouble((double)_1564);
        }
    }
    else {
        _1564 = NewDouble(DBL_PTR(_1562)->dbl - (double)_1563);
    }
    DeRef(_1562);
    _1562 = NOVALUE;
    _1563 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3116);
    *((int *)(_2+8)) = _s_3116;
    *((int *)(_2+12)) = _1564;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1565 = MAKE_SEQ(_1);
    _1564 = NOVALUE;
    DeRefDS(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    return _1565;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_3187 = find_from(_17ch_2843, _17white_space_2859, 1);
    if (_skip_blanks_1__tmp_at464_3187 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_17ch_2843 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1567 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1567 +(unsigned long) HIGH_BITS) >= 0){
        _1567 = NewDouble((double)_1567);
    }
    if (IS_ATOM_INT(_1567)) {
        _1568 = _1567 - _offset_3119;
        if ((long)((unsigned long)_1568 +(unsigned long) HIGH_BITS) >= 0){
            _1568 = NewDouble((double)_1568);
        }
    }
    else {
        _1568 = NewDouble(DBL_PTR(_1567)->dbl - (double)_offset_3119);
    }
    DeRef(_1567);
    _1567 = NOVALUE;
    _1569 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1568)) {
        _1570 = _1568 - _1569;
        if ((long)((unsigned long)_1570 +(unsigned long) HIGH_BITS) >= 0){
            _1570 = NewDouble((double)_1570);
        }
    }
    else {
        _1570 = NewDouble(DBL_PTR(_1568)->dbl - (double)_1569);
    }
    DeRef(_1568);
    _1568 = NOVALUE;
    _1569 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3116);
    *((int *)(_2+8)) = _s_3116;
    *((int *)(_2+12)) = _1570;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1571 = MAKE_SEQ(_1);
    _1570 = NOVALUE;
    DeRefDS(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    return _1571;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_17ch_2843 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3117;
    _e_3117 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3117);
    _1574 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1574, -2)){
        _1574 = NOVALUE;
        goto L10; // [574] 463
    }
    _1574 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _1576 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1576 +(unsigned long) HIGH_BITS) >= 0){
        _1576 = NewDouble((double)_1576);
    }
    if (IS_ATOM_INT(_1576)) {
        _1577 = _1576 - _offset_3119;
        if ((long)((unsigned long)_1577 +(unsigned long) HIGH_BITS) >= 0){
            _1577 = NewDouble((double)_1577);
        }
    }
    else {
        _1577 = NewDouble(DBL_PTR(_1576)->dbl - (double)_offset_3119);
    }
    DeRef(_1576);
    _1576 = NOVALUE;
    _1578 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1577)) {
        _1579 = _1577 - _1578;
        if ((long)((unsigned long)_1579 +(unsigned long) HIGH_BITS) >= 0){
            _1579 = NewDouble((double)_1579);
        }
    }
    else {
        _1579 = NewDouble(DBL_PTR(_1577)->dbl - (double)_1578);
    }
    DeRef(_1577);
    _1577 = NOVALUE;
    _1578 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1579;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1580 = MAKE_SEQ(_1);
    _1579 = NOVALUE;
    DeRef(_s_3116);
    DeRefDS(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    DeRef(_1571);
    _1571 = NOVALUE;
    return _1580;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_17ch_2843 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1582 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1582 +(unsigned long) HIGH_BITS) >= 0){
        _1582 = NewDouble((double)_1582);
    }
    if (IS_ATOM_INT(_1582)) {
        _1583 = _1582 - _offset_3119;
        if ((long)((unsigned long)_1583 +(unsigned long) HIGH_BITS) >= 0){
            _1583 = NewDouble((double)_1583);
        }
    }
    else {
        _1583 = NewDouble(DBL_PTR(_1582)->dbl - (double)_offset_3119);
    }
    DeRef(_1582);
    _1582 = NOVALUE;
    _1584 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1583)) {
        _1585 = _1583 - _1584;
        if ((long)((unsigned long)_1585 +(unsigned long) HIGH_BITS) >= 0){
            _1585 = NewDouble((double)_1585);
        }
    }
    else {
        _1585 = NewDouble(DBL_PTR(_1583)->dbl - (double)_1584);
    }
    DeRef(_1583);
    _1583 = NOVALUE;
    _1584 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1585;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1586 = MAKE_SEQ(_1);
    _1585 = NOVALUE;
    DeRef(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    DeRef(_1571);
    _1571 = NOVALUE;
    DeRef(_1580);
    _1580 = NOVALUE;
    return _1586;
L16: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_2843 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_3117;
    _e_3117 = _17get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1589 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1589 +(unsigned long) HIGH_BITS) >= 0){
        _1589 = NewDouble((double)_1589);
    }
    if (IS_ATOM_INT(_1589)) {
        _1590 = _1589 - _offset_3119;
        if ((long)((unsigned long)_1590 +(unsigned long) HIGH_BITS) >= 0){
            _1590 = NewDouble((double)_1590);
        }
    }
    else {
        _1590 = NewDouble(DBL_PTR(_1589)->dbl - (double)_offset_3119);
    }
    DeRef(_1589);
    _1589 = NOVALUE;
    _1591 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1590)) {
        _1592 = _1590 - _1591;
        if ((long)((unsigned long)_1592 +(unsigned long) HIGH_BITS) >= 0){
            _1592 = NewDouble((double)_1592);
        }
    }
    else {
        _1592 = NewDouble(DBL_PTR(_1590)->dbl - (double)_1591);
    }
    DeRef(_1590);
    _1590 = NOVALUE;
    _1591 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1592;
    ((int *)_2)[2] = _17leading_whitespace_3113;
    _1593 = MAKE_SEQ(_1);
    _1592 = NOVALUE;
    Concat((object_ptr)&_1594, _e_3117, _1593);
    DeRefDS(_1593);
    _1593 = NOVALUE;
    DeRef(_s_3116);
    DeRefDS(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    DeRef(_1571);
    _1571 = NOVALUE;
    DeRef(_1580);
    _1580 = NOVALUE;
    DeRef(_1586);
    _1586 = NOVALUE;
    return _1594;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_2843 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_3117;
    _e_3117 = _17get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1597 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0){
        _1597 = NewDouble((double)_1597);
    }
    if (IS_ATOM_INT(_1597)) {
        _1598 = _1597 - _offset_3119;
        if ((long)((unsigned long)_1598 +(unsigned long) HIGH_BITS) >= 0){
            _1598 = NewDouble((double)_1598);
        }
    }
    else {
        _1598 = NewDouble(DBL_PTR(_1597)->dbl - (double)_offset_3119);
    }
    DeRef(_1597);
    _1597 = NOVALUE;
    _1599 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1598)) {
        _1600 = _1598 - _1599;
        if ((long)((unsigned long)_1600 +(unsigned long) HIGH_BITS) >= 0){
            _1600 = NewDouble((double)_1600);
        }
    }
    else {
        _1600 = NewDouble(DBL_PTR(_1598)->dbl - (double)_1599);
    }
    DeRef(_1598);
    _1598 = NOVALUE;
    _1599 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1600;
    ((int *)_2)[2] = _17leading_whitespace_3113;
    _1601 = MAKE_SEQ(_1);
    _1600 = NOVALUE;
    Concat((object_ptr)&_1602, _e_3117, _1601);
    DeRefDS(_1601);
    _1601 = NOVALUE;
    DeRef(_s_3116);
    DeRefDS(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    DeRef(_1571);
    _1571 = NOVALUE;
    DeRef(_1580);
    _1580 = NOVALUE;
    DeRef(_1586);
    _1586 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    return _1602;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1603 = _17string_next_2842 - 1;
    if ((long)((unsigned long)_1603 +(unsigned long) HIGH_BITS) >= 0){
        _1603 = NewDouble((double)_1603);
    }
    if (IS_ATOM_INT(_1603)) {
        _1604 = _1603 - _offset_3119;
        if ((long)((unsigned long)_1604 +(unsigned long) HIGH_BITS) >= 0){
            _1604 = NewDouble((double)_1604);
        }
    }
    else {
        _1604 = NewDouble(DBL_PTR(_1603)->dbl - (double)_offset_3119);
    }
    DeRef(_1603);
    _1603 = NOVALUE;
    _1605 = (_17ch_2843 != -1);
    if (IS_ATOM_INT(_1604)) {
        _1606 = _1604 - _1605;
        if ((long)((unsigned long)_1606 +(unsigned long) HIGH_BITS) >= 0){
            _1606 = NewDouble((double)_1606);
        }
    }
    else {
        _1606 = NewDouble(DBL_PTR(_1604)->dbl - (double)_1605);
    }
    DeRef(_1604);
    _1604 = NOVALUE;
    _1605 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1606;
    *((int *)(_2+16)) = _17leading_whitespace_3113;
    _1607 = MAKE_SEQ(_1);
    _1606 = NOVALUE;
    DeRef(_s_3116);
    DeRef(_e_3117);
    DeRef(_1522);
    _1522 = NOVALUE;
    DeRef(_1534);
    _1534 = NOVALUE;
    DeRef(_1540);
    _1540 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1559);
    _1559 = NOVALUE;
    DeRef(_1565);
    _1565 = NOVALUE;
    DeRef(_1571);
    _1571 = NOVALUE;
    DeRef(_1580);
    _1580 = NOVALUE;
    DeRef(_1586);
    _1586 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1602);
    _1602 = NOVALUE;
    return _1607;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}


int _17get_value(int _target_3246, int _start_point_3247, int _answer_type_3248)
{
    int _msg_inlined_crash_at_35_3259 = NOVALUE;
    int _data_inlined_crash_at_32_3258 = NOVALUE;
    int _where_inlined_where_at_76_3265 = NOVALUE;
    int _seek_1__tmp_at90_3270 = NOVALUE;
    int _seek_inlined_seek_at_90_3269 = NOVALUE;
    int _pos_inlined_seek_at_87_3268 = NOVALUE;
    int _msg_inlined_crash_at_108_3273 = NOVALUE;
    int _1623 = NOVALUE;
    int _1620 = NOVALUE;
    int _1619 = NOVALUE;
    int _1618 = NOVALUE;
    int _1614 = NOVALUE;
    int _1613 = NOVALUE;
    int _1612 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _1612 = (_answer_type_3248 != _17GET_SHORT_ANSWER_3238);
    if (_1612 == 0) {
        goto L1; // [13] 55
    }
    _1614 = (_answer_type_3248 != _17GET_LONG_ANSWER_3241);
    if (_1614 == 0)
    {
        DeRef(_1614);
        _1614 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_1614);
        _1614 = NOVALUE;
    }

    /** 		error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_1617);
    RefDS(_1616);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1616;
    ((int *)_2)[2] = _1617;
    _1618 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_3258);
    _data_inlined_crash_at_32_3258 = _1618;
    _1618 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_3259);
    _msg_inlined_crash_at_35_3259 = EPrintf(-9999999, _1615, _data_inlined_crash_at_32_3258);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_3259);

    /** end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_3258);
    _data_inlined_crash_at_32_3258 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_3259);
    _msg_inlined_crash_at_35_3259 = NOVALUE;
L1: 

    /** 	if atom(target) then -- get()*/
    _1619 = IS_ATOM(_target_3246);
    if (_1619 == 0)
    {
        _1619 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _1619 = NOVALUE;
    }

    /** 		input_file = target*/
    Ref(_target_3246);
    _17input_file_2840 = _target_3246;
    if (!IS_ATOM_INT(_17input_file_2840)) {
        _1 = (long)(DBL_PTR(_17input_file_2840)->dbl);
        DeRefDS(_17input_file_2840);
        _17input_file_2840 = _1;
    }

    /** 		if start_point then*/
    if (_start_point_3247 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** 			if io:seek(target, io:where(target)+start_point) then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_3265);
    _where_inlined_where_at_76_3265 = machine(20, _target_3246);
    if (IS_ATOM_INT(_where_inlined_where_at_76_3265)) {
        _1620 = _where_inlined_where_at_76_3265 + _start_point_3247;
        if ((long)((unsigned long)_1620 + (unsigned long)HIGH_BITS) >= 0) 
        _1620 = NewDouble((double)_1620);
    }
    else {
        _1620 = NewDouble(DBL_PTR(_where_inlined_where_at_76_3265)->dbl + (double)_start_point_3247);
    }
    DeRef(_pos_inlined_seek_at_87_3268);
    _pos_inlined_seek_at_87_3268 = _1620;
    _1620 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_3268);
    Ref(_target_3246);
    DeRef(_seek_1__tmp_at90_3270);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _target_3246;
    ((int *)_2)[2] = _pos_inlined_seek_at_87_3268;
    _seek_1__tmp_at90_3270 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_3269 = machine(19, _seek_1__tmp_at90_3270);
    DeRef(_pos_inlined_seek_at_87_3268);
    _pos_inlined_seek_at_87_3268 = NOVALUE;
    DeRef(_seek_1__tmp_at90_3270);
    _seek_1__tmp_at90_3270 = NOVALUE;
    if (_seek_inlined_seek_at_90_3269 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** 				error:crash("Initial seek() for get() failed!")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_3273);
    _msg_inlined_crash_at_108_3273 = EPrintf(-9999999, _1621, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_3273);

    /** end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_3273);
    _msg_inlined_crash_at_108_3273 = NOVALUE;
L5: 
L4: 

    /** 		string_next = 1*/
    _17string_next_2842 = 1;

    /** 		input_string = 0*/
    DeRef(_17input_string_2841);
    _17input_string_2841 = 0;
    goto L7; // [139] 153
L3: 

    /** 		input_string = target*/
    Ref(_target_3246);
    DeRef(_17input_string_2841);
    _17input_string_2841 = _target_3246;

    /** 		string_next = start_point*/
    _17string_next_2842 = _start_point_3247;
L7: 

    /** 	if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_3248 != _17GET_SHORT_ANSWER_3238)
    goto L8; // [157] 166

    /** 		get_ch()*/
    _17get_ch();
L8: 

    /** 	return call_func(answer_type, {})*/
    _0 = (int)_00[_answer_type_3248].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_1623);
    _1623 = _1;
    DeRef(_target_3246);
    DeRef(_1612);
    _1612 = NOVALUE;
    return _1623;
    ;
}


int _17get(int _file_3280, int _offset_3281, int _answer_3282)
{
    int _1624 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_3280)) {
        _1 = (long)(DBL_PTR(_file_3280)->dbl);
        DeRefDS(_file_3280);
        _file_3280 = _1;
    }
    if (!IS_ATOM_INT(_offset_3281)) {
        _1 = (long)(DBL_PTR(_offset_3281)->dbl);
        DeRefDS(_offset_3281);
        _offset_3281 = _1;
    }
    if (!IS_ATOM_INT(_answer_3282)) {
        _1 = (long)(DBL_PTR(_answer_3282)->dbl);
        DeRefDS(_answer_3282);
        _answer_3282 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _1624 = _17get_value(_file_3280, _offset_3281, _answer_3282);
    return _1624;
    ;
}


int _17value(int _st_3286, int _start_point_3287, int _answer_3288)
{
    int _1625 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_point_3287)) {
        _1 = (long)(DBL_PTR(_start_point_3287)->dbl);
        DeRefDS(_start_point_3287);
        _start_point_3287 = _1;
    }
    if (!IS_ATOM_INT(_answer_3288)) {
        _1 = (long)(DBL_PTR(_answer_3288)->dbl);
        DeRefDS(_answer_3288);
        _answer_3288 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_3286);
    _1625 = _17get_value(_st_3286, _start_point_3287, _answer_3288);
    DeRefDS(_st_3286);
    return _1625;
    ;
}
int value() __attribute__ ((alias ("_17value")));


int _17defaulted_value(int _st_3292, int _def_3293, int _start_point_3294)
{
    int _result_3297 = NOVALUE;
    int _1630 = NOVALUE;
    int _1628 = NOVALUE;
    int _1626 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_point_3294)) {
        _1 = (long)(DBL_PTR(_start_point_3294)->dbl);
        DeRefDS(_start_point_3294);
        _start_point_3294 = _1;
    }

    /** 	if atom(st) then*/
    _1626 = IS_ATOM(_st_3292);
    if (_1626 == 0)
    {
        _1626 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _1626 = NOVALUE;
    }

    /** 		return def*/
    DeRef(_st_3292);
    DeRef(_result_3297);
    return _def_3293;
L1: 

    /** 	object result = get_value(st,start_point, GET_SHORT_ANSWER)*/
    Ref(_st_3292);
    _0 = _result_3297;
    _result_3297 = _17get_value(_st_3292, _start_point_3294, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);

    /** 	if result[1] = GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_result_3297);
    _1628 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _1628, 0)){
        _1628 = NOVALUE;
        goto L2; // [34] 49
    }
    _1628 = NOVALUE;

    /** 		return result[2]*/
    _2 = (int)SEQ_PTR(_result_3297);
    _1630 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1630);
    DeRef(_st_3292);
    DeRef(_def_3293);
    DeRef(_result_3297);
    return _1630;
L2: 

    /** 	return def*/
    DeRef(_st_3292);
    DeRef(_result_3297);
    _1630 = NOVALUE;
    return _def_3293;
    ;
}
int defaulted_value() __attribute__ ((alias ("_17defaulted_value")));



// 0x6945DD6E
