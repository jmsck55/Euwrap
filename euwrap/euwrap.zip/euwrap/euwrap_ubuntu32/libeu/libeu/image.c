// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _41graphics_point(int _p_18935)
{
    int _10527 = NOVALUE;
    int _10526 = NOVALUE;
    int _10524 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10521 = NOVALUE;
    int _10520 = NOVALUE;
    int _10518 = NOVALUE;
    int _10517 = NOVALUE;
    int _10516 = NOVALUE;
    int _10514 = NOVALUE;
    int _10513 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(p) then*/
    _10513 = IS_ATOM(_p_18935);
    if (_10513 == 0)
    {
        _10513 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _10513 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_p_18935);
    return 0;
L1: 

    /** 	if length(p) != 2 then*/
    if (IS_SEQUENCE(_p_18935)){
            _10514 = SEQ_PTR(_p_18935)->length;
    }
    else {
        _10514 = 1;
    }
    if (_10514 == 2)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_p_18935);
    return 0;
L2: 

    /** 	if not integer(p[1]) or p[1] < 0 then*/
    _2 = (int)SEQ_PTR(_p_18935);
    _10516 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10516))
    _10517 = 1;
    else if (IS_ATOM_DBL(_10516))
    _10517 = IS_ATOM_INT(DoubleToInt(_10516));
    else
    _10517 = 0;
    _10516 = NOVALUE;
    _10518 = (_10517 == 0);
    _10517 = NOVALUE;
    if (_10518 != 0) {
        goto L3; // [44] 61
    }
    _2 = (int)SEQ_PTR(_p_18935);
    _10520 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10520)) {
        _10521 = (_10520 < 0);
    }
    else {
        _10521 = binary_op(LESS, _10520, 0);
    }
    _10520 = NOVALUE;
    if (_10521 == 0) {
        DeRef(_10521);
        _10521 = NOVALUE;
        goto L4; // [57] 68
    }
    else {
        if (!IS_ATOM_INT(_10521) && DBL_PTR(_10521)->dbl == 0.0){
            DeRef(_10521);
            _10521 = NOVALUE;
            goto L4; // [57] 68
        }
        DeRef(_10521);
        _10521 = NOVALUE;
    }
    DeRef(_10521);
    _10521 = NOVALUE;
L3: 

    /** 		return 0*/
    DeRef(_p_18935);
    DeRef(_10518);
    _10518 = NOVALUE;
    return 0;
L4: 

    /** 	if not integer(p[2]) or p[2] < 0 then*/
    _2 = (int)SEQ_PTR(_p_18935);
    _10522 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10522))
    _10523 = 1;
    else if (IS_ATOM_DBL(_10522))
    _10523 = IS_ATOM_INT(DoubleToInt(_10522));
    else
    _10523 = 0;
    _10522 = NOVALUE;
    _10524 = (_10523 == 0);
    _10523 = NOVALUE;
    if (_10524 != 0) {
        goto L5; // [80] 97
    }
    _2 = (int)SEQ_PTR(_p_18935);
    _10526 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10526)) {
        _10527 = (_10526 < 0);
    }
    else {
        _10527 = binary_op(LESS, _10526, 0);
    }
    _10526 = NOVALUE;
    if (_10527 == 0) {
        DeRef(_10527);
        _10527 = NOVALUE;
        goto L6; // [93] 104
    }
    else {
        if (!IS_ATOM_INT(_10527) && DBL_PTR(_10527)->dbl == 0.0){
            DeRef(_10527);
            _10527 = NOVALUE;
            goto L6; // [93] 104
        }
        DeRef(_10527);
        _10527 = NOVALUE;
    }
    DeRef(_10527);
    _10527 = NOVALUE;
L5: 

    /** 		return 0*/
    DeRef(_p_18935);
    DeRef(_10518);
    _10518 = NOVALUE;
    DeRef(_10524);
    _10524 = NOVALUE;
    return 0;
L6: 

    /** 	return 1*/
    DeRef(_p_18935);
    DeRef(_10518);
    _10518 = NOVALUE;
    DeRef(_10524);
    _10524 = NOVALUE;
    return 1;
    ;
}
int graphics_point() __attribute__ ((alias ("_41graphics_point")));


int _41get_word()
{
    int _lower_18957 = NOVALUE;
    int _upper_18958 = NOVALUE;
    int _10532 = NOVALUE;
    int _10531 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lower = getc(fn)*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _lower_18957 = getc((FILE*)xstdin);
        }
        else
        _lower_18957 = getc(last_r_file_ptr);
    }
    else
    _lower_18957 = getc(last_r_file_ptr);

    /** 	upper = getc(fn)*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _upper_18958 = getc((FILE*)xstdin);
        }
        else
        _upper_18958 = getc(last_r_file_ptr);
    }
    else
    _upper_18958 = getc(last_r_file_ptr);

    /** 	if upper = EOF then*/
    if (_upper_18958 != -1)
    goto L1; // [17] 31

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_18932 = 3;
L1: 

    /** 	return upper * 256 + lower*/
    if (_upper_18958 == (short)_upper_18958)
    _10531 = _upper_18958 * 256;
    else
    _10531 = NewDouble(_upper_18958 * (double)256);
    if (IS_ATOM_INT(_10531)) {
        _10532 = _10531 + _lower_18957;
        if ((long)((unsigned long)_10532 + (unsigned long)HIGH_BITS) >= 0) 
        _10532 = NewDouble((double)_10532);
    }
    else {
        _10532 = NewDouble(DBL_PTR(_10531)->dbl + (double)_lower_18957);
    }
    DeRef(_10531);
    _10531 = NOVALUE;
    return _10532;
    ;
}


int _41get_c_block(int _num_bytes_18976)
{
    int _s_18977 = NOVALUE;
    int _10541 = NOVALUE;
    int _10540 = NOVALUE;
    int _10539 = NOVALUE;
    int _10538 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_bytes_18976)) {
        _1 = (long)(DBL_PTR(_num_bytes_18976)->dbl);
        DeRefDS(_num_bytes_18976);
        _num_bytes_18976 = _1;
    }

    /** 	s = repeat(0, num_bytes)*/
    DeRefi(_s_18977);
    _s_18977 = Repeat(0, _num_bytes_18976);

    /** 	for i = 1 to num_bytes do*/
    _10538 = _num_bytes_18976;
    {
        int _i_18980;
        _i_18980 = 1;
L1: 
        if (_i_18980 > _10538){
            goto L2; // [14] 39
        }

        /** 		s[i] = getc(fn)*/
        if (_41fn_18931 != last_r_file_no) {
            last_r_file_ptr = which_file(_41fn_18931, EF_READ);
            last_r_file_no = _41fn_18931;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _10539 = getc((FILE*)xstdin);
            }
            else
            _10539 = getc(last_r_file_ptr);
        }
        else
        _10539 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_18977);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_18977 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_18980);
        *(int *)_2 = _10539;
        if( _1 != _10539 ){
        }
        _10539 = NOVALUE;

        /** 	end for*/
        _i_18980 = _i_18980 + 1;
        goto L1; // [34] 21
L2: 
        ;
    }

    /** 	if s[$] = EOF then*/
    if (IS_SEQUENCE(_s_18977)){
            _10540 = SEQ_PTR(_s_18977)->length;
    }
    else {
        _10540 = 1;
    }
    _2 = (int)SEQ_PTR(_s_18977);
    _10541 = (int)*(((s1_ptr)_2)->base + _10540);
    if (_10541 != -1)
    goto L3; // [48] 62

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_18932 = 3;
L3: 

    /** 	return s*/
    _10541 = NOVALUE;
    return _s_18977;
    ;
}


int _41get_rgb(int _set_size_18990)
{
    int _red_18991 = NOVALUE;
    int _green_18992 = NOVALUE;
    int _blue_18993 = NOVALUE;
    int _10548 = NOVALUE;
    int _10547 = NOVALUE;
    int _0, _1, _2;
    

    /** 	blue = getc(fn)*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _blue_18993 = getc((FILE*)xstdin);
        }
        else
        _blue_18993 = getc(last_r_file_ptr);
    }
    else
    _blue_18993 = getc(last_r_file_ptr);

    /** 	green = getc(fn)*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _green_18992 = getc((FILE*)xstdin);
        }
        else
        _green_18992 = getc(last_r_file_ptr);
    }
    else
    _green_18992 = getc(last_r_file_ptr);

    /** 	red = getc(fn)*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _red_18991 = getc((FILE*)xstdin);
        }
        else
        _red_18991 = getc(last_r_file_ptr);
    }
    else
    _red_18991 = getc(last_r_file_ptr);

    /** 	if set_size = 4 then*/
    if (_set_size_18990 != 4)
    goto L1; // [26] 42

    /** 		if getc(fn) then*/
    if (_41fn_18931 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_18931, EF_READ);
        last_r_file_no = _41fn_18931;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _10547 = getc((FILE*)xstdin);
        }
        else
        _10547 = getc(last_r_file_ptr);
    }
    else
    _10547 = getc(last_r_file_ptr);
    if (_10547 == 0)
    {
        _10547 = NOVALUE;
        goto L2; // [37] 41
    }
    else{
        _10547 = NOVALUE;
    }
L2: 
L1: 

    /** 	return {red, green, blue}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _red_18991;
    *((int *)(_2+8)) = _green_18992;
    *((int *)(_2+12)) = _blue_18993;
    _10548 = MAKE_SEQ(_1);
    return _10548;
    ;
}


int _41get_rgb_block(int _num_dwords_19004, int _set_size_19005)
{
    int _s_19006 = NOVALUE;
    int _10554 = NOVALUE;
    int _10553 = NOVALUE;
    int _10552 = NOVALUE;
    int _10550 = NOVALUE;
    int _10549 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_dwords_19004)) {
        _1 = (long)(DBL_PTR(_num_dwords_19004)->dbl);
        DeRefDS(_num_dwords_19004);
        _num_dwords_19004 = _1;
    }

    /** 	s = {}*/
    RefDS(_5);
    DeRef(_s_19006);
    _s_19006 = _5;

    /** 	for i = 1 to num_dwords do*/
    _10549 = _num_dwords_19004;
    {
        int _i_19008;
        _i_19008 = 1;
L1: 
        if (_i_19008 > _10549){
            goto L2; // [17] 41
        }

        /** 		s = append(s, get_rgb(set_size))*/
        _10550 = _41get_rgb(_set_size_19005);
        Ref(_10550);
        Append(&_s_19006, _s_19006, _10550);
        DeRef(_10550);
        _10550 = NOVALUE;

        /** 	end for*/
        _i_19008 = _i_19008 + 1;
        goto L1; // [36] 24
L2: 
        ;
    }

    /** 	if s[$][3] = EOF then*/
    if (IS_SEQUENCE(_s_19006)){
            _10552 = SEQ_PTR(_s_19006)->length;
    }
    else {
        _10552 = 1;
    }
    _2 = (int)SEQ_PTR(_s_19006);
    _10553 = (int)*(((s1_ptr)_2)->base + _10552);
    _2 = (int)SEQ_PTR(_10553);
    _10554 = (int)*(((s1_ptr)_2)->base + 3);
    _10553 = NOVALUE;
    if (binary_op_a(NOTEQ, _10554, -1)){
        _10554 = NOVALUE;
        goto L3; // [54] 68
    }
    _10554 = NOVALUE;

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_18932 = 3;
L3: 

    /** 	return s*/
    return _s_19006;
    ;
}


int _41unpack(int _image_19028, int _BitCount_19029, int _Width_19030, int _Height_19031)
{
    int _pic_2d_19032 = NOVALUE;
    int _row_19033 = NOVALUE;
    int _bits_19034 = NOVALUE;
    int _bytes_19035 = NOVALUE;
    int _next_byte_19036 = NOVALUE;
    int _byte_19037 = NOVALUE;
    int _row_bytes_3__tmp_at17_19042 = NOVALUE;
    int _row_bytes_2__tmp_at17_19041 = NOVALUE;
    int _row_bytes_1__tmp_at17_19040 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_17_19039 = NOVALUE;
    int _10590 = NOVALUE;
    int _10587 = NOVALUE;
    int _10586 = NOVALUE;
    int _10582 = NOVALUE;
    int _10580 = NOVALUE;
    int _10578 = NOVALUE;
    int _10574 = NOVALUE;
    int _10570 = NOVALUE;
    int _10566 = NOVALUE;
    int _10562 = NOVALUE;
    int _10560 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_Width_19030)) {
        _1 = (long)(DBL_PTR(_Width_19030)->dbl);
        DeRefDS(_Width_19030);
        _Width_19030 = _1;
    }
    if (!IS_ATOM_INT(_Height_19031)) {
        _1 = (long)(DBL_PTR(_Height_19031)->dbl);
        DeRefDS(_Height_19031);
        _Height_19031 = _1;
    }

    /** 	pic_2d = {}*/
    RefDS(_5);
    DeRef(_pic_2d_19032);
    _pic_2d_19032 = _5;

    /** 	bytes = row_bytes(BitCount, Width)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at17_19040);
    if (_BitCount_19029 == (short)_BitCount_19029 && _Width_19030 <= INT15 && _Width_19030 >= -INT15)
    _row_bytes_1__tmp_at17_19040 = _BitCount_19029 * _Width_19030;
    else
    _row_bytes_1__tmp_at17_19040 = NewDouble(_BitCount_19029 * (double)_Width_19030);
    DeRef(_row_bytes_2__tmp_at17_19041);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at17_19040)) {
        _row_bytes_2__tmp_at17_19041 = _row_bytes_1__tmp_at17_19040 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at17_19041 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at17_19041 = NewDouble((double)_row_bytes_2__tmp_at17_19041);
    }
    else {
        _row_bytes_2__tmp_at17_19041 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at17_19040)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at17_19042);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at17_19041)) {
        if (32 > 0 && _row_bytes_2__tmp_at17_19041 >= 0) {
            _row_bytes_3__tmp_at17_19042 = _row_bytes_2__tmp_at17_19041 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at17_19041 / (double)32);
            if (_row_bytes_2__tmp_at17_19041 != MININT)
            _row_bytes_3__tmp_at17_19042 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at17_19042 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at17_19041, 32);
        _row_bytes_3__tmp_at17_19042 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_row_bytes_3__tmp_at17_19042)) {
        _bytes_19035 = _row_bytes_3__tmp_at17_19042 * 4;
    }
    else {
        _bytes_19035 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at17_19042)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at17_19040);
    _row_bytes_1__tmp_at17_19040 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at17_19041);
    _row_bytes_2__tmp_at17_19041 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at17_19042);
    _row_bytes_3__tmp_at17_19042 = NOVALUE;

    /** 	next_byte = 1*/
    _next_byte_19036 = 1;

    /** 	for i = 1 to Height do*/
    _10560 = _Height_19031;
    {
        int _i_19044;
        _i_19044 = 1;
L1: 
        if (_i_19044 > _10560){
            goto L2; // [49] 355
        }

        /** 		row = {}*/
        RefDS(_5);
        DeRef(_row_19033);
        _row_19033 = _5;

        /** 		if BitCount = 1 then*/
        if (_BitCount_19029 != 1)
        goto L3; // [65] 147

        /** 			for j = 1 to bytes do*/
        _10562 = _bytes_19035;
        {
            int _j_19049;
            _j_19049 = 1;
L4: 
            if (_j_19049 > _10562){
                goto L5; // [74] 144
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19028);
            _byte_19037 = (int)*(((s1_ptr)_2)->base + _next_byte_19036);
            if (!IS_ATOM_INT(_byte_19037))
            _byte_19037 = (long)DBL_PTR(_byte_19037)->dbl;

            /** 				next_byte += 1*/
            _next_byte_19036 = _next_byte_19036 + 1;

            /** 				bits = repeat(0, 8)*/
            DeRef(_bits_19034);
            _bits_19034 = Repeat(0, 8);

            /** 				for k = 8 to 1 by -1 do*/
            {
                int _k_19055;
                _k_19055 = 8;
L6: 
                if (_k_19055 < 1){
                    goto L7; // [101] 131
                }

                /** 					bits[k] = and_bits(byte, 1)*/
                {unsigned long tu;
                     tu = (unsigned long)_byte_19037 & (unsigned long)1;
                     _10566 = MAKE_UINT(tu);
                }
                _2 = (int)SEQ_PTR(_bits_19034);
                _2 = (int)(((s1_ptr)_2)->base + _k_19055);
                _1 = *(int *)_2;
                *(int *)_2 = _10566;
                if( _1 != _10566 ){
                    DeRef(_1);
                }
                _10566 = NOVALUE;

                /** 					byte = floor(byte/2)*/
                _byte_19037 = _byte_19037 >> 1;

                /** 				end for*/
                _k_19055 = _k_19055 + -1;
                goto L6; // [126] 108
L7: 
                ;
            }

            /** 				row &= bits*/
            Concat((object_ptr)&_row_19033, _row_19033, _bits_19034);

            /** 			end for*/
            _j_19049 = _j_19049 + 1;
            goto L4; // [139] 81
L5: 
            ;
        }
        goto L8; // [144] 337
L3: 

        /** 		elsif BitCount = 2 then*/
        if (_BitCount_19029 != 2)
        goto L9; // [149] 233

        /** 			for j = 1 to bytes do*/
        _10570 = _bytes_19035;
        {
            int _j_19062;
            _j_19062 = 1;
LA: 
            if (_j_19062 > _10570){
                goto LB; // [158] 230
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19028);
            _byte_19037 = (int)*(((s1_ptr)_2)->base + _next_byte_19036);
            if (!IS_ATOM_INT(_byte_19037))
            _byte_19037 = (long)DBL_PTR(_byte_19037)->dbl;

            /** 				next_byte += 1*/
            _next_byte_19036 = _next_byte_19036 + 1;

            /** 				bits = repeat(0, 4)*/
            DeRef(_bits_19034);
            _bits_19034 = Repeat(0, 4);

            /** 				for k = 4 to 1 by -1 do*/
            {
                int _k_19068;
                _k_19068 = 4;
LC: 
                if (_k_19068 < 1){
                    goto LD; // [185] 217
                }

                /** 					bits[k] = and_bits(byte, 3)*/
                {unsigned long tu;
                     tu = (unsigned long)_byte_19037 & (unsigned long)3;
                     _10574 = MAKE_UINT(tu);
                }
                _2 = (int)SEQ_PTR(_bits_19034);
                _2 = (int)(((s1_ptr)_2)->base + _k_19068);
                _1 = *(int *)_2;
                *(int *)_2 = _10574;
                if( _1 != _10574 ){
                    DeRef(_1);
                }
                _10574 = NOVALUE;

                /** 					byte = floor(byte/4)*/
                if (4 > 0 && _byte_19037 >= 0) {
                    _byte_19037 = _byte_19037 / 4;
                }
                else {
                    temp_dbl = floor((double)_byte_19037 / (double)4);
                    _byte_19037 = (long)temp_dbl;
                }

                /** 				end for*/
                _k_19068 = _k_19068 + -1;
                goto LC; // [212] 192
LD: 
                ;
            }

            /** 				row &= bits*/
            Concat((object_ptr)&_row_19033, _row_19033, _bits_19034);

            /** 			end for*/
            _j_19062 = _j_19062 + 1;
            goto LA; // [225] 165
LB: 
            ;
        }
        goto L8; // [230] 337
L9: 

        /** 		elsif BitCount = 4 then*/
        if (_BitCount_19029 != 4)
        goto LE; // [235] 293

        /** 			for j = 1 to bytes do*/
        _10578 = _bytes_19035;
        {
            int _j_19075;
            _j_19075 = 1;
LF: 
            if (_j_19075 > _10578){
                goto L10; // [244] 290
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19028);
            _byte_19037 = (int)*(((s1_ptr)_2)->base + _next_byte_19036);
            if (!IS_ATOM_INT(_byte_19037))
            _byte_19037 = (long)DBL_PTR(_byte_19037)->dbl;

            /** 				row = append(row, floor(byte/16))*/
            if (16 > 0 && _byte_19037 >= 0) {
                _10580 = _byte_19037 / 16;
            }
            else {
                temp_dbl = floor((double)_byte_19037 / (double)16);
                _10580 = (long)temp_dbl;
            }
            Append(&_row_19033, _row_19033, _10580);
            _10580 = NOVALUE;

            /** 				row = append(row, and_bits(byte, 15))*/
            {unsigned long tu;
                 tu = (unsigned long)_byte_19037 & (unsigned long)15;
                 _10582 = MAKE_UINT(tu);
            }
            Ref(_10582);
            Append(&_row_19033, _row_19033, _10582);
            DeRef(_10582);
            _10582 = NOVALUE;

            /** 				next_byte += 1*/
            _next_byte_19036 = _next_byte_19036 + 1;

            /** 			end for*/
            _j_19075 = _j_19075 + 1;
            goto LF; // [285] 251
L10: 
            ;
        }
        goto L8; // [290] 337
LE: 

        /** 		elsif BitCount = 8 then*/
        if (_BitCount_19029 != 8)
        goto L11; // [295] 323

        /** 			row = image[next_byte..next_byte+bytes-1]*/
        _10586 = _next_byte_19036 + _bytes_19035;
        if ((long)((unsigned long)_10586 + (unsigned long)HIGH_BITS) >= 0) 
        _10586 = NewDouble((double)_10586);
        if (IS_ATOM_INT(_10586)) {
            _10587 = _10586 - 1;
        }
        else {
            _10587 = NewDouble(DBL_PTR(_10586)->dbl - (double)1);
        }
        DeRef(_10586);
        _10586 = NOVALUE;
        rhs_slice_target = (object_ptr)&_row_19033;
        RHS_Slice(_image_19028, _next_byte_19036, _10587);

        /** 			next_byte += bytes*/
        _next_byte_19036 = _next_byte_19036 + _bytes_19035;
        goto L8; // [320] 337
L11: 

        /** 			error_code = BMP_UNSUPPORTED_FORMAT*/
        _41error_code_18932 = 4;

        /** 			exit*/
        goto L2; // [334] 355
L8: 

        /** 		pic_2d = prepend(pic_2d, row[1..Width])*/
        rhs_slice_target = (object_ptr)&_10590;
        RHS_Slice(_row_19033, 1, _Width_19030);
        RefDS(_10590);
        Prepend(&_pic_2d_19032, _pic_2d_19032, _10590);
        DeRefDS(_10590);
        _10590 = NOVALUE;

        /** 	end for*/
        _i_19044 = _i_19044 + 1;
        goto L1; // [350] 56
L2: 
        ;
    }

    /** 	return pic_2d*/
    DeRefDS(_image_19028);
    DeRef(_row_19033);
    DeRef(_bits_19034);
    DeRef(_10587);
    _10587 = NOVALUE;
    return _pic_2d_19032;
    ;
}


int _41read_bitmap(int _file_name_19095)
{
    int _Planes_19096 = NOVALUE;
    int _BitCount_19097 = NOVALUE;
    int _Width_19098 = NOVALUE;
    int _Height_19099 = NOVALUE;
    int _Compression_19100 = NOVALUE;
    int _OffBits_19101 = NOVALUE;
    int _SizeHeader_19102 = NOVALUE;
    int _NumColors_19103 = NOVALUE;
    int _Palette_19104 = NOVALUE;
    int _Bits_19105 = NOVALUE;
    int _two_d_bits_19106 = NOVALUE;
    int _get_dword_1__tmp_at38_19116 = NOVALUE;
    int _get_dword_inlined_get_dword_at_38_19115 = NOVALUE;
    int _upper_inlined_get_dword_at_38_19114 = NOVALUE;
    int _lower_inlined_get_dword_at_38_19113 = NOVALUE;
    int _get_dword_1__tmp_at77_19123 = NOVALUE;
    int _get_dword_inlined_get_dword_at_77_19122 = NOVALUE;
    int _upper_inlined_get_dword_at_77_19121 = NOVALUE;
    int _lower_inlined_get_dword_at_77_19120 = NOVALUE;
    int _get_dword_1__tmp_at106_19128 = NOVALUE;
    int _get_dword_inlined_get_dword_at_106_19127 = NOVALUE;
    int _upper_inlined_get_dword_at_106_19126 = NOVALUE;
    int _lower_inlined_get_dword_at_106_19125 = NOVALUE;
    int _get_dword_1__tmp_at141_19135 = NOVALUE;
    int _get_dword_inlined_get_dword_at_141_19134 = NOVALUE;
    int _upper_inlined_get_dword_at_141_19133 = NOVALUE;
    int _lower_inlined_get_dword_at_141_19132 = NOVALUE;
    int _get_dword_1__tmp_at170_19140 = NOVALUE;
    int _get_dword_inlined_get_dword_at_170_19139 = NOVALUE;
    int _upper_inlined_get_dword_at_170_19138 = NOVALUE;
    int _lower_inlined_get_dword_at_170_19137 = NOVALUE;
    int _get_dword_1__tmp_at213_19147 = NOVALUE;
    int _get_dword_inlined_get_dword_at_213_19146 = NOVALUE;
    int _upper_inlined_get_dword_at_213_19145 = NOVALUE;
    int _lower_inlined_get_dword_at_213_19144 = NOVALUE;
    int _get_dword_1__tmp_at263_19155 = NOVALUE;
    int _get_dword_inlined_get_dword_at_263_19154 = NOVALUE;
    int _upper_inlined_get_dword_at_263_19153 = NOVALUE;
    int _lower_inlined_get_dword_at_263_19152 = NOVALUE;
    int _get_dword_1__tmp_at292_19160 = NOVALUE;
    int _get_dword_inlined_get_dword_at_292_19159 = NOVALUE;
    int _upper_inlined_get_dword_at_292_19158 = NOVALUE;
    int _lower_inlined_get_dword_at_292_19157 = NOVALUE;
    int _get_dword_1__tmp_at321_19165 = NOVALUE;
    int _get_dword_inlined_get_dword_at_321_19164 = NOVALUE;
    int _upper_inlined_get_dword_at_321_19163 = NOVALUE;
    int _lower_inlined_get_dword_at_321_19162 = NOVALUE;
    int _get_dword_1__tmp_at350_19170 = NOVALUE;
    int _get_dword_inlined_get_dword_at_350_19169 = NOVALUE;
    int _upper_inlined_get_dword_at_350_19168 = NOVALUE;
    int _lower_inlined_get_dword_at_350_19167 = NOVALUE;
    int _get_dword_1__tmp_at379_19175 = NOVALUE;
    int _get_dword_inlined_get_dword_at_379_19174 = NOVALUE;
    int _upper_inlined_get_dword_at_379_19173 = NOVALUE;
    int _lower_inlined_get_dword_at_379_19172 = NOVALUE;
    int _row_bytes_3__tmp_at595_19208 = NOVALUE;
    int _row_bytes_2__tmp_at595_19207 = NOVALUE;
    int _row_bytes_1__tmp_at595_19206 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_595_19205 = NOVALUE;
    int _10625 = NOVALUE;
    int _10622 = NOVALUE;
    int _10621 = NOVALUE;
    int _10619 = NOVALUE;
    int _10618 = NOVALUE;
    int _10617 = NOVALUE;
    int _10614 = NOVALUE;
    int _10613 = NOVALUE;
    int _10606 = NOVALUE;
    int _10604 = NOVALUE;
    int _10602 = NOVALUE;
    int _10601 = NOVALUE;
    int _10596 = NOVALUE;
    int _10595 = NOVALUE;
    int _10594 = NOVALUE;
    int _0, _1, _2;
    

    /** 	error_code = 0*/
    _41error_code_18932 = 0;

    /** 	fn = open(file_name, "rb")*/
    _41fn_18931 = EOpen(_file_name_19095, _1284, 0);

    /** 	if fn = -1 then*/
    if (_41fn_18931 != -1)
    goto L1; // [19] 32

    /** 		return BMP_OPEN_FAILED*/
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRef(_Bits_19105);
    DeRef(_two_d_bits_19106);
    return 2;
L1: 

    /** 	get_word() -- Size*/
    _10594 = _41get_word();

    /** 	get_dword() -- Type*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_38_19113;
    _lower_inlined_get_dword_at_38_19113 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_38_19113)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_38_19113)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_38_19113);
        _lower_inlined_get_dword_at_38_19113 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_38_19114;
    _upper_inlined_get_dword_at_38_19114 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_38_19114)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_38_19114)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_38_19114);
        _upper_inlined_get_dword_at_38_19114 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at38_19116);
    _get_dword_1__tmp_at38_19116 = NewDouble(_upper_inlined_get_dword_at_38_19114 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_38_19115);
    if (IS_ATOM_INT(_get_dword_1__tmp_at38_19116)) {
        _get_dword_inlined_get_dword_at_38_19115 = _get_dword_1__tmp_at38_19116 + _lower_inlined_get_dword_at_38_19113;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_38_19115 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_38_19115 = NewDouble((double)_get_dword_inlined_get_dword_at_38_19115);
    }
    else {
        _get_dword_inlined_get_dword_at_38_19115 = NewDouble(DBL_PTR(_get_dword_1__tmp_at38_19116)->dbl + (double)_lower_inlined_get_dword_at_38_19113);
    }
    DeRef(_lower_inlined_get_dword_at_38_19113);
    _lower_inlined_get_dword_at_38_19113 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_38_19114);
    _upper_inlined_get_dword_at_38_19114 = NOVALUE;
    DeRef(_get_dword_1__tmp_at38_19116);
    _get_dword_1__tmp_at38_19116 = NOVALUE;

    /** 	get_word() -- X Hotspot*/
    _10595 = _41get_word();

    /** 	get_word() -- Y Hotspot*/
    _10596 = _41get_word();

    /** 	OffBits = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_77_19120;
    _lower_inlined_get_dword_at_77_19120 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_77_19120)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_77_19120)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_77_19120);
        _lower_inlined_get_dword_at_77_19120 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_77_19121;
    _upper_inlined_get_dword_at_77_19121 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_77_19121)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_77_19121)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_77_19121);
        _upper_inlined_get_dword_at_77_19121 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at77_19123);
    _get_dword_1__tmp_at77_19123 = NewDouble(_upper_inlined_get_dword_at_77_19121 * (double)65536);
    DeRef(_OffBits_19101);
    if (IS_ATOM_INT(_get_dword_1__tmp_at77_19123)) {
        _OffBits_19101 = _get_dword_1__tmp_at77_19123 + _lower_inlined_get_dword_at_77_19120;
        if ((long)((unsigned long)_OffBits_19101 + (unsigned long)HIGH_BITS) >= 0) 
        _OffBits_19101 = NewDouble((double)_OffBits_19101);
    }
    else {
        _OffBits_19101 = NewDouble(DBL_PTR(_get_dword_1__tmp_at77_19123)->dbl + (double)_lower_inlined_get_dword_at_77_19120);
    }
    DeRef(_lower_inlined_get_dword_at_77_19120);
    _lower_inlined_get_dword_at_77_19120 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_77_19121);
    _upper_inlined_get_dword_at_77_19121 = NOVALUE;
    DeRef(_get_dword_1__tmp_at77_19123);
    _get_dword_1__tmp_at77_19123 = NOVALUE;

    /** 	SizeHeader = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_106_19125;
    _lower_inlined_get_dword_at_106_19125 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_106_19125)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_106_19125)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_106_19125);
        _lower_inlined_get_dword_at_106_19125 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_106_19126;
    _upper_inlined_get_dword_at_106_19126 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_106_19126)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_106_19126)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_106_19126);
        _upper_inlined_get_dword_at_106_19126 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at106_19128);
    _get_dword_1__tmp_at106_19128 = NewDouble(_upper_inlined_get_dword_at_106_19126 * (double)65536);
    DeRef(_SizeHeader_19102);
    if (IS_ATOM_INT(_get_dword_1__tmp_at106_19128)) {
        _SizeHeader_19102 = _get_dword_1__tmp_at106_19128 + _lower_inlined_get_dword_at_106_19125;
        if ((long)((unsigned long)_SizeHeader_19102 + (unsigned long)HIGH_BITS) >= 0) 
        _SizeHeader_19102 = NewDouble((double)_SizeHeader_19102);
    }
    else {
        _SizeHeader_19102 = NewDouble(DBL_PTR(_get_dword_1__tmp_at106_19128)->dbl + (double)_lower_inlined_get_dword_at_106_19125);
    }
    DeRef(_lower_inlined_get_dword_at_106_19125);
    _lower_inlined_get_dword_at_106_19125 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_106_19126);
    _upper_inlined_get_dword_at_106_19126 = NOVALUE;
    DeRef(_get_dword_1__tmp_at106_19128);
    _get_dword_1__tmp_at106_19128 = NOVALUE;

    /** 	if SizeHeader = NEWHDRSIZE then*/
    if (binary_op_a(NOTEQ, _SizeHeader_19102, 40)){
        goto L2; // [136] 467
    }

    /** 		Width = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_141_19132;
    _lower_inlined_get_dword_at_141_19132 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_141_19132)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_141_19132)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_141_19132);
        _lower_inlined_get_dword_at_141_19132 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_141_19133;
    _upper_inlined_get_dword_at_141_19133 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_141_19133)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_141_19133)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_141_19133);
        _upper_inlined_get_dword_at_141_19133 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at141_19135);
    _get_dword_1__tmp_at141_19135 = NewDouble(_upper_inlined_get_dword_at_141_19133 * (double)65536);
    DeRef(_Width_19098);
    if (IS_ATOM_INT(_get_dword_1__tmp_at141_19135)) {
        _Width_19098 = _get_dword_1__tmp_at141_19135 + _lower_inlined_get_dword_at_141_19132;
        if ((long)((unsigned long)_Width_19098 + (unsigned long)HIGH_BITS) >= 0) 
        _Width_19098 = NewDouble((double)_Width_19098);
    }
    else {
        _Width_19098 = NewDouble(DBL_PTR(_get_dword_1__tmp_at141_19135)->dbl + (double)_lower_inlined_get_dword_at_141_19132);
    }
    DeRef(_lower_inlined_get_dword_at_141_19132);
    _lower_inlined_get_dword_at_141_19132 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_141_19133);
    _upper_inlined_get_dword_at_141_19133 = NOVALUE;
    DeRef(_get_dword_1__tmp_at141_19135);
    _get_dword_1__tmp_at141_19135 = NOVALUE;

    /** 		Height = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_170_19137;
    _lower_inlined_get_dword_at_170_19137 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_170_19137)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_170_19137)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_170_19137);
        _lower_inlined_get_dword_at_170_19137 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_170_19138;
    _upper_inlined_get_dword_at_170_19138 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_170_19138)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_170_19138)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_170_19138);
        _upper_inlined_get_dword_at_170_19138 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at170_19140);
    _get_dword_1__tmp_at170_19140 = NewDouble(_upper_inlined_get_dword_at_170_19138 * (double)65536);
    DeRef(_Height_19099);
    if (IS_ATOM_INT(_get_dword_1__tmp_at170_19140)) {
        _Height_19099 = _get_dword_1__tmp_at170_19140 + _lower_inlined_get_dword_at_170_19137;
        if ((long)((unsigned long)_Height_19099 + (unsigned long)HIGH_BITS) >= 0) 
        _Height_19099 = NewDouble((double)_Height_19099);
    }
    else {
        _Height_19099 = NewDouble(DBL_PTR(_get_dword_1__tmp_at170_19140)->dbl + (double)_lower_inlined_get_dword_at_170_19137);
    }
    DeRef(_lower_inlined_get_dword_at_170_19137);
    _lower_inlined_get_dword_at_170_19137 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_170_19138);
    _upper_inlined_get_dword_at_170_19138 = NOVALUE;
    DeRef(_get_dword_1__tmp_at170_19140);
    _get_dword_1__tmp_at170_19140 = NOVALUE;

    /** 		Planes = get_word()*/
    _Planes_19096 = _41get_word();
    if (!IS_ATOM_INT(_Planes_19096)) {
        _1 = (long)(DBL_PTR(_Planes_19096)->dbl);
        DeRefDS(_Planes_19096);
        _Planes_19096 = _1;
    }

    /** 		BitCount = get_word()*/
    _BitCount_19097 = _41get_word();
    if (!IS_ATOM_INT(_BitCount_19097)) {
        _1 = (long)(DBL_PTR(_BitCount_19097)->dbl);
        DeRefDS(_BitCount_19097);
        _BitCount_19097 = _1;
    }

    /** 		Compression = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_213_19144;
    _lower_inlined_get_dword_at_213_19144 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_213_19144)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_213_19144)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_213_19144);
        _lower_inlined_get_dword_at_213_19144 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_213_19145;
    _upper_inlined_get_dword_at_213_19145 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_213_19145)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_213_19145)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_213_19145);
        _upper_inlined_get_dword_at_213_19145 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at213_19147);
    _get_dword_1__tmp_at213_19147 = NewDouble(_upper_inlined_get_dword_at_213_19145 * (double)65536);
    DeRef(_Compression_19100);
    if (IS_ATOM_INT(_get_dword_1__tmp_at213_19147)) {
        _Compression_19100 = _get_dword_1__tmp_at213_19147 + _lower_inlined_get_dword_at_213_19144;
        if ((long)((unsigned long)_Compression_19100 + (unsigned long)HIGH_BITS) >= 0) 
        _Compression_19100 = NewDouble((double)_Compression_19100);
    }
    else {
        _Compression_19100 = NewDouble(DBL_PTR(_get_dword_1__tmp_at213_19147)->dbl + (double)_lower_inlined_get_dword_at_213_19144);
    }
    DeRef(_lower_inlined_get_dword_at_213_19144);
    _lower_inlined_get_dword_at_213_19144 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_213_19145);
    _upper_inlined_get_dword_at_213_19145 = NOVALUE;
    DeRef(_get_dword_1__tmp_at213_19147);
    _get_dword_1__tmp_at213_19147 = NOVALUE;

    /** 		if Compression != 0 then*/
    if (binary_op_a(EQUALS, _Compression_19100, 0)){
        goto L3; // [243] 262
    }

    /** 			close(fn)*/
    EClose(_41fn_18931);

    /** 			return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRef(_Bits_19105);
    DeRef(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    return 4;
L3: 

    /** 		get_dword() -- Size of Image*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_263_19152;
    _lower_inlined_get_dword_at_263_19152 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_263_19152)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_263_19152)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_263_19152);
        _lower_inlined_get_dword_at_263_19152 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_263_19153;
    _upper_inlined_get_dword_at_263_19153 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_263_19153)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_263_19153)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_263_19153);
        _upper_inlined_get_dword_at_263_19153 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at263_19155);
    _get_dword_1__tmp_at263_19155 = NewDouble(_upper_inlined_get_dword_at_263_19153 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_263_19154);
    if (IS_ATOM_INT(_get_dword_1__tmp_at263_19155)) {
        _get_dword_inlined_get_dword_at_263_19154 = _get_dword_1__tmp_at263_19155 + _lower_inlined_get_dword_at_263_19152;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_263_19154 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_263_19154 = NewDouble((double)_get_dword_inlined_get_dword_at_263_19154);
    }
    else {
        _get_dword_inlined_get_dword_at_263_19154 = NewDouble(DBL_PTR(_get_dword_1__tmp_at263_19155)->dbl + (double)_lower_inlined_get_dword_at_263_19152);
    }
    DeRef(_lower_inlined_get_dword_at_263_19152);
    _lower_inlined_get_dword_at_263_19152 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_263_19153);
    _upper_inlined_get_dword_at_263_19153 = NOVALUE;
    DeRef(_get_dword_1__tmp_at263_19155);
    _get_dword_1__tmp_at263_19155 = NOVALUE;

    /** 		get_dword() -- X Pels/Meter*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_292_19157;
    _lower_inlined_get_dword_at_292_19157 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_292_19157)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_292_19157)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_292_19157);
        _lower_inlined_get_dword_at_292_19157 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_292_19158;
    _upper_inlined_get_dword_at_292_19158 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_292_19158)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_292_19158)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_292_19158);
        _upper_inlined_get_dword_at_292_19158 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at292_19160);
    _get_dword_1__tmp_at292_19160 = NewDouble(_upper_inlined_get_dword_at_292_19158 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_292_19159);
    if (IS_ATOM_INT(_get_dword_1__tmp_at292_19160)) {
        _get_dword_inlined_get_dword_at_292_19159 = _get_dword_1__tmp_at292_19160 + _lower_inlined_get_dword_at_292_19157;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_292_19159 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_292_19159 = NewDouble((double)_get_dword_inlined_get_dword_at_292_19159);
    }
    else {
        _get_dword_inlined_get_dword_at_292_19159 = NewDouble(DBL_PTR(_get_dword_1__tmp_at292_19160)->dbl + (double)_lower_inlined_get_dword_at_292_19157);
    }
    DeRef(_lower_inlined_get_dword_at_292_19157);
    _lower_inlined_get_dword_at_292_19157 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_292_19158);
    _upper_inlined_get_dword_at_292_19158 = NOVALUE;
    DeRef(_get_dword_1__tmp_at292_19160);
    _get_dword_1__tmp_at292_19160 = NOVALUE;

    /** 		get_dword() -- Y Pels/Meter*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_321_19162;
    _lower_inlined_get_dword_at_321_19162 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_321_19162)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_321_19162)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_321_19162);
        _lower_inlined_get_dword_at_321_19162 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_321_19163;
    _upper_inlined_get_dword_at_321_19163 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_321_19163)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_321_19163)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_321_19163);
        _upper_inlined_get_dword_at_321_19163 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at321_19165);
    _get_dword_1__tmp_at321_19165 = NewDouble(_upper_inlined_get_dword_at_321_19163 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_321_19164);
    if (IS_ATOM_INT(_get_dword_1__tmp_at321_19165)) {
        _get_dword_inlined_get_dword_at_321_19164 = _get_dword_1__tmp_at321_19165 + _lower_inlined_get_dword_at_321_19162;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_321_19164 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_321_19164 = NewDouble((double)_get_dword_inlined_get_dword_at_321_19164);
    }
    else {
        _get_dword_inlined_get_dword_at_321_19164 = NewDouble(DBL_PTR(_get_dword_1__tmp_at321_19165)->dbl + (double)_lower_inlined_get_dword_at_321_19162);
    }
    DeRef(_lower_inlined_get_dword_at_321_19162);
    _lower_inlined_get_dword_at_321_19162 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_321_19163);
    _upper_inlined_get_dword_at_321_19163 = NOVALUE;
    DeRef(_get_dword_1__tmp_at321_19165);
    _get_dword_1__tmp_at321_19165 = NOVALUE;

    /** 		get_dword() -- Color Used*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_350_19167;
    _lower_inlined_get_dword_at_350_19167 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_350_19167)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_350_19167)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_350_19167);
        _lower_inlined_get_dword_at_350_19167 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_350_19168;
    _upper_inlined_get_dword_at_350_19168 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_350_19168)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_350_19168)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_350_19168);
        _upper_inlined_get_dword_at_350_19168 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at350_19170);
    _get_dword_1__tmp_at350_19170 = NewDouble(_upper_inlined_get_dword_at_350_19168 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_350_19169);
    if (IS_ATOM_INT(_get_dword_1__tmp_at350_19170)) {
        _get_dword_inlined_get_dword_at_350_19169 = _get_dword_1__tmp_at350_19170 + _lower_inlined_get_dword_at_350_19167;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_350_19169 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_350_19169 = NewDouble((double)_get_dword_inlined_get_dword_at_350_19169);
    }
    else {
        _get_dword_inlined_get_dword_at_350_19169 = NewDouble(DBL_PTR(_get_dword_1__tmp_at350_19170)->dbl + (double)_lower_inlined_get_dword_at_350_19167);
    }
    DeRef(_lower_inlined_get_dword_at_350_19167);
    _lower_inlined_get_dword_at_350_19167 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_350_19168);
    _upper_inlined_get_dword_at_350_19168 = NOVALUE;
    DeRef(_get_dword_1__tmp_at350_19170);
    _get_dword_1__tmp_at350_19170 = NOVALUE;

    /** 		get_dword() -- Color Important*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_379_19172;
    _lower_inlined_get_dword_at_379_19172 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_379_19172)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_379_19172)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_379_19172);
        _lower_inlined_get_dword_at_379_19172 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_379_19173;
    _upper_inlined_get_dword_at_379_19173 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_379_19173)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_379_19173)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_379_19173);
        _upper_inlined_get_dword_at_379_19173 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at379_19175);
    _get_dword_1__tmp_at379_19175 = NewDouble(_upper_inlined_get_dword_at_379_19173 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_379_19174);
    if (IS_ATOM_INT(_get_dword_1__tmp_at379_19175)) {
        _get_dword_inlined_get_dword_at_379_19174 = _get_dword_1__tmp_at379_19175 + _lower_inlined_get_dword_at_379_19172;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_379_19174 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_379_19174 = NewDouble((double)_get_dword_inlined_get_dword_at_379_19174);
    }
    else {
        _get_dword_inlined_get_dword_at_379_19174 = NewDouble(DBL_PTR(_get_dword_1__tmp_at379_19175)->dbl + (double)_lower_inlined_get_dword_at_379_19172);
    }
    DeRef(_lower_inlined_get_dword_at_379_19172);
    _lower_inlined_get_dword_at_379_19172 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_379_19173);
    _upper_inlined_get_dword_at_379_19173 = NOVALUE;
    DeRef(_get_dword_1__tmp_at379_19175);
    _get_dword_1__tmp_at379_19175 = NOVALUE;

    /** 		NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 4*/
    if (IS_ATOM_INT(_OffBits_19101) && IS_ATOM_INT(_SizeHeader_19102)) {
        _10601 = _OffBits_19101 - _SizeHeader_19102;
        if ((long)((unsigned long)_10601 +(unsigned long) HIGH_BITS) >= 0){
            _10601 = NewDouble((double)_10601);
        }
    }
    else {
        if (IS_ATOM_INT(_OffBits_19101)) {
            _10601 = NewDouble((double)_OffBits_19101 - DBL_PTR(_SizeHeader_19102)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader_19102)) {
                _10601 = NewDouble(DBL_PTR(_OffBits_19101)->dbl - (double)_SizeHeader_19102);
            }
            else
            _10601 = NewDouble(DBL_PTR(_OffBits_19101)->dbl - DBL_PTR(_SizeHeader_19102)->dbl);
        }
    }
    if (IS_ATOM_INT(_10601)) {
        _10602 = _10601 - 14;
        if ((long)((unsigned long)_10602 +(unsigned long) HIGH_BITS) >= 0){
            _10602 = NewDouble((double)_10602);
        }
    }
    else {
        _10602 = NewDouble(DBL_PTR(_10601)->dbl - (double)14);
    }
    DeRef(_10601);
    _10601 = NOVALUE;
    DeRef(_NumColors_19103);
    if (IS_ATOM_INT(_10602)) {
        _NumColors_19103 = (_10602 % 4) ? NewDouble((double)_10602 / 4) : (_10602 / 4);
    }
    else {
        _NumColors_19103 = NewDouble(DBL_PTR(_10602)->dbl / (double)4);
    }
    DeRef(_10602);
    _10602 = NOVALUE;

    /** 		if NumColors < 2 or NumColors > 256 then*/
    if (IS_ATOM_INT(_NumColors_19103)) {
        _10604 = (_NumColors_19103 < 2);
    }
    else {
        _10604 = (DBL_PTR(_NumColors_19103)->dbl < (double)2);
    }
    if (_10604 != 0) {
        goto L4; // [427] 440
    }
    if (IS_ATOM_INT(_NumColors_19103)) {
        _10606 = (_NumColors_19103 > 256);
    }
    else {
        _10606 = (DBL_PTR(_NumColors_19103)->dbl > (double)256);
    }
    if (_10606 == 0)
    {
        DeRef(_10606);
        _10606 = NOVALUE;
        goto L5; // [436] 455
    }
    else{
        DeRef(_10606);
        _10606 = NOVALUE;
    }
L4: 

    /** 			close(fn)*/
    EClose(_41fn_18931);

    /** 			return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRef(_Bits_19105);
    DeRef(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    DeRef(_10604);
    _10604 = NOVALUE;
    return 4;
L5: 

    /** 		Palette = get_rgb_block(NumColors, 4) */
    Ref(_NumColors_19103);
    _0 = _Palette_19104;
    _Palette_19104 = _41get_rgb_block(_NumColors_19103, 4);
    DeRef(_0);
    goto L6; // [464] 538
L2: 

    /** 	elsif SizeHeader = OLDHDRSIZE then */
    if (binary_op_a(NOTEQ, _SizeHeader_19102, 12)){
        goto L7; // [469] 523
    }

    /** 		Width = get_word()*/
    _0 = _Width_19098;
    _Width_19098 = _41get_word();
    DeRef(_0);

    /** 		Height = get_word()*/
    _0 = _Height_19099;
    _Height_19099 = _41get_word();
    DeRef(_0);

    /** 		Planes = get_word()*/
    _Planes_19096 = _41get_word();
    if (!IS_ATOM_INT(_Planes_19096)) {
        _1 = (long)(DBL_PTR(_Planes_19096)->dbl);
        DeRefDS(_Planes_19096);
        _Planes_19096 = _1;
    }

    /** 		BitCount = get_word()*/
    _BitCount_19097 = _41get_word();
    if (!IS_ATOM_INT(_BitCount_19097)) {
        _1 = (long)(DBL_PTR(_BitCount_19097)->dbl);
        DeRefDS(_BitCount_19097);
        _BitCount_19097 = _1;
    }

    /** 		NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 3*/
    if (IS_ATOM_INT(_OffBits_19101) && IS_ATOM_INT(_SizeHeader_19102)) {
        _10613 = _OffBits_19101 - _SizeHeader_19102;
        if ((long)((unsigned long)_10613 +(unsigned long) HIGH_BITS) >= 0){
            _10613 = NewDouble((double)_10613);
        }
    }
    else {
        if (IS_ATOM_INT(_OffBits_19101)) {
            _10613 = NewDouble((double)_OffBits_19101 - DBL_PTR(_SizeHeader_19102)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader_19102)) {
                _10613 = NewDouble(DBL_PTR(_OffBits_19101)->dbl - (double)_SizeHeader_19102);
            }
            else
            _10613 = NewDouble(DBL_PTR(_OffBits_19101)->dbl - DBL_PTR(_SizeHeader_19102)->dbl);
        }
    }
    if (IS_ATOM_INT(_10613)) {
        _10614 = _10613 - 14;
        if ((long)((unsigned long)_10614 +(unsigned long) HIGH_BITS) >= 0){
            _10614 = NewDouble((double)_10614);
        }
    }
    else {
        _10614 = NewDouble(DBL_PTR(_10613)->dbl - (double)14);
    }
    DeRef(_10613);
    _10613 = NOVALUE;
    DeRef(_NumColors_19103);
    if (IS_ATOM_INT(_10614)) {
        _NumColors_19103 = (_10614 % 3) ? NewDouble((double)_10614 / 3) : (_10614 / 3);
    }
    else {
        _NumColors_19103 = NewDouble(DBL_PTR(_10614)->dbl / (double)3);
    }
    DeRef(_10614);
    _10614 = NOVALUE;

    /** 		Palette = get_rgb_block(NumColors, 3) */
    Ref(_NumColors_19103);
    _0 = _Palette_19104;
    _Palette_19104 = _41get_rgb_block(_NumColors_19103, 3);
    DeRef(_0);
    goto L6; // [520] 538
L7: 

    /** 		close(fn)*/
    EClose(_41fn_18931);

    /** 		return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRef(_Bits_19105);
    DeRef(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    DeRef(_10604);
    _10604 = NOVALUE;
    return 4;
L6: 

    /** 	if Planes != 1 or Height <= 0 or Width <= 0 then*/
    _10617 = (_Planes_19096 != 1);
    if (_10617 != 0) {
        _10618 = 1;
        goto L8; // [546] 560
    }
    if (IS_ATOM_INT(_Height_19099)) {
        _10619 = (_Height_19099 <= 0);
    }
    else {
        _10619 = (DBL_PTR(_Height_19099)->dbl <= (double)0);
    }
    _10618 = (_10619 != 0);
L8: 
    if (_10618 != 0) {
        goto L9; // [560] 575
    }
    if (IS_ATOM_INT(_Width_19098)) {
        _10621 = (_Width_19098 <= 0);
    }
    else {
        _10621 = (DBL_PTR(_Width_19098)->dbl <= (double)0);
    }
    if (_10621 == 0)
    {
        DeRef(_10621);
        _10621 = NOVALUE;
        goto LA; // [571] 590
    }
    else{
        DeRef(_10621);
        _10621 = NOVALUE;
    }
L9: 

    /** 		close(fn)*/
    EClose(_41fn_18931);

    /** 		return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRef(_Bits_19105);
    DeRef(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    DeRef(_10604);
    _10604 = NOVALUE;
    DeRef(_10617);
    _10617 = NOVALUE;
    DeRef(_10619);
    _10619 = NOVALUE;
    return 4;
LA: 

    /** 	Bits = get_c_block(row_bytes(BitCount, Width) * Height)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at595_19206);
    if (IS_ATOM_INT(_Width_19098)) {
        if (_BitCount_19097 == (short)_BitCount_19097 && _Width_19098 <= INT15 && _Width_19098 >= -INT15)
        _row_bytes_1__tmp_at595_19206 = _BitCount_19097 * _Width_19098;
        else
        _row_bytes_1__tmp_at595_19206 = NewDouble(_BitCount_19097 * (double)_Width_19098);
    }
    else {
        _row_bytes_1__tmp_at595_19206 = NewDouble((double)_BitCount_19097 * DBL_PTR(_Width_19098)->dbl);
    }
    DeRef(_row_bytes_2__tmp_at595_19207);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at595_19206)) {
        _row_bytes_2__tmp_at595_19207 = _row_bytes_1__tmp_at595_19206 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at595_19207 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at595_19207 = NewDouble((double)_row_bytes_2__tmp_at595_19207);
    }
    else {
        _row_bytes_2__tmp_at595_19207 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at595_19206)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at595_19208);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at595_19207)) {
        if (32 > 0 && _row_bytes_2__tmp_at595_19207 >= 0) {
            _row_bytes_3__tmp_at595_19208 = _row_bytes_2__tmp_at595_19207 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at595_19207 / (double)32);
            if (_row_bytes_2__tmp_at595_19207 != MININT)
            _row_bytes_3__tmp_at595_19208 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at595_19208 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at595_19207, 32);
        _row_bytes_3__tmp_at595_19208 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_row_bytes_inlined_row_bytes_at_595_19205);
    if (IS_ATOM_INT(_row_bytes_3__tmp_at595_19208)) {
        if (_row_bytes_3__tmp_at595_19208 == (short)_row_bytes_3__tmp_at595_19208)
        _row_bytes_inlined_row_bytes_at_595_19205 = _row_bytes_3__tmp_at595_19208 * 4;
        else
        _row_bytes_inlined_row_bytes_at_595_19205 = NewDouble(_row_bytes_3__tmp_at595_19208 * (double)4);
    }
    else {
        _row_bytes_inlined_row_bytes_at_595_19205 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at595_19208)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at595_19206);
    _row_bytes_1__tmp_at595_19206 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at595_19207);
    _row_bytes_2__tmp_at595_19207 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at595_19208);
    _row_bytes_3__tmp_at595_19208 = NOVALUE;
    if (IS_ATOM_INT(_row_bytes_inlined_row_bytes_at_595_19205) && IS_ATOM_INT(_Height_19099)) {
        if (_row_bytes_inlined_row_bytes_at_595_19205 == (short)_row_bytes_inlined_row_bytes_at_595_19205 && _Height_19099 <= INT15 && _Height_19099 >= -INT15)
        _10622 = _row_bytes_inlined_row_bytes_at_595_19205 * _Height_19099;
        else
        _10622 = NewDouble(_row_bytes_inlined_row_bytes_at_595_19205 * (double)_Height_19099);
    }
    else {
        if (IS_ATOM_INT(_row_bytes_inlined_row_bytes_at_595_19205)) {
            _10622 = NewDouble((double)_row_bytes_inlined_row_bytes_at_595_19205 * DBL_PTR(_Height_19099)->dbl);
        }
        else {
            if (IS_ATOM_INT(_Height_19099)) {
                _10622 = NewDouble(DBL_PTR(_row_bytes_inlined_row_bytes_at_595_19205)->dbl * (double)_Height_19099);
            }
            else
            _10622 = NewDouble(DBL_PTR(_row_bytes_inlined_row_bytes_at_595_19205)->dbl * DBL_PTR(_Height_19099)->dbl);
        }
    }
    _0 = _Bits_19105;
    _Bits_19105 = _41get_c_block(_10622);
    DeRef(_0);
    _10622 = NOVALUE;

    /** 	close(fn)*/
    EClose(_41fn_18931);

    /** 	two_d_bits = unpack(Bits, BitCount, Width, Height)*/
    RefDS(_Bits_19105);
    Ref(_Width_19098);
    Ref(_Height_19099);
    _0 = _two_d_bits_19106;
    _two_d_bits_19106 = _41unpack(_Bits_19105, _BitCount_19097, _Width_19098, _Height_19099);
    DeRef(_0);

    /** 	if error_code then*/
    if (_41error_code_18932 == 0)
    {
        goto LB; // [650] 662
    }
    else{
    }

    /** 		return error_code */
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRef(_Palette_19104);
    DeRefDS(_Bits_19105);
    DeRefDS(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    DeRef(_10604);
    _10604 = NOVALUE;
    DeRef(_10617);
    _10617 = NOVALUE;
    DeRef(_10619);
    _10619 = NOVALUE;
    return _41error_code_18932;
LB: 

    /** 	return {Palette, two_d_bits}*/
    RefDS(_two_d_bits_19106);
    RefDS(_Palette_19104);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _Palette_19104;
    ((int *)_2)[2] = _two_d_bits_19106;
    _10625 = MAKE_SEQ(_1);
    DeRefDS(_file_name_19095);
    DeRef(_Width_19098);
    DeRef(_Height_19099);
    DeRef(_Compression_19100);
    DeRef(_OffBits_19101);
    DeRef(_SizeHeader_19102);
    DeRef(_NumColors_19103);
    DeRefDS(_Palette_19104);
    DeRef(_Bits_19105);
    DeRefDS(_two_d_bits_19106);
    DeRef(_10594);
    _10594 = NOVALUE;
    DeRef(_10595);
    _10595 = NOVALUE;
    DeRef(_10596);
    _10596 = NOVALUE;
    DeRef(_10604);
    _10604 = NOVALUE;
    DeRef(_10617);
    _10617 = NOVALUE;
    DeRef(_10619);
    _10619 = NOVALUE;
    return _10625;
    ;
}
int read_bitmap() __attribute__ ((alias ("_41read_bitmap")));


void _41putBmpFileHeader(int _numColors_19267)
{
    int _offBytes_19268 = NOVALUE;
    int _row_bytes_3__tmp_at102_19287 = NOVALUE;
    int _row_bytes_2__tmp_at102_19286 = NOVALUE;
    int _row_bytes_1__tmp_at102_19285 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_102_19284 = NOVALUE;
    int _10682 = NOVALUE;
    int _10681 = NOVALUE;
    int _10680 = NOVALUE;
    int _10679 = NOVALUE;
    int _10678 = NOVALUE;
    int _10677 = NOVALUE;
    int _10676 = NOVALUE;
    int _10675 = NOVALUE;
    int _10674 = NOVALUE;
    int _10673 = NOVALUE;
    int _10672 = NOVALUE;
    int _10671 = NOVALUE;
    int _10670 = NOVALUE;
    int _10669 = NOVALUE;
    int _10668 = NOVALUE;
    int _10667 = NOVALUE;
    int _10665 = NOVALUE;
    int _10664 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if numColors = 256 then*/
    if (_numColors_19267 != 256)
    goto L1; // [5] 17

    /** 		bitCount = 8            -- 8 bits per pixel*/
    _41bitCount_19237 = 8;
    goto L2; // [14] 74
L1: 

    /** 	elsif numColors = 16 then*/
    if (_numColors_19267 != 16)
    goto L3; // [19] 31

    /** 		bitCount = 4            -- 4 bits per pixel*/
    _41bitCount_19237 = 4;
    goto L2; // [28] 74
L3: 

    /** 	elsif numColors = 4 then*/
    if (_numColors_19267 != 4)
    goto L4; // [33] 45

    /** 		bitCount = 2            -- 2 bits per pixel */
    _41bitCount_19237 = 2;
    goto L2; // [42] 74
L4: 

    /** 	elsif numColors = 2 then*/
    if (_numColors_19267 != 2)
    goto L5; // [47] 59

    /** 		bitCount = 1            -- 1 bit per pixel*/
    _41bitCount_19237 = 1;
    goto L2; // [56] 74
L5: 

    /** 		error_code = BMP_INVALID_MODE*/
    _41error_code_18932 = 5;

    /** 		return*/
    return;
L2: 

    /** 	puts(fn, "BM")  -- file-type field in the file header*/
    EPuts(_41fn_18931, _10663); // DJP 

    /** 	offBytes = 4 * numColors + BMPFILEHDRSIZE + NEWHDRSIZE*/
    if (_numColors_19267 <= INT15 && _numColors_19267 >= -INT15)
    _10664 = 4 * _numColors_19267;
    else
    _10664 = NewDouble(4 * (double)_numColors_19267);
    if (IS_ATOM_INT(_10664)) {
        _10665 = _10664 + 14;
        if ((long)((unsigned long)_10665 + (unsigned long)HIGH_BITS) >= 0) 
        _10665 = NewDouble((double)_10665);
    }
    else {
        _10665 = NewDouble(DBL_PTR(_10664)->dbl + (double)14);
    }
    DeRef(_10664);
    _10664 = NOVALUE;
    if (IS_ATOM_INT(_10665)) {
        _offBytes_19268 = _10665 + 40;
    }
    else {
        _offBytes_19268 = NewDouble(DBL_PTR(_10665)->dbl + (double)40);
    }
    DeRef(_10665);
    _10665 = NOVALUE;
    if (!IS_ATOM_INT(_offBytes_19268)) {
        _1 = (long)(DBL_PTR(_offBytes_19268)->dbl);
        DeRefDS(_offBytes_19268);
        _offBytes_19268 = _1;
    }

    /** 	numRowBytes = row_bytes(bitCount, numXPixels)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at102_19285);
    if (_41numXPixels_19235 <= INT15)
    _row_bytes_1__tmp_at102_19285 = _41bitCount_19237 * _41numXPixels_19235;
    else
    _row_bytes_1__tmp_at102_19285 = NewDouble(_41bitCount_19237 * (double)_41numXPixels_19235);
    DeRef(_row_bytes_2__tmp_at102_19286);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at102_19285)) {
        _row_bytes_2__tmp_at102_19286 = _row_bytes_1__tmp_at102_19285 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at102_19286 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at102_19286 = NewDouble((double)_row_bytes_2__tmp_at102_19286);
    }
    else {
        _row_bytes_2__tmp_at102_19286 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at102_19285)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at102_19287);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at102_19286)) {
        if (32 > 0 && _row_bytes_2__tmp_at102_19286 >= 0) {
            _row_bytes_3__tmp_at102_19287 = _row_bytes_2__tmp_at102_19286 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at102_19286 / (double)32);
            if (_row_bytes_2__tmp_at102_19286 != MININT)
            _row_bytes_3__tmp_at102_19287 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at102_19287 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at102_19286, 32);
        _row_bytes_3__tmp_at102_19287 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_row_bytes_3__tmp_at102_19287)) {
        _41numRowBytes_19238 = _row_bytes_3__tmp_at102_19287 * 4;
    }
    else {
        _41numRowBytes_19238 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at102_19287)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at102_19285);
    _row_bytes_1__tmp_at102_19285 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at102_19286);
    _row_bytes_2__tmp_at102_19286 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at102_19287);
    _row_bytes_3__tmp_at102_19287 = NOVALUE;

    /** 	puts(fn, int_to_bytes(offBytes + numRowBytes * numYPixels))*/
    if (_41numRowBytes_19238 == (short)_41numRowBytes_19238 && _41numYPixels_19236 <= INT15)
    _10667 = _41numRowBytes_19238 * _41numYPixels_19236;
    else
    _10667 = NewDouble(_41numRowBytes_19238 * (double)_41numYPixels_19236);
    if (IS_ATOM_INT(_10667)) {
        _10668 = _offBytes_19268 + _10667;
        if ((long)((unsigned long)_10668 + (unsigned long)HIGH_BITS) >= 0) 
        _10668 = NewDouble((double)_10668);
    }
    else {
        _10668 = NewDouble((double)_offBytes_19268 + DBL_PTR(_10667)->dbl);
    }
    DeRef(_10667);
    _10667 = NOVALUE;
    _10669 = _8int_to_bytes(_10668);
    _10668 = NOVALUE;
    EPuts(_41fn_18931, _10669); // DJP 
    DeRef(_10669);
    _10669 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})              -- reserved fields, must be 0*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10670 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10670); // DJP 
    DeRefDS(_10670);
    _10670 = NOVALUE;

    /** 	puts(fn, int_to_bytes(offBytes))    -- offBytes is the offset to the start*/
    _10671 = _8int_to_bytes(_offBytes_19268);
    EPuts(_41fn_18931, _10671); // DJP 
    DeRef(_10671);
    _10671 = NOVALUE;

    /** 	puts(fn, int_to_bytes(NEWHDRSIZE))  -- size of the secondary header*/
    _10672 = _8int_to_bytes(40);
    EPuts(_41fn_18931, _10672); // DJP 
    DeRef(_10672);
    _10672 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numXPixels))  -- width of the bitmap in pixels*/
    _10673 = _8int_to_bytes(_41numXPixels_19235);
    EPuts(_41fn_18931, _10673); // DJP 
    DeRef(_10673);
    _10673 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numYPixels))  -- height of the bitmap in pixels*/
    _10674 = _8int_to_bytes(_41numYPixels_19236);
    EPuts(_41fn_18931, _10674); // DJP 
    DeRef(_10674);
    _10674 = NOVALUE;

    /** 	puts(fn, {1, 0})                    -- planes, must be a word of value 1*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _10675 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10675); // DJP 
    DeRefDS(_10675);
    _10675 = NOVALUE;

    /** 	puts(fn, {bitCount, 0})     -- bitCount*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _41bitCount_19237;
    ((int *)_2)[2] = 0;
    _10676 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10676); // DJP 
    DeRefDS(_10676);
    _10676 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- compression scheme*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10677 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10677); // DJP 
    DeRefDS(_10677);
    _10677 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- size image, not required*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10678 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10678); // DJP 
    DeRefDS(_10678);
    _10678 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- XPelsPerMeter, not required */
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10679 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10679); // DJP 
    DeRefDS(_10679);
    _10679 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- YPelsPerMeter, not required*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10680 = MAKE_SEQ(_1);
    EPuts(_41fn_18931, _10680); // DJP 
    DeRefDS(_10680);
    _10680 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numColors))   -- num colors used in the image*/
    _10681 = _8int_to_bytes(_numColors_19267);
    EPuts(_41fn_18931, _10681); // DJP 
    DeRef(_10681);
    _10681 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numColors))   -- num important colors in the image*/
    _10682 = _8int_to_bytes(_numColors_19267);
    EPuts(_41fn_18931, _10682); // DJP 
    DeRef(_10682);
    _10682 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _41putOneRowImage(int _x_19313, int _numPixelsPerByte_19314, int _shift_19315)
{
    int _j_19316 = NOVALUE;
    int _byte_19317 = NOVALUE;
    int _numBytesFilled_19318 = NOVALUE;
    int _10694 = NOVALUE;
    int _10690 = NOVALUE;
    int _10689 = NOVALUE;
    int _10688 = NOVALUE;
    int _10687 = NOVALUE;
    int _10683 = NOVALUE;
    int _0, _1, _2;
    

    /** 	x &= repeat(0, 7)   -- 7 zeros is safe enough*/
    _10683 = Repeat(0, 7);
    Concat((object_ptr)&_x_19313, _x_19313, _10683);
    DeRefDS(_10683);
    _10683 = NOVALUE;

    /** 	numBytesFilled = 0*/
    _numBytesFilled_19318 = 0;

    /** 	j = 1*/
    _j_19316 = 1;

    /** 	while j <= numXPixels do*/
L1: 
    if (_j_19316 > _41numXPixels_19235)
    goto L2; // [34] 108

    /** 		byte = x[j]*/
    _2 = (int)SEQ_PTR(_x_19313);
    _byte_19317 = (int)*(((s1_ptr)_2)->base + _j_19316);
    if (!IS_ATOM_INT(_byte_19317))
    _byte_19317 = (long)DBL_PTR(_byte_19317)->dbl;

    /** 		for k = 1 to numPixelsPerByte - 1 do*/
    _10687 = _numPixelsPerByte_19314 - 1;
    if ((long)((unsigned long)_10687 +(unsigned long) HIGH_BITS) >= 0){
        _10687 = NewDouble((double)_10687);
    }
    {
        int _k_19325;
        _k_19325 = 1;
L3: 
        if (binary_op_a(GREATER, _k_19325, _10687)){
            goto L4; // [50] 84
        }

        /** 			byte = byte * shift + x[j + k]*/
        if (_byte_19317 == (short)_byte_19317 && _shift_19315 <= INT15 && _shift_19315 >= -INT15)
        _10688 = _byte_19317 * _shift_19315;
        else
        _10688 = NewDouble(_byte_19317 * (double)_shift_19315);
        if (IS_ATOM_INT(_k_19325)) {
            _10689 = _j_19316 + _k_19325;
        }
        else {
            _10689 = NewDouble((double)_j_19316 + DBL_PTR(_k_19325)->dbl);
        }
        _2 = (int)SEQ_PTR(_x_19313);
        if (!IS_ATOM_INT(_10689)){
            _10690 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10689)->dbl));
        }
        else{
            _10690 = (int)*(((s1_ptr)_2)->base + _10689);
        }
        if (IS_ATOM_INT(_10688) && IS_ATOM_INT(_10690)) {
            _byte_19317 = _10688 + _10690;
        }
        else {
            _byte_19317 = binary_op(PLUS, _10688, _10690);
        }
        DeRef(_10688);
        _10688 = NOVALUE;
        _10690 = NOVALUE;
        if (!IS_ATOM_INT(_byte_19317)) {
            _1 = (long)(DBL_PTR(_byte_19317)->dbl);
            DeRefDS(_byte_19317);
            _byte_19317 = _1;
        }

        /** 		end for*/
        _0 = _k_19325;
        if (IS_ATOM_INT(_k_19325)) {
            _k_19325 = _k_19325 + 1;
            if ((long)((unsigned long)_k_19325 +(unsigned long) HIGH_BITS) >= 0){
                _k_19325 = NewDouble((double)_k_19325);
            }
        }
        else {
            _k_19325 = binary_op_a(PLUS, _k_19325, 1);
        }
        DeRef(_0);
        goto L3; // [79] 57
L4: 
        ;
        DeRef(_k_19325);
    }

    /** 		puts(fn, byte)*/
    EPuts(_41fn_18931, _byte_19317); // DJP 

    /** 		numBytesFilled += 1*/
    _numBytesFilled_19318 = _numBytesFilled_19318 + 1;

    /** 		j += numPixelsPerByte*/
    _j_19316 = _j_19316 + _numPixelsPerByte_19314;

    /** 	end while*/
    goto L1; // [105] 32
L2: 

    /** 	for m = 1 to numRowBytes - numBytesFilled do*/
    _10694 = _41numRowBytes_19238 - _numBytesFilled_19318;
    if ((long)((unsigned long)_10694 +(unsigned long) HIGH_BITS) >= 0){
        _10694 = NewDouble((double)_10694);
    }
    {
        int _m_19334;
        _m_19334 = 1;
L5: 
        if (binary_op_a(GREATER, _m_19334, _10694)){
            goto L6; // [116] 137
        }

        /** 		puts(fn, 0)*/
        EPuts(_41fn_18931, 0); // DJP 

        /** 	end for*/
        _0 = _m_19334;
        if (IS_ATOM_INT(_m_19334)) {
            _m_19334 = _m_19334 + 1;
            if ((long)((unsigned long)_m_19334 +(unsigned long) HIGH_BITS) >= 0){
                _m_19334 = NewDouble((double)_m_19334);
            }
        }
        else {
            _m_19334 = binary_op_a(PLUS, _m_19334, 1);
        }
        DeRef(_0);
        goto L5; // [132] 123
L6: 
        ;
        DeRef(_m_19334);
    }

    /** end procedure*/
    DeRefDS(_x_19313);
    DeRef(_10687);
    _10687 = NOVALUE;
    DeRef(_10694);
    _10694 = NOVALUE;
    DeRef(_10689);
    _10689 = NOVALUE;
    return;
    ;
}


void _41putColorTable(int _numColors_19338, int _pal_19339)
{
    int _10701 = NOVALUE;
    int _10700 = NOVALUE;
    int _10699 = NOVALUE;
    int _10698 = NOVALUE;
    int _10697 = NOVALUE;
    int _10696 = NOVALUE;
    int _10695 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to numColors do*/
    _10695 = _numColors_19338;
    {
        int _i_19341;
        _i_19341 = 1;
L1: 
        if (_i_19341 > _10695){
            goto L2; // [10] 76
        }

        /** 		puts(fn, pal[i][3])     -- blue first in .BMP file*/
        _2 = (int)SEQ_PTR(_pal_19339);
        _10696 = (int)*(((s1_ptr)_2)->base + _i_19341);
        _2 = (int)SEQ_PTR(_10696);
        _10697 = (int)*(((s1_ptr)_2)->base + 3);
        _10696 = NOVALUE;
        EPuts(_41fn_18931, _10697); // DJP 
        _10697 = NOVALUE;

        /** 		puts(fn, pal[i][2])     -- green second*/
        _2 = (int)SEQ_PTR(_pal_19339);
        _10698 = (int)*(((s1_ptr)_2)->base + _i_19341);
        _2 = (int)SEQ_PTR(_10698);
        _10699 = (int)*(((s1_ptr)_2)->base + 2);
        _10698 = NOVALUE;
        EPuts(_41fn_18931, _10699); // DJP 
        _10699 = NOVALUE;

        /** 		puts(fn, pal[i][1])     -- red third*/
        _2 = (int)SEQ_PTR(_pal_19339);
        _10700 = (int)*(((s1_ptr)_2)->base + _i_19341);
        _2 = (int)SEQ_PTR(_10700);
        _10701 = (int)*(((s1_ptr)_2)->base + 1);
        _10700 = NOVALUE;
        EPuts(_41fn_18931, _10701); // DJP 
        _10701 = NOVALUE;

        /** 		puts(fn, 0)             -- reserved, must be 0*/
        EPuts(_41fn_18931, 0); // DJP 

        /** 	end for*/
        _i_19341 = _i_19341 + 1;
        goto L1; // [71] 17
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_pal_19339);
    return;
    ;
}


void _41putImage1(int _image_19351)
{
    int _x_19352 = NOVALUE;
    int _numPixelsPerByte_19353 = NOVALUE;
    int _shift_19354 = NOVALUE;
    int _10706 = NOVALUE;
    int _10705 = NOVALUE;
    int _0, _1, _2;
    

    /** 	numPixelsPerByte = 8 / bitCount*/
    _numPixelsPerByte_19353 = (8 % _41bitCount_19237) ? NewDouble((double)8 / _41bitCount_19237) : (8 / _41bitCount_19237);
    if (!IS_ATOM_INT(_numPixelsPerByte_19353)) {
        _1 = (long)(DBL_PTR(_numPixelsPerByte_19353)->dbl);
        DeRefDS(_numPixelsPerByte_19353);
        _numPixelsPerByte_19353 = _1;
    }

    /** 	shift = power(2, bitCount)*/
    _shift_19354 = power(2, _41bitCount_19237);

    /** 	for i = numYPixels to 1 by -1 do*/
    {
        int _i_19358;
        _i_19358 = _41numYPixels_19236;
L1: 
        if (_i_19358 < 1){
            goto L2; // [27] 106
        }

        /** 		x = image[i]*/
        DeRef(_x_19352);
        _2 = (int)SEQ_PTR(_image_19351);
        _x_19352 = (int)*(((s1_ptr)_2)->base + _i_19358);
        Ref(_x_19352);

        /** 		if atom(x) then*/
        _10705 = IS_ATOM(_x_19352);
        if (_10705 == 0)
        {
            _10705 = NOVALUE;
            goto L3; // [45] 65
        }
        else{
            _10705 = NOVALUE;
        }

        /** 			error_code = BMP_INVALID_MODE*/
        _41error_code_18932 = 5;

        /** 			return*/
        DeRefDS(_image_19351);
        DeRef(_x_19352);
        return;
        goto L4; // [62] 92
L3: 

        /** 		elsif length(x) != numXPixels then*/
        if (IS_SEQUENCE(_x_19352)){
                _10706 = SEQ_PTR(_x_19352)->length;
        }
        else {
            _10706 = 1;
        }
        if (_10706 == _41numXPixels_19235)
        goto L5; // [72] 91

        /** 			error_code = BMP_INVALID_MODE*/
        _41error_code_18932 = 5;

        /** 			return*/
        DeRefDS(_image_19351);
        DeRef(_x_19352);
        return;
L5: 
L4: 

        /** 		putOneRowImage(x, numPixelsPerByte, shift) */
        Ref(_x_19352);
        _41putOneRowImage(_x_19352, _numPixelsPerByte_19353, _shift_19354);

        /** 	end for*/
        _i_19358 = _i_19358 + -1;
        goto L1; // [101] 34
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_image_19351);
    DeRef(_x_19352);
    return;
    ;
}


int _41save_bitmap(int _palette_n_image_19369, int _file_name_19370)
{
    int _color_19371 = NOVALUE;
    int _image_19372 = NOVALUE;
    int _numColors_19373 = NOVALUE;
    int _10713 = NOVALUE;
    int _0, _1, _2;
    

    /** 	error_code = BMP_SUCCESS*/
    _41error_code_18932 = 1;

    /** 	fn = open(file_name, "wb")*/
    _41fn_18931 = EOpen(_file_name_19370, _1325, 0);

    /** 	if fn = -1 then*/
    if (_41fn_18931 != -1)
    goto L1; // [25] 38

    /** 		return BMP_OPEN_FAILED*/
    DeRefDS(_palette_n_image_19369);
    DeRefDS(_file_name_19370);
    DeRef(_color_19371);
    DeRef(_image_19372);
    return 2;
L1: 

    /** 	color = palette_n_image[1]*/
    DeRef(_color_19371);
    _2 = (int)SEQ_PTR(_palette_n_image_19369);
    _color_19371 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_color_19371);

    /** 	image = palette_n_image[2]*/
    DeRef(_image_19372);
    _2 = (int)SEQ_PTR(_palette_n_image_19369);
    _image_19372 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_image_19372);

    /** 	numYPixels = length(image)*/
    if (IS_SEQUENCE(_image_19372)){
            _41numYPixels_19236 = SEQ_PTR(_image_19372)->length;
    }
    else {
        _41numYPixels_19236 = 1;
    }

    /** 	numXPixels = length(image[1])   -- assume the same length with each row*/
    _2 = (int)SEQ_PTR(_image_19372);
    _10713 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_10713)){
            _41numXPixels_19235 = SEQ_PTR(_10713)->length;
    }
    else {
        _41numXPixels_19235 = 1;
    }
    _10713 = NOVALUE;

    /** 	numColors = length(color)*/
    if (IS_SEQUENCE(_color_19371)){
            _numColors_19373 = SEQ_PTR(_color_19371)->length;
    }
    else {
        _numColors_19373 = 1;
    }

    /** 	putBmpFileHeader(numColors)*/
    _41putBmpFileHeader(_numColors_19373);

    /** 	if error_code = BMP_SUCCESS then*/
    if (_41error_code_18932 != 1)
    goto L2; // [84] 100

    /** 		putColorTable(numColors, color)*/
    RefDS(_color_19371);
    _41putColorTable(_numColors_19373, _color_19371);

    /** 		putImage1(image)*/
    RefDS(_image_19372);
    _41putImage1(_image_19372);
L2: 

    /** 	close(fn)*/
    EClose(_41fn_18931);

    /** 	return error_code*/
    DeRefDS(_palette_n_image_19369);
    DeRefDS(_file_name_19370);
    DeRef(_color_19371);
    DeRef(_image_19372);
    _10713 = NOVALUE;
    return _41error_code_18932;
    ;
}
int save_bitmap() __attribute__ ((alias ("_41save_bitmap")));



// 0xA23662E7
