// Euphoria To C version 3.1.1
#include <time.h>
#include "/home/owner/euphoria/include/euphoria.h"
#include <unistd.h>
#include "main-.h"

int Argc;
char **Argv;
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
int total_stack_size = 262144;

void _init()
{
    int _24 = 0;
    int _0, _1, _2;
    
    
    Argc = 0;
#ifdef CLK_TCK
    eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)CLK_TCK);
#else
    eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)sysconf(_SC_CLK_TCK));
#endif
    init_literal();
    _24 = power(2, 32);
    if (IS_ATOM_INT(_24)) {
        _2MAX_ADDR = _24 - 1;
        if ((long)((unsigned long)_2MAX_ADDR +(unsigned long) HIGH_BITS) >= 0)
            _2MAX_ADDR = NewDouble((double)_2MAX_ADDR);
    }
    else {
        _2MAX_ADDR = NewDouble(DBL_PTR(_24)->dbl - (double)1);
    }
    DeRef1(_24);
    _24 = 1048576;
    _2LOW_ADDR = 1048575;

    // mem = allocate(4)
    _0 = _2allocate(4);
    DeRef1(_2mem);
    _2mem = _0;

    // check_calls = 1
    _2check_calls = 1;

    // always_linked_list = 0
    _3always_linked_list = 0;
    RefDS(_148);
    _3SIGN_MASK = _148;
    RefDS(_138);
    _3SIGN_FLAG = _138;
    RefDS(_149);
    _3DOUBLE_FLAG = _149;
    RefDS(_150);
    _3INT_FLAG = _150;
    RefDS(_151);
    _3UINT_FLAG = _151;
    RefDS(_152);
    _3FLOAT_FLAG = _152;
    RefDS(_141);
    _3CSTRING = _141;
    RefDS(_3SIGN_FLAG);
    _3CBYTES = _3SIGN_FLAG;

    // init()
    _1init();
    ;
}
