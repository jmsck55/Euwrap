// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _6sprint(int _x_9363)
{
    int _s_9364 = NOVALUE;
    int _5164 = NOVALUE;
    int _5162 = NOVALUE;
    int _5161 = NOVALUE;
    int _5158 = NOVALUE;
    int _5157 = NOVALUE;
    int _5155 = NOVALUE;
    int _5154 = NOVALUE;
    int _5153 = NOVALUE;
    int _5152 = NOVALUE;
    int _5151 = NOVALUE;
    int _5150 = NOVALUE;
    int _5149 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _5149 = IS_ATOM(_x_9363);
    if (_5149 == 0)
    {
        _5149 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _5149 = NOVALUE;
    }

    /** 		return sprintf("%.10g", x)*/
    _5150 = EPrintf(-9999999, _4827, _x_9363);
    DeRef(_x_9363);
    DeRef(_s_9364);
    return _5150;
    goto L2; // [19] 137
L1: 

    /** 		s = "{"*/
    RefDS(_929);
    DeRef(_s_9364);
    _s_9364 = _929;

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9363)){
            _5151 = SEQ_PTR(_x_9363)->length;
    }
    else {
        _5151 = 1;
    }
    {
        int _i_9370;
        _i_9370 = 1;
L3: 
        if (_i_9370 > _5151){
            goto L4; // [34] 98
        }

        /** 			if atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_9363);
        _5152 = (int)*(((s1_ptr)_2)->base + _i_9370);
        _5153 = IS_ATOM(_5152);
        _5152 = NOVALUE;
        if (_5153 == 0)
        {
            _5153 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _5153 = NOVALUE;
        }

        /** 				s &= sprintf("%.10g", x[i])*/
        _2 = (int)SEQ_PTR(_x_9363);
        _5154 = (int)*(((s1_ptr)_2)->base + _i_9370);
        _5155 = EPrintf(-9999999, _4827, _5154);
        _5154 = NOVALUE;
        Concat((object_ptr)&_s_9364, _s_9364, _5155);
        DeRefDS(_5155);
        _5155 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** 				s &= sprint(x[i])*/
        _2 = (int)SEQ_PTR(_x_9363);
        _5157 = (int)*(((s1_ptr)_2)->base + _i_9370);
        Ref(_5157);
        _5158 = _6sprint(_5157);
        _5157 = NOVALUE;
        if (IS_SEQUENCE(_s_9364) && IS_ATOM(_5158)) {
            Ref(_5158);
            Append(&_s_9364, _s_9364, _5158);
        }
        else if (IS_ATOM(_s_9364) && IS_SEQUENCE(_5158)) {
        }
        else {
            Concat((object_ptr)&_s_9364, _s_9364, _5158);
        }
        DeRef(_5158);
        _5158 = NOVALUE;
L6: 

        /** 			s &= ','*/
        Append(&_s_9364, _s_9364, 44);

        /** 		end for*/
        _i_9370 = _i_9370 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** 		if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_9364)){
            _5161 = SEQ_PTR(_s_9364)->length;
    }
    else {
        _5161 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9364);
    _5162 = (int)*(((s1_ptr)_2)->base + _5161);
    if (binary_op_a(NOTEQ, _5162, 44)){
        _5162 = NOVALUE;
        goto L7; // [107] 123
    }
    _5162 = NOVALUE;

    /** 			s[$] = '}'*/
    if (IS_SEQUENCE(_s_9364)){
            _5164 = SEQ_PTR(_s_9364)->length;
    }
    else {
        _5164 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9364);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_9364 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _5164);
    _1 = *(int *)_2;
    *(int *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** 			s &= '}'*/
    Append(&_s_9364, _s_9364, 125);
L8: 

    /** 		return s*/
    DeRef(_x_9363);
    DeRef(_5150);
    _5150 = NOVALUE;
    return _s_9364;
L2: 
    ;
}


int  __stdcall _6trim_head(int _source_9392, int _what_9393, int _ret_index_9394)
{
    int _lpos_9395 = NOVALUE;
    int _5175 = NOVALUE;
    int _5174 = NOVALUE;
    int _5171 = NOVALUE;
    int _5170 = NOVALUE;
    int _5168 = NOVALUE;
    int _5166 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9394)) {
        _1 = (long)(DBL_PTR(_ret_index_9394)->dbl);
        DeRefDS(_ret_index_9394);
        _ret_index_9394 = _1;
    }

    /** 	if atom(what) then*/
    _5166 = IS_ATOM(_what_9393);
    if (_5166 == 0)
    {
        _5166 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5166 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9393;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9393);
    *((int *)(_2+4)) = _what_9393;
    _what_9393 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_9395 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9392)){
            _5168 = SEQ_PTR(_source_9392)->length;
    }
    else {
        _5168 = 1;
    }
    if (_lpos_9395 > _5168)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9392);
    _5170 = (int)*(((s1_ptr)_2)->base + _lpos_9395);
    _5171 = find_from(_5170, _what_9393, 1);
    _5170 = NOVALUE;
    if (_5171 != 0)
    goto L4; // [48] 56
    _5171 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_9395 = _lpos_9395 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	if ret_index then*/
    if (_ret_index_9394 == 0)
    {
        goto L5; // [69] 81
    }
    else{
    }

    /** 		return lpos*/
    DeRefDS(_source_9392);
    DeRef(_what_9393);
    return _lpos_9395;
    goto L6; // [78] 96
L5: 

    /** 		return source[lpos .. $]*/
    if (IS_SEQUENCE(_source_9392)){
            _5174 = SEQ_PTR(_source_9392)->length;
    }
    else {
        _5174 = 1;
    }
    rhs_slice_target = (object_ptr)&_5175;
    RHS_Slice(_source_9392, _lpos_9395, _5174);
    DeRefDS(_source_9392);
    DeRef(_what_9393);
    return _5175;
L6: 
    ;
}


int  __stdcall _6trim_tail(int _source_9413, int _what_9414, int _ret_index_9415)
{
    int _rpos_9416 = NOVALUE;
    int _5184 = NOVALUE;
    int _5181 = NOVALUE;
    int _5180 = NOVALUE;
    int _5176 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9415)) {
        _1 = (long)(DBL_PTR(_ret_index_9415)->dbl);
        DeRefDS(_ret_index_9415);
        _ret_index_9415 = _1;
    }

    /** 	if atom(what) then*/
    _5176 = IS_ATOM(_what_9414);
    if (_5176 == 0)
    {
        _5176 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5176 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9414;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9414);
    *((int *)(_2+4)) = _what_9414;
    _what_9414 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_9413)){
            _rpos_9416 = SEQ_PTR(_source_9413)->length;
    }
    else {
        _rpos_9416 = 1;
    }

    /** 	while rpos > 0 do*/
L2: 
    if (_rpos_9416 <= 0)
    goto L3; // [30] 64

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9413);
    _5180 = (int)*(((s1_ptr)_2)->base + _rpos_9416);
    _5181 = find_from(_5180, _what_9414, 1);
    _5180 = NOVALUE;
    if (_5181 != 0)
    goto L4; // [45] 53
    _5181 = NOVALUE;

    /** 			exit*/
    goto L3; // [50] 64
L4: 

    /** 		rpos -= 1*/
    _rpos_9416 = _rpos_9416 - 1;

    /** 	end while*/
    goto L2; // [61] 30
L3: 

    /** 	if ret_index then*/
    if (_ret_index_9415 == 0)
    {
        goto L5; // [66] 78
    }
    else{
    }

    /** 		return rpos*/
    DeRefDS(_source_9413);
    DeRef(_what_9414);
    return _rpos_9416;
    goto L6; // [75] 90
L5: 

    /** 		return source[1..rpos]*/
    rhs_slice_target = (object_ptr)&_5184;
    RHS_Slice(_source_9413, 1, _rpos_9416);
    DeRefDS(_source_9413);
    DeRef(_what_9414);
    return _5184;
L6: 
    ;
}


int  __stdcall _6trim(int _source_9433, int _what_9434, int _ret_index_9435)
{
    int _rpos_9436 = NOVALUE;
    int _lpos_9437 = NOVALUE;
    int _5205 = NOVALUE;
    int _5203 = NOVALUE;
    int _5201 = NOVALUE;
    int _5199 = NOVALUE;
    int _5196 = NOVALUE;
    int _5195 = NOVALUE;
    int _5190 = NOVALUE;
    int _5189 = NOVALUE;
    int _5187 = NOVALUE;
    int _5185 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_index_9435)) {
        _1 = (long)(DBL_PTR(_ret_index_9435)->dbl);
        DeRefDS(_ret_index_9435);
        _ret_index_9435 = _1;
    }

    /** 	if atom(what) then*/
    _5185 = IS_ATOM(_what_9434);
    if (_5185 == 0)
    {
        _5185 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5185 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9434;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_what_9434);
    *((int *)(_2+4)) = _what_9434;
    _what_9434 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_9437 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9433)){
            _5187 = SEQ_PTR(_source_9433)->length;
    }
    else {
        _5187 = 1;
    }
    if (_lpos_9437 > _5187)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9433);
    _5189 = (int)*(((s1_ptr)_2)->base + _lpos_9437);
    _5190 = find_from(_5189, _what_9434, 1);
    _5189 = NOVALUE;
    if (_5190 != 0)
    goto L4; // [48] 56
    _5190 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_9437 = _lpos_9437 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_9433)){
            _rpos_9436 = SEQ_PTR(_source_9433)->length;
    }
    else {
        _rpos_9436 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_9436 <= _lpos_9437)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9433);
    _5195 = (int)*(((s1_ptr)_2)->base + _rpos_9436);
    _5196 = find_from(_5195, _what_9434, 1);
    _5195 = NOVALUE;
    if (_5196 != 0)
    goto L7; // [92] 100
    _5196 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_9436 = _rpos_9436 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_9435 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_9437;
    ((int *)_2)[2] = _rpos_9436;
    _5199 = MAKE_SEQ(_1);
    DeRefDS(_source_9433);
    DeRef(_what_9434);
    return _5199;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_9437 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_9433)){
            _5201 = SEQ_PTR(_source_9433)->length;
    }
    else {
        _5201 = 1;
    }
    if (_rpos_9436 != _5201)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_9434);
    DeRef(_5199);
    _5199 = NOVALUE;
    return _source_9433;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_9433)){
            _5203 = SEQ_PTR(_source_9433)->length;
    }
    else {
        _5203 = 1;
    }
    if (_lpos_9437 <= _5203)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_9433);
    DeRef(_what_9434);
    DeRef(_5199);
    _5199 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_5205;
    RHS_Slice(_source_9433, _lpos_9437, _rpos_9436);
    DeRefDS(_source_9433);
    DeRef(_what_9434);
    DeRef(_5199);
    _5199 = NOVALUE;
    return _5205;
L9: 
    ;
}


int _6load_code_page(int _cpname_9475)
{
    int _cpdata_9476 = NOVALUE;
    int _pos_9477 = NOVALUE;
    int _kv_9478 = NOVALUE;
    int _cp_source_9479 = NOVALUE;
    int _cp_db_9480 = NOVALUE;
    int _fh_9552 = NOVALUE;
    int _idx_9556 = NOVALUE;
    int _vers_9557 = NOVALUE;
    int _seek_1__tmp_at464_9571 = NOVALUE;
    int _seek_inlined_seek_at_464_9570 = NOVALUE;
    int _seek_1__tmp_at514_9582 = NOVALUE;
    int _seek_inlined_seek_at_514_9581 = NOVALUE;
    int _pos_inlined_seek_at_511_9580 = NOVALUE;
    int _5279 = NOVALUE;
    int _5278 = NOVALUE;
    int _5275 = NOVALUE;
    int _5270 = NOVALUE;
    int _5269 = NOVALUE;
    int _5268 = NOVALUE;
    int _5266 = NOVALUE;
    int _5259 = NOVALUE;
    int _5258 = NOVALUE;
    int _5257 = NOVALUE;
    int _5255 = NOVALUE;
    int _5254 = NOVALUE;
    int _5253 = NOVALUE;
    int _5251 = NOVALUE;
    int _5249 = NOVALUE;
    int _5248 = NOVALUE;
    int _5246 = NOVALUE;
    int _5245 = NOVALUE;
    int _5243 = NOVALUE;
    int _5242 = NOVALUE;
    int _5241 = NOVALUE;
    int _5240 = NOVALUE;
    int _5237 = NOVALUE;
    int _5235 = NOVALUE;
    int _5233 = NOVALUE;
    int _5232 = NOVALUE;
    int _5230 = NOVALUE;
    int _5229 = NOVALUE;
    int _5228 = NOVALUE;
    int _5226 = NOVALUE;
    int _5225 = NOVALUE;
    int _5224 = NOVALUE;
    int _5221 = NOVALUE;
    int _5220 = NOVALUE;
    int _5219 = NOVALUE;
    int _5218 = NOVALUE;
    int _5216 = NOVALUE;
    int _5215 = NOVALUE;
    int _5212 = NOVALUE;
    int _5211 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cp_source = filesys:defaultext(cpname, ".ecp")*/
    RefDS(_cpname_9475);
    RefDS(_5207);
    _0 = _cp_source_9479;
    _cp_source_9479 = _11defaultext(_cpname_9475, _5207);
    DeRef(_0);

    /** 	cp_source = filesys:locate_file(cp_source)*/
    RefDS(_cp_source_9479);
    RefDS(_5);
    RefDS(_5);
    _0 = _cp_source_9479;
    _cp_source_9479 = _11locate_file(_cp_source_9479, _5, _5);
    DeRefDS(_0);

    /** 	cpdata = io:read_lines(cp_source)*/
    RefDS(_cp_source_9479);
    _0 = _cpdata_9476;
    _cpdata_9476 = _18read_lines(_cp_source_9479);
    DeRef(_0);

    /** 	if sequence(cpdata) then*/
    _5211 = IS_SEQUENCE(_cpdata_9476);
    if (_5211 == 0)
    {
        _5211 = NOVALUE;
        goto L1; // [33] 373
    }
    else{
        _5211 = NOVALUE;
    }

    /** 		pos = 0*/
    _pos_9477 = 0;

    /** 		while pos < length(cpdata) do*/
L2: 
    if (IS_SEQUENCE(_cpdata_9476)){
            _5212 = SEQ_PTR(_cpdata_9476)->length;
    }
    else {
        _5212 = 1;
    }
    if (_pos_9477 >= _5212)
    goto L3; // [49] 188

    /** 			pos += 1*/
    _pos_9477 = _pos_9477 + 1;

    /** 			cpdata[pos]  = trim(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5215 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    Ref(_5215);
    RefDS(_4563);
    _5216 = _6trim(_5215, _4563, 0);
    _5215 = NOVALUE;
    _2 = (int)SEQ_PTR(_cpdata_9476);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cpdata_9476 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pos_9477);
    _1 = *(int *)_2;
    *(int *)_2 = _5216;
    if( _1 != _5216 ){
        DeRef(_1);
    }
    _5216 = NOVALUE;

    /** 			if search:begins("--HEAD--", cpdata[pos]) then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5218 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    RefDS(_5217);
    Ref(_5218);
    _5219 = _9begins(_5217, _5218);
    _5218 = NOVALUE;
    if (_5219 == 0) {
        DeRef(_5219);
        _5219 = NOVALUE;
        goto L4; // [86] 94
    }
    else {
        if (!IS_ATOM_INT(_5219) && DBL_PTR(_5219)->dbl == 0.0){
            DeRef(_5219);
            _5219 = NOVALUE;
            goto L4; // [86] 94
        }
        DeRef(_5219);
        _5219 = NOVALUE;
    }
    DeRef(_5219);
    _5219 = NOVALUE;

    /** 				continue*/
    goto L2; // [91] 46
L4: 

    /** 			if cpdata[pos][1] = ';' then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5220 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    _2 = (int)SEQ_PTR(_5220);
    _5221 = (int)*(((s1_ptr)_2)->base + 1);
    _5220 = NOVALUE;
    if (binary_op_a(NOTEQ, _5221, 59)){
        _5221 = NOVALUE;
        goto L5; // [104] 113
    }
    _5221 = NOVALUE;

    /** 				continue	-- A comment line*/
    goto L2; // [110] 46
L5: 

    /** 			if search:begins("--CASE--", cpdata[pos]) then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5224 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    RefDS(_5223);
    Ref(_5224);
    _5225 = _9begins(_5223, _5224);
    _5224 = NOVALUE;
    if (_5225 == 0) {
        DeRef(_5225);
        _5225 = NOVALUE;
        goto L6; // [124] 132
    }
    else {
        if (!IS_ATOM_INT(_5225) && DBL_PTR(_5225)->dbl == 0.0){
            DeRef(_5225);
            _5225 = NOVALUE;
            goto L6; // [124] 132
        }
        DeRef(_5225);
        _5225 = NOVALUE;
    }
    DeRef(_5225);
    _5225 = NOVALUE;

    /** 				exit*/
    goto L3; // [129] 188
L6: 

    /** 			kv = keyvalues(cpdata[pos],,,,"")*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5226 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    Ref(_5226);
    RefDS(_5372);
    RefDS(_5373);
    RefDS(_5374);
    RefDS(_5);
    _0 = _kv_9478;
    _kv_9478 = _6keyvalues(_5226, _5372, _5373, _5374, _5, 1);
    DeRef(_0);
    _5226 = NOVALUE;

    /** 			if equal(lower(kv[1][1]), "title") then*/
    _2 = (int)SEQ_PTR(_kv_9478);
    _5228 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5228);
    _5229 = (int)*(((s1_ptr)_2)->base + 1);
    _5228 = NOVALUE;
    Ref(_5229);
    _5230 = _6lower(_5229);
    _5229 = NOVALUE;
    if (_5230 == _5231)
    _5232 = 1;
    else if (IS_ATOM_INT(_5230) && IS_ATOM_INT(_5231))
    _5232 = 0;
    else
    _5232 = (compare(_5230, _5231) == 0);
    DeRef(_5230);
    _5230 = NOVALUE;
    if (_5232 == 0)
    {
        _5232 = NOVALUE;
        goto L2; // [167] 46
    }
    else{
        _5232 = NOVALUE;
    }

    /** 				encoding_NAME = kv[1][2]*/
    _2 = (int)SEQ_PTR(_kv_9478);
    _5233 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_6encoding_NAME_9471);
    _2 = (int)SEQ_PTR(_5233);
    _6encoding_NAME_9471 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6encoding_NAME_9471);
    _5233 = NOVALUE;

    /** 		end while*/
    goto L2; // [185] 46
L3: 

    /** 		if pos > length(cpdata) then*/
    if (IS_SEQUENCE(_cpdata_9476)){
            _5235 = SEQ_PTR(_cpdata_9476)->length;
    }
    else {
        _5235 = 1;
    }
    if (_pos_9477 <= _5235)
    goto L7; // [193] 204

    /** 			return -2 -- No Case Conversion table found.*/
    DeRefDS(_cpname_9475);
    DeRef(_cpdata_9476);
    DeRef(_kv_9478);
    DeRef(_cp_source_9479);
    DeRef(_cp_db_9480);
    return -2;
L7: 

    /** 		upper_case_SET = ""*/
    RefDS(_5);
    DeRef(_6upper_case_SET_9470);
    _6upper_case_SET_9470 = _5;

    /** 		lower_case_SET = ""*/
    RefDS(_5);
    DeRef(_6lower_case_SET_9469);
    _6lower_case_SET_9469 = _5;

    /** 		while pos < length(cpdata) do*/
L8: 
    if (IS_SEQUENCE(_cpdata_9476)){
            _5237 = SEQ_PTR(_cpdata_9476)->length;
    }
    else {
        _5237 = 1;
    }
    if (_pos_9477 >= _5237)
    goto L9; // [226] 579

    /** 			pos += 1*/
    _pos_9477 = _pos_9477 + 1;

    /** 			cpdata[pos]  = trim(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5240 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    Ref(_5240);
    RefDS(_4563);
    _5241 = _6trim(_5240, _4563, 0);
    _5240 = NOVALUE;
    _2 = (int)SEQ_PTR(_cpdata_9476);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cpdata_9476 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pos_9477);
    _1 = *(int *)_2;
    *(int *)_2 = _5241;
    if( _1 != _5241 ){
        DeRef(_1);
    }
    _5241 = NOVALUE;

    /** 			if length(cpdata[pos]) < 3 then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5242 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    if (IS_SEQUENCE(_5242)){
            _5243 = SEQ_PTR(_5242)->length;
    }
    else {
        _5243 = 1;
    }
    _5242 = NOVALUE;
    if (_5243 >= 3)
    goto LA; // [261] 270

    /** 				continue*/
    goto L8; // [267] 223
LA: 

    /** 			if cpdata[pos][1] = ';' then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5245 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    _2 = (int)SEQ_PTR(_5245);
    _5246 = (int)*(((s1_ptr)_2)->base + 1);
    _5245 = NOVALUE;
    if (binary_op_a(NOTEQ, _5246, 59)){
        _5246 = NOVALUE;
        goto LB; // [280] 289
    }
    _5246 = NOVALUE;

    /** 				continue	-- A comment line*/
    goto L8; // [286] 223
LB: 

    /** 			if cpdata[pos][1] = '-' then*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5248 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    _2 = (int)SEQ_PTR(_5248);
    _5249 = (int)*(((s1_ptr)_2)->base + 1);
    _5248 = NOVALUE;
    if (binary_op_a(NOTEQ, _5249, 45)){
        _5249 = NOVALUE;
        goto LC; // [299] 308
    }
    _5249 = NOVALUE;

    /** 				exit*/
    goto L9; // [305] 579
LC: 

    /** 			kv = keyvalues(cpdata[pos])*/
    _2 = (int)SEQ_PTR(_cpdata_9476);
    _5251 = (int)*(((s1_ptr)_2)->base + _pos_9477);
    Ref(_5251);
    RefDS(_5372);
    RefDS(_5373);
    RefDS(_5374);
    RefDS(_307);
    _0 = _kv_9478;
    _kv_9478 = _6keyvalues(_5251, _5372, _5373, _5374, _307, 1);
    DeRef(_0);
    _5251 = NOVALUE;

    /** 			upper_case_SET &= convert:hex_text(kv[1][1])*/
    _2 = (int)SEQ_PTR(_kv_9478);
    _5253 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5253);
    _5254 = (int)*(((s1_ptr)_2)->base + 1);
    _5253 = NOVALUE;
    Ref(_5254);
    _5255 = _8hex_text(_5254);
    _5254 = NOVALUE;
    if (IS_SEQUENCE(_6upper_case_SET_9470) && IS_ATOM(_5255)) {
        Ref(_5255);
        Append(&_6upper_case_SET_9470, _6upper_case_SET_9470, _5255);
    }
    else if (IS_ATOM(_6upper_case_SET_9470) && IS_SEQUENCE(_5255)) {
    }
    else {
        Concat((object_ptr)&_6upper_case_SET_9470, _6upper_case_SET_9470, _5255);
    }
    DeRef(_5255);
    _5255 = NOVALUE;

    /** 			lower_case_SET &= convert:hex_text(kv[1][2])*/
    _2 = (int)SEQ_PTR(_kv_9478);
    _5257 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5257);
    _5258 = (int)*(((s1_ptr)_2)->base + 2);
    _5257 = NOVALUE;
    Ref(_5258);
    _5259 = _8hex_text(_5258);
    _5258 = NOVALUE;
    if (IS_SEQUENCE(_6lower_case_SET_9469) && IS_ATOM(_5259)) {
        Ref(_5259);
        Append(&_6lower_case_SET_9469, _6lower_case_SET_9469, _5259);
    }
    else if (IS_ATOM(_6lower_case_SET_9469) && IS_SEQUENCE(_5259)) {
    }
    else {
        Concat((object_ptr)&_6lower_case_SET_9469, _6lower_case_SET_9469, _5259);
    }
    DeRef(_5259);
    _5259 = NOVALUE;

    /** 		end while*/
    goto L8; // [367] 223
    goto L9; // [370] 579
L1: 

    /** 		cp_db = filesys:locate_file("ecp.dat")*/
    RefDS(_5261);
    RefDS(_5);
    RefDS(_5);
    _0 = _cp_db_9480;
    _cp_db_9480 = _11locate_file(_5261, _5, _5);
    DeRef(_0);

    /** 		integer fh = open(cp_db, "rb")*/
    _fh_9552 = EOpen(_cp_db_9480, _1309, 0);

    /** 		if fh = -1 then*/
    if (_fh_9552 != -1)
    goto LD; // [392] 403

    /** 			return -2 -- Couldn't open DB*/
    DeRef(_idx_9556);
    DeRef(_vers_9557);
    DeRefDS(_cpname_9475);
    DeRef(_cpdata_9476);
    DeRef(_kv_9478);
    DeRef(_cp_source_9479);
    DeRefDS(_cp_db_9480);
    _5242 = NOVALUE;
    return -2;
LD: 

    /** 		object idx*/

    /** 		object vers*/

    /** 		vers = serialize:deserialize(fh)  -- get the database version*/
    _0 = _vers_9557;
    _vers_9557 = _27deserialize(_fh_9552, 1);
    DeRef(_0);

    /** 		if atom(vers) or length(vers) = 0 then*/
    _5266 = IS_ATOM(_vers_9557);
    if (_5266 != 0) {
        goto LE; // [419] 435
    }
    if (IS_SEQUENCE(_vers_9557)){
            _5268 = SEQ_PTR(_vers_9557)->length;
    }
    else {
        _5268 = 1;
    }
    _5269 = (_5268 == 0);
    _5268 = NOVALUE;
    if (_5269 == 0)
    {
        DeRef(_5269);
        _5269 = NOVALUE;
        goto LF; // [431] 442
    }
    else{
        DeRef(_5269);
        _5269 = NOVALUE;
    }
LE: 

    /** 			return -3 -- DB is wrong or corrupted.*/
    DeRef(_idx_9556);
    DeRef(_vers_9557);
    DeRefDS(_cpname_9475);
    DeRef(_cpdata_9476);
    DeRef(_kv_9478);
    DeRef(_cp_source_9479);
    DeRef(_cp_db_9480);
    _5242 = NOVALUE;
    return -3;
LF: 

    /** 		switch vers[1] do*/
    _2 = (int)SEQ_PTR(_vers_9557);
    _5270 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_5270) ){
        goto L10; // [448] 563
    }
    if(!IS_ATOM_INT(_5270)){
        if( (DBL_PTR(_5270)->dbl != (double) ((int) DBL_PTR(_5270)->dbl) ) ){
            goto L10; // [448] 563
        }
        _0 = (int) DBL_PTR(_5270)->dbl;
    }
    else {
        _0 = _5270;
    };
    _5270 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 1, 2 then*/
        case 1:
        case 2:

        /** 				idx = serialize:deserialize(fh)  -- get Code Page index offset*/
        _0 = _idx_9556;
        _idx_9556 = _27deserialize(_fh_9552, 1);
        DeRef(_0);

        /** 				pos = io:seek(fh, idx)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_idx_9556);
        DeRef(_seek_1__tmp_at464_9571);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _fh_9552;
        ((int *)_2)[2] = _idx_9556;
        _seek_1__tmp_at464_9571 = MAKE_SEQ(_1);
        _pos_9477 = machine(19, _seek_1__tmp_at464_9571);
        DeRef(_seek_1__tmp_at464_9571);
        _seek_1__tmp_at464_9571 = NOVALUE;

        /** 				idx = serialize:deserialize(fh)	-- get the Code Page Index*/
        _0 = _idx_9556;
        _idx_9556 = _27deserialize(_fh_9552, 1);
        DeRef(_0);

        /** 				pos = find(cpname, idx[1])*/
        _2 = (int)SEQ_PTR(_idx_9556);
        _5275 = (int)*(((s1_ptr)_2)->base + 1);
        _pos_9477 = find_from(_cpname_9475, _5275, 1);
        _5275 = NOVALUE;

        /** 				if pos != 0 then*/
        if (_pos_9477 == 0)
        goto L11; // [501] 572

        /** 					pos = io:seek(fh, idx[2][pos])*/
        _2 = (int)SEQ_PTR(_idx_9556);
        _5278 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_5278);
        _5279 = (int)*(((s1_ptr)_2)->base + _pos_9477);
        _5278 = NOVALUE;
        Ref(_5279);
        DeRef(_pos_inlined_seek_at_511_9580);
        _pos_inlined_seek_at_511_9580 = _5279;
        _5279 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_511_9580);
        DeRef(_seek_1__tmp_at514_9582);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _fh_9552;
        ((int *)_2)[2] = _pos_inlined_seek_at_511_9580;
        _seek_1__tmp_at514_9582 = MAKE_SEQ(_1);
        _pos_9477 = machine(19, _seek_1__tmp_at514_9582);
        DeRef(_pos_inlined_seek_at_511_9580);
        _pos_inlined_seek_at_511_9580 = NOVALUE;
        DeRef(_seek_1__tmp_at514_9582);
        _seek_1__tmp_at514_9582 = NOVALUE;

        /** 					upper_case_SET = serialize:deserialize(fh) -- "uppercase"*/
        _0 = _27deserialize(_fh_9552, 1);
        DeRef(_6upper_case_SET_9470);
        _6upper_case_SET_9470 = _0;

        /** 					lower_case_SET = serialize:deserialize(fh) -- "lowercase"*/
        _0 = _27deserialize(_fh_9552, 1);
        DeRef(_6lower_case_SET_9469);
        _6lower_case_SET_9469 = _0;

        /** 					encoding_NAME = serialize:deserialize(fh) -- "title"*/
        _0 = _27deserialize(_fh_9552, 1);
        DeRef(_6encoding_NAME_9471);
        _6encoding_NAME_9471 = _0;
        goto L11; // [559] 572

        /** 			case else*/
        default:
L10: 

        /** 				return -4 -- Unhandled ecp database version.*/
        DeRef(_idx_9556);
        DeRef(_vers_9557);
        DeRefDS(_cpname_9475);
        DeRef(_cpdata_9476);
        DeRef(_kv_9478);
        DeRef(_cp_source_9479);
        DeRef(_cp_db_9480);
        _5242 = NOVALUE;
        return -4;
    ;}L11: 

    /** 		close(fh)*/
    EClose(_fh_9552);
    DeRef(_idx_9556);
    _idx_9556 = NOVALUE;
    DeRef(_vers_9557);
    _vers_9557 = NOVALUE;
L9: 

    /** 	return 0*/
    DeRefDS(_cpname_9475);
    DeRef(_cpdata_9476);
    DeRef(_kv_9478);
    DeRef(_cp_source_9479);
    DeRef(_cp_db_9480);
    _5242 = NOVALUE;
    return 0;
    ;
}


void  __stdcall _6set_encoding_properties(int _en_9589, int _lc_9590, int _uc_9591)
{
    int _res_9592 = NOVALUE;
    int _5302 = NOVALUE;
    int _5301 = NOVALUE;
    int _5300 = NOVALUE;
    int _5299 = NOVALUE;
    int _5298 = NOVALUE;
    int _5296 = NOVALUE;
    int _5295 = NOVALUE;
    int _5294 = NOVALUE;
    int _5290 = NOVALUE;
    int _5289 = NOVALUE;
    int _5288 = NOVALUE;
    int _5287 = NOVALUE;
    int _5286 = NOVALUE;
    int _5285 = NOVALUE;
    int _5284 = NOVALUE;
    int _5283 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(en) > 0 and length(lc) = 0 and length(uc) = 0 then*/
    if (IS_SEQUENCE(_en_9589)){
            _5283 = SEQ_PTR(_en_9589)->length;
    }
    else {
        _5283 = 1;
    }
    _5284 = (_5283 > 0);
    _5283 = NOVALUE;
    if (_5284 == 0) {
        _5285 = 0;
        goto L1; // [16] 31
    }
    if (IS_SEQUENCE(_lc_9590)){
            _5286 = SEQ_PTR(_lc_9590)->length;
    }
    else {
        _5286 = 1;
    }
    _5287 = (_5286 == 0);
    _5286 = NOVALUE;
    _5285 = (_5287 != 0);
L1: 
    if (_5285 == 0) {
        goto L2; // [31] 77
    }
    if (IS_SEQUENCE(_uc_9591)){
            _5289 = SEQ_PTR(_uc_9591)->length;
    }
    else {
        _5289 = 1;
    }
    _5290 = (_5289 == 0);
    _5289 = NOVALUE;
    if (_5290 == 0)
    {
        DeRef(_5290);
        _5290 = NOVALUE;
        goto L2; // [43] 77
    }
    else{
        DeRef(_5290);
        _5290 = NOVALUE;
    }

    /** 		res = load_code_page(en)*/
    RefDS(_en_9589);
    _res_9592 = _6load_code_page(_en_9589);
    if (!IS_ATOM_INT(_res_9592)) {
        _1 = (long)(DBL_PTR(_res_9592)->dbl);
        DeRefDS(_res_9592);
        _res_9592 = _1;
    }

    /** 		if res != 0 then*/
    if (_res_9592 == 0)
    goto L3; // [56] 71

    /** 			printf(2, "Failed to load code page '%s'. Error # %d\n", {en, res})*/
    RefDS(_en_9589);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _en_9589;
    ((int *)_2)[2] = _res_9592;
    _5294 = MAKE_SEQ(_1);
    EPrintf(2, _5293, _5294);
    DeRefDS(_5294);
    _5294 = NOVALUE;
L3: 

    /** 		return*/
    DeRefDS(_en_9589);
    DeRefDS(_lc_9590);
    DeRefDS(_uc_9591);
    DeRef(_5284);
    _5284 = NOVALUE;
    DeRef(_5287);
    _5287 = NOVALUE;
    return;
L2: 

    /** 	if length(lc) = length(uc) then*/
    if (IS_SEQUENCE(_lc_9590)){
            _5295 = SEQ_PTR(_lc_9590)->length;
    }
    else {
        _5295 = 1;
    }
    if (IS_SEQUENCE(_uc_9591)){
            _5296 = SEQ_PTR(_uc_9591)->length;
    }
    else {
        _5296 = 1;
    }
    if (_5295 != _5296)
    goto L4; // [85] 143

    /** 		if length(lc) = 0 and length(en) = 0 then*/
    if (IS_SEQUENCE(_lc_9590)){
            _5298 = SEQ_PTR(_lc_9590)->length;
    }
    else {
        _5298 = 1;
    }
    _5299 = (_5298 == 0);
    _5298 = NOVALUE;
    if (_5299 == 0) {
        goto L5; // [98] 121
    }
    if (IS_SEQUENCE(_en_9589)){
            _5301 = SEQ_PTR(_en_9589)->length;
    }
    else {
        _5301 = 1;
    }
    _5302 = (_5301 == 0);
    _5301 = NOVALUE;
    if (_5302 == 0)
    {
        DeRef(_5302);
        _5302 = NOVALUE;
        goto L5; // [110] 121
    }
    else{
        DeRef(_5302);
        _5302 = NOVALUE;
    }

    /** 			en = "ASCII"*/
    RefDS(_5206);
    DeRefDS(_en_9589);
    _en_9589 = _5206;
L5: 

    /** 		lower_case_SET = lc*/
    RefDS(_lc_9590);
    DeRef(_6lower_case_SET_9469);
    _6lower_case_SET_9469 = _lc_9590;

    /** 		upper_case_SET = uc*/
    RefDS(_uc_9591);
    DeRef(_6upper_case_SET_9470);
    _6upper_case_SET_9470 = _uc_9591;

    /** 		encoding_NAME = en*/
    RefDS(_en_9589);
    DeRef(_6encoding_NAME_9471);
    _6encoding_NAME_9471 = _en_9589;
L4: 

    /** end procedure*/
    DeRefDS(_en_9589);
    DeRefDS(_lc_9590);
    DeRefDS(_uc_9591);
    DeRef(_5284);
    _5284 = NOVALUE;
    DeRef(_5287);
    _5287 = NOVALUE;
    DeRef(_5299);
    _5299 = NOVALUE;
    return;
    ;
}


int  __stdcall _6get_encoding_properties()
{
    int _5303 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {encoding_NAME, lower_case_SET, upper_case_SET}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6encoding_NAME_9471);
    *((int *)(_2+4)) = _6encoding_NAME_9471;
    RefDS(_6lower_case_SET_9469);
    *((int *)(_2+8)) = _6lower_case_SET_9469;
    RefDS(_6upper_case_SET_9470);
    *((int *)(_2+12)) = _6upper_case_SET_9470;
    _5303 = MAKE_SEQ(_1);
    return _5303;
    ;
}


int _6change_case(int _x_9646, int _api_9647)
{
    int _changed_text_9648 = NOVALUE;
    int _single_char_9649 = NOVALUE;
    int _len_9650 = NOVALUE;
    int _5334 = NOVALUE;
    int _5332 = NOVALUE;
    int _5330 = NOVALUE;
    int _5329 = NOVALUE;
    int _5326 = NOVALUE;
    int _5324 = NOVALUE;
    int _5322 = NOVALUE;
    int _5321 = NOVALUE;
    int _5320 = NOVALUE;
    int _5319 = NOVALUE;
    int _5318 = NOVALUE;
    int _5315 = NOVALUE;
    int _5313 = NOVALUE;
    int _0, _1, _2;
    

    /** 		integer single_char = 0*/
    _single_char_9649 = 0;

    /** 		if not string(x) then*/
    Ref(_x_9646);
    _5313 = _7string(_x_9646);
    if (IS_ATOM_INT(_5313)) {
        if (_5313 != 0){
            DeRef(_5313);
            _5313 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    else {
        if (DBL_PTR(_5313)->dbl != 0.0){
            DeRef(_5313);
            _5313 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    DeRef(_5313);
    _5313 = NOVALUE;

    /** 			if atom(x) then*/
    _5315 = IS_ATOM(_x_9646);
    if (_5315 == 0)
    {
        _5315 = NOVALUE;
        goto L2; // [20] 50
    }
    else{
        _5315 = NOVALUE;
    }

    /** 				if x = 0 then*/
    if (binary_op_a(NOTEQ, _x_9646, 0)){
        goto L3; // [25] 36
    }

    /** 					return 0*/
    DeRef(_x_9646);
    DeRef(_api_9647);
    DeRefi(_changed_text_9648);
    return 0;
L3: 

    /** 				x = {x}*/
    _0 = _x_9646;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_x_9646);
    *((int *)(_2+4)) = _x_9646;
    _x_9646 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 				single_char = 1*/
    _single_char_9649 = 1;
    goto L4; // [47] 94
L2: 

    /** 				for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9646)){
            _5318 = SEQ_PTR(_x_9646)->length;
    }
    else {
        _5318 = 1;
    }
    {
        int _i_9662;
        _i_9662 = 1;
L5: 
        if (_i_9662 > _5318){
            goto L6; // [55] 87
        }

        /** 					x[i] = change_case(x[i], api)*/
        _2 = (int)SEQ_PTR(_x_9646);
        _5319 = (int)*(((s1_ptr)_2)->base + _i_9662);
        Ref(_api_9647);
        DeRef(_5320);
        _5320 = _api_9647;
        Ref(_5319);
        _5321 = _6change_case(_5319, _5320);
        _5319 = NOVALUE;
        _5320 = NOVALUE;
        _2 = (int)SEQ_PTR(_x_9646);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_9646 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9662);
        _1 = *(int *)_2;
        *(int *)_2 = _5321;
        if( _1 != _5321 ){
            DeRef(_1);
        }
        _5321 = NOVALUE;

        /** 				end for*/
        _i_9662 = _i_9662 + 1;
        goto L5; // [82] 62
L6: 
        ;
    }

    /** 				return x*/
    DeRef(_api_9647);
    DeRefi(_changed_text_9648);
    return _x_9646;
L4: 
L1: 

    /** 		if length(x) = 0 then*/
    if (IS_SEQUENCE(_x_9646)){
            _5322 = SEQ_PTR(_x_9646)->length;
    }
    else {
        _5322 = 1;
    }
    if (_5322 != 0)
    goto L7; // [100] 111

    /** 			return x*/
    DeRef(_api_9647);
    DeRefi(_changed_text_9648);
    return _x_9646;
L7: 

    /** 		if length(x) >= tm_size then*/
    if (IS_SEQUENCE(_x_9646)){
            _5324 = SEQ_PTR(_x_9646)->length;
    }
    else {
        _5324 = 1;
    }
    if (_5324 < _6tm_size_9640)
    goto L8; // [118] 148

    /** 			tm_size = length(x) + 1*/
    if (IS_SEQUENCE(_x_9646)){
            _5326 = SEQ_PTR(_x_9646)->length;
    }
    else {
        _5326 = 1;
    }
    _6tm_size_9640 = _5326 + 1;
    _5326 = NOVALUE;

    /** 			free(temp_mem)*/
    Ref(_6temp_mem_9641);
    _14free(_6temp_mem_9641);

    /** 			temp_mem = allocate(tm_size)*/
    _0 = _14allocate(_6tm_size_9640, 0);
    DeRef(_6temp_mem_9641);
    _6temp_mem_9641 = _0;
L8: 

    /** 		poke(temp_mem, x)*/
    if (IS_ATOM_INT(_6temp_mem_9641)){
        poke_addr = (unsigned char *)_6temp_mem_9641;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_6temp_mem_9641)->dbl);
    }
    if (IS_ATOM_INT(_x_9646)) {
        *poke_addr = (unsigned char)_x_9646;
    }
    else if (IS_ATOM(_x_9646)) {
        *poke_addr = (signed char)DBL_PTR(_x_9646)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_x_9646);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 		len = c_func(api, {temp_mem, length(x)} )*/
    if (IS_SEQUENCE(_x_9646)){
            _5329 = SEQ_PTR(_x_9646)->length;
    }
    else {
        _5329 = 1;
    }
    Ref(_6temp_mem_9641);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6temp_mem_9641;
    ((int *)_2)[2] = _5329;
    _5330 = MAKE_SEQ(_1);
    _5329 = NOVALUE;
    _len_9650 = call_c(1, _api_9647, _5330);
    DeRefDS(_5330);
    _5330 = NOVALUE;
    if (!IS_ATOM_INT(_len_9650)) {
        _1 = (long)(DBL_PTR(_len_9650)->dbl);
        DeRefDS(_len_9650);
        _len_9650 = _1;
    }

    /** 		changed_text = peek({temp_mem, len})*/
    Ref(_6temp_mem_9641);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6temp_mem_9641;
    ((int *)_2)[2] = _len_9650;
    _5332 = MAKE_SEQ(_1);
    DeRefi(_changed_text_9648);
    _1 = (int)SEQ_PTR(_5332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _changed_text_9648 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_5332);
    _5332 = NOVALUE;

    /** 		if single_char then*/
    if (_single_char_9649 == 0)
    {
        goto L9; // [188] 204
    }
    else{
    }

    /** 			return changed_text[1]*/
    _2 = (int)SEQ_PTR(_changed_text_9648);
    _5334 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_x_9646);
    DeRef(_api_9647);
    DeRefDSi(_changed_text_9648);
    return _5334;
    goto LA; // [201] 211
L9: 

    /** 			return changed_text*/
    DeRef(_x_9646);
    DeRef(_api_9647);
    _5334 = NOVALUE;
    return _changed_text_9648;
LA: 
    ;
}


int  __stdcall _6lower(int _x_9688)
{
    int _5338 = NOVALUE;
    int _5337 = NOVALUE;
    int _5335 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    if (IS_SEQUENCE(_6lower_case_SET_9469)){
            _5335 = SEQ_PTR(_6lower_case_SET_9469)->length;
    }
    else {
        _5335 = 1;
    }
    if (_5335 == 0)
    goto L1; // [8] 30

    /** 		return stdseq:mapping(x, upper_case_SET, lower_case_SET)*/
    Ref(_x_9688);
    RefDS(_6upper_case_SET_9470);
    RefDS(_6lower_case_SET_9469);
    _5337 = _23mapping(_x_9688, _6upper_case_SET_9470, _6lower_case_SET_9469, 0);
    DeRef(_x_9688);
    return _5337;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharLowerBuff)*/
    Ref(_x_9688);
    Ref(_6api_CharLowerBuff_9624);
    _5338 = _6change_case(_x_9688, _6api_CharLowerBuff_9624);
    DeRef(_x_9688);
    DeRef(_5337);
    _5337 = NOVALUE;
    return _5338;
    ;
}


int  __stdcall _6upper(int _x_9696)
{
    int _5342 = NOVALUE;
    int _5341 = NOVALUE;
    int _5339 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    if (IS_SEQUENCE(_6upper_case_SET_9470)){
            _5339 = SEQ_PTR(_6upper_case_SET_9470)->length;
    }
    else {
        _5339 = 1;
    }
    if (_5339 == 0)
    goto L1; // [8] 30

    /** 		return stdseq:mapping(x, lower_case_SET, upper_case_SET)*/
    Ref(_x_9696);
    RefDS(_6lower_case_SET_9469);
    RefDS(_6upper_case_SET_9470);
    _5341 = _23mapping(_x_9696, _6lower_case_SET_9469, _6upper_case_SET_9470, 0);
    DeRef(_x_9696);
    return _5341;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharUpperBuff)*/
    Ref(_x_9696);
    Ref(_6api_CharUpperBuff_9632);
    _5342 = _6change_case(_x_9696, _6api_CharUpperBuff_9632);
    DeRef(_x_9696);
    DeRef(_5341);
    _5341 = NOVALUE;
    return _5342;
    ;
}


int  __stdcall _6proper(int _x_9704)
{
    int _pos_9705 = NOVALUE;
    int _inword_9706 = NOVALUE;
    int _convert_9707 = NOVALUE;
    int _res_9708 = NOVALUE;
    int _5371 = NOVALUE;
    int _5370 = NOVALUE;
    int _5369 = NOVALUE;
    int _5368 = NOVALUE;
    int _5367 = NOVALUE;
    int _5366 = NOVALUE;
    int _5365 = NOVALUE;
    int _5364 = NOVALUE;
    int _5363 = NOVALUE;
    int _5362 = NOVALUE;
    int _5360 = NOVALUE;
    int _5359 = NOVALUE;
    int _5355 = NOVALUE;
    int _5352 = NOVALUE;
    int _5349 = NOVALUE;
    int _5346 = NOVALUE;
    int _5345 = NOVALUE;
    int _5344 = NOVALUE;
    int _5343 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_9706 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_9707 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_9704);
    DeRef(_res_9708);
    _res_9708 = _x_9704;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_9708)){
            _5343 = SEQ_PTR(_res_9708)->length;
    }
    else {
        _5343 = 1;
    }
    {
        int _i_9710;
        _i_9710 = 1;
L1: 
        if (_i_9710 > _5343){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5344 = (int)*(((s1_ptr)_2)->base + _i_9710);
        if (IS_ATOM_INT(_5344))
        _5345 = 1;
        else if (IS_ATOM_DBL(_5344))
        _5345 = IS_ATOM_INT(DoubleToInt(_5344));
        else
        _5345 = 0;
        _5344 = NOVALUE;
        if (_5345 == 0)
        {
            _5345 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _5345 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_9707 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5346 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5346);
        _pos_9705 = _7t_upper(_5346);
        _5346 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9705)) {
            _1 = (long)(DBL_PTR(_pos_9705)->dbl);
            DeRefDS(_pos_9705);
            _pos_9705 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_9705 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5349 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5349);
        _pos_9705 = _7t_lower(_5349);
        _5349 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9705)) {
            _1 = (long)(DBL_PTR(_pos_9705)->dbl);
            DeRefDS(_pos_9705);
            _pos_9705 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_9705 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5352 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5352);
        _pos_9705 = _7t_digit(_5352);
        _5352 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9705)) {
            _1 = (long)(DBL_PTR(_pos_9705)->dbl);
            DeRefDS(_pos_9705);
            _pos_9705 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_9705 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5355 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5355);
        _pos_9705 = _7t_specword(_5355);
        _5355 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9705)) {
            _1 = (long)(DBL_PTR(_pos_9705)->dbl);
            DeRefDS(_pos_9705);
            _pos_9705 = _1;
        }

        /** 							if pos then*/
        if (_pos_9705 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_9706 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_9706 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_9706 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_9705 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5359 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5359);
        _5360 = _6upper(_5359);
        _5359 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9708);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9708 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9710);
        _1 = *(int *)_2;
        *(int *)_2 = _5360;
        if( _1 != _5360 ){
            DeRef(_1);
        }
        _5360 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_9706 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_9706 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5362 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5362);
        _5363 = _6lower(_5362);
        _5362 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9708);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9708 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9710);
        _1 = *(int *)_2;
        *(int *)_2 = _5363;
        if( _1 != _5363 ){
            DeRef(_1);
        }
        _5363 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_9706 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_9707 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _5364 = _i_9710 - 1;
        {
            int _j_9750;
            _j_9750 = 1;
LB: 
            if (_j_9750 > _5364){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_9704);
            _5365 = (int)*(((s1_ptr)_2)->base + _j_9750);
            _5366 = IS_ATOM(_5365);
            _5365 = NOVALUE;
            if (_5366 == 0)
            {
                _5366 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _5366 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_9704);
            _5367 = (int)*(((s1_ptr)_2)->base + _j_9750);
            Ref(_5367);
            _2 = (int)SEQ_PTR(_res_9708);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_9708 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_9750);
            _1 = *(int *)_2;
            *(int *)_2 = _5367;
            if( _1 != _5367 ){
                DeRef(_1);
            }
            _5367 = NOVALUE;
LD: 

            /** 				end for*/
            _j_9750 = _j_9750 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_9707 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5368 = (int)*(((s1_ptr)_2)->base + _i_9710);
        _5369 = IS_SEQUENCE(_5368);
        _5368 = NOVALUE;
        if (_5369 == 0)
        {
            _5369 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _5369 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_9708);
        _5370 = (int)*(((s1_ptr)_2)->base + _i_9710);
        Ref(_5370);
        _5371 = _6proper(_5370);
        _5370 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9708);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9708 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9710);
        _1 = *(int *)_2;
        *(int *)_2 = _5371;
        if( _1 != _5371 ){
            DeRef(_1);
        }
        _5371 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_9710 = _i_9710 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_9704);
    DeRef(_5364);
    _5364 = NOVALUE;
    return _res_9708;
    ;
}


int  __stdcall _6keyvalues(int _source_9763, int _pair_delim_9764, int _kv_delim_9766, int _quotes_9768, int _whitespace_9770, int _haskeys_9771)
{
    int _lKeyValues_9772 = NOVALUE;
    int _value__9773 = NOVALUE;
    int _key__9774 = NOVALUE;
    int _lAllDelim_9775 = NOVALUE;
    int _lWhitePair_9776 = NOVALUE;
    int _lStartBracket_9777 = NOVALUE;
    int _lEndBracket_9778 = NOVALUE;
    int _lBracketed_9779 = NOVALUE;
    int _lQuote_9780 = NOVALUE;
    int _pos__9781 = NOVALUE;
    int _lChar_9782 = NOVALUE;
    int _lBPos_9783 = NOVALUE;
    int _lWasKV_9784 = NOVALUE;
    int _5547 = NOVALUE;
    int _5544 = NOVALUE;
    int _5540 = NOVALUE;
    int _5537 = NOVALUE;
    int _5536 = NOVALUE;
    int _5535 = NOVALUE;
    int _5534 = NOVALUE;
    int _5533 = NOVALUE;
    int _5532 = NOVALUE;
    int _5531 = NOVALUE;
    int _5529 = NOVALUE;
    int _5528 = NOVALUE;
    int _5527 = NOVALUE;
    int _5526 = NOVALUE;
    int _5525 = NOVALUE;
    int _5524 = NOVALUE;
    int _5523 = NOVALUE;
    int _5522 = NOVALUE;
    int _5519 = NOVALUE;
    int _5518 = NOVALUE;
    int _5517 = NOVALUE;
    int _5516 = NOVALUE;
    int _5515 = NOVALUE;
    int _5514 = NOVALUE;
    int _5510 = NOVALUE;
    int _5508 = NOVALUE;
    int _5507 = NOVALUE;
    int _5504 = NOVALUE;
    int _5500 = NOVALUE;
    int _5498 = NOVALUE;
    int _5495 = NOVALUE;
    int _5492 = NOVALUE;
    int _5489 = NOVALUE;
    int _5486 = NOVALUE;
    int _5483 = NOVALUE;
    int _5480 = NOVALUE;
    int _5476 = NOVALUE;
    int _5475 = NOVALUE;
    int _5474 = NOVALUE;
    int _5473 = NOVALUE;
    int _5472 = NOVALUE;
    int _5471 = NOVALUE;
    int _5470 = NOVALUE;
    int _5468 = NOVALUE;
    int _5467 = NOVALUE;
    int _5466 = NOVALUE;
    int _5465 = NOVALUE;
    int _5464 = NOVALUE;
    int _5463 = NOVALUE;
    int _5462 = NOVALUE;
    int _5461 = NOVALUE;
    int _5459 = NOVALUE;
    int _5456 = NOVALUE;
    int _5454 = NOVALUE;
    int _5452 = NOVALUE;
    int _5451 = NOVALUE;
    int _5450 = NOVALUE;
    int _5449 = NOVALUE;
    int _5448 = NOVALUE;
    int _5447 = NOVALUE;
    int _5446 = NOVALUE;
    int _5445 = NOVALUE;
    int _5442 = NOVALUE;
    int _5441 = NOVALUE;
    int _5440 = NOVALUE;
    int _5439 = NOVALUE;
    int _5438 = NOVALUE;
    int _5435 = NOVALUE;
    int _5432 = NOVALUE;
    int _5429 = NOVALUE;
    int _5426 = NOVALUE;
    int _5425 = NOVALUE;
    int _5423 = NOVALUE;
    int _5422 = NOVALUE;
    int _5418 = NOVALUE;
    int _5415 = NOVALUE;
    int _5412 = NOVALUE;
    int _5408 = NOVALUE;
    int _5407 = NOVALUE;
    int _5406 = NOVALUE;
    int _5405 = NOVALUE;
    int _5401 = NOVALUE;
    int _5398 = NOVALUE;
    int _5395 = NOVALUE;
    int _5394 = NOVALUE;
    int _5392 = NOVALUE;
    int _5390 = NOVALUE;
    int _5384 = NOVALUE;
    int _5382 = NOVALUE;
    int _5380 = NOVALUE;
    int _5378 = NOVALUE;
    int _5376 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_haskeys_9771)) {
        _1 = (long)(DBL_PTR(_haskeys_9771)->dbl);
        DeRefDS(_haskeys_9771);
        _haskeys_9771 = _1;
    }

    /** 	source = trim(source)*/
    RefDS(_source_9763);
    RefDS(_4563);
    _0 = _source_9763;
    _source_9763 = _6trim(_source_9763, _4563, 0);
    DeRefDS(_0);

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_9763)){
            _5376 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5376 = 1;
    }
    if (_5376 != 0)
    goto L1; // [20] 31

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_source_9763);
    DeRef(_pair_delim_9764);
    DeRef(_kv_delim_9766);
    DeRef(_quotes_9768);
    DeRef(_whitespace_9770);
    DeRef(_lKeyValues_9772);
    DeRef(_value__9773);
    DeRef(_key__9774);
    DeRef(_lAllDelim_9775);
    DeRef(_lWhitePair_9776);
    DeRefi(_lStartBracket_9777);
    DeRefi(_lEndBracket_9778);
    DeRefi(_lBracketed_9779);
    return _5;
L1: 

    /** 	if atom(pair_delim) then*/
    _5378 = IS_ATOM(_pair_delim_9764);
    if (_5378 == 0)
    {
        _5378 = NOVALUE;
        goto L2; // [36] 46
    }
    else{
        _5378 = NOVALUE;
    }

    /** 		pair_delim = {pair_delim}*/
    _0 = _pair_delim_9764;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pair_delim_9764);
    *((int *)(_2+4)) = _pair_delim_9764;
    _pair_delim_9764 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if atom(kv_delim) then*/
    _5380 = IS_ATOM(_kv_delim_9766);
    if (_5380 == 0)
    {
        _5380 = NOVALUE;
        goto L3; // [51] 61
    }
    else{
        _5380 = NOVALUE;
    }

    /** 		kv_delim = {kv_delim}*/
    _0 = _kv_delim_9766;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_kv_delim_9766);
    *((int *)(_2+4)) = _kv_delim_9766;
    _kv_delim_9766 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	if atom(quotes) then*/
    _5382 = IS_ATOM(_quotes_9768);
    if (_5382 == 0)
    {
        _5382 = NOVALUE;
        goto L4; // [66] 76
    }
    else{
        _5382 = NOVALUE;
    }

    /** 		quotes = {quotes}*/
    _0 = _quotes_9768;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quotes_9768);
    *((int *)(_2+4)) = _quotes_9768;
    _quotes_9768 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** 	if atom(whitespace) then*/
    _5384 = IS_ATOM(_whitespace_9770);
    if (_5384 == 0)
    {
        _5384 = NOVALUE;
        goto L5; // [81] 91
    }
    else{
        _5384 = NOVALUE;
    }

    /** 		whitespace = {whitespace}*/
    _0 = _whitespace_9770;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_whitespace_9770);
    *((int *)(_2+4)) = _whitespace_9770;
    _whitespace_9770 = MAKE_SEQ(_1);
    DeRef(_0);
L5: 

    /** 	lAllDelim = whitespace & pair_delim & kv_delim*/
    {
        int concat_list[3];

        concat_list[0] = _kv_delim_9766;
        concat_list[1] = _pair_delim_9764;
        concat_list[2] = _whitespace_9770;
        Concat_N((object_ptr)&_lAllDelim_9775, concat_list, 3);
    }

    /** 	lWhitePair = whitespace & pair_delim*/
    if (IS_SEQUENCE(_whitespace_9770) && IS_ATOM(_pair_delim_9764)) {
        Ref(_pair_delim_9764);
        Append(&_lWhitePair_9776, _whitespace_9770, _pair_delim_9764);
    }
    else if (IS_ATOM(_whitespace_9770) && IS_SEQUENCE(_pair_delim_9764)) {
        Ref(_whitespace_9770);
        Prepend(&_lWhitePair_9776, _pair_delim_9764, _whitespace_9770);
    }
    else {
        Concat((object_ptr)&_lWhitePair_9776, _whitespace_9770, _pair_delim_9764);
    }

    /** 	lStartBracket = "{[("*/
    RefDS(_5388);
    DeRefi(_lStartBracket_9777);
    _lStartBracket_9777 = _5388;

    /** 	lEndBracket   = "}])"*/
    RefDS(_5389);
    DeRefi(_lEndBracket_9778);
    _lEndBracket_9778 = _5389;

    /** 	lKeyValues = {}*/
    RefDS(_5);
    DeRef(_lKeyValues_9772);
    _lKeyValues_9772 = _5;

    /** 	pos_ = 1*/
    _pos__9781 = 1;

    /** 	while pos_ <= length(source) do*/
L6: 
    if (IS_SEQUENCE(_source_9763)){
            _5390 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5390 = 1;
    }
    if (_pos__9781 > _5390)
    goto L7; // [139] 1222

    /** 		while pos_ < length(source) do*/
L8: 
    if (IS_SEQUENCE(_source_9763)){
            _5392 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5392 = 1;
    }
    if (_pos__9781 >= _5392)
    goto L9; // [151] 186

    /** 			if find(source[pos_], whitespace) = 0 then*/
    _2 = (int)SEQ_PTR(_source_9763);
    _5394 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    _5395 = find_from(_5394, _whitespace_9770, 1);
    _5394 = NOVALUE;
    if (_5395 != 0)
    goto LA; // [166] 175

    /** 				exit*/
    goto L9; // [172] 186
LA: 

    /** 			pos_ +=1*/
    _pos__9781 = _pos__9781 + 1;

    /** 		end while*/
    goto L8; // [183] 148
L9: 

    /** 		key_ = ""*/
    RefDS(_5);
    DeRef(_key__9774);
    _key__9774 = _5;

    /** 		lQuote = 0*/
    _lQuote_9780 = 0;

    /** 		lChar = 0*/
    _lChar_9782 = 0;

    /** 		lWasKV = 0*/
    _lWasKV_9784 = 0;

    /** 		if haskeys then*/
    if (_haskeys_9771 == 0)
    {
        goto LB; // [210] 401
    }
    else{
    }

    /** 			while pos_ <= length(source) do*/
LC: 
    if (IS_SEQUENCE(_source_9763)){
            _5398 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5398 = 1;
    }
    if (_pos__9781 > _5398)
    goto LD; // [221] 335

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 				if find(lChar, quotes) != 0 then*/
    _5401 = find_from(_lChar_9782, _quotes_9768, 1);
    if (_5401 == 0)
    goto LE; // [238] 282

    /** 					if lChar = lQuote then*/
    if (_lChar_9782 != _lQuote_9780)
    goto LF; // [244] 261

    /** 						lQuote = 0*/
    _lQuote_9780 = 0;

    /** 						lChar = -1*/
    _lChar_9782 = -1;
    goto L10; // [258] 311
LF: 

    /** 					elsif lQuote = 0 then*/
    if (_lQuote_9780 != 0)
    goto L10; // [263] 311

    /** 						lQuote = lChar*/
    _lQuote_9780 = _lChar_9782;

    /** 						lChar = -1*/
    _lChar_9782 = -1;
    goto L10; // [279] 311
LE: 

    /** 				elsif lQuote = 0 and find(lChar, lAllDelim) != 0 then*/
    _5405 = (_lQuote_9780 == 0);
    if (_5405 == 0) {
        goto L11; // [288] 310
    }
    _5407 = find_from(_lChar_9782, _lAllDelim_9775, 1);
    _5408 = (_5407 != 0);
    _5407 = NOVALUE;
    if (_5408 == 0)
    {
        DeRef(_5408);
        _5408 = NOVALUE;
        goto L11; // [302] 310
    }
    else{
        DeRef(_5408);
        _5408 = NOVALUE;
    }

    /** 					exit*/
    goto LD; // [307] 335
L11: 
L10: 

    /** 				if lChar > 0 then*/
    if (_lChar_9782 <= 0)
    goto L12; // [313] 324

    /** 					key_ &= lChar*/
    Append(&_key__9774, _key__9774, _lChar_9782);
L12: 

    /** 				pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 			end while*/
    goto LC; // [332] 218
LD: 

    /** 			if find(lChar, whitespace) != 0 then*/
    _5412 = find_from(_lChar_9782, _whitespace_9770, 1);
    if (_5412 == 0)
    goto L13; // [342] 408

    /** 				pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 				while pos_ <= length(source) do*/
L14: 
    if (IS_SEQUENCE(_source_9763)){
            _5415 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5415 = 1;
    }
    if (_pos__9781 > _5415)
    goto L13; // [360] 408

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 					if find(lChar, whitespace) = 0 then*/
    _5418 = find_from(_lChar_9782, _whitespace_9770, 1);
    if (_5418 != 0)
    goto L15; // [377] 386

    /** 						exit*/
    goto L13; // [383] 408
L15: 

    /** 					pos_ +=1*/
    _pos__9781 = _pos__9781 + 1;

    /** 				end while*/
    goto L14; // [394] 357
    goto L13; // [398] 408
LB: 

    /** 			pos_ -= 1	-- Put back the last char.*/
    _pos__9781 = _pos__9781 - 1;
L13: 

    /** 		value_ = ""*/
    RefDS(_5);
    DeRef(_value__9773);
    _value__9773 = _5;

    /** 		if find(lChar, kv_delim) != 0  or not haskeys then*/
    _5422 = find_from(_lChar_9782, _kv_delim_9766, 1);
    _5423 = (_5422 != 0);
    _5422 = NOVALUE;
    if (_5423 != 0) {
        goto L16; // [426] 438
    }
    _5425 = (_haskeys_9771 == 0);
    if (_5425 == 0)
    {
        DeRef(_5425);
        _5425 = NOVALUE;
        goto L17; // [434] 911
    }
    else{
        DeRef(_5425);
        _5425 = NOVALUE;
    }
L16: 

    /** 			if find(lChar, kv_delim) != 0 then*/
    _5426 = find_from(_lChar_9782, _kv_delim_9766, 1);
    if (_5426 == 0)
    goto L18; // [445] 455

    /** 				lWasKV = 1*/
    _lWasKV_9784 = 1;
L18: 

    /** 			pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 			while pos_ <= length(source) do*/
L19: 
    if (IS_SEQUENCE(_source_9763)){
            _5429 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5429 = 1;
    }
    if (_pos__9781 > _5429)
    goto L1A; // [469] 506

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 				if find(lChar, whitespace) = 0 then*/
    _5432 = find_from(_lChar_9782, _whitespace_9770, 1);
    if (_5432 != 0)
    goto L1B; // [486] 495

    /** 					exit*/
    goto L1A; // [492] 506
L1B: 

    /** 				pos_ +=1*/
    _pos__9781 = _pos__9781 + 1;

    /** 			end while*/
    goto L19; // [503] 466
L1A: 

    /** 			lQuote = 0*/
    _lQuote_9780 = 0;

    /** 			lChar = 0*/
    _lChar_9782 = 0;

    /** 			lBracketed = {}*/
    RefDS(_5);
    DeRefi(_lBracketed_9779);
    _lBracketed_9779 = _5;

    /** 			while pos_ <= length(source) do*/
L1C: 
    if (IS_SEQUENCE(_source_9763)){
            _5435 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5435 = 1;
    }
    if (_pos__9781 > _5435)
    goto L1D; // [531] 813

    /** 				lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 				if length(lBracketed) = 0 and find(lChar, quotes) != 0 then*/
    if (IS_SEQUENCE(_lBracketed_9779)){
            _5438 = SEQ_PTR(_lBracketed_9779)->length;
    }
    else {
        _5438 = 1;
    }
    _5439 = (_5438 == 0);
    _5438 = NOVALUE;
    if (_5439 == 0) {
        goto L1E; // [550] 607
    }
    _5441 = find_from(_lChar_9782, _quotes_9768, 1);
    _5442 = (_5441 != 0);
    _5441 = NOVALUE;
    if (_5442 == 0)
    {
        DeRef(_5442);
        _5442 = NOVALUE;
        goto L1E; // [564] 607
    }
    else{
        DeRef(_5442);
        _5442 = NOVALUE;
    }

    /** 					if lChar = lQuote then*/
    if (_lChar_9782 != _lQuote_9780)
    goto L1F; // [569] 586

    /** 						lQuote = 0*/
    _lQuote_9780 = 0;

    /** 						lChar = -1*/
    _lChar_9782 = -1;
    goto L20; // [583] 789
L1F: 

    /** 					elsif lQuote = 0 then*/
    if (_lQuote_9780 != 0)
    goto L20; // [588] 789

    /** 						lQuote = lChar*/
    _lQuote_9780 = _lChar_9782;

    /** 						lChar = -1*/
    _lChar_9782 = -1;
    goto L20; // [604] 789
L1E: 

    /** 				elsif length(value_) = 1 and value_[1] = '~' and find(lChar, lStartBracket) > 0 then*/
    if (IS_SEQUENCE(_value__9773)){
            _5445 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5445 = 1;
    }
    _5446 = (_5445 == 1);
    _5445 = NOVALUE;
    if (_5446 == 0) {
        _5447 = 0;
        goto L21; // [616] 632
    }
    _2 = (int)SEQ_PTR(_value__9773);
    _5448 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5448)) {
        _5449 = (_5448 == 126);
    }
    else {
        _5449 = binary_op(EQUALS, _5448, 126);
    }
    _5448 = NOVALUE;
    if (IS_ATOM_INT(_5449))
    _5447 = (_5449 != 0);
    else
    _5447 = DBL_PTR(_5449)->dbl != 0.0;
L21: 
    if (_5447 == 0) {
        goto L22; // [632] 669
    }
    _5451 = find_from(_lChar_9782, _lStartBracket_9777, 1);
    _5452 = (_5451 > 0);
    _5451 = NOVALUE;
    if (_5452 == 0)
    {
        DeRef(_5452);
        _5452 = NOVALUE;
        goto L22; // [646] 669
    }
    else{
        DeRef(_5452);
        _5452 = NOVALUE;
    }

    /** 					lBPos = find(lChar, lStartBracket)*/
    _lBPos_9783 = find_from(_lChar_9782, _lStartBracket_9777, 1);

    /** 					lBracketed &= lEndBracket[lBPos]*/
    _2 = (int)SEQ_PTR(_lEndBracket_9778);
    _5454 = (int)*(((s1_ptr)_2)->base + _lBPos_9783);
    Append(&_lBracketed_9779, _lBracketed_9779, _5454);
    _5454 = NOVALUE;
    goto L20; // [666] 789
L22: 

    /** 				elsif find(lChar, lStartBracket) > 0 then*/
    _5456 = find_from(_lChar_9782, _lStartBracket_9777, 1);
    if (_5456 <= 0)
    goto L23; // [676] 700

    /** 					lBPos = find(lChar, lStartBracket)*/
    _lBPos_9783 = find_from(_lChar_9782, _lStartBracket_9777, 1);

    /** 					lBracketed &= lEndBracket[lBPos]*/
    _2 = (int)SEQ_PTR(_lEndBracket_9778);
    _5459 = (int)*(((s1_ptr)_2)->base + _lBPos_9783);
    Append(&_lBracketed_9779, _lBracketed_9779, _5459);
    _5459 = NOVALUE;
    goto L20; // [697] 789
L23: 

    /** 				elsif length(lBracketed) != 0 and lChar = lBracketed[$] then*/
    if (IS_SEQUENCE(_lBracketed_9779)){
            _5461 = SEQ_PTR(_lBracketed_9779)->length;
    }
    else {
        _5461 = 1;
    }
    _5462 = (_5461 != 0);
    _5461 = NOVALUE;
    if (_5462 == 0) {
        goto L24; // [709] 745
    }
    if (IS_SEQUENCE(_lBracketed_9779)){
            _5464 = SEQ_PTR(_lBracketed_9779)->length;
    }
    else {
        _5464 = 1;
    }
    _2 = (int)SEQ_PTR(_lBracketed_9779);
    _5465 = (int)*(((s1_ptr)_2)->base + _5464);
    _5466 = (_lChar_9782 == _5465);
    _5465 = NOVALUE;
    if (_5466 == 0)
    {
        DeRef(_5466);
        _5466 = NOVALUE;
        goto L24; // [725] 745
    }
    else{
        DeRef(_5466);
        _5466 = NOVALUE;
    }

    /** 					lBracketed = lBracketed[1..$-1]*/
    if (IS_SEQUENCE(_lBracketed_9779)){
            _5467 = SEQ_PTR(_lBracketed_9779)->length;
    }
    else {
        _5467 = 1;
    }
    _5468 = _5467 - 1;
    _5467 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lBracketed_9779;
    RHS_Slice(_lBracketed_9779, 1, _5468);
    goto L20; // [742] 789
L24: 

    /** 				elsif length(lBracketed) = 0 and lQuote = 0 and find(lChar, lWhitePair) != 0 then*/
    if (IS_SEQUENCE(_lBracketed_9779)){
            _5470 = SEQ_PTR(_lBracketed_9779)->length;
    }
    else {
        _5470 = 1;
    }
    _5471 = (_5470 == 0);
    _5470 = NOVALUE;
    if (_5471 == 0) {
        _5472 = 0;
        goto L25; // [754] 766
    }
    _5473 = (_lQuote_9780 == 0);
    _5472 = (_5473 != 0);
L25: 
    if (_5472 == 0) {
        goto L26; // [766] 788
    }
    _5475 = find_from(_lChar_9782, _lWhitePair_9776, 1);
    _5476 = (_5475 != 0);
    _5475 = NOVALUE;
    if (_5476 == 0)
    {
        DeRef(_5476);
        _5476 = NOVALUE;
        goto L26; // [780] 788
    }
    else{
        DeRef(_5476);
        _5476 = NOVALUE;
    }

    /** 					exit*/
    goto L1D; // [785] 813
L26: 
L20: 

    /** 				if lChar > 0 then*/
    if (_lChar_9782 <= 0)
    goto L27; // [791] 802

    /** 					value_ &= lChar*/
    Append(&_value__9773, _value__9773, _lChar_9782);
L27: 

    /** 				pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 			end while*/
    goto L1C; // [810] 528
L1D: 

    /** 			if find(lChar, whitespace) != 0  then*/
    _5480 = find_from(_lChar_9782, _whitespace_9770, 1);
    if (_5480 == 0)
    goto L28; // [820] 876

    /** 				pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 				while pos_ <= length(source) do*/
L29: 
    if (IS_SEQUENCE(_source_9763)){
            _5483 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5483 = 1;
    }
    if (_pos__9781 > _5483)
    goto L2A; // [838] 875

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 					if find(lChar, whitespace) = 0 then*/
    _5486 = find_from(_lChar_9782, _whitespace_9770, 1);
    if (_5486 != 0)
    goto L2B; // [855] 864

    /** 						exit*/
    goto L2A; // [861] 875
L2B: 

    /** 					pos_ +=1*/
    _pos__9781 = _pos__9781 + 1;

    /** 				end while*/
    goto L29; // [872] 835
L2A: 
L28: 

    /** 			if find(lChar, pair_delim) != 0  then*/
    _5489 = find_from(_lChar_9782, _pair_delim_9764, 1);
    if (_5489 == 0)
    goto L2C; // [883] 910

    /** 				pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;

    /** 				if pos_ <= length(source) then*/
    if (IS_SEQUENCE(_source_9763)){
            _5492 = SEQ_PTR(_source_9763)->length;
    }
    else {
        _5492 = 1;
    }
    if (_pos__9781 > _5492)
    goto L2D; // [898] 909

    /** 					lChar = source[pos_]*/
    _2 = (int)SEQ_PTR(_source_9763);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + _pos__9781);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;
L2D: 
L2C: 
L17: 

    /** 		if find(lChar, pair_delim) != 0  then*/
    _5495 = find_from(_lChar_9782, _pair_delim_9764, 1);
    if (_5495 == 0)
    goto L2E; // [918] 929

    /** 			pos_ += 1*/
    _pos__9781 = _pos__9781 + 1;
L2E: 

    /** 		if length(value_) = 0 then*/
    if (IS_SEQUENCE(_value__9773)){
            _5498 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5498 = 1;
    }
    if (_5498 != 0)
    goto L2F; // [934] 979

    /** 			if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9774)){
            _5500 = SEQ_PTR(_key__9774)->length;
    }
    else {
        _5500 = 1;
    }
    if (_5500 != 0)
    goto L30; // [943] 958

    /** 				lKeyValues = append(lKeyValues, {})*/
    RefDS(_5);
    Append(&_lKeyValues_9772, _lKeyValues_9772, _5);

    /** 				continue*/
    goto L6; // [955] 136
L30: 

    /** 			if not lWasKV then*/
    if (_lWasKV_9784 != 0)
    goto L31; // [960] 978

    /** 				value_ = key_*/
    RefDS(_key__9774);
    DeRef(_value__9773);
    _value__9773 = _key__9774;

    /** 				key_ = ""*/
    RefDS(_5);
    DeRefDS(_key__9774);
    _key__9774 = _5;
L31: 
L2F: 

    /** 		if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9774)){
            _5504 = SEQ_PTR(_key__9774)->length;
    }
    else {
        _5504 = 1;
    }
    if (_5504 != 0)
    goto L32; // [984] 1008

    /** 			if haskeys then*/
    if (_haskeys_9771 == 0)
    {
        goto L33; // [990] 1007
    }
    else{
    }

    /** 				key_ =  sprintf("p[%d]", length(lKeyValues) + 1)*/
    if (IS_SEQUENCE(_lKeyValues_9772)){
            _5507 = SEQ_PTR(_lKeyValues_9772)->length;
    }
    else {
        _5507 = 1;
    }
    _5508 = _5507 + 1;
    _5507 = NOVALUE;
    DeRefDS(_key__9774);
    _key__9774 = EPrintf(-9999999, _5506, _5508);
    _5508 = NOVALUE;
L33: 
L32: 

    /** 		if length(value_) > 0 then*/
    if (IS_SEQUENCE(_value__9773)){
            _5510 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5510 = 1;
    }
    if (_5510 <= 0)
    goto L34; // [1013] 1168

    /** 			lChar = value_[1]*/
    _2 = (int)SEQ_PTR(_value__9773);
    _lChar_9782 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lChar_9782))
    _lChar_9782 = (long)DBL_PTR(_lChar_9782)->dbl;

    /** 			lBPos = find(lChar, lStartBracket)*/
    _lBPos_9783 = find_from(_lChar_9782, _lStartBracket_9777, 1);

    /** 			if lBPos > 0 and value_[$] = lEndBracket[lBPos] then*/
    _5514 = (_lBPos_9783 > 0);
    if (_5514 == 0) {
        goto L35; // [1036] 1149
    }
    if (IS_SEQUENCE(_value__9773)){
            _5516 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5516 = 1;
    }
    _2 = (int)SEQ_PTR(_value__9773);
    _5517 = (int)*(((s1_ptr)_2)->base + _5516);
    _2 = (int)SEQ_PTR(_lEndBracket_9778);
    _5518 = (int)*(((s1_ptr)_2)->base + _lBPos_9783);
    if (IS_ATOM_INT(_5517)) {
        _5519 = (_5517 == _5518);
    }
    else {
        _5519 = binary_op(EQUALS, _5517, _5518);
    }
    _5517 = NOVALUE;
    _5518 = NOVALUE;
    if (_5519 == 0) {
        DeRef(_5519);
        _5519 = NOVALUE;
        goto L35; // [1056] 1149
    }
    else {
        if (!IS_ATOM_INT(_5519) && DBL_PTR(_5519)->dbl == 0.0){
            DeRef(_5519);
            _5519 = NOVALUE;
            goto L35; // [1056] 1149
        }
        DeRef(_5519);
        _5519 = NOVALUE;
    }
    DeRef(_5519);
    _5519 = NOVALUE;

    /** 				if lChar = '(' then*/
    if (_lChar_9782 != 40)
    goto L36; // [1061] 1108

    /** 					value_ = keyvalues(value_[2..$-1], pair_delim, kv_delim, quotes, whitespace, haskeys)*/
    if (IS_SEQUENCE(_value__9773)){
            _5522 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5522 = 1;
    }
    _5523 = _5522 - 1;
    _5522 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5524;
    RHS_Slice(_value__9773, 2, _5523);
    Ref(_pair_delim_9764);
    DeRef(_5525);
    _5525 = _pair_delim_9764;
    Ref(_kv_delim_9766);
    DeRef(_5526);
    _5526 = _kv_delim_9766;
    Ref(_quotes_9768);
    DeRef(_5527);
    _5527 = _quotes_9768;
    Ref(_whitespace_9770);
    DeRef(_5528);
    _5528 = _whitespace_9770;
    DeRef(_5529);
    _5529 = _haskeys_9771;
    _0 = _value__9773;
    _value__9773 = _6keyvalues(_5524, _5525, _5526, _5527, _5528, _5529);
    DeRefDS(_0);
    _5524 = NOVALUE;
    _5525 = NOVALUE;
    _5526 = NOVALUE;
    _5527 = NOVALUE;
    _5528 = NOVALUE;
    _5529 = NOVALUE;
    goto L37; // [1105] 1167
L36: 

    /** 					value_ = keyvalues(value_[2..$-1], pair_delim, kv_delim, quotes, whitespace, 0)*/
    if (IS_SEQUENCE(_value__9773)){
            _5531 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5531 = 1;
    }
    _5532 = _5531 - 1;
    _5531 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5533;
    RHS_Slice(_value__9773, 2, _5532);
    Ref(_pair_delim_9764);
    DeRef(_5534);
    _5534 = _pair_delim_9764;
    Ref(_kv_delim_9766);
    DeRef(_5535);
    _5535 = _kv_delim_9766;
    Ref(_quotes_9768);
    DeRef(_5536);
    _5536 = _quotes_9768;
    Ref(_whitespace_9770);
    DeRef(_5537);
    _5537 = _whitespace_9770;
    _0 = _value__9773;
    _value__9773 = _6keyvalues(_5533, _5534, _5535, _5536, _5537, 0);
    DeRefDS(_0);
    _5533 = NOVALUE;
    _5534 = NOVALUE;
    _5535 = NOVALUE;
    _5536 = NOVALUE;
    _5537 = NOVALUE;
    goto L37; // [1146] 1167
L35: 

    /** 			elsif lChar = '~' then*/
    if (_lChar_9782 != 126)
    goto L38; // [1151] 1166

    /** 				value_ = value_[2 .. $]*/
    if (IS_SEQUENCE(_value__9773)){
            _5540 = SEQ_PTR(_value__9773)->length;
    }
    else {
        _5540 = 1;
    }
    rhs_slice_target = (object_ptr)&_value__9773;
    RHS_Slice(_value__9773, 2, _5540);
L38: 
L37: 
L34: 

    /** 		key_ = trim(key_)*/
    RefDS(_key__9774);
    RefDS(_4563);
    _0 = _key__9774;
    _key__9774 = _6trim(_key__9774, _4563, 0);
    DeRefDS(_0);

    /** 		value_ = trim(value_)*/
    RefDS(_value__9773);
    RefDS(_4563);
    _0 = _value__9773;
    _value__9773 = _6trim(_value__9773, _4563, 0);
    DeRefDS(_0);

    /** 		if length(key_) = 0 then*/
    if (IS_SEQUENCE(_key__9774)){
            _5544 = SEQ_PTR(_key__9774)->length;
    }
    else {
        _5544 = 1;
    }
    if (_5544 != 0)
    goto L39; // [1193] 1206

    /** 			lKeyValues = append(lKeyValues, value_)*/
    RefDS(_value__9773);
    Append(&_lKeyValues_9772, _lKeyValues_9772, _value__9773);
    goto L6; // [1203] 136
L39: 

    /** 			lKeyValues = append(lKeyValues, {key_, value_})*/
    RefDS(_value__9773);
    RefDS(_key__9774);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key__9774;
    ((int *)_2)[2] = _value__9773;
    _5547 = MAKE_SEQ(_1);
    RefDS(_5547);
    Append(&_lKeyValues_9772, _lKeyValues_9772, _5547);
    DeRefDS(_5547);
    _5547 = NOVALUE;

    /** 	end while*/
    goto L6; // [1219] 136
L7: 

    /** 	return lKeyValues*/
    DeRefDS(_source_9763);
    DeRef(_pair_delim_9764);
    DeRef(_kv_delim_9766);
    DeRef(_quotes_9768);
    DeRef(_whitespace_9770);
    DeRef(_value__9773);
    DeRef(_key__9774);
    DeRef(_lAllDelim_9775);
    DeRef(_lWhitePair_9776);
    DeRefi(_lStartBracket_9777);
    DeRefi(_lEndBracket_9778);
    DeRefi(_lBracketed_9779);
    DeRef(_5405);
    _5405 = NOVALUE;
    DeRef(_5423);
    _5423 = NOVALUE;
    DeRef(_5439);
    _5439 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5462);
    _5462 = NOVALUE;
    DeRef(_5449);
    _5449 = NOVALUE;
    DeRef(_5468);
    _5468 = NOVALUE;
    DeRef(_5471);
    _5471 = NOVALUE;
    DeRef(_5473);
    _5473 = NOVALUE;
    DeRef(_5514);
    _5514 = NOVALUE;
    DeRef(_5523);
    _5523 = NOVALUE;
    DeRef(_5532);
    _5532 = NOVALUE;
    return _lKeyValues_9772;
    ;
}


int  __stdcall _6escape(int _s_10011, int _what_10012)
{
    int _r_10014 = NOVALUE;
    int _5554 = NOVALUE;
    int _5552 = NOVALUE;
    int _5551 = NOVALUE;
    int _5550 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence r = ""*/
    RefDS(_5);
    DeRef(_r_10014);
    _r_10014 = _5;

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_10011)){
            _5550 = SEQ_PTR(_s_10011)->length;
    }
    else {
        _5550 = 1;
    }
    {
        int _i_10016;
        _i_10016 = 1;
L1: 
        if (_i_10016 > _5550){
            goto L2; // [17] 62
        }

        /** 		if find(s[i], what) then*/
        _2 = (int)SEQ_PTR(_s_10011);
        _5551 = (int)*(((s1_ptr)_2)->base + _i_10016);
        _5552 = find_from(_5551, _what_10012, 1);
        _5551 = NOVALUE;
        if (_5552 == 0)
        {
            _5552 = NOVALUE;
            goto L3; // [35] 45
        }
        else{
            _5552 = NOVALUE;
        }

        /** 			r &= "\\"*/
        Concat((object_ptr)&_r_10014, _r_10014, _910);
L3: 

        /** 		r &= s[i]*/
        _2 = (int)SEQ_PTR(_s_10011);
        _5554 = (int)*(((s1_ptr)_2)->base + _i_10016);
        if (IS_SEQUENCE(_r_10014) && IS_ATOM(_5554)) {
            Ref(_5554);
            Append(&_r_10014, _r_10014, _5554);
        }
        else if (IS_ATOM(_r_10014) && IS_SEQUENCE(_5554)) {
        }
        else {
            Concat((object_ptr)&_r_10014, _r_10014, _5554);
        }
        _5554 = NOVALUE;

        /** 	end for*/
        _i_10016 = _i_10016 + 1;
        goto L1; // [57] 24
L2: 
        ;
    }

    /** 	return r*/
    DeRefDS(_s_10011);
    DeRefDS(_what_10012);
    return _r_10014;
    ;
}


int  __stdcall _6quote(int _text_in_10026, int _quote_pair_10027, int _esc_10029, int _sp_10031)
{
    int _5642 = NOVALUE;
    int _5641 = NOVALUE;
    int _5640 = NOVALUE;
    int _5638 = NOVALUE;
    int _5637 = NOVALUE;
    int _5636 = NOVALUE;
    int _5634 = NOVALUE;
    int _5633 = NOVALUE;
    int _5632 = NOVALUE;
    int _5631 = NOVALUE;
    int _5630 = NOVALUE;
    int _5629 = NOVALUE;
    int _5628 = NOVALUE;
    int _5627 = NOVALUE;
    int _5626 = NOVALUE;
    int _5624 = NOVALUE;
    int _5623 = NOVALUE;
    int _5622 = NOVALUE;
    int _5620 = NOVALUE;
    int _5619 = NOVALUE;
    int _5618 = NOVALUE;
    int _5617 = NOVALUE;
    int _5616 = NOVALUE;
    int _5615 = NOVALUE;
    int _5614 = NOVALUE;
    int _5613 = NOVALUE;
    int _5612 = NOVALUE;
    int _5610 = NOVALUE;
    int _5609 = NOVALUE;
    int _5607 = NOVALUE;
    int _5606 = NOVALUE;
    int _5605 = NOVALUE;
    int _5603 = NOVALUE;
    int _5602 = NOVALUE;
    int _5601 = NOVALUE;
    int _5600 = NOVALUE;
    int _5599 = NOVALUE;
    int _5598 = NOVALUE;
    int _5597 = NOVALUE;
    int _5596 = NOVALUE;
    int _5595 = NOVALUE;
    int _5594 = NOVALUE;
    int _5593 = NOVALUE;
    int _5592 = NOVALUE;
    int _5591 = NOVALUE;
    int _5590 = NOVALUE;
    int _5589 = NOVALUE;
    int _5588 = NOVALUE;
    int _5587 = NOVALUE;
    int _5584 = NOVALUE;
    int _5583 = NOVALUE;
    int _5582 = NOVALUE;
    int _5581 = NOVALUE;
    int _5580 = NOVALUE;
    int _5579 = NOVALUE;
    int _5578 = NOVALUE;
    int _5577 = NOVALUE;
    int _5576 = NOVALUE;
    int _5575 = NOVALUE;
    int _5574 = NOVALUE;
    int _5573 = NOVALUE;
    int _5572 = NOVALUE;
    int _5571 = NOVALUE;
    int _5568 = NOVALUE;
    int _5566 = NOVALUE;
    int _5565 = NOVALUE;
    int _5563 = NOVALUE;
    int _5561 = NOVALUE;
    int _5560 = NOVALUE;
    int _5559 = NOVALUE;
    int _5557 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_esc_10029)) {
        _1 = (long)(DBL_PTR(_esc_10029)->dbl);
        DeRefDS(_esc_10029);
        _esc_10029 = _1;
    }

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_10026)){
            _5557 = SEQ_PTR(_text_in_10026)->length;
    }
    else {
        _5557 = 1;
    }
    if (_5557 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_10027);
    DeRef(_sp_10031);
    return _text_in_10026;
L1: 

    /** 	if atom(quote_pair) then*/
    _5559 = IS_ATOM(_quote_pair_10027);
    if (_5559 == 0)
    {
        _5559 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _5559 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_10027);
    *((int *)(_2+4)) = _quote_pair_10027;
    _5560 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_10027);
    *((int *)(_2+4)) = _quote_pair_10027;
    _5561 = MAKE_SEQ(_1);
    DeRef(_quote_pair_10027);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5560;
    ((int *)_2)[2] = _5561;
    _quote_pair_10027 = MAKE_SEQ(_1);
    _5561 = NOVALUE;
    _5560 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_10027)){
            _5563 = SEQ_PTR(_quote_pair_10027)->length;
    }
    else {
        _5563 = 1;
    }
    if (_5563 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5565 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5566 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5566);
    Ref(_5565);
    DeRef(_quote_pair_10027);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5565;
    ((int *)_2)[2] = _5566;
    _quote_pair_10027 = MAKE_SEQ(_1);
    _5566 = NOVALUE;
    _5565 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_10027)){
            _5568 = SEQ_PTR(_quote_pair_10027)->length;
    }
    else {
        _5568 = 1;
    }
    if (_5568 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_5549);
    RefDS(_5549);
    DeRef(_quote_pair_10027);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5549;
    ((int *)_2)[2] = _5549;
    _quote_pair_10027 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_10026);
    _5571 = (int)*(((s1_ptr)_2)->base + 1);
    _5572 = IS_SEQUENCE(_5571);
    _5571 = NOVALUE;
    if (_5572 == 0)
    {
        _5572 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _5572 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_10026)){
            _5573 = SEQ_PTR(_text_in_10026)->length;
    }
    else {
        _5573 = 1;
    }
    {
        int _i_10054;
        _i_10054 = 1;
L7: 
        if (_i_10054 > _5573){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_10026);
        _5574 = (int)*(((s1_ptr)_2)->base + _i_10054);
        _5575 = IS_SEQUENCE(_5574);
        _5574 = NOVALUE;
        if (_5575 == 0)
        {
            _5575 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _5575 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_10026);
        _5576 = (int)*(((s1_ptr)_2)->base + _i_10054);
        Ref(_quote_pair_10027);
        DeRef(_5577);
        _5577 = _quote_pair_10027;
        DeRef(_5578);
        _5578 = _esc_10029;
        Ref(_sp_10031);
        DeRef(_5579);
        _5579 = _sp_10031;
        Ref(_5576);
        _5580 = _6quote(_5576, _5577, _5578, _5579);
        _5576 = NOVALUE;
        _5577 = NOVALUE;
        _5578 = NOVALUE;
        _5579 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_10026);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_10026 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_10054);
        _1 = *(int *)_2;
        *(int *)_2 = _5580;
        if( _1 != _5580 ){
            DeRef(_1);
        }
        _5580 = NOVALUE;
L9: 

        /** 		end for*/
        _i_10054 = _i_10054 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_10027);
    DeRef(_sp_10031);
    return _text_in_10026;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_10031)){
            _5581 = SEQ_PTR(_sp_10031)->length;
    }
    else {
        _5581 = 1;
    }
    {
        int _i_10065;
        _i_10065 = 1;
LA: 
        if (_i_10065 > _5581){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_10031);
        _5582 = (int)*(((s1_ptr)_2)->base + _i_10065);
        _5583 = find_from(_5582, _text_in_10026, 1);
        _5582 = NOVALUE;
        if (_5583 == 0)
        {
            _5583 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _5583 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_10031)){
                _5584 = SEQ_PTR(_sp_10031)->length;
        }
        else {
            _5584 = 1;
        }
        if (_i_10065 != _5584)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_10027);
        DeRef(_sp_10031);
        return _text_in_10026;
LD: 

        /** 	end for*/
        _i_10065 = _i_10065 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_10029 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5587 = (int)*(((s1_ptr)_2)->base + 1);
    _5588 = IS_ATOM(_5587);
    _5587 = NOVALUE;
    if (_5588 == 0)
    {
        _5588 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _5588 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5589 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5589);
    *((int *)(_2+4)) = _5589;
    _5590 = MAKE_SEQ(_1);
    _5589 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_10027 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _5590;
    if( _1 != _5590 ){
        DeRef(_1);
    }
    _5590 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5591 = (int)*(((s1_ptr)_2)->base + 2);
    _5592 = IS_ATOM(_5591);
    _5591 = NOVALUE;
    if (_5592 == 0)
    {
        _5592 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _5592 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5593 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5593);
    *((int *)(_2+4)) = _5593;
    _5594 = MAKE_SEQ(_1);
    _5593 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_10027 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5594;
    if( _1 != _5594 ){
        DeRef(_1);
    }
    _5594 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5595 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5596 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5595 == _5596)
    _5597 = 1;
    else if (IS_ATOM_INT(_5595) && IS_ATOM_INT(_5596))
    _5597 = 0;
    else
    _5597 = (compare(_5595, _5596) == 0);
    _5595 = NOVALUE;
    _5596 = NOVALUE;
    if (_5597 == 0)
    {
        _5597 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _5597 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5598 = (int)*(((s1_ptr)_2)->base + 1);
    _5599 = e_match_from(_5598, _text_in_10026, 1);
    _5598 = NOVALUE;
    if (_5599 == 0)
    {
        _5599 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _5599 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5600 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5600)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5600)) {
        Prepend(&_5601, _5600, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5601, _esc_10029, _5600);
    }
    _5600 = NOVALUE;
    _5602 = e_match_from(_5601, _text_in_10026, 1);
    DeRefDS(_5601);
    _5601 = NOVALUE;
    if (_5602 == 0)
    {
        _5602 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _5602 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_5603, _esc_10029, _esc_10029);
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_esc_10029, _text_in_10026, _5603, 0);
    DeRefDS(_0);
    _5603 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5605 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5606 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5606)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5606)) {
        Prepend(&_5607, _5606, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5607, _esc_10029, _5606);
    }
    _5606 = NOVALUE;
    Ref(_5605);
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_5605, _text_in_10026, _5607, 0);
    DeRefDS(_0);
    _5605 = NOVALUE;
    _5607 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5609 = (int)*(((s1_ptr)_2)->base + 1);
    _5610 = e_match_from(_5609, _text_in_10026, 1);
    _5609 = NOVALUE;
    if (_5610 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5612 = (int)*(((s1_ptr)_2)->base + 2);
    _5613 = e_match_from(_5612, _text_in_10026, 1);
    _5612 = NOVALUE;
    if (_5613 == 0)
    {
        _5613 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _5613 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5614 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5614)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5614)) {
        Prepend(&_5615, _5614, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5615, _esc_10029, _5614);
    }
    _5614 = NOVALUE;
    _5616 = e_match_from(_5615, _text_in_10026, 1);
    DeRefDS(_5615);
    _5615 = NOVALUE;
    if (_5616 == 0)
    {
        _5616 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _5616 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5617 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5617)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5617)) {
        Prepend(&_5618, _5617, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5618, _esc_10029, _5617);
    }
    _5617 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5619 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _5619;
        concat_list[1] = _esc_10029;
        concat_list[2] = _esc_10029;
        Concat_N((object_ptr)&_5620, concat_list, 3);
    }
    _5619 = NOVALUE;
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_5618, _text_in_10026, _5620, 0);
    DeRefDS(_0);
    _5618 = NOVALUE;
    _5620 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5622 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5623 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5623)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5623)) {
        Prepend(&_5624, _5623, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5624, _esc_10029, _5623);
    }
    _5623 = NOVALUE;
    Ref(_5622);
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_5622, _text_in_10026, _5624, 0);
    DeRefDS(_0);
    _5622 = NOVALUE;
    _5624 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5626 = (int)*(((s1_ptr)_2)->base + 2);
    _5627 = e_match_from(_5626, _text_in_10026, 1);
    _5626 = NOVALUE;
    if (_5627 == 0)
    {
        _5627 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _5627 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5628 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5628)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5628)) {
        Prepend(&_5629, _5628, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5629, _esc_10029, _5628);
    }
    _5628 = NOVALUE;
    _5630 = e_match_from(_5629, _text_in_10026, 1);
    DeRefDS(_5629);
    _5629 = NOVALUE;
    if (_5630 == 0)
    {
        _5630 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _5630 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5631 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5631)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5631)) {
        Prepend(&_5632, _5631, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5632, _esc_10029, _5631);
    }
    _5631 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5633 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5633;
        concat_list[1] = _esc_10029;
        concat_list[2] = _esc_10029;
        Concat_N((object_ptr)&_5634, concat_list, 3);
    }
    _5633 = NOVALUE;
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_5632, _text_in_10026, _5634, 0);
    DeRefDS(_0);
    _5632 = NOVALUE;
    _5634 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5636 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5637 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10029) && IS_ATOM(_5637)) {
    }
    else if (IS_ATOM(_esc_10029) && IS_SEQUENCE(_5637)) {
        Prepend(&_5638, _5637, _esc_10029);
    }
    else {
        Concat((object_ptr)&_5638, _esc_10029, _5637);
    }
    _5637 = NOVALUE;
    Ref(_5636);
    RefDS(_text_in_10026);
    _0 = _text_in_10026;
    _text_in_10026 = _9match_replace(_5636, _text_in_10026, _5638, 0);
    DeRefDS(_0);
    _5636 = NOVALUE;
    _5638 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5640 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_10027);
    _5641 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5641;
        concat_list[1] = _text_in_10026;
        concat_list[2] = _5640;
        Concat_N((object_ptr)&_5642, concat_list, 3);
    }
    _5641 = NOVALUE;
    _5640 = NOVALUE;
    DeRefDS(_text_in_10026);
    DeRef(_quote_pair_10027);
    DeRef(_sp_10031);
    return _5642;
    ;
}


int  __stdcall _6dequote(int _text_in_10144, int _quote_pairs_10145, int _esc_10148)
{
    int _pos_10213 = NOVALUE;
    int _5720 = NOVALUE;
    int _5719 = NOVALUE;
    int _5718 = NOVALUE;
    int _5717 = NOVALUE;
    int _5716 = NOVALUE;
    int _5715 = NOVALUE;
    int _5714 = NOVALUE;
    int _5713 = NOVALUE;
    int _5712 = NOVALUE;
    int _5711 = NOVALUE;
    int _5710 = NOVALUE;
    int _5708 = NOVALUE;
    int _5707 = NOVALUE;
    int _5706 = NOVALUE;
    int _5705 = NOVALUE;
    int _5704 = NOVALUE;
    int _5703 = NOVALUE;
    int _5702 = NOVALUE;
    int _5701 = NOVALUE;
    int _5700 = NOVALUE;
    int _5699 = NOVALUE;
    int _5698 = NOVALUE;
    int _5695 = NOVALUE;
    int _5694 = NOVALUE;
    int _5693 = NOVALUE;
    int _5692 = NOVALUE;
    int _5691 = NOVALUE;
    int _5690 = NOVALUE;
    int _5689 = NOVALUE;
    int _5688 = NOVALUE;
    int _5687 = NOVALUE;
    int _5686 = NOVALUE;
    int _5685 = NOVALUE;
    int _5684 = NOVALUE;
    int _5683 = NOVALUE;
    int _5682 = NOVALUE;
    int _5681 = NOVALUE;
    int _5680 = NOVALUE;
    int _5678 = NOVALUE;
    int _5677 = NOVALUE;
    int _5676 = NOVALUE;
    int _5675 = NOVALUE;
    int _5674 = NOVALUE;
    int _5673 = NOVALUE;
    int _5672 = NOVALUE;
    int _5671 = NOVALUE;
    int _5670 = NOVALUE;
    int _5669 = NOVALUE;
    int _5668 = NOVALUE;
    int _5667 = NOVALUE;
    int _5666 = NOVALUE;
    int _5665 = NOVALUE;
    int _5664 = NOVALUE;
    int _5663 = NOVALUE;
    int _5662 = NOVALUE;
    int _5661 = NOVALUE;
    int _5659 = NOVALUE;
    int _5657 = NOVALUE;
    int _5655 = NOVALUE;
    int _5654 = NOVALUE;
    int _5652 = NOVALUE;
    int _5650 = NOVALUE;
    int _5649 = NOVALUE;
    int _5648 = NOVALUE;
    int _5647 = NOVALUE;
    int _5645 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_esc_10148)) {
        _1 = (long)(DBL_PTR(_esc_10148)->dbl);
        DeRefDS(_esc_10148);
        _esc_10148 = _1;
    }

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_10144)){
            _5645 = SEQ_PTR(_text_in_10144)->length;
    }
    else {
        _5645 = 1;
    }
    if (_5645 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pairs_10145);
    return _text_in_10144;
L1: 

    /** 	if atom(quote_pairs) then*/
    _5647 = IS_ATOM(_quote_pairs_10145);
    if (_5647 == 0)
    {
        _5647 = NOVALUE;
        goto L2; // [26] 50
    }
    else{
        _5647 = NOVALUE;
    }

    /** 		quote_pairs = {{{quote_pairs}, {quote_pairs}}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pairs_10145);
    *((int *)(_2+4)) = _quote_pairs_10145;
    _5648 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pairs_10145);
    *((int *)(_2+4)) = _quote_pairs_10145;
    _5649 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5648;
    ((int *)_2)[2] = _5649;
    _5650 = MAKE_SEQ(_1);
    _5649 = NOVALUE;
    _5648 = NOVALUE;
    _0 = _quote_pairs_10145;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5650;
    _quote_pairs_10145 = MAKE_SEQ(_1);
    DeRef(_0);
    _5650 = NOVALUE;
    goto L3; // [47] 97
L2: 

    /** 	elsif length(quote_pairs) = 1 then*/
    if (IS_SEQUENCE(_quote_pairs_10145)){
            _5652 = SEQ_PTR(_quote_pairs_10145)->length;
    }
    else {
        _5652 = 1;
    }
    if (_5652 != 1)
    goto L4; // [55] 76

    /** 		quote_pairs = {quote_pairs[1], quote_pairs[1]}*/
    _2 = (int)SEQ_PTR(_quote_pairs_10145);
    _5654 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pairs_10145);
    _5655 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5655);
    Ref(_5654);
    DeRef(_quote_pairs_10145);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5654;
    ((int *)_2)[2] = _5655;
    _quote_pairs_10145 = MAKE_SEQ(_1);
    _5655 = NOVALUE;
    _5654 = NOVALUE;
    goto L3; // [73] 97
L4: 

    /** 	elsif length(quote_pairs) = 0 then*/
    if (IS_SEQUENCE(_quote_pairs_10145)){
            _5657 = SEQ_PTR(_quote_pairs_10145)->length;
    }
    else {
        _5657 = 1;
    }
    if (_5657 != 0)
    goto L5; // [81] 96

    /** 		quote_pairs = {{"\"", "\""}}*/
    RefDS(_5549);
    RefDS(_5549);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5549;
    ((int *)_2)[2] = _5549;
    _5659 = MAKE_SEQ(_1);
    _0 = _quote_pairs_10145;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5659;
    _quote_pairs_10145 = MAKE_SEQ(_1);
    DeRef(_0);
    _5659 = NOVALUE;
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_10144);
    _5661 = (int)*(((s1_ptr)_2)->base + 1);
    _5662 = IS_SEQUENCE(_5661);
    _5661 = NOVALUE;
    if (_5662 == 0)
    {
        _5662 = NOVALUE;
        goto L6; // [106] 170
    }
    else{
        _5662 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_10144)){
            _5663 = SEQ_PTR(_text_in_10144)->length;
    }
    else {
        _5663 = 1;
    }
    {
        int _i_10173;
        _i_10173 = 1;
L7: 
        if (_i_10173 > _5663){
            goto L8; // [114] 163
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_10144);
        _5664 = (int)*(((s1_ptr)_2)->base + _i_10173);
        _5665 = IS_SEQUENCE(_5664);
        _5664 = NOVALUE;
        if (_5665 == 0)
        {
            _5665 = NOVALUE;
            goto L9; // [130] 156
        }
        else{
            _5665 = NOVALUE;
        }

        /** 				text_in[i] = dequote(text_in[i], quote_pairs, esc)*/
        _2 = (int)SEQ_PTR(_text_in_10144);
        _5666 = (int)*(((s1_ptr)_2)->base + _i_10173);
        Ref(_quote_pairs_10145);
        DeRef(_5667);
        _5667 = _quote_pairs_10145;
        DeRef(_5668);
        _5668 = _esc_10148;
        Ref(_5666);
        _5669 = _6dequote(_5666, _5667, _5668);
        _5666 = NOVALUE;
        _5667 = NOVALUE;
        _5668 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_10144);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_10144 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_10173);
        _1 = *(int *)_2;
        *(int *)_2 = _5669;
        if( _1 != _5669 ){
            DeRef(_1);
        }
        _5669 = NOVALUE;
L9: 

        /** 		end for*/
        _i_10173 = _i_10173 + 1;
        goto L7; // [158] 121
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pairs_10145);
    return _text_in_10144;
L6: 

    /** 	for i = 1 to length(quote_pairs) do*/
    if (IS_SEQUENCE(_quote_pairs_10145)){
            _5670 = SEQ_PTR(_quote_pairs_10145)->length;
    }
    else {
        _5670 = 1;
    }
    {
        int _i_10183;
        _i_10183 = 1;
LA: 
        if (_i_10183 > _5670){
            goto LB; // [175] 466
        }

        /** 		if length(text_in) >= length(quote_pairs[i][1]) + length(quote_pairs[i][2]) then*/
        if (IS_SEQUENCE(_text_in_10144)){
                _5671 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5671 = 1;
        }
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5672 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5672);
        _5673 = (int)*(((s1_ptr)_2)->base + 1);
        _5672 = NOVALUE;
        if (IS_SEQUENCE(_5673)){
                _5674 = SEQ_PTR(_5673)->length;
        }
        else {
            _5674 = 1;
        }
        _5673 = NOVALUE;
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5675 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5675);
        _5676 = (int)*(((s1_ptr)_2)->base + 2);
        _5675 = NOVALUE;
        if (IS_SEQUENCE(_5676)){
                _5677 = SEQ_PTR(_5676)->length;
        }
        else {
            _5677 = 1;
        }
        _5676 = NOVALUE;
        _5678 = _5674 + _5677;
        if ((long)((unsigned long)_5678 + (unsigned long)HIGH_BITS) >= 0) 
        _5678 = NewDouble((double)_5678);
        _5674 = NOVALUE;
        _5677 = NOVALUE;
        if (binary_op_a(LESS, _5671, _5678)){
            _5671 = NOVALUE;
            DeRef(_5678);
            _5678 = NOVALUE;
            goto LC; // [213] 459
        }
        _5671 = NOVALUE;
        DeRef(_5678);
        _5678 = NOVALUE;

        /** 			if search:begins(quote_pairs[i][1], text_in) and search:ends(quote_pairs[i][2], text_in) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5680 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5680);
        _5681 = (int)*(((s1_ptr)_2)->base + 1);
        _5680 = NOVALUE;
        Ref(_5681);
        RefDS(_text_in_10144);
        _5682 = _9begins(_5681, _text_in_10144);
        _5681 = NOVALUE;
        if (IS_ATOM_INT(_5682)) {
            if (_5682 == 0) {
                goto LD; // [232] 456
            }
        }
        else {
            if (DBL_PTR(_5682)->dbl == 0.0) {
                goto LD; // [232] 456
            }
        }
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5684 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5684);
        _5685 = (int)*(((s1_ptr)_2)->base + 2);
        _5684 = NOVALUE;
        Ref(_5685);
        RefDS(_text_in_10144);
        _5686 = _9ends(_5685, _text_in_10144);
        _5685 = NOVALUE;
        if (_5686 == 0) {
            DeRef(_5686);
            _5686 = NOVALUE;
            goto LD; // [250] 456
        }
        else {
            if (!IS_ATOM_INT(_5686) && DBL_PTR(_5686)->dbl == 0.0){
                DeRef(_5686);
                _5686 = NOVALUE;
                goto LD; // [250] 456
            }
            DeRef(_5686);
            _5686 = NOVALUE;
        }
        DeRef(_5686);
        _5686 = NOVALUE;

        /** 				text_in = text_in[1 + length(quote_pairs[i][1]) .. $ - length(quote_pairs[i][2])]*/
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5687 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5687);
        _5688 = (int)*(((s1_ptr)_2)->base + 1);
        _5687 = NOVALUE;
        if (IS_SEQUENCE(_5688)){
                _5689 = SEQ_PTR(_5688)->length;
        }
        else {
            _5689 = 1;
        }
        _5688 = NOVALUE;
        _5690 = _5689 + 1;
        _5689 = NOVALUE;
        if (IS_SEQUENCE(_text_in_10144)){
                _5691 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5691 = 1;
        }
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5692 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5692);
        _5693 = (int)*(((s1_ptr)_2)->base + 2);
        _5692 = NOVALUE;
        if (IS_SEQUENCE(_5693)){
                _5694 = SEQ_PTR(_5693)->length;
        }
        else {
            _5694 = 1;
        }
        _5693 = NOVALUE;
        _5695 = _5691 - _5694;
        _5691 = NOVALUE;
        _5694 = NOVALUE;
        rhs_slice_target = (object_ptr)&_text_in_10144;
        RHS_Slice(_text_in_10144, _5690, _5695);

        /** 				integer pos = 1*/
        _pos_10213 = 1;

        /** 				while pos > 0 with entry do*/
        goto LE; // [300] 437
LF: 
        if (_pos_10213 <= 0)
        goto L10; // [303] 449

        /** 					if search:begins(quote_pairs[i][1], text_in[pos+1 .. $]) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5698 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5698);
        _5699 = (int)*(((s1_ptr)_2)->base + 1);
        _5698 = NOVALUE;
        _5700 = _pos_10213 + 1;
        if (_5700 > MAXINT){
            _5700 = NewDouble((double)_5700);
        }
        if (IS_SEQUENCE(_text_in_10144)){
                _5701 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5701 = 1;
        }
        rhs_slice_target = (object_ptr)&_5702;
        RHS_Slice(_text_in_10144, _5700, _5701);
        Ref(_5699);
        _5703 = _9begins(_5699, _5702);
        _5699 = NOVALUE;
        _5702 = NOVALUE;
        if (_5703 == 0) {
            DeRef(_5703);
            _5703 = NOVALUE;
            goto L11; // [334] 367
        }
        else {
            if (!IS_ATOM_INT(_5703) && DBL_PTR(_5703)->dbl == 0.0){
                DeRef(_5703);
                _5703 = NOVALUE;
                goto L11; // [334] 367
            }
            DeRef(_5703);
            _5703 = NOVALUE;
        }
        DeRef(_5703);
        _5703 = NOVALUE;

        /** 						text_in = text_in[1 .. pos-1] & text_in[pos + 1 .. $]*/
        _5704 = _pos_10213 - 1;
        rhs_slice_target = (object_ptr)&_5705;
        RHS_Slice(_text_in_10144, 1, _5704);
        _5706 = _pos_10213 + 1;
        if (_5706 > MAXINT){
            _5706 = NewDouble((double)_5706);
        }
        if (IS_SEQUENCE(_text_in_10144)){
                _5707 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5707 = 1;
        }
        rhs_slice_target = (object_ptr)&_5708;
        RHS_Slice(_text_in_10144, _5706, _5707);
        Concat((object_ptr)&_text_in_10144, _5705, _5708);
        DeRefDS(_5705);
        _5705 = NOVALUE;
        DeRef(_5705);
        _5705 = NOVALUE;
        DeRefDS(_5708);
        _5708 = NOVALUE;
        goto L12; // [364] 434
L11: 

        /** 					elsif search:begins(quote_pairs[i][2], text_in[pos+1 .. $]) then*/
        _2 = (int)SEQ_PTR(_quote_pairs_10145);
        _5710 = (int)*(((s1_ptr)_2)->base + _i_10183);
        _2 = (int)SEQ_PTR(_5710);
        _5711 = (int)*(((s1_ptr)_2)->base + 2);
        _5710 = NOVALUE;
        _5712 = _pos_10213 + 1;
        if (_5712 > MAXINT){
            _5712 = NewDouble((double)_5712);
        }
        if (IS_SEQUENCE(_text_in_10144)){
                _5713 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5713 = 1;
        }
        rhs_slice_target = (object_ptr)&_5714;
        RHS_Slice(_text_in_10144, _5712, _5713);
        Ref(_5711);
        _5715 = _9begins(_5711, _5714);
        _5711 = NOVALUE;
        _5714 = NOVALUE;
        if (_5715 == 0) {
            DeRef(_5715);
            _5715 = NOVALUE;
            goto L13; // [394] 427
        }
        else {
            if (!IS_ATOM_INT(_5715) && DBL_PTR(_5715)->dbl == 0.0){
                DeRef(_5715);
                _5715 = NOVALUE;
                goto L13; // [394] 427
            }
            DeRef(_5715);
            _5715 = NOVALUE;
        }
        DeRef(_5715);
        _5715 = NOVALUE;

        /** 						text_in = text_in[1 .. pos-1] & text_in[pos + 1 .. $]*/
        _5716 = _pos_10213 - 1;
        rhs_slice_target = (object_ptr)&_5717;
        RHS_Slice(_text_in_10144, 1, _5716);
        _5718 = _pos_10213 + 1;
        if (_5718 > MAXINT){
            _5718 = NewDouble((double)_5718);
        }
        if (IS_SEQUENCE(_text_in_10144)){
                _5719 = SEQ_PTR(_text_in_10144)->length;
        }
        else {
            _5719 = 1;
        }
        rhs_slice_target = (object_ptr)&_5720;
        RHS_Slice(_text_in_10144, _5718, _5719);
        Concat((object_ptr)&_text_in_10144, _5717, _5720);
        DeRefDS(_5717);
        _5717 = NOVALUE;
        DeRef(_5717);
        _5717 = NOVALUE;
        DeRefDS(_5720);
        _5720 = NOVALUE;
        goto L12; // [424] 434
L13: 

        /** 						pos += 1*/
        _pos_10213 = _pos_10213 + 1;
L12: 

        /** 				entry*/
LE: 

        /** 					pos = find(esc, text_in, pos)*/
        _pos_10213 = find_from(_esc_10148, _text_in_10144, _pos_10213);

        /** 				end while*/
        goto LF; // [446] 303
L10: 

        /** 				exit*/
        goto LB; // [453] 466
LD: 
LC: 

        /** 	end for*/
        _i_10183 = _i_10183 + 1;
        goto LA; // [461] 182
LB: 
        ;
    }

    /** 	return text_in*/
    DeRef(_quote_pairs_10145);
    _5673 = NOVALUE;
    _5676 = NOVALUE;
    _5688 = NOVALUE;
    DeRef(_5682);
    _5682 = NOVALUE;
    DeRef(_5690);
    _5690 = NOVALUE;
    _5693 = NOVALUE;
    DeRef(_5695);
    _5695 = NOVALUE;
    DeRef(_5704);
    _5704 = NOVALUE;
    DeRef(_5700);
    _5700 = NOVALUE;
    DeRef(_5716);
    _5716 = NOVALUE;
    DeRef(_5706);
    _5706 = NOVALUE;
    DeRef(_5712);
    _5712 = NOVALUE;
    DeRef(_5718);
    _5718 = NOVALUE;
    return _text_in_10144;
    ;
}


int  __stdcall _6format(int _format_pattern_10247, int _arg_list_10248)
{
    int _result_10249 = NOVALUE;
    int _in_token_10250 = NOVALUE;
    int _tch_10251 = NOVALUE;
    int _i_10252 = NOVALUE;
    int _tend_10253 = NOVALUE;
    int _cap_10254 = NOVALUE;
    int _align_10255 = NOVALUE;
    int _psign_10256 = NOVALUE;
    int _msign_10257 = NOVALUE;
    int _zfill_10258 = NOVALUE;
    int _bwz_10259 = NOVALUE;
    int _spacer_10260 = NOVALUE;
    int _alt_10261 = NOVALUE;
    int _width_10262 = NOVALUE;
    int _decs_10263 = NOVALUE;
    int _pos_10264 = NOVALUE;
    int _argn_10265 = NOVALUE;
    int _argl_10266 = NOVALUE;
    int _trimming_10267 = NOVALUE;
    int _hexout_10268 = NOVALUE;
    int _binout_10269 = NOVALUE;
    int _tsep_10270 = NOVALUE;
    int _istext_10271 = NOVALUE;
    int _prevargv_10272 = NOVALUE;
    int _currargv_10273 = NOVALUE;
    int _idname_10274 = NOVALUE;
    int _envsym_10275 = NOVALUE;
    int _envvar_10276 = NOVALUE;
    int _ep_10277 = NOVALUE;
    int _sp_10348 = NOVALUE;
    int _sp_10383 = NOVALUE;
    int _argtext_10430 = NOVALUE;
    int _tempv_10653 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_10708 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_10707 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_10715 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_10714 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_10713 = NOVALUE;
    int _msg_inlined_crash_at_2631_10737 = NOVALUE;
    int _dpos_10780 = NOVALUE;
    int _dist_10781 = NOVALUE;
    int _bracketed_10782 = NOVALUE;
    int _6131 = NOVALUE;
    int _6130 = NOVALUE;
    int _6129 = NOVALUE;
    int _6127 = NOVALUE;
    int _6126 = NOVALUE;
    int _6125 = NOVALUE;
    int _6122 = NOVALUE;
    int _6121 = NOVALUE;
    int _6118 = NOVALUE;
    int _6116 = NOVALUE;
    int _6113 = NOVALUE;
    int _6112 = NOVALUE;
    int _6111 = NOVALUE;
    int _6108 = NOVALUE;
    int _6105 = NOVALUE;
    int _6104 = NOVALUE;
    int _6103 = NOVALUE;
    int _6102 = NOVALUE;
    int _6099 = NOVALUE;
    int _6098 = NOVALUE;
    int _6097 = NOVALUE;
    int _6094 = NOVALUE;
    int _6092 = NOVALUE;
    int _6089 = NOVALUE;
    int _6088 = NOVALUE;
    int _6087 = NOVALUE;
    int _6086 = NOVALUE;
    int _6083 = NOVALUE;
    int _6078 = NOVALUE;
    int _6077 = NOVALUE;
    int _6076 = NOVALUE;
    int _6075 = NOVALUE;
    int _6069 = NOVALUE;
    int _6065 = NOVALUE;
    int _6064 = NOVALUE;
    int _6062 = NOVALUE;
    int _6060 = NOVALUE;
    int _6059 = NOVALUE;
    int _6058 = NOVALUE;
    int _6057 = NOVALUE;
    int _6056 = NOVALUE;
    int _6053 = NOVALUE;
    int _6050 = NOVALUE;
    int _6049 = NOVALUE;
    int _6046 = NOVALUE;
    int _6045 = NOVALUE;
    int _6044 = NOVALUE;
    int _6041 = NOVALUE;
    int _6039 = NOVALUE;
    int _6034 = NOVALUE;
    int _6033 = NOVALUE;
    int _6025 = NOVALUE;
    int _6021 = NOVALUE;
    int _6019 = NOVALUE;
    int _6018 = NOVALUE;
    int _6017 = NOVALUE;
    int _6014 = NOVALUE;
    int _6012 = NOVALUE;
    int _6011 = NOVALUE;
    int _6010 = NOVALUE;
    int _6008 = NOVALUE;
    int _6007 = NOVALUE;
    int _6006 = NOVALUE;
    int _6005 = NOVALUE;
    int _6002 = NOVALUE;
    int _6001 = NOVALUE;
    int _6000 = NOVALUE;
    int _5998 = NOVALUE;
    int _5997 = NOVALUE;
    int _5996 = NOVALUE;
    int _5995 = NOVALUE;
    int _5993 = NOVALUE;
    int _5991 = NOVALUE;
    int _5989 = NOVALUE;
    int _5987 = NOVALUE;
    int _5985 = NOVALUE;
    int _5983 = NOVALUE;
    int _5982 = NOVALUE;
    int _5981 = NOVALUE;
    int _5980 = NOVALUE;
    int _5979 = NOVALUE;
    int _5978 = NOVALUE;
    int _5976 = NOVALUE;
    int _5975 = NOVALUE;
    int _5973 = NOVALUE;
    int _5972 = NOVALUE;
    int _5970 = NOVALUE;
    int _5968 = NOVALUE;
    int _5967 = NOVALUE;
    int _5964 = NOVALUE;
    int _5962 = NOVALUE;
    int _5958 = NOVALUE;
    int _5956 = NOVALUE;
    int _5955 = NOVALUE;
    int _5954 = NOVALUE;
    int _5952 = NOVALUE;
    int _5951 = NOVALUE;
    int _5950 = NOVALUE;
    int _5949 = NOVALUE;
    int _5948 = NOVALUE;
    int _5946 = NOVALUE;
    int _5944 = NOVALUE;
    int _5943 = NOVALUE;
    int _5942 = NOVALUE;
    int _5941 = NOVALUE;
    int _5937 = NOVALUE;
    int _5934 = NOVALUE;
    int _5933 = NOVALUE;
    int _5930 = NOVALUE;
    int _5929 = NOVALUE;
    int _5928 = NOVALUE;
    int _5926 = NOVALUE;
    int _5925 = NOVALUE;
    int _5924 = NOVALUE;
    int _5923 = NOVALUE;
    int _5921 = NOVALUE;
    int _5919 = NOVALUE;
    int _5918 = NOVALUE;
    int _5917 = NOVALUE;
    int _5916 = NOVALUE;
    int _5915 = NOVALUE;
    int _5914 = NOVALUE;
    int _5912 = NOVALUE;
    int _5911 = NOVALUE;
    int _5910 = NOVALUE;
    int _5908 = NOVALUE;
    int _5907 = NOVALUE;
    int _5906 = NOVALUE;
    int _5905 = NOVALUE;
    int _5903 = NOVALUE;
    int _5900 = NOVALUE;
    int _5899 = NOVALUE;
    int _5897 = NOVALUE;
    int _5896 = NOVALUE;
    int _5894 = NOVALUE;
    int _5891 = NOVALUE;
    int _5890 = NOVALUE;
    int _5887 = NOVALUE;
    int _5885 = NOVALUE;
    int _5881 = NOVALUE;
    int _5879 = NOVALUE;
    int _5878 = NOVALUE;
    int _5877 = NOVALUE;
    int _5875 = NOVALUE;
    int _5873 = NOVALUE;
    int _5872 = NOVALUE;
    int _5871 = NOVALUE;
    int _5870 = NOVALUE;
    int _5869 = NOVALUE;
    int _5867 = NOVALUE;
    int _5865 = NOVALUE;
    int _5864 = NOVALUE;
    int _5863 = NOVALUE;
    int _5862 = NOVALUE;
    int _5860 = NOVALUE;
    int _5857 = NOVALUE;
    int _5855 = NOVALUE;
    int _5854 = NOVALUE;
    int _5852 = NOVALUE;
    int _5851 = NOVALUE;
    int _5850 = NOVALUE;
    int _5847 = NOVALUE;
    int _5846 = NOVALUE;
    int _5845 = NOVALUE;
    int _5844 = NOVALUE;
    int _5842 = NOVALUE;
    int _5841 = NOVALUE;
    int _5840 = NOVALUE;
    int _5839 = NOVALUE;
    int _5838 = NOVALUE;
    int _5835 = NOVALUE;
    int _5834 = NOVALUE;
    int _5833 = NOVALUE;
    int _5832 = NOVALUE;
    int _5830 = NOVALUE;
    int _5829 = NOVALUE;
    int _5828 = NOVALUE;
    int _5826 = NOVALUE;
    int _5825 = NOVALUE;
    int _5824 = NOVALUE;
    int _5822 = NOVALUE;
    int _5815 = NOVALUE;
    int _5813 = NOVALUE;
    int _5812 = NOVALUE;
    int _5805 = NOVALUE;
    int _5802 = NOVALUE;
    int _5798 = NOVALUE;
    int _5796 = NOVALUE;
    int _5795 = NOVALUE;
    int _5792 = NOVALUE;
    int _5790 = NOVALUE;
    int _5788 = NOVALUE;
    int _5785 = NOVALUE;
    int _5783 = NOVALUE;
    int _5782 = NOVALUE;
    int _5781 = NOVALUE;
    int _5780 = NOVALUE;
    int _5779 = NOVALUE;
    int _5776 = NOVALUE;
    int _5774 = NOVALUE;
    int _5773 = NOVALUE;
    int _5772 = NOVALUE;
    int _5769 = NOVALUE;
    int _5767 = NOVALUE;
    int _5765 = NOVALUE;
    int _5762 = NOVALUE;
    int _5761 = NOVALUE;
    int _5754 = NOVALUE;
    int _5751 = NOVALUE;
    int _5750 = NOVALUE;
    int _5743 = NOVALUE;
    int _5739 = NOVALUE;
    int _5736 = NOVALUE;
    int _5726 = NOVALUE;
    int _5724 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _5724 = IS_ATOM(_arg_list_10248);
    if (_5724 == 0)
    {
        _5724 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5724 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_10248;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_10248);
    *((int *)(_2+4)) = _arg_list_10248;
    _arg_list_10248 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_10249);
    _result_10249 = _5;

    /** 	in_token = 0*/
    _in_token_10250 = 0;

    /** 	i = 0*/
    _i_10252 = 0;

    /** 	tend = 0*/
    _tend_10253 = 0;

    /** 	argl = 0*/
    _argl_10266 = 0;

    /** 	spacer = 0*/
    _spacer_10260 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_10272);
    _prevargv_10272 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_10247)){
            _5726 = SEQ_PTR(_format_pattern_10247)->length;
    }
    else {
        _5726 = 1;
    }
    if (_i_10252 >= _5726)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_10252 = _i_10252 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_10247);
    _tch_10251 = (int)*(((s1_ptr)_2)->base + _i_10252);
    if (!IS_ATOM_INT(_tch_10251))
    _tch_10251 = (long)DBL_PTR(_tch_10251)->dbl;

    /**     	if not in_token then*/
    if (_in_token_10250 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_10251 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_10250 = 1;

    /**     			tend = 0*/
    _tend_10253 = 0;

    /** 				cap = 0*/
    _cap_10254 = 0;

    /** 				align = 0*/
    _align_10255 = 0;

    /** 				psign = 0*/
    _psign_10256 = 0;

    /** 				msign = 0*/
    _msign_10257 = 0;

    /** 				zfill = 0*/
    _zfill_10258 = 0;

    /** 				bwz = 0*/
    _bwz_10259 = 0;

    /** 				spacer = 0*/
    _spacer_10260 = 0;

    /** 				alt = 0*/
    _alt_10261 = 0;

    /**     			width = 0*/
    _width_10262 = 0;

    /**     			decs = -1*/
    _decs_10263 = -1;

    /**     			argn = 0*/
    _argn_10265 = 0;

    /**     			hexout = 0*/
    _hexout_10268 = 0;

    /**     			binout = 0*/
    _binout_10269 = 0;

    /**     			trimming = 0*/
    _trimming_10267 = 0;

    /**     			tsep = 0*/
    _tsep_10270 = 0;

    /**     			istext = 0*/
    _istext_10271 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_10274);
    _idname_10274 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_10276);
    _envvar_10276 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_10275);
    _envsym_10275 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_10249, _result_10249, _tch_10251);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_10251;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_10250 = 0;

        /**     				tend = i*/
        _tend_10253 = _i_10252;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_10249, _result_10249, _tch_10251);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5736 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5736 = 1;
        }
        if (_i_10252 >= _5736)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5739 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5739, 93)){
            _5739 = NOVALUE;
            goto L7; // [267] 248
        }
        _5739 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_10250 = 0;

        /** 	    					tend = 0*/
        _tend_10253 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_10254 = _tch_10251;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_10259 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_10260 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_10267 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_10258 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_10268 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_10269 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_10255 = _tch_10251;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_10256 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_10257 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_10261 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_10271 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5743 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5743 = 1;
        }
        if (_i_10252 >= _5743)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _tch_10251 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (!IS_ATOM_INT(_tch_10251))
        _tch_10251 = (long)DBL_PTR(_tch_10251)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10264 = find_from(_tch_10251, _1382, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10264 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_10252 = _i_10252 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_10262 == (short)_width_10262)
        _5750 = _width_10262 * 10;
        else
        _5750 = NewDouble(_width_10262 * (double)10);
        if (IS_ATOM_INT(_5750)) {
            _5751 = _5750 + _pos_10264;
            if ((long)((unsigned long)_5751 + (unsigned long)HIGH_BITS) >= 0) 
            _5751 = NewDouble((double)_5751);
        }
        else {
            _5751 = NewDouble(DBL_PTR(_5750)->dbl + (double)_pos_10264);
        }
        DeRef(_5750);
        _5750 = NOVALUE;
        if (IS_ATOM_INT(_5751)) {
            _width_10262 = _5751 - 1;
        }
        else {
            _width_10262 = NewDouble(DBL_PTR(_5751)->dbl - (double)1);
        }
        DeRef(_5751);
        _5751 = NOVALUE;
        if (!IS_ATOM_INT(_width_10262)) {
            _1 = (long)(DBL_PTR(_width_10262)->dbl);
            DeRefDS(_width_10262);
            _width_10262 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_10262 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_10258 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_10263 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5754 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5754 = 1;
        }
        if (_i_10252 >= _5754)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _tch_10251 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (!IS_ATOM_INT(_tch_10251))
        _tch_10251 = (long)DBL_PTR(_tch_10251)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10264 = find_from(_tch_10251, _1382, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10264 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_10252 = _i_10252 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_10263 == (short)_decs_10263)
        _5761 = _decs_10263 * 10;
        else
        _5761 = NewDouble(_decs_10263 * (double)10);
        if (IS_ATOM_INT(_5761)) {
            _5762 = _5761 + _pos_10264;
            if ((long)((unsigned long)_5762 + (unsigned long)HIGH_BITS) >= 0) 
            _5762 = NewDouble((double)_5762);
        }
        else {
            _5762 = NewDouble(DBL_PTR(_5761)->dbl + (double)_pos_10264);
        }
        DeRef(_5761);
        _5761 = NOVALUE;
        if (IS_ATOM_INT(_5762)) {
            _decs_10263 = _5762 - 1;
        }
        else {
            _decs_10263 = NewDouble(DBL_PTR(_5762)->dbl - (double)1);
        }
        DeRef(_5762);
        _5762 = NOVALUE;
        if (!IS_ATOM_INT(_decs_10263)) {
            _1 = (long)(DBL_PTR(_decs_10263)->dbl);
            DeRefDS(_decs_10263);
            _decs_10263 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10348 = _i_10252 + 1;

        /** 	    			i = sp*/
        _i_10252 = _sp_10348;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5765 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5765 = 1;
        }
        if (_i_10252 >= _5765)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5767 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5767, 125)){
            _5767 = NOVALUE;
            goto LE; // [637] 646
        }
        _5767 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5769 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5769, 93)){
            _5769 = NOVALUE;
            goto LF; // [652] 661
        }
        _5769 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5772 = _i_10252 - 1;
        rhs_slice_target = (object_ptr)&_5773;
        RHS_Slice(_format_pattern_10247, _sp_10348, _5772);
        RefDS(_4563);
        _5774 = _6trim(_5773, _4563, 0);
        _5773 = NOVALUE;
        if (IS_SEQUENCE(_5774) && IS_ATOM(61)) {
            Append(&_idname_10274, _5774, 61);
        }
        else if (IS_ATOM(_5774) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_10274, _5774, 61);
            DeRef(_5774);
            _5774 = NOVALUE;
        }
        DeRef(_5774);
        _5774 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5776 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5776, 93)){
            _5776 = NOVALUE;
            goto L10; // [699] 710
        }
        _5776 = NOVALUE;

        /**     					i -= 1*/
        _i_10252 = _i_10252 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_10248)){
                _5779 = SEQ_PTR(_arg_list_10248)->length;
        }
        else {
            _5779 = 1;
        }
        {
            int _j_10369;
            _j_10369 = 1;
L11: 
            if (_j_10369 > _5779){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10248);
            _5780 = (int)*(((s1_ptr)_2)->base + _j_10369);
            _5781 = IS_SEQUENCE(_5780);
            _5780 = NOVALUE;
            if (_5781 == 0)
            {
                _5781 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5781 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10248);
            _5782 = (int)*(((s1_ptr)_2)->base + _j_10369);
            RefDS(_idname_10274);
            Ref(_5782);
            _5783 = _9begins(_idname_10274, _5782);
            _5782 = NOVALUE;
            if (_5783 == 0) {
                DeRef(_5783);
                _5783 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5783) && DBL_PTR(_5783)->dbl == 0.0){
                    DeRef(_5783);
                    _5783 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5783);
                _5783 = NOVALUE;
            }
            DeRef(_5783);
            _5783 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_10265 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_10265 = _j_10369;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_10248)){
                    _5785 = SEQ_PTR(_arg_list_10248)->length;
            }
            else {
                _5785 = 1;
            }
            if (_j_10369 != _5785)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_10274);
            _idname_10274 = _5;

            /**     						argn = -1*/
            _argn_10265 = -1;
L16: 

            /**     				end for*/
            _j_10369 = _j_10369 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10383 = _i_10252 + 1;

        /** 	    			i = sp*/
        _i_10252 = _sp_10383;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5788 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5788 = 1;
        }
        if (_i_10252 >= _5788)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5790 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5790, 37)){
            _5790 = NOVALUE;
            goto L19; // [836] 845
        }
        _5790 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5792 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5792, 93)){
            _5792 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5792 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _5795 = _i_10252 - 1;
        rhs_slice_target = (object_ptr)&_5796;
        RHS_Slice(_format_pattern_10247, _sp_10383, _5795);
        RefDS(_4563);
        _0 = _envsym_10275;
        _envsym_10275 = _6trim(_5796, _4563, 0);
        DeRef(_0);
        _5796 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _5798 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (binary_op_a(NOTEQ, _5798, 93)){
            _5798 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5798 = NOVALUE;

        /**     					i -= 1*/
        _i_10252 = _i_10252 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_10276);
        _envvar_10276 = EGetEnv(_envsym_10275);

        /**     				argn = -1*/
        _argn_10265 = -1;

        /**     				if atom(envvar) then*/
        _5802 = IS_ATOM(_envvar_10276);
        if (_5802 == 0)
        {
            _5802 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5802 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_10276);
        _envvar_10276 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_10265 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_10252 = _i_10252 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5805 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5805 = 1;
        }
        if (_i_10252 >= _5805)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_10252 = _i_10252 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _tch_10251 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (!IS_ATOM_INT(_tch_10251))
        _tch_10251 = (long)DBL_PTR(_tch_10251)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_10264 = find_from(_tch_10251, _1382, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_10264 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_10252 = _i_10252 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_10265 == (short)_argn_10265)
        _5812 = _argn_10265 * 10;
        else
        _5812 = NewDouble(_argn_10265 * (double)10);
        if (IS_ATOM_INT(_5812)) {
            _5813 = _5812 + _pos_10264;
            if ((long)((unsigned long)_5813 + (unsigned long)HIGH_BITS) >= 0) 
            _5813 = NewDouble((double)_5813);
        }
        else {
            _5813 = NewDouble(DBL_PTR(_5812)->dbl + (double)_pos_10264);
        }
        DeRef(_5812);
        _5812 = NOVALUE;
        if (IS_ATOM_INT(_5813)) {
            _argn_10265 = _5813 - 1;
        }
        else {
            _argn_10265 = NewDouble(DBL_PTR(_5813)->dbl - (double)1);
        }
        DeRef(_5813);
        _5813 = NOVALUE;
        if (!IS_ATOM_INT(_argn_10265)) {
            _1 = (long)(DBL_PTR(_argn_10265)->dbl);
            DeRefDS(_argn_10265);
            _argn_10265 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_10247)){
                _5815 = SEQ_PTR(_format_pattern_10247)->length;
        }
        else {
            _5815 = 1;
        }
        if (_i_10252 >= _5815)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_10252 = _i_10252 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10247);
        _tsep_10270 = (int)*(((s1_ptr)_2)->base + _i_10252);
        if (!IS_ATOM_INT(_tsep_10270))
        _tsep_10270 = (long)DBL_PTR(_tsep_10270)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_10253 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10430);
    _argtext_10430 = _5;

    /**     			if argn = 0 then*/
    if (_argn_10265 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_10265 = _argl_10266 + 1;
L20: 

    /**     			argl = argn*/
    _argl_10266 = _argn_10265;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _5822 = (_argn_10265 < 1);
    if (_5822 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_10248)){
            _5824 = SEQ_PTR(_arg_list_10248)->length;
    }
    else {
        _5824 = 1;
    }
    _5825 = (_argn_10265 > _5824);
    _5824 = NOVALUE;
    if (_5825 == 0)
    {
        DeRef(_5825);
        _5825 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5825);
        _5825 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_10276)){
            _5826 = SEQ_PTR(_envvar_10276)->length;
    }
    else {
        _5826 = 1;
    }
    if (_5826 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_10276);
    DeRef(_argtext_10430);
    _argtext_10430 = _envvar_10276;

    /** 	    				currargv = envvar*/
    Ref(_envvar_10276);
    DeRef(_currargv_10273);
    _currargv_10273 = _envvar_10276;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10430);
    _argtext_10430 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_10273);
    _currargv_10273 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5828 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    Ref(_5828);
    _5829 = _7string(_5828);
    _5828 = NOVALUE;
    if (_5829 == 0) {
        DeRef(_5829);
        _5829 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5829) && DBL_PTR(_5829)->dbl == 0.0){
            DeRef(_5829);
            _5829 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5829);
        _5829 = NOVALUE;
    }
    DeRef(_5829);
    _5829 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_10274)){
            _5830 = SEQ_PTR(_idname_10274)->length;
    }
    else {
        _5830 = 1;
    }
    if (_5830 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5832 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (IS_SEQUENCE(_idname_10274)){
            _5833 = SEQ_PTR(_idname_10274)->length;
    }
    else {
        _5833 = 1;
    }
    _5834 = _5833 + 1;
    _5833 = NOVALUE;
    if (IS_SEQUENCE(_5832)){
            _5835 = SEQ_PTR(_5832)->length;
    }
    else {
        _5835 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_5832, _5834, _5835);
    _5832 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_10430);
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _argtext_10430 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    Ref(_argtext_10430);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5838 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (IS_ATOM_INT(_5838))
    _5839 = 1;
    else if (IS_ATOM_DBL(_5838))
    _5839 = IS_ATOM_INT(DoubleToInt(_5838));
    else
    _5839 = 0;
    _5838 = NOVALUE;
    if (_5839 == 0)
    {
        _5839 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _5839 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10271 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5840 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    Ref(_5840);
    _5841 = _20abs(_5840);
    _5840 = NOVALUE;
    _5842 = binary_op(AND_BITS, _2228, _5841);
    DeRef(_5841);
    _5841 = NOVALUE;
    _0 = _argtext_10430;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5842;
    _argtext_10430 = MAKE_SEQ(_1);
    DeRef(_0);
    _5842 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5844 = (_bwz_10259 != 0);
    if (_5844 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5846 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (IS_ATOM_INT(_5846)) {
        _5847 = (_5846 == 0);
    }
    else {
        _5847 = binary_op(EQUALS, _5846, 0);
    }
    _5846 = NOVALUE;
    if (_5847 == 0) {
        DeRef(_5847);
        _5847 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_5847) && DBL_PTR(_5847)->dbl == 0.0){
            DeRef(_5847);
            _5847 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_5847);
        _5847 = NOVALUE;
    }
    DeRef(_5847);
    _5847 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_10430);
    _argtext_10430 = Repeat(32, _width_10262);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_10269 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5850 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    Ref(_5850);
    _5851 = _8int_to_bits(_5850, 32);
    _5850 = NOVALUE;
    _5852 = _23reverse(_5851, 1, 0);
    _5851 = NOVALUE;
    DeRef(_argtext_10430);
    if (IS_ATOM_INT(_5852)) {
        _argtext_10430 = _5852 + 48;
        if ((long)((unsigned long)_argtext_10430 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_10430 = NewDouble((double)_argtext_10430);
    }
    else {
        _argtext_10430 = binary_op(PLUS, _5852, 48);
    }
    DeRef(_5852);
    _5852 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5854 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5854 = 1;
    }
    {
        int _ib_10479;
        _ib_10479 = 1;
L2C: 
        if (_ib_10479 > _5854){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_10430);
        _5855 = (int)*(((s1_ptr)_2)->base + _ib_10479);
        if (binary_op_a(NOTEQ, _5855, 49)){
            _5855 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _5855 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_10430)){
                _5857 = SEQ_PTR(_argtext_10430)->length;
        }
        else {
            _5857 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_10430;
        RHS_Slice(_argtext_10430, _ib_10479, _5857);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_10479 = _ib_10479 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_10268 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5860 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_argtext_10430);
    _argtext_10430 = EPrintf(-9999999, _919, _5860);
    _5860 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5862 = (_zfill_10258 != 0);
    if (_5862 == 0) {
        goto L30; // [1408] 1505
    }
    _5864 = (_width_10262 > 0);
    if (_5864 == 0)
    {
        DeRef(_5864);
        _5864 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_5864);
        _5864 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5865 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5865, 45)){
        _5865 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _5865 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5867 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5867 = 1;
    }
    if (_width_10262 <= _5867)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5869 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5869 = 1;
    }
    _5870 = _width_10262 - _5869;
    _5869 = NOVALUE;
    _5871 = Repeat(48, _5870);
    _5870 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10430)){
            _5872 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5872 = 1;
    }
    rhs_slice_target = (object_ptr)&_5873;
    RHS_Slice(_argtext_10430, 2, _5872);
    {
        int concat_list[3];

        concat_list[0] = _5873;
        concat_list[1] = _5871;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5873);
    _5873 = NOVALUE;
    DeRefDS(_5871);
    _5871 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5875 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5875 = 1;
    }
    if (_width_10262 <= _5875)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5877 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5877 = 1;
    }
    _5878 = _width_10262 - _5877;
    _5877 = NOVALUE;
    _5879 = Repeat(48, _5878);
    _5878 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _5879, _argtext_10430);
    DeRefDS(_5879);
    _5879 = NOVALUE;
    DeRef(_5879);
    _5879 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5881 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (binary_op_a(LESSEQ, _5881, 0)){
        _5881 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _5881 = NOVALUE;

    /** 								if psign then*/
    if (_psign_10256 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10258 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_10430, _argtext_10430, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5885 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5885, 48)){
        _5885 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _5885 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10430 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5887 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (binary_op_a(GREATEREQ, _5887, 0)){
        _5887 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _5887 = NOVALUE;

    /** 								if msign then*/
    if (_msign_10257 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10258 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5890 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5890 = 1;
    }
    rhs_slice_target = (object_ptr)&_5891;
    RHS_Slice(_argtext_10430, 2, _5890);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5891;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5891);
    _5891 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5894 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5894, 48)){
        _5894 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _5894 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5896 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5896 = 1;
    }
    rhs_slice_target = (object_ptr)&_5897;
    RHS_Slice(_argtext_10430, 3, _5896);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5897;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5897);
    _5897 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5899 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5899 = 1;
    }
    rhs_slice_target = (object_ptr)&_5900;
    RHS_Slice(_argtext_10430, 2, _5899);
    Append(&_argtext_10430, _5900, 41);
    DeRefDS(_5900);
    _5900 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5903 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_argtext_10430);
    _argtext_10430 = EPrintf(-9999999, _5902, _5903);
    _5903 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5905 = (_zfill_10258 != 0);
    if (_5905 == 0) {
        goto L27; // [1670] 2546
    }
    _5907 = (_width_10262 > 0);
    if (_5907 == 0)
    {
        DeRef(_5907);
        _5907 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_5907);
        _5907 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5908 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5908 = 1;
    }
    if (_width_10262 <= _5908)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5910 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5910 = 1;
    }
    _5911 = _width_10262 - _5910;
    _5910 = NOVALUE;
    _5912 = Repeat(48, _5911);
    _5911 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _5912, _argtext_10430);
    DeRefDS(_5912);
    _5912 = NOVALUE;
    DeRef(_5912);
    _5912 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5914 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    _5915 = IS_ATOM(_5914);
    _5914 = NOVALUE;
    if (_5915 == 0)
    {
        _5915 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _5915 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10271 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5916 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (IS_ATOM_INT(_5916))
    _5917 = e_floor(_5916);
    else
    _5917 = unary_op(FLOOR, _5916);
    _5916 = NOVALUE;
    _5918 = _20abs(_5917);
    _5917 = NOVALUE;
    _5919 = binary_op(AND_BITS, _2228, _5918);
    DeRef(_5918);
    _5918 = NOVALUE;
    _0 = _argtext_10430;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5919;
    _argtext_10430 = MAKE_SEQ(_1);
    DeRef(_0);
    _5919 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_10268 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5921 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_argtext_10430);
    _argtext_10430 = EPrintf(-9999999, _5902, _5921);
    _5921 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _5923 = (_zfill_10258 != 0);
    if (_5923 == 0) {
        goto L27; // [1786] 2546
    }
    _5925 = (_width_10262 > 0);
    if (_5925 == 0)
    {
        DeRef(_5925);
        _5925 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_5925);
        _5925 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5926 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5926 = 1;
    }
    if (_width_10262 <= _5926)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5928 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5928 = 1;
    }
    _5929 = _width_10262 - _5928;
    _5928 = NOVALUE;
    _5930 = Repeat(48, _5929);
    _5929 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _5930, _argtext_10430);
    DeRefDS(_5930);
    _5930 = NOVALUE;
    DeRef(_5930);
    _5930 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5933 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    _5934 = EPrintf(-9999999, _5932, _5933);
    _5933 = NOVALUE;
    RefDS(_4563);
    _0 = _argtext_10430;
    _argtext_10430 = _6trim(_5934, _4563, 0);
    DeRef(_0);
    _5934 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_10277 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _5937 = _ep_10277 + 2;
    if ((long)((unsigned long)_5937 + (unsigned long)HIGH_BITS) >= 0) 
    _5937 = NewDouble((double)_5937);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10430);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5937)) ? _5937 : (long)(DBL_PTR(_5937)->dbl);
        int stop = (IS_ATOM_INT(_5937)) ? _5937 : (long)(DBL_PTR(_5937)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10430), start, &_argtext_10430 );
            }
            else Tail(SEQ_PTR(_argtext_10430), stop+1, &_argtext_10430);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10430), start, &_argtext_10430);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10430 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10430)->ref == 1));
        }
    }
    DeRef(_5937);
    _5937 = NOVALUE;
    _5937 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_10277 = e_match_from(_5939, _argtext_10430, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _5941 = (_zfill_10258 != 0);
    if (_5941 == 0) {
        goto L3E; // [1896] 1981
    }
    _5943 = (_width_10262 > 0);
    if (_5943 == 0)
    {
        DeRef(_5943);
        _5943 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_5943);
        _5943 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5944 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5944 = 1;
    }
    if (_width_10262 <= _5944)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5946 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5946, 45)){
        _5946 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _5946 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5948 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5948 = 1;
    }
    _5949 = _width_10262 - _5948;
    _5948 = NOVALUE;
    _5950 = Repeat(48, _5949);
    _5949 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10430)){
            _5951 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5951 = 1;
    }
    rhs_slice_target = (object_ptr)&_5952;
    RHS_Slice(_argtext_10430, 2, _5951);
    {
        int concat_list[3];

        concat_list[0] = _5952;
        concat_list[1] = _5950;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5952);
    _5952 = NOVALUE;
    DeRefDS(_5950);
    _5950 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5954 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5954 = 1;
    }
    _5955 = _width_10262 - _5954;
    _5954 = NOVALUE;
    _5956 = Repeat(48, _5955);
    _5955 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _5956, _argtext_10430);
    DeRefDS(_5956);
    _5956 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5958 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (binary_op_a(LESSEQ, _5958, 0)){
        _5958 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _5958 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_10256 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10258 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_10430, _argtext_10430, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5962 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5962, 48)){
        _5962 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _5962 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10430 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5964 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (binary_op_a(GREATEREQ, _5964, 0)){
        _5964 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _5964 = NOVALUE;

    /** 									if msign then*/
    if (_msign_10257 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10258 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5967 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5967 = 1;
    }
    rhs_slice_target = (object_ptr)&_5968;
    RHS_Slice(_argtext_10430, 2, _5967);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5968;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5968);
    _5968 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _5970 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5970, 48)){
        _5970 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _5970 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5972 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5972 = 1;
    }
    rhs_slice_target = (object_ptr)&_5973;
    RHS_Slice(_argtext_10430, 3, _5972);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5973;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_5973);
    _5973 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10430)){
            _5975 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _5975 = 1;
    }
    rhs_slice_target = (object_ptr)&_5976;
    RHS_Slice(_argtext_10430, 2, _5975);
    Append(&_argtext_10430, _5976, 41);
    DeRefDS(_5976);
    _5976 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5978 = (_alt_10261 != 0);
    if (_5978 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5980 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    if (IS_SEQUENCE(_5980)){
            _5981 = SEQ_PTR(_5980)->length;
    }
    else {
        _5981 = 1;
    }
    _5980 = NOVALUE;
    _5982 = (_5981 == 2);
    _5981 = NOVALUE;
    if (_5982 == 0)
    {
        DeRef(_5982);
        _5982 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_5982);
        _5982 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _5983 = IS_ATOM(_prevargv_10272);
    if (_5983 == 0)
    {
        _5983 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _5983 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_10272, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5985 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_tempv_10653);
    _2 = (int)SEQ_PTR(_5985);
    _tempv_10653 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10653);
    _5985 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5987 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_tempv_10653);
    _2 = (int)SEQ_PTR(_5987);
    _tempv_10653 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10653);
    _5987 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_10272)){
            _5989 = SEQ_PTR(_prevargv_10272)->length;
    }
    else {
        _5989 = 1;
    }
    if (_5989 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5991 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_tempv_10653);
    _2 = (int)SEQ_PTR(_5991);
    _tempv_10653 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10653);
    _5991 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _5993 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    DeRef(_tempv_10653);
    _2 = (int)SEQ_PTR(_5993);
    _tempv_10653 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10653);
    _5993 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_10653);
    _5995 = _7string(_tempv_10653);
    if (_5995 == 0) {
        DeRef(_5995);
        _5995 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_5995) && DBL_PTR(_5995)->dbl == 0.0){
            DeRef(_5995);
            _5995 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_5995);
        _5995 = NOVALUE;
    }
    DeRef(_5995);
    _5995 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_10653);
    DeRef(_argtext_10430);
    _argtext_10430 = _tempv_10653;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_10653))
    _5996 = 1;
    else if (IS_ATOM_DBL(_tempv_10653))
    _5996 = IS_ATOM_INT(DoubleToInt(_tempv_10653));
    else
    _5996 = 0;
    if (_5996 == 0)
    {
        _5996 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _5996 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10271 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_10653);
    _5997 = _20abs(_tempv_10653);
    _5998 = binary_op(AND_BITS, _2228, _5997);
    DeRef(_5997);
    _5997 = NOVALUE;
    _0 = _argtext_10430;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5998;
    _argtext_10430 = MAKE_SEQ(_1);
    DeRef(_0);
    _5998 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _6000 = (_bwz_10259 != 0);
    if (_6000 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_10653)) {
        _6002 = (_tempv_10653 == 0);
    }
    else {
        _6002 = binary_op(EQUALS, _tempv_10653, 0);
    }
    if (_6002 == 0) {
        DeRef(_6002);
        _6002 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_6002) && DBL_PTR(_6002)->dbl == 0.0){
            DeRef(_6002);
            _6002 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_6002);
        _6002 = NOVALUE;
    }
    DeRef(_6002);
    _6002 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10430);
    _argtext_10430 = Repeat(32, _width_10262);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_10430);
    _argtext_10430 = EPrintf(-9999999, _919, _tempv_10653);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _6005 = IS_ATOM(_tempv_10653);
    if (_6005 == 0)
    {
        _6005 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _6005 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10271 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_10653))
    _6006 = e_floor(_tempv_10653);
    else
    _6006 = unary_op(FLOOR, _tempv_10653);
    _6007 = _20abs(_6006);
    _6006 = NOVALUE;
    _6008 = binary_op(AND_BITS, _2228, _6007);
    DeRef(_6007);
    _6007 = NOVALUE;
    _0 = _argtext_10430;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _6008;
    _argtext_10430 = MAKE_SEQ(_1);
    DeRef(_0);
    _6008 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _6010 = (_bwz_10259 != 0);
    if (_6010 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_10653)) {
        _6012 = (_tempv_10653 == 0);
    }
    else {
        _6012 = binary_op(EQUALS, _tempv_10653, 0);
    }
    if (_6012 == 0) {
        DeRef(_6012);
        _6012 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_6012) && DBL_PTR(_6012)->dbl == 0.0){
            DeRef(_6012);
            _6012 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_6012);
        _6012 = NOVALUE;
    }
    DeRef(_6012);
    _6012 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10430);
    _argtext_10430 = Repeat(32, _width_10262);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _6014 = EPrintf(-9999999, _5932, _tempv_10653);
    RefDS(_4563);
    _0 = _argtext_10430;
    _argtext_10430 = _6trim(_6014, _4563, 0);
    DeRef(_0);
    _6014 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_6016);
    *((int *)(_2+24)) = _6016;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _6017 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_10707);
    _options_inlined_pretty_sprint_at_2424_10707 = _6017;
    _6017 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_8698 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_10653);
    RefDS(_options_inlined_pretty_sprint_at_2424_10707);
    _26pretty(_tempv_10653, _options_inlined_pretty_sprint_at_2424_10707);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8701);
    DeRef(_argtext_10430);
    _argtext_10430 = _26pretty_line_8701;
    DeRef(_options_inlined_pretty_sprint_at_2424_10707);
    _options_inlined_pretty_sprint_at_2424_10707 = NOVALUE;
L4D: 
    DeRef(_tempv_10653);
    _tempv_10653 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _6018 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_6016);
    *((int *)(_2+24)) = _6016;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _6019 = MAKE_SEQ(_1);
    Ref(_6018);
    DeRef(_x_inlined_pretty_sprint_at_2477_10713);
    _x_inlined_pretty_sprint_at_2477_10713 = _6018;
    _6018 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10714);
    _options_inlined_pretty_sprint_at_2480_10714 = _6019;
    _6019 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_8698 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_10713);
    RefDS(_options_inlined_pretty_sprint_at_2480_10714);
    _26pretty(_x_inlined_pretty_sprint_at_2477_10713, _options_inlined_pretty_sprint_at_2480_10714);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_8701);
    DeRef(_argtext_10430);
    _argtext_10430 = _26pretty_line_8701;
    DeRef(_x_inlined_pretty_sprint_at_2477_10713);
    _x_inlined_pretty_sprint_at_2477_10713 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10714);
    _options_inlined_pretty_sprint_at_2480_10714 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_10277 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _6021 = _ep_10277 + 2;
    if ((long)((unsigned long)_6021 + (unsigned long)HIGH_BITS) >= 0) 
    _6021 = NewDouble((double)_6021);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10430);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_6021)) ? _6021 : (long)(DBL_PTR(_6021)->dbl);
        int stop = (IS_ATOM_INT(_6021)) ? _6021 : (long)(DBL_PTR(_6021)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10430), start, &_argtext_10430 );
            }
            else Tail(SEQ_PTR(_argtext_10430), stop+1, &_argtext_10430);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10430), start, &_argtext_10430);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10430 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10430)->ref == 1));
        }
    }
    DeRef(_6021);
    _6021 = NOVALUE;
    _6021 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_10277 = e_match_from(_5939, _argtext_10430, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_10273);
    _2 = (int)SEQ_PTR(_arg_list_10248);
    _currargv_10273 = (int)*(((s1_ptr)_2)->base + _argn_10265);
    Ref(_currargv_10273);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6025 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6025 = 1;
    }
    if (_6025 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_10254;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_10430);
        _0 = _argtext_10430;
        _argtext_10430 = _6upper(_argtext_10430);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_10430);
        _0 = _argtext_10430;
        _argtext_10430 = _6lower(_argtext_10430);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_10430);
        _0 = _argtext_10430;
        _argtext_10430 = _6proper(_argtext_10430);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_10254 = _cap_10254;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_10737);
        _msg_inlined_crash_at_2631_10737 = EPrintf(-9999999, _6032, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_10737);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_10737);
        _msg_inlined_crash_at_2631_10737 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _6033 = IS_ATOM(_currargv_10273);
    if (_6033 == 0)
    {
        _6033 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _6033 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _6034 = find_from(101, _argtext_10430, 1);
    if (_6034 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_10263 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_10264 = find_from(46, _argtext_10430, 1);

    /** 								if pos then*/
    if (_pos_10264 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_10263 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _6039 = _pos_10264 - 1;
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, 1, _6039);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6041 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6041 = 1;
    }
    _pos_10264 = _6041 - _pos_10264;
    _6041 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_10264 <= _decs_10263)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6044 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6044 = 1;
    }
    _6045 = _6044 - _pos_10264;
    if ((long)((unsigned long)_6045 +(unsigned long) HIGH_BITS) >= 0){
        _6045 = NewDouble((double)_6045);
    }
    _6044 = NOVALUE;
    if (IS_ATOM_INT(_6045)) {
        _6046 = _6045 + _decs_10263;
    }
    else {
        _6046 = NewDouble(DBL_PTR(_6045)->dbl + (double)_decs_10263);
    }
    DeRef(_6045);
    _6045 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, 1, _6046);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_10264 >= _decs_10263)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _6049 = _decs_10263 - _pos_10264;
    _6050 = Repeat(48, _6049);
    _6049 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _argtext_10430, _6050);
    DeRefDS(_6050);
    _6050 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_10263 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _6053 = Repeat(48, _decs_10263);
    {
        int concat_list[3];

        concat_list[0] = _6053;
        concat_list[1] = 46;
        concat_list[2] = _argtext_10430;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_6053);
    _6053 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_10255 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _6056 = IS_ATOM(_currargv_10273);
    if (_6056 == 0)
    {
        _6056 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _6056 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_10255 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_10255 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _6057 = IS_ATOM(_currargv_10273);
    if (_6057 == 0)
    {
        _6057 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _6057 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _6058 = (_tsep_10270 != 0);
    if (_6058 == 0) {
        goto L66; // [2842] 3029
    }
    _6060 = (_zfill_10258 == 0);
    if (_6060 == 0)
    {
        DeRef(_6060);
        _6060 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_6060);
        _6060 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_10269 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_10268 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_10781 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_10781 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    _6062 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6062)) {
        _bracketed_10782 = (_6062 == 40);
    }
    else {
        _bracketed_10782 = binary_op(EQUALS, _6062, 40);
    }
    _6062 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_10782)) {
        _1 = (long)(DBL_PTR(_bracketed_10782)->dbl);
        DeRefDS(_bracketed_10782);
        _bracketed_10782 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_10782 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6064 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6064 = 1;
    }
    _6065 = _6064 - 1;
    _6064 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, 2, _6065);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_10780 = find_from(46, _argtext_10430, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_10780 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6069 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6069 = 1;
    }
    _dpos_10780 = _6069 + 1;
    _6069 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_10270 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_10430);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10430 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_10780);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_10780 <= _dist_10781)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_10780 = _dpos_10780 - _dist_10781;

    /** 	    						if dpos > 1 then*/
    if (_dpos_10780 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _6075 = _dpos_10780 - 1;
    rhs_slice_target = (object_ptr)&_6076;
    RHS_Slice(_argtext_10430, 1, _6075);
    if (IS_SEQUENCE(_argtext_10430)){
            _6077 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6077 = 1;
    }
    rhs_slice_target = (object_ptr)&_6078;
    RHS_Slice(_argtext_10430, _dpos_10780, _6077);
    {
        int concat_list[3];

        concat_list[0] = _6078;
        concat_list[1] = _tsep_10270;
        concat_list[2] = _6076;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_6078);
    _6078 = NOVALUE;
    DeRefDS(_6076);
    _6076 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_10782 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_10430;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_10262 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_10430)){
            _width_10262 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _width_10262 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6083 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6083 = 1;
    }
    if (_width_10262 >= _6083)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_10255 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6086 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6086 = 1;
    }
    _6087 = _6086 - _width_10262;
    if ((long)((unsigned long)_6087 +(unsigned long) HIGH_BITS) >= 0){
        _6087 = NewDouble((double)_6087);
    }
    _6086 = NOVALUE;
    if (IS_ATOM_INT(_6087)) {
        _6088 = _6087 + 1;
        if (_6088 > MAXINT){
            _6088 = NewDouble((double)_6088);
        }
    }
    else
    _6088 = binary_op(PLUS, 1, _6087);
    DeRef(_6087);
    _6087 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10430)){
            _6089 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6089 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, _6088, _6089);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_10255 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6092 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6092 = 1;
    }
    _pos_10264 = _6092 - _width_10262;
    _6092 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _6094 = (_pos_10264 % 2);
    if (_6094 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_10264 & 1) {
        _pos_10264 = NewDouble((_pos_10264 >> 1) + 0.5);
    }
    else
    _pos_10264 = _pos_10264 >> 1;
    if (!IS_ATOM_INT(_pos_10264)) {
        _1 = (long)(DBL_PTR(_pos_10264)->dbl);
        DeRefDS(_pos_10264);
        _pos_10264 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _6097 = _pos_10264 + 1;
    if (_6097 > MAXINT){
        _6097 = NewDouble((double)_6097);
    }
    if (IS_SEQUENCE(_argtext_10430)){
            _6098 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6098 = 1;
    }
    _6099 = _6098 - _pos_10264;
    _6098 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, _6097, _6099);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_10264 = _pos_10264 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _6102 = _pos_10264 + 1;
    if (_6102 > MAXINT){
        _6102 = NewDouble((double)_6102);
    }
    if (IS_SEQUENCE(_argtext_10430)){
            _6103 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6103 = 1;
    }
    _6104 = _6103 - _pos_10264;
    if ((long)((unsigned long)_6104 +(unsigned long) HIGH_BITS) >= 0){
        _6104 = NewDouble((double)_6104);
    }
    _6103 = NOVALUE;
    if (IS_ATOM_INT(_6104)) {
        _6105 = _6104 - 1;
    }
    else {
        _6105 = NewDouble(DBL_PTR(_6104)->dbl - (double)1);
    }
    DeRef(_6104);
    _6104 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, _6102, _6105);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_10430;
    RHS_Slice(_argtext_10430, 1, _width_10262);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6108 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6108 = 1;
    }
    if (_width_10262 <= _6108)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_10255 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6111 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6111 = 1;
    }
    _6112 = _width_10262 - _6111;
    _6111 = NOVALUE;
    _6113 = Repeat(32, _6112);
    _6112 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _6113, _argtext_10430);
    DeRefDS(_6113);
    _6113 = NOVALUE;
    DeRef(_6113);
    _6113 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_10255 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6116 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6116 = 1;
    }
    _pos_10264 = _width_10262 - _6116;
    _6116 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _6118 = (_pos_10264 % 2);
    if (_6118 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_10264 & 1) {
        _pos_10264 = NewDouble((_pos_10264 >> 1) + 0.5);
    }
    else
    _pos_10264 = _pos_10264 >> 1;
    if (!IS_ATOM_INT(_pos_10264)) {
        _1 = (long)(DBL_PTR(_pos_10264)->dbl);
        DeRefDS(_pos_10264);
        _pos_10264 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _6121 = Repeat(32, _pos_10264);
    _6122 = Repeat(32, _pos_10264);
    {
        int concat_list[3];

        concat_list[0] = _6122;
        concat_list[1] = _argtext_10430;
        concat_list[2] = _6121;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_6122);
    _6122 = NOVALUE;
    DeRefDS(_6121);
    _6121 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_10264 = _pos_10264 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _6125 = Repeat(32, _pos_10264);
    _6126 = _pos_10264 + 1;
    _6127 = Repeat(32, _6126);
    _6126 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _6127;
        concat_list[1] = _argtext_10430;
        concat_list[2] = _6125;
        Concat_N((object_ptr)&_argtext_10430, concat_list, 3);
    }
    DeRefDS(_6127);
    _6127 = NOVALUE;
    DeRefDS(_6125);
    _6125 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_10430)){
            _6129 = SEQ_PTR(_argtext_10430)->length;
    }
    else {
        _6129 = 1;
    }
    _6130 = _width_10262 - _6129;
    _6129 = NOVALUE;
    _6131 = Repeat(32, _6130);
    _6130 = NOVALUE;
    Concat((object_ptr)&_argtext_10430, _argtext_10430, _6131);
    DeRefDS(_6131);
    _6131 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_10249, _result_10249, _argtext_10430);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_10260 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_10249, _result_10249, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_10267 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_10249);
    RefDS(_4563);
    _0 = _result_10249;
    _result_10249 = _6trim(_result_10249, _4563, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_10253 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_10273);
    DeRef(_prevargv_10272);
    _prevargv_10272 = _currargv_10273;
L1F: 
    DeRef(_argtext_10430);
    _argtext_10430 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_10247);
    DeRef(_arg_list_10248);
    DeRef(_prevargv_10272);
    DeRef(_currargv_10273);
    DeRef(_idname_10274);
    DeRef(_envsym_10275);
    DeRefi(_envvar_10276);
    DeRef(_6058);
    _6058 = NOVALUE;
    DeRef(_6102);
    _6102 = NOVALUE;
    DeRef(_5834);
    _5834 = NOVALUE;
    DeRef(_6065);
    _6065 = NOVALUE;
    DeRef(_6010);
    _6010 = NOVALUE;
    DeRef(_6088);
    _6088 = NOVALUE;
    DeRef(_6075);
    _6075 = NOVALUE;
    DeRef(_5795);
    _5795 = NOVALUE;
    DeRef(_6046);
    _6046 = NOVALUE;
    DeRef(_6039);
    _6039 = NOVALUE;
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5923);
    _5923 = NOVALUE;
    DeRef(_6118);
    _6118 = NOVALUE;
    DeRef(_5772);
    _5772 = NOVALUE;
    DeRef(_6000);
    _6000 = NOVALUE;
    DeRef(_6097);
    _6097 = NOVALUE;
    DeRef(_5844);
    _5844 = NOVALUE;
    DeRef(_6094);
    _6094 = NOVALUE;
    DeRef(_6105);
    _6105 = NOVALUE;
    DeRef(_5822);
    _5822 = NOVALUE;
    DeRef(_6099);
    _6099 = NOVALUE;
    DeRef(_5978);
    _5978 = NOVALUE;
    _5980 = NOVALUE;
    DeRef(_5941);
    _5941 = NOVALUE;
    DeRef(_5862);
    _5862 = NOVALUE;
    return _result_10249;
    ;
}


int  __stdcall _6wrap(int _content_10885, int _width_10886, int _wrap_with_10887, int _wrap_at_10888)
{
    int _result_10893 = NOVALUE;
    int _split_at_10896 = NOVALUE;
    int _6161 = NOVALUE;
    int _6159 = NOVALUE;
    int _6157 = NOVALUE;
    int _6156 = NOVALUE;
    int _6155 = NOVALUE;
    int _6153 = NOVALUE;
    int _6152 = NOVALUE;
    int _6150 = NOVALUE;
    int _6147 = NOVALUE;
    int _6145 = NOVALUE;
    int _6144 = NOVALUE;
    int _6143 = NOVALUE;
    int _6141 = NOVALUE;
    int _6140 = NOVALUE;
    int _6139 = NOVALUE;
    int _6137 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_width_10886)) {
        _1 = (long)(DBL_PTR(_width_10886)->dbl);
        DeRefDS(_width_10886);
        _width_10886 = _1;
    }

    /** 	if length(content) < width then*/
    if (IS_SEQUENCE(_content_10885)){
            _6137 = SEQ_PTR(_content_10885)->length;
    }
    else {
        _6137 = 1;
    }
    if (_6137 >= _width_10886)
    goto L1; // [14] 25

    /** 		return content*/
    DeRefDS(_wrap_with_10887);
    DeRefDS(_wrap_at_10888);
    DeRef(_result_10893);
    return _content_10885;
L1: 

    /** 	sequence result = ""*/
    RefDS(_5);
    DeRef(_result_10893);
    _result_10893 = _5;

    /** 	while length(content) do*/
L2: 
    if (IS_SEQUENCE(_content_10885)){
            _6139 = SEQ_PTR(_content_10885)->length;
    }
    else {
        _6139 = 1;
    }
    if (_6139 == 0)
    {
        _6139 = NOVALUE;
        goto L3; // [40] 259
    }
    else{
        _6139 = NOVALUE;
    }

    /** 		integer split_at = 0*/
    _split_at_10896 = 0;

    /** 		for i = width to 1 by -1 do*/
    {
        int _i_10898;
        _i_10898 = _width_10886;
L4: 
        if (_i_10898 < 1){
            goto L5; // [50] 88
        }

        /** 			if find(content[i], wrap_at) then*/
        _2 = (int)SEQ_PTR(_content_10885);
        _6140 = (int)*(((s1_ptr)_2)->base + _i_10898);
        _6141 = find_from(_6140, _wrap_at_10888, 1);
        _6140 = NOVALUE;
        if (_6141 == 0)
        {
            _6141 = NOVALUE;
            goto L6; // [68] 81
        }
        else{
            _6141 = NOVALUE;
        }

        /** 				split_at = i*/
        _split_at_10896 = _i_10898;

        /** 				exit*/
        goto L5; // [78] 88
L6: 

        /** 		end for*/
        _i_10898 = _i_10898 + -1;
        goto L4; // [83] 57
L5: 
        ;
    }

    /** 		if split_at = 0 then*/
    if (_split_at_10896 != 0)
    goto L7; // [90] 172

    /** 			for i = width to length(content) do*/
    if (IS_SEQUENCE(_content_10885)){
            _6143 = SEQ_PTR(_content_10885)->length;
    }
    else {
        _6143 = 1;
    }
    {
        int _i_10905;
        _i_10905 = _width_10886;
L8: 
        if (_i_10905 > _6143){
            goto L9; // [99] 137
        }

        /** 				if find(content[i], wrap_at) then*/
        _2 = (int)SEQ_PTR(_content_10885);
        _6144 = (int)*(((s1_ptr)_2)->base + _i_10905);
        _6145 = find_from(_6144, _wrap_at_10888, 1);
        _6144 = NOVALUE;
        if (_6145 == 0)
        {
            _6145 = NOVALUE;
            goto LA; // [117] 130
        }
        else{
            _6145 = NOVALUE;
        }

        /** 					split_at = i*/
        _split_at_10896 = _i_10905;

        /** 					exit*/
        goto L9; // [127] 137
LA: 

        /** 			end for*/
        _i_10905 = _i_10905 + 1;
        goto L8; // [132] 106
L9: 
        ;
    }

    /** 			if split_at = 0 then*/
    if (_split_at_10896 != 0)
    goto LB; // [139] 171

    /** 				if length(result) then*/
    if (IS_SEQUENCE(_result_10893)){
            _6147 = SEQ_PTR(_result_10893)->length;
    }
    else {
        _6147 = 1;
    }
    if (_6147 == 0)
    {
        _6147 = NOVALUE;
        goto LC; // [148] 158
    }
    else{
        _6147 = NOVALUE;
    }

    /** 					result &= wrap_with*/
    Concat((object_ptr)&_result_10893, _result_10893, _wrap_with_10887);
LC: 

    /** 				result &= content*/
    Concat((object_ptr)&_result_10893, _result_10893, _content_10885);

    /** 				exit*/
    goto L3; // [168] 259
LB: 
L7: 

    /** 		if length(result) then*/
    if (IS_SEQUENCE(_result_10893)){
            _6150 = SEQ_PTR(_result_10893)->length;
    }
    else {
        _6150 = 1;
    }
    if (_6150 == 0)
    {
        _6150 = NOVALUE;
        goto LD; // [177] 187
    }
    else{
        _6150 = NOVALUE;
    }

    /** 			result &= wrap_with*/
    Concat((object_ptr)&_result_10893, _result_10893, _wrap_with_10887);
LD: 

    /** 		result &= trim(content[1..split_at])*/
    rhs_slice_target = (object_ptr)&_6152;
    RHS_Slice(_content_10885, 1, _split_at_10896);
    RefDS(_4563);
    _6153 = _6trim(_6152, _4563, 0);
    _6152 = NOVALUE;
    if (IS_SEQUENCE(_result_10893) && IS_ATOM(_6153)) {
        Ref(_6153);
        Append(&_result_10893, _result_10893, _6153);
    }
    else if (IS_ATOM(_result_10893) && IS_SEQUENCE(_6153)) {
    }
    else {
        Concat((object_ptr)&_result_10893, _result_10893, _6153);
    }
    DeRef(_6153);
    _6153 = NOVALUE;

    /** 		content = trim(content[split_at + 1..$])*/
    _6155 = _split_at_10896 + 1;
    if (_6155 > MAXINT){
        _6155 = NewDouble((double)_6155);
    }
    if (IS_SEQUENCE(_content_10885)){
            _6156 = SEQ_PTR(_content_10885)->length;
    }
    else {
        _6156 = 1;
    }
    rhs_slice_target = (object_ptr)&_6157;
    RHS_Slice(_content_10885, _6155, _6156);
    RefDS(_4563);
    _0 = _content_10885;
    _content_10885 = _6trim(_6157, _4563, 0);
    DeRefDS(_0);
    _6157 = NOVALUE;

    /** 		if length(content) < width then*/
    if (IS_SEQUENCE(_content_10885)){
            _6159 = SEQ_PTR(_content_10885)->length;
    }
    else {
        _6159 = 1;
    }
    if (_6159 >= _width_10886)
    goto LE; // [231] 252

    /** 			result &= wrap_with & content*/
    Concat((object_ptr)&_6161, _wrap_with_10887, _content_10885);
    Concat((object_ptr)&_result_10893, _result_10893, _6161);
    DeRefDS(_6161);
    _6161 = NOVALUE;

    /** 			exit*/
    goto L3; // [249] 259
LE: 

    /** 	end while*/
    goto L2; // [256] 37
L3: 

    /** 	return result*/
    DeRefDS(_content_10885);
    DeRefDS(_wrap_with_10887);
    DeRefDS(_wrap_at_10888);
    DeRef(_6155);
    _6155 = NOVALUE;
    return _result_10893;
    ;
}



// 0x0011CA12
