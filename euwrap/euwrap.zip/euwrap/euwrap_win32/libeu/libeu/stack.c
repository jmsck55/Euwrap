// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _50stack(int _obj_p_22555)
{
    int _o_22559 = NOVALUE;
    int _12601 = NOVALUE;
    int _12600 = NOVALUE;
    int _12598 = NOVALUE;
    int _12596 = NOVALUE;
    int _12594 = NOVALUE;
    int _12593 = NOVALUE;
    int _12591 = NOVALUE;
    int _12589 = NOVALUE;
    int _12586 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_22555);
    RefDS(_5);
    _12586 = _28valid(_obj_p_22555, _5);
    if (IS_ATOM_INT(_12586)) {
        if (_12586 != 0){
            DeRef(_12586);
            _12586 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_12586)->dbl != 0.0){
            DeRef(_12586);
            _12586 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_12586);
    _12586 = NOVALUE;
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L1: 

    /** 	object o = eumem:ram_space[obj_p]*/
    DeRef(_o_22559);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_obj_p_22555)){
        _o_22559 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_22555)->dbl));
    }
    else{
        _o_22559 = (int)*(((s1_ptr)_2)->base + _obj_p_22555);
    }
    Ref(_o_22559);

    /** 	if not sequence(o) then return 0 end if*/
    _12589 = IS_SEQUENCE(_o_22559);
    if (_12589 != 0)
    goto L2; // [29] 37
    _12589 = NOVALUE;
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L2: 

    /** 	if length(o) != data then return 0 end if*/
    if (IS_SEQUENCE(_o_22559)){
            _12591 = SEQ_PTR(_o_22559)->length;
    }
    else {
        _12591 = 1;
    }
    if (_12591 == 3)
    goto L3; // [42] 51
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L3: 

    /** 	if not equal(o[type_tag], type_is_stack) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22559);
    _12593 = (int)*(((s1_ptr)_2)->base + 1);
    if (_12593 == _50type_is_stack_22551)
    _12594 = 1;
    else if (IS_ATOM_INT(_12593) && IS_ATOM_INT(_50type_is_stack_22551))
    _12594 = 0;
    else
    _12594 = (compare(_12593, _50type_is_stack_22551) == 0);
    _12593 = NOVALUE;
    if (_12594 != 0)
    goto L4; // [61] 69
    _12594 = NOVALUE;
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L4: 

    /** 	if not find(o[stack_type], { FIFO, FILO }) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22559);
    _12596 = (int)*(((s1_ptr)_2)->base + 2);
    _12598 = find_from(_12596, _12597, 1);
    _12596 = NOVALUE;
    if (_12598 != 0)
    goto L5; // [80] 88
    _12598 = NOVALUE;
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L5: 

    /** 	if not sequence(o[data]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_22559);
    _12600 = (int)*(((s1_ptr)_2)->base + 3);
    _12601 = IS_SEQUENCE(_12600);
    _12600 = NOVALUE;
    if (_12601 != 0)
    goto L6; // [97] 105
    _12601 = NOVALUE;
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 0;
L6: 

    /** 	return 1*/
    DeRef(_obj_p_22555);
    DeRef(_o_22559);
    return 1;
    ;
}


int  __stdcall _50new(int _typ_22582)
{
    int _new_stack_22583 = NOVALUE;
    int _12604 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_typ_22582)) {
        _1 = (long)(DBL_PTR(_typ_22582)->dbl);
        DeRefDS(_typ_22582);
        _typ_22582 = _1;
    }

    /** 	atom new_stack = eumem:malloc()*/
    _0 = _new_stack_22583;
    _new_stack_22583 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[new_stack] = { type_is_stack, typ, {} }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50type_is_stack_22551);
    *((int *)(_2+4)) = _50type_is_stack_22551;
    *((int *)(_2+8)) = _typ_22582;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _12604 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_new_stack_22583))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_new_stack_22583)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _new_stack_22583);
    _1 = *(int *)_2;
    *(int *)_2 = _12604;
    if( _1 != _12604 ){
        DeRef(_1);
    }
    _12604 = NOVALUE;

    /** 	return new_stack*/
    return _new_stack_22583;
    ;
}


int  __stdcall _50is_empty(int _sk_22588)
{
    int _12608 = NOVALUE;
    int _12607 = NOVALUE;
    int _12606 = NOVALUE;
    int _12605 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(eumem:ram_space[sk][data]) = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22588)){
        _12605 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22588)->dbl));
    }
    else{
        _12605 = (int)*(((s1_ptr)_2)->base + _sk_22588);
    }
    _2 = (int)SEQ_PTR(_12605);
    _12606 = (int)*(((s1_ptr)_2)->base + 3);
    _12605 = NOVALUE;
    if (IS_SEQUENCE(_12606)){
            _12607 = SEQ_PTR(_12606)->length;
    }
    else {
        _12607 = 1;
    }
    _12606 = NOVALUE;
    _12608 = (_12607 == 0);
    _12607 = NOVALUE;
    DeRef(_sk_22588);
    _12606 = NOVALUE;
    return _12608;
    ;
}


int  __stdcall _50size(int _sk_22595)
{
    int _12611 = NOVALUE;
    int _12610 = NOVALUE;
    int _12609 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(eumem:ram_space[sk][data])*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22595)){
        _12609 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22595)->dbl));
    }
    else{
        _12609 = (int)*(((s1_ptr)_2)->base + _sk_22595);
    }
    _2 = (int)SEQ_PTR(_12609);
    _12610 = (int)*(((s1_ptr)_2)->base + 3);
    _12609 = NOVALUE;
    if (IS_SEQUENCE(_12610)){
            _12611 = SEQ_PTR(_12610)->length;
    }
    else {
        _12611 = 1;
    }
    _12610 = NOVALUE;
    DeRef(_sk_22595);
    _12610 = NOVALUE;
    return _12611;
    ;
}


int  __stdcall _50at(int _sk_22601, int _idx_22602)
{
    int _o_22603 = NOVALUE;
    int _oidx_22606 = NOVALUE;
    int _msg_inlined_crash_at_74_22621 = NOVALUE;
    int _12624 = NOVALUE;
    int _12622 = NOVALUE;
    int _12621 = NOVALUE;
    int _12619 = NOVALUE;
    int _12617 = NOVALUE;
    int _12616 = NOVALUE;
    int _12612 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22602)) {
        _1 = (long)(DBL_PTR(_idx_22602)->dbl);
        DeRefDS(_idx_22602);
        _idx_22602 = _1;
    }

    /** 	sequence o = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22601)){
        _12612 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22601)->dbl));
    }
    else{
        _12612 = (int)*(((s1_ptr)_2)->base + _sk_22601);
    }
    DeRef(_o_22603);
    _2 = (int)SEQ_PTR(_12612);
    _o_22603 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_o_22603);
    _12612 = NOVALUE;

    /** 	integer oidx = idx*/
    _oidx_22606 = _idx_22602;

    /** 	if idx <= 0 then*/
    if (_idx_22602 > 0)
    goto L1; // [24] 37

    /** 		idx = 1 - idx*/
    _idx_22602 = 1 - _idx_22602;
    goto L2; // [34] 51
L1: 

    /** 		idx = length(o) - idx + 1*/
    if (IS_SEQUENCE(_o_22603)){
            _12616 = SEQ_PTR(_o_22603)->length;
    }
    else {
        _12616 = 1;
    }
    _12617 = _12616 - _idx_22602;
    if ((long)((unsigned long)_12617 +(unsigned long) HIGH_BITS) >= 0){
        _12617 = NewDouble((double)_12617);
    }
    _12616 = NOVALUE;
    if (IS_ATOM_INT(_12617)) {
        _idx_22602 = _12617 + 1;
    }
    else
    { // coercing _idx_22602 to an integer 1
        _idx_22602 = 1+(long)(DBL_PTR(_12617)->dbl);
        if( !IS_ATOM_INT(_idx_22602) ){
            _idx_22602 = (object)DBL_PTR(_idx_22602)->dbl;
        }
    }
    DeRef(_12617);
    _12617 = NOVALUE;
L2: 

    /** 	if idx < 1 or idx > length(o) then*/
    _12619 = (_idx_22602 < 1);
    if (_12619 != 0) {
        goto L3; // [57] 73
    }
    if (IS_SEQUENCE(_o_22603)){
            _12621 = SEQ_PTR(_o_22603)->length;
    }
    else {
        _12621 = 1;
    }
    _12622 = (_idx_22602 > _12621);
    _12621 = NOVALUE;
    if (_12622 == 0)
    {
        DeRef(_12622);
        _12622 = NOVALUE;
        goto L4; // [69] 94
    }
    else{
        DeRef(_12622);
        _12622 = NOVALUE;
    }
L3: 

    /** 		error:crash("stack index (%d) out of bounds for at()", oidx)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_74_22621);
    _msg_inlined_crash_at_74_22621 = EPrintf(-9999999, _12623, _oidx_22606);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_74_22621);

    /** end procedure*/
    goto L5; // [88] 91
L5: 
    DeRefi(_msg_inlined_crash_at_74_22621);
    _msg_inlined_crash_at_74_22621 = NOVALUE;
L4: 

    /** 	return o[idx]*/
    _2 = (int)SEQ_PTR(_o_22603);
    _12624 = (int)*(((s1_ptr)_2)->base + _idx_22602);
    Ref(_12624);
    DeRef(_sk_22601);
    DeRefDS(_o_22603);
    DeRef(_12619);
    _12619 = NOVALUE;
    return _12624;
    ;
}


void  __stdcall _50push(int _sk_22625, int _value_22626)
{
    int _msg_inlined_crash_at_106_22650 = NOVALUE;
    int _data_inlined_crash_at_103_22649 = NOVALUE;
    int _12642 = NOVALUE;
    int _12641 = NOVALUE;
    int _12640 = NOVALUE;
    int _12638 = NOVALUE;
    int _12637 = NOVALUE;
    int _12636 = NOVALUE;
    int _12634 = NOVALUE;
    int _12633 = NOVALUE;
    int _12632 = NOVALUE;
    int _12631 = NOVALUE;
    int _12629 = NOVALUE;
    int _12626 = NOVALUE;
    int _12625 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch eumem:ram_space[sk][stack_type] do*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22625)){
        _12625 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
    }
    else{
        _12625 = (int)*(((s1_ptr)_2)->base + _sk_22625);
    }
    _2 = (int)SEQ_PTR(_12625);
    _12626 = (int)*(((s1_ptr)_2)->base + 2);
    _12625 = NOVALUE;
    if (IS_SEQUENCE(_12626) ){
        goto L1; // [13] 86
    }
    if(!IS_ATOM_INT(_12626)){
        if( (DBL_PTR(_12626)->dbl != (double) ((int) DBL_PTR(_12626)->dbl) ) ){
            goto L1; // [13] 86
        }
        _0 = (int) DBL_PTR(_12626)->dbl;
    }
    else {
        _0 = _12626;
    };
    _12626 = NOVALUE;
    switch ( _0 ){ 

        /** 		case FIFO then*/
        case 1:

        /** 			eumem:ram_space[sk][data] = prepend(eumem:ram_space[sk][data], value)*/
        _2 = (int)SEQ_PTR(_28ram_space_10933);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _28ram_space_10933 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_sk_22625))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
        else
        _3 = (int)(_sk_22625 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_28ram_space_10933);
        if (!IS_ATOM_INT(_sk_22625)){
            _12631 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
        }
        else{
            _12631 = (int)*(((s1_ptr)_2)->base + _sk_22625);
        }
        _2 = (int)SEQ_PTR(_12631);
        _12632 = (int)*(((s1_ptr)_2)->base + 3);
        _12631 = NOVALUE;
        Ref(_value_22626);
        Prepend(&_12633, _12632, _value_22626);
        _12632 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _12633;
        if( _1 != _12633 ){
            DeRef(_1);
        }
        _12633 = NOVALUE;
        _12629 = NOVALUE;
        goto L2; // [49] 126

        /** 		case FILO then*/
        case 2:

        /** 			eumem:ram_space[sk][data] = append(eumem:ram_space[sk][data], value)*/
        _2 = (int)SEQ_PTR(_28ram_space_10933);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _28ram_space_10933 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_sk_22625))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
        else
        _3 = (int)(_sk_22625 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_28ram_space_10933);
        if (!IS_ATOM_INT(_sk_22625)){
            _12636 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
        }
        else{
            _12636 = (int)*(((s1_ptr)_2)->base + _sk_22625);
        }
        _2 = (int)SEQ_PTR(_12636);
        _12637 = (int)*(((s1_ptr)_2)->base + 3);
        _12636 = NOVALUE;
        Ref(_value_22626);
        Append(&_12638, _12637, _value_22626);
        _12637 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _12638;
        if( _1 != _12638 ){
            DeRef(_1);
        }
        _12638 = NOVALUE;
        _12634 = NOVALUE;
        goto L2; // [82] 126

        /** 		case else*/
        default:
L1: 

        /** 			error:crash("Internal error in stack.e: Stack %d has invalid stack type %d", {sk,eumem:ram_space[sk][stack_type]})*/
        _2 = (int)SEQ_PTR(_28ram_space_10933);
        if (!IS_ATOM_INT(_sk_22625)){
            _12640 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22625)->dbl));
        }
        else{
            _12640 = (int)*(((s1_ptr)_2)->base + _sk_22625);
        }
        _2 = (int)SEQ_PTR(_12640);
        _12641 = (int)*(((s1_ptr)_2)->base + 2);
        _12640 = NOVALUE;
        Ref(_12641);
        Ref(_sk_22625);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _sk_22625;
        ((int *)_2)[2] = _12641;
        _12642 = MAKE_SEQ(_1);
        _12641 = NOVALUE;
        DeRef(_data_inlined_crash_at_103_22649);
        _data_inlined_crash_at_103_22649 = _12642;
        _12642 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_106_22650);
        _msg_inlined_crash_at_106_22650 = EPrintf(-9999999, _12639, _data_inlined_crash_at_103_22649);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_106_22650);

        /** end procedure*/
        goto L3; // [120] 123
L3: 
        DeRef(_data_inlined_crash_at_103_22649);
        _data_inlined_crash_at_103_22649 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_106_22650);
        _msg_inlined_crash_at_106_22650 = NOVALUE;
    ;}L2: 

    /** end procedure*/
    DeRef(_sk_22625);
    DeRef(_value_22626);
    return;
    ;
}


int  __stdcall _50top(int _sk_22653)
{
    int _msg_inlined_crash_at_21_22661 = NOVALUE;
    int _12651 = NOVALUE;
    int _12650 = NOVALUE;
    int _12649 = NOVALUE;
    int _12648 = NOVALUE;
    int _12645 = NOVALUE;
    int _12644 = NOVALUE;
    int _12643 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(eumem:ram_space[sk][data]) = 0 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22653)){
        _12643 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22653)->dbl));
    }
    else{
        _12643 = (int)*(((s1_ptr)_2)->base + _sk_22653);
    }
    _2 = (int)SEQ_PTR(_12643);
    _12644 = (int)*(((s1_ptr)_2)->base + 3);
    _12643 = NOVALUE;
    if (IS_SEQUENCE(_12644)){
            _12645 = SEQ_PTR(_12644)->length;
    }
    else {
        _12645 = 1;
    }
    _12644 = NOVALUE;
    if (_12645 != 0)
    goto L1; // [16] 41

    /** 		error:crash("stack is empty so there is no top()", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_21_22661);
    _msg_inlined_crash_at_21_22661 = EPrintf(-9999999, _12647, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_21_22661);

    /** end procedure*/
    goto L2; // [35] 38
L2: 
    DeRefi(_msg_inlined_crash_at_21_22661);
    _msg_inlined_crash_at_21_22661 = NOVALUE;
L1: 

    /** 	return eumem:ram_space[sk][data][$]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22653)){
        _12648 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22653)->dbl));
    }
    else{
        _12648 = (int)*(((s1_ptr)_2)->base + _sk_22653);
    }
    _2 = (int)SEQ_PTR(_12648);
    _12649 = (int)*(((s1_ptr)_2)->base + 3);
    _12648 = NOVALUE;
    if (IS_SEQUENCE(_12649)){
            _12650 = SEQ_PTR(_12649)->length;
    }
    else {
        _12650 = 1;
    }
    _2 = (int)SEQ_PTR(_12649);
    _12651 = (int)*(((s1_ptr)_2)->base + _12650);
    _12649 = NOVALUE;
    Ref(_12651);
    DeRef(_sk_22653);
    _12644 = NOVALUE;
    return _12651;
    ;
}


int  __stdcall _50last(int _sk_22668)
{
    int _msg_inlined_crash_at_21_22676 = NOVALUE;
    int _12659 = NOVALUE;
    int _12658 = NOVALUE;
    int _12657 = NOVALUE;
    int _12654 = NOVALUE;
    int _12653 = NOVALUE;
    int _12652 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(eumem:ram_space[sk][data]) = 0 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22668)){
        _12652 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22668)->dbl));
    }
    else{
        _12652 = (int)*(((s1_ptr)_2)->base + _sk_22668);
    }
    _2 = (int)SEQ_PTR(_12652);
    _12653 = (int)*(((s1_ptr)_2)->base + 3);
    _12652 = NOVALUE;
    if (IS_SEQUENCE(_12653)){
            _12654 = SEQ_PTR(_12653)->length;
    }
    else {
        _12654 = 1;
    }
    _12653 = NOVALUE;
    if (_12654 != 0)
    goto L1; // [16] 41

    /** 		error:crash("stack is empty so there is no last()", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_21_22676);
    _msg_inlined_crash_at_21_22676 = EPrintf(-9999999, _12656, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_21_22676);

    /** end procedure*/
    goto L2; // [35] 38
L2: 
    DeRefi(_msg_inlined_crash_at_21_22676);
    _msg_inlined_crash_at_21_22676 = NOVALUE;
L1: 

    /** 	return eumem:ram_space[sk][data][1]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22668)){
        _12657 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22668)->dbl));
    }
    else{
        _12657 = (int)*(((s1_ptr)_2)->base + _sk_22668);
    }
    _2 = (int)SEQ_PTR(_12657);
    _12658 = (int)*(((s1_ptr)_2)->base + 3);
    _12657 = NOVALUE;
    _2 = (int)SEQ_PTR(_12658);
    _12659 = (int)*(((s1_ptr)_2)->base + 1);
    _12658 = NOVALUE;
    Ref(_12659);
    DeRef(_sk_22668);
    _12653 = NOVALUE;
    return _12659;
    ;
}


int  __stdcall _50pop(int _sk_22682, int _idx_22683)
{
    int _t_22684 = NOVALUE;
    int _msg_inlined_crash_at_49_22697 = NOVALUE;
    int _msg_inlined_crash_at_79_22703 = NOVALUE;
    int _data_inlined_crash_at_76_22702 = NOVALUE;
    int _top_obj_22707 = NOVALUE;
    int _12682 = NOVALUE;
    int _12681 = NOVALUE;
    int _12680 = NOVALUE;
    int _12679 = NOVALUE;
    int _12678 = NOVALUE;
    int _12677 = NOVALUE;
    int _12675 = NOVALUE;
    int _12672 = NOVALUE;
    int _12671 = NOVALUE;
    int _12670 = NOVALUE;
    int _12666 = NOVALUE;
    int _12665 = NOVALUE;
    int _12664 = NOVALUE;
    int _12662 = NOVALUE;
    int _12660 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_idx_22683)) {
        _1 = (long)(DBL_PTR(_idx_22683)->dbl);
        DeRefDS(_idx_22683);
        _idx_22683 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22682)){
        _12660 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22682)->dbl));
    }
    else{
        _12660 = (int)*(((s1_ptr)_2)->base + _sk_22682);
    }
    DeRef(_t_22684);
    _2 = (int)SEQ_PTR(_12660);
    _t_22684 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22684);
    _12660 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12662 = (_idx_22683 < 0);
    if (_12662 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22684)){
            _12664 = SEQ_PTR(_t_22684)->length;
    }
    else {
        _12664 = 1;
    }
    _12665 = (_idx_22683 > _12664);
    _12664 = NOVALUE;
    if (_12665 == 0)
    {
        DeRef(_12665);
        _12665 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12665);
        _12665 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22684)){
            _12666 = SEQ_PTR(_t_22684)->length;
    }
    else {
        _12666 = 1;
    }
    if (_12666 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot pop")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22697);
    _msg_inlined_crash_at_49_22697 = EPrintf(-9999999, _12668, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22697);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22697);
    _msg_inlined_crash_at_49_22697 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in pop()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22683;
    _12670 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22702);
    _data_inlined_crash_at_76_22702 = _12670;
    _12670 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22703);
    _msg_inlined_crash_at_79_22703 = EPrintf(-9999999, _12669, _data_inlined_crash_at_76_22702);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22703);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22702);
    _data_inlined_crash_at_76_22702 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22703);
    _msg_inlined_crash_at_79_22703 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22684)){
            _12671 = SEQ_PTR(_t_22684)->length;
    }
    else {
        _12671 = 1;
    }
    _12672 = _12671 - _idx_22683;
    if ((long)((unsigned long)_12672 +(unsigned long) HIGH_BITS) >= 0){
        _12672 = NewDouble((double)_12672);
    }
    _12671 = NOVALUE;
    if (IS_ATOM_INT(_12672)) {
        _idx_22683 = _12672 + 1;
    }
    else
    { // coercing _idx_22683 to an integer 1
        _idx_22683 = 1+(long)(DBL_PTR(_12672)->dbl);
        if( !IS_ATOM_INT(_idx_22683) ){
            _idx_22683 = (object)DBL_PTR(_idx_22683)->dbl;
        }
    }
    DeRef(_12672);
    _12672 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22707);
    _2 = (int)SEQ_PTR(_t_22684);
    _top_obj_22707 = (int)*(((s1_ptr)_2)->base + _idx_22683);
    Ref(_top_obj_22707);

    /** 	eumem:ram_space[sk][data] = t[1 .. idx - 1] & t[idx + 1 .. $]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22682))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22682)->dbl));
    else
    _3 = (int)(_sk_22682 + ((s1_ptr)_2)->base);
    _12677 = _idx_22683 - 1;
    rhs_slice_target = (object_ptr)&_12678;
    RHS_Slice(_t_22684, 1, _12677);
    _12679 = _idx_22683 + 1;
    if (_12679 > MAXINT){
        _12679 = NewDouble((double)_12679);
    }
    if (IS_SEQUENCE(_t_22684)){
            _12680 = SEQ_PTR(_t_22684)->length;
    }
    else {
        _12680 = 1;
    }
    rhs_slice_target = (object_ptr)&_12681;
    RHS_Slice(_t_22684, _12679, _12680);
    Concat((object_ptr)&_12682, _12678, _12681);
    DeRefDS(_12678);
    _12678 = NOVALUE;
    DeRef(_12678);
    _12678 = NOVALUE;
    DeRefDS(_12681);
    _12681 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _12682;
    if( _1 != _12682 ){
        DeRef(_1);
    }
    _12682 = NOVALUE;
    _12675 = NOVALUE;

    /** 	return top_obj*/
    DeRef(_sk_22682);
    DeRefDS(_t_22684);
    DeRef(_12662);
    _12662 = NOVALUE;
    _12677 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    return _top_obj_22707;
    ;
}


int  __stdcall _50peek_top(int _sk_22719, int _idx_22720)
{
    int _t_22721 = NOVALUE;
    int _msg_inlined_crash_at_49_22734 = NOVALUE;
    int _msg_inlined_crash_at_79_22740 = NOVALUE;
    int _data_inlined_crash_at_76_22739 = NOVALUE;
    int _top_obj_22744 = NOVALUE;
    int _12695 = NOVALUE;
    int _12694 = NOVALUE;
    int _12693 = NOVALUE;
    int _12689 = NOVALUE;
    int _12688 = NOVALUE;
    int _12687 = NOVALUE;
    int _12685 = NOVALUE;
    int _12683 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22720)) {
        _1 = (long)(DBL_PTR(_idx_22720)->dbl);
        DeRefDS(_idx_22720);
        _idx_22720 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22719)){
        _12683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22719)->dbl));
    }
    else{
        _12683 = (int)*(((s1_ptr)_2)->base + _sk_22719);
    }
    DeRef(_t_22721);
    _2 = (int)SEQ_PTR(_12683);
    _t_22721 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22721);
    _12683 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12685 = (_idx_22720 < 0);
    if (_12685 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22721)){
            _12687 = SEQ_PTR(_t_22721)->length;
    }
    else {
        _12687 = 1;
    }
    _12688 = (_idx_22720 > _12687);
    _12687 = NOVALUE;
    if (_12688 == 0)
    {
        DeRef(_12688);
        _12688 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12688);
        _12688 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22721)){
            _12689 = SEQ_PTR(_t_22721)->length;
    }
    else {
        _12689 = 1;
    }
    if (_12689 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot peek_top")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22734);
    _msg_inlined_crash_at_49_22734 = EPrintf(-9999999, _12691, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22734);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22734);
    _msg_inlined_crash_at_49_22734 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in peek_top()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22720;
    _12693 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22739);
    _data_inlined_crash_at_76_22739 = _12693;
    _12693 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22740);
    _msg_inlined_crash_at_79_22740 = EPrintf(-9999999, _12692, _data_inlined_crash_at_76_22739);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22740);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22739);
    _data_inlined_crash_at_76_22739 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22740);
    _msg_inlined_crash_at_79_22740 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22721)){
            _12694 = SEQ_PTR(_t_22721)->length;
    }
    else {
        _12694 = 1;
    }
    _12695 = _12694 - _idx_22720;
    if ((long)((unsigned long)_12695 +(unsigned long) HIGH_BITS) >= 0){
        _12695 = NewDouble((double)_12695);
    }
    _12694 = NOVALUE;
    if (IS_ATOM_INT(_12695)) {
        _idx_22720 = _12695 + 1;
    }
    else
    { // coercing _idx_22720 to an integer 1
        _idx_22720 = 1+(long)(DBL_PTR(_12695)->dbl);
        if( !IS_ATOM_INT(_idx_22720) ){
            _idx_22720 = (object)DBL_PTR(_idx_22720)->dbl;
        }
    }
    DeRef(_12695);
    _12695 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22744);
    _2 = (int)SEQ_PTR(_t_22721);
    _top_obj_22744 = (int)*(((s1_ptr)_2)->base + _idx_22720);
    Ref(_top_obj_22744);

    /** 	return top_obj*/
    DeRef(_sk_22719);
    DeRefDS(_t_22721);
    DeRef(_12685);
    _12685 = NOVALUE;
    return _top_obj_22744;
    ;
}


int  __stdcall _50peek_end(int _sk_22748, int _idx_22749)
{
    int _t_22750 = NOVALUE;
    int _msg_inlined_crash_at_49_22763 = NOVALUE;
    int _msg_inlined_crash_at_79_22769 = NOVALUE;
    int _data_inlined_crash_at_76_22768 = NOVALUE;
    int _top_obj_22773 = NOVALUE;
    int _12710 = NOVALUE;
    int _12709 = NOVALUE;
    int _12708 = NOVALUE;
    int _12704 = NOVALUE;
    int _12703 = NOVALUE;
    int _12702 = NOVALUE;
    int _12700 = NOVALUE;
    int _12698 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_idx_22749)) {
        _1 = (long)(DBL_PTR(_idx_22749)->dbl);
        DeRefDS(_idx_22749);
        _idx_22749 = _1;
    }

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22748)){
        _12698 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22748)->dbl));
    }
    else{
        _12698 = (int)*(((s1_ptr)_2)->base + _sk_22748);
    }
    DeRef(_t_22750);
    _2 = (int)SEQ_PTR(_12698);
    _t_22750 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22750);
    _12698 = NOVALUE;

    /** 	if idx < 0 or idx > length(t) then*/
    _12700 = (_idx_22749 < 0);
    if (_12700 != 0) {
        goto L1; // [23] 39
    }
    if (IS_SEQUENCE(_t_22750)){
            _12702 = SEQ_PTR(_t_22750)->length;
    }
    else {
        _12702 = 1;
    }
    _12703 = (_idx_22749 > _12702);
    _12702 = NOVALUE;
    if (_12703 == 0)
    {
        DeRef(_12703);
        _12703 = NOVALUE;
        goto L2; // [35] 100
    }
    else{
        DeRef(_12703);
        _12703 = NOVALUE;
    }
L1: 

    /** 		if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22750)){
            _12704 = SEQ_PTR(_t_22750)->length;
    }
    else {
        _12704 = 1;
    }
    if (_12704 != 0)
    goto L3; // [44] 71

    /** 			error:crash("stack is empty, cannot peek_end")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_49_22763);
    _msg_inlined_crash_at_49_22763 = EPrintf(-9999999, _12706, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_49_22763);

    /** end procedure*/
    goto L4; // [63] 66
L4: 
    DeRefi(_msg_inlined_crash_at_49_22763);
    _msg_inlined_crash_at_49_22763 = NOVALUE;
    goto L5; // [68] 99
L3: 

    /** 			error:crash("stack idx (%d) out of bounds in peek_end()", {idx})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _idx_22749;
    _12708 = MAKE_SEQ(_1);
    DeRefi(_data_inlined_crash_at_76_22768);
    _data_inlined_crash_at_76_22768 = _12708;
    _12708 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_79_22769);
    _msg_inlined_crash_at_79_22769 = EPrintf(-9999999, _12707, _data_inlined_crash_at_76_22768);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_79_22769);

    /** end procedure*/
    goto L6; // [93] 96
L6: 
    DeRefi(_data_inlined_crash_at_76_22768);
    _data_inlined_crash_at_76_22768 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_79_22769);
    _msg_inlined_crash_at_79_22769 = NOVALUE;
L5: 
L2: 

    /** 	idx = length(t) - idx + 1*/
    if (IS_SEQUENCE(_t_22750)){
            _12709 = SEQ_PTR(_t_22750)->length;
    }
    else {
        _12709 = 1;
    }
    _12710 = _12709 - _idx_22749;
    if ((long)((unsigned long)_12710 +(unsigned long) HIGH_BITS) >= 0){
        _12710 = NewDouble((double)_12710);
    }
    _12709 = NOVALUE;
    if (IS_ATOM_INT(_12710)) {
        _idx_22749 = _12710 + 1;
    }
    else
    { // coercing _idx_22749 to an integer 1
        _idx_22749 = 1+(long)(DBL_PTR(_12710)->dbl);
        if( !IS_ATOM_INT(_idx_22749) ){
            _idx_22749 = (object)DBL_PTR(_idx_22749)->dbl;
        }
    }
    DeRef(_12710);
    _12710 = NOVALUE;

    /** 	object top_obj = t[idx]*/
    DeRef(_top_obj_22773);
    _2 = (int)SEQ_PTR(_t_22750);
    _top_obj_22773 = (int)*(((s1_ptr)_2)->base + _idx_22749);
    Ref(_top_obj_22773);

    /** 	return top_obj*/
    DeRef(_sk_22748);
    DeRefDS(_t_22750);
    DeRef(_12700);
    _12700 = NOVALUE;
    return _top_obj_22773;
    ;
}


void  __stdcall _50swap(int _sk_22777)
{
    int _t_22778 = NOVALUE;
    int _msg_inlined_crash_at_25_22786 = NOVALUE;
    int _tmp_22787 = NOVALUE;
    int _12726 = NOVALUE;
    int _12725 = NOVALUE;
    int _12724 = NOVALUE;
    int _12723 = NOVALUE;
    int _12722 = NOVALUE;
    int _12721 = NOVALUE;
    int _12720 = NOVALUE;
    int _12718 = NOVALUE;
    int _12715 = NOVALUE;
    int _12713 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22777)){
        _12713 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22777)->dbl));
    }
    else{
        _12713 = (int)*(((s1_ptr)_2)->base + _sk_22777);
    }
    DeRef(_t_22778);
    _2 = (int)SEQ_PTR(_12713);
    _t_22778 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22778);
    _12713 = NOVALUE;

    /** 	if length(t) < 2 then*/
    if (IS_SEQUENCE(_t_22778)){
            _12715 = SEQ_PTR(_t_22778)->length;
    }
    else {
        _12715 = 1;
    }
    if (_12715 >= 2)
    goto L1; // [20] 45

    /** 		error:crash("swap() needs at least 2 items in the stack", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_25_22786);
    _msg_inlined_crash_at_25_22786 = EPrintf(-9999999, _12717, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_25_22786);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRefi(_msg_inlined_crash_at_25_22786);
    _msg_inlined_crash_at_25_22786 = NOVALUE;
L1: 

    /** 	object tmp = t[$]*/
    if (IS_SEQUENCE(_t_22778)){
            _12718 = SEQ_PTR(_t_22778)->length;
    }
    else {
        _12718 = 1;
    }
    DeRef(_tmp_22787);
    _2 = (int)SEQ_PTR(_t_22778);
    _tmp_22787 = (int)*(((s1_ptr)_2)->base + _12718);
    Ref(_tmp_22787);

    /** 	t[$] = t[$-1]*/
    if (IS_SEQUENCE(_t_22778)){
            _12720 = SEQ_PTR(_t_22778)->length;
    }
    else {
        _12720 = 1;
    }
    if (IS_SEQUENCE(_t_22778)){
            _12721 = SEQ_PTR(_t_22778)->length;
    }
    else {
        _12721 = 1;
    }
    _12722 = _12721 - 1;
    _12721 = NOVALUE;
    _2 = (int)SEQ_PTR(_t_22778);
    _12723 = (int)*(((s1_ptr)_2)->base + _12722);
    Ref(_12723);
    _2 = (int)SEQ_PTR(_t_22778);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_22778 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12720);
    _1 = *(int *)_2;
    *(int *)_2 = _12723;
    if( _1 != _12723 ){
        DeRef(_1);
    }
    _12723 = NOVALUE;

    /** 	t[$-1] = tmp*/
    if (IS_SEQUENCE(_t_22778)){
            _12724 = SEQ_PTR(_t_22778)->length;
    }
    else {
        _12724 = 1;
    }
    _12725 = _12724 - 1;
    _12724 = NOVALUE;
    Ref(_tmp_22787);
    _2 = (int)SEQ_PTR(_t_22778);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_22778 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12725);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_22787;
    DeRef(_1);

    /** 	eumem:ram_space[sk][data] = t*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22777))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22777)->dbl));
    else
    _3 = (int)(_sk_22777 + ((s1_ptr)_2)->base);
    RefDS(_t_22778);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _t_22778;
    DeRef(_1);
    _12726 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22777);
    DeRefDS(_t_22778);
    DeRef(_tmp_22787);
    _12722 = NOVALUE;
    _12725 = NOVALUE;
    return;
    ;
}


void  __stdcall _50dup(int _sk_22800)
{
    int _t_22801 = NOVALUE;
    int _msg_inlined_crash_at_25_22809 = NOVALUE;
    int _12737 = NOVALUE;
    int _12736 = NOVALUE;
    int _12735 = NOVALUE;
    int _12733 = NOVALUE;
    int _12730 = NOVALUE;
    int _12728 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22800)){
        _12728 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22800)->dbl));
    }
    else{
        _12728 = (int)*(((s1_ptr)_2)->base + _sk_22800);
    }
    DeRef(_t_22801);
    _2 = (int)SEQ_PTR(_12728);
    _t_22801 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_t_22801);
    _12728 = NOVALUE;

    /** 	if length(t) = 0 then*/
    if (IS_SEQUENCE(_t_22801)){
            _12730 = SEQ_PTR(_t_22801)->length;
    }
    else {
        _12730 = 1;
    }
    if (_12730 != 0)
    goto L1; // [20] 45

    /** 		error:crash("dup() needs at least one item in the stack", {})*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_25_22809);
    _msg_inlined_crash_at_25_22809 = EPrintf(-9999999, _12732, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_25_22809);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRefi(_msg_inlined_crash_at_25_22809);
    _msg_inlined_crash_at_25_22809 = NOVALUE;
L1: 

    /** 	eumem:ram_space[sk][data] = append(t, t[$])*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22800))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22800)->dbl));
    else
    _3 = (int)(_sk_22800 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_t_22801)){
            _12735 = SEQ_PTR(_t_22801)->length;
    }
    else {
        _12735 = 1;
    }
    _2 = (int)SEQ_PTR(_t_22801);
    _12736 = (int)*(((s1_ptr)_2)->base + _12735);
    Ref(_12736);
    Append(&_12737, _t_22801, _12736);
    _12736 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _12737;
    if( _1 != _12737 ){
        DeRef(_1);
    }
    _12737 = NOVALUE;
    _12733 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22800);
    DeRefDS(_t_22801);
    return;
    ;
}


void  __stdcall _50set(int _sk_22817, int _val_22818, int _idx_22819)
{
    int _o_22820 = NOVALUE;
    int _oidx_22823 = NOVALUE;
    int _msg_inlined_crash_at_74_22838 = NOVALUE;
    int _12750 = NOVALUE;
    int _12748 = NOVALUE;
    int _12747 = NOVALUE;
    int _12745 = NOVALUE;
    int _12743 = NOVALUE;
    int _12742 = NOVALUE;
    int _12738 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_idx_22819)) {
        _1 = (long)(DBL_PTR(_idx_22819)->dbl);
        DeRefDS(_idx_22819);
        _idx_22819 = _1;
    }

    /** 	sequence o = eumem:ram_space[sk][data]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_sk_22817)){
        _12738 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22817)->dbl));
    }
    else{
        _12738 = (int)*(((s1_ptr)_2)->base + _sk_22817);
    }
    DeRef(_o_22820);
    _2 = (int)SEQ_PTR(_12738);
    _o_22820 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_o_22820);
    _12738 = NOVALUE;

    /** 	integer oidx = idx*/
    _oidx_22823 = _idx_22819;

    /** 	if idx <= 0 then*/
    if (_idx_22819 > 0)
    goto L1; // [24] 37

    /** 		idx = 1 - idx*/
    _idx_22819 = 1 - _idx_22819;
    goto L2; // [34] 51
L1: 

    /** 		idx = length(o) - idx + 1*/
    if (IS_SEQUENCE(_o_22820)){
            _12742 = SEQ_PTR(_o_22820)->length;
    }
    else {
        _12742 = 1;
    }
    _12743 = _12742 - _idx_22819;
    if ((long)((unsigned long)_12743 +(unsigned long) HIGH_BITS) >= 0){
        _12743 = NewDouble((double)_12743);
    }
    _12742 = NOVALUE;
    if (IS_ATOM_INT(_12743)) {
        _idx_22819 = _12743 + 1;
    }
    else
    { // coercing _idx_22819 to an integer 1
        _idx_22819 = 1+(long)(DBL_PTR(_12743)->dbl);
        if( !IS_ATOM_INT(_idx_22819) ){
            _idx_22819 = (object)DBL_PTR(_idx_22819)->dbl;
        }
    }
    DeRef(_12743);
    _12743 = NOVALUE;
L2: 

    /** 	if idx < 1 or idx > length(o) then*/
    _12745 = (_idx_22819 < 1);
    if (_12745 != 0) {
        goto L3; // [57] 73
    }
    if (IS_SEQUENCE(_o_22820)){
            _12747 = SEQ_PTR(_o_22820)->length;
    }
    else {
        _12747 = 1;
    }
    _12748 = (_idx_22819 > _12747);
    _12747 = NOVALUE;
    if (_12748 == 0)
    {
        DeRef(_12748);
        _12748 = NOVALUE;
        goto L4; // [69] 94
    }
    else{
        DeRef(_12748);
        _12748 = NOVALUE;
    }
L3: 

    /** 		error:crash("stack index (%d) out of bounds for set()", oidx)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_74_22838);
    _msg_inlined_crash_at_74_22838 = EPrintf(-9999999, _12749, _oidx_22823);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_74_22838);

    /** end procedure*/
    goto L5; // [88] 91
L5: 
    DeRefi(_msg_inlined_crash_at_74_22838);
    _msg_inlined_crash_at_74_22838 = NOVALUE;
L4: 

    /** 	eumem:ram_space[sk][data][idx] = val*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22817))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22817)->dbl));
    else
    _3 = (int)(_sk_22817 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(3 + ((s1_ptr)_2)->base);
    _12750 = NOVALUE;
    Ref(_val_22818);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_22819);
    _1 = *(int *)_2;
    *(int *)_2 = _val_22818;
    DeRef(_1);
    _12750 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22817);
    DeRef(_val_22818);
    DeRef(_o_22820);
    DeRef(_12745);
    _12745 = NOVALUE;
    return;
    ;
}


void  __stdcall _50clear(int _sk_22843)
{
    int _12752 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eumem:ram_space[sk][data] = {}*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_sk_22843))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_sk_22843)->dbl));
    else
    _3 = (int)(_sk_22843 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _12752 = NOVALUE;

    /** end procedure*/
    DeRef(_sk_22843);
    return;
    ;
}



// 0xF92EB1AC
