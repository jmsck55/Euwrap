// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _5set_colors(int _pColorList_11012)
{
    int _lColorName_11013 = NOVALUE;
    int _6214 = NOVALUE;
    int _6211 = NOVALUE;
    int _6208 = NOVALUE;
    int _6205 = NOVALUE;
    int _6202 = NOVALUE;
    int _6199 = NOVALUE;
    int _6196 = NOVALUE;
    int _6191 = NOVALUE;
    int _6190 = NOVALUE;
    int _6189 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(pColorList) do*/
    if (IS_SEQUENCE(_pColorList_11012)){
            _6189 = SEQ_PTR(_pColorList_11012)->length;
    }
    else {
        _6189 = 1;
    }
    {
        int _i_11015;
        _i_11015 = 1;
L1: 
        if (_i_11015 > _6189){
            goto L2; // [8] 168
        }

        /** 		lColorName = text:upper(pColorList[i][1])*/
        _2 = (int)SEQ_PTR(_pColorList_11012);
        _6190 = (int)*(((s1_ptr)_2)->base + _i_11015);
        _2 = (int)SEQ_PTR(_6190);
        _6191 = (int)*(((s1_ptr)_2)->base + 1);
        _6190 = NOVALUE;
        Ref(_6191);
        _0 = _lColorName_11013;
        _lColorName_11013 = _6upper(_6191);
        DeRef(_0);
        _6191 = NOVALUE;

        /** 		switch lColorName do*/
        _1 = find(_lColorName_11013, _6193);
        switch ( _1 ){ 

            /** 			case "NORMAL" then*/
            case 1:

            /** 				NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6196 = (int)*(((s1_ptr)_2)->base + _i_11015);
            _2 = (int)SEQ_PTR(_6196);
            _5NORMAL_COLOR_10989 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5NORMAL_COLOR_10989)){
                _5NORMAL_COLOR_10989 = (long)DBL_PTR(_5NORMAL_COLOR_10989)->dbl;
            }
            _6196 = NOVALUE;
            goto L3; // [54] 161

            /** 			case "COMMENT" then*/
            case 2:

            /** 				COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6199 = (int)*(((s1_ptr)_2)->base + _i_11015);
            _2 = (int)SEQ_PTR(_6199);
            _5COMMENT_COLOR_10990 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5COMMENT_COLOR_10990)){
                _5COMMENT_COLOR_10990 = (long)DBL_PTR(_5COMMENT_COLOR_10990)->dbl;
            }
            _6199 = NOVALUE;
            goto L3; // [72] 161

            /** 			case "KEYWORD" then*/
            case 3:

            /** 				KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6202 = (int)*(((s1_ptr)_2)->base + _i_11015);
            _2 = (int)SEQ_PTR(_6202);
            _5KEYWORD_COLOR_10991 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5KEYWORD_COLOR_10991)){
                _5KEYWORD_COLOR_10991 = (long)DBL_PTR(_5KEYWORD_COLOR_10991)->dbl;
            }
            _6202 = NOVALUE;
            goto L3; // [90] 161

            /** 			case "BUILTIN" then*/
            case 4:

            /** 				BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6205 = (int)*(((s1_ptr)_2)->base + _i_11015);
            _2 = (int)SEQ_PTR(_6205);
            _5BUILTIN_COLOR_10992 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5BUILTIN_COLOR_10992)){
                _5BUILTIN_COLOR_10992 = (long)DBL_PTR(_5BUILTIN_COLOR_10992)->dbl;
            }
            _6205 = NOVALUE;
            goto L3; // [108] 161

            /** 			case "STRING" then*/
            case 5:

            /** 				STRING_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6208 = (int)*(((s1_ptr)_2)->base + _i_11015);
            _2 = (int)SEQ_PTR(_6208);
            _5STRING_COLOR_10993 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_5STRING_COLOR_10993)){
                _5STRING_COLOR_10993 = (long)DBL_PTR(_5STRING_COLOR_10993)->dbl;
            }
            _6208 = NOVALUE;
            goto L3; // [126] 161

            /** 			case "BRACKET" then*/
            case 6:

            /** 				BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (int)SEQ_PTR(_pColorList_11012);
            _6211 = (int)*(((s1_ptr)_2)->base + _i_11015);
            DeRef(_5BRACKET_COLOR_10994);
            _2 = (int)SEQ_PTR(_6211);
            _5BRACKET_COLOR_10994 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_5BRACKET_COLOR_10994);
            _6211 = NOVALUE;
            goto L3; // [144] 161

            /** 			case else*/
            case 0:

            /** 				printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_lColorName_11013);
            *((int *)(_2+4)) = _lColorName_11013;
            _6214 = MAKE_SEQ(_1);
            EPrintf(2, _6213, _6214);
            DeRefDS(_6214);
            _6214 = NOVALUE;
        ;}L3: 

        /** 	end for*/
        _i_11015 = _i_11015 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_pColorList_11012);
    DeRef(_lColorName_11013);
    return;
    ;
}


void  __stdcall _5init_class()
{
    int _0, _1, _2;
    

    /** 	NORMAL_COLOR  = #330033*/
    _5NORMAL_COLOR_10989 = 3342387;

    /** 	COMMENT_COLOR = #FF0055*/
    _5COMMENT_COLOR_10990 = 16711765;

    /** 	KEYWORD_COLOR = #0000FF*/
    _5KEYWORD_COLOR_10991 = 255;

    /** 	BUILTIN_COLOR = #FF00FF*/
    _5BUILTIN_COLOR_10992 = 16711935;

    /** 	STRING_COLOR  = #00A033*/
    _5STRING_COLOR_10993 = 41011;

    /** 	BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _5BRACKET_COLOR_10994;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3342387;
    *((int *)(_2+8)) = 10040115;
    *((int *)(_2+12)) = 255;
    *((int *)(_2+16)) = 5570815;
    *((int *)(_2+20)) = 65280;
    _5BRACKET_COLOR_10994 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	char_class = repeat(OTHER, 255)*/
    DeRefi(_5char_class_11009);
    _5char_class_11009 = Repeat(2, 255);

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_5char_class_11009;
    AssignSlice(97, 122, 3);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_5char_class_11009;
    AssignSlice(65, 90, 3);

    /** 	char_class['_'] = LETTER*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = 3;

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_5char_class_11009;
    AssignSlice(48, 57, 1);

    /** 	char_class['['] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = 4;

    /** 	char_class[']'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = 4;

    /** 	char_class['('] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = 4;

    /** 	char_class[')'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = 4;

    /** 	char_class['{'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = 4;

    /** 	char_class['}'] = BRACKET*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = 4;

    /** 	char_class['\''] = QUOTE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = 5;

    /** 	char_class['"'] = QUOTE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = 5;

    /** 	char_class['`'] = BACKTICK*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = 6;

    /** 	char_class[' '] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = 9;

    /** 	char_class['\t'] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = 9;

    /** 	char_class['\r'] = WHITE_SPACE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = 9;

    /** 	char_class['\n'] = NEW_LINE*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = 10;

    /** 	char_class['-'] = DASH*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 7;

    /** 	char_class['/'] = FORWARD_SLASH*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 8;

    /** end procedure*/
    return;
    ;
}


void _5seg_flush(int _new_color_11068)
{
    int _6228 = NOVALUE;
    int _6227 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_color_11068)) {
        _1 = (long)(DBL_PTR(_new_color_11068)->dbl);
        DeRefDS(_new_color_11068);
        _new_color_11068 = _1;
    }

    /** 	if new_color != current_color then*/
    if (_new_color_11068 == _5current_color_11063)
    goto L1; // [7] 70

    /** 		if seg_start <= seg_end then*/
    if (_5seg_start_11064 > _5seg_end_11065)
    goto L2; // [17] 64

    /** 			if current_color != DONT_CARE then*/
    if (_5current_color_11063 == -1)
    goto L3; // [25] 63

    /** 				color_segments = append(color_segments,*/
    rhs_slice_target = (object_ptr)&_6227;
    RHS_Slice(_5line_11061, _5seg_start_11064, _5seg_end_11065);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5current_color_11063;
    ((int *)_2)[2] = _6227;
    _6228 = MAKE_SEQ(_1);
    _6227 = NOVALUE;
    RefDS(_6228);
    Append(&_5color_segments_11062, _5color_segments_11062, _6228);
    DeRefDS(_6228);
    _6228 = NOVALUE;

    /** 				seg_start = seg_end + 1*/
    _5seg_start_11064 = _5seg_end_11065 + 1;
L3: 
L2: 

    /** 		current_color = new_color*/
    _5current_color_11063 = _new_color_11068;
L1: 

    /** end procedure*/
    return;
    ;
}


int _5default_state()
{
    int _6231 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _6231 = MAKE_SEQ(_1);
    return _6231;
    ;
}


int  __stdcall _5new()
{
    int _state_11087 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom state = eumem:malloc()*/
    _0 = _state_11087;
    _state_11087 = _28malloc(1, 1);
    DeRef(_0);

    /** 	reset(state)*/
    Ref(_state_11087);
    _5reset(_state_11087);

    /** 	return state*/
    return _state_11087;
    ;
}


void  __stdcall _5reset(int _state_11092)
{
    int _6235 = NOVALUE;
    int _0, _1, _2;
    

    /** 	eumem:ram_space[state] = default_state()*/
    _6235 = _5default_state();
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11092))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11092)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _state_11092);
    _1 = *(int *)_2;
    *(int *)_2 = _6235;
    if( _1 != _6235 ){
        DeRef(_1);
    }
    _6235 = NOVALUE;

    /** end procedure*/
    DeRef(_state_11092);
    return;
    ;
}


int  __stdcall _5SyntaxColor(int _pline_11096, int _state_11097)
{
    int _class_11098 = NOVALUE;
    int _last_11099 = NOVALUE;
    int _i_11100 = NOVALUE;
    int _c_11101 = NOVALUE;
    int _word_11102 = NOVALUE;
    int _old_seg_end_11217 = NOVALUE;
    int _6382 = NOVALUE;
    int _6381 = NOVALUE;
    int _6380 = NOVALUE;
    int _6374 = NOVALUE;
    int _6373 = NOVALUE;
    int _6371 = NOVALUE;
    int _6368 = NOVALUE;
    int _6366 = NOVALUE;
    int _6363 = NOVALUE;
    int _6359 = NOVALUE;
    int _6357 = NOVALUE;
    int _6354 = NOVALUE;
    int _6351 = NOVALUE;
    int _6350 = NOVALUE;
    int _6348 = NOVALUE;
    int _6347 = NOVALUE;
    int _6346 = NOVALUE;
    int _6345 = NOVALUE;
    int _6344 = NOVALUE;
    int _6343 = NOVALUE;
    int _6342 = NOVALUE;
    int _6340 = NOVALUE;
    int _6338 = NOVALUE;
    int _6336 = NOVALUE;
    int _6333 = NOVALUE;
    int _6327 = NOVALUE;
    int _6326 = NOVALUE;
    int _6325 = NOVALUE;
    int _6323 = NOVALUE;
    int _6322 = NOVALUE;
    int _6318 = NOVALUE;
    int _6316 = NOVALUE;
    int _6310 = NOVALUE;
    int _6309 = NOVALUE;
    int _6305 = NOVALUE;
    int _6303 = NOVALUE;
    int _6302 = NOVALUE;
    int _6298 = NOVALUE;
    int _6297 = NOVALUE;
    int _6295 = NOVALUE;
    int _6294 = NOVALUE;
    int _6292 = NOVALUE;
    int _6291 = NOVALUE;
    int _6290 = NOVALUE;
    int _6289 = NOVALUE;
    int _6288 = NOVALUE;
    int _6287 = NOVALUE;
    int _6286 = NOVALUE;
    int _6285 = NOVALUE;
    int _6284 = NOVALUE;
    int _6283 = NOVALUE;
    int _6282 = NOVALUE;
    int _6281 = NOVALUE;
    int _6280 = NOVALUE;
    int _6278 = NOVALUE;
    int _6277 = NOVALUE;
    int _6272 = NOVALUE;
    int _6271 = NOVALUE;
    int _6269 = NOVALUE;
    int _6263 = NOVALUE;
    int _6262 = NOVALUE;
    int _6260 = NOVALUE;
    int _6254 = NOVALUE;
    int _6252 = NOVALUE;
    int _6251 = NOVALUE;
    int _6249 = NOVALUE;
    int _6248 = NOVALUE;
    int _6246 = NOVALUE;
    int _6245 = NOVALUE;
    int _6243 = NOVALUE;
    int _6241 = NOVALUE;
    int _6240 = NOVALUE;
    int _6239 = NOVALUE;
    int _6238 = NOVALUE;
    int _6237 = NOVALUE;
    int _6236 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length(pline) > 0 and pline[$] != '\n' then*/
    if (IS_SEQUENCE(_pline_11096)){
            _6236 = SEQ_PTR(_pline_11096)->length;
    }
    else {
        _6236 = 1;
    }
    _6237 = (_6236 > 0);
    _6236 = NOVALUE;
    if (_6237 == 0) {
        goto L1; // [12] 38
    }
    if (IS_SEQUENCE(_pline_11096)){
            _6239 = SEQ_PTR(_pline_11096)->length;
    }
    else {
        _6239 = 1;
    }
    _2 = (int)SEQ_PTR(_pline_11096);
    _6240 = (int)*(((s1_ptr)_2)->base + _6239);
    if (IS_ATOM_INT(_6240)) {
        _6241 = (_6240 != 10);
    }
    else {
        _6241 = binary_op(NOTEQ, _6240, 10);
    }
    _6240 = NOVALUE;
    if (_6241 == 0) {
        DeRef(_6241);
        _6241 = NOVALUE;
        goto L1; // [28] 38
    }
    else {
        if (!IS_ATOM_INT(_6241) && DBL_PTR(_6241)->dbl == 0.0){
            DeRef(_6241);
            _6241 = NOVALUE;
            goto L1; // [28] 38
        }
        DeRef(_6241);
        _6241 = NOVALUE;
    }
    DeRef(_6241);
    _6241 = NOVALUE;

    /** 		pline &= '\n'*/
    Append(&_pline_11096, _pline_11096, 10);
L1: 

    /** 	if length(pline) < 2 then*/
    if (IS_SEQUENCE(_pline_11096)){
            _6243 = SEQ_PTR(_pline_11096)->length;
    }
    else {
        _6243 = 1;
    }
    if (_6243 >= 2)
    goto L2; // [43] 54

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_pline_11096);
    DeRef(_state_11097);
    DeRef(_word_11102);
    DeRef(_6237);
    _6237 = NOVALUE;
    return _5;
L2: 

    /** 	line = pline*/
    RefDS(_pline_11096);
    DeRef(_5line_11061);
    _5line_11061 = _pline_11096;

    /** 	current_color = DONT_CARE*/
    _5current_color_11063 = -1;

    /** 	seg_start = 1*/
    _5seg_start_11064 = 1;

    /** 	seg_end = 0*/
    _5seg_end_11065 = 0;

    /** 	color_segments = {}*/
    RefDS(_5);
    DeRef(_5color_segments_11062);
    _5color_segments_11062 = _5;

    /** 	if eumem:ram_space[state][S_MULTILINE_COMMENT] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6245 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6245 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6245);
    _6246 = (int)*(((s1_ptr)_2)->base + 3);
    _6245 = NOVALUE;
    if (_6246 == 0) {
        _6246 = NOVALUE;
        goto L3; // [95] 107
    }
    else {
        if (!IS_ATOM_INT(_6246) && DBL_PTR(_6246)->dbl == 0.0){
            _6246 = NOVALUE;
            goto L3; // [95] 107
        }
        _6246 = NOVALUE;
    }
    _6246 = NOVALUE;

    /** 		goto "MULTILINE_COMMENT"*/
    goto G4;
    goto L5; // [104] 154
L3: 

    /** 	elsif eumem:ram_space[state][S_STRING_TRIPLE] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6248 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6248 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6248);
    _6249 = (int)*(((s1_ptr)_2)->base + 1);
    _6248 = NOVALUE;
    if (_6249 == 0) {
        _6249 = NOVALUE;
        goto L6; // [119] 131
    }
    else {
        if (!IS_ATOM_INT(_6249) && DBL_PTR(_6249)->dbl == 0.0){
            _6249 = NOVALUE;
            goto L6; // [119] 131
        }
        _6249 = NOVALUE;
    }
    _6249 = NOVALUE;

    /** 		goto "MULTILINE_STRING"*/
    goto G7;
    goto L5; // [128] 154
L6: 

    /** 	elsif eumem:ram_space[state][S_STRING_BACKTICK] then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6251 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6251 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6251);
    _6252 = (int)*(((s1_ptr)_2)->base + 2);
    _6251 = NOVALUE;
    if (_6252 == 0) {
        _6252 = NOVALUE;
        goto L8; // [143] 153
    }
    else {
        if (!IS_ATOM_INT(_6252) && DBL_PTR(_6252)->dbl == 0.0){
            _6252 = NOVALUE;
            goto L8; // [143] 153
        }
        _6252 = NOVALUE;
    }
    _6252 = NOVALUE;

    /** 		goto "BACKTICK_STRING"*/
    goto G9;
L8: 
L5: 

    /** 	while 1 do*/
LA: 

    /** 		c = line[seg_end + 1]*/
    _6254 = _5seg_end_11065 + 1;
    _2 = (int)SEQ_PTR(_5line_11061);
    _c_11101 = (int)*(((s1_ptr)_2)->base + _6254);
    if (!IS_ATOM_INT(_c_11101))
    _c_11101 = (long)DBL_PTR(_c_11101)->dbl;

    /** 		class = char_class[c]*/
    _2 = (int)SEQ_PTR(_5char_class_11009);
    _class_11098 = (int)*(((s1_ptr)_2)->base + _c_11101);

    /** 		if class = WHITE_SPACE then*/
    if (_class_11098 != 9)
    goto LB; // [183] 198

    /** 			seg_end += 1  -- continue with current color*/
    _5seg_end_11065 = _5seg_end_11065 + 1;
    goto LA; // [195] 159
LB: 

    /** 		elsif class = LETTER then*/
    if (_class_11098 != 3)
    goto LC; // [200] 357

    /** 			last = length(line)-1*/
    if (IS_SEQUENCE(_5line_11061)){
            _6260 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6260 = 1;
    }
    _last_11099 = _6260 - 1;
    _6260 = NOVALUE;

    /** 			for j = seg_end + 2 to last do*/
    _6262 = _5seg_end_11065 + 2;
    if ((long)((unsigned long)_6262 + (unsigned long)HIGH_BITS) >= 0) 
    _6262 = NewDouble((double)_6262);
    _6263 = _last_11099;
    {
        int _j_11138;
        Ref(_6262);
        _j_11138 = _6262;
LD: 
        if (binary_op_a(GREATER, _j_11138, _6263)){
            goto LE; // [226] 282
        }

        /** 				c = line[j]*/
        _2 = (int)SEQ_PTR(_5line_11061);
        if (!IS_ATOM_INT(_j_11138)){
            _c_11101 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_j_11138)->dbl));
        }
        else{
            _c_11101 = (int)*(((s1_ptr)_2)->base + _j_11138);
        }
        if (!IS_ATOM_INT(_c_11101))
        _c_11101 = (long)DBL_PTR(_c_11101)->dbl;

        /** 				class = char_class[c]*/
        _2 = (int)SEQ_PTR(_5char_class_11009);
        _class_11098 = (int)*(((s1_ptr)_2)->base + _c_11101);

        /** 				if class != LETTER then*/
        if (_class_11098 == 3)
        goto LF; // [251] 275

        /** 					if class != DIGIT then*/
        if (_class_11098 == 1)
        goto L10; // [257] 274

        /** 						last = j - 1*/
        if (IS_ATOM_INT(_j_11138)) {
            _last_11099 = _j_11138 - 1;
        }
        else {
            _last_11099 = NewDouble(DBL_PTR(_j_11138)->dbl - (double)1);
        }
        if (!IS_ATOM_INT(_last_11099)) {
            _1 = (long)(DBL_PTR(_last_11099)->dbl);
            DeRefDS(_last_11099);
            _last_11099 = _1;
        }

        /** 						exit*/
        goto LE; // [271] 282
L10: 
LF: 

        /** 			end for*/
        _0 = _j_11138;
        if (IS_ATOM_INT(_j_11138)) {
            _j_11138 = _j_11138 + 1;
            if ((long)((unsigned long)_j_11138 +(unsigned long) HIGH_BITS) >= 0){
                _j_11138 = NewDouble((double)_j_11138);
            }
        }
        else {
            _j_11138 = binary_op_a(PLUS, _j_11138, 1);
        }
        DeRef(_0);
        goto LD; // [277] 233
LE: 
        ;
        DeRef(_j_11138);
    }

    /** 			word = line[seg_end+1..last]*/
    _6269 = _5seg_end_11065 + 1;
    rhs_slice_target = (object_ptr)&_word_11102;
    RHS_Slice(_5line_11061, _6269, _last_11099);

    /** 			if find(word, keywords) then*/
    _6271 = find_from(_word_11102, _4keywords_296, 1);
    if (_6271 == 0)
    {
        _6271 = NOVALUE;
        goto L11; // [306] 319
    }
    else{
        _6271 = NOVALUE;
    }

    /** 				seg_flush(KEYWORD_COLOR)*/
    _5seg_flush(_5KEYWORD_COLOR_10991);
    goto L12; // [316] 349
L11: 

    /** 			elsif find(word, builtins) then*/
    _6272 = find_from(_word_11102, _4builtins_343, 1);
    if (_6272 == 0)
    {
        _6272 = NOVALUE;
        goto L13; // [328] 341
    }
    else{
        _6272 = NOVALUE;
    }

    /** 				seg_flush(BUILTIN_COLOR)*/
    _5seg_flush(_5BUILTIN_COLOR_10992);
    goto L12; // [338] 349
L13: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10989);
L12: 

    /** 			seg_end = last*/
    _5seg_end_11065 = _last_11099;
    goto LA; // [354] 159
LC: 

    /** 		elsif class <= OTHER then -- DIGIT too*/
    if (_class_11098 > 2)
    goto L14; // [359] 381

    /** 			seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10989);

    /** 			seg_end += 1*/
    _5seg_end_11065 = _5seg_end_11065 + 1;
    goto LA; // [378] 159
L14: 

    /** 		elsif class = BRACKET then*/
    if (_class_11098 != 4)
    goto L15; // [383] 537

    /** 			if find(c, "([{") then*/
    _6277 = find_from(_c_11101, _6276, 1);
    if (_6277 == 0)
    {
        _6277 = NOVALUE;
        goto L16; // [394] 419
    }
    else{
        _6277 = NOVALUE;
    }

    /** 				eumem:ram_space[state][S_BRACKET_LEVEL] += 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _6280 = (int)*(((s1_ptr)_2)->base + 4);
    _6278 = NOVALUE;
    if (IS_ATOM_INT(_6280)) {
        _6281 = _6280 + 1;
        if (_6281 > MAXINT){
            _6281 = NewDouble((double)_6281);
        }
    }
    else
    _6281 = binary_op(PLUS, 1, _6280);
    _6280 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _6281;
    if( _1 != _6281 ){
        DeRef(_1);
    }
    _6281 = NOVALUE;
    _6278 = NOVALUE;
L16: 

    /** 			if eumem:ram_space[state][S_BRACKET_LEVEL] >= 1 and*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6282 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6282 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6282);
    _6283 = (int)*(((s1_ptr)_2)->base + 4);
    _6282 = NOVALUE;
    if (IS_ATOM_INT(_6283)) {
        _6284 = (_6283 >= 1);
    }
    else {
        _6284 = binary_op(GREATEREQ, _6283, 1);
    }
    _6283 = NOVALUE;
    if (IS_ATOM_INT(_6284)) {
        if (_6284 == 0) {
            goto L17; // [435] 486
        }
    }
    else {
        if (DBL_PTR(_6284)->dbl == 0.0) {
            goto L17; // [435] 486
        }
    }
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6286 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6286 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6286);
    _6287 = (int)*(((s1_ptr)_2)->base + 4);
    _6286 = NOVALUE;
    if (IS_SEQUENCE(_5BRACKET_COLOR_10994)){
            _6288 = SEQ_PTR(_5BRACKET_COLOR_10994)->length;
    }
    else {
        _6288 = 1;
    }
    if (IS_ATOM_INT(_6287)) {
        _6289 = (_6287 <= _6288);
    }
    else {
        _6289 = binary_op(LESSEQ, _6287, _6288);
    }
    _6287 = NOVALUE;
    _6288 = NOVALUE;
    if (_6289 == 0) {
        DeRef(_6289);
        _6289 = NOVALUE;
        goto L17; // [459] 486
    }
    else {
        if (!IS_ATOM_INT(_6289) && DBL_PTR(_6289)->dbl == 0.0){
            DeRef(_6289);
            _6289 = NOVALUE;
            goto L17; // [459] 486
        }
        DeRef(_6289);
        _6289 = NOVALUE;
    }
    DeRef(_6289);
    _6289 = NOVALUE;

    /** 				seg_flush(BRACKET_COLOR[eumem:ram_space[state][S_BRACKET_LEVEL]])*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_state_11097)){
        _6290 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    }
    else{
        _6290 = (int)*(((s1_ptr)_2)->base + _state_11097);
    }
    _2 = (int)SEQ_PTR(_6290);
    _6291 = (int)*(((s1_ptr)_2)->base + 4);
    _6290 = NOVALUE;
    _2 = (int)SEQ_PTR(_5BRACKET_COLOR_10994);
    if (!IS_ATOM_INT(_6291)){
        _6292 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6291)->dbl));
    }
    else{
        _6292 = (int)*(((s1_ptr)_2)->base + _6291);
    }
    Ref(_6292);
    _5seg_flush(_6292);
    _6292 = NOVALUE;
    goto L18; // [483] 494
L17: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10989);
L18: 

    /** 			if find(c, ")]}") then*/
    _6294 = find_from(_c_11101, _6293, 1);
    if (_6294 == 0)
    {
        _6294 = NOVALUE;
        goto L19; // [501] 526
    }
    else{
        _6294 = NOVALUE;
    }

    /** 				eumem:ram_space[state][S_BRACKET_LEVEL] -= 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _6297 = (int)*(((s1_ptr)_2)->base + 4);
    _6295 = NOVALUE;
    if (IS_ATOM_INT(_6297)) {
        _6298 = _6297 - 1;
        if ((long)((unsigned long)_6298 +(unsigned long) HIGH_BITS) >= 0){
            _6298 = NewDouble((double)_6298);
        }
    }
    else {
        _6298 = binary_op(MINUS, _6297, 1);
    }
    _6297 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _6298;
    if( _1 != _6298 ){
        DeRef(_1);
    }
    _6298 = NOVALUE;
    _6295 = NOVALUE;
L19: 

    /** 			seg_end += 1*/
    _5seg_end_11065 = _5seg_end_11065 + 1;
    goto LA; // [534] 159
L15: 

    /** 		elsif class = NEW_LINE then*/
    if (_class_11098 != 10)
    goto L1A; // [539] 550

    /** 			exit  -- end of line*/
    goto L1B; // [545] 1181
    goto LA; // [547] 159
L1A: 

    /** 		elsif class = DASH then*/
    if (_class_11098 != 7)
    goto L1C; // [552] 615

    /** 			if line[seg_end+2] = '-' then*/
    _6302 = _5seg_end_11065 + 2;
    _2 = (int)SEQ_PTR(_5line_11061);
    _6303 = (int)*(((s1_ptr)_2)->base + _6302);
    if (binary_op_a(NOTEQ, _6303, 45)){
        _6303 = NOVALUE;
        goto L1D; // [570] 597
    }
    _6303 = NOVALUE;

    /** 				seg_flush(COMMENT_COLOR)*/
    _5seg_flush(_5COMMENT_COLOR_10990);

    /** 				seg_end = length(line)-1*/
    if (IS_SEQUENCE(_5line_11061)){
            _6305 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6305 = 1;
    }
    _5seg_end_11065 = _6305 - 1;
    _6305 = NOVALUE;

    /** 				exit*/
    goto L1B; // [594] 1181
L1D: 

    /** 			seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10989);

    /** 			seg_end += 1*/
    _5seg_end_11065 = _5seg_end_11065 + 1;
    goto LA; // [612] 159
L1C: 

    /** 		elsif class = FORWARD_SLASH then*/
    if (_class_11098 != 8)
    goto L1E; // [617] 794

    /** 			if line[seg_end + 2] = '*' then*/
    _6309 = _5seg_end_11065 + 2;
    _2 = (int)SEQ_PTR(_5line_11061);
    _6310 = (int)*(((s1_ptr)_2)->base + _6309);
    if (binary_op_a(NOTEQ, _6310, 42)){
        _6310 = NOVALUE;
        goto L1F; // [635] 775
    }
    _6310 = NOVALUE;

    /** label "MULTILINE_COMMENT"*/
G4:

    /** 				if seg_end = 0 then*/
    if (_5seg_end_11065 != 0)
    goto L20; // [647] 657

    /** 					seg_end = 1*/
    _5seg_end_11065 = 1;
L20: 

    /** 				seg_flush(COMMENT_COLOR)*/
    _5seg_flush(_5COMMENT_COLOR_10990);

    //				i = match("*/", line, seg_end)
    _i_11100 = e_match_from(_6313, _5line_11061, _5seg_end_11065);

    /** 				if i = 0 then*/
    if (_i_11100 != 0)
    goto L21; // [677] 710

    /** 					eumem:ram_space[state][S_MULTILINE_COMMENT] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6316 = NOVALUE;

    /** 					seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_11061)){
            _6318 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6318 = 1;
    }
    _5seg_end_11065 = _6318 - 1;
    _6318 = NOVALUE;

    /** 					exit*/
    goto L1B; // [707] 1181
L21: 

    /** 				integer old_seg_end = seg_end + 2*/
    _old_seg_end_11217 = _5seg_end_11065 + 2;

    /** 				seg_end = i + 1*/
    _5seg_end_11065 = _i_11100 + 1;

    //				if old_seg_end < i and match("/*", line[old_seg_end..i]) then
    _6322 = (_old_seg_end_11217 < _i_11100);
    if (_6322 == 0) {
        goto L22; // [730] 757
    }
    rhs_slice_target = (object_ptr)&_6325;
    RHS_Slice(_5line_11061, _old_seg_end_11217, _i_11100);
    _6326 = e_match_from(_6324, _6325, 1);
    DeRefDS(_6325);
    _6325 = NOVALUE;
    if (_6326 == 0)
    {
        _6326 = NOVALUE;
        goto L22; // [747] 757
    }
    else{
        _6326 = NOVALUE;
    }

    /** 					goto "MULTILINE_COMMENT"*/
    goto G4;
L22: 

    /** 				eumem:ram_space[state][S_MULTILINE_COMMENT] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6327 = NOVALUE;
    goto LA; // [772] 159
L1F: 

    /** 				seg_flush(NORMAL_COLOR)*/
    _5seg_flush(_5NORMAL_COLOR_10989);

    /** 				seg_end += 1*/
    _5seg_end_11065 = _5seg_end_11065 + 1;
    goto LA; // [791] 159
L1E: 

    /** 		elsif class = BACKTICK then*/
    if (_class_11098 != 6)
    goto L23; // [798] 898

    /** label "BACKTICK_STRING"*/
G9:

    /** 			if seg_end = 0 then*/
    if (_5seg_end_11065 != 0)
    goto L24; // [810] 820

    /** 				seg_end = 1*/
    _5seg_end_11065 = 1;
L24: 

    /** 			seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10993);

    /** 			i = match("`", line, seg_end + 2)*/
    _6333 = _5seg_end_11065 + 2;
    if ((long)((unsigned long)_6333 + (unsigned long)HIGH_BITS) >= 0) 
    _6333 = NewDouble((double)_6333);
    _i_11100 = e_match_from(_6332, _5line_11061, _6333);
    DeRef(_6333);
    _6333 = NOVALUE;

    /** 			if i = 0 then*/
    if (_i_11100 != 0)
    goto L25; // [844] 877

    /** 				eumem:ram_space[state][S_STRING_BACKTICK] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6336 = NOVALUE;

    /** 				seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_11061)){
            _6338 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6338 = 1;
    }
    _5seg_end_11065 = _6338 - 1;
    _6338 = NOVALUE;

    /** 				exit*/
    goto L1B; // [874] 1181
L25: 

    /** 			seg_end = i*/
    _5seg_end_11065 = _i_11100;

    /** 			eumem:ram_space[state][S_STRING_BACKTICK] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6340 = NOVALUE;
    goto LA; // [895] 159
L23: 

    /** 			if line[seg_end + 2] = '"' and line[seg_end + 3] = '"' then*/
    _6342 = _5seg_end_11065 + 2;
    _2 = (int)SEQ_PTR(_5line_11061);
    _6343 = (int)*(((s1_ptr)_2)->base + _6342);
    if (IS_ATOM_INT(_6343)) {
        _6344 = (_6343 == 34);
    }
    else {
        _6344 = binary_op(EQUALS, _6343, 34);
    }
    _6343 = NOVALUE;
    if (IS_ATOM_INT(_6344)) {
        if (_6344 == 0) {
            goto L26; // [916] 1065
        }
    }
    else {
        if (DBL_PTR(_6344)->dbl == 0.0) {
            goto L26; // [916] 1065
        }
    }
    _6346 = _5seg_end_11065 + 3;
    _2 = (int)SEQ_PTR(_5line_11061);
    _6347 = (int)*(((s1_ptr)_2)->base + _6346);
    if (IS_ATOM_INT(_6347)) {
        _6348 = (_6347 == 34);
    }
    else {
        _6348 = binary_op(EQUALS, _6347, 34);
    }
    _6347 = NOVALUE;
    if (_6348 == 0) {
        DeRef(_6348);
        _6348 = NOVALUE;
        goto L26; // [937] 1065
    }
    else {
        if (!IS_ATOM_INT(_6348) && DBL_PTR(_6348)->dbl == 0.0){
            DeRef(_6348);
            _6348 = NOVALUE;
            goto L26; // [937] 1065
        }
        DeRef(_6348);
        _6348 = NOVALUE;
    }
    DeRef(_6348);
    _6348 = NOVALUE;

    /** label "MULTILINE_STRING"*/
G7:

    /** 				seg_end += 1*/
    _5seg_end_11065 = _5seg_end_11065 + 1;

    /** 				seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10993);

    /** 				if seg_end + 3 < length(line) then*/
    _6350 = _5seg_end_11065 + 3;
    if ((long)((unsigned long)_6350 + (unsigned long)HIGH_BITS) >= 0) 
    _6350 = NewDouble((double)_6350);
    if (IS_SEQUENCE(_5line_11061)){
            _6351 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6351 = 1;
    }
    if (binary_op_a(GREATEREQ, _6350, _6351)){
        DeRef(_6350);
        _6350 = NOVALUE;
        _6351 = NOVALUE;
        goto L27; // [972] 1029
    }
    DeRef(_6350);
    _6350 = NOVALUE;
    _6351 = NOVALUE;

    /** 					i = match(`"""`, line, seg_end + 3)*/
    _6354 = _5seg_end_11065 + 3;
    if ((long)((unsigned long)_6354 + (unsigned long)HIGH_BITS) >= 0) 
    _6354 = NewDouble((double)_6354);
    _i_11100 = e_match_from(_6353, _5line_11061, _6354);
    DeRef(_6354);
    _6354 = NOVALUE;

    /** 					if i = 0 then*/
    if (_i_11100 != 0)
    goto L28; // [993] 1041

    /** 						eumem:ram_space[state][S_STRING_TRIPLE] = 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6357 = NOVALUE;

    /** 						seg_end = length(line) - 1*/
    if (IS_SEQUENCE(_5line_11061)){
            _6359 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6359 = 1;
    }
    _5seg_end_11065 = _6359 - 1;
    _6359 = NOVALUE;

    /** 						exit*/
    goto L1B; // [1023] 1181
    goto L28; // [1026] 1041
L27: 

    /** 					i = length(line)*/
    if (IS_SEQUENCE(_5line_11061)){
            _i_11100 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _i_11100 = 1;
    }

    /** 					exit*/
    goto L1B; // [1038] 1181
L28: 

    /** 				seg_end = i + 2*/
    _5seg_end_11065 = _i_11100 + 2;

    /** 				eumem:ram_space[state][S_STRING_TRIPLE] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_11097))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_state_11097)->dbl));
    else
    _3 = (int)(_state_11097 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6363 = NOVALUE;
    goto LA; // [1062] 159
L26: 

    /** 				i = seg_end + 2*/
    _i_11100 = _5seg_end_11065 + 2;

    /** 				while i < length(line) do*/
L29: 
    if (IS_SEQUENCE(_5line_11061)){
            _6366 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6366 = 1;
    }
    if (_i_11100 >= _6366)
    goto L2A; // [1083] 1161

    /** 					if line[i] = c then*/
    _2 = (int)SEQ_PTR(_5line_11061);
    _6368 = (int)*(((s1_ptr)_2)->base + _i_11100);
    if (binary_op_a(NOTEQ, _6368, _c_11101)){
        _6368 = NOVALUE;
        goto L2B; // [1097] 1114
    }
    _6368 = NOVALUE;

    /** 						i += 1*/
    _i_11100 = _i_11100 + 1;

    /** 						exit*/
    goto L2A; // [1109] 1161
    goto L2C; // [1111] 1150
L2B: 

    /** 					elsif line[i] = '\\' then*/
    _2 = (int)SEQ_PTR(_5line_11061);
    _6371 = (int)*(((s1_ptr)_2)->base + _i_11100);
    if (binary_op_a(NOTEQ, _6371, 92)){
        _6371 = NOVALUE;
        goto L2D; // [1122] 1149
    }
    _6371 = NOVALUE;

    /** 						if i < length(line)-1 then*/
    if (IS_SEQUENCE(_5line_11061)){
            _6373 = SEQ_PTR(_5line_11061)->length;
    }
    else {
        _6373 = 1;
    }
    _6374 = _6373 - 1;
    _6373 = NOVALUE;
    if (_i_11100 >= _6374)
    goto L2E; // [1137] 1148

    /** 							i += 1 -- ignore escaped char*/
    _i_11100 = _i_11100 + 1;
L2E: 
L2D: 
L2C: 

    /** 					i += 1*/
    _i_11100 = _i_11100 + 1;

    /** 				end while*/
    goto L29; // [1158] 1078
L2A: 

    /** 				seg_flush(STRING_COLOR)*/
    _5seg_flush(_5STRING_COLOR_10993);

    /** 				seg_end = i - 1*/
    _5seg_end_11065 = _i_11100 - 1;

    /** 	end while*/
    goto LA; // [1178] 159
L1B: 

    /** 	if current_color = DONT_CARE then*/
    if (_5current_color_11063 != -1)
    goto L2F; // [1185] 1197

    /** 		current_color = NORMAL_COLOR*/
    _5current_color_11063 = _5NORMAL_COLOR_10989;
L2F: 

    /** 	return append(color_segments, {current_color, line[seg_start..seg_end]})*/
    rhs_slice_target = (object_ptr)&_6380;
    RHS_Slice(_5line_11061, _5seg_start_11064, _5seg_end_11065);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5current_color_11063;
    ((int *)_2)[2] = _6380;
    _6381 = MAKE_SEQ(_1);
    _6380 = NOVALUE;
    RefDS(_6381);
    Append(&_6382, _5color_segments_11062, _6381);
    DeRefDS(_6381);
    _6381 = NOVALUE;
    DeRefDS(_pline_11096);
    DeRef(_state_11097);
    DeRef(_word_11102);
    DeRef(_6237);
    _6237 = NOVALUE;
    DeRef(_6254);
    _6254 = NOVALUE;
    DeRef(_6262);
    _6262 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    _6291 = NOVALUE;
    DeRef(_6284);
    _6284 = NOVALUE;
    DeRef(_6302);
    _6302 = NOVALUE;
    DeRef(_6309);
    _6309 = NOVALUE;
    DeRef(_6322);
    _6322 = NOVALUE;
    DeRef(_6342);
    _6342 = NOVALUE;
    DeRef(_6346);
    _6346 = NOVALUE;
    DeRef(_6344);
    _6344 = NOVALUE;
    DeRef(_6374);
    _6374 = NOVALUE;
    return _6382;
    ;
}



// 0x9AA7E07B
