// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _31local_abort(int _lvl_15512)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517 = NOVALUE;
    int _8734 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_31pause_msg_15509)){
            _8734 = SEQ_PTR(_31pause_msg_15509)->length;
    }
    else {
        _8734 = 1;
    }
    if (_8734 == 0)
    goto L1; // [10] 45

    /** 		console:maybe_any_key(pause_msg, 1)*/

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_31pause_msg_15509);
    _32any_key(_31pause_msg_15509, 1);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15517 = NOVALUE;
L1: 

    /** 	abort(lvl)*/
    UserCleanup(_lvl_15512);

    /** end procedure*/
    return;
    ;
}


int _31standardize_opts(int _opts_15520, int _auto_help_switches_15521)
{
    int _lExtras_15522 = NOVALUE;
    int _opt_15526 = NOVALUE;
    int _updated_15528 = NOVALUE;
    int _msg_inlined_crash_at_178_15560 = NOVALUE;
    int _msg_inlined_crash_at_354_15591 = NOVALUE;
    int _msg_inlined_crash_at_410_15600 = NOVALUE;
    int _msg_inlined_crash_at_460_15609 = NOVALUE;
    int _msg_inlined_crash_at_510_15618 = NOVALUE;
    int _msg_inlined_crash_at_560_15627 = NOVALUE;
    int _opt_15661 = NOVALUE;
    int _msg_inlined_crash_at_878_15680 = NOVALUE;
    int _data_inlined_crash_at_875_15679 = NOVALUE;
    int _msg_inlined_crash_at_967_15698 = NOVALUE;
    int _data_inlined_crash_at_964_15697 = NOVALUE;
    int _has_h_15699 = NOVALUE;
    int _has_help_15700 = NOVALUE;
    int _has_question_15701 = NOVALUE;
    int _appended_opts_15721 = NOVALUE;
    int _8911 = NOVALUE;
    int _8910 = NOVALUE;
    int _8908 = NOVALUE;
    int _8907 = NOVALUE;
    int _8906 = NOVALUE;
    int _8905 = NOVALUE;
    int _8904 = NOVALUE;
    int _8903 = NOVALUE;
    int _8902 = NOVALUE;
    int _8901 = NOVALUE;
    int _8900 = NOVALUE;
    int _8899 = NOVALUE;
    int _8898 = NOVALUE;
    int _8897 = NOVALUE;
    int _8895 = NOVALUE;
    int _8894 = NOVALUE;
    int _8893 = NOVALUE;
    int _8892 = NOVALUE;
    int _8891 = NOVALUE;
    int _8890 = NOVALUE;
    int _8889 = NOVALUE;
    int _8888 = NOVALUE;
    int _8887 = NOVALUE;
    int _8886 = NOVALUE;
    int _8885 = NOVALUE;
    int _8884 = NOVALUE;
    int _8882 = NOVALUE;
    int _8880 = NOVALUE;
    int _8879 = NOVALUE;
    int _8878 = NOVALUE;
    int _8877 = NOVALUE;
    int _8875 = NOVALUE;
    int _8873 = NOVALUE;
    int _8870 = NOVALUE;
    int _8867 = NOVALUE;
    int _8864 = NOVALUE;
    int _8862 = NOVALUE;
    int _8861 = NOVALUE;
    int _8860 = NOVALUE;
    int _8859 = NOVALUE;
    int _8857 = NOVALUE;
    int _8856 = NOVALUE;
    int _8855 = NOVALUE;
    int _8853 = NOVALUE;
    int _8852 = NOVALUE;
    int _8851 = NOVALUE;
    int _8849 = NOVALUE;
    int _8848 = NOVALUE;
    int _8847 = NOVALUE;
    int _8846 = NOVALUE;
    int _8845 = NOVALUE;
    int _8843 = NOVALUE;
    int _8842 = NOVALUE;
    int _8841 = NOVALUE;
    int _8840 = NOVALUE;
    int _8839 = NOVALUE;
    int _8838 = NOVALUE;
    int _8837 = NOVALUE;
    int _8836 = NOVALUE;
    int _8835 = NOVALUE;
    int _8834 = NOVALUE;
    int _8832 = NOVALUE;
    int _8831 = NOVALUE;
    int _8830 = NOVALUE;
    int _8829 = NOVALUE;
    int _8828 = NOVALUE;
    int _8827 = NOVALUE;
    int _8826 = NOVALUE;
    int _8825 = NOVALUE;
    int _8823 = NOVALUE;
    int _8822 = NOVALUE;
    int _8821 = NOVALUE;
    int _8820 = NOVALUE;
    int _8819 = NOVALUE;
    int _8818 = NOVALUE;
    int _8817 = NOVALUE;
    int _8816 = NOVALUE;
    int _8815 = NOVALUE;
    int _8814 = NOVALUE;
    int _8813 = NOVALUE;
    int _8812 = NOVALUE;
    int _8811 = NOVALUE;
    int _8810 = NOVALUE;
    int _8809 = NOVALUE;
    int _8807 = NOVALUE;
    int _8805 = NOVALUE;
    int _8804 = NOVALUE;
    int _8803 = NOVALUE;
    int _8802 = NOVALUE;
    int _8800 = NOVALUE;
    int _8799 = NOVALUE;
    int _8798 = NOVALUE;
    int _8797 = NOVALUE;
    int _8795 = NOVALUE;
    int _8794 = NOVALUE;
    int _8793 = NOVALUE;
    int _8792 = NOVALUE;
    int _8790 = NOVALUE;
    int _8789 = NOVALUE;
    int _8788 = NOVALUE;
    int _8787 = NOVALUE;
    int _8785 = NOVALUE;
    int _8784 = NOVALUE;
    int _8783 = NOVALUE;
    int _8782 = NOVALUE;
    int _8779 = NOVALUE;
    int _8778 = NOVALUE;
    int _8777 = NOVALUE;
    int _8776 = NOVALUE;
    int _8775 = NOVALUE;
    int _8774 = NOVALUE;
    int _8773 = NOVALUE;
    int _8772 = NOVALUE;
    int _8770 = NOVALUE;
    int _8769 = NOVALUE;
    int _8768 = NOVALUE;
    int _8767 = NOVALUE;
    int _8766 = NOVALUE;
    int _8765 = NOVALUE;
    int _8764 = NOVALUE;
    int _8763 = NOVALUE;
    int _8760 = NOVALUE;
    int _8759 = NOVALUE;
    int _8758 = NOVALUE;
    int _8757 = NOVALUE;
    int _8756 = NOVALUE;
    int _8755 = NOVALUE;
    int _8754 = NOVALUE;
    int _8753 = NOVALUE;
    int _8752 = NOVALUE;
    int _8751 = NOVALUE;
    int _8750 = NOVALUE;
    int _8749 = NOVALUE;
    int _8748 = NOVALUE;
    int _8747 = NOVALUE;
    int _8746 = NOVALUE;
    int _8745 = NOVALUE;
    int _8744 = NOVALUE;
    int _8742 = NOVALUE;
    int _8741 = NOVALUE;
    int _8740 = NOVALUE;
    int _8738 = NOVALUE;
    int _8736 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_15522 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15520)){
            _8736 = SEQ_PTR(_opts_15520)->length;
    }
    else {
        _8736 = 1;
    }
    {
        int _i_15524;
        _i_15524 = 1;
L1: 
        if (_i_15524 > _8736){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_15526);
        _2 = (int)SEQ_PTR(_opts_15520);
        _opt_15526 = (int)*(((s1_ptr)_2)->base + _i_15524);
        Ref(_opt_15526);

        /** 		integer updated = 0*/
        _updated_15528 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_15526)){
                _8738 = SEQ_PTR(_opt_15526)->length;
        }
        else {
            _8738 = 1;
        }
        if (_8738 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_15526)){
                _8740 = SEQ_PTR(_opt_15526)->length;
        }
        else {
            _8740 = 1;
        }
        _8741 = 6 - _8740;
        _8740 = NOVALUE;
        _8742 = Repeat(-1, _8741);
        _8741 = NOVALUE;
        Concat((object_ptr)&_opt_15526, _opt_15526, _8742);
        DeRefDS(_8742);
        _8742 = NOVALUE;

        /** 			updated = 1*/
        _updated_15528 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8744 = (int)*(((s1_ptr)_2)->base + 1);
        _8745 = IS_SEQUENCE(_8744);
        _8744 = NOVALUE;
        if (_8745 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_15526);
        _8747 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_8747)){
                _8748 = SEQ_PTR(_8747)->length;
        }
        else {
            _8748 = 1;
        }
        _8747 = NOVALUE;
        _8749 = (_8748 == 0);
        _8748 = NOVALUE;
        if (_8749 == 0)
        {
            DeRef(_8749);
            _8749 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_8749);
            _8749 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8750 = (int)*(((s1_ptr)_2)->base + 2);
        _8751 = IS_SEQUENCE(_8750);
        _8750 = NOVALUE;
        if (_8751 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_15526);
        _8753 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_8753)){
                _8754 = SEQ_PTR(_8753)->length;
        }
        else {
            _8754 = 1;
        }
        _8753 = NOVALUE;
        _8755 = (_8754 == 0);
        _8754 = NOVALUE;
        if (_8755 == 0)
        {
            DeRef(_8755);
            _8755 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_8755);
            _8755 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8756 = (int)*(((s1_ptr)_2)->base + 2);
        _8757 = IS_ATOM(_8756);
        _8756 = NOVALUE;
        if (_8757 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_15526);
        _8759 = (int)*(((s1_ptr)_2)->base + 1);
        _8760 = IS_ATOM(_8759);
        _8759 = NOVALUE;
        if (_8760 == 0)
        {
            _8760 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _8760 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_15522 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_15560);
        _msg_inlined_crash_at_178_15560 = EPrintf(-9999999, _8762, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_15560);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_15560);
        _msg_inlined_crash_at_178_15560 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_15522 = _i_15524;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8763 = (int)*(((s1_ptr)_2)->base + 6);
        _8764 = IS_ATOM(_8763);
        _8763 = NOVALUE;
        if (_8764 == 0)
        {
            _8764 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _8764 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_31EXTRAS_15498);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _31EXTRAS_15498;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_15528 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8765 = (int)*(((s1_ptr)_2)->base + 3);
        _8766 = IS_ATOM(_8765);
        _8765 = NOVALUE;
        if (_8766 == 0)
        {
            _8766 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _8766 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8767 = (int)*(((s1_ptr)_2)->base + 4);
        _8768 = IS_ATOM(_8767);
        _8767 = NOVALUE;
        if (_8768 == 0)
        {
            _8768 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _8768 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8769 = (int)*(((s1_ptr)_2)->base + 4);
        if (_8769 == 112)
        _8770 = 1;
        else if (IS_ATOM_INT(_8769) && IS_ATOM_INT(112))
        _8770 = 0;
        else
        _8770 = (compare(_8769, 112) == 0);
        _8769 = NOVALUE;
        if (_8770 == 0)
        {
            _8770 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _8770 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_8771);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _8771;
        _8772 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8772;
        if( _1 != _8772 ){
            DeRef(_1);
        }
        _8772 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_15528 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8773 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_8773)){
                _8774 = SEQ_PTR(_8773)->length;
        }
        else {
            _8774 = 1;
        }
        _8773 = NOVALUE;
        {
            int _j_15579;
            _j_15579 = 1;
L10: 
            if (_j_15579 > _8774){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_15526);
            _8775 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_8775);
            _8776 = (int)*(((s1_ptr)_2)->base + _j_15579);
            _8775 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_15526);
            _8777 = (int)*(((s1_ptr)_2)->base + 4);
            _8778 = _j_15579 + 1;
            _8779 = find_from(_8776, _8777, _8778);
            _8776 = NOVALUE;
            _8777 = NOVALUE;
            _8778 = NOVALUE;
            if (_8779 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_15591);
            _msg_inlined_crash_at_354_15591 = EPrintf(-9999999, _8781, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_15591);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_15591);
            _msg_inlined_crash_at_354_15591 = NOVALUE;
L12: 

            /** 			end for*/
            _j_15579 = _j_15579 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8782 = (int)*(((s1_ptr)_2)->base + 4);
        _8783 = find_from(112, _8782, 1);
        _8782 = NOVALUE;
        if (_8783 == 0)
        {
            _8783 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _8783 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8784 = (int)*(((s1_ptr)_2)->base + 4);
        _8785 = find_from(110, _8784, 1);
        _8784 = NOVALUE;
        if (_8785 == 0)
        {
            _8785 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _8785 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_15600);
        _msg_inlined_crash_at_410_15600 = EPrintf(-9999999, _8786, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_15600);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_15600);
        _msg_inlined_crash_at_410_15600 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8787 = (int)*(((s1_ptr)_2)->base + 4);
        _8788 = find_from(99, _8787, 1);
        _8787 = NOVALUE;
        if (_8788 == 0)
        {
            _8788 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _8788 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8789 = (int)*(((s1_ptr)_2)->base + 4);
        _8790 = find_from(105, _8789, 1);
        _8789 = NOVALUE;
        if (_8790 == 0)
        {
            _8790 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _8790 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_15609);
        _msg_inlined_crash_at_460_15609 = EPrintf(-9999999, _8791, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_15609);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_15609);
        _msg_inlined_crash_at_460_15609 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8792 = (int)*(((s1_ptr)_2)->base + 4);
        _8793 = find_from(109, _8792, 1);
        _8792 = NOVALUE;
        if (_8793 == 0)
        {
            _8793 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _8793 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8794 = (int)*(((s1_ptr)_2)->base + 4);
        _8795 = find_from(111, _8794, 1);
        _8794 = NOVALUE;
        if (_8795 == 0)
        {
            _8795 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _8795 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_15618);
        _msg_inlined_crash_at_510_15618 = EPrintf(-9999999, _8796, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_15618);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_15618);
        _msg_inlined_crash_at_510_15618 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8797 = (int)*(((s1_ptr)_2)->base + 4);
        _8798 = find_from(49, _8797, 1);
        _8797 = NOVALUE;
        if (_8798 == 0)
        {
            _8798 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _8798 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8799 = (int)*(((s1_ptr)_2)->base + 4);
        _8800 = find_from(42, _8799, 1);
        _8799 = NOVALUE;
        if (_8800 == 0)
        {
            _8800 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _8800 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_15627);
        _msg_inlined_crash_at_560_15627 = EPrintf(-9999999, _8801, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_15627);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_15627);
        _msg_inlined_crash_at_560_15627 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8802 = (int)*(((s1_ptr)_2)->base + 5);
        _8803 = IS_SEQUENCE(_8802);
        _8802 = NOVALUE;
        if (_8803 == 0)
        {
            _8803 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _8803 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8804 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_8804))
        _8805 = 1;
        else if (IS_ATOM_DBL(_8804))
        _8805 = IS_ATOM_INT(DoubleToInt(_8804));
        else
        _8805 = 0;
        _8804 = NOVALUE;
        if (_8805 != 0)
        goto L22; // [617] 634
        _8805 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8807 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _8807, 0)){
            _8807 = NOVALUE;
            goto L23; // [640] 656
        }
        _8807 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8809 = (int)*(((s1_ptr)_2)->base + 6);
        _8810 = IS_SEQUENCE(_8809);
        _8809 = NOVALUE;
        if (_8810 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_15526);
        _8812 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_8812)){
                _8813 = SEQ_PTR(_8812)->length;
        }
        else {
            _8813 = 1;
        }
        _8812 = NOVALUE;
        _8814 = (_8813 == 0);
        _8813 = NOVALUE;
        if (_8814 == 0)
        {
            DeRef(_8814);
            _8814 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_8814);
            _8814 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15528 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8815 = (int)*(((s1_ptr)_2)->base + 6);
        _8816 = IS_ATOM(_8815);
        _8815 = NOVALUE;
        if (_8816 == 0)
        {
            _8816 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _8816 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8817 = (int)*(((s1_ptr)_2)->base + 2);
        _8818 = IS_SEQUENCE(_8817);
        _8817 = NOVALUE;
        if (_8818 == 0)
        {
            _8818 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _8818 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8819 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_8819);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8819;
        if( _1 != _8819 ){
            DeRef(_1);
        }
        _8819 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8820 = (int)*(((s1_ptr)_2)->base + 1);
        _8821 = IS_SEQUENCE(_8820);
        _8820 = NOVALUE;
        if (_8821 == 0)
        {
            _8821 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _8821 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_15526);
        _8822 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_8822);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8822;
        if( _1 != _8822 ){
            DeRef(_1);
        }
        _8822 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_31EXTRAS_15498);
        _2 = (int)SEQ_PTR(_opt_15526);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15526 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _31EXTRAS_15498;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_15528 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_15528 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_15526);
        _2 = (int)SEQ_PTR(_opts_15520);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15520 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15524);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_15526;
        DeRef(_1);
L29: 
        DeRef(_opt_15526);
        _opt_15526 = NOVALUE;

        /** 	end for*/
        _i_15524 = _i_15524 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15520)){
            _8823 = SEQ_PTR(_opts_15520)->length;
    }
    else {
        _8823 = 1;
    }
    {
        int _i_15659;
        _i_15659 = 1;
L2A: 
        if (_i_15659 > _8823){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_15661);
        _2 = (int)SEQ_PTR(_opts_15520);
        _opt_15661 = (int)*(((s1_ptr)_2)->base + _i_15659);
        Ref(_opt_15661);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15661);
        _8825 = (int)*(((s1_ptr)_2)->base + 1);
        _8826 = IS_SEQUENCE(_8825);
        _8825 = NOVALUE;
        if (_8826 == 0)
        {
            _8826 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _8826 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8827 = _i_15659 + 1;
        if (IS_SEQUENCE(_opts_15520)){
                _8828 = SEQ_PTR(_opts_15520)->length;
        }
        else {
            _8828 = 1;
        }
        {
            int _j_15667;
            _j_15667 = _8827;
L2D: 
            if (_j_15667 > _8828){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15661);
            _8829 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_15520);
            _8830 = (int)*(((s1_ptr)_2)->base + _j_15667);
            _2 = (int)SEQ_PTR(_8830);
            _8831 = (int)*(((s1_ptr)_2)->base + 1);
            _8830 = NOVALUE;
            if (_8829 == _8831)
            _8832 = 1;
            else if (IS_ATOM_INT(_8829) && IS_ATOM_INT(_8831))
            _8832 = 0;
            else
            _8832 = (compare(_8829, _8831) == 0);
            _8829 = NOVALUE;
            _8831 = NOVALUE;
            if (_8832 == 0)
            {
                _8832 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _8832 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15661);
            _8834 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8834);
            *((int *)(_2+4)) = _8834;
            _8835 = MAKE_SEQ(_1);
            _8834 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_15679);
            _data_inlined_crash_at_875_15679 = _8835;
            _8835 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_15680);
            _msg_inlined_crash_at_878_15680 = EPrintf(-9999999, _8833, _data_inlined_crash_at_875_15679);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_15680);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_15679);
            _data_inlined_crash_at_875_15679 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_15680);
            _msg_inlined_crash_at_878_15680 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_15667 = _j_15667 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15661);
        _8836 = (int)*(((s1_ptr)_2)->base + 2);
        _8837 = IS_SEQUENCE(_8836);
        _8836 = NOVALUE;
        if (_8837 == 0)
        {
            _8837 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _8837 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8838 = _i_15659 + 1;
        if (IS_SEQUENCE(_opts_15520)){
                _8839 = SEQ_PTR(_opts_15520)->length;
        }
        else {
            _8839 = 1;
        }
        {
            int _j_15685;
            _j_15685 = _8838;
L32: 
            if (_j_15685 > _8839){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15661);
            _8840 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_15520);
            _8841 = (int)*(((s1_ptr)_2)->base + _j_15685);
            _2 = (int)SEQ_PTR(_8841);
            _8842 = (int)*(((s1_ptr)_2)->base + 2);
            _8841 = NOVALUE;
            if (_8840 == _8842)
            _8843 = 1;
            else if (IS_ATOM_INT(_8840) && IS_ATOM_INT(_8842))
            _8843 = 0;
            else
            _8843 = (compare(_8840, _8842) == 0);
            _8840 = NOVALUE;
            _8842 = NOVALUE;
            if (_8843 == 0)
            {
                _8843 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _8843 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15661);
            _8845 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8845);
            *((int *)(_2+4)) = _8845;
            _8846 = MAKE_SEQ(_1);
            _8845 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_15697);
            _data_inlined_crash_at_964_15697 = _8846;
            _8846 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_15698);
            _msg_inlined_crash_at_967_15698 = EPrintf(-9999999, _8844, _data_inlined_crash_at_964_15697);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_15698);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_15697);
            _data_inlined_crash_at_964_15697 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_15698);
            _msg_inlined_crash_at_967_15698 = NOVALUE;
L34: 

            /** 			end for*/
            _j_15685 = _j_15685 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_15661);
        _opt_15661 = NOVALUE;

        /** 	end for*/
        _i_15659 = _i_15659 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_15699 = 0;
    _has_help_15700 = 0;
    _has_question_15701 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15520)){
            _8847 = SEQ_PTR(_opts_15520)->length;
    }
    else {
        _8847 = 1;
    }
    {
        int _i_15703;
        _i_15703 = 1;
L36: 
        if (_i_15703 > _8847){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8848 = (int)*(((s1_ptr)_2)->base + _i_15703);
        _2 = (int)SEQ_PTR(_8848);
        _8849 = (int)*(((s1_ptr)_2)->base + 1);
        _8848 = NOVALUE;
        if (_8849 == _8850)
        _8851 = 1;
        else if (IS_ATOM_INT(_8849) && IS_ATOM_INT(_8850))
        _8851 = 0;
        else
        _8851 = (compare(_8849, _8850) == 0);
        _8849 = NOVALUE;
        if (_8851 == 0)
        {
            _8851 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _8851 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_15699 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8852 = (int)*(((s1_ptr)_2)->base + _i_15703);
        _2 = (int)SEQ_PTR(_8852);
        _8853 = (int)*(((s1_ptr)_2)->base + 1);
        _8852 = NOVALUE;
        if (_8853 == _8854)
        _8855 = 1;
        else if (IS_ATOM_INT(_8853) && IS_ATOM_INT(_8854))
        _8855 = 0;
        else
        _8855 = (compare(_8853, _8854) == 0);
        _8853 = NOVALUE;
        if (_8855 == 0)
        {
            _8855 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _8855 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_15701 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8856 = (int)*(((s1_ptr)_2)->base + _i_15703);
        _2 = (int)SEQ_PTR(_8856);
        _8857 = (int)*(((s1_ptr)_2)->base + 2);
        _8856 = NOVALUE;
        if (_8857 == _8858)
        _8859 = 1;
        else if (IS_ATOM_INT(_8857) && IS_ATOM_INT(_8858))
        _8859 = 0;
        else
        _8859 = (compare(_8857, _8858) == 0);
        _8857 = NOVALUE;
        if (_8859 == 0)
        {
            _8859 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _8859 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_15700 = 1;
L3B: 

        /** 	end for*/
        _i_15703 = _i_15703 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_15521 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_15721 = 0;

    /** 		if not has_h and not has_help then*/
    _8860 = (_has_h_15699 == 0);
    if (_8860 == 0) {
        goto L3D; // [1121] 1154
    }
    _8862 = (_has_help_15700 == 0);
    if (_8862 == 0)
    {
        DeRef(_8862);
        _8862 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_8862);
        _8862 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8850);
    *((int *)(_2+4)) = _8850;
    RefDS(_8858);
    *((int *)(_2+8)) = _8858;
    RefDS(_8863);
    *((int *)(_2+12)) = _8863;
    RefDS(_8850);
    *((int *)(_2+16)) = _8850;
    *((int *)(_2+20)) = -1;
    _8864 = MAKE_SEQ(_1);
    RefDS(_8864);
    Append(&_opts_15520, _opts_15520, _8864);
    DeRefDS(_8864);
    _8864 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15721 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_15699 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8850);
    *((int *)(_2+4)) = _8850;
    *((int *)(_2+8)) = 0;
    RefDS(_8863);
    *((int *)(_2+12)) = _8863;
    RefDS(_8850);
    *((int *)(_2+16)) = _8850;
    *((int *)(_2+20)) = -1;
    _8867 = MAKE_SEQ(_1);
    RefDS(_8867);
    Append(&_opts_15520, _opts_15520, _8867);
    DeRefDS(_8867);
    _8867 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15721 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_15700 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_8858);
    *((int *)(_2+8)) = _8858;
    RefDS(_8863);
    *((int *)(_2+12)) = _8863;
    RefDS(_8850);
    *((int *)(_2+16)) = _8850;
    *((int *)(_2+20)) = -1;
    _8870 = MAKE_SEQ(_1);
    RefDS(_8870);
    Append(&_opts_15520, _opts_15520, _8870);
    DeRefDS(_8870);
    _8870 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15721 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_15701 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8854);
    *((int *)(_2+4)) = _8854;
    *((int *)(_2+8)) = 0;
    RefDS(_8863);
    *((int *)(_2+12)) = _8863;
    RefDS(_8850);
    *((int *)(_2+16)) = _8850;
    *((int *)(_2+20)) = -1;
    _8873 = MAKE_SEQ(_1);
    RefDS(_8873);
    Append(&_opts_15520, _opts_15520, _8873);
    DeRefDS(_8873);
    _8873 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15721 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_15721 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_15520);
    DeRef(_8875);
    _8875 = _opts_15520;
    _0 = _opts_15520;
    _opts_15520 = _31standardize_opts(_8875, 0);
    DeRefDS(_0);
    _8875 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15520)){
            _8877 = SEQ_PTR(_opts_15520)->length;
    }
    else {
        _8877 = 1;
    }
    {
        int _i_15745;
        _i_15745 = 1;
L43: 
        if (_i_15745 > _8877){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8878 = (int)*(((s1_ptr)_2)->base + _i_15745);
        _2 = (int)SEQ_PTR(_8878);
        _8879 = (int)*(((s1_ptr)_2)->base + 4);
        _8878 = NOVALUE;
        _8880 = find_from(112, _8879, 1);
        _8879 = NOVALUE;
        if (_8880 != 0)
        goto L45; // [1280] 1303
        _8880 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_15520);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15520 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15745 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8884 = (int)*(((s1_ptr)_2)->base + 4);
        _8882 = NOVALUE;
        if (IS_SEQUENCE(_8884) && IS_ATOM(110)) {
            Append(&_8885, _8884, 110);
        }
        else if (IS_ATOM(_8884) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_8885, _8884, 110);
            _8884 = NOVALUE;
        }
        _8884 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8885;
        if( _1 != _8885 ){
            DeRef(_1);
        }
        _8885 = NOVALUE;
        _8882 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8886 = (int)*(((s1_ptr)_2)->base + _i_15745);
        _2 = (int)SEQ_PTR(_8886);
        _8887 = (int)*(((s1_ptr)_2)->base + 4);
        _8886 = NOVALUE;
        _8888 = find_from(42, _8887, 1);
        _8887 = NOVALUE;
        _8889 = (_8888 == 0);
        _8888 = NOVALUE;
        if (_8889 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_15520);
        _8891 = (int)*(((s1_ptr)_2)->base + _i_15745);
        _2 = (int)SEQ_PTR(_8891);
        _8892 = (int)*(((s1_ptr)_2)->base + 4);
        _8891 = NOVALUE;
        _8893 = find_from(49, _8892, 1);
        _8892 = NOVALUE;
        _8894 = (_8893 == 0);
        _8893 = NOVALUE;
        if (_8894 == 0)
        {
            DeRef(_8894);
            _8894 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_8894);
            _8894 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_15520);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15520 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15745 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8897 = (int)*(((s1_ptr)_2)->base + 4);
        _8895 = NOVALUE;
        if (IS_SEQUENCE(_8897) && IS_ATOM(49)) {
            Append(&_8898, _8897, 49);
        }
        else if (IS_ATOM(_8897) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8898, _8897, 49);
            _8897 = NOVALUE;
        }
        _8897 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8898;
        if( _1 != _8898 ){
            DeRef(_1);
        }
        _8898 = NOVALUE;
        _8895 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15520);
        _8899 = (int)*(((s1_ptr)_2)->base + _i_15745);
        _2 = (int)SEQ_PTR(_8899);
        _8900 = (int)*(((s1_ptr)_2)->base + 4);
        _8899 = NOVALUE;
        _8901 = find_from(99, _8900, 1);
        _8900 = NOVALUE;
        _8902 = (_8901 == 0);
        _8901 = NOVALUE;
        if (_8902 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_15520);
        _8904 = (int)*(((s1_ptr)_2)->base + _i_15745);
        _2 = (int)SEQ_PTR(_8904);
        _8905 = (int)*(((s1_ptr)_2)->base + 4);
        _8904 = NOVALUE;
        _8906 = find_from(105, _8905, 1);
        _8905 = NOVALUE;
        _8907 = (_8906 == 0);
        _8906 = NOVALUE;
        if (_8907 == 0)
        {
            DeRef(_8907);
            _8907 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_8907);
            _8907 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_15520);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15520 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15745 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8910 = (int)*(((s1_ptr)_2)->base + 4);
        _8908 = NOVALUE;
        if (IS_SEQUENCE(_8910) && IS_ATOM(105)) {
            Append(&_8911, _8910, 105);
        }
        else if (IS_ATOM(_8910) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8911, _8910, 105);
            _8910 = NOVALUE;
        }
        _8910 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8911;
        if( _1 != _8911 ){
            DeRef(_1);
        }
        _8911 = NOVALUE;
        _8908 = NOVALUE;
L47: 

        /** 	end for*/
        _i_15745 = _i_15745 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _8747 = NOVALUE;
    _8753 = NOVALUE;
    _8773 = NOVALUE;
    _8812 = NOVALUE;
    DeRef(_8827);
    _8827 = NOVALUE;
    DeRef(_8838);
    _8838 = NOVALUE;
    DeRef(_8860);
    _8860 = NOVALUE;
    DeRef(_8889);
    _8889 = NOVALUE;
    DeRef(_8902);
    _8902 = NOVALUE;
    return _opts_15520;
    ;
}


void _31local_help(int _opts_15786, int _add_help_rid_15787, int _cmds_15788, int _std_15790, int _parse_options_15791)
{
    int _pad_size_15792 = NOVALUE;
    int _this_size_15793 = NOVALUE;
    int _cmd_15794 = NOVALUE;
    int _param_name_15795 = NOVALUE;
    int _has_param_15796 = NOVALUE;
    int _is_mandatory_15797 = NOVALUE;
    int _extras_mandatory_15798 = NOVALUE;
    int _extras_opt_15799 = NOVALUE;
    int _auto_help_15800 = NOVALUE;
    int _po_15801 = NOVALUE;
    int _msg_inlined_crash_at_94_15820 = NOVALUE;
    int _9101 = NOVALUE;
    int _9100 = NOVALUE;
    int _9099 = NOVALUE;
    int _9098 = NOVALUE;
    int _9096 = NOVALUE;
    int _9095 = NOVALUE;
    int _9094 = NOVALUE;
    int _9093 = NOVALUE;
    int _9092 = NOVALUE;
    int _9090 = NOVALUE;
    int _9088 = NOVALUE;
    int _9086 = NOVALUE;
    int _9084 = NOVALUE;
    int _9083 = NOVALUE;
    int _9082 = NOVALUE;
    int _9080 = NOVALUE;
    int _9079 = NOVALUE;
    int _9078 = NOVALUE;
    int _9075 = NOVALUE;
    int _9074 = NOVALUE;
    int _9073 = NOVALUE;
    int _9071 = NOVALUE;
    int _9070 = NOVALUE;
    int _9069 = NOVALUE;
    int _9067 = NOVALUE;
    int _9066 = NOVALUE;
    int _9065 = NOVALUE;
    int _9064 = NOVALUE;
    int _9063 = NOVALUE;
    int _9062 = NOVALUE;
    int _9061 = NOVALUE;
    int _9060 = NOVALUE;
    int _9057 = NOVALUE;
    int _9053 = NOVALUE;
    int _9050 = NOVALUE;
    int _9049 = NOVALUE;
    int _9048 = NOVALUE;
    int _9042 = NOVALUE;
    int _9041 = NOVALUE;
    int _9040 = NOVALUE;
    int _9039 = NOVALUE;
    int _9035 = NOVALUE;
    int _9032 = NOVALUE;
    int _9031 = NOVALUE;
    int _9030 = NOVALUE;
    int _9027 = NOVALUE;
    int _9026 = NOVALUE;
    int _9025 = NOVALUE;
    int _9023 = NOVALUE;
    int _9022 = NOVALUE;
    int _9021 = NOVALUE;
    int _9019 = NOVALUE;
    int _9018 = NOVALUE;
    int _9017 = NOVALUE;
    int _9016 = NOVALUE;
    int _9015 = NOVALUE;
    int _9014 = NOVALUE;
    int _9011 = NOVALUE;
    int _9010 = NOVALUE;
    int _9009 = NOVALUE;
    int _9006 = NOVALUE;
    int _9005 = NOVALUE;
    int _9004 = NOVALUE;
    int _9003 = NOVALUE;
    int _9002 = NOVALUE;
    int _9001 = NOVALUE;
    int _9000 = NOVALUE;
    int _8999 = NOVALUE;
    int _8998 = NOVALUE;
    int _8997 = NOVALUE;
    int _8996 = NOVALUE;
    int _8995 = NOVALUE;
    int _8990 = NOVALUE;
    int _8989 = NOVALUE;
    int _8987 = NOVALUE;
    int _8986 = NOVALUE;
    int _8985 = NOVALUE;
    int _8984 = NOVALUE;
    int _8983 = NOVALUE;
    int _8982 = NOVALUE;
    int _8980 = NOVALUE;
    int _8979 = NOVALUE;
    int _8978 = NOVALUE;
    int _8974 = NOVALUE;
    int _8973 = NOVALUE;
    int _8971 = NOVALUE;
    int _8970 = NOVALUE;
    int _8969 = NOVALUE;
    int _8968 = NOVALUE;
    int _8967 = NOVALUE;
    int _8966 = NOVALUE;
    int _8965 = NOVALUE;
    int _8962 = NOVALUE;
    int _8961 = NOVALUE;
    int _8960 = NOVALUE;
    int _8958 = NOVALUE;
    int _8957 = NOVALUE;
    int _8956 = NOVALUE;
    int _8955 = NOVALUE;
    int _8954 = NOVALUE;
    int _8953 = NOVALUE;
    int _8952 = NOVALUE;
    int _8949 = NOVALUE;
    int _8948 = NOVALUE;
    int _8947 = NOVALUE;
    int _8945 = NOVALUE;
    int _8944 = NOVALUE;
    int _8943 = NOVALUE;
    int _8942 = NOVALUE;
    int _8941 = NOVALUE;
    int _8940 = NOVALUE;
    int _8939 = NOVALUE;
    int _8938 = NOVALUE;
    int _8937 = NOVALUE;
    int _8936 = NOVALUE;
    int _8935 = NOVALUE;
    int _8934 = NOVALUE;
    int _8933 = NOVALUE;
    int _8932 = NOVALUE;
    int _8931 = NOVALUE;
    int _8930 = NOVALUE;
    int _8929 = NOVALUE;
    int _8928 = NOVALUE;
    int _8920 = NOVALUE;
    int _8917 = NOVALUE;
    int _8915 = NOVALUE;
    int _8913 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_15798 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_15799 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_15800 = 1;

    /** 	integer po = 1*/
    _po_15801 = 1;

    /** 	if atom(parse_options) then*/
    _8913 = IS_ATOM(_parse_options_15791);
    if (_8913 == 0)
    {
        _8913 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8913 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15791;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_15791);
    *((int *)(_2+4)) = _parse_options_15791;
    _parse_options_15791 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15791)){
            _8915 = SEQ_PTR(_parse_options_15791)->length;
    }
    else {
        _8915 = 1;
    }
    if (_po_15801 > _8915)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15791);
    _8917 = (int)*(((s1_ptr)_2)->base + _po_15801);
    if (IS_SEQUENCE(_8917) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8917)){
        if( (DBL_PTR(_8917)->dbl != (double) ((int) DBL_PTR(_8917)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_8917)->dbl;
    }
    else {
        _0 = _8917;
    };
    _8917 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15791)){
                _8920 = SEQ_PTR(_parse_options_15791)->length;
        }
        else {
            _8920 = 1;
        }
        if (_po_15801 >= _8920)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_15801 = _po_15801 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15787);
        _2 = (int)SEQ_PTR(_parse_options_15791);
        _add_help_rid_15787 = (int)*(((s1_ptr)_2)->base + _po_15801);
        Ref(_add_help_rid_15787);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_15820);
        _msg_inlined_crash_at_94_15820 = EPrintf(-9999999, _8924, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_15820);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_15820);
        _msg_inlined_crash_at_94_15820 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15800 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_15801 = _po_15801 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_15790 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15786);
    _0 = _opts_15786;
    _opts_15786 = _31standardize_opts(_opts_15786, _auto_help_15800);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_15792 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15786)){
            _8928 = SEQ_PTR(_opts_15786)->length;
    }
    else {
        _8928 = 1;
    }
    {
        int _i_15828;
        _i_15828 = 1;
L9: 
        if (_i_15828 > _8928){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_15793 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_15795);
        _param_name_15795 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8929 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8929);
        _8930 = (int)*(((s1_ptr)_2)->base + 1);
        _8929 = NOVALUE;
        _8931 = IS_ATOM(_8930);
        _8930 = NOVALUE;
        if (_8931 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_15786);
        _8933 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8933);
        _8934 = (int)*(((s1_ptr)_2)->base + 2);
        _8933 = NOVALUE;
        _8935 = IS_ATOM(_8934);
        _8934 = NOVALUE;
        if (_8935 == 0)
        {
            _8935 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _8935 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_15799 = _i_15828;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8936 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8936);
        _8937 = (int)*(((s1_ptr)_2)->base + 4);
        _8936 = NOVALUE;
        _8938 = find_from(109, _8937, 1);
        _8937 = NOVALUE;
        if (_8938 == 0)
        {
            _8938 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _8938 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_15798 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8939 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8939);
        _8940 = (int)*(((s1_ptr)_2)->base + 1);
        _8939 = NOVALUE;
        _8941 = IS_SEQUENCE(_8940);
        _8940 = NOVALUE;
        if (_8941 == 0)
        {
            _8941 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _8941 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8942 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8942);
        _8943 = (int)*(((s1_ptr)_2)->base + 1);
        _8942 = NOVALUE;
        if (IS_SEQUENCE(_8943)){
                _8944 = SEQ_PTR(_8943)->length;
        }
        else {
            _8944 = 1;
        }
        _8943 = NOVALUE;
        _8945 = _8944 + 1;
        _8944 = NOVALUE;
        _this_size_15793 = _this_size_15793 + _8945;
        _8945 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8947 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8947);
        _8948 = (int)*(((s1_ptr)_2)->base + 4);
        _8947 = NOVALUE;
        _8949 = find_from(109, _8948, 1);
        _8948 = NOVALUE;
        if (_8949 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15793 = _this_size_15793 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8952 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8952);
        _8953 = (int)*(((s1_ptr)_2)->base + 2);
        _8952 = NOVALUE;
        _8954 = IS_SEQUENCE(_8953);
        _8953 = NOVALUE;
        if (_8954 == 0)
        {
            _8954 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _8954 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8955 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8955);
        _8956 = (int)*(((s1_ptr)_2)->base + 2);
        _8955 = NOVALUE;
        if (IS_SEQUENCE(_8956)){
                _8957 = SEQ_PTR(_8956)->length;
        }
        else {
            _8957 = 1;
        }
        _8956 = NOVALUE;
        _8958 = _8957 + 2;
        _8957 = NOVALUE;
        _this_size_15793 = _this_size_15793 + _8958;
        _8958 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8960 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8960);
        _8961 = (int)*(((s1_ptr)_2)->base + 4);
        _8960 = NOVALUE;
        _8962 = find_from(109, _8961, 1);
        _8961 = NOVALUE;
        if (_8962 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15793 = _this_size_15793 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8965 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8965);
        _8966 = (int)*(((s1_ptr)_2)->base + 1);
        _8965 = NOVALUE;
        _8967 = IS_SEQUENCE(_8966);
        _8966 = NOVALUE;
        if (_8967 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_15786);
        _8969 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8969);
        _8970 = (int)*(((s1_ptr)_2)->base + 2);
        _8969 = NOVALUE;
        _8971 = IS_SEQUENCE(_8970);
        _8970 = NOVALUE;
        if (_8971 == 0)
        {
            _8971 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _8971 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_15793 = _this_size_15793 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8973 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8973);
        _8974 = (int)*(((s1_ptr)_2)->base + 4);
        _8973 = NOVALUE;
        _has_param_15796 = find_from(112, _8974, 1);
        _8974 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15796 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_15793 = _this_size_15793 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8978 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8978);
        _8979 = (int)*(((s1_ptr)_2)->base + 4);
        _8978 = NOVALUE;
        if (IS_SEQUENCE(_8979)){
                _8980 = SEQ_PTR(_8979)->length;
        }
        else {
            _8980 = 1;
        }
        _8979 = NOVALUE;
        if (_has_param_15796 >= _8980)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8982 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8982);
        _8983 = (int)*(((s1_ptr)_2)->base + 4);
        _8982 = NOVALUE;
        _2 = (int)SEQ_PTR(_8983);
        _8984 = (int)*(((s1_ptr)_2)->base + _has_param_15796);
        _8983 = NOVALUE;
        _8985 = IS_SEQUENCE(_8984);
        _8984 = NOVALUE;
        if (_8985 == 0)
        {
            _8985 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _8985 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8986 = (int)*(((s1_ptr)_2)->base + _i_15828);
        _2 = (int)SEQ_PTR(_8986);
        _8987 = (int)*(((s1_ptr)_2)->base + 4);
        _8986 = NOVALUE;
        DeRef(_param_name_15795);
        _2 = (int)SEQ_PTR(_8987);
        _param_name_15795 = (int)*(((s1_ptr)_2)->base + _has_param_15796);
        Ref(_param_name_15795);
        _8987 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_8771);
        DeRef(_param_name_15795);
        _param_name_15795 = _8771;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_8771);
        DeRef(_param_name_15795);
        _param_name_15795 = _8771;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_15795)){
                _8989 = SEQ_PTR(_param_name_15795)->length;
        }
        else {
            _8989 = 1;
        }
        _8990 = 2 + _8989;
        _8989 = NOVALUE;
        _this_size_15793 = _this_size_15793 + _8990;
        _8990 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_15792 >= _this_size_15793)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_15792 = _this_size_15793;
L16: 

        /** 	end for*/
LC: 
        _i_15828 = _i_15828 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_15792 = _pad_size_15792 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_15788);
    _8995 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8995);
    *((int *)(_2+4)) = _8995;
    _8996 = MAKE_SEQ(_1);
    _8995 = NOVALUE;
    EPrintf(1, _8994, _8996);
    DeRefDS(_8996);
    _8996 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15786)){
            _8997 = SEQ_PTR(_opts_15786)->length;
    }
    else {
        _8997 = 1;
    }
    {
        int _i_15912;
        _i_15912 = 1;
L17: 
        if (_i_15912 > _8997){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _8998 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_8998);
        _8999 = (int)*(((s1_ptr)_2)->base + 1);
        _8998 = NOVALUE;
        _9000 = IS_ATOM(_8999);
        _8999 = NOVALUE;
        if (_9000 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_15786);
        _9002 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9002);
        _9003 = (int)*(((s1_ptr)_2)->base + 2);
        _9002 = NOVALUE;
        _9004 = IS_ATOM(_9003);
        _9003 = NOVALUE;
        if (_9004 == 0)
        {
            _9004 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _9004 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9005 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9005);
        _9006 = (int)*(((s1_ptr)_2)->base + 4);
        _9005 = NOVALUE;
        _has_param_15796 = find_from(112, _9006, 1);
        _9006 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15796 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9009 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9009);
        _9010 = (int)*(((s1_ptr)_2)->base + 4);
        _9009 = NOVALUE;
        if (IS_SEQUENCE(_9010)){
                _9011 = SEQ_PTR(_9010)->length;
        }
        else {
            _9011 = 1;
        }
        _9010 = NOVALUE;
        if (_has_param_15796 >= _9011)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_15796 = _has_param_15796 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9014 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9014);
        _9015 = (int)*(((s1_ptr)_2)->base + 4);
        _9014 = NOVALUE;
        _2 = (int)SEQ_PTR(_9015);
        _9016 = (int)*(((s1_ptr)_2)->base + _has_param_15796);
        _9015 = NOVALUE;
        _9017 = IS_SEQUENCE(_9016);
        _9016 = NOVALUE;
        if (_9017 == 0)
        {
            _9017 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _9017 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9018 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9018);
        _9019 = (int)*(((s1_ptr)_2)->base + 4);
        _9018 = NOVALUE;
        DeRef(_param_name_15795);
        _2 = (int)SEQ_PTR(_9019);
        _param_name_15795 = (int)*(((s1_ptr)_2)->base + _has_param_15796);
        Ref(_param_name_15795);
        _9019 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_8771);
        DeRef(_param_name_15795);
        _param_name_15795 = _8771;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_8771);
        DeRef(_param_name_15795);
        _param_name_15795 = _8771;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9021 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9021);
        _9022 = (int)*(((s1_ptr)_2)->base + 4);
        _9021 = NOVALUE;
        _9023 = find_from(109, _9022, 1);
        _9022 = NOVALUE;
        _is_mandatory_15797 = (_9023 != 0);
        _9023 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_15794);
        _cmd_15794 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9025 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9025);
        _9026 = (int)*(((s1_ptr)_2)->base + 1);
        _9025 = NOVALUE;
        _9027 = IS_SEQUENCE(_9026);
        _9026 = NOVALUE;
        if (_9027 == 0)
        {
            _9027 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _9027 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15797 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_15794, _cmd_15794, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9030 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9030);
        _9031 = (int)*(((s1_ptr)_2)->base + 1);
        _9030 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_9031)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_9031)) {
            Prepend(&_9032, _9031, 45);
        }
        else {
            Concat((object_ptr)&_9032, 45, _9031);
        }
        _9031 = NOVALUE;
        Concat((object_ptr)&_cmd_15794, _cmd_15794, _9032);
        DeRefDS(_9032);
        _9032 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15796 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_9035, _param_name_15795, 32);
        Concat((object_ptr)&_cmd_15794, _cmd_15794, _9035);
        DeRefDS(_9035);
        _9035 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15797 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_15794, _cmd_15794, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9039 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9039);
        _9040 = (int)*(((s1_ptr)_2)->base + 2);
        _9039 = NOVALUE;
        _9041 = IS_SEQUENCE(_9040);
        _9040 = NOVALUE;
        if (_9041 == 0)
        {
            _9041 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _9041 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_15794)){
                _9042 = SEQ_PTR(_cmd_15794)->length;
        }
        else {
            _9042 = 1;
        }
        if (_9042 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_15794, _cmd_15794, _9044);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15797 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_15794, _cmd_15794, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9048 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9048);
        _9049 = (int)*(((s1_ptr)_2)->base + 2);
        _9048 = NOVALUE;
        if (IS_SEQUENCE(_6725) && IS_ATOM(_9049)) {
            Ref(_9049);
            Append(&_9050, _6725, _9049);
        }
        else if (IS_ATOM(_6725) && IS_SEQUENCE(_9049)) {
        }
        else {
            Concat((object_ptr)&_9050, _6725, _9049);
        }
        _9049 = NOVALUE;
        Concat((object_ptr)&_cmd_15794, _cmd_15794, _9050);
        DeRefDS(_9050);
        _9050 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15796 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_9053, _param_name_15795, 61);
        Concat((object_ptr)&_cmd_15794, _cmd_15794, _9053);
        DeRefDS(_9053);
        _9053 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15797 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_15794, _cmd_15794, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_15794)){
                _9057 = SEQ_PTR(_cmd_15794)->length;
        }
        else {
            _9057 = 1;
        }
        if (_9057 <= _pad_size_15792)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_15794;
            concat_list[2] = _9059;
            Concat_N((object_ptr)&_9060, concat_list, 3);
        }
        EPuts(1, _9060); // DJP 
        DeRefDS(_9060);
        _9060 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _9061 = _pad_size_15792 + 3;
        _9062 = Repeat(32, _9061);
        _9061 = NOVALUE;
        EPuts(1, _9062); // DJP 
        DeRefDS(_9062);
        _9062 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_15794);
        _9063 = _23pad_tail(_cmd_15794, _pad_size_15792, 32);
        if (IS_SEQUENCE(_9059) && IS_ATOM(_9063)) {
            Ref(_9063);
            Append(&_9064, _9059, _9063);
        }
        else if (IS_ATOM(_9059) && IS_SEQUENCE(_9063)) {
        }
        else {
            Concat((object_ptr)&_9064, _9059, _9063);
        }
        DeRef(_9063);
        _9063 = NOVALUE;
        EPuts(1, _9064); // DJP 
        DeRefDS(_9064);
        _9064 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_15786);
        _9065 = (int)*(((s1_ptr)_2)->base + _i_15912);
        _2 = (int)SEQ_PTR(_9065);
        _9066 = (int)*(((s1_ptr)_2)->base + 3);
        _9065 = NOVALUE;
        if (IS_SEQUENCE(_9066) && IS_ATOM(10)) {
            Append(&_9067, _9066, 10);
        }
        else if (IS_ATOM(_9066) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_9067, _9066, 10);
            _9066 = NOVALUE;
        }
        _9066 = NOVALUE;
        EPuts(1, _9067); // DJP 
        DeRefDS(_9067);
        _9067 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_15912 = _i_15912 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_15798 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15786);
    _9069 = (int)*(((s1_ptr)_2)->base + _extras_opt_15799);
    _2 = (int)SEQ_PTR(_9069);
    _9070 = (int)*(((s1_ptr)_2)->base + 3);
    _9069 = NOVALUE;
    if (IS_SEQUENCE(_9070)){
            _9071 = SEQ_PTR(_9070)->length;
    }
    else {
        _9071 = 1;
    }
    _9070 = NOVALUE;
    if (_9071 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15786);
    _9073 = (int)*(((s1_ptr)_2)->base + _extras_opt_15799);
    _2 = (int)SEQ_PTR(_9073);
    _9074 = (int)*(((s1_ptr)_2)->base + 3);
    _9073 = NOVALUE;
    if (IS_SEQUENCE(_1326) && IS_ATOM(_9074)) {
        Ref(_9074);
        Append(&_9075, _1326, _9074);
    }
    else if (IS_ATOM(_1326) && IS_SEQUENCE(_9074)) {
    }
    else {
        Concat((object_ptr)&_9075, _1326, _9074);
    }
    _9074 = NOVALUE;
    EPuts(1, _9075); // DJP 
    DeRefDS(_9075);
    _9075 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _9076); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_15799 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15786);
    _9078 = (int)*(((s1_ptr)_2)->base + _extras_opt_15799);
    _2 = (int)SEQ_PTR(_9078);
    _9079 = (int)*(((s1_ptr)_2)->base + 3);
    _9078 = NOVALUE;
    if (IS_SEQUENCE(_9079)){
            _9080 = SEQ_PTR(_9079)->length;
    }
    else {
        _9080 = 1;
    }
    _9079 = NOVALUE;
    if (_9080 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15786);
    _9082 = (int)*(((s1_ptr)_2)->base + _extras_opt_15799);
    _2 = (int)SEQ_PTR(_9082);
    _9083 = (int)*(((s1_ptr)_2)->base + 3);
    _9082 = NOVALUE;
    if (IS_SEQUENCE(_1326) && IS_ATOM(_9083)) {
        Ref(_9083);
        Append(&_9084, _1326, _9083);
    }
    else if (IS_ATOM(_1326) && IS_SEQUENCE(_9083)) {
    }
    else {
        Concat((object_ptr)&_9084, _1326, _9083);
    }
    _9083 = NOVALUE;
    EPuts(1, _9084); // DJP 
    DeRefDS(_9084);
    _9084 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _9085); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _9086 = IS_ATOM(_add_help_rid_15787);
    if (_9086 == 0)
    {
        _9086 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _9086 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_15787, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1326); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_15787].addr;
    if (_00[_add_help_rid_15787].convention) {
        (*(int (__stdcall *)())_0)(
                             );
    }
    else {
        (*(int (*)())_0)(
                             );
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1326); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_15787)){
            _9088 = SEQ_PTR(_add_help_rid_15787)->length;
    }
    else {
        _9088 = 1;
    }
    if (_9088 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _1326); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_15787);
    _9090 = _7t_display(_add_help_rid_15787);
    if (_9090 == 0) {
        DeRef(_9090);
        _9090 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_9090) && DBL_PTR(_9090)->dbl == 0.0){
            DeRef(_9090);
            _9090 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_9090);
        _9090 = NOVALUE;
    }
    DeRef(_9090);
    _9090 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_15787;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_15787);
    *((int *)(_2+4)) = _add_help_rid_15787;
    _add_help_rid_15787 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_15787)){
            _9092 = SEQ_PTR(_add_help_rid_15787)->length;
    }
    else {
        _9092 = 1;
    }
    {
        int _i_16037;
        _i_16037 = 1;
L34: 
        if (_i_16037 > _9092){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_15787);
        _9093 = (int)*(((s1_ptr)_2)->base + _i_16037);
        EPuts(1, _9093); // DJP 
        _9093 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_15787);
        _9094 = (int)*(((s1_ptr)_2)->base + _i_16037);
        if (IS_SEQUENCE(_9094)){
                _9095 = SEQ_PTR(_9094)->length;
        }
        else {
            _9095 = 1;
        }
        _9094 = NOVALUE;
        _9096 = (_9095 == 0);
        _9095 = NOVALUE;
        if (_9096 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_15787);
        _9098 = (int)*(((s1_ptr)_2)->base + _i_16037);
        if (IS_SEQUENCE(_9098)){
                _9099 = SEQ_PTR(_9098)->length;
        }
        else {
            _9099 = 1;
        }
        _2 = (int)SEQ_PTR(_9098);
        _9100 = (int)*(((s1_ptr)_2)->base + _9099);
        _9098 = NOVALUE;
        if (IS_ATOM_INT(_9100)) {
            _9101 = (_9100 != 10);
        }
        else {
            _9101 = binary_op(NOTEQ, _9100, 10);
        }
        _9100 = NOVALUE;
        if (_9101 == 0) {
            DeRef(_9101);
            _9101 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_9101) && DBL_PTR(_9101)->dbl == 0.0){
                DeRef(_9101);
                _9101 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_9101);
            _9101 = NOVALUE;
        }
        DeRef(_9101);
        _9101 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_16037 = _i_16037 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1326); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_15786);
    DeRef(_add_help_rid_15787);
    DeRefDS(_cmds_15788);
    DeRef(_parse_options_15791);
    DeRef(_cmd_15794);
    DeRef(_param_name_15795);
    _8943 = NOVALUE;
    _8956 = NOVALUE;
    _8979 = NOVALUE;
    _9010 = NOVALUE;
    _9070 = NOVALUE;
    _9079 = NOVALUE;
    _9094 = NOVALUE;
    DeRef(_9096);
    _9096 = NOVALUE;
    return;
    ;
}


void  __stdcall _31show_help(int _opts_16051, int _add_help_rid_16052, int _cmds_16053, int _parse_options_16055)
{
    int _0, _1, _2;
    

    /**     local_help(opts, add_help_rid, cmds, 0, parse_options)*/
    RefDS(_opts_16051);
    Ref(_add_help_rid_16052);
    RefDS(_cmds_16053);
    Ref(_parse_options_16055);
    _31local_help(_opts_16051, _add_help_rid_16052, _cmds_16053, 0, _parse_options_16055);

    /** end procedure*/
    DeRefDS(_opts_16051);
    DeRef(_add_help_rid_16052);
    DeRefDS(_cmds_16053);
    DeRef(_parse_options_16055);
    return;
    ;
}


int _31find_opt(int _opts_16058, int _opt_style_16059, int _cmd_text_16060)
{
    int _opt_name_16061 = NOVALUE;
    int _opt_param_16062 = NOVALUE;
    int _param_found_16063 = NOVALUE;
    int _reversed_16064 = NOVALUE;
    int _9203 = NOVALUE;
    int _9201 = NOVALUE;
    int _9200 = NOVALUE;
    int _9198 = NOVALUE;
    int _9197 = NOVALUE;
    int _9196 = NOVALUE;
    int _9195 = NOVALUE;
    int _9194 = NOVALUE;
    int _9191 = NOVALUE;
    int _9190 = NOVALUE;
    int _9189 = NOVALUE;
    int _9187 = NOVALUE;
    int _9186 = NOVALUE;
    int _9185 = NOVALUE;
    int _9184 = NOVALUE;
    int _9182 = NOVALUE;
    int _9181 = NOVALUE;
    int _9180 = NOVALUE;
    int _9179 = NOVALUE;
    int _9178 = NOVALUE;
    int _9177 = NOVALUE;
    int _9176 = NOVALUE;
    int _9175 = NOVALUE;
    int _9174 = NOVALUE;
    int _9173 = NOVALUE;
    int _9172 = NOVALUE;
    int _9171 = NOVALUE;
    int _9165 = NOVALUE;
    int _9164 = NOVALUE;
    int _9163 = NOVALUE;
    int _9155 = NOVALUE;
    int _9154 = NOVALUE;
    int _9152 = NOVALUE;
    int _9150 = NOVALUE;
    int _9149 = NOVALUE;
    int _9147 = NOVALUE;
    int _9146 = NOVALUE;
    int _9145 = NOVALUE;
    int _9144 = NOVALUE;
    int _9143 = NOVALUE;
    int _9141 = NOVALUE;
    int _9140 = NOVALUE;
    int _9138 = NOVALUE;
    int _9136 = NOVALUE;
    int _9135 = NOVALUE;
    int _9133 = NOVALUE;
    int _9132 = NOVALUE;
    int _9131 = NOVALUE;
    int _9130 = NOVALUE;
    int _9128 = NOVALUE;
    int _9127 = NOVALUE;
    int _9124 = NOVALUE;
    int _9122 = NOVALUE;
    int _9121 = NOVALUE;
    int _9119 = NOVALUE;
    int _9117 = NOVALUE;
    int _9115 = NOVALUE;
    int _9114 = NOVALUE;
    int _9112 = NOVALUE;
    int _9111 = NOVALUE;
    int _9110 = NOVALUE;
    int _9109 = NOVALUE;
    int _9108 = NOVALUE;
    int _9106 = NOVALUE;
    int _9105 = NOVALUE;
    int _9103 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_16063 = 0;

    /** 	integer reversed = 0*/
    _reversed_16064 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9103 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9103 = 1;
    }
    if (_9103 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_16060);
    _9105 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9105)) {
        _9106 = (_9105 == 39);
    }
    else {
        _9106 = binary_op(EQUALS, _9105, 39);
    }
    _9105 = NOVALUE;
    if (IS_ATOM_INT(_9106)) {
        if (_9106 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_9106)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_16060);
    _9108 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9108)) {
        _9109 = (_9108 == 34);
    }
    else {
        _9109 = binary_op(EQUALS, _9108, 34);
    }
    _9108 = NOVALUE;
    if (_9109 == 0) {
        DeRef(_9109);
        _9109 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_9109) && DBL_PTR(_9109)->dbl == 0.0){
            DeRef(_9109);
            _9109 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_9109);
        _9109 = NOVALUE;
    }
    DeRef(_9109);
    _9109 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9110 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9110 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_16060);
    _9111 = (int)*(((s1_ptr)_2)->base + _9110);
    _2 = (int)SEQ_PTR(_cmd_text_16060);
    _9112 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9111, _9112)){
        _9111 = NOVALUE;
        _9112 = NOVALUE;
        goto L4; // [64] 83
    }
    _9111 = NOVALUE;
    _9112 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9114 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9114 = 1;
    }
    _9115 = _9114 - 1;
    _9114 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_16060;
    RHS_Slice(_cmd_text_16060, 2, _9115);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9117 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9117 = 1;
    }
    if (_9117 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_16060);
    _9119 = (int)*(((s1_ptr)_2)->base + 1);
    _9121 = find_from(_9119, _9120, 1);
    _9119 = NOVALUE;
    if (_9121 == 0)
    {
        _9121 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _9121 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_16064 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9122 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9122 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_16060;
    RHS_Slice(_cmd_text_16060, 2, _9122);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9124 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9124 = 1;
    }
    if (_9124 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_9126);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _9126;
    _9127 = MAKE_SEQ(_1);
    DeRefDS(_opts_16058);
    DeRefDS(_opt_style_16059);
    DeRef(_cmd_text_16060);
    DeRef(_opt_name_16061);
    DeRef(_opt_param_16062);
    DeRef(_9115);
    _9115 = NOVALUE;
    DeRef(_9106);
    _9106 = NOVALUE;
    return _9127;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9128 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9128 = 1;
    }
    DeRef(_opt_name_16061);
    _opt_name_16061 = Repeat(32, _9128);
    _9128 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_16062);
    _opt_param_16062 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_16060)){
            _9130 = SEQ_PTR(_cmd_text_16060)->length;
    }
    else {
        _9130 = 1;
    }
    {
        int _i_16099;
        _i_16099 = 1;
L8: 
        if (_i_16099 > _9130){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_16060);
        _9131 = (int)*(((s1_ptr)_2)->base + _i_16099);
        _9132 = find_from(_9131, _5373, 1);
        _9131 = NOVALUE;
        if (_9132 == 0)
        {
            _9132 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _9132 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _9133 = _i_16099 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_16061;
        RHS_Slice(_opt_name_16061, 1, _9133);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _9135 = _i_16099 + 1;
        if (IS_SEQUENCE(_cmd_text_16060)){
                _9136 = SEQ_PTR(_cmd_text_16060)->length;
        }
        else {
            _9136 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_16062;
        RHS_Slice(_cmd_text_16060, _9135, _9136);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_16062)){
                _9138 = SEQ_PTR(_opt_param_16062)->length;
        }
        else {
            _9138 = 1;
        }
        if (_9138 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_16062);
        _9140 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_9140)) {
            _9141 = (_9140 == 39);
        }
        else {
            _9141 = binary_op(EQUALS, _9140, 39);
        }
        _9140 = NOVALUE;
        if (IS_ATOM_INT(_9141)) {
            if (_9141 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_9141)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_16062);
        _9143 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_9143)) {
            _9144 = (_9143 == 34);
        }
        else {
            _9144 = binary_op(EQUALS, _9143, 34);
        }
        _9143 = NOVALUE;
        if (_9144 == 0) {
            DeRef(_9144);
            _9144 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_9144) && DBL_PTR(_9144)->dbl == 0.0){
                DeRef(_9144);
                _9144 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_9144);
            _9144 = NOVALUE;
        }
        DeRef(_9144);
        _9144 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_16062)){
                _9145 = SEQ_PTR(_opt_param_16062)->length;
        }
        else {
            _9145 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_16062);
        _9146 = (int)*(((s1_ptr)_2)->base + _9145);
        _2 = (int)SEQ_PTR(_opt_param_16062);
        _9147 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _9146, _9147)){
            _9146 = NOVALUE;
            _9147 = NOVALUE;
            goto LE; // [259] 278
        }
        _9146 = NOVALUE;
        _9147 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_16062)){
                _9149 = SEQ_PTR(_opt_param_16062)->length;
        }
        else {
            _9149 = 1;
        }
        _9150 = _9149 - 1;
        _9149 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_16062;
        RHS_Slice(_opt_param_16062, 2, _9150);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_16062)){
                _9152 = SEQ_PTR(_opt_param_16062)->length;
        }
        else {
            _9152 = 1;
        }
        if (_9152 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_16063 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_16060);
        _9154 = (int)*(((s1_ptr)_2)->base + _i_16099);
        Ref(_9154);
        _2 = (int)SEQ_PTR(_opt_name_16061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_16061 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_16099);
        _1 = *(int *)_2;
        *(int *)_2 = _9154;
        if( _1 != _9154 ){
            DeRef(_1);
        }
        _9154 = NOVALUE;
LF: 

        /** 	end for*/
        _i_16099 = _i_16099 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_16063 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_16062);
    _9155 = _6lower(_opt_param_16062);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9156);
    *((int *)(_2+4)) = _9156;
    RefDS(_9157);
    *((int *)(_2+8)) = _9157;
    RefDS(_9158);
    *((int *)(_2+12)) = _9158;
    RefDS(_9159);
    *((int *)(_2+16)) = _9159;
    RefDS(_9160);
    *((int *)(_2+20)) = _9160;
    RefDS(_9161);
    *((int *)(_2+24)) = _9161;
    RefDS(_9162);
    *((int *)(_2+28)) = _9162;
    _9163 = MAKE_SEQ(_1);
    _9164 = find_from(_9155, _9163, 1);
    DeRef(_9155);
    _9155 = NOVALUE;
    DeRefDS(_9163);
    _9163 = NOVALUE;
    if (_9164 == 0)
    {
        _9164 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _9164 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_16062);
    _opt_param_16062 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_16062);
    _9165 = _6lower(_opt_param_16062);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9166);
    *((int *)(_2+4)) = _9166;
    RefDS(_9167);
    *((int *)(_2+8)) = _9167;
    RefDS(_9168);
    *((int *)(_2+12)) = _9168;
    RefDS(_9169);
    *((int *)(_2+16)) = _9169;
    RefDS(_9170);
    *((int *)(_2+20)) = _9170;
    RefDS(_7944);
    *((int *)(_2+24)) = _7944;
    _9171 = MAKE_SEQ(_1);
    _9172 = find_from(_9165, _9171, 1);
    DeRef(_9165);
    _9165 = NOVALUE;
    DeRefDS(_9171);
    _9171 = NOVALUE;
    if (_9172 == 0)
    {
        _9172 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _9172 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_16062);
    _opt_param_16062 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16058)){
            _9173 = SEQ_PTR(_opts_16058)->length;
    }
    else {
        _9173 = 1;
    }
    {
        int _i_16153;
        _i_16153 = 1;
L14: 
        if (_i_16153 > _9173){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16058);
        _9174 = (int)*(((s1_ptr)_2)->base + _i_16153);
        _2 = (int)SEQ_PTR(_9174);
        _9175 = (int)*(((s1_ptr)_2)->base + 4);
        _9174 = NOVALUE;
        _9176 = find_from(105, _9175, 1);
        _9175 = NOVALUE;
        if (_9176 == 0)
        {
            _9176 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _9176 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_16061);
        _9177 = _6lower(_opt_name_16061);
        _2 = (int)SEQ_PTR(_opts_16058);
        _9178 = (int)*(((s1_ptr)_2)->base + _i_16153);
        _2 = (int)SEQ_PTR(_opt_style_16059);
        _9179 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_9178);
        if (!IS_ATOM_INT(_9179)){
            _9180 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9179)->dbl));
        }
        else{
            _9180 = (int)*(((s1_ptr)_2)->base + _9179);
        }
        _9178 = NOVALUE;
        Ref(_9180);
        _9181 = _6lower(_9180);
        _9180 = NOVALUE;
        if (_9177 == _9181)
        _9182 = 1;
        else if (IS_ATOM_INT(_9177) && IS_ATOM_INT(_9181))
        _9182 = 0;
        else
        _9182 = (compare(_9177, _9181) == 0);
        DeRef(_9177);
        _9177 = NOVALUE;
        DeRef(_9181);
        _9181 = NOVALUE;
        if (_9182 != 0)
        goto L17; // [444] 482
        _9182 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_16058);
        _9184 = (int)*(((s1_ptr)_2)->base + _i_16153);
        _2 = (int)SEQ_PTR(_opt_style_16059);
        _9185 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_9184);
        if (!IS_ATOM_INT(_9185)){
            _9186 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9185)->dbl));
        }
        else{
            _9186 = (int)*(((s1_ptr)_2)->base + _9185);
        }
        _9184 = NOVALUE;
        if (_opt_name_16061 == _9186)
        _9187 = 1;
        else if (IS_ATOM_INT(_opt_name_16061) && IS_ATOM_INT(_9186))
        _9187 = 0;
        else
        _9187 = (compare(_opt_name_16061, _9186) == 0);
        _9186 = NOVALUE;
        if (_9187 != 0)
        goto L19; // [473] 481
        _9187 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16058);
        _9189 = (int)*(((s1_ptr)_2)->base + _i_16153);
        _2 = (int)SEQ_PTR(_9189);
        _9190 = (int)*(((s1_ptr)_2)->base + 4);
        _9189 = NOVALUE;
        _9191 = find_from(112, _9190, 1);
        _9190 = NOVALUE;
        if (_9191 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_16063 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_9193);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _9193;
        _9194 = MAKE_SEQ(_1);
        DeRefDS(_opts_16058);
        DeRefDS(_opt_style_16059);
        DeRef(_cmd_text_16060);
        DeRef(_opt_name_16061);
        DeRef(_opt_param_16062);
        DeRef(_9115);
        _9115 = NOVALUE;
        DeRef(_9106);
        _9106 = NOVALUE;
        DeRef(_9127);
        _9127 = NOVALUE;
        DeRef(_9133);
        _9133 = NOVALUE;
        DeRef(_9135);
        _9135 = NOVALUE;
        DeRef(_9150);
        _9150 = NOVALUE;
        DeRef(_9141);
        _9141 = NOVALUE;
        _9185 = NOVALUE;
        _9179 = NOVALUE;
        return _9194;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_16063 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16153;
        RefDS(_opt_name_16061);
        *((int *)(_2+8)) = _opt_name_16061;
        *((int *)(_2+12)) = _reversed_16064;
        Ref(_opt_param_16062);
        *((int *)(_2+16)) = _opt_param_16062;
        _9195 = MAKE_SEQ(_1);
        DeRefDS(_opts_16058);
        DeRefDS(_opt_style_16059);
        DeRef(_cmd_text_16060);
        DeRefDS(_opt_name_16061);
        DeRef(_opt_param_16062);
        DeRef(_9115);
        _9115 = NOVALUE;
        DeRef(_9106);
        _9106 = NOVALUE;
        DeRef(_9127);
        _9127 = NOVALUE;
        DeRef(_9133);
        _9133 = NOVALUE;
        DeRef(_9135);
        _9135 = NOVALUE;
        DeRef(_9150);
        _9150 = NOVALUE;
        DeRef(_9141);
        _9141 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        _9185 = NOVALUE;
        _9179 = NOVALUE;
        return _9195;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16058);
        _9196 = (int)*(((s1_ptr)_2)->base + _i_16153);
        _2 = (int)SEQ_PTR(_9196);
        _9197 = (int)*(((s1_ptr)_2)->base + 4);
        _9196 = NOVALUE;
        _9198 = find_from(112, _9197, 1);
        _9197 = NOVALUE;
        if (_9198 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16153;
        RefDS(_opt_name_16061);
        *((int *)(_2+8)) = _opt_name_16061;
        *((int *)(_2+12)) = _reversed_16064;
        *((int *)(_2+16)) = 1;
        _9200 = MAKE_SEQ(_1);
        DeRefDS(_opts_16058);
        DeRefDS(_opt_style_16059);
        DeRef(_cmd_text_16060);
        DeRefDS(_opt_name_16061);
        DeRef(_opt_param_16062);
        DeRef(_9115);
        _9115 = NOVALUE;
        DeRef(_9106);
        _9106 = NOVALUE;
        DeRef(_9127);
        _9127 = NOVALUE;
        DeRef(_9133);
        _9133 = NOVALUE;
        DeRef(_9135);
        _9135 = NOVALUE;
        DeRef(_9150);
        _9150 = NOVALUE;
        DeRef(_9141);
        _9141 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        _9185 = NOVALUE;
        _9179 = NOVALUE;
        DeRef(_9195);
        _9195 = NOVALUE;
        return _9200;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16153;
        RefDS(_opt_name_16061);
        *((int *)(_2+8)) = _opt_name_16061;
        *((int *)(_2+12)) = _reversed_16064;
        _9201 = MAKE_SEQ(_1);
        DeRefDS(_opts_16058);
        DeRefDS(_opt_style_16059);
        DeRef(_cmd_text_16060);
        DeRefDS(_opt_name_16061);
        DeRef(_opt_param_16062);
        DeRef(_9115);
        _9115 = NOVALUE;
        DeRef(_9106);
        _9106 = NOVALUE;
        DeRef(_9127);
        _9127 = NOVALUE;
        DeRef(_9133);
        _9133 = NOVALUE;
        DeRef(_9135);
        _9135 = NOVALUE;
        DeRef(_9150);
        _9150 = NOVALUE;
        DeRef(_9141);
        _9141 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        _9185 = NOVALUE;
        _9179 = NOVALUE;
        DeRef(_9195);
        _9195 = NOVALUE;
        DeRef(_9200);
        _9200 = NOVALUE;
        return _9201;
L1D: 

        /** 	end for*/
L18: 
        _i_16153 = _i_16153 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_9202);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _9202;
    _9203 = MAKE_SEQ(_1);
    DeRefDS(_opts_16058);
    DeRefDS(_opt_style_16059);
    DeRef(_cmd_text_16060);
    DeRef(_opt_name_16061);
    DeRef(_opt_param_16062);
    DeRef(_9115);
    _9115 = NOVALUE;
    DeRef(_9106);
    _9106 = NOVALUE;
    DeRef(_9127);
    _9127 = NOVALUE;
    DeRef(_9133);
    _9133 = NOVALUE;
    DeRef(_9135);
    _9135 = NOVALUE;
    DeRef(_9150);
    _9150 = NOVALUE;
    DeRef(_9141);
    _9141 = NOVALUE;
    DeRef(_9194);
    _9194 = NOVALUE;
    _9185 = NOVALUE;
    _9179 = NOVALUE;
    DeRef(_9195);
    _9195 = NOVALUE;
    DeRef(_9200);
    _9200 = NOVALUE;
    DeRef(_9201);
    _9201 = NOVALUE;
    return _9203;
    ;
}


int  __stdcall _31cmd_parse(int _opts_16196, int _parse_options_16197, int _cmds_16198)
{
    int _arg_idx_16200 = NOVALUE;
    int _opts_done_16201 = NOVALUE;
    int _cmd_16202 = NOVALUE;
    int _param_16203 = NOVALUE;
    int _find_result_16204 = NOVALUE;
    int _type__16205 = NOVALUE;
    int _from__16206 = NOVALUE;
    int _help_opts_16207 = NOVALUE;
    int _call_count_16208 = NOVALUE;
    int _add_help_rid_16209 = NOVALUE;
    int _validation_16210 = NOVALUE;
    int _has_extra_16211 = NOVALUE;
    int _use_at_16212 = NOVALUE;
    int _auto_help_16213 = NOVALUE;
    int _help_on_error_16214 = NOVALUE;
    int _po_16215 = NOVALUE;
    int _msg_inlined_crash_at_107_16233 = NOVALUE;
    int _msg_inlined_crash_at_237_16250 = NOVALUE;
    int _msg_inlined_crash_at_275_16257 = NOVALUE;
    int _fmt_inlined_crash_at_272_16256 = NOVALUE;
    int _parsed_opts_16262 = NOVALUE;
    int _at_cmds_16309 = NOVALUE;
    int _j_16310 = NOVALUE;
    int _cmdex_16395 = NOVALUE;
    int _opt_16459 = NOVALUE;
    int _map_add_operation_16462 = NOVALUE;
    int _pos_16501 = NOVALUE;
    int _ver_pos_16548 = NOVALUE;
    int _msg_inlined_crash_at_2040_16566 = NOVALUE;
    int _fmt_inlined_crash_at_2037_16565 = NOVALUE;
    int _9485 = NOVALUE;
    int _9484 = NOVALUE;
    int _9483 = NOVALUE;
    int _9480 = NOVALUE;
    int _9479 = NOVALUE;
    int _9478 = NOVALUE;
    int _9475 = NOVALUE;
    int _9474 = NOVALUE;
    int _9473 = NOVALUE;
    int _9472 = NOVALUE;
    int _9471 = NOVALUE;
    int _9470 = NOVALUE;
    int _9469 = NOVALUE;
    int _9468 = NOVALUE;
    int _9467 = NOVALUE;
    int _9466 = NOVALUE;
    int _9465 = NOVALUE;
    int _9464 = NOVALUE;
    int _9463 = NOVALUE;
    int _9462 = NOVALUE;
    int _9461 = NOVALUE;
    int _9460 = NOVALUE;
    int _9457 = NOVALUE;
    int _9456 = NOVALUE;
    int _9455 = NOVALUE;
    int _9452 = NOVALUE;
    int _9451 = NOVALUE;
    int _9449 = NOVALUE;
    int _9448 = NOVALUE;
    int _9447 = NOVALUE;
    int _9446 = NOVALUE;
    int _9445 = NOVALUE;
    int _9444 = NOVALUE;
    int _9443 = NOVALUE;
    int _9442 = NOVALUE;
    int _9440 = NOVALUE;
    int _9439 = NOVALUE;
    int _9437 = NOVALUE;
    int _9436 = NOVALUE;
    int _9435 = NOVALUE;
    int _9434 = NOVALUE;
    int _9433 = NOVALUE;
    int _9432 = NOVALUE;
    int _9431 = NOVALUE;
    int _9430 = NOVALUE;
    int _9428 = NOVALUE;
    int _9427 = NOVALUE;
    int _9426 = NOVALUE;
    int _9424 = NOVALUE;
    int _9422 = NOVALUE;
    int _9421 = NOVALUE;
    int _9420 = NOVALUE;
    int _9419 = NOVALUE;
    int _9418 = NOVALUE;
    int _9417 = NOVALUE;
    int _9416 = NOVALUE;
    int _9415 = NOVALUE;
    int _9414 = NOVALUE;
    int _9411 = NOVALUE;
    int _9408 = NOVALUE;
    int _9407 = NOVALUE;
    int _9405 = NOVALUE;
    int _9404 = NOVALUE;
    int _9403 = NOVALUE;
    int _9402 = NOVALUE;
    int _9401 = NOVALUE;
    int _9400 = NOVALUE;
    int _9399 = NOVALUE;
    int _9398 = NOVALUE;
    int _9397 = NOVALUE;
    int _9396 = NOVALUE;
    int _9395 = NOVALUE;
    int _9392 = NOVALUE;
    int _9389 = NOVALUE;
    int _9387 = NOVALUE;
    int _9386 = NOVALUE;
    int _9384 = NOVALUE;
    int _9383 = NOVALUE;
    int _9382 = NOVALUE;
    int _9380 = NOVALUE;
    int _9379 = NOVALUE;
    int _9378 = NOVALUE;
    int _9376 = NOVALUE;
    int _9374 = NOVALUE;
    int _9372 = NOVALUE;
    int _9370 = NOVALUE;
    int _9369 = NOVALUE;
    int _9368 = NOVALUE;
    int _9367 = NOVALUE;
    int _9366 = NOVALUE;
    int _9362 = NOVALUE;
    int _9360 = NOVALUE;
    int _9359 = NOVALUE;
    int _9358 = NOVALUE;
    int _9357 = NOVALUE;
    int _9356 = NOVALUE;
    int _9355 = NOVALUE;
    int _9353 = NOVALUE;
    int _9352 = NOVALUE;
    int _9351 = NOVALUE;
    int _9350 = NOVALUE;
    int _9349 = NOVALUE;
    int _9348 = NOVALUE;
    int _9347 = NOVALUE;
    int _9343 = NOVALUE;
    int _9342 = NOVALUE;
    int _9339 = NOVALUE;
    int _9338 = NOVALUE;
    int _9337 = NOVALUE;
    int _9336 = NOVALUE;
    int _9335 = NOVALUE;
    int _9334 = NOVALUE;
    int _9333 = NOVALUE;
    int _9332 = NOVALUE;
    int _9331 = NOVALUE;
    int _9330 = NOVALUE;
    int _9329 = NOVALUE;
    int _9328 = NOVALUE;
    int _9327 = NOVALUE;
    int _9326 = NOVALUE;
    int _9325 = NOVALUE;
    int _9324 = NOVALUE;
    int _9323 = NOVALUE;
    int _9322 = NOVALUE;
    int _9321 = NOVALUE;
    int _9320 = NOVALUE;
    int _9319 = NOVALUE;
    int _9318 = NOVALUE;
    int _9317 = NOVALUE;
    int _9316 = NOVALUE;
    int _9315 = NOVALUE;
    int _9314 = NOVALUE;
    int _9313 = NOVALUE;
    int _9312 = NOVALUE;
    int _9311 = NOVALUE;
    int _9310 = NOVALUE;
    int _9309 = NOVALUE;
    int _9308 = NOVALUE;
    int _9305 = NOVALUE;
    int _9304 = NOVALUE;
    int _9303 = NOVALUE;
    int _9302 = NOVALUE;
    int _9301 = NOVALUE;
    int _9299 = NOVALUE;
    int _9298 = NOVALUE;
    int _9295 = NOVALUE;
    int _9294 = NOVALUE;
    int _9293 = NOVALUE;
    int _9292 = NOVALUE;
    int _9291 = NOVALUE;
    int _9289 = NOVALUE;
    int _9288 = NOVALUE;
    int _9287 = NOVALUE;
    int _9286 = NOVALUE;
    int _9283 = NOVALUE;
    int _9281 = NOVALUE;
    int _9280 = NOVALUE;
    int _9279 = NOVALUE;
    int _9277 = NOVALUE;
    int _9275 = NOVALUE;
    int _9274 = NOVALUE;
    int _9271 = NOVALUE;
    int _9269 = NOVALUE;
    int _9268 = NOVALUE;
    int _9267 = NOVALUE;
    int _9266 = NOVALUE;
    int _9265 = NOVALUE;
    int _9264 = NOVALUE;
    int _9263 = NOVALUE;
    int _9262 = NOVALUE;
    int _9261 = NOVALUE;
    int _9260 = NOVALUE;
    int _9258 = NOVALUE;
    int _9254 = NOVALUE;
    int _9252 = NOVALUE;
    int _9251 = NOVALUE;
    int _9250 = NOVALUE;
    int _9247 = NOVALUE;
    int _9246 = NOVALUE;
    int _9245 = NOVALUE;
    int _9243 = NOVALUE;
    int _9242 = NOVALUE;
    int _9241 = NOVALUE;
    int _9240 = NOVALUE;
    int _9239 = NOVALUE;
    int _9237 = NOVALUE;
    int _9236 = NOVALUE;
    int _9235 = NOVALUE;
    int _9234 = NOVALUE;
    int _9233 = NOVALUE;
    int _9232 = NOVALUE;
    int _9231 = NOVALUE;
    int _9230 = NOVALUE;
    int _9229 = NOVALUE;
    int _9226 = NOVALUE;
    int _9223 = NOVALUE;
    int _9222 = NOVALUE;
    int _9216 = NOVALUE;
    int _9212 = NOVALUE;
    int _9209 = NOVALUE;
    int _9207 = NOVALUE;
    int _9205 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    DeRef(_add_help_rid_16209);
    _add_help_rid_16209 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_16210 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_16211 = 0;

    /** 	integer use_at = 1*/
    _use_at_16212 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_16213 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_16214 = 1;

    /** 	integer po = 1*/
    _po_16215 = 1;

    /** 	if atom(parse_options) then*/
    _9205 = IS_ATOM(_parse_options_16197);
    if (_9205 == 0)
    {
        _9205 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _9205 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_16197;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_16197);
    *((int *)(_2+4)) = _parse_options_16197;
    _parse_options_16197 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_16197)){
            _9207 = SEQ_PTR(_parse_options_16197)->length;
    }
    else {
        _9207 = 1;
    }
    if (_po_16215 > _9207)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_16197);
    _9209 = (int)*(((s1_ptr)_2)->base + _po_16215);
    if (IS_SEQUENCE(_9209) ){
        goto L4; // [73] 261
    }
    if(!IS_ATOM_INT(_9209)){
        if( (DBL_PTR(_9209)->dbl != (double) ((int) DBL_PTR(_9209)->dbl) ) ){
            goto L4; // [73] 261
        }
        _0 = (int) DBL_PTR(_9209)->dbl;
    }
    else {
        _0 = _9209;
    };
    _9209 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_16197)){
                _9212 = SEQ_PTR(_parse_options_16197)->length;
        }
        else {
            _9212 = 1;
        }
        if (_po_16215 >= _9212)
        goto L5; // [87] 106

        /** 					po += 1*/
        _po_16215 = _po_16215 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_16209);
        _2 = (int)SEQ_PTR(_parse_options_16197);
        _add_help_rid_16209 = (int)*(((s1_ptr)_2)->base + _po_16215);
        Ref(_add_help_rid_16209);
        goto L6; // [103] 297
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_16233);
        _msg_inlined_crash_at_107_16233 = EPrintf(-9999999, _8924, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_16233);

        /** end procedure*/
        goto L7; // [121] 124
L7: 
        DeRefi(_msg_inlined_crash_at_107_16233);
        _msg_inlined_crash_at_107_16233 = NOVALUE;
        goto L6; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_16213 = 0;
        goto L6; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_16214 = 0;
        goto L6; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_16210 = 2;
        goto L6; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_16210 = 3;
        goto L6; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_16210 = 4;
        goto L6; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_16212 = 0;
        goto L6; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_16212 = 1;
        goto L6; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_16197)){
                _9216 = SEQ_PTR(_parse_options_16197)->length;
        }
        else {
            _9216 = 1;
        }
        if (_po_16215 >= _9216)
        goto L8; // [215] 236

        /** 					po += 1*/
        _po_16215 = _po_16215 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_31pause_msg_15509);
        _2 = (int)SEQ_PTR(_parse_options_16197);
        _31pause_msg_15509 = (int)*(((s1_ptr)_2)->base + _po_16215);
        Ref(_31pause_msg_15509);
        goto L6; // [233] 297
L8: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_16250);
        _msg_inlined_crash_at_237_16250 = EPrintf(-9999999, _9220, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_16250);

        /** end procedure*/
        goto L9; // [251] 254
L9: 
        DeRefi(_msg_inlined_crash_at_237_16250);
        _msg_inlined_crash_at_237_16250 = NOVALUE;
        goto L6; // [257] 297

        /** 			case else*/
        default:
L4: 

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_16197);
        _9222 = (int)*(((s1_ptr)_2)->base + _po_16215);
        _9223 = EPrintf(-9999999, _9221, _9222);
        _9222 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_16256);
        _fmt_inlined_crash_at_272_16256 = _9223;
        _9223 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_16257);
        _msg_inlined_crash_at_275_16257 = EPrintf(-9999999, _fmt_inlined_crash_at_272_16256, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_16257);

        /** end procedure*/
        goto LA; // [291] 294
LA: 
        DeRefi(_fmt_inlined_crash_at_272_16256);
        _fmt_inlined_crash_at_272_16256 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_16257);
        _msg_inlined_crash_at_275_16257 = NOVALUE;
    ;}L6: 

    /** 		po += 1*/
    _po_16215 = _po_16215 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_16196);
    _0 = _opts_16196;
    _opts_16196 = _31standardize_opts(_opts_16196, _auto_help_16213);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_16196)){
            _9226 = SEQ_PTR(_opts_16196)->length;
    }
    else {
        _9226 = 1;
    }
    DeRef(_call_count_16208);
    _call_count_16208 = Repeat(0, _9226);
    _9226 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_16262;
    _parsed_opts_16262 = _33new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_16262);
    RefDS(_31EXTRAS_15498);
    RefDS(_5);
    _33put(_parsed_opts_16262, _31EXTRAS_15498, _5, 1, _33threshold_size_12989);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_16207);
    _help_opts_16207 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16196)){
            _9229 = SEQ_PTR(_opts_16196)->length;
    }
    else {
        _9229 = 1;
    }
    {
        int _i_16265;
        _i_16265 = 1;
LB: 
        if (_i_16265 > _9229){
            goto LC; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9230 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9230);
        _9231 = (int)*(((s1_ptr)_2)->base + 4);
        _9230 = NOVALUE;
        _9232 = find_from(104, _9231, 1);
        _9231 = NOVALUE;
        if (_9232 == 0)
        {
            _9232 = NOVALUE;
            goto LD; // [379] 510
        }
        else{
            _9232 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9233 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9233);
        _9234 = (int)*(((s1_ptr)_2)->base + 1);
        _9233 = NOVALUE;
        _9235 = IS_SEQUENCE(_9234);
        _9234 = NOVALUE;
        if (_9235 == 0)
        {
            _9235 = NOVALUE;
            goto LE; // [395] 413
        }
        else{
            _9235 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9236 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9236);
        _9237 = (int)*(((s1_ptr)_2)->base + 1);
        _9236 = NOVALUE;
        Ref(_9237);
        Append(&_help_opts_16207, _help_opts_16207, _9237);
        _9237 = NOVALUE;
LE: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9239 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9239);
        _9240 = (int)*(((s1_ptr)_2)->base + 2);
        _9239 = NOVALUE;
        _9241 = IS_SEQUENCE(_9240);
        _9240 = NOVALUE;
        if (_9241 == 0)
        {
            _9241 = NOVALUE;
            goto LF; // [426] 444
        }
        else{
            _9241 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9242 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9242);
        _9243 = (int)*(((s1_ptr)_2)->base + 2);
        _9242 = NOVALUE;
        Ref(_9243);
        Append(&_help_opts_16207, _help_opts_16207, _9243);
        _9243 = NOVALUE;
LF: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9245 = (int)*(((s1_ptr)_2)->base + _i_16265);
        _2 = (int)SEQ_PTR(_9245);
        _9246 = (int)*(((s1_ptr)_2)->base + 4);
        _9245 = NOVALUE;
        _9247 = find_from(105, _9246, 1);
        _9246 = NOVALUE;
        if (_9247 == 0)
        {
            _9247 = NOVALUE;
            goto L10; // [459] 509
        }
        else{
            _9247 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_16207);
        _0 = _help_opts_16207;
        _help_opts_16207 = _6lower(_help_opts_16207);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_16207)){
                _arg_idx_16200 = SEQ_PTR(_help_opts_16207)->length;
        }
        else {
            _arg_idx_16200 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _9250 = _arg_idx_16200;
        {
            int _j_16292;
            _j_16292 = 1;
L11: 
            if (_j_16292 > _9250){
                goto L12; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_16207);
            _9251 = (int)*(((s1_ptr)_2)->base + _j_16292);
            Ref(_9251);
            _9252 = _6upper(_9251);
            _9251 = NOVALUE;
            Ref(_9252);
            Append(&_help_opts_16207, _help_opts_16207, _9252);
            DeRef(_9252);
            _9252 = NOVALUE;

            /** 				end for*/
            _j_16292 = _j_16292 + 1;
            goto L11; // [503] 487
L12: 
            ;
        }
L10: 
LD: 

        /** 	end for*/
        _i_16265 = _i_16265 + 1;
        goto LB; // [512] 364
LC: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_16200 = 2;

    /** 	opts_done = 0*/
    _opts_done_16201 = 0;

    /** 	while arg_idx < length(cmds) do*/
L13: 
    if (IS_SEQUENCE(_cmds_16198)){
            _9254 = SEQ_PTR(_cmds_16198)->length;
    }
    else {
        _9254 = 1;
    }
    if (_arg_idx_16200 >= _9254)
    goto L14; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_16200 = _arg_idx_16200 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_16202);
    _2 = (int)SEQ_PTR(_cmds_16198);
    _cmd_16202 = (int)*(((s1_ptr)_2)->base + _arg_idx_16200);
    Ref(_cmd_16202);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9258 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9258 = 1;
    }
    if (_9258 != 0)
    goto L15; // [558] 567

    /** 			continue*/
    goto L13; // [564] 532
L15: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_16202);
    _9260 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9260)) {
        _9261 = (_9260 == 64);
    }
    else {
        _9261 = binary_op(EQUALS, _9260, 64);
    }
    _9260 = NOVALUE;
    if (IS_ATOM_INT(_9261)) {
        if (_9261 == 0) {
            goto L16; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_9261)->dbl == 0.0) {
            goto L16; // [577] 1095
        }
    }
    if (_use_at_16212 == 0)
    {
        goto L16; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9263 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9263 = 1;
    }
    _9264 = (_9263 > 2);
    _9263 = NOVALUE;
    if (_9264 == 0) {
        goto L17; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_16202);
    _9266 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_9266)) {
        _9267 = (_9266 == 64);
    }
    else {
        _9267 = binary_op(EQUALS, _9266, 64);
    }
    _9266 = NOVALUE;
    if (_9267 == 0) {
        DeRef(_9267);
        _9267 = NOVALUE;
        goto L17; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_9267) && DBL_PTR(_9267)->dbl == 0.0){
            DeRef(_9267);
            _9267 = NOVALUE;
            goto L17; // [611] 660
        }
        DeRef(_9267);
        _9267 = NOVALUE;
    }
    DeRef(_9267);
    _9267 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9268 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9268 = 1;
    }
    rhs_slice_target = (object_ptr)&_9269;
    RHS_Slice(_cmd_16202, 3, _9268);
    _0 = _at_cmds_16309;
    _at_cmds_16309 = _18read_lines(_9269);
    DeRef(_0);
    _9269 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16309 == -1)
    _9271 = 1;
    else if (IS_ATOM_INT(_at_cmds_16309) && IS_ATOM_INT(-1))
    _9271 = 0;
    else
    _9271 = (compare(_at_cmds_16309, -1) == 0);
    if (_9271 == 0)
    {
        _9271 = NOVALUE;
        goto L18; // [634] 738
    }
    else{
        _9271 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_16198);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_16200)) ? _arg_idx_16200 : (long)(DBL_PTR(_arg_idx_16200)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_16200)) ? _arg_idx_16200 : (long)(DBL_PTR(_arg_idx_16200)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_16198), start, &_cmds_16198 );
            }
            else Tail(SEQ_PTR(_cmds_16198), stop+1, &_cmds_16198);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_16198), start, &_cmds_16198);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_16198 = Remove_elements(start, stop, (SEQ_PTR(_cmds_16198)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_16200 = _arg_idx_16200 - 1;

    /** 					continue*/
    DeRef(_at_cmds_16309);
    _at_cmds_16309 = NOVALUE;
    goto L13; // [654] 532
    goto L18; // [657] 738
L17: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9274 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9274 = 1;
    }
    rhs_slice_target = (object_ptr)&_9275;
    RHS_Slice(_cmd_16202, 2, _9274);
    _0 = _at_cmds_16309;
    _at_cmds_16309 = _18read_lines(_9275);
    DeRef(_0);
    _9275 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16309 == -1)
    _9277 = 1;
    else if (IS_ATOM_INT(_at_cmds_16309) && IS_ATOM_INT(-1))
    _9277 = 0;
    else
    _9277 = (compare(_at_cmds_16309, -1) == 0);
    if (_9277 == 0)
    {
        _9277 = NOVALUE;
        goto L19; // [680] 737
    }
    else{
        _9277 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9279 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9279 = 1;
    }
    rhs_slice_target = (object_ptr)&_9280;
    RHS_Slice(_cmd_16202, 2, _9279);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9280;
    _9281 = MAKE_SEQ(_1);
    _9280 = NOVALUE;
    EPrintf(2, _9278, _9281);
    DeRefDS(_9281);
    _9281 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_16214 == 0)
    {
        goto L1A; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16196);
    Ref(_add_help_rid_16209);
    RefDS(_cmds_16198);
    Ref(_parse_options_16197);
    _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
    goto L1B; // [715] 731
L1A: 

    /** 					elsif auto_help then*/
    if (_auto_help_16213 == 0)
    {
        goto L1C; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _9282, _5);
L1C: 
L1B: 

    /** 					local_abort(1)*/
    _31local_abort(1);
L19: 
L18: 

    /** 			j = 0*/
    _j_16310 = 0;

    /** 			while j < length(at_cmds) do*/
L1D: 
    if (IS_SEQUENCE(_at_cmds_16309)){
            _9283 = SEQ_PTR(_at_cmds_16309)->length;
    }
    else {
        _9283 = 1;
    }
    if (_j_16310 >= _9283)
    goto L1E; // [753] 1074

    /** 				j += 1*/
    _j_16310 = _j_16310 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9286 = (int)*(((s1_ptr)_2)->base + _j_16310);
    Ref(_9286);
    RefDS(_4563);
    _9287 = _6trim(_9286, _4563, 0);
    _9286 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16309 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16310);
    _1 = *(int *)_2;
    *(int *)_2 = _9287;
    if( _1 != _9287 ){
        DeRef(_1);
    }
    _9287 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9288 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9288)){
            _9289 = SEQ_PTR(_9288)->length;
    }
    else {
        _9289 = 1;
    }
    _9288 = NOVALUE;
    if (_9289 != 0)
    goto L1F; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _9291 = _j_16310 - 1;
    rhs_slice_target = (object_ptr)&_9292;
    RHS_Slice(_at_cmds_16309, 1, _9291);
    _9293 = _j_16310 + 1;
    if (_9293 > MAXINT){
        _9293 = NewDouble((double)_9293);
    }
    if (IS_SEQUENCE(_at_cmds_16309)){
            _9294 = SEQ_PTR(_at_cmds_16309)->length;
    }
    else {
        _9294 = 1;
    }
    rhs_slice_target = (object_ptr)&_9295;
    RHS_Slice(_at_cmds_16309, _9293, _9294);
    Concat((object_ptr)&_at_cmds_16309, _9292, _9295);
    DeRefDS(_9292);
    _9292 = NOVALUE;
    DeRef(_9292);
    _9292 = NOVALUE;
    DeRefDS(_9295);
    _9295 = NOVALUE;

    /** 					j -= 1*/
    _j_16310 = _j_16310 - 1;
    goto L1D; // [825] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9298 = (int)*(((s1_ptr)_2)->base + _j_16310);
    _2 = (int)SEQ_PTR(_9298);
    _9299 = (int)*(((s1_ptr)_2)->base + 1);
    _9298 = NOVALUE;
    if (binary_op_a(NOTEQ, _9299, 35)){
        _9299 = NOVALUE;
        goto L20; // [838] 878
    }
    _9299 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _9301 = _j_16310 - 1;
    rhs_slice_target = (object_ptr)&_9302;
    RHS_Slice(_at_cmds_16309, 1, _9301);
    _9303 = _j_16310 + 1;
    if (_9303 > MAXINT){
        _9303 = NewDouble((double)_9303);
    }
    if (IS_SEQUENCE(_at_cmds_16309)){
            _9304 = SEQ_PTR(_at_cmds_16309)->length;
    }
    else {
        _9304 = 1;
    }
    rhs_slice_target = (object_ptr)&_9305;
    RHS_Slice(_at_cmds_16309, _9303, _9304);
    Concat((object_ptr)&_at_cmds_16309, _9302, _9305);
    DeRefDS(_9302);
    _9302 = NOVALUE;
    DeRef(_9302);
    _9302 = NOVALUE;
    DeRefDS(_9305);
    _9305 = NOVALUE;

    /** 					j -= 1*/
    _j_16310 = _j_16310 - 1;
    goto L1D; // [875] 748
L20: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9308 = (int)*(((s1_ptr)_2)->base + _j_16310);
    _2 = (int)SEQ_PTR(_9308);
    _9309 = (int)*(((s1_ptr)_2)->base + 1);
    _9308 = NOVALUE;
    if (IS_ATOM_INT(_9309)) {
        _9310 = (_9309 == 34);
    }
    else {
        _9310 = binary_op(EQUALS, _9309, 34);
    }
    _9309 = NOVALUE;
    if (IS_ATOM_INT(_9310)) {
        if (_9310 == 0) {
            DeRef(_9311);
            _9311 = 0;
            goto L21; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_9310)->dbl == 0.0) {
            DeRef(_9311);
            _9311 = 0;
            goto L21; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9312 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9312)){
            _9313 = SEQ_PTR(_9312)->length;
    }
    else {
        _9313 = 1;
    }
    _2 = (int)SEQ_PTR(_9312);
    _9314 = (int)*(((s1_ptr)_2)->base + _9313);
    _9312 = NOVALUE;
    if (IS_ATOM_INT(_9314)) {
        _9315 = (_9314 == 34);
    }
    else {
        _9315 = binary_op(EQUALS, _9314, 34);
    }
    _9314 = NOVALUE;
    DeRef(_9311);
    if (IS_ATOM_INT(_9315))
    _9311 = (_9315 != 0);
    else
    _9311 = DBL_PTR(_9315)->dbl != 0.0;
L21: 
    if (_9311 == 0) {
        goto L22; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9317 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9317)){
            _9318 = SEQ_PTR(_9317)->length;
    }
    else {
        _9318 = 1;
    }
    _9317 = NOVALUE;
    _9319 = (_9318 >= 2);
    _9318 = NOVALUE;
    if (_9319 == 0)
    {
        DeRef(_9319);
        _9319 = NOVALUE;
        goto L22; // [931] 959
    }
    else{
        DeRef(_9319);
        _9319 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9320 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9320)){
            _9321 = SEQ_PTR(_9320)->length;
    }
    else {
        _9321 = 1;
    }
    _9322 = _9321 - 1;
    _9321 = NOVALUE;
    rhs_slice_target = (object_ptr)&_9323;
    RHS_Slice(_9320, 2, _9322);
    _9320 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16309 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16310);
    _1 = *(int *)_2;
    *(int *)_2 = _9323;
    if( _1 != _9323 ){
        DeRef(_1);
    }
    _9323 = NOVALUE;
    goto L1D; // [956] 748
L22: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9324 = (int)*(((s1_ptr)_2)->base + _j_16310);
    _2 = (int)SEQ_PTR(_9324);
    _9325 = (int)*(((s1_ptr)_2)->base + 1);
    _9324 = NOVALUE;
    if (IS_ATOM_INT(_9325)) {
        _9326 = (_9325 == 39);
    }
    else {
        _9326 = binary_op(EQUALS, _9325, 39);
    }
    _9325 = NOVALUE;
    if (IS_ATOM_INT(_9326)) {
        if (_9326 == 0) {
            DeRef(_9327);
            _9327 = 0;
            goto L23; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_9326)->dbl == 0.0) {
            DeRef(_9327);
            _9327 = 0;
            goto L23; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9328 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9328)){
            _9329 = SEQ_PTR(_9328)->length;
    }
    else {
        _9329 = 1;
    }
    _2 = (int)SEQ_PTR(_9328);
    _9330 = (int)*(((s1_ptr)_2)->base + _9329);
    _9328 = NOVALUE;
    if (IS_ATOM_INT(_9330)) {
        _9331 = (_9330 == 39);
    }
    else {
        _9331 = binary_op(EQUALS, _9330, 39);
    }
    _9330 = NOVALUE;
    DeRef(_9327);
    if (IS_ATOM_INT(_9331))
    _9327 = (_9331 != 0);
    else
    _9327 = DBL_PTR(_9331)->dbl != 0.0;
L23: 
    if (_9327 == 0) {
        goto L24; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9333 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9333)){
            _9334 = SEQ_PTR(_9333)->length;
    }
    else {
        _9334 = 1;
    }
    _9333 = NOVALUE;
    _9335 = (_9334 >= 2);
    _9334 = NOVALUE;
    if (_9335 == 0)
    {
        DeRef(_9335);
        _9335 = NOVALUE;
        goto L24; // [1012] 1066
    }
    else{
        DeRef(_9335);
        _9335 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_16309);
    _9336 = (int)*(((s1_ptr)_2)->base + _j_16310);
    if (IS_SEQUENCE(_9336)){
            _9337 = SEQ_PTR(_9336)->length;
    }
    else {
        _9337 = 1;
    }
    _9338 = _9337 - 1;
    _9337 = NOVALUE;
    rhs_slice_target = (object_ptr)&_9339;
    RHS_Slice(_9336, 2, _9338);
    _9336 = NOVALUE;
    _0 = _cmdex_16395;
    _cmdex_16395 = _23split(_9339, 32, 1, 0);
    DeRef(_0);
    _9339 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_16309;
        int p2 = _cmdex_16395;
        int p3 = _j_16310;
        int p4 = _j_16310;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_16309;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_16395)){
            _9342 = SEQ_PTR(_cmdex_16395)->length;
    }
    else {
        _9342 = 1;
    }
    _9343 = _j_16310 + _9342;
    if ((long)((unsigned long)_9343 + (unsigned long)HIGH_BITS) >= 0) 
    _9343 = NewDouble((double)_9343);
    _9342 = NOVALUE;
    if (IS_ATOM_INT(_9343)) {
        _j_16310 = _9343 - 1;
    }
    else {
        _j_16310 = NewDouble(DBL_PTR(_9343)->dbl - (double)1);
    }
    DeRef(_9343);
    _9343 = NOVALUE;
    if (!IS_ATOM_INT(_j_16310)) {
        _1 = (long)(DBL_PTR(_j_16310)->dbl);
        DeRefDS(_j_16310);
        _j_16310 = _1;
    }
L24: 
    DeRef(_cmdex_16395);
    _cmdex_16395 = NOVALUE;

    /** 			end while*/
    goto L1D; // [1071] 748
L1E: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_16198;
        int p2 = _at_cmds_16309;
        int p3 = _arg_idx_16200;
        int p4 = _arg_idx_16200;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_16198;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_16200 = _arg_idx_16200 - 1;

    /** 			continue*/
    DeRef(_at_cmds_16309);
    _at_cmds_16309 = NOVALUE;
    goto L13; // [1092] 532
L16: 
    DeRef(_at_cmds_16309);
    _at_cmds_16309 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_16201 != 0) {
        _9347 = 1;
        goto L25; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_16202);
    _9348 = (int)*(((s1_ptr)_2)->base + 1);
    _9349 = find_from(_9348, _37CMD_SWITCHES_15290, 1);
    _9348 = NOVALUE;
    _9350 = (_9349 == 0);
    _9349 = NOVALUE;
    _9347 = (_9350 != 0);
L25: 
    if (_9347 != 0) {
        DeRef(_9351);
        _9351 = 1;
        goto L26; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_16202)){
            _9352 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9352 = 1;
    }
    _9353 = (_9352 == 1);
    _9352 = NOVALUE;
    _9351 = (_9353 != 0);
L26: 
    if (_9351 == 0)
    {
        _9351 = NOVALUE;
        goto L27; // [1135] 1215
    }
    else{
        _9351 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_16262);
    RefDS(_31EXTRAS_15498);
    RefDS(_cmd_16202);
    _33put(_parsed_opts_16262, _31EXTRAS_15498, _cmd_16202, 6, _33threshold_size_12989);

    /** 			has_extra = 1*/
    _has_extra_16211 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_16210 != 4)
    goto L13; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _9355 = _arg_idx_16200 + 1;
    if (_9355 > MAXINT){
        _9355 = NewDouble((double)_9355);
    }
    if (IS_SEQUENCE(_cmds_16198)){
            _9356 = SEQ_PTR(_cmds_16198)->length;
    }
    else {
        _9356 = 1;
    }
    {
        int _i_16418;
        Ref(_9355);
        _i_16418 = _9355;
L28: 
        if (binary_op_a(GREATER, _i_16418, _9356)){
            goto L29; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_16198);
        if (!IS_ATOM_INT(_i_16418)){
            _9357 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_16418)->dbl));
        }
        else{
            _9357 = (int)*(((s1_ptr)_2)->base + _i_16418);
        }
        Ref(_parsed_opts_16262);
        RefDS(_31EXTRAS_15498);
        Ref(_9357);
        _33put(_parsed_opts_16262, _31EXTRAS_15498, _9357, 6, _33threshold_size_12989);
        _9357 = NOVALUE;

        /** 				end for*/
        _0 = _i_16418;
        if (IS_ATOM_INT(_i_16418)) {
            _i_16418 = _i_16418 + 1;
            if ((long)((unsigned long)_i_16418 +(unsigned long) HIGH_BITS) >= 0){
                _i_16418 = NewDouble((double)_i_16418);
            }
        }
        else {
            _i_16418 = binary_op_a(PLUS, _i_16418, 1);
        }
        DeRef(_0);
        goto L28; // [1197] 1178
L29: 
        ;
        DeRef(_i_16418);
    }

    /** 				exit*/
    goto L14; // [1204] 2072
    goto L2A; // [1206] 1214

    /** 				continue*/
    goto L13; // [1211] 532
L2A: 
L27: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_16202 == _6725)
    _9358 = 1;
    else if (IS_ATOM_INT(_cmd_16202) && IS_ATOM_INT(_6725))
    _9358 = 0;
    else
    _9358 = (compare(_cmd_16202, _6725) == 0);
    if (_9358 == 0)
    {
        _9358 = NOVALUE;
        goto L2B; // [1221] 1234
    }
    else{
        _9358 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_16201 = 1;

    /** 			continue*/
    goto L13; // [1231] 532
L2B: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_9359;
    RHS_Slice(_cmd_16202, 1, 2);
    if (_9359 == _6725)
    _9360 = 1;
    else if (IS_ATOM_INT(_9359) && IS_ATOM_INT(_6725))
    _9360 = 0;
    else
    _9360 = (compare(_9359, _6725) == 0);
    DeRefDS(_9359);
    _9359 = NOVALUE;
    if (_9360 == 0)
    {
        _9360 = NOVALUE;
        goto L2C; // [1245] 1262
    }
    else{
        _9360 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_6725);
    DeRef(_type__16205);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _6725;
    _type__16205 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__16206 = 3;
    goto L2D; // [1259] 1298
L2C: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_16202);
    _9362 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9362, 45)){
        _9362 = NOVALUE;
        goto L2E; // [1268] 1286
    }
    _9362 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_7944);
    DeRef(_type__16205);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _7944;
    _type__16205 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__16206 = 2;
    goto L2D; // [1283] 1298
L2E: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_3806);
    DeRef(_type__16205);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _3806;
    _type__16205 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__16206 = 2;
L2D: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9366 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9366 = 1;
    }
    rhs_slice_target = (object_ptr)&_9367;
    RHS_Slice(_cmd_16202, _from__16206, _9366);
    _9368 = find_from(_9367, _help_opts_16207, 1);
    DeRefDS(_9367);
    _9367 = NOVALUE;
    if (_9368 == 0)
    {
        _9368 = NOVALUE;
        goto L2F; // [1315] 1335
    }
    else{
        _9368 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16196);
    Ref(_add_help_rid_16209);
    RefDS(_cmds_16198);
    Ref(_parse_options_16197);
    _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _31local_abort(0);
L2F: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_16202)){
            _9369 = SEQ_PTR(_cmd_16202)->length;
    }
    else {
        _9369 = 1;
    }
    rhs_slice_target = (object_ptr)&_9370;
    RHS_Slice(_cmd_16202, _from__16206, _9369);
    RefDS(_opts_16196);
    RefDS(_type__16205);
    _0 = _find_result_16204;
    _find_result_16204 = _31find_opt(_opts_16196, _type__16205, _9370);
    DeRef(_0);
    _9370 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9372 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _9372, 0)){
        _9372 = NOVALUE;
        goto L30; // [1361] 1370
    }
    _9372 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L13; // [1367] 532
L30: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9374 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9374, 0)){
        _9374 = NOVALUE;
        goto L31; // [1376] 1471
    }
    _9374 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _9376 = (_validation_16210 == 2);
    if (_9376 != 0) {
        goto L32; // [1386] 1411
    }
    _9378 = (_validation_16210 == 4);
    if (_9378 == 0) {
        DeRef(_9379);
        _9379 = 0;
        goto L33; // [1394] 1406
    }
    _9380 = (_has_extra_16211 == 0);
    _9379 = (_9380 != 0);
L33: 
    if (_9379 == 0)
    {
        _9379 = NOVALUE;
        goto L13; // [1407] 532
    }
    else{
        _9379 = NOVALUE;
    }
L32: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9382 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9382);
    RefDS(_cmd_16202);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_16202;
    ((int *)_2)[2] = _9382;
    _9383 = MAKE_SEQ(_1);
    _9382 = NOVALUE;
    EPrintf(1, _9381, _9383);
    DeRefDS(_9383);
    _9383 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_16214 == 0)
    {
        goto L34; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16196);
    Ref(_add_help_rid_16209);
    RefDS(_cmds_16198);
    Ref(_parse_options_16197);
    _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
    goto L35; // [1444] 1460
L34: 

    /** 				elsif auto_help then*/
    if (_auto_help_16213 == 0)
    {
        goto L36; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _9282, _5);
L36: 
L35: 

    /** 				local_abort(1)*/
    _31local_abort(1);

    /** 			continue*/
    goto L13; // [1468] 532
L31: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9384 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_16459);
    _2 = (int)SEQ_PTR(_opts_16196);
    if (!IS_ATOM_INT(_9384)){
        _opt_16459 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9384)->dbl));
    }
    else{
        _opt_16459 = (int)*(((s1_ptr)_2)->base + _9384);
    }
    Ref(_opt_16459);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_16462 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9386 = (int)*(((s1_ptr)_2)->base + 4);
    _9387 = find_from(112, _9386, 1);
    _9386 = NOVALUE;
    if (_9387 == 0)
    goto L37; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_16462 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_16204)){
            _9389 = SEQ_PTR(_find_result_16204)->length;
    }
    else {
        _9389 = 1;
    }
    if (_9389 >= 4)
    goto L38; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_16200 = _arg_idx_16200 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_16198)){
            _9392 = SEQ_PTR(_cmds_16198)->length;
    }
    else {
        _9392 = 1;
    }
    if (_arg_idx_16200 > _9392)
    goto L39; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_16203);
    _2 = (int)SEQ_PTR(_cmds_16198);
    _param_16203 = (int)*(((s1_ptr)_2)->base + _arg_idx_16200);
    Ref(_param_16203);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_16203)){
            _9395 = SEQ_PTR(_param_16203)->length;
    }
    else {
        _9395 = 1;
    }
    _9396 = (_9395 == 2);
    _9395 = NOVALUE;
    if (_9396 == 0) {
        goto L3A; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_16203);
    _9398 = (int)*(((s1_ptr)_2)->base + 1);
    _9399 = find_from(_9398, _8610, 1);
    _9398 = NOVALUE;
    if (_9399 == 0)
    {
        _9399 = NOVALUE;
        goto L3A; // [1561] 1579
    }
    else{
        _9399 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_16203);
    _param_16203 = _5;
    goto L3A; // [1570] 1579
L39: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_16203);
    _param_16203 = _5;
L3A: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_16203)){
            _9400 = SEQ_PTR(_param_16203)->length;
    }
    else {
        _9400 = 1;
    }
    _9401 = (_9400 == 0);
    _9400 = NOVALUE;
    if (_9401 == 0) {
        goto L3B; // [1590] 1684
    }
    _9403 = (_validation_16210 == 2);
    if (_9403 != 0) {
        DeRef(_9404);
        _9404 = 1;
        goto L3C; // [1598] 1610
    }
    _9405 = (_validation_16210 == 4);
    _9404 = (_9405 != 0);
L3C: 
    if (_9404 == 0)
    {
        _9404 = NOVALUE;
        goto L3B; // [1611] 1684
    }
    else{
        _9404 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9407 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9407);
    *((int *)(_2+4)) = _9407;
    _9408 = MAKE_SEQ(_1);
    _9407 = NOVALUE;
    EPrintf(1, _9406, _9408);
    DeRefDS(_9408);
    _9408 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_16214 == 0)
    {
        goto L3D; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16196);
    Ref(_add_help_rid_16209);
    RefDS(_cmds_16198);
    Ref(_parse_options_16197);
    _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
    goto L3E; // [1642] 1658
L3D: 

    /** 					elsif auto_help then*/
    if (_auto_help_16213 == 0)
    {
        goto L3F; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _9282, _5);
L3F: 
L3E: 

    /** 					local_abort(1)*/
    _31local_abort(1);
    goto L3B; // [1664] 1684
L38: 

    /** 				param = find_result[4]*/
    DeRef(_param_16203);
    _2 = (int)SEQ_PTR(_find_result_16204);
    _param_16203 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_16203);
    goto L3B; // [1674] 1684
L37: 

    /** 			param = find_result[4]*/
    DeRef(_param_16203);
    _2 = (int)SEQ_PTR(_find_result_16204);
    _param_16203 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_16203);
L3B: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9411 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _9411, 0)){
        _9411 = NOVALUE;
        goto L40; // [1690] 1763
    }
    _9411 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _pos_16501 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_16501))
    _pos_16501 = (long)DBL_PTR(_pos_16501)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_16208);
    _9414 = (int)*(((s1_ptr)_2)->base + _pos_16501);
    if (IS_ATOM_INT(_9414)) {
        _9415 = _9414 + 1;
        if (_9415 > MAXINT){
            _9415 = NewDouble((double)_9415);
        }
    }
    else
    _9415 = binary_op(PLUS, 1, _9414);
    _9414 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_16208);
    _2 = (int)(((s1_ptr)_2)->base + _pos_16501);
    _1 = *(int *)_2;
    *(int *)_2 = _9415;
    if( _1 != _9415 ){
        DeRef(_1);
    }
    _9415 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9416 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9417 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_16208);
    _9418 = (int)*(((s1_ptr)_2)->base + _pos_16501);
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9419 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9417);
    *((int *)(_2+4)) = _9417;
    Ref(_9418);
    *((int *)(_2+8)) = _9418;
    Ref(_param_16203);
    *((int *)(_2+12)) = _param_16203;
    Ref(_9419);
    *((int *)(_2+16)) = _9419;
    _9420 = MAKE_SEQ(_1);
    _9419 = NOVALUE;
    _9418 = NOVALUE;
    _9417 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9420;
    _9421 = MAKE_SEQ(_1);
    _9420 = NOVALUE;
    _1 = (int)SEQ_PTR(_9421);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_9416].addr;
    Ref(*(int *)(_2+4));
    if (_00[_9416].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
    }
    DeRef(_9422);
    _9422 = _1;
    DeRefDS(_9421);
    _9421 = NOVALUE;
    if (binary_op_a(NOTEQ, _9422, 0)){
        DeRef(_9422);
        _9422 = NOVALUE;
        goto L41; // [1749] 1762
    }
    DeRef(_9422);
    _9422 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_16459);
    _opt_16459 = NOVALUE;
    goto L13; // [1759] 532
L41: 
L40: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9424 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _9424, 1)){
        _9424 = NOVALUE;
        goto L42; // [1771] 1788
    }
    _9424 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9426 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16262);
    Ref(_9426);
    _33remove(_parsed_opts_16262, _9426);
    _9426 = NOVALUE;
    goto L43; // [1785] 1965
L42: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9427 = (int)*(((s1_ptr)_2)->base + 4);
    _9428 = find_from(42, _9427, 1);
    _9427 = NOVALUE;
    if (_9428 != 0)
    goto L44; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9430 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16262);
    Ref(_9430);
    _9431 = _33has(_parsed_opts_16262, _9430);
    _9430 = NOVALUE;
    if (IS_ATOM_INT(_9431)) {
        if (_9431 == 0) {
            goto L45; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_9431)->dbl == 0.0) {
            goto L45; // [1814] 1925
        }
    }
    _9433 = (_validation_16210 == 2);
    if (_9433 != 0) {
        DeRef(_9434);
        _9434 = 1;
        goto L46; // [1822] 1834
    }
    _9435 = (_validation_16210 == 4);
    _9434 = (_9435 != 0);
L46: 
    if (_9434 == 0)
    {
        _9434 = NOVALUE;
        goto L45; // [1835] 1925
    }
    else{
        _9434 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9436 = (int)*(((s1_ptr)_2)->base + 4);
    _9437 = find_from(112, _9436, 1);
    _9436 = NOVALUE;
    if (_9437 != 0) {
        goto L47; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_16459);
    _9439 = (int)*(((s1_ptr)_2)->base + 4);
    _9440 = find_from(49, _9439, 1);
    _9439 = NOVALUE;
    if (_9440 == 0)
    {
        _9440 = NOVALUE;
        goto L48; // [1863] 1964
    }
    else{
        _9440 = NOVALUE;
    }
L47: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16204);
    _9442 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9442);
    *((int *)(_2+4)) = _9442;
    _9443 = MAKE_SEQ(_1);
    _9442 = NOVALUE;
    EPrintf(1, _9441, _9443);
    DeRefDS(_9443);
    _9443 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_16214 == 0)
    {
        goto L49; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16196);
    Ref(_add_help_rid_16209);
    RefDS(_cmds_16198);
    Ref(_parse_options_16197);
    _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
    goto L4A; // [1900] 1916
L49: 

    /** 						elsif auto_help then*/
    if (_auto_help_16213 == 0)
    {
        goto L4B; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _9282, _5);
L4B: 
L4A: 

    /** 						local_abort(1)*/
    _31local_abort(1);
    goto L48; // [1922] 1964
L45: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9444 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16262);
    Ref(_9444);
    Ref(_param_16203);
    _33put(_parsed_opts_16262, _9444, _param_16203, 1, _33threshold_size_12989);
    _9444 = NOVALUE;
    goto L48; // [1943] 1964
L44: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9445 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16262);
    Ref(_9445);
    Ref(_param_16203);
    _33put(_parsed_opts_16262, _9445, _param_16203, _map_add_operation_16462, _33threshold_size_12989);
    _9445 = NOVALUE;
L48: 
L43: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9446 = (int)*(((s1_ptr)_2)->base + 4);
    _9447 = find_from(118, _9446, 1);
    _9446 = NOVALUE;
    if (_9447 == 0)
    {
        _9447 = NOVALUE;
        goto L4C; // [1976] 2063
    }
    else{
        _9447 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9448 = (int)*(((s1_ptr)_2)->base + 4);
    _9449 = find_from(118, _9448, 1);
    _9448 = NOVALUE;
    _ver_pos_16548 = _9449 + 1;
    _9449 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9451 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_9451)){
            _9452 = SEQ_PTR(_9451)->length;
    }
    else {
        _9452 = 1;
    }
    _9451 = NOVALUE;
    if (_9452 < _ver_pos_16548)
    goto L4D; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_16459);
    _9455 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_9455);
    _9456 = (int)*(((s1_ptr)_2)->base + _ver_pos_16548);
    _9455 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9456);
    *((int *)(_2+4)) = _9456;
    _9457 = MAKE_SEQ(_1);
    _9456 = NOVALUE;
    EPrintf(1, _9454, _9457);
    DeRefDS(_9457);
    _9457 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4E; // [2029] 2062
L4D: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_9460, _9458, _9459);
    DeRefi(_fmt_inlined_crash_at_2037_16565);
    _fmt_inlined_crash_at_2037_16565 = _9460;
    _9460 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_16566);
    _msg_inlined_crash_at_2040_16566 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_16565, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_16566);

    /** end procedure*/
    goto L4F; // [2056] 2059
L4F: 
    DeRefi(_fmt_inlined_crash_at_2037_16565);
    _fmt_inlined_crash_at_2037_16565 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_16566);
    _msg_inlined_crash_at_2040_16566 = NOVALUE;
L4E: 
L4C: 
    DeRef(_opt_16459);
    _opt_16459 = NOVALUE;

    /** 	end while*/
    goto L13; // [2069] 532
L14: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16196)){
            _9461 = SEQ_PTR(_opts_16196)->length;
    }
    else {
        _9461 = 1;
    }
    {
        int _i_16568;
        _i_16568 = 1;
L50: 
        if (_i_16568 > _9461){
            goto L51; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9462 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9462);
        _9463 = (int)*(((s1_ptr)_2)->base + 4);
        _9462 = NOVALUE;
        _9464 = find_from(109, _9463, 1);
        _9463 = NOVALUE;
        if (_9464 == 0)
        {
            _9464 = NOVALUE;
            goto L52; // [2099] 2285
        }
        else{
            _9464 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9465 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9465);
        _9466 = (int)*(((s1_ptr)_2)->base + 1);
        _9465 = NOVALUE;
        _9467 = IS_ATOM(_9466);
        _9466 = NOVALUE;
        if (_9467 == 0) {
            goto L53; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_16196);
        _9469 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9469);
        _9470 = (int)*(((s1_ptr)_2)->base + 2);
        _9469 = NOVALUE;
        _9471 = IS_ATOM(_9470);
        _9470 = NOVALUE;
        if (_9471 == 0)
        {
            _9471 = NOVALUE;
            goto L53; // [2131] 2206
        }
        else{
            _9471 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9472 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9472);
        _9473 = (int)*(((s1_ptr)_2)->base + 6);
        _9472 = NOVALUE;
        Ref(_parsed_opts_16262);
        Ref(_9473);
        _9474 = _33get(_parsed_opts_16262, _9473, 0);
        _9473 = NOVALUE;
        if (IS_SEQUENCE(_9474)){
                _9475 = SEQ_PTR(_9474)->length;
        }
        else {
            _9475 = 1;
        }
        DeRef(_9474);
        _9474 = NOVALUE;
        if (_9475 != 0)
        goto L54; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _9477); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_16214 == 0)
        {
            goto L55; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_16196);
        Ref(_add_help_rid_16209);
        RefDS(_cmds_16198);
        Ref(_parse_options_16197);
        _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
        goto L56; // [2181] 2197
L55: 

        /** 					elsif auto_help then*/
        if (_auto_help_16213 == 0)
        {
            goto L57; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _9282, _5);
L57: 
L56: 

        /** 					local_abort(1)*/
        _31local_abort(1);
        goto L54; // [2203] 2284
L53: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9478 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9478);
        _9479 = (int)*(((s1_ptr)_2)->base + 6);
        _9478 = NOVALUE;
        Ref(_parsed_opts_16262);
        Ref(_9479);
        _9480 = _33has(_parsed_opts_16262, _9479);
        _9479 = NOVALUE;
        if (IS_ATOM_INT(_9480)) {
            if (_9480 != 0){
                DeRef(_9480);
                _9480 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_9480)->dbl != 0.0){
                DeRef(_9480);
                _9480 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        DeRef(_9480);
        _9480 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_16196);
        _9483 = (int)*(((s1_ptr)_2)->base + _i_16568);
        _2 = (int)SEQ_PTR(_9483);
        _9484 = (int)*(((s1_ptr)_2)->base + 6);
        _9483 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_9484);
        *((int *)(_2+4)) = _9484;
        _9485 = MAKE_SEQ(_1);
        _9484 = NOVALUE;
        EPrintf(1, _9482, _9485);
        DeRefDS(_9485);
        _9485 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_16214 == 0)
        {
            goto L59; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_16196);
        Ref(_add_help_rid_16209);
        RefDS(_cmds_16198);
        Ref(_parse_options_16197);
        _31local_help(_opts_16196, _add_help_rid_16209, _cmds_16198, 1, _parse_options_16197);
        goto L5A; // [2261] 2277
L59: 

        /** 					elsif auto_help then*/
        if (_auto_help_16213 == 0)
        {
            goto L5B; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _9282, _5);
L5B: 
L5A: 

        /** 					local_abort(1)*/
        _31local_abort(1);
L58: 
L54: 
L52: 

        /** 	end for*/
        _i_16568 = _i_16568 + 1;
        goto L50; // [2287] 2084
L51: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_16196);
    DeRef(_parse_options_16197);
    DeRefDS(_cmds_16198);
    DeRef(_cmd_16202);
    DeRef(_param_16203);
    DeRef(_find_result_16204);
    DeRef(_type__16205);
    DeRef(_help_opts_16207);
    DeRef(_call_count_16208);
    DeRef(_add_help_rid_16209);
    DeRef(_9396);
    _9396 = NOVALUE;
    DeRef(_9264);
    _9264 = NOVALUE;
    DeRef(_9403);
    _9403 = NOVALUE;
    DeRef(_9326);
    _9326 = NOVALUE;
    DeRef(_9291);
    _9291 = NOVALUE;
    DeRef(_9322);
    _9322 = NOVALUE;
    DeRef(_9401);
    _9401 = NOVALUE;
    DeRef(_9301);
    _9301 = NOVALUE;
    DeRef(_9380);
    _9380 = NOVALUE;
    DeRef(_9293);
    _9293 = NOVALUE;
    _9451 = NOVALUE;
    DeRef(_9261);
    _9261 = NOVALUE;
    DeRef(_9331);
    _9331 = NOVALUE;
    DeRef(_9338);
    _9338 = NOVALUE;
    DeRef(_9433);
    _9433 = NOVALUE;
    DeRef(_9310);
    _9310 = NOVALUE;
    _9333 = NOVALUE;
    DeRef(_9435);
    _9435 = NOVALUE;
    _9288 = NOVALUE;
    DeRef(_9353);
    _9353 = NOVALUE;
    _9317 = NOVALUE;
    DeRef(_9350);
    _9350 = NOVALUE;
    _9384 = NOVALUE;
    DeRef(_9376);
    _9376 = NOVALUE;
    DeRef(_9378);
    _9378 = NOVALUE;
    _9416 = NOVALUE;
    DeRef(_9355);
    _9355 = NOVALUE;
    _9474 = NOVALUE;
    DeRef(_9303);
    _9303 = NOVALUE;
    DeRef(_9315);
    _9315 = NOVALUE;
    DeRef(_9405);
    _9405 = NOVALUE;
    DeRef(_9431);
    _9431 = NOVALUE;
    return _parsed_opts_16262;
    ;
}


int  __stdcall _31build_commandline(int _cmds_16605)
{
    int _9488 = NOVALUE;
    int _9487 = NOVALUE;
    int _9486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_5549);
    RefDS(_5549);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5549;
    ((int *)_2)[2] = _5549;
    _9486 = MAKE_SEQ(_1);
    RefDS(_cmds_16605);
    RefDS(_3362);
    _9487 = _6quote(_cmds_16605, _9486, 92, _3362);
    _9486 = NOVALUE;
    RefDS(_3362);
    _9488 = _23flatten(_9487, _3362);
    _9487 = NOVALUE;
    DeRefDS(_cmds_16605);
    return _9488;
    ;
}


int  __stdcall _31parse_commandline(int _cmdline_16611)
{
    int _9489 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return keyvalues(cmdline, " ", ":=", "\"'`", " \t\r\n", 0)*/
    RefDS(_cmdline_16611);
    RefDS(_3362);
    RefDS(_5373);
    RefDS(_5374);
    RefDS(_4563);
    _9489 = _6keyvalues(_cmdline_16611, _3362, _5373, _5374, _4563, 0);
    DeRefDS(_cmdline_16611);
    return _9489;
    ;
}



// 0xA4A8A0A5
