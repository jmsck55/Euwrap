// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _34calc_primes(int _approx_limit_12305, int _time_limit_p_12306)
{
    int _result__12307 = NOVALUE;
    int _candidate__12308 = NOVALUE;
    int _pos__12309 = NOVALUE;
    int _time_out__12310 = NOVALUE;
    int _maxp__12311 = NOVALUE;
    int _maxf__12312 = NOVALUE;
    int _maxf_idx_12313 = NOVALUE;
    int _next_trigger_12314 = NOVALUE;
    int _growth_12315 = NOVALUE;
    int _7012 = NOVALUE;
    int _7009 = NOVALUE;
    int _7007 = NOVALUE;
    int _7004 = NOVALUE;
    int _7001 = NOVALUE;
    int _6998 = NOVALUE;
    int _6991 = NOVALUE;
    int _6989 = NOVALUE;
    int _6986 = NOVALUE;
    int _6983 = NOVALUE;
    int _6979 = NOVALUE;
    int _6978 = NOVALUE;
    int _6974 = NOVALUE;
    int _6968 = NOVALUE;
    int _6966 = NOVALUE;
    int _6964 = NOVALUE;
    int _6959 = NOVALUE;
    int _6958 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_approx_limit_12305)) {
        _1 = (long)(DBL_PTR(_approx_limit_12305)->dbl);
        DeRefDS(_approx_limit_12305);
        _approx_limit_12305 = _1;
    }

    /** 	if approx_limit <= list_of_primes[$] then*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _6958 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _6958 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _6959 = (int)*(((s1_ptr)_2)->base + _6958);
    if (binary_op_a(GREATER, _approx_limit_12305, _6959)){
        _6959 = NOVALUE;
        goto L1; // [14] 59
    }
    _6959 = NOVALUE;

    /** 		pos_ = search:binary_search(approx_limit, list_of_primes)*/
    RefDS(_34list_of_primes_12301);
    _pos__12309 = _9binary_search(_approx_limit_12305, _34list_of_primes_12301, 1, 0);
    if (!IS_ATOM_INT(_pos__12309)) {
        _1 = (long)(DBL_PTR(_pos__12309)->dbl);
        DeRefDS(_pos__12309);
        _pos__12309 = _1;
    }

    /** 		if pos_ < 0 then*/
    if (_pos__12309 >= 0)
    goto L2; // [33] 45

    /** 			pos_ = (-pos_)*/
    _pos__12309 = - _pos__12309;
L2: 

    /** 		return list_of_primes[1..pos_]*/
    rhs_slice_target = (object_ptr)&_6964;
    RHS_Slice(_34list_of_primes_12301, 1, _pos__12309);
    DeRef(_time_limit_p_12306);
    DeRef(_result__12307);
    DeRef(_time_out__12310);
    return _6964;
L1: 

    /** 	pos_ = length(list_of_primes)*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _pos__12309 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _pos__12309 = 1;
    }

    /** 	candidate_ = list_of_primes[$]*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _6966 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _6966 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _candidate__12308 = (int)*(((s1_ptr)_2)->base + _6966);
    if (!IS_ATOM_INT(_candidate__12308))
    _candidate__12308 = (long)DBL_PTR(_candidate__12308)->dbl;

    /** 	maxf_ = floor(power(candidate_, 0.5))*/
    temp_d.dbl = (double)_candidate__12308;
    _6968 = Dpower(&temp_d, DBL_PTR(_2369));
    _maxf__12312 = unary_op(FLOOR, _6968);
    DeRefDS(_6968);
    _6968 = NOVALUE;
    if (!IS_ATOM_INT(_maxf__12312)) {
        _1 = (long)(DBL_PTR(_maxf__12312)->dbl);
        DeRefDS(_maxf__12312);
        _maxf__12312 = _1;
    }

    /** 	maxf_idx = search:binary_search(maxf_, list_of_primes)*/
    RefDS(_34list_of_primes_12301);
    _maxf_idx_12313 = _9binary_search(_maxf__12312, _34list_of_primes_12301, 1, 0);
    if (!IS_ATOM_INT(_maxf_idx_12313)) {
        _1 = (long)(DBL_PTR(_maxf_idx_12313)->dbl);
        DeRefDS(_maxf_idx_12313);
        _maxf_idx_12313 = _1;
    }

    /** 	if maxf_idx < 0 then*/
    if (_maxf_idx_12313 >= 0)
    goto L3; // [103] 123

    /** 		maxf_idx = (-maxf_idx)*/
    _maxf_idx_12313 = - _maxf_idx_12313;

    /** 		maxf_ = list_of_primes[maxf_idx]*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _maxf__12312 = (int)*(((s1_ptr)_2)->base + _maxf_idx_12313);
    if (!IS_ATOM_INT(_maxf__12312))
    _maxf__12312 = (long)DBL_PTR(_maxf__12312)->dbl;
L3: 

    /** 	next_trigger = list_of_primes[maxf_idx+1]*/
    _6974 = _maxf_idx_12313 + 1;
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _next_trigger_12314 = (int)*(((s1_ptr)_2)->base + _6974);
    if (!IS_ATOM_INT(_next_trigger_12314))
    _next_trigger_12314 = (long)DBL_PTR(_next_trigger_12314)->dbl;

    /** 	next_trigger *= next_trigger*/
    _next_trigger_12314 = _next_trigger_12314 * _next_trigger_12314;

    /** 	growth = floor(approx_limit  / 3.5) - length(list_of_primes)*/
    _2 = binary_op(DIVIDE, _approx_limit_12305, _6977);
    _6978 = unary_op(FLOOR, _2);
    DeRef(_2);
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _6979 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _6979 = 1;
    }
    if (IS_ATOM_INT(_6978)) {
        _growth_12315 = _6978 - _6979;
    }
    else {
        _growth_12315 = NewDouble(DBL_PTR(_6978)->dbl - (double)_6979);
    }
    DeRef(_6978);
    _6978 = NOVALUE;
    _6979 = NOVALUE;
    if (!IS_ATOM_INT(_growth_12315)) {
        _1 = (long)(DBL_PTR(_growth_12315)->dbl);
        DeRefDS(_growth_12315);
        _growth_12315 = _1;
    }

    /** 	if growth <= 0 then*/
    if (_growth_12315 > 0)
    goto L4; // [162] 174

    /** 		growth = length(list_of_primes)*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _growth_12315 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _growth_12315 = 1;
    }
L4: 

    /** 	result_ = list_of_primes & repeat(0, growth)*/
    _6983 = Repeat(0, _growth_12315);
    Concat((object_ptr)&_result__12307, _34list_of_primes_12301, _6983);
    DeRefDS(_6983);
    _6983 = NOVALUE;

    /** 	if time_limit_p < 0 then*/
    if (binary_op_a(GREATEREQ, _time_limit_p_12306, 0)){
        goto L5; // [188] 203
    }

    /** 		time_out_ = time() + 100_000_000*/
    DeRef(_6986);
    _6986 = NewDouble(current_time());
    DeRef(_time_out__12310);
    _time_out__12310 = NewDouble(DBL_PTR(_6986)->dbl + (double)100000000);
    DeRefDS(_6986);
    _6986 = NOVALUE;
    goto L6; // [200] 212
L5: 

    /** 		time_out_ = time() + time_limit_p*/
    DeRef(_6989);
    _6989 = NewDouble(current_time());
    DeRef(_time_out__12310);
    if (IS_ATOM_INT(_time_limit_p_12306)) {
        _time_out__12310 = NewDouble(DBL_PTR(_6989)->dbl + (double)_time_limit_p_12306);
    }
    else
    _time_out__12310 = NewDouble(DBL_PTR(_6989)->dbl + DBL_PTR(_time_limit_p_12306)->dbl);
    DeRefDS(_6989);
    _6989 = NOVALUE;
L6: 

    /** 	while time_out_ >= time()  label "MW" do*/
L7: 
    DeRef(_6991);
    _6991 = NewDouble(current_time());
    if (binary_op_a(LESS, _time_out__12310, _6991)){
        DeRefDS(_6991);
        _6991 = NOVALUE;
        goto L8; // [221] 370
    }
    DeRef(_6991);
    _6991 = NOVALUE;

    /** 		task_yield()*/

    /** 		candidate_ += 2*/
    _candidate__12308 = _candidate__12308 + 2;

    /** 		if candidate_ >= next_trigger then*/
    if (_candidate__12308 < _next_trigger_12314)
    goto L9; // [236] 271

    /** 			maxf_idx += 1*/
    _maxf_idx_12313 = _maxf_idx_12313 + 1;

    /** 			maxf_ = result_[maxf_idx]*/
    _2 = (int)SEQ_PTR(_result__12307);
    _maxf__12312 = (int)*(((s1_ptr)_2)->base + _maxf_idx_12313);
    if (!IS_ATOM_INT(_maxf__12312))
    _maxf__12312 = (long)DBL_PTR(_maxf__12312)->dbl;

    /** 			next_trigger = result_[maxf_idx+1]*/
    _6998 = _maxf_idx_12313 + 1;
    _2 = (int)SEQ_PTR(_result__12307);
    _next_trigger_12314 = (int)*(((s1_ptr)_2)->base + _6998);
    if (!IS_ATOM_INT(_next_trigger_12314))
    _next_trigger_12314 = (long)DBL_PTR(_next_trigger_12314)->dbl;

    /** 			next_trigger *= next_trigger*/
    _next_trigger_12314 = _next_trigger_12314 * _next_trigger_12314;
L9: 

    /** 		for i = 2 to pos_ do*/
    _7001 = _pos__12309;
    {
        int _i_12368;
        _i_12368 = 2;
LA: 
        if (_i_12368 > _7001){
            goto LB; // [276] 322
        }

        /** 			maxp_ = result_[i]*/
        _2 = (int)SEQ_PTR(_result__12307);
        _maxp__12311 = (int)*(((s1_ptr)_2)->base + _i_12368);
        if (!IS_ATOM_INT(_maxp__12311))
        _maxp__12311 = (long)DBL_PTR(_maxp__12311)->dbl;

        /** 			if maxp_ > maxf_ then*/
        if (_maxp__12311 <= _maxf__12312)
        goto LC; // [291] 300

        /** 				exit*/
        goto LB; // [297] 322
LC: 

        /** 			if remainder(candidate_, maxp_) = 0 then*/
        _7004 = (_candidate__12308 % _maxp__12311);
        if (_7004 != 0)
        goto LD; // [306] 315

        /** 				continue "MW"*/
        goto L7; // [312] 217
LD: 

        /** 		end for*/
        _i_12368 = _i_12368 + 1;
        goto LA; // [317] 283
LB: 
        ;
    }

    /** 		pos_ += 1*/
    _pos__12309 = _pos__12309 + 1;

    /** 		if pos_ >= length(result_) then*/
    if (IS_SEQUENCE(_result__12307)){
            _7007 = SEQ_PTR(_result__12307)->length;
    }
    else {
        _7007 = 1;
    }
    if (_pos__12309 < _7007)
    goto LE; // [333] 348

    /** 			result_ &= repeat(0, 1000)*/
    _7009 = Repeat(0, 1000);
    Concat((object_ptr)&_result__12307, _result__12307, _7009);
    DeRefDS(_7009);
    _7009 = NOVALUE;
LE: 

    /** 		result_[pos_] = candidate_*/
    _2 = (int)SEQ_PTR(_result__12307);
    _2 = (int)(((s1_ptr)_2)->base + _pos__12309);
    _1 = *(int *)_2;
    *(int *)_2 = _candidate__12308;
    DeRef(_1);

    /** 		if candidate_ >= approx_limit then*/
    if (_candidate__12308 < _approx_limit_12305)
    goto L7; // [356] 217

    /** 			exit*/
    goto L8; // [362] 370

    /** 	end while*/
    goto L7; // [367] 217
L8: 

    /** 	return result_[1..pos_]*/
    rhs_slice_target = (object_ptr)&_7012;
    RHS_Slice(_result__12307, 1, _pos__12309);
    DeRef(_time_limit_p_12306);
    DeRefDS(_result__12307);
    DeRef(_time_out__12310);
    DeRef(_6964);
    _6964 = NOVALUE;
    DeRef(_6974);
    _6974 = NOVALUE;
    DeRef(_6998);
    _6998 = NOVALUE;
    DeRef(_7004);
    _7004 = NOVALUE;
    return _7012;
    ;
}


int  __stdcall _34next_prime(int _n_12387, int _fail_signal_p_12388, int _time_out_p_12389)
{
    int _i_12390 = NOVALUE;
    int _7032 = NOVALUE;
    int _7026 = NOVALUE;
    int _7025 = NOVALUE;
    int _7024 = NOVALUE;
    int _7023 = NOVALUE;
    int _7022 = NOVALUE;
    int _7019 = NOVALUE;
    int _7018 = NOVALUE;
    int _7015 = NOVALUE;
    int _7014 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_12387)) {
        _1 = (long)(DBL_PTR(_n_12387)->dbl);
        DeRefDS(_n_12387);
        _n_12387 = _1;
    }

    /** 	if n < 0 then*/
    if (_n_12387 >= 0)
    goto L1; // [5] 16

    /** 		return fail_signal_p*/
    DeRef(_time_out_p_12389);
    return _fail_signal_p_12388;
L1: 

    /** 	if list_of_primes[$] < n then*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _7014 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _7014 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7015 = (int)*(((s1_ptr)_2)->base + _7014);
    if (binary_op_a(GREATEREQ, _7015, _n_12387)){
        _7015 = NOVALUE;
        goto L2; // [27] 41
    }
    _7015 = NOVALUE;

    /** 		list_of_primes = calc_primes(n,time_out_p)*/
    Ref(_time_out_p_12389);
    _0 = _34calc_primes(_n_12387, _time_out_p_12389);
    DeRefDS(_34list_of_primes_12301);
    _34list_of_primes_12301 = _0;
L2: 

    /** 	if n > list_of_primes[$] then*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _7018 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _7018 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7019 = (int)*(((s1_ptr)_2)->base + _7018);
    if (binary_op_a(LESSEQ, _n_12387, _7019)){
        _7019 = NOVALUE;
        goto L3; // [52] 63
    }
    _7019 = NOVALUE;

    /** 		return fail_signal_p*/
    DeRef(_time_out_p_12389);
    return _fail_signal_p_12388;
L3: 

    /** 	if n < 1009 and 1009 <= list_of_primes[$] then*/
    _7022 = (_n_12387 < 1009);
    if (_7022 == 0) {
        goto L4; // [69] 106
    }
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _7024 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _7024 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7025 = (int)*(((s1_ptr)_2)->base + _7024);
    if (IS_ATOM_INT(_7025)) {
        _7026 = (1009 <= _7025);
    }
    else {
        _7026 = binary_op(LESSEQ, 1009, _7025);
    }
    _7025 = NOVALUE;
    if (_7026 == 0) {
        DeRef(_7026);
        _7026 = NOVALUE;
        goto L4; // [87] 106
    }
    else {
        if (!IS_ATOM_INT(_7026) && DBL_PTR(_7026)->dbl == 0.0){
            DeRef(_7026);
            _7026 = NOVALUE;
            goto L4; // [87] 106
        }
        DeRef(_7026);
        _7026 = NOVALUE;
    }
    DeRef(_7026);
    _7026 = NOVALUE;

    /** 		i = search:binary_search(n, list_of_primes, ,169)*/
    RefDS(_34list_of_primes_12301);
    _i_12390 = _9binary_search(_n_12387, _34list_of_primes_12301, 1, 169);
    if (!IS_ATOM_INT(_i_12390)) {
        _1 = (long)(DBL_PTR(_i_12390)->dbl);
        DeRefDS(_i_12390);
        _i_12390 = _1;
    }
    goto L5; // [103] 120
L4: 

    /** 		i = search:binary_search(n, list_of_primes)*/
    RefDS(_34list_of_primes_12301);
    _i_12390 = _9binary_search(_n_12387, _34list_of_primes_12301, 1, 0);
    if (!IS_ATOM_INT(_i_12390)) {
        _1 = (long)(DBL_PTR(_i_12390)->dbl);
        DeRefDS(_i_12390);
        _i_12390 = _1;
    }
L5: 

    /** 	if i < 0 then*/
    if (_i_12390 >= 0)
    goto L6; // [124] 136

    /** 		i = (-i)*/
    _i_12390 = - _i_12390;
L6: 

    /** 	return list_of_primes[i]*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7032 = (int)*(((s1_ptr)_2)->base + _i_12390);
    Ref(_7032);
    DeRef(_fail_signal_p_12388);
    DeRef(_time_out_p_12389);
    DeRef(_7022);
    _7022 = NOVALUE;
    return _7032;
    ;
}


int  __stdcall _34prime_list(int _top_prime_p_12419)
{
    int _index__12420 = NOVALUE;
    int _7044 = NOVALUE;
    int _7041 = NOVALUE;
    int _7035 = NOVALUE;
    int _7034 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_top_prime_p_12419)) {
        _1 = (long)(DBL_PTR(_top_prime_p_12419)->dbl);
        DeRefDS(_top_prime_p_12419);
        _top_prime_p_12419 = _1;
    }

    /** 	if top_prime_p <= 0 then*/
    if (_top_prime_p_12419 > 0)
    goto L1; // [5] 18

    /** 		return list_of_primes*/
    RefDS(_34list_of_primes_12301);
    return _34list_of_primes_12301;
L1: 

    /** 	if list_of_primes[$] < top_prime_p then*/
    if (IS_SEQUENCE(_34list_of_primes_12301)){
            _7034 = SEQ_PTR(_34list_of_primes_12301)->length;
    }
    else {
        _7034 = 1;
    }
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7035 = (int)*(((s1_ptr)_2)->base + _7034);
    if (binary_op_a(GREATEREQ, _7035, _top_prime_p_12419)){
        _7035 = NOVALUE;
        goto L2; // [29] 43
    }
    _7035 = NOVALUE;

    /** 		list_of_primes = calc_primes(top_prime_p, 5)*/
    _0 = _34calc_primes(_top_prime_p_12419, 5);
    DeRefDS(_34list_of_primes_12301);
    _34list_of_primes_12301 = _0;
L2: 

    /** 	index_ = search:binary_search(top_prime_p, list_of_primes)*/
    RefDS(_34list_of_primes_12301);
    _index__12420 = _9binary_search(_top_prime_p_12419, _34list_of_primes_12301, 1, 0);
    if (!IS_ATOM_INT(_index__12420)) {
        _1 = (long)(DBL_PTR(_index__12420)->dbl);
        DeRefDS(_index__12420);
        _index__12420 = _1;
    }

    /** 	if index_ < 0 then*/
    if (_index__12420 >= 0)
    goto L3; // [58] 70

    /** 		index_ = - index_*/
    _index__12420 = - _index__12420;
L3: 

    /** 	if list_of_primes[index_] > top_prime_p then*/
    _2 = (int)SEQ_PTR(_34list_of_primes_12301);
    _7041 = (int)*(((s1_ptr)_2)->base + _index__12420);
    if (binary_op_a(LESSEQ, _7041, _top_prime_p_12419)){
        _7041 = NOVALUE;
        goto L4; // [78] 89
    }
    _7041 = NOVALUE;

    /** 		index_ -= 1*/
    _index__12420 = _index__12420 - 1;
L4: 

    /** 	return list_of_primes[1 .. index_]*/
    rhs_slice_target = (object_ptr)&_7044;
    RHS_Slice(_34list_of_primes_12301, 1, _index__12420);
    return _7044;
    ;
}



// 0xEECF565D
