#include "include/euphoria.h"
#include "main-.h"

int _5;
int _18;
int _21;
int _22;
int _23;
int _24;
int _25;
int _26;
int _27;
int _60;
int _69;
int _78;
int _82;
int _84;
int _86;
int _88;
int _89;
int _94;
int _95;
int _96;
int _97;
int _98;
int _99;
int _100;
int _101;
int _102;
int _103;
int _104;
int _105;
int _106;
int _107;
int _108;
int _109;
int _110;
int _111;
int _112;
int _113;
int _114;
int _115;
int _116;
int _117;
int _118;
int _119;
int _120;
int _121;
int _122;
int _123;
int _124;
int _125;
int _126;
int _127;
int _128;
int _129;
int _130;
int _131;
int _132;
int _133;
int _134;
int _135;
int _136;
int _137;
int _138;
int _140;
int _141;
int _142;
int _143;
int _144;
int _145;
int _146;
int _147;
int _148;
int _149;
int _150;
int _151;
int _152;
int _153;
int _154;
int _155;
int _156;
int _157;
int _158;
int _159;
int _160;
int _161;
int _162;
int _163;
int _164;
int _165;
int _166;
int _167;
int _168;
int _169;
int _170;
int _171;
int _172;
int _173;
int _174;
int _175;
int _176;
int _177;
int _178;
int _179;
int _180;
int _181;
int _182;
int _183;
int _184;
int _185;
int _186;
int _187;
int _188;
int _189;
int _190;
int _191;
int _192;
int _193;
int _194;
int _195;
int _196;
int _197;
int _198;
int _199;
int _200;
int _201;
int _202;
int _203;
int _204;
int _205;
int _206;
int _207;
int _208;
int _209;
int _210;
int _211;
int _212;
int _213;
int _214;
int _215;
int _216;
int _217;
int _218;
int _219;
int _220;
int _221;
int _222;
int _223;
int _224;
int _225;
int _226;
int _227;
int _258;
int _282;
int _285;
int _289;
int _292;
int _298;
int _300;
int _301;
int _302;
int _303;
int _304;
int _305;
int _307;
int _310;
int _311;
int _313;
int _315;
int _318;
int _321;
int _324;
int _326;
int _331;
int _337;
int _342;
int _476;
int _658;
int _661;
int _662;
int _663;
int _671;
int _679;
int _783;
int _802;
int _803;
int _804;
int _811;
int _812;
int _910;
int _911;
int _919;
int _921;
int _929;
int _937;
int _943;
int _945;
int _947;
int _949;
int _951;
int _971;
int _1032;
int _1034;
int _1037;
int _1040;
int _1043;
int _1045;
int _1067;
int _1068;
int _1070;
int _1091;
int _1092;
int _1093;
int _1117;
int _1122;
int _1124;
int _1128;
int _1163;
int _1256;
int _1297;
int _1303;
int _1309;
int _1325;
int _1326;
int _1354;
int _1372;
int _1382;
int _1383;
int _1385;
int _1400;
int _1401;
int _1637;
int _1639;
int _1644;
int _1645;
int _1646;
int _1650;
int _1660;
int _1661;
int _1662;
int _1667;
int _1671;
int _1698;
int _1699;
int _1763;
int _1780;
int _1785;
int _1833;
int _1834;
int _1835;
int _1836;
int _1837;
int _1838;
int _1839;
int _1840;
int _1841;
int _1842;
int _1843;
int _1844;
int _1846;
int _1847;
int _1848;
int _1849;
int _1850;
int _1851;
int _1852;
int _1853;
int _1854;
int _1855;
int _1856;
int _1858;
int _1859;
int _1860;
int _1861;
int _1862;
int _1863;
int _1864;
int _1866;
int _1867;
int _1868;
int _1869;
int _1870;
int _1871;
int _1872;
int _1874;
int _1875;
int _1974;
int _1994;
int _2073;
int _2094;
int _2108;
int _2109;
int _2228;
int _2236;
int _2266;
int _2267;
int _2268;
int _2269;
int _2270;
int _2271;
int _2272;
int _2273;
int _2274;
int _2275;
int _2276;
int _2277;
int _2278;
int _2279;
int _2280;
int _2281;
int _2282;
int _2283;
int _2284;
int _2285;
int _2288;
int _2369;
int _2402;
int _2446;
int _2482;
int _2533;
int _2535;
int _2576;
int _2582;
int _2680;
int _2743;
int _2827;
int _2830;
int _2927;
int _2928;
int _2955;
int _2956;
int _2963;
int _2984;
int _3014;
int _3024;
int _3097;
int _3098;
int _3099;
int _3100;
int _3107;
int _3108;
int _3115;
int _3116;
int _3117;
int _3124;
int _3125;
int _3132;
int _3133;
int _3140;
int _3141;
int _3148;
int _3149;
int _3150;
int _3200;
int _3201;
int _3202;
int _3269;
int _3275;
int _3337;
int _3362;
int _3586;
int _3649;
int _3710;
int _3776;
int _3778;
int _3779;
int _3780;
int _3781;
int _3782;
int _3783;
int _3784;
int _3785;
int _3788;
int _3791;
int _3794;
int _3797;
int _3800;
int _3803;
int _3806;
int _3807;
int _3808;
int _3809;
int _3810;
int _3811;
int _3812;
int _3819;
int _3845;
int _3850;
int _4098;
int _4101;
int _4103;
int _4140;
int _4202;
int _4469;
int _4472;
int _4475;
int _4478;
int _4483;
int _4486;
int _4489;
int _4490;
int _4491;
int _4492;
int _4493;
int _4496;
int _4501;
int _4559;
int _4560;
int _4561;
int _4562;
int _4563;
int _4631;
int _4644;
int _4647;
int _4650;
int _4653;
int _4654;
int _4656;
int _4657;
int _4670;
int _4738;
int _4763;
int _4764;
int _4765;
int _4766;
int _4767;
int _4768;
int _4777;
int _4807;
int _4820;
int _4827;
int _4919;
int _4920;
int _4985;
int _5009;
int _5010;
int _5206;
int _5207;
int _5217;
int _5223;
int _5231;
int _5261;
int _5271;
int _5272;
int _5293;
int _5304;
int _5306;
int _5309;
int _5372;
int _5373;
int _5374;
int _5388;
int _5389;
int _5506;
int _5549;
int _5733;
int _5734;
int _5902;
int _5932;
int _5939;
int _6016;
int _6027;
int _6028;
int _6032;
int _6136;
int _6193;
int _6194;
int _6195;
int _6198;
int _6201;
int _6204;
int _6207;
int _6210;
int _6213;
int _6247;
int _6250;
int _6253;
int _6276;
int _6293;
int _6313;
int _6324;
int _6332;
int _6353;
int _6389;
int _6390;
int _6393;
int _6394;
int _6395;
int _6396;
int _6397;
int _6398;
int _6399;
int _6400;
int _6401;
int _6402;
int _6403;
int _6490;
int _6605;
int _6623;
int _6624;
int _6625;
int _6629;
int _6717;
int _6725;
int _6768;
int _6769;
int _6770;
int _6771;
int _6772;
int _6773;
int _6774;
int _6775;
int _6776;
int _6777;
int _6778;
int _6779;
int _6780;
int _6781;
int _6782;
int _6783;
int _6784;
int _6785;
int _6786;
int _6787;
int _6788;
int _6789;
int _6790;
int _6791;
int _6792;
int _6793;
int _6794;
int _6795;
int _6796;
int _6797;
int _6798;
int _6799;
int _6800;
int _6801;
int _6802;
int _6803;
int _6804;
int _6805;
int _6806;
int _6808;
int _6809;
int _6810;
int _6811;
int _6812;
int _6813;
int _6814;
int _6815;
int _6816;
int _6821;
int _6822;
int _6823;
int _6836;
int _6839;
int _6844;
int _6853;
int _6857;
int _6879;
int _6883;
int _6884;
int _6885;
int _6886;
int _6888;
int _6889;
int _6957;
int _6977;
int _6993;
int _7087;
int _7088;
int _7312;
int _7320;
int _7321;
int _7322;
int _7323;
int _7463;
int _7464;
int _7542;
int _7543;
int _7572;
int _7575;
int _7638;
int _7639;
int _7897;
int _7922;
int _7943;
int _7944;
int _7981;
int _7983;
int _7991;
int _7992;
int _8008;
int _8024;
int _8124;
int _8318;
int _8319;
int _8320;
int _8321;
int _8322;
int _8323;
int _8324;
int _8325;
int _8326;
int _8327;
int _8328;
int _8329;
int _8330;
int _8331;
int _8332;
int _8333;
int _8334;
int _8335;
int _8336;
int _8337;
int _8338;
int _8339;
int _8340;
int _8341;
int _8342;
int _8343;
int _8344;
int _8345;
int _8346;
int _8347;
int _8348;
int _8349;
int _8350;
int _8351;
int _8352;
int _8353;
int _8354;
int _8355;
int _8356;
int _8357;
int _8358;
int _8359;
int _8360;
int _8361;
int _8362;
int _8363;
int _8364;
int _8365;
int _8366;
int _8367;
int _8368;
int _8369;
int _8370;
int _8371;
int _8372;
int _8373;
int _8374;
int _8375;
int _8376;
int _8377;
int _8378;
int _8379;
int _8380;
int _8381;
int _8382;
int _8383;
int _8384;
int _8385;
int _8386;
int _8387;
int _8388;
int _8389;
int _8390;
int _8391;
int _8392;
int _8393;
int _8394;
int _8395;
int _8396;
int _8397;
int _8398;
int _8399;
int _8400;
int _8401;
int _8402;
int _8403;
int _8404;
int _8405;
int _8406;
int _8407;
int _8408;
int _8409;
int _8410;
int _8411;
int _8412;
int _8413;
int _8414;
int _8415;
int _8416;
int _8417;
int _8418;
int _8419;
int _8420;
int _8421;
int _8422;
int _8423;
int _8424;
int _8425;
int _8426;
int _8427;
int _8428;
int _8429;
int _8430;
int _8431;
int _8432;
int _8433;
int _8434;
int _8435;
int _8436;
int _8437;
int _8438;
int _8439;
int _8440;
int _8441;
int _8442;
int _8443;
int _8444;
int _8445;
int _8446;
int _8447;
int _8448;
int _8449;
int _8450;
int _8451;
int _8452;
int _8458;
int _8468;
int _8479;
int _8586;
int _8603;
int _8605;
int _8610;
int _8613;
int _8615;
int _8620;
int _8636;
int _8638;
int _8643;
int _8646;
int _8649;
int _8652;
int _8654;
int _8657;
int _8662;
int _8667;
int _8673;
int _8678;
int _8683;
int _8688;
int _8693;
int _8698;
int _8700;
int _8705;
int _8707;
int _8711;
int _8713;
int _8722;
int _8731;
int _8762;
int _8771;
int _8781;
int _8786;
int _8791;
int _8796;
int _8801;
int _8833;
int _8844;
int _8850;
int _8854;
int _8858;
int _8863;
int _8918;
int _8919;
int _8924;
int _8994;
int _9044;
int _9059;
int _9076;
int _9085;
int _9120;
int _9126;
int _9156;
int _9157;
int _9158;
int _9159;
int _9160;
int _9161;
int _9162;
int _9166;
int _9167;
int _9168;
int _9169;
int _9170;
int _9193;
int _9202;
int _9210;
int _9211;
int _9220;
int _9221;
int _9278;
int _9282;
int _9381;
int _9406;
int _9441;
int _9454;
int _9458;
int _9459;
int _9477;
int _9482;
int _9506;
int _9507;
int _9508;
int _9509;
int _9510;
int _9514;
int _9530;
int _9531;
int _9541;
int _9565;
int _9566;
int _9649;
int _9650;
int _9653;
int _9656;
int _9660;
int _9666;
int _9667;
int _9669;
int _9670;
int _9676;
int _9677;
int _9681;
int _9686;
int _9687;
int _9697;
int _9700;
int _9703;
int _9715;
int _9720;
int _9723;
int _9728;
int _9729;
int _9734;
int _9745;
int _9748;
int _9757;
int _9761;
int _9762;
int _9763;
int _9766;
int _9767;
int _9768;
int _9770;
int _9774;
int _9775;
int _9779;
int _9781;
int _9788;
int _9791;
int _9797;
int _9803;
int _9806;
int _9810;
int _9952;
int _9953;
int _9967;
int _9970;
int _9995;
int _10218;
int _10219;
int _10223;
int _10249;
int _10250;
int _10253;
int _10318;
int _10367;
int _10375;
int _10427;
int _10441;
int _10450;
int _10471;
int _10483;
int _10484;
int _10525;
int _10557;
int _10594;
int _10595;
int _10823;
int _11084;
int _11085;
int _11086;
int _11087;
int _11088;
int _11089;
int _11090;
int _11091;
int _11092;
int _11093;
int _11094;
int _11095;
int _11096;
int _11097;
int _11098;
int _11099;
int _11100;
int _11101;
int _11102;
int _11103;
int _11104;
int _11105;
int _11106;
int _11107;
int _11108;
int _11109;
int _11110;
int _11111;
int _11112;
int _11113;
int _11114;
int _11115;
int _11116;
int _11117;
int _11118;
int _11119;
int _11120;
int _11121;
int _11122;
int _11123;
int _11124;
int _11125;
int _11126;
int _11127;
int _11128;
int _11129;
int _11130;
int _11131;
int _11132;
int _11133;
int _11134;
int _11135;
int _11136;
int _11137;
int _11138;
int _11139;
int _11140;
int _11141;
int _11142;
int _11143;
int _11144;
int _11145;
int _11146;
int _11147;
int _11148;
int _11149;
int _11150;
int _11151;
int _11152;
int _11153;
int _11154;
int _11155;
int _11156;
int _11157;
int _11158;
int _11159;
int _11160;
int _11161;
int _11162;
int _11163;
int _11164;
int _11165;
int _11166;
int _11167;
int _11168;
int _11169;
int _11170;
int _11171;
int _11172;
int _11173;
int _11174;
int _11175;
int _11176;
int _11177;
int _11178;
int _11179;
int _11180;
int _11181;
int _11182;
int _11183;
int _11184;
int _11185;
int _11186;
int _11187;
int _11188;
int _11189;
int _11190;
int _11191;
int _11192;
int _11193;
int _11194;
int _11195;
int _11196;
int _11197;
int _11198;
int _11199;
int _11200;
int _11201;
int _11202;
int _11203;
int _11204;
int _11205;
int _11206;
int _11207;
int _11208;
int _11209;
int _11210;
int _11211;
int _11212;
int _11213;
int _11214;
int _11215;
int _11216;
int _11217;
int _11218;
int _11219;
int _11220;
int _11221;
int _11222;
int _11223;
int _11224;
int _11225;
int _11226;
int _11227;
int _11228;
int _11229;
int _11230;
int _11231;
int _11232;
int _11233;
int _11234;
int _11235;
int _11236;
int _11237;
int _11238;
int _11239;
int _11240;
int _11241;
int _11242;
int _11243;
int _11244;
int _11245;
int _11246;
int _11247;
int _11248;
int _11249;
int _11250;
int _11251;
int _11252;
int _11253;
int _11254;
int _11255;
int _11256;
int _11257;
int _11258;
int _11259;
int _11260;
int _11261;
int _11262;
int _11263;
int _11264;
int _11265;
int _11266;
int _11267;
int _11268;
int _11269;
int _11270;
int _11271;
int _11272;
int _11273;
int _11274;
int _11275;
int _11276;
int _11277;
int _11278;
int _11279;
int _11280;
int _11281;
int _11282;
int _11283;
int _11284;
int _11285;
int _11286;
int _11287;
int _11288;
int _11289;
int _11290;
int _11291;
int _11299;
int _11300;
int _11301;
int _11302;
int _11303;
int _11304;
int _11305;
int _11306;
int _11307;
int _11308;
int _11309;
int _11310;
int _11311;
int _11312;
int _11313;
int _11314;
int _11315;
int _11316;
int _11317;
int _11318;
int _11319;
int _11320;
int _11321;
int _11322;
int _11323;
int _11324;
int _11325;
int _11326;
int _11327;
int _11328;
int _11329;
int _11330;
int _11331;
int _11332;
int _11333;
int _11334;
int _11335;
int _11336;
int _11337;
int _11338;
int _11339;
int _11340;
int _11341;
int _11342;
int _11343;
int _11344;
int _11345;
int _11346;
int _11347;
int _11348;
int _11349;
int _11350;
int _11351;
int _11352;
int _11353;
int _11354;
int _11355;
int _11356;
int _11357;
int _11358;
int _11359;
int _11360;
int _11361;
int _11362;
int _11363;
int _11364;
int _11365;
int _11366;
int _11367;
int _11368;
int _11369;
int _11370;
int _11371;
int _11372;
int _11373;
int _11374;
int _11375;
int _11376;
int _11377;
int _11378;
int _11379;
int _11380;
int _11381;
int _11382;
int _11383;
int _11384;
int _11385;
int _11386;
int _11387;
int _11388;
int _11389;
int _11390;
int _11391;
int _11392;
int _11393;
int _11394;
int _11395;
int _11396;
int _11397;
int _11398;
int _11399;
int _11400;
int _11401;
int _11402;
int _11403;
int _11404;
int _11405;
int _11406;
int _11407;
int _11408;
int _11409;
int _11410;
int _11411;
int _11412;
int _11413;
int _11414;
int _11415;
int _11416;
int _11417;
int _11418;
int _11419;
int _11420;
int _11421;
int _11422;
int _11423;
int _11424;
int _11425;
int _11426;
int _11427;
int _11428;
int _11429;
int _11430;
int _11431;
int _11432;
int _11433;
int _11434;
int _11435;
int _11436;
int _11437;
int _11438;
int _11439;
int _11440;
int _11441;
int _11442;
int _11443;
int _11444;
int _11445;
int _11446;
int _11447;
int _11448;
int _11449;
int _11450;
int _11451;
int _11452;
int _11453;
int _11454;
int _11455;
int _11456;
int _11457;
int _11458;
int _11459;
int _11460;
int _11461;
int _11462;
int _11463;
int _11464;
int _11465;
int _11466;
int _11467;
int _11468;
int _11469;
int _11470;
int _11471;
int _11472;
int _11473;
int _11474;
int _11475;
int _11476;
int _11477;
int _11478;
int _11479;
int _11480;
int _11481;
int _11482;
int _11483;
int _11484;
int _11485;
int _11486;
int _11487;
int _11488;
int _11489;
int _11490;
int _11491;
int _11492;
int _11493;
int _11494;
int _11495;
int _11496;
int _11497;
int _11498;
int _11499;
int _11500;
int _11501;
int _11502;
int _11503;
int _11504;
int _11505;
int _11506;
int _11508;
int _11509;
int _11510;
int _11511;
int _11512;
int _11513;
int _11514;
int _11515;
int _11516;
int _11517;
int _11518;
int _11519;
int _11520;
int _11521;
int _11522;
int _11523;
int _11524;
int _11525;
int _11526;
int _11528;
int _11567;
int _11643;
int _11654;
int _11656;
int _11658;
int _11661;
int _11664;
int _11667;
int _11670;
int _11671;
int _11672;
int _11693;
int _11696;
int _11706;
int _11708;
int _11709;
int _11710;
int _11715;
int _11719;
int _11741;
int _11782;
int _11789;
int _11791;
int _11796;
int _11826;
int _11828;
int _11831;
int _11834;
int _11837;
int _11840;
int _11843;
int _11845;
int _11848;
int _11851;
int _11854;
int _11855;
int _11856;
int _11857;
int _11858;
int _11859;
int _11860;
int _11861;
int _11862;
int _11863;
int _11909;
int _11970;
int _11971;
int _11977;
int _11979;
int _11981;
int _11983;
int _11985;
int _11987;
int _11989;
int _11991;
int _11993;
int _11995;
int _11997;
int _11999;
int _12001;
int _12003;
int _12005;
int _12007;
int _12009;
int _12011;
int _12013;
int _12015;
int _12017;
int _12019;
int _12021;
int _12023;
int _12025;
int _12027;
int _12029;
int _12031;
int _12033;
int _12052;
int _12054;
int _12056;
int _12058;
int _12060;
int _12063;
int _12065;
int _12067;
int _12069;
int _12071;
int _12073;
int _12075;
int _12077;
int _12079;
int _12081;
int _12083;
int _12085;
int _12087;
int _12089;
int _12091;
int _12093;
int _12095;
int _12097;
int _12117;
int _12125;
int _12298;
int _12300;
int _12302;
int _12327;
int _12520;
int _12585;
int _12597;
int _12623;
int _12627;
int _12628;
int _12639;
int _12647;
int _12656;
int _12668;
int _12669;
int _12691;
int _12692;
int _12706;
int _12707;
int _12717;
int _12732;
int _12749;
int _12759;
int _12766;
int _12779;
int _12780;
int _12781;
int _12790;
int _12808;
int _12811;
int _12844;
int _12851;
int _12859;
int _12860;
int _12861;
int _12875;
int _12899;
int _12922;
int _12932;
int _12933;
int _12938;
int _12949;
int _12953;
int _12956;
int _12963;
int _12966;
int _12968;
int _12974;
int _12980;
int _12983;
int _12991;
int _12993;
int _12996;
int _12998;
int _13003;
int _13005;
int _13008;
int _13013;
int _13014;
int _13015;
int _13024;
int _13026;
int _13053;
int _13069;
int _13081;
int _13088;
int _13098;
int _13118;
int _13122;
int _13127;
int _13141;
int _13156;
int _13158;
int _13162;
int _13163;
int _13166;
int _13181;
int _13264;
int _13265;
int _13267;
int _13270;
int _13274;
int _13275;
int _13276;
int _13277;
int _13278;
int _13651;
int _13652;
int _13653;

// 0x0B5C1933
// Declaring file vars
int _3M_EU_INFO_146 = 75;
int _3MAJ_VER_148 = 1;
int _3MIN_VER_149 = 2;
int _3PAT_VER_151 = 3;
int _3VER_TYPE_153 = 4;
int _3NODE_155 = 5;
int _3REVISION_157 = 6;
int _3REVISION_DATE_159 = 7;
int _3START_TIME_161 = 8;
int _3version_info_163 = NOVALUE;
int _3is_developmental_165 = NOVALUE;
int _3is_release_169 = NOVALUE;
int _4keywords_296 = NOVALUE;
int _4builtins_343 = NOVALUE;
int _7OBJ_UNASSIGNED_439 = 0;
int _7OBJ_INTEGER_440 = 1;
int _7OBJ_ATOM_441 = 2;
int _7OBJ_SEQUENCE_442 = 3;
int _7FALSE_443 = NOVALUE;
int _7TRUE_445 = NOVALUE;
int _7CS_FIRST_447 = 0;
int _7CS_Consonant_448 = 1;
int _7CS_Vowel_449 = 2;
int _7CS_Hexadecimal_450 = 3;
int _7CS_Whitespace_451 = 4;
int _7CS_Punctuation_452 = 5;
int _7CS_Printable_453 = 6;
int _7CS_Displayable_454 = 7;
int _7CS_Lowercase_455 = 8;
int _7CS_Uppercase_456 = 9;
int _7CS_Alphanumeric_458 = 10;
int _7CS_Identifier_459 = 11;
int _7CS_Alphabetic_461 = 12;
int _7CS_ASCII_462 = 13;
int _7CS_Control_464 = 14;
int _7CS_Digit_466 = 15;
int _7CS_Graphic_468 = 16;
int _7CS_Bytes_470 = 17;
int _7CS_SpecWord_472 = 18;
int _7CS_Boolean_474 = 19;
int _7CS_LAST_476 = 20;
int _7Defined_Sets_538 = NOVALUE;
int _7INVALID_ROUTINE_ID_872 = NOVALUE;
int _7NO_ROUTINE_ID_875 = -99999;
int _9NESTED_ANY_958 = 1;
int _9NESTED_ALL_959 = 2;
int _9NESTED_INDEX_960 = 4;
int _9NESTED_BACKWARD_961 = 8;
int _8M_A_TO_F64_1357 = 46;
int _8M_F64_TO_A_1359 = 47;
int _8M_A_TO_F32_1360 = 48;
int _8M_F32_TO_A_1361 = 49;
int _8M_ALLOC_1363 = 16;
int _8mem_1364 = NOVALUE;
int _8vDigits_1526 = NOVALUE;
int _8decimal_mark_1528 = NOVALUE;
int _10M_CRASH_MESSAGE_1778 = 37;
int _10M_CRASH_FILE_1779 = 57;
int _10M_CRASH_ROUTINE_1780 = 66;
int _10M_CRASH_1781 = 67;
int _10M_WARNING_FILE_1782 = 72;
int _15PAGE_EXECUTE_1812 = 16;
int _15PAGE_EXECUTE_READ_1813 = 32;
int _15PAGE_EXECUTE_READWRITE_1814 = 64;
int _15PAGE_EXECUTE_WRITECOPY_1815 = 128;
int _15PAGE_WRITECOPY_1816 = 8;
int _15PAGE_READWRITE_1817 = 4;
int _15PAGE_READONLY_1818 = 2;
int _15PAGE_NOACCESS_1819 = 1;
int _15PAGE_NONE_1820 = 1;
int _15PAGE_READ_EXECUTE_1821 = 32;
int _15PAGE_READ_WRITE_1822 = 4;
int _15PAGE_READ_1823 = 2;
int _15PAGE_READ_WRITE_EXECUTE_1824 = 64;
int _15PAGE_WRITE_EXECUTE_COPY_1825 = 128;
int _15PAGE_WRITE_COPY_1826 = 8;
int _15MEMORY_PROTECTION_1827 = NOVALUE;
int _15DEP_really_works_1853 = NOVALUE;
int _15use_DEP_1854 = NOVALUE;
int _15MEM_COMMIT_1855 = 4096;
int _15MEM_RESERVE_1857 = 8192;
int _15MEM_RESET_1859 = 524288;
int _15MEM_RELEASE_1861 = 32768;
int _15FREE_RID_1863 = NOVALUE;
int _15A_READ_1864 = 1;
int _15A_WRITE_1865 = 2;
int _15A_EXECUTE_1866 = 3;
int _15M_ALLOC_1867 = 16;
int _15M_FREE_1868 = 17;
int _16MAX_ADDR_1880 = NOVALUE;
int _16check_calls_1912 = NOVALUE;
int _16BORDER_SPACE_1938 = 0;
int _16leader_1939 = NOVALUE;
int _16trailer_1941 = NOVALUE;
int _16VirtualFree_rid_1954 = NOVALUE;
int _14FREE_ARRAY_RID_1968 = NOVALUE;
int _14ADDRESS_LENGTH_1969 = 4;
int _14page_size_2082 = NOVALUE;
int _14kernel_dll_2083 = NOVALUE;
int _14memDLL_id_2084 = NOVALUE;
int _14VirtualAlloc_rid_2085 = NOVALUE;
int _14VirtualProtect_rid_2086 = NOVALUE;
int _14GetLastError_rid_2087 = NOVALUE;
int _14GetSystemInfo_rid_2088 = NOVALUE;
int _14vaa_2135 = NOVALUE;
int _14system_info_ptr_2152 = NOVALUE;
int _14PAGE_SIZE_2165 = NOVALUE;
int _14oldprotptr_2254 = NOVALUE;
int _13C_CHAR_2353 = 16777217;
int _13C_BYTE_2355 = 16777217;
int _13C_UCHAR_2356 = 33554433;
int _13C_UBYTE_2358 = 33554433;
int _13C_SHORT_2359 = 16777218;
int _13C_WORD_2361 = 16777218;
int _13C_USHORT_2362 = 33554434;
int _13C_INT_2364 = 16777220;
int _13C_BOOL_2366 = 16777220;
int _13C_UINT_2367 = 33554436;
int _13C_SIZE_T_2369 = 33554436;
int _13C_LONG_2370 = 16777220;
int _13C_ULONG_2371 = 33554436;
int _13C_POINTER_2372 = 33554436;
int _13C_HANDLE_2373 = 33554436;
int _13C_HWND_2374 = 33554436;
int _13C_DWORD_2375 = 33554436;
int _13C_WPARAM_2376 = 16777220;
int _13C_LPARAM_2377 = 16777220;
int _13C_HRESULT_2378 = 16777220;
int _13C_FLOAT_2379 = 50331652;
int _13C_DOUBLE_2381 = 50331656;
int _13C_DWORDLONG_2383 = 50331656;
int _13E_INTEGER_2384 = 100663300;
int _13E_ATOM_2386 = 117440516;
int _13E_SEQUENCE_2388 = 134217732;
int _13E_OBJECT_2390 = 150994948;
int _13NULL_2392 = 0;
int _13M_OPEN_DLL_2393 = 50;
int _13M_DEFINE_C_2394 = 51;
int _13M_DEFINE_VAR_2395 = 56;
int _13M_CALL_BACK_2452 = 52;
int _18M_SEEK_2461 = 19;
int _18M_WHERE_2462 = 20;
int _18M_FLUSH_2463 = 60;
int _18M_LOCK_FILE_2465 = 61;
int _18M_UNLOCK_FILE_2467 = 62;
int _18STDIN_2469 = 0;
int _18STDOUT_2470 = 1;
int _18STDERR_2471 = 2;
int _18SCREEN_2472 = 1;
int _18EOF_2473 = -1;
int _18CHUNK_2474 = 100;
int _18mem0_2507 = NOVALUE;
int _18mem1_2508 = NOVALUE;
int _18mem2_2509 = NOVALUE;
int _18mem3_2510 = NOVALUE;
int _18LOCK_SHARED_2561 = 1;
int _18LOCK_EXCLUSIVE_2562 = 2;
int _18BINARY_MODE_2749 = 1;
int _18TEXT_MODE_2750 = 2;
int _18UNIX_TEXT_2751 = 3;
int _18DOS_TEXT_2752 = 4;
int _17GET_SUCCESS_2910 = 0;
int _17GET_EOF_2911 = -1;
int _17GET_FAIL_2912 = 1;
int _17GET_NOTHING_2913 = -2;
int _17DIGITS_2915 = NOVALUE;
int _17HEX_DIGITS_2917 = NOVALUE;
int _17START_NUMERIC_2920 = NOVALUE;
int _17TRUE_2923 = 1;
int _17input_file_2934 = NOVALUE;
int _17input_string_2935 = NOVALUE;
int _17string_next_2936 = NOVALUE;
int _17ch_2937 = NOVALUE;
int _17white_space_2953 = NOVALUE;
int _17ESCAPE_CHARS_2958 = NOVALUE;
int _17ESCAPED_CHARS_2960 = NOVALUE;
int _17GET_IGNORE_3015 = -2;
int _17leading_whitespace_3207 = NOVALUE;
int _17GET_SHORT_ANSWER_3332 = NOVALUE;
int _17GET_LONG_ANSWER_3335 = NOVALUE;
int _12gmtime__3399 = NOVALUE;
int _12time__3404 = NOVALUE;
int _12TM_SEC_3409 = 1;
int _12TM_MIN_3410 = 2;
int _12TM_HOUR_3411 = 3;
int _12TM_MDAY_3412 = 4;
int _12TM_MON_3413 = 5;
int _12TM_YEAR_3414 = 6;
int _12Gregorian_Reformation_3457 = 1752;
int _12Gregorian_Reformation00_3459 = 1700;
int _12DaysPerMonth_3461 = NOVALUE;
int _12EPOCH_1970_3464 = NOVALUE;
int _12DayLengthInSeconds_3466 = 86400;
int _12month_names_3673 = NOVALUE;
int _12month_abbrs_3687 = NOVALUE;
int _12day_names_3700 = NOVALUE;
int _12day_abbrs_3709 = NOVALUE;
int _12ampm_3718 = NOVALUE;
int _12YEAR_3722 = 1;
int _12MONTH_3723 = 2;
int _12DAY_3724 = 3;
int _12HOUR_3725 = 4;
int _12MINUTE_3726 = 5;
int _12SECOND_3727 = 6;
int _12YEARS_3728 = 1;
int _12MONTHS_3729 = 2;
int _12WEEKS_3730 = 3;
int _12DAYS_3731 = 4;
int _12HOURS_3732 = 5;
int _12MINUTES_3733 = 6;
int _12SECONDS_3734 = 7;
int _12DATE_3735 = 8;
int _12date_now_4112 = NOVALUE;
int _12now_inlined_now_at_779_4114 = NOVALUE;
int _12now_1__tmp_at779_4115 = NOVALUE;
int _19HSIEH30_4299 = -6;
int _19HSIEH32_4301 = -5;
int _19ADLER32_4303 = -4;
int _19FLETCHER32_4305 = -3;
int _19MD5_4307 = -2;
int _19SHA256_4308 = -1;
int _21M_SET_RAND_4335 = 35;
int _21M_GET_RAND_4336 = 98;
int _22PI_4424 = NOVALUE;
int _22QUARTPI_4426 = NOVALUE;
int _22HALFPI_4428 = NOVALUE;
int _22TWOPI_4430 = NOVALUE;
int _22PISQR_4432 = NOVALUE;
int _22INVSQ2PI_4434 = NOVALUE;
int _22PHI_4436 = NOVALUE;
int _22E_4438 = NOVALUE;
int _22LN2_4440 = NOVALUE;
int _22INVLN2_4442 = NOVALUE;
int _22LN10_4444 = NOVALUE;
int _22INVLN10_4446 = NOVALUE;
int _22SQRT2_4448 = NOVALUE;
int _22HALFSQRT2_4450 = NOVALUE;
int _22SQRT3_4452 = NOVALUE;
int _22DEGREES_TO_RADIANS_4454 = NOVALUE;
int _22RADIANS_TO_DEGREES_4456 = NOVALUE;
int _22EULER_GAMMA_4458 = NOVALUE;
int _22SQRTE_4460 = NOVALUE;
int _22PINF_4462 = NOVALUE;
int _22MINF_4465 = NOVALUE;
int _22SQRT5_4467 = NOVALUE;
int _24ASCENDING_5106 = 1;
int _24NORMAL_ORDER_5107 = 1;
int _24DESCENDING_5108 = -1;
int _24REVERSE_ORDER_5109 = -1;
int _23ADD_PREPEND_5384 = 1;
int _23ADD_APPEND_5385 = 2;
int _23ADD_SORT_UP_5386 = 3;
int _23ADD_SORT_DOWN_5387 = 4;
int _23ROTATE_LEFT_5388 = 1;
int _23ROTATE_RIGHT_5389 = -1;
int _23STDFLTR_ALPHA_6250 = NOVALUE;
int _23BK_LEN_6435 = 1;
int _23BK_PIECES_6436 = 2;
int _23SEQ_NOALT_6861 = NOVALUE;
int _23RD_INPLACE_6893 = 1;
int _23RD_PRESORTED_6894 = 2;
int _23RD_SORT_6895 = 3;
int _23COMBINE_UNSORTED_6934 = 0;
int _23COMBINE_SORTED_6935 = 1;
int _25END_MARKER_7018 = -1;
int _11M_DIR_7079 = 22;
int _11M_CURRENT_DIR_7081 = 23;
int _11M_CHDIR_7082 = 63;
int _11lib_7083 = NOVALUE;
int _11xCopyFile_7093 = NOVALUE;
int _11xMoveFile_7098 = NOVALUE;
int _11xDeleteFile_7102 = NOVALUE;
int _11xCreateDirectory_7106 = NOVALUE;
int _11xRemoveDirectory_7113 = NOVALUE;
int _11xGetFileAttributes_7117 = NOVALUE;
int _11xGetDiskFreeSpace_7121 = NOVALUE;
int _11SLASH_7129 = 92;
int _11SLASHES_7130 = NOVALUE;
int _11EOLSEP_7132 = NOVALUE;
int _11PATHSEP_7133 = 59;
int _11NULLDEVICE_7134 = NOVALUE;
int _11SHARED_LIB_EXT_7136 = NOVALUE;
int _11EOL_7138 = 10;
int _11D_NAME_7139 = 1;
int _11D_ATTRIBUTES_7140 = 2;
int _11D_SIZE_7141 = 3;
int _11D_YEAR_7142 = 4;
int _11D_MONTH_7143 = 5;
int _11D_DAY_7144 = 6;
int _11D_HOUR_7145 = 7;
int _11D_MINUTE_7146 = 8;
int _11D_SECOND_7147 = 9;
int _11D_MILLISECOND_7148 = 10;
int _11D_ALTNAME_7149 = 11;
int _11W_BAD_PATH_7150 = -1;
int _11DEFAULT_DIR_SOURCE_7187 = -2;
int _11my_dir_7188 = NOVALUE;
int _11InitCurDir_7342 = NOVALUE;
int _11PATH_DIR_7488 = 1;
int _11PATH_FILENAME_7489 = 2;
int _11PATH_BASENAME_7490 = 3;
int _11PATH_FILEEXT_7491 = 4;
int _11PATH_DRIVEID_7492 = 5;
int _11AS_IS_7643 = 0;
int _11TO_LOWER_7644 = 1;
int _11CORRECT_7645 = 2;
int _11TO_SHORT_7646 = 4;
int _11starting_current_dir_7647 = NOVALUE;
int _11system_drive_case_7649 = NOVALUE;
int _11FILETYPE_UNDEFINED_8057 = -1;
int _11FILETYPE_NOT_FOUND_8058 = 0;
int _11FILETYPE_FILE_8059 = 1;
int _11FILETYPE_DIRECTORY_8060 = 2;
int _11SECTORS_PER_CLUSTER_8095 = 1;
int _11BYTES_PER_SECTOR_8096 = 2;
int _11NUMBER_OF_FREE_CLUSTERS_8097 = 3;
int _11TOTAL_NUMBER_OF_CLUSTERS_8098 = 4;
int _11TOTAL_BYTES_8099 = 1;
int _11FREE_BYTES_8100 = 2;
int _11USED_BYTES_8101 = 3;
int _11COUNT_DIRS_8102 = 1;
int _11COUNT_FILES_8103 = 2;
int _11COUNT_SIZE_8104 = 3;
int _11COUNT_TYPES_8105 = 4;
int _11EXT_NAME_8106 = 1;
int _11EXT_COUNT_8107 = 2;
int _11EXT_SIZE_8108 = 3;
int _11file_counters_8410 = NOVALUE;
int _26pretty_end_col_8685 = NOVALUE;
int _26pretty_chars_8686 = NOVALUE;
int _26pretty_start_col_8687 = NOVALUE;
int _26pretty_level_8688 = NOVALUE;
int _26pretty_file_8689 = NOVALUE;
int _26pretty_ascii_8690 = NOVALUE;
int _26pretty_indent_8691 = NOVALUE;
int _26pretty_ascii_min_8692 = NOVALUE;
int _26pretty_ascii_max_8693 = NOVALUE;
int _26pretty_line_count_8694 = NOVALUE;
int _26pretty_line_max_8695 = NOVALUE;
int _26pretty_dots_8696 = NOVALUE;
int _26pretty_line_breaks_8697 = NOVALUE;
int _26pretty_printing_8698 = NOVALUE;
int _26pretty_fp_format_8699 = NOVALUE;
int _26pretty_int_format_8700 = NOVALUE;
int _26pretty_line_8701 = NOVALUE;
int _26PRETTY_DEFAULT_8845 = NOVALUE;
int _26DISPLAY_ASCII_8847 = 1;
int _26INDENT_8848 = 2;
int _26START_COLUMN_8849 = 3;
int _26WRAP_8850 = 4;
int _26INT_FORMAT_8851 = 5;
int _26FP_FORMAT_8852 = 6;
int _26MIN_ASCII_8853 = 7;
int _26MAX_ASCII_8854 = 8;
int _26MAX_LINES_8855 = 9;
int _26LINE_BREAKS_8856 = 10;
int _27I2B_8891 = 249;
int _27I3B_8893 = 250;
int _27I4B_8895 = 251;
int _27F4B_8897 = 252;
int _27F8B_8899 = 253;
int _27S1B_8901 = 254;
int _27S4B_8903 = 255;
int _27I8B_8904 = 0;
int _27F10B_8905 = 1;
int _27MIN1B_8906 = -9;
int _27MAX1B_8908 = 239;
int _27MIN2B_8910 = NOVALUE;
int _27MAX2B_8913 = NOVALUE;
int _27MIN3B_8916 = NOVALUE;
int _27MAX3B_8919 = NOVALUE;
int _27MIN4B_8922 = NOVALUE;
int _27mem0_8925 = NOVALUE;
int _27mem1_8926 = NOVALUE;
int _27mem2_8927 = NOVALUE;
int _27mem3_8928 = NOVALUE;
int _27f80_8933 = NOVALUE;
int _27f64_8934 = NOVALUE;
int _27F80_TO_ATOM_8935 = NOVALUE;
int _27i64_8973 = NOVALUE;
int _27PEEK8S_8974 = NOVALUE;
int _6lower_case_SET_9469 = NOVALUE;
int _6upper_case_SET_9470 = NOVALUE;
int _6encoding_NAME_9471 = NOVALUE;
int _6user32_9620 = NOVALUE;
int _6api_CharLowerBuff_9624 = NOVALUE;
int _6api_CharUpperBuff_9632 = NOVALUE;
int _6tm_size_9640 = NOVALUE;
int _6temp_mem_9641 = NOVALUE;
int _28ram_space_10933 = NOVALUE;
int _28ram_free_list_10934 = NOVALUE;
int _28free_rid_10935 = NOVALUE;
int _5NORMAL_COLOR_10989 = NOVALUE;
int _5COMMENT_COLOR_10990 = NOVALUE;
int _5KEYWORD_COLOR_10991 = NOVALUE;
int _5BUILTIN_COLOR_10992 = NOVALUE;
int _5STRING_COLOR_10993 = NOVALUE;
int _5BRACKET_COLOR_10994 = NOVALUE;
int _5S_STRING_TRIPLE_10995 = 1;
int _5S_STRING_BACKTICK_10996 = 2;
int _5S_MULTILINE_COMMENT_10997 = 3;
int _5S_BRACKET_LEVEL_10998 = 4;
int _5DIGIT_10999 = 1;
int _5OTHER_11000 = 2;
int _5LETTER_11001 = 3;
int _5BRACKET_11002 = 4;
int _5QUOTE_11003 = 5;
int _5BACKTICK_11004 = 6;
int _5DASH_11005 = 7;
int _5FORWARD_SLASH_11006 = 8;
int _5WHITE_SPACE_11007 = 9;
int _5NEW_LINE_11008 = 10;
int _5char_class_11009 = NOVALUE;
int _5DONT_CARE_11060 = -1;
int _5line_11061 = NOVALUE;
int _5color_segments_11062 = NOVALUE;
int _5current_color_11063 = NOVALUE;
int _5seg_start_11064 = NOVALUE;
int _5seg_end_11065 = NOVALUE;
int _5g_state_11082 = NOVALUE;
int _29EOL_11306 = 10;
int _29TRUE_11307 = 1;
int _29FALSE_11308 = 0;
int _29ET_TOKENS_11309 = 1;
int _29ET_ERROR_11310 = 2;
int _29ET_ERR_LINE_11311 = 3;
int _29ET_ERR_COLUMN_11312 = 4;
int _29T_EOF_11313 = 1;
int _29T_NULL_11314 = 2;
int _29T_SHBANG_11315 = 3;
int _29T_NEWLINE_11316 = 4;
int _29T_COMMENT_11317 = 5;
int _29T_NUMBER_11318 = 6;
int _29T_CHAR_11319 = 7;
int _29T_STRING_11320 = 8;
int _29T_IDENTIFIER_11321 = 9;
int _29T_KEYWORD_11322 = 10;
int _29T_DOUBLE_OPS_11323 = 11;
int _29T_PLUSEQ_11324 = 11;
int _29T_MINUSEQ_11325 = 12;
int _29T_MULTIPLYEQ_11326 = 13;
int _29T_DIVIDEEQ_11327 = 14;
int _29T_LTEQ_11328 = 15;
int _29T_GTEQ_11329 = 16;
int _29T_NOTEQ_11330 = 17;
int _29T_CONCATEQ_11331 = 18;
int _29T_DELIMITER_11332 = 19;
int _29T_PLUS_11333 = 19;
int _29T_MINUS_11334 = 20;
int _29T_MULTIPLY_11335 = 21;
int _29T_DIVIDE_11337 = 22;
int _29T_LT_11338 = 23;
int _29T_GT_11339 = 24;
int _29T_NOT_11340 = 25;
int _29T_CONCAT_11342 = 26;
int _29T_SINGLE_OPS_11343 = 27;
int _29T_EQ_11345 = 27;
int _29T_LPAREN_11346 = 28;
int _29T_RPAREN_11347 = 29;
int _29T_LBRACE_11348 = 30;
int _29T_RBRACE_11349 = 31;
int _29T_LBRACKET_11350 = 32;
int _29T_RBRACKET_11351 = 33;
int _29T_QPRINT_11352 = 34;
int _29T_COMMA_11353 = 35;
int _29T_PERIOD_11354 = 36;
int _29T_COLON_11355 = 37;
int _29T_DOLLAR_11356 = 38;
int _29T_SLICE_11358 = 39;
int _29TF_HEX_11359 = 1;
int _29TF_INT_11360 = 2;
int _29TF_ATOM_11361 = 3;
int _29TF_STRING_SINGLE_11362 = 4;
int _29TF_STRING_TRIPLE_11363 = 5;
int _29TF_STRING_BACKTICK_11364 = 6;
int _29TF_STRING_HEX_11365 = 7;
int _29TF_COMMENT_SINGLE_11366 = 8;
int _29TF_COMMENT_MULTIPLE_11367 = 9;
int _29Delimiters_11368 = NOVALUE;
int _29TTYPE_11372 = 1;
int _29TDATA_11373 = 2;
int _29TLNUM_11374 = 3;
int _29TLPOS_11375 = 4;
int _29TFORM_11376 = 5;
int _29Token_11377 = NOVALUE;
int _29source_text_11379 = NOVALUE;
int _29sti_11380 = NOVALUE;
int _29LNum_11381 = NOVALUE;
int _29LPos_11382 = NOVALUE;
int _29Look_11383 = NOVALUE;
int _29ERR_11384 = NOVALUE;
int _29ERR_LNUM_11385 = NOVALUE;
int _29ERR_LPOS_11386 = NOVALUE;
int _29ERR_NONE_11387 = 0;
int _29ERR_OPEN_11388 = 1;
int _29ERR_ESCAPE_11389 = 2;
int _29ERR_EOL_CHAR_11390 = 3;
int _29ERR_CLOSE_CHAR_11391 = 4;
int _29ERR_EOL_STRING_11392 = 5;
int _29ERR_HEX_11393 = 6;
int _29ERR_DECIMAL_11394 = 7;
int _29ERR_UNKNOWN_11395 = 8;
int _29ERR_EOF_11396 = 9;
int _29ERR_EOF_STRING_11397 = 10;
int _29ERR_HEX_STRING_11398 = 11;
int _29ERROR_STRING_11399 = NOVALUE;
int _29IGNORE_NEWLINES_11426 = NOVALUE;
int _29IGNORE_COMMENTS_11427 = NOVALUE;
int _29STRING_NUMBERS_11428 = NOVALUE;
int _29QFLAGS_11567 = NOVALUE;
int _29SUBSCRIPT_11673 = NOVALUE;
int _29INCLUDE_NEXT_11848 = NOVALUE;
int _29token_names_12034 = NOVALUE;
int _29token_forms_12075 = NOVALUE;
int _30aleph_12149 = NOVALUE;
int _30ediv_12166 = NOVALUE;
int _30erem_12168 = NOVALUE;
int _30emul_12170 = NOVALUE;
int _30drem_12172 = NOVALUE;
int _30dmul_12174 = NOVALUE;
int _30ddiv_12176 = NOVALUE;
int _30nc4_12178 = NOVALUE;
int _30next_12180 = NOVALUE;
int _30nc3_12182 = NOVALUE;
int _30ldrop_12184 = NOVALUE;
int _34list_of_primes_12301 = NOVALUE;
int _35ST_FULLPOP_12531 = 1;
int _35ST_SAMPLE_12532 = 2;
int _35ST_ALLNUM_12533 = 1;
int _35ST_IGNSTR_12534 = 2;
int _35ST_ZEROSTR_12535 = 3;
int _33TYPE_TAG_12966 = 1;
int _33ELEMENT_COUNT_12967 = 2;
int _33IN_USE_12968 = 3;
int _33MAP_TYPE_12969 = 4;
int _33KEY_BUCKETS_12970 = 5;
int _33VALUE_BUCKETS_12971 = 6;
int _33KEY_LIST_12972 = 5;
int _33VALUE_LIST_12973 = 6;
int _33FREE_LIST_12974 = 7;
int _33type_is_map_12975 = NOVALUE;
int _33PUT_12977 = 1;
int _33ADD_12978 = 2;
int _33SUBTRACT_12979 = 3;
int _33MULTIPLY_12980 = 4;
int _33DIVIDE_12981 = 5;
int _33APPEND_12982 = 6;
int _33CONCAT_12983 = 7;
int _33LEAVE_12984 = 8;
int _33INIT_OPERATIONS_12985 = NOVALUE;
int _33SMALLMAP_12987 = 115;
int _33LARGEMAP_12988 = 76;
int _33threshold_size_12989 = NOVALUE;
int _33init_small_map_key_12990 = NOVALUE;
int _33maxInt_13072 = 1073741823;
int _33NUM_ENTRIES_13700 = 1;
int _33NUM_IN_USE_13701 = 2;
int _33NUM_BUCKETS_13702 = 3;
int _33LARGEST_BUCKET_13703 = 4;
int _33SMALLEST_BUCKET_13704 = 5;
int _33AVERAGE_BUCKET_13705 = 6;
int _33STDEV_BUCKET_13706 = 7;
int _33SM_TEXT_14087 = 1;
int _33SM_RAW_14088 = 2;
int _36BMP_SUCCESS_14289 = 1;
int _36BMP_OPEN_FAILED_14290 = 2;
int _36BMP_UNEXPECTED_EOF_14291 = 3;
int _36BMP_UNSUPPORTED_FORMAT_14292 = 4;
int _36BMP_INVALID_MODE_14293 = 5;
int _36VC_COLOR_14294 = 1;
int _36VC_MODE_14295 = 2;
int _36VC_LINES_14296 = 3;
int _36VC_COLUMNS_14297 = 4;
int _36VC_XPIXELS_14298 = 5;
int _36VC_YPIXELS_14299 = 6;
int _36VC_NCOLORS_14300 = 7;
int _36VC_PAGES_14301 = 8;
int _36VC_SCRNLINES_14302 = 9;
int _36VC_SCRNCOLS_14303 = 10;
int _36BLACK_14304 = 0;
int _36BLUE_14305 = 1;
int _36GREEN_14306 = 2;
int _36CYAN_14307 = 3;
int _36RED_14308 = 4;
int _36MAGENTA_14309 = 5;
int _36BROWN_14310 = 6;
int _36WHITE_14311 = 7;
int _36GRAY_14312 = 8;
int _36BRIGHT_BLUE_14313 = 9;
int _36BRIGHT_GREEN_14314 = 10;
int _36BRIGHT_CYAN_14315 = 11;
int _36BRIGHT_RED_14316 = 12;
int _36BRIGHT_MAGENTA_14317 = 13;
int _36YELLOW_14318 = 14;
int _36BRIGHT_WHITE_14319 = 15;
int _36true_fgcolor_14320 = NOVALUE;
int _36true_bgcolor_14322 = NOVALUE;
int _36BLINKING_14324 = 16;
int _36BYTES_PER_CHAR_14325 = 2;
int _36M_VIDEO_CONFIG_14354 = 13;
int _36FGSET_14358 = 1;
int _36BGSET_14359 = 2;
int _32M_WAIT_KEY_14360 = 26;
int _32M_ALLOW_BREAK_14361 = 42;
int _32M_CHECK_BREAK_14362 = 43;
int _32M_CURSOR_14363 = 6;
int _32M_TEXTROWS_14364 = 12;
int _32M_FREE_CONSOLE_14365 = 54;
int _32M_GET_SCREEN_CHAR_14366 = 58;
int _32M_PUT_SCREEN_CHAR_14367 = 59;
int _32M_HAS_CONSOLE_14368 = 99;
int _32M_KEY_CODES_14369 = 100;
int _32KC_LBUTTON_14377 = NOVALUE;
int _32KC_RBUTTON_14379 = NOVALUE;
int _32KC_CANCEL_14381 = NOVALUE;
int _32KC_MBUTTON_14383 = NOVALUE;
int _32KC_XBUTTON1_14385 = NOVALUE;
int _32KC_XBUTTON2_14387 = NOVALUE;
int _32KC_BACK_14389 = NOVALUE;
int _32KC_TAB_14391 = NOVALUE;
int _32KC_CLEAR_14393 = NOVALUE;
int _32KC_RETURN_14395 = NOVALUE;
int _32KC_SHIFT_14397 = NOVALUE;
int _32KC_CONTROL_14399 = NOVALUE;
int _32KC_MENU_14401 = NOVALUE;
int _32KC_PAUSE_14403 = NOVALUE;
int _32KC_CAPITAL_14405 = NOVALUE;
int _32KC_KANA_14407 = NOVALUE;
int _32KC_JUNJA_14409 = NOVALUE;
int _32KC_FINAL_14411 = NOVALUE;
int _32KC_HANJA_14413 = NOVALUE;
int _32KC_ESCAPE_14415 = NOVALUE;
int _32KC_CONVERT_14417 = NOVALUE;
int _32KC_NONCONVERT_14419 = NOVALUE;
int _32KC_ACCEPT_14421 = NOVALUE;
int _32KC_MODECHANGE_14423 = NOVALUE;
int _32KC_SPACE_14425 = NOVALUE;
int _32KC_PRIOR_14427 = NOVALUE;
int _32KC_NEXT_14429 = NOVALUE;
int _32KC_END_14431 = NOVALUE;
int _32KC_HOME_14433 = NOVALUE;
int _32KC_LEFT_14435 = NOVALUE;
int _32KC_UP_14437 = NOVALUE;
int _32KC_RIGHT_14439 = NOVALUE;
int _32KC_DOWN_14441 = NOVALUE;
int _32KC_SELECT_14443 = NOVALUE;
int _32KC_PRINT_14445 = NOVALUE;
int _32KC_EXECUTE_14447 = NOVALUE;
int _32KC_SNAPSHOT_14449 = NOVALUE;
int _32KC_INSERT_14451 = NOVALUE;
int _32KC_DELETE_14453 = NOVALUE;
int _32KC_HELP_14455 = NOVALUE;
int _32KC_LWIN_14457 = NOVALUE;
int _32KC_RWIN_14459 = NOVALUE;
int _32KC_APPS_14461 = NOVALUE;
int _32KC_SLEEP_14463 = NOVALUE;
int _32KC_NUMPAD0_14465 = NOVALUE;
int _32KC_NUMPAD1_14467 = NOVALUE;
int _32KC_NUMPAD2_14469 = NOVALUE;
int _32KC_NUMPAD3_14471 = NOVALUE;
int _32KC_NUMPAD4_14473 = NOVALUE;
int _32KC_NUMPAD5_14475 = NOVALUE;
int _32KC_NUMPAD6_14477 = NOVALUE;
int _32KC_NUMPAD7_14479 = NOVALUE;
int _32KC_NUMPAD8_14481 = NOVALUE;
int _32KC_NUMPAD9_14483 = NOVALUE;
int _32KC_MULTIPLY_14485 = NOVALUE;
int _32KC_ADD_14487 = NOVALUE;
int _32KC_SEPARATOR_14489 = NOVALUE;
int _32KC_SUBTRACT_14491 = NOVALUE;
int _32KC_DECIMAL_14493 = NOVALUE;
int _32KC_DIVIDE_14495 = NOVALUE;
int _32KC_F1_14497 = NOVALUE;
int _32KC_F2_14499 = NOVALUE;
int _32KC_F3_14501 = NOVALUE;
int _32KC_F4_14503 = NOVALUE;
int _32KC_F5_14505 = NOVALUE;
int _32KC_F6_14507 = NOVALUE;
int _32KC_F7_14509 = NOVALUE;
int _32KC_F8_14511 = NOVALUE;
int _32KC_F9_14513 = NOVALUE;
int _32KC_F10_14515 = NOVALUE;
int _32KC_F11_14517 = NOVALUE;
int _32KC_F12_14519 = NOVALUE;
int _32KC_F13_14521 = NOVALUE;
int _32KC_F14_14524 = NOVALUE;
int _32KC_F15_14526 = NOVALUE;
int _32KC_F16_14528 = NOVALUE;
int _32KC_F17_14530 = NOVALUE;
int _32KC_F18_14532 = NOVALUE;
int _32KC_F19_14535 = NOVALUE;
int _32KC_F20_14538 = NOVALUE;
int _32KC_F21_14540 = NOVALUE;
int _32KC_F22_14543 = NOVALUE;
int _32KC_F23_14546 = NOVALUE;
int _32KC_F24_14549 = NOVALUE;
int _32KC_NUMLOCK_14552 = NOVALUE;
int _32KC_SCROLL_14555 = NOVALUE;
int _32KC_LSHIFT_14558 = NOVALUE;
int _32KC_RSHIFT_14560 = NOVALUE;
int _32KC_LCONTROL_14563 = NOVALUE;
int _32KC_RCONTROL_14566 = NOVALUE;
int _32KC_LMENU_14568 = NOVALUE;
int _32KC_RMENU_14570 = NOVALUE;
int _32KC_BROWSER_BACK_14572 = NOVALUE;
int _32KC_BROWSER_FORWARD_14575 = NOVALUE;
int _32KC_BROWSER_REFRESH_14578 = NOVALUE;
int _32KC_BROWSER_STOP_14581 = NOVALUE;
int _32KC_BROWSER_SEARCH_14583 = NOVALUE;
int _32KC_BROWSER_FAVORITES_14586 = NOVALUE;
int _32KC_BROWSER_HOME_14589 = NOVALUE;
int _32KC_VOLUME_MUTE_14592 = NOVALUE;
int _32KC_VOLUME_DOWN_14595 = NOVALUE;
int _32KC_VOLUME_UP_14598 = NOVALUE;
int _32KC_MEDIA_NEXT_TRACK_14601 = NOVALUE;
int _32KC_MEDIA_PREV_TRACK_14604 = NOVALUE;
int _32KC_MEDIA_STOP_14607 = NOVALUE;
int _32KC_MEDIA_PLAY_PAUSE_14610 = NOVALUE;
int _32KC_LAUNCH_MAIL_14613 = NOVALUE;
int _32KC_LAUNCH_MEDIA_SELECT_14616 = NOVALUE;
int _32KC_LAUNCH_APP1_14619 = NOVALUE;
int _32KC_LAUNCH_APP2_14622 = NOVALUE;
int _32KC_OEM_1_14625 = NOVALUE;
int _32KC_OEM_PLUS_14628 = NOVALUE;
int _32KC_OEM_COMMA_14631 = NOVALUE;
int _32KC_OEM_MINUS_14634 = NOVALUE;
int _32KC_OEM_PERIOD_14637 = NOVALUE;
int _32KC_OEM_2_14640 = NOVALUE;
int _32KC_OEM_3_14643 = NOVALUE;
int _32KC_OEM_4_14646 = NOVALUE;
int _32KC_OEM_5_14648 = NOVALUE;
int _32KC_OEM_6_14651 = NOVALUE;
int _32KC_OEM_7_14653 = NOVALUE;
int _32KC_OEM_8_14656 = NOVALUE;
int _32KC_OEM_102_14658 = NOVALUE;
int _32KC_PROCESSKEY_14661 = NOVALUE;
int _32KC_PACKET_14663 = NOVALUE;
int _32KC_ATTN_14666 = NOVALUE;
int _32KC_CRSEL_14669 = NOVALUE;
int _32KC_EXSEL_14672 = NOVALUE;
int _32KC_EREOF_14674 = NOVALUE;
int _32KC_PLAY_14676 = NOVALUE;
int _32KC_ZOOM_14678 = NOVALUE;
int _32KC_NONAME_14680 = NOVALUE;
int _32KC_PA1_14682 = NOVALUE;
int _32KC_OEM_CLEAR_14684 = NOVALUE;
int _32KM_CONTROL_14686 = 4096;
int _32KM_SHIFT_14687 = 8192;
int _32KM_ALT_14688 = 16384;
int _32NO_CURSOR_14992 = 8192;
int _32UNDERLINE_CURSOR_14993 = 1543;
int _32THICK_UNDERLINE_CURSOR_14995 = 1287;
int _32HALF_BLOCK_CURSOR_14997 = 1031;
int _32BLOCK_CURSOR_14999 = 7;
int _37CMD_SWITCHES_15290 = NOVALUE;
int _37M_SLEEP_15292 = 64;
int _37M_SET_ENV_15293 = 73;
int _37M_UNSET_ENV_15294 = 74;
int _37WIN32_15295 = 2;
int _37WINDOWS_15296 = 2;
int _37LINUX_15297 = 3;
int _37OSX_15298 = 4;
int _37OPENBSD_15299 = 6;
int _37NETBSD_15300 = 7;
int _37FREEBSD_15301 = 8;
int _37M_INSTANCE_15302 = 55;
int _37cur_pid_15306 = NOVALUE;
int _37M_UNAME_15318 = NOVALUE;
int _31NO_PARAMETER_15474 = 110;
int _31HAS_PARAMETER_15475 = 112;
int _31NO_CASE_15476 = 105;
int _31HAS_CASE_15477 = 99;
int _31MANDATORY_15478 = 109;
int _31OPTIONAL_15479 = 111;
int _31ONCE_15480 = 49;
int _31MULTIPLE_15481 = 42;
int _31HELP_15482 = 104;
int _31VERSIONING_15483 = 118;
int _31HELP_RID_15484 = 1;
int _31VALIDATE_ALL_15485 = 2;
int _31NO_VALIDATION_15486 = 3;
int _31NO_VALIDATION_AFTER_FIRST_EXTRA_15487 = 4;
int _31SHOW_ONLY_OPTIONS_15488 = 5;
int _31AT_EXPANSION_15489 = 6;
int _31NO_AT_EXPANSION_15490 = 7;
int _31PAUSE_MSG_15491 = 8;
int _31NO_HELP_15492 = 9;
int _31NO_HELP_ON_ERROR_15493 = 10;
int _31OPT_IDX_15494 = 1;
int _31OPT_CNT_15495 = 2;
int _31OPT_VAL_15496 = 3;
int _31OPT_REV_15497 = 4;
int _31EXTRAS_15498 = NOVALUE;
int _31OPT_EXTRAS_15502 = NOVALUE;
int _31SHORTNAME_15503 = 1;
int _31LONGNAME_15504 = 2;
int _31DESCRIPTION_15505 = 3;
int _31OPTIONS_15506 = 4;
int _31CALLBACK_15507 = 5;
int _31MAPNAME_15508 = 6;
int _31pause_msg_15509 = NOVALUE;
int _38DB_OK_16654 = 0;
int _38DB_OPEN_FAIL_16655 = -1;
int _38DB_EXISTS_ALREADY_16656 = -2;
int _38DB_LOCK_FAIL_16657 = -3;
int _38DB_BAD_NAME_16658 = -4;
int _38DB_FATAL_FAIL_16659 = -404;
int _38DB_LOCK_NO_16662 = 0;
int _38DB_LOCK_SHARED_16663 = 1;
int _38DB_LOCK_EXCLUSIVE_16664 = 2;
int _38DB_LOCK_READ_ONLY_16665 = 3;
int _38MISSING_END_16666 = 900;
int _38NO_DATABASE_16668 = 901;
int _38BAD_SEEK_16670 = 902;
int _38NO_TABLE_16672 = 903;
int _38DUP_TABLE_16674 = 904;
int _38BAD_RECNO_16676 = 905;
int _38INSERT_FAILED_16678 = 906;
int _38LAST_ERROR_CODE_16680 = 907;
int _38BAD_FILE_16682 = 908;
int _38DB_MAGIC_16684 = 77;
int _38DB_MAJOR_16685 = 4;
int _38DB_MINOR_16686 = 0;
int _38SIZEOF_TABLE_HEADER_16687 = 16;
int _38TABLE_HEADERS_16688 = 3;
int _38FREE_COUNT_16689 = 7;
int _38FREE_LIST_16690 = 11;
int _38DEF_INIT_FREE_16691 = 5;
int _38DEF_INIT_TABLES_16692 = 5;
int _38MAX_INDEX_16693 = 10;
int _38DEF_INIT_RECORDS_16694 = 50;
int _38CONNECT_LOCK_16695 = 1;
int _38CONNECT_TABLES_16696 = 2;
int _38CONNECT_FREE_16697 = 3;
int _38TRUE_16698 = 1;
int _38current_db_16699 = NOVALUE;
int _38current_table_pos_16700 = NOVALUE;
int _38current_table_name_16701 = NOVALUE;
int _38db_names_16702 = NOVALUE;
int _38db_file_nums_16703 = NOVALUE;
int _38db_lock_methods_16704 = NOVALUE;
int _38current_lock_16705 = NOVALUE;
int _38key_pointers_16706 = NOVALUE;
int _38key_cache_16707 = NOVALUE;
int _38cache_index_16708 = NOVALUE;
int _38caching_option_16709 = NOVALUE;
int _38DISCONNECT_16710 = NOVALUE;
int _38LOCK_METHOD_16712 = NOVALUE;
int _38INIT_TABLES_16714 = NOVALUE;
int _38INIT_FREE_16716 = NOVALUE;
int _38CONNECTION_16718 = NOVALUE;
int _38Known_Aliases_16720 = NOVALUE;
int _38Alias_Details_16721 = NOVALUE;
int _38db_fatal_id_16722 = NOVALUE;
int _38vLastErrors_16723 = NOVALUE;
int _38mem0_16741 = NOVALUE;
int _38mem1_16742 = NOVALUE;
int _38mem2_16743 = NOVALUE;
int _38mem3_16744 = NOVALUE;
int _38I2B_16800 = 249;
int _38I3B_16801 = 250;
int _38I4B_16802 = 251;
int _38F4B_16803 = 252;
int _38F8B_16804 = 253;
int _38S1B_16805 = 254;
int _38S4B_16806 = 255;
int _38MIN1B_16807 = -9;
int _38MAX1B_16808 = 239;
int _38MIN2B_16809 = NOVALUE;
int _38MAX2B_16812 = NOVALUE;
int _38MIN3B_16815 = NOVALUE;
int _38MAX3B_16818 = NOVALUE;
int _38MIN4B_16821 = NOVALUE;
int _38memseq_16961 = NOVALUE;
int _39one_bit_numbers_19011 = NOVALUE;
int _40M_GRAPHICS_MODE_19106 = 5;
int _40M_WRAP_19107 = 7;
int _40M_SCROLL_19108 = 8;
int _40M_SET_T_COLOR_19109 = 9;
int _40M_SET_B_COLOR_19110 = 10;
int _40M_GET_POSITION_19111 = 25;
int _41BMPFILEHDRSIZE_19210 = 14;
int _41OLDHDRSIZE_19211 = 12;
int _41NEWHDRSIZE_19212 = 40;
int _41EOF_19213 = -1;
int _41fn_19214 = NOVALUE;
int _41error_code_19215 = NOVALUE;
int _41numXPixels_19518 = NOVALUE;
int _41numYPixels_19519 = NOVALUE;
int _41bitCount_19520 = NOVALUE;
int _41numRowBytes_19521 = NOVALUE;
int _42lcid_hex_19673 = NOVALUE;
int _42lcid_string_19881 = NOVALUE;
int _44w32_names_20112 = NOVALUE;
int _44w32_name_canonical_20322 = NOVALUE;
int _44posix_names_20343 = NOVALUE;
int _44locale_canonical_20346 = NOVALUE;
int _44platform_locale_20347 = NOVALUE;
int _43P_20417 = 33554436;
int _43I_20418 = 16777220;
int _43def_lang_20419 = NOVALUE;
int _43lang_path_20420 = NOVALUE;
int _43lib_20575 = NOVALUE;
int _43lib2_20579 = NOVALUE;
int _43f_strfmon_20583 = NOVALUE;
int _43f_strfnum_20588 = NOVALUE;
int _43f_setlocale_20593 = NOVALUE;
int _43f_strftime_20598 = NOVALUE;
int _43LC_ALL_20603 = 0;
int _43LC_MONETARY_20604 = 3;
int _43LC_NUMERIC_20605 = 4;
int _43current_locale_20606 = NOVALUE;
int _46kernel32_20920 = NOVALUE;
int _46iCreatePipe_20923 = NOVALUE;
int _46iReadFile_20927 = NOVALUE;
int _46iWriteFile_20931 = NOVALUE;
int _46iCloseHandle_20935 = NOVALUE;
int _46iTerminateProcess_20939 = NOVALUE;
int _46iGetLastError_20943 = NOVALUE;
int _46iGetStdHandle_20946 = NOVALUE;
int _46iSetHandleInformation_20950 = NOVALUE;
int _46iCreateProcess_20954 = NOVALUE;
int _46SA_SIZE_20958 = 12;
int _46PIPE_WRITE_HANDLE_20959 = 1;
int _46PIPE_READ_HANDLE_20960 = 2;
int _46HANDLE_FLAG_INHERIT_20961 = 1;
int _46SUIdwFlags_20962 = 44;
int _46SUIhStdInput_20963 = 56;
int _46STARTUPINFO_SIZE_20964 = 68;
int _46STARTF_USESHOWWINDOW_20965 = 1;
int _46STARTF_USESTDHANDLES_20966 = 256;
int _46PROCESS_INFORMATION_SIZE_20967 = 16;
int _46FAIL_20968 = 0;
int _46STDIN_20979 = 1;
int _46STDOUT_20980 = 2;
int _46STDERR_20981 = 3;
int _46PID_20982 = 4;
int _46PARENT_20983 = 1;
int _46CHILD_20984 = 2;
int _46os_errno_20985 = NOVALUE;
int _47M_PCRE_COMPILE_21227 = 68;
int _47M_PCRE_EXEC_21228 = 70;
int _47M_PCRE_REPLACE_21229 = 71;
int _47M_PCRE_ERROR_MESSAGE_21230 = 95;
int _47M_PCRE_GET_OVECTOR_SIZE_21231 = 97;
int _47DEFAULT_21232 = 0;
int _47CASELESS_21233 = 1;
int _47MULTILINE_21234 = 2;
int _47DOTALL_21235 = 4;
int _47EXTENDED_21236 = 8;
int _47ANCHORED_21237 = 16;
int _47DOLLAR_ENDONLY_21238 = 32;
int _47EXTRA_21239 = 64;
int _47NOTBOL_21240 = 128;
int _47NOTEOL_21241 = 256;
int _47UNGREEDY_21242 = 512;
int _47NOTEMPTY_21243 = 1024;
int _47UTF8_21244 = 2048;
int _47NO_AUTO_CAPTURE_21245 = 4096;
int _47NO_UTF8_CHECK_21246 = 8192;
int _47AUTO_CALLOUT_21247 = 16384;
int _47PARTIAL_21248 = 32768;
int _47DFA_SHORTEST_21249 = 65536;
int _47DFA_RESTART_21250 = 131072;
int _47FIRSTLINE_21251 = 262144;
int _47DUPNAMES_21252 = 524288;
int _47NEWLINE_CR_21253 = 1048576;
int _47NEWLINE_LF_21254 = 2097152;
int _47NEWLINE_CRLF_21255 = 3145728;
int _47NEWLINE_ANY_21257 = 4194304;
int _47NEWLINE_ANYCRLF_21258 = 5242880;
int _47BSR_ANYCRLF_21260 = 8388608;
int _47BSR_UNICODE_21261 = 16777216;
int _47STRING_OFFSETS_21262 = 201326592;
int _47option_names_21264 = NOVALUE;
int _47ERROR_NOMATCH_21324 = -1;
int _47ERROR_NULL_21325 = -2;
int _47ERROR_BADOPTION_21326 = -3;
int _47ERROR_BADMAGIC_21327 = -4;
int _47ERROR_UNKNOWN_OPCODE_21328 = -5;
int _47ERROR_UNKNOWN_NODE_21329 = -5;
int _47ERROR_NOMEMORY_21330 = -6;
int _47ERROR_NOSUBSTRING_21331 = -7;
int _47ERROR_MATCHLIMIT_21333 = -8;
int _47ERROR_CALLOUT_21335 = -9;
int _47ERROR_BADUTF8_21336 = -10;
int _47ERROR_BADUTF8_OFFSET_21338 = -11;
int _47ERROR_PARTIAL_21340 = -12;
int _47ERROR_BADPARTIAL_21342 = -13;
int _47ERROR_INTERNAL_21344 = -14;
int _47ERROR_BADCOUNT_21346 = -15;
int _47ERROR_DFA_UITEM_21348 = -16;
int _47ERROR_DFA_UCOND_21350 = -17;
int _47ERROR_DFA_UMLIMIT_21352 = -18;
int _47ERROR_DFA_WSSIZE_21354 = -19;
int _47ERROR_DFA_RECURSE_21356 = -20;
int _47ERROR_RECURSIONLIMIT_21358 = -21;
int _47ERROR_NULLWSLIMIT_21360 = -22;
int _47ERROR_BADNEWLINE_21362 = -23;
int _47error_names_21364 = NOVALUE;
int _47all_options_21413 = NOVALUE;
int _49DEFAULT_PORT_21868 = 80;
int _49re_ip_21869 = NOVALUE;
int _49re_http_url_21872 = NOVALUE;
int _49re_mail_url_21875 = NOVALUE;
int _49URL_ENTIRE_21915 = 1;
int _49URL_PROTOCOL_21916 = 2;
int _49URL_HTTP_DOMAIN_21917 = 3;
int _49URL_HTTP_PATH_21918 = 4;
int _49URL_HTTP_QUERY_21919 = 5;
int _49URL_MAIL_ADDRESS_21920 = 3;
int _49URL_MAIL_USER_21921 = 4;
int _49URL_MAIL_DOMAIN_21922 = 5;
int _49URL_MAIL_QUERY_21923 = 6;
int _48M_SOCK_GETSERVBYNAME_21950 = 77;
int _48M_SOCK_GETSERVBYPORT_21951 = 78;
int _48M_SOCK_SOCKET_21952 = 81;
int _48M_SOCK_CLOSE_21953 = 82;
int _48M_SOCK_SHUTDOWN_21954 = 83;
int _48M_SOCK_CONNECT_21955 = 84;
int _48M_SOCK_SEND_21956 = 85;
int _48M_SOCK_RECV_21957 = 86;
int _48M_SOCK_BIND_21958 = 87;
int _48M_SOCK_LISTEN_21959 = 88;
int _48M_SOCK_ACCEPT_21960 = 89;
int _48M_SOCK_SETSOCKOPT_21961 = 90;
int _48M_SOCK_GETSOCKOPT_21962 = 91;
int _48M_SOCK_SELECT_21963 = 92;
int _48M_SOCK_SENDTO_21964 = 93;
int _48M_SOCK_RECVFROM_21965 = 94;
int _48M_SOCK_ERROR_CODE_21967 = 96;
int _48M_SOCK_INFO_21968 = 4;
int _48OK_21972 = 0;
int _48ERR_ACCESS_21973 = -1;
int _48ERR_ADDRINUSE_21974 = -2;
int _48ERR_ADDRNOTAVAIL_21975 = -3;
int _48ERR_AFNOSUPPORT_21976 = -4;
int _48ERR_AGAIN_21977 = -5;
int _48ERR_ALREADY_21978 = -6;
int _48ERR_CONNABORTED_21979 = -7;
int _48ERR_CONNREFUSED_21980 = -8;
int _48ERR_CONNRESET_21981 = -9;
int _48ERR_DESTADDRREQ_21982 = -10;
int _48ERR_FAULT_21983 = -11;
int _48ERR_HOSTUNREACH_21984 = -12;
int _48ERR_INPROGRESS_21985 = -13;
int _48ERR_INTR_21986 = -14;
int _48ERR_INVAL_21987 = -15;
int _48ERR_IO_21988 = -16;
int _48ERR_ISCONN_21989 = -17;
int _48ERR_ISDIR_21990 = -18;
int _48ERR_LOOP_21991 = -19;
int _48ERR_MFILE_21992 = -20;
int _48ERR_MSGSIZE_21993 = -21;
int _48ERR_NAMETOOLONG_21994 = -22;
int _48ERR_NETDOWN_21995 = -23;
int _48ERR_NETRESET_21996 = -24;
int _48ERR_NETUNREACH_21998 = -25;
int _48ERR_NFILE_22000 = -26;
int _48ERR_NOBUFS_22002 = -27;
int _48ERR_NOENT_22004 = -28;
int _48ERR_NOTCONN_22006 = -29;
int _48ERR_NOTDIR_22008 = -30;
int _48ERR_NOTINITIALISED_22010 = -31;
int _48ERR_NOTSOCK_22012 = -32;
int _48ERR_OPNOTSUPP_22015 = -33;
int _48ERR_PROTONOSUPPORT_22018 = -34;
int _48ERR_PROTOTYPE_22021 = -35;
int _48ERR_ROFS_22024 = -36;
int _48ERR_SHUTDOWN_22027 = -37;
int _48ERR_SOCKTNOSUPPORT_22030 = -38;
int _48ERR_TIMEDOUT_22033 = -39;
int _48ERR_WOULDBLOCK_22036 = -40;
int _48ESOCK_UNDEFINED_VALUE_22039 = -9999;
int _48ESOCK_UNKNOWN_FLAG_22042 = -9998;
int _48ESOCK_TYPE_AF_22045 = 1;
int _48ESOCK_TYPE_TYPE_22047 = 2;
int _48ESOCK_TYPE_OPTION_22049 = 3;
int _48EAF_UNSPEC_22051 = 6;
int _48EAF_UNIX_22053 = 1;
int _48EAF_INET_22054 = 2;
int _48EAF_INET6_22055 = 3;
int _48EAF_APPLETALK_22056 = 4;
int _48EAF_BTH_22058 = 5;
int _48ESOCK_STREAM_22060 = 1;
int _48ESOCK_DGRAM_22061 = 2;
int _48ESOCK_RAW_22062 = 3;
int _48ESOCK_RDM_22063 = 4;
int _48ESOCK_SEQPACKET_22064 = 5;
int _48sockinfo_22065 = NOVALUE;
int _48AF_UNSPEC_22068 = NOVALUE;
int _48AF_UNIX_22070 = NOVALUE;
int _48AF_INET_22072 = NOVALUE;
int _48AF_INET6_22074 = NOVALUE;
int _48AF_APPLETALK_22076 = NOVALUE;
int _48AF_BTH_22078 = NOVALUE;
int _48SOCK_STREAM_22082 = NOVALUE;
int _48SOCK_DGRAM_22084 = NOVALUE;
int _48SOCK_RAW_22086 = NOVALUE;
int _48SOCK_RDM_22088 = NOVALUE;
int _48SOCK_SEQPACKET_22090 = NOVALUE;
int _48SELECT_SOCKET_22092 = 1;
int _48SELECT_IS_READABLE_22093 = 2;
int _48SELECT_IS_WRITABLE_22094 = 3;
int _48SELECT_IS_ERROR_22095 = 4;
int _48SD_SEND_22096 = 0;
int _48SD_RECEIVE_22098 = 1;
int _48SD_BOTH_22099 = 2;
int _48ESOL_SOCKET_22100 = 1;
int _48ESO_DEBUG_22101 = 2;
int _48ESO_ACCEPTCONN_22102 = 3;
int _48ESO_REUSEADDR_22103 = 4;
int _48ESO_KEEPALIVE_22104 = 5;
int _48ESO_DONTROUTE_22105 = 6;
int _48ESO_BROADCAST_22106 = 7;
int _48ESO_LINGER_22108 = 8;
int _48ESO_SNDBUF_22110 = 9;
int _48ESO_RCVBUF_22112 = 10;
int _48ESO_SNDLOWAT_22114 = 11;
int _48ESO_RCVLOWAT_22116 = 12;
int _48ESO_SNDTIMEO_22118 = 13;
int _48ESO_RCVTIMEO_22120 = 14;
int _48ESO_ERROR_22122 = 15;
int _48ESO_TYPE_22124 = 16;
int _48ESO_OOBINLINE_22126 = 17;
int _48ESO_USELOOPBACK_22128 = 18;
int _48ESO_DONTLINGER_22130 = 19;
int _48ESO_REUSEPORT_22132 = 20;
int _48ESO_CONNDATA_22134 = 21;
int _48ESO_CONNOPT_22136 = 22;
int _48ESO_DISCDATA_22138 = 23;
int _48ESO_DISCOPT_22140 = 24;
int _48ESO_CONNDATALEN_22142 = 25;
int _48ESO_CONNOPTLEN_22144 = 26;
int _48ESO_DISCDATALEN_22146 = 27;
int _48ESO_DISCOPTLEN_22148 = 28;
int _48ESO_OPENTYPE_22150 = 29;
int _48ESO_MAXDG_22152 = 30;
int _48ESO_MAXPATHDG_22154 = 31;
int _48ESO_SYNCHRONOUS_ALTERT_22156 = 32;
int _48ESO_SYNCHRONOUS_NONALERT_22157 = 33;
int _48ESO_SNDBUFFORCE_22158 = 34;
int _48ESO_RCVBUFFORCE_22159 = 35;
int _48ESO_NO_CHECK_22160 = 36;
int _48ESO_PRIORITY_22161 = 37;
int _48ESO_BSDCOMPAT_22162 = 38;
int _48ESO_PASSCRED_22163 = 39;
int _48ESO_PEERCRED_22164 = 40;
int _48ESO_SECURITY_AUTHENTICATION_22165 = 41;
int _48ESO_SECURITY_ENCRYPTION_TRANSPORT_22167 = 42;
int _48ESO_SECURITY_ENCRYPTION_NETWORK_22169 = 43;
int _48ESO_BINDTODEVICE_22171 = 44;
int _48ESO_ATTACH_FILTER_22173 = 45;
int _48ESO_DETACH_FILTER_22175 = 46;
int _48ESO_PEERNAME_22177 = 47;
int _48ESO_TIMESTAMP_22179 = 48;
int _48ESCM_TIMESTAMP_22181 = 49;
int _48ESO_PEERSEC_22183 = 50;
int _48ESO_PASSSEC_22185 = 51;
int _48ESO_TIMESTAMPNS_22187 = 52;
int _48ESCM_TIMESTAMPNS_22189 = 53;
int _48ESO_MARK_22191 = 54;
int _48ESO_TIMESTAMPING_22193 = 55;
int _48ESCM_TIMESTAMPING_22195 = 56;
int _48ESO_PROTOCOL_22197 = 57;
int _48ESO_DOMAIN_22199 = 58;
int _48ESO_RXQ_OVFL_22201 = 59;
int _48SOL_SOCKET_22205 = NOVALUE;
int _48SO_DEBUG_22207 = NOVALUE;
int _48SO_ACCEPTCONN_22209 = NOVALUE;
int _48SO_REUSEADDR_22211 = NOVALUE;
int _48SO_KEEPALIVE_22213 = NOVALUE;
int _48SO_DONTROUTE_22215 = NOVALUE;
int _48SO_BROADCAST_22217 = NOVALUE;
int _48SO_LINGER_22219 = NOVALUE;
int _48SO_SNDBUF_22221 = NOVALUE;
int _48SO_RCVBUF_22223 = NOVALUE;
int _48SO_SNDLOWAT_22225 = NOVALUE;
int _48SO_RCVLOWAT_22227 = NOVALUE;
int _48SO_SNDTIMEO_22229 = NOVALUE;
int _48SO_RCVTIMEO_22231 = NOVALUE;
int _48SO_ERROR_22233 = NOVALUE;
int _48SO_TYPE_22235 = NOVALUE;
int _48SO_OOBINLINE_22237 = NOVALUE;
int _48SO_USELOOPBACK_22239 = NOVALUE;
int _48SO_DONTLINGER_22241 = NOVALUE;
int _48SO_REUSEPORT_22243 = NOVALUE;
int _48SO_CONNDATA_22245 = NOVALUE;
int _48SO_CONNOPT_22247 = NOVALUE;
int _48SO_DISCDATA_22249 = NOVALUE;
int _48SO_DISCOPT_22251 = NOVALUE;
int _48SO_CONNDATALEN_22253 = NOVALUE;
int _48SO_CONNOPTLEN_22255 = NOVALUE;
int _48SO_DISCDATALEN_22257 = NOVALUE;
int _48SO_DISCOPTLEN_22259 = NOVALUE;
int _48SO_OPENTYPE_22261 = NOVALUE;
int _48SO_MAXDG_22263 = NOVALUE;
int _48SO_MAXPATHDG_22265 = NOVALUE;
int _48SO_SYNCHRONOUS_ALTERT_22267 = NOVALUE;
int _48SO_SYNCHRONOUS_NONALERT_22269 = NOVALUE;
int _48SO_SNDBUFFORCE_22271 = NOVALUE;
int _48SO_RCVBUFFORCE_22273 = NOVALUE;
int _48SO_NO_CHECK_22275 = NOVALUE;
int _48SO_PRIORITY_22277 = NOVALUE;
int _48SO_BSDCOMPAT_22279 = NOVALUE;
int _48SO_PASSCRED_22281 = NOVALUE;
int _48SO_PEERCRED_22283 = NOVALUE;
int _48SO_SECURITY_AUTHENTICATION_22285 = NOVALUE;
int _48SO_SECURITY_ENCRYPTION_TRANSPORT_22287 = NOVALUE;
int _48SO_SECURITY_ENCRYPTION_NETWORK_22289 = NOVALUE;
int _48SO_BINDTODEVICE_22291 = NOVALUE;
int _48SO_ATTACH_FILTER_22293 = NOVALUE;
int _48SO_DETACH_FILTER_22295 = NOVALUE;
int _48SO_PEERNAME_22297 = NOVALUE;
int _48SO_TIMESTAMP_22299 = NOVALUE;
int _48SCM_TIMESTAMP_22301 = NOVALUE;
int _48SO_PEERSEC_22303 = NOVALUE;
int _48SO_PASSSEC_22305 = NOVALUE;
int _48SO_TIMESTAMPNS_22307 = NOVALUE;
int _48SCM_TIMESTAMPNS_22309 = NOVALUE;
int _48SO_MARK_22311 = NOVALUE;
int _48SO_TIMESTAMPING_22313 = NOVALUE;
int _48SCM_TIMESTAMPING_22315 = NOVALUE;
int _48SO_PROTOCOL_22317 = NOVALUE;
int _48SO_DOMAIN_22319 = NOVALUE;
int _48SO_RXQ_OVFL_22321 = NOVALUE;
int _48MSG_OOB_22323 = 1;
int _48MSG_PEEK_22324 = 2;
int _48MSG_DONTROUTE_22325 = 4;
int _48MSG_TRYHARD_22326 = 4;
int _48MSG_CTRUNC_22327 = 8;
int _48MSG_PROXY_22328 = 16;
int _48MSG_TRUNC_22329 = 32;
int _48MSG_DONTWAIT_22330 = 64;
int _48MSG_EOR_22332 = 128;
int _48MSG_WAITALL_22334 = 256;
int _48MSG_FIN_22336 = 512;
int _48MSG_SYN_22338 = 1024;
int _48MSG_CONFIRM_22340 = 2048;
int _48MSG_RST_22341 = 4096;
int _48MSG_ERRQUEUE_22343 = 8192;
int _48MSG_NOSIGNAL_22345 = 16384;
int _48MSG_MORE_22347 = 32768;
int _48SOCKET_SOCKET_22349 = 1;
int _48SOCKET_SOCKADDR_IN_22350 = 2;
int _48delete_socket_rid_22378 = NOVALUE;
int _50FIFO_22546 = 1;
int _50FILO_22547 = 2;
int _50type_tag_22548 = 1;
int _50stack_type_22549 = 2;
int _50data_22550 = 3;
int _50type_is_stack_22551 = NOVALUE;
int _51M_SLEEP_22878 = 64;
int _53M_SOCK_GETHOSTBYNAME_22928 = 79;
int _53M_SOCK_GETHOSTBYADDR_22930 = 80;
int _53ADDR_FLAGS_22932 = 1;
int _53ADDR_FAMILY_22933 = 2;
int _53ADDR_TYPE_22934 = 3;
int _53ADDR_PROTOCOL_22935 = 4;
int _53ADDR_ADDRESS_22936 = 5;
int _53HOST_OFFICIAL_NAME_22937 = 1;
int _53HOST_ALIASES_22938 = 2;
int _53HOST_IPS_22939 = 3;
int _53HOST_TYPE_22940 = 4;
int _53DNS_QUERY_STANDARD_22941 = 0;
int _53DNS_QUERY_ACCEPT_TRUNCATED_RESPONSE_22942 = 1;
int _53DNS_QUERY_USE_TCP_ONLY_22943 = 2;
int _53DNS_QUERY_NO_RECURSION_22944 = 4;
int _53DNS_QUERY_BYPASS_CACHE_22945 = 8;
int _53DNS_QUERY_NO_WIRE_QUERY_22946 = 16;
int _53DNS_QUERY_NO_LOCAL_NAME_22947 = 32;
int _53DNS_QUERY_NO_HOSTS_FILE_22948 = 64;
int _53DNS_QUERY_NO_NETBT_22949 = 128;
int _53DNS_QUERY_WIRE_ONLY_22950 = 256;
int _53DNS_QUERY_RETURN_MESSAGE_22951 = 512;
int _53DNS_QUERY_TREAT_AS_FQDN_22952 = 4096;
int _53DNS_QUERY_DONT_RESET_TTL_VALUES_22953 = 1048576;
int _53DNS_QUERY_RESERVED_22954 = NOVALUE;
int _53NS_C_IN_22956 = 1;
int _53NS_C_ANY_22957 = 255;
int _53NS_KT_RSA_22959 = 1;
int _53NS_KT_DH_22960 = 2;
int _53NS_KT_DSA_22961 = 3;
int _53NS_KT_PRIVATE_22962 = 254;
int _53NS_T_A_22964 = 1;
int _53NS_T_NS_22965 = 2;
int _53NS_T_PTR_22966 = 12;
int _53NS_T_MX_22967 = 15;
int _53NS_T_AAAA_22968 = 28;
int _53NS_T_A6_22969 = 38;
int _53NS_T_ANY_22970 = 255;
int _55PAIR_SEP_A_22987 = 38;
int _55PAIR_SEP_B_22988 = 59;
int _55HEX_SIG_22989 = 37;
int _55WHITESPACE_22990 = 43;
int _55VALUE_SEP_22991 = 61;
int _55URL_PROTOCOL_23034 = 1;
int _55URL_HOSTNAME_23035 = 2;
int _55URL_PORT_23036 = 3;
int _55URL_PATH_23037 = 4;
int _55URL_USER_23038 = 5;
int _55URL_PASSWORD_23039 = 6;
int _55URL_QUERY_STRING_23040 = 7;
int _55alphanum_23146 = NOVALUE;
int _55hexnums_23148 = NOVALUE;
int _54USER_AGENT_HEADER_23245 = NOVALUE;
int _54R_HOST_23253 = 1;
int _54R_PORT_23254 = 2;
int _54R_PATH_23255 = 3;
int _54R_REQUEST_23256 = 4;
int _54FR_SIZE_23257 = 4;
int _54ERR_MALFORMED_URL_23258 = -1;
int _54ERR_INVALID_PROTOCOL_23259 = -2;
int _54ERR_INVALID_DATA_23261 = -3;
int _54ERR_INVALID_DATA_ENCODING_23263 = -4;
int _54ERR_HOST_LOOKUP_FAILED_23265 = -5;
int _54ERR_CONNECT_FAILED_23267 = -6;
int _54ERR_SEND_FAILED_23269 = -7;
int _54ERR_RECEIVE_FAILED_23270 = -8;
int _54FORM_URLENCODED_23271 = 1;
int _54MULTIPART_FORM_DATA_23272 = 2;
int _54ENCODE_NONE_23273 = 0;
int _54ENCODE_BASE64_23274 = 1;
int _54ENCODING_STRINGS_23275 = NOVALUE;
int _54rand_chars_23430 = NOVALUE;
int _54rand_chars_len_23432 = NOVALUE;
int _56MB_ABORTRETRYIGNORE_23656 = 2;
int _56MB_APPLMODAL_23657 = 0;
int _56MB_DEFAULT_DESKTOP_ONLY_23658 = 131072;
int _56MB_DEFBUTTON1_23659 = 0;
int _56MB_DEFBUTTON2_23660 = 256;
int _56MB_DEFBUTTON3_23661 = 512;
int _56MB_DEFBUTTON4_23662 = 768;
int _56MB_HELP_23664 = 16384;
int _56MB_ICONASTERISK_23665 = 64;
int _56MB_ICONERROR_23666 = 16;
int _56MB_ICONEXCLAMATION_23667 = 48;
int _56MB_ICONHAND_23668 = 16;
int _56MB_ICONINFORMATION_23669 = 64;
int _56MB_ICONQUESTION_23670 = 32;
int _56MB_ICONSTOP_23671 = 16;
int _56MB_ICONWARNING_23672 = 48;
int _56MB_OK_23673 = 0;
int _56MB_OKCANCEL_23674 = 1;
int _56MB_RETRYCANCEL_23675 = 5;
int _56MB_RIGHT_23676 = 524288;
int _56MB_RTLREADING_23678 = 1048576;
int _56MB_SERVICE_NOTIFICATION_23679 = 262144;
int _56MB_SETFOREGROUND_23680 = 65536;
int _56MB_SYSTEMMODAL_23682 = 4096;
int _56MB_TASKMODAL_23683 = 8192;
int _56MB_YESNO_23684 = 4;
int _56MB_YESNOCANCEL_23685 = 3;
int _56IDABORT_23686 = 3;
int _56IDCANCEL_23687 = 2;
int _56IDIGNORE_23688 = 5;
int _56IDNO_23689 = 7;
int _56IDOK_23690 = 1;
int _56IDRETRY_23691 = 4;
int _56IDYES_23692 = 6;
int _56lib_23693 = NOVALUE;
int _56msgbox_id_23694 = NOVALUE;
int _56get_active_id_23695 = NOVALUE;
int _57SND_DEFAULT_23743 = 0;
int _57SND_STOP_23744 = 16;
int _57SND_QUESTION_23745 = 32;
int _57SND_EXCLAMATION_23746 = 48;
int _57SND_ASTERISK_23747 = 64;
int _57xMessageBeep_23748 = NOVALUE;
int _57xUser32_23749 = NOVALUE;
int _59M_ALLOC_23777 = 16;
int _59M_FREE_23778 = 17;
int _59M_ALLOC_LOW_23779 = 32;
int _59M_FREE_LOW_23780 = 33;
int _59M_INTERRUPT_23781 = 34;
int _59M_SET_RAND_23782 = 35;
int _59M_USE_VESA_23783 = 36;
int _59M_CRASH_MESSAGE_23784 = 37;
int _59M_TICK_RATE_23785 = 38;
int _59M_GET_VECTOR_23786 = 39;
int _59M_SET_VECTOR_23787 = 40;
int _59M_LOCK_MEMORY_23788 = 41;
int _59M_A_TO_F64_23789 = 46;
int _59M_F64_TO_A_23790 = 47;
int _59M_A_TO_F32_23791 = 48;
int _59M_F32_TO_A_23792 = 49;
int _59M_CRASH_FILE_23793 = 57;
int _59M_CRASH_ROUTINE_23794 = 66;
int _59MAX_ADDR_23796 = NOVALUE;
int _59LOW_ADDR_23799 = NOVALUE;
int _59REG_LIST_SIZE_23829 = 10;
int _59REG_DI_23830 = 1;
int _59REG_SI_23831 = 2;
int _59REG_BP_23832 = 3;
int _59REG_BX_23833 = 4;
int _59REG_DX_23834 = 5;
int _59REG_CX_23835 = 6;
int _59REG_AX_23836 = 7;
int _59REG_FLAGS_23837 = 8;
int _59REG_ES_23838 = 9;
int _59REG_DS_23839 = 10;
int _59mem_23871 = NOVALUE;
int _59allocate_inlined_allocate_at_5045_23873 = NOVALUE;
int _59check_calls_23960 = NOVALUE;
int _58always_linked_list_23970 = NOVALUE;
int _58NULL_24035 = 0;
int _58SIZE_OF_STRUCT_24036 = 16;
int _58MAX_LENGTH_24037 = 268435455;
int _58SIGN_MASK_24039 = NOVALUE;
int _58SIGN_FLAG_24041 = NOVALUE;
int _58DOUBLE_FLAG_24042 = NOVALUE;
int _58INT_FLAG_24044 = NOVALUE;
int _58UINT_FLAG_24046 = NOVALUE;
int _58FLOAT_FLAG_24048 = NOVALUE;
int _58CSTRING_24050 = NOVALUE;
int _58CBYTES_24051 = NOVALUE;
int _1VERSION_24309 = 3;
int _1high_address_24312 = NOVALUE;
int _1data_24313 = NOVALUE;
int _1free_list_24314 = NOVALUE;
int _1state_inlined_new_at_1228_25245 = NOVALUE;
int _1new_inlined_new_at_1228_25246 = NOVALUE;
int _1options_inlined_new_at_4378_25256 = NOVALUE;
int _1new_1__tmp_at4381_25257 = NOVALUE;
int _1new_2__tmp_at4381_25258 = NOVALUE;
int _1options_inlined_new_at_4409_25260 = NOVALUE;
int _1new_1__tmp_at4412_25261 = NOVALUE;
int _1new_2__tmp_at4412_25262 = NOVALUE;
int _1options_inlined_new_at_4440_25264 = NOVALUE;
int _1new_1__tmp_at4443_25265 = NOVALUE;
int _1new_2__tmp_at4443_25266 = NOVALUE;


struct routine_list _00[] = {
  {"set_return_linked_list", (int (*)())_1set_return_linked_list, 0, 1, 1, 1, 6, 0},
  {"get_return_linked_list", (int (*)())_1get_return_linked_list, 1, 1, 0, 1, 6, 0},
  {"get_version", (int (*)())_1get_version, 2, 1, 0, 1, 6, 0},
  {"init", (int (*)())_1init, 3, 1, 0, 1, 6, 0},
  {"get_high_address", (int (*)())_1get_high_address, 4, 1, 0, 1, 6, 0},
  {"set_high_address", (int (*)())_1set_high_address, 5, 1, 1, 0, 5, 0},
  {"get_address", (int (*)())_1get_address, 6, 1, 2, 0, 5, 0},
  {"register_data", (int (*)())_1register_data, 7, 1, 1, 0, 5, 0},
  {"retval", (int (*)())_1retval, 8, 1, 1, 0, 5, 0},
  {"length_of_data", (int (*)())_1length_of_data, 9, 1, 0, 1, 6, 0},
  {"is_free", (int (*)())_1is_free, 10, 1, 1, 1, 6, 0},
  {"access_free_list", (int (*)())_1access_free_list, 11, 1, 0, 1, 6, 0},
  {"generic_free", (int (*)())_1generic_free, 12, 1, 2, 1, 6, 0},
  {"delete_linked_list", (int (*)())_1delete_linked_list, 13, 1, 1, 1, 6, 0},
  {"free_linked_lists", (int (*)())_1free_linked_lists, 14, 1, 3, 1, 6, 0},
  {"register_linked_list", (int (*)())_1register_linked_list, 15, 1, 2, 1, 6, 0},
  {"new_linked_list", (int (*)())_1new_linked_list, 16, 1, 2, 1, 6, 0},
  {"store_linked_list", (int (*)())_1store_linked_list, 17, 1, 3, 1, 6, 0},
  {"access_linked_list", (int (*)())_1access_linked_list, 18, 1, 1, 1, 6, 0},
  {"at_linked_list", (int (*)())_1at_linked_list, 19, 1, 2, 1, 6, 0},
  {"free_linked_list_dll", (int (*)())_1free_linked_list_dll, 20, 1, 2, 1, 6, 0},
  {"length_linked_list", (int (*)())_1length_linked_list, 21, 1, 1, 1, 6, 0},
  {"store_at_linked_list", (int (*)())_1store_at_linked_list, 22, 1, 4, 1, 6, 0},
  {"eu_repeat", (int (*)())_1eu_repeat, 23, 1, 2, 1, 6, 0},
  {"eu_mem_set", (int (*)())_1eu_mem_set, 24, 1, 4, 1, 6, 0},
  {"eu_mem_copy", (int (*)())_1eu_mem_copy, 25, 1, 5, 1, 6, 0},
  {"eu_add", (int (*)())_1eu_add, 26, 1, 2, 1, 6, 0},
  {"eu_subtract", (int (*)())_1eu_subtract, 27, 1, 2, 1, 6, 0},
  {"eu_multiply", (int (*)())_1eu_multiply, 28, 1, 2, 1, 6, 0},
  {"eu_divide", (int (*)())_1eu_divide, 29, 1, 2, 1, 6, 0},
  {"eu_negate", (int (*)())_1eu_negate, 30, 1, 1, 1, 6, 0},
  {"eu_not", (int (*)())_1eu_not, 31, 1, 1, 1, 6, 0},
  {"eu_equals", (int (*)())_1eu_equals, 32, 1, 2, 1, 6, 0},
  {"eu_and", (int (*)())_1eu_and, 33, 1, 2, 1, 6, 0},
  {"eu_or", (int (*)())_1eu_or, 34, 1, 2, 1, 6, 0},
  {"eu_xor", (int (*)())_1eu_xor, 35, 1, 2, 1, 6, 0},
  {"eu_question_mark", (int (*)())_1eu_question_mark, 36, 1, 1, 1, 6, 0},
  {"eu_abort", (int (*)())_1eu_abort, 37, 1, 1, 1, 6, 0},
  {"eu_and_bits", (int (*)())_1eu_and_bits, 38, 1, 2, 1, 6, 0},
  {"eu_append", (int (*)())_1eu_append, 39, 1, 2, 1, 6, 0},
  {"eu_arctan", (int (*)())_1eu_arctan, 40, 1, 1, 1, 6, 0},
  {"eu_atom", (int (*)())_1eu_atom, 41, 1, 1, 1, 6, 0},
  {"eu_c_func", (int (*)())_1eu_c_func, 42, 1, 2, 1, 6, 0},
  {"eu_c_proc", (int (*)())_1eu_c_proc, 43, 1, 2, 1, 6, 0},
  {"eu_call", (int (*)())_1eu_call, 44, 1, 2, 1, 6, 0},
  {"eu_clear_screen", (int (*)())_1eu_clear_screen, 45, 1, 0, 1, 6, 0},
  {"eu_close", (int (*)())_1eu_close, 46, 1, 1, 1, 6, 0},
  {"eu_command_line", (int (*)())_1eu_command_line, 47, 1, 0, 1, 6, 0},
  {"eu_compare", (int (*)())_1eu_compare, 48, 1, 2, 1, 6, 0},
  {"eu_concat", (int (*)())_1eu_concat, 49, 1, 2, 1, 6, 0},
  {"eu_cos", (int (*)())_1eu_cos, 50, 1, 1, 1, 6, 0},
  {"eu_date", (int (*)())_1eu_date, 51, 1, 0, 1, 6, 0},
  {"eu_equal", (int (*)())_1eu_equal, 52, 1, 2, 1, 6, 0},
  {"eu_find_from", (int (*)())_1eu_find_from, 53, 1, 3, 1, 6, 0},
  {"eu_find", (int (*)())_1eu_find, 54, 1, 3, 1, 6, 0},
  {"eu_floor", (int (*)())_1eu_floor, 55, 1, 1, 1, 6, 0},
  {"eu_integer_division", (int (*)())_1eu_integer_division, 56, 1, 2, 1, 6, 0},
  {"eu_get_key", (int (*)())_1eu_get_key, 57, 1, 0, 1, 6, 0},
  {"eu_getc", (int (*)())_1eu_getc, 58, 1, 1, 1, 6, 0},
  {"eu_getenv", (int (*)())_1eu_getenv, 59, 1, 1, 1, 6, 0},
  {"eu_gets", (int (*)())_1eu_gets, 60, 1, 1, 1, 6, 0},
  {"eu_integer", (int (*)())_1eu_integer, 61, 1, 1, 1, 6, 0},
  {"eu_length", (int (*)())_1eu_length, 62, 1, 1, 1, 6, 0},
  {"eu_log", (int (*)())_1eu_log, 63, 1, 1, 1, 6, 0},
  {"eu_machine_func", (int (*)())_1eu_machine_func, 64, 1, 2, 1, 6, 0},
  {"eu_machine_proc", (int (*)())_1eu_machine_proc, 65, 1, 2, 1, 6, 0},
  {"eu_match_from", (int (*)())_1eu_match_from, 66, 1, 3, 1, 6, 0},
  {"eu_match", (int (*)())_1eu_match, 67, 1, 3, 1, 6, 0},
  {"eu_not_bits", (int (*)())_1eu_not_bits, 68, 1, 1, 1, 6, 0},
  {"eu_object", (int (*)())_1eu_object, 69, 1, 1, 1, 6, 0},
  {"eu_open", (int (*)())_1eu_open, 70, 1, 2, 1, 6, 0},
  {"eu_open_str", (int (*)())_1eu_open_str, 71, 1, 3, 1, 6, 0},
  {"eu_or_bits", (int (*)())_1eu_or_bits, 72, 1, 2, 1, 6, 0},
  {"eu_peek", (int (*)())_1eu_peek, 73, 1, 1, 1, 6, 0},
  {"eu_peek4s", (int (*)())_1eu_peek4s, 74, 1, 1, 1, 6, 0},
  {"eu_peek4u", (int (*)())_1eu_peek4u, 75, 1, 1, 1, 6, 0},
  {"eu_platform", (int (*)())_1eu_platform, 76, 1, 0, 1, 6, 0},
  {"eu_poke", (int (*)())_1eu_poke, 77, 1, 2, 1, 6, 0},
  {"eu_poke4", (int (*)())_1eu_poke4, 78, 1, 2, 1, 6, 0},
  {"eu_position", (int (*)())_1eu_position, 79, 1, 2, 1, 6, 0},
  {"eu_power", (int (*)())_1eu_power, 80, 1, 2, 1, 6, 0},
  {"eu_prepend", (int (*)())_1eu_prepend, 81, 1, 2, 1, 6, 0},
  {"eu_print", (int (*)())_1eu_print, 82, 1, 2, 1, 6, 0},
  {"eu_printf", (int (*)())_1eu_printf, 83, 1, 3, 1, 6, 0},
  {"eu_puts", (int (*)())_1eu_puts, 84, 1, 2, 1, 6, 0},
  {"eu_rand", (int (*)())_1eu_rand, 85, 1, 1, 1, 6, 0},
  {"eu_remainder", (int (*)())_1eu_remainder, 86, 1, 2, 1, 6, 0},
  {"eu_sequence", (int (*)())_1eu_sequence, 87, 1, 1, 1, 6, 0},
  {"eu_sin", (int (*)())_1eu_sin, 88, 1, 1, 1, 6, 0},
  {"eu_sprintf", (int (*)())_1eu_sprintf, 89, 1, 2, 1, 6, 0},
  {"eu_sqrt", (int (*)())_1eu_sqrt, 90, 1, 1, 1, 6, 0},
  {"eu_subscript", (int (*)())_1eu_subscript, 91, 1, 3, 1, 6, 0},
  {"eu_system", (int (*)())_1eu_system, 92, 1, 2, 1, 6, 0},
  {"eu_system_exec", (int (*)())_1eu_system_exec, 93, 1, 2, 1, 6, 0},
  {"eu_tan", (int (*)())_1eu_tan, 94, 1, 1, 1, 6, 0},
  {"eu_time", (int (*)())_1eu_time, 95, 1, 0, 1, 6, 0},
  {"eu_xor_bits", (int (*)())_1eu_xor_bits, 96, 1, 2, 1, 6, 0},
  {"eu_hash", (int (*)())_1eu_hash, 97, 1, 2, 1, 6, 0},
  {"eu_head", (int (*)())_1eu_head, 98, 1, 2, 1, 6, 0},
  {"eu_include_paths", (int (*)())_1eu_include_paths, 99, 1, 1, 1, 6, 0},
  {"eu_insert", (int (*)())_1eu_insert, 100, 1, 3, 1, 6, 0},
  {"eu_peek2s", (int (*)())_1eu_peek2s, 101, 1, 1, 1, 6, 0},
  {"eu_peek2u", (int (*)())_1eu_peek2u, 102, 1, 1, 1, 6, 0},
  {"eu_peek_string", (int (*)())_1eu_peek_string, 103, 1, 1, 1, 6, 0},
  {"eu_peeks", (int (*)())_1eu_peeks, 104, 1, 1, 1, 6, 0},
  {"eu_poke2", (int (*)())_1eu_poke2, 105, 1, 2, 1, 6, 0},
  {"eu_remove", (int (*)())_1eu_remove, 106, 1, 3, 1, 6, 0},
  {"eu_replace", (int (*)())_1eu_replace, 107, 1, 4, 1, 6, 0},
  {"eu_splice", (int (*)())_1eu_splice, 108, 1, 3, 1, 6, 0},
  {"eu_tail", (int (*)())_1eu_tail, 109, 1, 2, 1, 6, 0},
  {"eu_call_func_std", (int (*)())_1eu_call_func_std, 110, 1, 2, 1, 6, 0},
  {"eu_call_func_val", (int (*)())_1eu_call_func_val, 111, 1, 2, 1, 6, 0},
  {"eu_call_func", (int (*)())_1eu_call_func, 112, 1, 2, 1, 6, 0},
  {"eu_call_proc", (int (*)())_1eu_call_proc, 113, 1, 2, 1, 6, 0},
  {"eu_routine_id", (int (*)())_1eu_routine_id, 114, 1, 1, 1, 6, 0},
  {"eu_routine_id_str", (int (*)())_1eu_routine_id_str, 115, 1, 2, 1, 6, 0},
  {"syncolor_new", (int (*)())_2syncolor_new, 116, 2, 0, 1, 13, 0},
  {"base64_encode", (int (*)())_2base64_encode, 117, 2, 2, 1, 13, 0},
  {"base64_decode", (int (*)())_2base64_decode, 118, 2, 1, 1, 13, 0},
  {"console_allow_break", (int (*)())_2console_allow_break, 119, 2, 1, 1, 13, 0},
  {"console_has_console", (int (*)())_2console_has_console, 120, 2, 0, 1, 13, 0},
  {"datetime_format", (int (*)())_2datetime_format, 121, 2, 2, 1, 13, 0},
  {"datetime_new", (int (*)())_2datetime_new, 122, 2, 6, 1, 13, 0},
  {"datetime_datetime", (int (*)())_2datetime_datetime, 123, 2, 1, 1, 13, 0},
  {"datetime_parse", (int (*)())_2datetime_parse, 124, 2, 3, 1, 13, 0},
  {"datetime_add", (int (*)())_2datetime_add, 125, 2, 3, 1, 13, 0},
  {"stdget_get", (int (*)())_2stdget_get, 126, 2, 3, 1, 13, 0},
  {"graphics_wrap", (int (*)())_2graphics_wrap, 127, 2, 1, 1, 13, 0},
  {"locale_get", (int (*)())_2locale_get, 128, 2, 0, 1, 13, 0},
  {"locale_datetime", (int (*)())_2locale_datetime, 129, 2, 2, 1, 13, 0},
  {"locale_set", (int (*)())_2locale_set, 130, 2, 1, 1, 13, 0},
  {"map_new", (int (*)())_2map_new, 131, 2, 1, 1, 13, 0},
  {"map_get", (int (*)())_2map_get, 132, 2, 3, 1, 13, 0},
  {"map_size", (int (*)())_2map_size, 133, 2, 1, 1, 13, 0},
  {"map_clear", (int (*)())_2map_clear, 134, 2, 1, 1, 13, 0},
  {"map_remove", (int (*)())_2map_remove, 135, 2, 2, 1, 13, 0},
  {"map_calc_hash", (int (*)())_2map_calc_hash, 136, 2, 2, 1, 13, 0},
  {"map_compare", (int (*)())_2map_compare, 137, 2, 3, 1, 13, 0},
  {"math_sum", (int (*)())_2math_sum, 138, 2, 1, 1, 13, 0},
  {"pipeio_create", (int (*)())_2pipeio_create, 139, 2, 0, 1, 13, 0},
  {"pipeio_close", (int (*)())_2pipeio_close, 140, 2, 1, 1, 13, 0},
  {"regex_new", (int (*)())_2regex_new, 141, 2, 2, 1, 13, 0},
  {"regex_escape", (int (*)())_2regex_escape, 142, 2, 1, 1, 13, 0},
  {"regex_find_all", (int (*)())_2regex_find_all, 143, 2, 5, 1, 13, 0},
  {"regex_is_match", (int (*)())_2regex_is_match, 144, 2, 4, 1, 13, 0},
  {"regex_split", (int (*)())_2regex_split, 145, 2, 4, 1, 13, 0},
  {"regex_find_replace", (int (*)())_2regex_find_replace, 146, 2, 5, 1, 13, 0},
  {"regex_get_ovector_size", (int (*)())_2regex_get_ovector_size, 147, 2, 2, 1, 13, 0},
  {"regex_find", (int (*)())_2regex_find, 148, 2, 5, 1, 13, 0},
  {"search_find_all", (int (*)())_2search_find_all, 149, 2, 3, 1, 13, 0},
  {"search_find_replace", (int (*)())_2search_find_replace, 150, 2, 4, 1, 13, 0},
  {"stdseq_split", (int (*)())_2stdseq_split, 151, 2, 4, 1, 13, 0},
  {"sockets_create", (int (*)())_2sockets_create, 152, 2, 3, 1, 13, 0},
  {"sockets_close", (int (*)())_2sockets_close, 153, 2, 1, 1, 13, 0},
  {"stack_new", (int (*)())_2stack_new, 154, 2, 1, 1, 13, 0},
  {"stack_size", (int (*)())_2stack_size, 155, 2, 1, 1, 13, 0},
  {"stack_set", (int (*)())_2stack_set, 156, 2, 3, 1, 13, 0},
  {"stack_clear", (int (*)())_2stack_clear, 157, 2, 1, 1, 13, 0},
  {"stats_sum", (int (*)())_2stats_sum, 158, 2, 2, 1, 13, 0},
  {"text_format", (int (*)())_2text_format, 159, 2, 2, 1, 13, 0},
  {"text_wrap", (int (*)())_2text_wrap, 160, 2, 4, 1, 13, 0},
  {"text_escape", (int (*)())_2text_escape, 161, 2, 2, 1, 13, 0},
  {"wildcard_is_match", (int (*)())_2wildcard_is_match, 162, 2, 2, 1, 13, 0},
  {"url_parse", (int (*)())_2url_parse, 163, 2, 2, 1, 13, 0},
  {"url_encode", (int (*)())_2url_encode, 164, 2, 2, 1, 13, 0},
  {"url_decode", (int (*)())_2url_decode, 165, 2, 1, 1, 13, 0},
  {"lib_call_func", (int (*)())_2lib_call_func, 166, 2, 2, 1, 13, 0},
  {"lib_call_proc", (int (*)())_2lib_call_proc, 167, 2, 2, 1, 13, 0},
  {"lib_routine_id", (int (*)())_2lib_routine_id, 168, 2, 1, 1, 13, 0},
  {"platform_name", (int (*)())_3platform_name, 169, 3, 0, 1, 13, 0},
  {"version", (int (*)())_3version, 170, 3, 0, 1, 13, 0},
  {"version_major", (int (*)())_3version_major, 171, 3, 0, 1, 13, 0},
  {"version_minor", (int (*)())_3version_minor, 172, 3, 0, 1, 13, 0},
  {"version_patch", (int (*)())_3version_patch, 173, 3, 0, 1, 13, 0},
  {"version_node", (int (*)())_3version_node, 174, 3, 1, 1, 13, 0},
  {"version_revision", (int (*)())_3version_revision, 175, 3, 0, 1, 13, 0},
  {"version_date", (int (*)())_3version_date, 176, 3, 1, 1, 13, 0},
  {"version_type", (int (*)())_3version_type, 177, 3, 0, 1, 13, 0},
  {"version_string", (int (*)())_3version_string, 178, 3, 1, 1, 13, 0},
  {"version_string_short", (int (*)())_3version_string_short, 179, 3, 0, 1, 13, 0},
  {"version_string_long", (int (*)())_3version_string_long, 180, 3, 1, 1, 13, 0},
  {"euphoria_copyright", (int (*)())_3euphoria_copyright, 181, 3, 0, 1, 13, 0},
  {"pcre_copyright", (int (*)())_3pcre_copyright, 182, 3, 0, 1, 13, 0},
  {"all_copyrights", (int (*)())_3all_copyrights, 183, 3, 0, 1, 13, 0},
  {"start_time", (int (*)())_3start_time, 184, 3, 0, 1, 13, 0},
  {"set_colors", (int (*)())_5set_colors, 185, 5, 1, 1, 13, 0},
  {"init_class", (int (*)())_5init_class, 186, 5, 0, 1, 13, 0},
  {"new", (int (*)())_5new, 189, 5, 0, 1, 11, 0},
  {"reset", (int (*)())_5reset, 190, 5, 1, 1, 13, 0},
  {"SyntaxColor", (int (*)())_5SyntaxColor, 191, 5, 2, 1, 13, 0},
  {"sprint", (int (*)())_6sprint, 192, 6, 1, 1, 13, 0},
  {"trim_head", (int (*)())_6trim_head, 193, 6, 3, 1, 13, 0},
  {"trim_tail", (int (*)())_6trim_tail, 194, 6, 3, 1, 13, 0},
  {"trim", (int (*)())_6trim, 195, 6, 3, 1, 13, 0},
  {"set_encoding_properties", (int (*)())_6set_encoding_properties, 197, 6, 3, 1, 13, 0},
  {"get_encoding_properties", (int (*)())_6get_encoding_properties, 198, 6, 0, 1, 13, 0},
  {"lower", (int (*)())_6lower, 200, 6, 1, 1, 13, 0},
  {"upper", (int (*)())_6upper, 201, 6, 1, 1, 13, 0},
  {"proper", (int (*)())_6proper, 202, 6, 1, 1, 13, 0},
  {"keyvalues", (int (*)())_6keyvalues, 203, 6, 6, 1, 13, 0},
  {"escape", (int (*)())_6escape, 204, 6, 2, 1, 11, 0},
  {"quote", (int (*)())_6quote, 205, 6, 4, 1, 13, 0},
  {"dequote", (int (*)())_6dequote, 206, 6, 3, 1, 13, 0},
  {"format", (int (*)())_6format, 207, 6, 2, 1, 11, 0},
  {"wrap", (int (*)())_6wrap, 208, 6, 4, 1, 11, 0},
  {"char_test", (int (*)())_7char_test, 209, 7, 2, 1, 13, 0},
  {"set_default_charsets", (int (*)())_7set_default_charsets, 210, 7, 0, 1, 13, 0},
  {"get_charsets", (int (*)())_7get_charsets, 211, 7, 0, 1, 13, 0},
  {"set_charsets", (int (*)())_7set_charsets, 212, 7, 1, 1, 13, 0},
  {"boolean", (int (*)())_7boolean, 213, 7, 1, 1, 13, 0},
  {"t_boolean", (int (*)())_7t_boolean, 214, 7, 1, 1, 13, 0},
  {"t_alnum", (int (*)())_7t_alnum, 215, 7, 1, 1, 13, 0},
  {"t_identifier", (int (*)())_7t_identifier, 216, 7, 1, 1, 13, 0},
  {"t_alpha", (int (*)())_7t_alpha, 217, 7, 1, 1, 13, 0},
  {"t_ascii", (int (*)())_7t_ascii, 218, 7, 1, 1, 13, 0},
  {"t_cntrl", (int (*)())_7t_cntrl, 219, 7, 1, 1, 13, 0},
  {"t_digit", (int (*)())_7t_digit, 220, 7, 1, 1, 13, 0},
  {"t_graph", (int (*)())_7t_graph, 221, 7, 1, 1, 13, 0},
  {"t_specword", (int (*)())_7t_specword, 222, 7, 1, 1, 13, 0},
  {"t_bytearray", (int (*)())_7t_bytearray, 223, 7, 1, 1, 13, 0},
  {"t_lower", (int (*)())_7t_lower, 224, 7, 1, 1, 13, 0},
  {"t_print", (int (*)())_7t_print, 225, 7, 1, 1, 13, 0},
  {"t_display", (int (*)())_7t_display, 226, 7, 1, 1, 13, 0},
  {"t_punct", (int (*)())_7t_punct, 227, 7, 1, 1, 13, 0},
  {"t_space", (int (*)())_7t_space, 228, 7, 1, 1, 13, 0},
  {"t_upper", (int (*)())_7t_upper, 229, 7, 1, 1, 13, 0},
  {"t_xdigit", (int (*)())_7t_xdigit, 230, 7, 1, 1, 13, 0},
  {"t_vowel", (int (*)())_7t_vowel, 231, 7, 1, 1, 13, 0},
  {"t_consonant", (int (*)())_7t_consonant, 232, 7, 1, 1, 13, 0},
  {"integer_array", (int (*)())_7integer_array, 233, 7, 1, 1, 13, 0},
  {"t_text", (int (*)())_7t_text, 234, 7, 1, 1, 13, 0},
  {"number_array", (int (*)())_7number_array, 235, 7, 1, 1, 13, 0},
  {"sequence_array", (int (*)())_7sequence_array, 236, 7, 1, 1, 13, 0},
  {"ascii_string", (int (*)())_7ascii_string, 237, 7, 1, 1, 13, 0},
  {"string", (int (*)())_7string, 238, 7, 1, 1, 13, 0},
  {"cstring", (int (*)())_7cstring, 239, 7, 1, 1, 13, 0},
  {"int_to_bytes", (int (*)())_8int_to_bytes, 240, 8, 1, 1, 13, 0},
  {"bytes_to_int", (int (*)())_8bytes_to_int, 243, 8, 1, 1, 13, 0},
  {"int_to_bits", (int (*)())_8int_to_bits, 244, 8, 2, 1, 13, 0},
  {"bits_to_int", (int (*)())_8bits_to_int, 245, 8, 1, 1, 13, 0},
  {"atom_to_float64", (int (*)())_8atom_to_float64, 246, 8, 1, 1, 13, 0},
  {"atom_to_float32", (int (*)())_8atom_to_float32, 247, 8, 1, 1, 13, 0},
  {"float64_to_atom", (int (*)())_8float64_to_atom, 248, 8, 1, 1, 13, 0},
  {"float32_to_atom", (int (*)())_8float32_to_atom, 249, 8, 1, 1, 13, 0},
  {"hex_text", (int (*)())_8hex_text, 250, 8, 1, 1, 13, 0},
  {"set_decimal_mark", (int (*)())_8set_decimal_mark, 251, 8, 1, 1, 13, 0},
  {"to_number", (int (*)())_8to_number, 252, 8, 2, 1, 13, 0},
  {"to_integer", (int (*)())_8to_integer, 253, 8, 2, 1, 13, 0},
  {"to_string", (int (*)())_8to_string, 254, 8, 3, 1, 13, 0},
  {"find_any", (int (*)())_9find_any, 255, 9, 3, 1, 13, 0},
  {"match_any", (int (*)())_9match_any, 256, 9, 3, 1, 13, 0},
  {"find_each", (int (*)())_9find_each, 257, 9, 3, 1, 13, 0},
  {"find_all", (int (*)())_9find_all, 258, 9, 3, 1, 11, 0},
  {"find_all_but", (int (*)())_9find_all_but, 259, 9, 3, 1, 13, 0},
  {"find_nested", (int (*)())_9find_nested, 260, 9, 4, 1, 13, 0},
  {"rfind", (int (*)())_9rfind, 261, 9, 3, 1, 13, 0},
  {"find_replace", (int (*)())_9find_replace, 262, 9, 4, 1, 11, 0},
  {"match_replace", (int (*)())_9match_replace, 263, 9, 4, 1, 13, 0},
  {"binary_search", (int (*)())_9binary_search, 264, 9, 4, 1, 13, 0},
  {"match_all", (int (*)())_9match_all, 265, 9, 3, 1, 13, 0},
  {"rmatch", (int (*)())_9rmatch, 266, 9, 3, 1, 13, 0},
  {"begins", (int (*)())_9begins, 267, 9, 2, 1, 13, 0},
  {"ends", (int (*)())_9ends, 268, 9, 2, 1, 13, 0},
  {"is_in_range", (int (*)())_9is_in_range, 269, 9, 3, 1, 13, 0},
  {"is_in_list", (int (*)())_9is_in_list, 270, 9, 2, 1, 13, 0},
  {"lookup", (int (*)())_9lookup, 271, 9, 4, 1, 13, 0},
  {"vlookup", (int (*)())_9vlookup, 272, 9, 5, 1, 13, 0},
  {"crash", (int (*)())_10crash, 273, 10, 2, 1, 13, 0},
  {"crash_message", (int (*)())_10crash_message, 274, 10, 1, 1, 13, 0},
  {"crash_file", (int (*)())_10crash_file, 275, 10, 1, 1, 13, 0},
  {"warning_file", (int (*)())_10warning_file, 276, 10, 1, 1, 13, 0},
  {"crash_routine", (int (*)())_10crash_routine, 277, 10, 1, 1, 13, 0},
  {"dir", (int (*)())_11dir, 279, 11, 1, 1, 13, 0},
  {"current_dir", (int (*)())_11current_dir, 280, 11, 0, 1, 13, 0},
  {"chdir", (int (*)())_11chdir, 281, 11, 1, 1, 13, 0},
  {"walk_dir", (int (*)())_11walk_dir, 283, 11, 4, 1, 13, 0},
  {"create_directory", (int (*)())_11create_directory, 284, 11, 3, 1, 13, 0},
  {"create_file", (int (*)())_11create_file, 285, 11, 1, 1, 13, 0},
  {"delete_file", (int (*)())_11delete_file, 286, 11, 1, 1, 13, 0},
  {"curdir", (int (*)())_11curdir, 287, 11, 1, 1, 13, 0},
  {"init_curdir", (int (*)())_11init_curdir, 288, 11, 0, 1, 13, 0},
  {"clear_directory", (int (*)())_11clear_directory, 289, 11, 2, 1, 13, 0},
  {"remove_directory", (int (*)())_11remove_directory, 290, 11, 2, 1, 13, 0},
  {"pathinfo", (int (*)())_11pathinfo, 291, 11, 2, 1, 13, 0},
  {"dirname", (int (*)())_11dirname, 292, 11, 2, 1, 13, 0},
  {"pathname", (int (*)())_11pathname, 293, 11, 1, 1, 13, 0},
  {"filename", (int (*)())_11filename, 294, 11, 1, 1, 13, 0},
  {"filebase", (int (*)())_11filebase, 295, 11, 1, 1, 13, 0},
  {"fileext", (int (*)())_11fileext, 296, 11, 1, 1, 13, 0},
  {"driveid", (int (*)())_11driveid, 297, 11, 1, 1, 13, 0},
  {"defaultext", (int (*)())_11defaultext, 298, 11, 2, 1, 13, 0},
  {"absolute_path", (int (*)())_11absolute_path, 299, 11, 1, 1, 13, 0},
  {"case_flagset_type", (int (*)())_11case_flagset_type, 300, 11, 1, 1, 13, 0},
  {"canonical_path", (int (*)())_11canonical_path, 301, 11, 3, 1, 13, 0},
  {"abbreviate_path", (int (*)())_11abbreviate_path, 303, 11, 2, 1, 13, 0},
  {"split_path", (int (*)())_11split_path, 304, 11, 1, 1, 13, 0},
  {"join_path", (int (*)())_11join_path, 305, 11, 1, 1, 13, 0},
  {"file_type", (int (*)())_11file_type, 306, 11, 1, 1, 13, 0},
  {"file_exists", (int (*)())_11file_exists, 307, 11, 1, 1, 13, 0},
  {"file_timestamp", (int (*)())_11file_timestamp, 308, 11, 1, 1, 13, 0},
  {"copy_file", (int (*)())_11copy_file, 309, 11, 3, 1, 13, 0},
  {"rename_file", (int (*)())_11rename_file, 310, 11, 3, 1, 13, 0},
  {"move_file", (int (*)())_11move_file, 311, 11, 3, 1, 13, 0},
  {"file_length", (int (*)())_11file_length, 312, 11, 1, 1, 13, 0},
  {"locate_file", (int (*)())_11locate_file, 313, 11, 3, 1, 13, 0},
  {"disk_metrics", (int (*)())_11disk_metrics, 314, 11, 1, 1, 13, 0},
  {"disk_size", (int (*)())_11disk_size, 315, 11, 1, 1, 13, 0},
  {"count_files", (int (*)())_11count_files, 316, 11, 3, 0, 5, 0},
  {"dir_size", (int (*)())_11dir_size, 317, 11, 2, 1, 13, 0},
  {"temp_file", (int (*)())_11temp_file, 318, 11, 4, 1, 13, 0},
  {"checksum", (int (*)())_11checksum, 319, 11, 4, 1, 13, 0},
  {"datetime", (int (*)())_12datetime, 331, 12, 1, 1, 11, 0},
  {"from_date", (int (*)())_12from_date, 332, 12, 1, 1, 13, 0},
  {"now", (int (*)())_12now, 333, 12, 0, 1, 13, 0},
  {"now_gmt", (int (*)())_12now_gmt, 334, 12, 0, 1, 13, 0},
  {"new", (int (*)())_12new, 335, 12, 6, 1, 11, 0},
  {"new_time", (int (*)())_12new_time, 336, 12, 3, 1, 13, 0},
  {"weeks_day", (int (*)())_12weeks_day, 337, 12, 1, 1, 13, 0},
  {"years_day", (int (*)())_12years_day, 338, 12, 1, 1, 13, 0},
  {"is_leap_year", (int (*)())_12is_leap_year, 339, 12, 1, 1, 13, 0},
  {"days_in_month", (int (*)())_12days_in_month, 340, 12, 1, 1, 13, 0},
  {"days_in_year", (int (*)())_12days_in_year, 341, 12, 1, 1, 13, 0},
  {"to_unix", (int (*)())_12to_unix, 342, 12, 1, 1, 13, 0},
  {"from_unix", (int (*)())_12from_unix, 343, 12, 1, 1, 13, 0},
  {"format", (int (*)())_12format, 344, 12, 2, 1, 11, 0},
  {"parse", (int (*)())_12parse, 345, 12, 3, 1, 11, 0},
  {"add", (int (*)())_12add, 346, 12, 3, 1, 11, 0},
  {"subtract", (int (*)())_12subtract, 347, 12, 3, 1, 13, 0},
  {"diff", (int (*)())_12diff, 348, 12, 2, 1, 13, 0},
  {"open_dll", (int (*)())_13open_dll, 349, 13, 1, 1, 13, 0},
  {"define_c_var", (int (*)())_13define_c_var, 350, 13, 2, 1, 13, 0},
  {"define_c_proc", (int (*)())_13define_c_proc, 351, 13, 3, 1, 13, 0},
  {"define_c_func", (int (*)())_13define_c_func, 352, 13, 4, 1, 13, 0},
  {"call_back", (int (*)())_13call_back, 353, 13, 1, 1, 13, 0},
  {"allocate", (int (*)())_14allocate, 354, 14, 2, 1, 13, 0},
  {"allocate_data", (int (*)())_14allocate_data, 355, 14, 2, 1, 13, 0},
  {"allocate_pointer_array", (int (*)())_14allocate_pointer_array, 356, 14, 2, 1, 13, 0},
  {"allocate_string_pointer_array", (int (*)())_14allocate_string_pointer_array, 357, 14, 2, 1, 13, 0},
  {"allocate_wstring", (int (*)())_14allocate_wstring, 358, 14, 2, 1, 13, 0},
  {"peek_wstring", (int (*)())_14peek_wstring, 359, 14, 1, 1, 13, 0},
  {"poke_string", (int (*)())_14poke_string, 360, 14, 3, 1, 13, 0},
  {"poke_wstring", (int (*)())_14poke_wstring, 361, 14, 3, 1, 13, 0},
  {"is_DEP_supported", (int (*)())_14is_DEP_supported, 363, 14, 0, 1, 13, 0},
  {"is_using_DEP", (int (*)())_14is_using_DEP, 364, 14, 0, 1, 13, 0},
  {"DEP_on", (int (*)())_14DEP_on, 365, 14, 1, 1, 13, 0},
  {"allocate_code", (int (*)())_14allocate_code, 366, 14, 2, 1, 13, 0},
  {"allocate_string", (int (*)())_14allocate_string, 367, 14, 2, 1, 13, 0},
  {"allocate_protect", (int (*)())_14allocate_protect, 368, 14, 3, 1, 13, 0},
  {"free", (int (*)())_14free, 372, 14, 1, 1, 13, 0},
  {"free_pointer_array", (int (*)())_14free_pointer_array, 373, 14, 1, 1, 13, 0},
  {"std_library_address", (int (*)())_14std_library_address, 374, 14, 1, 1, 13, 0},
  {"valid_memory_protection_constant", (int (*)())_14valid_memory_protection_constant, 375, 14, 1, 1, 13, 0},
  {"page_aligned_address", (int (*)())_14page_aligned_address, 376, 14, 1, 1, 13, 0},
  {"valid_memory_protection_constant", (int (*)())_15valid_memory_protection_constant, 377, 15, 1, 1, 11, 0},
  {"test_read", (int (*)())_15test_read, 378, 15, 1, 1, 11, 0},
  {"test_write", (int (*)())_15test_write, 379, 15, 1, 1, 11, 0},
  {"test_exec", (int (*)())_15test_exec, 380, 15, 1, 1, 11, 0},
  {"valid_wordsize", (int (*)())_15valid_wordsize, 381, 15, 1, 1, 11, 0},
  {"positive_int", (int (*)())_16positive_int, 382, 16, 1, 1, 11, 0},
  {"machine_addr", (int (*)())_16machine_addr, 383, 16, 1, 1, 13, 0},
  {"deallocate", (int (*)())_16deallocate, 384, 16, 1, 1, 11, 0},
  {"register_block", (int (*)())_16register_block, 385, 16, 3, 1, 13, 0},
  {"unregister_block", (int (*)())_16unregister_block, 386, 16, 1, 1, 13, 0},
  {"safe_address", (int (*)())_16safe_address, 387, 16, 3, 1, 13, 0},
  {"check_all_blocks", (int (*)())_16check_all_blocks, 388, 16, 0, 1, 13, 0},
  {"prepare_block", (int (*)())_16prepare_block, 389, 16, 3, 1, 11, 0},
  {"bordered_address", (int (*)())_16bordered_address, 390, 16, 1, 1, 11, 0},
  {"dep_works", (int (*)())_16dep_works, 391, 16, 0, 1, 11, 0},
  {"free_code", (int (*)())_16free_code, 392, 16, 3, 1, 13, 0},
  {"Get", (int (*)())_17Get, 403, 17, 0, 0, 5, 0},
  {"Get2", (int (*)())_17Get2, 404, 17, 0, 0, 5, 0},
  {"get", (int (*)())_17get, 406, 17, 3, 1, 11, 0},
  {"value", (int (*)())_17value, 407, 17, 3, 1, 13, 0},
  {"defaulted_value", (int (*)())_17defaulted_value, 408, 17, 3, 1, 13, 0},
  {"get_bytes", (int (*)())_18get_bytes, 409, 18, 2, 1, 13, 0},
  {"get_integer32", (int (*)())_18get_integer32, 410, 18, 1, 1, 13, 0},
  {"get_integer16", (int (*)())_18get_integer16, 411, 18, 1, 1, 13, 0},
  {"put_integer32", (int (*)())_18put_integer32, 412, 18, 2, 1, 13, 0},
  {"put_integer16", (int (*)())_18put_integer16, 413, 18, 2, 1, 13, 0},
  {"get_dstring", (int (*)())_18get_dstring, 414, 18, 2, 1, 13, 0},
  {"file_number", (int (*)())_18file_number, 415, 18, 1, 1, 13, 0},
  {"file_position", (int (*)())_18file_position, 416, 18, 1, 1, 13, 0},
  {"lock_type", (int (*)())_18lock_type, 417, 18, 1, 1, 13, 0},
  {"byte_range", (int (*)())_18byte_range, 418, 18, 1, 1, 13, 0},
  {"seek", (int (*)())_18seek, 419, 18, 2, 1, 13, 0},
  {"where", (int (*)())_18where, 420, 18, 1, 1, 13, 0},
  {"flush", (int (*)())_18flush, 421, 18, 1, 1, 13, 0},
  {"lock_file", (int (*)())_18lock_file, 422, 18, 3, 1, 13, 0},
  {"unlock_file", (int (*)())_18unlock_file, 423, 18, 2, 1, 13, 0},
  {"read_lines", (int (*)())_18read_lines, 424, 18, 1, 1, 13, 0},
  {"process_lines", (int (*)())_18process_lines, 425, 18, 3, 1, 13, 0},
  {"write_lines", (int (*)())_18write_lines, 426, 18, 2, 1, 13, 0},
  {"append_lines", (int (*)())_18append_lines, 427, 18, 2, 1, 13, 0},
  {"read_file", (int (*)())_18read_file, 428, 18, 2, 1, 13, 0},
  {"write_file", (int (*)())_18write_file, 429, 18, 3, 1, 13, 0},
  {"writef", (int (*)())_18writef, 430, 18, 4, 1, 13, 0},
  {"writefln", (int (*)())_18writefln, 431, 18, 4, 1, 13, 0},
  {"abs", (int (*)())_20abs, 433, 20, 1, 1, 13, 0},
  {"sign", (int (*)())_20sign, 434, 20, 1, 1, 13, 0},
  {"larger_of", (int (*)())_20larger_of, 435, 20, 2, 1, 13, 0},
  {"smaller_of", (int (*)())_20smaller_of, 436, 20, 2, 1, 13, 0},
  {"max", (int (*)())_20max, 437, 20, 1, 1, 13, 0},
  {"min", (int (*)())_20min, 438, 20, 1, 1, 13, 0},
  {"ensure_in_range", (int (*)())_20ensure_in_range, 439, 20, 2, 1, 13, 0},
  {"ensure_in_list", (int (*)())_20ensure_in_list, 440, 20, 3, 1, 13, 0},
  {"mod", (int (*)())_20mod, 441, 20, 2, 1, 13, 0},
  {"trunc", (int (*)())_20trunc, 442, 20, 1, 1, 13, 0},
  {"frac", (int (*)())_20frac, 443, 20, 1, 1, 13, 0},
  {"intdiv", (int (*)())_20intdiv, 444, 20, 2, 1, 13, 0},
  {"ceil", (int (*)())_20ceil, 445, 20, 1, 1, 13, 0},
  {"round", (int (*)())_20round, 446, 20, 2, 1, 13, 0},
  {"arccos", (int (*)())_20arccos, 447, 20, 1, 1, 13, 0},
  {"arcsin", (int (*)())_20arcsin, 448, 20, 1, 1, 13, 0},
  {"atan2", (int (*)())_20atan2, 449, 20, 2, 1, 13, 0},
  {"rad2deg", (int (*)())_20rad2deg, 450, 20, 1, 1, 13, 0},
  {"deg2rad", (int (*)())_20deg2rad, 451, 20, 1, 1, 13, 0},
  {"log10", (int (*)())_20log10, 452, 20, 1, 1, 13, 0},
  {"exp", (int (*)())_20exp, 453, 20, 1, 1, 13, 0},
  {"fib", (int (*)())_20fib, 454, 20, 1, 1, 13, 0},
  {"cosh", (int (*)())_20cosh, 455, 20, 1, 1, 13, 0},
  {"sinh", (int (*)())_20sinh, 456, 20, 1, 1, 13, 0},
  {"tanh", (int (*)())_20tanh, 457, 20, 1, 1, 13, 0},
  {"arcsinh", (int (*)())_20arcsinh, 458, 20, 1, 1, 13, 0},
  {"arccosh", (int (*)())_20arccosh, 460, 20, 1, 1, 13, 0},
  {"arctanh", (int (*)())_20arctanh, 462, 20, 1, 1, 13, 0},
  {"sum", (int (*)())_20sum, 463, 20, 1, 1, 11, 0},
  {"product", (int (*)())_20product, 464, 20, 1, 1, 13, 0},
  {"or_all", (int (*)())_20or_all, 465, 20, 1, 1, 13, 0},
  {"shift_bits", (int (*)())_20shift_bits, 466, 20, 2, 1, 13, 0},
  {"rotate_bits", (int (*)())_20rotate_bits, 467, 20, 2, 1, 13, 0},
  {"gcd", (int (*)())_20gcd, 468, 20, 2, 1, 13, 0},
  {"approx", (int (*)())_20approx, 469, 20, 3, 1, 13, 0},
  {"powof2", (int (*)())_20powof2, 470, 20, 1, 1, 13, 0},
  {"is_even", (int (*)())_20is_even, 471, 20, 1, 1, 13, 0},
  {"is_even_obj", (int (*)())_20is_even_obj, 472, 20, 1, 1, 13, 0},
  {"rand_range", (int (*)())_21rand_range, 473, 21, 2, 1, 13, 0},
  {"rnd", (int (*)())_21rnd, 474, 21, 0, 1, 13, 0},
  {"rnd_1", (int (*)())_21rnd_1, 475, 21, 0, 1, 13, 0},
  {"set_rand", (int (*)())_21set_rand, 476, 21, 1, 1, 13, 0},
  {"get_rand", (int (*)())_21get_rand, 477, 21, 0, 1, 13, 0},
  {"chance", (int (*)())_21chance, 478, 21, 2, 1, 13, 0},
  {"roll", (int (*)())_21roll, 479, 21, 2, 1, 13, 0},
  {"sample", (int (*)())_21sample, 480, 21, 3, 1, 13, 0},
  {"binop_ok", (int (*)())_23binop_ok, 481, 23, 2, 1, 13, 0},
  {"fetch", (int (*)())_23fetch, 482, 23, 2, 1, 13, 0},
  {"store", (int (*)())_23store, 483, 23, 3, 1, 13, 0},
  {"valid_index", (int (*)())_23valid_index, 484, 23, 2, 1, 13, 0},
  {"rotate", (int (*)())_23rotate, 485, 23, 4, 1, 13, 0},
  {"columnize", (int (*)())_23columnize, 486, 23, 3, 1, 13, 0},
  {"apply", (int (*)())_23apply, 487, 23, 3, 1, 13, 0},
  {"mapping", (int (*)())_23mapping, 488, 23, 4, 1, 13, 0},
  {"reverse", (int (*)())_23reverse, 489, 23, 3, 1, 13, 0},
  {"shuffle", (int (*)())_23shuffle, 490, 23, 1, 1, 13, 0},
  {"series", (int (*)())_23series, 491, 23, 4, 1, 13, 0},
  {"repeat_pattern", (int (*)())_23repeat_pattern, 492, 23, 2, 1, 13, 0},
  {"pad_head", (int (*)())_23pad_head, 493, 23, 3, 1, 13, 0},
  {"pad_tail", (int (*)())_23pad_tail, 494, 23, 3, 1, 13, 0},
  {"add_item", (int (*)())_23add_item, 495, 23, 3, 1, 13, 0},
  {"remove_item", (int (*)())_23remove_item, 496, 23, 2, 1, 13, 0},
  {"mid", (int (*)())_23mid, 497, 23, 3, 1, 13, 0},
  {"slice", (int (*)())_23slice, 498, 23, 3, 1, 13, 0},
  {"vslice", (int (*)())_23vslice, 499, 23, 3, 1, 13, 0},
  {"patch", (int (*)())_23patch, 500, 23, 4, 1, 13, 0},
  {"remove_all", (int (*)())_23remove_all, 501, 23, 2, 1, 13, 0},
  {"retain_all", (int (*)())_23retain_all, 502, 23, 2, 1, 13, 0},
  {"filter", (int (*)())_23filter, 503, 23, 4, 1, 13, 0},
  {"filter_alpha", (int (*)())_23filter_alpha, 504, 23, 2, 0, 5, 0},
  {"extract", (int (*)())_23extract, 505, 23, 2, 1, 13, 0},
  {"project", (int (*)())_23project, 506, 23, 2, 1, 13, 0},
  {"split", (int (*)())_23split, 507, 23, 4, 1, 11, 0},
  {"split_any", (int (*)())_23split_any, 508, 23, 4, 1, 13, 0},
  {"join", (int (*)())_23join, 509, 23, 2, 1, 13, 0},
  {"breakup", (int (*)())_23breakup, 510, 23, 3, 1, 13, 0},
  {"flatten", (int (*)())_23flatten, 511, 23, 2, 1, 13, 0},
  {"pivot", (int (*)())_23pivot, 512, 23, 2, 1, 13, 0},
  {"build_list", (int (*)())_23build_list, 513, 23, 4, 1, 13, 0},
  {"transform", (int (*)())_23transform, 514, 23, 2, 1, 13, 0},
  {"transmute", (int (*)())_23transmute, 515, 23, 5, 1, 13, 0},
  {"sim_index", (int (*)())_23sim_index, 516, 23, 2, 1, 13, 0},
  {"remove_subseq", (int (*)())_23remove_subseq, 517, 23, 2, 1, 13, 0},
  {"remove_dups", (int (*)())_23remove_dups, 518, 23, 2, 1, 13, 0},
  {"combine", (int (*)())_23combine, 519, 23, 2, 1, 13, 0},
  {"minsize", (int (*)())_23minsize, 520, 23, 3, 1, 13, 0},
  {"sort", (int (*)())_24sort, 521, 24, 2, 1, 13, 0},
  {"custom_sort", (int (*)())_24custom_sort, 522, 24, 4, 1, 13, 0},
  {"column_compare", (int (*)())_24column_compare, 523, 24, 3, 0, 5, 0},
  {"sort_columns", (int (*)())_24sort_columns, 524, 24, 2, 1, 13, 0},
  {"merge", (int (*)())_24merge, 525, 24, 4, 1, 13, 0},
  {"insertion_sort", (int (*)())_24insertion_sort, 526, 24, 4, 1, 13, 0},
  {"is_match", (int (*)())_25is_match, 528, 25, 2, 1, 11, 0},
  {"pretty_print", (int (*)())_26pretty_print, 535, 26, 3, 1, 13, 0},
  {"pretty_sprint", (int (*)())_26pretty_sprint, 536, 26, 2, 1, 13, 0},
  {"deserialize", (int (*)())_27deserialize, 545, 27, 2, 1, 13, 0},
  {"serialize", (int (*)())_27serialize, 546, 27, 1, 1, 13, 0},
  {"dump", (int (*)())_27dump, 547, 27, 2, 1, 13, 0},
  {"load", (int (*)())_27load, 548, 27, 1, 1, 13, 0},
  {"malloc", (int (*)())_28malloc, 549, 28, 2, 1, 11, 0},
  {"free", (int (*)())_28free, 550, 28, 1, 1, 11, 0},
  {"valid", (int (*)())_28valid, 551, 28, 2, 1, 11, 0},
  {"error_string", (int (*)())_29error_string, 553, 29, 1, 1, 13, 0},
  {"keep_newlines", (int (*)())_29keep_newlines, 554, 29, 1, 1, 13, 0},
  {"keep_comments", (int (*)())_29keep_comments, 555, 29, 1, 1, 13, 0},
  {"string_numbers", (int (*)())_29string_numbers, 556, 29, 1, 1, 13, 0},
  {"tokenize_string", (int (*)())_29tokenize_string, 586, 29, 1, 1, 13, 0},
  {"tokenize_file", (int (*)())_29tokenize_file, 587, 29, 1, 1, 13, 0},
  {"show_tokens", (int (*)())_29show_tokens, 588, 29, 2, 1, 13, 0},
  {"encode", (int (*)())_30encode, 589, 30, 2, 1, 11, 0},
  {"decode", (int (*)())_30decode, 590, 30, 1, 1, 11, 0},
  {"show_help", (int (*)())_31show_help, 594, 31, 4, 1, 13, 0},
  {"cmd_parse", (int (*)())_31cmd_parse, 596, 31, 3, 1, 13, 0},
  {"build_commandline", (int (*)())_31build_commandline, 597, 31, 1, 1, 13, 0},
  {"parse_commandline", (int (*)())_31parse_commandline, 598, 31, 1, 1, 13, 0},
  {"has_console", (int (*)())_32has_console, 599, 32, 0, 1, 11, 0},
  {"key_codes", (int (*)())_32key_codes, 600, 32, 1, 1, 13, 0},
  {"set_keycodes", (int (*)())_32set_keycodes, 601, 32, 1, 1, 13, 0},
  {"allow_break", (int (*)())_32allow_break, 602, 32, 1, 1, 11, 0},
  {"check_break", (int (*)())_32check_break, 603, 32, 0, 1, 13, 0},
  {"wait_key", (int (*)())_32wait_key, 604, 32, 0, 1, 13, 0},
  {"any_key", (int (*)())_32any_key, 605, 32, 2, 1, 13, 0},
  {"maybe_any_key", (int (*)())_32maybe_any_key, 606, 32, 2, 1, 13, 0},
  {"prompt_number", (int (*)())_32prompt_number, 607, 32, 2, 1, 13, 0},
  {"prompt_string", (int (*)())_32prompt_string, 608, 32, 1, 1, 13, 0},
  {"positive_int", (int (*)())_32positive_int, 611, 32, 1, 1, 13, 0},
  {"get_screen_char", (int (*)())_32get_screen_char, 612, 32, 3, 1, 13, 0},
  {"put_screen_char", (int (*)())_32put_screen_char, 613, 32, 3, 1, 13, 0},
  {"attr_to_colors", (int (*)())_32attr_to_colors, 614, 32, 1, 1, 13, 0},
  {"colors_to_attr", (int (*)())_32colors_to_attr, 615, 32, 2, 1, 13, 0},
  {"display_text_image", (int (*)())_32display_text_image, 616, 32, 2, 1, 13, 0},
  {"save_text_image", (int (*)())_32save_text_image, 617, 32, 2, 1, 13, 0},
  {"text_rows", (int (*)())_32text_rows, 618, 32, 1, 1, 13, 0},
  {"cursor", (int (*)())_32cursor, 619, 32, 1, 1, 13, 0},
  {"free_console", (int (*)())_32free_console, 620, 32, 0, 1, 13, 0},
  {"display", (int (*)())_32display, 621, 32, 3, 1, 13, 0},
  {"map", (int (*)())_33map, 622, 33, 1, 1, 13, 0},
  {"calc_hash", (int (*)())_33calc_hash, 623, 33, 2, 1, 11, 0},
  {"threshold", (int (*)())_33threshold, 624, 33, 1, 1, 13, 0},
  {"type_of", (int (*)())_33type_of, 625, 33, 1, 1, 13, 0},
  {"rehash", (int (*)())_33rehash, 626, 33, 2, 1, 13, 0},
  {"new", (int (*)())_33new, 627, 33, 1, 1, 11, 0},
  {"new_extra", (int (*)())_33new_extra, 628, 33, 2, 1, 13, 0},
  {"compare", (int (*)())_33compare, 629, 33, 3, 1, 11, 0},
  {"has", (int (*)())_33has, 630, 33, 2, 1, 13, 0},
  {"get", (int (*)())_33get, 631, 33, 3, 1, 11, 0},
  {"nested_get", (int (*)())_33nested_get, 632, 33, 3, 1, 13, 0},
  {"put", (int (*)())_33put, 633, 33, 5, 1, 13, 0},
  {"nested_put", (int (*)())_33nested_put, 634, 33, 5, 1, 13, 0},
  {"remove", (int (*)())_33remove, 635, 33, 2, 1, 11, 0},
  {"clear", (int (*)())_33clear, 636, 33, 1, 1, 11, 0},
  {"size", (int (*)())_33size, 637, 33, 1, 1, 11, 0},
  {"statistics", (int (*)())_33statistics, 638, 33, 1, 1, 13, 0},
  {"keys", (int (*)())_33keys, 639, 33, 2, 1, 13, 0},
  {"values", (int (*)())_33values, 640, 33, 3, 1, 13, 0},
  {"pairs", (int (*)())_33pairs, 641, 33, 2, 1, 13, 0},
  {"optimize", (int (*)())_33optimize, 642, 33, 3, 1, 13, 0},
  {"load_map", (int (*)())_33load_map, 643, 33, 1, 1, 13, 0},
  {"save_map", (int (*)())_33save_map, 644, 33, 3, 1, 13, 0},
  {"copy", (int (*)())_33copy, 645, 33, 3, 1, 13, 0},
  {"new_from_kvpairs", (int (*)())_33new_from_kvpairs, 646, 33, 1, 1, 13, 0},
  {"new_from_string", (int (*)())_33new_from_string, 647, 33, 1, 1, 13, 0},
  {"for_each", (int (*)())_33for_each, 648, 33, 5, 1, 13, 0},
  {"calc_primes", (int (*)())_34calc_primes, 651, 34, 2, 1, 13, 0},
  {"next_prime", (int (*)())_34next_prime, 652, 34, 3, 1, 13, 0},
  {"prime_list", (int (*)())_34prime_list, 653, 34, 1, 1, 13, 0},
  {"small", (int (*)())_35small, 654, 35, 2, 1, 13, 0},
  {"largest", (int (*)())_35largest, 655, 35, 1, 1, 13, 0},
  {"smallest", (int (*)())_35smallest, 656, 35, 1, 1, 13, 0},
  {"range", (int (*)())_35range, 657, 35, 1, 1, 13, 0},
  {"stdev", (int (*)())_35stdev, 659, 35, 3, 1, 13, 0},
  {"avedev", (int (*)())_35avedev, 660, 35, 3, 1, 13, 0},
  {"sum", (int (*)())_35sum, 661, 35, 2, 1, 11, 0},
  {"count", (int (*)())_35count, 662, 35, 2, 1, 13, 0},
  {"average", (int (*)())_35average, 663, 35, 2, 1, 13, 0},
  {"geomean", (int (*)())_35geomean, 664, 35, 2, 1, 13, 0},
  {"harmean", (int (*)())_35harmean, 665, 35, 2, 1, 13, 0},
  {"movavg", (int (*)())_35movavg, 666, 35, 2, 1, 13, 0},
  {"emovavg", (int (*)())_35emovavg, 667, 35, 2, 1, 13, 0},
  {"median", (int (*)())_35median, 668, 35, 2, 1, 13, 0},
  {"raw_frequency", (int (*)())_35raw_frequency, 669, 35, 2, 1, 13, 0},
  {"mode", (int (*)())_35mode, 670, 35, 2, 1, 13, 0},
  {"central_moment", (int (*)())_35central_moment, 671, 35, 4, 1, 13, 0},
  {"sum_central_moments", (int (*)())_35sum_central_moments, 672, 35, 3, 1, 13, 0},
  {"skewness", (int (*)())_35skewness, 673, 35, 2, 1, 13, 0},
  {"kurtosis", (int (*)())_35kurtosis, 674, 35, 2, 1, 13, 0},
  {"color", (int (*)())_36color, 675, 36, 1, 1, 13, 0},
  {"mixture", (int (*)())_36mixture, 676, 36, 1, 1, 13, 0},
  {"video_config", (int (*)())_36video_config, 677, 36, 0, 1, 13, 0},
  {"instance", (int (*)())_37instance, 678, 37, 0, 1, 13, 0},
  {"get_pid", (int (*)())_37get_pid, 679, 37, 0, 1, 13, 0},
  {"uname", (int (*)())_37uname, 680, 37, 0, 1, 13, 0},
  {"is_win_nt", (int (*)())_37is_win_nt, 681, 37, 0, 1, 13, 0},
  {"setenv", (int (*)())_37setenv, 682, 37, 3, 1, 13, 0},
  {"unsetenv", (int (*)())_37unsetenv, 683, 37, 1, 1, 13, 0},
  {"sleep", (int (*)())_37sleep, 684, 37, 1, 1, 13, 0},
  {"db_get_errors", (int (*)())_38db_get_errors, 696, 38, 1, 1, 13, 0},
  {"db_dump", (int (*)())_38db_dump, 697, 38, 2, 1, 13, 0},
  {"check_free_list", (int (*)())_38check_free_list, 698, 38, 0, 1, 13, 0},
  {"db_connect", (int (*)())_38db_connect, 702, 38, 3, 1, 13, 0},
  {"db_create", (int (*)())_38db_create, 703, 38, 4, 1, 13, 0},
  {"db_open", (int (*)())_38db_open, 704, 38, 2, 1, 13, 0},
  {"db_select", (int (*)())_38db_select, 705, 38, 2, 1, 13, 0},
  {"db_close", (int (*)())_38db_close, 706, 38, 0, 1, 13, 0},
  {"db_select_table", (int (*)())_38db_select_table, 708, 38, 1, 1, 13, 0},
  {"db_current_table", (int (*)())_38db_current_table, 709, 38, 0, 1, 13, 0},
  {"db_create_table", (int (*)())_38db_create_table, 710, 38, 2, 1, 13, 0},
  {"db_delete_table", (int (*)())_38db_delete_table, 711, 38, 1, 1, 13, 0},
  {"db_clear_table", (int (*)())_38db_clear_table, 712, 38, 2, 1, 13, 0},
  {"db_rename_table", (int (*)())_38db_rename_table, 713, 38, 2, 1, 13, 0},
  {"db_table_list", (int (*)())_38db_table_list, 714, 38, 0, 1, 13, 0},
  {"db_find_key", (int (*)())_38db_find_key, 716, 38, 2, 1, 13, 0},
  {"db_insert", (int (*)())_38db_insert, 717, 38, 3, 1, 13, 0},
  {"db_delete_record", (int (*)())_38db_delete_record, 718, 38, 2, 1, 13, 0},
  {"db_replace_data", (int (*)())_38db_replace_data, 719, 38, 3, 1, 13, 0},
  {"db_table_size", (int (*)())_38db_table_size, 720, 38, 1, 1, 13, 0},
  {"db_record_data", (int (*)())_38db_record_data, 721, 38, 2, 1, 13, 0},
  {"db_fetch_record", (int (*)())_38db_fetch_record, 722, 38, 2, 1, 13, 0},
  {"db_record_key", (int (*)())_38db_record_key, 723, 38, 2, 1, 13, 0},
  {"db_compress", (int (*)())_38db_compress, 724, 38, 0, 1, 13, 0},
  {"db_current", (int (*)())_38db_current, 725, 38, 0, 1, 13, 0},
  {"db_cache_clear", (int (*)())_38db_cache_clear, 726, 38, 0, 1, 13, 0},
  {"db_set_caching", (int (*)())_38db_set_caching, 727, 38, 1, 1, 13, 0},
  {"db_replace_recid", (int (*)())_38db_replace_recid, 728, 38, 2, 1, 13, 0},
  {"db_record_recid", (int (*)())_38db_record_recid, 729, 38, 1, 1, 13, 0},
  {"db_get_recid", (int (*)())_38db_get_recid, 730, 38, 2, 1, 13, 0},
  {"which_bit", (int (*)())_39which_bit, 731, 39, 1, 1, 13, 0},
  {"flags_to_string", (int (*)())_39flags_to_string, 732, 39, 3, 1, 13, 0},
  {"get_position", (int (*)())_40get_position, 733, 40, 0, 1, 13, 0},
  {"text_color", (int (*)())_40text_color, 734, 40, 1, 1, 13, 0},
  {"bk_color", (int (*)())_40bk_color, 735, 40, 1, 1, 13, 0},
  {"console_colors", (int (*)())_40console_colors, 736, 40, 1, 1, 13, 0},
  {"wrap", (int (*)())_40wrap, 737, 40, 1, 1, 11, 0},
  {"scroll", (int (*)())_40scroll, 738, 40, 3, 1, 13, 0},
  {"graphics_mode", (int (*)())_40graphics_mode, 739, 40, 1, 1, 13, 0},
  {"graphics_point", (int (*)())_41graphics_point, 740, 41, 1, 1, 13, 0},
  {"read_bitmap", (int (*)())_41read_bitmap, 748, 41, 1, 1, 13, 0},
  {"save_bitmap", (int (*)())_41save_bitmap, 757, 41, 2, 1, 13, 0},
  {"lcid", (int (*)())_42lcid, 758, 42, 1, 1, 13, 0},
  {"get_lcid", (int (*)())_42get_lcid, 759, 42, 1, 1, 13, 0},
  {"set_lang_path", (int (*)())_43set_lang_path, 760, 43, 1, 1, 13, 0},
  {"get_lang_path", (int (*)())_43get_lang_path, 761, 43, 0, 1, 13, 0},
  {"lang_load", (int (*)())_43lang_load, 762, 43, 1, 1, 13, 0},
  {"set_def_lang", (int (*)())_43set_def_lang, 763, 43, 1, 1, 13, 0},
  {"get_def_lang", (int (*)())_43get_def_lang, 764, 43, 0, 1, 13, 0},
  {"translate", (int (*)())_43translate, 765, 43, 4, 1, 13, 0},
  {"trsprintf", (int (*)())_43trsprintf, 766, 43, 3, 1, 13, 0},
  {"set", (int (*)())_43set, 767, 43, 1, 1, 11, 0},
  {"get", (int (*)())_43get, 768, 43, 0, 1, 11, 0},
  {"money", (int (*)())_43money, 769, 43, 1, 1, 13, 0},
  {"number", (int (*)())_43number, 770, 43, 1, 1, 13, 0},
  {"datetime", (int (*)())_43datetime, 772, 43, 2, 1, 11, 0},
  {"get_text", (int (*)())_43get_text, 773, 43, 3, 1, 13, 0},
  {"canonical", (int (*)())_44canonical, 774, 44, 1, 1, 13, 0},
  {"decanonical", (int (*)())_44decanonical, 775, 44, 1, 1, 13, 0},
  {"canon2win", (int (*)())_44canon2win, 776, 44, 1, 1, 13, 0},
  {"process", (int (*)())_46process, 778, 46, 1, 1, 13, 0},
  {"close", (int (*)())_46close, 779, 46, 1, 1, 11, 0},
  {"kill", (int (*)())_46kill, 780, 46, 2, 1, 13, 0},
  {"read", (int (*)())_46read, 782, 46, 2, 1, 13, 0},
  {"write", (int (*)())_46write, 783, 46, 2, 1, 13, 0},
  {"error_no", (int (*)())_46error_no, 785, 46, 0, 1, 13, 0},
  {"create", (int (*)())_46create, 790, 46, 0, 1, 11, 0},
  {"exec", (int (*)())_46exec, 791, 46, 2, 1, 13, 0},
  {"regex", (int (*)())_47regex, 792, 47, 1, 1, 13, 0},
  {"option_spec", (int (*)())_47option_spec, 793, 47, 1, 1, 13, 0},
  {"option_spec_to_string", (int (*)())_47option_spec_to_string, 794, 47, 1, 1, 13, 0},
  {"error_to_string", (int (*)())_47error_to_string, 795, 47, 1, 1, 13, 0},
  {"new", (int (*)())_47new, 796, 47, 2, 1, 11, 0},
  {"error_message", (int (*)())_47error_message, 797, 47, 1, 1, 13, 0},
  {"escape", (int (*)())_47escape, 798, 47, 1, 1, 11, 0},
  {"get_ovector_size", (int (*)())_47get_ovector_size, 799, 47, 2, 1, 11, 0},
  {"find", (int (*)())_47find, 800, 47, 5, 1, 11, 0},
  {"find_all", (int (*)())_47find_all, 801, 47, 5, 1, 11, 0},
  {"has_match", (int (*)())_47has_match, 802, 47, 4, 1, 13, 0},
  {"is_match", (int (*)())_47is_match, 803, 47, 4, 1, 11, 0},
  {"matches", (int (*)())_47matches, 804, 47, 4, 1, 13, 0},
  {"all_matches", (int (*)())_47all_matches, 805, 47, 4, 1, 13, 0},
  {"split", (int (*)())_47split, 806, 47, 4, 1, 11, 0},
  {"split_limit", (int (*)())_47split_limit, 807, 47, 5, 1, 13, 0},
  {"find_replace", (int (*)())_47find_replace, 808, 47, 5, 1, 11, 0},
  {"find_replace_limit", (int (*)())_47find_replace_limit, 809, 47, 6, 1, 13, 0},
  {"find_replace_callback", (int (*)())_47find_replace_callback, 810, 47, 6, 1, 13, 0},
  {"error_code", (int (*)())_48error_code, 811, 48, 0, 1, 13, 0},
  {"socket", (int (*)())_48socket, 812, 48, 1, 1, 13, 0},
  {"delete_socket", (int (*)())_48delete_socket, 813, 48, 1, 0, 5, 0},
  {"create", (int (*)())_48create, 814, 48, 3, 1, 11, 0},
  {"close", (int (*)())_48close, 815, 48, 1, 1, 11, 0},
  {"shutdown", (int (*)())_48shutdown, 816, 48, 2, 1, 13, 0},
  {"select", (int (*)())_48select, 817, 48, 5, 1, 13, 0},
  {"send", (int (*)())_48send, 818, 48, 3, 1, 13, 0},
  {"receive", (int (*)())_48receive, 819, 48, 2, 1, 13, 0},
  {"get_option", (int (*)())_48get_option, 820, 48, 3, 1, 13, 0},
  {"set_option", (int (*)())_48set_option, 821, 48, 4, 1, 13, 0},
  {"connect", (int (*)())_48connect, 822, 48, 3, 1, 13, 0},
  {"bind", (int (*)())_48bind, 823, 48, 3, 1, 13, 0},
  {"listen", (int (*)())_48listen, 824, 48, 2, 1, 13, 0},
  {"accept", (int (*)())_48accept, 825, 48, 1, 1, 13, 0},
  {"send_to", (int (*)())_48send_to, 826, 48, 5, 1, 13, 0},
  {"receive_from", (int (*)())_48receive_from, 827, 48, 2, 1, 13, 0},
  {"service_by_name", (int (*)())_48service_by_name, 828, 48, 2, 1, 13, 0},
  {"service_by_port", (int (*)())_48service_by_port, 829, 48, 2, 1, 13, 0},
  {"info", (int (*)())_48info, 830, 48, 1, 1, 13, 0},
  {"is_inetaddr", (int (*)())_49is_inetaddr, 831, 49, 1, 1, 13, 0},
  {"parse_ip_address", (int (*)())_49parse_ip_address, 832, 49, 2, 1, 13, 0},
  {"parse_url", (int (*)())_49parse_url, 833, 49, 1, 1, 13, 0},
  {"stack", (int (*)())_50stack, 834, 50, 1, 1, 13, 0},
  {"new", (int (*)())_50new, 835, 50, 1, 1, 11, 0},
  {"is_empty", (int (*)())_50is_empty, 836, 50, 1, 1, 13, 0},
  {"size", (int (*)())_50size, 837, 50, 1, 1, 11, 0},
  {"at", (int (*)())_50at, 838, 50, 2, 1, 13, 0},
  {"push", (int (*)())_50push, 839, 50, 2, 1, 13, 0},
  {"top", (int (*)())_50top, 840, 50, 1, 1, 13, 0},
  {"last", (int (*)())_50last, 841, 50, 1, 1, 13, 0},
  {"pop", (int (*)())_50pop, 842, 50, 2, 1, 13, 0},
  {"peek_top", (int (*)())_50peek_top, 843, 50, 2, 1, 13, 0},
  {"peek_end", (int (*)())_50peek_end, 844, 50, 2, 1, 13, 0},
  {"swap", (int (*)())_50swap, 845, 50, 1, 1, 13, 0},
  {"dup", (int (*)())_50dup, 846, 50, 1, 1, 13, 0},
  {"set", (int (*)())_50set, 847, 50, 3, 1, 11, 0},
  {"clear", (int (*)())_50clear, 848, 50, 1, 1, 11, 0},
  {"task_delay", (int (*)())_51task_delay, 849, 51, 1, 1, 13, 0},
  {"iif", (int (*)())_52iif, 850, 52, 3, 1, 13, 0},
  {"iff", (int (*)())_52iff, 851, 52, 3, 1, 13, 0},
  {"host_by_name", (int (*)())_53host_by_name, 852, 53, 1, 1, 13, 0},
  {"host_by_addr", (int (*)())_53host_by_addr, 853, 53, 1, 1, 13, 0},
  {"http_post", (int (*)())_54http_post, 859, 54, 5, 1, 13, 0},
  {"http_get", (int (*)())_54http_get, 860, 54, 4, 1, 13, 0},
  {"parse_querystring", (int (*)())_55parse_querystring, 861, 55, 1, 1, 13, 0},
  {"parse", (int (*)())_55parse, 862, 55, 2, 1, 11, 0},
  {"encode", (int (*)())_55encode, 863, 55, 2, 1, 11, 0},
  {"decode", (int (*)())_55decode, 864, 55, 1, 1, 11, 0},
  {"message_box", (int (*)())_56message_box, 865, 56, 3, 1, 13, 0},
  {"sound", (int (*)())_57sound, 866, 57, 1, 1, 13, 0},
  {"set_return_linked_list", (int (*)())_58set_return_linked_list, 867, 58, 1, 1, 13, 0},
  {"get_return_linked_list", (int (*)())_58get_return_linked_list, 868, 58, 0, 1, 13, 0},
  {"mystring", (int (*)())_58mystring, 869, 58, 1, 1, 13, 0},
  {"myarray", (int (*)())_58myarray, 870, 58, 1, 1, 13, 0},
  {"sequence_to_linked_list", (int (*)())_58sequence_to_linked_list, 871, 58, 1, 1, 13, 0},
  {"free_linked_list", (int (*)())_58free_linked_list, 872, 58, 1, 1, 13, 0},
  {"linked_list_to_sequence", (int (*)())_58linked_list_to_sequence, 873, 58, 1, 1, 13, 0},
  {"allocate", (int (*)())_59allocate, 879, 59, 1, 1, 6, 0},
  {"free", (int (*)())_59free, 880, 59, 1, 1, 6, 0},
  {"allocate_low", (int (*)())_59allocate_low, 881, 59, 1, 1, 6, 0},
  {"free_low", (int (*)())_59free_low, 882, 59, 1, 1, 6, 0},
  {"int_to_bytes", (int (*)())_59int_to_bytes, 883, 59, 1, 1, 6, 0},
  {"bytes_to_int", (int (*)())_59bytes_to_int, 884, 59, 1, 1, 6, 0},
  {"int_to_bits", (int (*)())_59int_to_bits, 885, 59, 2, 1, 6, 0},
  {"bits_to_int", (int (*)())_59bits_to_int, 886, 59, 1, 1, 6, 0},
  {"set_rand", (int (*)())_59set_rand, 887, 59, 1, 1, 6, 0},
  {"crash_message", (int (*)())_59crash_message, 888, 59, 1, 1, 6, 0},
  {"crash_file", (int (*)())_59crash_file, 889, 59, 1, 1, 6, 0},
  {"crash_routine", (int (*)())_59crash_routine, 890, 59, 1, 1, 6, 0},
  {"atom_to_float64", (int (*)())_59atom_to_float64, 891, 59, 1, 1, 6, 0},
  {"atom_to_float32", (int (*)())_59atom_to_float32, 892, 59, 1, 1, 6, 0},
  {"float64_to_atom", (int (*)())_59float64_to_atom, 893, 59, 1, 1, 6, 0},
  {"float32_to_atom", (int (*)())_59float32_to_atom, 894, 59, 1, 1, 6, 0},
  {"allocate_string", (int (*)())_59allocate_string, 895, 59, 1, 1, 6, 0},
  {"register_block", (int (*)())_59register_block, 896, 59, 2, 1, 6, 0},
  {"unregister_block", (int (*)())_59unregister_block, 897, 59, 1, 1, 6, 0},
  {"check_all_blocks", (int (*)())_59check_all_blocks, 898, 59, 0, 1, 6, 0},
  {"", 0, 999999999, 0, 0, 0, 0}
};

unsigned char ** _02;
object _0switches;
struct ns_list _01[] = {
  {"eu", 0, 0, 1},
  {"libeu", 1, 1, 1},
  {"all", 2, 2, 2},
  {"info", 3, 3, 3},
  {"keywords", 4, 20, 4},
  {"syncolor", 5, 21, 5},
  {"text", 6, 22, 6},
  {"types", 7, 23, 7},
  {"convert", 8, 55, 8},
  {"search", 9, 56, 9},
  {"error", 10, 90, 10},
  {"filesys", 11, 96, 11},
  {"datetime", 12, 97, 12},
  {"dll", 13, 98, 13},
  {"machine", 14, 99, 14},
  {"memconst", 15, 100, 15},
  {"memory", 16, 106, 14},
  {"memory", 16, 107, 16},
  {"stdget", 17, 147, 17},
  {"io", 18, 148, 18},
  {"stdhash", 19, 217, 19},
  {"math", 20, 218, 20},
  {"random", 21, 219, 21},
  {"mathcons", 22, 228, 22},
  {"stdseq", 23, 270, 23},
  {"stdsort", 24, 271, 24},
  {"wildcard", 25, 318, 25},
  {"pretty", 26, 363, 26},
  {"serialize", 27, 372, 27},
  {"eumem", 28, 402, 28},
  {"tokenize", 29, 414, 29},
  {"base64", 30, 452, 30},
  {"cmdline", 31, 457, 31},
  {"console", 32, 458, 32},
  {"map", 33, 459, 33},
  {"primes", 34, 460, 34},
  {"stats", 35, 464, 33},
  {"stats", 35, 465, 35},
  {"graphcst", 36, 516, 36},
  {"os", 37, 543, 37},
  {"eds", 38, 566, 38},
  {"flags", 39, 613, 39},
  {"graphics", 40, 617, 40},
  {"image", 41, 626, 41},
  {"lcid", 42, 645, 42},
  {"locale", 43, 648, 43},
  {"dt", 12, 649, 43},
  {"lcid", 42, 650, 43},
  {"lcc", 44, 651, 43},
  {"localconv", 44, 652, 44},
  {"pipeio", 46, 681, 46},
  {"regex", 47, 699, 47},
  {"flags", 39, 700, 47},
  {"sockets", 48, 731, 48},
  {"common", 49, 732, 49},
  {"seq", 23, 733, 49},
  {"stack", 50, 759, 50},
  {"task", 51, 780, 51},
  {"utils", 52, 785, 52},
  {"dns", 53, 789, 53},
  {"http", 54, 792, 54},
  {"sock", 48, 793, 54},
  {"url", 55, 794, 54},
  {"url", 55, 795, 55},
  {"msgbox", 56, 810, 56},
  {"sound", 57, 812, 57},
  {"list", 58, 817, 58},
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern unsigned char *string_ptr;
    extern object decompress(unsigned int c);
    extern double sqrt();
    setran(); /* initialize random generator seeds */
    _13653 = NewString("C:\\Users\\jmsck\\OneDrive\\euphoria40\\bin\\");
    _13652 = NewString("C:\\Users\\Owner\\OneDrive\\euwrap_the_one_im_working_on\\euwrap\\euwrap_win32\\libeu");
    _13651 = NewString("C:\\Users\\Owner\\OneDrive\\euphoria40/include");
    _5 = NewString("");
    _13265 = NewDouble((double)-2.1474836480000000e+09);
    _13264 = NewDouble((double)2.1474836480000000e+09);
    _13270 = NewDouble((double)2.1474836470000000e+09);
    _13267 = NewDouble((double)4.2949672950000000e+09);
    _13278 = NewDouble((double)3.4896609280000000e+09);
    _13277 = NewDouble((double)2.9527900160000000e+09);
    _13276 = NewDouble((double)2.6843545600000000e+09);
    _13275 = NewDouble((double)2.4159191040000000e+09);
    _13274 = NewDouble((double)4.0265318400000000e+09);
    _13181 = NewString("MessageBeep");
    _13156 = NewString("user32.dll");
    _13166 = NewString("couldn't find GetActiveWindow\n");
    _13163 = NewString("GetActiveWindow");
    _13162 = NewString("couldn't find MessageBoxA\n");
    _13158 = NewString("MessageBoxA");
    _12991 = NewString("\r\n");
    _13141 = NewString("GET");
    _13127 = NewString("Content-Length: %d\r\n");
    _13122 = NewString("Content-Type: %s\r\n");
    _13118 = NewString("; boundary=");
    _13098 = NewString("POST");
    _13088 = NewString("content-length");
    _13081 = NewString(": ");
    _12790 = NewString(" ");
    _13069 = NewString("\r\n\r\n");
    _13053 = NewString("top");
    _13026 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
    _12993 = NewString("--");
    _13024 = NewString("\r\n--");
    _13015 = NewString("Content-Transfer-Encoding: base64\r\n");
    _13014 = NewString("\x07\x0D");
    string_ptr = "\xFE\x02\x02\x03";
	_13013 = decompress( 0 );
    _13008 = NewString("Content-Type: ");
    _13005 = NewString("\"\r\n");
    _13003 = NewString("; filename=\"");
    _12998 = NewString("\"");
    _12996 = NewString("Content-Disposition: form-data; name=\"");
    _12983 = NewString("=");
    _12980 = NewString("&");
    _12974 = NewString("Connection: close\r\n");
    _12968 = NewString("%s: %s\r\n");
    _12966 = NewString("Connection");
    _12963 = NewString("User-Agent");
    _12956 = NewString("%s %s HTTP/1.0\r\nHost: %s:%d\r\n");
    _12953 = NewString("%s %s HTTP/1.0\r\nHost: %s\r\n");
    _12949 = NewString("?");
    _12327 = NewString("/");
    _12938 = NewString("http");
    _12933 = NewString("multipart/form-data");
    _12932 = NewString("application/x-www-form-urlencoded");
    _12922 = NewString("User-Agent: Euphoria-HTTP/%d.%d\r\n");
    _12781 = NewString("#");
    _12899 = NewString("#0");
    _12875 = NewString("%");
    _12861 = NewString("+");
    _12860 = NewString("0123456789ABCDEF");
    _12859 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234567890");
    _12844 = NewString("parse_done");
    _12851 = NewString("parse_query_string");
    _12808 = NewString("parse_path");
    _12811 = NewString("parse_domain");
    _12780 = NewString("\x07\x49\x55\x69\x6B");
    _12779 = NewString("%+=&;");
    _12766 = NewDouble((double)4.2781900800000000e+09);
    _12759 = NewDouble((double)1.0000000000000000e-02);
    _12749 = NewString("stack index (%d) out of bounds for set()");
    _12732 = NewString("dup() needs at least one item in the stack");
    _12717 = NewString("swap() needs at least 2 items in the stack");
    _12707 = NewString("stack idx (%d) out of bounds in peek_end()");
    _12706 = NewString("stack is empty, cannot peek_end");
    _12692 = NewString("stack idx (%d) out of bounds in peek_top()");
    _12691 = NewString("stack is empty, cannot peek_top");
    _12669 = NewString("stack idx (%d) out of bounds in pop()");
    _12668 = NewString("stack is empty, cannot pop");
    _12656 = NewString("stack is empty so there is no last()");
    _12647 = NewString("stack is empty so there is no top()");
    _12639 = NewString("Internal error in stack.e: Stack %d has invalid stack type %d");
    _12628 = NewString("\x07\x28");
    _12627 = NewString("\x01\x02");
    _12623 = NewString("stack index (%d) out of bounds for at()");
    _12597 = NewString("\x01\x02");
    _12585 = NewString("Eu:StdStack");
    _12520 = NewString("delete_socket");
    _12302 = NewString("(mailto):(([^@]+)@([^?]+))(\\?.*)?");
    _12300 = NewString("(http|https|ftp|ftps|gopher|gophers)://([^/]+)(/[^?]+)?(\\?.*)?");
    _12298 = NewString("^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])(\\:[0-9]+)?$");
    _12125 = NewString(".\\+*?[^]$(){}=!<>|:-");
    _12117 = NewString("Unknown Error");
    _11715 = NewString("%d");
    _12097 = NewString("ERROR_BADNEWLINE");
    _12095 = NewString("ERROR_NULLWSLIMIT");
    _12093 = NewString("ERROR_RECURSIONLIMIT");
    _12091 = NewString("ERROR_DFA_RECURSE");
    _12089 = NewString("ERROR_DFA_WSSIZE");
    _12087 = NewString("ERROR_DFA_UMLIMIT");
    _12085 = NewString("ERROR_DFA_UCOND");
    _12083 = NewString("ERROR_DFA_UITEM");
    _12081 = NewString("ERROR_BADCOUNT");
    _12079 = NewString("ERROR_INTERNAL");
    _12077 = NewString("ERROR_BADPARTIAL");
    _12075 = NewString("ERROR_PARTIAL");
    _12073 = NewString("ERROR_BADUTF8_OFFSET");
    _12071 = NewString("ERROR_BADUTF8");
    _12069 = NewString("ERROR_CALLOUT");
    _12067 = NewString("ERROR_MATCHLIMIT");
    _12065 = NewString("ERROR_NOSUBSTRING");
    _12063 = NewString("ERROR_NOMEMORY");
    _12060 = NewString("ERROR_UNKNOWN_OPCODE/NODE");
    _12058 = NewString("ERROR_BADMAGIC");
    _12056 = NewString("ERROR_BADOPTION");
    _12054 = NewString("ERROR_NULL");
    _12052 = NewString("ERROR_NOMATCH");
    _12033 = NewString("STRING_OFFSETS");
    _12031 = NewString("BSR_UNICODE");
    _12029 = NewString("BSR_ANYCRLF");
    _12027 = NewString("NEWLINE_ANYCRLF");
    _12025 = NewString("NEWLINE_ANY");
    _12023 = NewString("NEWLINE_CRLF");
    _12021 = NewString("NEWLINE_LF");
    _12019 = NewString("NEWLINE_CR");
    _12017 = NewString("DUPNAMES");
    _12015 = NewString("FIRSTLINE");
    _12013 = NewString("DFA_RESTART");
    _12011 = NewString("DFA_SHORTEST");
    _12009 = NewString("PARTIAL");
    _12007 = NewString("AUTO_CALLOUT");
    _12005 = NewString("NO_UTF8_CHECK");
    _12003 = NewString("NO_AUTO_CAPTURE");
    _12001 = NewString("UTF8");
    _11999 = NewString("NOTEMPTY");
    _11997 = NewString("UNGREEDY");
    _11995 = NewString("NOTEOL");
    _11993 = NewString("NOTBOL");
    _11991 = NewString("EXTRA");
    _11989 = NewString("DOLLAR_ENDONLY");
    _11987 = NewString("ANCHORED");
    _11985 = NewString("EXTENDED");
    _11983 = NewString("DOTALL");
    _11981 = NewString("MULTILINE");
    _11979 = NewString("CASELESS");
    _11977 = NewString("DEFAULT");
    _11971 = NewString("-c");
    _11970 = NewString("/bin/sh");
    _11909 = NewString("Errno = %d");
    _11863 = NewString("errno");
    _11862 = NewString("signal");
    _11861 = NewString("execv");
    _11860 = NewString("fork");
    _11859 = NewString("kill");
    _11858 = NewString("dup2");
    _11857 = NewString("close");
    _11856 = NewString("write");
    _11855 = NewString("read");
    _11854 = NewString("pipe");
    _11672 = NewString("libc.dylib");
    _11671 = NewString("libc.so");
    _11851 = NewString("CreateProcessA");
    _11848 = NewString("SetHandleInformation");
    _11845 = NewString("GetStdHandle");
    _11843 = NewString("GetLastError");
    _11840 = NewString("TerminateProcess");
    _11837 = NewString("CloseHandle");
    _11834 = NewString("WriteFile");
    _11831 = NewString("ReadFile");
    _11828 = NewString("CreatePipe");
    _11826 = NewString("kernel32.dll");
    _11796 = NewString("1");
    _11791 = NewString(".edb");
    _11789 = NewString("_");
    _11782 = NewString("teksto");
    _11741 = NewString("1234567890");
    _11719 = NewString("%.15f");
    _11710 = NewString("[,,]");
    _11709 = NewString("%!n");
    _11708 = NewString("%!.0n");
    _11706 = NewString("$[,,.2]");
    _11696 = NewString("%.8f");
    _11693 = NewString("%n");
    _11667 = NewString("strftime");
    _11664 = NewString("setlocale");
    _11670 = NewString("strfmon");
    _11661 = NewString("GetNumberFormatA");
    _11658 = NewString("GetCurrencyFormatA");
    _11656 = NewString("KERNEL32.DLL");
    _11654 = NewString("MSVCRT.DLL");
    _11643 = NewString("__");
    _11567 = NewString("lng");
    _11291 = NewString("C");
    _11290 = NewString("zu_ZA");
    _11289 = NewString("yo_NG");
    _11288 = NewString("ii_CN");
    _11287 = NewString("sah_RU");
    _11286 = NewString("xh_ZA");
    _11285 = NewString("wo_SN");
    _11284 = NewString("cy_GB");
    _11283 = NewString("vi_VN");
    _11282 = NewString("uz_Latn_UZ");
    _11281 = NewString("uz_Cyrl_UZ");
    _11280 = NewString("ur_PK");
    _11279 = NewString("tr_IN");
    _11278 = NewString("wen_DE");
    _11277 = NewString("uk_UA");
    _11276 = NewString("ug_CN");
    _11275 = NewString("tk_TM");
    _11274 = NewString("tr_TR");
    _11273 = NewString("bo_CN");
    _11272 = NewString("bo_BT");
    _11271 = NewString("th_TH");
    _11270 = NewString("te_IN");
    _11269 = NewString("tt_RU");
    _11268 = NewString("ta_IN");
    _11267 = NewString("tmz_Latn_DZ");
    _11266 = NewString("tg_Cyrl_TJ");
    _11265 = NewString("syr_SY");
    _11264 = NewString("sv_SE");
    _11263 = NewString("sv_FI");
    _11262 = NewString("sw_KE");
    _11261 = NewString("es_VE");
    _11260 = NewString("es_UY");
    _11259 = NewString("es_US");
    _11258 = NewString("es_ES_tradnl");
    _11257 = NewString("es_ES");
    _11256 = NewString("es_PR");
    _11255 = NewString("es_PE");
    _11254 = NewString("es_PY");
    _11253 = NewString("es_PA");
    _11252 = NewString("es_NI");
    _11251 = NewString("es_MX");
    _11250 = NewString("es_HN");
    _11249 = NewString("es_GT");
    _11248 = NewString("es_SV");
    _11247 = NewString("es_EC");
    _11246 = NewString("es_DO");
    _11245 = NewString("es_CR");
    _11244 = NewString("es_CO");
    _11243 = NewString("es_CL");
    _11242 = NewString("es_BO");
    _11241 = NewString("es_AR");
    _11240 = NewString("sl_SI");
    _11239 = NewString("sk_SK");
    _11238 = NewString("si_LK");
    _11237 = NewString("tn_ZA");
    _11236 = NewString("ns_ZA");
    _11235 = NewString("sr_Latn_CS");
    _11234 = NewString("sr_Cyrl_CS");
    _11233 = NewString("sr_Latn_BA");
    _11232 = NewString("sr_Cyrl_BA");
    _11231 = NewString("sa_IN");
    _11230 = NewString("sma_SE");
    _11229 = NewString("sma_NO");
    _11228 = NewString("sms_FI");
    _11227 = NewString("se_SE");
    _11226 = NewString("se_NO");
    _11225 = NewString("se_FI");
    _11224 = NewString("smj_SE");
    _11223 = NewString("smj_NO");
    _11222 = NewString("smn_FI");
    _11221 = NewString("ru_RU");
    _11220 = NewString("rm_CH");
    _11219 = NewString("ro_RO");
    _11218 = NewString("quz_PE");
    _11217 = NewString("quz_EC");
    _11216 = NewString("quz_BO");
    _11215 = NewString("pa_IN");
    _11214 = NewString("pt_PT");
    _11213 = NewString("pt_BR");
    _11212 = NewString("pl_PL");
    _11211 = NewString("fa_IR");
    _11210 = NewString("ps_AF");
    _11209 = NewString("or_IN");
    _11208 = NewString("oc_FR");
    _11207 = NewString("nn_NO");
    _11206 = NewString("nb_NO");
    _11205 = NewString("ne_NP");
    _11204 = NewString("ne_IN");
    _11203 = NewString("mn_Mong_CN");
    _11202 = NewString("mn_Cyrl_MN");
    _11201 = NewString("moh_CA");
    _11200 = NewString("mr_IN");
    _11199 = NewString("arn_CL");
    _11198 = NewString("mi_NZ");
    _11197 = NewString("mt_MT");
    _11196 = NewString("ml_IN");
    _11195 = NewString("ms_MY");
    _11194 = NewString("ms_BN");
    _11193 = NewString("mk_MK");
    _11192 = NewString("lb_LU");
    _11191 = NewString("dsb_DE");
    _11190 = NewString("lt_LT");
    _11189 = NewString("lv_LV");
    _11188 = NewString("lo_LA");
    _11187 = NewString("ky_KG");
    _11186 = NewString("ko_KR");
    _11185 = NewString("kok_IN");
    _11184 = NewString("rw_RW");
    _11183 = NewString("qut_GT");
    _11182 = NewString("kh_KH");
    _11181 = NewString("kk_KZ");
    _11180 = NewString("kn_IN");
    _11179 = NewString("ja_JP");
    _11178 = NewString("it_CH");
    _11177 = NewString("it_IT");
    _11176 = NewString("ga_IE");
    _11175 = NewString("iu_Cans_CA");
    _11174 = NewString("iu_Latn_CA");
    _11173 = NewString("id_ID");
    _11172 = NewString("ig_NG");
    _11171 = NewString("is_IS");
    _11170 = NewString("hu_HU");
    _11169 = NewString("hi_IN");
    _11168 = NewString("he_IL");
    _11167 = NewString("ha_Latn_NG");
    _11166 = NewString("gu_IN");
    _11165 = NewString("kl_GL");
    _11164 = NewString("el_GR");
    _11163 = NewString("de_CH");
    _11162 = NewString("de_LU");
    _11161 = NewString("de_LI");
    _11160 = NewString("de_DE");
    _11159 = NewString("de_AT");
    _11158 = NewString("ka_GE");
    _11157 = NewString("gl_ES");
    _11156 = NewString("fy_NL");
    _11155 = NewString("fr_CH");
    _11154 = NewString("fr_MC");
    _11153 = NewString("fr_LU");
    _11152 = NewString("fr_FR");
    _11151 = NewString("fr_CA");
    _11150 = NewString("fr_BE");
    _11149 = NewString("fi_FI");
    _11148 = NewString("fil_PH");
    _11147 = NewString("fo_FO");
    _11146 = NewString("et_EE");
    _11145 = NewString("en_ZW");
    _11144 = NewString("en_US");
    _11143 = NewString("en_GB");
    _11142 = NewString("en_TT");
    _11141 = NewString("en_ZA");
    _11140 = NewString("en_SG");
    _11139 = NewString("en_PH");
    _11138 = NewString("en_NZ");
    _11137 = NewString("en_MY");
    _11136 = NewString("en_JM");
    _11135 = NewString("en_IE");
    _11134 = NewString("en_IN");
    _11133 = NewString("en_029");
    _11132 = NewString("en_CA");
    _11131 = NewString("en_BZ");
    _11130 = NewString("en_AU");
    _11129 = NewString("nl_NL");
    _11128 = NewString("nl_BE");
    _11127 = NewString("dv_MV");
    _11126 = NewString("prs_AF");
    _11125 = NewString("da_DK");
    _11124 = NewString("cs_CZ");
    _11123 = NewString("hr_HR");
    _11122 = NewString("hr_BA");
    _11528 = NewString("co_FR");
    _11121 = NewString("zh_TW");
    _11120 = NewString("zh_SG");
    _11119 = NewString("zh_CN");
    _11118 = NewString("zh_MO");
    _11117 = NewString("zh_HK");
    _11116 = NewString("ca_ES");
    _11115 = NewString("bg_BG");
    _11114 = NewString("br_FR");
    _11113 = NewString("bs_Latn_BA");
    _11112 = NewString("bs_Cyrl_BA");
    _11111 = NewString("bn_IN");
    _11110 = NewString("be_BY");
    _11109 = NewString("eu_ES");
    _11108 = NewString("ba_RU");
    _11107 = NewString("az_Latn_AZ");
    _11106 = NewString("az_Cyrl_AZ");
    _11105 = NewString("as_IN");
    _11104 = NewString("hy_AM");
    _11103 = NewString("ar_YE");
    _11102 = NewString("ar_AE");
    _11101 = NewString("ar_TN");
    _11100 = NewString("ar_SY");
    _11099 = NewString("ar_SA");
    _11098 = NewString("ar_QA");
    _11097 = NewString("ar_OM");
    _11096 = NewString("ar_MA");
    _11095 = NewString("ar_LY");
    _11094 = NewString("ar_LB");
    _11093 = NewString("ar_KW");
    _11092 = NewString("ar_JO");
    _11091 = NewString("ar_IQ");
    _11090 = NewString("ar_EG");
    _11089 = NewString("ar_BH");
    _11088 = NewString("ar_DZ");
    _11087 = NewString("am_ET");
    _11086 = NewString("gsw_FR");
    _11085 = NewString("sq_AL");
    _11084 = NewString("af_ZA");
    _11526 = NewString("Ukrainian_Ukraine");
    _11525 = NewString("Swedish_Sweden");
    _11515 = NewString("Estonian_Estonia");
    _11524 = NewString("Spanish_Spain");
    _11523 = NewString("Slovak_Slovakia");
    _11522 = NewString("Serbian (Cyrillic)_Serbia");
    _11521 = NewString("Russian_Russia");
    _11520 = NewString("Romanian_Romania");
    _11519 = NewString("Italian_Italy");
    _11518 = NewString("Hungarian_Hungary");
    _11517 = NewString("French_France");
    _11516 = NewString("Finnish_Finland");
    _11514 = NewString("English_United States");
    _11513 = NewString("English_Australia");
    _11512 = NewString("Danish_Denmark");
    _11511 = NewString("Catalan_Spain");
    _11510 = NewString("Belarusian_Belarus");
    _11509 = NewString("Basque_Spain");
    _11508 = NewString("Afrikaans_South Africa");
    _11506 = NewString("zu-ZA");
    _11505 = NewString("yo-NG");
    _11504 = NewString("ii-CN");
    _11503 = NewString("sah-RU");
    _11502 = NewString("xh-ZA");
    _11501 = NewString("wo-SN");
    _11500 = NewString("cy-GB");
    _11499 = NewString("vi-VN");
    _11498 = NewString("uz-Latn-UZ");
    _11497 = NewString("uz-Cyrl-UZ");
    _11496 = NewString("ur-PK");
    _11495 = NewString("tr-IN");
    _11494 = NewString("wen-DE");
    _11493 = NewString("uk-UA");
    _11492 = NewString("ug-CN");
    _11491 = NewString("tk-TM");
    _11490 = NewString("tr-TR");
    _11489 = NewString("bo-CN");
    _11488 = NewString("bo-BT");
    _11487 = NewString("th-TH");
    _11486 = NewString("te-IN");
    _11485 = NewString("tt-RU");
    _11484 = NewString("ta-IN");
    _11483 = NewString("tmz-Latn-DZ");
    _11482 = NewString("tg-Cyrl-TJ");
    _11481 = NewString("syr-SY");
    _11480 = NewString("sv-SE");
    _11479 = NewString("sv-FI");
    _11478 = NewString("sw-KE");
    _11477 = NewString("es-VE");
    _11476 = NewString("es-UY");
    _11475 = NewString("es-US");
    _11474 = NewString("es-ES_tradnl");
    _11473 = NewString("es-ES");
    _11472 = NewString("es-PR");
    _11471 = NewString("es-PE");
    _11470 = NewString("es-PY");
    _11469 = NewString("es-PA");
    _11468 = NewString("es-NI");
    _11467 = NewString("es-MX");
    _11466 = NewString("es-HN");
    _11465 = NewString("es-GT");
    _11464 = NewString("es-SV");
    _11463 = NewString("es-EC");
    _11462 = NewString("es-DO");
    _11461 = NewString("es-CR");
    _11460 = NewString("es-CO");
    _11459 = NewString("es-CL");
    _11458 = NewString("es-BO");
    _11457 = NewString("es-AR");
    _11456 = NewString("sl-SI");
    _11455 = NewString("sk-SK");
    _11454 = NewString("si-LK");
    _11453 = NewString("tn-ZA");
    _11452 = NewString("ns-ZA");
    _11451 = NewString("sr-Latn-CS");
    _11450 = NewString("sr-Cyrl-CS");
    _11449 = NewString("sr-Latn-BA");
    _11448 = NewString("sr-Cyrl-BA");
    _11447 = NewString("sa-IN");
    _11446 = NewString("sma-SE");
    _11445 = NewString("sma-NO");
    _11444 = NewString("sms-FI");
    _11443 = NewString("se-SE");
    _11442 = NewString("se-NO");
    _11441 = NewString("se-FI");
    _11440 = NewString("smj-SE");
    _11439 = NewString("smj-NO");
    _11438 = NewString("smn-FI");
    _11437 = NewString("ru-RU");
    _11436 = NewString("rm-CH");
    _11435 = NewString("ro-RO");
    _11434 = NewString("quz-PE");
    _11433 = NewString("quz-EC");
    _11432 = NewString("quz-BO");
    _11431 = NewString("pa-IN");
    _11430 = NewString("pt-PT");
    _11429 = NewString("pt-BR");
    _11428 = NewString("pl-PL");
    _11427 = NewString("fa-IR");
    _11426 = NewString("ps-AF");
    _11425 = NewString("or-IN");
    _11424 = NewString("oc-FR");
    _11423 = NewString("nn-NO");
    _11422 = NewString("nb-NO");
    _11421 = NewString("ne-NP");
    _11420 = NewString("ne-IN");
    _11419 = NewString("mn-Mong-CN");
    _11418 = NewString("mn-Cyrl-MN");
    _11417 = NewString("moh-CA");
    _11416 = NewString("mr-IN");
    _11415 = NewString("arn-CL");
    _11414 = NewString("mi-NZ");
    _11413 = NewString("mt-MT");
    _11412 = NewString("ml-IN");
    _11411 = NewString("ms-MY");
    _11410 = NewString("ms-BN");
    _11409 = NewString("mk-MK");
    _11408 = NewString("lb-LU");
    _11407 = NewString("dsb-DE");
    _11406 = NewString("lt-LT");
    _11405 = NewString("lv-LV");
    _11404 = NewString("lo-LA");
    _11403 = NewString("ky-KG");
    _11402 = NewString("ko-KR");
    _11401 = NewString("kok-IN");
    _11400 = NewString("rw-RW");
    _11399 = NewString("qut-GT");
    _11398 = NewString("kh-KH");
    _11397 = NewString("kk-KZ");
    _11396 = NewString("kn-IN");
    _11395 = NewString("ja-JP");
    _11394 = NewString("it-CH");
    _11393 = NewString("it-IT");
    _11392 = NewString("ga-IE");
    _11391 = NewString("iu-Cans-CA");
    _11390 = NewString("iu-Latn-CA");
    _11389 = NewString("id-ID");
    _11388 = NewString("ig-NG");
    _11387 = NewString("is-IS");
    _11386 = NewString("hu-HU");
    _11385 = NewString("hi-IN");
    _11384 = NewString("he-IL");
    _11383 = NewString("ha-Latn-NG");
    _11382 = NewString("gu-IN");
    _11381 = NewString("kl-GL");
    _11380 = NewString("el-GR");
    _11379 = NewString("de-CH");
    _11378 = NewString("de-LU");
    _11377 = NewString("de-LI");
    _11376 = NewString("de-DE");
    _11375 = NewString("de-AT");
    _11374 = NewString("ka-GE");
    _11373 = NewString("gl-ES");
    _11372 = NewString("fy-NL");
    _11371 = NewString("fr-CH");
    _11370 = NewString("fr-MC");
    _11369 = NewString("fr-LU");
    _11368 = NewString("fr-FR");
    _11367 = NewString("fr-CA");
    _11366 = NewString("fr-BE");
    _11365 = NewString("fi-FI");
    _11364 = NewString("fil-PH");
    _11363 = NewString("fo-FO");
    _11362 = NewString("et-EE");
    _11361 = NewString("en-ZW");
    _11360 = NewString("en-US");
    _11359 = NewString("en-GB");
    _11358 = NewString("en-TT");
    _11357 = NewString("en-ZA");
    _11356 = NewString("en-SG");
    _11355 = NewString("en-PH");
    _11354 = NewString("en-NZ");
    _11353 = NewString("en-MY");
    _11352 = NewString("en-JM");
    _11351 = NewString("en-IE");
    _11350 = NewString("en-IN");
    _11349 = NewString("en-029");
    _11348 = NewString("en-CA");
    _11347 = NewString("en-BZ");
    _11346 = NewString("en-AU");
    _11345 = NewString("nl-NL");
    _11344 = NewString("nl-BE");
    _11343 = NewString("dv-MV");
    _11342 = NewString("prs-AF");
    _11341 = NewString("da-DK");
    _11340 = NewString("cs-CZ");
    _11339 = NewString("hr-HR");
    _11338 = NewString("hr-BA");
    _11337 = NewString("co-FR");
    _11336 = NewString("zh-TW");
    _11335 = NewString("zh-SG");
    _11334 = NewString("zh-CN");
    _11333 = NewString("zh-MO");
    _11332 = NewString("zh-HK");
    _11331 = NewString("ca-ES");
    _11330 = NewString("bg-BG");
    _11329 = NewString("br-FR");
    _11328 = NewString("bs-Latn-BA");
    _11327 = NewString("bs-Cyrl-BA");
    _11326 = NewString("bn-IN");
    _11325 = NewString("be-BY");
    _11324 = NewString("eu-ES");
    _11323 = NewString("ba-RU");
    _11322 = NewString("az-Latn-AZ");
    _11321 = NewString("az-Cyrl-AZ");
    _11320 = NewString("as-IN");
    _11319 = NewString("hy-AM");
    _11318 = NewString("ar-YE");
    _11317 = NewString("ar-AE");
    _11316 = NewString("ar-TN");
    _11315 = NewString("ar-SY");
    _11314 = NewString("ar-SA");
    _11313 = NewString("ar-QA");
    _11312 = NewString("ar-OM");
    _11311 = NewString("ar-MA");
    _11310 = NewString("ar-LY");
    _11309 = NewString("ar-LB");
    _11308 = NewString("ar-KW");
    _11307 = NewString("ar-JO");
    _11306 = NewString("ar-IQ");
    _11305 = NewString("ar-EG");
    _11304 = NewString("ar-BH");
    _11303 = NewString("ar-DZ");
    _11302 = NewString("am-ET");
    _11301 = NewString("gsw-FR");
    _11300 = NewString("sq-AL");
    _11299 = NewString("af-ZA");
    _1354 = NewString("wb");
    _10823 = NewString("BM");
    _1309 = NewString("rb");
    _8854 = NewString("?");
    _10595 = NewDouble((double)2.1474836480000000e+09);
    _10594 = NewDouble((double)1.0737418240000000e+09);
    _10557 = NewString("db_get_recid");
    _10253 = NewString("no table selected");
    _10249 = NewString("invalid table name given");
    _10484 = NewString("db_compress");
    _10525 = NewString("couldn't insert into new database");
    _1256 = NewString("r");
    _10483 = NewString("no current database");
    _10471 = NewString("db_record_key");
    _10375 = NewString("bad record number");
    _10450 = NewString("db_record_data");
    _10441 = NewString("db_table_size");
    _10427 = NewString("db_replace_data");
    _10367 = NewString("db_delete_record");
    _10318 = NewDouble((double)1.5000000000000000e+00);
    _10250 = NewString("db_find_key");
    _10219 = NewString("db_rename_table");
    _10223 = NewString("target table name already exists");
    _10218 = NewString("source table doesn't exist");
    _9970 = NewString("edb");
    _9995 = NewString("ub");
    _9967 = NewString("\x05\x0A");
    _9953 = NewString("\x07\x1B\x2F");
    string_ptr = "\xFE\x03\xFE\x0B\x6E\x71\x65\x6D\x61\x6F\x67\x76\x6A\x71\x66"
"\xFE\x0B\x6B\x70\x6B\x76\x61\x76\x63\x64\x6E\x67\x75\xFE\x09"
"\x6B\x70\x6B\x76\x61\x68\x74\x67\x67";
	_9952 = decompress( 0 );
    _9810 = NewString("bad size in front of free block");
    _9806 = NewString("block size too big");
    _9803 = NewString("bad block address");
    _9797 = NewString("free list space is bad");
    _9791 = NewString("bad free list pointer");
    _9788 = NewString("free count is too high");
    _9781 = NewString("No free blocks available.\n");
    _9779 = NewString("%08x: %6d bytes\n");
    _9775 = NewString(" [#%08x]:");
    _9774 = NewString("Number of Free blocks: %d ");
    _9770 = NewString("[free blocks:#%08x]\n");
    _9768 = NewString("\nblock #%d (empty)\n\n");
    _9715 = NewString("\n\n");
    _9767 = NewString("\x02\x02\x09");
    _9766 = NewString("  data: ");
    _9763 = NewString("[data %d:#%08x]\n");
    _9762 = NewString("\x02\x02\x08");
    _9761 = NewString("  key: ");
    _9757 = NewString("[key %d:#%08x]\n");
    _9748 = NewString("[record %d:#%08x]\n");
    _9745 = NewString("\n--------------------------\nblock #%d, ptrs:%d\n--------------------------\n");
    _9734 = NewString("[table block %d:#%08x]\n");
    _9729 = NewString("\ntable \"%s\", records:%d    indexblks: %d\n\n\n");
    _9728 = NewString("[table name:#%08x]\n");
    _9723 = NewString("\n---------------\n[table header:#%08x]\n");
    _9720 = NewString("[tables:#%08x]\n");
    _9454 = NewString("%s\n");
    _9703 = NewString("\x13\x1C\x26");
    _9700 = NewString("%02x");
    _9697 = NewString("%08x");
    _9687 = NewString("            Disk Dump\nDiskAddr ");
    _9686 = NewString("s\n");
    _1326 = NewString("\n");
    _9681 = NewString("The \"%s\" database has %d table");
    _9677 = NewString("Euphoria Database System Version %d.%d\n\n");
    _9676 = NewString("This is not a Euphoria Database file.\n");
    _9670 = NewString("%Y-%m-%d %H:%M:%S");
    _9669 = NewString("Database dump as at %s\n");
    _9667 = NewString("db_dump");
    _9666 = NewString("bad file");
    _1297 = NewString("w");
    _9650 = NewString("safe_seek");
    _9660 = NewString("io:seek not in position");
    _9656 = NewString("io:seek to position failed");
    _9653 = NewString("io:seeking past EOF");
    _9649 = NewString("no current database defined");
    _9566 = NewString("\x07\x29\x58\x6B\x9E");
    _9565 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _9541 = NewString("equal_string");
    _9530 = NewString("string is missing 0 terminator");
    _9531 = NewString("get_string");
    _9514 = NewString("Error Code %d: %s, from %s");
    _9510 = NewString("?connection?");
    _9509 = NewString("init_free");
    _9508 = NewString("init_tables");
    _9507 = NewString("lock_method");
    _9506 = NewString("!disconnect!");
    _4563 = NewString(" \t\r\n");
    _5374 = NewString("\"'`");
    _5373 = NewString(":=");
    _3362 = NewString(" ");
    _9282 = NewString("Try '--help' for more information.\n");
    _9482 = NewString("option '%s' is mandatory but was not supplied.\n");
    _9477 = NewString("Additional arguments were expected.\n");
    _9459 = NewString("VERSIONING was used with no version string supplied");
    _9458 = NewString("help options are incorrect,\n");
    _9441 = NewString("option '%s' must not occur more than once in the command line.\n");
    _9406 = NewString("option '%s' must have a parameter\n");
    _8610 = NewString("-/");
    _9381 = NewString("option '%s': %s\n");
    _3806 = NewString("/");
    _7944 = NewString("-");
    _6725 = NewString("--");
    _9278 = NewString("Cannot access '@' argument file '%s'\n");
    _9221 = NewString("Unrecognised cmdline PARSE OPTION - %d");
    _9220 = NewString("PAUSE_MSG was given to cmd_parse with no actually message text");
    _8924 = NewString("HELP_RID was given to cmd_parse with no routine_id");
    _9211 = NewString("\x07\x3A\x45\x50\x5B\x66\x71\x7C\x87");
    _9210 = NewString("\x01\x09\x0A\x02\x03\x04\x07\x06\x08");
    _9202 = NewString("Unrecognised");
    _9193 = NewString("Option should not have a parameter");
    _9170 = NewString("false");
    _9169 = NewString("n");
    _9168 = NewString("no");
    _9167 = NewString("off");
    _9166 = NewString("0");
    _9162 = NewString("+");
    _9161 = NewString("ok");
    _9160 = NewString("true");
    _9159 = NewString("y");
    _9158 = NewString("yes");
    _9157 = NewString("on");
    _9156 = NewString("1");
    _9126 = NewString("Empty command text");
    _9120 = NewString("!-");
    _9085 = NewString("One or more additional arguments can be supplied.\n");
    _9076 = NewString("One or more additional arguments are also required\n");
    _9059 = NewString("   ");
    _9044 = NewString(", ");
    _8771 = NewString("x");
    _8994 = NewString("%s options:\n");
    _8919 = NewString("\x07\x3A");
    _8918 = NewString("\x01\x09");
    _8850 = NewString("h");
    _8863 = NewString("Display the command options");
    _8858 = NewString("help");
    _8844 = NewString("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n");
    _8833 = NewString("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n");
    _8801 = NewString("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n");
    _8796 = NewString("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n");
    _8791 = NewString("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n");
    _8786 = NewString("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n");
    _8781 = NewString("cmd_opts: Duplicate processing options are not allowed in an option record.\n");
    _8762 = NewString("cmd_opts: There must be less than two 'extras' option records.\n");
    _8731 = NewString("extras");
    _8657 = NewString("WinNT");
    _8722 = NewString("UNKNOWN");
    _8713 = NewString("Version %d.%d");
    _8711 = NewString("Unknown Windows");
    _8707 = NewString("WinCE %d.%d");
    _8705 = NewString("WinCE");
    _8700 = NewString("WinNT %d.%d");
    _8698 = NewString("WinNT 3.1");
    _8693 = NewString("WinNT 3.5");
    _8688 = NewString("WinNT 3.51");
    _8683 = NewString("WinNT 4.0");
    _8678 = NewString("Win2K");
    _8673 = NewString("WinXP");
    _8667 = NewString("Vista");
    _8662 = NewString("Windows7");
    _8654 = NewString("Unknown");
    _8652 = NewString("WinME");
    _8649 = NewString("Win98");
    _8646 = NewString("Win95");
    _8643 = NewString("Win9x");
    _8638 = NewString("Windows %d.%d");
    _8636 = NewString("Win32s");
    _8620 = NewString("GetVersionExA");
    _8613 = NewString("kernel32.dll");
    _8615 = NewString("GetCurrentProcessId");
    _8605 = NewString("\"\"");
    _8603 = NewString("\x02");
    _8586 = NewString("%15.15f");
    _919 = NewString("%d");
    _8479 = NewString("A number from %g to %g is expected here - try again\n");
    _8468 = NewString("A number is expected - try again\n");
    _8458 = NewString("Press Any Key to continue...");
    _7991 = NewString("\x01\x02");
    _8452 = NewString("OEM_CLEAR");
    _8451 = NewString("PA1");
    _8450 = NewString("NONAME");
    _8449 = NewString("ZOOM");
    _8448 = NewString("PLAY");
    _8447 = NewString("EREOF");
    _8446 = NewString("EXSEL");
    _8445 = NewString("CRSEL");
    _8444 = NewString("ATTN");
    _8443 = NewString("PACKET");
    _8442 = NewString("PROCESSKEY");
    _8441 = NewString("OEM_102");
    _8440 = NewString("OEM_8");
    _8439 = NewString("OEM_7");
    _8438 = NewString("OEM_6");
    _8437 = NewString("OEM_5");
    _8436 = NewString("OEM_4");
    _8435 = NewString("OEM_3");
    _8434 = NewString("OEM_2");
    _8433 = NewString("OEM_PERIOD");
    _8432 = NewString("OEM_MINUS");
    _8431 = NewString("OEM_COMMA");
    _8430 = NewString("OEM_PLUS");
    _8429 = NewString("OEM_1");
    _8428 = NewString("LAUNCH_APP2");
    _8427 = NewString("LAUNCH_APP1");
    _8426 = NewString("LAUNCH_MEDIA_SELECT");
    _8425 = NewString("LAUNCH_MAIL");
    _8424 = NewString("MEDIA_PLAY_PAUSE");
    _8423 = NewString("MEDIA_STOP");
    _8422 = NewString("MEDIA_PREV_TRACK");
    _8421 = NewString("MEDIA_NEXT_TRACK");
    _8420 = NewString("VOLUME_UP");
    _8419 = NewString("VOLUME_DOWN");
    _8418 = NewString("VOLUME_MUTE");
    _8417 = NewString("BROWSER_HOME");
    _8416 = NewString("BROWSER_FAVORITES");
    _8415 = NewString("BROWSER_SEARCH");
    _8414 = NewString("BROWSER_STOP");
    _8413 = NewString("BROWSER_REFRESH");
    _8412 = NewString("BROWSER_FORWARD");
    _8411 = NewString("BROWSER_BACK");
    _8410 = NewString("RMENU");
    _8409 = NewString("LMENU");
    _8408 = NewString("RCONTROL");
    _8407 = NewString("LCONTROL");
    _8406 = NewString("RSHIFT");
    _8405 = NewString("LSHIFT");
    _8404 = NewString("SCROLL");
    _8403 = NewString("NUMLOCK");
    _8402 = NewString("F24");
    _8401 = NewString("F23");
    _8400 = NewString("F22");
    _8399 = NewString("F21");
    _8398 = NewString("F20");
    _8397 = NewString("F19");
    _8396 = NewString("F18");
    _8395 = NewString("F17");
    _8394 = NewString("F16");
    _8393 = NewString("F15");
    _8392 = NewString("F14");
    _8391 = NewString("F13");
    _8390 = NewString("F12");
    _8389 = NewString("F11");
    _8388 = NewString("F10");
    _8387 = NewString("F9");
    _8386 = NewString("F8");
    _8385 = NewString("F7");
    _8384 = NewString("F6");
    _8383 = NewString("F5");
    _8382 = NewString("F4");
    _8381 = NewString("F3");
    _8380 = NewString("F2");
    _8379 = NewString("F1");
    _8378 = NewString("DIVIDE");
    _8377 = NewString("DECIMAL");
    _8376 = NewString("SUBTRACT");
    _8375 = NewString("SEPARATOR");
    _8374 = NewString("ADD");
    _8373 = NewString("MULTIPLY");
    _8372 = NewString("NUMPAD9");
    _8371 = NewString("NUMPAD8");
    _8370 = NewString("NUMPAD7");
    _8369 = NewString("NUMPAD6");
    _8368 = NewString("NUMPAD5");
    _8367 = NewString("NUMPAD4");
    _8366 = NewString("NUMPAD3");
    _8365 = NewString("NUMPAD2");
    _8364 = NewString("NUMPAD1");
    _8363 = NewString("NUMPAD0");
    _8362 = NewString("SLEEP");
    _8361 = NewString("APPS");
    _8360 = NewString("RWIN");
    _8359 = NewString("LWIN");
    _8358 = NewString("HELP");
    _8357 = NewString("DELETE");
    _8356 = NewString("INSERT");
    _8355 = NewString("SNAPSHOT");
    _8354 = NewString("EXECUTE");
    _8353 = NewString("PRINT");
    _8352 = NewString("SELECT");
    _8351 = NewString("DOWN");
    _8350 = NewString("RIGHT");
    _8349 = NewString("UP");
    _8348 = NewString("LEFT");
    _4098 = NewString("HOME");
    _8347 = NewString("END");
    _8346 = NewString("NEXT");
    _8345 = NewString("PRIOR");
    _8344 = NewString("SPACE");
    _8343 = NewString("MODECHANGE");
    _8342 = NewString("ACCEPT");
    _8341 = NewString("NONCONVERT");
    _8340 = NewString("CONVERT");
    _8339 = NewString("ESCAPE");
    _8338 = NewString("HANJA");
    _8337 = NewString("FINAL");
    _8336 = NewString("JUNJA");
    _8335 = NewString("KANA");
    _8334 = NewString("CAPITAL");
    _8333 = NewString("PAUSE");
    _8332 = NewString("MENU");
    _8331 = NewString("CONTROL");
    _8330 = NewString("SHIFT");
    _8329 = NewString("RETURN");
    _8328 = NewString("CLEAR");
    _8327 = NewString("TAB");
    _8326 = NewString("BACK");
    _8325 = NewString("XBUTTON2");
    _8324 = NewString("XBUTTON1");
    _8323 = NewString("MBUTTON");
    _8322 = NewString("CANCEL");
    _8321 = NewString("RBUTTON");
    _8320 = NewString("LBUTTON");
    string_ptr = "\xFE\x86\x09\x17\x25\x33\x41\x4F\x5D\x6B\x79\x87\x95\xA3\xB1"
"\xBF\xCD\xDB\xE9\xF7\xF9\x03\x81\xF9\x11\x81\xF9\x1F\x81\xF9"
"\x2D\x81\xF9\x3B\x81\xF9\x49\x81\xF9\x57\x81\xF9\x65\x81\xF9"
"\x73\x81\xF9\x81\x81\xF9\x8F\x81\xF9\x9D\x81\xF9\xAB\x81\xF9"
"\xB9\x81\xF9\xC7\x81\xF9\xD5\x81\xF9\xE3\x81\xF9\xF1\x81\xF9"
"\xFF\x81\xF9\x0D\x82\xF9\x1B\x82\xF9\x29\x82\xF9\x37\x82\xF9"
"\x45\x82\xF9\x53\x82\xF9\x61\x82\xF9\x6F\x82\xF9\x7D\x82\xF9"
"\x8B\x82\xF9\x99\x82\xF9\xA7\x82\xF9\xB5\x82\xF9\xC3\x82\xF9"
"\xD1\x82\xF9\xDF\x82\xF9\xED\x82\xF9\xFB\x82\xF9\x09\x83\xF9"
"\x17\x83\xF9\x25\x83\xF9\x33\x83\xF9\x41\x83\xF9\x4F\x83\xF9"
"\x5D\x83\xF9\x6B\x83\xF9\x79\x83\xF9\x87\x83\xF9\x95\x83\xF9"
"\xA3\x83\xF9\xB1\x83\xF9\xBF\x83\xF9\xCD\x83\xF9\xDB\x83\xF9"
"\xE9\x83\xF9\xF7\x83\xF9\x05\x84\xF9\x13\x84\xF9\x21\x84\xF9"
"\x2F\x84\xF9\x3D\x84\xF9\x4B\x84\xF9\x59\x84\xF9\x67\x84\xF9"
"\x75\x84\xF9\x83\x84\xF9\x91\x84\xF9\x9F\x84\xF9\xAD\x84\xF9"
"\xBB\x84\xF9\xC9\x84\xF9\xD7\x84\xF9\xE5\x84\xF9\xF3\x84\xF9"
"\x01\x85\xF9\x0F\x85\xF9\x1D\x85\xF9\x2B\x85\xF9\x39\x85\xF9"
"\x47\x85\xF9\x55\x85\xF9\x63\x85\xF9\x71\x85\xF9\x7F\x85\xF9"
"\x8D\x85\xF9\x9B\x85\xF9\xA9\x85\xF9\xB7\x85\xF9\xC5\x85\xF9"
"\xD3\x85\xF9\xE1\x85\xF9\xEF\x85\xF9\xFD\x85\xF9\x0B\x86\xF9"
"\x19\x86\xF9\x27\x86\xF9\x35\x86\xF9\x43\x86\xF9\x51\x86\xF9"
"\x5F\x86\xF9\x6D\x86\xF9\x7B\x86\xF9\x89\x86\xF9\x97\x86\xF9"
"\xA5\x86\xF9\xB3\x86\xF9\xC1\x86\xF9\xCF\x86\xF9\xDD\x86\xF9"
"\xEB\x86\xF9\xF9\x86\xF9\x07\x87\xF9\x15\x87\xF9\x23\x87\xF9"
"\x31\x87\xF9\x3F\x87\xF9\x4D\x87";
	_8319 = decompress( 0 );
    string_ptr = "\xFE\x86\xFE\x07\x4E\x44\x57\x56\x56\x51\x50\xFE\x07\x54\x44"
"\x57\x56\x56\x51\x50\xFE\x06\x45\x43\x50\x45\x47\x4E\xFE\x07"
"\x4F\x44\x57\x56\x56\x51\x50\xFE\x08\x5A\x44\x57\x56\x56\x51"
"\x50\x33\xFE\x08\x5A\x44\x57\x56\x56\x51\x50\x34\xFE\x04\x44"
"\x43\x45\x4D\xFE\x03\x56\x43\x44\xFE\x05\x45\x4E\x47\x43\x54"
"\xFE\x06\x54\x47\x56\x57\x54\x50\xFE\x05\x55\x4A\x4B\x48\x56"
"\xFE\x07\x45\x51\x50\x56\x54\x51\x4E\xFE\x04\x4F\x47\x50\x57"
"\xFE\x05\x52\x43\x57\x55\x47\xFE\x07\x45\x43\x52\x4B\x56\x43"
"\x4E\xFE\x04\x4D\x43\x50\x43\xFE\x05\x4C\x57\x50\x4C\x43\xFE"
"\x05\x48\x4B\x50\x43\x4E\xFE\x05\x4A\x43\x50\x4C\x43\xFE\x06"
"\x47\x55\x45\x43\x52\x47\xFE\x07\x45\x51\x50\x58\x47\x54\x56"
"\xFE\x0A\x50\x51\x50\x45\x51\x50\x58\x47\x54\x56\xFE\x06\x43"
"\x45\x45\x47\x52\x56\xFE\x0A\x4F\x51\x46\x47\x45\x4A\x43\x50"
"\x49\x47\xFE\x05\x55\x52\x43\x45\x47\xFE\x05\x52\x54\x4B\x51"
"\x54\xFE\x04\x50\x47\x5A\x56\xFE\x03\x47\x50\x46\xFE\x04\x4A"
"\x51\x4F\x47\xFE\x04\x4E\x47\x48\x56\xFE\x02\x57\x52\xFE\x05"
"\x54\x4B\x49\x4A\x56\xFE\x04\x46\x51\x59\x50\xFE\x06\x55\x47"
"\x4E\x47\x45\x56\xFE\x05\x52\x54\x4B\x50\x56\xFE\x07\x47\x5A"
"\x47\x45\x57\x56\x47\xFE\x08\x55\x50\x43\x52\x55\x4A\x51\x56"
"\xFE\x06\x4B\x50\x55\x47\x54\x56\xFE\x06\x46\x47\x4E\x47\x56"
"\x47\xFE\x04\x4A\x47\x4E\x52\xFE\x04\x4E\x59\x4B\x50\xFE\x04"
"\x54\x59\x4B\x50\xFE\x04\x43\x52\x52\x55\xFE\x05\x55\x4E\x47"
"\x47\x52\xFE\x07\x50\x57\x4F\x52\x43\x46\x32\xFE\x07\x50\x57"
"\x4F\x52\x43\x46\x33\xFE\x07\x50\x57\x4F\x52\x43\x46\x34\xFE"
"\x07\x50\x57\x4F\x52\x43\x46\x35\xFE\x07\x50\x57\x4F\x52\x43"
"\x46\x36\xFE\x07\x50\x57\x4F\x52\x43\x46\x37\xFE\x07\x50\x57"
"\x4F\x52\x43\x46\x38\xFE\x07\x50\x57\x4F\x52\x43\x46\x39\xFE"
"\x07\x50\x57\x4F\x52\x43\x46\x3A\xFE\x07\x50\x57\x4F\x52\x43"
"\x46\x3B\xFE\x08\x4F\x57\x4E\x56\x4B\x52\x4E\x5B\xFE\x03\x43"
"\x46\x46\xFE\x09\x55\x47\x52\x43\x54\x43\x56\x51\x54\xFE\x08"
"\x55\x57\x44\x56\x54\x43\x45\x56\xFE\x07\x46\x47\x45\x4B\x4F"
"\x43\x4E\xFE\x06\x46\x4B\x58\x4B\x46\x47\xFE\x02\x48\x33\xFE"
"\x02\x48\x34\xFE\x02\x48\x35\xFE\x02\x48\x36\xFE\x02\x48\x37"
"\xFE\x02\x48\x38\xFE\x02\x48\x39\xFE\x02\x48\x3A\xFE\x02\x48"
"\x3B\xFE\x03\x48\x33\x32\xFE\x03\x48\x33\x33\xFE\x03\x48\x33"
"\x34\xFE\x03\x48\x33\x35\xFE\x03\x48\x33\x36\xFE\x03\x48\x33"
"\x37\xFE\x03\x48\x33\x38\xFE\x03\x48\x33\x39\xFE\x03\x48\x33"
"\x3A\xFE\x03\x48\x33\x3B\xFE\x03\x48\x34\x32\xFE\x03\x48\x34"
"\x33\xFE\x03\x48\x34\x34\xFE\x03\x48\x34\x35\xFE\x03\x48\x34"
"\x36\xFE\x07\x50\x57\x4F\x4E\x51\x45\x4D\xFE\x06\x55\x45\x54"
"\x51\x4E\x4E\xFE\x06\x4E\x55\x4A\x4B\x48\x56\xFE\x06\x54\x55"
"\x4A\x4B\x48\x56\xFE\x08\x4E\x45\x51\x50\x56\x54\x51\x4E\xFE"
"\x08\x54\x45\x51\x50\x56\x54\x51\x4E\xFE\x05\x4E\x4F\x47\x50"
"\x57\xFE\x05\x54\x4F\x47\x50\x57\xFE\x0C\x44\x54\x51\x59\x55"
"\x47\x54\x61\x44\x43\x45\x4D\xFE\x0F\x44\x54\x51\x59\x55\x47"
"\x54\x61\x48\x51\x54\x59\x43\x54\x46\xFE\x0F\x44\x54\x51\x59"
"\x55\x47\x54\x61\x54\x47\x48\x54\x47\x55\x4A\xFE\x0C\x44\x54"
"\x51\x59\x55\x47\x54\x61\x55\x56\x51\x52\xFE\x0E\x44\x54\x51"
"\x59\x55\x47\x54\x61\x55\x47\x43\x54\x45\x4A\xFE\x11\x44\x54"
"\x51\x59\x55\x47\x54\x61\x48\x43\x58\x51\x54\x4B\x56\x47\x55"
"\xFE\x0C\x44\x54\x51\x59\x55\x47\x54\x61\x4A\x51\x4F\x47\xFE"
"\x0B\x58\x51\x4E\x57\x4F\x47\x61\x4F\x57\x56\x47\xFE\x0B\x58"
"\x51\x4E\x57\x4F\x47\x61\x46\x51\x59\x50\xFE\x09\x58\x51\x4E"
"\x57\x4F\x47\x61\x57\x52\xFE\x10\x4F\x47\x46\x4B\x43\x61\x50"
"\x47\x5A\x56\x61\x56\x54\x43\x45\x4D\xFE\x10\x4F\x47\x46\x4B"
"\x43\x61\x52\x54\x47\x58\x61\x56\x54\x43\x45\x4D\xFE\x0A\x4F"
"\x47\x46\x4B\x43\x61\x55\x56\x51\x52\xFE\x10\x4F\x47\x46\x4B"
"\x43\x61\x52\x4E\x43\x5B\x61\x52\x43\x57\x55\x47\xFE\x0B\x4E"
"\x43\x57\x50\x45\x4A\x61\x4F\x43\x4B\x4E\xFE\x13\x4E\x43\x57"
"\x50\x45\x4A\x61\x4F\x47\x46\x4B\x43\x61\x55\x47\x4E\x47\x45"
"\x56\xFE\x0B\x4E\x43\x57\x50\x45\x4A\x61\x43\x52\x52\x33\xFE"
"\x0B\x4E\x43\x57\x50\x45\x4A\x61\x43\x52\x52\x34\xFE\x05\x51"
"\x47\x4F\x61\x33\xFE\x08\x51\x47\x4F\x61\x52\x4E\x57\x55\xFE"
"\x09\x51\x47\x4F\x61\x45\x51\x4F\x4F\x43\xFE\x09\x51\x47\x4F"
"\x61\x4F\x4B\x50\x57\x55\xFE\x0A\x51\x47\x4F\x61\x52\x47\x54"
"\x4B\x51\x46\xFE\x05\x51\x47\x4F\x61\x34\xFE\x05\x51\x47\x4F"
"\x61\x35\xFE\x05\x51\x47\x4F\x61\x36\xFE\x05\x51\x47\x4F\x61"
"\x37\xFE\x05\x51\x47\x4F\x61\x38\xFE\x05\x51\x47\x4F\x61\x39"
"\xFE\x05\x51\x47\x4F\x61\x3A\xFE\x07\x51\x47\x4F\x61\x33\x32"
"\x34\xFE\x0A\x52\x54\x51\x45\x47\x55\x55\x4D\x47\x5B\xFE\x06"
"\x52\x43\x45\x4D\x47\x56\xFE\x04\x43\x56\x56\x50\xFE\x05\x45"
"\x54\x55\x47\x4E\xFE\x05\x47\x5A\x55\x47\x4E\xFE\x05\x47\x54"
"\x47\x51\x48\xFE\x04\x52\x4E\x43\x5B\xFE\x04\x5C\x51\x51\x4F"
"\xFE\x06\x50\x51\x50\x43\x4F\x47\xFE\x03\x52\x43\x33\xFE\x09"
"\x51\x47\x4F\x61\x45\x4E\x47\x43\x54";
	_8318 = decompress( 0 );
    _8124 = NewDouble((double)4.2949672320000000e+09);
    _8024 = NewString("%s = %s\n");
    _7943 = NewString("\\-");
    _6016 = NewString("%.15g");
    _8008 = NewString("%Y%m%d%H%M%S");
    _7992 = NewString("\x07\x09");
    _7983 = NewString(",$");
    _7981 = NewString("\",$\"");
    _7922 = NewString(",${");
    _7897 = NewDouble((double)1.3330000000000000e+00);
    _7572 = NewString("Unknown operation given to map.e:put()");
    _7639 = NewString("\x07\x18\x31\x4A\x63\x7C\x99\xB2");
    _7638 = NewString("\x01\x02\x03\x04\x05\x06\x07\x08");
    _7575 = NewString("Inappropriate initial operation given to map.e:put()");
    _7543 = NewString("\x07\x1D\x3B\x59\x77\x95\xC3\xE1");
    _7542 = NewString("\x01\x02\x03\x04\x05\x06\x07\x08");
    _7464 = NewString("\x07\x09\x2D\x2F");
    _7463 = NewString("vVkK");
    _6977 = NewDouble((double)3.5000000000000000e+00);
    _7323 = NewDouble((double)-7.5960358940999999e+04);
    _7322 = NewDouble((double)7.5960358940999999e+04);
    _7321 = NewString("\x01\x06\x07\x02\x03\x08");
    _7320 = NewString("Eu:StdMap");
    _7312 = NewString("\x01");
    _2236 = NewDouble((double)1.0000000000000000e+00);
    _2369 = NewDouble((double)5.0000000000000000e-01);
    _7088 = NewString("\x07\x1A");
    _7087 = NewString("\x02\x03");
    _6993 = NewString("MW");
    _6957 = NewString("\x02\x03");
    _1325 = NewString("\r\n");
    _6889 = NewString("\x02\x01\x01");
    _6888 = NewString("\x03\x01\x02");
    _6886 = NewString("\x02\x03\x04\x01");
    _6885 = NewString("\x10\x04\x01");
    _6884 = NewString("\x04\x10\x40");
    _6883 = NewString("\x40\x10\x04");
    _6879 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
    _6857 = NewString("%-29s : %s\n");
    _6853 = NewString("UNKNOWN                       : %d\n");
    _6844 = NewString("T_NEWLINE                     : \\n\n");
    _6839 = NewString("T_NUMBER %20s : %s\n");
    _6836 = NewString("%f");
    _6823 = NewString("T_STRING %20s : [[[%s]]]\n");
    _6822 = NewString("\x07\x2D\x80");
    _6821 = NewString("\x08\x06\x04");
    _6816 = NewString("TF_COMMENT_MULTIPLE");
    _6815 = NewString("TF_COMMENT_SINGLE");
    _6814 = NewString("TF_STRING_HEX");
    _6813 = NewString("TF_STRING_BACKTICK");
    _6812 = NewString("TF_STRING_TRIPPLE");
    _6811 = NewString("TF_STRING_SINGLE");
    _6810 = NewString("TF_ATOM");
    _6809 = NewString("TF_INT");
    _6808 = NewString("TF_HEX");
    _6806 = NewString("T_SLICE");
    _6805 = NewString("T_DOLLAR");
    _6804 = NewString("T_COLON");
    _6803 = NewString("T_PERIOD");
    _6802 = NewString("T_COMMA");
    _6801 = NewString("T_QPRINT");
    _6800 = NewString("T_RBRACKET");
    _6799 = NewString("T_LBRACKET");
    _6798 = NewString("T_RBRACE");
    _6797 = NewString("T_LBRACE");
    _6796 = NewString("T_RPAREN");
    _6795 = NewString("T_LPAREN");
    _6794 = NewString("T_EQ");
    _6793 = NewString("T_CONCAT");
    _6792 = NewString("T_NOT");
    _6791 = NewString("T_GT");
    _6790 = NewString("T_LT");
    _6789 = NewString("T_DIVIDE");
    _6788 = NewString("T_MULTIPLY");
    _6787 = NewString("T_MINUS");
    _6786 = NewString("T_PLUS");
    _6785 = NewString("T_CONCATEQ");
    _6784 = NewString("T_NOTEQ");
    _6783 = NewString("T_GTEQ");
    _6782 = NewString("T_LTEQ");
    _6781 = NewString("T_DIVIDEEQ");
    _6780 = NewString("T_MULTIPLYEQ");
    _6779 = NewString("T_MINUSEQ");
    _6778 = NewString("T_PLUSEQ");
    _6777 = NewString("T_KEYWORD");
    _6776 = NewString("T_IDENTIFIER");
    _6775 = NewString("T_STRING");
    _6774 = NewString("T_CHAR");
    _6773 = NewString("T_NUMBER");
    _6772 = NewString("T_COMMENT");
    _6771 = NewString("T_NEWLINE");
    _6770 = NewString("T_SHBANG");
    _6769 = NewString("T_NULL");
    _6768 = NewString("T_EOF");
    _6717 = NewString("%g");
    _118 = NewString("include");
    _6623 = NewString("xuU");
    _6629 = NewString("0123456789ABCDEFabcdef _\t\n\r");
    _6625 = NewString("tokenize.e: Unknown base code '%s', ignored.\n");
    _6624 = NewString("\x07\x12\x1D");
    _6605 = NewString("btdx");
    _6353 = NewString("\"\"\"");
    _6490 = NewString("t\\r'n\"");
    _6313 = NewString("*/");
    _6403 = NewString("Invalid hexadecimal or unicode string");
    _6402 = NewString("End of file reached without closing \" char");
    _6401 = NewString("Expected EOF");
    _6400 = NewString("Unknown token type");
    _6399 = NewString("Expected a decimal value");
    _6398 = NewString("Expected a hex value");
    _6397 = NewString("End of line reached without closing \" char");
    _6396 = NewString("Expected a closing ' char");
    _6395 = NewString("End of line reached without closing ' char");
    _6394 = NewString("Expected an escape character");
    _6393 = NewString("Failed to open file");
    _6390 = NewString("=(){}[]?,.:$");
    _6389 = NewString("+-*/<>!&");
    _6250 = NewString("MULTILINE_STRING");
    _6332 = NewString("`");
    _6253 = NewString("BACKTICK_STRING");
    _6247 = NewString("MULTILINE_COMMENT");
    _6324 = NewString("/*");
    _6293 = NewString(")]}");
    _6276 = NewString("([{");
    _6213 = NewString("syncolor.e: Unknown color name '%s', ignored.\n");
    _6210 = NewString("BRACKET");
    _6207 = NewString("STRING");
    _6204 = NewString("BUILTIN");
    _6201 = NewString("KEYWORD");
    _6198 = NewString("COMMENT");
    _6195 = NewString("NORMAL");
    _6194 = NewString("\x07\x19\x2B\x3D\x4F\x61");
    string_ptr = "\xFE\x06\xFE\x06\x50\x51\x54\x4F\x43\x4E\xFE\x07\x45\x51\x4F"
"\x4F\x47\x50\x56\xFE\x07\x4D\x47\x5B\x59\x51\x54\x46\xFE\x07"
"\x44\x57\x4B\x4E\x56\x4B\x50\xFE\x06\x55\x56\x54\x4B\x50\x49"
"\xFE\x07\x44\x54\x43\x45\x4D\x47\x56";
	_6193 = decompress( 0 );
    _1124 = NewString("free");
    _6136 = NewString(" \t");
    _6032 = NewString("logic error: 'cap' mode in format.");
    _6028 = NewString("\x07\x15\x23\x31");
    string_ptr = "\xFE\x04\x77\x6E\x79\x02";
	_6027 = decompress( 0 );
    _5939 = NewString("e+0");
    _5932 = NewString("%15.15g");
    _2228 = NewDouble((double)4.2949672950000000e+09);
    _5902 = NewString("%x");
    _1382 = NewString("0123456789");
    string_ptr = "\xFE\x21\x09\x19\x55\x57\x59\x64\x6F\x7A\x85\x90\x9B\xA6\xA8"
"\xAA\xB5\xC0\xCB\xD6\xE1\xF9\x38\x81\xF9\x88\x81\xF9\x4F\x82"
"\xF9\xD3\x82\xF9\xD5\x82\xF9\xD7\x82\xF9\xD9\x82\xF9\xDB\x82"
"\xF9\xDD\x82\xF9\xDF\x82\xF9\xE1\x82\xF9\xE3\x82\xF9\xE5\x82"
"\xF9\x3D\x83";
	_5734 = decompress( 0 );
    _5733 = NewString("][wulbstzXBc<>+(?T:.{%0123456789,");
    _5549 = NewString("\"");
    _910 = NewString("\\");
    _5506 = NewString("p[%d]");
    _5389 = NewString("}])");
    _5388 = NewString("{[(");
    _307 = NewString(" \t\n\r");
    _5372 = NewString(";,");
    _5309 = NewString("CharUpperBuffA");
    _5306 = NewString("CharLowerBuffA");
    _5304 = NewString("user32.dll");
    _5206 = NewString("ASCII");
    _5293 = NewString("Failed to load code page '%s'. Error # %d\n");
    _5272 = NewString("\x07\x09");
    _5271 = NewString("\x01\x02");
    _5261 = NewString("ecp.dat");
    _5231 = NewString("title");
    _5223 = NewString("--CASE--");
    _5217 = NewString("--HEAD--");
    _5207 = NewString(".ecp");
    _4827 = NewString("%.10g");
    _929 = NewString("{");
    _4985 = NewString("Invalid sequence serialization");
    _5010 = NewString("\x07\x33\x6F\x8C\xCF");
    _5009 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _4920 = NewString("\x07\x25\x4E\x62\x8D");
    _4919 = NewString("\xF9\xFA\xFB\xFC\xFD");
    _4820 = NewString(" ...");
    _4807 = NewString("\t\r\n\\");
    _4777 = NewString("\t\n\r\\");
    _4768 = NewString("\\\"");
    _911 = NewString("\\\\");
    _4767 = NewString("\\r");
    _4766 = NewString("\\n");
    _4765 = NewString("\\t");
    _4764 = NewString("\x07\x13\x1F\x2B\x37");
    _4763 = NewString("\t\n\r\\\"");
    _4738 = NewString("[:08X]");
    _4670 = NewString("%s%s%06d%s");
    _3819 = NewString(".");
    _4657 = NewString("\x07\x16\x23");
    string_ptr = "\xFE\x03\x03\x04\x02";
	_4656 = decompress( 0 );
    _4654 = NewString("/tmp/");
    _4653 = NewString("C:\\temp\\");
    _4650 = NewString("TMP");
    _4647 = NewString("TEMP");
    _4644 = NewString("_T_");
    _4631 = NewString("count_files");
    _3850 = NewString("..");
    _4562 = NewString(" > ");
    _4561 = NewString("df -k ");
    _4560 = NewString(".tmp");
    _4559 = NewString("/tmp/eudf");
    _4501 = NewString("PATH");
    _4496 = NewString("USERPATH");
    _4493 = NewString("C:\\Users\\jmsck\\OneDrive\\euphoria40\\bin\\");
    _4492 = NewString("C:\\Users\\Owner\\OneDrive\\euwrap_the_one_im_working_on\\euwrap\\euwrap_win32\\libeu");
    _4491 = NewString("C:\\Users\\Owner\\OneDrive\\euphoria40/include");
    _4490 = NewString("/usr/share/euphoria/bin/");
    _4489 = NewString("/usr/local/share/euphoria/bin/");
    _4486 = NewString("data");
    _4483 = NewString("etc");
    _4478 = NewString("EUDIST");
    _4475 = NewString("docs");
    _4472 = NewString("bin");
    _4469 = NewString("EUDIR");
    _4103 = NewString("HOMEPATH");
    _4101 = NewString("HOMEDRIVE");
    _4202 = NewString("partloop");
    _4140 = NewString("/\\");
    _300 = NewString("  ");
    _3845 = NewString(" \\\n");
    _3812 = NewString("dll");
    _3811 = NewString("NUL:");
    _3810 = NewString("\\/:");
    _3809 = NewString("so");
    _3808 = NewString("dylib");
    _3807 = NewString("/dev/null");
    _3803 = NewString("GetDiskFreeSpaceA");
    _3800 = NewString("GetFileAttributesA");
    _3797 = NewString("RemoveDirectoryA");
    _3794 = NewString("CreateDirectoryA");
    _3791 = NewString("DeleteFileA");
    _3788 = NewString("MoveFileA");
    _3785 = NewString("CopyFileA");
    _3784 = NewString("access");
    _3783 = NewString("rmdir");
    _3782 = NewString("mkdir");
    _3781 = NewString("unlink");
    _3780 = NewString("rename");
    _3779 = NewString("stat");
    _3778 = NewString("__xstat");
    _1067 = NewString("libc.so");
    _1661 = NewString("libc.dylib");
    _3776 = NewString("kernel32");
    _3710 = NewDouble((double)1.5000000000000000e+00);
    _3649 = NewDouble((double)1.2345600000000001e+00);
    _3586 = NewString("DoA");
    _3337 = NewString(", \t|");
    _3275 = NewString("%d is not a valid index for the input sequence");
    _3269 = NewString("filter_alpha");
    _663 = NewString("()");
    _679 = NewString("(]");
    _671 = NewString("[)");
    _658 = NewString("[]");
    string_ptr = "\xFE\x05\x09\x41\xA3\xF9\x03\x81\xF9\x65\x81";
	_3202 = decompress( 0 );
    string_ptr = "\xFE\x05\xFE\x00\xFE\x02\x5D\x5F\xFE\x02\x5D\x2B\xFE\x02\x2A"
"\x5F\xFE\x02\x2A\x2B";
	_3201 = decompress( 0 );
    _3200 = NewString("out");
    string_ptr = "\xFE\x05\x09\x41\x90\xDF\xF9\x2C\x81";
	_3150 = decompress( 0 );
    string_ptr = "\xFE\x05\xFE\x00\xFE\x02\x5D\x5F\xFE\x02\x5D\x2B\xFE\x02\x2A"
"\x5F\xFE\x02\x2A\x2B";
	_3149 = decompress( 0 );
    _3148 = NewString("in");
    _3141 = NewString("ge");
    _3140 = NewString(">=");
    _3133 = NewString("gt");
    _3132 = NewString(">");
    _3125 = NewString("ne");
    _3124 = NewString("!=");
    _3117 = NewString("eq");
    _3116 = NewString("==");
    _3115 = NewString("=");
    _3108 = NewString("le");
    _3107 = NewString("<=");
    _3100 = NewString("lt");
    _3099 = NewString("<");
    string_ptr = "\xFE\x0F\x09\x0B\x43\x45\x7D\x7F\x81\xB9\xBB\xF3\xF5\xF9\x2B"
"\x81\xF9\x2D\x81\xF9\x65\x81\xF9\xEB\x82";
	_3098 = decompress( 0 );
    string_ptr = "\xFE\x0F\xFE\x01\x3E\xFE\x02\x6E\x76\xFE\x02\x3E\x3F\xFE\x02"
"\x6E\x67\xFE\x01\x3F\xFE\x02\x3F\x3F\xFE\x02\x67\x73\xFE\x02"
"\x23\x3F\xFE\x02\x70\x67\xFE\x01\x40\xFE\x02\x69\x76\xFE\x02"
"\x40\x3F\xFE\x02\x69\x67\xFE\x02\x6B\x70\xFE\x03\x71\x77\x76";
	_3097 = decompress( 0 );
    _3024 = NewString("sequence:vslice(): colno should be a valid index on the %d-th element, but was %d");
    _3014 = NewString("sequence:vslice(): colno should be a valid index, but was %d");
    _2984 = NewString("mid(): len was %d and should be greater than %d.");
    _2963 = NewString("sequence.e:add_item() invalid Order argument '%d'");
    _2956 = NewString("\x07\x17\x27\x3C");
    _2955 = NewString("\x01\x02\x03\x04");
    _2928 = NewString("\x07\x2C");
    _2927 = NewString("+*");
    _2830 = NewString("sequence:rotate(): invalid 'stop' parameter %d");
    _2827 = NewString("sequence:rotate(): invalid 'start' parameter %d");
    _2743 = NewString("outer");
    _2680 = NewString("column_compare");
    _2582 = NewString("approx(): Sequence arguments must be the same length");
    _2576 = NewDouble((double)5.0000000000000001e-03);
    _2535 = NewDouble((double)2.1474836470000000e+09);
    _2533 = NewDouble((double)2.1474836480000000e+09);
    _2482 = NewDouble((double)-1.0000000000000000e+00);
    _2446 = NewDouble((double)-1.5707963267948966e+00);
    _2402 = NewString("The lengths of the two supplied sequences do not match.");
    _2288 = NewDouble((double)2.2360679774997898e+00);
    _2285 = NewDouble((double)1.0000000000000000e+308);
    _2284 = NewDouble((double)1.6487212707001282e+00);
    _2283 = NewDouble((double)5.7721566490153287e-01);
    _2282 = NewDouble((double)5.7295779513082323e+01);
    _2281 = NewDouble((double)1.7453292519943295e-02);
    _2280 = NewDouble((double)1.7320508075688772e+00);
    _2279 = NewDouble((double)7.0710678118654757e-01);
    _2278 = NewDouble((double)1.4142135623730949e+00);
    _2277 = NewDouble((double)4.3429448190325187e-01);
    _2276 = NewDouble((double)2.3025850929940459e+00);
    _2275 = NewDouble((double)1.4426950408889634e+00);
    _2274 = NewDouble((double)6.9314718055994529e-01);
    _2273 = NewDouble((double)2.7182818284590455e+00);
    _2272 = NewDouble((double)1.6180339887498949e+00);
    _2271 = NewDouble((double)3.9894228040143365e-01);
    _2270 = NewDouble((double)9.8696044010893580e+00);
    _2269 = NewDouble((double)6.2831853071795862e+00);
    _2268 = NewDouble((double)1.5707963267948966e+00);
    _2267 = NewDouble((double)7.8539816339744839e-01);
    _2266 = NewDouble((double)3.1415926535897931e+00);
    _2109 = NewString("\x07\x17\x27\x37\x47\x57\x67");
    _2108 = NewString("YymdHMS");
    _1974 = NewString("%Y-%m-%d %H:%M:%S");
    _2094 = NewString("%04d");
    _1994 = NewString("%02d");
    _2073 = NewString("7");
    _1875 = NewString("PM");
    _1874 = NewString("AM");
    _1872 = NewString("Sat");
    _1871 = NewString("Fri");
    _1870 = NewString("Thu");
    _1869 = NewString("Wed");
    _1868 = NewString("Tue");
    _1867 = NewString("Mon");
    _1866 = NewString("Sun");
    _1864 = NewString("Saturday");
    _1863 = NewString("Friday");
    _1862 = NewString("Thursday");
    _1861 = NewString("Wednesday");
    _1860 = NewString("Tuesday");
    _1859 = NewString("Monday");
    _1858 = NewString("Sunday");
    _1856 = NewString("Dec");
    _1855 = NewString("Nov");
    _1854 = NewString("Oct");
    _1853 = NewString("Sep");
    _1852 = NewString("Aug");
    _1851 = NewString("Jul");
    _1850 = NewString("Jun");
    _1837 = NewString("May");
    _1849 = NewString("Apr");
    _1848 = NewString("Mar");
    _1847 = NewString("Feb");
    _1846 = NewString("Jan");
    _1844 = NewString("December");
    _1843 = NewString("November");
    _1842 = NewString("October");
    _1841 = NewString("September");
    _1840 = NewString("August");
    _1839 = NewString("July");
    _1838 = NewString("June");
    _1836 = NewString("April");
    _1835 = NewString("March");
    _1834 = NewString("February");
    _1833 = NewString("January");
    _1785 = NewDouble((double)3.6525000000000000e+02);
    _1780 = NewDouble((double)3.0436876040000001e+01);
    _1763 = NewDouble((double)2.5000000000000000e-01);
    _1699 = NewDouble((double)6.2135856000000000e+10);
    _1698 = NewString("\x1F\x1C\x1F\x1E\x1F\x1E\x1F\x1F\x1E\x1F\x1E\x1F");
    _1671 = NewDouble((double)3.5776430080000000e+09);
    _225 = NewString("time");
    _1660 = NewString("gmtime");
    _1667 = NewString("GetSystemTimeAsFileTime");
    _1032 = NewString("kernel32.dll");
    _1662 = NewString("msvcrt.dll");
    _1650 = NewString("Initial seek() for get() failed!");
    _1646 = NewString("GET_LONG_ANSWER");
    _1645 = NewString("GET_SHORT_ANSWER");
    _1644 = NewString("Invalid type of answer, please only use %s (the default) or %s.");
    _1639 = NewString("Get2");
    _1637 = NewString("Get");
    _1401 = NewString("\n'\"\t\\\r");
    _1400 = NewString("n'\"t\\r");
    _1385 = NewString("-+.#");
    _1383 = NewString("ABCDEF");
    _1372 = NewString("Unable to write to '%s'");
    _1303 = NewString("a");
    _1163 = NewString("A C function is being defined from Non-executable memory.");
    _1128 = NewString("free_pointer_array");
    _1122 = NewString("free() called with nested sequence");
    _1117 = NewString("free(\"%s\") is not a valid address");
    _1093 = NewString("Parameter error: Wrong word size %d in allocate_protect().");
    _1092 = NewString("\x07\x12\x1D");
    _1091 = NewString("\x01\x02\x04");
    _1070 = NewString("getpagesize");
    _1068 = NewString("sysconf");
    _1045 = NewString("GetSystemInfo");
    _1043 = NewString("GetLastError");
    _1040 = NewString("VirtualFree");
    _1037 = NewString("VirtualProtect");
    _1034 = NewString("VirtualAlloc");
    _971 = NewString("deallocate");
    _951 = NewString("\x01\x02\x04");
    _949 = NewString("\x10\x20\x40\x80");
    _947 = NewString("\x40\x80\x08\x04");
    _945 = NewString("\x20\x40\x04\x02");
    _943 = NewString("\x10\x20\x40\x80\x08\x04\x02\x01");
    _937 = NewString(", ");
    _921 = NewString("%.15f");
    string_ptr = "\xFE\x27\x09\x28\x47\x6D\x93\xB9\xBB\xBD\xBF\xC1\xE0\xF9\xFD"
"\x80\xF9\xFF\x80\xF9\x34\x81\xF9\x6D\x81\xF9\x6F\x81\xF9\x71"
"\x81\xF9\x86\x81\xF9\x88\x81\xF9\x8A\x81\xF9\x8C\x81\xF9\x8E"
"\x81\xF9\x90\x81\xF9\x92\x81\xF9\x94\x81\xF9\x96\x81\xF9\x98"
"\x81\xF9\x9A\x81\xF9\x9C\x81\xF9\x9E\x81\xF9\xA0\x81\xF9\xA2"
"\x81\xF9\xA4\x81\xF9\xA6\x81\xF9\xA8\x81\xF9\xAA\x81\xF9\xAC"
"\x81\xF9\xAE\x81\xF9\xB0\x81";
	_812 = decompress( 0 );
    _811 = NewString("\x2D\x2B\x23\x40\x21\x24\xA3\xA4\xA5\x80\x5F\x2E\x2C\x25\x09"
"\x20\xA0\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43"
"\x44\x45\x46\x61\x62\x63\x64\x65\x66");
    _804 = NewString("\x07\x09");
    _803 = NewString(",.");
    _802 = NewString("0123456789ABCDEFabcdef");
    _783 = NewString("0123456789abcdefABCDEF");
    _662 = NewString("\x07\x3A\x6D");
    string_ptr = "\xFE\x03\xFE\x02\x2A\x2B\xFE\x02\x5D\x2B\xFE\x02\x2A\x5F";
	_661 = decompress( 0 );
    _476 = NewString("#");
    _342 = NewString("_");
    _337 = NewString("!~");
    _289 = NewString("09");
    _331 = NewString("");
    _326 = NewString("{~");
    _324 = NewString("[`");
    _321 = NewString(":?");
    _318 = NewString(" /");
    _315 = NewString("af");
    _313 = NewString("AF");
    _311 = NewString("aeiouAEIOU");
    _310 = NewString("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ");
    _305 = NewString("\x07\x07");
    _304 = NewString("\x08\x08");
    _303 = NewString("\r\r");
    _302 = NewString("\n\n");
    _301 = NewString("\t\t");
    _298 = NewString(" ~");
    _282 = NewString("az");
    _285 = NewString("AZ");
    _292 = NewString("__");
    _258 = NewString("NXTCHR");
    _227 = NewString("xor_bits");
    _226 = NewString("trace");
    _224 = NewString("task_yield");
    _223 = NewString("task_suspend");
    _222 = NewString("task_status");
    _221 = NewString("task_self");
    _220 = NewString("task_schedule");
    _219 = NewString("task_list");
    _218 = NewString("task_create");
    _217 = NewString("task_clock_stop");
    _216 = NewString("task_clock_start");
    _215 = NewString("tan");
    _214 = NewString("tail");
    _213 = NewString("system_exec");
    _212 = NewString("system");
    _211 = NewString("sqrt");
    _210 = NewString("sprintf");
    _209 = NewString("splice");
    _208 = NewString("sin");
    _207 = NewString("sequence");
    _206 = NewString("routine_id");
    _205 = NewString("replace");
    _204 = NewString("repeat");
    _203 = NewString("remove");
    _202 = NewString("remainder");
    _201 = NewString("rand");
    _200 = NewString("puts");
    _199 = NewString("printf");
    _198 = NewString("print");
    _197 = NewString("prepend");
    _196 = NewString("power");
    _195 = NewString("position");
    _194 = NewString("poke4");
    _193 = NewString("poke2");
    _192 = NewString("poke");
    _191 = NewString("platform");
    _190 = NewString("pixel");
    _189 = NewString("peeks");
    _188 = NewString("peek_string");
    _187 = NewString("peek4u");
    _186 = NewString("peek4s");
    _185 = NewString("peek2u");
    _184 = NewString("peek2s");
    _183 = NewString("peek");
    _182 = NewString("or_bits");
    _181 = NewString("option_switches");
    _180 = NewString("open");
    _179 = NewString("object");
    _178 = NewString("not_bits");
    _177 = NewString("mem_set");
    _176 = NewString("mem_copy");
    _175 = NewString("match");
    _174 = NewString("machine_proc");
    _173 = NewString("machine_func");
    _172 = NewString("log");
    _171 = NewString("length");
    _170 = NewString("integer");
    _169 = NewString("insert");
    _168 = NewString("include_paths");
    _167 = NewString("head");
    _166 = NewString("hash");
    _165 = NewString("gets");
    _164 = NewString("getenv");
    _163 = NewString("getc");
    _162 = NewString("get_key");
    _161 = NewString("floor");
    _160 = NewString("find");
    _159 = NewString("equal");
    _158 = NewString("delete_routine");
    _157 = NewString("delete");
    _156 = NewString("date");
    _155 = NewString("cos");
    _154 = NewString("compare");
    _153 = NewString("command_line");
    _152 = NewString("close");
    _151 = NewString("clear_screen");
    _150 = NewString("call_proc");
    _149 = NewString("call_func");
    _148 = NewString("call");
    _147 = NewString("c_proc");
    _146 = NewString("c_func");
    _145 = NewString("atom");
    _144 = NewString("arctan");
    _143 = NewString("append");
    _142 = NewString("and_bits");
    _141 = NewString("abort");
    _140 = NewString("?");
    _138 = NewString("xor");
    _137 = NewString("without");
    _136 = NewString("with");
    _135 = NewString("while");
    _134 = NewString("until");
    _133 = NewString("type");
    _132 = NewString("to");
    _131 = NewString("then");
    _130 = NewString("switch");
    _129 = NewString("routine");
    _128 = NewString("return");
    _127 = NewString("retry");
    _126 = NewString("public");
    _125 = NewString("procedure");
    _124 = NewString("override");
    _123 = NewString("or");
    _122 = NewString("not");
    _121 = NewString("namespace");
    _120 = NewString("loop");
    _119 = NewString("label");
    _117 = NewString("ifdef");
    _116 = NewString("if");
    _115 = NewString("goto");
    _114 = NewString("global");
    _113 = NewString("function");
    _112 = NewString("for");
    _111 = NewString("fallthru");
    _110 = NewString("export");
    _109 = NewString("exit");
    _108 = NewString("enum");
    _107 = NewString("entry");
    _106 = NewString("end");
    _105 = NewString("elsifdef");
    _104 = NewString("elsif");
    _103 = NewString("elsedef");
    _102 = NewString("else");
    _101 = NewString("do");
    _100 = NewString("continue");
    _99 = NewString("constant");
    _98 = NewString("case");
    _97 = NewString("by");
    _96 = NewString("break");
    _95 = NewString("as");
    _94 = NewString("and");
    _89 = NewString("Copyright (c) 1997-2010 University of Cambridge\nAll Rights Reserved\n");
    _88 = NewString("PCRE v8.10");
    _86 = NewString("Copyright (c) 2007-2011 by OpenEuphoria Group.\nCopyright (c) 1993-2006 by Rapid Deployment Software.\nAll Rights Reserved.");
    _84 = NewString("Euphoria v");
    _82 = NewString(" for ");
    _78 = NewString("%d.%d.%d");
    _69 = NewString("%d.%d.%d %s (%s, %s)");
    _60 = NewString("%d.%d.%d %s (%d:%s, %s)");
    _27 = NewString("Unknown");
    _26 = NewString("NetBSD");
    _25 = NewString("OpenBSD");
    _24 = NewString("FreeBSD");
    _23 = NewString("OS X");
    _22 = NewString("Linux");
    _21 = NewString("Windows");
    _18 = NewString("development");
	_8vDigits_1526 = NewString("0123456789ABCDEFabcdef");
	_15MEMORY_PROTECTION_1827 = NewString("\x10\x20\x40\x80\x08\x04\x02\x01");
	_17DIGITS_2915 = NewString("0123456789");
	_17white_space_2953 = NewString(" \t\n\r");
	_17ESCAPE_CHARS_2958 = NewString("n'\"t\\r");
	_17ESCAPED_CHARS_2960 = NewString("\n'\"\t\\\r");
	_12DaysPerMonth_3461 = NewString("\x1F\x1C\x1F\x1E\x1F\x1E\x1F\x1F\x1E\x1F\x1E\x1F");
	_12EPOCH_1970_3464 = NewDouble( 62135856000.0000000000000000 );
	_22PI_4424 = NewDouble( 3.1415926535897931 );
	_22QUARTPI_4426 = NewDouble( 0.7853981633974484 );
	_22HALFPI_4428 = NewDouble( 1.5707963267948966 );
	_22TWOPI_4430 = NewDouble( 6.2831853071795862 );
	_22PISQR_4432 = NewDouble( 9.8696044010893580 );
	_22INVSQ2PI_4434 = NewDouble( 0.3989422804014336 );
	_22PHI_4436 = NewDouble( 1.6180339887498949 );
	_22E_4438 = NewDouble( 2.7182818284590455 );
	_22LN2_4440 = NewDouble( 0.6931471805599453 );
	_22INVLN2_4442 = NewDouble( 1.4426950408889634 );
	_22LN10_4444 = NewDouble( 2.3025850929940459 );
	_22INVLN10_4446 = NewDouble( 0.4342944819032519 );
	_22SQRT2_4448 = NewDouble( 1.4142135623730949 );
	_22HALFSQRT2_4450 = NewDouble( 0.7071067811865476 );
	_22SQRT3_4452 = NewDouble( 1.7320508075688772 );
	_22DEGREES_TO_RADIANS_4454 = NewDouble( 0.0174532925199433 );
	_22RADIANS_TO_DEGREES_4456 = NewDouble( 57.2957795130823229 );
	_22EULER_GAMMA_4458 = NewDouble( 0.5772156649015329 );
	_22SQRTE_4460 = NewDouble( 1.6487212707001282 );
	_22SQRT5_4467 = NewDouble( 2.2360679774997898 );
	_11SLASHES_7130 = NewString("\\/:");
	_11EOLSEP_7132 = NewString("\r\n");
	_11NULLDEVICE_7134 = NewString("NUL:");
	_11SHARED_LIB_EXT_7136 = NewString("dll");
	_29QFLAGS_11567 = NewString("t\\r'n\"");
	_30aleph_12149 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
	_30drem_12172 = NewString("\x40\x10\x04");
	_30dmul_12174 = NewString("\x04\x10\x40");
	_30ddiv_12176 = NewString("\x10\x04\x01");
	_30nc4_12178 = NewString("\x02\x03\x04\x01");
	_30nc3_12182 = NewString("\x03\x01\x02");
	_30ldrop_12184 = NewString("\x02\x01\x01");
	_33type_is_map_12975 = NewString("Eu:StdMap");
	_33INIT_OPERATIONS_12985 = NewString("\x01\x06\x07\x02\x03\x08");
	_33init_small_map_key_12990 = NewDouble( -75960.3589409999985950 );
	_37CMD_SWITCHES_15290 = NewString("-/");
	_38DISCONNECT_16710 = NewString("!disconnect!");
	_38LOCK_METHOD_16712 = NewString("lock_method");
	_38INIT_TABLES_16714 = NewString("init_tables");
	_38INIT_FREE_16716 = NewString("init_free");
	_38CONNECTION_16718 = NewString("?connection?");
	_50type_is_stack_22551 = NewString("Eu:StdStack");
	_53DNS_QUERY_RESERVED_22954 = NewDouble( 4278190080.0000000000000000 );
	_55alphanum_23146 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234567890");
	_55hexnums_23148 = NewString("0123456789ABCDEF");
	_54rand_chars_23430 = NewString("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
	_58SIGN_MASK_24039 = NewDouble( 4026531840.0000000000000000 );
	_58SIGN_FLAG_24041 = NewDouble( 2147483648.0000000000000000 );
	_58DOUBLE_FLAG_24042 = NewDouble( 2415919104.0000000000000000 );
	_58INT_FLAG_24044 = NewDouble( 2684354560.0000000000000000 );
	_58UINT_FLAG_24046 = NewDouble( 2952790016.0000000000000000 );
	_58FLOAT_FLAG_24048 = NewDouble( 3489660928.0000000000000000 );
	_58CSTRING_24050 = NewDouble( 4294967295.0000000000000000 );
	_58CBYTES_24051 = NewDouble( 2147483648.0000000000000000 );
}
