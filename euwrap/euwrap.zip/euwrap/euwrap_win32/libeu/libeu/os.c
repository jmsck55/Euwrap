// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _37instance()
{
    int _8611 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_INSTANCE, 0)*/
    _8611 = machine(55, 0);
    return _8611;
    ;
}


int  __stdcall _37get_pid()
{
    int _8614 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		if cur_pid = -1 then*/
    if (binary_op_a(NOTEQ, _37cur_pid_15306, -1)){
        goto L1; // [7] 43
    }

    /** 			cur_pid = dll:define_c_func( dll:open_dll("kernel32.dll"), "GetCurrentProcessId", {}, dll:C_DWORD)*/
    RefDS(_8613);
    _8614 = _13open_dll(_8613);
    RefDS(_8615);
    RefDS(_5);
    _0 = _13define_c_func(_8614, _8615, _5, 33554436);
    DeRef(_37cur_pid_15306);
    _37cur_pid_15306 = _0;
    _8614 = NOVALUE;

    /** 			if cur_pid >= 0 then*/
    if (binary_op_a(LESS, _37cur_pid_15306, 0)){
        goto L2; // [28] 42
    }

    /** 				cur_pid = c_func(cur_pid, {})*/
    _0 = _37cur_pid_15306;
    _37cur_pid_15306 = call_c(1, _37cur_pid_15306, _5);
    DeRef(_0);
L2: 
L1: 

    /** 		return cur_pid*/
    Ref(_37cur_pid_15306);
    return _37cur_pid_15306;
    ;
}


int  __stdcall _37uname()
{
    int _buf_15325 = NOVALUE;
    int _sbuf_15326 = NOVALUE;
    int _maj_15327 = NOVALUE;
    int _mine_15328 = NOVALUE;
    int _build_15329 = NOVALUE;
    int _plat_15330 = NOVALUE;
    int _8720 = NOVALUE;
    int _8718 = NOVALUE;
    int _8717 = NOVALUE;
    int _8715 = NOVALUE;
    int _8714 = NOVALUE;
    int _8709 = NOVALUE;
    int _8708 = NOVALUE;
    int _8702 = NOVALUE;
    int _8701 = NOVALUE;
    int _8697 = NOVALUE;
    int _8696 = NOVALUE;
    int _8695 = NOVALUE;
    int _8692 = NOVALUE;
    int _8691 = NOVALUE;
    int _8690 = NOVALUE;
    int _8687 = NOVALUE;
    int _8686 = NOVALUE;
    int _8685 = NOVALUE;
    int _8682 = NOVALUE;
    int _8681 = NOVALUE;
    int _8680 = NOVALUE;
    int _8677 = NOVALUE;
    int _8676 = NOVALUE;
    int _8675 = NOVALUE;
    int _8671 = NOVALUE;
    int _8670 = NOVALUE;
    int _8669 = NOVALUE;
    int _8666 = NOVALUE;
    int _8665 = NOVALUE;
    int _8664 = NOVALUE;
    int _8661 = NOVALUE;
    int _8660 = NOVALUE;
    int _8659 = NOVALUE;
    int _8640 = NOVALUE;
    int _8639 = NOVALUE;
    int _8633 = NOVALUE;
    int _8631 = NOVALUE;
    int _8629 = NOVALUE;
    int _8627 = NOVALUE;
    int _8626 = NOVALUE;
    int _8625 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		atom buf*/

    /** 		sequence sbuf*/

    /** 		integer maj, mine, build, plat*/

    /** 		buf = machine:allocate(148)*/
    _0 = _buf_15325;
    _buf_15325 = _14allocate(148, 0);
    DeRef(_0);

    /** 		poke4(buf, 148)*/
    if (IS_ATOM_INT(_buf_15325)){
        poke4_addr = (unsigned long *)_buf_15325;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_buf_15325)->dbl);
    }
    *poke4_addr = (unsigned long)148;

    /** 		if c_func(M_UNAME, {buf}) then*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_buf_15325);
    *((int *)(_2+4)) = _buf_15325;
    _8625 = MAKE_SEQ(_1);
    _8626 = call_c(1, _37M_UNAME_15318, _8625);
    DeRefDS(_8625);
    _8625 = NOVALUE;
    if (_8626 == 0) {
        DeRef(_8626);
        _8626 = NOVALUE;
        goto L1; // [34] 529
    }
    else {
        if (!IS_ATOM_INT(_8626) && DBL_PTR(_8626)->dbl == 0.0){
            DeRef(_8626);
            _8626 = NOVALUE;
            goto L1; // [34] 529
        }
        DeRef(_8626);
        _8626 = NOVALUE;
    }
    DeRef(_8626);
    _8626 = NOVALUE;

    /** 			maj = peek4u(buf+4)*/
    if (IS_ATOM_INT(_buf_15325)) {
        _8627 = _buf_15325 + 4;
        if ((long)((unsigned long)_8627 + (unsigned long)HIGH_BITS) >= 0) 
        _8627 = NewDouble((double)_8627);
    }
    else {
        _8627 = NewDouble(DBL_PTR(_buf_15325)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_8627)) {
        _maj_15327 = *(unsigned long *)_8627;
        if ((unsigned)_maj_15327 > (unsigned)MAXINT)
        _maj_15327 = NewDouble((double)(unsigned long)_maj_15327);
    }
    else {
        _maj_15327 = *(unsigned long *)(unsigned long)(DBL_PTR(_8627)->dbl);
        if ((unsigned)_maj_15327 > (unsigned)MAXINT)
        _maj_15327 = NewDouble((double)(unsigned long)_maj_15327);
    }
    DeRef(_8627);
    _8627 = NOVALUE;
    if (!IS_ATOM_INT(_maj_15327)) {
        _1 = (long)(DBL_PTR(_maj_15327)->dbl);
        DeRefDS(_maj_15327);
        _maj_15327 = _1;
    }

    /** 			mine = peek4u(buf+8)*/
    if (IS_ATOM_INT(_buf_15325)) {
        _8629 = _buf_15325 + 8;
        if ((long)((unsigned long)_8629 + (unsigned long)HIGH_BITS) >= 0) 
        _8629 = NewDouble((double)_8629);
    }
    else {
        _8629 = NewDouble(DBL_PTR(_buf_15325)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_8629)) {
        _mine_15328 = *(unsigned long *)_8629;
        if ((unsigned)_mine_15328 > (unsigned)MAXINT)
        _mine_15328 = NewDouble((double)(unsigned long)_mine_15328);
    }
    else {
        _mine_15328 = *(unsigned long *)(unsigned long)(DBL_PTR(_8629)->dbl);
        if ((unsigned)_mine_15328 > (unsigned)MAXINT)
        _mine_15328 = NewDouble((double)(unsigned long)_mine_15328);
    }
    DeRef(_8629);
    _8629 = NOVALUE;
    if (!IS_ATOM_INT(_mine_15328)) {
        _1 = (long)(DBL_PTR(_mine_15328)->dbl);
        DeRefDS(_mine_15328);
        _mine_15328 = _1;
    }

    /** 			build = peek4u(buf+12)*/
    if (IS_ATOM_INT(_buf_15325)) {
        _8631 = _buf_15325 + 12;
        if ((long)((unsigned long)_8631 + (unsigned long)HIGH_BITS) >= 0) 
        _8631 = NewDouble((double)_8631);
    }
    else {
        _8631 = NewDouble(DBL_PTR(_buf_15325)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_8631)) {
        _build_15329 = *(unsigned long *)_8631;
        if ((unsigned)_build_15329 > (unsigned)MAXINT)
        _build_15329 = NewDouble((double)(unsigned long)_build_15329);
    }
    else {
        _build_15329 = *(unsigned long *)(unsigned long)(DBL_PTR(_8631)->dbl);
        if ((unsigned)_build_15329 > (unsigned)MAXINT)
        _build_15329 = NewDouble((double)(unsigned long)_build_15329);
    }
    DeRef(_8631);
    _8631 = NOVALUE;
    if (!IS_ATOM_INT(_build_15329)) {
        _1 = (long)(DBL_PTR(_build_15329)->dbl);
        DeRefDS(_build_15329);
        _build_15329 = _1;
    }

    /** 			plat = peek4u(buf+16)*/
    if (IS_ATOM_INT(_buf_15325)) {
        _8633 = _buf_15325 + 16;
        if ((long)((unsigned long)_8633 + (unsigned long)HIGH_BITS) >= 0) 
        _8633 = NewDouble((double)_8633);
    }
    else {
        _8633 = NewDouble(DBL_PTR(_buf_15325)->dbl + (double)16);
    }
    if (IS_ATOM_INT(_8633)) {
        _plat_15330 = *(unsigned long *)_8633;
        if ((unsigned)_plat_15330 > (unsigned)MAXINT)
        _plat_15330 = NewDouble((double)(unsigned long)_plat_15330);
    }
    else {
        _plat_15330 = *(unsigned long *)(unsigned long)(DBL_PTR(_8633)->dbl);
        if ((unsigned)_plat_15330 > (unsigned)MAXINT)
        _plat_15330 = NewDouble((double)(unsigned long)_plat_15330);
    }
    DeRef(_8633);
    _8633 = NOVALUE;
    if (!IS_ATOM_INT(_plat_15330)) {
        _1 = (long)(DBL_PTR(_plat_15330)->dbl);
        DeRefDS(_plat_15330);
        _plat_15330 = _1;
    }

    /** 			sbuf = {}*/
    RefDS(_5);
    DeRef(_sbuf_15326);
    _sbuf_15326 = _5;

    /** 			if plat = 0 then*/
    if (_plat_15330 != 0)
    goto L2; // [90] 117

    /** 				sbuf = append(sbuf, "Win32s")*/
    RefDS(_8636);
    Append(&_sbuf_15326, _sbuf_15326, _8636);

    /** 				sbuf = append(sbuf, sprintf("Windows %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_15327;
    ((int *)_2)[2] = _mine_15328;
    _8639 = MAKE_SEQ(_1);
    _8640 = EPrintf(-9999999, _8638, _8639);
    DeRefDS(_8639);
    _8639 = NOVALUE;
    RefDS(_8640);
    Append(&_sbuf_15326, _sbuf_15326, _8640);
    DeRefDS(_8640);
    _8640 = NOVALUE;
    goto L3; // [114] 489
L2: 

    /** 			elsif plat = 1 then*/
    if (_plat_15330 != 1)
    goto L4; // [119] 184

    /** 				sbuf = append(sbuf, "Win9x")*/
    RefDS(_8643);
    Append(&_sbuf_15326, _sbuf_15326, _8643);

    /** 				if mine = 0 then*/
    if (_mine_15328 != 0)
    goto L5; // [131] 144

    /** 					sbuf = append(sbuf, "Win95")*/
    RefDS(_8646);
    Append(&_sbuf_15326, _sbuf_15326, _8646);
    goto L3; // [141] 489
L5: 

    /** 				elsif mine = 10 then*/
    if (_mine_15328 != 10)
    goto L6; // [146] 159

    /** 					sbuf = append(sbuf, "Win98")*/
    RefDS(_8649);
    Append(&_sbuf_15326, _sbuf_15326, _8649);
    goto L3; // [156] 489
L6: 

    /** 				elsif mine = 90 then*/
    if (_mine_15328 != 90)
    goto L7; // [161] 174

    /** 					sbuf = append(sbuf, "WinME")*/
    RefDS(_8652);
    Append(&_sbuf_15326, _sbuf_15326, _8652);
    goto L3; // [171] 489
L7: 

    /** 					sbuf = append(sbuf, "Unknown")*/
    RefDS(_8654);
    Append(&_sbuf_15326, _sbuf_15326, _8654);
    goto L3; // [181] 489
L4: 

    /** 			elsif plat = 2 then*/
    if (_plat_15330 != 2)
    goto L8; // [186] 439

    /** 				sbuf = append(sbuf, "WinNT")*/
    RefDS(_8657);
    Append(&_sbuf_15326, _sbuf_15326, _8657);

    /** 				if maj = 6 and mine = 1 then*/
    _8659 = (_maj_15327 == 6);
    if (_8659 == 0) {
        goto L9; // [202] 223
    }
    _8661 = (_mine_15328 == 1);
    if (_8661 == 0)
    {
        DeRef(_8661);
        _8661 = NOVALUE;
        goto L9; // [211] 223
    }
    else{
        DeRef(_8661);
        _8661 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Windows7")*/
    RefDS(_8662);
    Append(&_sbuf_15326, _sbuf_15326, _8662);
    goto L3; // [220] 489
L9: 

    /** 				elsif maj = 6 and mine = 0 then*/
    _8664 = (_maj_15327 == 6);
    if (_8664 == 0) {
        goto LA; // [229] 250
    }
    _8666 = (_mine_15328 == 0);
    if (_8666 == 0)
    {
        DeRef(_8666);
        _8666 = NOVALUE;
        goto LA; // [238] 250
    }
    else{
        DeRef(_8666);
        _8666 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Vista")*/
    RefDS(_8667);
    Append(&_sbuf_15326, _sbuf_15326, _8667);
    goto L3; // [247] 489
LA: 

    /** 				elsif maj = 5 and mine = 1 or 2 then*/
    _8669 = (_maj_15327 == 5);
    if (_8669 == 0) {
        _8670 = 0;
        goto LB; // [256] 268
    }
    _8671 = (_mine_15328 == 1);
    _8670 = (_8671 != 0);
LB: 
    if (_8670 != 0) {
        goto LC; // [268] 277
    }
LC: 

    /** 					sbuf = append(sbuf, "WinXP")*/
    RefDS(_8673);
    Append(&_sbuf_15326, _sbuf_15326, _8673);
    goto L3; // [283] 489

    /** 				elsif maj = 5 and mine = 0 then*/
    _8675 = (_maj_15327 == 5);
    if (_8675 == 0) {
        goto LD; // [292] 313
    }
    _8677 = (_mine_15328 == 0);
    if (_8677 == 0)
    {
        DeRef(_8677);
        _8677 = NOVALUE;
        goto LD; // [301] 313
    }
    else{
        DeRef(_8677);
        _8677 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Win2K")*/
    RefDS(_8678);
    Append(&_sbuf_15326, _sbuf_15326, _8678);
    goto L3; // [310] 489
LD: 

    /** 				elsif maj = 4 and mine = 0 then*/
    _8680 = (_maj_15327 == 4);
    if (_8680 == 0) {
        goto LE; // [319] 340
    }
    _8682 = (_mine_15328 == 0);
    if (_8682 == 0)
    {
        DeRef(_8682);
        _8682 = NOVALUE;
        goto LE; // [328] 340
    }
    else{
        DeRef(_8682);
        _8682 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 4.0")*/
    RefDS(_8683);
    Append(&_sbuf_15326, _sbuf_15326, _8683);
    goto L3; // [337] 489
LE: 

    /** 				elsif maj = 3 and mine = 51 then*/
    _8685 = (_maj_15327 == 3);
    if (_8685 == 0) {
        goto LF; // [346] 367
    }
    _8687 = (_mine_15328 == 51);
    if (_8687 == 0)
    {
        DeRef(_8687);
        _8687 = NOVALUE;
        goto LF; // [355] 367
    }
    else{
        DeRef(_8687);
        _8687 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.51")*/
    RefDS(_8688);
    Append(&_sbuf_15326, _sbuf_15326, _8688);
    goto L3; // [364] 489
LF: 

    /** 				elsif maj = 3 and mine = 50 then --is it 50 or 5?*/
    _8690 = (_maj_15327 == 3);
    if (_8690 == 0) {
        goto L10; // [373] 394
    }
    _8692 = (_mine_15328 == 50);
    if (_8692 == 0)
    {
        DeRef(_8692);
        _8692 = NOVALUE;
        goto L10; // [382] 394
    }
    else{
        DeRef(_8692);
        _8692 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.5")*/
    RefDS(_8693);
    Append(&_sbuf_15326, _sbuf_15326, _8693);
    goto L3; // [391] 489
L10: 

    /** 				elsif maj = 3 and mine = 1 then*/
    _8695 = (_maj_15327 == 3);
    if (_8695 == 0) {
        goto L11; // [400] 421
    }
    _8697 = (_mine_15328 == 1);
    if (_8697 == 0)
    {
        DeRef(_8697);
        _8697 = NOVALUE;
        goto L11; // [409] 421
    }
    else{
        DeRef(_8697);
        _8697 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.1")*/
    RefDS(_8698);
    Append(&_sbuf_15326, _sbuf_15326, _8698);
    goto L3; // [418] 489
L11: 

    /** 					sbuf = append(sbuf, sprintf("WinNT %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_15327;
    ((int *)_2)[2] = _mine_15328;
    _8701 = MAKE_SEQ(_1);
    _8702 = EPrintf(-9999999, _8700, _8701);
    DeRefDS(_8701);
    _8701 = NOVALUE;
    RefDS(_8702);
    Append(&_sbuf_15326, _sbuf_15326, _8702);
    DeRefDS(_8702);
    _8702 = NOVALUE;
    goto L3; // [436] 489
L8: 

    /** 			elsif plat = 3 then*/
    if (_plat_15330 != 3)
    goto L12; // [441] 468

    /** 				sbuf = append(sbuf, "WinCE")*/
    RefDS(_8705);
    Append(&_sbuf_15326, _sbuf_15326, _8705);

    /** 				sbuf = append(sbuf, sprintf("WinCE %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_15327;
    ((int *)_2)[2] = _mine_15328;
    _8708 = MAKE_SEQ(_1);
    _8709 = EPrintf(-9999999, _8707, _8708);
    DeRefDS(_8708);
    _8708 = NOVALUE;
    RefDS(_8709);
    Append(&_sbuf_15326, _sbuf_15326, _8709);
    DeRefDS(_8709);
    _8709 = NOVALUE;
    goto L3; // [465] 489
L12: 

    /** 				sbuf = append(sbuf, "Unknown Windows")*/
    RefDS(_8711);
    Append(&_sbuf_15326, _sbuf_15326, _8711);

    /** 				sbuf = append(sbuf, sprintf("Version %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_15327;
    ((int *)_2)[2] = _mine_15328;
    _8714 = MAKE_SEQ(_1);
    _8715 = EPrintf(-9999999, _8713, _8714);
    DeRefDS(_8714);
    _8714 = NOVALUE;
    RefDS(_8715);
    Append(&_sbuf_15326, _sbuf_15326, _8715);
    DeRefDS(_8715);
    _8715 = NOVALUE;
L3: 

    /** 			sbuf = append(sbuf, peek_string(buf+20))*/
    if (IS_ATOM_INT(_buf_15325)) {
        _8717 = _buf_15325 + 20;
        if ((long)((unsigned long)_8717 + (unsigned long)HIGH_BITS) >= 0) 
        _8717 = NewDouble((double)_8717);
    }
    else {
        _8717 = NewDouble(DBL_PTR(_buf_15325)->dbl + (double)20);
    }
    if (IS_ATOM_INT(_8717)) {
        _8718 =  NewString((char *)_8717);
    }
    else {
        _8718 = NewString((char *)(unsigned long)(DBL_PTR(_8717)->dbl));
    }
    DeRef(_8717);
    _8717 = NOVALUE;
    RefDS(_8718);
    Append(&_sbuf_15326, _sbuf_15326, _8718);
    DeRefDS(_8718);
    _8718 = NOVALUE;

    /** 			sbuf &= {plat, build, mine, maj}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _plat_15330;
    *((int *)(_2+8)) = _build_15329;
    *((int *)(_2+12)) = _mine_15328;
    *((int *)(_2+16)) = _maj_15327;
    _8720 = MAKE_SEQ(_1);
    Concat((object_ptr)&_sbuf_15326, _sbuf_15326, _8720);
    DeRefDS(_8720);
    _8720 = NOVALUE;

    /** 			machine:free( buf )*/
    Ref(_buf_15325);
    _14free(_buf_15325);

    /** 			return sbuf*/
    DeRef(_buf_15325);
    DeRef(_8659);
    _8659 = NOVALUE;
    DeRef(_8664);
    _8664 = NOVALUE;
    DeRef(_8669);
    _8669 = NOVALUE;
    DeRef(_8671);
    _8671 = NOVALUE;
    DeRef(_8675);
    _8675 = NOVALUE;
    DeRef(_8680);
    _8680 = NOVALUE;
    DeRef(_8685);
    _8685 = NOVALUE;
    DeRef(_8690);
    _8690 = NOVALUE;
    DeRef(_8695);
    _8695 = NOVALUE;
    return _sbuf_15326;
    goto L13; // [526] 541
L1: 

    /** 			machine:free( buf )*/
    Ref(_buf_15325);
    _14free(_buf_15325);

    /** 			return {}*/
    RefDS(_5);
    DeRef(_buf_15325);
    DeRef(_sbuf_15326);
    DeRef(_8659);
    _8659 = NOVALUE;
    DeRef(_8664);
    _8664 = NOVALUE;
    DeRef(_8669);
    _8669 = NOVALUE;
    DeRef(_8671);
    _8671 = NOVALUE;
    DeRef(_8675);
    _8675 = NOVALUE;
    DeRef(_8680);
    _8680 = NOVALUE;
    DeRef(_8685);
    _8685 = NOVALUE;
    DeRef(_8690);
    _8690 = NOVALUE;
    DeRef(_8695);
    _8695 = NOVALUE;
    return _5;
L13: 
    ;
}


int  __stdcall _37is_win_nt()
{
    int _s_15453 = NOVALUE;
    int _8725 = NOVALUE;
    int _8724 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		sequence s*/

    /** 		s = uname()*/
    _0 = _s_15453;
    _s_15453 = _37uname();
    DeRef(_0);

    /** 		return equal(s[1], "WinNT")*/
    _2 = (int)SEQ_PTR(_s_15453);
    _8724 = (int)*(((s1_ptr)_2)->base + 1);
    if (_8724 == _8657)
    _8725 = 1;
    else if (IS_ATOM_INT(_8724) && IS_ATOM_INT(_8657))
    _8725 = 0;
    else
    _8725 = (compare(_8724, _8657) == 0);
    _8724 = NOVALUE;
    DeRefDS(_s_15453);
    return _8725;
    ;
}


int  __stdcall _37setenv(int _name_15459, int _val_15460, int _overwrite_15461)
{
    int _8727 = NOVALUE;
    int _8726 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_15461)) {
        _1 = (long)(DBL_PTR(_overwrite_15461)->dbl);
        DeRefDS(_overwrite_15461);
        _overwrite_15461 = _1;
    }

    /** 	return machine_func(M_SET_ENV, {name, val, overwrite})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_15459);
    *((int *)(_2+4)) = _name_15459;
    RefDS(_val_15460);
    *((int *)(_2+8)) = _val_15460;
    *((int *)(_2+12)) = _overwrite_15461;
    _8726 = MAKE_SEQ(_1);
    _8727 = machine(73, _8726);
    DeRefDS(_8726);
    _8726 = NOVALUE;
    DeRefDS(_name_15459);
    DeRefDS(_val_15460);
    return _8727;
    ;
}


int  __stdcall _37unsetenv(int _env_15466)
{
    int _8729 = NOVALUE;
    int _8728 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_UNSET_ENV, {env})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_env_15466);
    *((int *)(_2+4)) = _env_15466;
    _8728 = MAKE_SEQ(_1);
    _8729 = machine(74, _8728);
    DeRefDS(_8728);
    _8728 = NOVALUE;
    DeRefDS(_env_15466);
    return _8729;
    ;
}


void  __stdcall _37sleep(int _t_15471)
{
    int _0, _1, _2;
    

    /** 	if t >= 0 then*/
    if (binary_op_a(LESS, _t_15471, 0)){
        goto L1; // [3] 13
    }

    /** 		machine_proc(M_SLEEP, t)*/
    machine(64, _t_15471);
L1: 

    /** end procedure*/
    DeRef(_t_15471);
    return;
    ;
}



// 0x313AF91C
