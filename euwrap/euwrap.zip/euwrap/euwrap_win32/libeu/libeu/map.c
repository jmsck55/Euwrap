// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _33map(int _obj_p_12995)
{
    int _m__12999 = NOVALUE;
    int _7376 = NOVALUE;
    int _7375 = NOVALUE;
    int _7374 = NOVALUE;
    int _7373 = NOVALUE;
    int _7372 = NOVALUE;
    int _7371 = NOVALUE;
    int _7370 = NOVALUE;
    int _7369 = NOVALUE;
    int _7368 = NOVALUE;
    int _7367 = NOVALUE;
    int _7365 = NOVALUE;
    int _7364 = NOVALUE;
    int _7363 = NOVALUE;
    int _7362 = NOVALUE;
    int _7360 = NOVALUE;
    int _7359 = NOVALUE;
    int _7358 = NOVALUE;
    int _7357 = NOVALUE;
    int _7355 = NOVALUE;
    int _7354 = NOVALUE;
    int _7353 = NOVALUE;
    int _7352 = NOVALUE;
    int _7351 = NOVALUE;
    int _7350 = NOVALUE;
    int _7349 = NOVALUE;
    int _7348 = NOVALUE;
    int _7347 = NOVALUE;
    int _7346 = NOVALUE;
    int _7344 = NOVALUE;
    int _7342 = NOVALUE;
    int _7341 = NOVALUE;
    int _7339 = NOVALUE;
    int _7337 = NOVALUE;
    int _7336 = NOVALUE;
    int _7334 = NOVALUE;
    int _7333 = NOVALUE;
    int _7331 = NOVALUE;
    int _7329 = NOVALUE;
    int _7327 = NOVALUE;
    int _7324 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_12995);
    RefDS(_5);
    _7324 = _28valid(_obj_p_12995, _5);
    if (IS_ATOM_INT(_7324)) {
        if (_7324 != 0){
            DeRef(_7324);
            _7324 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_7324)->dbl != 0.0){
            DeRef(_7324);
            _7324 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_7324);
    _7324 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__12999);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_obj_p_12995)){
        _m__12999 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_12995)->dbl));
    }
    else{
        _m__12999 = (int)*(((s1_ptr)_2)->base + _obj_p_12995);
    }
    Ref(_m__12999);

    /** 	if not sequence(m_) then return 0 end if*/
    _7327 = IS_SEQUENCE(_m__12999);
    if (_7327 != 0)
    goto L2; // [31] 39
    _7327 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__12999)){
            _7329 = SEQ_PTR(_m__12999)->length;
    }
    else {
        _7329 = 1;
    }
    if (_7329 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__12999)){
            _7331 = SEQ_PTR(_m__12999)->length;
    }
    else {
        _7331 = 1;
    }
    if (_7331 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7333 = (int)*(((s1_ptr)_2)->base + 1);
    if (_7333 == _33type_is_map_12975)
    _7334 = 1;
    else if (IS_ATOM_INT(_7333) && IS_ATOM_INT(_33type_is_map_12975))
    _7334 = 0;
    else
    _7334 = (compare(_7333, _33type_is_map_12975) == 0);
    _7333 = NOVALUE;
    if (_7334 != 0)
    goto L5; // [77] 85
    _7334 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7336 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7336))
    _7337 = 1;
    else if (IS_ATOM_DBL(_7336))
    _7337 = IS_ATOM_INT(DoubleToInt(_7336));
    else
    _7337 = 0;
    _7336 = NOVALUE;
    if (_7337 != 0)
    goto L6; // [94] 102
    _7337 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7339 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _7339, 0)){
        _7339 = NOVALUE;
        goto L7; // [108] 117
    }
    _7339 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7341 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7341))
    _7342 = 1;
    else if (IS_ATOM_DBL(_7341))
    _7342 = IS_ATOM_INT(DoubleToInt(_7341));
    else
    _7342 = 0;
    _7341 = NOVALUE;
    if (_7342 != 0)
    goto L8; // [126] 134
    _7342 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7344 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _7344, 0)){
        _7344 = NOVALUE;
        goto L9; // [140] 149
    }
    _7344 = NOVALUE;
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7346 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7346 == 115)
    _7347 = 1;
    else if (IS_ATOM_INT(_7346) && IS_ATOM_INT(115))
    _7347 = 0;
    else
    _7347 = (compare(_7346, 115) == 0);
    _7346 = NOVALUE;
    if (_7347 == 0)
    {
        _7347 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _7347 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7348 = (int)*(((s1_ptr)_2)->base + 5);
    _7349 = IS_ATOM(_7348);
    _7348 = NOVALUE;
    if (_7349 == 0)
    {
        _7349 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _7349 = NOVALUE;
    }
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7350 = (int)*(((s1_ptr)_2)->base + 6);
    _7351 = IS_ATOM(_7350);
    _7350 = NOVALUE;
    if (_7351 == 0)
    {
        _7351 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _7351 = NOVALUE;
    }
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7352 = (int)*(((s1_ptr)_2)->base + 7);
    _7353 = IS_ATOM(_7352);
    _7352 = NOVALUE;
    if (_7353 == 0)
    {
        _7353 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _7353 = NOVALUE;
    }
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7354 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7354)){
            _7355 = SEQ_PTR(_7354)->length;
    }
    else {
        _7355 = 1;
    }
    _7354 = NOVALUE;
    if (_7355 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7357 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7357)){
            _7358 = SEQ_PTR(_7357)->length;
    }
    else {
        _7358 = 1;
    }
    _7357 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12999);
    _7359 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7359)){
            _7360 = SEQ_PTR(_7359)->length;
    }
    else {
        _7360 = 1;
    }
    _7359 = NOVALUE;
    if (_7358 == _7360)
    goto LF; // [247] 256
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7362 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7362)){
            _7363 = SEQ_PTR(_7362)->length;
    }
    else {
        _7363 = 1;
    }
    _7362 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12999);
    _7364 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7364)){
            _7365 = SEQ_PTR(_7364)->length;
    }
    else {
        _7365 = 1;
    }
    _7364 = NOVALUE;
    if (_7363 == _7365)
    goto L10; // [272] 366
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7367 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7367 == 76)
    _7368 = 1;
    else if (IS_ATOM_INT(_7367) && IS_ATOM_INT(76))
    _7368 = 0;
    else
    _7368 = (compare(_7367, 76) == 0);
    _7367 = NOVALUE;
    if (_7368 == 0)
    {
        _7368 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _7368 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7369 = (int)*(((s1_ptr)_2)->base + 5);
    _7370 = IS_ATOM(_7369);
    _7369 = NOVALUE;
    if (_7370 == 0)
    {
        _7370 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _7370 = NOVALUE;
    }
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7371 = (int)*(((s1_ptr)_2)->base + 6);
    _7372 = IS_ATOM(_7371);
    _7371 = NOVALUE;
    if (_7372 == 0)
    {
        _7372 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _7372 = NOVALUE;
    }
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12999);
    _7373 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7373)){
            _7374 = SEQ_PTR(_7373)->length;
    }
    else {
        _7374 = 1;
    }
    _7373 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12999);
    _7375 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7375)){
            _7376 = SEQ_PTR(_7375)->length;
    }
    else {
        _7376 = 1;
    }
    _7375 = NOVALUE;
    if (_7374 == _7376)
    goto L10; // [347] 366
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    _7373 = NOVALUE;
    _7375 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    _7373 = NOVALUE;
    _7375 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_12995);
    DeRef(_m__12999);
    _7354 = NOVALUE;
    _7357 = NOVALUE;
    _7359 = NOVALUE;
    _7362 = NOVALUE;
    _7364 = NOVALUE;
    _7373 = NOVALUE;
    _7375 = NOVALUE;
    return 1;
    ;
}


int  __stdcall _33calc_hash(int _key_p_13076, int _max_hash_p_13077)
{
    int _ret__13078 = NOVALUE;
    int _7381 = NOVALUE;
    int _7380 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_hash_p_13077)) {
        _1 = (long)(DBL_PTR(_max_hash_p_13077)->dbl);
        DeRefDS(_max_hash_p_13077);
        _max_hash_p_13077 = _1;
    }

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    _ret__13078 = calc_hash(_key_p_13076, -6);
    if (!IS_ATOM_INT(_ret__13078)) {
        _1 = (long)(DBL_PTR(_ret__13078)->dbl);
        DeRefDS(_ret__13078);
        _ret__13078 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _7380 = (_ret__13078 % _max_hash_p_13077);
    _7381 = _7380 + 1;
    if (_7381 > MAXINT){
        _7381 = NewDouble((double)_7381);
    }
    _7380 = NOVALUE;
    DeRef(_key_p_13076);
    return _7381;
    ;
}


int  __stdcall _33threshold(int _new_value_p_13084)
{
    int _old_value__13087 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_value_p_13084)) {
        _1 = (long)(DBL_PTR(_new_value_p_13084)->dbl);
        DeRefDS(_new_value_p_13084);
        _new_value_p_13084 = _1;
    }

    /** 	if new_value_p < 1 then*/
    if (_new_value_p_13084 >= 1)
    goto L1; // [5] 18

    /** 		return threshold_size*/
    return _33threshold_size_12989;
L1: 

    /** 	integer old_value_ = threshold_size*/
    _old_value__13087 = _33threshold_size_12989;

    /** 	threshold_size = new_value_p*/
    _33threshold_size_12989 = _new_value_p_13084;

    /** 	return old_value_*/
    return _old_value__13087;
    ;
}


int  __stdcall _33type_of(int _the_map_p_13090)
{
    int _7384 = NOVALUE;
    int _7383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eumem:ram_space[the_map_p][MAP_TYPE]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13090)){
        _7383 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13090)->dbl));
    }
    else{
        _7383 = (int)*(((s1_ptr)_2)->base + _the_map_p_13090);
    }
    _2 = (int)SEQ_PTR(_7383);
    _7384 = (int)*(((s1_ptr)_2)->base + 4);
    _7383 = NOVALUE;
    Ref(_7384);
    DeRef(_the_map_p_13090);
    return _7384;
    ;
}


void  __stdcall _33rehash(int _the_map_p_13095, int _requested_bucket_size_p_13096)
{
    int _size__13097 = NOVALUE;
    int _index_2__13098 = NOVALUE;
    int _old_key_buckets__13099 = NOVALUE;
    int _old_val_buckets__13100 = NOVALUE;
    int _new_key_buckets__13101 = NOVALUE;
    int _new_val_buckets__13102 = NOVALUE;
    int _key__13103 = NOVALUE;
    int _value__13104 = NOVALUE;
    int _pos_13105 = NOVALUE;
    int _new_keys_13106 = NOVALUE;
    int _in_use_13107 = NOVALUE;
    int _elem_count_13108 = NOVALUE;
    int _calc_hash_1__tmp_at227_13151 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_13150 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_13149 = NOVALUE;
    int _7444 = NOVALUE;
    int _7443 = NOVALUE;
    int _7442 = NOVALUE;
    int _7441 = NOVALUE;
    int _7440 = NOVALUE;
    int _7439 = NOVALUE;
    int _7438 = NOVALUE;
    int _7437 = NOVALUE;
    int _7436 = NOVALUE;
    int _7434 = NOVALUE;
    int _7433 = NOVALUE;
    int _7432 = NOVALUE;
    int _7429 = NOVALUE;
    int _7428 = NOVALUE;
    int _7426 = NOVALUE;
    int _7425 = NOVALUE;
    int _7424 = NOVALUE;
    int _7423 = NOVALUE;
    int _7421 = NOVALUE;
    int _7419 = NOVALUE;
    int _7417 = NOVALUE;
    int _7414 = NOVALUE;
    int _7412 = NOVALUE;
    int _7411 = NOVALUE;
    int _7410 = NOVALUE;
    int _7409 = NOVALUE;
    int _7407 = NOVALUE;
    int _7405 = NOVALUE;
    int _7403 = NOVALUE;
    int _7402 = NOVALUE;
    int _7400 = NOVALUE;
    int _7398 = NOVALUE;
    int _7395 = NOVALUE;
    int _7393 = NOVALUE;
    int _7392 = NOVALUE;
    int _7391 = NOVALUE;
    int _7390 = NOVALUE;
    int _7389 = NOVALUE;
    int _7386 = NOVALUE;
    int _7385 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_13095)) {
        _1 = (long)(DBL_PTR(_the_map_p_13095)->dbl);
        DeRefDS(_the_map_p_13095);
        _the_map_p_13095 = _1;
    }
    if (!IS_ATOM_INT(_requested_bucket_size_p_13096)) {
        _1 = (long)(DBL_PTR(_requested_bucket_size_p_13096)->dbl);
        DeRefDS(_requested_bucket_size_p_13096);
        _requested_bucket_size_p_13096 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7385 = (int)*(((s1_ptr)_2)->base + _the_map_p_13095);
    _2 = (int)SEQ_PTR(_7385);
    _7386 = (int)*(((s1_ptr)_2)->base + 4);
    _7385 = NOVALUE;
    if (binary_op_a(NOTEQ, _7386, 115)){
        _7386 = NOVALUE;
        goto L1; // [17] 27
    }
    _7386 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__13099);
    DeRef(_old_val_buckets__13100);
    DeRef(_new_key_buckets__13101);
    DeRef(_new_val_buckets__13102);
    DeRef(_key__13103);
    DeRef(_value__13104);
    DeRef(_new_keys_13106);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_13096 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7389 = (int)*(((s1_ptr)_2)->base + _the_map_p_13095);
    _2 = (int)SEQ_PTR(_7389);
    _7390 = (int)*(((s1_ptr)_2)->base + 5);
    _7389 = NOVALUE;
    if (IS_SEQUENCE(_7390)){
            _7391 = SEQ_PTR(_7390)->length;
    }
    else {
        _7391 = 1;
    }
    _7390 = NOVALUE;
    _7392 = NewDouble((double)_7391 * DBL_PTR(_6977)->dbl);
    _7391 = NOVALUE;
    _7393 = unary_op(FLOOR, _7392);
    DeRefDS(_7392);
    _7392 = NOVALUE;
    if (IS_ATOM_INT(_7393)) {
        _size__13097 = _7393 + 1;
    }
    else
    { // coercing _size__13097 to an integer 1
        _size__13097 = 1+(long)(DBL_PTR(_7393)->dbl);
        if( !IS_ATOM_INT(_size__13097) ){
            _size__13097 = (object)DBL_PTR(_size__13097)->dbl;
        }
    }
    DeRef(_7393);
    _7393 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__13097 = _requested_bucket_size_p_13096;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__13097 == 0xC0000000)
    _7395 = (int)NewDouble((double)-0xC0000000);
    else
    _7395 = - _size__13097;
    _size__13097 = _34next_prime(_size__13097, _7395, 2);
    _7395 = NOVALUE;
    if (!IS_ATOM_INT(_size__13097)) {
        _1 = (long)(DBL_PTR(_size__13097)->dbl);
        DeRefDS(_size__13097);
        _size__13097 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__13097 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__13099);
    DeRef(_old_val_buckets__13100);
    DeRef(_new_key_buckets__13101);
    DeRef(_new_val_buckets__13102);
    DeRef(_key__13103);
    DeRef(_value__13104);
    DeRef(_new_keys_13106);
    _7390 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7398 = (int)*(((s1_ptr)_2)->base + _the_map_p_13095);
    DeRef(_old_key_buckets__13099);
    _2 = (int)SEQ_PTR(_7398);
    _old_key_buckets__13099 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__13099);
    _7398 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7400 = (int)*(((s1_ptr)_2)->base + _the_map_p_13095);
    DeRef(_old_val_buckets__13100);
    _2 = (int)SEQ_PTR(_7400);
    _old_val_buckets__13100 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__13100);
    _7400 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _7402 = _33threshold_size_12989 + 1;
    _7403 = Repeat(1, _7402);
    _7402 = NOVALUE;
    DeRef(_new_key_buckets__13101);
    _new_key_buckets__13101 = Repeat(_7403, _size__13097);
    DeRefDS(_7403);
    _7403 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _7405 = Repeat(0, _33threshold_size_12989);
    DeRef(_new_val_buckets__13102);
    _new_val_buckets__13102 = Repeat(_7405, _size__13097);
    DeRefDS(_7405);
    _7405 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7407 = (int)*(((s1_ptr)_2)->base + _the_map_p_13095);
    _2 = (int)SEQ_PTR(_7407);
    _elem_count_13108 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_13108)){
        _elem_count_13108 = (long)DBL_PTR(_elem_count_13108)->dbl;
    }
    _7407 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_13107 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13095);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__13099)){
            _7409 = SEQ_PTR(_old_key_buckets__13099)->length;
    }
    else {
        _7409 = 1;
    }
    {
        int _index_13138;
        _index_13138 = 1;
L5: 
        if (_index_13138 > _7409){
            goto L6; // [183] 371
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__13099);
        _7410 = (int)*(((s1_ptr)_2)->base + _index_13138);
        if (IS_SEQUENCE(_7410)){
                _7411 = SEQ_PTR(_7410)->length;
        }
        else {
            _7411 = 1;
        }
        _7410 = NOVALUE;
        {
            int _entry_idx_13141;
            _entry_idx_13141 = 1;
L7: 
            if (_entry_idx_13141 > _7411){
                goto L8; // [199] 364
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__13099);
            _7412 = (int)*(((s1_ptr)_2)->base + _index_13138);
            DeRef(_key__13103);
            _2 = (int)SEQ_PTR(_7412);
            _key__13103 = (int)*(((s1_ptr)_2)->base + _entry_idx_13141);
            Ref(_key__13103);
            _7412 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__13100);
            _7414 = (int)*(((s1_ptr)_2)->base + _index_13138);
            DeRef(_value__13104);
            _2 = (int)SEQ_PTR(_7414);
            _value__13104 = (int)*(((s1_ptr)_2)->base + _entry_idx_13141);
            Ref(_value__13104);
            _7414 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_13149);
            _ret__inlined_calc_hash_at_227_13149 = calc_hash(_key__13103, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_13149)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_13149)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_13149);
                _ret__inlined_calc_hash_at_227_13149 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_13151 = (_ret__inlined_calc_hash_at_227_13149 % _size__13097);
            _index_2__13098 = _calc_hash_1__tmp_at227_13151 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_13149);
            _ret__inlined_calc_hash_at_227_13149 = NOVALUE;

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_13106);
            _2 = (int)SEQ_PTR(_new_key_buckets__13101);
            _new_keys_13106 = (int)*(((s1_ptr)_2)->base + _index_2__13098);
            RefDS(_new_keys_13106);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_13106)){
                    _7417 = SEQ_PTR(_new_keys_13106)->length;
            }
            else {
                _7417 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_13106);
            _pos_13105 = (int)*(((s1_ptr)_2)->base + _7417);
            if (!IS_ATOM_INT(_pos_13105))
            _pos_13105 = (long)DBL_PTR(_pos_13105)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_13106)){
                    _7419 = SEQ_PTR(_new_keys_13106)->length;
            }
            else {
                _7419 = 1;
            }
            if (_7419 != _pos_13105)
            goto L9; // [271] 308

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _7421 = Repeat(_pos_13105, _33threshold_size_12989);
            Concat((object_ptr)&_new_keys_13106, _new_keys_13106, _7421);
            DeRefDS(_7421);
            _7421 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _7423 = Repeat(0, _33threshold_size_12989);
            _2 = (int)SEQ_PTR(_new_val_buckets__13102);
            _7424 = (int)*(((s1_ptr)_2)->base + _index_2__13098);
            if (IS_SEQUENCE(_7424) && IS_ATOM(_7423)) {
            }
            else if (IS_ATOM(_7424) && IS_SEQUENCE(_7423)) {
                Ref(_7424);
                Prepend(&_7425, _7423, _7424);
            }
            else {
                Concat((object_ptr)&_7425, _7424, _7423);
                _7424 = NOVALUE;
            }
            _7424 = NOVALUE;
            DeRefDS(_7423);
            _7423 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__13102);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__13102 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__13098);
            _1 = *(int *)_2;
            *(int *)_2 = _7425;
            if( _1 != _7425 ){
                DeRef(_1);
            }
            _7425 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__13103);
            _2 = (int)SEQ_PTR(_new_keys_13106);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_13106 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_13105);
            _1 = *(int *)_2;
            *(int *)_2 = _key__13103;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__13102);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__13102 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__13098 + ((s1_ptr)_2)->base);
            Ref(_value__13104);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_13105);
            _1 = *(int *)_2;
            *(int *)_2 = _value__13104;
            DeRef(_1);
            _7426 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_13106)){
                    _7428 = SEQ_PTR(_new_keys_13106)->length;
            }
            else {
                _7428 = 1;
            }
            _7429 = _pos_13105 + 1;
            if (_7429 > MAXINT){
                _7429 = NewDouble((double)_7429);
            }
            _2 = (int)SEQ_PTR(_new_keys_13106);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_13106 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _7428);
            _1 = *(int *)_2;
            *(int *)_2 = _7429;
            if( _1 != _7429 ){
                DeRef(_1);
            }
            _7429 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_13106);
            _2 = (int)SEQ_PTR(_new_key_buckets__13101);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__13101 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__13098);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_13106;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_13105 != 1)
            goto LA; // [346] 357

            /** 				in_use += 1*/
            _in_use_13107 = _in_use_13107 + 1;
LA: 

            /** 		end for*/
            _entry_idx_13141 = _entry_idx_13141 + 1;
            goto L7; // [359] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_13138 = _index_13138 + 1;
        goto L5; // [366] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__13101)){
            _7432 = SEQ_PTR(_new_key_buckets__13101)->length;
    }
    else {
        _7432 = 1;
    }
    {
        int _index_13171;
        _index_13171 = 1;
LB: 
        if (_index_13171 > _7432){
            goto LC; // [376] 449
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__13101);
        _7433 = (int)*(((s1_ptr)_2)->base + _index_13171);
        if (IS_SEQUENCE(_7433)){
                _7434 = SEQ_PTR(_7433)->length;
        }
        else {
            _7434 = 1;
        }
        _2 = (int)SEQ_PTR(_7433);
        _pos_13105 = (int)*(((s1_ptr)_2)->base + _7434);
        if (!IS_ATOM_INT(_pos_13105)){
            _pos_13105 = (long)DBL_PTR(_pos_13105)->dbl;
        }
        _7433 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__13101);
        _7436 = (int)*(((s1_ptr)_2)->base + _index_13171);
        _2 = (int)SEQ_PTR(_new_key_buckets__13101);
        _7437 = (int)*(((s1_ptr)_2)->base + _index_13171);
        if (IS_SEQUENCE(_7437)){
                _7438 = SEQ_PTR(_7437)->length;
        }
        else {
            _7438 = 1;
        }
        _7437 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7436);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_13105)) ? _pos_13105 : (long)(DBL_PTR(_pos_13105)->dbl);
            int stop = (IS_ATOM_INT(_7438)) ? _7438 : (long)(DBL_PTR(_7438)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7436);
                DeRef(_7439);
                _7439 = _7436;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7436), start, &_7439 );
                }
                else Tail(SEQ_PTR(_7436), stop+1, &_7439);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7436), start, &_7439);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7439);
                _7439 = _1;
            }
        }
        _7436 = NOVALUE;
        _7438 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__13101);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__13101 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13171);
        _1 = *(int *)_2;
        *(int *)_2 = _7439;
        if( _1 != _7439 ){
            DeRefDS(_1);
        }
        _7439 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__13102);
        _7440 = (int)*(((s1_ptr)_2)->base + _index_13171);
        _2 = (int)SEQ_PTR(_new_val_buckets__13102);
        _7441 = (int)*(((s1_ptr)_2)->base + _index_13171);
        if (IS_SEQUENCE(_7441)){
                _7442 = SEQ_PTR(_7441)->length;
        }
        else {
            _7442 = 1;
        }
        _7441 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7440);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_13105)) ? _pos_13105 : (long)(DBL_PTR(_pos_13105)->dbl);
            int stop = (IS_ATOM_INT(_7442)) ? _7442 : (long)(DBL_PTR(_7442)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7440);
                DeRef(_7443);
                _7443 = _7440;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7440), start, &_7443 );
                }
                else Tail(SEQ_PTR(_7440), stop+1, &_7443);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7440), start, &_7443);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7443);
                _7443 = _1;
            }
        }
        _7440 = NOVALUE;
        _7442 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__13102);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__13102 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13171);
        _1 = *(int *)_2;
        *(int *)_2 = _7443;
        if( _1 != _7443 ){
            DeRef(_1);
        }
        _7443 = NOVALUE;

        /** 	end for*/
        _index_13171 = _index_13171 + 1;
        goto LB; // [444] 383
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12975);
    *((int *)(_2+4)) = _33type_is_map_12975;
    *((int *)(_2+8)) = _elem_count_13108;
    *((int *)(_2+12)) = _in_use_13107;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__13101);
    *((int *)(_2+20)) = _new_key_buckets__13101;
    RefDS(_new_val_buckets__13102);
    *((int *)(_2+24)) = _new_val_buckets__13102;
    _7444 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13095);
    _1 = *(int *)_2;
    *(int *)_2 = _7444;
    if( _1 != _7444 ){
        DeRef(_1);
    }
    _7444 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__13099);
    DeRef(_old_val_buckets__13100);
    DeRefDS(_new_key_buckets__13101);
    DeRefDS(_new_val_buckets__13102);
    DeRef(_key__13103);
    DeRef(_value__13104);
    DeRef(_new_keys_13106);
    _7390 = NOVALUE;
    _7410 = NOVALUE;
    _7437 = NOVALUE;
    _7441 = NOVALUE;
    return;
    ;
}


int  __stdcall _33new(int _initial_size_p_13187)
{
    int _buckets__13189 = NOVALUE;
    int _new_map__13190 = NOVALUE;
    int _temp_map__13191 = NOVALUE;
    int _7457 = NOVALUE;
    int _7456 = NOVALUE;
    int _7455 = NOVALUE;
    int _7453 = NOVALUE;
    int _7452 = NOVALUE;
    int _7449 = NOVALUE;
    int _7448 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_initial_size_p_13187)) {
        _1 = (long)(DBL_PTR(_initial_size_p_13187)->dbl);
        DeRefDS(_initial_size_p_13187);
        _initial_size_p_13187 = _1;
    }

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_13187 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_13187 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_13187 <= _33threshold_size_12989)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _7448 = _initial_size_p_13187 + _33threshold_size_12989;
    if ((long)((unsigned long)_7448 + (unsigned long)HIGH_BITS) >= 0) 
    _7448 = NewDouble((double)_7448);
    if (IS_ATOM_INT(_7448)) {
        _7449 = _7448 - 1;
        if ((long)((unsigned long)_7449 +(unsigned long) HIGH_BITS) >= 0){
            _7449 = NewDouble((double)_7449);
        }
    }
    else {
        _7449 = NewDouble(DBL_PTR(_7448)->dbl - (double)1);
    }
    DeRef(_7448);
    _7448 = NOVALUE;
    if (IS_ATOM_INT(_7449)) {
        if (_33threshold_size_12989 > 0 && _7449 >= 0) {
            _buckets__13189 = _7449 / _33threshold_size_12989;
        }
        else {
            temp_dbl = floor((double)_7449 / (double)_33threshold_size_12989);
            _buckets__13189 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7449, _33threshold_size_12989);
        _buckets__13189 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7449);
    _7449 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__13189)) {
        _1 = (long)(DBL_PTR(_buckets__13189)->dbl);
        DeRefDS(_buckets__13189);
        _buckets__13189 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__13189 = _34next_prime(_buckets__13189, -1, 1);
    if (!IS_ATOM_INT(_buckets__13189)) {
        _1 = (long)(DBL_PTR(_buckets__13189)->dbl);
        DeRefDS(_buckets__13189);
        _buckets__13189 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _7452 = Repeat(_5, _buckets__13189);
    _7453 = Repeat(_5, _buckets__13189);
    _0 = _new_map__13190;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12975);
    *((int *)(_2+4)) = _33type_is_map_12975;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _7452;
    *((int *)(_2+24)) = _7453;
    _new_map__13190 = MAKE_SEQ(_1);
    DeRef(_0);
    _7453 = NOVALUE;
    _7452 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _7455 = Repeat(_33init_small_map_key_12990, _initial_size_p_13187);
    _7456 = Repeat(0, _initial_size_p_13187);
    _7457 = Repeat(0, _initial_size_p_13187);
    _0 = _new_map__13190;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12975);
    *((int *)(_2+4)) = _33type_is_map_12975;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7455;
    *((int *)(_2+24)) = _7456;
    *((int *)(_2+28)) = _7457;
    _new_map__13190 = MAKE_SEQ(_1);
    DeRef(_0);
    _7457 = NOVALUE;
    _7456 = NOVALUE;
    _7455 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__13191;
    _temp_map__13191 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__13190);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__13191))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__13191)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__13191);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__13190;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__13190);
    return _temp_map__13191;
    ;
}


int  __stdcall _33new_extra(int _the_map_p_13211, int _initial_size_p_13212)
{
    int _7461 = NOVALUE;
    int _7460 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_initial_size_p_13212)) {
        _1 = (long)(DBL_PTR(_initial_size_p_13212)->dbl);
        DeRefDS(_initial_size_p_13212);
        _initial_size_p_13212 = _1;
    }

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_13211);
    _7460 = _33map(_the_map_p_13211);
    if (_7460 == 0) {
        DeRef(_7460);
        _7460 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_7460) && DBL_PTR(_7460)->dbl == 0.0){
            DeRef(_7460);
            _7460 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_7460);
        _7460 = NOVALUE;
    }
    DeRef(_7460);
    _7460 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_13211;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _7461 = _33new(_initial_size_p_13212);
    DeRef(_the_map_p_13211);
    return _7461;
L2: 
    ;
}


int  __stdcall _33compare(int _map_1_p_13219, int _map_2_p_13220, int _scope_p_13221)
{
    int _data_set_1__13222 = NOVALUE;
    int _data_set_2__13223 = NOVALUE;
    int _7473 = NOVALUE;
    int _7467 = NOVALUE;
    int _7465 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_scope_p_13221)) {
        _1 = (long)(DBL_PTR(_scope_p_13221)->dbl);
        DeRefDS(_scope_p_13221);
        _scope_p_13221 = _1;
    }

    /** 	if map_1_p = map_2_p then*/
    if (binary_op_a(NOTEQ, _map_1_p_13219, _map_2_p_13220)){
        goto L1; // [5] 16
    }

    /** 		return 0*/
    DeRef(_map_1_p_13219);
    DeRef(_map_2_p_13220);
    DeRef(_data_set_1__13222);
    DeRef(_data_set_2__13223);
    return 0;
L1: 

    /** 	switch scope_p do*/
    _0 = _scope_p_13221;
    switch ( _0 ){ 

        /** 		case 'v', 'V' then*/
        case 118:
        case 86:

        /** 			data_set_1_ = stdsort:sort(values(map_1_p))*/
        Ref(_map_1_p_13219);
        _7465 = _33values(_map_1_p_13219, 0, 0);
        _0 = _data_set_1__13222;
        _data_set_1__13222 = _24sort(_7465, 1);
        DeRef(_0);
        _7465 = NOVALUE;

        /** 			data_set_2_ = stdsort:sort(values(map_2_p))*/
        Ref(_map_2_p_13220);
        _7467 = _33values(_map_2_p_13220, 0, 0);
        _0 = _data_set_2__13223;
        _data_set_2__13223 = _24sort(_7467, 1);
        DeRef(_0);
        _7467 = NOVALUE;
        goto L2; // [59] 110

        /** 		case 'k', 'K' then*/
        case 107:
        case 75:

        /** 			data_set_1_ = keys(map_1_p, 1)*/
        Ref(_map_1_p_13219);
        _0 = _data_set_1__13222;
        _data_set_1__13222 = _33keys(_map_1_p_13219, 1);
        DeRef(_0);

        /** 			data_set_2_ = keys(map_2_p, 1)*/
        Ref(_map_2_p_13220);
        _0 = _data_set_2__13223;
        _data_set_2__13223 = _33keys(_map_2_p_13220, 1);
        DeRef(_0);
        goto L2; // [85] 110

        /** 		case else*/
        default:

        /** 			data_set_1_ = pairs(map_1_p, 1)*/
        Ref(_map_1_p_13219);
        _0 = _data_set_1__13222;
        _data_set_1__13222 = _33pairs(_map_1_p_13219, 1);
        DeRef(_0);

        /** 			data_set_2_ = pairs(map_2_p, 1)*/
        Ref(_map_2_p_13220);
        _0 = _data_set_2__13223;
        _data_set_2__13223 = _33pairs(_map_2_p_13220, 1);
        DeRef(_0);
    ;}L2: 

    /** 	if equal(data_set_1_, data_set_2_) then*/
    if (_data_set_1__13222 == _data_set_2__13223)
    _7473 = 1;
    else if (IS_ATOM_INT(_data_set_1__13222) && IS_ATOM_INT(_data_set_2__13223))
    _7473 = 0;
    else
    _7473 = (compare(_data_set_1__13222, _data_set_2__13223) == 0);
    if (_7473 == 0)
    {
        _7473 = NOVALUE;
        goto L3; // [120] 130
    }
    else{
        _7473 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_map_1_p_13219);
    DeRef(_map_2_p_13220);
    DeRefDS(_data_set_1__13222);
    DeRefDS(_data_set_2__13223);
    return 1;
L3: 

    /** 	return -1*/
    DeRef(_map_1_p_13219);
    DeRef(_map_2_p_13220);
    DeRef(_data_set_1__13222);
    DeRef(_data_set_2__13223);
    return -1;
    ;
}


int  __stdcall _33has(int _the_map_p_13249, int _the_key_p_13250)
{
    int _index__13251 = NOVALUE;
    int _pos__13252 = NOVALUE;
    int _from__13253 = NOVALUE;
    int _calc_hash_1__tmp_at36_13265 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_13264 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_13263 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_13262 = NOVALUE;
    int _7497 = NOVALUE;
    int _7495 = NOVALUE;
    int _7494 = NOVALUE;
    int _7491 = NOVALUE;
    int _7490 = NOVALUE;
    int _7489 = NOVALUE;
    int _7487 = NOVALUE;
    int _7486 = NOVALUE;
    int _7484 = NOVALUE;
    int _7482 = NOVALUE;
    int _7481 = NOVALUE;
    int _7480 = NOVALUE;
    int _7479 = NOVALUE;
    int _7478 = NOVALUE;
    int _7477 = NOVALUE;
    int _7475 = NOVALUE;
    int _7474 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13249)) {
        _1 = (long)(DBL_PTR(_the_map_p_13249)->dbl);
        DeRefDS(_the_map_p_13249);
        _the_map_p_13249 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7474 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7474);
    _7475 = (int)*(((s1_ptr)_2)->base + 4);
    _7474 = NOVALUE;
    if (binary_op_a(NOTEQ, _7475, 76)){
        _7475 = NOVALUE;
        goto L1; // [15] 84
    }
    _7475 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7477 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7477);
    _7478 = (int)*(((s1_ptr)_2)->base + 5);
    _7477 = NOVALUE;
    if (IS_SEQUENCE(_7478)){
            _7479 = SEQ_PTR(_7478)->length;
    }
    else {
        _7479 = 1;
    }
    _7478 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_13262 = _7479;
    _7479 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_13263);
    _ret__inlined_calc_hash_at_36_13263 = calc_hash(_the_key_p_13250, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_13263)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_13263)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_13263);
        _ret__inlined_calc_hash_at_36_13263 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_13265 = (_ret__inlined_calc_hash_at_36_13263 % _max_hash_p_inlined_calc_hash_at_33_13262);
    _index__13251 = _calc_hash_1__tmp_at36_13265 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_13263);
    _ret__inlined_calc_hash_at_36_13263 = NOVALUE;

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7480 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7480);
    _7481 = (int)*(((s1_ptr)_2)->base + 5);
    _7480 = NOVALUE;
    _2 = (int)SEQ_PTR(_7481);
    _7482 = (int)*(((s1_ptr)_2)->base + _index__13251);
    _7481 = NOVALUE;
    _pos__13252 = find_from(_the_key_p_13250, _7482, 1);
    _7482 = NOVALUE;
    goto L2; // [81] 199
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13250 == _33init_small_map_key_12990)
    _7484 = 1;
    else if (IS_ATOM_INT(_the_key_p_13250) && IS_ATOM_INT(_33init_small_map_key_12990))
    _7484 = 0;
    else
    _7484 = (compare(_the_key_p_13250, _33init_small_map_key_12990) == 0);
    if (_7484 == 0)
    {
        _7484 = NOVALUE;
        goto L3; // [90] 180
    }
    else{
        _7484 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13253 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__13253 <= 0)
    goto L5; // [103] 198

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7486 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7486);
    _7487 = (int)*(((s1_ptr)_2)->base + 5);
    _7486 = NOVALUE;
    _pos__13252 = find_from(_the_key_p_13250, _7487, _from__13253);
    _7487 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13252 == 0)
    {
        goto L6; // [126] 159
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7489 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7489);
    _7490 = (int)*(((s1_ptr)_2)->base + 7);
    _7489 = NOVALUE;
    _2 = (int)SEQ_PTR(_7490);
    _7491 = (int)*(((s1_ptr)_2)->base + _pos__13252);
    _7490 = NOVALUE;
    if (binary_op_a(NOTEQ, _7491, 1)){
        _7491 = NOVALUE;
        goto L7; // [145] 166
    }
    _7491 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_13250);
    _7478 = NOVALUE;
    return 1;
    goto L7; // [156] 166
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_13250);
    _7478 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__13253 = _pos__13252 + 1;

    /** 			end while*/
    goto L4; // [174] 103
    goto L5; // [177] 198
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _7494 = (int)*(((s1_ptr)_2)->base + _the_map_p_13249);
    _2 = (int)SEQ_PTR(_7494);
    _7495 = (int)*(((s1_ptr)_2)->base + 5);
    _7494 = NOVALUE;
    _pos__13252 = find_from(_the_key_p_13250, _7495, 1);
    _7495 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _7497 = (_pos__13252 != 0);
    DeRef(_the_key_p_13250);
    _7478 = NOVALUE;
    return _7497;
    ;
}


int  __stdcall _33get(int _the_map_p_13293, int _the_key_p_13294, int _default_value_p_13295)
{
    int _bucket__13296 = NOVALUE;
    int _pos__13297 = NOVALUE;
    int _from__13298 = NOVALUE;
    int _themap_13299 = NOVALUE;
    int _thekeys_13304 = NOVALUE;
    int _calc_hash_1__tmp_at40_13311 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13310 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13309 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13308 = NOVALUE;
    int _7522 = NOVALUE;
    int _7521 = NOVALUE;
    int _7519 = NOVALUE;
    int _7517 = NOVALUE;
    int _7516 = NOVALUE;
    int _7514 = NOVALUE;
    int _7513 = NOVALUE;
    int _7511 = NOVALUE;
    int _7509 = NOVALUE;
    int _7508 = NOVALUE;
    int _7507 = NOVALUE;
    int _7506 = NOVALUE;
    int _7503 = NOVALUE;
    int _7502 = NOVALUE;
    int _7499 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13293)) {
        _1 = (long)(DBL_PTR(_the_map_p_13293)->dbl);
        DeRefDS(_the_map_p_13293);
        _the_map_p_13293 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_13299);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _themap_13299 = (int)*(((s1_ptr)_2)->base + _the_map_p_13293);
    Ref(_themap_13299);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7499 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7499, 76)){
        _7499 = NOVALUE;
        goto L1; // [19] 111
    }
    _7499 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_13304);
    _2 = (int)SEQ_PTR(_themap_13299);
    _thekeys_13304 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_13304);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_13304)){
            _7502 = SEQ_PTR(_thekeys_13304)->length;
    }
    else {
        _7502 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_13308 = _7502;
    _7502 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13309);
    _ret__inlined_calc_hash_at_40_13309 = calc_hash(_the_key_p_13294, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13309)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13309)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13309);
        _ret__inlined_calc_hash_at_40_13309 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13311 = (_ret__inlined_calc_hash_at_40_13309 % _max_hash_p_inlined_calc_hash_at_37_13308);
    _bucket__13296 = _calc_hash_1__tmp_at40_13311 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13309);
    _ret__inlined_calc_hash_at_40_13309 = NOVALUE;

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_13304);
    _7503 = (int)*(((s1_ptr)_2)->base + _bucket__13296);
    _pos__13297 = find_from(_the_key_p_13294, _7503, 1);
    _7503 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__13297 <= 0)
    goto L2; // [77] 100

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7506 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7506);
    _7507 = (int)*(((s1_ptr)_2)->base + _bucket__13296);
    _7506 = NOVALUE;
    _2 = (int)SEQ_PTR(_7507);
    _7508 = (int)*(((s1_ptr)_2)->base + _pos__13297);
    _7507 = NOVALUE;
    Ref(_7508);
    DeRefDS(_thekeys_13304);
    DeRef(_the_key_p_13294);
    DeRef(_default_value_p_13295);
    DeRefDS(_themap_13299);
    return _7508;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_13304);
    DeRef(_the_key_p_13294);
    DeRef(_themap_13299);
    _7508 = NOVALUE;
    return _default_value_p_13295;
    goto L3; // [108] 236
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13294 == _33init_small_map_key_12990)
    _7509 = 1;
    else if (IS_ATOM_INT(_the_key_p_13294) && IS_ATOM_INT(_33init_small_map_key_12990))
    _7509 = 0;
    else
    _7509 = (compare(_the_key_p_13294, _33init_small_map_key_12990) == 0);
    if (_7509 == 0)
    {
        _7509 = NOVALUE;
        goto L4; // [117] 203
    }
    else{
        _7509 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13298 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__13298 <= 0)
    goto L6; // [130] 235

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7511 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13297 = find_from(_the_key_p_13294, _7511, _from__13298);
    _7511 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13297 == 0)
    {
        goto L7; // [147] 182
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7513 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7513);
    _7514 = (int)*(((s1_ptr)_2)->base + _pos__13297);
    _7513 = NOVALUE;
    if (binary_op_a(NOTEQ, _7514, 1)){
        _7514 = NOVALUE;
        goto L8; // [160] 189
    }
    _7514 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7516 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7516);
    _7517 = (int)*(((s1_ptr)_2)->base + _pos__13297);
    _7516 = NOVALUE;
    Ref(_7517);
    DeRef(_the_key_p_13294);
    DeRef(_default_value_p_13295);
    DeRefDS(_themap_13299);
    _7508 = NOVALUE;
    return _7517;
    goto L8; // [179] 189
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_13294);
    DeRef(_themap_13299);
    _7508 = NOVALUE;
    _7517 = NOVALUE;
    return _default_value_p_13295;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__13298 = _pos__13297 + 1;

    /** 			end while*/
    goto L5; // [197] 130
    goto L6; // [200] 235
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7519 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13297 = find_from(_the_key_p_13294, _7519, 1);
    _7519 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__13297 == 0)
    {
        goto L9; // [216] 234
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13299);
    _7521 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7521);
    _7522 = (int)*(((s1_ptr)_2)->base + _pos__13297);
    _7521 = NOVALUE;
    Ref(_7522);
    DeRef(_the_key_p_13294);
    DeRef(_default_value_p_13295);
    DeRefDS(_themap_13299);
    _7508 = NOVALUE;
    _7517 = NOVALUE;
    return _7522;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_13294);
    DeRef(_themap_13299);
    _7508 = NOVALUE;
    _7517 = NOVALUE;
    _7522 = NOVALUE;
    return _default_value_p_13295;
    ;
}


int  __stdcall _33nested_get(int _the_map_p_13343, int _the_keys_p_13344, int _default_value_p_13345)
{
    int _val__13350 = NOVALUE;
    int _7532 = NOVALUE;
    int _7531 = NOVALUE;
    int _7529 = NOVALUE;
    int _7527 = NOVALUE;
    int _7525 = NOVALUE;
    int _7524 = NOVALUE;
    int _7523 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( the_keys_p ) - 1 do*/
    if (IS_SEQUENCE(_the_keys_p_13344)){
            _7523 = SEQ_PTR(_the_keys_p_13344)->length;
    }
    else {
        _7523 = 1;
    }
    _7524 = _7523 - 1;
    _7523 = NOVALUE;
    {
        int _i_13347;
        _i_13347 = 1;
L1: 
        if (_i_13347 > _7524){
            goto L2; // [12] 74
        }

        /** 		object val_ = get( the_map_p, the_keys_p[1], 0 )*/
        _2 = (int)SEQ_PTR(_the_keys_p_13344);
        _7525 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_the_map_p_13343);
        Ref(_7525);
        _0 = _val__13350;
        _val__13350 = _33get(_the_map_p_13343, _7525, 0);
        DeRef(_0);
        _7525 = NOVALUE;

        /** 		if not map( val_ ) then*/
        Ref(_val__13350);
        _7527 = _33map(_val__13350);
        if (IS_ATOM_INT(_7527)) {
            if (_7527 != 0){
                DeRef(_7527);
                _7527 = NOVALUE;
                goto L3; // [37] 49
            }
        }
        else {
            if (DBL_PTR(_7527)->dbl != 0.0){
                DeRef(_7527);
                _7527 = NOVALUE;
                goto L3; // [37] 49
            }
        }
        DeRef(_7527);
        _7527 = NOVALUE;

        /** 			return default_value_p*/
        DeRef(_val__13350);
        DeRef(_the_map_p_13343);
        DeRefDS(_the_keys_p_13344);
        DeRef(_7524);
        _7524 = NOVALUE;
        return _default_value_p_13345;
        goto L4; // [46] 65
L3: 

        /** 			the_map_p = val_*/
        Ref(_val__13350);
        DeRef(_the_map_p_13343);
        _the_map_p_13343 = _val__13350;

        /** 			the_keys_p = the_keys_p[2..$]*/
        if (IS_SEQUENCE(_the_keys_p_13344)){
                _7529 = SEQ_PTR(_the_keys_p_13344)->length;
        }
        else {
            _7529 = 1;
        }
        rhs_slice_target = (object_ptr)&_the_keys_p_13344;
        RHS_Slice(_the_keys_p_13344, 2, _7529);
L4: 
        DeRef(_val__13350);
        _val__13350 = NOVALUE;

        /** 	end for*/
        _i_13347 = _i_13347 + 1;
        goto L1; // [69] 19
L2: 
        ;
    }

    /** 	return get( the_map_p, the_keys_p[1], default_value_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13344);
    _7531 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13343);
    Ref(_7531);
    Ref(_default_value_p_13345);
    _7532 = _33get(_the_map_p_13343, _7531, _default_value_p_13345);
    _7531 = NOVALUE;
    DeRef(_the_map_p_13343);
    DeRefDS(_the_keys_p_13344);
    DeRef(_default_value_p_13345);
    DeRef(_7524);
    _7524 = NOVALUE;
    return _7532;
    ;
}


void  __stdcall _33put(int _the_map_p_13363, int _the_key_p_13364, int _the_value_p_13365, int _operation_p_13366, int _trigger_p_13367)
{
    int _index__13368 = NOVALUE;
    int _bucket__13369 = NOVALUE;
    int _average_length__13370 = NOVALUE;
    int _from__13371 = NOVALUE;
    int _map_data_13372 = NOVALUE;
    int _calc_hash_1__tmp_at46_13383 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_13382 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_13381 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_13380 = NOVALUE;
    int _data_13415 = NOVALUE;
    int _msg_inlined_crash_at_332_13431 = NOVALUE;
    int _msg_inlined_crash_at_377_13437 = NOVALUE;
    int _tmp_seqk_13451 = NOVALUE;
    int _tmp_seqv_13459 = NOVALUE;
    int _msg_inlined_crash_at_719_13495 = NOVALUE;
    int _msg_inlined_crash_at_1077_13558 = NOVALUE;
    int _7666 = NOVALUE;
    int _7665 = NOVALUE;
    int _7663 = NOVALUE;
    int _7662 = NOVALUE;
    int _7661 = NOVALUE;
    int _7660 = NOVALUE;
    int _7658 = NOVALUE;
    int _7657 = NOVALUE;
    int _7656 = NOVALUE;
    int _7654 = NOVALUE;
    int _7653 = NOVALUE;
    int _7652 = NOVALUE;
    int _7650 = NOVALUE;
    int _7649 = NOVALUE;
    int _7648 = NOVALUE;
    int _7646 = NOVALUE;
    int _7645 = NOVALUE;
    int _7644 = NOVALUE;
    int _7642 = NOVALUE;
    int _7640 = NOVALUE;
    int _7634 = NOVALUE;
    int _7633 = NOVALUE;
    int _7632 = NOVALUE;
    int _7631 = NOVALUE;
    int _7629 = NOVALUE;
    int _7627 = NOVALUE;
    int _7626 = NOVALUE;
    int _7625 = NOVALUE;
    int _7624 = NOVALUE;
    int _7623 = NOVALUE;
    int _7622 = NOVALUE;
    int _7619 = NOVALUE;
    int _7617 = NOVALUE;
    int _7614 = NOVALUE;
    int _7612 = NOVALUE;
    int _7609 = NOVALUE;
    int _7608 = NOVALUE;
    int _7606 = NOVALUE;
    int _7603 = NOVALUE;
    int _7602 = NOVALUE;
    int _7599 = NOVALUE;
    int _7596 = NOVALUE;
    int _7594 = NOVALUE;
    int _7592 = NOVALUE;
    int _7589 = NOVALUE;
    int _7587 = NOVALUE;
    int _7586 = NOVALUE;
    int _7585 = NOVALUE;
    int _7584 = NOVALUE;
    int _7583 = NOVALUE;
    int _7582 = NOVALUE;
    int _7581 = NOVALUE;
    int _7580 = NOVALUE;
    int _7579 = NOVALUE;
    int _7573 = NOVALUE;
    int _7571 = NOVALUE;
    int _7570 = NOVALUE;
    int _7568 = NOVALUE;
    int _7566 = NOVALUE;
    int _7563 = NOVALUE;
    int _7562 = NOVALUE;
    int _7561 = NOVALUE;
    int _7560 = NOVALUE;
    int _7558 = NOVALUE;
    int _7557 = NOVALUE;
    int _7556 = NOVALUE;
    int _7554 = NOVALUE;
    int _7553 = NOVALUE;
    int _7552 = NOVALUE;
    int _7550 = NOVALUE;
    int _7549 = NOVALUE;
    int _7548 = NOVALUE;
    int _7546 = NOVALUE;
    int _7544 = NOVALUE;
    int _7539 = NOVALUE;
    int _7538 = NOVALUE;
    int _7537 = NOVALUE;
    int _7536 = NOVALUE;
    int _7534 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_13363)) {
        _1 = (long)(DBL_PTR(_the_map_p_13363)->dbl);
        DeRefDS(_the_map_p_13363);
        _the_map_p_13363 = _1;
    }
    if (!IS_ATOM_INT(_operation_p_13366)) {
        _1 = (long)(DBL_PTR(_operation_p_13366)->dbl);
        DeRefDS(_operation_p_13366);
        _operation_p_13366 = _1;
    }
    if (!IS_ATOM_INT(_trigger_p_13367)) {
        _1 = (long)(DBL_PTR(_trigger_p_13367)->dbl);
        DeRefDS(_trigger_p_13367);
        _trigger_p_13367 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _map_data_13372 = (int)*(((s1_ptr)_2)->base + _the_map_p_13363);
    Ref(_map_data_13372);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7534 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7534, 76)){
        _7534 = NOVALUE;
        goto L1; // [31] 616
    }
    _7534 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7536 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7536)){
            _7537 = SEQ_PTR(_7536)->length;
    }
    else {
        _7537 = 1;
    }
    _7536 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_13380 = _7537;
    _7537 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_13381);
    _ret__inlined_calc_hash_at_46_13381 = calc_hash(_the_key_p_13364, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_13381)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_13381)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_13381);
        _ret__inlined_calc_hash_at_46_13381 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_13383 = (_ret__inlined_calc_hash_at_46_13381 % _max_hash_p_inlined_calc_hash_at_43_13380);
    _bucket__13369 = _calc_hash_1__tmp_at46_13383 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_13381);
    _ret__inlined_calc_hash_at_46_13381 = NOVALUE;

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7538 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7538);
    _7539 = (int)*(((s1_ptr)_2)->base + _bucket__13369);
    _7538 = NOVALUE;
    _index__13368 = find_from(_the_key_p_13364, _7539, 1);
    _7539 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__13368 <= 0)
    goto L2; // [87] 366

    /** 			switch operation_p do*/
    _0 = _operation_p_13366;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7544 = NOVALUE;
        Ref(_the_value_p_13365);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13365;
        DeRef(_1);
        _7544 = NOVALUE;
        goto L3; // [118] 352

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7546 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7548 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7546 = NOVALUE;
        if (IS_ATOM_INT(_7548) && IS_ATOM_INT(_the_value_p_13365)) {
            _7549 = _7548 + _the_value_p_13365;
            if ((long)((unsigned long)_7549 + (unsigned long)HIGH_BITS) >= 0) 
            _7549 = NewDouble((double)_7549);
        }
        else {
            _7549 = binary_op(PLUS, _7548, _the_value_p_13365);
        }
        _7548 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7549;
        if( _1 != _7549 ){
            DeRef(_1);
        }
        _7549 = NOVALUE;
        _7546 = NOVALUE;
        goto L3; // [148] 352

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7550 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7552 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7550 = NOVALUE;
        if (IS_ATOM_INT(_7552) && IS_ATOM_INT(_the_value_p_13365)) {
            _7553 = _7552 - _the_value_p_13365;
            if ((long)((unsigned long)_7553 +(unsigned long) HIGH_BITS) >= 0){
                _7553 = NewDouble((double)_7553);
            }
        }
        else {
            _7553 = binary_op(MINUS, _7552, _the_value_p_13365);
        }
        _7552 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7553;
        if( _1 != _7553 ){
            DeRef(_1);
        }
        _7553 = NOVALUE;
        _7550 = NOVALUE;
        goto L3; // [178] 352

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7554 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7556 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7554 = NOVALUE;
        if (IS_ATOM_INT(_7556) && IS_ATOM_INT(_the_value_p_13365)) {
            if (_7556 == (short)_7556 && _the_value_p_13365 <= INT15 && _the_value_p_13365 >= -INT15)
            _7557 = _7556 * _the_value_p_13365;
            else
            _7557 = NewDouble(_7556 * (double)_the_value_p_13365);
        }
        else {
            _7557 = binary_op(MULTIPLY, _7556, _the_value_p_13365);
        }
        _7556 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7557;
        if( _1 != _7557 ){
            DeRef(_1);
        }
        _7557 = NOVALUE;
        _7554 = NOVALUE;
        goto L3; // [208] 352

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7558 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7560 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7558 = NOVALUE;
        if (IS_ATOM_INT(_7560) && IS_ATOM_INT(_the_value_p_13365)) {
            _7561 = (_7560 % _the_value_p_13365) ? NewDouble((double)_7560 / _the_value_p_13365) : (_7560 / _the_value_p_13365);
        }
        else {
            _7561 = binary_op(DIVIDE, _7560, _the_value_p_13365);
        }
        _7560 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7561;
        if( _1 != _7561 ){
            DeRef(_1);
        }
        _7561 = NOVALUE;
        _7558 = NOVALUE;
        goto L3; // [238] 352

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        _7562 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7562);
        _7563 = (int)*(((s1_ptr)_2)->base + _bucket__13369);
        _7562 = NOVALUE;
        DeRef(_data_13415);
        _2 = (int)SEQ_PTR(_7563);
        _data_13415 = (int)*(((s1_ptr)_2)->base + _index__13368);
        Ref(_data_13415);
        _7563 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_13365);
        Append(&_data_13415, _data_13415, _the_value_p_13365);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7566 = NOVALUE;
        RefDS(_data_13415);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _data_13415;
        DeRef(_1);
        _7566 = NOVALUE;
        DeRefDS(_data_13415);
        _data_13415 = NOVALUE;
        goto L3; // [284] 352

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13369 + ((s1_ptr)_2)->base);
        _7568 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7570 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7568 = NOVALUE;
        if (IS_SEQUENCE(_7570) && IS_ATOM(_the_value_p_13365)) {
            Ref(_the_value_p_13365);
            Append(&_7571, _7570, _the_value_p_13365);
        }
        else if (IS_ATOM(_7570) && IS_SEQUENCE(_the_value_p_13365)) {
            Ref(_7570);
            Prepend(&_7571, _the_value_p_13365, _7570);
        }
        else {
            Concat((object_ptr)&_7571, _7570, _the_value_p_13365);
            _7570 = NOVALUE;
        }
        _7570 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7571;
        if( _1 != _7571 ){
            DeRef(_1);
        }
        _7571 = NOVALUE;
        _7568 = NOVALUE;
        goto L3; // [314] 352

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_13366 = _operation_p_13366;
        goto L3; // [325] 352

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_332_13431);
        _msg_inlined_crash_at_332_13431 = EPrintf(-9999999, _7572, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_332_13431);

        /** end procedure*/
        goto L4; // [346] 349
L4: 
        DeRefi(_msg_inlined_crash_at_332_13431);
        _msg_inlined_crash_at_332_13431 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13372;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13451);
    DeRef(_tmp_seqv_13459);
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRefDS(_map_data_13372);
    _7536 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7573 = find_from(_operation_p_13366, _33INIT_OPERATIONS_12985, 1);
    if (_7573 != 0)
    goto L5; // [373] 397
    _7573 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_377_13437);
    _msg_inlined_crash_at_377_13437 = EPrintf(-9999999, _7575, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_377_13437);

    /** end procedure*/
    goto L6; // [391] 394
L6: 
    DeRefi(_msg_inlined_crash_at_377_13437);
    _msg_inlined_crash_at_377_13437 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_13366 != 8)
    goto L7; // [399] 417

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13372;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13451);
    DeRef(_tmp_seqv_13459);
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRefDS(_map_data_13372);
    _7536 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_13366 != 6)
    goto L8; // [419] 430

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_13365;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13365);
    *((int *)(_2+4)) = _the_value_p_13365;
    _the_value_p_13365 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7579 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7579);
    _7580 = (int)*(((s1_ptr)_2)->base + _bucket__13369);
    _7579 = NOVALUE;
    if (IS_SEQUENCE(_7580)){
            _7581 = SEQ_PTR(_7580)->length;
    }
    else {
        _7581 = 1;
    }
    _7580 = NOVALUE;
    _7582 = (_7581 == 0);
    _7581 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7583 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7583)) {
        _7584 = _7583 + _7582;
        if ((long)((unsigned long)_7584 + (unsigned long)HIGH_BITS) >= 0) 
        _7584 = NewDouble((double)_7584);
    }
    else {
        _7584 = binary_op(PLUS, _7583, _7582);
    }
    _7583 = NOVALUE;
    _7582 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7584;
    if( _1 != _7584 ){
        DeRef(_1);
    }
    _7584 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7585 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7585)) {
        _7586 = _7585 + 1;
        if (_7586 > MAXINT){
            _7586 = NewDouble((double)_7586);
        }
    }
    else
    _7586 = binary_op(PLUS, 1, _7585);
    _7585 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7586;
    if( _1 != _7586 ){
        DeRef(_1);
    }
    _7586 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7587 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_13451);
    _2 = (int)SEQ_PTR(_7587);
    _tmp_seqk_13451 = (int)*(((s1_ptr)_2)->base + _bucket__13369);
    Ref(_tmp_seqk_13451);
    _7587 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13369);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7589 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_13364);
    Append(&_tmp_seqk_13451, _tmp_seqk_13451, _the_key_p_13364);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_13451);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13369);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_13451;
    DeRef(_1);
    _7592 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7594 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_13459);
    _2 = (int)SEQ_PTR(_7594);
    _tmp_seqv_13459 = (int)*(((s1_ptr)_2)->base + _bucket__13369);
    Ref(_tmp_seqv_13459);
    _7594 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13369);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7596 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_13365);
    Append(&_tmp_seqv_13459, _tmp_seqv_13459, _the_value_p_13365);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_13459);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13369);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_13459;
    DeRef(_1);
    _7599 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13372;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_13367 <= 0)
    goto L9; // [567] 606

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7602 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7603 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__13370);
    if (IS_ATOM_INT(_7602) && IS_ATOM_INT(_7603)) {
        _average_length__13370 = (_7602 % _7603) ? NewDouble((double)_7602 / _7603) : (_7602 / _7603);
    }
    else {
        _average_length__13370 = binary_op(DIVIDE, _7602, _7603);
    }
    _7602 = NOVALUE;
    _7603 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__13370, _trigger_p_13367)){
        goto LA; // [587] 605
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13372);
    _map_data_13372 = _5;

    /** 				rehash(the_map_p)*/
    _33rehash(_the_map_p_13363, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_13451);
    DeRef(_tmp_seqv_13459);
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRef(_map_data_13372);
    _7536 = NOVALUE;
    _7580 = NOVALUE;
    return;
    goto LB; // [613] 1110
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13364 == _33init_small_map_key_12990)
    _7606 = 1;
    else if (IS_ATOM_INT(_the_key_p_13364) && IS_ATOM_INT(_33init_small_map_key_12990))
    _7606 = 0;
    else
    _7606 = (compare(_the_key_p_13364, _33init_small_map_key_12990) == 0);
    if (_7606 == 0)
    {
        _7606 = NOVALUE;
        goto LC; // [622] 688
    }
    else{
        _7606 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13371 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [632] 669
LE: 
    if (_index__13368 <= 0)
    goto LF; // [637] 700

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7608 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7608);
    _7609 = (int)*(((s1_ptr)_2)->base + _index__13368);
    _7608 = NOVALUE;
    if (binary_op_a(NOTEQ, _7609, 1)){
        _7609 = NOVALUE;
        goto L10; // [651] 660
    }
    _7609 = NOVALUE;

    /** 					exit*/
    goto LF; // [657] 700
L10: 

    /** 				from_ = index_ + 1*/
    _from__13371 = _index__13368 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7612 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13368 = find_from(_the_key_p_13364, _7612, _from__13371);
    _7612 = NOVALUE;

    /** 			end while*/
    goto LE; // [682] 635
    goto LF; // [685] 700
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7614 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13368 = find_from(_the_key_p_13364, _7614, 1);
    _7614 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__13368 != 0)
    goto L11; // [704] 882

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7617 = find_from(_operation_p_13366, _33INIT_OPERATIONS_12985, 1);
    if (_7617 != 0)
    goto L12; // [715] 739
    _7617 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_719_13495);
    _msg_inlined_crash_at_719_13495 = EPrintf(-9999999, _7575, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_719_13495);

    /** end procedure*/
    goto L13; // [733] 736
L13: 
    DeRefi(_msg_inlined_crash_at_719_13495);
    _msg_inlined_crash_at_719_13495 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7619 = (int)*(((s1_ptr)_2)->base + 7);
    _index__13368 = find_from(0, _7619, 1);
    _7619 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__13368 != 0)
    goto L14; // [752] 806

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13372;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13372);
    _map_data_13372 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _33convert_to_large_map(_the_map_p_13363);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_7622);
    _7622 = _the_map_p_13363;
    Ref(_the_key_p_13364);
    DeRef(_7623);
    _7623 = _the_key_p_13364;
    Ref(_the_value_p_13365);
    DeRef(_7624);
    _7624 = _the_value_p_13365;
    DeRef(_7625);
    _7625 = _operation_p_13366;
    DeRef(_7626);
    _7626 = _trigger_p_13367;
    _33put(_7622, _7623, _7624, _7625, _7626);
    _7622 = NOVALUE;
    _7623 = NOVALUE;
    _7624 = NOVALUE;
    _7625 = NOVALUE;
    _7626 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRefDS(_map_data_13372);
    _7536 = NOVALUE;
    _7580 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_13364);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13368);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_13364;
    DeRef(_1);
    _7627 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13368);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _7629 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7631 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7631)) {
        _7632 = _7631 + 1;
        if (_7632 > MAXINT){
            _7632 = NewDouble((double)_7632);
        }
    }
    else
    _7632 = binary_op(PLUS, 1, _7631);
    _7631 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7632;
    if( _1 != _7632 ){
        DeRef(_1);
    }
    _7632 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13372);
    _7633 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7633)) {
        _7634 = _7633 + 1;
        if (_7634 > MAXINT){
            _7634 = NewDouble((double)_7634);
        }
    }
    else
    _7634 = binary_op(PLUS, 1, _7633);
    _7633 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7634;
    if( _1 != _7634 ){
        DeRef(_1);
    }
    _7634 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_13366 != 6)
    goto L15; // [858] 869

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_13365;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13365);
    *((int *)(_2+4)) = _the_value_p_13365;
    _the_value_p_13365 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_13366 == 8)
    goto L16; // [871] 881

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_13366 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_13366;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_13365);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13365;
        DeRef(_1);
        _7640 = NOVALUE;
        goto L17; // [904] 1096

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7644 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7642 = NOVALUE;
        if (IS_ATOM_INT(_7644) && IS_ATOM_INT(_the_value_p_13365)) {
            _7645 = _7644 + _the_value_p_13365;
            if ((long)((unsigned long)_7645 + (unsigned long)HIGH_BITS) >= 0) 
            _7645 = NewDouble((double)_7645);
        }
        else {
            _7645 = binary_op(PLUS, _7644, _the_value_p_13365);
        }
        _7644 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7645;
        if( _1 != _7645 ){
            DeRef(_1);
        }
        _7645 = NOVALUE;
        _7642 = NOVALUE;
        goto L17; // [929] 1096

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7648 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7646 = NOVALUE;
        if (IS_ATOM_INT(_7648) && IS_ATOM_INT(_the_value_p_13365)) {
            _7649 = _7648 - _the_value_p_13365;
            if ((long)((unsigned long)_7649 +(unsigned long) HIGH_BITS) >= 0){
                _7649 = NewDouble((double)_7649);
            }
        }
        else {
            _7649 = binary_op(MINUS, _7648, _the_value_p_13365);
        }
        _7648 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7649;
        if( _1 != _7649 ){
            DeRef(_1);
        }
        _7649 = NOVALUE;
        _7646 = NOVALUE;
        goto L17; // [954] 1096

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7652 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7650 = NOVALUE;
        if (IS_ATOM_INT(_7652) && IS_ATOM_INT(_the_value_p_13365)) {
            if (_7652 == (short)_7652 && _the_value_p_13365 <= INT15 && _the_value_p_13365 >= -INT15)
            _7653 = _7652 * _the_value_p_13365;
            else
            _7653 = NewDouble(_7652 * (double)_the_value_p_13365);
        }
        else {
            _7653 = binary_op(MULTIPLY, _7652, _the_value_p_13365);
        }
        _7652 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7653;
        if( _1 != _7653 ){
            DeRef(_1);
        }
        _7653 = NOVALUE;
        _7650 = NOVALUE;
        goto L17; // [979] 1096

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7656 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7654 = NOVALUE;
        if (IS_ATOM_INT(_7656) && IS_ATOM_INT(_the_value_p_13365)) {
            _7657 = (_7656 % _the_value_p_13365) ? NewDouble((double)_7656 / _the_value_p_13365) : (_7656 / _the_value_p_13365);
        }
        else {
            _7657 = binary_op(DIVIDE, _7656, _the_value_p_13365);
        }
        _7656 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7657;
        if( _1 != _7657 ){
            DeRef(_1);
        }
        _7657 = NOVALUE;
        _7654 = NOVALUE;
        goto L17; // [1004] 1096

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_13372);
        _7660 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7660);
        _7661 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7660 = NOVALUE;
        Ref(_the_value_p_13365);
        Append(&_7662, _7661, _the_value_p_13365);
        _7661 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7662;
        if( _1 != _7662 ){
            DeRef(_1);
        }
        _7662 = NOVALUE;
        _7658 = NOVALUE;
        goto L17; // [1033] 1096

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13372);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13372 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7665 = (int)*(((s1_ptr)_2)->base + _index__13368);
        _7663 = NOVALUE;
        if (IS_SEQUENCE(_7665) && IS_ATOM(_the_value_p_13365)) {
            Ref(_the_value_p_13365);
            Append(&_7666, _7665, _the_value_p_13365);
        }
        else if (IS_ATOM(_7665) && IS_SEQUENCE(_the_value_p_13365)) {
            Ref(_7665);
            Prepend(&_7666, _the_value_p_13365, _7665);
        }
        else {
            Concat((object_ptr)&_7666, _7665, _the_value_p_13365);
            _7665 = NOVALUE;
        }
        _7665 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13368);
        _1 = *(int *)_2;
        *(int *)_2 = _7666;
        if( _1 != _7666 ){
            DeRef(_1);
        }
        _7666 = NOVALUE;
        _7663 = NOVALUE;
        goto L17; // [1058] 1096

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_13366 = _operation_p_13366;
        goto L17; // [1069] 1096

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1077_13558);
        _msg_inlined_crash_at_1077_13558 = EPrintf(-9999999, _7572, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1077_13558);

        /** end procedure*/
        goto L18; // [1090] 1093
L18: 
        DeRefi(_msg_inlined_crash_at_1077_13558);
        _msg_inlined_crash_at_1077_13558 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13372);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13363);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13372;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRefDS(_map_data_13372);
    _7536 = NOVALUE;
    _7580 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_13364);
    DeRef(_the_value_p_13365);
    DeRef(_average_length__13370);
    DeRef(_map_data_13372);
    _7536 = NOVALUE;
    _7580 = NOVALUE;
    return;
    ;
}


void  __stdcall _33nested_put(int _the_map_p_13561, int _the_keys_p_13562, int _the_value_p_13563, int _operation_p_13564, int _trigger_p_13565)
{
    int _temp_map__13566 = NOVALUE;
    int _7678 = NOVALUE;
    int _7677 = NOVALUE;
    int _7676 = NOVALUE;
    int _7675 = NOVALUE;
    int _7674 = NOVALUE;
    int _7673 = NOVALUE;
    int _7671 = NOVALUE;
    int _7670 = NOVALUE;
    int _7669 = NOVALUE;
    int _7667 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_operation_p_13564)) {
        _1 = (long)(DBL_PTR(_operation_p_13564)->dbl);
        DeRefDS(_operation_p_13564);
        _operation_p_13564 = _1;
    }
    if (!IS_ATOM_INT(_trigger_p_13565)) {
        _1 = (long)(DBL_PTR(_trigger_p_13565)->dbl);
        DeRefDS(_trigger_p_13565);
        _trigger_p_13565 = _1;
    }

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_13562)){
            _7667 = SEQ_PTR(_the_keys_p_13562)->length;
    }
    else {
        _7667 = 1;
    }
    if (_7667 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13562);
    _7669 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13561);
    Ref(_7669);
    Ref(_the_value_p_13563);
    _33put(_the_map_p_13561, _7669, _the_value_p_13563, _operation_p_13564, _trigger_p_13565);
    _7669 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13562);
    _7670 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13561);
    Ref(_7670);
    _7671 = _33get(_the_map_p_13561, _7670, 0);
    _7670 = NOVALUE;
    _0 = _temp_map__13566;
    _temp_map__13566 = _33new_extra(_7671, 690);
    DeRef(_0);
    _7671 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_13562)){
            _7673 = SEQ_PTR(_the_keys_p_13562)->length;
    }
    else {
        _7673 = 1;
    }
    rhs_slice_target = (object_ptr)&_7674;
    RHS_Slice(_the_keys_p_13562, 2, _7673);
    Ref(_the_value_p_13563);
    DeRef(_7675);
    _7675 = _the_value_p_13563;
    DeRef(_7676);
    _7676 = _operation_p_13564;
    DeRef(_7677);
    _7677 = _trigger_p_13565;
    Ref(_temp_map__13566);
    _33nested_put(_temp_map__13566, _7674, _7675, _7676, _7677);
    _7674 = NOVALUE;
    _7675 = NOVALUE;
    _7676 = NOVALUE;
    _7677 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13562);
    _7678 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13561);
    Ref(_7678);
    Ref(_temp_map__13566);
    _33put(_the_map_p_13561, _7678, _temp_map__13566, 1, _trigger_p_13565);
    _7678 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_13561);
    DeRefDS(_the_keys_p_13562);
    DeRef(_the_value_p_13563);
    DeRef(_temp_map__13566);
    return;
    ;
}


void  __stdcall _33remove(int _the_map_p_13583, int _the_key_p_13584)
{
    int _index__13585 = NOVALUE;
    int _bucket__13586 = NOVALUE;
    int _temp_map__13587 = NOVALUE;
    int _from__13588 = NOVALUE;
    int _calc_hash_1__tmp_at40_13599 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13598 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13597 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13596 = NOVALUE;
    int _7743 = NOVALUE;
    int _7742 = NOVALUE;
    int _7741 = NOVALUE;
    int _7740 = NOVALUE;
    int _7738 = NOVALUE;
    int _7736 = NOVALUE;
    int _7734 = NOVALUE;
    int _7732 = NOVALUE;
    int _7731 = NOVALUE;
    int _7729 = NOVALUE;
    int _7726 = NOVALUE;
    int _7725 = NOVALUE;
    int _7724 = NOVALUE;
    int _7723 = NOVALUE;
    int _7722 = NOVALUE;
    int _7721 = NOVALUE;
    int _7720 = NOVALUE;
    int _7719 = NOVALUE;
    int _7718 = NOVALUE;
    int _7717 = NOVALUE;
    int _7716 = NOVALUE;
    int _7715 = NOVALUE;
    int _7714 = NOVALUE;
    int _7712 = NOVALUE;
    int _7711 = NOVALUE;
    int _7710 = NOVALUE;
    int _7709 = NOVALUE;
    int _7708 = NOVALUE;
    int _7707 = NOVALUE;
    int _7706 = NOVALUE;
    int _7705 = NOVALUE;
    int _7704 = NOVALUE;
    int _7703 = NOVALUE;
    int _7702 = NOVALUE;
    int _7700 = NOVALUE;
    int _7698 = NOVALUE;
    int _7696 = NOVALUE;
    int _7695 = NOVALUE;
    int _7694 = NOVALUE;
    int _7692 = NOVALUE;
    int _7691 = NOVALUE;
    int _7690 = NOVALUE;
    int _7689 = NOVALUE;
    int _7688 = NOVALUE;
    int _7685 = NOVALUE;
    int _7684 = NOVALUE;
    int _7683 = NOVALUE;
    int _7682 = NOVALUE;
    int _7680 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13587);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13583)){
        _temp_map__13587 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13583)->dbl));
    }
    else{
        _temp_map__13587 = (int)*(((s1_ptr)_2)->base + _the_map_p_13583);
    }
    Ref(_temp_map__13587);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13583))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13583)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13583);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7680 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7680, 76)){
        _7680 = NOVALUE;
        goto L1; // [25] 303
    }
    _7680 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7682 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7682)){
            _7683 = SEQ_PTR(_7682)->length;
    }
    else {
        _7683 = 1;
    }
    _7682 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_13596 = _7683;
    _7683 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13597);
    _ret__inlined_calc_hash_at_40_13597 = calc_hash(_the_key_p_13584, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13597)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13597)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13597);
        _ret__inlined_calc_hash_at_40_13597 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13599 = (_ret__inlined_calc_hash_at_40_13597 % _max_hash_p_inlined_calc_hash_at_37_13596);
    _bucket__13586 = _calc_hash_1__tmp_at40_13599 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13597);
    _ret__inlined_calc_hash_at_40_13597 = NOVALUE;

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7684 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7684);
    _7685 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7684 = NOVALUE;
    _index__13585 = find_from(_the_key_p_13584, _7685, 1);
    _7685 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__13585 == 0)
    goto L2; // [81] 429

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7688 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7688)) {
        _7689 = _7688 - 1;
        if ((long)((unsigned long)_7689 +(unsigned long) HIGH_BITS) >= 0){
            _7689 = NewDouble((double)_7689);
        }
    }
    else {
        _7689 = binary_op(MINUS, _7688, 1);
    }
    _7688 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7689;
    if( _1 != _7689 ){
        DeRef(_1);
    }
    _7689 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7690 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7690);
    _7691 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7690 = NOVALUE;
    if (IS_SEQUENCE(_7691)){
            _7692 = SEQ_PTR(_7691)->length;
    }
    else {
        _7692 = 1;
    }
    _7691 = NOVALUE;
    if (_7692 != 1)
    goto L3; // [112] 155

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7694 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7694)) {
        _7695 = _7694 - 1;
        if ((long)((unsigned long)_7695 +(unsigned long) HIGH_BITS) >= 0){
            _7695 = NewDouble((double)_7695);
        }
    }
    else {
        _7695 = binary_op(MINUS, _7694, 1);
    }
    _7694 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7695;
    if( _1 != _7695 ){
        DeRef(_1);
    }
    _7695 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13586);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7696 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13586);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7698 = NOVALUE;
    goto L4; // [152] 260
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7702 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7702);
    _7703 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7702 = NOVALUE;
    _7704 = _index__13585 - 1;
    rhs_slice_target = (object_ptr)&_7705;
    RHS_Slice(_7703, 1, _7704);
    _7703 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7706 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7706);
    _7707 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7706 = NOVALUE;
    _7708 = _index__13585 + 1;
    if (_7708 > MAXINT){
        _7708 = NewDouble((double)_7708);
    }
    if (IS_SEQUENCE(_7707)){
            _7709 = SEQ_PTR(_7707)->length;
    }
    else {
        _7709 = 1;
    }
    rhs_slice_target = (object_ptr)&_7710;
    RHS_Slice(_7707, _7708, _7709);
    _7707 = NOVALUE;
    Concat((object_ptr)&_7711, _7705, _7710);
    DeRefDS(_7705);
    _7705 = NOVALUE;
    DeRef(_7705);
    _7705 = NOVALUE;
    DeRefDS(_7710);
    _7710 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13586);
    _1 = *(int *)_2;
    *(int *)_2 = _7711;
    if( _1 != _7711 ){
        DeRef(_1);
    }
    _7711 = NOVALUE;
    _7700 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7714 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7714);
    _7715 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7714 = NOVALUE;
    _7716 = _index__13585 - 1;
    rhs_slice_target = (object_ptr)&_7717;
    RHS_Slice(_7715, 1, _7716);
    _7715 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7718 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7718);
    _7719 = (int)*(((s1_ptr)_2)->base + _bucket__13586);
    _7718 = NOVALUE;
    _7720 = _index__13585 + 1;
    if (_7720 > MAXINT){
        _7720 = NewDouble((double)_7720);
    }
    if (IS_SEQUENCE(_7719)){
            _7721 = SEQ_PTR(_7719)->length;
    }
    else {
        _7721 = 1;
    }
    rhs_slice_target = (object_ptr)&_7722;
    RHS_Slice(_7719, _7720, _7721);
    _7719 = NOVALUE;
    Concat((object_ptr)&_7723, _7717, _7722);
    DeRefDS(_7717);
    _7717 = NOVALUE;
    DeRef(_7717);
    _7717 = NOVALUE;
    DeRefDS(_7722);
    _7722 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13586);
    _1 = *(int *)_2;
    *(int *)_2 = _7723;
    if( _1 != _7723 ){
        DeRef(_1);
    }
    _7723 = NOVALUE;
    _7712 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7724 = (int)*(((s1_ptr)_2)->base + 2);
    if (_33threshold_size_12989 <= INT15 && _33threshold_size_12989 >= -INT15)
    _7725 = 51 * _33threshold_size_12989;
    else
    _7725 = NewDouble(51 * (double)_33threshold_size_12989);
    if (IS_ATOM_INT(_7725)) {
        if (100 > 0 && _7725 >= 0) {
            _7726 = _7725 / 100;
        }
        else {
            temp_dbl = floor((double)_7725 / (double)100);
            if (_7725 != MININT)
            _7726 = (long)temp_dbl;
            else
            _7726 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7725, 100);
        _7726 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7725);
    _7725 = NOVALUE;
    if (binary_op_a(GREATEREQ, _7724, _7726)){
        _7724 = NOVALUE;
        DeRef(_7726);
        _7726 = NOVALUE;
        goto L2; // [276] 429
    }
    _7724 = NOVALUE;
    DeRef(_7726);
    _7726 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13587);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13583))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13583)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13583);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13587;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_13583);
    _33convert_to_small_map(_the_map_p_13583);

    /** 				return*/
    DeRef(_the_map_p_13583);
    DeRef(_the_key_p_13584);
    DeRefDS(_temp_map__13587);
    _7682 = NOVALUE;
    _7691 = NOVALUE;
    DeRef(_7704);
    _7704 = NOVALUE;
    DeRef(_7716);
    _7716 = NOVALUE;
    DeRef(_7708);
    _7708 = NOVALUE;
    DeRef(_7720);
    _7720 = NOVALUE;
    return;
    goto L2; // [300] 429
L1: 

    /** 		from_ = 1*/
    _from__13588 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__13588 <= 0)
    goto L6; // [313] 428

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7729 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13585 = find_from(_the_key_p_13584, _7729, _from__13588);
    _7729 = NOVALUE;

    /** 			if index_ then*/
    if (_index__13585 == 0)
    {
        goto L6; // [330] 428
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7731 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7731);
    _7732 = (int)*(((s1_ptr)_2)->base + _index__13585);
    _7731 = NOVALUE;
    if (binary_op_a(NOTEQ, _7732, 1)){
        _7732 = NOVALUE;
        goto L7; // [343] 417
    }
    _7732 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13585);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7734 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_33init_small_map_key_12990);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13585);
    _1 = *(int *)_2;
    *(int *)_2 = _33init_small_map_key_12990;
    DeRef(_1);
    _7736 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13585);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7738 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7740 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7740)) {
        _7741 = _7740 - 1;
        if ((long)((unsigned long)_7741 +(unsigned long) HIGH_BITS) >= 0){
            _7741 = NewDouble((double)_7741);
        }
    }
    else {
        _7741 = binary_op(MINUS, _7740, 1);
    }
    _7740 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7741;
    if( _1 != _7741 ){
        DeRef(_1);
    }
    _7741 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13587);
    _7742 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7742)) {
        _7743 = _7742 - 1;
        if ((long)((unsigned long)_7743 +(unsigned long) HIGH_BITS) >= 0){
            _7743 = NewDouble((double)_7743);
        }
    }
    else {
        _7743 = binary_op(MINUS, _7742, 1);
    }
    _7742 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13587);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13587 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7743;
    if( _1 != _7743 ){
        DeRef(_1);
    }
    _7743 = NOVALUE;
    goto L7; // [409] 417

    /** 				exit*/
    goto L6; // [414] 428
L7: 

    /** 			from_ = index_ + 1*/
    _from__13588 = _index__13585 + 1;

    /** 		end while*/
    goto L5; // [425] 313
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13587);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13583))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13583)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13583);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13587;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13583);
    DeRef(_the_key_p_13584);
    DeRefDS(_temp_map__13587);
    _7682 = NOVALUE;
    _7691 = NOVALUE;
    DeRef(_7704);
    _7704 = NOVALUE;
    DeRef(_7716);
    _7716 = NOVALUE;
    DeRef(_7708);
    _7708 = NOVALUE;
    DeRef(_7720);
    _7720 = NOVALUE;
    return;
    ;
}


void  __stdcall _33clear(int _the_map_p_13673)
{
    int _temp_map__13674 = NOVALUE;
    int _7762 = NOVALUE;
    int _7761 = NOVALUE;
    int _7760 = NOVALUE;
    int _7759 = NOVALUE;
    int _7758 = NOVALUE;
    int _7757 = NOVALUE;
    int _7756 = NOVALUE;
    int _7755 = NOVALUE;
    int _7754 = NOVALUE;
    int _7753 = NOVALUE;
    int _7752 = NOVALUE;
    int _7751 = NOVALUE;
    int _7750 = NOVALUE;
    int _7749 = NOVALUE;
    int _7748 = NOVALUE;
    int _7746 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13674);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13673)){
        _temp_map__13674 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13673)->dbl));
    }
    else{
        _temp_map__13674 = (int)*(((s1_ptr)_2)->base + _the_map_p_13673);
    }
    Ref(_temp_map__13674);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7746 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7746, 76)){
        _7746 = NOVALUE;
        goto L1; // [17] 70
    }
    _7746 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7748 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7748)){
            _7749 = SEQ_PTR(_7748)->length;
    }
    else {
        _7749 = 1;
    }
    _7748 = NOVALUE;
    _7750 = Repeat(_5, _7749);
    _7749 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7750;
    if( _1 != _7750 ){
        DeRef(_1);
    }
    _7750 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7751 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7751)){
            _7752 = SEQ_PTR(_7751)->length;
    }
    else {
        _7752 = 1;
    }
    _7751 = NOVALUE;
    _7753 = Repeat(_5, _7752);
    _7752 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7753;
    if( _1 != _7753 ){
        DeRef(_1);
    }
    _7753 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7754 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7754)){
            _7755 = SEQ_PTR(_7754)->length;
    }
    else {
        _7755 = 1;
    }
    _7754 = NOVALUE;
    _7756 = Repeat(_33init_small_map_key_12990, _7755);
    _7755 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7756;
    if( _1 != _7756 ){
        DeRef(_1);
    }
    _7756 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7757 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7757)){
            _7758 = SEQ_PTR(_7757)->length;
    }
    else {
        _7758 = 1;
    }
    _7757 = NOVALUE;
    _7759 = Repeat(0, _7758);
    _7758 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7759;
    if( _1 != _7759 ){
        DeRef(_1);
    }
    _7759 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13674);
    _7760 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7760)){
            _7761 = SEQ_PTR(_7760)->length;
    }
    else {
        _7761 = 1;
    }
    _7760 = NOVALUE;
    _7762 = Repeat(0, _7761);
    _7761 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13674);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13674 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7762;
    if( _1 != _7762 ){
        DeRef(_1);
    }
    _7762 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13674);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13673))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13673)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13673);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13674;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13673);
    DeRefDS(_temp_map__13674);
    _7748 = NOVALUE;
    _7751 = NOVALUE;
    _7754 = NOVALUE;
    _7757 = NOVALUE;
    _7760 = NOVALUE;
    return;
    ;
}


int  __stdcall _33size(int _the_map_p_13697)
{
    int _7764 = NOVALUE;
    int _7763 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13697)){
        _7763 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13697)->dbl));
    }
    else{
        _7763 = (int)*(((s1_ptr)_2)->base + _the_map_p_13697);
    }
    _2 = (int)SEQ_PTR(_7763);
    _7764 = (int)*(((s1_ptr)_2)->base + 2);
    _7763 = NOVALUE;
    Ref(_7764);
    DeRef(_the_map_p_13697);
    return _7764;
    ;
}


int  __stdcall _33statistics(int _the_map_p_13709)
{
    int _statistic_set__13710 = NOVALUE;
    int _lengths__13711 = NOVALUE;
    int _length__13712 = NOVALUE;
    int _temp_map__13713 = NOVALUE;
    int _7795 = NOVALUE;
    int _7794 = NOVALUE;
    int _7793 = NOVALUE;
    int _7792 = NOVALUE;
    int _7791 = NOVALUE;
    int _7790 = NOVALUE;
    int _7789 = NOVALUE;
    int _7788 = NOVALUE;
    int _7787 = NOVALUE;
    int _7786 = NOVALUE;
    int _7785 = NOVALUE;
    int _7784 = NOVALUE;
    int _7781 = NOVALUE;
    int _7779 = NOVALUE;
    int _7776 = NOVALUE;
    int _7775 = NOVALUE;
    int _7774 = NOVALUE;
    int _7773 = NOVALUE;
    int _7771 = NOVALUE;
    int _7770 = NOVALUE;
    int _7769 = NOVALUE;
    int _7768 = NOVALUE;
    int _7766 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13713);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13709)){
        _temp_map__13713 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13709)->dbl));
    }
    else{
        _temp_map__13713 = (int)*(((s1_ptr)_2)->base + _the_map_p_13709);
    }
    Ref(_temp_map__13713);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7766 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7766, 76)){
        _7766 = NOVALUE;
        goto L1; // [17] 164
    }
    _7766 = NOVALUE;

    /** 		statistic_set_ = { */
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7768 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7769 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7770 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7770)){
            _7771 = SEQ_PTR(_7770)->length;
    }
    else {
        _7771 = 1;
    }
    _7770 = NOVALUE;
    _0 = _statistic_set__13710;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7768);
    *((int *)(_2+4)) = _7768;
    Ref(_7769);
    *((int *)(_2+8)) = _7769;
    *((int *)(_2+12)) = _7771;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 1073741823;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    _statistic_set__13710 = MAKE_SEQ(_1);
    DeRef(_0);
    _7771 = NOVALUE;
    _7769 = NOVALUE;
    _7768 = NOVALUE;

    /** 		lengths_ = {}*/
    RefDS(_5);
    DeRefi(_lengths__13711);
    _lengths__13711 = _5;

    /** 		for i = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7773 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7773)){
            _7774 = SEQ_PTR(_7773)->length;
    }
    else {
        _7774 = 1;
    }
    _7773 = NOVALUE;
    {
        int _i_13724;
        _i_13724 = 1;
L2: 
        if (_i_13724 > _7774){
            goto L3; // [64] 138
        }

        /** 			length_ = length(temp_map_[KEY_BUCKETS][i])*/
        _2 = (int)SEQ_PTR(_temp_map__13713);
        _7775 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7775);
        _7776 = (int)*(((s1_ptr)_2)->base + _i_13724);
        _7775 = NOVALUE;
        if (IS_SEQUENCE(_7776)){
                _length__13712 = SEQ_PTR(_7776)->length;
        }
        else {
            _length__13712 = 1;
        }
        _7776 = NOVALUE;

        /** 			if length_ > 0 then*/
        if (_length__13712 <= 0)
        goto L4; // [86] 131

        /** 				if length_ > statistic_set_[LARGEST_BUCKET] then*/
        _2 = (int)SEQ_PTR(_statistic_set__13710);
        _7779 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(LESSEQ, _length__13712, _7779)){
            _7779 = NOVALUE;
            goto L5; // [96] 107
        }
        _7779 = NOVALUE;

        /** 					statistic_set_[LARGEST_BUCKET] = length_*/
        _2 = (int)SEQ_PTR(_statistic_set__13710);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _statistic_set__13710 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _length__13712;
        DeRef(_1);
L5: 

        /** 				if length_ < statistic_set_[SMALLEST_BUCKET] then*/
        _2 = (int)SEQ_PTR(_statistic_set__13710);
        _7781 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _length__13712, _7781)){
            _7781 = NOVALUE;
            goto L6; // [113] 124
        }
        _7781 = NOVALUE;

        /** 					statistic_set_[SMALLEST_BUCKET] = length_*/
        _2 = (int)SEQ_PTR(_statistic_set__13710);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _statistic_set__13710 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _length__13712;
        DeRef(_1);
L6: 

        /** 				lengths_ &= length_*/
        Append(&_lengths__13711, _lengths__13711, _length__13712);
L4: 

        /** 		end for*/
        _i_13724 = _i_13724 + 1;
        goto L2; // [133] 71
L3: 
        ;
    }

    /** 		statistic_set_[AVERAGE_BUCKET] = stats:average(lengths_)*/
    RefDS(_lengths__13711);
    _7784 = _35average(_lengths__13711, 1);
    _2 = (int)SEQ_PTR(_statistic_set__13710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _statistic_set__13710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7784;
    if( _1 != _7784 ){
        DeRef(_1);
    }
    _7784 = NOVALUE;

    /** 		statistic_set_[STDEV_BUCKET] = stats:stdev(lengths_)*/
    RefDS(_lengths__13711);
    _7785 = _35stdev(_lengths__13711, 1, 2);
    _2 = (int)SEQ_PTR(_statistic_set__13710);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _statistic_set__13710 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7785;
    if( _1 != _7785 ){
        DeRef(_1);
    }
    _7785 = NOVALUE;
    goto L7; // [161] 213
L1: 

    /** 		statistic_set_ = {*/
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7786 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7787 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7788 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7788)){
            _7789 = SEQ_PTR(_7788)->length;
    }
    else {
        _7789 = 1;
    }
    _7788 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7790 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7790)){
            _7791 = SEQ_PTR(_7790)->length;
    }
    else {
        _7791 = 1;
    }
    _7790 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7792 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7792)){
            _7793 = SEQ_PTR(_7792)->length;
    }
    else {
        _7793 = 1;
    }
    _7792 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13713);
    _7794 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7794)){
            _7795 = SEQ_PTR(_7794)->length;
    }
    else {
        _7795 = 1;
    }
    _7794 = NOVALUE;
    _0 = _statistic_set__13710;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7786);
    *((int *)(_2+4)) = _7786;
    Ref(_7787);
    *((int *)(_2+8)) = _7787;
    *((int *)(_2+12)) = _7789;
    *((int *)(_2+16)) = _7791;
    *((int *)(_2+20)) = _7793;
    *((int *)(_2+24)) = _7795;
    *((int *)(_2+28)) = 0;
    _statistic_set__13710 = MAKE_SEQ(_1);
    DeRef(_0);
    _7795 = NOVALUE;
    _7793 = NOVALUE;
    _7791 = NOVALUE;
    _7789 = NOVALUE;
    _7787 = NOVALUE;
    _7786 = NOVALUE;
L7: 

    /** 	return statistic_set_*/
    DeRef(_the_map_p_13709);
    DeRefi(_lengths__13711);
    DeRef(_temp_map__13713);
    _7773 = NOVALUE;
    _7776 = NOVALUE;
    _7770 = NOVALUE;
    _7788 = NOVALUE;
    _7790 = NOVALUE;
    _7792 = NOVALUE;
    _7794 = NOVALUE;
    return _statistic_set__13710;
    ;
}


int  __stdcall _33keys(int _the_map_p_13755, int _sorted_result_13756)
{
    int _buckets__13757 = NOVALUE;
    int _current_bucket__13758 = NOVALUE;
    int _results__13759 = NOVALUE;
    int _pos__13760 = NOVALUE;
    int _temp_map__13761 = NOVALUE;
    int _7820 = NOVALUE;
    int _7818 = NOVALUE;
    int _7817 = NOVALUE;
    int _7815 = NOVALUE;
    int _7814 = NOVALUE;
    int _7813 = NOVALUE;
    int _7812 = NOVALUE;
    int _7810 = NOVALUE;
    int _7809 = NOVALUE;
    int _7808 = NOVALUE;
    int _7807 = NOVALUE;
    int _7805 = NOVALUE;
    int _7803 = NOVALUE;
    int _7800 = NOVALUE;
    int _7798 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sorted_result_13756)) {
        _1 = (long)(DBL_PTR(_sorted_result_13756)->dbl);
        DeRefDS(_sorted_result_13756);
        _sorted_result_13756 = _1;
    }

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13761);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13755)){
        _temp_map__13761 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13755)->dbl));
    }
    else{
        _temp_map__13761 = (int)*(((s1_ptr)_2)->base + _the_map_p_13755);
    }
    Ref(_temp_map__13761);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13761);
    _7798 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13759);
    _results__13759 = Repeat(0, _7798);
    _7798 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13760 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13761);
    _7800 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7800, 76)){
        _7800 = NOVALUE;
        goto L1; // [34] 113
    }
    _7800 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__13757);
    _2 = (int)SEQ_PTR(_temp_map__13761);
    _buckets__13757 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__13757);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13757)){
            _7803 = SEQ_PTR(_buckets__13757)->length;
    }
    else {
        _7803 = 1;
    }
    {
        int _index_13770;
        _index_13770 = 1;
L2: 
        if (_index_13770 > _7803){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__13758);
        _2 = (int)SEQ_PTR(_buckets__13757);
        _current_bucket__13758 = (int)*(((s1_ptr)_2)->base + _index_13770);
        Ref(_current_bucket__13758);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__13758)){
                _7805 = SEQ_PTR(_current_bucket__13758)->length;
        }
        else {
            _7805 = 1;
        }
        if (_7805 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__13758)){
                _7807 = SEQ_PTR(_current_bucket__13758)->length;
        }
        else {
            _7807 = 1;
        }
        _7808 = _pos__13760 + _7807;
        if ((long)((unsigned long)_7808 + (unsigned long)HIGH_BITS) >= 0) 
        _7808 = NewDouble((double)_7808);
        _7807 = NOVALUE;
        if (IS_ATOM_INT(_7808)) {
            _7809 = _7808 - 1;
        }
        else {
            _7809 = NewDouble(DBL_PTR(_7808)->dbl - (double)1);
        }
        DeRef(_7808);
        _7808 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13759;
        AssignSlice(_pos__13760, _7809, _current_bucket__13758);
        DeRef(_7809);
        _7809 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__13758)){
                _7810 = SEQ_PTR(_current_bucket__13758)->length;
        }
        else {
            _7810 = 1;
        }
        _pos__13760 = _pos__13760 + _7810;
        _7810 = NOVALUE;
L4: 

        /** 		end for*/
        _index_13770 = _index_13770 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13761);
    _7812 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7812)){
            _7813 = SEQ_PTR(_7812)->length;
    }
    else {
        _7813 = 1;
    }
    _7812 = NOVALUE;
    {
        int _index_13783;
        _index_13783 = 1;
L6: 
        if (_index_13783 > _7813){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13761);
        _7814 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7814);
        _7815 = (int)*(((s1_ptr)_2)->base + _index_13783);
        _7814 = NOVALUE;
        if (binary_op_a(EQUALS, _7815, 0)){
            _7815 = NOVALUE;
            goto L8; // [139] 164
        }
        _7815 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13761);
        _7817 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7817);
        _7818 = (int)*(((s1_ptr)_2)->base + _index_13783);
        _7817 = NOVALUE;
        Ref(_7818);
        _2 = (int)SEQ_PTR(_results__13759);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13759 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13760);
        _1 = *(int *)_2;
        *(int *)_2 = _7818;
        if( _1 != _7818 ){
            DeRef(_1);
        }
        _7818 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13760 = _pos__13760 + 1;
L8: 

        /** 		end for*/
        _index_13783 = _index_13783 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_13756 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13759);
    _7820 = _24sort(_results__13759, 1);
    DeRef(_the_map_p_13755);
    DeRef(_buckets__13757);
    DeRef(_current_bucket__13758);
    DeRefDS(_results__13759);
    DeRef(_temp_map__13761);
    _7812 = NOVALUE;
    return _7820;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_13755);
    DeRef(_buckets__13757);
    DeRef(_current_bucket__13758);
    DeRef(_temp_map__13761);
    _7812 = NOVALUE;
    DeRef(_7820);
    _7820 = NOVALUE;
    return _results__13759;
LA: 
    ;
}


int  __stdcall _33values(int _the_map_13798, int _keys_13799, int _default_values_13800)
{
    int _buckets__13824 = NOVALUE;
    int _bucket__13825 = NOVALUE;
    int _results__13826 = NOVALUE;
    int _pos__13827 = NOVALUE;
    int _temp_map__13828 = NOVALUE;
    int _7860 = NOVALUE;
    int _7859 = NOVALUE;
    int _7857 = NOVALUE;
    int _7856 = NOVALUE;
    int _7855 = NOVALUE;
    int _7854 = NOVALUE;
    int _7852 = NOVALUE;
    int _7851 = NOVALUE;
    int _7850 = NOVALUE;
    int _7849 = NOVALUE;
    int _7847 = NOVALUE;
    int _7845 = NOVALUE;
    int _7842 = NOVALUE;
    int _7840 = NOVALUE;
    int _7838 = NOVALUE;
    int _7837 = NOVALUE;
    int _7836 = NOVALUE;
    int _7835 = NOVALUE;
    int _7833 = NOVALUE;
    int _7832 = NOVALUE;
    int _7831 = NOVALUE;
    int _7830 = NOVALUE;
    int _7829 = NOVALUE;
    int _7828 = NOVALUE;
    int _7826 = NOVALUE;
    int _7825 = NOVALUE;
    int _7823 = NOVALUE;
    int _7822 = NOVALUE;
    int _7821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _7821 = IS_SEQUENCE(_keys_13799);
    if (_7821 == 0)
    {
        _7821 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _7821 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _7822 = IS_ATOM(_default_values_13800);
    if (_7822 == 0)
    {
        _7822 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _7822 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    if (IS_SEQUENCE(_keys_13799)){
            _7823 = SEQ_PTR(_keys_13799)->length;
    }
    else {
        _7823 = 1;
    }
    _0 = _default_values_13800;
    _default_values_13800 = Repeat(_default_values_13800, _7823);
    DeRef(_0);
    _7823 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_13800)){
            _7825 = SEQ_PTR(_default_values_13800)->length;
    }
    else {
        _7825 = 1;
    }
    if (IS_SEQUENCE(_keys_13799)){
            _7826 = SEQ_PTR(_keys_13799)->length;
    }
    else {
        _7826 = 1;
    }
    if (_7825 >= _7826)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_13800)){
            _7828 = SEQ_PTR(_default_values_13800)->length;
    }
    else {
        _7828 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_13800);
    _7829 = (int)*(((s1_ptr)_2)->base + _7828);
    if (IS_SEQUENCE(_keys_13799)){
            _7830 = SEQ_PTR(_keys_13799)->length;
    }
    else {
        _7830 = 1;
    }
    if (IS_SEQUENCE(_default_values_13800)){
            _7831 = SEQ_PTR(_default_values_13800)->length;
    }
    else {
        _7831 = 1;
    }
    _7832 = _7830 - _7831;
    _7830 = NOVALUE;
    _7831 = NOVALUE;
    _7833 = Repeat(_7829, _7832);
    _7829 = NOVALUE;
    _7832 = NOVALUE;
    if (IS_SEQUENCE(_default_values_13800) && IS_ATOM(_7833)) {
    }
    else if (IS_ATOM(_default_values_13800) && IS_SEQUENCE(_7833)) {
        Ref(_default_values_13800);
        Prepend(&_default_values_13800, _7833, _default_values_13800);
    }
    else {
        Concat((object_ptr)&_default_values_13800, _default_values_13800, _7833);
    }
    DeRefDS(_7833);
    _7833 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_13799)){
            _7835 = SEQ_PTR(_keys_13799)->length;
    }
    else {
        _7835 = 1;
    }
    {
        int _i_13819;
        _i_13819 = 1;
L5: 
        if (_i_13819 > _7835){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_13799);
        _7836 = (int)*(((s1_ptr)_2)->base + _i_13819);
        _2 = (int)SEQ_PTR(_default_values_13800);
        _7837 = (int)*(((s1_ptr)_2)->base + _i_13819);
        Ref(_the_map_13798);
        Ref(_7836);
        Ref(_7837);
        _7838 = _33get(_the_map_13798, _7836, _7837);
        _7836 = NOVALUE;
        _7837 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_13799);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_13799 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13819);
        _1 = *(int *)_2;
        *(int *)_2 = _7838;
        if( _1 != _7838 ){
            DeRef(_1);
        }
        _7838 = NOVALUE;

        /** 		end for*/
        _i_13819 = _i_13819 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_the_map_13798);
    DeRef(_default_values_13800);
    DeRef(_buckets__13824);
    DeRef(_bucket__13825);
    DeRef(_results__13826);
    DeRef(_temp_map__13828);
    return _keys_13799;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__13828);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_13798)){
        _temp_map__13828 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_13798)->dbl));
    }
    else{
        _temp_map__13828 = (int)*(((s1_ptr)_2)->base + _the_map_13798);
    }
    Ref(_temp_map__13828);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13828);
    _7840 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13826);
    _results__13826 = Repeat(0, _7840);
    _7840 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13827 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13828);
    _7842 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7842, 76)){
        _7842 = NOVALUE;
        goto L7; // [157] 236
    }
    _7842 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__13824);
    _2 = (int)SEQ_PTR(_temp_map__13828);
    _buckets__13824 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__13824);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13824)){
            _7845 = SEQ_PTR(_buckets__13824)->length;
    }
    else {
        _7845 = 1;
    }
    {
        int _index_13837;
        _index_13837 = 1;
L8: 
        if (_index_13837 > _7845){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__13825);
        _2 = (int)SEQ_PTR(_buckets__13824);
        _bucket__13825 = (int)*(((s1_ptr)_2)->base + _index_13837);
        Ref(_bucket__13825);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__13825)){
                _7847 = SEQ_PTR(_bucket__13825)->length;
        }
        else {
            _7847 = 1;
        }
        if (_7847 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__13825)){
                _7849 = SEQ_PTR(_bucket__13825)->length;
        }
        else {
            _7849 = 1;
        }
        _7850 = _pos__13827 + _7849;
        if ((long)((unsigned long)_7850 + (unsigned long)HIGH_BITS) >= 0) 
        _7850 = NewDouble((double)_7850);
        _7849 = NOVALUE;
        if (IS_ATOM_INT(_7850)) {
            _7851 = _7850 - 1;
        }
        else {
            _7851 = NewDouble(DBL_PTR(_7850)->dbl - (double)1);
        }
        DeRef(_7850);
        _7850 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13826;
        AssignSlice(_pos__13827, _7851, _bucket__13825);
        DeRef(_7851);
        _7851 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__13825)){
                _7852 = SEQ_PTR(_bucket__13825)->length;
        }
        else {
            _7852 = 1;
        }
        _pos__13827 = _pos__13827 + _7852;
        _7852 = NOVALUE;
LA: 

        /** 		end for*/
        _index_13837 = _index_13837 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13828);
    _7854 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7854)){
            _7855 = SEQ_PTR(_7854)->length;
    }
    else {
        _7855 = 1;
    }
    _7854 = NOVALUE;
    {
        int _index_13850;
        _index_13850 = 1;
LC: 
        if (_index_13850 > _7855){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13828);
        _7856 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7856);
        _7857 = (int)*(((s1_ptr)_2)->base + _index_13850);
        _7856 = NOVALUE;
        if (binary_op_a(EQUALS, _7857, 0)){
            _7857 = NOVALUE;
            goto LE; // [262] 287
        }
        _7857 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13828);
        _7859 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7859);
        _7860 = (int)*(((s1_ptr)_2)->base + _index_13850);
        _7859 = NOVALUE;
        Ref(_7860);
        _2 = (int)SEQ_PTR(_results__13826);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13826 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13827);
        _1 = *(int *)_2;
        *(int *)_2 = _7860;
        if( _1 != _7860 ){
            DeRef(_1);
        }
        _7860 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13827 = _pos__13827 + 1;
LE: 

        /** 		end for*/
        _index_13850 = _index_13850 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_the_map_13798);
    DeRef(_keys_13799);
    DeRef(_default_values_13800);
    DeRef(_buckets__13824);
    DeRef(_bucket__13825);
    DeRef(_temp_map__13828);
    _7854 = NOVALUE;
    return _results__13826;
    ;
}


int  __stdcall _33pairs(int _the_map_p_13862, int _sorted_result_13863)
{
    int _key_bucket__13864 = NOVALUE;
    int _value_bucket__13865 = NOVALUE;
    int _results__13866 = NOVALUE;
    int _pos__13867 = NOVALUE;
    int _temp_map__13868 = NOVALUE;
    int _7896 = NOVALUE;
    int _7894 = NOVALUE;
    int _7893 = NOVALUE;
    int _7891 = NOVALUE;
    int _7890 = NOVALUE;
    int _7889 = NOVALUE;
    int _7887 = NOVALUE;
    int _7885 = NOVALUE;
    int _7884 = NOVALUE;
    int _7883 = NOVALUE;
    int _7882 = NOVALUE;
    int _7880 = NOVALUE;
    int _7878 = NOVALUE;
    int _7877 = NOVALUE;
    int _7875 = NOVALUE;
    int _7874 = NOVALUE;
    int _7872 = NOVALUE;
    int _7870 = NOVALUE;
    int _7869 = NOVALUE;
    int _7868 = NOVALUE;
    int _7866 = NOVALUE;
    int _7864 = NOVALUE;
    int _7863 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sorted_result_13863)) {
        _1 = (long)(DBL_PTR(_sorted_result_13863)->dbl);
        DeRefDS(_sorted_result_13863);
        _sorted_result_13863 = _1;
    }

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13868);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13862)){
        _temp_map__13868 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13862)->dbl));
    }
    else{
        _temp_map__13868 = (int)*(((s1_ptr)_2)->base + _the_map_p_13862);
    }
    Ref(_temp_map__13868);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7863 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__13868);
    _7864 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13866);
    _results__13866 = Repeat(_7863, _7864);
    DeRefDS(_7863);
    _7863 = NOVALUE;
    _7864 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13867 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13868);
    _7866 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7866, 76)){
        _7866 = NOVALUE;
        goto L1; // [38] 147
    }
    _7866 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13868);
    _7868 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7868)){
            _7869 = SEQ_PTR(_7868)->length;
    }
    else {
        _7869 = 1;
    }
    _7868 = NOVALUE;
    {
        int _index_13877;
        _index_13877 = 1;
L2: 
        if (_index_13877 > _7869){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13868);
        _7870 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__13864);
        _2 = (int)SEQ_PTR(_7870);
        _key_bucket__13864 = (int)*(((s1_ptr)_2)->base + _index_13877);
        Ref(_key_bucket__13864);
        _7870 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13868);
        _7872 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__13865);
        _2 = (int)SEQ_PTR(_7872);
        _value_bucket__13865 = (int)*(((s1_ptr)_2)->base + _index_13877);
        Ref(_value_bucket__13865);
        _7872 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__13864)){
                _7874 = SEQ_PTR(_key_bucket__13864)->length;
        }
        else {
            _7874 = 1;
        }
        {
            int _j_13885;
            _j_13885 = 1;
L4: 
            if (_j_13885 > _7874){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13866);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13866 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13867 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__13864);
            _7877 = (int)*(((s1_ptr)_2)->base + _j_13885);
            Ref(_7877);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _7877;
            if( _1 != _7877 ){
                DeRef(_1);
            }
            _7877 = NOVALUE;
            _7875 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13866);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13866 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13867 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__13865);
            _7880 = (int)*(((s1_ptr)_2)->base + _j_13885);
            Ref(_7880);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _7880;
            if( _1 != _7880 ){
                DeRef(_1);
            }
            _7880 = NOVALUE;
            _7878 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__13867 = _pos__13867 + 1;

            /** 			end for*/
            _j_13885 = _j_13885 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_13877 = _index_13877 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13868);
    _7882 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7882)){
            _7883 = SEQ_PTR(_7882)->length;
    }
    else {
        _7883 = 1;
    }
    _7882 = NOVALUE;
    {
        int _index_13896;
        _index_13896 = 1;
L7: 
        if (_index_13896 > _7883){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13868);
        _7884 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7884);
        _7885 = (int)*(((s1_ptr)_2)->base + _index_13896);
        _7884 = NOVALUE;
        if (binary_op_a(EQUALS, _7885, 0)){
            _7885 = NOVALUE;
            goto L9; // [173] 222
        }
        _7885 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13866);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13866 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13867 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13868);
        _7889 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7889);
        _7890 = (int)*(((s1_ptr)_2)->base + _index_13896);
        _7889 = NOVALUE;
        Ref(_7890);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7890;
        if( _1 != _7890 ){
            DeRef(_1);
        }
        _7890 = NOVALUE;
        _7887 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13866);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13866 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13867 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13868);
        _7893 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7893);
        _7894 = (int)*(((s1_ptr)_2)->base + _index_13896);
        _7893 = NOVALUE;
        Ref(_7894);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7894;
        if( _1 != _7894 ){
            DeRef(_1);
        }
        _7894 = NOVALUE;
        _7891 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13867 = _pos__13867 + 1;
L9: 

        /** 		end for	*/
        _index_13896 = _index_13896 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_13863 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13866);
    _7896 = _24sort(_results__13866, 1);
    DeRef(_the_map_p_13862);
    DeRef(_key_bucket__13864);
    DeRef(_value_bucket__13865);
    DeRefDS(_results__13866);
    DeRef(_temp_map__13868);
    _7868 = NOVALUE;
    _7882 = NOVALUE;
    return _7896;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_13862);
    DeRef(_key_bucket__13864);
    DeRef(_value_bucket__13865);
    DeRef(_temp_map__13868);
    _7868 = NOVALUE;
    _7882 = NOVALUE;
    DeRef(_7896);
    _7896 = NOVALUE;
    return _results__13866;
LB: 
    ;
}


void  __stdcall _33optimize(int _the_map_p_13917, int _max_p_13918, int _grow_p_13919)
{
    int _stats__13921 = NOVALUE;
    int _next_guess__13922 = NOVALUE;
    int _prev_guess_13923 = NOVALUE;
    int _7917 = NOVALUE;
    int _7916 = NOVALUE;
    int _7914 = NOVALUE;
    int _7913 = NOVALUE;
    int _7912 = NOVALUE;
    int _7911 = NOVALUE;
    int _7910 = NOVALUE;
    int _7908 = NOVALUE;
    int _7906 = NOVALUE;
    int _7905 = NOVALUE;
    int _7904 = NOVALUE;
    int _7903 = NOVALUE;
    int _7899 = NOVALUE;
    int _7898 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_p_13918)) {
        _1 = (long)(DBL_PTR(_max_p_13918)->dbl);
        DeRefDS(_max_p_13918);
        _max_p_13918 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13917)){
        _7898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13917)->dbl));
    }
    else{
        _7898 = (int)*(((s1_ptr)_2)->base + _the_map_p_13917);
    }
    _2 = (int)SEQ_PTR(_7898);
    _7899 = (int)*(((s1_ptr)_2)->base + 4);
    _7898 = NOVALUE;
    if (binary_op_a(NOTEQ, _7899, 76)){
        _7899 = NOVALUE;
        goto L1; // [15] 178
    }
    _7899 = NOVALUE;

    /** 		if grow_p < 1 then*/
    if (binary_op_a(GREATEREQ, _grow_p_13919, 1)){
        goto L2; // [21] 31
    }

    /** 			grow_p = 1.333*/
    RefDS(_7897);
    DeRef(_grow_p_13919);
    _grow_p_13919 = _7897;
L2: 

    /** 		if max_p < 3 then*/
    if (_max_p_13918 >= 3)
    goto L3; // [33] 43

    /** 			max_p = 3*/
    _max_p_13918 = 3;
L3: 

    /** 		next_guess_ = math:max({1, floor(eumem:ram_space[the_map_p][ELEMENT_COUNT] / max_p)})*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_the_map_p_13917)){
        _7903 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13917)->dbl));
    }
    else{
        _7903 = (int)*(((s1_ptr)_2)->base + _the_map_p_13917);
    }
    _2 = (int)SEQ_PTR(_7903);
    _7904 = (int)*(((s1_ptr)_2)->base + 2);
    _7903 = NOVALUE;
    if (IS_ATOM_INT(_7904)) {
        if (_max_p_13918 > 0 && _7904 >= 0) {
            _7905 = _7904 / _max_p_13918;
        }
        else {
            temp_dbl = floor((double)_7904 / (double)_max_p_13918);
            if (_7904 != MININT)
            _7905 = (long)temp_dbl;
            else
            _7905 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7904, _max_p_13918);
        _7905 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _7904 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _7905;
    _7906 = MAKE_SEQ(_1);
    _7905 = NOVALUE;
    _next_guess__13922 = _20max(_7906);
    _7906 = NOVALUE;
    if (!IS_ATOM_INT(_next_guess__13922)) {
        _1 = (long)(DBL_PTR(_next_guess__13922)->dbl);
        DeRefDS(_next_guess__13922);
        _next_guess__13922 = _1;
    }

    /** 		while 1 with entry do*/
    goto L4; // [71] 158
L5: 

    /** 			if stats_[LARGEST_BUCKET] <= max_p then*/
    _2 = (int)SEQ_PTR(_stats__13921);
    _7908 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(GREATER, _7908, _max_p_13918)){
        _7908 = NOVALUE;
        goto L6; // [82] 91
    }
    _7908 = NOVALUE;

    /** 				exit -- Largest is now smaller than the maximum I wanted.*/
    goto L7; // [88] 177
L6: 

    /** 			if stats_[LARGEST_BUCKET] <= (stats_[STDEV_BUCKET]*3 + stats_[AVERAGE_BUCKET]) then*/
    _2 = (int)SEQ_PTR(_stats__13921);
    _7910 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_stats__13921);
    _7911 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_ATOM_INT(_7911)) {
        if (_7911 == (short)_7911)
        _7912 = _7911 * 3;
        else
        _7912 = NewDouble(_7911 * (double)3);
    }
    else {
        _7912 = binary_op(MULTIPLY, _7911, 3);
    }
    _7911 = NOVALUE;
    _2 = (int)SEQ_PTR(_stats__13921);
    _7913 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_7912) && IS_ATOM_INT(_7913)) {
        _7914 = _7912 + _7913;
        if ((long)((unsigned long)_7914 + (unsigned long)HIGH_BITS) >= 0) 
        _7914 = NewDouble((double)_7914);
    }
    else {
        _7914 = binary_op(PLUS, _7912, _7913);
    }
    DeRef(_7912);
    _7912 = NOVALUE;
    _7913 = NOVALUE;
    if (binary_op_a(GREATER, _7910, _7914)){
        _7910 = NOVALUE;
        DeRef(_7914);
        _7914 = NOVALUE;
        goto L8; // [113] 122
    }
    _7910 = NOVALUE;
    DeRef(_7914);
    _7914 = NOVALUE;

    /** 				exit -- Largest is smaller than is statistically expected.*/
    goto L7; // [119] 177
L8: 

    /** 			prev_guess = next_guess_*/
    _prev_guess_13923 = _next_guess__13922;

    /** 			next_guess_ = floor(stats_[NUM_BUCKETS] * grow_p)*/
    _2 = (int)SEQ_PTR(_stats__13921);
    _7916 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7916) && IS_ATOM_INT(_grow_p_13919)) {
        if (_7916 == (short)_7916 && _grow_p_13919 <= INT15 && _grow_p_13919 >= -INT15)
        _7917 = _7916 * _grow_p_13919;
        else
        _7917 = NewDouble(_7916 * (double)_grow_p_13919);
    }
    else {
        _7917 = binary_op(MULTIPLY, _7916, _grow_p_13919);
    }
    _7916 = NOVALUE;
    if (IS_ATOM_INT(_7917))
    _next_guess__13922 = e_floor(_7917);
    else
    _next_guess__13922 = unary_op(FLOOR, _7917);
    DeRef(_7917);
    _7917 = NOVALUE;
    if (!IS_ATOM_INT(_next_guess__13922)) {
        _1 = (long)(DBL_PTR(_next_guess__13922)->dbl);
        DeRefDS(_next_guess__13922);
        _next_guess__13922 = _1;
    }

    /** 			if prev_guess = next_guess_ then*/
    if (_prev_guess_13923 != _next_guess__13922)
    goto L9; // [144] 155

    /** 				next_guess_ += 1*/
    _next_guess__13922 = _next_guess__13922 + 1;
L9: 

    /** 		entry*/
L4: 

    /** 			rehash(the_map_p, next_guess_)*/
    Ref(_the_map_p_13917);
    _33rehash(_the_map_p_13917, _next_guess__13922);

    /** 			stats_ = statistics(the_map_p)*/
    Ref(_the_map_p_13917);
    _0 = _stats__13921;
    _stats__13921 = _33statistics(_the_map_p_13917);
    DeRef(_0);

    /** 		end while*/
    goto L5; // [174] 74
L7: 
L1: 

    /** end procedure*/
    DeRef(_the_map_p_13917);
    DeRef(_grow_p_13919);
    DeRef(_stats__13921);
    return;
    ;
}


int  __stdcall _33load_map(int _input_file_name_13957)
{
    int _file_handle_13958 = NOVALUE;
    int _line_in_13959 = NOVALUE;
    int _logical_line_13960 = NOVALUE;
    int _has_comment_13961 = NOVALUE;
    int _delim_pos_13962 = NOVALUE;
    int _data_value_13963 = NOVALUE;
    int _data_key_13964 = NOVALUE;
    int _conv_res_13965 = NOVALUE;
    int _new_map_13966 = NOVALUE;
    int _line_conts_13967 = NOVALUE;
    int _value_inlined_value_at_217_14012 = NOVALUE;
    int _value_inlined_value_at_297_14027 = NOVALUE;
    int _seek_1__tmp_at517_14065 = NOVALUE;
    int _seek_inlined_seek_at_517_14064 = NOVALUE;
    int _7998 = NOVALUE;
    int _7997 = NOVALUE;
    int _7996 = NOVALUE;
    int _7995 = NOVALUE;
    int _7990 = NOVALUE;
    int _7988 = NOVALUE;
    int _7987 = NOVALUE;
    int _7979 = NOVALUE;
    int _7978 = NOVALUE;
    int _7977 = NOVALUE;
    int _7976 = NOVALUE;
    int _7972 = NOVALUE;
    int _7971 = NOVALUE;
    int _7968 = NOVALUE;
    int _7967 = NOVALUE;
    int _7966 = NOVALUE;
    int _7963 = NOVALUE;
    int _7962 = NOVALUE;
    int _7960 = NOVALUE;
    int _7957 = NOVALUE;
    int _7956 = NOVALUE;
    int _7955 = NOVALUE;
    int _7952 = NOVALUE;
    int _7951 = NOVALUE;
    int _7949 = NOVALUE;
    int _7947 = NOVALUE;
    int _7946 = NOVALUE;
    int _7941 = NOVALUE;
    int _7939 = NOVALUE;
    int _7938 = NOVALUE;
    int _7935 = NOVALUE;
    int _7931 = NOVALUE;
    int _7929 = NOVALUE;
    int _7923 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence line_conts =   ",${"*/
    RefDS(_7922);
    DeRefi(_line_conts_13967);
    _line_conts_13967 = _7922;

    /** 	if sequence(input_file_name) then*/
    _7923 = IS_SEQUENCE(_input_file_name_13957);
    if (_7923 == 0)
    {
        _7923 = NOVALUE;
        goto L1; // [13] 26
    }
    else{
        _7923 = NOVALUE;
    }

    /** 		file_handle = open(input_file_name, "rb")*/
    _file_handle_13958 = EOpen(_input_file_name_13957, _1309, 0);
    goto L2; // [23] 34
L1: 

    /** 		file_handle = input_file_name*/
    Ref(_input_file_name_13957);
    _file_handle_13958 = _input_file_name_13957;
    if (!IS_ATOM_INT(_file_handle_13958)) {
        _1 = (long)(DBL_PTR(_file_handle_13958)->dbl);
        DeRefDS(_file_handle_13958);
        _file_handle_13958 = _1;
    }
L2: 

    /** 	if file_handle = -1 then*/
    if (_file_handle_13958 != -1)
    goto L3; // [38] 49

    /** 		return -1*/
    DeRef(_input_file_name_13957);
    DeRef(_line_in_13959);
    DeRef(_logical_line_13960);
    DeRef(_data_value_13963);
    DeRef(_data_key_13964);
    DeRef(_conv_res_13965);
    DeRef(_new_map_13966);
    DeRefi(_line_conts_13967);
    return -1;
L3: 

    /** 	new_map = new(threshold_size) -- Assume a small map initially.*/
    _0 = _new_map_13966;
    _new_map_13966 = _33new(_33threshold_size_12989);
    DeRef(_0);

    /** 	for i = 1 to 10 do*/
    {
        int _i_13977;
        _i_13977 = 1;
L4: 
        if (_i_13977 > 10){
            goto L5; // [59] 118
        }

        /** 		delim_pos = getc(file_handle)*/
        if (_file_handle_13958 != last_r_file_no) {
            last_r_file_ptr = which_file(_file_handle_13958, EF_READ);
            last_r_file_no = _file_handle_13958;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _delim_pos_13962 = getKBchar();
            }
            else
            _delim_pos_13962 = getc(last_r_file_ptr);
        }
        else
        _delim_pos_13962 = getc(last_r_file_ptr);

        /** 		if delim_pos = -1 then */
        if (_delim_pos_13962 != -1)
        goto L6; // [73] 82

        /** 			exit*/
        goto L5; // [79] 118
L6: 

        /** 		if not t_print(delim_pos) then */
        _7929 = _7t_print(_delim_pos_13962);
        if (IS_ATOM_INT(_7929)) {
            if (_7929 != 0){
                DeRef(_7929);
                _7929 = NOVALUE;
                goto L7; // [88] 106
            }
        }
        else {
            if (DBL_PTR(_7929)->dbl != 0.0){
                DeRef(_7929);
                _7929 = NOVALUE;
                goto L7; // [88] 106
            }
        }
        DeRef(_7929);
        _7929 = NOVALUE;

        /** 	    	if not t_space(delim_pos) then*/
        _7931 = _7t_space(_delim_pos_13962);
        if (IS_ATOM_INT(_7931)) {
            if (_7931 != 0){
                DeRef(_7931);
                _7931 = NOVALUE;
                goto L8; // [97] 105
            }
        }
        else {
            if (DBL_PTR(_7931)->dbl != 0.0){
                DeRef(_7931);
                _7931 = NOVALUE;
                goto L8; // [97] 105
            }
        }
        DeRef(_7931);
        _7931 = NOVALUE;

        /** 	    		exit*/
        goto L5; // [102] 118
L8: 
L7: 

        /** 	    delim_pos = -1*/
        _delim_pos_13962 = -1;

        /** 	end for*/
        _i_13977 = _i_13977 + 1;
        goto L4; // [113] 66
L5: 
        ;
    }

    /** 	if delim_pos = -1 then*/
    if (_delim_pos_13962 != -1)
    goto L9; // [122] 513

    /** 		close(file_handle)*/
    EClose(_file_handle_13958);

    /** 		file_handle = open(input_file_name, "r")*/
    _file_handle_13958 = EOpen(_input_file_name_13957, _1256, 0);

    /** 		while sequence(logical_line) with entry do*/
    goto LA; // [139] 357
LB: 
    _7935 = IS_SEQUENCE(_logical_line_13960);
    if (_7935 == 0)
    {
        _7935 = NOVALUE;
        goto LC; // [147] 652
    }
    else{
        _7935 = NOVALUE;
    }

    /** 			delim_pos = find('=', logical_line)*/
    _delim_pos_13962 = find_from(61, _logical_line_13960, 1);

    /** 			if delim_pos > 0 then*/
    if (_delim_pos_13962 <= 0)
    goto LD; // [159] 354

    /** 				data_key = text:trim(logical_line[1..delim_pos-1])*/
    _7938 = _delim_pos_13962 - 1;
    rhs_slice_target = (object_ptr)&_7939;
    RHS_Slice(_logical_line_13960, 1, _7938);
    RefDS(_4563);
    _0 = _data_key_13964;
    _data_key_13964 = _6trim(_7939, _4563, 0);
    DeRef(_0);
    _7939 = NOVALUE;

    /** 				if length(data_key) > 0 then*/
    if (IS_SEQUENCE(_data_key_13964)){
            _7941 = SEQ_PTR(_data_key_13964)->length;
    }
    else {
        _7941 = 1;
    }
    if (_7941 <= 0)
    goto LE; // [185] 353

    /** 					data_key = search:match_replace("\\-", data_key, "-")*/
    RefDS(_7943);
    Ref(_data_key_13964);
    RefDS(_7944);
    _0 = _data_key_13964;
    _data_key_13964 = _9match_replace(_7943, _data_key_13964, _7944, 0);
    DeRef(_0);

    /** 					if not t_alpha(data_key[1]) then*/
    _2 = (int)SEQ_PTR(_data_key_13964);
    _7946 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7946);
    _7947 = _7t_alpha(_7946);
    _7946 = NOVALUE;
    if (IS_ATOM_INT(_7947)) {
        if (_7947 != 0){
            DeRef(_7947);
            _7947 = NOVALUE;
            goto LF; // [208] 262
        }
    }
    else {
        if (DBL_PTR(_7947)->dbl != 0.0){
            DeRef(_7947);
            _7947 = NOVALUE;
            goto LF; // [208] 262
        }
    }
    DeRef(_7947);
    _7947 = NOVALUE;

    /** 						conv_res = stdget:value(data_key,,stdget:GET_LONG_ANSWER)*/
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3335)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3335)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3335);
        _17GET_LONG_ANSWER_3335 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_data_key_13964);
    _0 = _conv_res_13965;
    _conv_res_13965 = _17get_value(_data_key_13964, 1, _17GET_LONG_ANSWER_3335);
    DeRef(_0);

    /** 						if conv_res[1] = stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _7949 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _7949, 0)){
        _7949 = NOVALUE;
        goto L10; // [236] 261
    }
    _7949 = NOVALUE;

    /** 							if conv_res[3] = length(data_key) then*/
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _7951 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_data_key_13964)){
            _7952 = SEQ_PTR(_data_key_13964)->length;
    }
    else {
        _7952 = 1;
    }
    if (binary_op_a(NOTEQ, _7951, _7952)){
        _7951 = NOVALUE;
        _7952 = NOVALUE;
        goto L11; // [249] 260
    }
    _7951 = NOVALUE;
    _7952 = NOVALUE;

    /** 								data_key = conv_res[2]*/
    DeRef(_data_key_13964);
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _data_key_13964 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_key_13964);
L11: 
L10: 
LF: 

    /** 					data_value = text:trim(logical_line[delim_pos+1..$])*/
    _7955 = _delim_pos_13962 + 1;
    if (_7955 > MAXINT){
        _7955 = NewDouble((double)_7955);
    }
    if (IS_SEQUENCE(_logical_line_13960)){
            _7956 = SEQ_PTR(_logical_line_13960)->length;
    }
    else {
        _7956 = 1;
    }
    rhs_slice_target = (object_ptr)&_7957;
    RHS_Slice(_logical_line_13960, _7955, _7956);
    RefDS(_4563);
    _0 = _data_value_13963;
    _data_value_13963 = _6trim(_7957, _4563, 0);
    DeRef(_0);
    _7957 = NOVALUE;

    /** 					data_value = search:match_replace("\\-", data_value, "-")*/
    RefDS(_7943);
    Ref(_data_value_13963);
    RefDS(_7944);
    _0 = _data_value_13963;
    _data_value_13963 = _9match_replace(_7943, _data_value_13963, _7944, 0);
    DeRef(_0);

    /** 					conv_res = stdget:value(data_value,,stdget:GET_LONG_ANSWER)*/
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3335)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3335)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3335);
        _17GET_LONG_ANSWER_3335 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_data_value_13963);
    _0 = _conv_res_13965;
    _conv_res_13965 = _17get_value(_data_value_13963, 1, _17GET_LONG_ANSWER_3335);
    DeRef(_0);

    /** 					if conv_res[1] = stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _7960 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _7960, 0)){
        _7960 = NOVALUE;
        goto L12; // [316] 341
    }
    _7960 = NOVALUE;

    /** 						if conv_res[3] = length(data_value) then*/
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _7962 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_data_value_13963)){
            _7963 = SEQ_PTR(_data_value_13963)->length;
    }
    else {
        _7963 = 1;
    }
    if (binary_op_a(NOTEQ, _7962, _7963)){
        _7962 = NOVALUE;
        _7963 = NOVALUE;
        goto L13; // [329] 340
    }
    _7962 = NOVALUE;
    _7963 = NOVALUE;

    /** 							data_value = conv_res[2]*/
    DeRef(_data_value_13963);
    _2 = (int)SEQ_PTR(_conv_res_13965);
    _data_value_13963 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_data_value_13963);
L13: 
L12: 

    /** 					put(new_map, data_key, data_value)*/
    Ref(_new_map_13966);
    Ref(_data_key_13964);
    Ref(_data_value_13963);
    _33put(_new_map_13966, _data_key_13964, _data_value_13963, 1, _33threshold_size_12989);
LE: 
LD: 

    /** 		entry*/
LA: 

    /** 			logical_line = -1*/
    DeRef(_logical_line_13960);
    _logical_line_13960 = -1;

    /** 			while sequence(line_in) with entry do*/
    goto L14; // [364] 495
L15: 
    _7966 = IS_SEQUENCE(_line_in_13959);
    if (_7966 == 0)
    {
        _7966 = NOVALUE;
        goto LB; // [372] 142
    }
    else{
        _7966 = NOVALUE;
    }

    /** 				if atom(logical_line) then*/
    _7967 = IS_ATOM(_logical_line_13960);
    if (_7967 == 0)
    {
        _7967 = NOVALUE;
        goto L16; // [380] 389
    }
    else{
        _7967 = NOVALUE;
    }

    /** 					logical_line = ""*/
    RefDS(_5);
    DeRef(_logical_line_13960);
    _logical_line_13960 = _5;
L16: 

    /** 				has_comment = search:rmatch("--", line_in)*/
    if (IS_SEQUENCE(_line_in_13959)){
            _7968 = SEQ_PTR(_line_in_13959)->length;
    }
    else {
        _7968 = 1;
    }
    RefDS(_6725);
    Ref(_line_in_13959);
    _has_comment_13961 = _9rmatch(_6725, _line_in_13959, _7968);
    _7968 = NOVALUE;
    if (!IS_ATOM_INT(_has_comment_13961)) {
        _1 = (long)(DBL_PTR(_has_comment_13961)->dbl);
        DeRefDS(_has_comment_13961);
        _has_comment_13961 = _1;
    }

    /** 				if has_comment != 0 then*/
    if (_has_comment_13961 == 0)
    goto L17; // [404] 428

    /** 					line_in = text:trim(line_in[1..has_comment-1])*/
    _7971 = _has_comment_13961 - 1;
    rhs_slice_target = (object_ptr)&_7972;
    RHS_Slice(_line_in_13959, 1, _7971);
    RefDS(_4563);
    _0 = _line_in_13959;
    _line_in_13959 = _6trim(_7972, _4563, 0);
    DeRef(_0);
    _7972 = NOVALUE;
    goto L18; // [425] 437
L17: 

    /** 					line_in = text:trim(line_in)*/
    Ref(_line_in_13959);
    RefDS(_4563);
    _0 = _line_in_13959;
    _line_in_13959 = _6trim(_line_in_13959, _4563, 0);
    DeRef(_0);
L18: 

    /** 				logical_line &= line_in*/
    if (IS_SEQUENCE(_logical_line_13960) && IS_ATOM(_line_in_13959)) {
        Ref(_line_in_13959);
        Append(&_logical_line_13960, _logical_line_13960, _line_in_13959);
    }
    else if (IS_ATOM(_logical_line_13960) && IS_SEQUENCE(_line_in_13959)) {
        Ref(_logical_line_13960);
        Prepend(&_logical_line_13960, _line_in_13959, _logical_line_13960);
    }
    else {
        Concat((object_ptr)&_logical_line_13960, _logical_line_13960, _line_in_13959);
    }

    /** 				if length(line_in) then*/
    if (IS_SEQUENCE(_line_in_13959)){
            _7976 = SEQ_PTR(_line_in_13959)->length;
    }
    else {
        _7976 = 1;
    }
    if (_7976 == 0)
    {
        _7976 = NOVALUE;
        goto L19; // [448] 492
    }
    else{
        _7976 = NOVALUE;
    }

    /** 					if not find(line_in[$], line_conts) then*/
    if (IS_SEQUENCE(_line_in_13959)){
            _7977 = SEQ_PTR(_line_in_13959)->length;
    }
    else {
        _7977 = 1;
    }
    _2 = (int)SEQ_PTR(_line_in_13959);
    _7978 = (int)*(((s1_ptr)_2)->base + _7977);
    _7979 = find_from(_7978, _line_conts_13967, 1);
    _7978 = NOVALUE;
    if (_7979 != 0)
    goto L1A; // [465] 491
    _7979 = NOVALUE;

    /** 						logical_line = search:match_replace(`",$"`, logical_line, "")*/
    RefDS(_7981);
    RefDS(_logical_line_13960);
    RefDS(_5);
    _0 = _logical_line_13960;
    _logical_line_13960 = _9match_replace(_7981, _logical_line_13960, _5, 0);
    DeRefDS(_0);

    /** 						logical_line = search:match_replace(`,$`, logical_line, "")*/
    RefDS(_7983);
    Ref(_logical_line_13960);
    RefDS(_5);
    _0 = _logical_line_13960;
    _logical_line_13960 = _9match_replace(_7983, _logical_line_13960, _5, 0);
    DeRef(_0);

    /** 						exit*/
    goto LB; // [488] 142
L1A: 
L19: 

    /** 			entry*/
L14: 

    /** 				line_in = gets(file_handle)*/
    DeRef(_line_in_13959);
    _line_in_13959 = EGets(_file_handle_13958);

    /** 			end while*/
    goto L15; // [502] 367

    /** 		end while*/
    goto LB; // [507] 142
    goto LC; // [510] 652
L9: 

    /** 		io:seek(file_handle, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at517_14065);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_handle_13958;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at517_14065 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_517_14064 = machine(19, _seek_1__tmp_at517_14065);
    DeRefi(_seek_1__tmp_at517_14065);
    _seek_1__tmp_at517_14065 = NOVALUE;

    /** 		line_in  = serialize:deserialize(file_handle)*/
    _0 = _line_in_13959;
    _line_in_13959 = _27deserialize(_file_handle_13958, 1);
    DeRef(_0);

    /** 		if atom(line_in) then*/
    _7987 = IS_ATOM(_line_in_13959);
    if (_7987 == 0)
    {
        _7987 = NOVALUE;
        goto L1B; // [540] 550
    }
    else{
        _7987 = NOVALUE;
    }

    /** 			return -2*/
    DeRef(_input_file_name_13957);
    DeRef(_line_in_13959);
    DeRef(_logical_line_13960);
    DeRef(_data_value_13963);
    DeRef(_data_key_13964);
    DeRef(_conv_res_13965);
    DeRef(_new_map_13966);
    DeRefi(_line_conts_13967);
    DeRef(_7938);
    _7938 = NOVALUE;
    DeRef(_7955);
    _7955 = NOVALUE;
    DeRef(_7971);
    _7971 = NOVALUE;
    return -2;
L1B: 

    /** 		if length(line_in) > 1 then*/
    if (IS_SEQUENCE(_line_in_13959)){
            _7988 = SEQ_PTR(_line_in_13959)->length;
    }
    else {
        _7988 = 1;
    }
    if (_7988 <= 1)
    goto L1C; // [555] 644

    /** 			switch line_in[1] do*/
    _2 = (int)SEQ_PTR(_line_in_13959);
    _7990 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_7990) ){
        goto L1D; // [565] 632
    }
    if(!IS_ATOM_INT(_7990)){
        if( (DBL_PTR(_7990)->dbl != (double) ((int) DBL_PTR(_7990)->dbl) ) ){
            goto L1D; // [565] 632
        }
        _0 = (int) DBL_PTR(_7990)->dbl;
    }
    else {
        _0 = _7990;
    };
    _7990 = NOVALUE;
    switch ( _0 ){ 

        /** 				case 1, 2 then*/
        case 1:
        case 2:

        /** 					data_key   = serialize:deserialize(file_handle)*/
        _0 = _data_key_13964;
        _data_key_13964 = _27deserialize(_file_handle_13958, 1);
        DeRef(_0);

        /** 					data_value =  serialize:deserialize(file_handle)*/
        _0 = _data_value_13963;
        _data_value_13963 = _27deserialize(_file_handle_13958, 1);
        DeRef(_0);

        /** 					for i = 1 to length(data_key) do*/
        if (IS_SEQUENCE(_data_key_13964)){
                _7995 = SEQ_PTR(_data_key_13964)->length;
        }
        else {
            _7995 = 1;
        }
        {
            int _i_14079;
            _i_14079 = 1;
L1E: 
            if (_i_14079 > _7995){
                goto L1F; // [595] 628
            }

            /** 						put(new_map, data_key[i], data_value[i])*/
            _2 = (int)SEQ_PTR(_data_key_13964);
            _7996 = (int)*(((s1_ptr)_2)->base + _i_14079);
            _2 = (int)SEQ_PTR(_data_value_13963);
            _7997 = (int)*(((s1_ptr)_2)->base + _i_14079);
            Ref(_new_map_13966);
            Ref(_7996);
            Ref(_7997);
            _33put(_new_map_13966, _7996, _7997, 1, _33threshold_size_12989);
            _7996 = NOVALUE;
            _7997 = NOVALUE;

            /** 					end for*/
            _i_14079 = _i_14079 + 1;
            goto L1E; // [623] 602
L1F: 
            ;
        }
        goto L20; // [628] 651

        /** 				case else*/
        default:
L1D: 

        /** 					return -2*/
        DeRef(_input_file_name_13957);
        DeRef(_line_in_13959);
        DeRef(_logical_line_13960);
        DeRef(_data_value_13963);
        DeRef(_data_key_13964);
        DeRef(_conv_res_13965);
        DeRef(_new_map_13966);
        DeRefi(_line_conts_13967);
        DeRef(_7938);
        _7938 = NOVALUE;
        DeRef(_7955);
        _7955 = NOVALUE;
        DeRef(_7971);
        _7971 = NOVALUE;
        return -2;
    ;}    goto L20; // [641] 651
L1C: 

    /** 			return -2*/
    DeRef(_input_file_name_13957);
    DeRef(_line_in_13959);
    DeRef(_logical_line_13960);
    DeRef(_data_value_13963);
    DeRef(_data_key_13964);
    DeRef(_conv_res_13965);
    DeRef(_new_map_13966);
    DeRefi(_line_conts_13967);
    DeRef(_7938);
    _7938 = NOVALUE;
    DeRef(_7955);
    _7955 = NOVALUE;
    DeRef(_7971);
    _7971 = NOVALUE;
    return -2;
L20: 
LC: 

    /** 	if sequence(input_file_name) then*/
    _7998 = IS_SEQUENCE(_input_file_name_13957);
    if (_7998 == 0)
    {
        _7998 = NOVALUE;
        goto L21; // [657] 665
    }
    else{
        _7998 = NOVALUE;
    }

    /** 		close(file_handle)*/
    EClose(_file_handle_13958);
L21: 

    /** 	optimize(new_map)*/
    Ref(_new_map_13966);
    RefDS(_7897);
    _33optimize(_new_map_13966, _33threshold_size_12989, _7897);

    /** 	return new_map*/
    DeRef(_input_file_name_13957);
    DeRef(_line_in_13959);
    DeRef(_logical_line_13960);
    DeRef(_data_value_13963);
    DeRef(_data_key_13964);
    DeRef(_conv_res_13965);
    DeRefi(_line_conts_13967);
    DeRef(_7938);
    _7938 = NOVALUE;
    DeRef(_7955);
    _7955 = NOVALUE;
    DeRef(_7971);
    _7971 = NOVALUE;
    return _new_map_13966;
    ;
}


int  __stdcall _33save_map(int _the_map__14091, int _file_name_p_14092, int _type__14093)
{
    int _file_handle__14094 = NOVALUE;
    int _keys__14095 = NOVALUE;
    int _values__14096 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_174_14129 = NOVALUE;
    int _options_inlined_pretty_sprint_at_171_14128 = NOVALUE;
    int _x_inlined_pretty_sprint_at_168_14127 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_243_14137 = NOVALUE;
    int _options_inlined_pretty_sprint_at_240_14136 = NOVALUE;
    int _x_inlined_pretty_sprint_at_237_14135 = NOVALUE;
    int _8029 = NOVALUE;
    int _8028 = NOVALUE;
    int _8027 = NOVALUE;
    int _8026 = NOVALUE;
    int _8025 = NOVALUE;
    int _8023 = NOVALUE;
    int _8022 = NOVALUE;
    int _8021 = NOVALUE;
    int _8020 = NOVALUE;
    int _8019 = NOVALUE;
    int _8018 = NOVALUE;
    int _8017 = NOVALUE;
    int _8016 = NOVALUE;
    int _8015 = NOVALUE;
    int _8014 = NOVALUE;
    int _8013 = NOVALUE;
    int _8012 = NOVALUE;
    int _8011 = NOVALUE;
    int _8010 = NOVALUE;
    int _8009 = NOVALUE;
    int _8007 = NOVALUE;
    int _7999 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type__14093)) {
        _1 = (long)(DBL_PTR(_type__14093)->dbl);
        DeRefDS(_type__14093);
        _type__14093 = _1;
    }

    /** 	integer file_handle_ = -2*/
    _file_handle__14094 = -2;

    /** 	if sequence(file_name_p) then*/
    _7999 = IS_SEQUENCE(_file_name_p_14092);
    if (_7999 == 0)
    {
        _7999 = NOVALUE;
        goto L1; // [13] 43
    }
    else{
        _7999 = NOVALUE;
    }

    /** 		if type_ = SM_TEXT then*/
    if (_type__14093 != 1)
    goto L2; // [18] 32

    /** 			file_handle_ = open(file_name_p, "w")*/
    _file_handle__14094 = EOpen(_file_name_p_14092, _1297, 0);
    goto L3; // [29] 51
L2: 

    /** 			file_handle_ = open(file_name_p, "wb")*/
    _file_handle__14094 = EOpen(_file_name_p_14092, _1354, 0);
    goto L3; // [40] 51
L1: 

    /** 		file_handle_ = file_name_p*/
    Ref(_file_name_p_14092);
    _file_handle__14094 = _file_name_p_14092;
    if (!IS_ATOM_INT(_file_handle__14094)) {
        _1 = (long)(DBL_PTR(_file_handle__14094)->dbl);
        DeRefDS(_file_handle__14094);
        _file_handle__14094 = _1;
    }
L3: 

    /** 	if file_handle_ < 0 then*/
    if (_file_handle__14094 >= 0)
    goto L4; // [53] 64

    /** 		return -1*/
    DeRef(_the_map__14091);
    DeRef(_file_name_p_14092);
    DeRef(_keys__14095);
    DeRef(_values__14096);
    return -1;
L4: 

    /** 	keys_ = keys(the_map_)*/
    Ref(_the_map__14091);
    _0 = _keys__14095;
    _keys__14095 = _33keys(_the_map__14091, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    Ref(_the_map__14091);
    _0 = _values__14096;
    _values__14096 = _33values(_the_map__14091, 0, 0);
    DeRef(_0);

    /** 	if type_ = SM_RAW then*/
    if (_type__14093 != 2)
    goto L5; // [85] 137

    /** 		puts(file_handle_, serialize:serialize({*/
    _8007 = _12now_gmt();
    RefDS(_8008);
    _8009 = _12format(_8007, _8008);
    _8007 = NOVALUE;
    _8010 = _3version_string(0);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = _8009;
    *((int *)(_2+12)) = _8010;
    _8011 = MAKE_SEQ(_1);
    _8010 = NOVALUE;
    _8009 = NOVALUE;
    _8012 = _27serialize(_8011);
    _8011 = NOVALUE;
    EPuts(_file_handle__14094, _8012); // DJP 
    DeRef(_8012);
    _8012 = NOVALUE;

    /** 		puts(file_handle_, serialize:serialize(keys_))*/
    RefDS(_keys__14095);
    _8013 = _27serialize(_keys__14095);
    EPuts(_file_handle__14094, _8013); // DJP 
    DeRef(_8013);
    _8013 = NOVALUE;

    /** 		puts(file_handle_, serialize:serialize(values_))*/
    RefDS(_values__14096);
    _8014 = _27serialize(_values__14096);
    EPuts(_file_handle__14094, _8014); // DJP 
    DeRef(_8014);
    _8014 = NOVALUE;
    goto L6; // [134] 313
L5: 

    /** 		for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__14095)){
            _8015 = SEQ_PTR(_keys__14095)->length;
    }
    else {
        _8015 = 1;
    }
    {
        int _i_14122;
        _i_14122 = 1;
L7: 
        if (_i_14122 > _8015){
            goto L8; // [142] 312
        }

        /** 			keys_[i] = pretty:pretty_sprint(keys_[i], {2,0,1,0,"%d","%.15g",32,127,1,0})*/
        _2 = (int)SEQ_PTR(_keys__14095);
        _8016 = (int)*(((s1_ptr)_2)->base + _i_14122);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 2;
        *((int *)(_2+8)) = 0;
        *((int *)(_2+12)) = 1;
        *((int *)(_2+16)) = 0;
        RefDS(_919);
        *((int *)(_2+20)) = _919;
        RefDS(_6016);
        *((int *)(_2+24)) = _6016;
        *((int *)(_2+28)) = 32;
        *((int *)(_2+32)) = 127;
        *((int *)(_2+36)) = 1;
        *((int *)(_2+40)) = 0;
        _8017 = MAKE_SEQ(_1);
        Ref(_8016);
        DeRef(_x_inlined_pretty_sprint_at_168_14127);
        _x_inlined_pretty_sprint_at_168_14127 = _8016;
        _8016 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_171_14128);
        _options_inlined_pretty_sprint_at_171_14128 = _8017;
        _8017 = NOVALUE;

        /** 	pretty_printing = 0*/
        _26pretty_printing_8698 = 0;

        /** 	pretty( x, options )*/
        Ref(_x_inlined_pretty_sprint_at_168_14127);
        RefDS(_options_inlined_pretty_sprint_at_171_14128);
        _26pretty(_x_inlined_pretty_sprint_at_168_14127, _options_inlined_pretty_sprint_at_171_14128);

        /** 	return pretty_line*/
        RefDS(_26pretty_line_8701);
        DeRef(_pretty_sprint_inlined_pretty_sprint_at_174_14129);
        _pretty_sprint_inlined_pretty_sprint_at_174_14129 = _26pretty_line_8701;
        DeRef(_x_inlined_pretty_sprint_at_168_14127);
        _x_inlined_pretty_sprint_at_168_14127 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_171_14128);
        _options_inlined_pretty_sprint_at_171_14128 = NOVALUE;
        RefDS(_pretty_sprint_inlined_pretty_sprint_at_174_14129);
        _2 = (int)SEQ_PTR(_keys__14095);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys__14095 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14122);
        _1 = *(int *)_2;
        *(int *)_2 = _pretty_sprint_inlined_pretty_sprint_at_174_14129;
        DeRef(_1);

        /** 			keys_[i] = search:match_replace("-", keys_[i], "\\-")*/
        _2 = (int)SEQ_PTR(_keys__14095);
        _8018 = (int)*(((s1_ptr)_2)->base + _i_14122);
        RefDS(_7944);
        Ref(_8018);
        RefDS(_7943);
        _8019 = _9match_replace(_7944, _8018, _7943, 0);
        _8018 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys__14095);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys__14095 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14122);
        _1 = *(int *)_2;
        *(int *)_2 = _8019;
        if( _1 != _8019 ){
            DeRef(_1);
        }
        _8019 = NOVALUE;

        /** 			values_[i] = pretty:pretty_sprint(values_[i], {2,0,1,0,"%d","%.15g",32,127,1,0})*/
        _2 = (int)SEQ_PTR(_values__14096);
        _8020 = (int)*(((s1_ptr)_2)->base + _i_14122);
        _1 = NewS1(10);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 2;
        *((int *)(_2+8)) = 0;
        *((int *)(_2+12)) = 1;
        *((int *)(_2+16)) = 0;
        RefDS(_919);
        *((int *)(_2+20)) = _919;
        RefDS(_6016);
        *((int *)(_2+24)) = _6016;
        *((int *)(_2+28)) = 32;
        *((int *)(_2+32)) = 127;
        *((int *)(_2+36)) = 1;
        *((int *)(_2+40)) = 0;
        _8021 = MAKE_SEQ(_1);
        Ref(_8020);
        DeRef(_x_inlined_pretty_sprint_at_237_14135);
        _x_inlined_pretty_sprint_at_237_14135 = _8020;
        _8020 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_240_14136);
        _options_inlined_pretty_sprint_at_240_14136 = _8021;
        _8021 = NOVALUE;

        /** 	pretty_printing = 0*/
        _26pretty_printing_8698 = 0;

        /** 	pretty( x, options )*/
        Ref(_x_inlined_pretty_sprint_at_237_14135);
        RefDS(_options_inlined_pretty_sprint_at_240_14136);
        _26pretty(_x_inlined_pretty_sprint_at_237_14135, _options_inlined_pretty_sprint_at_240_14136);

        /** 	return pretty_line*/
        RefDS(_26pretty_line_8701);
        DeRef(_pretty_sprint_inlined_pretty_sprint_at_243_14137);
        _pretty_sprint_inlined_pretty_sprint_at_243_14137 = _26pretty_line_8701;
        DeRef(_x_inlined_pretty_sprint_at_237_14135);
        _x_inlined_pretty_sprint_at_237_14135 = NOVALUE;
        DeRef(_options_inlined_pretty_sprint_at_240_14136);
        _options_inlined_pretty_sprint_at_240_14136 = NOVALUE;
        RefDS(_pretty_sprint_inlined_pretty_sprint_at_243_14137);
        _2 = (int)SEQ_PTR(_values__14096);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values__14096 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14122);
        _1 = *(int *)_2;
        *(int *)_2 = _pretty_sprint_inlined_pretty_sprint_at_243_14137;
        DeRef(_1);

        /** 			values_[i] = search:match_replace("-", values_[i], "\\-")*/
        _2 = (int)SEQ_PTR(_values__14096);
        _8022 = (int)*(((s1_ptr)_2)->base + _i_14122);
        RefDS(_7944);
        Ref(_8022);
        RefDS(_7943);
        _8023 = _9match_replace(_7944, _8022, _7943, 0);
        _8022 = NOVALUE;
        _2 = (int)SEQ_PTR(_values__14096);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values__14096 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14122);
        _1 = *(int *)_2;
        *(int *)_2 = _8023;
        if( _1 != _8023 ){
            DeRef(_1);
        }
        _8023 = NOVALUE;

        /** 			printf(file_handle_, "%s = %s\n", {keys_[i], values_[i]})*/
        _2 = (int)SEQ_PTR(_keys__14095);
        _8025 = (int)*(((s1_ptr)_2)->base + _i_14122);
        _2 = (int)SEQ_PTR(_values__14096);
        _8026 = (int)*(((s1_ptr)_2)->base + _i_14122);
        Ref(_8026);
        Ref(_8025);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _8025;
        ((int *)_2)[2] = _8026;
        _8027 = MAKE_SEQ(_1);
        _8026 = NOVALUE;
        _8025 = NOVALUE;
        EPrintf(_file_handle__14094, _8024, _8027);
        DeRefDS(_8027);
        _8027 = NOVALUE;

        /** 		end for*/
        _i_14122 = _i_14122 + 1;
        goto L7; // [307] 149
L8: 
        ;
    }
L6: 

    /** 	if sequence(file_name_p) then*/
    _8028 = IS_SEQUENCE(_file_name_p_14092);
    if (_8028 == 0)
    {
        _8028 = NOVALUE;
        goto L9; // [318] 326
    }
    else{
        _8028 = NOVALUE;
    }

    /** 		close(file_handle_)*/
    EClose(_file_handle__14094);
L9: 

    /** 	return length(keys_)*/
    if (IS_SEQUENCE(_keys__14095)){
            _8029 = SEQ_PTR(_keys__14095)->length;
    }
    else {
        _8029 = 1;
    }
    DeRef(_the_map__14091);
    DeRef(_file_name_p_14092);
    DeRefDS(_keys__14095);
    DeRef(_values__14096);
    return _8029;
    ;
}


int  __stdcall _33copy(int _source_map_14149, int _dest_map_14150, int _put_operation_14151)
{
    int _keys_set_14154 = NOVALUE;
    int _value_set_14155 = NOVALUE;
    int _source_data_14156 = NOVALUE;
    int _temp_map_14188 = NOVALUE;
    int _8053 = NOVALUE;
    int _8051 = NOVALUE;
    int _8050 = NOVALUE;
    int _8049 = NOVALUE;
    int _8048 = NOVALUE;
    int _8046 = NOVALUE;
    int _8045 = NOVALUE;
    int _8044 = NOVALUE;
    int _8043 = NOVALUE;
    int _8042 = NOVALUE;
    int _8041 = NOVALUE;
    int _8040 = NOVALUE;
    int _8038 = NOVALUE;
    int _8036 = NOVALUE;
    int _8035 = NOVALUE;
    int _8034 = NOVALUE;
    int _8032 = NOVALUE;
    int _8030 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_put_operation_14151)) {
        _1 = (long)(DBL_PTR(_put_operation_14151)->dbl);
        DeRefDS(_put_operation_14151);
        _put_operation_14151 = _1;
    }

    /** 	if map(dest_map) then*/
    Ref(_dest_map_14150);
    _8030 = _33map(_dest_map_14150);
    if (_8030 == 0) {
        DeRef(_8030);
        _8030 = NOVALUE;
        goto L1; // [9] 203
    }
    else {
        if (!IS_ATOM_INT(_8030) && DBL_PTR(_8030)->dbl == 0.0){
            DeRef(_8030);
            _8030 = NOVALUE;
            goto L1; // [9] 203
        }
        DeRef(_8030);
        _8030 = NOVALUE;
    }
    DeRef(_8030);
    _8030 = NOVALUE;

    /** 		sequence keys_set*/

    /** 		sequence value_set		*/

    /** 		sequence source_data*/

    /** 		source_data = eumem:ram_space[source_map]	*/
    DeRef(_source_data_14156);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_source_map_14149)){
        _source_data_14156 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_source_map_14149)->dbl));
    }
    else{
        _source_data_14156 = (int)*(((s1_ptr)_2)->base + _source_map_14149);
    }
    Ref(_source_data_14156);

    /** 		if source_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_source_data_14156);
    _8032 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _8032, 76)){
        _8032 = NOVALUE;
        goto L2; // [34] 126
    }
    _8032 = NOVALUE;

    /** 			for index = 1 to length(source_data[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_source_data_14156);
    _8034 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_8034)){
            _8035 = SEQ_PTR(_8034)->length;
    }
    else {
        _8035 = 1;
    }
    _8034 = NOVALUE;
    {
        int _index_14162;
        _index_14162 = 1;
L3: 
        if (_index_14162 > _8035){
            goto L4; // [47] 123
        }

        /** 				keys_set = source_data[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_source_data_14156);
        _8036 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_keys_set_14154);
        _2 = (int)SEQ_PTR(_8036);
        _keys_set_14154 = (int)*(((s1_ptr)_2)->base + _index_14162);
        Ref(_keys_set_14154);
        _8036 = NOVALUE;

        /** 				value_set = source_data[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_source_data_14156);
        _8038 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_set_14155);
        _2 = (int)SEQ_PTR(_8038);
        _value_set_14155 = (int)*(((s1_ptr)_2)->base + _index_14162);
        Ref(_value_set_14155);
        _8038 = NOVALUE;

        /** 				for j = 1 to length(keys_set) do*/
        if (IS_SEQUENCE(_keys_set_14154)){
                _8040 = SEQ_PTR(_keys_set_14154)->length;
        }
        else {
            _8040 = 1;
        }
        {
            int _j_14170;
            _j_14170 = 1;
L5: 
            if (_j_14170 > _8040){
                goto L6; // [83] 116
            }

            /** 					put(dest_map, keys_set[j], value_set[j], put_operation)*/
            _2 = (int)SEQ_PTR(_keys_set_14154);
            _8041 = (int)*(((s1_ptr)_2)->base + _j_14170);
            _2 = (int)SEQ_PTR(_value_set_14155);
            _8042 = (int)*(((s1_ptr)_2)->base + _j_14170);
            Ref(_dest_map_14150);
            Ref(_8041);
            Ref(_8042);
            _33put(_dest_map_14150, _8041, _8042, _put_operation_14151, _33threshold_size_12989);
            _8041 = NOVALUE;
            _8042 = NOVALUE;

            /** 				end for*/
            _j_14170 = _j_14170 + 1;
            goto L5; // [111] 90
L6: 
            ;
        }

        /** 			end for*/
        _index_14162 = _index_14162 + 1;
        goto L3; // [118] 54
L4: 
        ;
    }
    goto L7; // [123] 192
L2: 

    /** 			for index = 1 to length(source_data[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_source_data_14156);
    _8043 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_8043)){
            _8044 = SEQ_PTR(_8043)->length;
    }
    else {
        _8044 = 1;
    }
    _8043 = NOVALUE;
    {
        int _index_14176;
        _index_14176 = 1;
L8: 
        if (_index_14176 > _8044){
            goto L9; // [135] 191
        }

        /** 				if source_data[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_source_data_14156);
        _8045 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_8045);
        _8046 = (int)*(((s1_ptr)_2)->base + _index_14176);
        _8045 = NOVALUE;
        if (binary_op_a(EQUALS, _8046, 0)){
            _8046 = NOVALUE;
            goto LA; // [152] 184
        }
        _8046 = NOVALUE;

        /** 					put(dest_map, source_data[KEY_LIST][index], */
        _2 = (int)SEQ_PTR(_source_data_14156);
        _8048 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_8048);
        _8049 = (int)*(((s1_ptr)_2)->base + _index_14176);
        _8048 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_data_14156);
        _8050 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_8050);
        _8051 = (int)*(((s1_ptr)_2)->base + _index_14176);
        _8050 = NOVALUE;
        Ref(_dest_map_14150);
        Ref(_8049);
        Ref(_8051);
        _33put(_dest_map_14150, _8049, _8051, _put_operation_14151, _33threshold_size_12989);
        _8049 = NOVALUE;
        _8051 = NOVALUE;
LA: 

        /** 			end for*/
        _index_14176 = _index_14176 + 1;
        goto L8; // [186] 142
L9: 
        ;
    }
L7: 

    /** 		return dest_map*/
    DeRef(_keys_set_14154);
    DeRef(_value_set_14155);
    DeRef(_source_data_14156);
    DeRef(_source_map_14149);
    _8034 = NOVALUE;
    _8043 = NOVALUE;
    return _dest_map_14150;
    goto LB; // [200] 233
L1: 

    /** 		atom temp_map = eumem:malloc()*/
    _0 = _temp_map_14188;
    _temp_map_14188 = _28malloc(1, 1);
    DeRef(_0);

    /** 	 	eumem:ram_space[temp_map] = eumem:ram_space[source_map]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_source_map_14149)){
        _8053 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_source_map_14149)->dbl));
    }
    else{
        _8053 = (int)*(((s1_ptr)_2)->base + _source_map_14149);
    }
    Ref(_8053);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map_14188))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map_14188)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map_14188);
    _1 = *(int *)_2;
    *(int *)_2 = _8053;
    if( _1 != _8053 ){
        DeRef(_1);
    }
    _8053 = NOVALUE;

    /** 		return temp_map*/
    DeRef(_source_map_14149);
    DeRef(_dest_map_14150);
    _8034 = NOVALUE;
    _8043 = NOVALUE;
    return _temp_map_14188;
    DeRef(_temp_map_14188);
    _temp_map_14188 = NOVALUE;
LB: 
    ;
}


int  __stdcall _33new_from_kvpairs(int _kv_pairs_14193)
{
    int _new_map_14194 = NOVALUE;
    int _8065 = NOVALUE;
    int _8064 = NOVALUE;
    int _8063 = NOVALUE;
    int _8062 = NOVALUE;
    int _8060 = NOVALUE;
    int _8059 = NOVALUE;
    int _8058 = NOVALUE;
    int _8056 = NOVALUE;
    int _8055 = NOVALUE;
    int _8054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_map = new( floor(7 * length(kv_pairs) / 2) )*/
    if (IS_SEQUENCE(_kv_pairs_14193)){
            _8054 = SEQ_PTR(_kv_pairs_14193)->length;
    }
    else {
        _8054 = 1;
    }
    if (_8054 <= INT15)
    _8055 = 7 * _8054;
    else
    _8055 = NewDouble(7 * (double)_8054);
    _8054 = NOVALUE;
    if (IS_ATOM_INT(_8055)) {
        _8056 = _8055 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _8055, 2);
        _8056 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_8055);
    _8055 = NOVALUE;
    _0 = _new_map_14194;
    _new_map_14194 = _33new(_8056);
    DeRef(_0);
    _8056 = NOVALUE;

    /** 	for i = 1 to length(kv_pairs) do*/
    if (IS_SEQUENCE(_kv_pairs_14193)){
            _8058 = SEQ_PTR(_kv_pairs_14193)->length;
    }
    else {
        _8058 = 1;
    }
    {
        int _i_14200;
        _i_14200 = 1;
L1: 
        if (_i_14200 > _8058){
            goto L2; // [25] 80
        }

        /** 		if length(kv_pairs[i]) = 2 then*/
        _2 = (int)SEQ_PTR(_kv_pairs_14193);
        _8059 = (int)*(((s1_ptr)_2)->base + _i_14200);
        if (IS_SEQUENCE(_8059)){
                _8060 = SEQ_PTR(_8059)->length;
        }
        else {
            _8060 = 1;
        }
        _8059 = NOVALUE;
        if (_8060 != 2)
        goto L3; // [41] 73

        /** 			put(new_map, kv_pairs[i][1], kv_pairs[i][2])*/
        _2 = (int)SEQ_PTR(_kv_pairs_14193);
        _8062 = (int)*(((s1_ptr)_2)->base + _i_14200);
        _2 = (int)SEQ_PTR(_8062);
        _8063 = (int)*(((s1_ptr)_2)->base + 1);
        _8062 = NOVALUE;
        _2 = (int)SEQ_PTR(_kv_pairs_14193);
        _8064 = (int)*(((s1_ptr)_2)->base + _i_14200);
        _2 = (int)SEQ_PTR(_8064);
        _8065 = (int)*(((s1_ptr)_2)->base + 2);
        _8064 = NOVALUE;
        Ref(_new_map_14194);
        Ref(_8063);
        Ref(_8065);
        _33put(_new_map_14194, _8063, _8065, 1, _33threshold_size_12989);
        _8063 = NOVALUE;
        _8065 = NOVALUE;
L3: 

        /** 	end for*/
        _i_14200 = _i_14200 + 1;
        goto L1; // [75] 32
L2: 
        ;
    }

    /** 	return new_map	*/
    DeRefDS(_kv_pairs_14193);
    _8059 = NOVALUE;
    return _new_map_14194;
    ;
}


int  __stdcall _33new_from_string(int _kv_string_14212)
{
    int _8067 = NOVALUE;
    int _8066 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return new_from_kvpairs( text:keyvalues (kv_string) )*/
    RefDS(_kv_string_14212);
    RefDS(_5372);
    RefDS(_5373);
    RefDS(_5374);
    RefDS(_307);
    _8066 = _6keyvalues(_kv_string_14212, _5372, _5373, _5374, _307, 1);
    _8067 = _33new_from_kvpairs(_8066);
    _8066 = NOVALUE;
    DeRefDS(_kv_string_14212);
    return _8067;
    ;
}


int  __stdcall _33for_each(int _source_map_14217, int _user_rid_14218, int _user_data_14219, int _in_sorted_order_14220, int _signal_boundary_14221)
{
    int _lKV_14222 = NOVALUE;
    int _lRes_14223 = NOVALUE;
    int _progress_code_14224 = NOVALUE;
    int _8086 = NOVALUE;
    int _8084 = NOVALUE;
    int _8083 = NOVALUE;
    int _8082 = NOVALUE;
    int _8081 = NOVALUE;
    int _8080 = NOVALUE;
    int _8078 = NOVALUE;
    int _8077 = NOVALUE;
    int _8076 = NOVALUE;
    int _8075 = NOVALUE;
    int _8074 = NOVALUE;
    int _8073 = NOVALUE;
    int _8072 = NOVALUE;
    int _8071 = NOVALUE;
    int _8070 = NOVALUE;
    int _8069 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_user_rid_14218)) {
        _1 = (long)(DBL_PTR(_user_rid_14218)->dbl);
        DeRefDS(_user_rid_14218);
        _user_rid_14218 = _1;
    }
    if (!IS_ATOM_INT(_in_sorted_order_14220)) {
        _1 = (long)(DBL_PTR(_in_sorted_order_14220)->dbl);
        DeRefDS(_in_sorted_order_14220);
        _in_sorted_order_14220 = _1;
    }
    if (!IS_ATOM_INT(_signal_boundary_14221)) {
        _1 = (long)(DBL_PTR(_signal_boundary_14221)->dbl);
        DeRefDS(_signal_boundary_14221);
        _signal_boundary_14221 = _1;
    }

    /** 	lKV = pairs(source_map, in_sorted_order)	*/
    Ref(_source_map_14217);
    _0 = _lKV_14222;
    _lKV_14222 = _33pairs(_source_map_14217, _in_sorted_order_14220);
    DeRef(_0);

    /** 	if length(lKV) = 0 and signal_boundary != 0 then*/
    if (IS_SEQUENCE(_lKV_14222)){
            _8069 = SEQ_PTR(_lKV_14222)->length;
    }
    else {
        _8069 = 1;
    }
    _8070 = (_8069 == 0);
    _8069 = NOVALUE;
    if (_8070 == 0) {
        goto L1; // [25] 55
    }
    _8072 = (_signal_boundary_14221 != 0);
    if (_8072 == 0)
    {
        DeRef(_8072);
        _8072 = NOVALUE;
        goto L1; // [34] 55
    }
    else{
        DeRef(_8072);
        _8072 = NOVALUE;
    }

    /** 		return call_func(user_rid, {0,0,user_data,0} )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    Ref(_user_data_14219);
    *((int *)(_2+12)) = _user_data_14219;
    *((int *)(_2+16)) = 0;
    _8073 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_8073);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_user_rid_14218].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    Ref(*(int *)(_2+12));
    Ref(*(int *)(_2+16));
    if (_00[_user_rid_14218].convention) {
        _1 = (*(int (__stdcall *)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12), 
                            *(int *)(_2+16)
                             );
    }
    else {
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8), 
                            *(int *)(_2+12), 
                            *(int *)(_2+16)
                             );
    }
    DeRef(_8074);
    _8074 = _1;
    DeRefDS(_8073);
    _8073 = NOVALUE;
    DeRef(_source_map_14217);
    DeRef(_user_data_14219);
    DeRef(_lKV_14222);
    DeRef(_lRes_14223);
    DeRef(_8070);
    _8070 = NOVALUE;
    return _8074;
L1: 

    /** 	for i = 1 to length(lKV) do*/
    if (IS_SEQUENCE(_lKV_14222)){
            _8075 = SEQ_PTR(_lKV_14222)->length;
    }
    else {
        _8075 = 1;
    }
    {
        int _i_14234;
        _i_14234 = 1;
L2: 
        if (_i_14234 > _8075){
            goto L3; // [60] 154
        }

        /** 		if i = length(lKV) and signal_boundary then*/
        if (IS_SEQUENCE(_lKV_14222)){
                _8076 = SEQ_PTR(_lKV_14222)->length;
        }
        else {
            _8076 = 1;
        }
        _8077 = (_i_14234 == _8076);
        _8076 = NOVALUE;
        if (_8077 == 0) {
            goto L4; // [76] 94
        }
        if (_signal_boundary_14221 == 0)
        {
            goto L4; // [81] 94
        }
        else{
        }

        /** 			progress_code = -i*/
        _progress_code_14224 = - _i_14234;
        goto L5; // [91] 100
L4: 

        /** 			progress_code = i*/
        _progress_code_14224 = _i_14234;
L5: 

        /** 		lRes = call_func(user_rid, {lKV[i][1], lKV[i][2], user_data, progress_code})*/
        _2 = (int)SEQ_PTR(_lKV_14222);
        _8080 = (int)*(((s1_ptr)_2)->base + _i_14234);
        _2 = (int)SEQ_PTR(_8080);
        _8081 = (int)*(((s1_ptr)_2)->base + 1);
        _8080 = NOVALUE;
        _2 = (int)SEQ_PTR(_lKV_14222);
        _8082 = (int)*(((s1_ptr)_2)->base + _i_14234);
        _2 = (int)SEQ_PTR(_8082);
        _8083 = (int)*(((s1_ptr)_2)->base + 2);
        _8082 = NOVALUE;
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_8081);
        *((int *)(_2+4)) = _8081;
        Ref(_8083);
        *((int *)(_2+8)) = _8083;
        Ref(_user_data_14219);
        *((int *)(_2+12)) = _user_data_14219;
        *((int *)(_2+16)) = _progress_code_14224;
        _8084 = MAKE_SEQ(_1);
        _8083 = NOVALUE;
        _8081 = NOVALUE;
        _1 = (int)SEQ_PTR(_8084);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_user_rid_14218].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        Ref(*(int *)(_2+12));
        Ref(*(int *)(_2+16));
        if (_00[_user_rid_14218].convention) {
            _1 = (*(int (__stdcall *)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
        }
        else {
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
        }
        DeRef(_lRes_14223);
        _lRes_14223 = _1;
        DeRefDS(_8084);
        _8084 = NOVALUE;

        /** 		if not equal(lRes, 0) then*/
        if (_lRes_14223 == 0)
        _8086 = 1;
        else if (IS_ATOM_INT(_lRes_14223) && IS_ATOM_INT(0))
        _8086 = 0;
        else
        _8086 = (compare(_lRes_14223, 0) == 0);
        if (_8086 != 0)
        goto L6; // [137] 147
        _8086 = NOVALUE;

        /** 			return lRes*/
        DeRef(_source_map_14217);
        DeRef(_user_data_14219);
        DeRefDS(_lKV_14222);
        DeRef(_8070);
        _8070 = NOVALUE;
        DeRef(_8077);
        _8077 = NOVALUE;
        DeRef(_8074);
        _8074 = NOVALUE;
        return _lRes_14223;
L6: 

        /** 	end for*/
        _i_14234 = _i_14234 + 1;
        goto L2; // [149] 67
L3: 
        ;
    }

    /** 	return 0*/
    DeRef(_source_map_14217);
    DeRef(_user_data_14219);
    DeRef(_lKV_14222);
    DeRef(_lRes_14223);
    DeRef(_8070);
    _8070 = NOVALUE;
    DeRef(_8077);
    _8077 = NOVALUE;
    DeRef(_8074);
    _8074 = NOVALUE;
    return 0;
    ;
}


void _33convert_to_large_map(int _the_map__14253)
{
    int _temp_map__14254 = NOVALUE;
    int _map_handle__14255 = NOVALUE;
    int _8100 = NOVALUE;
    int _8099 = NOVALUE;
    int _8098 = NOVALUE;
    int _8097 = NOVALUE;
    int _8096 = NOVALUE;
    int _8094 = NOVALUE;
    int _8093 = NOVALUE;
    int _8092 = NOVALUE;
    int _8091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__14254);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _temp_map__14254 = (int)*(((s1_ptr)_2)->base + _the_map__14253);
    Ref(_temp_map__14254);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__14255;
    _map_handle__14255 = _33new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__14254);
    _8091 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_8091)){
            _8092 = SEQ_PTR(_8091)->length;
    }
    else {
        _8092 = 1;
    }
    _8091 = NOVALUE;
    {
        int _index_14259;
        _index_14259 = 1;
L1: 
        if (_index_14259 > _8092){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__14254);
        _8093 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_8093);
        _8094 = (int)*(((s1_ptr)_2)->base + _index_14259);
        _8093 = NOVALUE;
        if (binary_op_a(EQUALS, _8094, 0)){
            _8094 = NOVALUE;
            goto L3; // [45] 77
        }
        _8094 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__14254);
        _8096 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_8096);
        _8097 = (int)*(((s1_ptr)_2)->base + _index_14259);
        _8096 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__14254);
        _8098 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_8098);
        _8099 = (int)*(((s1_ptr)_2)->base + _index_14259);
        _8098 = NOVALUE;
        Ref(_map_handle__14255);
        Ref(_8097);
        Ref(_8099);
        _33put(_map_handle__14255, _8097, _8099, 1, _33threshold_size_12989);
        _8097 = NOVALUE;
        _8099 = NOVALUE;
L3: 

        /** 	end for*/
        _index_14259 = _index_14259 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_map_handle__14255)){
        _8100 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__14255)->dbl));
    }
    else{
        _8100 = (int)*(((s1_ptr)_2)->base + _map_handle__14255);
    }
    Ref(_8100);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14253);
    _1 = *(int *)_2;
    *(int *)_2 = _8100;
    if( _1 != _8100 ){
        DeRef(_1);
    }
    _8100 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__14254);
    DeRef(_map_handle__14255);
    _8091 = NOVALUE;
    return;
    ;
}


void _33convert_to_small_map(int _the_map__14273)
{
    int _keys__14274 = NOVALUE;
    int _values__14275 = NOVALUE;
    int _8109 = NOVALUE;
    int _8108 = NOVALUE;
    int _8107 = NOVALUE;
    int _8106 = NOVALUE;
    int _8105 = NOVALUE;
    int _8104 = NOVALUE;
    int _8103 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__14273)) {
        _1 = (long)(DBL_PTR(_the_map__14273)->dbl);
        DeRefDS(_the_map__14273);
        _the_map__14273 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__14274;
    _keys__14274 = _33keys(_the_map__14273, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__14275;
    _values__14275 = _33values(_the_map__14273, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _8103 = Repeat(_33init_small_map_key_12990, _33threshold_size_12989);
    _8104 = Repeat(0, _33threshold_size_12989);
    _8105 = Repeat(0, _33threshold_size_12989);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_33type_is_map_12975);
    *((int *)(_2+4)) = _33type_is_map_12975;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _8103;
    *((int *)(_2+24)) = _8104;
    *((int *)(_2+28)) = _8105;
    _8106 = MAKE_SEQ(_1);
    _8105 = NOVALUE;
    _8104 = NOVALUE;
    _8103 = NOVALUE;
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14273);
    _1 = *(int *)_2;
    *(int *)_2 = _8106;
    if( _1 != _8106 ){
        DeRef(_1);
    }
    _8106 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__14274)){
            _8107 = SEQ_PTR(_keys__14274)->length;
    }
    else {
        _8107 = 1;
    }
    {
        int _i_14283;
        _i_14283 = 1;
L1: 
        if (_i_14283 > _8107){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__14274);
        _8108 = (int)*(((s1_ptr)_2)->base + _i_14283);
        _2 = (int)SEQ_PTR(_values__14275);
        _8109 = (int)*(((s1_ptr)_2)->base + _i_14283);
        Ref(_8108);
        Ref(_8109);
        _33put(_the_map__14273, _8108, _8109, 1, 0);
        _8108 = NOVALUE;
        _8109 = NOVALUE;

        /** 	end for*/
        _i_14283 = _i_14283 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__14274);
    DeRef(_values__14275);
    return;
    ;
}



// 0x67C11715
