// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _51task_delay(int _delaytime_22881)
{
    int _t_22882 = NOVALUE;
    int _12757 = NOVALUE;
    int _12756 = NOVALUE;
    int _0, _1, _2;
    

    /** 	t = time()*/
    DeRef(_t_22882);
    _t_22882 = NewDouble(current_time());

    /** 	while time() - t < delaytime do*/
L1: 
    DeRef(_12756);
    _12756 = NewDouble(current_time());
    if (IS_ATOM_INT(_t_22882)) {
        _12757 = NewDouble(DBL_PTR(_12756)->dbl - (double)_t_22882);
    }
    else
    _12757 = NewDouble(DBL_PTR(_12756)->dbl - DBL_PTR(_t_22882)->dbl);
    DeRefDS(_12756);
    _12756 = NOVALUE;
    if (binary_op_a(GREATEREQ, _12757, _delaytime_22881)){
        DeRefDS(_12757);
        _12757 = NOVALUE;
        goto L2; // [16] 33
    }
    DeRef(_12757);
    _12757 = NOVALUE;

    /** 		machine_proc(M_SLEEP, 0.01)*/
    machine(64, _12759);

    /** 		task_yield()*/

    /** 	end while*/
    goto L1; // [30] 10
L2: 

    /** end procedure*/
    DeRef(_delaytime_22881);
    DeRef(_t_22882);
    return;
    ;
}



// 0xDDCCBF07
