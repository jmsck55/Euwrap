// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _53host_by_name(int _name_22973)
{
    int _12770 = NOVALUE;
    int _12769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETHOSTBYNAME, { name })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_22973);
    *((int *)(_2+4)) = _name_22973;
    _12769 = MAKE_SEQ(_1);
    _12770 = machine(79, _12769);
    DeRefDS(_12769);
    _12769 = NOVALUE;
    DeRefDS(_name_22973);
    return _12770;
    ;
}


int  __stdcall _53host_by_addr(int _address_22978)
{
    int _12772 = NOVALUE;
    int _12771 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETHOSTBYADDR, { address })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_address_22978);
    *((int *)(_2+4)) = _address_22978;
    _12771 = MAKE_SEQ(_1);
    _12772 = machine(80, _12771);
    DeRefDS(_12771);
    _12771 = NOVALUE;
    DeRefDS(_address_22978);
    return _12772;
    ;
}



// 0x4914A464
