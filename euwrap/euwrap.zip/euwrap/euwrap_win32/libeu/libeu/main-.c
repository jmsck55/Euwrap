// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include <time.h>
#include "include/euphoria.h"
#include "main-.h"

#include <Windows.h>


int Argc;
char **Argv;
unsigned default_heap;
/* this is in the header */
/*__declspec(dllimport) unsigned __stdcall GetProcessHeap(void)*/;
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned short *poke2_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
int total_stack_size = 262144;

int __stdcall _CRT_INIT (int, int, void *);


void EuInit()
{
    s1_ptr _0switch_ptr;
    int _13190 = 0;
    int _13188 = 0;
    int _13159 = 0;
    int _12925 = 0;
    int _12924 = 0;
    int _12923 = 0;
    int _12100 = 0;
    int _12098 = 0;
    int _12096 = 0;
    int _12094 = 0;
    int _12092 = 0;
    int _12090 = 0;
    int _12088 = 0;
    int _12086 = 0;
    int _12084 = 0;
    int _12082 = 0;
    int _12080 = 0;
    int _12078 = 0;
    int _12076 = 0;
    int _12074 = 0;
    int _12072 = 0;
    int _12070 = 0;
    int _12068 = 0;
    int _12066 = 0;
    int _12064 = 0;
    int _12062 = 0;
    int _12061 = 0;
    int _12059 = 0;
    int _12057 = 0;
    int _12055 = 0;
    int _12053 = 0;
    int _12034 = 0;
    int _12032 = 0;
    int _12030 = 0;
    int _12028 = 0;
    int _12026 = 0;
    int _12024 = 0;
    int _12022 = 0;
    int _12020 = 0;
    int _12018 = 0;
    int _12016 = 0;
    int _12014 = 0;
    int _12012 = 0;
    int _12010 = 0;
    int _12008 = 0;
    int _12006 = 0;
    int _12004 = 0;
    int _12002 = 0;
    int _12000 = 0;
    int _11998 = 0;
    int _11996 = 0;
    int _11994 = 0;
    int _11992 = 0;
    int _11990 = 0;
    int _11988 = 0;
    int _11986 = 0;
    int _11984 = 0;
    int _11982 = 0;
    int _11980 = 0;
    int _11978 = 0;
    int _11852 = 0;
    int _11849 = 0;
    int _11846 = 0;
    int _11841 = 0;
    int _11838 = 0;
    int _11835 = 0;
    int _11832 = 0;
    int _11829 = 0;
    int _11668 = 0;
    int _11665 = 0;
    int _11662 = 0;
    int _11659 = 0;
    int _9559 = 0;
    int _9557 = 0;
    int _9555 = 0;
    int _9553 = 0;
    int _9551 = 0;
    int _8732 = 0;
    int _8621 = 0;
    int _8619 = 0;
    int _6383 = 0;
    int _6233 = 0;
    int _5310 = 0;
    int _5307 = 0;
    int _4864 = 0;
    int _4862 = 0;
    int _4860 = 0;
    int _4858 = 0;
    int _4856 = 0;
    int _4074 = 0;
    int _4073 = 0;
    int _4072 = 0;
    int _3804 = 0;
    int _3801 = 0;
    int _3798 = 0;
    int _3795 = 0;
    int _3792 = 0;
    int _3789 = 0;
    int _3786 = 0;
    int _3650 = 0;
    int _1668 = 0;
    int _1666 = 0;
    int _1664 = 0;
    int _1663 = 0;
    int _1065 = 0;
    int _1064 = 0;
    int _1061 = 0;
    int _1059 = 0;
    int _1058 = 0;
    int _1056 = 0;
    int _1055 = 0;
    int _1054 = 0;
    int _1053;
    int _1052 = 0;
    int _1051;
    int _1050 = 0;
    int _1049;
    int _1048 = 0;
    int _1046 = 0;
    int _1041 = 0;
    int _1038 = 0;
    int _1035 = 0;
    int _957 = 0;
    int _17 = 0;
    int _0, _1, _2;
    
    
    Argc = 0;
    default_heap = GetProcessHeap();

    _02 = (unsigned char**) malloc( 4 * 60 );
    _02[0] = (unsigned char*) malloc( 4 );
    _02[0][0] = 59;
    _02[1] = "\x01\x02\x03\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x03\x00";
    _02[2] = "\x02\x00\x02\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x00\x00";
    _02[3] = "\x03\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[4] = "\x04\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[5] = "\x05\x00\x00\x00\x03\x02\x03\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[6] = "\x06\x00\x00\x00\x00\x00\x03\x03\x03\x03\x03\x03\x01\x03\x03"
"\x07\x07\x00\x03\x01\x03\x07\x07\x03\x01\x01\x03\x03\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[7] = "\x07\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[8] = "\x08\x00\x00\x00\x00\x00\x03\x03\x03\x03\x01\x01\x01\x01\x01"
"\x01\x01\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[9] = "\x09\x00\x00\x00\x00\x00\x00\x03\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[10] = "\x0A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[11] = "\x0B\x00\x00\x00\x00\x00\x03\x03\x01\x03\x01\x03\x03\x03\x03"
"\x07\x07\x00\x03\x03\x03\x05\x05\x03\x03\x03\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[12] = "\x0C\x00\x00\x00\x00\x00\x00\x03\x00\x00\x01\x00\x02\x03\x03"
"\x07\x07\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[13] = "\x0D\x00\x00\x00\x00\x00\x00\x03\x00\x00\x03\x00\x00\x03\x03"
"\x05\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[14] = "\x0E\x00\x00\x00\x00\x00\x00\x03\x00\x00\x03\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[15] = "\x0F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[16] = "\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x07\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[17] = "\x11\x00\x00\x00\x00\x00\x01\x01\x01\x01\x03\x01\x01\x01\x01"
"\x01\x01\x02\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[18] = "\x12\x00\x00\x00\x00\x00\x03\x03\x01\x03\x03\x01\x01\x01\x03"
"\x07\x07\x00\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[19] = "\x13\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[20] = "\x14\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x07\x07\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[21] = "\x15\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[22] = "\x16\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[23] = "\x17\x00\x00\x00\x00\x00\x00\x03\x00\x03\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[24] = "\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[25] = "\x19\x00\x00\x00\x00\x00\x03\x01\x01\x01\x01\x01\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[26] = "\x1A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[27] = "\x1B\x00\x00\x00\x00\x00\x01\x01\x03\x01\x03\x01\x01\x03\x03"
"\x07\x07\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x02\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[28] = "\x1C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[29] = "\x1D\x00\x00\x00\x03\x00\x01\x01\x03\x01\x01\x01\x01\x01\x01"
"\x03\x03\x00\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x02"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[30] = "\x1E\x00\x00\x00\x00\x00\x00\x01\x00\x03\x01\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x03\x01\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[31] = "\x1F\x00\x00\x01\x00\x00\x03\x03\x01\x01\x03\x01\x01\x01\x01"
"\x03\x03\x01\x03\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x00\x02\x03\x03\x01\x01\x04\x03\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[32] = "\x20\x00\x00\x00\x00\x00\x03\x03\x01\x01\x01\x01\x01\x01\x01"
"\x03\x03\x03\x01\x01\x01\x03\x03\x01\x01\x01\x03\x01\x01\x00"
"\x00\x00\x02\x03\x01\x01\x07\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[33] = "\x21\x00\x00\x03\x00\x00\x03\x03\x01\x03\x03\x01\x03\x01\x01"
"\x03\x03\x03\x03\x03\x03\x07\x07\x01\x03\x01\x03\x03\x03\x00"
"\x00\x00\x00\x02\x03\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[34] = "\x22\x00\x00\x00\x00\x00\x00\x01\x00\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[35] = "\x23\x00\x00\x00\x00\x00\x00\x01\x00\x01\x01\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x03\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[36] = "\x24\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[37] = "\x25\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[38] = "\x26\x00\x00\x00\x00\x00\x03\x03\x03\x01\x03\x03\x03\x01\x03"
"\x07\x07\x01\x03\x01\x03\x07\x07\x01\x01\x01\x03\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[39] = "\x27\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x01\x01\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[40] = "\x28\x00\x00\x00\x00\x00\x01\x03\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x07\x01\x01\x01\x07\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[41] = "\x29\x00\x00\x00\x00\x00\x01\x01\x03\x01\x01\x01\x01\x01\x01"
"\x01\x01\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00\x00\x02\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[42] = "\x2A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[43] = "\x2B\x00\x00\x01\x00\x00\x03\x03\x01\x03\x01\x03\x03\x03\x03"
"\x07\x07\x01\x03\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x03\x00\x00\x00\x03\x02\x03"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[44] = "\x2C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[45] = "\x2D\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[46] = "\x2E\x00\x00\x00\x00\x00\x00\x01\x00\x00\x03\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[47] = "\x2F\x00\x00\x01\x00\x00\x03\x03\x01\x03\x01\x01\x01\x01\x03"
"\x07\x07\x01\x01\x01\x03\x07\x07\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x03\x00\x00\x00\x00\x00"
"\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[48] = "\x30\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x03"
"\x07\x07\x01\x01\x01\x01\x01\x01\x03\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x01\x02\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[49] = "\x31\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x03\x03\x03\x01\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x03\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[50] = "\x32\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[51] = "\x33\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[52] = "\x34\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00";
    _02[53] = "\x35\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00";
    _02[54] = "\x36\x00\x00\x03\x00\x00\x03\x03\x03\x01\x01\x01\x01\x01\x01"
"\x03\x03\x01\x01\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x03\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x01\x03\x01\x00\x00\x00\x03\x02\x03\x00\x00\x00\x00";
    _02[55] = "\x37\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x03\x01\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00";
    _02[56] = "\x38\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00";
    _02[57] = "\x39\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x03\x01"
"\x03\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00";
    _02[58] = "\x3A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x03";
    _02[59] = "\x3B\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02";

    eu_startup(_00, _01, _02, (int)CLOCKS_PER_SEC, (int)CLK_TCK);
    _0switch_ptr = (s1_ptr) NewS1( 5 );
    _0switch_ptr->base[1] = NewString("-wat    ");
    _0switch_ptr->base[2] = NewString("-keep    ");
    _0switch_ptr->base[3] = NewString("-dll    ");
    _0switch_ptr->base[4] = NewString("-i    ");
    _0switch_ptr->base[5] = NewString("C:\\\\Users\\\\jmsck\\\\OneDrive\\\\euphoria40\\\\bin    ");
    _0switches = MAKE_SEQ( _0switch_ptr );

    init_literal();
    _3version_info_163 = machine(75, _5);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _17 = (int)*(((s1_ptr)_2)->base + 4);
    if (_17 == _18)
    _3is_developmental_165 = 1;
    else if (IS_ATOM_INT(_17) && IS_ATOM_INT(_18))
    _3is_developmental_165 = 0;
    else
    _3is_developmental_165 = (compare(_17, _18) == 0);
    _17 = NOVALUE;
    _3is_release_169 = (_3is_developmental_165 == 0);
    _1 = NewS1(45);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_94);
    *((int *)(_2+4)) = _94;
    RefDS(_95);
    *((int *)(_2+8)) = _95;
    RefDS(_96);
    *((int *)(_2+12)) = _96;
    RefDS(_97);
    *((int *)(_2+16)) = _97;
    RefDS(_98);
    *((int *)(_2+20)) = _98;
    RefDS(_99);
    *((int *)(_2+24)) = _99;
    RefDS(_100);
    *((int *)(_2+28)) = _100;
    RefDS(_101);
    *((int *)(_2+32)) = _101;
    RefDS(_102);
    *((int *)(_2+36)) = _102;
    RefDS(_103);
    *((int *)(_2+40)) = _103;
    RefDS(_104);
    *((int *)(_2+44)) = _104;
    RefDS(_105);
    *((int *)(_2+48)) = _105;
    RefDS(_106);
    *((int *)(_2+52)) = _106;
    RefDS(_107);
    *((int *)(_2+56)) = _107;
    RefDS(_108);
    *((int *)(_2+60)) = _108;
    RefDS(_109);
    *((int *)(_2+64)) = _109;
    RefDS(_110);
    *((int *)(_2+68)) = _110;
    RefDS(_111);
    *((int *)(_2+72)) = _111;
    RefDS(_112);
    *((int *)(_2+76)) = _112;
    RefDS(_113);
    *((int *)(_2+80)) = _113;
    RefDS(_114);
    *((int *)(_2+84)) = _114;
    RefDS(_115);
    *((int *)(_2+88)) = _115;
    RefDS(_116);
    *((int *)(_2+92)) = _116;
    RefDS(_117);
    *((int *)(_2+96)) = _117;
    RefDS(_118);
    *((int *)(_2+100)) = _118;
    RefDS(_119);
    *((int *)(_2+104)) = _119;
    RefDS(_120);
    *((int *)(_2+108)) = _120;
    RefDS(_121);
    *((int *)(_2+112)) = _121;
    RefDS(_122);
    *((int *)(_2+116)) = _122;
    RefDS(_123);
    *((int *)(_2+120)) = _123;
    RefDS(_124);
    *((int *)(_2+124)) = _124;
    RefDS(_125);
    *((int *)(_2+128)) = _125;
    RefDS(_126);
    *((int *)(_2+132)) = _126;
    RefDS(_127);
    *((int *)(_2+136)) = _127;
    RefDS(_128);
    *((int *)(_2+140)) = _128;
    RefDS(_129);
    *((int *)(_2+144)) = _129;
    RefDS(_130);
    *((int *)(_2+148)) = _130;
    RefDS(_131);
    *((int *)(_2+152)) = _131;
    RefDS(_132);
    *((int *)(_2+156)) = _132;
    RefDS(_133);
    *((int *)(_2+160)) = _133;
    RefDS(_134);
    *((int *)(_2+164)) = _134;
    RefDS(_135);
    *((int *)(_2+168)) = _135;
    RefDS(_136);
    *((int *)(_2+172)) = _136;
    RefDS(_137);
    *((int *)(_2+176)) = _137;
    RefDS(_138);
    *((int *)(_2+180)) = _138;
    _4keywords_296 = MAKE_SEQ(_1);
    _1 = NewS1(88);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    RefDS(_141);
    *((int *)(_2+8)) = _141;
    RefDS(_142);
    *((int *)(_2+12)) = _142;
    RefDS(_143);
    *((int *)(_2+16)) = _143;
    RefDS(_144);
    *((int *)(_2+20)) = _144;
    RefDS(_145);
    *((int *)(_2+24)) = _145;
    RefDS(_146);
    *((int *)(_2+28)) = _146;
    RefDS(_147);
    *((int *)(_2+32)) = _147;
    RefDS(_148);
    *((int *)(_2+36)) = _148;
    RefDS(_149);
    *((int *)(_2+40)) = _149;
    RefDS(_150);
    *((int *)(_2+44)) = _150;
    RefDS(_151);
    *((int *)(_2+48)) = _151;
    RefDS(_152);
    *((int *)(_2+52)) = _152;
    RefDS(_153);
    *((int *)(_2+56)) = _153;
    RefDS(_154);
    *((int *)(_2+60)) = _154;
    RefDS(_155);
    *((int *)(_2+64)) = _155;
    RefDS(_156);
    *((int *)(_2+68)) = _156;
    RefDS(_157);
    *((int *)(_2+72)) = _157;
    RefDS(_158);
    *((int *)(_2+76)) = _158;
    RefDS(_159);
    *((int *)(_2+80)) = _159;
    RefDS(_160);
    *((int *)(_2+84)) = _160;
    RefDS(_161);
    *((int *)(_2+88)) = _161;
    RefDS(_162);
    *((int *)(_2+92)) = _162;
    RefDS(_163);
    *((int *)(_2+96)) = _163;
    RefDS(_164);
    *((int *)(_2+100)) = _164;
    RefDS(_165);
    *((int *)(_2+104)) = _165;
    RefDS(_166);
    *((int *)(_2+108)) = _166;
    RefDS(_167);
    *((int *)(_2+112)) = _167;
    RefDS(_168);
    *((int *)(_2+116)) = _168;
    RefDS(_169);
    *((int *)(_2+120)) = _169;
    RefDS(_170);
    *((int *)(_2+124)) = _170;
    RefDS(_171);
    *((int *)(_2+128)) = _171;
    RefDS(_172);
    *((int *)(_2+132)) = _172;
    RefDS(_173);
    *((int *)(_2+136)) = _173;
    RefDS(_174);
    *((int *)(_2+140)) = _174;
    RefDS(_175);
    *((int *)(_2+144)) = _175;
    RefDS(_176);
    *((int *)(_2+148)) = _176;
    RefDS(_177);
    *((int *)(_2+152)) = _177;
    RefDS(_178);
    *((int *)(_2+156)) = _178;
    RefDS(_179);
    *((int *)(_2+160)) = _179;
    RefDS(_180);
    *((int *)(_2+164)) = _180;
    RefDS(_181);
    *((int *)(_2+168)) = _181;
    RefDS(_182);
    *((int *)(_2+172)) = _182;
    RefDS(_183);
    *((int *)(_2+176)) = _183;
    RefDS(_184);
    *((int *)(_2+180)) = _184;
    RefDS(_185);
    *((int *)(_2+184)) = _185;
    RefDS(_186);
    *((int *)(_2+188)) = _186;
    RefDS(_187);
    *((int *)(_2+192)) = _187;
    RefDS(_188);
    *((int *)(_2+196)) = _188;
    RefDS(_189);
    *((int *)(_2+200)) = _189;
    RefDS(_190);
    *((int *)(_2+204)) = _190;
    RefDS(_191);
    *((int *)(_2+208)) = _191;
    RefDS(_192);
    *((int *)(_2+212)) = _192;
    RefDS(_193);
    *((int *)(_2+216)) = _193;
    RefDS(_194);
    *((int *)(_2+220)) = _194;
    RefDS(_195);
    *((int *)(_2+224)) = _195;
    RefDS(_196);
    *((int *)(_2+228)) = _196;
    RefDS(_197);
    *((int *)(_2+232)) = _197;
    RefDS(_198);
    *((int *)(_2+236)) = _198;
    RefDS(_199);
    *((int *)(_2+240)) = _199;
    RefDS(_200);
    *((int *)(_2+244)) = _200;
    RefDS(_201);
    *((int *)(_2+248)) = _201;
    RefDS(_202);
    *((int *)(_2+252)) = _202;
    RefDS(_203);
    *((int *)(_2+256)) = _203;
    RefDS(_204);
    *((int *)(_2+260)) = _204;
    RefDS(_205);
    *((int *)(_2+264)) = _205;
    RefDS(_206);
    *((int *)(_2+268)) = _206;
    RefDS(_207);
    *((int *)(_2+272)) = _207;
    RefDS(_208);
    *((int *)(_2+276)) = _208;
    RefDS(_209);
    *((int *)(_2+280)) = _209;
    RefDS(_210);
    *((int *)(_2+284)) = _210;
    RefDS(_211);
    *((int *)(_2+288)) = _211;
    RefDS(_212);
    *((int *)(_2+292)) = _212;
    RefDS(_213);
    *((int *)(_2+296)) = _213;
    RefDS(_214);
    *((int *)(_2+300)) = _214;
    RefDS(_215);
    *((int *)(_2+304)) = _215;
    RefDS(_216);
    *((int *)(_2+308)) = _216;
    RefDS(_217);
    *((int *)(_2+312)) = _217;
    RefDS(_218);
    *((int *)(_2+316)) = _218;
    RefDS(_219);
    *((int *)(_2+320)) = _219;
    RefDS(_220);
    *((int *)(_2+324)) = _220;
    RefDS(_221);
    *((int *)(_2+328)) = _221;
    RefDS(_222);
    *((int *)(_2+332)) = _222;
    RefDS(_223);
    *((int *)(_2+336)) = _223;
    RefDS(_224);
    *((int *)(_2+340)) = _224;
    RefDS(_225);
    *((int *)(_2+344)) = _225;
    RefDS(_226);
    *((int *)(_2+348)) = _226;
    RefDS(_227);
    *((int *)(_2+352)) = _227;
    _4builtins_343 = MAKE_SEQ(_1);
    _7FALSE_443 = (1 == 0);
    _7TRUE_445 = (1 == 1);

    /** set_default_charsets()*/
    _7set_default_charsets();
    _7INVALID_ROUTINE_ID_872 = CRoutineId(54, 7, _476);
    DeRef1(_8mem_1364);
    _8mem_1364 = machine(16, 4);
    _8decimal_mark_1528 = 46;

    /** ifdef WINDOWS then*/
    _15DEP_really_works_1853 = 0;
    _15use_DEP_1854 = 1;

    /** ifdef SAFE then*/
    _957 = power(2, 32);
    if (IS_ATOM_INT(_957)) {
        _16MAX_ADDR_1880 = _957 - 1;
        if ((long)((unsigned long)_16MAX_ADDR_1880 +(unsigned long) HIGH_BITS) >= 0){
            _16MAX_ADDR_1880 = NewDouble((double)_16MAX_ADDR_1880);
        }
    }
    else {
        _16MAX_ADDR_1880 = NewDouble(DBL_PTR(_957)->dbl - (double)1);
    }
    DeRef1(_957);
    _957 = NOVALUE;

    /** ifdef DATA_EXECUTE then*/

    /** memconst:FREE_RID = routine_id("deallocate")*/
    _15FREE_RID_1863 = CRoutineId(110, 16, _971);
    _16check_calls_1912 = 1;
    _16leader_1939 = Repeat(64, 0);
    _16trailer_1941 = Repeat(37, 0);
    _14page_size_2082 = 0;

    /** ifdef WINDOWS then*/

    /** 	memDLL_id = dll:open_dll( "kernel32.dll" )*/
    RefDS(_1032);
    _0 = _13open_dll(_1032);
    DeRef1(_14memDLL_id_2084);
    _14memDLL_id_2084 = _0;

    /** 	kernel_dll = memDLL_id*/
    Ref(_14memDLL_id_2084);
    DeRef1(_14kernel_dll_2083);
    _14kernel_dll_2083 = _14memDLL_id_2084;

    /** 	VirtualAlloc_rid = dll:define_c_func( memDLL_id, "VirtualAlloc", { dll:C_POINTER, dll:C_SIZE_T, dll:C_DWORD, dll:C_DWORD }, dll:C_POINTER )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _1035 = MAKE_SEQ(_1);
    Ref(_14memDLL_id_2084);
    RefDS(_1034);
    _0 = _13define_c_func(_14memDLL_id_2084, _1034, _1035, 33554436);
    DeRef1(_14VirtualAlloc_rid_2085);
    _14VirtualAlloc_rid_2085 = _0;
    _1035 = NOVALUE;

    /** 	VirtualProtect_rid = dll:define_c_func( memDLL_id, "VirtualProtect", { dll:C_POINTER, dll:C_SIZE_T, dll:C_DWORD, dll:C_POINTER }, dll:C_BOOL )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _1038 = MAKE_SEQ(_1);
    Ref(_14memDLL_id_2084);
    RefDS(_1037);
    _0 = _13define_c_func(_14memDLL_id_2084, _1037, _1038, 16777220);
    DeRef1(_14VirtualProtect_rid_2086);
    _14VirtualProtect_rid_2086 = _0;
    _1038 = NOVALUE;

    /** 	memory:VirtualFree_rid = dll:define_c_func( kernel_dll, "VirtualFree", { dll:C_POINTER, dll:C_SIZE_T, dll:C_DWORD }, dll:C_BOOL )*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    _1041 = MAKE_SEQ(_1);
    Ref(_14kernel_dll_2083);
    RefDS(_1040);
    _0 = _13define_c_func(_14kernel_dll_2083, _1040, _1041, 16777220);
    DeRef1(_16VirtualFree_rid_1954);
    _16VirtualFree_rid_1954 = _0;
    _1041 = NOVALUE;

    /** 	GetLastError_rid = dll:define_c_func( kernel_dll, "GetLastError", {}, dll:C_DWORD )*/
    Ref(_14kernel_dll_2083);
    RefDS(_1043);
    RefDS(_5);
    _0 = _13define_c_func(_14kernel_dll_2083, _1043, _5, 33554436);
    DeRef1(_14GetLastError_rid_2087);
    _14GetLastError_rid_2087 = _0;

    /** 	GetSystemInfo_rid = dll:define_c_proc( kernel_dll, "GetSystemInfo", { dll:C_POINTER } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _1046 = MAKE_SEQ(_1);
    Ref(_14kernel_dll_2083);
    RefDS(_1045);
    _0 = _13define_c_proc(_14kernel_dll_2083, _1045, _1046);
    DeRef1(_14GetSystemInfo_rid_2088);
    _14GetSystemInfo_rid_2088 = _0;
    _1046 = NOVALUE;

    /** 	if VirtualAlloc_rid != -1 and VirtualProtect_rid != -1 */
    if (IS_ATOM_INT(_14VirtualAlloc_rid_2085)) {
        _1048 = (_14VirtualAlloc_rid_2085 != -1);
    }
    else {
        _1048 = (DBL_PTR(_14VirtualAlloc_rid_2085)->dbl != (double)-1);
    }
    if (_1048 == 0) {
        _1049 = 0;
        goto L1; // [412] 426
    }
    if (IS_ATOM_INT(_14VirtualProtect_rid_2086)) {
        _1050 = (_14VirtualProtect_rid_2086 != -1);
    }
    else {
        _1050 = (DBL_PTR(_14VirtualProtect_rid_2086)->dbl != (double)-1);
    }
    _1049 = (_1050 != 0);
L1: 
    if (_1049 == 0) {
        _1051 = 0;
        goto L2; // [426] 440
    }
    if (IS_ATOM_INT(_14GetLastError_rid_2087)) {
        _1052 = (_14GetLastError_rid_2087 != -1);
    }
    else {
        _1052 = (DBL_PTR(_14GetLastError_rid_2087)->dbl != (double)-1);
    }
    _1051 = (_1052 != 0);
L2: 
    if (_1051 == 0) {
        goto L3; // [440] 517
    }
    if (IS_ATOM_INT(_14GetSystemInfo_rid_2088)) {
        _1054 = (_14GetSystemInfo_rid_2088 != -1);
    }
    else {
        _1054 = (DBL_PTR(_14GetSystemInfo_rid_2088)->dbl != (double)-1);
    }
    if (_1054 == 0)
    {
        DeRef1(_1054);
        _1054 = NOVALUE;
        goto L3; // [451] 517
    }
    else{
        DeRef1(_1054);
        _1054 = NOVALUE;
    }

    /** 		atom vaa = VirtualAlloc( 0, 1, or_bits( MEM_RESERVE, MEM_COMMIT ), PAGE_READ_WRITE_EXECUTE ) != 0 */
    {unsigned long tu;
         tu = (unsigned long)8192 | (unsigned long)4096;
         _1055 = MAKE_UINT(tu);
    }
    _1056 = _14VirtualAlloc(0, 1, _1055, 64);
    _1055 = NOVALUE;
    DeRef1(_14vaa_2135);
    if (IS_ATOM_INT(_1056)) {
        _14vaa_2135 = (_1056 != 0);
    }
    else {
        _14vaa_2135 = binary_op(NOTEQ, _1056, 0);
    }
    DeRef1(_1056);
    _1056 = NOVALUE;

    /** 		if vaa then*/
    if (_14vaa_2135 == 0) {
        goto L4; // [481] 516
    }
    else {
        if (!IS_ATOM_INT(_14vaa_2135) && DBL_PTR(_14vaa_2135)->dbl == 0.0){
            goto L4; // [481] 516
        }
    }

    /** 			DEP_really_works = 1*/
    _15DEP_really_works_1853 = 1;

    /** 			c_func( VirtualFree_rid, { vaa, 1, MEM_RELEASE } )*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_14vaa_2135);
    *((int *)(_2+4)) = _14vaa_2135;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 32768;
    _1058 = MAKE_SEQ(_1);
    _1059 = call_c(1, _16VirtualFree_rid_1954, _1058);
    DeRef1(_1058);
    _1058 = NOVALUE;

    /** 			vaa = 0*/
    DeRef1(_14vaa_2135);
    _14vaa_2135 = 0;
L4: 
L3: 
    DeRef1(_14vaa_2135);
    _14vaa_2135 = NOVALUE;
    DeRef1(_1048);
    _1048 = NOVALUE;
    DeRef1(_1050);
    _1050 = NOVALUE;
    DeRef1(_1052);
    _1052 = NOVALUE;
    DeRef1(_1059);
    _1059 = NOVALUE;

    /** 	if GetSystemInfo_rid != -1 then*/
    if (binary_op_a(EQUALS, _14GetSystemInfo_rid_2088, -1)){
        goto L5; // [524] 581
    }
    _1061 = 36;
    _0 = _14allocate(36, 0);
    DeRef1(_14system_info_ptr_2152);
    _14system_info_ptr_2152 = _0;
    _1061 = NOVALUE;

    /** 		if system_info_ptr != 0 then*/
    if (binary_op_a(EQUALS, _14system_info_ptr_2152, 0)){
        goto L6; // [541] 580
    }

    /** 			c_proc( GetSystemInfo_rid, { system_info_ptr } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_14system_info_ptr_2152);
    *((int *)(_2+4)) = _14system_info_ptr_2152;
    _1064 = MAKE_SEQ(_1);
    call_c(0, _14GetSystemInfo_rid_2088, _1064);
    DeRef1(_1064);
    _1064 = NOVALUE;

    /** 			page_size = peek4u( system_info_ptr + ADDRESS_LENGTH )*/
    if (IS_ATOM_INT(_14system_info_ptr_2152)) {
        _1065 = _14system_info_ptr_2152 + 4;
        if ((long)((unsigned long)_1065 + (unsigned long)HIGH_BITS) >= 0) 
        _1065 = NewDouble((double)_1065);
    }
    else {
        _1065 = binary_op(PLUS, _14system_info_ptr_2152, 4);
    }
    if (IS_ATOM_INT(_1065)) {
        _14page_size_2082 = *(unsigned long *)_1065;
        if ((unsigned)_14page_size_2082 > (unsigned)MAXINT)
        _14page_size_2082 = NewDouble((double)(unsigned long)_14page_size_2082);
    }
    else if (IS_ATOM(_1065)) {
        _14page_size_2082 = *(unsigned long *)(unsigned long)(DBL_PTR(_1065)->dbl);
        if ((unsigned)_14page_size_2082 > (unsigned)MAXINT)
        _14page_size_2082 = NewDouble((double)(unsigned long)_14page_size_2082);
    }
    else {
        _1 = (int)SEQ_PTR(_1065);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _14page_size_2082 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    DeRef1(_1065);
    _1065 = NOVALUE;
    if (!IS_ATOM_INT(_14page_size_2082)) {
        _1 = (long)(DBL_PTR(_14page_size_2082)->dbl);
        DeRefDS(_14page_size_2082);
        _14page_size_2082 = _1;
    }

    /** 			free( system_info_ptr )*/
    Ref(_14system_info_ptr_2152);
    _14free(_14system_info_ptr_2152);
L6: 
L5: 
    DeRef1(_14system_info_ptr_2152);
    _14system_info_ptr_2152 = NOVALUE;
    _14PAGE_SIZE_2165 = _14page_size_2082;

    /** ifdef WINDOWS then*/

    /** ifdef WINDOWS then*/
    _0 = _14allocate_data(4, 0);
    DeRef1(_14oldprotptr_2254);
    _14oldprotptr_2254 = _0;

    /** memconst:FREE_RID = routine_id("free")*/
    _15FREE_RID_1863 = CRoutineId(137, 14, _1124);

    /** FREE_ARRAY_RID = routine_id("free_pointer_array")*/
    _14FREE_ARRAY_RID_1968 = CRoutineId(138, 14, _1128);

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_18mem0_2507);
    _18mem0_2507 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_18mem1_2508);
    if (IS_ATOM_INT(_18mem0_2507)) {
        _18mem1_2508 = _18mem0_2507 + 1;
        if (_18mem1_2508 > MAXINT){
            _18mem1_2508 = NewDouble((double)_18mem1_2508);
        }
    }
    else
    _18mem1_2508 = binary_op(PLUS, 1, _18mem0_2507);

    /** mem2 = mem0 + 2*/
    DeRef1(_18mem2_2509);
    if (IS_ATOM_INT(_18mem0_2507)) {
        _18mem2_2509 = _18mem0_2507 + 2;
        if ((long)((unsigned long)_18mem2_2509 + (unsigned long)HIGH_BITS) >= 0) 
        _18mem2_2509 = NewDouble((double)_18mem2_2509);
    }
    else {
        _18mem2_2509 = NewDouble(DBL_PTR(_18mem0_2507)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_18mem3_2510);
    if (IS_ATOM_INT(_18mem0_2507)) {
        _18mem3_2510 = _18mem0_2507 + 3;
        if ((long)((unsigned long)_18mem3_2510 + (unsigned long)HIGH_BITS) >= 0) 
        _18mem3_2510 = NewDouble((double)_18mem3_2510);
    }
    else {
        _18mem3_2510 = NewDouble(DBL_PTR(_18mem0_2507)->dbl + (double)3);
    }
    Concat((object_ptr)&_17HEX_DIGITS_2917, _17DIGITS_2915, _1383);
    Concat((object_ptr)&_17START_NUMERIC_2920, _17DIGITS_2915, _1385);
    _17GET_SHORT_ANSWER_3332 = CRoutineId(183, 17, _1637);
    _17GET_LONG_ANSWER_3335 = CRoutineId(183, 17, _1639);

    /** ifdef LINUX then*/
    RefDS(_1662);
    _1663 = _13open_dll(_1662);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _1664 = MAKE_SEQ(_1);
    RefDS(_1660);
    _12gmtime__3399 = _13define_c_func(_1663, _1660, _1664, 33554436);
    _1663 = NOVALUE;
    _1664 = NOVALUE;
    RefDS(_1032);
    _1666 = _13open_dll(_1032);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _1668 = MAKE_SEQ(_1);
    RefDS(_1667);
    _12time__3404 = _13define_c_proc(_1666, _1667, _1668);
    _1666 = NOVALUE;
    _1668 = NOVALUE;
    _0 = _12month_names_3673;
    _1 = NewS1(12);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1833);
    *((int *)(_2+4)) = _1833;
    RefDS(_1834);
    *((int *)(_2+8)) = _1834;
    RefDS(_1835);
    *((int *)(_2+12)) = _1835;
    RefDS(_1836);
    *((int *)(_2+16)) = _1836;
    RefDS(_1837);
    *((int *)(_2+20)) = _1837;
    RefDS(_1838);
    *((int *)(_2+24)) = _1838;
    RefDS(_1839);
    *((int *)(_2+28)) = _1839;
    RefDS(_1840);
    *((int *)(_2+32)) = _1840;
    RefDS(_1841);
    *((int *)(_2+36)) = _1841;
    RefDS(_1842);
    *((int *)(_2+40)) = _1842;
    RefDS(_1843);
    *((int *)(_2+44)) = _1843;
    RefDS(_1844);
    *((int *)(_2+48)) = _1844;
    _12month_names_3673 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12month_abbrs_3687;
    _1 = NewS1(12);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1846);
    *((int *)(_2+4)) = _1846;
    RefDS(_1847);
    *((int *)(_2+8)) = _1847;
    RefDS(_1848);
    *((int *)(_2+12)) = _1848;
    RefDS(_1849);
    *((int *)(_2+16)) = _1849;
    RefDS(_1837);
    *((int *)(_2+20)) = _1837;
    RefDS(_1850);
    *((int *)(_2+24)) = _1850;
    RefDS(_1851);
    *((int *)(_2+28)) = _1851;
    RefDS(_1852);
    *((int *)(_2+32)) = _1852;
    RefDS(_1853);
    *((int *)(_2+36)) = _1853;
    RefDS(_1854);
    *((int *)(_2+40)) = _1854;
    RefDS(_1855);
    *((int *)(_2+44)) = _1855;
    RefDS(_1856);
    *((int *)(_2+48)) = _1856;
    _12month_abbrs_3687 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12day_names_3700;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1858);
    *((int *)(_2+4)) = _1858;
    RefDS(_1859);
    *((int *)(_2+8)) = _1859;
    RefDS(_1860);
    *((int *)(_2+12)) = _1860;
    RefDS(_1861);
    *((int *)(_2+16)) = _1861;
    RefDS(_1862);
    *((int *)(_2+20)) = _1862;
    RefDS(_1863);
    *((int *)(_2+24)) = _1863;
    RefDS(_1864);
    *((int *)(_2+28)) = _1864;
    _12day_names_3700 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12day_abbrs_3709;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1866);
    *((int *)(_2+4)) = _1866;
    RefDS(_1867);
    *((int *)(_2+8)) = _1867;
    RefDS(_1868);
    *((int *)(_2+12)) = _1868;
    RefDS(_1869);
    *((int *)(_2+16)) = _1869;
    RefDS(_1870);
    *((int *)(_2+20)) = _1870;
    RefDS(_1871);
    *((int *)(_2+24)) = _1871;
    RefDS(_1872);
    *((int *)(_2+28)) = _1872;
    _12day_abbrs_3709 = MAKE_SEQ(_1);
    DeRef1(_0);
    RefDS(_1875);
    RefDS(_1874);
    DeRef1(_12ampm_3718);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1874;
    ((int *)_2)[2] = _1875;
    _12ampm_3718 = MAKE_SEQ(_1);

    /** 	return from_date(date())*/
    DeRef1(_12now_1__tmp_at779_4115);
    _12now_1__tmp_at779_4115 = Date();
    RefDS(_12now_1__tmp_at779_4115);
    _12date_now_4112 = _12from_date(_12now_1__tmp_at779_4115);
    DeRef1(_12now_1__tmp_at779_4115);
    _12now_1__tmp_at779_4115 = NOVALUE;
    _22PINF_4462 = NewDouble(DBL_PTR(_2285)->dbl * (double)1000);
    _22MINF_4465 = unary_op(UMINUS, _22PINF_4462);
    _23STDFLTR_ALPHA_6250 = CRoutineId(301, 23, _3269);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3649);
    *((int *)(_2+4)) = _3649;
    _3650 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3650;
    _23SEQ_NOALT_6861 = MAKE_SEQ(_1);
    _3650 = NOVALUE;

    /** ifdef not UNIX then*/

    /** ifdef UNIX then*/

    /** ifdef WINDOWS then	*/
    RefDS(_3776);
    _11lib_7083 = _13open_dll(_3776);

    /** ifdef LINUX then*/

    /** ifdef UNIX then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 16777220;
    _3786 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3785);
    _11xCopyFile_7093 = _13define_c_func(_11lib_7083, _3785, _3786, 16777220);
    _3786 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _3789 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3788);
    _11xMoveFile_7098 = _13define_c_func(_11lib_7083, _3788, _3789, 16777220);
    _3789 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _3792 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3791);
    _11xDeleteFile_7102 = _13define_c_func(_11lib_7083, _3791, _3792, 16777220);
    _3792 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _3795 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3794);
    _11xCreateDirectory_7106 = _13define_c_func(_11lib_7083, _3794, _3795, 16777220);
    _3795 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _3798 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3797);
    _11xRemoveDirectory_7113 = _13define_c_func(_11lib_7083, _3797, _3798, 16777220);
    _3798 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _3801 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3800);
    _11xGetFileAttributes_7117 = _13define_c_func(_11lib_7083, _3800, _3801, 16777220);
    _3801 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 33554436;
    _3804 = MAKE_SEQ(_1);
    Ref(_11lib_7083);
    RefDS(_3803);
    _11xGetDiskFreeSpace_7121 = _13define_c_func(_11lib_7083, _3803, _3804, 16777220);
    _3804 = NOVALUE;

    /** ifdef UNIX then*/
    _11my_dir_7188 = -2;
    _0 = _11curdir(0);
    DeRef1(_11InitCurDir_7342);
    _11InitCurDir_7342 = _0;

    /** ifdef WINDOWS then*/
    _11starting_current_dir_7647 = machine(23, _5);
    _4072 = not_bits(65);
    if (IS_ATOM_INT(_4072)) {
        {unsigned long tu;
             tu = (unsigned long)97 & (unsigned long)_4072;
             _4073 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)97;
        _4073 = Dand_bits(&temp_d, DBL_PTR(_4072));
    }
    DeRef1(_4072);
    _4072 = NOVALUE;
    _2 = (int)SEQ_PTR(_11starting_current_dir_7647);
    _4074 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4073)) {
        {unsigned long tu;
             tu = (unsigned long)_4073 & (unsigned long)_4074;
             _11system_drive_case_7649 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_4074;
        _11system_drive_case_7649 = Dand_bits(DBL_PTR(_4073), &temp_d);
    }
    DeRef1(_4073);
    _4073 = NOVALUE;
    _4074 = NOVALUE;

    /** ifdef LINUX then*/
    RefDS(_5);
    DeRef1(_11file_counters_8410);
    _11file_counters_8410 = _5;

    /** ifdef UNIX then*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 78;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_4827);
    *((int *)(_2+24)) = _4827;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1000000000;
    *((int *)(_2+40)) = 1;
    _26PRETTY_DEFAULT_8845 = MAKE_SEQ(_1);
    _4856 = 32768;
    _27MIN2B_8910 = - 32768;
    _4858 = 32768;
    _27MAX2B_8913 = 32767;
    _4858 = NOVALUE;
    _4860 = 8388608;
    _27MIN3B_8916 = - 8388608;
    _4862 = 8388608;
    _27MAX3B_8919 = 8388607;
    _4862 = NOVALUE;
    _4864 = power(2, 31);
    if (IS_ATOM_INT(_4864)) {
        if ((unsigned long)_4864 == 0xC0000000)
        _27MIN4B_8922 = (int)NewDouble((double)-0xC0000000);
        else
        _27MIN4B_8922 = - _4864;
    }
    else {
        _27MIN4B_8922 = unary_op(UMINUS, _4864);
    }
    DeRef1(_4864);
    _4864 = NOVALUE;
    _4856 = NOVALUE;
    _4860 = NOVALUE;

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_27mem0_8925);
    _27mem0_8925 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_27mem1_8926);
    if (IS_ATOM_INT(_27mem0_8925)) {
        _27mem1_8926 = _27mem0_8925 + 1;
        if (_27mem1_8926 > MAXINT){
            _27mem1_8926 = NewDouble((double)_27mem1_8926);
        }
    }
    else
    _27mem1_8926 = binary_op(PLUS, 1, _27mem0_8925);

    /** mem2 = mem0 + 2*/
    DeRef1(_27mem2_8927);
    if (IS_ATOM_INT(_27mem0_8925)) {
        _27mem2_8927 = _27mem0_8925 + 2;
        if ((long)((unsigned long)_27mem2_8927 + (unsigned long)HIGH_BITS) >= 0) 
        _27mem2_8927 = NewDouble((double)_27mem2_8927);
    }
    else {
        _27mem2_8927 = NewDouble(DBL_PTR(_27mem0_8925)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_27mem3_8928);
    if (IS_ATOM_INT(_27mem0_8925)) {
        _27mem3_8928 = _27mem0_8925 + 3;
        if ((long)((unsigned long)_27mem3_8928 + (unsigned long)HIGH_BITS) >= 0) 
        _27mem3_8928 = NewDouble((double)_27mem3_8928);
    }
    else {
        _27mem3_8928 = NewDouble(DBL_PTR(_27mem0_8925)->dbl + (double)3);
    }
    DeRef1(_27f80_8933);
    _27f80_8933 = 0;
    DeRef1(_27f64_8934);
    _27f64_8934 = 0;
    _27F80_TO_ATOM_8935 = 0;
    DeRef1(_27i64_8973);
    _27i64_8973 = 0;
    _27PEEK8S_8974 = 0;

    /** ifdef UNIX then*/
    RefDS(_5);
    DeRef1(_6lower_case_SET_9469);
    _6lower_case_SET_9469 = _5;
    RefDS(_5);
    DeRef1(_6upper_case_SET_9470);
    _6upper_case_SET_9470 = _5;
    RefDS(_5206);
    DeRef1(_6encoding_NAME_9471);
    _6encoding_NAME_9471 = _5206;

    /** ifdef WINDOWS then*/
    RefDS(_5304);
    _0 = _13open_dll(_5304);
    DeRef1(_6user32_9620);
    _6user32_9620 = _0;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 16777220;
    _5307 = MAKE_SEQ(_1);
    Ref(_6user32_9620);
    RefDS(_5306);
    _0 = _13define_c_func(_6user32_9620, _5306, _5307, 16777220);
    DeRef1(_6api_CharLowerBuff_9624);
    _6api_CharLowerBuff_9624 = _0;
    _5307 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 16777220;
    _5310 = MAKE_SEQ(_1);
    Ref(_6user32_9620);
    RefDS(_5309);
    _0 = _13define_c_func(_6user32_9620, _5309, _5310, 16777220);
    DeRef1(_6api_CharUpperBuff_9632);
    _6api_CharUpperBuff_9632 = _0;
    _5310 = NOVALUE;
    _6tm_size_9640 = 1024;
    _0 = _14allocate(1024, 0);
    DeRef1(_6temp_mem_9641);
    _6temp_mem_9641 = _0;
    RefDS(_5);
    DeRef1(_28ram_space_10933);
    _28ram_space_10933 = _5;
    _28ram_free_list_10934 = 0;

    /** free_rid = routine_id("free")*/
    _28free_rid_10935 = CRoutineId(404, 28, _1124);
    _0 = _28malloc(1, 1);
    DeRef1(_5g_state_11082);
    _5g_state_11082 = _0;

    /** eumem:ram_space[g_state] = default_state()*/
    _6233 = _5default_state();
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5g_state_11082))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5g_state_11082)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _5g_state_11082);
    _1 = *(int *)_2;
    *(int *)_2 = _6233;
    if( _1 != _6233 ){
        DeRef(_1);
    }
    _6233 = NOVALUE;

    /** new()*/

    /** 	atom state = eumem:malloc()*/
    _0 = _28malloc(1, 1);
    DeRef1(_1state_inlined_new_at_1228_25245);
    _1state_inlined_new_at_1228_25245 = _0;

    /** 	reset(state)*/
    Ref(_1state_inlined_new_at_1228_25245);
    _5reset(_1state_inlined_new_at_1228_25245);

    /** 	return state*/
    Ref(_1state_inlined_new_at_1228_25245);
    DeRef1(_1new_inlined_new_at_1228_25246);
    _1new_inlined_new_at_1228_25246 = _1state_inlined_new_at_1228_25245;
    DeRef1(_1state_inlined_new_at_1228_25245);
    _1state_inlined_new_at_1228_25245 = NOVALUE;
    Ref(_1new_inlined_new_at_1228_25246);
    DeRef1(_6383);
    _6383 = _1new_inlined_new_at_1228_25246;

    /** init_class()*/
    _5init_class();
    Concat((object_ptr)&_29Delimiters_11368, _6389, _6390);
    _0 = _29Token_11377;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    RefDS(_5);
    *((int *)(_2+8)) = _5;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    _29Token_11377 = MAKE_SEQ(_1);
    DeRef1(_0);
    RefDS(_5);
    DeRef1(_29source_text_11379);
    _29source_text_11379 = _5;
    _29sti_11380 = 0;
    _29LNum_11381 = 0;
    _29LPos_11382 = 0;
    _29Look_11383 = 10;
    _29ERR_11384 = 0;
    _29ERR_LNUM_11385 = 0;
    _29ERR_LPOS_11386 = 0;
    _1 = NewS1(11);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6393);
    *((int *)(_2+4)) = _6393;
    RefDS(_6394);
    *((int *)(_2+8)) = _6394;
    RefDS(_6395);
    *((int *)(_2+12)) = _6395;
    RefDS(_6396);
    *((int *)(_2+16)) = _6396;
    RefDS(_6397);
    *((int *)(_2+20)) = _6397;
    RefDS(_6398);
    *((int *)(_2+24)) = _6398;
    RefDS(_6399);
    *((int *)(_2+28)) = _6399;
    RefDS(_6400);
    *((int *)(_2+32)) = _6400;
    RefDS(_6401);
    *((int *)(_2+36)) = _6401;
    RefDS(_6402);
    *((int *)(_2+40)) = _6402;
    RefDS(_6403);
    *((int *)(_2+44)) = _6403;
    _29ERROR_STRING_11399 = MAKE_SEQ(_1);
    _29IGNORE_NEWLINES_11426 = 1;
    _29IGNORE_COMMENTS_11427 = 1;
    _29STRING_NUMBERS_11428 = 0;
    _29SUBSCRIPT_11673 = 0;
    _29INCLUDE_NEXT_11848 = 0;
    _1 = NewS1(39);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6768);
    *((int *)(_2+4)) = _6768;
    RefDS(_6769);
    *((int *)(_2+8)) = _6769;
    RefDS(_6770);
    *((int *)(_2+12)) = _6770;
    RefDS(_6771);
    *((int *)(_2+16)) = _6771;
    RefDS(_6772);
    *((int *)(_2+20)) = _6772;
    RefDS(_6773);
    *((int *)(_2+24)) = _6773;
    RefDS(_6774);
    *((int *)(_2+28)) = _6774;
    RefDS(_6775);
    *((int *)(_2+32)) = _6775;
    RefDS(_6776);
    *((int *)(_2+36)) = _6776;
    RefDS(_6777);
    *((int *)(_2+40)) = _6777;
    RefDS(_6778);
    *((int *)(_2+44)) = _6778;
    RefDS(_6779);
    *((int *)(_2+48)) = _6779;
    RefDS(_6780);
    *((int *)(_2+52)) = _6780;
    RefDS(_6781);
    *((int *)(_2+56)) = _6781;
    RefDS(_6782);
    *((int *)(_2+60)) = _6782;
    RefDS(_6783);
    *((int *)(_2+64)) = _6783;
    RefDS(_6784);
    *((int *)(_2+68)) = _6784;
    RefDS(_6785);
    *((int *)(_2+72)) = _6785;
    RefDS(_6786);
    *((int *)(_2+76)) = _6786;
    RefDS(_6787);
    *((int *)(_2+80)) = _6787;
    RefDS(_6788);
    *((int *)(_2+84)) = _6788;
    RefDS(_6789);
    *((int *)(_2+88)) = _6789;
    RefDS(_6790);
    *((int *)(_2+92)) = _6790;
    RefDS(_6791);
    *((int *)(_2+96)) = _6791;
    RefDS(_6792);
    *((int *)(_2+100)) = _6792;
    RefDS(_6793);
    *((int *)(_2+104)) = _6793;
    RefDS(_6794);
    *((int *)(_2+108)) = _6794;
    RefDS(_6795);
    *((int *)(_2+112)) = _6795;
    RefDS(_6796);
    *((int *)(_2+116)) = _6796;
    RefDS(_6797);
    *((int *)(_2+120)) = _6797;
    RefDS(_6798);
    *((int *)(_2+124)) = _6798;
    RefDS(_6799);
    *((int *)(_2+128)) = _6799;
    RefDS(_6800);
    *((int *)(_2+132)) = _6800;
    RefDS(_6801);
    *((int *)(_2+136)) = _6801;
    RefDS(_6802);
    *((int *)(_2+140)) = _6802;
    RefDS(_6803);
    *((int *)(_2+144)) = _6803;
    RefDS(_6804);
    *((int *)(_2+148)) = _6804;
    RefDS(_6805);
    *((int *)(_2+152)) = _6805;
    RefDS(_6806);
    *((int *)(_2+156)) = _6806;
    _29token_names_12034 = MAKE_SEQ(_1);
    _1 = NewS1(9);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6808);
    *((int *)(_2+4)) = _6808;
    RefDS(_6809);
    *((int *)(_2+8)) = _6809;
    RefDS(_6810);
    *((int *)(_2+12)) = _6810;
    RefDS(_6811);
    *((int *)(_2+16)) = _6811;
    RefDS(_6812);
    *((int *)(_2+20)) = _6812;
    RefDS(_6813);
    *((int *)(_2+24)) = _6813;
    RefDS(_6814);
    *((int *)(_2+28)) = _6814;
    RefDS(_6815);
    *((int *)(_2+32)) = _6815;
    RefDS(_6816);
    *((int *)(_2+36)) = _6816;
    _29token_forms_12075 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 16;
    *((int *)(_2+12)) = 64;
    *((int *)(_2+16)) = 0;
    _30ediv_12166 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 16;
    *((int *)(_2+16)) = 64;
    _30erem_12168 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 16;
    *((int *)(_2+12)) = 4;
    *((int *)(_2+16)) = 1;
    _30emul_12170 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 0;
    _30next_12180 = MAKE_SEQ(_1);
    RefDS(_6957);
    DeRef1(_34list_of_primes_12301);
    _34list_of_primes_12301 = _6957;
    _33threshold_size_12989 = 23;

    /** ifdef WINDOWS then*/
    _0 = _36true_fgcolor_14320;
    _1 = NewS1(32);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 3;
    *((int *)(_2+20)) = 4;
    *((int *)(_2+24)) = 5;
    *((int *)(_2+28)) = 6;
    *((int *)(_2+32)) = 7;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 9;
    *((int *)(_2+44)) = 10;
    *((int *)(_2+48)) = 11;
    *((int *)(_2+52)) = 12;
    *((int *)(_2+56)) = 13;
    *((int *)(_2+60)) = 14;
    *((int *)(_2+64)) = 15;
    *((int *)(_2+68)) = 16;
    *((int *)(_2+72)) = 17;
    *((int *)(_2+76)) = 18;
    *((int *)(_2+80)) = 19;
    *((int *)(_2+84)) = 20;
    *((int *)(_2+88)) = 21;
    *((int *)(_2+92)) = 22;
    *((int *)(_2+96)) = 23;
    *((int *)(_2+100)) = 24;
    *((int *)(_2+104)) = 25;
    *((int *)(_2+108)) = 26;
    *((int *)(_2+112)) = 27;
    *((int *)(_2+116)) = 28;
    *((int *)(_2+120)) = 29;
    *((int *)(_2+124)) = 30;
    *((int *)(_2+128)) = 31;
    _36true_fgcolor_14320 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _36true_bgcolor_14322;
    _1 = NewS1(32);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 3;
    *((int *)(_2+20)) = 4;
    *((int *)(_2+24)) = 5;
    *((int *)(_2+28)) = 6;
    *((int *)(_2+32)) = 7;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 9;
    *((int *)(_2+44)) = 10;
    *((int *)(_2+48)) = 11;
    *((int *)(_2+52)) = 12;
    *((int *)(_2+56)) = 13;
    *((int *)(_2+60)) = 14;
    *((int *)(_2+64)) = 15;
    *((int *)(_2+68)) = 16;
    *((int *)(_2+72)) = 17;
    *((int *)(_2+76)) = 18;
    *((int *)(_2+80)) = 19;
    *((int *)(_2+84)) = 20;
    *((int *)(_2+88)) = 21;
    *((int *)(_2+92)) = 22;
    *((int *)(_2+96)) = 23;
    *((int *)(_2+100)) = 24;
    *((int *)(_2+104)) = 25;
    *((int *)(_2+108)) = 26;
    *((int *)(_2+112)) = 27;
    *((int *)(_2+116)) = 28;
    *((int *)(_2+120)) = 29;
    *((int *)(_2+124)) = 30;
    *((int *)(_2+128)) = 31;
    _36true_bgcolor_14322 = MAKE_SEQ(_1);
    DeRef1(_0);
    _32KC_LBUTTON_14377 = 2;
    _32KC_RBUTTON_14379 = 3;
    _32KC_CANCEL_14381 = 4;
    _32KC_MBUTTON_14383 = 5;
    _32KC_XBUTTON1_14385 = 6;
    _32KC_XBUTTON2_14387 = 7;
    _32KC_BACK_14389 = 9;
    _32KC_TAB_14391 = 10;
    _32KC_CLEAR_14393 = 13;
    _32KC_RETURN_14395 = 14;
    _32KC_SHIFT_14397 = 17;
    _32KC_CONTROL_14399 = 18;
    _32KC_MENU_14401 = 19;
    _32KC_PAUSE_14403 = 20;
    _32KC_CAPITAL_14405 = 21;
    _32KC_KANA_14407 = 22;
    _32KC_JUNJA_14409 = 24;
    _32KC_FINAL_14411 = 25;
    _32KC_HANJA_14413 = 26;
    _32KC_ESCAPE_14415 = 28;
    _32KC_CONVERT_14417 = 29;
    _32KC_NONCONVERT_14419 = 30;
    _32KC_ACCEPT_14421 = 31;
    _32KC_MODECHANGE_14423 = 32;
    _32KC_SPACE_14425 = 33;
    _32KC_PRIOR_14427 = 34;
    _32KC_NEXT_14429 = 35;
    _32KC_END_14431 = 36;
    _32KC_HOME_14433 = 37;
    _32KC_LEFT_14435 = 38;
    _32KC_UP_14437 = 39;
    _32KC_RIGHT_14439 = 40;
    _32KC_DOWN_14441 = 41;
    _32KC_SELECT_14443 = 42;
    _32KC_PRINT_14445 = 43;
    _32KC_EXECUTE_14447 = 44;
    _32KC_SNAPSHOT_14449 = 45;
    _32KC_INSERT_14451 = 46;
    _32KC_DELETE_14453 = 47;
    _32KC_HELP_14455 = 48;
    _32KC_LWIN_14457 = 92;
    _32KC_RWIN_14459 = 93;
    _32KC_APPS_14461 = 94;
    _32KC_SLEEP_14463 = 96;
    _32KC_NUMPAD0_14465 = 97;
    _32KC_NUMPAD1_14467 = 98;
    _32KC_NUMPAD2_14469 = 99;
    _32KC_NUMPAD3_14471 = 100;
    _32KC_NUMPAD4_14473 = 101;
    _32KC_NUMPAD5_14475 = 102;
    _32KC_NUMPAD6_14477 = 103;
    _32KC_NUMPAD7_14479 = 104;
    _32KC_NUMPAD8_14481 = 105;
    _32KC_NUMPAD9_14483 = 106;
    _32KC_MULTIPLY_14485 = 107;
    _32KC_ADD_14487 = 108;
    _32KC_SEPARATOR_14489 = 109;
    _32KC_SUBTRACT_14491 = 110;
    _32KC_DECIMAL_14493 = 111;
    _32KC_DIVIDE_14495 = 112;
    _32KC_F1_14497 = 113;
    _32KC_F2_14499 = 114;
    _32KC_F3_14501 = 115;
    _32KC_F4_14503 = 116;
    _32KC_F5_14505 = 117;
    _32KC_F6_14507 = 118;
    _32KC_F7_14509 = 119;
    _32KC_F8_14511 = 120;
    _32KC_F9_14513 = 121;
    _32KC_F10_14515 = 122;
    _32KC_F11_14517 = 123;
    _32KC_F12_14519 = 124;
    _32KC_F13_14521 = 125;
    _32KC_F14_14524 = 126;
    _32KC_F15_14526 = 127;
    _32KC_F16_14528 = 128;
    _32KC_F17_14530 = 129;
    _32KC_F18_14532 = 130;
    _32KC_F19_14535 = 131;
    _32KC_F20_14538 = 132;
    _32KC_F21_14540 = 133;
    _32KC_F22_14543 = 134;
    _32KC_F23_14546 = 135;
    _32KC_F24_14549 = 136;
    _32KC_NUMLOCK_14552 = 145;
    _32KC_SCROLL_14555 = 146;
    _32KC_LSHIFT_14558 = 161;
    _32KC_RSHIFT_14560 = 162;
    _32KC_LCONTROL_14563 = 163;
    _32KC_RCONTROL_14566 = 164;
    _32KC_LMENU_14568 = 165;
    _32KC_RMENU_14570 = 166;
    _32KC_BROWSER_BACK_14572 = 167;
    _32KC_BROWSER_FORWARD_14575 = 168;
    _32KC_BROWSER_REFRESH_14578 = 169;
    _32KC_BROWSER_STOP_14581 = 170;
    _32KC_BROWSER_SEARCH_14583 = 171;
    _32KC_BROWSER_FAVORITES_14586 = 172;
    _32KC_BROWSER_HOME_14589 = 173;
    _32KC_VOLUME_MUTE_14592 = 174;
    _32KC_VOLUME_DOWN_14595 = 175;
    _32KC_VOLUME_UP_14598 = 176;
    _32KC_MEDIA_NEXT_TRACK_14601 = 177;
    _32KC_MEDIA_PREV_TRACK_14604 = 178;
    _32KC_MEDIA_STOP_14607 = 179;
    _32KC_MEDIA_PLAY_PAUSE_14610 = 180;
    _32KC_LAUNCH_MAIL_14613 = 181;
    _32KC_LAUNCH_MEDIA_SELECT_14616 = 182;
    _32KC_LAUNCH_APP1_14619 = 183;
    _32KC_LAUNCH_APP2_14622 = 184;
    _32KC_OEM_1_14625 = 187;
    _32KC_OEM_PLUS_14628 = 188;
    _32KC_OEM_COMMA_14631 = 189;
    _32KC_OEM_MINUS_14634 = 190;
    _32KC_OEM_PERIOD_14637 = 191;
    _32KC_OEM_2_14640 = 192;
    _32KC_OEM_3_14643 = 193;
    _32KC_OEM_4_14646 = 220;
    _32KC_OEM_5_14648 = 221;
    _32KC_OEM_6_14651 = 222;
    _32KC_OEM_7_14653 = 223;
    _32KC_OEM_8_14656 = 224;
    _32KC_OEM_102_14658 = 227;
    _32KC_PROCESSKEY_14661 = 230;
    _32KC_PACKET_14663 = 232;
    _32KC_ATTN_14666 = 247;
    _32KC_CRSEL_14669 = 248;
    _32KC_EXSEL_14672 = 249;
    _32KC_EREOF_14674 = 250;
    _32KC_PLAY_14676 = 251;
    _32KC_ZOOM_14678 = 252;
    _32KC_NONAME_14680 = 253;
    _32KC_PA1_14682 = 254;
    _32KC_OEM_CLEAR_14684 = 255;

    /** ifdef WINDOWS then*/

    /** ifdef UNIX then*/

    /** ifdef WINDOWS then*/
    DeRef1(_37cur_pid_15306);
    _37cur_pid_15306 = -1;

    /** ifdef WINDOWS then*/
    RefDS(_8613);
    _8619 = _13open_dll(_8613);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _8621 = MAKE_SEQ(_1);
    RefDS(_8620);
    _37M_UNAME_15318 = _13define_c_func(_8619, _8620, _8621, 16777220);
    _8619 = NOVALUE;
    _8621 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8731);
    *((int *)(_2+4)) = _8731;
    _8732 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8732;
    _31EXTRAS_15498 = MAKE_SEQ(_1);
    _8732 = NOVALUE;
    RefDS(_31EXTRAS_15498);
    _31OPT_EXTRAS_15502 = _31EXTRAS_15498;
    RefDS(_5);
    DeRef1(_31pause_msg_15509);
    _31pause_msg_15509 = _5;
    _38current_db_16699 = -1;
    DeRef1(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;
    RefDS(_5);
    DeRef1(_38current_table_name_16701);
    _38current_table_name_16701 = _5;
    RefDS(_5);
    DeRef1(_38db_names_16702);
    _38db_names_16702 = _5;
    RefDS(_5);
    DeRef1(_38db_file_nums_16703);
    _38db_file_nums_16703 = _5;
    RefDS(_5);
    DeRef1(_38db_lock_methods_16704);
    _38db_lock_methods_16704 = _5;
    _38current_lock_16705 = 0;
    RefDS(_5);
    DeRef1(_38key_pointers_16706);
    _38key_pointers_16706 = _5;
    RefDS(_5);
    DeRef1(_38key_cache_16707);
    _38key_cache_16707 = _5;
    RefDS(_5);
    DeRef1(_38cache_index_16708);
    _38cache_index_16708 = _5;
    _38caching_option_16709 = 1;
    RefDS(_5);
    DeRef1(_38Known_Aliases_16720);
    _38Known_Aliases_16720 = _5;
    RefDS(_5);
    DeRef1(_38Alias_Details_16721);
    _38Alias_Details_16721 = _5;

    /** db_fatal_id = DB_FATAL_FAIL	-- Initialized separately from declaration so*/
    _38db_fatal_id_16722 = -404;
    RefDS(_5);
    DeRef1(_38vLastErrors_16723);
    _38vLastErrors_16723 = _5;

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_38mem0_16741);
    _38mem0_16741 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_38mem1_16742);
    if (IS_ATOM_INT(_38mem0_16741)) {
        _38mem1_16742 = _38mem0_16741 + 1;
        if (_38mem1_16742 > MAXINT){
            _38mem1_16742 = NewDouble((double)_38mem1_16742);
        }
    }
    else
    _38mem1_16742 = binary_op(PLUS, 1, _38mem0_16741);

    /** mem2 = mem0 + 2*/
    DeRef1(_38mem2_16743);
    if (IS_ATOM_INT(_38mem0_16741)) {
        _38mem2_16743 = _38mem0_16741 + 2;
        if ((long)((unsigned long)_38mem2_16743 + (unsigned long)HIGH_BITS) >= 0) 
        _38mem2_16743 = NewDouble((double)_38mem2_16743);
    }
    else {
        _38mem2_16743 = NewDouble(DBL_PTR(_38mem0_16741)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_38mem3_16744);
    if (IS_ATOM_INT(_38mem0_16741)) {
        _38mem3_16744 = _38mem0_16741 + 3;
        if ((long)((unsigned long)_38mem3_16744 + (unsigned long)HIGH_BITS) >= 0) 
        _38mem3_16744 = NewDouble((double)_38mem3_16744);
    }
    else {
        _38mem3_16744 = NewDouble(DBL_PTR(_38mem0_16741)->dbl + (double)3);
    }
    _9551 = 32768;
    _38MIN2B_16809 = - 32768;
    _9553 = 32768;
    _38MAX2B_16812 = 32767;
    _9553 = NOVALUE;
    _9555 = 8388608;
    _38MIN3B_16815 = - 8388608;
    _9557 = 8388608;
    _38MAX3B_16818 = 8388607;
    _9557 = NOVALUE;
    _9559 = power(2, 31);
    if (IS_ATOM_INT(_9559)) {
        if ((unsigned long)_9559 == 0xC0000000)
        _38MIN4B_16821 = (int)NewDouble((double)-0xC0000000);
        else
        _38MIN4B_16821 = - _9559;
    }
    else {
        _38MIN4B_16821 = unary_op(UMINUS, _9559);
    }
    DeRef1(_9559);
    _9559 = NOVALUE;
    _9551 = NOVALUE;
    _9555 = NOVALUE;

    /** memseq = {mem0, 4}*/
    Ref(_38mem0_16741);
    DeRef1(_38memseq_16961);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38mem0_16741;
    ((int *)_2)[2] = 4;
    _38memseq_16961 = MAKE_SEQ(_1);
    _0 = _33new(690);
    DeRef1(_39one_bit_numbers_19011);
    _39one_bit_numbers_19011 = _0;

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0001, 1)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 1, 1, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0010, 2)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 2, 2, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0100, 3)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 4, 3, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_1000, 4)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 8, 4, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0001_0000, 5)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 16, 5, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0010_0000, 6)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 32, 6, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0100_0000, 7)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 64, 7, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_1000_0000, 8)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 128, 8, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0001_0000_0000, 9)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 256, 9, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0010_0000_0000, 10)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 512, 10, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0100_0000_0000, 11)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 1024, 11, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_1000_0000_0000, 12)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 2048, 12, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0001_0000_0000_0000, 13)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 4096, 13, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0010_0000_0000_0000, 14)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 8192, 14, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0100_0000_0000_0000, 15)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 16384, 15, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_1000_0000_0000_0000, 16)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 32768, 16, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0001_0000_0000_0000_0000, 17)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 65536, 17, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0010_0000_0000_0000_0000, 18)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 131072, 18, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0100_0000_0000_0000_0000, 19)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 262144, 19, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_1000_0000_0000_0000_0000, 20)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 524288, 20, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0001_0000_0000_0000_0000_0000, 21)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 1048576, 21, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0010_0000_0000_0000_0000_0000, 22)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 2097152, 22, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_0100_0000_0000_0000_0000_0000, 23)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 4194304, 23, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0000_1000_0000_0000_0000_0000_0000, 24)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 8388608, 24, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0001_0000_0000_0000_0000_0000_0000, 25)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 16777216, 25, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0010_0000_0000_0000_0000_0000_0000, 26)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 33554432, 26, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_0100_0000_0000_0000_0000_0000_0000, 27)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 67108864, 27, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0000_1000_0000_0000_0000_0000_0000_0000, 28)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 134217728, 28, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0001_0000_0000_0000_0000_0000_0000_0000, 29)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 268435456, 29, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0010_0000_0000_0000_0000_0000_0000_0000, 30)*/
    Ref(_39one_bit_numbers_19011);
    _33put(_39one_bit_numbers_19011, 536870912, 30, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b0100_0000_0000_0000_0000_0000_0000_0000, 31)*/
    Ref(_39one_bit_numbers_19011);
    RefDS(_10594);
    _33put(_39one_bit_numbers_19011, _10594, 31, 1, _33threshold_size_12989);

    /** map:put(one_bit_numbers, 0b1000_0000_0000_0000_0000_0000_0000_0000, 32)*/
    Ref(_39one_bit_numbers_19011);
    RefDS(_10595);
    _33put(_39one_bit_numbers_19011, _10595, 32, 1, _33threshold_size_12989);

    /** ifdef WINDOWS then*/
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1078;
    *((int *)(_2+8)) = 1052;
    *((int *)(_2+12)) = 1156;
    *((int *)(_2+16)) = 1118;
    *((int *)(_2+20)) = 5121;
    *((int *)(_2+24)) = 15361;
    *((int *)(_2+28)) = 3073;
    *((int *)(_2+32)) = 2049;
    *((int *)(_2+36)) = 11265;
    *((int *)(_2+40)) = 13313;
    *((int *)(_2+44)) = 12289;
    *((int *)(_2+48)) = 4097;
    *((int *)(_2+52)) = 6145;
    *((int *)(_2+56)) = 8193;
    *((int *)(_2+60)) = 16385;
    *((int *)(_2+64)) = 1025;
    *((int *)(_2+68)) = 10241;
    *((int *)(_2+72)) = 7169;
    *((int *)(_2+76)) = 14337;
    *((int *)(_2+80)) = 9217;
    *((int *)(_2+84)) = 1067;
    *((int *)(_2+88)) = 1101;
    *((int *)(_2+92)) = 2092;
    *((int *)(_2+96)) = 1068;
    *((int *)(_2+100)) = 1133;
    *((int *)(_2+104)) = 1069;
    *((int *)(_2+108)) = 1059;
    *((int *)(_2+112)) = 1093;
    *((int *)(_2+116)) = 8218;
    *((int *)(_2+120)) = 5146;
    *((int *)(_2+124)) = 1150;
    *((int *)(_2+128)) = 1026;
    *((int *)(_2+132)) = 1027;
    *((int *)(_2+136)) = 3076;
    *((int *)(_2+140)) = 5124;
    *((int *)(_2+144)) = 2052;
    *((int *)(_2+148)) = 4100;
    *((int *)(_2+152)) = 1028;
    *((int *)(_2+156)) = 4122;
    *((int *)(_2+160)) = 1050;
    *((int *)(_2+164)) = 1029;
    *((int *)(_2+168)) = 1030;
    *((int *)(_2+172)) = 1164;
    *((int *)(_2+176)) = 1125;
    *((int *)(_2+180)) = 2067;
    *((int *)(_2+184)) = 1043;
    *((int *)(_2+188)) = 3081;
    *((int *)(_2+192)) = 10249;
    *((int *)(_2+196)) = 4105;
    *((int *)(_2+200)) = 9225;
    *((int *)(_2+204)) = 16393;
    *((int *)(_2+208)) = 6153;
    *((int *)(_2+212)) = 8201;
    *((int *)(_2+216)) = 17417;
    *((int *)(_2+220)) = 5129;
    *((int *)(_2+224)) = 13321;
    *((int *)(_2+228)) = 18441;
    *((int *)(_2+232)) = 7177;
    *((int *)(_2+236)) = 11273;
    *((int *)(_2+240)) = 2057;
    *((int *)(_2+244)) = 1033;
    *((int *)(_2+248)) = 12297;
    *((int *)(_2+252)) = 1061;
    *((int *)(_2+256)) = 1080;
    *((int *)(_2+260)) = 1124;
    *((int *)(_2+264)) = 1035;
    *((int *)(_2+268)) = 2060;
    *((int *)(_2+272)) = 3084;
    *((int *)(_2+276)) = 1036;
    *((int *)(_2+280)) = 5132;
    *((int *)(_2+284)) = 6156;
    *((int *)(_2+288)) = 4108;
    *((int *)(_2+292)) = 1122;
    *((int *)(_2+296)) = 1110;
    *((int *)(_2+300)) = 1079;
    *((int *)(_2+304)) = 3079;
    *((int *)(_2+308)) = 1031;
    *((int *)(_2+312)) = 5127;
    *((int *)(_2+316)) = 4103;
    *((int *)(_2+320)) = 2055;
    *((int *)(_2+324)) = 1032;
    *((int *)(_2+328)) = 1135;
    *((int *)(_2+332)) = 1095;
    *((int *)(_2+336)) = 1128;
    *((int *)(_2+340)) = 1037;
    *((int *)(_2+344)) = 1081;
    *((int *)(_2+348)) = 1038;
    *((int *)(_2+352)) = 1039;
    *((int *)(_2+356)) = 1136;
    *((int *)(_2+360)) = 1057;
    *((int *)(_2+364)) = 2141;
    *((int *)(_2+368)) = 1117;
    *((int *)(_2+372)) = 2108;
    *((int *)(_2+376)) = 1040;
    *((int *)(_2+380)) = 2064;
    *((int *)(_2+384)) = 1041;
    *((int *)(_2+388)) = 1099;
    *((int *)(_2+392)) = 1087;
    *((int *)(_2+396)) = 1107;
    *((int *)(_2+400)) = 1158;
    *((int *)(_2+404)) = 1159;
    *((int *)(_2+408)) = 1111;
    *((int *)(_2+412)) = 2066;
    *((int *)(_2+416)) = 1042;
    *((int *)(_2+420)) = 1088;
    *((int *)(_2+424)) = 1108;
    *((int *)(_2+428)) = 1062;
    *((int *)(_2+432)) = 1063;
    *((int *)(_2+436)) = 2094;
    *((int *)(_2+440)) = 1134;
    *((int *)(_2+444)) = 1071;
    *((int *)(_2+448)) = 2110;
    *((int *)(_2+452)) = 1086;
    *((int *)(_2+456)) = 1100;
    *((int *)(_2+460)) = 1082;
    *((int *)(_2+464)) = 1153;
    *((int *)(_2+468)) = 1146;
    *((int *)(_2+472)) = 1102;
    *((int *)(_2+476)) = 1148;
    *((int *)(_2+480)) = 1104;
    *((int *)(_2+484)) = 2128;
    *((int *)(_2+488)) = 1121;
    *((int *)(_2+492)) = 1044;
    *((int *)(_2+496)) = 2068;
    *((int *)(_2+500)) = 1154;
    *((int *)(_2+504)) = 1096;
    *((int *)(_2+508)) = 1123;
    *((int *)(_2+512)) = 1065;
    *((int *)(_2+516)) = 1045;
    *((int *)(_2+520)) = 1046;
    *((int *)(_2+524)) = 2070;
    *((int *)(_2+528)) = 1094;
    *((int *)(_2+532)) = 1131;
    *((int *)(_2+536)) = 2155;
    *((int *)(_2+540)) = 3179;
    *((int *)(_2+544)) = 1048;
    *((int *)(_2+548)) = 1047;
    *((int *)(_2+552)) = 1049;
    *((int *)(_2+556)) = 9275;
    *((int *)(_2+560)) = 4155;
    *((int *)(_2+564)) = 5179;
    *((int *)(_2+568)) = 3131;
    *((int *)(_2+572)) = 1083;
    *((int *)(_2+576)) = 2107;
    *((int *)(_2+580)) = 8251;
    *((int *)(_2+584)) = 6203;
    *((int *)(_2+588)) = 7227;
    *((int *)(_2+592)) = 1103;
    *((int *)(_2+596)) = 7194;
    *((int *)(_2+600)) = 6170;
    *((int *)(_2+604)) = 3098;
    *((int *)(_2+608)) = 2074;
    *((int *)(_2+612)) = 1132;
    *((int *)(_2+616)) = 1074;
    *((int *)(_2+620)) = 1115;
    *((int *)(_2+624)) = 1051;
    *((int *)(_2+628)) = 1060;
    *((int *)(_2+632)) = 11274;
    *((int *)(_2+636)) = 16394;
    *((int *)(_2+640)) = 13322;
    *((int *)(_2+644)) = 9226;
    *((int *)(_2+648)) = 5130;
    *((int *)(_2+652)) = 7178;
    *((int *)(_2+656)) = 12298;
    *((int *)(_2+660)) = 17418;
    *((int *)(_2+664)) = 4106;
    *((int *)(_2+668)) = 18442;
    *((int *)(_2+672)) = 2058;
    *((int *)(_2+676)) = 19466;
    *((int *)(_2+680)) = 6154;
    *((int *)(_2+684)) = 15370;
    *((int *)(_2+688)) = 10250;
    *((int *)(_2+692)) = 20490;
    *((int *)(_2+696)) = 3082;
    *((int *)(_2+700)) = 1034;
    *((int *)(_2+704)) = 21514;
    *((int *)(_2+708)) = 14346;
    *((int *)(_2+712)) = 8202;
    *((int *)(_2+716)) = 1089;
    *((int *)(_2+720)) = 2077;
    *((int *)(_2+724)) = 1053;
    *((int *)(_2+728)) = 1114;
    *((int *)(_2+732)) = 1064;
    *((int *)(_2+736)) = 2143;
    *((int *)(_2+740)) = 1097;
    *((int *)(_2+744)) = 1092;
    *((int *)(_2+748)) = 1098;
    *((int *)(_2+752)) = 1054;
    *((int *)(_2+756)) = 2129;
    *((int *)(_2+760)) = 1105;
    *((int *)(_2+764)) = 1055;
    *((int *)(_2+768)) = 1090;
    *((int *)(_2+772)) = 1152;
    *((int *)(_2+776)) = 1058;
    *((int *)(_2+780)) = 1070;
    *((int *)(_2+784)) = 2080;
    *((int *)(_2+788)) = 1056;
    *((int *)(_2+792)) = 2115;
    *((int *)(_2+796)) = 1091;
    *((int *)(_2+800)) = 1066;
    *((int *)(_2+804)) = 1106;
    *((int *)(_2+808)) = 1160;
    *((int *)(_2+812)) = 1076;
    *((int *)(_2+816)) = 1157;
    *((int *)(_2+820)) = 1144;
    *((int *)(_2+824)) = 1130;
    *((int *)(_2+828)) = 1077;
    *((int *)(_2+832)) = 127;
    _42lcid_hex_19673 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_11084);
    *((int *)(_2+4)) = _11084;
    RefDS(_11085);
    *((int *)(_2+8)) = _11085;
    RefDS(_11086);
    *((int *)(_2+12)) = _11086;
    RefDS(_11087);
    *((int *)(_2+16)) = _11087;
    RefDS(_11088);
    *((int *)(_2+20)) = _11088;
    RefDS(_11089);
    *((int *)(_2+24)) = _11089;
    RefDS(_11090);
    *((int *)(_2+28)) = _11090;
    RefDS(_11091);
    *((int *)(_2+32)) = _11091;
    RefDS(_11092);
    *((int *)(_2+36)) = _11092;
    RefDS(_11093);
    *((int *)(_2+40)) = _11093;
    RefDS(_11094);
    *((int *)(_2+44)) = _11094;
    RefDS(_11095);
    *((int *)(_2+48)) = _11095;
    RefDS(_11096);
    *((int *)(_2+52)) = _11096;
    RefDS(_11097);
    *((int *)(_2+56)) = _11097;
    RefDS(_11098);
    *((int *)(_2+60)) = _11098;
    RefDS(_11099);
    *((int *)(_2+64)) = _11099;
    RefDS(_11100);
    *((int *)(_2+68)) = _11100;
    RefDS(_11101);
    *((int *)(_2+72)) = _11101;
    RefDS(_11102);
    *((int *)(_2+76)) = _11102;
    RefDS(_11103);
    *((int *)(_2+80)) = _11103;
    RefDS(_11104);
    *((int *)(_2+84)) = _11104;
    RefDS(_11105);
    *((int *)(_2+88)) = _11105;
    RefDS(_11106);
    *((int *)(_2+92)) = _11106;
    RefDS(_11107);
    *((int *)(_2+96)) = _11107;
    RefDS(_11108);
    *((int *)(_2+100)) = _11108;
    RefDS(_11109);
    *((int *)(_2+104)) = _11109;
    RefDS(_11110);
    *((int *)(_2+108)) = _11110;
    RefDS(_11111);
    *((int *)(_2+112)) = _11111;
    RefDS(_11112);
    *((int *)(_2+116)) = _11112;
    RefDS(_11113);
    *((int *)(_2+120)) = _11113;
    RefDS(_11114);
    *((int *)(_2+124)) = _11114;
    RefDS(_11115);
    *((int *)(_2+128)) = _11115;
    RefDS(_11116);
    *((int *)(_2+132)) = _11116;
    RefDS(_11117);
    *((int *)(_2+136)) = _11117;
    RefDS(_11118);
    *((int *)(_2+140)) = _11118;
    RefDS(_11119);
    *((int *)(_2+144)) = _11119;
    RefDS(_11120);
    *((int *)(_2+148)) = _11120;
    RefDS(_11121);
    *((int *)(_2+152)) = _11121;
    RefDS(_11122);
    *((int *)(_2+156)) = _11122;
    RefDS(_11123);
    *((int *)(_2+160)) = _11123;
    RefDS(_11124);
    *((int *)(_2+164)) = _11124;
    RefDS(_11125);
    *((int *)(_2+168)) = _11125;
    RefDS(_11126);
    *((int *)(_2+172)) = _11126;
    RefDS(_11127);
    *((int *)(_2+176)) = _11127;
    RefDS(_11128);
    *((int *)(_2+180)) = _11128;
    RefDS(_11129);
    *((int *)(_2+184)) = _11129;
    RefDS(_11130);
    *((int *)(_2+188)) = _11130;
    RefDS(_11131);
    *((int *)(_2+192)) = _11131;
    RefDS(_11132);
    *((int *)(_2+196)) = _11132;
    RefDS(_11133);
    *((int *)(_2+200)) = _11133;
    RefDS(_11134);
    *((int *)(_2+204)) = _11134;
    RefDS(_11135);
    *((int *)(_2+208)) = _11135;
    RefDS(_11136);
    *((int *)(_2+212)) = _11136;
    RefDS(_11137);
    *((int *)(_2+216)) = _11137;
    RefDS(_11138);
    *((int *)(_2+220)) = _11138;
    RefDS(_11139);
    *((int *)(_2+224)) = _11139;
    RefDS(_11140);
    *((int *)(_2+228)) = _11140;
    RefDS(_11141);
    *((int *)(_2+232)) = _11141;
    RefDS(_11142);
    *((int *)(_2+236)) = _11142;
    RefDS(_11143);
    *((int *)(_2+240)) = _11143;
    RefDS(_11144);
    *((int *)(_2+244)) = _11144;
    RefDS(_11145);
    *((int *)(_2+248)) = _11145;
    RefDS(_11146);
    *((int *)(_2+252)) = _11146;
    RefDS(_11147);
    *((int *)(_2+256)) = _11147;
    RefDS(_11148);
    *((int *)(_2+260)) = _11148;
    RefDS(_11149);
    *((int *)(_2+264)) = _11149;
    RefDS(_11150);
    *((int *)(_2+268)) = _11150;
    RefDS(_11151);
    *((int *)(_2+272)) = _11151;
    RefDS(_11152);
    *((int *)(_2+276)) = _11152;
    RefDS(_11153);
    *((int *)(_2+280)) = _11153;
    RefDS(_11154);
    *((int *)(_2+284)) = _11154;
    RefDS(_11155);
    *((int *)(_2+288)) = _11155;
    RefDS(_11156);
    *((int *)(_2+292)) = _11156;
    RefDS(_11157);
    *((int *)(_2+296)) = _11157;
    RefDS(_11158);
    *((int *)(_2+300)) = _11158;
    RefDS(_11159);
    *((int *)(_2+304)) = _11159;
    RefDS(_11160);
    *((int *)(_2+308)) = _11160;
    RefDS(_11161);
    *((int *)(_2+312)) = _11161;
    RefDS(_11162);
    *((int *)(_2+316)) = _11162;
    RefDS(_11163);
    *((int *)(_2+320)) = _11163;
    RefDS(_11164);
    *((int *)(_2+324)) = _11164;
    RefDS(_11165);
    *((int *)(_2+328)) = _11165;
    RefDS(_11166);
    *((int *)(_2+332)) = _11166;
    RefDS(_11167);
    *((int *)(_2+336)) = _11167;
    RefDS(_11168);
    *((int *)(_2+340)) = _11168;
    RefDS(_11169);
    *((int *)(_2+344)) = _11169;
    RefDS(_11170);
    *((int *)(_2+348)) = _11170;
    RefDS(_11171);
    *((int *)(_2+352)) = _11171;
    RefDS(_11172);
    *((int *)(_2+356)) = _11172;
    RefDS(_11173);
    *((int *)(_2+360)) = _11173;
    RefDS(_11174);
    *((int *)(_2+364)) = _11174;
    RefDS(_11175);
    *((int *)(_2+368)) = _11175;
    RefDS(_11176);
    *((int *)(_2+372)) = _11176;
    RefDS(_11177);
    *((int *)(_2+376)) = _11177;
    RefDS(_11178);
    *((int *)(_2+380)) = _11178;
    RefDS(_11179);
    *((int *)(_2+384)) = _11179;
    RefDS(_11180);
    *((int *)(_2+388)) = _11180;
    RefDS(_11181);
    *((int *)(_2+392)) = _11181;
    RefDS(_11182);
    *((int *)(_2+396)) = _11182;
    RefDS(_11183);
    *((int *)(_2+400)) = _11183;
    RefDS(_11184);
    *((int *)(_2+404)) = _11184;
    RefDS(_11185);
    *((int *)(_2+408)) = _11185;
    RefDS(_11186);
    *((int *)(_2+412)) = _11186;
    RefDS(_11187);
    *((int *)(_2+416)) = _11187;
    RefDS(_11188);
    *((int *)(_2+420)) = _11188;
    RefDS(_11189);
    *((int *)(_2+424)) = _11189;
    RefDS(_11190);
    *((int *)(_2+428)) = _11190;
    RefDS(_11191);
    *((int *)(_2+432)) = _11191;
    RefDS(_11192);
    *((int *)(_2+436)) = _11192;
    RefDS(_11193);
    *((int *)(_2+440)) = _11193;
    RefDS(_11194);
    *((int *)(_2+444)) = _11194;
    RefDS(_11195);
    *((int *)(_2+448)) = _11195;
    RefDS(_11196);
    *((int *)(_2+452)) = _11196;
    RefDS(_11197);
    *((int *)(_2+456)) = _11197;
    RefDS(_11198);
    *((int *)(_2+460)) = _11198;
    RefDS(_11199);
    *((int *)(_2+464)) = _11199;
    RefDS(_11200);
    *((int *)(_2+468)) = _11200;
    RefDS(_11201);
    *((int *)(_2+472)) = _11201;
    RefDS(_11202);
    *((int *)(_2+476)) = _11202;
    RefDS(_11203);
    *((int *)(_2+480)) = _11203;
    RefDS(_11204);
    *((int *)(_2+484)) = _11204;
    RefDS(_11205);
    *((int *)(_2+488)) = _11205;
    RefDS(_11206);
    *((int *)(_2+492)) = _11206;
    RefDS(_11207);
    *((int *)(_2+496)) = _11207;
    RefDS(_11208);
    *((int *)(_2+500)) = _11208;
    RefDS(_11209);
    *((int *)(_2+504)) = _11209;
    RefDS(_11210);
    *((int *)(_2+508)) = _11210;
    RefDS(_11211);
    *((int *)(_2+512)) = _11211;
    RefDS(_11212);
    *((int *)(_2+516)) = _11212;
    RefDS(_11213);
    *((int *)(_2+520)) = _11213;
    RefDS(_11214);
    *((int *)(_2+524)) = _11214;
    RefDS(_11215);
    *((int *)(_2+528)) = _11215;
    RefDS(_11216);
    *((int *)(_2+532)) = _11216;
    RefDS(_11217);
    *((int *)(_2+536)) = _11217;
    RefDS(_11218);
    *((int *)(_2+540)) = _11218;
    RefDS(_11219);
    *((int *)(_2+544)) = _11219;
    RefDS(_11220);
    *((int *)(_2+548)) = _11220;
    RefDS(_11221);
    *((int *)(_2+552)) = _11221;
    RefDS(_11222);
    *((int *)(_2+556)) = _11222;
    RefDS(_11223);
    *((int *)(_2+560)) = _11223;
    RefDS(_11224);
    *((int *)(_2+564)) = _11224;
    RefDS(_11225);
    *((int *)(_2+568)) = _11225;
    RefDS(_11226);
    *((int *)(_2+572)) = _11226;
    RefDS(_11227);
    *((int *)(_2+576)) = _11227;
    RefDS(_11228);
    *((int *)(_2+580)) = _11228;
    RefDS(_11229);
    *((int *)(_2+584)) = _11229;
    RefDS(_11230);
    *((int *)(_2+588)) = _11230;
    RefDS(_11231);
    *((int *)(_2+592)) = _11231;
    RefDS(_11232);
    *((int *)(_2+596)) = _11232;
    RefDS(_11233);
    *((int *)(_2+600)) = _11233;
    RefDS(_11234);
    *((int *)(_2+604)) = _11234;
    RefDS(_11235);
    *((int *)(_2+608)) = _11235;
    RefDS(_11236);
    *((int *)(_2+612)) = _11236;
    RefDS(_11237);
    *((int *)(_2+616)) = _11237;
    RefDS(_11238);
    *((int *)(_2+620)) = _11238;
    RefDS(_11239);
    *((int *)(_2+624)) = _11239;
    RefDS(_11240);
    *((int *)(_2+628)) = _11240;
    RefDS(_11241);
    *((int *)(_2+632)) = _11241;
    RefDS(_11242);
    *((int *)(_2+636)) = _11242;
    RefDS(_11243);
    *((int *)(_2+640)) = _11243;
    RefDS(_11244);
    *((int *)(_2+644)) = _11244;
    RefDS(_11245);
    *((int *)(_2+648)) = _11245;
    RefDS(_11246);
    *((int *)(_2+652)) = _11246;
    RefDS(_11247);
    *((int *)(_2+656)) = _11247;
    RefDS(_11248);
    *((int *)(_2+660)) = _11248;
    RefDS(_11249);
    *((int *)(_2+664)) = _11249;
    RefDS(_11250);
    *((int *)(_2+668)) = _11250;
    RefDS(_11251);
    *((int *)(_2+672)) = _11251;
    RefDS(_11252);
    *((int *)(_2+676)) = _11252;
    RefDS(_11253);
    *((int *)(_2+680)) = _11253;
    RefDS(_11254);
    *((int *)(_2+684)) = _11254;
    RefDS(_11255);
    *((int *)(_2+688)) = _11255;
    RefDS(_11256);
    *((int *)(_2+692)) = _11256;
    RefDS(_11257);
    *((int *)(_2+696)) = _11257;
    RefDS(_11258);
    *((int *)(_2+700)) = _11258;
    RefDS(_11259);
    *((int *)(_2+704)) = _11259;
    RefDS(_11260);
    *((int *)(_2+708)) = _11260;
    RefDS(_11261);
    *((int *)(_2+712)) = _11261;
    RefDS(_11262);
    *((int *)(_2+716)) = _11262;
    RefDS(_11263);
    *((int *)(_2+720)) = _11263;
    RefDS(_11264);
    *((int *)(_2+724)) = _11264;
    RefDS(_11265);
    *((int *)(_2+728)) = _11265;
    RefDS(_11266);
    *((int *)(_2+732)) = _11266;
    RefDS(_11267);
    *((int *)(_2+736)) = _11267;
    RefDS(_11268);
    *((int *)(_2+740)) = _11268;
    RefDS(_11269);
    *((int *)(_2+744)) = _11269;
    RefDS(_11270);
    *((int *)(_2+748)) = _11270;
    RefDS(_11271);
    *((int *)(_2+752)) = _11271;
    RefDS(_11272);
    *((int *)(_2+756)) = _11272;
    RefDS(_11273);
    *((int *)(_2+760)) = _11273;
    RefDS(_11274);
    *((int *)(_2+764)) = _11274;
    RefDS(_11275);
    *((int *)(_2+768)) = _11275;
    RefDS(_11276);
    *((int *)(_2+772)) = _11276;
    RefDS(_11277);
    *((int *)(_2+776)) = _11277;
    RefDS(_11278);
    *((int *)(_2+780)) = _11278;
    RefDS(_11279);
    *((int *)(_2+784)) = _11279;
    RefDS(_11280);
    *((int *)(_2+788)) = _11280;
    RefDS(_11281);
    *((int *)(_2+792)) = _11281;
    RefDS(_11282);
    *((int *)(_2+796)) = _11282;
    RefDS(_11283);
    *((int *)(_2+800)) = _11283;
    RefDS(_11284);
    *((int *)(_2+804)) = _11284;
    RefDS(_11285);
    *((int *)(_2+808)) = _11285;
    RefDS(_11286);
    *((int *)(_2+812)) = _11286;
    RefDS(_11287);
    *((int *)(_2+816)) = _11287;
    RefDS(_11288);
    *((int *)(_2+820)) = _11288;
    RefDS(_11289);
    *((int *)(_2+824)) = _11289;
    RefDS(_11290);
    *((int *)(_2+828)) = _11290;
    RefDS(_11291);
    *((int *)(_2+832)) = _11291;
    _42lcid_string_19881 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_11299);
    *((int *)(_2+4)) = _11299;
    RefDS(_11300);
    *((int *)(_2+8)) = _11300;
    RefDS(_11301);
    *((int *)(_2+12)) = _11301;
    RefDS(_11302);
    *((int *)(_2+16)) = _11302;
    RefDS(_11303);
    *((int *)(_2+20)) = _11303;
    RefDS(_11304);
    *((int *)(_2+24)) = _11304;
    RefDS(_11305);
    *((int *)(_2+28)) = _11305;
    RefDS(_11306);
    *((int *)(_2+32)) = _11306;
    RefDS(_11307);
    *((int *)(_2+36)) = _11307;
    RefDS(_11308);
    *((int *)(_2+40)) = _11308;
    RefDS(_11309);
    *((int *)(_2+44)) = _11309;
    RefDS(_11310);
    *((int *)(_2+48)) = _11310;
    RefDS(_11311);
    *((int *)(_2+52)) = _11311;
    RefDS(_11312);
    *((int *)(_2+56)) = _11312;
    RefDS(_11313);
    *((int *)(_2+60)) = _11313;
    RefDS(_11314);
    *((int *)(_2+64)) = _11314;
    RefDS(_11315);
    *((int *)(_2+68)) = _11315;
    RefDS(_11316);
    *((int *)(_2+72)) = _11316;
    RefDS(_11317);
    *((int *)(_2+76)) = _11317;
    RefDS(_11318);
    *((int *)(_2+80)) = _11318;
    RefDS(_11319);
    *((int *)(_2+84)) = _11319;
    RefDS(_11320);
    *((int *)(_2+88)) = _11320;
    RefDS(_11321);
    *((int *)(_2+92)) = _11321;
    RefDS(_11322);
    *((int *)(_2+96)) = _11322;
    RefDS(_11323);
    *((int *)(_2+100)) = _11323;
    RefDS(_11324);
    *((int *)(_2+104)) = _11324;
    RefDS(_11325);
    *((int *)(_2+108)) = _11325;
    RefDS(_11326);
    *((int *)(_2+112)) = _11326;
    RefDS(_11327);
    *((int *)(_2+116)) = _11327;
    RefDS(_11328);
    *((int *)(_2+120)) = _11328;
    RefDS(_11329);
    *((int *)(_2+124)) = _11329;
    RefDS(_11330);
    *((int *)(_2+128)) = _11330;
    RefDS(_11331);
    *((int *)(_2+132)) = _11331;
    RefDS(_11332);
    *((int *)(_2+136)) = _11332;
    RefDS(_11333);
    *((int *)(_2+140)) = _11333;
    RefDS(_11334);
    *((int *)(_2+144)) = _11334;
    RefDS(_11335);
    *((int *)(_2+148)) = _11335;
    RefDS(_11336);
    *((int *)(_2+152)) = _11336;
    RefDS(_11337);
    *((int *)(_2+156)) = _11337;
    RefDS(_11338);
    *((int *)(_2+160)) = _11338;
    RefDS(_11339);
    *((int *)(_2+164)) = _11339;
    RefDS(_11340);
    *((int *)(_2+168)) = _11340;
    RefDS(_11341);
    *((int *)(_2+172)) = _11341;
    RefDS(_11342);
    *((int *)(_2+176)) = _11342;
    RefDS(_11343);
    *((int *)(_2+180)) = _11343;
    RefDS(_11344);
    *((int *)(_2+184)) = _11344;
    RefDS(_11345);
    *((int *)(_2+188)) = _11345;
    RefDS(_11346);
    *((int *)(_2+192)) = _11346;
    RefDS(_11347);
    *((int *)(_2+196)) = _11347;
    RefDS(_11348);
    *((int *)(_2+200)) = _11348;
    RefDS(_11349);
    *((int *)(_2+204)) = _11349;
    RefDS(_11350);
    *((int *)(_2+208)) = _11350;
    RefDS(_11351);
    *((int *)(_2+212)) = _11351;
    RefDS(_11352);
    *((int *)(_2+216)) = _11352;
    RefDS(_11353);
    *((int *)(_2+220)) = _11353;
    RefDS(_11354);
    *((int *)(_2+224)) = _11354;
    RefDS(_11355);
    *((int *)(_2+228)) = _11355;
    RefDS(_11356);
    *((int *)(_2+232)) = _11356;
    RefDS(_11357);
    *((int *)(_2+236)) = _11357;
    RefDS(_11358);
    *((int *)(_2+240)) = _11358;
    RefDS(_11359);
    *((int *)(_2+244)) = _11359;
    RefDS(_11360);
    *((int *)(_2+248)) = _11360;
    RefDS(_11361);
    *((int *)(_2+252)) = _11361;
    RefDS(_11362);
    *((int *)(_2+256)) = _11362;
    RefDS(_11363);
    *((int *)(_2+260)) = _11363;
    RefDS(_11364);
    *((int *)(_2+264)) = _11364;
    RefDS(_11365);
    *((int *)(_2+268)) = _11365;
    RefDS(_11366);
    *((int *)(_2+272)) = _11366;
    RefDS(_11367);
    *((int *)(_2+276)) = _11367;
    RefDS(_11368);
    *((int *)(_2+280)) = _11368;
    RefDS(_11369);
    *((int *)(_2+284)) = _11369;
    RefDS(_11370);
    *((int *)(_2+288)) = _11370;
    RefDS(_11371);
    *((int *)(_2+292)) = _11371;
    RefDS(_11372);
    *((int *)(_2+296)) = _11372;
    RefDS(_11373);
    *((int *)(_2+300)) = _11373;
    RefDS(_11374);
    *((int *)(_2+304)) = _11374;
    RefDS(_11375);
    *((int *)(_2+308)) = _11375;
    RefDS(_11376);
    *((int *)(_2+312)) = _11376;
    RefDS(_11377);
    *((int *)(_2+316)) = _11377;
    RefDS(_11378);
    *((int *)(_2+320)) = _11378;
    RefDS(_11379);
    *((int *)(_2+324)) = _11379;
    RefDS(_11380);
    *((int *)(_2+328)) = _11380;
    RefDS(_11381);
    *((int *)(_2+332)) = _11381;
    RefDS(_11382);
    *((int *)(_2+336)) = _11382;
    RefDS(_11383);
    *((int *)(_2+340)) = _11383;
    RefDS(_11384);
    *((int *)(_2+344)) = _11384;
    RefDS(_11385);
    *((int *)(_2+348)) = _11385;
    RefDS(_11386);
    *((int *)(_2+352)) = _11386;
    RefDS(_11387);
    *((int *)(_2+356)) = _11387;
    RefDS(_11388);
    *((int *)(_2+360)) = _11388;
    RefDS(_11389);
    *((int *)(_2+364)) = _11389;
    RefDS(_11390);
    *((int *)(_2+368)) = _11390;
    RefDS(_11391);
    *((int *)(_2+372)) = _11391;
    RefDS(_11392);
    *((int *)(_2+376)) = _11392;
    RefDS(_11393);
    *((int *)(_2+380)) = _11393;
    RefDS(_11394);
    *((int *)(_2+384)) = _11394;
    RefDS(_11395);
    *((int *)(_2+388)) = _11395;
    RefDS(_11396);
    *((int *)(_2+392)) = _11396;
    RefDS(_11397);
    *((int *)(_2+396)) = _11397;
    RefDS(_11398);
    *((int *)(_2+400)) = _11398;
    RefDS(_11399);
    *((int *)(_2+404)) = _11399;
    RefDS(_11400);
    *((int *)(_2+408)) = _11400;
    RefDS(_11401);
    *((int *)(_2+412)) = _11401;
    RefDS(_11402);
    *((int *)(_2+416)) = _11402;
    RefDS(_11403);
    *((int *)(_2+420)) = _11403;
    RefDS(_11404);
    *((int *)(_2+424)) = _11404;
    RefDS(_11405);
    *((int *)(_2+428)) = _11405;
    RefDS(_11406);
    *((int *)(_2+432)) = _11406;
    RefDS(_11407);
    *((int *)(_2+436)) = _11407;
    RefDS(_11408);
    *((int *)(_2+440)) = _11408;
    RefDS(_11409);
    *((int *)(_2+444)) = _11409;
    RefDS(_11410);
    *((int *)(_2+448)) = _11410;
    RefDS(_11411);
    *((int *)(_2+452)) = _11411;
    RefDS(_11412);
    *((int *)(_2+456)) = _11412;
    RefDS(_11413);
    *((int *)(_2+460)) = _11413;
    RefDS(_11414);
    *((int *)(_2+464)) = _11414;
    RefDS(_11415);
    *((int *)(_2+468)) = _11415;
    RefDS(_11416);
    *((int *)(_2+472)) = _11416;
    RefDS(_11417);
    *((int *)(_2+476)) = _11417;
    RefDS(_11418);
    *((int *)(_2+480)) = _11418;
    RefDS(_11419);
    *((int *)(_2+484)) = _11419;
    RefDS(_11420);
    *((int *)(_2+488)) = _11420;
    RefDS(_11421);
    *((int *)(_2+492)) = _11421;
    RefDS(_11422);
    *((int *)(_2+496)) = _11422;
    RefDS(_11423);
    *((int *)(_2+500)) = _11423;
    RefDS(_11424);
    *((int *)(_2+504)) = _11424;
    RefDS(_11425);
    *((int *)(_2+508)) = _11425;
    RefDS(_11426);
    *((int *)(_2+512)) = _11426;
    RefDS(_11427);
    *((int *)(_2+516)) = _11427;
    RefDS(_11428);
    *((int *)(_2+520)) = _11428;
    RefDS(_11429);
    *((int *)(_2+524)) = _11429;
    RefDS(_11430);
    *((int *)(_2+528)) = _11430;
    RefDS(_11431);
    *((int *)(_2+532)) = _11431;
    RefDS(_11432);
    *((int *)(_2+536)) = _11432;
    RefDS(_11433);
    *((int *)(_2+540)) = _11433;
    RefDS(_11434);
    *((int *)(_2+544)) = _11434;
    RefDS(_11435);
    *((int *)(_2+548)) = _11435;
    RefDS(_11436);
    *((int *)(_2+552)) = _11436;
    RefDS(_11437);
    *((int *)(_2+556)) = _11437;
    RefDS(_11438);
    *((int *)(_2+560)) = _11438;
    RefDS(_11439);
    *((int *)(_2+564)) = _11439;
    RefDS(_11440);
    *((int *)(_2+568)) = _11440;
    RefDS(_11441);
    *((int *)(_2+572)) = _11441;
    RefDS(_11442);
    *((int *)(_2+576)) = _11442;
    RefDS(_11443);
    *((int *)(_2+580)) = _11443;
    RefDS(_11444);
    *((int *)(_2+584)) = _11444;
    RefDS(_11445);
    *((int *)(_2+588)) = _11445;
    RefDS(_11446);
    *((int *)(_2+592)) = _11446;
    RefDS(_11447);
    *((int *)(_2+596)) = _11447;
    RefDS(_11448);
    *((int *)(_2+600)) = _11448;
    RefDS(_11449);
    *((int *)(_2+604)) = _11449;
    RefDS(_11450);
    *((int *)(_2+608)) = _11450;
    RefDS(_11451);
    *((int *)(_2+612)) = _11451;
    RefDS(_11452);
    *((int *)(_2+616)) = _11452;
    RefDS(_11453);
    *((int *)(_2+620)) = _11453;
    RefDS(_11454);
    *((int *)(_2+624)) = _11454;
    RefDS(_11455);
    *((int *)(_2+628)) = _11455;
    RefDS(_11456);
    *((int *)(_2+632)) = _11456;
    RefDS(_11457);
    *((int *)(_2+636)) = _11457;
    RefDS(_11458);
    *((int *)(_2+640)) = _11458;
    RefDS(_11459);
    *((int *)(_2+644)) = _11459;
    RefDS(_11460);
    *((int *)(_2+648)) = _11460;
    RefDS(_11461);
    *((int *)(_2+652)) = _11461;
    RefDS(_11462);
    *((int *)(_2+656)) = _11462;
    RefDS(_11463);
    *((int *)(_2+660)) = _11463;
    RefDS(_11464);
    *((int *)(_2+664)) = _11464;
    RefDS(_11465);
    *((int *)(_2+668)) = _11465;
    RefDS(_11466);
    *((int *)(_2+672)) = _11466;
    RefDS(_11467);
    *((int *)(_2+676)) = _11467;
    RefDS(_11468);
    *((int *)(_2+680)) = _11468;
    RefDS(_11469);
    *((int *)(_2+684)) = _11469;
    RefDS(_11470);
    *((int *)(_2+688)) = _11470;
    RefDS(_11471);
    *((int *)(_2+692)) = _11471;
    RefDS(_11472);
    *((int *)(_2+696)) = _11472;
    RefDS(_11473);
    *((int *)(_2+700)) = _11473;
    RefDS(_11474);
    *((int *)(_2+704)) = _11474;
    RefDS(_11475);
    *((int *)(_2+708)) = _11475;
    RefDS(_11476);
    *((int *)(_2+712)) = _11476;
    RefDS(_11477);
    *((int *)(_2+716)) = _11477;
    RefDS(_11478);
    *((int *)(_2+720)) = _11478;
    RefDS(_11479);
    *((int *)(_2+724)) = _11479;
    RefDS(_11480);
    *((int *)(_2+728)) = _11480;
    RefDS(_11481);
    *((int *)(_2+732)) = _11481;
    RefDS(_11482);
    *((int *)(_2+736)) = _11482;
    RefDS(_11483);
    *((int *)(_2+740)) = _11483;
    RefDS(_11484);
    *((int *)(_2+744)) = _11484;
    RefDS(_11485);
    *((int *)(_2+748)) = _11485;
    RefDS(_11486);
    *((int *)(_2+752)) = _11486;
    RefDS(_11487);
    *((int *)(_2+756)) = _11487;
    RefDS(_11488);
    *((int *)(_2+760)) = _11488;
    RefDS(_11489);
    *((int *)(_2+764)) = _11489;
    RefDS(_11490);
    *((int *)(_2+768)) = _11490;
    RefDS(_11491);
    *((int *)(_2+772)) = _11491;
    RefDS(_11492);
    *((int *)(_2+776)) = _11492;
    RefDS(_11493);
    *((int *)(_2+780)) = _11493;
    RefDS(_11494);
    *((int *)(_2+784)) = _11494;
    RefDS(_11495);
    *((int *)(_2+788)) = _11495;
    RefDS(_11496);
    *((int *)(_2+792)) = _11496;
    RefDS(_11497);
    *((int *)(_2+796)) = _11497;
    RefDS(_11498);
    *((int *)(_2+800)) = _11498;
    RefDS(_11499);
    *((int *)(_2+804)) = _11499;
    RefDS(_11500);
    *((int *)(_2+808)) = _11500;
    RefDS(_11501);
    *((int *)(_2+812)) = _11501;
    RefDS(_11502);
    *((int *)(_2+816)) = _11502;
    RefDS(_11503);
    *((int *)(_2+820)) = _11503;
    RefDS(_11504);
    *((int *)(_2+824)) = _11504;
    RefDS(_11505);
    *((int *)(_2+828)) = _11505;
    RefDS(_11506);
    *((int *)(_2+832)) = _11506;
    _44w32_names_20112 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RepeatElem(_2+4, _11508, 24);
    RefDSn(_11509, 2);
    *((int *)(_2+100)) = _11509;
    *((int *)(_2+104)) = _11509;
    RefDSn(_11510, 6);
    *((int *)(_2+108)) = _11510;
    *((int *)(_2+112)) = _11510;
    *((int *)(_2+116)) = _11510;
    *((int *)(_2+120)) = _11510;
    *((int *)(_2+124)) = _11510;
    *((int *)(_2+128)) = _11510;
    RepeatElem(_2+132, _11511, 10);
    RefDSn(_11512, 5);
    *((int *)(_2+172)) = _11512;
    *((int *)(_2+176)) = _11512;
    *((int *)(_2+180)) = _11512;
    *((int *)(_2+184)) = _11512;
    *((int *)(_2+188)) = _11512;
    RefDS(_11513);
    *((int *)(_2+192)) = _11513;
    RepeatElem(_2+196, _11514, 15);
    RefDS(_11515);
    *((int *)(_2+256)) = _11515;
    RefDSn(_11514, 2);
    *((int *)(_2+260)) = _11514;
    *((int *)(_2+264)) = _11514;
    RefDS(_11516);
    *((int *)(_2+268)) = _11516;
    RepeatElem(_2+272, _11517, 20);
    RefDSn(_11518, 7);
    *((int *)(_2+352)) = _11518;
    *((int *)(_2+356)) = _11518;
    *((int *)(_2+360)) = _11518;
    *((int *)(_2+364)) = _11518;
    *((int *)(_2+368)) = _11518;
    *((int *)(_2+372)) = _11518;
    *((int *)(_2+376)) = _11518;
    RepeatElem(_2+380, _11519, 42);
    RefDSn(_11520, 2);
    *((int *)(_2+548)) = _11520;
    *((int *)(_2+552)) = _11520;
    RefDSn(_11521, 4);
    *((int *)(_2+556)) = _11521;
    *((int *)(_2+560)) = _11521;
    *((int *)(_2+564)) = _11521;
    *((int *)(_2+568)) = _11521;
    RepeatElem(_2+572, _11522, 15);
    RefDS(_11523);
    *((int *)(_2+632)) = _11523;
    RepeatElem(_2+636, _11515, 16);
    RefDS(_11524);
    *((int *)(_2+700)) = _11524;
    RefDSn(_11515, 4);
    *((int *)(_2+704)) = _11515;
    *((int *)(_2+708)) = _11515;
    *((int *)(_2+712)) = _11515;
    *((int *)(_2+716)) = _11515;
    RepeatElem(_2+720, _11525, 15);
    RepeatElem(_2+780, _11526, 14);
    _44w32_name_canonical_20322 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_11084);
    *((int *)(_2+4)) = _11084;
    RefDS(_11085);
    *((int *)(_2+8)) = _11085;
    RefDS(_11086);
    *((int *)(_2+12)) = _11086;
    RefDS(_11087);
    *((int *)(_2+16)) = _11087;
    RefDS(_11088);
    *((int *)(_2+20)) = _11088;
    RefDS(_11089);
    *((int *)(_2+24)) = _11089;
    RefDS(_11090);
    *((int *)(_2+28)) = _11090;
    RefDS(_11091);
    *((int *)(_2+32)) = _11091;
    RefDS(_11092);
    *((int *)(_2+36)) = _11092;
    RefDS(_11093);
    *((int *)(_2+40)) = _11093;
    RefDS(_11094);
    *((int *)(_2+44)) = _11094;
    RefDS(_11095);
    *((int *)(_2+48)) = _11095;
    RefDS(_11096);
    *((int *)(_2+52)) = _11096;
    RefDS(_11097);
    *((int *)(_2+56)) = _11097;
    RefDS(_11098);
    *((int *)(_2+60)) = _11098;
    RefDS(_11099);
    *((int *)(_2+64)) = _11099;
    RefDS(_11100);
    *((int *)(_2+68)) = _11100;
    RefDS(_11101);
    *((int *)(_2+72)) = _11101;
    RefDS(_11102);
    *((int *)(_2+76)) = _11102;
    RefDS(_11103);
    *((int *)(_2+80)) = _11103;
    RefDS(_11104);
    *((int *)(_2+84)) = _11104;
    RefDS(_11105);
    *((int *)(_2+88)) = _11105;
    RefDS(_11106);
    *((int *)(_2+92)) = _11106;
    RefDS(_11107);
    *((int *)(_2+96)) = _11107;
    RefDS(_11108);
    *((int *)(_2+100)) = _11108;
    RefDS(_11109);
    *((int *)(_2+104)) = _11109;
    RefDS(_11110);
    *((int *)(_2+108)) = _11110;
    RefDS(_11111);
    *((int *)(_2+112)) = _11111;
    RefDS(_11112);
    *((int *)(_2+116)) = _11112;
    RefDS(_11113);
    *((int *)(_2+120)) = _11113;
    RefDS(_11114);
    *((int *)(_2+124)) = _11114;
    RefDS(_11115);
    *((int *)(_2+128)) = _11115;
    RefDS(_11116);
    *((int *)(_2+132)) = _11116;
    RefDS(_11117);
    *((int *)(_2+136)) = _11117;
    RefDS(_11118);
    *((int *)(_2+140)) = _11118;
    RefDS(_11119);
    *((int *)(_2+144)) = _11119;
    RefDS(_11120);
    *((int *)(_2+148)) = _11120;
    RefDS(_11121);
    *((int *)(_2+152)) = _11121;
    RefDS(_11528);
    *((int *)(_2+156)) = _11528;
    RefDS(_11122);
    *((int *)(_2+160)) = _11122;
    RefDS(_11123);
    *((int *)(_2+164)) = _11123;
    RefDS(_11124);
    *((int *)(_2+168)) = _11124;
    RefDS(_11125);
    *((int *)(_2+172)) = _11125;
    RefDS(_11126);
    *((int *)(_2+176)) = _11126;
    RefDS(_11127);
    *((int *)(_2+180)) = _11127;
    RefDS(_11128);
    *((int *)(_2+184)) = _11128;
    RefDS(_11129);
    *((int *)(_2+188)) = _11129;
    RefDS(_11130);
    *((int *)(_2+192)) = _11130;
    RefDS(_11131);
    *((int *)(_2+196)) = _11131;
    RefDS(_11132);
    *((int *)(_2+200)) = _11132;
    RefDS(_11133);
    *((int *)(_2+204)) = _11133;
    RefDS(_11134);
    *((int *)(_2+208)) = _11134;
    RefDS(_11135);
    *((int *)(_2+212)) = _11135;
    RefDS(_11136);
    *((int *)(_2+216)) = _11136;
    RefDS(_11137);
    *((int *)(_2+220)) = _11137;
    RefDS(_11138);
    *((int *)(_2+224)) = _11138;
    RefDS(_11139);
    *((int *)(_2+228)) = _11139;
    RefDS(_11140);
    *((int *)(_2+232)) = _11140;
    RefDS(_11141);
    *((int *)(_2+236)) = _11141;
    RefDS(_11142);
    *((int *)(_2+240)) = _11142;
    RefDS(_11143);
    *((int *)(_2+244)) = _11143;
    RefDS(_11144);
    *((int *)(_2+248)) = _11144;
    RefDS(_11145);
    *((int *)(_2+252)) = _11145;
    RefDS(_11146);
    *((int *)(_2+256)) = _11146;
    RefDS(_11147);
    *((int *)(_2+260)) = _11147;
    RefDS(_11148);
    *((int *)(_2+264)) = _11148;
    RefDS(_11149);
    *((int *)(_2+268)) = _11149;
    RefDS(_11150);
    *((int *)(_2+272)) = _11150;
    RefDS(_11151);
    *((int *)(_2+276)) = _11151;
    RefDS(_11152);
    *((int *)(_2+280)) = _11152;
    RefDS(_11153);
    *((int *)(_2+284)) = _11153;
    RefDS(_11154);
    *((int *)(_2+288)) = _11154;
    RefDS(_11155);
    *((int *)(_2+292)) = _11155;
    RefDS(_11156);
    *((int *)(_2+296)) = _11156;
    RefDS(_11157);
    *((int *)(_2+300)) = _11157;
    RefDS(_11158);
    *((int *)(_2+304)) = _11158;
    RefDS(_11159);
    *((int *)(_2+308)) = _11159;
    RefDS(_11160);
    *((int *)(_2+312)) = _11160;
    RefDS(_11161);
    *((int *)(_2+316)) = _11161;
    RefDS(_11162);
    *((int *)(_2+320)) = _11162;
    RefDS(_11163);
    *((int *)(_2+324)) = _11163;
    RefDS(_11164);
    *((int *)(_2+328)) = _11164;
    RefDS(_11165);
    *((int *)(_2+332)) = _11165;
    RefDS(_11166);
    *((int *)(_2+336)) = _11166;
    RefDS(_11167);
    *((int *)(_2+340)) = _11167;
    RefDS(_11168);
    *((int *)(_2+344)) = _11168;
    RefDS(_11169);
    *((int *)(_2+348)) = _11169;
    RefDS(_11170);
    *((int *)(_2+352)) = _11170;
    RefDS(_11171);
    *((int *)(_2+356)) = _11171;
    RefDS(_11172);
    *((int *)(_2+360)) = _11172;
    RefDS(_11173);
    *((int *)(_2+364)) = _11173;
    RefDS(_11174);
    *((int *)(_2+368)) = _11174;
    RefDS(_11175);
    *((int *)(_2+372)) = _11175;
    RefDS(_11176);
    *((int *)(_2+376)) = _11176;
    RefDS(_11177);
    *((int *)(_2+380)) = _11177;
    RefDS(_11178);
    *((int *)(_2+384)) = _11178;
    RefDS(_11179);
    *((int *)(_2+388)) = _11179;
    RefDS(_11180);
    *((int *)(_2+392)) = _11180;
    RefDS(_11181);
    *((int *)(_2+396)) = _11181;
    RefDS(_11182);
    *((int *)(_2+400)) = _11182;
    RefDS(_11183);
    *((int *)(_2+404)) = _11183;
    RefDS(_11184);
    *((int *)(_2+408)) = _11184;
    RefDS(_11185);
    *((int *)(_2+412)) = _11185;
    RefDS(_11186);
    *((int *)(_2+416)) = _11186;
    RefDS(_11187);
    *((int *)(_2+420)) = _11187;
    RefDS(_11188);
    *((int *)(_2+424)) = _11188;
    RefDS(_11189);
    *((int *)(_2+428)) = _11189;
    RefDS(_11190);
    *((int *)(_2+432)) = _11190;
    RefDS(_11191);
    *((int *)(_2+436)) = _11191;
    RefDS(_11192);
    *((int *)(_2+440)) = _11192;
    RefDS(_11193);
    *((int *)(_2+444)) = _11193;
    RefDS(_11194);
    *((int *)(_2+448)) = _11194;
    RefDS(_11195);
    *((int *)(_2+452)) = _11195;
    RefDS(_11196);
    *((int *)(_2+456)) = _11196;
    RefDS(_11197);
    *((int *)(_2+460)) = _11197;
    RefDS(_11198);
    *((int *)(_2+464)) = _11198;
    RefDS(_11199);
    *((int *)(_2+468)) = _11199;
    RefDS(_11200);
    *((int *)(_2+472)) = _11200;
    RefDS(_11201);
    *((int *)(_2+476)) = _11201;
    RefDS(_11202);
    *((int *)(_2+480)) = _11202;
    RefDS(_11203);
    *((int *)(_2+484)) = _11203;
    RefDS(_11204);
    *((int *)(_2+488)) = _11204;
    RefDS(_11205);
    *((int *)(_2+492)) = _11205;
    RefDS(_11206);
    *((int *)(_2+496)) = _11206;
    RefDS(_11207);
    *((int *)(_2+500)) = _11207;
    RefDS(_11208);
    *((int *)(_2+504)) = _11208;
    RefDS(_11209);
    *((int *)(_2+508)) = _11209;
    RefDS(_11210);
    *((int *)(_2+512)) = _11210;
    RefDS(_11211);
    *((int *)(_2+516)) = _11211;
    RefDS(_11212);
    *((int *)(_2+520)) = _11212;
    RefDS(_11213);
    *((int *)(_2+524)) = _11213;
    RefDS(_11214);
    *((int *)(_2+528)) = _11214;
    RefDS(_11215);
    *((int *)(_2+532)) = _11215;
    RefDS(_11216);
    *((int *)(_2+536)) = _11216;
    RefDS(_11217);
    *((int *)(_2+540)) = _11217;
    RefDS(_11218);
    *((int *)(_2+544)) = _11218;
    RefDS(_11219);
    *((int *)(_2+548)) = _11219;
    RefDS(_11220);
    *((int *)(_2+552)) = _11220;
    RefDS(_11221);
    *((int *)(_2+556)) = _11221;
    RefDS(_11222);
    *((int *)(_2+560)) = _11222;
    RefDS(_11223);
    *((int *)(_2+564)) = _11223;
    RefDS(_11224);
    *((int *)(_2+568)) = _11224;
    RefDS(_11225);
    *((int *)(_2+572)) = _11225;
    RefDS(_11226);
    *((int *)(_2+576)) = _11226;
    RefDS(_11227);
    *((int *)(_2+580)) = _11227;
    RefDS(_11228);
    *((int *)(_2+584)) = _11228;
    RefDS(_11229);
    *((int *)(_2+588)) = _11229;
    RefDS(_11230);
    *((int *)(_2+592)) = _11230;
    RefDS(_11231);
    *((int *)(_2+596)) = _11231;
    RefDS(_11232);
    *((int *)(_2+600)) = _11232;
    RefDS(_11233);
    *((int *)(_2+604)) = _11233;
    RefDS(_11234);
    *((int *)(_2+608)) = _11234;
    RefDS(_11235);
    *((int *)(_2+612)) = _11235;
    RefDS(_11236);
    *((int *)(_2+616)) = _11236;
    RefDS(_11237);
    *((int *)(_2+620)) = _11237;
    RefDS(_11238);
    *((int *)(_2+624)) = _11238;
    RefDS(_11239);
    *((int *)(_2+628)) = _11239;
    RefDS(_11240);
    *((int *)(_2+632)) = _11240;
    RefDS(_11241);
    *((int *)(_2+636)) = _11241;
    RefDS(_11242);
    *((int *)(_2+640)) = _11242;
    RefDS(_11243);
    *((int *)(_2+644)) = _11243;
    RefDS(_11244);
    *((int *)(_2+648)) = _11244;
    RefDS(_11245);
    *((int *)(_2+652)) = _11245;
    RefDS(_11246);
    *((int *)(_2+656)) = _11246;
    RefDS(_11247);
    *((int *)(_2+660)) = _11247;
    RefDS(_11248);
    *((int *)(_2+664)) = _11248;
    RefDS(_11249);
    *((int *)(_2+668)) = _11249;
    RefDS(_11250);
    *((int *)(_2+672)) = _11250;
    RefDS(_11251);
    *((int *)(_2+676)) = _11251;
    RefDS(_11252);
    *((int *)(_2+680)) = _11252;
    RefDS(_11253);
    *((int *)(_2+684)) = _11253;
    RefDS(_11254);
    *((int *)(_2+688)) = _11254;
    RefDS(_11255);
    *((int *)(_2+692)) = _11255;
    RefDS(_11256);
    *((int *)(_2+696)) = _11256;
    RefDS(_11257);
    *((int *)(_2+700)) = _11257;
    RefDS(_11258);
    *((int *)(_2+704)) = _11258;
    RefDS(_11259);
    *((int *)(_2+708)) = _11259;
    RefDS(_11260);
    *((int *)(_2+712)) = _11260;
    RefDS(_11261);
    *((int *)(_2+716)) = _11261;
    RefDS(_11262);
    *((int *)(_2+720)) = _11262;
    RefDS(_11263);
    *((int *)(_2+724)) = _11263;
    RefDS(_11264);
    *((int *)(_2+728)) = _11264;
    RefDS(_11265);
    *((int *)(_2+732)) = _11265;
    RefDS(_11266);
    *((int *)(_2+736)) = _11266;
    RefDS(_11267);
    *((int *)(_2+740)) = _11267;
    RefDS(_11268);
    *((int *)(_2+744)) = _11268;
    RefDS(_11269);
    *((int *)(_2+748)) = _11269;
    RefDS(_11270);
    *((int *)(_2+752)) = _11270;
    RefDS(_11271);
    *((int *)(_2+756)) = _11271;
    RefDS(_11272);
    *((int *)(_2+760)) = _11272;
    RefDS(_11273);
    *((int *)(_2+764)) = _11273;
    RefDS(_11274);
    *((int *)(_2+768)) = _11274;
    RefDS(_11275);
    *((int *)(_2+772)) = _11275;
    RefDS(_11276);
    *((int *)(_2+776)) = _11276;
    RefDS(_11277);
    *((int *)(_2+780)) = _11277;
    RefDS(_11278);
    *((int *)(_2+784)) = _11278;
    RefDS(_11279);
    *((int *)(_2+788)) = _11279;
    RefDS(_11280);
    *((int *)(_2+792)) = _11280;
    RefDS(_11281);
    *((int *)(_2+796)) = _11281;
    RefDS(_11282);
    *((int *)(_2+800)) = _11282;
    RefDS(_11283);
    *((int *)(_2+804)) = _11283;
    RefDS(_11284);
    *((int *)(_2+808)) = _11284;
    RefDS(_11285);
    *((int *)(_2+812)) = _11285;
    RefDS(_11286);
    *((int *)(_2+816)) = _11286;
    RefDS(_11287);
    *((int *)(_2+820)) = _11287;
    RefDS(_11288);
    *((int *)(_2+824)) = _11288;
    RefDS(_11289);
    *((int *)(_2+828)) = _11289;
    RefDS(_11290);
    *((int *)(_2+832)) = _11290;
    _44posix_names_20343 = MAKE_SEQ(_1);
    RefDS(_44posix_names_20343);
    _44locale_canonical_20346 = _44posix_names_20343;

    /** ifdef UNIX then*/
    RefDS(_44w32_name_canonical_20322);
    _44platform_locale_20347 = _44w32_name_canonical_20322;
    DeRef1(_43def_lang_20419);
    _43def_lang_20419 = 0;
    DeRef1(_43lang_path_20420);
    _43lang_path_20420 = 0;

    /** ifdef WINDOWS then*/
    RefDS(_11654);
    _43lib_20575 = _13open_dll(_11654);
    RefDS(_11656);
    _43lib2_20579 = _13open_dll(_11656);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    *((int *)(_2+8)) = 16777220;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 33554436;
    *((int *)(_2+24)) = 16777220;
    _11659 = MAKE_SEQ(_1);
    Ref(_43lib2_20579);
    RefDS(_11658);
    _43f_strfmon_20583 = _13define_c_func(_43lib2_20579, _11658, _11659, 16777220);
    _11659 = NOVALUE;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    *((int *)(_2+8)) = 16777220;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 33554436;
    *((int *)(_2+24)) = 16777220;
    _11662 = MAKE_SEQ(_1);
    Ref(_43lib2_20579);
    RefDS(_11661);
    _43f_strfnum_20588 = _13define_c_func(_43lib2_20579, _11661, _11662, 16777220);
    _11662 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777220;
    ((int *)_2)[2] = 33554436;
    _11665 = MAKE_SEQ(_1);
    Ref(_43lib_20575);
    RefDS(_11664);
    _43f_setlocale_20593 = _13define_c_func(_43lib_20575, _11664, _11665, 33554436);
    _11665 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 16777220;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _11668 = MAKE_SEQ(_1);
    Ref(_43lib_20575);
    RefDS(_11667);
    _43f_strftime_20598 = _13define_c_func(_43lib_20575, _11667, _11668, 16777220);
    _11668 = NOVALUE;
    RefDS(_5);
    DeRef1(_43current_locale_20606);
    _43current_locale_20606 = _5;

    /** ifdef WINDOWS then*/
    RefDS(_11826);
    _46kernel32_20920 = _13open_dll(_11826);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _11829 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11828);
    _46iCreatePipe_20923 = _13define_c_func(_46kernel32_20920, _11828, _11829, 16777220);
    _11829 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 33554436;
    _11832 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11831);
    _46iReadFile_20927 = _13define_c_func(_46kernel32_20920, _11831, _11832, 16777220);
    _11832 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 33554436;
    _11835 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11834);
    _46iWriteFile_20931 = _13define_c_func(_46kernel32_20920, _11834, _11835, 16777220);
    _11835 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _11838 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11837);
    _46iCloseHandle_20935 = _13define_c_func(_46kernel32_20920, _11837, _11838, 16777220);
    _11838 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _11841 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11840);
    _46iTerminateProcess_20939 = _13define_c_func(_46kernel32_20920, _11840, _11841, 16777220);
    _11841 = NOVALUE;
    Ref(_46kernel32_20920);
    RefDS(_11843);
    RefDS(_5);
    _46iGetLastError_20943 = _13define_c_func(_46kernel32_20920, _11843, _5, 33554436);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _11846 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11845);
    _46iGetStdHandle_20946 = _13define_c_func(_46kernel32_20920, _11845, _11846, 33554436);
    _11846 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    _11849 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11848);
    _46iSetHandleInformation_20950 = _13define_c_func(_46kernel32_20920, _11848, _11849, 16777220);
    _11849 = NOVALUE;
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    *((int *)(_2+20)) = 16777220;
    *((int *)(_2+24)) = 33554436;
    *((int *)(_2+28)) = 33554436;
    *((int *)(_2+32)) = 33554436;
    *((int *)(_2+36)) = 33554436;
    *((int *)(_2+40)) = 33554436;
    _11852 = MAKE_SEQ(_1);
    Ref(_46kernel32_20920);
    RefDS(_11851);
    _46iCreateProcess_20954 = _13define_c_func(_46kernel32_20920, _11851, _11852, 16777220);
    _11852 = NOVALUE;
    DeRef1(_46os_errno_20985);
    _46os_errno_20985 = 0;

    /** ifdef WINDOWS then*/
    RefDS(_11977);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _11977;
    _11978 = MAKE_SEQ(_1);
    RefDS(_11979);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _11979;
    _11980 = MAKE_SEQ(_1);
    RefDS(_11981);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _11981;
    _11982 = MAKE_SEQ(_1);
    RefDS(_11983);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _11983;
    _11984 = MAKE_SEQ(_1);
    RefDS(_11985);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8;
    ((int *)_2)[2] = _11985;
    _11986 = MAKE_SEQ(_1);
    RefDS(_11987);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16;
    ((int *)_2)[2] = _11987;
    _11988 = MAKE_SEQ(_1);
    RefDS(_11989);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 32;
    ((int *)_2)[2] = _11989;
    _11990 = MAKE_SEQ(_1);
    RefDS(_11991);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 64;
    ((int *)_2)[2] = _11991;
    _11992 = MAKE_SEQ(_1);
    RefDS(_11993);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 128;
    ((int *)_2)[2] = _11993;
    _11994 = MAKE_SEQ(_1);
    RefDS(_11995);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 256;
    ((int *)_2)[2] = _11995;
    _11996 = MAKE_SEQ(_1);
    RefDS(_11997);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 512;
    ((int *)_2)[2] = _11997;
    _11998 = MAKE_SEQ(_1);
    RefDS(_11999);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1024;
    ((int *)_2)[2] = _11999;
    _12000 = MAKE_SEQ(_1);
    RefDS(_12001);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2048;
    ((int *)_2)[2] = _12001;
    _12002 = MAKE_SEQ(_1);
    RefDS(_12003);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4096;
    ((int *)_2)[2] = _12003;
    _12004 = MAKE_SEQ(_1);
    RefDS(_12005);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8192;
    ((int *)_2)[2] = _12005;
    _12006 = MAKE_SEQ(_1);
    RefDS(_12007);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16384;
    ((int *)_2)[2] = _12007;
    _12008 = MAKE_SEQ(_1);
    RefDS(_12009);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 32768;
    ((int *)_2)[2] = _12009;
    _12010 = MAKE_SEQ(_1);
    RefDS(_12011);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 65536;
    ((int *)_2)[2] = _12011;
    _12012 = MAKE_SEQ(_1);
    RefDS(_12013);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 131072;
    ((int *)_2)[2] = _12013;
    _12014 = MAKE_SEQ(_1);
    RefDS(_12015);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 262144;
    ((int *)_2)[2] = _12015;
    _12016 = MAKE_SEQ(_1);
    RefDS(_12017);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 524288;
    ((int *)_2)[2] = _12017;
    _12018 = MAKE_SEQ(_1);
    RefDS(_12019);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1048576;
    ((int *)_2)[2] = _12019;
    _12020 = MAKE_SEQ(_1);
    RefDS(_12021);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2097152;
    ((int *)_2)[2] = _12021;
    _12022 = MAKE_SEQ(_1);
    RefDS(_12023);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3145728;
    ((int *)_2)[2] = _12023;
    _12024 = MAKE_SEQ(_1);
    RefDS(_12025);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4194304;
    ((int *)_2)[2] = _12025;
    _12026 = MAKE_SEQ(_1);
    RefDS(_12027);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5242880;
    ((int *)_2)[2] = _12027;
    _12028 = MAKE_SEQ(_1);
    RefDS(_12029);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8388608;
    ((int *)_2)[2] = _12029;
    _12030 = MAKE_SEQ(_1);
    RefDS(_12031);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777216;
    ((int *)_2)[2] = _12031;
    _12032 = MAKE_SEQ(_1);
    RefDS(_12033);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 201326592;
    ((int *)_2)[2] = _12033;
    _12034 = MAKE_SEQ(_1);
    _1 = NewS1(29);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _11978;
    *((int *)(_2+8)) = _11980;
    *((int *)(_2+12)) = _11982;
    *((int *)(_2+16)) = _11984;
    *((int *)(_2+20)) = _11986;
    *((int *)(_2+24)) = _11988;
    *((int *)(_2+28)) = _11990;
    *((int *)(_2+32)) = _11992;
    *((int *)(_2+36)) = _11994;
    *((int *)(_2+40)) = _11996;
    *((int *)(_2+44)) = _11998;
    *((int *)(_2+48)) = _12000;
    *((int *)(_2+52)) = _12002;
    *((int *)(_2+56)) = _12004;
    *((int *)(_2+60)) = _12006;
    *((int *)(_2+64)) = _12008;
    *((int *)(_2+68)) = _12010;
    *((int *)(_2+72)) = _12012;
    *((int *)(_2+76)) = _12014;
    *((int *)(_2+80)) = _12016;
    *((int *)(_2+84)) = _12018;
    *((int *)(_2+88)) = _12020;
    *((int *)(_2+92)) = _12022;
    *((int *)(_2+96)) = _12024;
    *((int *)(_2+100)) = _12026;
    *((int *)(_2+104)) = _12028;
    *((int *)(_2+108)) = _12030;
    *((int *)(_2+112)) = _12032;
    *((int *)(_2+116)) = _12034;
    _47option_names_21264 = MAKE_SEQ(_1);
    _12034 = NOVALUE;
    _12032 = NOVALUE;
    _12030 = NOVALUE;
    _12028 = NOVALUE;
    _12026 = NOVALUE;
    _12024 = NOVALUE;
    _12022 = NOVALUE;
    _12020 = NOVALUE;
    _12018 = NOVALUE;
    _12016 = NOVALUE;
    _12014 = NOVALUE;
    _12012 = NOVALUE;
    _12010 = NOVALUE;
    _12008 = NOVALUE;
    _12006 = NOVALUE;
    _12004 = NOVALUE;
    _12002 = NOVALUE;
    _12000 = NOVALUE;
    _11998 = NOVALUE;
    _11996 = NOVALUE;
    _11994 = NOVALUE;
    _11992 = NOVALUE;
    _11990 = NOVALUE;
    _11988 = NOVALUE;
    _11986 = NOVALUE;
    _11984 = NOVALUE;
    _11982 = NOVALUE;
    _11980 = NOVALUE;
    _11978 = NOVALUE;
    RefDS(_12052);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _12052;
    _12053 = MAKE_SEQ(_1);
    RefDS(_12054);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _12054;
    _12055 = MAKE_SEQ(_1);
    RefDS(_12056);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -3;
    ((int *)_2)[2] = _12056;
    _12057 = MAKE_SEQ(_1);
    RefDS(_12058);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -4;
    ((int *)_2)[2] = _12058;
    _12059 = MAKE_SEQ(_1);
    RefDS(_12060);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -5;
    ((int *)_2)[2] = _12060;
    _12061 = MAKE_SEQ(_1);
    RefDS(_12060);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -5;
    ((int *)_2)[2] = _12060;
    _12062 = MAKE_SEQ(_1);
    RefDS(_12063);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -6;
    ((int *)_2)[2] = _12063;
    _12064 = MAKE_SEQ(_1);
    RefDS(_12065);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -7;
    ((int *)_2)[2] = _12065;
    _12066 = MAKE_SEQ(_1);
    RefDS(_12067);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -8;
    ((int *)_2)[2] = _12067;
    _12068 = MAKE_SEQ(_1);
    RefDS(_12069);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -9;
    ((int *)_2)[2] = _12069;
    _12070 = MAKE_SEQ(_1);
    RefDS(_12071);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -10;
    ((int *)_2)[2] = _12071;
    _12072 = MAKE_SEQ(_1);
    RefDS(_12073);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -11;
    ((int *)_2)[2] = _12073;
    _12074 = MAKE_SEQ(_1);
    RefDS(_12075);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -12;
    ((int *)_2)[2] = _12075;
    _12076 = MAKE_SEQ(_1);
    RefDS(_12077);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -13;
    ((int *)_2)[2] = _12077;
    _12078 = MAKE_SEQ(_1);
    RefDS(_12079);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -14;
    ((int *)_2)[2] = _12079;
    _12080 = MAKE_SEQ(_1);
    RefDS(_12081);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -15;
    ((int *)_2)[2] = _12081;
    _12082 = MAKE_SEQ(_1);
    RefDS(_12083);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -16;
    ((int *)_2)[2] = _12083;
    _12084 = MAKE_SEQ(_1);
    RefDS(_12085);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -17;
    ((int *)_2)[2] = _12085;
    _12086 = MAKE_SEQ(_1);
    RefDS(_12087);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -18;
    ((int *)_2)[2] = _12087;
    _12088 = MAKE_SEQ(_1);
    RefDS(_12089);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -19;
    ((int *)_2)[2] = _12089;
    _12090 = MAKE_SEQ(_1);
    RefDS(_12091);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -20;
    ((int *)_2)[2] = _12091;
    _12092 = MAKE_SEQ(_1);
    RefDS(_12093);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -21;
    ((int *)_2)[2] = _12093;
    _12094 = MAKE_SEQ(_1);
    RefDS(_12095);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -22;
    ((int *)_2)[2] = _12095;
    _12096 = MAKE_SEQ(_1);
    RefDS(_12097);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -23;
    ((int *)_2)[2] = _12097;
    _12098 = MAKE_SEQ(_1);
    _1 = NewS1(24);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12053;
    *((int *)(_2+8)) = _12055;
    *((int *)(_2+12)) = _12057;
    *((int *)(_2+16)) = _12059;
    *((int *)(_2+20)) = _12061;
    *((int *)(_2+24)) = _12062;
    *((int *)(_2+28)) = _12064;
    *((int *)(_2+32)) = _12066;
    *((int *)(_2+36)) = _12068;
    *((int *)(_2+40)) = _12070;
    *((int *)(_2+44)) = _12072;
    *((int *)(_2+48)) = _12074;
    *((int *)(_2+52)) = _12076;
    *((int *)(_2+56)) = _12078;
    *((int *)(_2+60)) = _12080;
    *((int *)(_2+64)) = _12082;
    *((int *)(_2+68)) = _12084;
    *((int *)(_2+72)) = _12086;
    *((int *)(_2+76)) = _12088;
    *((int *)(_2+80)) = _12090;
    *((int *)(_2+84)) = _12092;
    *((int *)(_2+88)) = _12094;
    *((int *)(_2+92)) = _12096;
    *((int *)(_2+96)) = _12098;
    _47error_names_21364 = MAKE_SEQ(_1);
    _12098 = NOVALUE;
    _12096 = NOVALUE;
    _12094 = NOVALUE;
    _12092 = NOVALUE;
    _12090 = NOVALUE;
    _12088 = NOVALUE;
    _12086 = NOVALUE;
    _12084 = NOVALUE;
    _12082 = NOVALUE;
    _12080 = NOVALUE;
    _12078 = NOVALUE;
    _12076 = NOVALUE;
    _12074 = NOVALUE;
    _12072 = NOVALUE;
    _12070 = NOVALUE;
    _12068 = NOVALUE;
    _12066 = NOVALUE;
    _12064 = NOVALUE;
    _12062 = NOVALUE;
    _12061 = NOVALUE;
    _12059 = NOVALUE;
    _12057 = NOVALUE;
    _12055 = NOVALUE;
    _12053 = NOVALUE;
    _1 = NewS1(29);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 4;
    *((int *)(_2+20)) = 8;
    *((int *)(_2+24)) = 16;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 64;
    *((int *)(_2+36)) = 128;
    *((int *)(_2+40)) = 256;
    *((int *)(_2+44)) = 512;
    *((int *)(_2+48)) = 1024;
    *((int *)(_2+52)) = 2048;
    *((int *)(_2+56)) = 4096;
    *((int *)(_2+60)) = 8192;
    *((int *)(_2+64)) = 16384;
    *((int *)(_2+68)) = 32768;
    *((int *)(_2+72)) = 65536;
    *((int *)(_2+76)) = 131072;
    *((int *)(_2+80)) = 262144;
    *((int *)(_2+84)) = 524288;
    *((int *)(_2+88)) = 1048576;
    *((int *)(_2+92)) = 2097152;
    *((int *)(_2+96)) = 3145728;
    *((int *)(_2+100)) = 4194304;
    *((int *)(_2+104)) = 5242880;
    *((int *)(_2+108)) = 8388608;
    *((int *)(_2+112)) = 16777216;
    *((int *)(_2+116)) = 201326592;
    _12100 = MAKE_SEQ(_1);
    _47all_options_21413 = _20or_all(_12100);
    _12100 = NOVALUE;
    DeRef1(_1options_inlined_new_at_4378_25256);
    _1options_inlined_new_at_4378_25256 = 0;

    /** 	if sequence(options) then */
    _1new_1__tmp_at4381_25257 = 0;
    if (_1new_1__tmp_at4381_25257 == 0)
    {
        goto L7; // [4387] 4397
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(0);
    _1options_inlined_new_at_4378_25256 = _0;
L7: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_4378_25256);
    RefDS(_12298);
    DeRef1(_1new_2__tmp_at4381_25258);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12298;
    ((int *)_2)[2] = _1options_inlined_new_at_4378_25256;
    _1new_2__tmp_at4381_25258 = MAKE_SEQ(_1);
    _49re_ip_21869 = machine(68, _1new_2__tmp_at4381_25258);
    DeRef1(_1options_inlined_new_at_4378_25256);
    _1options_inlined_new_at_4378_25256 = NOVALUE;
    DeRef1(_1new_2__tmp_at4381_25258);
    _1new_2__tmp_at4381_25258 = NOVALUE;
    DeRef1(_1options_inlined_new_at_4409_25260);
    _1options_inlined_new_at_4409_25260 = 1;

    /** 	if sequence(options) then */
    _1new_1__tmp_at4412_25261 = 0;
    if (_1new_1__tmp_at4412_25261 == 0)
    {
        goto L8; // [4418] 4428
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(1);
    _1options_inlined_new_at_4409_25260 = _0;
L8: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_4409_25260);
    RefDS(_12300);
    DeRef1(_1new_2__tmp_at4412_25262);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12300;
    ((int *)_2)[2] = _1options_inlined_new_at_4409_25260;
    _1new_2__tmp_at4412_25262 = MAKE_SEQ(_1);
    _49re_http_url_21872 = machine(68, _1new_2__tmp_at4412_25262);
    DeRef1(_1options_inlined_new_at_4409_25260);
    _1options_inlined_new_at_4409_25260 = NOVALUE;
    DeRef1(_1new_2__tmp_at4412_25262);
    _1new_2__tmp_at4412_25262 = NOVALUE;
    DeRef1(_1options_inlined_new_at_4440_25264);
    _1options_inlined_new_at_4440_25264 = 0;

    /** 	if sequence(options) then */
    _1new_1__tmp_at4443_25265 = 0;
    if (_1new_1__tmp_at4443_25265 == 0)
    {
        goto L9; // [4449] 4459
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(0);
    _1options_inlined_new_at_4440_25264 = _0;
L9: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_4440_25264);
    RefDS(_12302);
    DeRef1(_1new_2__tmp_at4443_25266);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12302;
    ((int *)_2)[2] = _1options_inlined_new_at_4440_25264;
    _1new_2__tmp_at4443_25266 = MAKE_SEQ(_1);
    _49re_mail_url_21875 = machine(68, _1new_2__tmp_at4443_25266);
    DeRef1(_1options_inlined_new_at_4440_25264);
    _1options_inlined_new_at_4440_25264 = NOVALUE;
    DeRef1(_1new_2__tmp_at4443_25266);
    _1new_2__tmp_at4443_25266 = NOVALUE;
    _0 = _48info(1);
    DeRef1(_48sockinfo_22065);
    _48sockinfo_22065 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_UNSPEC_22068 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_UNIX_22070 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_INET_22072 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_INET6_22074 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_APPLETALK_22076 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48AF_BTH_22078 = (int)*(((s1_ptr)_2)->base + 5);

    /** sockinfo = info(ESOCK_TYPE_TYPE)*/
    _0 = _48info(2);
    DeRef1(_48sockinfo_22065);
    _48sockinfo_22065 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOCK_STREAM_22082 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOCK_DGRAM_22084 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOCK_RAW_22086 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOCK_RDM_22088 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOCK_SEQPACKET_22090 = (int)*(((s1_ptr)_2)->base + 5);

    /** sockinfo = info(ESOCK_TYPE_OPTION)*/
    _0 = _48info(3);
    DeRef1(_48sockinfo_22065);
    _48sockinfo_22065 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SOL_SOCKET_22205 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DEBUG_22207 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_ACCEPTCONN_22209 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_REUSEADDR_22211 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_KEEPALIVE_22213 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DONTROUTE_22215 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_BROADCAST_22217 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_LINGER_22219 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SNDBUF_22221 = (int)*(((s1_ptr)_2)->base + 9);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_RCVBUF_22223 = (int)*(((s1_ptr)_2)->base + 10);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SNDLOWAT_22225 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_RCVLOWAT_22227 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SNDTIMEO_22229 = (int)*(((s1_ptr)_2)->base + 13);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_RCVTIMEO_22231 = (int)*(((s1_ptr)_2)->base + 14);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_ERROR_22233 = (int)*(((s1_ptr)_2)->base + 15);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_TYPE_22235 = (int)*(((s1_ptr)_2)->base + 16);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_OOBINLINE_22237 = (int)*(((s1_ptr)_2)->base + 17);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_USELOOPBACK_22239 = (int)*(((s1_ptr)_2)->base + 18);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DONTLINGER_22241 = (int)*(((s1_ptr)_2)->base + 19);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_REUSEPORT_22243 = (int)*(((s1_ptr)_2)->base + 20);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_CONNDATA_22245 = (int)*(((s1_ptr)_2)->base + 21);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_CONNOPT_22247 = (int)*(((s1_ptr)_2)->base + 22);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DISCDATA_22249 = (int)*(((s1_ptr)_2)->base + 23);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DISCOPT_22251 = (int)*(((s1_ptr)_2)->base + 24);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_CONNDATALEN_22253 = (int)*(((s1_ptr)_2)->base + 25);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_CONNOPTLEN_22255 = (int)*(((s1_ptr)_2)->base + 26);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DISCDATALEN_22257 = (int)*(((s1_ptr)_2)->base + 27);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DISCOPTLEN_22259 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_OPENTYPE_22261 = (int)*(((s1_ptr)_2)->base + 29);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_MAXDG_22263 = (int)*(((s1_ptr)_2)->base + 30);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_MAXPATHDG_22265 = (int)*(((s1_ptr)_2)->base + 31);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SYNCHRONOUS_ALTERT_22267 = (int)*(((s1_ptr)_2)->base + 32);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SYNCHRONOUS_NONALERT_22269 = (int)*(((s1_ptr)_2)->base + 33);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SNDBUFFORCE_22271 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_RCVBUFFORCE_22273 = (int)*(((s1_ptr)_2)->base + 35);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_NO_CHECK_22275 = (int)*(((s1_ptr)_2)->base + 36);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PRIORITY_22277 = (int)*(((s1_ptr)_2)->base + 37);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_BSDCOMPAT_22279 = (int)*(((s1_ptr)_2)->base + 38);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PASSCRED_22281 = (int)*(((s1_ptr)_2)->base + 39);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PEERCRED_22283 = (int)*(((s1_ptr)_2)->base + 40);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SECURITY_AUTHENTICATION_22285 = (int)*(((s1_ptr)_2)->base + 41);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SECURITY_ENCRYPTION_TRANSPORT_22287 = (int)*(((s1_ptr)_2)->base + 42);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_SECURITY_ENCRYPTION_NETWORK_22289 = (int)*(((s1_ptr)_2)->base + 43);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_BINDTODEVICE_22291 = (int)*(((s1_ptr)_2)->base + 44);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_ATTACH_FILTER_22293 = (int)*(((s1_ptr)_2)->base + 45);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DETACH_FILTER_22295 = (int)*(((s1_ptr)_2)->base + 46);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PEERNAME_22297 = (int)*(((s1_ptr)_2)->base + 47);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_TIMESTAMP_22299 = (int)*(((s1_ptr)_2)->base + 48);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SCM_TIMESTAMP_22301 = (int)*(((s1_ptr)_2)->base + 49);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PEERSEC_22303 = (int)*(((s1_ptr)_2)->base + 50);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PASSSEC_22305 = (int)*(((s1_ptr)_2)->base + 51);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_TIMESTAMPNS_22307 = (int)*(((s1_ptr)_2)->base + 52);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SCM_TIMESTAMPNS_22309 = (int)*(((s1_ptr)_2)->base + 53);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_MARK_22311 = (int)*(((s1_ptr)_2)->base + 54);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_TIMESTAMPING_22313 = (int)*(((s1_ptr)_2)->base + 55);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SCM_TIMESTAMPING_22315 = (int)*(((s1_ptr)_2)->base + 56);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_PROTOCOL_22317 = (int)*(((s1_ptr)_2)->base + 57);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_DOMAIN_22319 = (int)*(((s1_ptr)_2)->base + 58);
    _2 = (int)SEQ_PTR(_48sockinfo_22065);
    _48SO_RXQ_OVFL_22321 = (int)*(((s1_ptr)_2)->base + 59);
    _48delete_socket_rid_22378 = CRoutineId(739, 48, _12520);
    _12923 = _3version_major();
    _12924 = _3version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12923;
    ((int *)_2)[2] = _12924;
    _12925 = MAKE_SEQ(_1);
    _12924 = NOVALUE;
    _12923 = NOVALUE;
    _54USER_AGENT_HEADER_23245 = EPrintf(-9999999, _12922, _12925);
    DeRef1(_12925);
    _12925 = NOVALUE;
    RefDS(_12933);
    RefDS(_12932);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12932;
    ((int *)_2)[2] = _12933;
    _54ENCODING_STRINGS_23275 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_54rand_chars_23430)){
            _54rand_chars_len_23432 = SEQ_PTR(_54rand_chars_23430)->length;
    }
    else {
        _54rand_chars_len_23432 = 1;
    }

    /** ifdef WINDOWS then*/

    /** 	lib = dll:open_dll("user32.dll")*/
    RefDS(_13156);
    _0 = _13open_dll(_13156);
    DeRef1(_56lib_23693);
    _56lib_23693 = _0;

    /** 	msgbox_id = dll:define_c_func(lib, "MessageBoxA", {C_UINT, C_POINTER, */
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _13159 = MAKE_SEQ(_1);
    Ref(_56lib_23693);
    RefDS(_13158);
    _0 = _13define_c_func(_56lib_23693, _13158, _13159, 16777220);
    _56msgbox_id_23694 = _0;
    _13159 = NOVALUE;
    if (!IS_ATOM_INT(_56msgbox_id_23694)) {
        _1 = (long)(DBL_PTR(_56msgbox_id_23694)->dbl);
        DeRefDS(_56msgbox_id_23694);
        _56msgbox_id_23694 = _1;
    }

    /** 	if msgbox_id = -1 then*/
    if (_56msgbox_id_23694 != -1)
    goto LA; // [5070] 5084

    /** 		puts(2, "couldn't find MessageBoxA\n")*/
    EPuts(2, _13162); // DJP 

    /** 		abort(1)*/
    UserCleanup(1);
LA: 

    /** 	get_active_id = dll:define_c_func(lib, "GetActiveWindow", {}, C_UINT)*/
    Ref(_56lib_23693);
    RefDS(_13163);
    RefDS(_5);
    _0 = _13define_c_func(_56lib_23693, _13163, _5, 33554436);
    _56get_active_id_23695 = _0;
    if (!IS_ATOM_INT(_56get_active_id_23695)) {
        _1 = (long)(DBL_PTR(_56get_active_id_23695)->dbl);
        DeRefDS(_56get_active_id_23695);
        _56get_active_id_23695 = _1;
    }

    /** 	if get_active_id = -1 then*/
    if (_56get_active_id_23695 != -1)
    goto LB; // [5105] 5119

    /** 		puts(2, "couldn't find GetActiveWindow\n")*/
    EPuts(2, _13166); // DJP 

    /** 		abort(1)*/
    UserCleanup(1);
LB: 
    _13188 = power(2, 32);
    if (IS_ATOM_INT(_13188)) {
        _59MAX_ADDR_23796 = _13188 - 1;
        if ((long)((unsigned long)_59MAX_ADDR_23796 +(unsigned long) HIGH_BITS) >= 0){
            _59MAX_ADDR_23796 = NewDouble((double)_59MAX_ADDR_23796);
        }
    }
    else {
        _59MAX_ADDR_23796 = NewDouble(DBL_PTR(_13188)->dbl - (double)1);
    }
    DeRef1(_13188);
    _13188 = NOVALUE;
    _13190 = 1048576;
    _59LOW_ADDR_23799 = 1048575;
    _13190 = NOVALUE;

    /** mem = allocate(4)*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef1(_59mem_23871);
    _59mem_23871 = machine(16, 4);

    /** check_calls = 1*/
    _59check_calls_23960 = 1;

    /** always_linked_list = 0*/
    _58always_linked_list_23970 = 0;

    /** init()*/

    /** 	high_address = 0*/
    _1high_address_24312 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef1(_1data_24313);
    _1data_24313 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef1(_1free_list_24314);
    _1free_list_24314 = _5;

    /** end procedure*/
    goto LC; // [5199] 5202
LC: 
    ;
}

int __stdcall LibMain(int hDLL, int Reason, void *Reserved)
{
    if (Reason == 1)
    EuInit();
    return 1;
}
// GenerateUserRoutines

// 0x16125A96
