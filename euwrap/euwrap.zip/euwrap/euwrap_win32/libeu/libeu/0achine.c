// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _59allocate(int _n_23842)
{
    int _13204 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_23842)) {
        _1 = (long)(DBL_PTR(_n_23842)->dbl);
        DeRefDS(_n_23842);
        _n_23842 = _1;
    }

    /**     return machine_func(M_ALLOC, n)*/
    _13204 = machine(16, _n_23842);
    return _13204;
    ;
}


void  __stdcall _59free(int _a_23846)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_23846);

    /** end procedure*/
    DeRef(_a_23846);
    return;
    ;
}


int  __stdcall _59allocate_low(int _n_23849)
{
    int _allocate_inlined_allocate_at_4_23851 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_23849)) {
        _1 = (long)(DBL_PTR(_n_23849)->dbl);
        DeRefDS(_n_23849);
        _n_23849 = _1;
    }

    /**     return allocate( n )*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef(_allocate_inlined_allocate_at_4_23851);
    _allocate_inlined_allocate_at_4_23851 = machine(16, _n_23849);
    return _allocate_inlined_allocate_at_4_23851;
    ;
}


void  __stdcall _59free_low(int _a_23854)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_23854)) {
        _1 = (long)(DBL_PTR(_a_23854)->dbl);
        DeRefDS(_a_23854);
        _a_23854 = _1;
    }

    /**     free( a )*/

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_23854);

    /** end procedure*/
    goto L1; // [12] 15
L1: 

    /** end procedure*/
    return;
    ;
}


int  __stdcall _59int_to_bytes(int _x_23858)
{
    int _a_23859 = NOVALUE;
    int _b_23860 = NOVALUE;
    int _c_23861 = NOVALUE;
    int _d_23862 = NOVALUE;
    int _13212 = NOVALUE;
    int _0, _1, _2;
    

    /**     a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23858)) {
        _a_23859 = (_x_23858 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_23859 = Dremainder(DBL_PTR(_x_23858), &temp_d);
    }
    if (!IS_ATOM_INT(_a_23859)) {
        _1 = (long)(DBL_PTR(_a_23859)->dbl);
        DeRefDS(_a_23859);
        _a_23859 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23858;
    if (IS_ATOM_INT(_x_23858)) {
        if (256 > 0 && _x_23858 >= 0) {
            _x_23858 = _x_23858 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23858 / (double)256);
            if (_x_23858 != MININT)
            _x_23858 = (long)temp_dbl;
            else
            _x_23858 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23858, 256);
        _x_23858 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23858)) {
        _b_23860 = (_x_23858 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_23860 = Dremainder(DBL_PTR(_x_23858), &temp_d);
    }
    if (!IS_ATOM_INT(_b_23860)) {
        _1 = (long)(DBL_PTR(_b_23860)->dbl);
        DeRefDS(_b_23860);
        _b_23860 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23858;
    if (IS_ATOM_INT(_x_23858)) {
        if (256 > 0 && _x_23858 >= 0) {
            _x_23858 = _x_23858 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23858 / (double)256);
            if (_x_23858 != MININT)
            _x_23858 = (long)temp_dbl;
            else
            _x_23858 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23858, 256);
        _x_23858 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23858)) {
        _c_23861 = (_x_23858 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_23861 = Dremainder(DBL_PTR(_x_23858), &temp_d);
    }
    if (!IS_ATOM_INT(_c_23861)) {
        _1 = (long)(DBL_PTR(_c_23861)->dbl);
        DeRefDS(_c_23861);
        _c_23861 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_23858;
    if (IS_ATOM_INT(_x_23858)) {
        if (256 > 0 && _x_23858 >= 0) {
            _x_23858 = _x_23858 / 256;
        }
        else {
            temp_dbl = floor((double)_x_23858 / (double)256);
            if (_x_23858 != MININT)
            _x_23858 = (long)temp_dbl;
            else
            _x_23858 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_23858, 256);
        _x_23858 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_23858)) {
        _d_23862 = (_x_23858 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_23862 = Dremainder(DBL_PTR(_x_23858), &temp_d);
    }
    if (!IS_ATOM_INT(_d_23862)) {
        _1 = (long)(DBL_PTR(_d_23862)->dbl);
        DeRefDS(_d_23862);
        _d_23862 = _1;
    }

    /**     return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_23859;
    *((int *)(_2+8)) = _b_23860;
    *((int *)(_2+12)) = _c_23861;
    *((int *)(_2+16)) = _d_23862;
    _13212 = MAKE_SEQ(_1);
    DeRef(_x_23858);
    return _13212;
    ;
}


int  __stdcall _59bytes_to_int(int _s_23876)
{
    int _13216 = NOVALUE;
    int _13215 = NOVALUE;
    int _13213 = NOVALUE;
    int _0, _1, _2;
    

    /**     if length(s) = 4 then*/
    if (IS_SEQUENCE(_s_23876)){
            _13213 = SEQ_PTR(_s_23876)->length;
    }
    else {
        _13213 = 1;
    }
    if (_13213 != 4)
    goto L1; // [8] 22

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_59mem_23871)){
        poke_addr = (unsigned char *)_59mem_23871;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem_23871)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_23876);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    goto L2; // [19] 35
L1: 

    /** 	poke(mem, s[1..4]) -- avoid breaking old code*/
    rhs_slice_target = (object_ptr)&_13215;
    RHS_Slice(_s_23876, 1, 4);
    if (IS_ATOM_INT(_59mem_23871)){
        poke_addr = (unsigned char *)_59mem_23871;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem_23871)->dbl);
    }
    _1 = (int)SEQ_PTR(_13215);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_13215);
    _13215 = NOVALUE;
L2: 

    /**     return peek4u(mem)*/
    if (IS_ATOM_INT(_59mem_23871)) {
        _13216 = *(unsigned long *)_59mem_23871;
        if ((unsigned)_13216 > (unsigned)MAXINT)
        _13216 = NewDouble((double)(unsigned long)_13216);
    }
    else {
        _13216 = *(unsigned long *)(unsigned long)(DBL_PTR(_59mem_23871)->dbl);
        if ((unsigned)_13216 > (unsigned)MAXINT)
        _13216 = NewDouble((double)(unsigned long)_13216);
    }
    DeRefDS(_s_23876);
    return _13216;
    ;
}


int  __stdcall _59int_to_bits(int _x_23885, int _nbits_23886)
{
    int _bits_23887 = NOVALUE;
    int _mask_23888 = NOVALUE;
    int _13229 = NOVALUE;
    int _13228 = NOVALUE;
    int _13226 = NOVALUE;
    int _13223 = NOVALUE;
    int _13222 = NOVALUE;
    int _13221 = NOVALUE;
    int _13220 = NOVALUE;
    int _13219 = NOVALUE;
    int _13218 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nbits_23886)) {
        _1 = (long)(DBL_PTR(_nbits_23886)->dbl);
        DeRefDS(_nbits_23886);
        _nbits_23886 = _1;
    }

    /**     bits = repeat(0, nbits)*/
    DeRef(_bits_23887);
    _bits_23887 = Repeat(0, _nbits_23886);

    /**     if integer(x) and nbits < 30 then*/
    if (IS_ATOM_INT(_x_23885))
    _13218 = 1;
    else if (IS_ATOM_DBL(_x_23885))
    _13218 = IS_ATOM_INT(DoubleToInt(_x_23885));
    else
    _13218 = 0;
    if (_13218 == 0) {
        goto L1; // [14] 73
    }
    _13220 = (_nbits_23886 < 30);
    if (_13220 == 0)
    {
        DeRef(_13220);
        _13220 = NOVALUE;
        goto L1; // [23] 73
    }
    else{
        DeRef(_13220);
        _13220 = NOVALUE;
    }

    /** 	mask = 1*/
    _mask_23888 = 1;

    /** 	for i = 1 to nbits do*/
    _13221 = _nbits_23886;
    {
        int _i_23895;
        _i_23895 = 1;
L2: 
        if (_i_23895 > _13221){
            goto L3; // [36] 70
        }

        /** 	    bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_23885)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_23885 & (unsigned long)_mask_23888;
                 _13222 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_23888;
            _13222 = Dand_bits(DBL_PTR(_x_23885), &temp_d);
        }
        if (IS_ATOM_INT(_13222)) {
            _13223 = (_13222 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _13223 = Dand(DBL_PTR(_13222), &temp_d);
        }
        DeRef(_13222);
        _13222 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_23887);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_23887 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23895);
        _1 = *(int *)_2;
        *(int *)_2 = _13223;
        if( _1 != _13223 ){
            DeRef(_1);
        }
        _13223 = NOVALUE;

        /** 	    mask *= 2*/
        _mask_23888 = _mask_23888 + _mask_23888;

        /** 	end for*/
        _i_23895 = _i_23895 + 1;
        goto L2; // [65] 43
L3: 
        ;
    }
    goto L4; // [70] 126
L1: 

    /** 	if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_23885, 0)){
        goto L5; // [75] 90
    }

    /** 	    x += power(2, nbits) -- for 2's complement bit pattern*/
    _13226 = power(2, _nbits_23886);
    _0 = _x_23885;
    if (IS_ATOM_INT(_x_23885) && IS_ATOM_INT(_13226)) {
        _x_23885 = _x_23885 + _13226;
        if ((long)((unsigned long)_x_23885 + (unsigned long)HIGH_BITS) >= 0) 
        _x_23885 = NewDouble((double)_x_23885);
    }
    else {
        if (IS_ATOM_INT(_x_23885)) {
            _x_23885 = NewDouble((double)_x_23885 + DBL_PTR(_13226)->dbl);
        }
        else {
            if (IS_ATOM_INT(_13226)) {
                _x_23885 = NewDouble(DBL_PTR(_x_23885)->dbl + (double)_13226);
            }
            else
            _x_23885 = NewDouble(DBL_PTR(_x_23885)->dbl + DBL_PTR(_13226)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_13226);
    _13226 = NOVALUE;
L5: 

    /** 	for i = 1 to nbits do*/
    _13228 = _nbits_23886;
    {
        int _i_23906;
        _i_23906 = 1;
L6: 
        if (_i_23906 > _13228){
            goto L7; // [95] 125
        }

        /** 	    bits[i] = remainder(x, 2) */
        if (IS_ATOM_INT(_x_23885)) {
            _13229 = (_x_23885 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _13229 = Dremainder(DBL_PTR(_x_23885), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_23887);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_23887 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23906);
        _1 = *(int *)_2;
        *(int *)_2 = _13229;
        if( _1 != _13229 ){
            DeRef(_1);
        }
        _13229 = NOVALUE;

        /** 	    x = floor(x / 2)*/
        _0 = _x_23885;
        if (IS_ATOM_INT(_x_23885)) {
            _x_23885 = _x_23885 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_23885, 2);
            _x_23885 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 	end for*/
        _i_23906 = _i_23906 + 1;
        goto L6; // [120] 102
L7: 
        ;
    }
L4: 

    /**     return bits*/
    DeRef(_x_23885);
    return _bits_23887;
    ;
}


int  __stdcall _59bits_to_int(int _bits_23912)
{
    int _value_23913 = NOVALUE;
    int _p_23914 = NOVALUE;
    int _13232 = NOVALUE;
    int _13231 = NOVALUE;
    int _0, _1, _2;
    

    /**     value = 0*/
    DeRef(_value_23913);
    _value_23913 = 0;

    /**     p = 1*/
    DeRef(_p_23914);
    _p_23914 = 1;

    /**     for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_23912)){
            _13231 = SEQ_PTR(_bits_23912)->length;
    }
    else {
        _13231 = 1;
    }
    {
        int _i_23916;
        _i_23916 = 1;
L1: 
        if (_i_23916 > _13231){
            goto L2; // [18] 54
        }

        /** 	if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_23912);
        _13232 = (int)*(((s1_ptr)_2)->base + _i_23916);
        if (_13232 == 0) {
            _13232 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_13232) && DBL_PTR(_13232)->dbl == 0.0){
                _13232 = NOVALUE;
                goto L3; // [31] 41
            }
            _13232 = NOVALUE;
        }
        _13232 = NOVALUE;

        /** 	    value += p*/
        _0 = _value_23913;
        if (IS_ATOM_INT(_value_23913) && IS_ATOM_INT(_p_23914)) {
            _value_23913 = _value_23913 + _p_23914;
            if ((long)((unsigned long)_value_23913 + (unsigned long)HIGH_BITS) >= 0) 
            _value_23913 = NewDouble((double)_value_23913);
        }
        else {
            if (IS_ATOM_INT(_value_23913)) {
                _value_23913 = NewDouble((double)_value_23913 + DBL_PTR(_p_23914)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_23914)) {
                    _value_23913 = NewDouble(DBL_PTR(_value_23913)->dbl + (double)_p_23914);
                }
                else
                _value_23913 = NewDouble(DBL_PTR(_value_23913)->dbl + DBL_PTR(_p_23914)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 	p += p*/
        _0 = _p_23914;
        if (IS_ATOM_INT(_p_23914) && IS_ATOM_INT(_p_23914)) {
            _p_23914 = _p_23914 + _p_23914;
            if ((long)((unsigned long)_p_23914 + (unsigned long)HIGH_BITS) >= 0) 
            _p_23914 = NewDouble((double)_p_23914);
        }
        else {
            if (IS_ATOM_INT(_p_23914)) {
                _p_23914 = NewDouble((double)_p_23914 + DBL_PTR(_p_23914)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_23914)) {
                    _p_23914 = NewDouble(DBL_PTR(_p_23914)->dbl + (double)_p_23914);
                }
                else
                _p_23914 = NewDouble(DBL_PTR(_p_23914)->dbl + DBL_PTR(_p_23914)->dbl);
            }
        }
        DeRef(_0);

        /**     end for*/
        _i_23916 = _i_23916 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /**     return value*/
    DeRefDS(_bits_23912);
    DeRef(_p_23914);
    return _value_23913;
    ;
}


void  __stdcall _59set_rand(int _seed_23924)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_seed_23924)) {
        _1 = (long)(DBL_PTR(_seed_23924)->dbl);
        DeRefDS(_seed_23924);
        _seed_23924 = _1;
    }

    /**     machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_23924);

    /** end procedure*/
    return;
    ;
}


void  __stdcall _59crash_message(int _msg_23927)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_23927);

    /** end procedure*/
    DeRefDS(_msg_23927);
    return;
    ;
}


void  __stdcall _59crash_file(int _file_path_23930)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_23930);

    /** end procedure*/
    DeRefDS(_file_path_23930);
    return;
    ;
}


void  __stdcall _59crash_routine(int _proc_23933)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_23933)) {
        _1 = (long)(DBL_PTR(_proc_23933)->dbl);
        DeRefDS(_proc_23933);
        _proc_23933 = _1;
    }

    /**     machine_proc(M_CRASH_ROUTINE, proc)*/
    machine(66, _proc_23933);

    /** end procedure*/
    return;
    ;
}


int  __stdcall _59atom_to_float64(int _a_23936)
{
    int _13235 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F64, a)*/
    _13235 = machine(46, _a_23936);
    DeRef(_a_23936);
    return _13235;
    ;
}


int  __stdcall _59atom_to_float32(int _a_23940)
{
    int _13236 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F32, a)*/
    _13236 = machine(48, _a_23940);
    DeRef(_a_23940);
    return _13236;
    ;
}


int  __stdcall _59float64_to_atom(int _ieee64_23944)
{
    int _13237 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F64_TO_A, ieee64)*/
    _13237 = machine(47, _ieee64_23944);
    DeRefDS(_ieee64_23944);
    return _13237;
    ;
}


int  __stdcall _59float32_to_atom(int _ieee32_23948)
{
    int _13238 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F32_TO_A, ieee32)*/
    _13238 = machine(49, _ieee32_23948);
    DeRefDS(_ieee32_23948);
    return _13238;
    ;
}


int  __stdcall _59allocate_string(int _s_23952)
{
    int _mem_23953 = NOVALUE;
    int _13243 = NOVALUE;
    int _13242 = NOVALUE;
    int _13240 = NOVALUE;
    int _13239 = NOVALUE;
    int _0, _1, _2;
    

    /**     mem = machine_func(M_ALLOC, length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_23952)){
            _13239 = SEQ_PTR(_s_23952)->length;
    }
    else {
        _13239 = 1;
    }
    _13240 = _13239 + 1;
    _13239 = NOVALUE;
    DeRef(_mem_23953);
    _mem_23953 = machine(16, _13240);
    _13240 = NOVALUE;

    /**     if mem then*/
    if (_mem_23953 == 0) {
        goto L1; // [18] 39
    }
    else {
        if (!IS_ATOM_INT(_mem_23953) && DBL_PTR(_mem_23953)->dbl == 0.0){
            goto L1; // [18] 39
        }
    }

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_mem_23953)){
        poke_addr = (unsigned char *)_mem_23953;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_23953)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_23952);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_23952)){
            _13242 = SEQ_PTR(_s_23952)->length;
    }
    else {
        _13242 = 1;
    }
    if (IS_ATOM_INT(_mem_23953)) {
        _13243 = _mem_23953 + _13242;
        if ((long)((unsigned long)_13243 + (unsigned long)HIGH_BITS) >= 0) 
        _13243 = NewDouble((double)_13243);
    }
    else {
        _13243 = NewDouble(DBL_PTR(_mem_23953)->dbl + (double)_13242);
    }
    _13242 = NOVALUE;
    if (IS_ATOM_INT(_13243)){
        poke_addr = (unsigned char *)_13243;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13243)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13243);
    _13243 = NOVALUE;
L1: 

    /**     return mem*/
    DeRefDS(_s_23952);
    return _mem_23953;
    ;
}


void  __stdcall _59register_block(int _block_addr_23963, int _block_len_23964)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void  __stdcall _59unregister_block(int _block_addr_23967)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void  __stdcall _59check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}



// 0x02E39E1D
