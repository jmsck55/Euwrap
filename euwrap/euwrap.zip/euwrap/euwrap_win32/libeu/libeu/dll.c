// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _13open_dll(int _file_name_2398)
{
    int _fh_2408 = NOVALUE;
    int _1156 = NOVALUE;
    int _1154 = NOVALUE;
    int _1153 = NOVALUE;
    int _1152 = NOVALUE;
    int _1151 = NOVALUE;
    int _1150 = NOVALUE;
    int _1149 = NOVALUE;
    int _1148 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_2398)){
            _1148 = SEQ_PTR(_file_name_2398)->length;
    }
    else {
        _1148 = 1;
    }
    _1149 = (_1148 > 0);
    _1148 = NOVALUE;
    if (_1149 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_2398);
    _1151 = _7string(_file_name_2398);
    if (_1151 == 0) {
        DeRef(_1151);
        _1151 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_1151) && DBL_PTR(_1151)->dbl == 0.0){
            DeRef(_1151);
            _1151 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_1151);
        _1151 = NOVALUE;
    }
    DeRef(_1151);
    _1151 = NOVALUE;

    /** 		return machine_func(M_OPEN_DLL, file_name)*/
    _1152 = machine(50, _file_name_2398);
    DeRefDS(_file_name_2398);
    DeRef(_1149);
    _1149 = NOVALUE;
    return _1152;
L1: 

    /** 	for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_2398)){
            _1153 = SEQ_PTR(_file_name_2398)->length;
    }
    else {
        _1153 = 1;
    }
    {
        int _idx_2406;
        _idx_2406 = 1;
L2: 
        if (_idx_2406 > _1153){
            goto L3; // [40] 82
        }

        /** 		atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (int)SEQ_PTR(_file_name_2398);
        _1154 = (int)*(((s1_ptr)_2)->base + _idx_2406);
        DeRef(_fh_2408);
        _fh_2408 = machine(50, _1154);
        _1154 = NOVALUE;

        /** 		if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_2408)) {
            _1156 = (_fh_2408 == 0);
        }
        else {
            _1156 = unary_op(NOT, _fh_2408);
        }
        if (_1156 != 0)
        goto L4; // [62] 73

        /** 			return fh*/
        DeRefDS(_file_name_2398);
        DeRef(_1149);
        _1149 = NOVALUE;
        DeRef(_1152);
        _1152 = NOVALUE;
        _1156 = NOVALUE;
        return _fh_2408;
L4: 
        DeRef(_fh_2408);
        _fh_2408 = NOVALUE;

        /** 	end for*/
        _idx_2406 = _idx_2406 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_name_2398);
    DeRef(_1149);
    _1149 = NOVALUE;
    DeRef(_1152);
    _1152 = NOVALUE;
    DeRef(_1156);
    _1156 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _13define_c_var(int _lib_2416, int _variable_name_2417)
{
    int _1159 = NOVALUE;
    int _1158 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_DEFINE_VAR, {lib, variable_name})*/
    RefDS(_variable_name_2417);
    Ref(_lib_2416);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lib_2416;
    ((int *)_2)[2] = _variable_name_2417;
    _1158 = MAKE_SEQ(_1);
    _1159 = machine(56, _1158);
    DeRefDS(_1158);
    _1158 = NOVALUE;
    DeRef(_lib_2416);
    DeRefDS(_variable_name_2417);
    return _1159;
    ;
}


int  __stdcall _13define_c_proc(int _lib_2422, int _routine_name_2423, int _arg_types_2424)
{
    int _safe_address_inlined_safe_address_at_11_2429 = NOVALUE;
    int _msg_inlined_crash_at_26_2433 = NOVALUE;
    int _1165 = NOVALUE;
    int _1164 = NOVALUE;
    int _1162 = NOVALUE;
    int _1161 = NOVALUE;
    int _1160 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _1160 = IS_ATOM(_routine_name_2423);
    if (_1160 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_2429 = 1;
    _1162 = (1 == 0);
    if (_1162 == 0)
    {
        DeRef(_1162);
        _1162 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_1162);
        _1162 = NOVALUE;
    }

    /**         error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_2433);
    _msg_inlined_crash_at_26_2433 = EPrintf(-9999999, _1163, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_2433);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_2433);
    _msg_inlined_crash_at_26_2433 = NOVALUE;
L1: 

    /** 	return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_2422);
    *((int *)(_2+4)) = _lib_2422;
    Ref(_routine_name_2423);
    *((int *)(_2+8)) = _routine_name_2423;
    RefDS(_arg_types_2424);
    *((int *)(_2+12)) = _arg_types_2424;
    *((int *)(_2+16)) = 0;
    _1164 = MAKE_SEQ(_1);
    _1165 = machine(51, _1164);
    DeRefDS(_1164);
    _1164 = NOVALUE;
    DeRef(_lib_2422);
    DeRef(_routine_name_2423);
    DeRefDS(_arg_types_2424);
    return _1165;
    ;
}


int  __stdcall _13define_c_func(int _lib_2438, int _routine_name_2439, int _arg_types_2440, int _return_type_2441)
{
    int _safe_address_inlined_safe_address_at_11_2446 = NOVALUE;
    int _msg_inlined_crash_at_26_2449 = NOVALUE;
    int _1170 = NOVALUE;
    int _1169 = NOVALUE;
    int _1168 = NOVALUE;
    int _1167 = NOVALUE;
    int _1166 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _1166 = IS_ATOM(_routine_name_2439);
    if (_1166 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_2446 = 1;
    _1168 = (1 == 0);
    if (_1168 == 0)
    {
        DeRef(_1168);
        _1168 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_1168);
        _1168 = NOVALUE;
    }

    /** 	      error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_2449);
    _msg_inlined_crash_at_26_2449 = EPrintf(-9999999, _1163, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_2449);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_2449);
    _msg_inlined_crash_at_26_2449 = NOVALUE;
L1: 

    /** 	  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_2438);
    *((int *)(_2+4)) = _lib_2438;
    Ref(_routine_name_2439);
    *((int *)(_2+8)) = _routine_name_2439;
    RefDS(_arg_types_2440);
    *((int *)(_2+12)) = _arg_types_2440;
    Ref(_return_type_2441);
    *((int *)(_2+16)) = _return_type_2441;
    _1169 = MAKE_SEQ(_1);
    _1170 = machine(51, _1169);
    DeRefDS(_1169);
    _1169 = NOVALUE;
    DeRef(_lib_2438);
    DeRef(_routine_name_2439);
    DeRefDS(_arg_types_2440);
    DeRef(_return_type_2441);
    return _1170;
    ;
}


int  __stdcall _13call_back(int _id_2455)
{
    int _1171 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return machine_func(M_CALL_BACK, id)*/
    _1171 = machine(52, _id_2455);
    DeRef(_id_2455);
    return _1171;
    ;
}



// 0x7EFBF7C5
