// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _43set_lang_path(int _pp_20423)
{
    int _0, _1, _2;
    

    /** 	lang_path = pp*/
    Ref(_pp_20423);
    DeRef(_43lang_path_20420);
    _43lang_path_20420 = _pp_20423;

    /** end procedure*/
    DeRef(_pp_20423);
    return;
    ;
}


int  __stdcall _43get_lang_path()
{
    int _0, _1, _2;
    

    /** 	return lang_path*/
    Ref(_43lang_path_20420);
    return _43lang_path_20420;
    ;
}


int  __stdcall _43lang_load(int _filename_20428)
{
    int _lines_20429 = NOVALUE;
    int _line_20430 = NOVALUE;
    int _key_20431 = NOVALUE;
    int _msg_20432 = NOVALUE;
    int _delim_20433 = NOVALUE;
    int _cont_20434 = NOVALUE;
    int _keylang_20435 = NOVALUE;
    int _altlang_20436 = NOVALUE;
    int _tempname_20446 = NOVALUE;
    int _11620 = NOVALUE;
    int _11618 = NOVALUE;
    int _11617 = NOVALUE;
    int _11616 = NOVALUE;
    int _11613 = NOVALUE;
    int _11611 = NOVALUE;
    int _11610 = NOVALUE;
    int _11609 = NOVALUE;
    int _11608 = NOVALUE;
    int _11606 = NOVALUE;
    int _11605 = NOVALUE;
    int _11603 = NOVALUE;
    int _11602 = NOVALUE;
    int _11596 = NOVALUE;
    int _11594 = NOVALUE;
    int _11592 = NOVALUE;
    int _11589 = NOVALUE;
    int _11588 = NOVALUE;
    int _11587 = NOVALUE;
    int _11586 = NOVALUE;
    int _11584 = NOVALUE;
    int _11583 = NOVALUE;
    int _11581 = NOVALUE;
    int _11580 = NOVALUE;
    int _11579 = NOVALUE;
    int _11575 = NOVALUE;
    int _11573 = NOVALUE;
    int _11572 = NOVALUE;
    int _11571 = NOVALUE;
    int _11570 = NOVALUE;
    int _11569 = NOVALUE;
    int _0, _1, _2;
    

    /** 	keylang = map:new()*/
    _0 = _keylang_20435;
    _keylang_20435 = _33new(690);
    DeRef(_0);

    /** 	altlang = map:new()*/
    _0 = _altlang_20436;
    _altlang_20436 = _33new(690);
    DeRef(_0);

    /** 	cont = 0*/
    _cont_20434 = 0;

    /** 	filename = filesys:defaultext(filename, "lng")*/
    RefDS(_filename_20428);
    RefDS(_11567);
    _0 = _filename_20428;
    _filename_20428 = _11defaultext(_filename_20428, _11567);
    DeRefDS(_0);

    /** 	if sequence(lang_path) and length(lang_path) > 0 then*/
    _11569 = IS_SEQUENCE(_43lang_path_20420);
    if (_11569 == 0) {
        goto L1; // [36] 106
    }
    if (IS_SEQUENCE(_43lang_path_20420)){
            _11571 = SEQ_PTR(_43lang_path_20420)->length;
    }
    else {
        _11571 = 1;
    }
    _11572 = (_11571 > 0);
    _11571 = NOVALUE;
    if (_11572 == 0)
    {
        DeRef(_11572);
        _11572 = NOVALUE;
        goto L1; // [50] 106
    }
    else{
        DeRef(_11572);
        _11572 = NOVALUE;
    }

    /** 		sequence tempname */

    /** 		tempname = filesys:locate_file(filename, {lang_path})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_43lang_path_20420);
    *((int *)(_2+4)) = _43lang_path_20420;
    _11573 = MAKE_SEQ(_1);
    RefDS(_filename_20428);
    RefDS(_5);
    _0 = _tempname_20446;
    _tempname_20446 = _11locate_file(_filename_20428, _11573, _5);
    DeRef(_0);
    _11573 = NOVALUE;

    /** 		if equal(tempname, filename) then*/
    if (_tempname_20446 == _filename_20428)
    _11575 = 1;
    else if (IS_ATOM_INT(_tempname_20446) && IS_ATOM_INT(_filename_20428))
    _11575 = 0;
    else
    _11575 = (compare(_tempname_20446, _filename_20428) == 0);
    if (_11575 == 0)
    {
        _11575 = NOVALUE;
        goto L2; // [77] 93
    }
    else{
        _11575 = NOVALUE;
    }

    /** 			filename = filesys:locate_file(filename)*/
    RefDS(_filename_20428);
    RefDS(_5);
    RefDS(_5);
    _0 = _filename_20428;
    _filename_20428 = _11locate_file(_filename_20428, _5, _5);
    DeRefDS(_0);
    goto L3; // [90] 101
L2: 

    /** 			filename = tempname*/
    RefDS(_tempname_20446);
    DeRefDS(_filename_20428);
    _filename_20428 = _tempname_20446;
L3: 
    DeRef(_tempname_20446);
    _tempname_20446 = NOVALUE;
    goto L4; // [103] 117
L1: 

    /** 		filename = filesys:locate_file(filename)*/
    RefDS(_filename_20428);
    RefDS(_5);
    RefDS(_5);
    _0 = _filename_20428;
    _filename_20428 = _11locate_file(_filename_20428, _5, _5);
    DeRefDS(_0);
L4: 

    /** 	lines = io:read_lines(filename)*/
    RefDS(_filename_20428);
    _0 = _lines_20429;
    _lines_20429 = _18read_lines(_filename_20428);
    DeRef(_0);

    /** 	if atom(lines) then*/
    _11579 = IS_ATOM(_lines_20429);
    if (_11579 == 0)
    {
        _11579 = NOVALUE;
        goto L5; // [128] 138
    }
    else{
        _11579 = NOVALUE;
    }

    /** 		return 0  -- Language maps unchanged.*/
    DeRefDS(_filename_20428);
    DeRef(_lines_20429);
    DeRef(_line_20430);
    DeRef(_key_20431);
    DeRef(_msg_20432);
    DeRef(_keylang_20435);
    DeRef(_altlang_20436);
    return 0;
L5: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_20429)){
            _11580 = SEQ_PTR(_lines_20429)->length;
    }
    else {
        _11580 = 1;
    }
    {
        int _i_20459;
        _i_20459 = 1;
L6: 
        if (_i_20459 > _11580){
            goto L7; // [143] 460
        }

        /** 		if cont then*/
        if (_cont_20434 == 0)
        {
            goto L8; // [152] 250
        }
        else{
        }

        /** 			line = text:trim_tail(lines[i])*/
        _2 = (int)SEQ_PTR(_lines_20429);
        _11581 = (int)*(((s1_ptr)_2)->base + _i_20459);
        Ref(_11581);
        RefDS(_4563);
        _0 = _line_20430;
        _line_20430 = _6trim_tail(_11581, _4563, 0);
        DeRef(_0);
        _11581 = NOVALUE;

        /** 			if line[$] = '&' then*/
        if (IS_SEQUENCE(_line_20430)){
                _11583 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11583 = 1;
        }
        _2 = (int)SEQ_PTR(_line_20430);
        _11584 = (int)*(((s1_ptr)_2)->base + _11583);
        if (binary_op_a(NOTEQ, _11584, 38)){
            _11584 = NOVALUE;
            goto L9; // [178] 209
        }
        _11584 = NOVALUE;

        /** 				msg &= line[1..$-1] & '\n'*/
        if (IS_SEQUENCE(_line_20430)){
                _11586 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11586 = 1;
        }
        _11587 = _11586 - 1;
        _11586 = NOVALUE;
        rhs_slice_target = (object_ptr)&_11588;
        RHS_Slice(_line_20430, 1, _11587);
        Append(&_11589, _11588, 10);
        DeRefDS(_11588);
        _11588 = NOVALUE;
        Concat((object_ptr)&_msg_20432, _msg_20432, _11589);
        DeRefDS(_11589);
        _11589 = NOVALUE;
        goto LA; // [206] 453
L9: 

        /** 				msg &= line*/
        Concat((object_ptr)&_msg_20432, _msg_20432, _line_20430);

        /** 				map:put(keylang, key, msg)*/
        Ref(_keylang_20435);
        RefDS(_key_20431);
        RefDS(_msg_20432);
        _33put(_keylang_20435, _key_20431, _msg_20432, 1, _33threshold_size_12989);

        /** 				map:put(altlang, msg, key)*/
        Ref(_altlang_20436);
        RefDS(_msg_20432);
        RefDS(_key_20431);
        _33put(_altlang_20436, _msg_20432, _key_20431, 1, _33threshold_size_12989);

        /** 				cont = 0*/
        _cont_20434 = 0;
        goto LA; // [247] 453
L8: 

        /** 			line = text:trim(lines[i])*/
        _2 = (int)SEQ_PTR(_lines_20429);
        _11592 = (int)*(((s1_ptr)_2)->base + _i_20459);
        Ref(_11592);
        RefDS(_4563);
        _0 = _line_20430;
        _line_20430 = _6trim(_11592, _4563, 0);
        DeRef(_0);
        _11592 = NOVALUE;

        /** 			if length(line) = 0 then*/
        if (IS_SEQUENCE(_line_20430)){
                _11594 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11594 = 1;
        }
        if (_11594 != 0)
        goto LB; // [269] 278

        /** 				continue*/
        goto LC; // [275] 455
LB: 

        /** 			if line[1] = '#' then*/
        _2 = (int)SEQ_PTR(_line_20430);
        _11596 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _11596, 35)){
            _11596 = NOVALUE;
            goto LD; // [284] 293
        }
        _11596 = NOVALUE;

        /** 				continue*/
        goto LC; // [290] 455
LD: 

        /** 			delim = find('=', line)*/
        _delim_20433 = find_from(61, _line_20430, 1);

        /** 			if delim = 0 then*/
        if (_delim_20433 != 0)
        goto LE; // [302] 314

        /** 				delim = find(' ', line)*/
        _delim_20433 = find_from(32, _line_20430, 1);
LE: 

        /** 			if delim = 0 then*/
        if (_delim_20433 != 0)
        goto LF; // [316] 325

        /** 				continue*/
        goto LC; // [322] 455
LF: 

        /** 			key = text:trim(line[1..delim-1])*/
        _11602 = _delim_20433 - 1;
        rhs_slice_target = (object_ptr)&_11603;
        RHS_Slice(_line_20430, 1, _11602);
        RefDS(_4563);
        _0 = _key_20431;
        _key_20431 = _6trim(_11603, _4563, 0);
        DeRef(_0);
        _11603 = NOVALUE;

        /** 			if line[$] = '&' then*/
        if (IS_SEQUENCE(_line_20430)){
                _11605 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11605 = 1;
        }
        _2 = (int)SEQ_PTR(_line_20430);
        _11606 = (int)*(((s1_ptr)_2)->base + _11605);
        if (binary_op_a(NOTEQ, _11606, 38)){
            _11606 = NOVALUE;
            goto L10; // [353] 407
        }
        _11606 = NOVALUE;

        /** 				cont = 1*/
        _cont_20434 = 1;

        /** 				msg = text:trim(line[delim+1..$-1])*/
        _11608 = _delim_20433 + 1;
        if (_11608 > MAXINT){
            _11608 = NewDouble((double)_11608);
        }
        if (IS_SEQUENCE(_line_20430)){
                _11609 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11609 = 1;
        }
        _11610 = _11609 - 1;
        _11609 = NOVALUE;
        rhs_slice_target = (object_ptr)&_11611;
        RHS_Slice(_line_20430, _11608, _11610);
        RefDS(_4563);
        _0 = _msg_20432;
        _msg_20432 = _6trim(_11611, _4563, 0);
        DeRef(_0);
        _11611 = NOVALUE;

        /** 				if length(msg) > 0 then*/
        if (IS_SEQUENCE(_msg_20432)){
                _11613 = SEQ_PTR(_msg_20432)->length;
        }
        else {
            _11613 = 1;
        }
        if (_11613 <= 0)
        goto L11; // [393] 452

        /** 					msg &= '\n'*/
        Append(&_msg_20432, _msg_20432, 10);
        goto L11; // [404] 452
L10: 

        /** 				msg = text:trim(line[delim+1..$])*/
        _11616 = _delim_20433 + 1;
        if (_11616 > MAXINT){
            _11616 = NewDouble((double)_11616);
        }
        if (IS_SEQUENCE(_line_20430)){
                _11617 = SEQ_PTR(_line_20430)->length;
        }
        else {
            _11617 = 1;
        }
        rhs_slice_target = (object_ptr)&_11618;
        RHS_Slice(_line_20430, _11616, _11617);
        RefDS(_4563);
        _0 = _msg_20432;
        _msg_20432 = _6trim(_11618, _4563, 0);
        DeRef(_0);
        _11618 = NOVALUE;

        /** 				map:put(keylang, key, msg)*/
        Ref(_keylang_20435);
        RefDS(_key_20431);
        RefDS(_msg_20432);
        _33put(_keylang_20435, _key_20431, _msg_20432, 1, _33threshold_size_12989);

        /** 				map:put(altlang, msg, key)*/
        Ref(_altlang_20436);
        RefDS(_msg_20432);
        RefDS(_key_20431);
        _33put(_altlang_20436, _msg_20432, _key_20431, 1, _33threshold_size_12989);
L11: 
LA: 

        /** 	end for*/
LC: 
        _i_20459 = _i_20459 + 1;
        goto L6; // [455] 150
L7: 
        ;
    }

    /** 	return {keylang, altlang}*/
    Ref(_altlang_20436);
    Ref(_keylang_20435);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keylang_20435;
    ((int *)_2)[2] = _altlang_20436;
    _11620 = MAKE_SEQ(_1);
    DeRefDS(_filename_20428);
    DeRef(_lines_20429);
    DeRef(_line_20430);
    DeRef(_key_20431);
    DeRef(_msg_20432);
    DeRef(_keylang_20435);
    DeRef(_altlang_20436);
    DeRef(_11587);
    _11587 = NOVALUE;
    DeRef(_11602);
    _11602 = NOVALUE;
    DeRef(_11608);
    _11608 = NOVALUE;
    DeRef(_11610);
    _11610 = NOVALUE;
    DeRef(_11616);
    _11616 = NOVALUE;
    return _11620;
    ;
}


void  __stdcall _43set_def_lang(int _langmap_20514)
{
    int _11624 = NOVALUE;
    int _11623 = NOVALUE;
    int _11622 = NOVALUE;
    int _11621 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(langmap) and langmap = 0 then*/
    _11621 = IS_ATOM(_langmap_20514);
    if (_11621 == 0) {
        goto L1; // [6] 26
    }
    if (IS_ATOM_INT(_langmap_20514)) {
        _11623 = (_langmap_20514 == 0);
    }
    else {
        _11623 = binary_op(EQUALS, _langmap_20514, 0);
    }
    if (_11623 == 0) {
        DeRef(_11623);
        _11623 = NOVALUE;
        goto L1; // [15] 26
    }
    else {
        if (!IS_ATOM_INT(_11623) && DBL_PTR(_11623)->dbl == 0.0){
            DeRef(_11623);
            _11623 = NOVALUE;
            goto L1; // [15] 26
        }
        DeRef(_11623);
        _11623 = NOVALUE;
    }
    DeRef(_11623);
    _11623 = NOVALUE;

    /** 		def_lang = langmap*/
    Ref(_langmap_20514);
    DeRef(_43def_lang_20419);
    _43def_lang_20419 = _langmap_20514;
    goto L2; // [23] 42
L1: 

    /** 	elsif length(langmap) = 2 then*/
    if (IS_SEQUENCE(_langmap_20514)){
            _11624 = SEQ_PTR(_langmap_20514)->length;
    }
    else {
        _11624 = 1;
    }
    if (_11624 != 2)
    goto L3; // [31] 41

    /** 		def_lang = langmap*/
    Ref(_langmap_20514);
    DeRef(_43def_lang_20419);
    _43def_lang_20419 = _langmap_20514;
L3: 
L2: 

    /** end procedure*/
    DeRef(_langmap_20514);
    return;
    ;
}


int  __stdcall _43get_def_lang()
{
    int _0, _1, _2;
    

    /** 	return def_lang*/
    Ref(_43def_lang_20419);
    return _43def_lang_20419;
    ;
}


int  __stdcall _43translate(int _word_20526, int _langmap_20527, int _defval_20528, int _mode_20529)
{
    int _11637 = NOVALUE;
    int _11636 = NOVALUE;
    int _11635 = NOVALUE;
    int _11634 = NOVALUE;
    int _11632 = NOVALUE;
    int _11631 = NOVALUE;
    int _11629 = NOVALUE;
    int _11628 = NOVALUE;
    int _11627 = NOVALUE;
    int _11626 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mode_20529)) {
        _1 = (long)(DBL_PTR(_mode_20529)->dbl);
        DeRefDS(_mode_20529);
        _mode_20529 = _1;
    }

    /** 	if equal(defval, mathcons:PINF) then*/
    if (_defval_20528 == _22PINF_4462)
    _11626 = 1;
    else if (IS_ATOM_INT(_defval_20528) && IS_ATOM_INT(_22PINF_4462))
    _11626 = 0;
    else
    _11626 = (compare(_defval_20528, _22PINF_4462) == 0);
    if (_11626 == 0)
    {
        _11626 = NOVALUE;
        goto L1; // [13] 22
    }
    else{
        _11626 = NOVALUE;
    }

    /** 		defval = word*/
    RefDS(_word_20526);
    DeRef(_defval_20528);
    _defval_20528 = _word_20526;
L1: 

    /** 	if equal(langmap, 0) then*/
    if (_langmap_20527 == 0)
    _11627 = 1;
    else if (IS_ATOM_INT(_langmap_20527) && IS_ATOM_INT(0))
    _11627 = 0;
    else
    _11627 = (compare(_langmap_20527, 0) == 0);
    if (_11627 == 0)
    {
        _11627 = NOVALUE;
        goto L2; // [28] 60
    }
    else{
        _11627 = NOVALUE;
    }

    /** 		if equal(def_lang, 0) then*/
    if (_43def_lang_20419 == 0)
    _11628 = 1;
    else if (IS_ATOM_INT(_43def_lang_20419) && IS_ATOM_INT(0))
    _11628 = 0;
    else
    _11628 = (compare(_43def_lang_20419, 0) == 0);
    if (_11628 == 0)
    {
        _11628 = NOVALUE;
        goto L3; // [39] 51
    }
    else{
        _11628 = NOVALUE;
    }

    /** 			return defval*/
    DeRefDS(_word_20526);
    DeRef(_langmap_20527);
    return _defval_20528;
    goto L4; // [48] 59
L3: 

    /** 			langmap = def_lang*/
    Ref(_43def_lang_20419);
    DeRef(_langmap_20527);
    _langmap_20527 = _43def_lang_20419;
L4: 
L2: 

    /** 	if atom(langmap) or length(langmap) != 2 then*/
    _11629 = IS_ATOM(_langmap_20527);
    if (_11629 != 0) {
        goto L5; // [65] 81
    }
    if (IS_SEQUENCE(_langmap_20527)){
            _11631 = SEQ_PTR(_langmap_20527)->length;
    }
    else {
        _11631 = 1;
    }
    _11632 = (_11631 != 2);
    _11631 = NOVALUE;
    if (_11632 == 0)
    {
        DeRef(_11632);
        _11632 = NOVALUE;
        goto L6; // [77] 88
    }
    else{
        DeRef(_11632);
        _11632 = NOVALUE;
    }
L5: 

    /** 		return defval*/
    DeRefDS(_word_20526);
    DeRef(_langmap_20527);
    return _defval_20528;
L6: 

    /** 	if mode = 0 then*/
    if (_mode_20529 != 0)
    goto L7; // [90] 113

    /** 		return map:get(langmap[1], word, defval)*/
    _2 = (int)SEQ_PTR(_langmap_20527);
    _11634 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_11634);
    RefDS(_word_20526);
    Ref(_defval_20528);
    _11635 = _33get(_11634, _word_20526, _defval_20528);
    _11634 = NOVALUE;
    DeRefDS(_word_20526);
    DeRef(_langmap_20527);
    DeRef(_defval_20528);
    return _11635;
    goto L8; // [110] 130
L7: 

    /** 		return map:get(langmap[2], word, defval)*/
    _2 = (int)SEQ_PTR(_langmap_20527);
    _11636 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_11636);
    RefDS(_word_20526);
    Ref(_defval_20528);
    _11637 = _33get(_11636, _word_20526, _defval_20528);
    _11636 = NOVALUE;
    DeRefDS(_word_20526);
    DeRef(_langmap_20527);
    DeRef(_defval_20528);
    DeRef(_11635);
    _11635 = NOVALUE;
    return _11637;
L8: 
    ;
}


int  __stdcall _43trsprintf(int _fmt_20551, int _data_20552, int _langmap_20553)
{
    int _11653 = NOVALUE;
    int _11651 = NOVALUE;
    int _11650 = NOVALUE;
    int _11648 = NOVALUE;
    int _11647 = NOVALUE;
    int _11646 = NOVALUE;
    int _11645 = NOVALUE;
    int _11644 = NOVALUE;
    int _11642 = NOVALUE;
    int _11641 = NOVALUE;
    int _11640 = NOVALUE;
    int _11639 = NOVALUE;
    int _11638 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(data) do*/
    if (IS_SEQUENCE(_data_20552)){
            _11638 = SEQ_PTR(_data_20552)->length;
    }
    else {
        _11638 = 1;
    }
    {
        int _i_20555;
        _i_20555 = 1;
L1: 
        if (_i_20555 > _11638){
            goto L2; // [10] 89
        }

        /** 		if sequence(data[i]) then*/
        _2 = (int)SEQ_PTR(_data_20552);
        _11639 = (int)*(((s1_ptr)_2)->base + _i_20555);
        _11640 = IS_SEQUENCE(_11639);
        _11639 = NOVALUE;
        if (_11640 == 0)
        {
            _11640 = NOVALUE;
            goto L3; // [26] 82
        }
        else{
            _11640 = NOVALUE;
        }

        /** 			data[i] = translate(data[i], langmap, mathcons:PINF)*/
        _2 = (int)SEQ_PTR(_data_20552);
        _11641 = (int)*(((s1_ptr)_2)->base + _i_20555);
        Ref(_11641);
        Ref(_langmap_20553);
        RefDS(_22PINF_4462);
        _11642 = _43translate(_11641, _langmap_20553, _22PINF_4462, 0);
        _11641 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_20552);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_20552 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_20555);
        _1 = *(int *)_2;
        *(int *)_2 = _11642;
        if( _1 != _11642 ){
            DeRef(_1);
        }
        _11642 = NOVALUE;

        /** 			if search:begins("__", data[i]) then*/
        _2 = (int)SEQ_PTR(_data_20552);
        _11644 = (int)*(((s1_ptr)_2)->base + _i_20555);
        RefDS(_11643);
        Ref(_11644);
        _11645 = _9begins(_11643, _11644);
        _11644 = NOVALUE;
        if (_11645 == 0) {
            DeRef(_11645);
            _11645 = NOVALUE;
            goto L4; // [59] 81
        }
        else {
            if (!IS_ATOM_INT(_11645) && DBL_PTR(_11645)->dbl == 0.0){
                DeRef(_11645);
                _11645 = NOVALUE;
                goto L4; // [59] 81
            }
            DeRef(_11645);
            _11645 = NOVALUE;
        }
        DeRef(_11645);
        _11645 = NOVALUE;

        /** 				data[i] = data[i][3 .. $]*/
        _2 = (int)SEQ_PTR(_data_20552);
        _11646 = (int)*(((s1_ptr)_2)->base + _i_20555);
        if (IS_SEQUENCE(_11646)){
                _11647 = SEQ_PTR(_11646)->length;
        }
        else {
            _11647 = 1;
        }
        rhs_slice_target = (object_ptr)&_11648;
        RHS_Slice(_11646, 3, _11647);
        _11646 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_20552);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_20552 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_20555);
        _1 = *(int *)_2;
        *(int *)_2 = _11648;
        if( _1 != _11648 ){
            DeRef(_1);
        }
        _11648 = NOVALUE;
L4: 
L3: 

        /** 	end for*/
        _i_20555 = _i_20555 + 1;
        goto L1; // [84] 17
L2: 
        ;
    }

    /** 	fmt = translate(fmt, langmap, mathcons:PINF)*/
    RefDS(_fmt_20551);
    Ref(_langmap_20553);
    RefDS(_22PINF_4462);
    _0 = _fmt_20551;
    _fmt_20551 = _43translate(_fmt_20551, _langmap_20553, _22PINF_4462, 0);
    DeRefDS(_0);

    /** 	if search:begins("__", fmt) then*/
    RefDS(_11643);
    RefDS(_fmt_20551);
    _11650 = _9begins(_11643, _fmt_20551);
    if (_11650 == 0) {
        DeRef(_11650);
        _11650 = NOVALUE;
        goto L5; // [109] 123
    }
    else {
        if (!IS_ATOM_INT(_11650) && DBL_PTR(_11650)->dbl == 0.0){
            DeRef(_11650);
            _11650 = NOVALUE;
            goto L5; // [109] 123
        }
        DeRef(_11650);
        _11650 = NOVALUE;
    }
    DeRef(_11650);
    _11650 = NOVALUE;

    /** 		fmt = fmt[3 .. $]*/
    if (IS_SEQUENCE(_fmt_20551)){
            _11651 = SEQ_PTR(_fmt_20551)->length;
    }
    else {
        _11651 = 1;
    }
    rhs_slice_target = (object_ptr)&_fmt_20551;
    RHS_Slice(_fmt_20551, 3, _11651);
L5: 

    /** 	return sprintf(fmt, data)	*/
    _11653 = EPrintf(-9999999, _fmt_20551, _data_20552);
    DeRefDS(_fmt_20551);
    DeRefDS(_data_20552);
    DeRef(_langmap_20553);
    return _11653;
    ;
}


int  __stdcall _43set(int _new_locale_20612)
{
    int _lAddr_localename_20613 = NOVALUE;
    int _ign_20614 = NOVALUE;
    int _nlocale_20615 = NOVALUE;
    int _11681 = NOVALUE;
    int _11679 = NOVALUE;
    int _11677 = NOVALUE;
    int _11675 = NOVALUE;
    int _0, _1, _2;
    

    /** 	nlocale = lcc:decanonical(new_locale)*/
    RefDS(_new_locale_20612);
    _0 = _nlocale_20615;
    _nlocale_20615 = _44decanonical(_new_locale_20612);
    DeRef(_0);

    /** 	lAddr_localename = machine:allocate_string(nlocale)*/
    RefDS(_nlocale_20615);
    _0 = _lAddr_localename_20613;
    _lAddr_localename_20613 = _14allocate_string(_nlocale_20615, 0);
    DeRef(_0);

    /** 	ign = c_func(f_setlocale, {LC_MONETARY, lAddr_localename})*/
    Ref(_lAddr_localename_20613);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3;
    ((int *)_2)[2] = _lAddr_localename_20613;
    _11675 = MAKE_SEQ(_1);
    DeRef(_ign_20614);
    _ign_20614 = call_c(1, _43f_setlocale_20593, _11675);
    DeRefDS(_11675);
    _11675 = NOVALUE;

    /** 	ign = c_func(f_setlocale, {LC_NUMERIC, lAddr_localename})*/
    Ref(_lAddr_localename_20613);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _lAddr_localename_20613;
    _11677 = MAKE_SEQ(_1);
    DeRef(_ign_20614);
    _ign_20614 = call_c(1, _43f_setlocale_20593, _11677);
    DeRefDS(_11677);
    _11677 = NOVALUE;

    /** 	ign = c_func(f_setlocale, {LC_ALL, lAddr_localename})*/
    Ref(_lAddr_localename_20613);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _lAddr_localename_20613;
    _11679 = MAKE_SEQ(_1);
    DeRef(_ign_20614);
    _ign_20614 = call_c(1, _43f_setlocale_20593, _11679);
    DeRefDS(_11679);
    _11679 = NOVALUE;

    /** 	machine:free(lAddr_localename)*/
    Ref(_lAddr_localename_20613);
    _14free(_lAddr_localename_20613);

    /** 	if sequence(lang_path) then*/
    _11681 = IS_SEQUENCE(_43lang_path_20420);
    if (_11681 == 0)
    {
        _11681 = NOVALUE;
        goto L1; // [69] 79
    }
    else{
        _11681 = NOVALUE;
    }

    /** 		def_lang = lang_load(nlocale)*/
    RefDS(_nlocale_20615);
    _0 = _43lang_load(_nlocale_20615);
    DeRef(_43def_lang_20419);
    _43def_lang_20419 = _0;
L1: 

    /** 	ign = (ign != dll:NULL)*/
    _0 = _ign_20614;
    if (IS_ATOM_INT(_ign_20614)) {
        _ign_20614 = (_ign_20614 != 0);
    }
    else {
        _ign_20614 = (DBL_PTR(_ign_20614)->dbl != (double)0);
    }
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		if ign then*/
    if (_ign_20614 == 0)
    {
        goto L2; // [89] 100
    }
    else{
    }

    /** 			current_locale = new_locale*/
    RefDS(_new_locale_20612);
    DeRef(_43current_locale_20606);
    _43current_locale_20606 = _new_locale_20612;
L2: 

    /** 	return ign*/
    DeRefDS(_new_locale_20612);
    DeRef(_lAddr_localename_20613);
    DeRef(_nlocale_20615);
    return _ign_20614;
    ;
}


int  __stdcall _43get()
{
    int _r_20631 = NOVALUE;
    int _p_20632 = NOVALUE;
    int _11690 = NOVALUE;
    int _11689 = NOVALUE;
    int _11688 = NOVALUE;
    int _11684 = NOVALUE;
    int _0, _1, _2;
    

    /** 	p = c_func(f_setlocale, {LC_ALL, dll:NULL})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _11684 = MAKE_SEQ(_1);
    DeRef(_p_20632);
    _p_20632 = call_c(1, _43f_setlocale_20593, _11684);
    DeRefDS(_11684);
    _11684 = NOVALUE;

    /** 	if p = dll:NULL then*/
    if (binary_op_a(NOTEQ, _p_20632, 0)){
        goto L1; // [16] 27
    }

    /** 		return ""*/
    RefDS(_5);
    DeRef(_r_20631);
    DeRef(_p_20632);
    return _5;
L1: 

    /** 	r = peek_string(p)*/
    DeRef(_r_20631);
    if (IS_ATOM_INT(_p_20632)) {
        _r_20631 =  NewString((char *)_p_20632);
    }
    else {
        _r_20631 = NewString((char *)(unsigned long)(DBL_PTR(_p_20632)->dbl));
    }

    /** 	ifdef WINDOWS then*/

    /** 		if equal(lcc:decanonical(r), lcc:decanonical(current_locale)) then*/
    RefDS(_r_20631);
    _11688 = _44decanonical(_r_20631);
    RefDS(_43current_locale_20606);
    _11689 = _44decanonical(_43current_locale_20606);
    if (_11688 == _11689)
    _11690 = 1;
    else if (IS_ATOM_INT(_11688) && IS_ATOM_INT(_11689))
    _11690 = 0;
    else
    _11690 = (compare(_11688, _11689) == 0);
    DeRef(_11688);
    _11688 = NOVALUE;
    DeRef(_11689);
    _11689 = NOVALUE;
    if (_11690 == 0)
    {
        _11690 = NOVALUE;
        goto L2; // [52] 64
    }
    else{
        _11690 = NOVALUE;
    }

    /** 			return current_locale*/
    RefDS(_43current_locale_20606);
    DeRefDSi(_r_20631);
    DeRef(_p_20632);
    return _43current_locale_20606;
L2: 

    /** 	r = lcc:canonical(r)*/
    RefDS(_r_20631);
    _0 = _r_20631;
    _r_20631 = _44canonical(_r_20631);
    DeRefDS(_0);

    /** 	return r*/
    DeRef(_p_20632);
    return _r_20631;
    ;
}


int  __stdcall _43money(int _amount_20645)
{
    int _result_20646 = NOVALUE;
    int _pResult_20647 = NOVALUE;
    int _pTmp_20648 = NOVALUE;
    int _11707 = NOVALUE;
    int _11704 = NOVALUE;
    int _11703 = NOVALUE;
    int _11702 = NOVALUE;
    int _11701 = NOVALUE;
    int _11700 = NOVALUE;
    int _11698 = NOVALUE;
    int _11697 = NOVALUE;
    int _11694 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if f_strfmon != -1 then*/
    if (binary_op_a(EQUALS, _43f_strfmon_20583, -1)){
        goto L1; // [5] 98
    }

    /** 		ifdef UNIX then*/

    /** 			pResult = machine:allocate(4 * 160)*/
    _11694 = 640;
    _0 = _pResult_20647;
    _pResult_20647 = _14allocate(640, 0);
    DeRef(_0);
    _11694 = NOVALUE;

    /** 			pTmp = machine:allocate_string(sprintf("%.8f", {amount}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_amount_20645);
    *((int *)(_2+4)) = _amount_20645;
    _11697 = MAKE_SEQ(_1);
    _11698 = EPrintf(-9999999, _11696, _11697);
    DeRefDS(_11697);
    _11697 = NOVALUE;
    _0 = _pTmp_20648;
    _pTmp_20648 = _14allocate_string(_11698, 0);
    DeRef(_0);
    _11698 = NOVALUE;

    /** 			c_func(f_strfmon, {lcid:get_lcid(get()), 0, pTmp, NULL, pResult, 4 * 160})*/
    _11700 = _43get();
    _11701 = _42get_lcid(_11700);
    _11700 = NOVALUE;
    _11702 = 640;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _11701;
    *((int *)(_2+8)) = 0;
    Ref(_pTmp_20648);
    *((int *)(_2+12)) = _pTmp_20648;
    *((int *)(_2+16)) = 0;
    Ref(_pResult_20647);
    *((int *)(_2+20)) = _pResult_20647;
    *((int *)(_2+24)) = 640;
    _11703 = MAKE_SEQ(_1);
    _11702 = NOVALUE;
    _11701 = NOVALUE;
    _11704 = call_c(1, _43f_strfmon_20583, _11703);
    DeRefDS(_11703);
    _11703 = NOVALUE;

    /** 		result = peek_string(pResult)*/
    DeRefi(_result_20646);
    if (IS_ATOM_INT(_pResult_20647)) {
        _result_20646 =  NewString((char *)_pResult_20647);
    }
    else {
        _result_20646 = NewString((char *)(unsigned long)(DBL_PTR(_pResult_20647)->dbl));
    }

    /** 		machine:free(pResult)*/
    Ref(_pResult_20647);
    _14free(_pResult_20647);

    /** 		machine:free(pTmp)*/
    Ref(_pTmp_20648);
    _14free(_pTmp_20648);

    /** 		return result*/
    DeRef(_amount_20645);
    DeRef(_pResult_20647);
    DeRef(_pTmp_20648);
    DeRef(_11704);
    _11704 = NOVALUE;
    return _result_20646;
    goto L2; // [95] 110
L1: 

    /** 		return text:format("$[,,.2]", amount)*/
    RefDS(_11706);
    Ref(_amount_20645);
    _11707 = _6format(_11706, _amount_20645);
    DeRef(_amount_20645);
    DeRefi(_result_20646);
    DeRef(_pResult_20647);
    DeRef(_pTmp_20648);
    DeRef(_11704);
    _11704 = NOVALUE;
    return _11707;
L2: 
    ;
}


int  __stdcall _43number(int _num_20670)
{
    int _result_20671 = NOVALUE;
    int _pResult_20672 = NOVALUE;
    int _pTmp_20673 = NOVALUE;
    int _lpFormat_20677 = NOVALUE;
    int _is_int_20703 = NOVALUE;
    int _float_20707 = NOVALUE;
    int _11750 = NOVALUE;
    int _11748 = NOVALUE;
    int _11747 = NOVALUE;
    int _11745 = NOVALUE;
    int _11744 = NOVALUE;
    int _11742 = NOVALUE;
    int _11740 = NOVALUE;
    int _11739 = NOVALUE;
    int _11736 = NOVALUE;
    int _11735 = NOVALUE;
    int _11734 = NOVALUE;
    int _11728 = NOVALUE;
    int _11727 = NOVALUE;
    int _11726 = NOVALUE;
    int _11725 = NOVALUE;
    int _11724 = NOVALUE;
    int _11723 = NOVALUE;
    int _11721 = NOVALUE;
    int _11720 = NOVALUE;
    int _11717 = NOVALUE;
    int _11716 = NOVALUE;
    int _11714 = NOVALUE;
    int _11712 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		atom lpFormat*/

    /** 		if f_strfnum != -1 then*/
    if (binary_op_a(EQUALS, _43f_strfnum_20588, -1)){
        goto L1; // [9] 116
    }

    /** 			pResult = machine:allocate(4 * 160)*/
    _11712 = 640;
    _0 = _pResult_20672;
    _pResult_20672 = _14allocate(640, 0);
    DeRef(_0);
    _11712 = NOVALUE;

    /** 			if integer(num) then*/
    if (IS_ATOM_INT(_num_20670))
    _11714 = 1;
    else if (IS_ATOM_DBL(_num_20670))
    _11714 = IS_ATOM_INT(DoubleToInt(_num_20670));
    else
    _11714 = 0;
    if (_11714 == 0)
    {
        _11714 = NOVALUE;
        goto L2; // [29] 57
    }
    else{
        _11714 = NOVALUE;
    }

    /** 				pTmp = machine:allocate_string(sprintf("%d", {num}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_num_20670);
    *((int *)(_2+4)) = _num_20670;
    _11716 = MAKE_SEQ(_1);
    _11717 = EPrintf(-9999999, _11715, _11716);
    DeRefDS(_11716);
    _11716 = NOVALUE;
    _0 = _pTmp_20673;
    _pTmp_20673 = _14allocate_string(_11717, 0);
    DeRef(_0);
    _11717 = NOVALUE;

    /** 				lpFormat = NULL*/
    _lpFormat_20677 = 0;
    goto L3; // [54] 80
L2: 

    /** 				lpFormat = NULL*/
    _lpFormat_20677 = 0;

    /** 				pTmp = machine:allocate_string(sprintf("%.15f", {num}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_num_20670);
    *((int *)(_2+4)) = _num_20670;
    _11720 = MAKE_SEQ(_1);
    _11721 = EPrintf(-9999999, _11719, _11720);
    DeRefDS(_11720);
    _11720 = NOVALUE;
    _0 = _pTmp_20673;
    _pTmp_20673 = _14allocate_string(_11721, 0);
    DeRef(_0);
    _11721 = NOVALUE;
L3: 

    /** 			c_func(f_strfnum, {lcid:get_lcid(get()), 0, pTmp, lpFormat, pResult, 4 * 160})*/
    _11723 = _43get();
    _11724 = _42get_lcid(_11723);
    _11723 = NOVALUE;
    _11725 = 640;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _11724;
    *((int *)(_2+8)) = 0;
    Ref(_pTmp_20673);
    *((int *)(_2+12)) = _pTmp_20673;
    *((int *)(_2+16)) = _lpFormat_20677;
    Ref(_pResult_20672);
    *((int *)(_2+20)) = _pResult_20672;
    *((int *)(_2+24)) = 640;
    _11726 = MAKE_SEQ(_1);
    _11725 = NOVALUE;
    _11724 = NOVALUE;
    _11727 = call_c(1, _43f_strfnum_20588, _11726);
    DeRefDS(_11726);
    _11726 = NOVALUE;
    goto L4; // [113] 128
L1: 

    /** 			return text:format("[,,]", num)*/
    RefDS(_11710);
    Ref(_num_20670);
    _11728 = _6format(_11710, _num_20670);
    DeRef(_num_20670);
    DeRef(_result_20671);
    DeRef(_pResult_20672);
    DeRef(_pTmp_20673);
    DeRef(_11727);
    _11727 = NOVALUE;
    return _11728;
L4: 

    /** 	result = peek_string(pResult)*/
    DeRef(_result_20671);
    if (IS_ATOM_INT(_pResult_20672)) {
        _result_20671 =  NewString((char *)_pResult_20672);
    }
    else {
        _result_20671 = NewString((char *)(unsigned long)(DBL_PTR(_pResult_20672)->dbl));
    }

    /** 	machine:free(pResult)*/
    Ref(_pResult_20672);
    _14free(_pResult_20672);

    /** 	machine:free(pTmp)*/
    Ref(_pTmp_20673);
    _14free(_pTmp_20673);

    /** 	integer is_int = integer(num)*/
    if (IS_ATOM_INT(_num_20670))
    _is_int_20703 = 1;
    else if (IS_ATOM_DBL(_num_20670))
    _is_int_20703 = IS_ATOM_INT(DoubleToInt(_num_20670));
    else
    _is_int_20703 = 0;

    /** 	if is_int = 0 then*/
    if (_is_int_20703 != 0)
    goto L5; // [156] 223

    /** 		sequence float = sprintf("%.15f", num)*/
    DeRefi(_float_20707);
    _float_20707 = EPrintf(-9999999, _11719, _num_20670);

    /** 		is_int = find('.', float)*/
    _is_int_20703 = find_from(46, _float_20707, 1);

    /** 		if is_int then*/
    if (_is_int_20703 == 0)
    {
        goto L6; // [175] 222
    }
    else{
    }

    /** 			for i = length(float) to is_int+1 by -1 do*/
    if (IS_SEQUENCE(_float_20707)){
            _11734 = SEQ_PTR(_float_20707)->length;
    }
    else {
        _11734 = 1;
    }
    _11735 = _is_int_20703 + 1;
    {
        int _i_20712;
        _i_20712 = _11734;
L7: 
        if (_i_20712 < _11735){
            goto L8; // [187] 221
        }

        /** 				if float[i] != '0' then*/
        _2 = (int)SEQ_PTR(_float_20707);
        _11736 = (int)*(((s1_ptr)_2)->base + _i_20712);
        if (_11736 == 48)
        goto L9; // [200] 214

        /** 					is_int = 0*/
        _is_int_20703 = 0;

        /** 					exit*/
        goto L8; // [211] 221
L9: 

        /** 			end for*/
        _i_20712 = _i_20712 + -1;
        goto L7; // [216] 194
L8: 
        ;
    }
L6: 
L5: 
    DeRefi(_float_20707);
    _float_20707 = NOVALUE;

    /** 	if is_int != 0 then -- The input was an integer*/
    if (_is_int_20703 == 0)
    goto LA; // [227] 342

    /** 		is_int = 0*/
    _is_int_20703 = 0;

    /** 		for i = length(result) to 1 by -1 do*/
    if (IS_SEQUENCE(_result_20671)){
            _11739 = SEQ_PTR(_result_20671)->length;
    }
    else {
        _11739 = 1;
    }
    {
        int _i_20721;
        _i_20721 = _11739;
LB: 
        if (_i_20721 < 1){
            goto LC; // [241] 280
        }

        /** 			if find(result[i], "1234567890") then*/
        _2 = (int)SEQ_PTR(_result_20671);
        _11740 = (int)*(((s1_ptr)_2)->base + _i_20721);
        _11742 = find_from(_11740, _11741, 1);
        _11740 = NOVALUE;
        if (_11742 == 0)
        {
            _11742 = NOVALUE;
            goto LD; // [259] 273
        }
        else{
            _11742 = NOVALUE;
        }

        /** 				is_int = i + 1*/
        _is_int_20703 = _i_20721 + 1;

        /** 				exit*/
        goto LC; // [270] 280
LD: 

        /** 		end for*/
        _i_20721 = _i_20721 + -1;
        goto LB; // [275] 248
LC: 
        ;
    }

    /** 		for i = is_int - 1 to 1 by -1 do*/
    _11744 = _is_int_20703 - 1;
    if ((long)((unsigned long)_11744 +(unsigned long) HIGH_BITS) >= 0){
        _11744 = NewDouble((double)_11744);
    }
    {
        int _i_20729;
        Ref(_11744);
        _i_20729 = _11744;
LE: 
        if (binary_op_a(LESS, _i_20729, 1)){
            goto LF; // [286] 341
        }

        /** 			if result[i] != '0' then*/
        _2 = (int)SEQ_PTR(_result_20671);
        if (!IS_ATOM_INT(_i_20729)){
            _11745 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_20729)->dbl));
        }
        else{
            _11745 = (int)*(((s1_ptr)_2)->base + _i_20729);
        }
        if (binary_op_a(EQUALS, _11745, 48)){
            _11745 = NOVALUE;
            goto L10; // [299] 334
        }
        _11745 = NOVALUE;

        /** 				if not find(result[i], "1234567890") then*/
        _2 = (int)SEQ_PTR(_result_20671);
        if (!IS_ATOM_INT(_i_20729)){
            _11747 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_20729)->dbl));
        }
        else{
            _11747 = (int)*(((s1_ptr)_2)->base + _i_20729);
        }
        _11748 = find_from(_11747, _11741, 1);
        _11747 = NOVALUE;
        if (_11748 != 0)
        goto LF; // [314] 341
        _11748 = NOVALUE;

        /** 					result = eu:remove(result, i, is_int - 1)*/
        _11750 = _is_int_20703 - 1;
        if ((long)((unsigned long)_11750 +(unsigned long) HIGH_BITS) >= 0){
            _11750 = NewDouble((double)_11750);
        }
        {
            s1_ptr assign_space = SEQ_PTR(_result_20671);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_20729)) ? _i_20729 : (long)(DBL_PTR(_i_20729)->dbl);
            int stop = (IS_ATOM_INT(_11750)) ? _11750 : (long)(DBL_PTR(_11750)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_result_20671), start, &_result_20671 );
                }
                else Tail(SEQ_PTR(_result_20671), stop+1, &_result_20671);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_result_20671), start, &_result_20671);
            }
            else {
                assign_slice_seq = &assign_space;
                _result_20671 = Remove_elements(start, stop, (SEQ_PTR(_result_20671)->ref == 1));
            }
        }
        DeRef(_11750);
        _11750 = NOVALUE;

        /** 				exit*/
        goto LF; // [331] 341
L10: 

        /** 		end for*/
        _0 = _i_20729;
        if (IS_ATOM_INT(_i_20729)) {
            _i_20729 = _i_20729 + -1;
            if ((long)((unsigned long)_i_20729 +(unsigned long) HIGH_BITS) >= 0){
                _i_20729 = NewDouble((double)_i_20729);
            }
        }
        else {
            _i_20729 = binary_op_a(PLUS, _i_20729, -1);
        }
        DeRef(_0);
        goto LE; // [336] 293
LF: 
        ;
        DeRef(_i_20729);
    }
LA: 

    /** 	return result*/
    DeRef(_num_20670);
    DeRef(_pResult_20672);
    DeRef(_pTmp_20673);
    DeRef(_11727);
    _11727 = NOVALUE;
    DeRef(_11728);
    _11728 = NOVALUE;
    DeRef(_11735);
    _11735 = NOVALUE;
    _11736 = NOVALUE;
    DeRef(_11744);
    _11744 = NOVALUE;
    return _result_20671;
    ;
}


int _43mk_tm_struct(int _dtm_20742)
{
    int _pDtm_20743 = NOVALUE;
    int _weeks_day_4__tmp_at107_20770 = NOVALUE;
    int _weeks_day_3__tmp_at107_20769 = NOVALUE;
    int _weeks_day_2__tmp_at107_20768 = NOVALUE;
    int _weeks_day_1__tmp_at107_20767 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_107_20766 = NOVALUE;
    int _years_day_4__tmp_at145_20778 = NOVALUE;
    int _years_day_3__tmp_at145_20777 = NOVALUE;
    int _years_day_2__tmp_at145_20776 = NOVALUE;
    int _years_day_1__tmp_at145_20775 = NOVALUE;
    int _years_day_inlined_years_day_at_145_20774 = NOVALUE;
    int _11769 = NOVALUE;
    int _11768 = NOVALUE;
    int _11767 = NOVALUE;
    int _11766 = NOVALUE;
    int _11765 = NOVALUE;
    int _11764 = NOVALUE;
    int _11763 = NOVALUE;
    int _11762 = NOVALUE;
    int _11761 = NOVALUE;
    int _11760 = NOVALUE;
    int _11759 = NOVALUE;
    int _11758 = NOVALUE;
    int _11757 = NOVALUE;
    int _11756 = NOVALUE;
    int _11755 = NOVALUE;
    int _11754 = NOVALUE;
    int _11753 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pDtm = machine:allocate(36)*/
    _0 = _pDtm_20743;
    _pDtm_20743 = _14allocate(36, 0);
    DeRef(_0);

    /** 	poke4(pDtm,    dtm[SECOND])        -- int tm_sec*/
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11753 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_pDtm_20743)){
        poke4_addr = (unsigned long *)_pDtm_20743;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_pDtm_20743)->dbl);
    }
    if (IS_ATOM_INT(_11753)) {
        *poke4_addr = (unsigned long)_11753;
    }
    else if (IS_ATOM(_11753)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11753)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11753);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _11753 = NOVALUE;

    /** 	poke4(pDtm+4,  dtm[MINUTE])        -- int tm_min*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11754 = _pDtm_20743 + 4;
        if ((long)((unsigned long)_11754 + (unsigned long)HIGH_BITS) >= 0) 
        _11754 = NewDouble((double)_11754);
    }
    else {
        _11754 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)4);
    }
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11755 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_11754)){
        poke4_addr = (unsigned long *)_11754;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11754)->dbl);
    }
    if (IS_ATOM_INT(_11755)) {
        *poke4_addr = (unsigned long)_11755;
    }
    else if (IS_ATOM(_11755)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11755)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11755);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11754);
    _11754 = NOVALUE;
    _11755 = NOVALUE;

    /** 	poke4(pDtm+8,  dtm[HOUR])          -- int tm_hour*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11756 = _pDtm_20743 + 8;
        if ((long)((unsigned long)_11756 + (unsigned long)HIGH_BITS) >= 0) 
        _11756 = NewDouble((double)_11756);
    }
    else {
        _11756 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)8);
    }
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11757 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_11756)){
        poke4_addr = (unsigned long *)_11756;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11756)->dbl);
    }
    if (IS_ATOM_INT(_11757)) {
        *poke4_addr = (unsigned long)_11757;
    }
    else if (IS_ATOM(_11757)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11757)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11757);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11756);
    _11756 = NOVALUE;
    _11757 = NOVALUE;

    /** 	poke4(pDtm+12, dtm[DAY])           -- int tm_mday*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11758 = _pDtm_20743 + 12;
        if ((long)((unsigned long)_11758 + (unsigned long)HIGH_BITS) >= 0) 
        _11758 = NewDouble((double)_11758);
    }
    else {
        _11758 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)12);
    }
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11759 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_11758)){
        poke4_addr = (unsigned long *)_11758;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11758)->dbl);
    }
    if (IS_ATOM_INT(_11759)) {
        *poke4_addr = (unsigned long)_11759;
    }
    else if (IS_ATOM(_11759)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11759)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11759);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11758);
    _11758 = NOVALUE;
    _11759 = NOVALUE;

    /** 	poke4(pDtm+16, dtm[MONTH] - 1)     -- int tm_mon*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11760 = _pDtm_20743 + 16;
        if ((long)((unsigned long)_11760 + (unsigned long)HIGH_BITS) >= 0) 
        _11760 = NewDouble((double)_11760);
    }
    else {
        _11760 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)16);
    }
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11761 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_11761)) {
        _11762 = _11761 - 1;
        if ((long)((unsigned long)_11762 +(unsigned long) HIGH_BITS) >= 0){
            _11762 = NewDouble((double)_11762);
        }
    }
    else {
        _11762 = binary_op(MINUS, _11761, 1);
    }
    _11761 = NOVALUE;
    if (IS_ATOM_INT(_11760)){
        poke4_addr = (unsigned long *)_11760;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11760)->dbl);
    }
    if (IS_ATOM_INT(_11762)) {
        *poke4_addr = (unsigned long)_11762;
    }
    else if (IS_ATOM(_11762)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11762)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11762);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11760);
    _11760 = NOVALUE;
    DeRef(_11762);
    _11762 = NOVALUE;

    /** 	poke4(pDtm+20, dtm[YEAR] - 1900)   -- int tm_year*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11763 = _pDtm_20743 + 20;
        if ((long)((unsigned long)_11763 + (unsigned long)HIGH_BITS) >= 0) 
        _11763 = NewDouble((double)_11763);
    }
    else {
        _11763 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)20);
    }
    _2 = (int)SEQ_PTR(_dtm_20742);
    _11764 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11764)) {
        _11765 = _11764 - 1900;
        if ((long)((unsigned long)_11765 +(unsigned long) HIGH_BITS) >= 0){
            _11765 = NewDouble((double)_11765);
        }
    }
    else {
        _11765 = binary_op(MINUS, _11764, 1900);
    }
    _11764 = NOVALUE;
    if (IS_ATOM_INT(_11763)){
        poke4_addr = (unsigned long *)_11763;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11763)->dbl);
    }
    if (IS_ATOM_INT(_11765)) {
        *poke4_addr = (unsigned long)_11765;
    }
    else if (IS_ATOM(_11765)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11765)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11765);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11763);
    _11763 = NOVALUE;
    DeRef(_11765);
    _11765 = NOVALUE;

    /** 	poke4(pDtm+24, datetime:weeks_day(dtm) - 1)    -- int tm_wday*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11766 = _pDtm_20743 + 24;
        if ((long)((unsigned long)_11766 + (unsigned long)HIGH_BITS) >= 0) 
        _11766 = NewDouble((double)_11766);
    }
    else {
        _11766 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)24);
    }

    /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
    Ref(_dtm_20742);
    _0 = _weeks_day_1__tmp_at107_20767;
    _weeks_day_1__tmp_at107_20767 = _12julianDay(_dtm_20742);
    DeRef(_0);
    DeRef(_weeks_day_2__tmp_at107_20768);
    if (IS_ATOM_INT(_weeks_day_1__tmp_at107_20767)) {
        _weeks_day_2__tmp_at107_20768 = _weeks_day_1__tmp_at107_20767 - 1;
        if ((long)((unsigned long)_weeks_day_2__tmp_at107_20768 +(unsigned long) HIGH_BITS) >= 0){
            _weeks_day_2__tmp_at107_20768 = NewDouble((double)_weeks_day_2__tmp_at107_20768);
        }
    }
    else {
        _weeks_day_2__tmp_at107_20768 = binary_op(MINUS, _weeks_day_1__tmp_at107_20767, 1);
    }
    DeRef(_weeks_day_3__tmp_at107_20769);
    if (IS_ATOM_INT(_weeks_day_2__tmp_at107_20768)) {
        _weeks_day_3__tmp_at107_20769 = _weeks_day_2__tmp_at107_20768 + 4094;
        if ((long)((unsigned long)_weeks_day_3__tmp_at107_20769 + (unsigned long)HIGH_BITS) >= 0) 
        _weeks_day_3__tmp_at107_20769 = NewDouble((double)_weeks_day_3__tmp_at107_20769);
    }
    else {
        _weeks_day_3__tmp_at107_20769 = binary_op(PLUS, _weeks_day_2__tmp_at107_20768, 4094);
    }
    DeRef(_weeks_day_4__tmp_at107_20770);
    if (IS_ATOM_INT(_weeks_day_3__tmp_at107_20769)) {
        _weeks_day_4__tmp_at107_20770 = (_weeks_day_3__tmp_at107_20769 % 7);
    }
    else {
        _weeks_day_4__tmp_at107_20770 = binary_op(REMAINDER, _weeks_day_3__tmp_at107_20769, 7);
    }
    DeRef(_weeks_day_inlined_weeks_day_at_107_20766);
    if (IS_ATOM_INT(_weeks_day_4__tmp_at107_20770)) {
        _weeks_day_inlined_weeks_day_at_107_20766 = _weeks_day_4__tmp_at107_20770 + 1;
        if (_weeks_day_inlined_weeks_day_at_107_20766 > MAXINT){
            _weeks_day_inlined_weeks_day_at_107_20766 = NewDouble((double)_weeks_day_inlined_weeks_day_at_107_20766);
        }
    }
    else
    _weeks_day_inlined_weeks_day_at_107_20766 = binary_op(PLUS, 1, _weeks_day_4__tmp_at107_20770);
    DeRef(_weeks_day_1__tmp_at107_20767);
    _weeks_day_1__tmp_at107_20767 = NOVALUE;
    DeRef(_weeks_day_2__tmp_at107_20768);
    _weeks_day_2__tmp_at107_20768 = NOVALUE;
    DeRef(_weeks_day_3__tmp_at107_20769);
    _weeks_day_3__tmp_at107_20769 = NOVALUE;
    DeRef(_weeks_day_4__tmp_at107_20770);
    _weeks_day_4__tmp_at107_20770 = NOVALUE;
    if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_107_20766)) {
        _11767 = _weeks_day_inlined_weeks_day_at_107_20766 - 1;
        if ((long)((unsigned long)_11767 +(unsigned long) HIGH_BITS) >= 0){
            _11767 = NewDouble((double)_11767);
        }
    }
    else {
        _11767 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_107_20766, 1);
    }
    if (IS_ATOM_INT(_11766)){
        poke4_addr = (unsigned long *)_11766;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11766)->dbl);
    }
    if (IS_ATOM_INT(_11767)) {
        *poke4_addr = (unsigned long)_11767;
    }
    else if (IS_ATOM(_11767)) {
        *poke4_addr = (unsigned long)DBL_PTR(_11767)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_11767);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11766);
    _11766 = NOVALUE;
    DeRef(_11767);
    _11767 = NOVALUE;

    /** 	poke4(pDtm+28, datetime:years_day(dtm))        -- int tm_yday*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11768 = _pDtm_20743 + 28;
        if ((long)((unsigned long)_11768 + (unsigned long)HIGH_BITS) >= 0) 
        _11768 = NewDouble((double)_11768);
    }
    else {
        _11768 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)28);
    }

    /** 	return julianDayOfYear({dt[YEAR], dt[MONTH], dt[DAY]})*/
    DeRef(_years_day_1__tmp_at145_20775);
    _2 = (int)SEQ_PTR(_dtm_20742);
    _years_day_1__tmp_at145_20775 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_years_day_1__tmp_at145_20775);
    DeRef(_years_day_2__tmp_at145_20776);
    _2 = (int)SEQ_PTR(_dtm_20742);
    _years_day_2__tmp_at145_20776 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_years_day_2__tmp_at145_20776);
    DeRef(_years_day_3__tmp_at145_20777);
    _2 = (int)SEQ_PTR(_dtm_20742);
    _years_day_3__tmp_at145_20777 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_years_day_3__tmp_at145_20777);
    _0 = _years_day_4__tmp_at145_20778;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_years_day_1__tmp_at145_20775);
    *((int *)(_2+4)) = _years_day_1__tmp_at145_20775;
    Ref(_years_day_2__tmp_at145_20776);
    *((int *)(_2+8)) = _years_day_2__tmp_at145_20776;
    Ref(_years_day_3__tmp_at145_20777);
    *((int *)(_2+12)) = _years_day_3__tmp_at145_20777;
    _years_day_4__tmp_at145_20778 = MAKE_SEQ(_1);
    DeRef(_0);
    RefDS(_years_day_4__tmp_at145_20778);
    _0 = _years_day_inlined_years_day_at_145_20774;
    _years_day_inlined_years_day_at_145_20774 = _12julianDayOfYear(_years_day_4__tmp_at145_20778);
    DeRef(_0);
    DeRef(_years_day_1__tmp_at145_20775);
    _years_day_1__tmp_at145_20775 = NOVALUE;
    DeRef(_years_day_2__tmp_at145_20776);
    _years_day_2__tmp_at145_20776 = NOVALUE;
    DeRef(_years_day_3__tmp_at145_20777);
    _years_day_3__tmp_at145_20777 = NOVALUE;
    DeRef(_years_day_4__tmp_at145_20778);
    _years_day_4__tmp_at145_20778 = NOVALUE;
    if (IS_ATOM_INT(_11768)){
        poke4_addr = (unsigned long *)_11768;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11768)->dbl);
    }
    if (IS_ATOM_INT(_years_day_inlined_years_day_at_145_20774)) {
        *poke4_addr = (unsigned long)_years_day_inlined_years_day_at_145_20774;
    }
    else if (IS_ATOM(_years_day_inlined_years_day_at_145_20774)) {
        *poke4_addr = (unsigned long)DBL_PTR(_years_day_inlined_years_day_at_145_20774)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_years_day_inlined_years_day_at_145_20774);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_11768);
    _11768 = NOVALUE;

    /** 	poke4(pDtm+32, 0)                  -- int tm_isdst*/
    if (IS_ATOM_INT(_pDtm_20743)) {
        _11769 = _pDtm_20743 + 32;
        if ((long)((unsigned long)_11769 + (unsigned long)HIGH_BITS) >= 0) 
        _11769 = NewDouble((double)_11769);
    }
    else {
        _11769 = NewDouble(DBL_PTR(_pDtm_20743)->dbl + (double)32);
    }
    if (IS_ATOM_INT(_11769)){
        poke4_addr = (unsigned long *)_11769;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_11769)->dbl);
    }
    *poke4_addr = (unsigned long)0;
    DeRef(_11769);
    _11769 = NOVALUE;

    /** 	return pDtm*/
    DeRef(_dtm_20742);
    return _pDtm_20743;
    ;
}


int  __stdcall _43datetime(int _fmt_20782, int _dtm_20783)
{
    int _pFmt_20784 = NOVALUE;
    int _pRes_20785 = NOVALUE;
    int _pDtm_20786 = NOVALUE;
    int _res_20787 = NOVALUE;
    int _11780 = NOVALUE;
    int _11779 = NOVALUE;
    int _11778 = NOVALUE;
    int _11775 = NOVALUE;
    int _11774 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if f_strftime != -1 then*/
    if (binary_op_a(EQUALS, _43f_strftime_20598, -1)){
        goto L1; // [7] 72
    }

    /** 		pDtm = mk_tm_struct(dtm)*/
    Ref(_dtm_20783);
    _0 = _pDtm_20786;
    _pDtm_20786 = _43mk_tm_struct(_dtm_20783);
    DeRef(_0);

    /** 		pFmt = machine:allocate_string(fmt)*/
    RefDS(_fmt_20782);
    _0 = _pFmt_20784;
    _pFmt_20784 = _14allocate_string(_fmt_20782, 0);
    DeRef(_0);

    /** 		pRes = machine:allocate(1024)*/
    _0 = _pRes_20785;
    _pRes_20785 = _14allocate(1024, 0);
    DeRef(_0);

    /** 		c_func(f_strftime, {pRes, 256, pFmt, pDtm})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pRes_20785);
    *((int *)(_2+4)) = _pRes_20785;
    *((int *)(_2+8)) = 256;
    Ref(_pFmt_20784);
    *((int *)(_2+12)) = _pFmt_20784;
    Ref(_pDtm_20786);
    *((int *)(_2+16)) = _pDtm_20786;
    _11774 = MAKE_SEQ(_1);
    _11775 = call_c(1, _43f_strftime_20598, _11774);
    DeRefDS(_11774);
    _11774 = NOVALUE;

    /** 		res = peek_string(pRes)*/
    DeRef(_res_20787);
    if (IS_ATOM_INT(_pRes_20785)) {
        _res_20787 =  NewString((char *)_pRes_20785);
    }
    else {
        _res_20787 = NewString((char *)(unsigned long)(DBL_PTR(_pRes_20785)->dbl));
    }

    /** 		machine:free(pRes)*/
    Ref(_pRes_20785);
    _14free(_pRes_20785);

    /** 		machine:free(pFmt)*/
    Ref(_pFmt_20784);
    _14free(_pFmt_20784);

    /** 		machine:free(pDtm)*/
    Ref(_pDtm_20786);
    _14free(_pDtm_20786);
    goto L2; // [69] 107
L1: 

    /** 		res = date()*/
    DeRef(_res_20787);
    _res_20787 = Date();

    /** 		res[1] += 1900*/
    _2 = (int)SEQ_PTR(_res_20787);
    _11778 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11778)) {
        _11779 = _11778 + 1900;
        if ((long)((unsigned long)_11779 + (unsigned long)HIGH_BITS) >= 0) 
        _11779 = NewDouble((double)_11779);
    }
    else {
        _11779 = binary_op(PLUS, _11778, 1900);
    }
    _11778 = NOVALUE;
    _2 = (int)SEQ_PTR(_res_20787);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _res_20787 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _11779;
    if( _1 != _11779 ){
        DeRef(_1);
    }
    _11779 = NOVALUE;

    /** 		res = datetime:format(res[1..6], fmt)*/
    rhs_slice_target = (object_ptr)&_11780;
    RHS_Slice(_res_20787, 1, 6);
    RefDS(_fmt_20782);
    _0 = _res_20787;
    _res_20787 = _12format(_11780, _fmt_20782);
    DeRefDS(_0);
    _11780 = NOVALUE;
L2: 

    /** 	return res*/
    DeRefDS(_fmt_20782);
    DeRef(_dtm_20783);
    DeRef(_pFmt_20784);
    DeRef(_pRes_20785);
    DeRef(_pDtm_20786);
    DeRef(_11775);
    _11775 = NOVALUE;
    return _res_20787;
    ;
}


int  __stdcall _43get_text(int _MsgNum_20804, int _LocalQuals_20805, int _DBBase_20806)
{
    int _db_res_20808 = NOVALUE;
    int _lMsgText_20809 = NOVALUE;
    int _dbname_20810 = NOVALUE;
    int _11818 = NOVALUE;
    int _11816 = NOVALUE;
    int _11814 = NOVALUE;
    int _11813 = NOVALUE;
    int _11812 = NOVALUE;
    int _11810 = NOVALUE;
    int _11809 = NOVALUE;
    int _11808 = NOVALUE;
    int _11802 = NOVALUE;
    int _11801 = NOVALUE;
    int _11800 = NOVALUE;
    int _11793 = NOVALUE;
    int _11790 = NOVALUE;
    int _11788 = NOVALUE;
    int _11786 = NOVALUE;
    int _11785 = NOVALUE;
    int _11784 = NOVALUE;
    int _11783 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_20804)) {
        _1 = (long)(DBL_PTR(_MsgNum_20804)->dbl);
        DeRefDS(_MsgNum_20804);
        _MsgNum_20804 = _1;
    }

    /** 	db_res = -1*/
    _db_res_20808 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_20809);
    _lMsgText_20809 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_20805);
    _11783 = _7string(_LocalQuals_20805);
    if (IS_ATOM_INT(_11783)) {
        if (_11783 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11783)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_20805)){
            _11785 = SEQ_PTR(_LocalQuals_20805)->length;
    }
    else {
        _11785 = 1;
    }
    _11786 = (_11785 > 0);
    _11785 = NOVALUE;
    if (_11786 == 0)
    {
        DeRef(_11786);
        _11786 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11786);
        _11786 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_20805;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_20805);
    *((int *)(_2+4)) = _LocalQuals_20805;
    _LocalQuals_20805 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20805)){
            _11788 = SEQ_PTR(_LocalQuals_20805)->length;
    }
    else {
        _11788 = 1;
    }
    {
        int _i_20819;
        _i_20819 = 1;
L2: 
        if (_i_20819 > _11788){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_20805);
        _11790 = (int)*(((s1_ptr)_2)->base + _i_20819);
        {
            int concat_list[4];

            concat_list[0] = _11791;
            concat_list[1] = _11790;
            concat_list[2] = _11789;
            concat_list[3] = _DBBase_20806;
            Concat_N((object_ptr)&_dbname_20810, concat_list, 4);
        }
        _11790 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_20810);
        RefDS(_5);
        RefDS(_5);
        _11793 = _11locate_file(_dbname_20810, _5, _5);
        _db_res_20808 = _38db_select(_11793, 3);
        _11793 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_20808)) {
            _1 = (long)(DBL_PTR(_db_res_20808)->dbl);
            DeRefDS(_db_res_20808);
            _db_res_20808 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_20808 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11796);
        _db_res_20808 = _38db_select_table(_11796);
        if (!IS_ATOM_INT(_db_res_20808)) {
            _1 = (long)(DBL_PTR(_db_res_20808)->dbl);
            DeRefDS(_db_res_20808);
            _db_res_20808 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_20808 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_38current_table_name_16701);
        _0 = _lMsgText_20809;
        _lMsgText_20809 = _38db_fetch_record(_MsgNum_20804, _38current_table_name_16701);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11800 = IS_SEQUENCE(_lMsgText_20809);
        if (_11800 == 0)
        {
            _11800 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11800 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_20819 = _i_20819 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11801 = IS_ATOM(_lMsgText_20809);
    if (_11801 == 0)
    {
        _11801 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11801 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11802, _DBBase_20806, _11791);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_20810;
    _dbname_20810 = _11locate_file(_11802, _5, _5);
    DeRef(_0);
    _11802 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_20810);
    _db_res_20808 = _38db_select(_dbname_20810, 3);
    if (!IS_ATOM_INT(_db_res_20808)) {
        _1 = (long)(DBL_PTR(_db_res_20808)->dbl);
        DeRefDS(_db_res_20808);
        _db_res_20808 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_20808 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11796);
    _db_res_20808 = _38db_select_table(_11796);
    if (!IS_ATOM_INT(_db_res_20808)) {
        _1 = (long)(DBL_PTR(_db_res_20808)->dbl);
        DeRefDS(_db_res_20808);
        _db_res_20808 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_20808 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_20805)){
            _11808 = SEQ_PTR(_LocalQuals_20805)->length;
    }
    else {
        _11808 = 1;
    }
    {
        int _i_20848;
        _i_20848 = 1;
LA: 
        if (_i_20848 > _11808){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_20805);
        _11809 = (int)*(((s1_ptr)_2)->base + _i_20848);
        Ref(_11809);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11809;
        ((int *)_2)[2] = _MsgNum_20804;
        _11810 = MAKE_SEQ(_1);
        _11809 = NOVALUE;
        RefDS(_38current_table_name_16701);
        _0 = _lMsgText_20809;
        _lMsgText_20809 = _38db_fetch_record(_11810, _38current_table_name_16701);
        DeRef(_0);
        _11810 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11812 = IS_SEQUENCE(_lMsgText_20809);
        if (_11812 == 0)
        {
            _11812 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11812 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_20848 = _i_20848 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11813 = IS_ATOM(_lMsgText_20809);
    if (_11813 == 0)
    {
        _11813 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11813 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_20804;
    _11814 = MAKE_SEQ(_1);
    RefDS(_38current_table_name_16701);
    _0 = _lMsgText_20809;
    _lMsgText_20809 = _38db_fetch_record(_11814, _38current_table_name_16701);
    DeRef(_0);
    _11814 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11816 = IS_ATOM(_lMsgText_20809);
    if (_11816 == 0)
    {
        _11816 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11816 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_38current_table_name_16701);
    _0 = _lMsgText_20809;
    _lMsgText_20809 = _38db_fetch_record(_MsgNum_20804, _38current_table_name_16701);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11818 = IS_ATOM(_lMsgText_20809);
    if (_11818 == 0)
    {
        _11818 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11818 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_20805);
    DeRefDS(_DBBase_20806);
    DeRef(_lMsgText_20809);
    DeRef(_dbname_20810);
    DeRef(_11783);
    _11783 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_20805);
    DeRefDS(_DBBase_20806);
    DeRef(_dbname_20810);
    DeRef(_11783);
    _11783 = NOVALUE;
    return _lMsgText_20809;
L10: 
    ;
}



// 0x098C257D
