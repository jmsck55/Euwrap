// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _40get_position()
{
    int _10632 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_GET_POSITION, 0)*/
    _10632 = machine(25, 0);
    return _10632;
    ;
}


void  __stdcall _40text_color(int _c_19118)
{
    int _10634 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = and_bits(c, 0x1F)*/
    _0 = _c_19118;
    if (IS_ATOM_INT(_c_19118)) {
        {unsigned long tu;
             tu = (unsigned long)_c_19118 & (unsigned long)31;
             _c_19118 = MAKE_UINT(tu);
        }
    }
    else {
        _c_19118 = binary_op(AND_BITS, _c_19118, 31);
    }
    DeRef(_0);

    /** 	c = true_fgcolor[c+1]*/
    if (IS_ATOM_INT(_c_19118)) {
        _10634 = _c_19118 + 1;
    }
    else
    _10634 = binary_op(PLUS, 1, _c_19118);
    DeRef(_c_19118);
    _2 = (int)SEQ_PTR(_36true_fgcolor_14320);
    if (!IS_ATOM_INT(_10634)){
        _c_19118 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10634)->dbl));
    }
    else{
        _c_19118 = (int)*(((s1_ptr)_2)->base + _10634);
    }
    Ref(_c_19118);

    /** 	machine_proc(M_SET_T_COLOR, c)*/
    machine(9, _c_19118);

    /** end procedure*/
    DeRef(_c_19118);
    DeRef(_10634);
    _10634 = NOVALUE;
    return;
    ;
}


void  __stdcall _40bk_color(int _c_19126)
{
    int _10637 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = and_bits(c, 0x1F)*/
    _0 = _c_19126;
    if (IS_ATOM_INT(_c_19126)) {
        {unsigned long tu;
             tu = (unsigned long)_c_19126 & (unsigned long)31;
             _c_19126 = MAKE_UINT(tu);
        }
    }
    else {
        _c_19126 = binary_op(AND_BITS, _c_19126, 31);
    }
    DeRef(_0);

    /** 	c = true_bgcolor[c+1]*/
    if (IS_ATOM_INT(_c_19126)) {
        _10637 = _c_19126 + 1;
    }
    else
    _10637 = binary_op(PLUS, 1, _c_19126);
    DeRef(_c_19126);
    _2 = (int)SEQ_PTR(_36true_bgcolor_14322);
    if (!IS_ATOM_INT(_10637)){
        _c_19126 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10637)->dbl));
    }
    else{
        _c_19126 = (int)*(((s1_ptr)_2)->base + _10637);
    }
    Ref(_c_19126);

    /** 	machine_proc(M_SET_B_COLOR, c)*/
    machine(10, _c_19126);

    /** end procedure*/
    DeRef(_c_19126);
    DeRef(_10637);
    _10637 = NOVALUE;
    return;
    ;
}


int  __stdcall _40console_colors(int _colorset_19133)
{
    int _currentset_19134 = NOVALUE;
    int _10668 = NOVALUE;
    int _10667 = NOVALUE;
    int _10666 = NOVALUE;
    int _10665 = NOVALUE;
    int _10664 = NOVALUE;
    int _10663 = NOVALUE;
    int _10661 = NOVALUE;
    int _10660 = NOVALUE;
    int _10659 = NOVALUE;
    int _10658 = NOVALUE;
    int _10656 = NOVALUE;
    int _10655 = NOVALUE;
    int _10653 = NOVALUE;
    int _10652 = NOVALUE;
    int _10651 = NOVALUE;
    int _10650 = NOVALUE;
    int _10648 = NOVALUE;
    int _10647 = NOVALUE;
    int _10645 = NOVALUE;
    int _10642 = NOVALUE;
    int _10640 = NOVALUE;
    int _10639 = NOVALUE;
    int _0, _1, _2;
    

    /** 	currentset = {true_fgcolor[1 .. 16], true_bgcolor[1 .. 16]}*/
    rhs_slice_target = (object_ptr)&_10639;
    RHS_Slice(_36true_fgcolor_14320, 1, 16);
    rhs_slice_target = (object_ptr)&_10640;
    RHS_Slice(_36true_bgcolor_14322, 1, 16);
    DeRef(_currentset_19134);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _10639;
    ((int *)_2)[2] = _10640;
    _currentset_19134 = MAKE_SEQ(_1);
    _10640 = NOVALUE;
    _10639 = NOVALUE;

    /** 	if length(colorset) = 16 then*/
    if (IS_SEQUENCE(_colorset_19133)){
            _10642 = SEQ_PTR(_colorset_19133)->length;
    }
    else {
        _10642 = 1;
    }
    if (_10642 != 16)
    goto L1; // [28] 39

    /** 		colorset = {colorset, colorset}*/
    RefDS(_colorset_19133);
    RefDS(_colorset_19133);
    _0 = _colorset_19133;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _colorset_19133;
    ((int *)_2)[2] = _colorset_19133;
    _colorset_19133 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	if length(colorset) != 2 then*/
    if (IS_SEQUENCE(_colorset_19133)){
            _10645 = SEQ_PTR(_colorset_19133)->length;
    }
    else {
        _10645 = 1;
    }
    if (_10645 == 2)
    goto L2; // [44] 55

    /** 		return currentset*/
    DeRefDS(_colorset_19133);
    return _currentset_19134;
L2: 

    /** 	if length(colorset[FGSET]) != 16 then*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10647 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_10647)){
            _10648 = SEQ_PTR(_10647)->length;
    }
    else {
        _10648 = 1;
    }
    _10647 = NOVALUE;
    if (_10648 == 16)
    goto L3; // [66] 77

    /** 	   	return currentset*/
    DeRefDS(_colorset_19133);
    _10647 = NOVALUE;
    return _currentset_19134;
L3: 

    /** 	if not types:char_test( colorset[FGSET], {{0,15}} ) then*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10650 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 15;
    _10651 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _10651;
    _10652 = MAKE_SEQ(_1);
    _10651 = NOVALUE;
    Ref(_10650);
    _10653 = _7char_test(_10650, _10652);
    _10650 = NOVALUE;
    _10652 = NOVALUE;
    if (IS_ATOM_INT(_10653)) {
        if (_10653 != 0){
            DeRef(_10653);
            _10653 = NOVALUE;
            goto L4; // [98] 108
        }
    }
    else {
        if (DBL_PTR(_10653)->dbl != 0.0){
            DeRef(_10653);
            _10653 = NOVALUE;
            goto L4; // [98] 108
        }
    }
    DeRef(_10653);
    _10653 = NOVALUE;

    /** 	   	return currentset*/
    DeRefDS(_colorset_19133);
    _10647 = NOVALUE;
    return _currentset_19134;
L4: 

    /** 	if length(colorset[BGSET]) != 16 then*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10655 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_10655)){
            _10656 = SEQ_PTR(_10655)->length;
    }
    else {
        _10656 = 1;
    }
    _10655 = NOVALUE;
    if (_10656 == 16)
    goto L5; // [119] 130

    /** 	   	return currentset*/
    DeRefDS(_colorset_19133);
    _10647 = NOVALUE;
    _10655 = NOVALUE;
    return _currentset_19134;
L5: 

    /** 	if not types:char_test( colorset[BGSET], {{0,15}} ) then*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10658 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 15;
    _10659 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _10659;
    _10660 = MAKE_SEQ(_1);
    _10659 = NOVALUE;
    Ref(_10658);
    _10661 = _7char_test(_10658, _10660);
    _10658 = NOVALUE;
    _10660 = NOVALUE;
    if (IS_ATOM_INT(_10661)) {
        if (_10661 != 0){
            DeRef(_10661);
            _10661 = NOVALUE;
            goto L6; // [151] 161
        }
    }
    else {
        if (DBL_PTR(_10661)->dbl != 0.0){
            DeRef(_10661);
            _10661 = NOVALUE;
            goto L6; // [151] 161
        }
    }
    DeRef(_10661);
    _10661 = NOVALUE;

    /** 	   	return currentset*/
    DeRefDS(_colorset_19133);
    _10647 = NOVALUE;
    _10655 = NOVALUE;
    return _currentset_19134;
L6: 

    /** 	true_fgcolor[1..16]  = colorset[FGSET]*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10663 = (int)*(((s1_ptr)_2)->base + 1);
    assign_slice_seq = (s1_ptr *)&_36true_fgcolor_14320;
    AssignSlice(1, 16, _10663);
    _10663 = NOVALUE;

    /** 	true_fgcolor[17..32] = colorset[FGSET] + BLINKING*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10664 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10664)) {
        _10665 = _10664 + 16;
        if ((long)((unsigned long)_10665 + (unsigned long)HIGH_BITS) >= 0) 
        _10665 = NewDouble((double)_10665);
    }
    else {
        _10665 = binary_op(PLUS, _10664, 16);
    }
    _10664 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_36true_fgcolor_14320;
    AssignSlice(17, 32, _10665);
    DeRef(_10665);
    _10665 = NOVALUE;

    /** 	true_bgcolor[1..16]  = colorset[BGSET]*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10666 = (int)*(((s1_ptr)_2)->base + 2);
    assign_slice_seq = (s1_ptr *)&_36true_bgcolor_14322;
    AssignSlice(1, 16, _10666);
    _10666 = NOVALUE;

    /** 	true_bgcolor[17..32] = colorset[BGSET] + BLINKING*/
    _2 = (int)SEQ_PTR(_colorset_19133);
    _10667 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10667)) {
        _10668 = _10667 + 16;
        if ((long)((unsigned long)_10668 + (unsigned long)HIGH_BITS) >= 0) 
        _10668 = NewDouble((double)_10668);
    }
    else {
        _10668 = binary_op(PLUS, _10667, 16);
    }
    _10667 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_36true_bgcolor_14322;
    AssignSlice(17, 32, _10668);
    DeRef(_10668);
    _10668 = NOVALUE;

    /** 	return currentset*/
    DeRefDS(_colorset_19133);
    _10647 = NOVALUE;
    _10655 = NOVALUE;
    return _currentset_19134;
    ;
}


void  __stdcall _40wrap(int _on_19189)
{
    int _10670 = NOVALUE;
    int _10669 = NOVALUE;
    int _0, _1, _2;
    

    /** 	machine_proc(M_WRAP, not equal(on, 0))*/
    if (_on_19189 == 0)
    _10669 = 1;
    else if (IS_ATOM_INT(_on_19189) && IS_ATOM_INT(0))
    _10669 = 0;
    else
    _10669 = (compare(_on_19189, 0) == 0);
    _10670 = (_10669 == 0);
    _10669 = NOVALUE;
    machine(7, _10670);
    _10670 = NOVALUE;

    /** end procedure*/
    DeRef(_on_19189);
    return;
    ;
}


void  __stdcall _40scroll(int _amount_19194, int _top_line_19195, int _bottom_line_19196)
{
    int _10671 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_19194)) {
        _1 = (long)(DBL_PTR(_amount_19194)->dbl);
        DeRefDS(_amount_19194);
        _amount_19194 = _1;
    }

    /** 	machine_proc(M_SCROLL, {amount, top_line, bottom_line})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _amount_19194;
    Ref(_top_line_19195);
    *((int *)(_2+8)) = _top_line_19195;
    Ref(_bottom_line_19196);
    *((int *)(_2+12)) = _bottom_line_19196;
    _10671 = MAKE_SEQ(_1);
    machine(8, _10671);
    DeRefDS(_10671);
    _10671 = NOVALUE;

    /** end procedure*/
    DeRef(_top_line_19195);
    DeRef(_bottom_line_19196);
    return;
    ;
}


int  __stdcall _40graphics_mode(int _m_19200)
{
    int _10672 = NOVALUE;
    int _0, _1, _2;
    

    /**    return machine_func(M_GRAPHICS_MODE, m)*/
    _10672 = machine(5, _m_19200);
    DeRef(_m_19200);
    return _10672;
    ;
}



// 0x1989F9D5
