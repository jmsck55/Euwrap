// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _55parse_querystring(int _query_string_22995)
{
    int _i_22996 = NOVALUE;
    int _char_22997 = NOVALUE;
    int _tmp_22998 = NOVALUE;
    int _charbuf_22999 = NOVALUE;
    int _fname_23000 = NOVALUE;
    int _the_map_23001 = NOVALUE;
    int _value_inlined_value_at_100_23020 = NOVALUE;
    int _st_inlined_value_at_97_23019 = NOVALUE;
    int _12794 = NOVALUE;
    int _12787 = NOVALUE;
    int _12786 = NOVALUE;
    int _12785 = NOVALUE;
    int _12784 = NOVALUE;
    int _12783 = NOVALUE;
    int _12782 = NOVALUE;
    int _12776 = NOVALUE;
    int _12775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence charbuf, fname=""*/
    RefDS(_5);
    DeRef(_fname_23000);
    _fname_23000 = _5;

    /** 	map:map the_map = map:new()*/
    _0 = _the_map_23001;
    _the_map_23001 = _33new(690);
    DeRef(_0);

    /** 	if atom(query_string) then*/
    _12775 = IS_ATOM(_query_string_22995);
    if (_12775 == 0)
    {
        _12775 = NOVALUE;
        goto L1; // [19] 29
    }
    else{
        _12775 = NOVALUE;
    }

    /** 		return the_map*/
    DeRef(_query_string_22995);
    DeRef(_tmp_22998);
    DeRef(_charbuf_22999);
    DeRefDS(_fname_23000);
    return _the_map_23001;
L1: 

    /** 	charbuf = {}  */
    RefDS(_5);
    DeRef(_charbuf_22999);
    _charbuf_22999 = _5;

    /** 	i = 1*/
    _i_22996 = 1;

    /** 	while i <= length(query_string) do*/
L2: 
    if (IS_SEQUENCE(_query_string_22995)){
            _12776 = SEQ_PTR(_query_string_22995)->length;
    }
    else {
        _12776 = 1;
    }
    if (_i_22996 > _12776)
    goto L3; // [49] 221

    /** 		char = query_string[i]  -- character we're working on*/
    _2 = (int)SEQ_PTR(_query_string_22995);
    _char_22997 = (int)*(((s1_ptr)_2)->base + _i_22996);
    if (!IS_ATOM_INT(_char_22997)){
        _char_22997 = (long)DBL_PTR(_char_22997)->dbl;
    }

    /** 		switch char do*/
    _0 = _char_22997;
    switch ( _0 ){ 

        /** 			case HEX_SIG then*/
        case 37:

        /** 				tmp = stdget:value("#" & query_string[i+1] & query_string[i+2])*/
        _12782 = _i_22996 + 1;
        _2 = (int)SEQ_PTR(_query_string_22995);
        _12783 = (int)*(((s1_ptr)_2)->base + _12782);
        _12784 = _i_22996 + 2;
        _2 = (int)SEQ_PTR(_query_string_22995);
        _12785 = (int)*(((s1_ptr)_2)->base + _12784);
        {
            int concat_list[3];

            concat_list[0] = _12785;
            concat_list[1] = _12783;
            concat_list[2] = _12781;
            Concat_N((object_ptr)&_12786, concat_list, 3);
        }
        _12785 = NOVALUE;
        _12783 = NOVALUE;
        DeRef(_st_inlined_value_at_97_23019);
        _st_inlined_value_at_97_23019 = _12786;
        _12786 = NOVALUE;
        if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3332)) {
            _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3332)->dbl);
            DeRefDS(_17GET_SHORT_ANSWER_3332);
            _17GET_SHORT_ANSWER_3332 = _1;
        }

        /** 	return get_value(st, start_point, answer)*/
        RefDS(_st_inlined_value_at_97_23019);
        _0 = _tmp_22998;
        _tmp_22998 = _17get_value(_st_inlined_value_at_97_23019, 1, _17GET_SHORT_ANSWER_3332);
        DeRef(_0);
        DeRef(_st_inlined_value_at_97_23019);
        _st_inlined_value_at_97_23019 = NOVALUE;

        /** 				charbuf &= tmp[2]*/
        _2 = (int)SEQ_PTR(_tmp_22998);
        _12787 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_charbuf_22999) && IS_ATOM(_12787)) {
            Ref(_12787);
            Append(&_charbuf_22999, _charbuf_22999, _12787);
        }
        else if (IS_ATOM(_charbuf_22999) && IS_SEQUENCE(_12787)) {
        }
        else {
            Concat((object_ptr)&_charbuf_22999, _charbuf_22999, _12787);
        }
        _12787 = NOVALUE;

        /** 				i += 2 -- skip over hex digits*/
        _i_22996 = _i_22996 + 2;
        goto L4; // [132] 210

        /** 			case WHITESPACE then*/
        case 43:

        /** 				charbuf &= " "*/
        Concat((object_ptr)&_charbuf_22999, _charbuf_22999, _12790);
        goto L4; // [144] 210

        /** 			case VALUE_SEP then*/
        case 61:

        /** 				fname = charbuf*/
        RefDS(_charbuf_22999);
        DeRef(_fname_23000);
        _fname_23000 = _charbuf_22999;

        /** 				charbuf = {}*/
        RefDS(_5);
        DeRefDS(_charbuf_22999);
        _charbuf_22999 = _5;
        goto L4; // [164] 210

        /** 			case PAIR_SEP_A, PAIR_SEP_B then*/
        case 38:
        case 59:

        /** 				map:put(the_map, fname, charbuf)*/
        Ref(_the_map_23001);
        RefDS(_fname_23000);
        RefDS(_charbuf_22999);
        _33put(_the_map_23001, _fname_23000, _charbuf_22999, 1, _33threshold_size_12989);

        /** 				fname = {}*/
        RefDS(_5);
        DeRefDS(_fname_23000);
        _fname_23000 = _5;

        /** 				charbuf = {}*/
        RefDS(_5);
        DeRefDS(_charbuf_22999);
        _charbuf_22999 = _5;
        goto L4; // [197] 210

        /** 			case else*/
        default:

        /** 				charbuf &= char*/
        Append(&_charbuf_22999, _charbuf_22999, _char_22997);
    ;}L4: 

    /** 		i += 1*/
    _i_22996 = _i_22996 + 1;

    /** 	end while*/
    goto L2; // [218] 46
L3: 

    /** 	if length(fname) then*/
    if (IS_SEQUENCE(_fname_23000)){
            _12794 = SEQ_PTR(_fname_23000)->length;
    }
    else {
        _12794 = 1;
    }
    if (_12794 == 0)
    {
        _12794 = NOVALUE;
        goto L5; // [226] 241
    }
    else{
        _12794 = NOVALUE;
    }

    /** 		map:put(the_map, fname, charbuf)*/
    Ref(_the_map_23001);
    RefDS(_fname_23000);
    RefDS(_charbuf_22999);
    _33put(_the_map_23001, _fname_23000, _charbuf_22999, 1, _33threshold_size_12989);
L5: 

    /** 	return the_map*/
    DeRef(_query_string_22995);
    DeRef(_tmp_22998);
    DeRef(_charbuf_22999);
    DeRef(_fname_23000);
    DeRef(_12782);
    _12782 = NOVALUE;
    DeRef(_12784);
    _12784 = NOVALUE;
    return _the_map_23001;
    ;
}


int  __stdcall _55parse(int _url_23043, int _querystring_also_23044)
{
    int _protocol_23045 = NOVALUE;
    int _host_name_23046 = NOVALUE;
    int _path_23047 = NOVALUE;
    int _user_name_23048 = NOVALUE;
    int _password_23049 = NOVALUE;
    int _query_string_23050 = NOVALUE;
    int _port_23051 = NOVALUE;
    int _pos_23052 = NOVALUE;
    int _at_23071 = NOVALUE;
    int _password_colon_23076 = NOVALUE;
    int _qs_start_23091 = NOVALUE;
    int _first_slash_23094 = NOVALUE;
    int _port_colon_23096 = NOVALUE;
    int _port_end_23115 = NOVALUE;
    int _12858 = NOVALUE;
    int _12856 = NOVALUE;
    int _12855 = NOVALUE;
    int _12853 = NOVALUE;
    int _12852 = NOVALUE;
    int _12849 = NOVALUE;
    int _12846 = NOVALUE;
    int _12842 = NOVALUE;
    int _12841 = NOVALUE;
    int _12836 = NOVALUE;
    int _12834 = NOVALUE;
    int _12832 = NOVALUE;
    int _12828 = NOVALUE;
    int _12821 = NOVALUE;
    int _12819 = NOVALUE;
    int _12818 = NOVALUE;
    int _12816 = NOVALUE;
    int _12815 = NOVALUE;
    int _12814 = NOVALUE;
    int _12813 = NOVALUE;
    int _12806 = NOVALUE;
    int _12803 = NOVALUE;
    int _12800 = NOVALUE;
    int _12797 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_querystring_also_23044)) {
        _1 = (long)(DBL_PTR(_querystring_also_23044)->dbl);
        DeRefDS(_querystring_also_23044);
        _querystring_also_23044 = _1;
    }

    /**     sequence protocol = ""*/
    RefDS(_5);
    DeRef(_protocol_23045);
    _protocol_23045 = _5;

    /**     host_name = 0*/
    DeRef(_host_name_23046);
    _host_name_23046 = 0;

    /**     port = 0*/
    _port_23051 = 0;

    /**     path = 0*/
    DeRef(_path_23047);
    _path_23047 = 0;

    /**     user_name = 0*/
    DeRef(_user_name_23048);
    _user_name_23048 = 0;

    /**     password  = 0*/
    DeRef(_password_23049);
    _password_23049 = 0;

    /**     query_string = 0*/
    DeRef(_query_string_23050);
    _query_string_23050 = 0;

    /** 	integer pos = find(':', url)*/
    _pos_23052 = find_from(58, _url_23043, 1);

    /**     if not pos then*/
    if (_pos_23052 != 0)
    goto L1; // [51] 61

    /**         return 0*/
    DeRefDS(_url_23043);
    DeRefDS(_protocol_23045);
    return 0;
L1: 

    /** 	protocol = url[1..pos - 1]*/
    _12797 = _pos_23052 - 1;
    rhs_slice_target = (object_ptr)&_protocol_23045;
    RHS_Slice(_url_23043, 1, _12797);

    /**     pos += 1*/
    _pos_23052 = _pos_23052 + 1;

    /**     if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_23043);
    _12800 = (int)*(((s1_ptr)_2)->base + _pos_23052);
    if (binary_op_a(NOTEQ, _12800, 47)){
        _12800 = NOVALUE;
        goto L2; // [84] 95
    }
    _12800 = NOVALUE;

    /**         pos += 1*/
    _pos_23052 = _pos_23052 + 1;
L2: 

    /**     if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_23043);
    _12803 = (int)*(((s1_ptr)_2)->base + _pos_23052);
    if (binary_op_a(NOTEQ, _12803, 47)){
        _12803 = NOVALUE;
        goto L3; // [101] 112
    }
    _12803 = NOVALUE;

    /**         pos += 1*/
    _pos_23052 = _pos_23052 + 1;
L3: 

    /** 	if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_23043);
    _12806 = (int)*(((s1_ptr)_2)->base + _pos_23052);
    if (binary_op_a(NOTEQ, _12806, 47)){
        _12806 = NOVALUE;
        goto L4; // [118] 129
    }
    _12806 = NOVALUE;

    /**         goto "parse_path"*/
    goto G5;
L4: 

    /** 	integer at = find('@', url)*/
    _at_23071 = find_from(64, _url_23043, 1);

    /**     if not at then*/
    if (_at_23071 != 0)
    goto L6; // [138] 148

    /**         goto "parse_domain"*/
    goto G7;
L6: 

    /**     integer password_colon = find(':', url, pos)*/
    _password_colon_23076 = find_from(58, _url_23043, _pos_23052);

    /**     if password_colon > 0 and password_colon < at then*/
    _12813 = (_password_colon_23076 > 0);
    if (_12813 == 0) {
        goto L8; // [161] 202
    }
    _12815 = (_password_colon_23076 < _at_23071);
    if (_12815 == 0)
    {
        DeRef(_12815);
        _12815 = NOVALUE;
        goto L8; // [170] 202
    }
    else{
        DeRef(_12815);
        _12815 = NOVALUE;
    }

    /**         user_name = url[pos..password_colon-1]*/
    _12816 = _password_colon_23076 - 1;
    rhs_slice_target = (object_ptr)&_user_name_23048;
    RHS_Slice(_url_23043, _pos_23052, _12816);

    /**         password = url[password_colon+1..at-1]*/
    _12818 = _password_colon_23076 + 1;
    if (_12818 > MAXINT){
        _12818 = NewDouble((double)_12818);
    }
    _12819 = _at_23071 - 1;
    rhs_slice_target = (object_ptr)&_password_23049;
    RHS_Slice(_url_23043, _12818, _12819);
    goto L9; // [199] 214
L8: 

    /**     	user_name = url[pos..at-1]*/
    _12821 = _at_23071 - 1;
    rhs_slice_target = (object_ptr)&_user_name_23048;
    RHS_Slice(_url_23043, _pos_23052, _12821);
L9: 

    /**     pos = at + 1*/
    _pos_23052 = _at_23071 + 1;

    /** label "parse_domain"*/
G7:

    /**     integer qs_start = find('?', url, pos)*/
    _qs_start_23091 = find_from(63, _url_23043, _pos_23052);

    /** 	integer first_slash = find('/', url, pos)*/
    _first_slash_23094 = find_from(47, _url_23043, _pos_23052);

    /**     integer port_colon = find(':', url, pos)*/
    _port_colon_23096 = find_from(58, _url_23043, _pos_23052);

    /**     if port_colon then*/
    if (_port_colon_23096 == 0)
    {
        goto LA; // [247] 264
    }
    else{
    }

    /**         host_name = url[pos..port_colon-1]*/
    _12828 = _port_colon_23096 - 1;
    rhs_slice_target = (object_ptr)&_host_name_23046;
    RHS_Slice(_url_23043, _pos_23052, _12828);
    goto LB; // [261] 315
LA: 

    /**         if not first_slash then*/
    if (_first_slash_23094 != 0)
    goto LC; // [266] 302

    /**             if not qs_start then*/
    if (_qs_start_23091 != 0)
    goto LD; // [271] 287

    /**                 host_name = url[pos..$]*/
    if (IS_SEQUENCE(_url_23043)){
            _12832 = SEQ_PTR(_url_23043)->length;
    }
    else {
        _12832 = 1;
    }
    rhs_slice_target = (object_ptr)&_host_name_23046;
    RHS_Slice(_url_23043, _pos_23052, _12832);
    goto LE; // [284] 314
LD: 

    /**             	host_name = url[pos..qs_start-1]*/
    _12834 = _qs_start_23091 - 1;
    rhs_slice_target = (object_ptr)&_host_name_23046;
    RHS_Slice(_url_23043, _pos_23052, _12834);
    goto LE; // [299] 314
LC: 

    /**         	host_name = url[pos..first_slash-1]*/
    _12836 = _first_slash_23094 - 1;
    rhs_slice_target = (object_ptr)&_host_name_23046;
    RHS_Slice(_url_23043, _pos_23052, _12836);
LE: 
LB: 

    /**     if port_colon then*/
    if (_port_colon_23096 == 0)
    {
        goto LF; // [317] 379
    }
    else{
    }

    /**         integer port_end = 0*/
    _port_end_23115 = 0;

    /** 		if first_slash then*/
    if (_first_slash_23094 == 0)
    {
        goto L10; // [327] 339
    }
    else{
    }

    /**             port_end = first_slash - 1*/
    _port_end_23115 = _first_slash_23094 - 1;
    goto L11; // [336] 359
L10: 

    /**         elsif qs_start then*/
    if (_qs_start_23091 == 0)
    {
        goto L12; // [341] 353
    }
    else{
    }

    /**             port_end = qs_start - 1*/
    _port_end_23115 = _qs_start_23091 - 1;
    goto L11; // [350] 359
L12: 

    /**         	port_end = length(url)*/
    if (IS_SEQUENCE(_url_23043)){
            _port_end_23115 = SEQ_PTR(_url_23043)->length;
    }
    else {
        _port_end_23115 = 1;
    }
L11: 

    /** 		port = stdget:defaulted_value(url[port_colon+1..port_end], 0)*/
    _12841 = _port_colon_23096 + 1;
    rhs_slice_target = (object_ptr)&_12842;
    RHS_Slice(_url_23043, _12841, _port_end_23115);
    _port_23051 = _17defaulted_value(_12842, 0, 1);
    _12842 = NOVALUE;
    if (!IS_ATOM_INT(_port_23051)) {
        _1 = (long)(DBL_PTR(_port_23051)->dbl);
        DeRefDS(_port_23051);
        _port_23051 = _1;
    }
LF: 

    /**     if first_slash then*/
    if (_first_slash_23094 == 0)
    {
        goto L13; // [383] 394
    }
    else{
    }

    /**         pos = first_slash*/
    _pos_23052 = _first_slash_23094;
    goto L14; // [391] 414
L13: 

    /**     elsif qs_start then*/
    if (_qs_start_23091 == 0)
    {
        goto L15; // [396] 407
    }
    else{
    }

    /**         pos = qs_start*/
    _pos_23052 = _qs_start_23091;
    goto L14; // [404] 414
L15: 

    /**         goto "parse_done"*/
    goto G16;
L14: 

    /** label "parse_path"*/
G5:

    /**     if not qs_start then*/
    if (_qs_start_23091 != 0)
    goto L17; // [420] 440

    /**         path = url[pos..$]*/
    if (IS_SEQUENCE(_url_23043)){
            _12846 = SEQ_PTR(_url_23043)->length;
    }
    else {
        _12846 = 1;
    }
    rhs_slice_target = (object_ptr)&_path_23047;
    RHS_Slice(_url_23043, _pos_23052, _12846);

    /**         goto "parse_done"*/
    goto G16;
L17: 

    /**     if pos != qs_start then*/
    if (_pos_23052 == _qs_start_23091)
    goto L18; // [442] 458

    /**         path = url[pos..qs_start - 1]*/
    _12849 = _qs_start_23091 - 1;
    rhs_slice_target = (object_ptr)&_path_23047;
    RHS_Slice(_url_23043, _pos_23052, _12849);
L18: 

    /**     pos = qs_start*/
    _pos_23052 = _qs_start_23091;

    /** label "parse_query_string"*/
G19:

    /** 	query_string = url[qs_start + 1..$]*/
    _12852 = _qs_start_23091 + 1;
    if (_12852 > MAXINT){
        _12852 = NewDouble((double)_12852);
    }
    if (IS_SEQUENCE(_url_23043)){
            _12853 = SEQ_PTR(_url_23043)->length;
    }
    else {
        _12853 = 1;
    }
    rhs_slice_target = (object_ptr)&_query_string_23050;
    RHS_Slice(_url_23043, _12852, _12853);

    /**     if querystring_also and length(query_string) then*/
    if (_querystring_also_23044 == 0) {
        goto L1A; // [483] 501
    }
    if (IS_SEQUENCE(_query_string_23050)){
            _12856 = SEQ_PTR(_query_string_23050)->length;
    }
    else {
        _12856 = 1;
    }
    if (_12856 == 0)
    {
        _12856 = NOVALUE;
        goto L1A; // [491] 501
    }
    else{
        _12856 = NOVALUE;
    }

    /**         query_string = parse_querystring(query_string)*/
    Ref(_query_string_23050);
    _0 = _query_string_23050;
    _query_string_23050 = _55parse_querystring(_query_string_23050);
    DeRef(_0);
L1A: 

    /** label "parse_done"*/
G16:

    /**     return { protocol, host_name, port, path, user_name, password, query_string }*/
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_protocol_23045);
    *((int *)(_2+4)) = _protocol_23045;
    Ref(_host_name_23046);
    *((int *)(_2+8)) = _host_name_23046;
    *((int *)(_2+12)) = _port_23051;
    Ref(_path_23047);
    *((int *)(_2+16)) = _path_23047;
    Ref(_user_name_23048);
    *((int *)(_2+20)) = _user_name_23048;
    Ref(_password_23049);
    *((int *)(_2+24)) = _password_23049;
    Ref(_query_string_23050);
    *((int *)(_2+28)) = _query_string_23050;
    _12858 = MAKE_SEQ(_1);
    DeRefDS(_url_23043);
    DeRefDS(_protocol_23045);
    DeRef(_host_name_23046);
    DeRef(_path_23047);
    DeRef(_user_name_23048);
    DeRef(_password_23049);
    DeRef(_query_string_23050);
    DeRef(_12797);
    _12797 = NOVALUE;
    DeRef(_12813);
    _12813 = NOVALUE;
    DeRef(_12816);
    _12816 = NOVALUE;
    DeRef(_12818);
    _12818 = NOVALUE;
    DeRef(_12819);
    _12819 = NOVALUE;
    DeRef(_12821);
    _12821 = NOVALUE;
    DeRef(_12828);
    _12828 = NOVALUE;
    DeRef(_12834);
    _12834 = NOVALUE;
    DeRef(_12836);
    _12836 = NOVALUE;
    DeRef(_12841);
    _12841 = NOVALUE;
    DeRef(_12849);
    _12849 = NOVALUE;
    DeRef(_12852);
    _12852 = NOVALUE;
    return _12858;
    ;
}


int  __stdcall _55encode(int _what_23152, int _spacecode_23153)
{
    int _encoded_23155 = NOVALUE;
    int _junk_23156 = NOVALUE;
    int _junk1_23157 = NOVALUE;
    int _junk2_23158 = NOVALUE;
    int _12880 = NOVALUE;
    int _12879 = NOVALUE;
    int _12878 = NOVALUE;
    int _12877 = NOVALUE;
    int _12876 = NOVALUE;
    int _12873 = NOVALUE;
    int _12872 = NOVALUE;
    int _12868 = NOVALUE;
    int _12867 = NOVALUE;
    int _12865 = NOVALUE;
    int _12864 = NOVALUE;
    int _12863 = NOVALUE;
    int _12862 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence encoded = ""*/
    RefDS(_5);
    DeRef(_encoded_23155);
    _encoded_23155 = _5;

    /** 	object junk = "", junk1, junk2*/
    RefDS(_5);
    DeRef(_junk_23156);
    _junk_23156 = _5;

    /** 	for idx = 1 to length(what) do*/
    if (IS_SEQUENCE(_what_23152)){
            _12862 = SEQ_PTR(_what_23152)->length;
    }
    else {
        _12862 = 1;
    }
    {
        int _idx_23160;
        _idx_23160 = 1;
L1: 
        if (_idx_23160 > _12862){
            goto L2; // [22] 145
        }

        /** 		if find(what[idx],alphanum) then*/
        _2 = (int)SEQ_PTR(_what_23152);
        _12863 = (int)*(((s1_ptr)_2)->base + _idx_23160);
        _12864 = find_from(_12863, _55alphanum_23146, 1);
        _12863 = NOVALUE;
        if (_12864 == 0)
        {
            _12864 = NOVALUE;
            goto L3; // [40] 56
        }
        else{
            _12864 = NOVALUE;
        }

        /** 			encoded &= what[idx]*/
        _2 = (int)SEQ_PTR(_what_23152);
        _12865 = (int)*(((s1_ptr)_2)->base + _idx_23160);
        if (IS_SEQUENCE(_encoded_23155) && IS_ATOM(_12865)) {
            Ref(_12865);
            Append(&_encoded_23155, _encoded_23155, _12865);
        }
        else if (IS_ATOM(_encoded_23155) && IS_SEQUENCE(_12865)) {
        }
        else {
            Concat((object_ptr)&_encoded_23155, _encoded_23155, _12865);
        }
        _12865 = NOVALUE;
        goto L4; // [53] 138
L3: 

        /** 		elsif equal(what[idx],' ') then*/
        _2 = (int)SEQ_PTR(_what_23152);
        _12867 = (int)*(((s1_ptr)_2)->base + _idx_23160);
        if (_12867 == 32)
        _12868 = 1;
        else if (IS_ATOM_INT(_12867) && IS_ATOM_INT(32))
        _12868 = 0;
        else
        _12868 = (compare(_12867, 32) == 0);
        _12867 = NOVALUE;
        if (_12868 == 0)
        {
            _12868 = NOVALUE;
            goto L5; // [66] 78
        }
        else{
            _12868 = NOVALUE;
        }

        /** 			encoded &= spacecode*/
        Concat((object_ptr)&_encoded_23155, _encoded_23155, _spacecode_23153);
        goto L4; // [75] 138
L5: 

        /** 		elsif 1 then*/

        /** 			junk = what[idx]*/
        DeRef(_junk_23156);
        _2 = (int)SEQ_PTR(_what_23152);
        _junk_23156 = (int)*(((s1_ptr)_2)->base + _idx_23160);
        Ref(_junk_23156);

        /** 			junk1 = floor(junk / 16)*/
        DeRef(_junk1_23157);
        if (IS_ATOM_INT(_junk_23156)) {
            if (16 > 0 && _junk_23156 >= 0) {
                _junk1_23157 = _junk_23156 / 16;
            }
            else {
                temp_dbl = floor((double)_junk_23156 / (double)16);
                if (_junk_23156 != MININT)
                _junk1_23157 = (long)temp_dbl;
                else
                _junk1_23157 = NewDouble(temp_dbl);
            }
        }
        else {
            _2 = binary_op(DIVIDE, _junk_23156, 16);
            _junk1_23157 = unary_op(FLOOR, _2);
            DeRef(_2);
        }

        /** 			junk2 = floor(junk - (junk1 * 16))*/
        if (IS_ATOM_INT(_junk1_23157)) {
            if (_junk1_23157 == (short)_junk1_23157)
            _12872 = _junk1_23157 * 16;
            else
            _12872 = NewDouble(_junk1_23157 * (double)16);
        }
        else {
            _12872 = binary_op(MULTIPLY, _junk1_23157, 16);
        }
        if (IS_ATOM_INT(_junk_23156) && IS_ATOM_INT(_12872)) {
            _12873 = _junk_23156 - _12872;
            if ((long)((unsigned long)_12873 +(unsigned long) HIGH_BITS) >= 0){
                _12873 = NewDouble((double)_12873);
            }
        }
        else {
            _12873 = binary_op(MINUS, _junk_23156, _12872);
        }
        DeRef(_12872);
        _12872 = NOVALUE;
        DeRef(_junk2_23158);
        if (IS_ATOM_INT(_12873))
        _junk2_23158 = e_floor(_12873);
        else
        _junk2_23158 = unary_op(FLOOR, _12873);
        DeRef(_12873);
        _12873 = NOVALUE;

        /** 			encoded &= "%" & hexnums[junk1+1] & hexnums[junk2+1]*/
        if (IS_ATOM_INT(_junk1_23157)) {
            _12876 = _junk1_23157 + 1;
        }
        else
        _12876 = binary_op(PLUS, 1, _junk1_23157);
        _2 = (int)SEQ_PTR(_55hexnums_23148);
        if (!IS_ATOM_INT(_12876)){
            _12877 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12876)->dbl));
        }
        else{
            _12877 = (int)*(((s1_ptr)_2)->base + _12876);
        }
        if (IS_ATOM_INT(_junk2_23158)) {
            _12878 = _junk2_23158 + 1;
        }
        else
        _12878 = binary_op(PLUS, 1, _junk2_23158);
        _2 = (int)SEQ_PTR(_55hexnums_23148);
        if (!IS_ATOM_INT(_12878)){
            _12879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12878)->dbl));
        }
        else{
            _12879 = (int)*(((s1_ptr)_2)->base + _12878);
        }
        {
            int concat_list[3];

            concat_list[0] = _12879;
            concat_list[1] = _12877;
            concat_list[2] = _12875;
            Concat_N((object_ptr)&_12880, concat_list, 3);
        }
        _12879 = NOVALUE;
        _12877 = NOVALUE;
        Concat((object_ptr)&_encoded_23155, _encoded_23155, _12880);
        DeRefDS(_12880);
        _12880 = NOVALUE;
L4: 

        /** 	end for*/
        _idx_23160 = _idx_23160 + 1;
        goto L1; // [140] 29
L2: 
        ;
    }

    /** 	return encoded*/
    DeRefDS(_what_23152);
    DeRefDS(_spacecode_23153);
    DeRef(_junk_23156);
    DeRef(_junk1_23157);
    DeRef(_junk2_23158);
    DeRef(_12876);
    _12876 = NOVALUE;
    DeRef(_12878);
    _12878 = NOVALUE;
    return _encoded_23155;
    ;
}


int  __stdcall _55decode(int _what_23186)
{
    int _k_23187 = NOVALUE;
    int _value_inlined_value_at_119_23216 = NOVALUE;
    int _st_inlined_value_at_116_23215 = NOVALUE;
    int _value_inlined_value_at_202_23231 = NOVALUE;
    int _st_inlined_value_at_199_23230 = NOVALUE;
    int _12919 = NOVALUE;
    int _12918 = NOVALUE;
    int _12917 = NOVALUE;
    int _12916 = NOVALUE;
    int _12915 = NOVALUE;
    int _12914 = NOVALUE;
    int _12913 = NOVALUE;
    int _12912 = NOVALUE;
    int _12911 = NOVALUE;
    int _12910 = NOVALUE;
    int _12908 = NOVALUE;
    int _12907 = NOVALUE;
    int _12906 = NOVALUE;
    int _12905 = NOVALUE;
    int _12904 = NOVALUE;
    int _12903 = NOVALUE;
    int _12902 = NOVALUE;
    int _12901 = NOVALUE;
    int _12900 = NOVALUE;
    int _12897 = NOVALUE;
    int _12896 = NOVALUE;
    int _12894 = NOVALUE;
    int _12893 = NOVALUE;
    int _12892 = NOVALUE;
    int _12891 = NOVALUE;
    int _12890 = NOVALUE;
    int _12888 = NOVALUE;
    int _12886 = NOVALUE;
    int _12884 = NOVALUE;
    int _12882 = NOVALUE;
    int _0, _1, _2;
    

    /**   integer k = 1*/
    _k_23187 = 1;

    /**   while k <= length(what) do*/
L1: 
    if (IS_SEQUENCE(_what_23186)){
            _12882 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12882 = 1;
    }
    if (_k_23187 > _12882)
    goto L2; // [16] 275

    /**     if what[k] = '+' then*/
    _2 = (int)SEQ_PTR(_what_23186);
    _12884 = (int)*(((s1_ptr)_2)->base + _k_23187);
    if (binary_op_a(NOTEQ, _12884, 43)){
        _12884 = NOVALUE;
        goto L3; // [26] 39
    }
    _12884 = NOVALUE;

    /**       what[k] = ' ' -- space is a special case, converts into +*/
    _2 = (int)SEQ_PTR(_what_23186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_23186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_23187);
    _1 = *(int *)_2;
    *(int *)_2 = 32;
    DeRef(_1);
    goto L4; // [36] 264
L3: 

    /**     elsif what[k] = '%' then*/
    _2 = (int)SEQ_PTR(_what_23186);
    _12886 = (int)*(((s1_ptr)_2)->base + _k_23187);
    if (binary_op_a(NOTEQ, _12886, 37)){
        _12886 = NOVALUE;
        goto L5; // [45] 263
    }
    _12886 = NOVALUE;

    /**       if k = length(what) then*/
    if (IS_SEQUENCE(_what_23186)){
            _12888 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12888 = 1;
    }
    if (_k_23187 != _12888)
    goto L6; // [54] 88

    /**         what = what[1..k-1] & what[k+1 .. $]*/
    _12890 = _k_23187 - 1;
    rhs_slice_target = (object_ptr)&_12891;
    RHS_Slice(_what_23186, 1, _12890);
    _12892 = _k_23187 + 1;
    if (_12892 > MAXINT){
        _12892 = NewDouble((double)_12892);
    }
    if (IS_SEQUENCE(_what_23186)){
            _12893 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12893 = 1;
    }
    rhs_slice_target = (object_ptr)&_12894;
    RHS_Slice(_what_23186, _12892, _12893);
    Concat((object_ptr)&_what_23186, _12891, _12894);
    DeRefDS(_12891);
    _12891 = NOVALUE;
    DeRef(_12891);
    _12891 = NOVALUE;
    DeRefDS(_12894);
    _12894 = NOVALUE;
    goto L4; // [85] 264
L6: 

    /**       elsif k+1 = length(what) then*/
    _12896 = _k_23187 + 1;
    if (_12896 > MAXINT){
        _12896 = NewDouble((double)_12896);
    }
    if (IS_SEQUENCE(_what_23186)){
            _12897 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12897 = 1;
    }
    if (binary_op_a(NOTEQ, _12896, _12897)){
        DeRef(_12896);
        _12896 = NOVALUE;
        _12897 = NOVALUE;
        goto L7; // [97] 179
    }
    DeRef(_12896);
    _12896 = NOVALUE;
    _12897 = NOVALUE;

    /**         what[k] = stdget:value("#0" & what[k+1])*/
    _12900 = _k_23187 + 1;
    _2 = (int)SEQ_PTR(_what_23186);
    _12901 = (int)*(((s1_ptr)_2)->base + _12900);
    if (IS_SEQUENCE(_12899) && IS_ATOM(_12901)) {
        Ref(_12901);
        Append(&_12902, _12899, _12901);
    }
    else if (IS_ATOM(_12899) && IS_SEQUENCE(_12901)) {
    }
    else {
        Concat((object_ptr)&_12902, _12899, _12901);
    }
    _12901 = NOVALUE;
    DeRef(_st_inlined_value_at_116_23215);
    _st_inlined_value_at_116_23215 = _12902;
    _12902 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3332)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3332)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3332);
        _17GET_SHORT_ANSWER_3332 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_116_23215);
    _0 = _value_inlined_value_at_119_23216;
    _value_inlined_value_at_119_23216 = _17get_value(_st_inlined_value_at_116_23215, 1, _17GET_SHORT_ANSWER_3332);
    DeRef(_0);
    DeRef(_st_inlined_value_at_116_23215);
    _st_inlined_value_at_116_23215 = NOVALUE;
    Ref(_value_inlined_value_at_119_23216);
    _2 = (int)SEQ_PTR(_what_23186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_23186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_23187);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_119_23216;
    DeRef(_1);

    /**         what[k] = what[k][2]*/
    _2 = (int)SEQ_PTR(_what_23186);
    _12903 = (int)*(((s1_ptr)_2)->base + _k_23187);
    _2 = (int)SEQ_PTR(_12903);
    _12904 = (int)*(((s1_ptr)_2)->base + 2);
    _12903 = NOVALUE;
    Ref(_12904);
    _2 = (int)SEQ_PTR(_what_23186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_23186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_23187);
    _1 = *(int *)_2;
    *(int *)_2 = _12904;
    if( _1 != _12904 ){
        DeRef(_1);
    }
    _12904 = NOVALUE;

    /**         what = what[1..k] & what[k+2 .. $]*/
    rhs_slice_target = (object_ptr)&_12905;
    RHS_Slice(_what_23186, 1, _k_23187);
    _12906 = _k_23187 + 2;
    if ((long)((unsigned long)_12906 + (unsigned long)HIGH_BITS) >= 0) 
    _12906 = NewDouble((double)_12906);
    if (IS_SEQUENCE(_what_23186)){
            _12907 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12907 = 1;
    }
    rhs_slice_target = (object_ptr)&_12908;
    RHS_Slice(_what_23186, _12906, _12907);
    Concat((object_ptr)&_what_23186, _12905, _12908);
    DeRefDS(_12905);
    _12905 = NOVALUE;
    DeRef(_12905);
    _12905 = NOVALUE;
    DeRefDS(_12908);
    _12908 = NOVALUE;
    goto L4; // [176] 264
L7: 

    /**         what[k] = stdget:value("#" & what[k+1..k+2])*/
    _12910 = _k_23187 + 1;
    if (_12910 > MAXINT){
        _12910 = NewDouble((double)_12910);
    }
    _12911 = _k_23187 + 2;
    rhs_slice_target = (object_ptr)&_12912;
    RHS_Slice(_what_23186, _12910, _12911);
    Concat((object_ptr)&_12913, _12781, _12912);
    DeRefDS(_12912);
    _12912 = NOVALUE;
    DeRef(_st_inlined_value_at_199_23230);
    _st_inlined_value_at_199_23230 = _12913;
    _12913 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3332)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3332)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3332);
        _17GET_SHORT_ANSWER_3332 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_199_23230);
    _0 = _value_inlined_value_at_202_23231;
    _value_inlined_value_at_202_23231 = _17get_value(_st_inlined_value_at_199_23230, 1, _17GET_SHORT_ANSWER_3332);
    DeRef(_0);
    DeRef(_st_inlined_value_at_199_23230);
    _st_inlined_value_at_199_23230 = NOVALUE;
    Ref(_value_inlined_value_at_202_23231);
    _2 = (int)SEQ_PTR(_what_23186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_23186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_23187);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_202_23231;
    DeRef(_1);

    /**         what[k] = what[k][2]*/
    _2 = (int)SEQ_PTR(_what_23186);
    _12914 = (int)*(((s1_ptr)_2)->base + _k_23187);
    _2 = (int)SEQ_PTR(_12914);
    _12915 = (int)*(((s1_ptr)_2)->base + 2);
    _12914 = NOVALUE;
    Ref(_12915);
    _2 = (int)SEQ_PTR(_what_23186);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_23186 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_23187);
    _1 = *(int *)_2;
    *(int *)_2 = _12915;
    if( _1 != _12915 ){
        DeRef(_1);
    }
    _12915 = NOVALUE;

    /**         what = what[1..k] & what[k+3 .. $]*/
    rhs_slice_target = (object_ptr)&_12916;
    RHS_Slice(_what_23186, 1, _k_23187);
    _12917 = _k_23187 + 3;
    if ((long)((unsigned long)_12917 + (unsigned long)HIGH_BITS) >= 0) 
    _12917 = NewDouble((double)_12917);
    if (IS_SEQUENCE(_what_23186)){
            _12918 = SEQ_PTR(_what_23186)->length;
    }
    else {
        _12918 = 1;
    }
    rhs_slice_target = (object_ptr)&_12919;
    RHS_Slice(_what_23186, _12917, _12918);
    Concat((object_ptr)&_what_23186, _12916, _12919);
    DeRefDS(_12916);
    _12916 = NOVALUE;
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRefDS(_12919);
    _12919 = NOVALUE;
    goto L4; // [260] 264
L5: 
L4: 

    /**     k += 1*/
    _k_23187 = _k_23187 + 1;

    /**   end while*/
    goto L1; // [272] 13
L2: 

    /**   return what*/
    DeRef(_12890);
    _12890 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    DeRef(_12892);
    _12892 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12906);
    _12906 = NOVALUE;
    DeRef(_12911);
    _12911 = NOVALUE;
    DeRef(_12917);
    _12917 = NOVALUE;
    return _what_23186;
    ;
}



// 0xD7C98A3E
