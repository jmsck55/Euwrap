// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _39which_bit(int _theValue_19030)
{
    int _10596 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:get(one_bit_numbers, theValue, 0)*/
    Ref(_39one_bit_numbers_19011);
    Ref(_theValue_19030);
    _10596 = _33get(_39one_bit_numbers_19011, _theValue_19030, 0);
    DeRef(_theValue_19030);
    return _10596;
    ;
}


int  __stdcall _39flags_to_string(int _flag_bits_19034, int _flag_names_19035, int _expand_flags_19036)
{
    int _s_19037 = NOVALUE;
    int _has_one_bit_19054 = NOVALUE;
    int _which_bit_inlined_which_bit_at_100_19056 = NOVALUE;
    int _current_flag_19060 = NOVALUE;
    int _which_bit_inlined_which_bit_at_241_19086 = NOVALUE;
    int _10629 = NOVALUE;
    int _10627 = NOVALUE;
    int _10626 = NOVALUE;
    int _10624 = NOVALUE;
    int _10622 = NOVALUE;
    int _10621 = NOVALUE;
    int _10617 = NOVALUE;
    int _10616 = NOVALUE;
    int _10613 = NOVALUE;
    int _10612 = NOVALUE;
    int _10608 = NOVALUE;
    int _10607 = NOVALUE;
    int _10606 = NOVALUE;
    int _10605 = NOVALUE;
    int _10604 = NOVALUE;
    int _10603 = NOVALUE;
    int _10602 = NOVALUE;
    int _10600 = NOVALUE;
    int _10599 = NOVALUE;
    int _10598 = NOVALUE;
    int _10597 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_expand_flags_19036)) {
        _1 = (long)(DBL_PTR(_expand_flags_19036)->dbl);
        DeRefDS(_expand_flags_19036);
        _expand_flags_19036 = _1;
    }

    /**     sequence s = {}*/
    RefDS(_5);
    DeRef(_s_19037);
    _s_19037 = _5;

    /**     if sequence(flag_bits) then*/
    _10597 = IS_SEQUENCE(_flag_bits_19034);
    if (_10597 == 0)
    {
        _10597 = NOVALUE;
        goto L1; // [17] 97
    }
    else{
        _10597 = NOVALUE;
    }

    /** 		for i = 1 to length(flag_bits) do*/
    if (IS_SEQUENCE(_flag_bits_19034)){
            _10598 = SEQ_PTR(_flag_bits_19034)->length;
    }
    else {
        _10598 = 1;
    }
    {
        int _i_19041;
        _i_19041 = 1;
L2: 
        if (_i_19041 > _10598){
            goto L3; // [25] 87
        }

        /** 			if not sequence(flag_bits[i]) then*/
        _2 = (int)SEQ_PTR(_flag_bits_19034);
        _10599 = (int)*(((s1_ptr)_2)->base + _i_19041);
        _10600 = IS_SEQUENCE(_10599);
        _10599 = NOVALUE;
        if (_10600 != 0)
        goto L4; // [41] 69
        _10600 = NOVALUE;

        /** 				flag_bits[i] = flags_to_string(flag_bits[i], flag_names, expand_flags)*/
        _2 = (int)SEQ_PTR(_flag_bits_19034);
        _10602 = (int)*(((s1_ptr)_2)->base + _i_19041);
        RefDS(_flag_names_19035);
        DeRef(_10603);
        _10603 = _flag_names_19035;
        DeRef(_10604);
        _10604 = _expand_flags_19036;
        Ref(_10602);
        _10605 = _39flags_to_string(_10602, _10603, _10604);
        _10602 = NOVALUE;
        _10603 = NOVALUE;
        _10604 = NOVALUE;
        _2 = (int)SEQ_PTR(_flag_bits_19034);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _flag_bits_19034 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_19041);
        _1 = *(int *)_2;
        *(int *)_2 = _10605;
        if( _1 != _10605 ){
            DeRef(_1);
        }
        _10605 = NOVALUE;
        goto L5; // [66] 80
L4: 

        /** 				flag_bits[i] = {"?"}*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_8854);
        *((int *)(_2+4)) = _8854;
        _10606 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_flag_bits_19034);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _flag_bits_19034 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_19041);
        _1 = *(int *)_2;
        *(int *)_2 = _10606;
        if( _1 != _10606 ){
            DeRef(_1);
        }
        _10606 = NOVALUE;
L5: 

        /** 		end for*/
        _i_19041 = _i_19041 + 1;
        goto L2; // [82] 32
L3: 
        ;
    }

    /** 		s = flag_bits*/
    Ref(_flag_bits_19034);
    DeRef(_s_19037);
    _s_19037 = _flag_bits_19034;
    goto L6; // [94] 295
L1: 

    /** 		integer has_one_bit*/

    /** 		has_one_bit = which_bit(flag_bits)*/

    /** 	return map:get(one_bit_numbers, theValue, 0)*/
    Ref(_39one_bit_numbers_19011);
    Ref(_flag_bits_19034);
    _has_one_bit_19054 = _33get(_39one_bit_numbers_19011, _flag_bits_19034, 0);

    /** 		for i = 1 to length(flag_names) do*/
    if (IS_SEQUENCE(_flag_names_19035)){
            _10607 = SEQ_PTR(_flag_names_19035)->length;
    }
    else {
        _10607 = 1;
    }
    {
        int _i_19058;
        _i_19058 = 1;
L7: 
        if (_i_19058 > _10607){
            goto L8; // [117] 292
        }

        /** 			atom current_flag = flag_names[i][1]*/
        _2 = (int)SEQ_PTR(_flag_names_19035);
        _10608 = (int)*(((s1_ptr)_2)->base + _i_19058);
        DeRef(_current_flag_19060);
        _2 = (int)SEQ_PTR(_10608);
        _current_flag_19060 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_current_flag_19060);
        _10608 = NOVALUE;

        /** 			if flag_bits = 0 then*/
        if (binary_op_a(NOTEQ, _flag_bits_19034, 0)){
            goto L9; // [136] 170
        }

        /** 				if current_flag = 0 then*/
        if (binary_op_a(NOTEQ, _current_flag_19060, 0)){
            goto LA; // [142] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_19035);
        _10612 = (int)*(((s1_ptr)_2)->base + _i_19058);
        _2 = (int)SEQ_PTR(_10612);
        _10613 = (int)*(((s1_ptr)_2)->base + 2);
        _10612 = NOVALUE;
        Ref(_10613);
        Append(&_s_19037, _s_19037, _10613);
        _10613 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_19060);
        _current_flag_19060 = NOVALUE;
        goto L8; // [164] 292
        goto LA; // [167] 283
L9: 

        /** 			elsif has_one_bit then*/
        if (_has_one_bit_19054 == 0)
        {
            goto LB; // [172] 205
        }
        else{
        }

        /** 				if current_flag = flag_bits then*/
        if (binary_op_a(NOTEQ, _current_flag_19060, _flag_bits_19034)){
            goto LA; // [177] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_19035);
        _10616 = (int)*(((s1_ptr)_2)->base + _i_19058);
        _2 = (int)SEQ_PTR(_10616);
        _10617 = (int)*(((s1_ptr)_2)->base + 2);
        _10616 = NOVALUE;
        Ref(_10617);
        Append(&_s_19037, _s_19037, _10617);
        _10617 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_19060);
        _current_flag_19060 = NOVALUE;
        goto L8; // [199] 292
        goto LA; // [202] 283
LB: 

        /** 			elsif not expand_flags then*/
        if (_expand_flags_19036 != 0)
        goto LC; // [207] 240

        /** 				if current_flag = flag_bits then*/
        if (binary_op_a(NOTEQ, _current_flag_19060, _flag_bits_19034)){
            goto LA; // [212] 283
        }

        /** 					s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_19035);
        _10621 = (int)*(((s1_ptr)_2)->base + _i_19058);
        _2 = (int)SEQ_PTR(_10621);
        _10622 = (int)*(((s1_ptr)_2)->base + 2);
        _10621 = NOVALUE;
        Ref(_10622);
        Append(&_s_19037, _s_19037, _10622);
        _10622 = NOVALUE;

        /** 					exit*/
        DeRef(_current_flag_19060);
        _current_flag_19060 = NOVALUE;
        goto L8; // [234] 292
        goto LA; // [237] 283
LC: 

        /** 				if which_bit(current_flag) then*/

        /** 	return map:get(one_bit_numbers, theValue, 0)*/
        Ref(_39one_bit_numbers_19011);
        Ref(_current_flag_19060);
        _0 = _which_bit_inlined_which_bit_at_241_19086;
        _which_bit_inlined_which_bit_at_241_19086 = _33get(_39one_bit_numbers_19011, _current_flag_19060, 0);
        DeRef(_0);
        if (_which_bit_inlined_which_bit_at_241_19086 == 0) {
            goto LD; // [253] 282
        }
        else {
            if (!IS_ATOM_INT(_which_bit_inlined_which_bit_at_241_19086) && DBL_PTR(_which_bit_inlined_which_bit_at_241_19086)->dbl == 0.0){
                goto LD; // [253] 282
            }
        }

        /** 					if and_bits( current_flag, flag_bits ) = current_flag then*/
        if (IS_ATOM_INT(_current_flag_19060) && IS_ATOM_INT(_flag_bits_19034)) {
            {unsigned long tu;
                 tu = (unsigned long)_current_flag_19060 & (unsigned long)_flag_bits_19034;
                 _10624 = MAKE_UINT(tu);
            }
        }
        else {
            _10624 = binary_op(AND_BITS, _current_flag_19060, _flag_bits_19034);
        }
        if (binary_op_a(NOTEQ, _10624, _current_flag_19060)){
            DeRef(_10624);
            _10624 = NOVALUE;
            goto LE; // [262] 281
        }
        DeRef(_10624);
        _10624 = NOVALUE;

        /** 						s = append(s,flag_names[i][2])*/
        _2 = (int)SEQ_PTR(_flag_names_19035);
        _10626 = (int)*(((s1_ptr)_2)->base + _i_19058);
        _2 = (int)SEQ_PTR(_10626);
        _10627 = (int)*(((s1_ptr)_2)->base + 2);
        _10626 = NOVALUE;
        Ref(_10627);
        Append(&_s_19037, _s_19037, _10627);
        _10627 = NOVALUE;
LE: 
LD: 
LA: 
        DeRef(_current_flag_19060);
        _current_flag_19060 = NOVALUE;

        /** 		end for*/
        _i_19058 = _i_19058 + 1;
        goto L7; // [287] 124
L8: 
        ;
    }
L6: 

    /**     if length(s) = 0 then*/
    if (IS_SEQUENCE(_s_19037)){
            _10629 = SEQ_PTR(_s_19037)->length;
    }
    else {
        _10629 = 1;
    }
    if (_10629 != 0)
    goto LF; // [300] 311

    /** 		s = append(s,"?")*/
    RefDS(_8854);
    Append(&_s_19037, _s_19037, _8854);
LF: 

    /**     return s*/
    DeRef(_flag_bits_19034);
    DeRefDS(_flag_names_19035);
    return _s_19037;
    ;
}



// 0xB0E943BE
