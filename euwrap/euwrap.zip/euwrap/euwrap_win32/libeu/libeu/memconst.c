// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _15valid_memory_protection_constant(int _x_1831)
{
    int _944 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _944 = find_from(_x_1831, _15MEMORY_PROTECTION_1827, 1);
    DeRef(_x_1831);
    return _944;
    ;
}


int  __stdcall _15test_read(int _protection_1835)
{
    int _946 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE,  */
    _946 = find_from(_protection_1835, _945, 1);
    DeRef(_protection_1835);
    return _946;
    ;
}


int  __stdcall _15test_write(int _protection_1840)
{
    int _948 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READWRITE,*/
    _948 = find_from(_protection_1840, _947, 1);
    DeRef(_protection_1840);
    return _948;
    ;
}


int  __stdcall _15test_exec(int _protection_1845)
{
    int _950 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find(protection,{PAGE_EXECUTE,*/
    _950 = find_from(_protection_1845, _949, 1);
    DeRef(_protection_1845);
    return _950;
    ;
}


int  __stdcall _15valid_wordsize(int _i_1850)
{
    int _952 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _952 = find_from(_i_1850, _951, 1);
    DeRef(_i_1850);
    return _952;
    ;
}



// 0x56F18518
