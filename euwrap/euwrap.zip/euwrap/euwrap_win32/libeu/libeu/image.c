// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _41graphics_point(int _p_19218)
{
    int _10687 = NOVALUE;
    int _10686 = NOVALUE;
    int _10684 = NOVALUE;
    int _10683 = NOVALUE;
    int _10682 = NOVALUE;
    int _10681 = NOVALUE;
    int _10680 = NOVALUE;
    int _10678 = NOVALUE;
    int _10677 = NOVALUE;
    int _10676 = NOVALUE;
    int _10674 = NOVALUE;
    int _10673 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(p) then*/
    _10673 = IS_ATOM(_p_19218);
    if (_10673 == 0)
    {
        _10673 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _10673 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_p_19218);
    return 0;
L1: 

    /** 	if length(p) != 2 then*/
    if (IS_SEQUENCE(_p_19218)){
            _10674 = SEQ_PTR(_p_19218)->length;
    }
    else {
        _10674 = 1;
    }
    if (_10674 == 2)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_p_19218);
    return 0;
L2: 

    /** 	if not integer(p[1]) or p[1] < 0 then*/
    _2 = (int)SEQ_PTR(_p_19218);
    _10676 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10676))
    _10677 = 1;
    else if (IS_ATOM_DBL(_10676))
    _10677 = IS_ATOM_INT(DoubleToInt(_10676));
    else
    _10677 = 0;
    _10676 = NOVALUE;
    _10678 = (_10677 == 0);
    _10677 = NOVALUE;
    if (_10678 != 0) {
        goto L3; // [44] 61
    }
    _2 = (int)SEQ_PTR(_p_19218);
    _10680 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10680)) {
        _10681 = (_10680 < 0);
    }
    else {
        _10681 = binary_op(LESS, _10680, 0);
    }
    _10680 = NOVALUE;
    if (_10681 == 0) {
        DeRef(_10681);
        _10681 = NOVALUE;
        goto L4; // [57] 68
    }
    else {
        if (!IS_ATOM_INT(_10681) && DBL_PTR(_10681)->dbl == 0.0){
            DeRef(_10681);
            _10681 = NOVALUE;
            goto L4; // [57] 68
        }
        DeRef(_10681);
        _10681 = NOVALUE;
    }
    DeRef(_10681);
    _10681 = NOVALUE;
L3: 

    /** 		return 0*/
    DeRef(_p_19218);
    DeRef(_10678);
    _10678 = NOVALUE;
    return 0;
L4: 

    /** 	if not integer(p[2]) or p[2] < 0 then*/
    _2 = (int)SEQ_PTR(_p_19218);
    _10682 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10682))
    _10683 = 1;
    else if (IS_ATOM_DBL(_10682))
    _10683 = IS_ATOM_INT(DoubleToInt(_10682));
    else
    _10683 = 0;
    _10682 = NOVALUE;
    _10684 = (_10683 == 0);
    _10683 = NOVALUE;
    if (_10684 != 0) {
        goto L5; // [80] 97
    }
    _2 = (int)SEQ_PTR(_p_19218);
    _10686 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10686)) {
        _10687 = (_10686 < 0);
    }
    else {
        _10687 = binary_op(LESS, _10686, 0);
    }
    _10686 = NOVALUE;
    if (_10687 == 0) {
        DeRef(_10687);
        _10687 = NOVALUE;
        goto L6; // [93] 104
    }
    else {
        if (!IS_ATOM_INT(_10687) && DBL_PTR(_10687)->dbl == 0.0){
            DeRef(_10687);
            _10687 = NOVALUE;
            goto L6; // [93] 104
        }
        DeRef(_10687);
        _10687 = NOVALUE;
    }
    DeRef(_10687);
    _10687 = NOVALUE;
L5: 

    /** 		return 0*/
    DeRef(_p_19218);
    DeRef(_10678);
    _10678 = NOVALUE;
    DeRef(_10684);
    _10684 = NOVALUE;
    return 0;
L6: 

    /** 	return 1*/
    DeRef(_p_19218);
    DeRef(_10678);
    _10678 = NOVALUE;
    DeRef(_10684);
    _10684 = NOVALUE;
    return 1;
    ;
}


int _41get_word()
{
    int _lower_19240 = NOVALUE;
    int _upper_19241 = NOVALUE;
    int _10692 = NOVALUE;
    int _10691 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lower = getc(fn)*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _lower_19240 = getKBchar();
        }
        else
        _lower_19240 = getc(last_r_file_ptr);
    }
    else
    _lower_19240 = getc(last_r_file_ptr);

    /** 	upper = getc(fn)*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _upper_19241 = getKBchar();
        }
        else
        _upper_19241 = getc(last_r_file_ptr);
    }
    else
    _upper_19241 = getc(last_r_file_ptr);

    /** 	if upper = EOF then*/
    if (_upper_19241 != -1)
    goto L1; // [17] 31

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_19215 = 3;
L1: 

    /** 	return upper * 256 + lower*/
    if (_upper_19241 == (short)_upper_19241)
    _10691 = _upper_19241 * 256;
    else
    _10691 = NewDouble(_upper_19241 * (double)256);
    if (IS_ATOM_INT(_10691)) {
        _10692 = _10691 + _lower_19240;
        if ((long)((unsigned long)_10692 + (unsigned long)HIGH_BITS) >= 0) 
        _10692 = NewDouble((double)_10692);
    }
    else {
        _10692 = NewDouble(DBL_PTR(_10691)->dbl + (double)_lower_19240);
    }
    DeRef(_10691);
    _10691 = NOVALUE;
    return _10692;
    ;
}


int _41get_c_block(int _num_bytes_19259)
{
    int _s_19260 = NOVALUE;
    int _10701 = NOVALUE;
    int _10700 = NOVALUE;
    int _10699 = NOVALUE;
    int _10698 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_bytes_19259)) {
        _1 = (long)(DBL_PTR(_num_bytes_19259)->dbl);
        DeRefDS(_num_bytes_19259);
        _num_bytes_19259 = _1;
    }

    /** 	s = repeat(0, num_bytes)*/
    DeRefi(_s_19260);
    _s_19260 = Repeat(0, _num_bytes_19259);

    /** 	for i = 1 to num_bytes do*/
    _10698 = _num_bytes_19259;
    {
        int _i_19263;
        _i_19263 = 1;
L1: 
        if (_i_19263 > _10698){
            goto L2; // [14] 39
        }

        /** 		s[i] = getc(fn)*/
        if (_41fn_19214 != last_r_file_no) {
            last_r_file_ptr = which_file(_41fn_19214, EF_READ);
            last_r_file_no = _41fn_19214;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _10699 = getKBchar();
            }
            else
            _10699 = getc(last_r_file_ptr);
        }
        else
        _10699 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_19260);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_19260 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_19263);
        *(int *)_2 = _10699;
        if( _1 != _10699 ){
        }
        _10699 = NOVALUE;

        /** 	end for*/
        _i_19263 = _i_19263 + 1;
        goto L1; // [34] 21
L2: 
        ;
    }

    /** 	if s[$] = EOF then*/
    if (IS_SEQUENCE(_s_19260)){
            _10700 = SEQ_PTR(_s_19260)->length;
    }
    else {
        _10700 = 1;
    }
    _2 = (int)SEQ_PTR(_s_19260);
    _10701 = (int)*(((s1_ptr)_2)->base + _10700);
    if (_10701 != -1)
    goto L3; // [48] 62

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_19215 = 3;
L3: 

    /** 	return s*/
    _10701 = NOVALUE;
    return _s_19260;
    ;
}


int _41get_rgb(int _set_size_19273)
{
    int _red_19274 = NOVALUE;
    int _green_19275 = NOVALUE;
    int _blue_19276 = NOVALUE;
    int _10708 = NOVALUE;
    int _10707 = NOVALUE;
    int _0, _1, _2;
    

    /** 	blue = getc(fn)*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _blue_19276 = getKBchar();
        }
        else
        _blue_19276 = getc(last_r_file_ptr);
    }
    else
    _blue_19276 = getc(last_r_file_ptr);

    /** 	green = getc(fn)*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _green_19275 = getKBchar();
        }
        else
        _green_19275 = getc(last_r_file_ptr);
    }
    else
    _green_19275 = getc(last_r_file_ptr);

    /** 	red = getc(fn)*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _red_19274 = getKBchar();
        }
        else
        _red_19274 = getc(last_r_file_ptr);
    }
    else
    _red_19274 = getc(last_r_file_ptr);

    /** 	if set_size = 4 then*/
    if (_set_size_19273 != 4)
    goto L1; // [26] 42

    /** 		if getc(fn) then*/
    if (_41fn_19214 != last_r_file_no) {
        last_r_file_ptr = which_file(_41fn_19214, EF_READ);
        last_r_file_no = _41fn_19214;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _10707 = getKBchar();
        }
        else
        _10707 = getc(last_r_file_ptr);
    }
    else
    _10707 = getc(last_r_file_ptr);
    if (_10707 == 0)
    {
        _10707 = NOVALUE;
        goto L2; // [37] 41
    }
    else{
        _10707 = NOVALUE;
    }
L2: 
L1: 

    /** 	return {red, green, blue}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _red_19274;
    *((int *)(_2+8)) = _green_19275;
    *((int *)(_2+12)) = _blue_19276;
    _10708 = MAKE_SEQ(_1);
    return _10708;
    ;
}


int _41get_rgb_block(int _num_dwords_19287, int _set_size_19288)
{
    int _s_19289 = NOVALUE;
    int _10714 = NOVALUE;
    int _10713 = NOVALUE;
    int _10712 = NOVALUE;
    int _10710 = NOVALUE;
    int _10709 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_dwords_19287)) {
        _1 = (long)(DBL_PTR(_num_dwords_19287)->dbl);
        DeRefDS(_num_dwords_19287);
        _num_dwords_19287 = _1;
    }

    /** 	s = {}*/
    RefDS(_5);
    DeRef(_s_19289);
    _s_19289 = _5;

    /** 	for i = 1 to num_dwords do*/
    _10709 = _num_dwords_19287;
    {
        int _i_19291;
        _i_19291 = 1;
L1: 
        if (_i_19291 > _10709){
            goto L2; // [17] 41
        }

        /** 		s = append(s, get_rgb(set_size))*/
        _10710 = _41get_rgb(_set_size_19288);
        Ref(_10710);
        Append(&_s_19289, _s_19289, _10710);
        DeRef(_10710);
        _10710 = NOVALUE;

        /** 	end for*/
        _i_19291 = _i_19291 + 1;
        goto L1; // [36] 24
L2: 
        ;
    }

    /** 	if s[$][3] = EOF then*/
    if (IS_SEQUENCE(_s_19289)){
            _10712 = SEQ_PTR(_s_19289)->length;
    }
    else {
        _10712 = 1;
    }
    _2 = (int)SEQ_PTR(_s_19289);
    _10713 = (int)*(((s1_ptr)_2)->base + _10712);
    _2 = (int)SEQ_PTR(_10713);
    _10714 = (int)*(((s1_ptr)_2)->base + 3);
    _10713 = NOVALUE;
    if (binary_op_a(NOTEQ, _10714, -1)){
        _10714 = NOVALUE;
        goto L3; // [54] 68
    }
    _10714 = NOVALUE;

    /** 		error_code = BMP_UNEXPECTED_EOF*/
    _41error_code_19215 = 3;
L3: 

    /** 	return s*/
    return _s_19289;
    ;
}


int _41unpack(int _image_19311, int _BitCount_19312, int _Width_19313, int _Height_19314)
{
    int _pic_2d_19315 = NOVALUE;
    int _row_19316 = NOVALUE;
    int _bits_19317 = NOVALUE;
    int _bytes_19318 = NOVALUE;
    int _next_byte_19319 = NOVALUE;
    int _byte_19320 = NOVALUE;
    int _row_bytes_3__tmp_at17_19325 = NOVALUE;
    int _row_bytes_2__tmp_at17_19324 = NOVALUE;
    int _row_bytes_1__tmp_at17_19323 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_17_19322 = NOVALUE;
    int _10750 = NOVALUE;
    int _10747 = NOVALUE;
    int _10746 = NOVALUE;
    int _10742 = NOVALUE;
    int _10740 = NOVALUE;
    int _10738 = NOVALUE;
    int _10734 = NOVALUE;
    int _10730 = NOVALUE;
    int _10726 = NOVALUE;
    int _10722 = NOVALUE;
    int _10720 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_Width_19313)) {
        _1 = (long)(DBL_PTR(_Width_19313)->dbl);
        DeRefDS(_Width_19313);
        _Width_19313 = _1;
    }
    if (!IS_ATOM_INT(_Height_19314)) {
        _1 = (long)(DBL_PTR(_Height_19314)->dbl);
        DeRefDS(_Height_19314);
        _Height_19314 = _1;
    }

    /** 	pic_2d = {}*/
    RefDS(_5);
    DeRef(_pic_2d_19315);
    _pic_2d_19315 = _5;

    /** 	bytes = row_bytes(BitCount, Width)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at17_19323);
    if (_BitCount_19312 == (short)_BitCount_19312 && _Width_19313 <= INT15 && _Width_19313 >= -INT15)
    _row_bytes_1__tmp_at17_19323 = _BitCount_19312 * _Width_19313;
    else
    _row_bytes_1__tmp_at17_19323 = NewDouble(_BitCount_19312 * (double)_Width_19313);
    DeRef(_row_bytes_2__tmp_at17_19324);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at17_19323)) {
        _row_bytes_2__tmp_at17_19324 = _row_bytes_1__tmp_at17_19323 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at17_19324 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at17_19324 = NewDouble((double)_row_bytes_2__tmp_at17_19324);
    }
    else {
        _row_bytes_2__tmp_at17_19324 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at17_19323)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at17_19325);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at17_19324)) {
        if (32 > 0 && _row_bytes_2__tmp_at17_19324 >= 0) {
            _row_bytes_3__tmp_at17_19325 = _row_bytes_2__tmp_at17_19324 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at17_19324 / (double)32);
            if (_row_bytes_2__tmp_at17_19324 != MININT)
            _row_bytes_3__tmp_at17_19325 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at17_19325 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at17_19324, 32);
        _row_bytes_3__tmp_at17_19325 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_row_bytes_3__tmp_at17_19325)) {
        _bytes_19318 = _row_bytes_3__tmp_at17_19325 * 4;
    }
    else {
        _bytes_19318 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at17_19325)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at17_19323);
    _row_bytes_1__tmp_at17_19323 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at17_19324);
    _row_bytes_2__tmp_at17_19324 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at17_19325);
    _row_bytes_3__tmp_at17_19325 = NOVALUE;

    /** 	next_byte = 1*/
    _next_byte_19319 = 1;

    /** 	for i = 1 to Height do*/
    _10720 = _Height_19314;
    {
        int _i_19327;
        _i_19327 = 1;
L1: 
        if (_i_19327 > _10720){
            goto L2; // [49] 355
        }

        /** 		row = {}*/
        RefDS(_5);
        DeRef(_row_19316);
        _row_19316 = _5;

        /** 		if BitCount = 1 then*/
        if (_BitCount_19312 != 1)
        goto L3; // [65] 147

        /** 			for j = 1 to bytes do*/
        _10722 = _bytes_19318;
        {
            int _j_19332;
            _j_19332 = 1;
L4: 
            if (_j_19332 > _10722){
                goto L5; // [74] 144
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19311);
            _byte_19320 = (int)*(((s1_ptr)_2)->base + _next_byte_19319);
            if (!IS_ATOM_INT(_byte_19320))
            _byte_19320 = (long)DBL_PTR(_byte_19320)->dbl;

            /** 				next_byte += 1*/
            _next_byte_19319 = _next_byte_19319 + 1;

            /** 				bits = repeat(0, 8)*/
            DeRef(_bits_19317);
            _bits_19317 = Repeat(0, 8);

            /** 				for k = 8 to 1 by -1 do*/
            {
                int _k_19338;
                _k_19338 = 8;
L6: 
                if (_k_19338 < 1){
                    goto L7; // [101] 131
                }

                /** 					bits[k] = and_bits(byte, 1)*/
                {unsigned long tu;
                     tu = (unsigned long)_byte_19320 & (unsigned long)1;
                     _10726 = MAKE_UINT(tu);
                }
                _2 = (int)SEQ_PTR(_bits_19317);
                _2 = (int)(((s1_ptr)_2)->base + _k_19338);
                _1 = *(int *)_2;
                *(int *)_2 = _10726;
                if( _1 != _10726 ){
                    DeRef(_1);
                }
                _10726 = NOVALUE;

                /** 					byte = floor(byte/2)*/
                _byte_19320 = _byte_19320 >> 1;

                /** 				end for*/
                _k_19338 = _k_19338 + -1;
                goto L6; // [126] 108
L7: 
                ;
            }

            /** 				row &= bits*/
            Concat((object_ptr)&_row_19316, _row_19316, _bits_19317);

            /** 			end for*/
            _j_19332 = _j_19332 + 1;
            goto L4; // [139] 81
L5: 
            ;
        }
        goto L8; // [144] 337
L3: 

        /** 		elsif BitCount = 2 then*/
        if (_BitCount_19312 != 2)
        goto L9; // [149] 233

        /** 			for j = 1 to bytes do*/
        _10730 = _bytes_19318;
        {
            int _j_19345;
            _j_19345 = 1;
LA: 
            if (_j_19345 > _10730){
                goto LB; // [158] 230
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19311);
            _byte_19320 = (int)*(((s1_ptr)_2)->base + _next_byte_19319);
            if (!IS_ATOM_INT(_byte_19320))
            _byte_19320 = (long)DBL_PTR(_byte_19320)->dbl;

            /** 				next_byte += 1*/
            _next_byte_19319 = _next_byte_19319 + 1;

            /** 				bits = repeat(0, 4)*/
            DeRef(_bits_19317);
            _bits_19317 = Repeat(0, 4);

            /** 				for k = 4 to 1 by -1 do*/
            {
                int _k_19351;
                _k_19351 = 4;
LC: 
                if (_k_19351 < 1){
                    goto LD; // [185] 217
                }

                /** 					bits[k] = and_bits(byte, 3)*/
                {unsigned long tu;
                     tu = (unsigned long)_byte_19320 & (unsigned long)3;
                     _10734 = MAKE_UINT(tu);
                }
                _2 = (int)SEQ_PTR(_bits_19317);
                _2 = (int)(((s1_ptr)_2)->base + _k_19351);
                _1 = *(int *)_2;
                *(int *)_2 = _10734;
                if( _1 != _10734 ){
                    DeRef(_1);
                }
                _10734 = NOVALUE;

                /** 					byte = floor(byte/4)*/
                if (4 > 0 && _byte_19320 >= 0) {
                    _byte_19320 = _byte_19320 / 4;
                }
                else {
                    temp_dbl = floor((double)_byte_19320 / (double)4);
                    _byte_19320 = (long)temp_dbl;
                }

                /** 				end for*/
                _k_19351 = _k_19351 + -1;
                goto LC; // [212] 192
LD: 
                ;
            }

            /** 				row &= bits*/
            Concat((object_ptr)&_row_19316, _row_19316, _bits_19317);

            /** 			end for*/
            _j_19345 = _j_19345 + 1;
            goto LA; // [225] 165
LB: 
            ;
        }
        goto L8; // [230] 337
L9: 

        /** 		elsif BitCount = 4 then*/
        if (_BitCount_19312 != 4)
        goto LE; // [235] 293

        /** 			for j = 1 to bytes do*/
        _10738 = _bytes_19318;
        {
            int _j_19358;
            _j_19358 = 1;
LF: 
            if (_j_19358 > _10738){
                goto L10; // [244] 290
            }

            /** 				byte = image[next_byte]*/
            _2 = (int)SEQ_PTR(_image_19311);
            _byte_19320 = (int)*(((s1_ptr)_2)->base + _next_byte_19319);
            if (!IS_ATOM_INT(_byte_19320))
            _byte_19320 = (long)DBL_PTR(_byte_19320)->dbl;

            /** 				row = append(row, floor(byte/16))*/
            if (16 > 0 && _byte_19320 >= 0) {
                _10740 = _byte_19320 / 16;
            }
            else {
                temp_dbl = floor((double)_byte_19320 / (double)16);
                _10740 = (long)temp_dbl;
            }
            Append(&_row_19316, _row_19316, _10740);
            _10740 = NOVALUE;

            /** 				row = append(row, and_bits(byte, 15))*/
            {unsigned long tu;
                 tu = (unsigned long)_byte_19320 & (unsigned long)15;
                 _10742 = MAKE_UINT(tu);
            }
            Ref(_10742);
            Append(&_row_19316, _row_19316, _10742);
            DeRef(_10742);
            _10742 = NOVALUE;

            /** 				next_byte += 1*/
            _next_byte_19319 = _next_byte_19319 + 1;

            /** 			end for*/
            _j_19358 = _j_19358 + 1;
            goto LF; // [285] 251
L10: 
            ;
        }
        goto L8; // [290] 337
LE: 

        /** 		elsif BitCount = 8 then*/
        if (_BitCount_19312 != 8)
        goto L11; // [295] 323

        /** 			row = image[next_byte..next_byte+bytes-1]*/
        _10746 = _next_byte_19319 + _bytes_19318;
        if ((long)((unsigned long)_10746 + (unsigned long)HIGH_BITS) >= 0) 
        _10746 = NewDouble((double)_10746);
        if (IS_ATOM_INT(_10746)) {
            _10747 = _10746 - 1;
        }
        else {
            _10747 = NewDouble(DBL_PTR(_10746)->dbl - (double)1);
        }
        DeRef(_10746);
        _10746 = NOVALUE;
        rhs_slice_target = (object_ptr)&_row_19316;
        RHS_Slice(_image_19311, _next_byte_19319, _10747);

        /** 			next_byte += bytes*/
        _next_byte_19319 = _next_byte_19319 + _bytes_19318;
        goto L8; // [320] 337
L11: 

        /** 			error_code = BMP_UNSUPPORTED_FORMAT*/
        _41error_code_19215 = 4;

        /** 			exit*/
        goto L2; // [334] 355
L8: 

        /** 		pic_2d = prepend(pic_2d, row[1..Width])*/
        rhs_slice_target = (object_ptr)&_10750;
        RHS_Slice(_row_19316, 1, _Width_19313);
        RefDS(_10750);
        Prepend(&_pic_2d_19315, _pic_2d_19315, _10750);
        DeRefDS(_10750);
        _10750 = NOVALUE;

        /** 	end for*/
        _i_19327 = _i_19327 + 1;
        goto L1; // [350] 56
L2: 
        ;
    }

    /** 	return pic_2d*/
    DeRefDS(_image_19311);
    DeRef(_row_19316);
    DeRef(_bits_19317);
    DeRef(_10747);
    _10747 = NOVALUE;
    return _pic_2d_19315;
    ;
}


int  __stdcall _41read_bitmap(int _file_name_19378)
{
    int _Planes_19379 = NOVALUE;
    int _BitCount_19380 = NOVALUE;
    int _Width_19381 = NOVALUE;
    int _Height_19382 = NOVALUE;
    int _Compression_19383 = NOVALUE;
    int _OffBits_19384 = NOVALUE;
    int _SizeHeader_19385 = NOVALUE;
    int _NumColors_19386 = NOVALUE;
    int _Palette_19387 = NOVALUE;
    int _Bits_19388 = NOVALUE;
    int _two_d_bits_19389 = NOVALUE;
    int _get_dword_1__tmp_at38_19399 = NOVALUE;
    int _get_dword_inlined_get_dword_at_38_19398 = NOVALUE;
    int _upper_inlined_get_dword_at_38_19397 = NOVALUE;
    int _lower_inlined_get_dword_at_38_19396 = NOVALUE;
    int _get_dword_1__tmp_at77_19406 = NOVALUE;
    int _get_dword_inlined_get_dword_at_77_19405 = NOVALUE;
    int _upper_inlined_get_dword_at_77_19404 = NOVALUE;
    int _lower_inlined_get_dword_at_77_19403 = NOVALUE;
    int _get_dword_1__tmp_at106_19411 = NOVALUE;
    int _get_dword_inlined_get_dword_at_106_19410 = NOVALUE;
    int _upper_inlined_get_dword_at_106_19409 = NOVALUE;
    int _lower_inlined_get_dword_at_106_19408 = NOVALUE;
    int _get_dword_1__tmp_at141_19418 = NOVALUE;
    int _get_dword_inlined_get_dword_at_141_19417 = NOVALUE;
    int _upper_inlined_get_dword_at_141_19416 = NOVALUE;
    int _lower_inlined_get_dword_at_141_19415 = NOVALUE;
    int _get_dword_1__tmp_at170_19423 = NOVALUE;
    int _get_dword_inlined_get_dword_at_170_19422 = NOVALUE;
    int _upper_inlined_get_dword_at_170_19421 = NOVALUE;
    int _lower_inlined_get_dword_at_170_19420 = NOVALUE;
    int _get_dword_1__tmp_at213_19430 = NOVALUE;
    int _get_dword_inlined_get_dword_at_213_19429 = NOVALUE;
    int _upper_inlined_get_dword_at_213_19428 = NOVALUE;
    int _lower_inlined_get_dword_at_213_19427 = NOVALUE;
    int _get_dword_1__tmp_at263_19438 = NOVALUE;
    int _get_dword_inlined_get_dword_at_263_19437 = NOVALUE;
    int _upper_inlined_get_dword_at_263_19436 = NOVALUE;
    int _lower_inlined_get_dword_at_263_19435 = NOVALUE;
    int _get_dword_1__tmp_at292_19443 = NOVALUE;
    int _get_dword_inlined_get_dword_at_292_19442 = NOVALUE;
    int _upper_inlined_get_dword_at_292_19441 = NOVALUE;
    int _lower_inlined_get_dword_at_292_19440 = NOVALUE;
    int _get_dword_1__tmp_at321_19448 = NOVALUE;
    int _get_dword_inlined_get_dword_at_321_19447 = NOVALUE;
    int _upper_inlined_get_dword_at_321_19446 = NOVALUE;
    int _lower_inlined_get_dword_at_321_19445 = NOVALUE;
    int _get_dword_1__tmp_at350_19453 = NOVALUE;
    int _get_dword_inlined_get_dword_at_350_19452 = NOVALUE;
    int _upper_inlined_get_dword_at_350_19451 = NOVALUE;
    int _lower_inlined_get_dword_at_350_19450 = NOVALUE;
    int _get_dword_1__tmp_at379_19458 = NOVALUE;
    int _get_dword_inlined_get_dword_at_379_19457 = NOVALUE;
    int _upper_inlined_get_dword_at_379_19456 = NOVALUE;
    int _lower_inlined_get_dword_at_379_19455 = NOVALUE;
    int _row_bytes_3__tmp_at595_19491 = NOVALUE;
    int _row_bytes_2__tmp_at595_19490 = NOVALUE;
    int _row_bytes_1__tmp_at595_19489 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_595_19488 = NOVALUE;
    int _10785 = NOVALUE;
    int _10782 = NOVALUE;
    int _10781 = NOVALUE;
    int _10779 = NOVALUE;
    int _10778 = NOVALUE;
    int _10777 = NOVALUE;
    int _10774 = NOVALUE;
    int _10773 = NOVALUE;
    int _10766 = NOVALUE;
    int _10764 = NOVALUE;
    int _10762 = NOVALUE;
    int _10761 = NOVALUE;
    int _10756 = NOVALUE;
    int _10755 = NOVALUE;
    int _10754 = NOVALUE;
    int _0, _1, _2;
    

    /** 	error_code = 0*/
    _41error_code_19215 = 0;

    /** 	fn = open(file_name, "rb")*/
    _41fn_19214 = EOpen(_file_name_19378, _1309, 0);

    /** 	if fn = -1 then*/
    if (_41fn_19214 != -1)
    goto L1; // [19] 32

    /** 		return BMP_OPEN_FAILED*/
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRef(_Bits_19388);
    DeRef(_two_d_bits_19389);
    return 2;
L1: 

    /** 	get_word() -- Size*/
    _10754 = _41get_word();

    /** 	get_dword() -- Type*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_38_19396;
    _lower_inlined_get_dword_at_38_19396 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_38_19396)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_38_19396)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_38_19396);
        _lower_inlined_get_dword_at_38_19396 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_38_19397;
    _upper_inlined_get_dword_at_38_19397 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_38_19397)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_38_19397)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_38_19397);
        _upper_inlined_get_dword_at_38_19397 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at38_19399);
    _get_dword_1__tmp_at38_19399 = NewDouble(_upper_inlined_get_dword_at_38_19397 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_38_19398);
    if (IS_ATOM_INT(_get_dword_1__tmp_at38_19399)) {
        _get_dword_inlined_get_dword_at_38_19398 = _get_dword_1__tmp_at38_19399 + _lower_inlined_get_dword_at_38_19396;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_38_19398 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_38_19398 = NewDouble((double)_get_dword_inlined_get_dword_at_38_19398);
    }
    else {
        _get_dword_inlined_get_dword_at_38_19398 = NewDouble(DBL_PTR(_get_dword_1__tmp_at38_19399)->dbl + (double)_lower_inlined_get_dword_at_38_19396);
    }
    DeRef(_lower_inlined_get_dword_at_38_19396);
    _lower_inlined_get_dword_at_38_19396 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_38_19397);
    _upper_inlined_get_dword_at_38_19397 = NOVALUE;
    DeRef(_get_dword_1__tmp_at38_19399);
    _get_dword_1__tmp_at38_19399 = NOVALUE;

    /** 	get_word() -- X Hotspot*/
    _10755 = _41get_word();

    /** 	get_word() -- Y Hotspot*/
    _10756 = _41get_word();

    /** 	OffBits = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_77_19403;
    _lower_inlined_get_dword_at_77_19403 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_77_19403)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_77_19403)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_77_19403);
        _lower_inlined_get_dword_at_77_19403 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_77_19404;
    _upper_inlined_get_dword_at_77_19404 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_77_19404)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_77_19404)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_77_19404);
        _upper_inlined_get_dword_at_77_19404 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at77_19406);
    _get_dword_1__tmp_at77_19406 = NewDouble(_upper_inlined_get_dword_at_77_19404 * (double)65536);
    DeRef(_OffBits_19384);
    if (IS_ATOM_INT(_get_dword_1__tmp_at77_19406)) {
        _OffBits_19384 = _get_dword_1__tmp_at77_19406 + _lower_inlined_get_dword_at_77_19403;
        if ((long)((unsigned long)_OffBits_19384 + (unsigned long)HIGH_BITS) >= 0) 
        _OffBits_19384 = NewDouble((double)_OffBits_19384);
    }
    else {
        _OffBits_19384 = NewDouble(DBL_PTR(_get_dword_1__tmp_at77_19406)->dbl + (double)_lower_inlined_get_dword_at_77_19403);
    }
    DeRef(_lower_inlined_get_dword_at_77_19403);
    _lower_inlined_get_dword_at_77_19403 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_77_19404);
    _upper_inlined_get_dword_at_77_19404 = NOVALUE;
    DeRef(_get_dword_1__tmp_at77_19406);
    _get_dword_1__tmp_at77_19406 = NOVALUE;

    /** 	SizeHeader = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_106_19408;
    _lower_inlined_get_dword_at_106_19408 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_106_19408)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_106_19408)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_106_19408);
        _lower_inlined_get_dword_at_106_19408 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_106_19409;
    _upper_inlined_get_dword_at_106_19409 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_106_19409)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_106_19409)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_106_19409);
        _upper_inlined_get_dword_at_106_19409 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at106_19411);
    _get_dword_1__tmp_at106_19411 = NewDouble(_upper_inlined_get_dword_at_106_19409 * (double)65536);
    DeRef(_SizeHeader_19385);
    if (IS_ATOM_INT(_get_dword_1__tmp_at106_19411)) {
        _SizeHeader_19385 = _get_dword_1__tmp_at106_19411 + _lower_inlined_get_dword_at_106_19408;
        if ((long)((unsigned long)_SizeHeader_19385 + (unsigned long)HIGH_BITS) >= 0) 
        _SizeHeader_19385 = NewDouble((double)_SizeHeader_19385);
    }
    else {
        _SizeHeader_19385 = NewDouble(DBL_PTR(_get_dword_1__tmp_at106_19411)->dbl + (double)_lower_inlined_get_dword_at_106_19408);
    }
    DeRef(_lower_inlined_get_dword_at_106_19408);
    _lower_inlined_get_dword_at_106_19408 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_106_19409);
    _upper_inlined_get_dword_at_106_19409 = NOVALUE;
    DeRef(_get_dword_1__tmp_at106_19411);
    _get_dword_1__tmp_at106_19411 = NOVALUE;

    /** 	if SizeHeader = NEWHDRSIZE then*/
    if (binary_op_a(NOTEQ, _SizeHeader_19385, 40)){
        goto L2; // [136] 467
    }

    /** 		Width = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_141_19415;
    _lower_inlined_get_dword_at_141_19415 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_141_19415)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_141_19415)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_141_19415);
        _lower_inlined_get_dword_at_141_19415 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_141_19416;
    _upper_inlined_get_dword_at_141_19416 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_141_19416)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_141_19416)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_141_19416);
        _upper_inlined_get_dword_at_141_19416 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at141_19418);
    _get_dword_1__tmp_at141_19418 = NewDouble(_upper_inlined_get_dword_at_141_19416 * (double)65536);
    DeRef(_Width_19381);
    if (IS_ATOM_INT(_get_dword_1__tmp_at141_19418)) {
        _Width_19381 = _get_dword_1__tmp_at141_19418 + _lower_inlined_get_dword_at_141_19415;
        if ((long)((unsigned long)_Width_19381 + (unsigned long)HIGH_BITS) >= 0) 
        _Width_19381 = NewDouble((double)_Width_19381);
    }
    else {
        _Width_19381 = NewDouble(DBL_PTR(_get_dword_1__tmp_at141_19418)->dbl + (double)_lower_inlined_get_dword_at_141_19415);
    }
    DeRef(_lower_inlined_get_dword_at_141_19415);
    _lower_inlined_get_dword_at_141_19415 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_141_19416);
    _upper_inlined_get_dword_at_141_19416 = NOVALUE;
    DeRef(_get_dword_1__tmp_at141_19418);
    _get_dword_1__tmp_at141_19418 = NOVALUE;

    /** 		Height = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_170_19420;
    _lower_inlined_get_dword_at_170_19420 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_170_19420)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_170_19420)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_170_19420);
        _lower_inlined_get_dword_at_170_19420 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_170_19421;
    _upper_inlined_get_dword_at_170_19421 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_170_19421)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_170_19421)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_170_19421);
        _upper_inlined_get_dword_at_170_19421 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at170_19423);
    _get_dword_1__tmp_at170_19423 = NewDouble(_upper_inlined_get_dword_at_170_19421 * (double)65536);
    DeRef(_Height_19382);
    if (IS_ATOM_INT(_get_dword_1__tmp_at170_19423)) {
        _Height_19382 = _get_dword_1__tmp_at170_19423 + _lower_inlined_get_dword_at_170_19420;
        if ((long)((unsigned long)_Height_19382 + (unsigned long)HIGH_BITS) >= 0) 
        _Height_19382 = NewDouble((double)_Height_19382);
    }
    else {
        _Height_19382 = NewDouble(DBL_PTR(_get_dword_1__tmp_at170_19423)->dbl + (double)_lower_inlined_get_dword_at_170_19420);
    }
    DeRef(_lower_inlined_get_dword_at_170_19420);
    _lower_inlined_get_dword_at_170_19420 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_170_19421);
    _upper_inlined_get_dword_at_170_19421 = NOVALUE;
    DeRef(_get_dword_1__tmp_at170_19423);
    _get_dword_1__tmp_at170_19423 = NOVALUE;

    /** 		Planes = get_word()*/
    _Planes_19379 = _41get_word();
    if (!IS_ATOM_INT(_Planes_19379)) {
        _1 = (long)(DBL_PTR(_Planes_19379)->dbl);
        DeRefDS(_Planes_19379);
        _Planes_19379 = _1;
    }

    /** 		BitCount = get_word()*/
    _BitCount_19380 = _41get_word();
    if (!IS_ATOM_INT(_BitCount_19380)) {
        _1 = (long)(DBL_PTR(_BitCount_19380)->dbl);
        DeRefDS(_BitCount_19380);
        _BitCount_19380 = _1;
    }

    /** 		Compression = get_dword()*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_213_19427;
    _lower_inlined_get_dword_at_213_19427 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_213_19427)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_213_19427)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_213_19427);
        _lower_inlined_get_dword_at_213_19427 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_213_19428;
    _upper_inlined_get_dword_at_213_19428 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_213_19428)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_213_19428)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_213_19428);
        _upper_inlined_get_dword_at_213_19428 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at213_19430);
    _get_dword_1__tmp_at213_19430 = NewDouble(_upper_inlined_get_dword_at_213_19428 * (double)65536);
    DeRef(_Compression_19383);
    if (IS_ATOM_INT(_get_dword_1__tmp_at213_19430)) {
        _Compression_19383 = _get_dword_1__tmp_at213_19430 + _lower_inlined_get_dword_at_213_19427;
        if ((long)((unsigned long)_Compression_19383 + (unsigned long)HIGH_BITS) >= 0) 
        _Compression_19383 = NewDouble((double)_Compression_19383);
    }
    else {
        _Compression_19383 = NewDouble(DBL_PTR(_get_dword_1__tmp_at213_19430)->dbl + (double)_lower_inlined_get_dword_at_213_19427);
    }
    DeRef(_lower_inlined_get_dword_at_213_19427);
    _lower_inlined_get_dword_at_213_19427 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_213_19428);
    _upper_inlined_get_dword_at_213_19428 = NOVALUE;
    DeRef(_get_dword_1__tmp_at213_19430);
    _get_dword_1__tmp_at213_19430 = NOVALUE;

    /** 		if Compression != 0 then*/
    if (binary_op_a(EQUALS, _Compression_19383, 0)){
        goto L3; // [243] 262
    }

    /** 			close(fn)*/
    EClose(_41fn_19214);

    /** 			return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRef(_Bits_19388);
    DeRef(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    return 4;
L3: 

    /** 		get_dword() -- Size of Image*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_263_19435;
    _lower_inlined_get_dword_at_263_19435 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_263_19435)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_263_19435)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_263_19435);
        _lower_inlined_get_dword_at_263_19435 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_263_19436;
    _upper_inlined_get_dword_at_263_19436 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_263_19436)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_263_19436)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_263_19436);
        _upper_inlined_get_dword_at_263_19436 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at263_19438);
    _get_dword_1__tmp_at263_19438 = NewDouble(_upper_inlined_get_dword_at_263_19436 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_263_19437);
    if (IS_ATOM_INT(_get_dword_1__tmp_at263_19438)) {
        _get_dword_inlined_get_dword_at_263_19437 = _get_dword_1__tmp_at263_19438 + _lower_inlined_get_dword_at_263_19435;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_263_19437 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_263_19437 = NewDouble((double)_get_dword_inlined_get_dword_at_263_19437);
    }
    else {
        _get_dword_inlined_get_dword_at_263_19437 = NewDouble(DBL_PTR(_get_dword_1__tmp_at263_19438)->dbl + (double)_lower_inlined_get_dword_at_263_19435);
    }
    DeRef(_lower_inlined_get_dword_at_263_19435);
    _lower_inlined_get_dword_at_263_19435 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_263_19436);
    _upper_inlined_get_dword_at_263_19436 = NOVALUE;
    DeRef(_get_dword_1__tmp_at263_19438);
    _get_dword_1__tmp_at263_19438 = NOVALUE;

    /** 		get_dword() -- X Pels/Meter*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_292_19440;
    _lower_inlined_get_dword_at_292_19440 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_292_19440)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_292_19440)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_292_19440);
        _lower_inlined_get_dword_at_292_19440 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_292_19441;
    _upper_inlined_get_dword_at_292_19441 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_292_19441)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_292_19441)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_292_19441);
        _upper_inlined_get_dword_at_292_19441 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at292_19443);
    _get_dword_1__tmp_at292_19443 = NewDouble(_upper_inlined_get_dword_at_292_19441 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_292_19442);
    if (IS_ATOM_INT(_get_dword_1__tmp_at292_19443)) {
        _get_dword_inlined_get_dword_at_292_19442 = _get_dword_1__tmp_at292_19443 + _lower_inlined_get_dword_at_292_19440;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_292_19442 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_292_19442 = NewDouble((double)_get_dword_inlined_get_dword_at_292_19442);
    }
    else {
        _get_dword_inlined_get_dword_at_292_19442 = NewDouble(DBL_PTR(_get_dword_1__tmp_at292_19443)->dbl + (double)_lower_inlined_get_dword_at_292_19440);
    }
    DeRef(_lower_inlined_get_dword_at_292_19440);
    _lower_inlined_get_dword_at_292_19440 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_292_19441);
    _upper_inlined_get_dword_at_292_19441 = NOVALUE;
    DeRef(_get_dword_1__tmp_at292_19443);
    _get_dword_1__tmp_at292_19443 = NOVALUE;

    /** 		get_dword() -- Y Pels/Meter*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_321_19445;
    _lower_inlined_get_dword_at_321_19445 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_321_19445)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_321_19445)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_321_19445);
        _lower_inlined_get_dword_at_321_19445 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_321_19446;
    _upper_inlined_get_dword_at_321_19446 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_321_19446)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_321_19446)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_321_19446);
        _upper_inlined_get_dword_at_321_19446 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at321_19448);
    _get_dword_1__tmp_at321_19448 = NewDouble(_upper_inlined_get_dword_at_321_19446 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_321_19447);
    if (IS_ATOM_INT(_get_dword_1__tmp_at321_19448)) {
        _get_dword_inlined_get_dword_at_321_19447 = _get_dword_1__tmp_at321_19448 + _lower_inlined_get_dword_at_321_19445;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_321_19447 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_321_19447 = NewDouble((double)_get_dword_inlined_get_dword_at_321_19447);
    }
    else {
        _get_dword_inlined_get_dword_at_321_19447 = NewDouble(DBL_PTR(_get_dword_1__tmp_at321_19448)->dbl + (double)_lower_inlined_get_dword_at_321_19445);
    }
    DeRef(_lower_inlined_get_dword_at_321_19445);
    _lower_inlined_get_dword_at_321_19445 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_321_19446);
    _upper_inlined_get_dword_at_321_19446 = NOVALUE;
    DeRef(_get_dword_1__tmp_at321_19448);
    _get_dword_1__tmp_at321_19448 = NOVALUE;

    /** 		get_dword() -- Color Used*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_350_19450;
    _lower_inlined_get_dword_at_350_19450 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_350_19450)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_350_19450)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_350_19450);
        _lower_inlined_get_dword_at_350_19450 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_350_19451;
    _upper_inlined_get_dword_at_350_19451 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_350_19451)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_350_19451)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_350_19451);
        _upper_inlined_get_dword_at_350_19451 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at350_19453);
    _get_dword_1__tmp_at350_19453 = NewDouble(_upper_inlined_get_dword_at_350_19451 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_350_19452);
    if (IS_ATOM_INT(_get_dword_1__tmp_at350_19453)) {
        _get_dword_inlined_get_dword_at_350_19452 = _get_dword_1__tmp_at350_19453 + _lower_inlined_get_dword_at_350_19450;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_350_19452 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_350_19452 = NewDouble((double)_get_dword_inlined_get_dword_at_350_19452);
    }
    else {
        _get_dword_inlined_get_dword_at_350_19452 = NewDouble(DBL_PTR(_get_dword_1__tmp_at350_19453)->dbl + (double)_lower_inlined_get_dword_at_350_19450);
    }
    DeRef(_lower_inlined_get_dword_at_350_19450);
    _lower_inlined_get_dword_at_350_19450 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_350_19451);
    _upper_inlined_get_dword_at_350_19451 = NOVALUE;
    DeRef(_get_dword_1__tmp_at350_19453);
    _get_dword_1__tmp_at350_19453 = NOVALUE;

    /** 		get_dword() -- Color Important*/

    /** 	lower = get_word()*/
    _0 = _lower_inlined_get_dword_at_379_19455;
    _lower_inlined_get_dword_at_379_19455 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_lower_inlined_get_dword_at_379_19455)) {
        _1 = (long)(DBL_PTR(_lower_inlined_get_dword_at_379_19455)->dbl);
        DeRefDS(_lower_inlined_get_dword_at_379_19455);
        _lower_inlined_get_dword_at_379_19455 = _1;
    }

    /** 	upper = get_word()*/
    _0 = _upper_inlined_get_dword_at_379_19456;
    _upper_inlined_get_dword_at_379_19456 = _41get_word();
    DeRef(_0);
    if (!IS_ATOM_INT(_upper_inlined_get_dword_at_379_19456)) {
        _1 = (long)(DBL_PTR(_upper_inlined_get_dword_at_379_19456)->dbl);
        DeRefDS(_upper_inlined_get_dword_at_379_19456);
        _upper_inlined_get_dword_at_379_19456 = _1;
    }

    /** 	return upper * 65536 + lower*/
    DeRef(_get_dword_1__tmp_at379_19458);
    _get_dword_1__tmp_at379_19458 = NewDouble(_upper_inlined_get_dword_at_379_19456 * (double)65536);
    DeRef(_get_dword_inlined_get_dword_at_379_19457);
    if (IS_ATOM_INT(_get_dword_1__tmp_at379_19458)) {
        _get_dword_inlined_get_dword_at_379_19457 = _get_dword_1__tmp_at379_19458 + _lower_inlined_get_dword_at_379_19455;
        if ((long)((unsigned long)_get_dword_inlined_get_dword_at_379_19457 + (unsigned long)HIGH_BITS) >= 0) 
        _get_dword_inlined_get_dword_at_379_19457 = NewDouble((double)_get_dword_inlined_get_dword_at_379_19457);
    }
    else {
        _get_dword_inlined_get_dword_at_379_19457 = NewDouble(DBL_PTR(_get_dword_1__tmp_at379_19458)->dbl + (double)_lower_inlined_get_dword_at_379_19455);
    }
    DeRef(_lower_inlined_get_dword_at_379_19455);
    _lower_inlined_get_dword_at_379_19455 = NOVALUE;
    DeRef(_upper_inlined_get_dword_at_379_19456);
    _upper_inlined_get_dword_at_379_19456 = NOVALUE;
    DeRef(_get_dword_1__tmp_at379_19458);
    _get_dword_1__tmp_at379_19458 = NOVALUE;

    /** 		NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 4*/
    if (IS_ATOM_INT(_OffBits_19384) && IS_ATOM_INT(_SizeHeader_19385)) {
        _10761 = _OffBits_19384 - _SizeHeader_19385;
        if ((long)((unsigned long)_10761 +(unsigned long) HIGH_BITS) >= 0){
            _10761 = NewDouble((double)_10761);
        }
    }
    else {
        if (IS_ATOM_INT(_OffBits_19384)) {
            _10761 = NewDouble((double)_OffBits_19384 - DBL_PTR(_SizeHeader_19385)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader_19385)) {
                _10761 = NewDouble(DBL_PTR(_OffBits_19384)->dbl - (double)_SizeHeader_19385);
            }
            else
            _10761 = NewDouble(DBL_PTR(_OffBits_19384)->dbl - DBL_PTR(_SizeHeader_19385)->dbl);
        }
    }
    if (IS_ATOM_INT(_10761)) {
        _10762 = _10761 - 14;
        if ((long)((unsigned long)_10762 +(unsigned long) HIGH_BITS) >= 0){
            _10762 = NewDouble((double)_10762);
        }
    }
    else {
        _10762 = NewDouble(DBL_PTR(_10761)->dbl - (double)14);
    }
    DeRef(_10761);
    _10761 = NOVALUE;
    DeRef(_NumColors_19386);
    if (IS_ATOM_INT(_10762)) {
        _NumColors_19386 = (_10762 % 4) ? NewDouble((double)_10762 / 4) : (_10762 / 4);
    }
    else {
        _NumColors_19386 = NewDouble(DBL_PTR(_10762)->dbl / (double)4);
    }
    DeRef(_10762);
    _10762 = NOVALUE;

    /** 		if NumColors < 2 or NumColors > 256 then*/
    if (IS_ATOM_INT(_NumColors_19386)) {
        _10764 = (_NumColors_19386 < 2);
    }
    else {
        _10764 = (DBL_PTR(_NumColors_19386)->dbl < (double)2);
    }
    if (_10764 != 0) {
        goto L4; // [427] 440
    }
    if (IS_ATOM_INT(_NumColors_19386)) {
        _10766 = (_NumColors_19386 > 256);
    }
    else {
        _10766 = (DBL_PTR(_NumColors_19386)->dbl > (double)256);
    }
    if (_10766 == 0)
    {
        DeRef(_10766);
        _10766 = NOVALUE;
        goto L5; // [436] 455
    }
    else{
        DeRef(_10766);
        _10766 = NOVALUE;
    }
L4: 

    /** 			close(fn)*/
    EClose(_41fn_19214);

    /** 			return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRef(_Bits_19388);
    DeRef(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    DeRef(_10764);
    _10764 = NOVALUE;
    return 4;
L5: 

    /** 		Palette = get_rgb_block(NumColors, 4) */
    Ref(_NumColors_19386);
    _0 = _Palette_19387;
    _Palette_19387 = _41get_rgb_block(_NumColors_19386, 4);
    DeRef(_0);
    goto L6; // [464] 538
L2: 

    /** 	elsif SizeHeader = OLDHDRSIZE then */
    if (binary_op_a(NOTEQ, _SizeHeader_19385, 12)){
        goto L7; // [469] 523
    }

    /** 		Width = get_word()*/
    _0 = _Width_19381;
    _Width_19381 = _41get_word();
    DeRef(_0);

    /** 		Height = get_word()*/
    _0 = _Height_19382;
    _Height_19382 = _41get_word();
    DeRef(_0);

    /** 		Planes = get_word()*/
    _Planes_19379 = _41get_word();
    if (!IS_ATOM_INT(_Planes_19379)) {
        _1 = (long)(DBL_PTR(_Planes_19379)->dbl);
        DeRefDS(_Planes_19379);
        _Planes_19379 = _1;
    }

    /** 		BitCount = get_word()*/
    _BitCount_19380 = _41get_word();
    if (!IS_ATOM_INT(_BitCount_19380)) {
        _1 = (long)(DBL_PTR(_BitCount_19380)->dbl);
        DeRefDS(_BitCount_19380);
        _BitCount_19380 = _1;
    }

    /** 		NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 3*/
    if (IS_ATOM_INT(_OffBits_19384) && IS_ATOM_INT(_SizeHeader_19385)) {
        _10773 = _OffBits_19384 - _SizeHeader_19385;
        if ((long)((unsigned long)_10773 +(unsigned long) HIGH_BITS) >= 0){
            _10773 = NewDouble((double)_10773);
        }
    }
    else {
        if (IS_ATOM_INT(_OffBits_19384)) {
            _10773 = NewDouble((double)_OffBits_19384 - DBL_PTR(_SizeHeader_19385)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader_19385)) {
                _10773 = NewDouble(DBL_PTR(_OffBits_19384)->dbl - (double)_SizeHeader_19385);
            }
            else
            _10773 = NewDouble(DBL_PTR(_OffBits_19384)->dbl - DBL_PTR(_SizeHeader_19385)->dbl);
        }
    }
    if (IS_ATOM_INT(_10773)) {
        _10774 = _10773 - 14;
        if ((long)((unsigned long)_10774 +(unsigned long) HIGH_BITS) >= 0){
            _10774 = NewDouble((double)_10774);
        }
    }
    else {
        _10774 = NewDouble(DBL_PTR(_10773)->dbl - (double)14);
    }
    DeRef(_10773);
    _10773 = NOVALUE;
    DeRef(_NumColors_19386);
    if (IS_ATOM_INT(_10774)) {
        _NumColors_19386 = (_10774 % 3) ? NewDouble((double)_10774 / 3) : (_10774 / 3);
    }
    else {
        _NumColors_19386 = NewDouble(DBL_PTR(_10774)->dbl / (double)3);
    }
    DeRef(_10774);
    _10774 = NOVALUE;

    /** 		Palette = get_rgb_block(NumColors, 3) */
    Ref(_NumColors_19386);
    _0 = _Palette_19387;
    _Palette_19387 = _41get_rgb_block(_NumColors_19386, 3);
    DeRef(_0);
    goto L6; // [520] 538
L7: 

    /** 		close(fn)*/
    EClose(_41fn_19214);

    /** 		return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRef(_Bits_19388);
    DeRef(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    DeRef(_10764);
    _10764 = NOVALUE;
    return 4;
L6: 

    /** 	if Planes != 1 or Height <= 0 or Width <= 0 then*/
    _10777 = (_Planes_19379 != 1);
    if (_10777 != 0) {
        _10778 = 1;
        goto L8; // [546] 560
    }
    if (IS_ATOM_INT(_Height_19382)) {
        _10779 = (_Height_19382 <= 0);
    }
    else {
        _10779 = (DBL_PTR(_Height_19382)->dbl <= (double)0);
    }
    _10778 = (_10779 != 0);
L8: 
    if (_10778 != 0) {
        goto L9; // [560] 575
    }
    if (IS_ATOM_INT(_Width_19381)) {
        _10781 = (_Width_19381 <= 0);
    }
    else {
        _10781 = (DBL_PTR(_Width_19381)->dbl <= (double)0);
    }
    if (_10781 == 0)
    {
        DeRef(_10781);
        _10781 = NOVALUE;
        goto LA; // [571] 590
    }
    else{
        DeRef(_10781);
        _10781 = NOVALUE;
    }
L9: 

    /** 		close(fn)*/
    EClose(_41fn_19214);

    /** 		return BMP_UNSUPPORTED_FORMAT*/
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRef(_Bits_19388);
    DeRef(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    DeRef(_10764);
    _10764 = NOVALUE;
    DeRef(_10777);
    _10777 = NOVALUE;
    DeRef(_10779);
    _10779 = NOVALUE;
    return 4;
LA: 

    /** 	Bits = get_c_block(row_bytes(BitCount, Width) * Height)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at595_19489);
    if (IS_ATOM_INT(_Width_19381)) {
        if (_BitCount_19380 == (short)_BitCount_19380 && _Width_19381 <= INT15 && _Width_19381 >= -INT15)
        _row_bytes_1__tmp_at595_19489 = _BitCount_19380 * _Width_19381;
        else
        _row_bytes_1__tmp_at595_19489 = NewDouble(_BitCount_19380 * (double)_Width_19381);
    }
    else {
        _row_bytes_1__tmp_at595_19489 = NewDouble((double)_BitCount_19380 * DBL_PTR(_Width_19381)->dbl);
    }
    DeRef(_row_bytes_2__tmp_at595_19490);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at595_19489)) {
        _row_bytes_2__tmp_at595_19490 = _row_bytes_1__tmp_at595_19489 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at595_19490 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at595_19490 = NewDouble((double)_row_bytes_2__tmp_at595_19490);
    }
    else {
        _row_bytes_2__tmp_at595_19490 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at595_19489)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at595_19491);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at595_19490)) {
        if (32 > 0 && _row_bytes_2__tmp_at595_19490 >= 0) {
            _row_bytes_3__tmp_at595_19491 = _row_bytes_2__tmp_at595_19490 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at595_19490 / (double)32);
            if (_row_bytes_2__tmp_at595_19490 != MININT)
            _row_bytes_3__tmp_at595_19491 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at595_19491 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at595_19490, 32);
        _row_bytes_3__tmp_at595_19491 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_row_bytes_inlined_row_bytes_at_595_19488);
    if (IS_ATOM_INT(_row_bytes_3__tmp_at595_19491)) {
        if (_row_bytes_3__tmp_at595_19491 == (short)_row_bytes_3__tmp_at595_19491)
        _row_bytes_inlined_row_bytes_at_595_19488 = _row_bytes_3__tmp_at595_19491 * 4;
        else
        _row_bytes_inlined_row_bytes_at_595_19488 = NewDouble(_row_bytes_3__tmp_at595_19491 * (double)4);
    }
    else {
        _row_bytes_inlined_row_bytes_at_595_19488 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at595_19491)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at595_19489);
    _row_bytes_1__tmp_at595_19489 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at595_19490);
    _row_bytes_2__tmp_at595_19490 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at595_19491);
    _row_bytes_3__tmp_at595_19491 = NOVALUE;
    if (IS_ATOM_INT(_row_bytes_inlined_row_bytes_at_595_19488) && IS_ATOM_INT(_Height_19382)) {
        if (_row_bytes_inlined_row_bytes_at_595_19488 == (short)_row_bytes_inlined_row_bytes_at_595_19488 && _Height_19382 <= INT15 && _Height_19382 >= -INT15)
        _10782 = _row_bytes_inlined_row_bytes_at_595_19488 * _Height_19382;
        else
        _10782 = NewDouble(_row_bytes_inlined_row_bytes_at_595_19488 * (double)_Height_19382);
    }
    else {
        if (IS_ATOM_INT(_row_bytes_inlined_row_bytes_at_595_19488)) {
            _10782 = NewDouble((double)_row_bytes_inlined_row_bytes_at_595_19488 * DBL_PTR(_Height_19382)->dbl);
        }
        else {
            if (IS_ATOM_INT(_Height_19382)) {
                _10782 = NewDouble(DBL_PTR(_row_bytes_inlined_row_bytes_at_595_19488)->dbl * (double)_Height_19382);
            }
            else
            _10782 = NewDouble(DBL_PTR(_row_bytes_inlined_row_bytes_at_595_19488)->dbl * DBL_PTR(_Height_19382)->dbl);
        }
    }
    _0 = _Bits_19388;
    _Bits_19388 = _41get_c_block(_10782);
    DeRef(_0);
    _10782 = NOVALUE;

    /** 	close(fn)*/
    EClose(_41fn_19214);

    /** 	two_d_bits = unpack(Bits, BitCount, Width, Height)*/
    RefDS(_Bits_19388);
    Ref(_Width_19381);
    Ref(_Height_19382);
    _0 = _two_d_bits_19389;
    _two_d_bits_19389 = _41unpack(_Bits_19388, _BitCount_19380, _Width_19381, _Height_19382);
    DeRef(_0);

    /** 	if error_code then*/
    if (_41error_code_19215 == 0)
    {
        goto LB; // [650] 662
    }
    else{
    }

    /** 		return error_code */
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRef(_Palette_19387);
    DeRefDS(_Bits_19388);
    DeRefDS(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    DeRef(_10764);
    _10764 = NOVALUE;
    DeRef(_10777);
    _10777 = NOVALUE;
    DeRef(_10779);
    _10779 = NOVALUE;
    return _41error_code_19215;
LB: 

    /** 	return {Palette, two_d_bits}*/
    RefDS(_two_d_bits_19389);
    RefDS(_Palette_19387);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _Palette_19387;
    ((int *)_2)[2] = _two_d_bits_19389;
    _10785 = MAKE_SEQ(_1);
    DeRefDS(_file_name_19378);
    DeRef(_Width_19381);
    DeRef(_Height_19382);
    DeRef(_Compression_19383);
    DeRef(_OffBits_19384);
    DeRef(_SizeHeader_19385);
    DeRef(_NumColors_19386);
    DeRefDS(_Palette_19387);
    DeRef(_Bits_19388);
    DeRefDS(_two_d_bits_19389);
    DeRef(_10754);
    _10754 = NOVALUE;
    DeRef(_10755);
    _10755 = NOVALUE;
    DeRef(_10756);
    _10756 = NOVALUE;
    DeRef(_10764);
    _10764 = NOVALUE;
    DeRef(_10777);
    _10777 = NOVALUE;
    DeRef(_10779);
    _10779 = NOVALUE;
    return _10785;
    ;
}


void _41putBmpFileHeader(int _numColors_19550)
{
    int _offBytes_19551 = NOVALUE;
    int _row_bytes_3__tmp_at102_19570 = NOVALUE;
    int _row_bytes_2__tmp_at102_19569 = NOVALUE;
    int _row_bytes_1__tmp_at102_19568 = NOVALUE;
    int _row_bytes_inlined_row_bytes_at_102_19567 = NOVALUE;
    int _10842 = NOVALUE;
    int _10841 = NOVALUE;
    int _10840 = NOVALUE;
    int _10839 = NOVALUE;
    int _10838 = NOVALUE;
    int _10837 = NOVALUE;
    int _10836 = NOVALUE;
    int _10835 = NOVALUE;
    int _10834 = NOVALUE;
    int _10833 = NOVALUE;
    int _10832 = NOVALUE;
    int _10831 = NOVALUE;
    int _10830 = NOVALUE;
    int _10829 = NOVALUE;
    int _10828 = NOVALUE;
    int _10827 = NOVALUE;
    int _10825 = NOVALUE;
    int _10824 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if numColors = 256 then*/
    if (_numColors_19550 != 256)
    goto L1; // [5] 17

    /** 		bitCount = 8            -- 8 bits per pixel*/
    _41bitCount_19520 = 8;
    goto L2; // [14] 74
L1: 

    /** 	elsif numColors = 16 then*/
    if (_numColors_19550 != 16)
    goto L3; // [19] 31

    /** 		bitCount = 4            -- 4 bits per pixel*/
    _41bitCount_19520 = 4;
    goto L2; // [28] 74
L3: 

    /** 	elsif numColors = 4 then*/
    if (_numColors_19550 != 4)
    goto L4; // [33] 45

    /** 		bitCount = 2            -- 2 bits per pixel */
    _41bitCount_19520 = 2;
    goto L2; // [42] 74
L4: 

    /** 	elsif numColors = 2 then*/
    if (_numColors_19550 != 2)
    goto L5; // [47] 59

    /** 		bitCount = 1            -- 1 bit per pixel*/
    _41bitCount_19520 = 1;
    goto L2; // [56] 74
L5: 

    /** 		error_code = BMP_INVALID_MODE*/
    _41error_code_19215 = 5;

    /** 		return*/
    return;
L2: 

    /** 	puts(fn, "BM")  -- file-type field in the file header*/
    EPuts(_41fn_19214, _10823); // DJP 

    /** 	offBytes = 4 * numColors + BMPFILEHDRSIZE + NEWHDRSIZE*/
    if (_numColors_19550 <= INT15 && _numColors_19550 >= -INT15)
    _10824 = 4 * _numColors_19550;
    else
    _10824 = NewDouble(4 * (double)_numColors_19550);
    if (IS_ATOM_INT(_10824)) {
        _10825 = _10824 + 14;
        if ((long)((unsigned long)_10825 + (unsigned long)HIGH_BITS) >= 0) 
        _10825 = NewDouble((double)_10825);
    }
    else {
        _10825 = NewDouble(DBL_PTR(_10824)->dbl + (double)14);
    }
    DeRef(_10824);
    _10824 = NOVALUE;
    if (IS_ATOM_INT(_10825)) {
        _offBytes_19551 = _10825 + 40;
    }
    else {
        _offBytes_19551 = NewDouble(DBL_PTR(_10825)->dbl + (double)40);
    }
    DeRef(_10825);
    _10825 = NOVALUE;
    if (!IS_ATOM_INT(_offBytes_19551)) {
        _1 = (long)(DBL_PTR(_offBytes_19551)->dbl);
        DeRefDS(_offBytes_19551);
        _offBytes_19551 = _1;
    }

    /** 	numRowBytes = row_bytes(bitCount, numXPixels)*/

    /** 	return floor(((BitCount * Width) + 31) / 32) * 4*/
    DeRef(_row_bytes_1__tmp_at102_19568);
    if (_41numXPixels_19518 <= INT15)
    _row_bytes_1__tmp_at102_19568 = _41bitCount_19520 * _41numXPixels_19518;
    else
    _row_bytes_1__tmp_at102_19568 = NewDouble(_41bitCount_19520 * (double)_41numXPixels_19518);
    DeRef(_row_bytes_2__tmp_at102_19569);
    if (IS_ATOM_INT(_row_bytes_1__tmp_at102_19568)) {
        _row_bytes_2__tmp_at102_19569 = _row_bytes_1__tmp_at102_19568 + 31;
        if ((long)((unsigned long)_row_bytes_2__tmp_at102_19569 + (unsigned long)HIGH_BITS) >= 0) 
        _row_bytes_2__tmp_at102_19569 = NewDouble((double)_row_bytes_2__tmp_at102_19569);
    }
    else {
        _row_bytes_2__tmp_at102_19569 = NewDouble(DBL_PTR(_row_bytes_1__tmp_at102_19568)->dbl + (double)31);
    }
    DeRef(_row_bytes_3__tmp_at102_19570);
    if (IS_ATOM_INT(_row_bytes_2__tmp_at102_19569)) {
        if (32 > 0 && _row_bytes_2__tmp_at102_19569 >= 0) {
            _row_bytes_3__tmp_at102_19570 = _row_bytes_2__tmp_at102_19569 / 32;
        }
        else {
            temp_dbl = floor((double)_row_bytes_2__tmp_at102_19569 / (double)32);
            if (_row_bytes_2__tmp_at102_19569 != MININT)
            _row_bytes_3__tmp_at102_19570 = (long)temp_dbl;
            else
            _row_bytes_3__tmp_at102_19570 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _row_bytes_2__tmp_at102_19569, 32);
        _row_bytes_3__tmp_at102_19570 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_row_bytes_3__tmp_at102_19570)) {
        _41numRowBytes_19521 = _row_bytes_3__tmp_at102_19570 * 4;
    }
    else {
        _41numRowBytes_19521 = NewDouble(DBL_PTR(_row_bytes_3__tmp_at102_19570)->dbl * (double)4);
    }
    DeRef(_row_bytes_1__tmp_at102_19568);
    _row_bytes_1__tmp_at102_19568 = NOVALUE;
    DeRef(_row_bytes_2__tmp_at102_19569);
    _row_bytes_2__tmp_at102_19569 = NOVALUE;
    DeRef(_row_bytes_3__tmp_at102_19570);
    _row_bytes_3__tmp_at102_19570 = NOVALUE;

    /** 	puts(fn, int_to_bytes(offBytes + numRowBytes * numYPixels))*/
    if (_41numRowBytes_19521 == (short)_41numRowBytes_19521 && _41numYPixels_19519 <= INT15)
    _10827 = _41numRowBytes_19521 * _41numYPixels_19519;
    else
    _10827 = NewDouble(_41numRowBytes_19521 * (double)_41numYPixels_19519);
    if (IS_ATOM_INT(_10827)) {
        _10828 = _offBytes_19551 + _10827;
        if ((long)((unsigned long)_10828 + (unsigned long)HIGH_BITS) >= 0) 
        _10828 = NewDouble((double)_10828);
    }
    else {
        _10828 = NewDouble((double)_offBytes_19551 + DBL_PTR(_10827)->dbl);
    }
    DeRef(_10827);
    _10827 = NOVALUE;
    _10829 = _8int_to_bytes(_10828);
    _10828 = NOVALUE;
    EPuts(_41fn_19214, _10829); // DJP 
    DeRef(_10829);
    _10829 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})              -- reserved fields, must be 0*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10830 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10830); // DJP 
    DeRefDS(_10830);
    _10830 = NOVALUE;

    /** 	puts(fn, int_to_bytes(offBytes))    -- offBytes is the offset to the start*/
    _10831 = _8int_to_bytes(_offBytes_19551);
    EPuts(_41fn_19214, _10831); // DJP 
    DeRef(_10831);
    _10831 = NOVALUE;

    /** 	puts(fn, int_to_bytes(NEWHDRSIZE))  -- size of the secondary header*/
    _10832 = _8int_to_bytes(40);
    EPuts(_41fn_19214, _10832); // DJP 
    DeRef(_10832);
    _10832 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numXPixels))  -- width of the bitmap in pixels*/
    _10833 = _8int_to_bytes(_41numXPixels_19518);
    EPuts(_41fn_19214, _10833); // DJP 
    DeRef(_10833);
    _10833 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numYPixels))  -- height of the bitmap in pixels*/
    _10834 = _8int_to_bytes(_41numYPixels_19519);
    EPuts(_41fn_19214, _10834); // DJP 
    DeRef(_10834);
    _10834 = NOVALUE;

    /** 	puts(fn, {1, 0})                    -- planes, must be a word of value 1*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _10835 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10835); // DJP 
    DeRefDS(_10835);
    _10835 = NOVALUE;

    /** 	puts(fn, {bitCount, 0})     -- bitCount*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _41bitCount_19520;
    ((int *)_2)[2] = 0;
    _10836 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10836); // DJP 
    DeRefDS(_10836);
    _10836 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- compression scheme*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10837 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10837); // DJP 
    DeRefDS(_10837);
    _10837 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- size image, not required*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10838 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10838); // DJP 
    DeRefDS(_10838);
    _10838 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- XPelsPerMeter, not required */
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10839 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10839); // DJP 
    DeRefDS(_10839);
    _10839 = NOVALUE;

    /** 	puts(fn, {0, 0, 0, 0})      -- YPelsPerMeter, not required*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _10840 = MAKE_SEQ(_1);
    EPuts(_41fn_19214, _10840); // DJP 
    DeRefDS(_10840);
    _10840 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numColors))   -- num colors used in the image*/
    _10841 = _8int_to_bytes(_numColors_19550);
    EPuts(_41fn_19214, _10841); // DJP 
    DeRef(_10841);
    _10841 = NOVALUE;

    /** 	puts(fn, int_to_bytes(numColors))   -- num important colors in the image*/
    _10842 = _8int_to_bytes(_numColors_19550);
    EPuts(_41fn_19214, _10842); // DJP 
    DeRef(_10842);
    _10842 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _41putOneRowImage(int _x_19596, int _numPixelsPerByte_19597, int _shift_19598)
{
    int _j_19599 = NOVALUE;
    int _byte_19600 = NOVALUE;
    int _numBytesFilled_19601 = NOVALUE;
    int _10854 = NOVALUE;
    int _10850 = NOVALUE;
    int _10849 = NOVALUE;
    int _10848 = NOVALUE;
    int _10847 = NOVALUE;
    int _10843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	x &= repeat(0, 7)   -- 7 zeros is safe enough*/
    _10843 = Repeat(0, 7);
    Concat((object_ptr)&_x_19596, _x_19596, _10843);
    DeRefDS(_10843);
    _10843 = NOVALUE;

    /** 	numBytesFilled = 0*/
    _numBytesFilled_19601 = 0;

    /** 	j = 1*/
    _j_19599 = 1;

    /** 	while j <= numXPixels do*/
L1: 
    if (_j_19599 > _41numXPixels_19518)
    goto L2; // [34] 108

    /** 		byte = x[j]*/
    _2 = (int)SEQ_PTR(_x_19596);
    _byte_19600 = (int)*(((s1_ptr)_2)->base + _j_19599);
    if (!IS_ATOM_INT(_byte_19600))
    _byte_19600 = (long)DBL_PTR(_byte_19600)->dbl;

    /** 		for k = 1 to numPixelsPerByte - 1 do*/
    _10847 = _numPixelsPerByte_19597 - 1;
    if ((long)((unsigned long)_10847 +(unsigned long) HIGH_BITS) >= 0){
        _10847 = NewDouble((double)_10847);
    }
    {
        int _k_19608;
        _k_19608 = 1;
L3: 
        if (binary_op_a(GREATER, _k_19608, _10847)){
            goto L4; // [50] 84
        }

        /** 			byte = byte * shift + x[j + k]*/
        if (_byte_19600 == (short)_byte_19600 && _shift_19598 <= INT15 && _shift_19598 >= -INT15)
        _10848 = _byte_19600 * _shift_19598;
        else
        _10848 = NewDouble(_byte_19600 * (double)_shift_19598);
        if (IS_ATOM_INT(_k_19608)) {
            _10849 = _j_19599 + _k_19608;
        }
        else {
            _10849 = NewDouble((double)_j_19599 + DBL_PTR(_k_19608)->dbl);
        }
        _2 = (int)SEQ_PTR(_x_19596);
        if (!IS_ATOM_INT(_10849)){
            _10850 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10849)->dbl));
        }
        else{
            _10850 = (int)*(((s1_ptr)_2)->base + _10849);
        }
        if (IS_ATOM_INT(_10848) && IS_ATOM_INT(_10850)) {
            _byte_19600 = _10848 + _10850;
        }
        else {
            _byte_19600 = binary_op(PLUS, _10848, _10850);
        }
        DeRef(_10848);
        _10848 = NOVALUE;
        _10850 = NOVALUE;
        if (!IS_ATOM_INT(_byte_19600)) {
            _1 = (long)(DBL_PTR(_byte_19600)->dbl);
            DeRefDS(_byte_19600);
            _byte_19600 = _1;
        }

        /** 		end for*/
        _0 = _k_19608;
        if (IS_ATOM_INT(_k_19608)) {
            _k_19608 = _k_19608 + 1;
            if ((long)((unsigned long)_k_19608 +(unsigned long) HIGH_BITS) >= 0){
                _k_19608 = NewDouble((double)_k_19608);
            }
        }
        else {
            _k_19608 = binary_op_a(PLUS, _k_19608, 1);
        }
        DeRef(_0);
        goto L3; // [79] 57
L4: 
        ;
        DeRef(_k_19608);
    }

    /** 		puts(fn, byte)*/
    EPuts(_41fn_19214, _byte_19600); // DJP 

    /** 		numBytesFilled += 1*/
    _numBytesFilled_19601 = _numBytesFilled_19601 + 1;

    /** 		j += numPixelsPerByte*/
    _j_19599 = _j_19599 + _numPixelsPerByte_19597;

    /** 	end while*/
    goto L1; // [105] 32
L2: 

    /** 	for m = 1 to numRowBytes - numBytesFilled do*/
    _10854 = _41numRowBytes_19521 - _numBytesFilled_19601;
    if ((long)((unsigned long)_10854 +(unsigned long) HIGH_BITS) >= 0){
        _10854 = NewDouble((double)_10854);
    }
    {
        int _m_19617;
        _m_19617 = 1;
L5: 
        if (binary_op_a(GREATER, _m_19617, _10854)){
            goto L6; // [116] 137
        }

        /** 		puts(fn, 0)*/
        EPuts(_41fn_19214, 0); // DJP 

        /** 	end for*/
        _0 = _m_19617;
        if (IS_ATOM_INT(_m_19617)) {
            _m_19617 = _m_19617 + 1;
            if ((long)((unsigned long)_m_19617 +(unsigned long) HIGH_BITS) >= 0){
                _m_19617 = NewDouble((double)_m_19617);
            }
        }
        else {
            _m_19617 = binary_op_a(PLUS, _m_19617, 1);
        }
        DeRef(_0);
        goto L5; // [132] 123
L6: 
        ;
        DeRef(_m_19617);
    }

    /** end procedure*/
    DeRefDS(_x_19596);
    DeRef(_10847);
    _10847 = NOVALUE;
    DeRef(_10854);
    _10854 = NOVALUE;
    DeRef(_10849);
    _10849 = NOVALUE;
    return;
    ;
}


void _41putColorTable(int _numColors_19621, int _pal_19622)
{
    int _10861 = NOVALUE;
    int _10860 = NOVALUE;
    int _10859 = NOVALUE;
    int _10858 = NOVALUE;
    int _10857 = NOVALUE;
    int _10856 = NOVALUE;
    int _10855 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to numColors do*/
    _10855 = _numColors_19621;
    {
        int _i_19624;
        _i_19624 = 1;
L1: 
        if (_i_19624 > _10855){
            goto L2; // [10] 76
        }

        /** 		puts(fn, pal[i][3])     -- blue first in .BMP file*/
        _2 = (int)SEQ_PTR(_pal_19622);
        _10856 = (int)*(((s1_ptr)_2)->base + _i_19624);
        _2 = (int)SEQ_PTR(_10856);
        _10857 = (int)*(((s1_ptr)_2)->base + 3);
        _10856 = NOVALUE;
        EPuts(_41fn_19214, _10857); // DJP 
        _10857 = NOVALUE;

        /** 		puts(fn, pal[i][2])     -- green second*/
        _2 = (int)SEQ_PTR(_pal_19622);
        _10858 = (int)*(((s1_ptr)_2)->base + _i_19624);
        _2 = (int)SEQ_PTR(_10858);
        _10859 = (int)*(((s1_ptr)_2)->base + 2);
        _10858 = NOVALUE;
        EPuts(_41fn_19214, _10859); // DJP 
        _10859 = NOVALUE;

        /** 		puts(fn, pal[i][1])     -- red third*/
        _2 = (int)SEQ_PTR(_pal_19622);
        _10860 = (int)*(((s1_ptr)_2)->base + _i_19624);
        _2 = (int)SEQ_PTR(_10860);
        _10861 = (int)*(((s1_ptr)_2)->base + 1);
        _10860 = NOVALUE;
        EPuts(_41fn_19214, _10861); // DJP 
        _10861 = NOVALUE;

        /** 		puts(fn, 0)             -- reserved, must be 0*/
        EPuts(_41fn_19214, 0); // DJP 

        /** 	end for*/
        _i_19624 = _i_19624 + 1;
        goto L1; // [71] 17
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_pal_19622);
    return;
    ;
}


void _41putImage1(int _image_19634)
{
    int _x_19635 = NOVALUE;
    int _numPixelsPerByte_19636 = NOVALUE;
    int _shift_19637 = NOVALUE;
    int _10866 = NOVALUE;
    int _10865 = NOVALUE;
    int _0, _1, _2;
    

    /** 	numPixelsPerByte = 8 / bitCount*/
    _numPixelsPerByte_19636 = (8 % _41bitCount_19520) ? NewDouble((double)8 / _41bitCount_19520) : (8 / _41bitCount_19520);
    if (!IS_ATOM_INT(_numPixelsPerByte_19636)) {
        _1 = (long)(DBL_PTR(_numPixelsPerByte_19636)->dbl);
        DeRefDS(_numPixelsPerByte_19636);
        _numPixelsPerByte_19636 = _1;
    }

    /** 	shift = power(2, bitCount)*/
    _shift_19637 = power(2, _41bitCount_19520);

    /** 	for i = numYPixels to 1 by -1 do*/
    {
        int _i_19641;
        _i_19641 = _41numYPixels_19519;
L1: 
        if (_i_19641 < 1){
            goto L2; // [27] 106
        }

        /** 		x = image[i]*/
        DeRef(_x_19635);
        _2 = (int)SEQ_PTR(_image_19634);
        _x_19635 = (int)*(((s1_ptr)_2)->base + _i_19641);
        Ref(_x_19635);

        /** 		if atom(x) then*/
        _10865 = IS_ATOM(_x_19635);
        if (_10865 == 0)
        {
            _10865 = NOVALUE;
            goto L3; // [45] 65
        }
        else{
            _10865 = NOVALUE;
        }

        /** 			error_code = BMP_INVALID_MODE*/
        _41error_code_19215 = 5;

        /** 			return*/
        DeRefDS(_image_19634);
        DeRef(_x_19635);
        return;
        goto L4; // [62] 92
L3: 

        /** 		elsif length(x) != numXPixels then*/
        if (IS_SEQUENCE(_x_19635)){
                _10866 = SEQ_PTR(_x_19635)->length;
        }
        else {
            _10866 = 1;
        }
        if (_10866 == _41numXPixels_19518)
        goto L5; // [72] 91

        /** 			error_code = BMP_INVALID_MODE*/
        _41error_code_19215 = 5;

        /** 			return*/
        DeRefDS(_image_19634);
        DeRef(_x_19635);
        return;
L5: 
L4: 

        /** 		putOneRowImage(x, numPixelsPerByte, shift) */
        Ref(_x_19635);
        _41putOneRowImage(_x_19635, _numPixelsPerByte_19636, _shift_19637);

        /** 	end for*/
        _i_19641 = _i_19641 + -1;
        goto L1; // [101] 34
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_image_19634);
    DeRef(_x_19635);
    return;
    ;
}


int  __stdcall _41save_bitmap(int _palette_n_image_19652, int _file_name_19653)
{
    int _color_19654 = NOVALUE;
    int _image_19655 = NOVALUE;
    int _numColors_19656 = NOVALUE;
    int _10873 = NOVALUE;
    int _0, _1, _2;
    

    /** 	error_code = BMP_SUCCESS*/
    _41error_code_19215 = 1;

    /** 	fn = open(file_name, "wb")*/
    _41fn_19214 = EOpen(_file_name_19653, _1354, 0);

    /** 	if fn = -1 then*/
    if (_41fn_19214 != -1)
    goto L1; // [25] 38

    /** 		return BMP_OPEN_FAILED*/
    DeRefDS(_palette_n_image_19652);
    DeRefDS(_file_name_19653);
    DeRef(_color_19654);
    DeRef(_image_19655);
    return 2;
L1: 

    /** 	color = palette_n_image[1]*/
    DeRef(_color_19654);
    _2 = (int)SEQ_PTR(_palette_n_image_19652);
    _color_19654 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_color_19654);

    /** 	image = palette_n_image[2]*/
    DeRef(_image_19655);
    _2 = (int)SEQ_PTR(_palette_n_image_19652);
    _image_19655 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_image_19655);

    /** 	numYPixels = length(image)*/
    if (IS_SEQUENCE(_image_19655)){
            _41numYPixels_19519 = SEQ_PTR(_image_19655)->length;
    }
    else {
        _41numYPixels_19519 = 1;
    }

    /** 	numXPixels = length(image[1])   -- assume the same length with each row*/
    _2 = (int)SEQ_PTR(_image_19655);
    _10873 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_10873)){
            _41numXPixels_19518 = SEQ_PTR(_10873)->length;
    }
    else {
        _41numXPixels_19518 = 1;
    }
    _10873 = NOVALUE;

    /** 	numColors = length(color)*/
    if (IS_SEQUENCE(_color_19654)){
            _numColors_19656 = SEQ_PTR(_color_19654)->length;
    }
    else {
        _numColors_19656 = 1;
    }

    /** 	putBmpFileHeader(numColors)*/
    _41putBmpFileHeader(_numColors_19656);

    /** 	if error_code = BMP_SUCCESS then*/
    if (_41error_code_19215 != 1)
    goto L2; // [84] 100

    /** 		putColorTable(numColors, color)*/
    RefDS(_color_19654);
    _41putColorTable(_numColors_19656, _color_19654);

    /** 		putImage1(image)*/
    RefDS(_image_19655);
    _41putImage1(_image_19655);
L2: 

    /** 	close(fn)*/
    EClose(_41fn_19214);

    /** 	return error_code*/
    DeRefDS(_palette_n_image_19652);
    DeRefDS(_file_name_19653);
    DeRef(_color_19654);
    DeRef(_image_19655);
    _10873 = NOVALUE;
    return _41error_code_19215;
    ;
}



// 0x76CE8972
