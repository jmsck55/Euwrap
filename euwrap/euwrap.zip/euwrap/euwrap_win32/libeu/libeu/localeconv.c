// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _44canonical(int _new_locale_20350)
{
    int _w_20351 = NOVALUE;
    int _ws_20352 = NOVALUE;
    int _p_20353 = NOVALUE;
    int _n_20354 = NOVALUE;
    int _11541 = NOVALUE;
    int _11531 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20354 = find_from(46, _new_locale_20350, 1);

    /** 		if n then*/
    if (_n_20354 == 0)
    {
        goto L1; // [14] 28
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20350)){
            _11531 = SEQ_PTR(_new_locale_20350)->length;
    }
    else {
        _11531 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20350);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20354)) ? _n_20354 : (long)(DBL_PTR(_n_20354)->dbl);
        int stop = (IS_ATOM_INT(_11531)) ? _11531 : (long)(DBL_PTR(_11531)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20350), start, &_new_locale_20350 );
            }
            else Tail(SEQ_PTR(_new_locale_20350), stop+1, &_new_locale_20350);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20350), start, &_new_locale_20350);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20350 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20350)->ref == 1));
        }
    }
    _11531 = NOVALUE;
L1: 

    /** 	p = find(new_locale, posix_names)*/
    _p_20353 = find_from(_new_locale_20350, _44posix_names_20343, 1);

    /** 	w = find(new_locale, w32_names)*/
    _w_20351 = find_from(_new_locale_20350, _44w32_names_20112, 1);

    /** 	ws = find(new_locale, w32_name_canonical)*/
    _ws_20352 = find_from(_new_locale_20350, _44w32_name_canonical_20322, 1);

    /** 	if p != 0 then*/
    if (_p_20353 == 0)
    goto L2; // [57] 69

    /** 		n = p*/
    _n_20354 = _p_20353;
    goto L3; // [66] 104
L2: 

    /** 	elsif w != 0 then*/
    if (_w_20351 == 0)
    goto L4; // [71] 83

    /** 		n = w*/
    _n_20354 = _w_20351;
    goto L3; // [80] 104
L4: 

    /** 	elsif ws != 0 then*/
    if (_ws_20352 == 0)
    goto L5; // [85] 97

    /** 		n = ws*/
    _n_20354 = _ws_20352;
    goto L3; // [94] 104
L5: 

    /** 		return new_locale*/
    return _new_locale_20350;
L3: 

    /** 	new_locale = locale_canonical[n]*/
    DeRefDS(_new_locale_20350);
    _2 = (int)SEQ_PTR(_44locale_canonical_20346);
    _new_locale_20350 = (int)*(((s1_ptr)_2)->base + _n_20354);
    RefDS(_new_locale_20350);

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20354 = find_from(46, _new_locale_20350, 1);

    /** 		if n then*/
    if (_n_20354 == 0)
    {
        goto L6; // [127] 141
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20350)){
            _11541 = SEQ_PTR(_new_locale_20350)->length;
    }
    else {
        _11541 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20350);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20354)) ? _n_20354 : (long)(DBL_PTR(_n_20354)->dbl);
        int stop = (IS_ATOM_INT(_11541)) ? _11541 : (long)(DBL_PTR(_11541)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20350), start, &_new_locale_20350 );
            }
            else Tail(SEQ_PTR(_new_locale_20350), stop+1, &_new_locale_20350);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20350), start, &_new_locale_20350);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20350 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20350)->ref == 1));
        }
    }
    _11541 = NOVALUE;
L6: 

    /** 	return new_locale*/
    return _new_locale_20350;
    ;
}


int  __stdcall _44decanonical(int _new_locale_20376)
{
    int _w_20377 = NOVALUE;
    int _ws_20378 = NOVALUE;
    int _p_20379 = NOVALUE;
    int _n_20380 = NOVALUE;
    int _11554 = NOVALUE;
    int _11544 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20380 = find_from(46, _new_locale_20376, 1);

    /** 		if n then*/
    if (_n_20380 == 0)
    {
        goto L1; // [14] 28
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20376)){
            _11544 = SEQ_PTR(_new_locale_20376)->length;
    }
    else {
        _11544 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20376);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20380)) ? _n_20380 : (long)(DBL_PTR(_n_20380)->dbl);
        int stop = (IS_ATOM_INT(_11544)) ? _11544 : (long)(DBL_PTR(_11544)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20376), start, &_new_locale_20376 );
            }
            else Tail(SEQ_PTR(_new_locale_20376), stop+1, &_new_locale_20376);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20376), start, &_new_locale_20376);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20376 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20376)->ref == 1));
        }
    }
    _11544 = NOVALUE;
L1: 

    /** 	p = find(new_locale, posix_names)*/
    _p_20379 = find_from(_new_locale_20376, _44posix_names_20343, 1);

    /** 	w = find(new_locale, w32_names)*/
    _w_20377 = find_from(_new_locale_20376, _44w32_names_20112, 1);

    /** 	ws = find(new_locale, w32_name_canonical)*/
    _ws_20378 = find_from(_new_locale_20376, _44w32_name_canonical_20322, 1);

    /** 	if p != 0 then*/
    if (_p_20379 == 0)
    goto L2; // [57] 69

    /** 		n = p*/
    _n_20380 = _p_20379;
    goto L3; // [66] 104
L2: 

    /** 	elsif w != 0 then*/
    if (_w_20377 == 0)
    goto L4; // [71] 83

    /** 		n = w*/
    _n_20380 = _w_20377;
    goto L3; // [80] 104
L4: 

    /** 	elsif ws != 0 then*/
    if (_ws_20378 == 0)
    goto L5; // [85] 97

    /** 		n = ws*/
    _n_20380 = _ws_20378;
    goto L3; // [94] 104
L5: 

    /** 		return new_locale*/
    return _new_locale_20376;
L3: 

    /** 	new_locale = platform_locale[n]*/
    DeRefDS(_new_locale_20376);
    _2 = (int)SEQ_PTR(_44platform_locale_20347);
    _new_locale_20376 = (int)*(((s1_ptr)_2)->base + _n_20380);
    RefDS(_new_locale_20376);

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20380 = find_from(46, _new_locale_20376, 1);

    /** 		if n then*/
    if (_n_20380 == 0)
    {
        goto L6; // [127] 141
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20376)){
            _11554 = SEQ_PTR(_new_locale_20376)->length;
    }
    else {
        _11554 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20376);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20380)) ? _n_20380 : (long)(DBL_PTR(_n_20380)->dbl);
        int stop = (IS_ATOM_INT(_11554)) ? _11554 : (long)(DBL_PTR(_11554)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20376), start, &_new_locale_20376 );
            }
            else Tail(SEQ_PTR(_new_locale_20376), stop+1, &_new_locale_20376);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20376), start, &_new_locale_20376);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20376 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20376)->ref == 1));
        }
    }
    _11554 = NOVALUE;
L6: 

    /** 	return new_locale*/
    return _new_locale_20376;
    ;
}


int  __stdcall _44canon2win(int _new_locale_20402)
{
    int _w_20403 = NOVALUE;
    int _n_20404 = NOVALUE;
    int _11563 = NOVALUE;
    int _11557 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20404 = find_from(46, _new_locale_20402, 1);

    /** 		if n then*/
    if (_n_20404 == 0)
    {
        goto L1; // [14] 28
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20402)){
            _11557 = SEQ_PTR(_new_locale_20402)->length;
    }
    else {
        _11557 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20402);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20404)) ? _n_20404 : (long)(DBL_PTR(_n_20404)->dbl);
        int stop = (IS_ATOM_INT(_11557)) ? _11557 : (long)(DBL_PTR(_11557)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20402), start, &_new_locale_20402 );
            }
            else Tail(SEQ_PTR(_new_locale_20402), stop+1, &_new_locale_20402);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20402), start, &_new_locale_20402);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20402 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20402)->ref == 1));
        }
    }
    _11557 = NOVALUE;
L1: 

    /** 	w = find(new_locale, posix_names)*/
    _w_20403 = find_from(_new_locale_20402, _44posix_names_20343, 1);

    /** 	if w = 0 then*/
    if (_w_20403 != 0)
    goto L2; // [39] 50

    /** 		return "C"*/
    RefDS(_11291);
    DeRefDS(_new_locale_20402);
    return _11291;
L2: 

    /** 	new_locale = w32_names[w]*/
    DeRefDS(_new_locale_20402);
    _2 = (int)SEQ_PTR(_44w32_names_20112);
    _new_locale_20402 = (int)*(((s1_ptr)_2)->base + _w_20403);
    RefDS(_new_locale_20402);

    /** 	ifdef WINDOWS then*/

    /** 		n = find('.', new_locale) */
    _n_20404 = find_from(46, _new_locale_20402, 1);

    /** 		if n then*/
    if (_n_20404 == 0)
    {
        goto L3; // [71] 85
    }
    else{
    }

    /** 			new_locale = remove(new_locale, n, length(new_locale))*/
    if (IS_SEQUENCE(_new_locale_20402)){
            _11563 = SEQ_PTR(_new_locale_20402)->length;
    }
    else {
        _11563 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_new_locale_20402);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_n_20404)) ? _n_20404 : (long)(DBL_PTR(_n_20404)->dbl);
        int stop = (IS_ATOM_INT(_11563)) ? _11563 : (long)(DBL_PTR(_11563)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_new_locale_20402), start, &_new_locale_20402 );
            }
            else Tail(SEQ_PTR(_new_locale_20402), stop+1, &_new_locale_20402);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_new_locale_20402), start, &_new_locale_20402);
        }
        else {
            assign_slice_seq = &assign_space;
            _new_locale_20402 = Remove_elements(start, stop, (SEQ_PTR(_new_locale_20402)->ref == 1));
        }
    }
    _11563 = NOVALUE;
L3: 

    /** 	return new_locale*/
    return _new_locale_20402;
    ;
}



// 0xA9B298D3
