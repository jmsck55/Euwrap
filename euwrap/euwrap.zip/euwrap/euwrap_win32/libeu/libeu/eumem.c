// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int  __stdcall _28malloc(int _mem_struct_p_10938, int _cleanup_p_10939)
{
    int _temp__10940 = NOVALUE;
    int _6171 = NOVALUE;
    int _6169 = NOVALUE;
    int _6168 = NOVALUE;
    int _6167 = NOVALUE;
    int _6163 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_cleanup_p_10939)) {
        _1 = (long)(DBL_PTR(_cleanup_p_10939)->dbl);
        DeRefDS(_cleanup_p_10939);
        _cleanup_p_10939 = _1;
    }

    /** 	if atom(mem_struct_p) then*/
    _6163 = IS_ATOM(_mem_struct_p_10938);
    if (_6163 == 0)
    {
        _6163 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _6163 = NOVALUE;
    }

    /** 		mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_10938;
    _mem_struct_p_10938 = Repeat(0, _mem_struct_p_10938);
    DeRef(_0);
L1: 

    /** 	if ram_free_list = 0 then*/
    if (_28ram_free_list_10934 != 0)
    goto L2; // [22] 72

    /** 		ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_10938);
    Append(&_28ram_space_10933, _28ram_space_10933, _mem_struct_p_10938);

    /** 		if cleanup_p then*/
    if (_cleanup_p_10939 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** 			return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_28ram_space_10933)){
            _6167 = SEQ_PTR(_28ram_space_10933)->length;
    }
    else {
        _6167 = 1;
    }
    _6168 = NewDouble( (double) _6167 );
    _1 = (int) _00[_28free_rid_10935].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_28free_rid_10935].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _28free_rid_10935;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6168)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6168)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6168)) ){
        DeRefDS(_6168);
        _6168 = NewDouble( DBL_PTR(_6168)->dbl );
    }
    DBL_PTR(_6168)->cleanup = (cleanup_ptr)_1;
    _6167 = NOVALUE;
    DeRef(_mem_struct_p_10938);
    return _6168;
    goto L4; // [56] 71
L3: 

    /** 			return length(ram_space)*/
    if (IS_SEQUENCE(_28ram_space_10933)){
            _6169 = SEQ_PTR(_28ram_space_10933)->length;
    }
    else {
        _6169 = 1;
    }
    DeRef(_mem_struct_p_10938);
    DeRef(_6168);
    _6168 = NOVALUE;
    return _6169;
L4: 
L2: 

    /** 	temp_ = ram_free_list*/
    _temp__10940 = _28ram_free_list_10934;

    /** 	ram_free_list = ram_space[temp_]*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    _28ram_free_list_10934 = (int)*(((s1_ptr)_2)->base + _temp__10940);
    if (!IS_ATOM_INT(_28ram_free_list_10934))
    _28ram_free_list_10934 = (long)DBL_PTR(_28ram_free_list_10934)->dbl;

    /** 	ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_10938);
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp__10940);
    _1 = *(int *)_2;
    *(int *)_2 = _mem_struct_p_10938;
    DeRef(_1);

    /** 	if cleanup_p then*/
    if (_cleanup_p_10939 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** 		return delete_routine( temp_, free_rid )*/
    _6171 = NewDouble( (double) _temp__10940 );
    _1 = (int) _00[_28free_rid_10935].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_28free_rid_10935].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _28free_rid_10935;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6171)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6171)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6171)) ){
        DeRefDS(_6171);
        _6171 = NewDouble( DBL_PTR(_6171)->dbl );
    }
    DBL_PTR(_6171)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_10938);
    DeRef(_6168);
    _6168 = NOVALUE;
    return _6171;
    goto L6; // [112] 122
L5: 

    /** 		return temp_*/
    DeRef(_mem_struct_p_10938);
    DeRef(_6168);
    _6168 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    return _temp__10940;
L6: 
    ;
}


void  __stdcall _28free(int _mem_p_10958)
{
    int _6173 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10958, 1)){
        goto L1; // [3] 11
    }
    DeRef(_mem_p_10958);
    return;
L1: 

    /** 	if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_28ram_space_10933)){
            _6173 = SEQ_PTR(_28ram_space_10933)->length;
    }
    else {
        _6173 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10958, _6173)){
        _6173 = NOVALUE;
        goto L2; // [18] 26
    }
    _6173 = NOVALUE;
    DeRef(_mem_p_10958);
    return;
L2: 

    /** 	ram_space[mem_p] = ram_free_list*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10933 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_10958))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10958)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _mem_p_10958);
    _1 = *(int *)_2;
    *(int *)_2 = _28ram_free_list_10934;
    DeRef(_1);

    /** 	ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_10958))
    _28ram_free_list_10934 = e_floor(_mem_p_10958);
    else
    _28ram_free_list_10934 = unary_op(FLOOR, _mem_p_10958);
    if (!IS_ATOM_INT(_28ram_free_list_10934)) {
        _1 = (long)(DBL_PTR(_28ram_free_list_10934)->dbl);
        DeRefDS(_28ram_free_list_10934);
        _28ram_free_list_10934 = _1;
    }

    /** end procedure*/
    DeRef(_mem_p_10958);
    return;
    ;
}


int  __stdcall _28valid(int _mem_p_10968, int _mem_struct_p_10969)
{
    int _6187 = NOVALUE;
    int _6186 = NOVALUE;
    int _6184 = NOVALUE;
    int _6183 = NOVALUE;
    int _6182 = NOVALUE;
    int _6180 = NOVALUE;
    int _6177 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(mem_p) then return 0 end if*/
    if (IS_ATOM_INT(_mem_p_10968))
    _6177 = 1;
    else if (IS_ATOM_DBL(_mem_p_10968))
    _6177 = IS_ATOM_INT(DoubleToInt(_mem_p_10968));
    else
    _6177 = 0;
    if (_6177 != 0)
    goto L1; // [6] 14
    _6177 = NOVALUE;
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 0;
L1: 

    /** 	if mem_p < 1 then return 0 end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10968, 1)){
        goto L2; // [16] 25
    }
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 0;
L2: 

    /** 	if mem_p > length(ram_space) then return 0 end if*/
    if (IS_SEQUENCE(_28ram_space_10933)){
            _6180 = SEQ_PTR(_28ram_space_10933)->length;
    }
    else {
        _6180 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10968, _6180)){
        _6180 = NOVALUE;
        goto L3; // [32] 41
    }
    _6180 = NOVALUE;
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 0;
L3: 

    /** 	if sequence(mem_struct_p) then return 1 end if*/
    _6182 = IS_SEQUENCE(_mem_struct_p_10969);
    if (_6182 == 0)
    {
        _6182 = NOVALUE;
        goto L4; // [46] 54
    }
    else{
        _6182 = NOVALUE;
    }
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 1;
L4: 

    /** 	if atom(ram_space[mem_p]) then */
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_mem_p_10968)){
        _6183 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10968)->dbl));
    }
    else{
        _6183 = (int)*(((s1_ptr)_2)->base + _mem_p_10968);
    }
    _6184 = IS_ATOM(_6183);
    _6183 = NOVALUE;
    if (_6184 == 0)
    {
        _6184 = NOVALUE;
        goto L5; // [65] 88
    }
    else{
        _6184 = NOVALUE;
    }

    /** 		if mem_struct_p >= 0 then*/
    if (binary_op_a(LESS, _mem_struct_p_10969, 0)){
        goto L6; // [70] 81
    }

    /** 			return 0*/
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 0;
L6: 

    /** 		return 1*/
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    return 1;
L5: 

    /** 	if length(ram_space[mem_p]) != mem_struct_p then*/
    _2 = (int)SEQ_PTR(_28ram_space_10933);
    if (!IS_ATOM_INT(_mem_p_10968)){
        _6186 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10968)->dbl));
    }
    else{
        _6186 = (int)*(((s1_ptr)_2)->base + _mem_p_10968);
    }
    if (IS_SEQUENCE(_6186)){
            _6187 = SEQ_PTR(_6186)->length;
    }
    else {
        _6187 = 1;
    }
    _6186 = NOVALUE;
    if (binary_op_a(EQUALS, _6187, _mem_struct_p_10969)){
        _6187 = NOVALUE;
        goto L7; // [99] 110
    }
    _6187 = NOVALUE;

    /** 		return 0*/
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    _6186 = NOVALUE;
    return 0;
L7: 

    /** 	return 1*/
    DeRef(_mem_p_10968);
    DeRef(_mem_struct_p_10969);
    _6186 = NOVALUE;
    return 1;
    ;
}



// 0xEE88CE60
