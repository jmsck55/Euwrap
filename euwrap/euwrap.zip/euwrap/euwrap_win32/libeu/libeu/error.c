// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _10crash(int _fmt_1786, int _data_1787)
{
    int _msg_1788 = NOVALUE;
    int _0, _1, _2;
    

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_1788);
    _msg_1788 = EPrintf(-9999999, _fmt_1786, _data_1787);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_1788);

    /** end procedure*/
    DeRefDS(_fmt_1786);
    DeRef(_data_1787);
    DeRefDSi(_msg_1788);
    return;
    ;
}


void  __stdcall _10crash_message(int _msg_1792)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_1792);

    /** end procedure*/
    DeRefDS(_msg_1792);
    return;
    ;
}


void  __stdcall _10crash_file(int _file_path_1795)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_1795);

    /** end procedure*/
    DeRefDS(_file_path_1795);
    return;
    ;
}


void  __stdcall _10warning_file(int _file_path_1798)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_1798);

    /** end procedure*/
    DeRef(_file_path_1798);
    return;
    ;
}


void  __stdcall _10crash_routine(int _func_1801)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_func_1801)) {
        _1 = (long)(DBL_PTR(_func_1801)->dbl);
        DeRefDS(_func_1801);
        _func_1801 = _1;
    }

    /** 	machine_proc(M_CRASH_ROUTINE, func)*/
    machine(66, _func_1801);

    /** end procedure*/
    return;
    ;
}



// 0x6F928DEE
