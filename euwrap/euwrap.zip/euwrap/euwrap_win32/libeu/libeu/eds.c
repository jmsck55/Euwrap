// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _38fatal(int _errcode_16726, int _msg_16727, int _routine_name_16728, int _parms_16729)
{
    int _9511 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_16726;
    RefDS(_msg_16727);
    *((int *)(_2+8)) = _msg_16727;
    RefDS(_routine_name_16728);
    *((int *)(_2+12)) = _routine_name_16728;
    RefDS(_parms_16729);
    *((int *)(_2+16)) = _parms_16729;
    _9511 = MAKE_SEQ(_1);
    RefDS(_9511);
    Append(&_38vLastErrors_16723, _38vLastErrors_16723, _9511);
    DeRefDS(_9511);
    _9511 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_16727);
    DeRefDSi(_routine_name_16728);
    DeRefDS(_parms_16729);
    return;
    ;
}


int _38get4()
{
    int _9527 = NOVALUE;
    int _9526 = NOVALUE;
    int _9525 = NOVALUE;
    int _9524 = NOVALUE;
    int _9523 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9523 = getKBchar();
        }
        else
        _9523 = getc(last_r_file_ptr);
    }
    else
    _9523 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem0_16741)){
        poke_addr = (unsigned char *)_38mem0_16741;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke_addr = (unsigned char)_9523;
    _9523 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9524 = getKBchar();
        }
        else
        _9524 = getc(last_r_file_ptr);
    }
    else
    _9524 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem1_16742)){
        poke_addr = (unsigned char *)_38mem1_16742;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem1_16742)->dbl);
    }
    *poke_addr = (unsigned char)_9524;
    _9524 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9525 = getKBchar();
        }
        else
        _9525 = getc(last_r_file_ptr);
    }
    else
    _9525 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem2_16743)){
        poke_addr = (unsigned char *)_38mem2_16743;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem2_16743)->dbl);
    }
    *poke_addr = (unsigned char)_9525;
    _9525 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9526 = getKBchar();
        }
        else
        _9526 = getc(last_r_file_ptr);
    }
    else
    _9526 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_38mem3_16744)){
        poke_addr = (unsigned char *)_38mem3_16744;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38mem3_16744)->dbl);
    }
    *poke_addr = (unsigned char)_9526;
    _9526 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_38mem0_16741)) {
        _9527 = *(unsigned long *)_38mem0_16741;
        if ((unsigned)_9527 > (unsigned)MAXINT)
        _9527 = NewDouble((double)(unsigned long)_9527);
    }
    else {
        _9527 = *(unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        if ((unsigned)_9527 > (unsigned)MAXINT)
        _9527 = NewDouble((double)(unsigned long)_9527);
    }
    return _9527;
    ;
}


int _38get_string()
{
    int _where_inlined_where_at_31_16768 = NOVALUE;
    int _s_16758 = NOVALUE;
    int _c_16759 = NOVALUE;
    int _i_16760 = NOVALUE;
    int _9539 = NOVALUE;
    int _9536 = NOVALUE;
    int _9534 = NOVALUE;
    int _9532 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_16758);
    _s_16758 = Repeat(0, 256);

    /** 	i = 0*/
    _i_16760 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_16759 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_16759 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_16768);
    _where_inlined_where_at_31_16768 = machine(20, _38current_db_16699);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_16768);
    *((int *)(_2+4)) = _where_inlined_where_at_31_16768;
    _9532 = MAKE_SEQ(_1);
    RefDS(_9530);
    RefDS(_9531);
    _38fatal(900, _9530, _9531, _9532);
    _9532 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_16760 = _i_16760 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_16758)){
            _9534 = SEQ_PTR(_s_16758)->length;
    }
    else {
        _9534 = 1;
    }
    if (_i_16760 <= _9534)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9536 = Repeat(0, 256);
    Concat((object_ptr)&_s_16758, _s_16758, _9536);
    DeRefDS(_9536);
    _9536 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_16758);
    _2 = (int)(((s1_ptr)_2)->base + _i_16760);
    *(int *)_2 = _c_16759;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16759 = getKBchar();
        }
        else
        _c_16759 = getc(last_r_file_ptr);
    }
    else
    _c_16759 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9539;
    RHS_Slice(_s_16758, 1, _i_16760);
    DeRefDSi(_s_16758);
    return _9539;
    ;
}


int _38equal_string(int _target_16780)
{
    int _c_16781 = NOVALUE;
    int _i_16782 = NOVALUE;
    int _where_inlined_where_at_27_16788 = NOVALUE;
    int _9550 = NOVALUE;
    int _9549 = NOVALUE;
    int _9546 = NOVALUE;
    int _9544 = NOVALUE;
    int _9542 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_16782 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_16781 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_16781 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_16788);
    _where_inlined_where_at_27_16788 = machine(20, _38current_db_16699);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_16788);
    *((int *)(_2+4)) = _where_inlined_where_at_27_16788;
    _9542 = MAKE_SEQ(_1);
    RefDS(_9530);
    RefDS(_9541);
    _38fatal(900, _9530, _9541, _9542);
    _9542 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_16780);
    return -404;
L4: 

    /** 		i += 1*/
    _i_16782 = _i_16782 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_16780)){
            _9544 = SEQ_PTR(_target_16780)->length;
    }
    else {
        _9544 = 1;
    }
    if (_i_16782 <= _9544)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_16780);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_16780);
    _9546 = (int)*(((s1_ptr)_2)->base + _i_16782);
    if (binary_op_a(EQUALS, _9546, _c_16781)){
        _9546 = NOVALUE;
        goto L6; // [80] 91
    }
    _9546 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_16780);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16781 = getKBchar();
        }
        else
        _c_16781 = getc(last_r_file_ptr);
    }
    else
    _c_16781 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_16780)){
            _9549 = SEQ_PTR(_target_16780)->length;
    }
    else {
        _9549 = 1;
    }
    _9550 = (_i_16782 == _9549);
    _9549 = NOVALUE;
    DeRefDS(_target_16780);
    return _9550;
    ;
}


int _38decompress(int _c_16826)
{
    int _s_16827 = NOVALUE;
    int _len_16828 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_16863 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_16862 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_16876 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_16875 = NOVALUE;
    int _9605 = NOVALUE;
    int _9604 = NOVALUE;
    int _9603 = NOVALUE;
    int _9600 = NOVALUE;
    int _9595 = NOVALUE;
    int _9594 = NOVALUE;
    int _9593 = NOVALUE;
    int _9592 = NOVALUE;
    int _9591 = NOVALUE;
    int _9590 = NOVALUE;
    int _9589 = NOVALUE;
    int _9588 = NOVALUE;
    int _9587 = NOVALUE;
    int _9586 = NOVALUE;
    int _9585 = NOVALUE;
    int _9584 = NOVALUE;
    int _9583 = NOVALUE;
    int _9582 = NOVALUE;
    int _9581 = NOVALUE;
    int _9580 = NOVALUE;
    int _9579 = NOVALUE;
    int _9578 = NOVALUE;
    int _9577 = NOVALUE;
    int _9576 = NOVALUE;
    int _9575 = NOVALUE;
    int _9574 = NOVALUE;
    int _9573 = NOVALUE;
    int _9572 = NOVALUE;
    int _9571 = NOVALUE;
    int _9570 = NOVALUE;
    int _9569 = NOVALUE;
    int _9568 = NOVALUE;
    int _9567 = NOVALUE;
    int _9564 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_16826 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16826 = getKBchar();
        }
        else
        _c_16826 = getc(last_r_file_ptr);
    }
    else
    _c_16826 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_16826 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9564 = _c_16826 + -9;
    DeRef(_s_16827);
    return _9564;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_16826;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9567 = getKBchar();
            }
            else
            _9567 = getc(last_r_file_ptr);
        }
        else
        _9567 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9568 = getKBchar();
            }
            else
            _9568 = getc(last_r_file_ptr);
        }
        else
        _9568 = getc(last_r_file_ptr);
        _9569 = 256 * _9568;
        _9568 = NOVALUE;
        _9570 = _9567 + _9569;
        _9567 = NOVALUE;
        _9569 = NOVALUE;
        _9571 = _9570 + _38MIN2B_16809;
        if ((long)((unsigned long)_9571 + (unsigned long)HIGH_BITS) >= 0) 
        _9571 = NewDouble((double)_9571);
        _9570 = NOVALUE;
        DeRef(_s_16827);
        DeRef(_9564);
        _9564 = NOVALUE;
        return _9571;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9572 = getKBchar();
            }
            else
            _9572 = getc(last_r_file_ptr);
        }
        else
        _9572 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9573 = getKBchar();
            }
            else
            _9573 = getc(last_r_file_ptr);
        }
        else
        _9573 = getc(last_r_file_ptr);
        _9574 = 256 * _9573;
        _9573 = NOVALUE;
        _9575 = _9572 + _9574;
        _9572 = NOVALUE;
        _9574 = NOVALUE;
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9576 = getKBchar();
            }
            else
            _9576 = getc(last_r_file_ptr);
        }
        else
        _9576 = getc(last_r_file_ptr);
        _9577 = 65536 * _9576;
        _9576 = NOVALUE;
        _9578 = _9575 + _9577;
        _9575 = NOVALUE;
        _9577 = NOVALUE;
        _9579 = _9578 + _38MIN3B_16815;
        if ((long)((unsigned long)_9579 + (unsigned long)HIGH_BITS) >= 0) 
        _9579 = NewDouble((double)_9579);
        _9578 = NOVALUE;
        DeRef(_s_16827);
        DeRef(_9564);
        _9564 = NOVALUE;
        DeRef(_9571);
        _9571 = NOVALUE;
        return _9579;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9580 = _38get4();
        if (IS_ATOM_INT(_9580) && IS_ATOM_INT(_38MIN4B_16821)) {
            _9581 = _9580 + _38MIN4B_16821;
            if ((long)((unsigned long)_9581 + (unsigned long)HIGH_BITS) >= 0) 
            _9581 = NewDouble((double)_9581);
        }
        else {
            _9581 = binary_op(PLUS, _9580, _38MIN4B_16821);
        }
        DeRef(_9580);
        _9580 = NOVALUE;
        DeRef(_s_16827);
        DeRef(_9564);
        _9564 = NOVALUE;
        DeRef(_9571);
        _9571 = NOVALUE;
        DeRef(_9579);
        _9579 = NOVALUE;
        return _9581;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9582 = getKBchar();
            }
            else
            _9582 = getc(last_r_file_ptr);
        }
        else
        _9582 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9583 = getKBchar();
            }
            else
            _9583 = getc(last_r_file_ptr);
        }
        else
        _9583 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9584 = getKBchar();
            }
            else
            _9584 = getc(last_r_file_ptr);
        }
        else
        _9584 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9585 = getKBchar();
            }
            else
            _9585 = getc(last_r_file_ptr);
        }
        else
        _9585 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9582;
        *((int *)(_2+8)) = _9583;
        *((int *)(_2+12)) = _9584;
        *((int *)(_2+16)) = _9585;
        _9586 = MAKE_SEQ(_1);
        _9585 = NOVALUE;
        _9584 = NOVALUE;
        _9583 = NOVALUE;
        _9582 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16862);
        _ieee32_inlined_float32_to_atom_at_173_16862 = _9586;
        _9586 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_16863);
        _float32_to_atom_inlined_float32_to_atom_at_176_16863 = machine(49, _ieee32_inlined_float32_to_atom_at_173_16862);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16862);
        _ieee32_inlined_float32_to_atom_at_173_16862 = NOVALUE;
        DeRef(_s_16827);
        DeRef(_9564);
        _9564 = NOVALUE;
        DeRef(_9571);
        _9571 = NOVALUE;
        DeRef(_9579);
        _9579 = NOVALUE;
        DeRef(_9581);
        _9581 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_16863;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9587 = getKBchar();
            }
            else
            _9587 = getc(last_r_file_ptr);
        }
        else
        _9587 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9588 = getKBchar();
            }
            else
            _9588 = getc(last_r_file_ptr);
        }
        else
        _9588 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9589 = getKBchar();
            }
            else
            _9589 = getc(last_r_file_ptr);
        }
        else
        _9589 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9590 = getKBchar();
            }
            else
            _9590 = getc(last_r_file_ptr);
        }
        else
        _9590 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9591 = getKBchar();
            }
            else
            _9591 = getc(last_r_file_ptr);
        }
        else
        _9591 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9592 = getKBchar();
            }
            else
            _9592 = getc(last_r_file_ptr);
        }
        else
        _9592 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9593 = getKBchar();
            }
            else
            _9593 = getc(last_r_file_ptr);
        }
        else
        _9593 = getc(last_r_file_ptr);
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9594 = getKBchar();
            }
            else
            _9594 = getc(last_r_file_ptr);
        }
        else
        _9594 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9587;
        *((int *)(_2+8)) = _9588;
        *((int *)(_2+12)) = _9589;
        *((int *)(_2+16)) = _9590;
        *((int *)(_2+20)) = _9591;
        *((int *)(_2+24)) = _9592;
        *((int *)(_2+28)) = _9593;
        *((int *)(_2+32)) = _9594;
        _9595 = MAKE_SEQ(_1);
        _9594 = NOVALUE;
        _9593 = NOVALUE;
        _9592 = NOVALUE;
        _9591 = NOVALUE;
        _9590 = NOVALUE;
        _9589 = NOVALUE;
        _9588 = NOVALUE;
        _9587 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16875);
        _ieee64_inlined_float64_to_atom_at_248_16875 = _9595;
        _9595 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_16876);
        _float64_to_atom_inlined_float64_to_atom_at_251_16876 = machine(47, _ieee64_inlined_float64_to_atom_at_248_16875);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16875);
        _ieee64_inlined_float64_to_atom_at_248_16875 = NOVALUE;
        DeRef(_s_16827);
        DeRef(_9564);
        _9564 = NOVALUE;
        DeRef(_9571);
        _9571 = NOVALUE;
        DeRef(_9579);
        _9579 = NOVALUE;
        DeRef(_9581);
        _9581 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_16876;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_16826 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_38current_db_16699 != last_r_file_no) {
            last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
            last_r_file_no = _38current_db_16699;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_16828 = getKBchar();
            }
            else
            _len_16828 = getc(last_r_file_ptr);
        }
        else
        _len_16828 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_16828 = _38get4();
        if (!IS_ATOM_INT(_len_16828)) {
            _1 = (long)(DBL_PTR(_len_16828)->dbl);
            DeRefDS(_len_16828);
            _len_16828 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_16827);
        _s_16827 = Repeat(0, _len_16828);

        /** 			for i = 1 to len do*/
        _9600 = _len_16828;
        {
            int _i_16885;
            _i_16885 = 1;
L5: 
            if (_i_16885 > _9600){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_38current_db_16699 != last_r_file_no) {
                last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
                last_r_file_no = _38current_db_16699;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_16826 = getKBchar();
                }
                else
                _c_16826 = getc(last_r_file_ptr);
            }
            else
            _c_16826 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_16826 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9603 = _c_16826 + -9;
            _2 = (int)SEQ_PTR(_s_16827);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_16827 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_16885);
            _1 = *(int *)_2;
            *(int *)_2 = _9603;
            if( _1 != _9603 ){
                DeRef(_1);
            }
            _9603 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9604);
            _9604 = _c_16826;
            _9605 = _38decompress(_9604);
            _9604 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_16827);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_16827 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_16885);
            _1 = *(int *)_2;
            *(int *)_2 = _9605;
            if( _1 != _9605 ){
                DeRef(_1);
            }
            _9605 = NOVALUE;
L8: 

            /** 			end for*/
            _i_16885 = _i_16885 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9564);
        _9564 = NOVALUE;
        DeRef(_9571);
        _9571 = NOVALUE;
        DeRef(_9579);
        _9579 = NOVALUE;
        DeRef(_9581);
        _9581 = NOVALUE;
        return _s_16827;
    ;}    ;
}


int _38compress(int _x_16896)
{
    int _x4_16897 = NOVALUE;
    int _s_16898 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_16932 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_16935 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_16940 = NOVALUE;
    int _9644 = NOVALUE;
    int _9643 = NOVALUE;
    int _9642 = NOVALUE;
    int _9640 = NOVALUE;
    int _9639 = NOVALUE;
    int _9637 = NOVALUE;
    int _9635 = NOVALUE;
    int _9634 = NOVALUE;
    int _9633 = NOVALUE;
    int _9631 = NOVALUE;
    int _9630 = NOVALUE;
    int _9629 = NOVALUE;
    int _9628 = NOVALUE;
    int _9627 = NOVALUE;
    int _9626 = NOVALUE;
    int _9625 = NOVALUE;
    int _9624 = NOVALUE;
    int _9623 = NOVALUE;
    int _9621 = NOVALUE;
    int _9620 = NOVALUE;
    int _9619 = NOVALUE;
    int _9618 = NOVALUE;
    int _9617 = NOVALUE;
    int _9616 = NOVALUE;
    int _9614 = NOVALUE;
    int _9613 = NOVALUE;
    int _9612 = NOVALUE;
    int _9611 = NOVALUE;
    int _9610 = NOVALUE;
    int _9609 = NOVALUE;
    int _9608 = NOVALUE;
    int _9607 = NOVALUE;
    int _9606 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_16896))
    _9606 = 1;
    else if (IS_ATOM_DBL(_x_16896))
    _9606 = IS_ATOM_INT(DoubleToInt(_x_16896));
    else
    _9606 = 0;
    if (_9606 == 0)
    {
        _9606 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9606 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_16896)) {
        _9607 = (_x_16896 >= -9);
    }
    else {
        _9607 = binary_op(GREATEREQ, _x_16896, -9);
    }
    if (IS_ATOM_INT(_9607)) {
        if (_9607 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9607)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_16896)) {
        _9609 = (_x_16896 <= 239);
    }
    else {
        _9609 = binary_op(LESSEQ, _x_16896, 239);
    }
    if (_9609 == 0) {
        DeRef(_9609);
        _9609 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9609) && DBL_PTR(_9609)->dbl == 0.0){
            DeRef(_9609);
            _9609 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9609);
        _9609 = NOVALUE;
    }
    DeRef(_9609);
    _9609 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_16896)) {
        _9610 = _x_16896 - -9;
        if ((long)((unsigned long)_9610 +(unsigned long) HIGH_BITS) >= 0){
            _9610 = NewDouble((double)_9610);
        }
    }
    else {
        _9610 = binary_op(MINUS, _x_16896, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9610;
    _9611 = MAKE_SEQ(_1);
    _9610 = NOVALUE;
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    return _9611;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_16896)) {
        _9612 = (_x_16896 >= _38MIN2B_16809);
    }
    else {
        _9612 = binary_op(GREATEREQ, _x_16896, _38MIN2B_16809);
    }
    if (IS_ATOM_INT(_9612)) {
        if (_9612 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9612)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_16896)) {
        _9614 = (_x_16896 <= 32767);
    }
    else {
        _9614 = binary_op(LESSEQ, _x_16896, 32767);
    }
    if (_9614 == 0) {
        DeRef(_9614);
        _9614 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9614) && DBL_PTR(_9614)->dbl == 0.0){
            DeRef(_9614);
            _9614 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9614);
        _9614 = NOVALUE;
    }
    DeRef(_9614);
    _9614 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_16896;
    if (IS_ATOM_INT(_x_16896)) {
        _x_16896 = _x_16896 - _38MIN2B_16809;
        if ((long)((unsigned long)_x_16896 +(unsigned long) HIGH_BITS) >= 0){
            _x_16896 = NewDouble((double)_x_16896);
        }
    }
    else {
        _x_16896 = binary_op(MINUS, _x_16896, _38MIN2B_16809);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_16896)) {
        {unsigned long tu;
             tu = (unsigned long)_x_16896 & (unsigned long)255;
             _9616 = MAKE_UINT(tu);
        }
    }
    else {
        _9616 = binary_op(AND_BITS, _x_16896, 255);
    }
    if (IS_ATOM_INT(_x_16896)) {
        if (256 > 0 && _x_16896 >= 0) {
            _9617 = _x_16896 / 256;
        }
        else {
            temp_dbl = floor((double)_x_16896 / (double)256);
            if (_x_16896 != MININT)
            _9617 = (long)temp_dbl;
            else
            _9617 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16896, 256);
        _9617 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _9616;
    *((int *)(_2+12)) = _9617;
    _9618 = MAKE_SEQ(_1);
    _9617 = NOVALUE;
    _9616 = NOVALUE;
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    return _9618;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_16896)) {
        _9619 = (_x_16896 >= _38MIN3B_16815);
    }
    else {
        _9619 = binary_op(GREATEREQ, _x_16896, _38MIN3B_16815);
    }
    if (IS_ATOM_INT(_9619)) {
        if (_9619 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9619)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_16896)) {
        _9621 = (_x_16896 <= 8388607);
    }
    else {
        _9621 = binary_op(LESSEQ, _x_16896, 8388607);
    }
    if (_9621 == 0) {
        DeRef(_9621);
        _9621 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9621) && DBL_PTR(_9621)->dbl == 0.0){
            DeRef(_9621);
            _9621 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9621);
        _9621 = NOVALUE;
    }
    DeRef(_9621);
    _9621 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_16896;
    if (IS_ATOM_INT(_x_16896)) {
        _x_16896 = _x_16896 - _38MIN3B_16815;
        if ((long)((unsigned long)_x_16896 +(unsigned long) HIGH_BITS) >= 0){
            _x_16896 = NewDouble((double)_x_16896);
        }
    }
    else {
        _x_16896 = binary_op(MINUS, _x_16896, _38MIN3B_16815);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_16896)) {
        {unsigned long tu;
             tu = (unsigned long)_x_16896 & (unsigned long)255;
             _9623 = MAKE_UINT(tu);
        }
    }
    else {
        _9623 = binary_op(AND_BITS, _x_16896, 255);
    }
    if (IS_ATOM_INT(_x_16896)) {
        if (256 > 0 && _x_16896 >= 0) {
            _9624 = _x_16896 / 256;
        }
        else {
            temp_dbl = floor((double)_x_16896 / (double)256);
            if (_x_16896 != MININT)
            _9624 = (long)temp_dbl;
            else
            _9624 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16896, 256);
        _9624 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9624)) {
        {unsigned long tu;
             tu = (unsigned long)_9624 & (unsigned long)255;
             _9625 = MAKE_UINT(tu);
        }
    }
    else {
        _9625 = binary_op(AND_BITS, _9624, 255);
    }
    DeRef(_9624);
    _9624 = NOVALUE;
    if (IS_ATOM_INT(_x_16896)) {
        if (65536 > 0 && _x_16896 >= 0) {
            _9626 = _x_16896 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_16896 / (double)65536);
            if (_x_16896 != MININT)
            _9626 = (long)temp_dbl;
            else
            _9626 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16896, 65536);
        _9626 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _9623;
    *((int *)(_2+12)) = _9625;
    *((int *)(_2+16)) = _9626;
    _9627 = MAKE_SEQ(_1);
    _9626 = NOVALUE;
    _9625 = NOVALUE;
    _9623 = NOVALUE;
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    DeRef(_9618);
    _9618 = NOVALUE;
    DeRef(_9619);
    _9619 = NOVALUE;
    return _9627;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_16896) && IS_ATOM_INT(_38MIN4B_16821)) {
        _9628 = _x_16896 - _38MIN4B_16821;
        if ((long)((unsigned long)_9628 +(unsigned long) HIGH_BITS) >= 0){
            _9628 = NewDouble((double)_9628);
        }
    }
    else {
        _9628 = binary_op(MINUS, _x_16896, _38MIN4B_16821);
    }
    _9629 = _8int_to_bytes(_9628);
    _9628 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9629)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9629)) {
        Prepend(&_9630, _9629, 251);
    }
    else {
        Concat((object_ptr)&_9630, 251, _9629);
    }
    DeRef(_9629);
    _9629 = NOVALUE;
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    DeRef(_9618);
    _9618 = NOVALUE;
    DeRef(_9619);
    _9619 = NOVALUE;
    DeRef(_9627);
    _9627 = NOVALUE;
    return _9630;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _9631 = IS_ATOM(_x_16896);
    if (_9631 == 0)
    {
        _9631 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _9631 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_16897);
    _x4_16897 = machine(48, _x_16896);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_16935);
    _float32_to_atom_inlined_float32_to_atom_at_203_16935 = machine(49, _x4_16897);
    if (binary_op_a(NOTEQ, _x_16896, _float32_to_atom_inlined_float32_to_atom_at_203_16935)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_9633, _x4_16897, 252);
    DeRef(_x_16896);
    DeRefDSi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    DeRef(_9618);
    _9618 = NOVALUE;
    DeRef(_9619);
    _9619 = NOVALUE;
    DeRef(_9627);
    _9627 = NOVALUE;
    DeRef(_9630);
    _9630 = NOVALUE;
    return _9633;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_16940);
    _atom_to_float64_inlined_atom_to_float64_at_229_16940 = machine(46, _x_16896);
    Prepend(&_9634, _atom_to_float64_inlined_atom_to_float64_at_229_16940, 253);
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_s_16898);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    DeRef(_9618);
    _9618 = NOVALUE;
    DeRef(_9619);
    _9619 = NOVALUE;
    DeRef(_9627);
    _9627 = NOVALUE;
    DeRef(_9630);
    _9630 = NOVALUE;
    DeRef(_9633);
    _9633 = NOVALUE;
    return _9634;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_16896)){
            _9635 = SEQ_PTR(_x_16896)->length;
    }
    else {
        _9635 = 1;
    }
    if (_9635 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_16896)){
            _9637 = SEQ_PTR(_x_16896)->length;
    }
    else {
        _9637 = 1;
    }
    DeRef(_s_16898);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _9637;
    _s_16898 = MAKE_SEQ(_1);
    _9637 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_16896)){
            _9639 = SEQ_PTR(_x_16896)->length;
    }
    else {
        _9639 = 1;
    }
    _9640 = _8int_to_bytes(_9639);
    _9639 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9640)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9640)) {
        Prepend(&_s_16898, _9640, 255);
    }
    else {
        Concat((object_ptr)&_s_16898, 255, _9640);
    }
    DeRef(_9640);
    _9640 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_16896)){
            _9642 = SEQ_PTR(_x_16896)->length;
    }
    else {
        _9642 = 1;
    }
    {
        int _i_16953;
        _i_16953 = 1;
LA: 
        if (_i_16953 > _9642){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_16896);
        _9643 = (int)*(((s1_ptr)_2)->base + _i_16953);
        Ref(_9643);
        _9644 = _38compress(_9643);
        _9643 = NOVALUE;
        if (IS_SEQUENCE(_s_16898) && IS_ATOM(_9644)) {
            Ref(_9644);
            Append(&_s_16898, _s_16898, _9644);
        }
        else if (IS_ATOM(_s_16898) && IS_SEQUENCE(_9644)) {
        }
        else {
            Concat((object_ptr)&_s_16898, _s_16898, _9644);
        }
        DeRef(_9644);
        _9644 = NOVALUE;

        /** 		end for*/
        _i_16953 = _i_16953 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_16896);
    DeRefi(_x4_16897);
    DeRef(_9607);
    _9607 = NOVALUE;
    DeRef(_9611);
    _9611 = NOVALUE;
    DeRef(_9612);
    _9612 = NOVALUE;
    DeRef(_9618);
    _9618 = NOVALUE;
    DeRef(_9619);
    _9619 = NOVALUE;
    DeRef(_9627);
    _9627 = NOVALUE;
    DeRef(_9630);
    _9630 = NOVALUE;
    DeRef(_9633);
    _9633 = NOVALUE;
    DeRef(_9634);
    _9634 = NOVALUE;
    return _s_16898;
L3: 
    ;
}


void _38safe_seek(int _pos_16972, int _msg_16973)
{
    int _eofpos_16974 = NOVALUE;
    int _seek_1__tmp_at32_16982 = NOVALUE;
    int _seek_inlined_seek_at_32_16981 = NOVALUE;
    int _where_inlined_where_at_49_16984 = NOVALUE;
    int _seek_1__tmp_at84_16992 = NOVALUE;
    int _seek_inlined_seek_at_84_16991 = NOVALUE;
    int _where_inlined_where_at_129_17000 = NOVALUE;
    int _9661 = NOVALUE;
    int _9657 = NOVALUE;
    int _9654 = NOVALUE;
    int _9651 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16699 != -1)
    goto L1; // [7] 29

    /** 		fatal(NO_DATABASE, "no current database defined", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16972);
    *((int *)(_2+4)) = _pos_16972;
    _9651 = MAKE_SEQ(_1);
    RefDS(_9649);
    RefDS(_9650);
    _38fatal(901, _9649, _9650, _9651);
    _9651 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16972);
    DeRef(_eofpos_16974);
    return;
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at32_16982);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at32_16982 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_32_16981 = machine(19, _seek_1__tmp_at32_16982);
    DeRefi(_seek_1__tmp_at32_16982);
    _seek_1__tmp_at32_16982 = NOVALUE;

    /** 	eofpos = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_eofpos_16974);
    _eofpos_16974 = machine(20, _38current_db_16699);

    /** 	if pos > eofpos then*/
    if (binary_op_a(LESSEQ, _pos_16972, _eofpos_16974)){
        goto L2; // [59] 81
    }

    /** 		fatal(BAD_SEEK, "io:seeking past EOF", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16972);
    *((int *)(_2+4)) = _pos_16972;
    _9654 = MAKE_SEQ(_1);
    RefDS(_9653);
    RefDS(_9650);
    _38fatal(902, _9653, _9650, _9654);
    _9654 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16972);
    DeRef(_eofpos_16974);
    return;
L2: 

    /** 	if io:seek(current_db, pos) != 0 then*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_16972);
    DeRef(_seek_1__tmp_at84_16992);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_16972;
    _seek_1__tmp_at84_16992 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_84_16991 = machine(19, _seek_1__tmp_at84_16992);
    DeRef(_seek_1__tmp_at84_16992);
    _seek_1__tmp_at84_16992 = NOVALUE;
    if (_seek_inlined_seek_at_84_16991 == 0)
    goto L3; // [98] 120

    /** 		fatal(BAD_SEEK, "io:seek to position failed", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16972);
    *((int *)(_2+4)) = _pos_16972;
    _9657 = MAKE_SEQ(_1);
    RefDS(_9656);
    RefDS(_9650);
    _38fatal(902, _9656, _9650, _9657);
    _9657 = NOVALUE;

    /** 		return*/
    DeRef(_pos_16972);
    DeRef(_eofpos_16974);
    return;
L3: 

    /** 	if pos != -1 then*/
    if (binary_op_a(EQUALS, _pos_16972, -1)){
        goto L4; // [122] 160
    }

    /** 		if io:where(current_db) != pos then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_129_17000);
    _where_inlined_where_at_129_17000 = machine(20, _38current_db_16699);
    if (binary_op_a(EQUALS, _where_inlined_where_at_129_17000, _pos_16972)){
        goto L5; // [137] 159
    }

    /** 			fatal(BAD_SEEK, "io:seek not in position", "safe_seek", {pos})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pos_16972);
    *((int *)(_2+4)) = _pos_16972;
    _9661 = MAKE_SEQ(_1);
    RefDS(_9660);
    RefDS(_9650);
    _38fatal(902, _9660, _9650, _9661);
    _9661 = NOVALUE;

    /** 			return*/
    DeRef(_pos_16972);
    DeRef(_eofpos_16974);
    return;
L5: 
L4: 

    /** end procedure*/
    DeRef(_pos_16972);
    DeRef(_eofpos_16974);
    return;
    ;
}


int  __stdcall _38db_get_errors(int _clearing_17006)
{
    int _lErrors_17007 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_clearing_17006)) {
        _1 = (long)(DBL_PTR(_clearing_17006)->dbl);
        DeRefDS(_clearing_17006);
        _clearing_17006 = _1;
    }

    /** 	lErrors = vLastErrors*/
    RefDS(_38vLastErrors_16723);
    DeRef(_lErrors_17007);
    _lErrors_17007 = _38vLastErrors_16723;

    /** 	if clearing then*/
    if (_clearing_17006 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		vLastErrors = {}*/
    RefDS(_5);
    DeRefDS(_38vLastErrors_16723);
    _38vLastErrors_16723 = _5;
L1: 

    /** 	return lErrors*/
    return _lErrors_17007;
    ;
}


void  __stdcall _38db_dump(int _file_id_17011, int _low_level_too_17012)
{
    int _magic_17013 = NOVALUE;
    int _minor_17014 = NOVALUE;
    int _major_17015 = NOVALUE;
    int _fn_17016 = NOVALUE;
    int _tables_17017 = NOVALUE;
    int _ntables_17018 = NOVALUE;
    int _tname_17019 = NOVALUE;
    int _trecords_17020 = NOVALUE;
    int _t_header_17021 = NOVALUE;
    int _tnrecs_17022 = NOVALUE;
    int _key_ptr_17023 = NOVALUE;
    int _data_ptr_17024 = NOVALUE;
    int _size_17025 = NOVALUE;
    int _addr_17026 = NOVALUE;
    int _tindex_17027 = NOVALUE;
    int _fbp_17028 = NOVALUE;
    int _key_17029 = NOVALUE;
    int _data_17030 = NOVALUE;
    int _c_17031 = NOVALUE;
    int _n_17032 = NOVALUE;
    int _tblocks_17033 = NOVALUE;
    int _a_17034 = NOVALUE;
    int _ll_line_17035 = NOVALUE;
    int _hi_17036 = NOVALUE;
    int _ci_17037 = NOVALUE;
    int _now_1__tmp_at77_17052 = NOVALUE;
    int _now_inlined_now_at_77_17051 = NOVALUE;
    int _seek_1__tmp_at105_17058 = NOVALUE;
    int _seek_inlined_seek_at_105_17057 = NOVALUE;
    int _get1_inlined_get1_at_135_17063 = NOVALUE;
    int _get1_inlined_get1_at_159_17069 = NOVALUE;
    int _get1_inlined_get1_at_169_17071 = NOVALUE;
    int _seek_1__tmp_at196_17077 = NOVALUE;
    int _seek_inlined_seek_at_196_17076 = NOVALUE;
    int _seek_1__tmp_at282_17093 = NOVALUE;
    int _seek_inlined_seek_at_282_17092 = NOVALUE;
    int _seek_1__tmp_at556_17132 = NOVALUE;
    int _seek_inlined_seek_at_556_17131 = NOVALUE;
    int _get1_inlined_get1_at_571_17134 = NOVALUE;
    int _get1_inlined_get1_at_606_17140 = NOVALUE;
    int _get1_inlined_get1_at_616_17142 = NOVALUE;
    int _seek_1__tmp_at643_17148 = NOVALUE;
    int _seek_inlined_seek_at_643_17147 = NOVALUE;
    int _where_inlined_where_at_665_17151 = NOVALUE;
    int _seek_1__tmp_at730_17165 = NOVALUE;
    int _seek_inlined_seek_at_730_17164 = NOVALUE;
    int _seek_1__tmp_at821_17186 = NOVALUE;
    int _seek_inlined_seek_at_821_17185 = NOVALUE;
    int _pos_inlined_seek_at_818_17184 = NOVALUE;
    int _seek_1__tmp_at917_17208 = NOVALUE;
    int _seek_inlined_seek_at_917_17207 = NOVALUE;
    int _pos_inlined_seek_at_914_17206 = NOVALUE;
    int _seek_1__tmp_at953_17215 = NOVALUE;
    int _seek_inlined_seek_at_953_17214 = NOVALUE;
    int _seek_1__tmp_at1012_17225 = NOVALUE;
    int _seek_inlined_seek_at_1012_17224 = NOVALUE;
    int _seek_1__tmp_at1083_17234 = NOVALUE;
    int _seek_inlined_seek_at_1083_17233 = NOVALUE;
    int _seek_1__tmp_at1117_17239 = NOVALUE;
    int _seek_inlined_seek_at_1117_17238 = NOVALUE;
    int _seek_1__tmp_at1178_17249 = NOVALUE;
    int _seek_inlined_seek_at_1178_17248 = NOVALUE;
    int _9782 = NOVALUE;
    int _9780 = NOVALUE;
    int _9776 = NOVALUE;
    int _9764 = NOVALUE;
    int _9758 = NOVALUE;
    int _9755 = NOVALUE;
    int _9754 = NOVALUE;
    int _9753 = NOVALUE;
    int _9752 = NOVALUE;
    int _9751 = NOVALUE;
    int _9750 = NOVALUE;
    int _9749 = NOVALUE;
    int _9747 = NOVALUE;
    int _9746 = NOVALUE;
    int _9741 = NOVALUE;
    int _9740 = NOVALUE;
    int _9739 = NOVALUE;
    int _9738 = NOVALUE;
    int _9737 = NOVALUE;
    int _9736 = NOVALUE;
    int _9735 = NOVALUE;
    int _9733 = NOVALUE;
    int _9731 = NOVALUE;
    int _9730 = NOVALUE;
    int _9722 = NOVALUE;
    int _9718 = NOVALUE;
    int _9716 = NOVALUE;
    int _9714 = NOVALUE;
    int _9713 = NOVALUE;
    int _9709 = NOVALUE;
    int _9708 = NOVALUE;
    int _9707 = NOVALUE;
    int _9704 = NOVALUE;
    int _9701 = NOVALUE;
    int _9699 = NOVALUE;
    int _9698 = NOVALUE;
    int _9695 = NOVALUE;
    int _9692 = NOVALUE;
    int _9689 = NOVALUE;
    int _9688 = NOVALUE;
    int _9684 = NOVALUE;
    int _9683 = NOVALUE;
    int _9682 = NOVALUE;
    int _9678 = NOVALUE;
    int _9673 = NOVALUE;
    int _9672 = NOVALUE;
    int _9671 = NOVALUE;
    int _9668 = NOVALUE;
    int _9662 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_level_too_17012)) {
        _1 = (long)(DBL_PTR(_low_level_too_17012)->dbl);
        DeRefDS(_low_level_too_17012);
        _low_level_too_17012 = _1;
    }

    /** 	if sequence(file_id) then*/
    _9662 = IS_SEQUENCE(_file_id_17011);
    if (_9662 == 0)
    {
        _9662 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _9662 = NOVALUE;
    }

    /** 		fn = open(file_id, "w")*/
    _fn_17016 = EOpen(_file_id_17011, _1297, 0);
    goto L2; // [18] 50
L1: 

    /** 	elsif file_id > 0 then*/
    if (binary_op_a(LESSEQ, _file_id_17011, 0)){
        goto L3; // [23] 42
    }

    /** 		fn = file_id*/
    Ref(_file_id_17011);
    _fn_17016 = _file_id_17011;
    if (!IS_ATOM_INT(_fn_17016)) {
        _1 = (long)(DBL_PTR(_fn_17016)->dbl);
        DeRefDS(_fn_17016);
        _fn_17016 = _1;
    }

    /** 		puts(fn, '\n')*/
    EPuts(_fn_17016, 10); // DJP 
    goto L2; // [39] 50
L3: 

    /** 		fn = file_id*/
    Ref(_file_id_17011);
    _fn_17016 = _file_id_17011;
    if (!IS_ATOM_INT(_fn_17016)) {
        _1 = (long)(DBL_PTR(_fn_17016)->dbl);
        DeRefDS(_fn_17016);
        _fn_17016 = _1;
    }
L2: 

    /** 	if fn <= 0 then*/
    if (_fn_17016 > 0)
    goto L4; // [54] 76

    /** 		fatal( BAD_FILE, "bad file", "db_dump", {file_id, low_level_too})*/
    Ref(_file_id_17011);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_id_17011;
    ((int *)_2)[2] = _low_level_too_17012;
    _9668 = MAKE_SEQ(_1);
    RefDS(_9666);
    RefDS(_9667);
    _38fatal(908, _9666, _9667, _9668);
    _9668 = NOVALUE;

    /** 		return*/
    DeRef(_file_id_17011);
    DeRef(_tables_17017);
    DeRef(_ntables_17018);
    DeRef(_tname_17019);
    DeRef(_trecords_17020);
    DeRef(_t_header_17021);
    DeRef(_tnrecs_17022);
    DeRef(_key_ptr_17023);
    DeRef(_data_ptr_17024);
    DeRef(_size_17025);
    DeRef(_addr_17026);
    DeRef(_tindex_17027);
    DeRef(_fbp_17028);
    DeRef(_key_17029);
    DeRef(_data_17030);
    DeRef(_a_17034);
    DeRef(_ll_line_17035);
    return;
L4: 

    /** 	printf(fn, "Database dump as at %s\n", {datetime:format( datetime:now(), "%Y-%m-%d %H:%M:%S")})*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at77_17052);
    _now_1__tmp_at77_17052 = Date();
    RefDS(_now_1__tmp_at77_17052);
    _0 = _now_inlined_now_at_77_17051;
    _now_inlined_now_at_77_17051 = _12from_date(_now_1__tmp_at77_17052);
    DeRef(_0);
    DeRefi(_now_1__tmp_at77_17052);
    _now_1__tmp_at77_17052 = NOVALUE;
    Ref(_now_inlined_now_at_77_17051);
    RefDS(_9670);
    _9671 = _12format(_now_inlined_now_at_77_17051, _9670);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9671;
    _9672 = MAKE_SEQ(_1);
    _9671 = NOVALUE;
    EPrintf(_fn_17016, _9669, _9672);
    DeRefDS(_9672);
    _9672 = NOVALUE;

    /** 	io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at105_17058);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at105_17058 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_105_17057 = machine(19, _seek_1__tmp_at105_17058);
    DeRefi(_seek_1__tmp_at105_17058);
    _seek_1__tmp_at105_17058 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _9673 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _9673 = 1;
    }
    if (_9673 <= 0)
    goto L5; // [126] 134
    DeRef(_file_id_17011);
    DeRef(_tables_17017);
    DeRef(_ntables_17018);
    DeRef(_tname_17019);
    DeRef(_trecords_17020);
    DeRef(_t_header_17021);
    DeRef(_tnrecs_17022);
    DeRef(_key_ptr_17023);
    DeRef(_data_ptr_17024);
    DeRef(_size_17025);
    DeRef(_addr_17026);
    DeRef(_tindex_17027);
    DeRef(_fbp_17028);
    DeRef(_key_17029);
    DeRef(_data_17030);
    DeRef(_a_17034);
    DeRef(_ll_line_17035);
    return;
L5: 

    /** 	magic = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_17013 = getKBchar();
        }
        else
        _magic_17013 = getc(last_r_file_ptr);
    }
    else
    _magic_17013 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_17013 == 77)
    goto L6; // [146] 158

    /** 		puts(fn, "This is not a Euphoria Database file.\n")*/
    EPuts(_fn_17016, _9676); // DJP 
    goto L7; // [155] 261
L6: 

    /** 		major = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _major_17015 = getKBchar();
        }
        else
        _major_17015 = getc(last_r_file_ptr);
    }
    else
    _major_17015 = getc(last_r_file_ptr);

    /** 		minor = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _minor_17014 = getKBchar();
        }
        else
        _minor_17014 = getc(last_r_file_ptr);
    }
    else
    _minor_17014 = getc(last_r_file_ptr);

    /** 		printf(fn, "Euphoria Database System Version %d.%d\n\n", {major, minor})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _major_17015;
    ((int *)_2)[2] = _minor_17014;
    _9678 = MAKE_SEQ(_1);
    EPrintf(_fn_17016, _9677, _9678);
    DeRefDS(_9678);
    _9678 = NOVALUE;

    /** 		tables = get4()*/
    _0 = _tables_17017;
    _tables_17017 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17017);
    DeRef(_seek_1__tmp_at196_17077);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_17017;
    _seek_1__tmp_at196_17077 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_17076 = machine(19, _seek_1__tmp_at196_17077);
    DeRef(_seek_1__tmp_at196_17077);
    _seek_1__tmp_at196_17077 = NOVALUE;

    /** 		ntables = get4()*/
    _0 = _ntables_17018;
    _ntables_17018 = _38get4();
    DeRef(_0);

    /** 		printf(fn, "The \"%s\" database has %d table",*/
    _9682 = find_from(_38current_db_16699, _38db_file_nums_16703, 1);
    _2 = (int)SEQ_PTR(_38db_names_16702);
    _9683 = (int)*(((s1_ptr)_2)->base + _9682);
    Ref(_ntables_17018);
    Ref(_9683);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9683;
    ((int *)_2)[2] = _ntables_17018;
    _9684 = MAKE_SEQ(_1);
    _9683 = NOVALUE;
    EPrintf(_fn_17016, _9681, _9684);
    DeRefDS(_9684);
    _9684 = NOVALUE;

    /** 		if ntables = 1 then*/
    if (binary_op_a(NOTEQ, _ntables_17018, 1)){
        goto L8; // [242] 254
    }

    /** 			puts(fn, "\n")*/
    EPuts(_fn_17016, _1326); // DJP 
    goto L9; // [251] 260
L8: 

    /** 			puts(fn, "s\n")*/
    EPuts(_fn_17016, _9686); // DJP 
L9: 
L7: 

    /** 	if low_level_too then*/
    if (_low_level_too_17012 == 0)
    {
        goto LA; // [263] 553
    }
    else{
    }

    /** 		puts(fn, "            Disk Dump\nDiskAddr " & repeat('-', 58))*/
    _9688 = Repeat(45, 58);
    Concat((object_ptr)&_9689, _9687, _9688);
    DeRefDS(_9688);
    _9688 = NOVALUE;
    EPuts(_fn_17016, _9689); // DJP 
    DeRefDS(_9689);
    _9689 = NOVALUE;

    /** 		io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at282_17093);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at282_17093 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_282_17092 = machine(19, _seek_1__tmp_at282_17093);
    DeRefi(_seek_1__tmp_at282_17093);
    _seek_1__tmp_at282_17093 = NOVALUE;

    /** 		a = 0*/
    DeRef(_a_17034);
    _a_17034 = 0;

    /** 		while c >= 0 with entry do*/
    goto LB; // [303] 515
LC: 
    if (_c_17031 < 0)
    goto LD; // [308] 527

    /** 			if c = -1 then*/
    if (_c_17031 != -1)
    goto LE; // [314] 323

    /** 				exit*/
    goto LD; // [320] 527
LE: 

    /** 			if remainder(a, 16) = 0 then*/
    if (IS_ATOM_INT(_a_17034)) {
        _9692 = (_a_17034 % 16);
    }
    else {
        temp_d.dbl = (double)16;
        _9692 = Dremainder(DBL_PTR(_a_17034), &temp_d);
    }
    if (binary_op_a(NOTEQ, _9692, 0)){
        DeRef(_9692);
        _9692 = NOVALUE;
        goto LF; // [329] 406
    }
    DeRef(_9692);
    _9692 = NOVALUE;

    /** 				if a > 0 then*/
    if (binary_op_a(LESSEQ, _a_17034, 0)){
        goto L10; // [335] 354
    }

    /** 					printf(fn, "%s\n", {ll_line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ll_line_17035);
    *((int *)(_2+4)) = _ll_line_17035;
    _9695 = MAKE_SEQ(_1);
    EPrintf(_fn_17016, _9454, _9695);
    DeRefDS(_9695);
    _9695 = NOVALUE;
    goto L11; // [351] 360
L10: 

    /** 					puts(fn, '\n')*/
    EPuts(_fn_17016, 10); // DJP 
L11: 

    /** 				ll_line = repeat(' ', 67)*/
    DeRef(_ll_line_17035);
    _ll_line_17035 = Repeat(32, 67);

    /** 				ll_line[9] = ':'*/
    _2 = (int)SEQ_PTR(_ll_line_17035);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_17035 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = 58;

    /** 				ll_line[48] = '|'*/
    _2 = (int)SEQ_PTR(_ll_line_17035);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_17035 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    *(int *)_2 = 124;

    /** 				ll_line[67] = '|'*/
    _2 = (int)SEQ_PTR(_ll_line_17035);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_17035 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    *(int *)_2 = 124;

    /** 				hi = 11*/
    _hi_17036 = 11;

    /** 				ci = 50*/
    _ci_17037 = 50;

    /** 				ll_line[1..8] = sprintf("%08x", a)*/
    _9698 = EPrintf(-9999999, _9697, _a_17034);
    assign_slice_seq = (s1_ptr *)&_ll_line_17035;
    AssignSlice(1, 8, _9698);
    DeRefDS(_9698);
    _9698 = NOVALUE;
LF: 

    /** 			ll_line[hi .. hi + 1] = sprintf("%02x", c)*/
    _9699 = _hi_17036 + 1;
    if (_9699 > MAXINT){
        _9699 = NewDouble((double)_9699);
    }
    _9701 = EPrintf(-9999999, _9700, _c_17031);
    assign_slice_seq = (s1_ptr *)&_ll_line_17035;
    AssignSlice(_hi_17036, _9699, _9701);
    DeRef(_9699);
    _9699 = NOVALUE;
    DeRefDS(_9701);
    _9701 = NOVALUE;

    /** 			hi += 2*/
    _hi_17036 = _hi_17036 + 2;

    /** 			if eu:find(hi, {19, 28, 38}) then*/
    _9704 = find_from(_hi_17036, _9703, 1);
    if (_9704 == 0)
    {
        _9704 = NOVALUE;
        goto L12; // [438] 460
    }
    else{
        _9704 = NOVALUE;
    }

    /** 				hi += 1*/
    _hi_17036 = _hi_17036 + 1;

    /** 				if hi = 29 then*/
    if (_hi_17036 != 29)
    goto L13; // [449] 459

    /** 					hi = 30*/
    _hi_17036 = 30;
L13: 
L12: 

    /** 			if c > ' ' and c < '~' then*/
    _9707 = (_c_17031 > 32);
    if (_9707 == 0) {
        goto L14; // [466] 489
    }
    _9709 = (_c_17031 < 126);
    if (_9709 == 0)
    {
        DeRef(_9709);
        _9709 = NOVALUE;
        goto L14; // [475] 489
    }
    else{
        DeRef(_9709);
        _9709 = NOVALUE;
    }

    /** 				ll_line[ci] = c*/
    _2 = (int)SEQ_PTR(_ll_line_17035);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_17035 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ci_17037);
    _1 = *(int *)_2;
    *(int *)_2 = _c_17031;
    DeRef(_1);
    goto L15; // [486] 498
L14: 

    /** 				ll_line[ci] = '.'*/
    _2 = (int)SEQ_PTR(_ll_line_17035);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ll_line_17035 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ci_17037);
    _1 = *(int *)_2;
    *(int *)_2 = 46;
    DeRef(_1);
L15: 

    /** 			ci += 1*/
    _ci_17037 = _ci_17037 + 1;

    /** 			a += 1*/
    _0 = _a_17034;
    if (IS_ATOM_INT(_a_17034)) {
        _a_17034 = _a_17034 + 1;
        if (_a_17034 > MAXINT){
            _a_17034 = NewDouble((double)_a_17034);
        }
    }
    else
    _a_17034 = binary_op(PLUS, 1, _a_17034);
    DeRef(_0);

    /** 		  entry*/
LB: 

    /** 			c = getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17031 = getKBchar();
        }
        else
        _c_17031 = getc(last_r_file_ptr);
    }
    else
    _c_17031 = getc(last_r_file_ptr);

    /** 		end while*/
    goto LC; // [524] 306
LD: 

    /** 		printf(fn, "%s\n", {ll_line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ll_line_17035);
    *((int *)(_2+4)) = _ll_line_17035;
    _9713 = MAKE_SEQ(_1);
    EPrintf(_fn_17016, _9454, _9713);
    DeRefDS(_9713);
    _9713 = NOVALUE;

    /** 		puts(fn, repeat('-', 67) & "\n\n")*/
    _9714 = Repeat(45, 67);
    Concat((object_ptr)&_9716, _9714, _9715);
    DeRefDS(_9714);
    _9714 = NOVALUE;
    DeRef(_9714);
    _9714 = NOVALUE;
    EPuts(_fn_17016, _9716); // DJP 
    DeRefDS(_9716);
    _9716 = NOVALUE;
LA: 

    /** 	io:seek(current_db, 0)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at556_17132);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 0;
    _seek_1__tmp_at556_17132 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_556_17131 = machine(19, _seek_1__tmp_at556_17132);
    DeRefi(_seek_1__tmp_at556_17132);
    _seek_1__tmp_at556_17132 = NOVALUE;

    /** 	magic = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_17013 = getKBchar();
        }
        else
        _magic_17013 = getc(last_r_file_ptr);
    }
    else
    _magic_17013 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_17013 == 77)
    goto L16; // [582] 605

    /** 		if sequence(file_id) then*/
    _9718 = IS_SEQUENCE(_file_id_17011);
    if (_9718 == 0)
    {
        _9718 = NOVALUE;
        goto L17; // [591] 599
    }
    else{
        _9718 = NOVALUE;
    }

    /** 			close(fn)*/
    EClose(_fn_17016);
L17: 

    /** 		return*/
    DeRef(_file_id_17011);
    DeRef(_tables_17017);
    DeRef(_ntables_17018);
    DeRef(_tname_17019);
    DeRef(_trecords_17020);
    DeRef(_t_header_17021);
    DeRef(_tnrecs_17022);
    DeRef(_key_ptr_17023);
    DeRef(_data_ptr_17024);
    DeRef(_size_17025);
    DeRef(_addr_17026);
    DeRef(_tindex_17027);
    DeRef(_fbp_17028);
    DeRef(_key_17029);
    DeRef(_data_17030);
    DeRef(_a_17034);
    DeRef(_ll_line_17035);
    DeRef(_9707);
    _9707 = NOVALUE;
    return;
L16: 

    /** 	major = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _major_17015 = getKBchar();
        }
        else
        _major_17015 = getc(last_r_file_ptr);
    }
    else
    _major_17015 = getc(last_r_file_ptr);

    /** 	minor = get1()*/

    /** 	return getc(current_db)*/
    if (_38current_db_16699 != last_r_file_no) {
        last_r_file_ptr = which_file(_38current_db_16699, EF_READ);
        last_r_file_no = _38current_db_16699;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _minor_17014 = getKBchar();
        }
        else
        _minor_17014 = getc(last_r_file_ptr);
    }
    else
    _minor_17014 = getc(last_r_file_ptr);

    /** 	tables = get4()*/
    _0 = _tables_17017;
    _tables_17017 = _38get4();
    DeRef(_0);

    /** 	if low_level_too then printf(fn, "[tables:#%08x]\n", tables) end if*/
    if (_low_level_too_17012 == 0)
    {
        goto L18; // [632] 640
    }
    else{
    }
    EPrintf(_fn_17016, _9720, _tables_17017);
L18: 

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17017);
    DeRef(_seek_1__tmp_at643_17148);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_17017;
    _seek_1__tmp_at643_17148 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_643_17147 = machine(19, _seek_1__tmp_at643_17148);
    DeRef(_seek_1__tmp_at643_17148);
    _seek_1__tmp_at643_17148 = NOVALUE;

    /** 	ntables = get4()*/
    _0 = _ntables_17018;
    _ntables_17018 = _38get4();
    DeRef(_0);

    /** 	t_header = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_t_header_17021);
    _t_header_17021 = machine(20, _38current_db_16699);

    /** 	for t = 1 to ntables do*/
    Ref(_ntables_17018);
    DeRef(_9722);
    _9722 = _ntables_17018;
    {
        int _t_17153;
        _t_17153 = 1;
L19: 
        if (binary_op_a(GREATER, _t_17153, _9722)){
            goto L1A; // [678] 1104
        }

        /** 		if low_level_too then printf(fn, "\n---------------\n[table header:#%08x]\n", t_header) end if*/
        if (_low_level_too_17012 == 0)
        {
            goto L1B; // [687] 695
        }
        else{
        }
        EPrintf(_fn_17016, _9723, _t_header_17021);
L1B: 

        /** 		tname = get4()*/
        _0 = _tname_17019;
        _tname_17019 = _38get4();
        DeRef(_0);

        /** 		tnrecs = get4()*/
        _0 = _tnrecs_17022;
        _tnrecs_17022 = _38get4();
        DeRef(_0);

        /** 		tblocks = get4()*/
        _tblocks_17033 = _38get4();
        if (!IS_ATOM_INT(_tblocks_17033)) {
            _1 = (long)(DBL_PTR(_tblocks_17033)->dbl);
            DeRefDS(_tblocks_17033);
            _tblocks_17033 = _1;
        }

        /** 		tindex = get4()*/
        _0 = _tindex_17027;
        _tindex_17027 = _38get4();
        DeRef(_0);

        /** 		if low_level_too then printf(fn, "[table name:#%08x]\n", tname) end if*/
        if (_low_level_too_17012 == 0)
        {
            goto L1C; // [719] 727
        }
        else{
        }
        EPrintf(_fn_17016, _9728, _tname_17019);
L1C: 

        /** 		io:seek(current_db, tname)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_tname_17019);
        DeRef(_seek_1__tmp_at730_17165);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _tname_17019;
        _seek_1__tmp_at730_17165 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_730_17164 = machine(19, _seek_1__tmp_at730_17165);
        DeRef(_seek_1__tmp_at730_17165);
        _seek_1__tmp_at730_17165 = NOVALUE;

        /** 		printf(fn, "\ntable \"%s\", records:%d    indexblks: %d\n\n\n", {get_string(), tnrecs, tblocks})*/
        _9730 = _38get_string();
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9730;
        Ref(_tnrecs_17022);
        *((int *)(_2+8)) = _tnrecs_17022;
        *((int *)(_2+12)) = _tblocks_17033;
        _9731 = MAKE_SEQ(_1);
        _9730 = NOVALUE;
        EPrintf(_fn_17016, _9729, _9731);
        DeRefDS(_9731);
        _9731 = NOVALUE;

        /** 		if tnrecs > 0 then*/
        if (binary_op_a(LESSEQ, _tnrecs_17022, 0)){
            goto L1D; // [761] 1074
        }

        /** 			for b = 1 to tblocks do*/
        _9733 = _tblocks_17033;
        {
            int _b_17172;
            _b_17172 = 1;
L1E: 
            if (_b_17172 > _9733){
                goto L1F; // [770] 1073
            }

            /** 				if low_level_too then printf(fn, "[table block %d:#%08x]\n", {b, tindex+(b-1)*8}) end if*/
            if (_low_level_too_17012 == 0)
            {
                goto L20; // [779] 803
            }
            else{
            }
            _9735 = _b_17172 - 1;
            if (_9735 == (short)_9735)
            _9736 = _9735 * 8;
            else
            _9736 = NewDouble(_9735 * (double)8);
            _9735 = NOVALUE;
            if (IS_ATOM_INT(_tindex_17027) && IS_ATOM_INT(_9736)) {
                _9737 = _tindex_17027 + _9736;
                if ((long)((unsigned long)_9737 + (unsigned long)HIGH_BITS) >= 0) 
                _9737 = NewDouble((double)_9737);
            }
            else {
                if (IS_ATOM_INT(_tindex_17027)) {
                    _9737 = NewDouble((double)_tindex_17027 + DBL_PTR(_9736)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_9736)) {
                        _9737 = NewDouble(DBL_PTR(_tindex_17027)->dbl + (double)_9736);
                    }
                    else
                    _9737 = NewDouble(DBL_PTR(_tindex_17027)->dbl + DBL_PTR(_9736)->dbl);
                }
            }
            DeRef(_9736);
            _9736 = NOVALUE;
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _b_17172;
            ((int *)_2)[2] = _9737;
            _9738 = MAKE_SEQ(_1);
            _9737 = NOVALUE;
            EPrintf(_fn_17016, _9734, _9738);
            DeRefDS(_9738);
            _9738 = NOVALUE;
L20: 

            /** 				io:seek(current_db, tindex+(b-1)*8)*/
            _9739 = _b_17172 - 1;
            if (_9739 == (short)_9739)
            _9740 = _9739 * 8;
            else
            _9740 = NewDouble(_9739 * (double)8);
            _9739 = NOVALUE;
            if (IS_ATOM_INT(_tindex_17027) && IS_ATOM_INT(_9740)) {
                _9741 = _tindex_17027 + _9740;
                if ((long)((unsigned long)_9741 + (unsigned long)HIGH_BITS) >= 0) 
                _9741 = NewDouble((double)_9741);
            }
            else {
                if (IS_ATOM_INT(_tindex_17027)) {
                    _9741 = NewDouble((double)_tindex_17027 + DBL_PTR(_9740)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_9740)) {
                        _9741 = NewDouble(DBL_PTR(_tindex_17027)->dbl + (double)_9740);
                    }
                    else
                    _9741 = NewDouble(DBL_PTR(_tindex_17027)->dbl + DBL_PTR(_9740)->dbl);
                }
            }
            DeRef(_9740);
            _9740 = NOVALUE;
            DeRef(_pos_inlined_seek_at_818_17184);
            _pos_inlined_seek_at_818_17184 = _9741;
            _9741 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_818_17184);
            DeRef(_seek_1__tmp_at821_17186);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16699;
            ((int *)_2)[2] = _pos_inlined_seek_at_818_17184;
            _seek_1__tmp_at821_17186 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_821_17185 = machine(19, _seek_1__tmp_at821_17186);
            DeRef(_pos_inlined_seek_at_818_17184);
            _pos_inlined_seek_at_818_17184 = NOVALUE;
            DeRef(_seek_1__tmp_at821_17186);
            _seek_1__tmp_at821_17186 = NOVALUE;

            /** 				tnrecs = get4()*/
            _0 = _tnrecs_17022;
            _tnrecs_17022 = _38get4();
            DeRef(_0);

            /** 				trecords = get4()*/
            _0 = _trecords_17020;
            _trecords_17020 = _38get4();
            DeRef(_0);

            /** 				if tnrecs > 0 then*/
            if (binary_op_a(LESSEQ, _tnrecs_17022, 0)){
                goto L21; // [847] 1059
            }

            /** 					printf(fn, "\n--------------------------\nblock #%d, ptrs:%d\n--------------------------\n", {b, tnrecs})*/
            Ref(_tnrecs_17022);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _b_17172;
            ((int *)_2)[2] = _tnrecs_17022;
            _9746 = MAKE_SEQ(_1);
            EPrintf(_fn_17016, _9745, _9746);
            DeRefDS(_9746);
            _9746 = NOVALUE;

            /** 					for r = 1 to tnrecs do*/
            Ref(_tnrecs_17022);
            DeRef(_9747);
            _9747 = _tnrecs_17022;
            {
                int _r_17194;
                _r_17194 = 1;
L22: 
                if (binary_op_a(GREATER, _r_17194, _9747)){
                    goto L23; // [866] 1056
                }

                /** 						if low_level_too then printf(fn, "[record %d:#%08x]\n", {r, trecords+(r-1)*4}) end if*/
                if (_low_level_too_17012 == 0)
                {
                    goto L24; // [875] 899
                }
                else{
                }
                if (IS_ATOM_INT(_r_17194)) {
                    _9749 = _r_17194 - 1;
                    if ((long)((unsigned long)_9749 +(unsigned long) HIGH_BITS) >= 0){
                        _9749 = NewDouble((double)_9749);
                    }
                }
                else {
                    _9749 = NewDouble(DBL_PTR(_r_17194)->dbl - (double)1);
                }
                if (IS_ATOM_INT(_9749)) {
                    if (_9749 == (short)_9749)
                    _9750 = _9749 * 4;
                    else
                    _9750 = NewDouble(_9749 * (double)4);
                }
                else {
                    _9750 = NewDouble(DBL_PTR(_9749)->dbl * (double)4);
                }
                DeRef(_9749);
                _9749 = NOVALUE;
                if (IS_ATOM_INT(_trecords_17020) && IS_ATOM_INT(_9750)) {
                    _9751 = _trecords_17020 + _9750;
                    if ((long)((unsigned long)_9751 + (unsigned long)HIGH_BITS) >= 0) 
                    _9751 = NewDouble((double)_9751);
                }
                else {
                    if (IS_ATOM_INT(_trecords_17020)) {
                        _9751 = NewDouble((double)_trecords_17020 + DBL_PTR(_9750)->dbl);
                    }
                    else {
                        if (IS_ATOM_INT(_9750)) {
                            _9751 = NewDouble(DBL_PTR(_trecords_17020)->dbl + (double)_9750);
                        }
                        else
                        _9751 = NewDouble(DBL_PTR(_trecords_17020)->dbl + DBL_PTR(_9750)->dbl);
                    }
                }
                DeRef(_9750);
                _9750 = NOVALUE;
                Ref(_r_17194);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_17194;
                ((int *)_2)[2] = _9751;
                _9752 = MAKE_SEQ(_1);
                _9751 = NOVALUE;
                EPrintf(_fn_17016, _9748, _9752);
                DeRefDS(_9752);
                _9752 = NOVALUE;
L24: 

                /** 						io:seek(current_db, trecords+(r-1)*4)*/
                if (IS_ATOM_INT(_r_17194)) {
                    _9753 = _r_17194 - 1;
                    if ((long)((unsigned long)_9753 +(unsigned long) HIGH_BITS) >= 0){
                        _9753 = NewDouble((double)_9753);
                    }
                }
                else {
                    _9753 = NewDouble(DBL_PTR(_r_17194)->dbl - (double)1);
                }
                if (IS_ATOM_INT(_9753)) {
                    if (_9753 == (short)_9753)
                    _9754 = _9753 * 4;
                    else
                    _9754 = NewDouble(_9753 * (double)4);
                }
                else {
                    _9754 = NewDouble(DBL_PTR(_9753)->dbl * (double)4);
                }
                DeRef(_9753);
                _9753 = NOVALUE;
                if (IS_ATOM_INT(_trecords_17020) && IS_ATOM_INT(_9754)) {
                    _9755 = _trecords_17020 + _9754;
                    if ((long)((unsigned long)_9755 + (unsigned long)HIGH_BITS) >= 0) 
                    _9755 = NewDouble((double)_9755);
                }
                else {
                    if (IS_ATOM_INT(_trecords_17020)) {
                        _9755 = NewDouble((double)_trecords_17020 + DBL_PTR(_9754)->dbl);
                    }
                    else {
                        if (IS_ATOM_INT(_9754)) {
                            _9755 = NewDouble(DBL_PTR(_trecords_17020)->dbl + (double)_9754);
                        }
                        else
                        _9755 = NewDouble(DBL_PTR(_trecords_17020)->dbl + DBL_PTR(_9754)->dbl);
                    }
                }
                DeRef(_9754);
                _9754 = NOVALUE;
                DeRef(_pos_inlined_seek_at_914_17206);
                _pos_inlined_seek_at_914_17206 = _9755;
                _9755 = NOVALUE;

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_pos_inlined_seek_at_914_17206);
                DeRef(_seek_1__tmp_at917_17208);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16699;
                ((int *)_2)[2] = _pos_inlined_seek_at_914_17206;
                _seek_1__tmp_at917_17208 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_917_17207 = machine(19, _seek_1__tmp_at917_17208);
                DeRef(_pos_inlined_seek_at_914_17206);
                _pos_inlined_seek_at_914_17206 = NOVALUE;
                DeRef(_seek_1__tmp_at917_17208);
                _seek_1__tmp_at917_17208 = NOVALUE;

                /** 						key_ptr = get4()*/
                _0 = _key_ptr_17023;
                _key_ptr_17023 = _38get4();
                DeRef(_0);

                /** 						if low_level_too then printf(fn, "[key %d:#%08x]\n", {r, key_ptr}) end if*/
                if (_low_level_too_17012 == 0)
                {
                    goto L25; // [938] 950
                }
                else{
                }
                Ref(_key_ptr_17023);
                Ref(_r_17194);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_17194;
                ((int *)_2)[2] = _key_ptr_17023;
                _9758 = MAKE_SEQ(_1);
                EPrintf(_fn_17016, _9757, _9758);
                DeRefDS(_9758);
                _9758 = NOVALUE;
L25: 

                /** 						io:seek(current_db, key_ptr)*/

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_key_ptr_17023);
                DeRef(_seek_1__tmp_at953_17215);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16699;
                ((int *)_2)[2] = _key_ptr_17023;
                _seek_1__tmp_at953_17215 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_953_17214 = machine(19, _seek_1__tmp_at953_17215);
                DeRef(_seek_1__tmp_at953_17215);
                _seek_1__tmp_at953_17215 = NOVALUE;

                /** 						data_ptr = get4()*/
                _0 = _data_ptr_17024;
                _data_ptr_17024 = _38get4();
                DeRef(_0);

                /** 						key = decompress(0)*/
                _0 = _key_17029;
                _key_17029 = _38decompress(0);
                DeRef(_0);

                /** 						puts(fn, "  key: ")*/
                EPuts(_fn_17016, _9761); // DJP 

                /** 						pretty:pretty_print(fn, key, {2, 2, 8})*/
                Ref(_key_17029);
                RefDS(_9762);
                _26pretty_print(_fn_17016, _key_17029, _9762);

                /** 						puts(fn, '\n')*/
                EPuts(_fn_17016, 10); // DJP 

                /** 						if low_level_too then printf(fn, "[data %d:#%08x]\n", {r, data_ptr}) end if*/
                if (_low_level_too_17012 == 0)
                {
                    goto L26; // [997] 1009
                }
                else{
                }
                Ref(_data_ptr_17024);
                Ref(_r_17194);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _r_17194;
                ((int *)_2)[2] = _data_ptr_17024;
                _9764 = MAKE_SEQ(_1);
                EPrintf(_fn_17016, _9763, _9764);
                DeRefDS(_9764);
                _9764 = NOVALUE;
L26: 

                /** 						io:seek(current_db, data_ptr)*/

                /** 	return machine_func(M_SEEK, {fn, pos})*/
                Ref(_data_ptr_17024);
                DeRef(_seek_1__tmp_at1012_17225);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _38current_db_16699;
                ((int *)_2)[2] = _data_ptr_17024;
                _seek_1__tmp_at1012_17225 = MAKE_SEQ(_1);
                _seek_inlined_seek_at_1012_17224 = machine(19, _seek_1__tmp_at1012_17225);
                DeRef(_seek_1__tmp_at1012_17225);
                _seek_1__tmp_at1012_17225 = NOVALUE;

                /** 						data = decompress(0)*/
                _0 = _data_17030;
                _data_17030 = _38decompress(0);
                DeRef(_0);

                /** 						puts(fn, "  data: ")*/
                EPuts(_fn_17016, _9766); // DJP 

                /** 						pretty:pretty_print(fn, data, {2, 2, 9})*/
                Ref(_data_17030);
                RefDS(_9767);
                _26pretty_print(_fn_17016, _data_17030, _9767);

                /** 						puts(fn, "\n\n")*/
                EPuts(_fn_17016, _9715); // DJP 

                /** 					end for*/
                _0 = _r_17194;
                if (IS_ATOM_INT(_r_17194)) {
                    _r_17194 = _r_17194 + 1;
                    if ((long)((unsigned long)_r_17194 +(unsigned long) HIGH_BITS) >= 0){
                        _r_17194 = NewDouble((double)_r_17194);
                    }
                }
                else {
                    _r_17194 = binary_op_a(PLUS, _r_17194, 1);
                }
                DeRef(_0);
                goto L22; // [1051] 873
L23: 
                ;
                DeRef(_r_17194);
            }
            goto L27; // [1056] 1066
L21: 

            /** 					printf(fn, "\nblock #%d (empty)\n\n", b)*/
            EPrintf(_fn_17016, _9768, _b_17172);
L27: 

            /** 			end for*/
            _b_17172 = _b_17172 + 1;
            goto L1E; // [1068] 777
L1F: 
            ;
        }
L1D: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_17021;
        if (IS_ATOM_INT(_t_header_17021)) {
            _t_header_17021 = _t_header_17021 + 16;
            if ((long)((unsigned long)_t_header_17021 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_17021 = NewDouble((double)_t_header_17021);
        }
        else {
            _t_header_17021 = NewDouble(DBL_PTR(_t_header_17021)->dbl + (double)16);
        }
        DeRef(_0);

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_17021);
        DeRef(_seek_1__tmp_at1083_17234);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _t_header_17021;
        _seek_1__tmp_at1083_17234 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_1083_17233 = machine(19, _seek_1__tmp_at1083_17234);
        DeRef(_seek_1__tmp_at1083_17234);
        _seek_1__tmp_at1083_17234 = NOVALUE;

        /** 	end for*/
        _0 = _t_17153;
        if (IS_ATOM_INT(_t_17153)) {
            _t_17153 = _t_17153 + 1;
            if ((long)((unsigned long)_t_17153 +(unsigned long) HIGH_BITS) >= 0){
                _t_17153 = NewDouble((double)_t_17153);
            }
        }
        else {
            _t_17153 = binary_op_a(PLUS, _t_17153, 1);
        }
        DeRef(_0);
        goto L19; // [1099] 685
L1A: 
        ;
        DeRef(_t_17153);
    }

    /** 	if low_level_too then printf(fn, "[free blocks:#%08x]\n", FREE_COUNT) end if*/
    if (_low_level_too_17012 == 0)
    {
        goto L28; // [1106] 1114
    }
    else{
    }
    EPrintf(_fn_17016, _9770, 7);
L28: 

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at1117_17239);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at1117_17239 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1117_17238 = machine(19, _seek_1__tmp_at1117_17239);
    DeRefi(_seek_1__tmp_at1117_17239);
    _seek_1__tmp_at1117_17239 = NOVALUE;

    /** 	n = get4()*/
    _n_17032 = _38get4();
    if (!IS_ATOM_INT(_n_17032)) {
        _1 = (long)(DBL_PTR(_n_17032)->dbl);
        DeRefDS(_n_17032);
        _n_17032 = _1;
    }

    /** 	puts(fn, '\n')*/
    EPuts(_fn_17016, 10); // DJP 

    /** 	if n > 0 then*/
    if (_n_17032 <= 0)
    goto L29; // [1145] 1234

    /** 		fbp = get4()*/
    _0 = _fbp_17028;
    _fbp_17028 = _38get4();
    DeRef(_0);

    /** 		printf(fn, "Number of Free blocks: %d ", n)*/
    EPrintf(_fn_17016, _9774, _n_17032);

    /** 		if low_level_too then printf(fn, " [#%08x]:", fbp) end if*/
    if (_low_level_too_17012 == 0)
    {
        goto L2A; // [1162] 1170
    }
    else{
    }
    EPrintf(_fn_17016, _9775, _fbp_17028);
L2A: 

    /** 		puts(fn, '\n')*/
    EPuts(_fn_17016, 10); // DJP 

    /** 		io:seek(current_db, fbp)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_fbp_17028);
    DeRef(_seek_1__tmp_at1178_17249);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _fbp_17028;
    _seek_1__tmp_at1178_17249 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1178_17248 = machine(19, _seek_1__tmp_at1178_17249);
    DeRef(_seek_1__tmp_at1178_17249);
    _seek_1__tmp_at1178_17249 = NOVALUE;

    /** 		for i = 1 to n do*/
    _9776 = _n_17032;
    {
        int _i_17251;
        _i_17251 = 1;
L2B: 
        if (_i_17251 > _9776){
            goto L2C; // [1197] 1231
        }

        /** 			addr = get4()*/
        _0 = _addr_17026;
        _addr_17026 = _38get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_17025;
        _size_17025 = _38get4();
        DeRef(_0);

        /** 			printf(fn, "%08x: %6d bytes\n", {addr, size})*/
        Ref(_size_17025);
        Ref(_addr_17026);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _addr_17026;
        ((int *)_2)[2] = _size_17025;
        _9780 = MAKE_SEQ(_1);
        EPrintf(_fn_17016, _9779, _9780);
        DeRefDS(_9780);
        _9780 = NOVALUE;

        /** 		end for*/
        _i_17251 = _i_17251 + 1;
        goto L2B; // [1226] 1204
L2C: 
        ;
    }
    goto L2D; // [1231] 1240
L29: 

    /** 		puts(fn, "No free blocks available.\n")*/
    EPuts(_fn_17016, _9781); // DJP 
L2D: 

    /** 	if sequence(file_id) then*/
    _9782 = IS_SEQUENCE(_file_id_17011);
    if (_9782 == 0)
    {
        _9782 = NOVALUE;
        goto L2E; // [1245] 1253
    }
    else{
        _9782 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_17016);
L2E: 

    /** end procedure*/
    DeRef(_file_id_17011);
    DeRef(_tables_17017);
    DeRef(_ntables_17018);
    DeRef(_tname_17019);
    DeRef(_trecords_17020);
    DeRef(_t_header_17021);
    DeRef(_tnrecs_17022);
    DeRef(_key_ptr_17023);
    DeRef(_data_ptr_17024);
    DeRef(_size_17025);
    DeRef(_addr_17026);
    DeRef(_tindex_17027);
    DeRef(_fbp_17028);
    DeRef(_key_17029);
    DeRef(_data_17030);
    DeRef(_a_17034);
    DeRef(_ll_line_17035);
    DeRef(_9707);
    _9707 = NOVALUE;
    return;
    ;
}


void  __stdcall _38check_free_list()
{
    int _msg_inlined_crash_at_273_17319 = NOVALUE;
    int _msg_inlined_crash_at_233_17312 = NOVALUE;
    int _msg_inlined_crash_at_201_17306 = NOVALUE;
    int _msg_inlined_crash_at_142_17295 = NOVALUE;
    int _msg_inlined_crash_at_87_17286 = NOVALUE;
    int _msg_inlined_crash_at_55_17280 = NOVALUE;
    int _where_inlined_where_at_25_17273 = NOVALUE;
    int _free_count_17263 = NOVALUE;
    int _free_list_17264 = NOVALUE;
    int _addr_17265 = NOVALUE;
    int _size_17266 = NOVALUE;
    int _free_list_space_17267 = NOVALUE;
    int _max_17268 = NOVALUE;
    int _9808 = NOVALUE;
    int _9807 = NOVALUE;
    int _9800 = NOVALUE;
    int _9799 = NOVALUE;
    int _9798 = NOVALUE;
    int _9796 = NOVALUE;
    int _9794 = NOVALUE;
    int _9792 = NOVALUE;
    int _9786 = NOVALUE;
    int _9783 = NOVALUE;
    int _0, _1, _2;
    

    /** 	safe_seek(-1)*/
    RefDS(_5);
    _38safe_seek(-1, _5);

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _9783 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _9783 = 1;
    }
    if (_9783 <= 0)
    goto L1; // [14] 22
    DeRef(_free_count_17263);
    DeRef(_free_list_17264);
    DeRef(_addr_17265);
    DeRef(_size_17266);
    DeRef(_free_list_space_17267);
    DeRef(_max_17268);
    return;
L1: 

    /** 	max = io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_max_17268);
    _max_17268 = machine(20, _38current_db_16699);

    /** 	safe_seek( FREE_COUNT)*/
    RefDS(_5);
    _38safe_seek(7, _5);

    /** 	free_count = get4()*/
    _0 = _free_count_17263;
    _free_count_17263 = _38get4();
    DeRef(_0);

    /** 	if free_count > max/13 then*/
    if (IS_ATOM_INT(_max_17268)) {
        _9786 = (_max_17268 % 13) ? NewDouble((double)_max_17268 / 13) : (_max_17268 / 13);
    }
    else {
        _9786 = NewDouble(DBL_PTR(_max_17268)->dbl / (double)13);
    }
    if (binary_op_a(LESSEQ, _free_count_17263, _9786)){
        DeRef(_9786);
        _9786 = NOVALUE;
        goto L2; // [50] 75
    }
    DeRef(_9786);
    _9786 = NOVALUE;

    /** 		error:crash("free count is too high")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_55_17280);
    _msg_inlined_crash_at_55_17280 = EPrintf(-9999999, _9788, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_55_17280);

    /** end procedure*/
    goto L3; // [69] 72
L3: 
    DeRefi(_msg_inlined_crash_at_55_17280);
    _msg_inlined_crash_at_55_17280 = NOVALUE;
L2: 

    /** 	free_list = get4()*/
    _0 = _free_list_17264;
    _free_list_17264 = _38get4();
    DeRef(_0);

    /** 	if free_list > max then*/
    if (binary_op_a(LESSEQ, _free_list_17264, _max_17268)){
        goto L4; // [82] 107
    }

    /** 		error:crash("bad free list pointer")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_87_17286);
    _msg_inlined_crash_at_87_17286 = EPrintf(-9999999, _9791, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_87_17286);

    /** end procedure*/
    goto L5; // [101] 104
L5: 
    DeRefi(_msg_inlined_crash_at_87_17286);
    _msg_inlined_crash_at_87_17286 = NOVALUE;
L4: 

    /** 	safe_seek( free_list - 4)*/
    if (IS_ATOM_INT(_free_list_17264)) {
        _9792 = _free_list_17264 - 4;
        if ((long)((unsigned long)_9792 +(unsigned long) HIGH_BITS) >= 0){
            _9792 = NewDouble((double)_9792);
        }
    }
    else {
        _9792 = NewDouble(DBL_PTR(_free_list_17264)->dbl - (double)4);
    }
    RefDS(_5);
    _38safe_seek(_9792, _5);
    _9792 = NOVALUE;

    /** 	free_list_space = get4()*/
    _0 = _free_list_space_17267;
    _free_list_space_17267 = _38get4();
    DeRef(_0);

    /** 	if free_list_space > max or free_list_space < 0 then*/
    if (IS_ATOM_INT(_free_list_space_17267) && IS_ATOM_INT(_max_17268)) {
        _9794 = (_free_list_space_17267 > _max_17268);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_17267)) {
            _9794 = ((double)_free_list_space_17267 > DBL_PTR(_max_17268)->dbl);
        }
        else {
            if (IS_ATOM_INT(_max_17268)) {
                _9794 = (DBL_PTR(_free_list_space_17267)->dbl > (double)_max_17268);
            }
            else
            _9794 = (DBL_PTR(_free_list_space_17267)->dbl > DBL_PTR(_max_17268)->dbl);
        }
    }
    if (_9794 != 0) {
        goto L6; // [128] 141
    }
    if (IS_ATOM_INT(_free_list_space_17267)) {
        _9796 = (_free_list_space_17267 < 0);
    }
    else {
        _9796 = (DBL_PTR(_free_list_space_17267)->dbl < (double)0);
    }
    if (_9796 == 0)
    {
        DeRef(_9796);
        _9796 = NOVALUE;
        goto L7; // [137] 162
    }
    else{
        DeRef(_9796);
        _9796 = NOVALUE;
    }
L6: 

    /** 		error:crash("free list space is bad")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_142_17295);
    _msg_inlined_crash_at_142_17295 = EPrintf(-9999999, _9797, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_142_17295);

    /** end procedure*/
    goto L8; // [156] 159
L8: 
    DeRefi(_msg_inlined_crash_at_142_17295);
    _msg_inlined_crash_at_142_17295 = NOVALUE;
L7: 

    /** 	for i = 0 to free_count - 1 do*/
    if (IS_ATOM_INT(_free_count_17263)) {
        _9798 = _free_count_17263 - 1;
        if ((long)((unsigned long)_9798 +(unsigned long) HIGH_BITS) >= 0){
            _9798 = NewDouble((double)_9798);
        }
    }
    else {
        _9798 = NewDouble(DBL_PTR(_free_count_17263)->dbl - (double)1);
    }
    {
        int _i_17297;
        _i_17297 = 0;
L9: 
        if (binary_op_a(GREATER, _i_17297, _9798)){
            goto LA; // [168] 300
        }

        /** 		safe_seek( free_list + i * 8)*/
        if (IS_ATOM_INT(_i_17297)) {
            if (_i_17297 == (short)_i_17297)
            _9799 = _i_17297 * 8;
            else
            _9799 = NewDouble(_i_17297 * (double)8);
        }
        else {
            _9799 = NewDouble(DBL_PTR(_i_17297)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_free_list_17264) && IS_ATOM_INT(_9799)) {
            _9800 = _free_list_17264 + _9799;
            if ((long)((unsigned long)_9800 + (unsigned long)HIGH_BITS) >= 0) 
            _9800 = NewDouble((double)_9800);
        }
        else {
            if (IS_ATOM_INT(_free_list_17264)) {
                _9800 = NewDouble((double)_free_list_17264 + DBL_PTR(_9799)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9799)) {
                    _9800 = NewDouble(DBL_PTR(_free_list_17264)->dbl + (double)_9799);
                }
                else
                _9800 = NewDouble(DBL_PTR(_free_list_17264)->dbl + DBL_PTR(_9799)->dbl);
            }
        }
        DeRef(_9799);
        _9799 = NOVALUE;
        RefDS(_5);
        _38safe_seek(_9800, _5);
        _9800 = NOVALUE;

        /** 		addr = get4()*/
        _0 = _addr_17265;
        _addr_17265 = _38get4();
        DeRef(_0);

        /** 		if addr > max then*/
        if (binary_op_a(LESSEQ, _addr_17265, _max_17268)){
            goto LB; // [196] 221
        }

        /** 			error:crash("bad block address")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_201_17306);
        _msg_inlined_crash_at_201_17306 = EPrintf(-9999999, _9803, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_201_17306);

        /** end procedure*/
        goto LC; // [215] 218
LC: 
        DeRefi(_msg_inlined_crash_at_201_17306);
        _msg_inlined_crash_at_201_17306 = NOVALUE;
LB: 

        /** 		size = get4()*/
        _0 = _size_17266;
        _size_17266 = _38get4();
        DeRef(_0);

        /** 		if size > max then*/
        if (binary_op_a(LESSEQ, _size_17266, _max_17268)){
            goto LD; // [228] 253
        }

        /** 			error:crash("block size too big")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_233_17312);
        _msg_inlined_crash_at_233_17312 = EPrintf(-9999999, _9806, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_233_17312);

        /** end procedure*/
        goto LE; // [247] 250
LE: 
        DeRefi(_msg_inlined_crash_at_233_17312);
        _msg_inlined_crash_at_233_17312 = NOVALUE;
LD: 

        /** 		safe_seek( addr - 4)*/
        if (IS_ATOM_INT(_addr_17265)) {
            _9807 = _addr_17265 - 4;
            if ((long)((unsigned long)_9807 +(unsigned long) HIGH_BITS) >= 0){
                _9807 = NewDouble((double)_9807);
            }
        }
        else {
            _9807 = NewDouble(DBL_PTR(_addr_17265)->dbl - (double)4);
        }
        RefDS(_5);
        _38safe_seek(_9807, _5);
        _9807 = NOVALUE;

        /** 		if get4() > size then*/
        _9808 = _38get4();
        if (binary_op_a(LESSEQ, _9808, _size_17266)){
            DeRef(_9808);
            _9808 = NOVALUE;
            goto LF; // [268] 293
        }
        DeRef(_9808);
        _9808 = NOVALUE;

        /** 			error:crash("bad size in front of free block")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_273_17319);
        _msg_inlined_crash_at_273_17319 = EPrintf(-9999999, _9810, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_273_17319);

        /** end procedure*/
        goto L10; // [287] 290
L10: 
        DeRefi(_msg_inlined_crash_at_273_17319);
        _msg_inlined_crash_at_273_17319 = NOVALUE;
LF: 

        /** 	end for*/
        _0 = _i_17297;
        if (IS_ATOM_INT(_i_17297)) {
            _i_17297 = _i_17297 + 1;
            if ((long)((unsigned long)_i_17297 +(unsigned long) HIGH_BITS) >= 0){
                _i_17297 = NewDouble((double)_i_17297);
            }
        }
        else {
            _i_17297 = binary_op_a(PLUS, _i_17297, 1);
        }
        DeRef(_0);
        goto L9; // [295] 175
LA: 
        ;
        DeRef(_i_17297);
    }

    /** end procedure*/
    DeRef(_free_count_17263);
    DeRef(_free_list_17264);
    DeRef(_addr_17265);
    DeRef(_size_17266);
    DeRef(_free_list_space_17267);
    DeRef(_max_17268);
    DeRef(_9794);
    _9794 = NOVALUE;
    DeRef(_9798);
    _9798 = NOVALUE;
    return;
    ;
}


int _38db_allocate(int _n_17322)
{
    int _free_list_17323 = NOVALUE;
    int _size_17324 = NOVALUE;
    int _size_ptr_17325 = NOVALUE;
    int _addr_17326 = NOVALUE;
    int _free_count_17327 = NOVALUE;
    int _remaining_17328 = NOVALUE;
    int _seek_1__tmp_at4_17331 = NOVALUE;
    int _seek_inlined_seek_at_4_17330 = NOVALUE;
    int _seek_1__tmp_at39_17338 = NOVALUE;
    int _seek_inlined_seek_at_39_17337 = NOVALUE;
    int _seek_1__tmp_at111_17355 = NOVALUE;
    int _seek_inlined_seek_at_111_17354 = NOVALUE;
    int _pos_inlined_seek_at_108_17353 = NOVALUE;
    int _put4_1__tmp_at137_17360 = NOVALUE;
    int _x_inlined_put4_at_134_17359 = NOVALUE;
    int _seek_1__tmp_at167_17363 = NOVALUE;
    int _seek_inlined_seek_at_167_17362 = NOVALUE;
    int _put4_1__tmp_at193_17368 = NOVALUE;
    int _x_inlined_put4_at_190_17367 = NOVALUE;
    int _seek_1__tmp_at244_17376 = NOVALUE;
    int _seek_inlined_seek_at_244_17375 = NOVALUE;
    int _pos_inlined_seek_at_241_17374 = NOVALUE;
    int _put4_1__tmp_at266_17380 = NOVALUE;
    int _x_inlined_put4_at_263_17379 = NOVALUE;
    int _seek_1__tmp_at333_17391 = NOVALUE;
    int _seek_inlined_seek_at_333_17390 = NOVALUE;
    int _pos_inlined_seek_at_330_17389 = NOVALUE;
    int _seek_1__tmp_at364_17395 = NOVALUE;
    int _seek_inlined_seek_at_364_17394 = NOVALUE;
    int _put4_1__tmp_at386_17399 = NOVALUE;
    int _x_inlined_put4_at_383_17398 = NOVALUE;
    int _seek_1__tmp_at423_17404 = NOVALUE;
    int _seek_inlined_seek_at_423_17403 = NOVALUE;
    int _pos_inlined_seek_at_420_17402 = NOVALUE;
    int _put4_1__tmp_at438_17406 = NOVALUE;
    int _seek_1__tmp_at490_17410 = NOVALUE;
    int _seek_inlined_seek_at_490_17409 = NOVALUE;
    int _put4_1__tmp_at512_17414 = NOVALUE;
    int _x_inlined_put4_at_509_17413 = NOVALUE;
    int _where_inlined_where_at_542_17416 = NOVALUE;
    int _9841 = NOVALUE;
    int _9839 = NOVALUE;
    int _9838 = NOVALUE;
    int _9837 = NOVALUE;
    int _9836 = NOVALUE;
    int _9835 = NOVALUE;
    int _9833 = NOVALUE;
    int _9832 = NOVALUE;
    int _9831 = NOVALUE;
    int _9830 = NOVALUE;
    int _9828 = NOVALUE;
    int _9827 = NOVALUE;
    int _9826 = NOVALUE;
    int _9825 = NOVALUE;
    int _9824 = NOVALUE;
    int _9823 = NOVALUE;
    int _9822 = NOVALUE;
    int _9820 = NOVALUE;
    int _9818 = NOVALUE;
    int _9815 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17331);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_17331 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17330 = machine(19, _seek_1__tmp_at4_17331);
    DeRefi(_seek_1__tmp_at4_17331);
    _seek_1__tmp_at4_17331 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17327 = _38get4();
    if (!IS_ATOM_INT(_free_count_17327)) {
        _1 = (long)(DBL_PTR(_free_count_17327)->dbl);
        DeRefDS(_free_count_17327);
        _free_count_17327 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_17327 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_17323;
    _free_list_17323 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17323);
    DeRef(_seek_1__tmp_at39_17338);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _free_list_17323;
    _seek_1__tmp_at39_17338 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_17337 = machine(19, _seek_1__tmp_at39_17338);
    DeRef(_seek_1__tmp_at39_17338);
    _seek_1__tmp_at39_17338 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_17325);
    if (IS_ATOM_INT(_free_list_17323)) {
        _size_ptr_17325 = _free_list_17323 + 4;
        if ((long)((unsigned long)_size_ptr_17325 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_17325 = NewDouble((double)_size_ptr_17325);
    }
    else {
        _size_ptr_17325 = NewDouble(DBL_PTR(_free_list_17323)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _9815 = _free_count_17327;
    {
        int _i_17341;
        _i_17341 = 1;
L2: 
        if (_i_17341 > _9815){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_17326;
        _addr_17326 = _38get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_17324;
        _size_17324 = _38get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_17322)) {
            _9818 = _n_17322 + 4;
            if ((long)((unsigned long)_9818 + (unsigned long)HIGH_BITS) >= 0) 
            _9818 = NewDouble((double)_9818);
        }
        else {
            _9818 = NewDouble(DBL_PTR(_n_17322)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_17324, _9818)){
            DeRef(_9818);
            _9818 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_9818);
        _9818 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_17322)) {
            _9820 = _n_17322 + 16;
            if ((long)((unsigned long)_9820 + (unsigned long)HIGH_BITS) >= 0) 
            _9820 = NewDouble((double)_9820);
        }
        else {
            _9820 = NewDouble(DBL_PTR(_n_17322)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_17324, _9820)){
            DeRef(_9820);
            _9820 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_9820);
        _9820 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17326)) {
            _9822 = _addr_17326 - 4;
            if ((long)((unsigned long)_9822 +(unsigned long) HIGH_BITS) >= 0){
                _9822 = NewDouble((double)_9822);
            }
        }
        else {
            _9822 = NewDouble(DBL_PTR(_addr_17326)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_17353);
        _pos_inlined_seek_at_108_17353 = _9822;
        _9822 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_17353);
        DeRef(_seek_1__tmp_at111_17355);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_17353;
        _seek_1__tmp_at111_17355 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_17354 = machine(19, _seek_1__tmp_at111_17355);
        DeRef(_pos_inlined_seek_at_108_17353);
        _pos_inlined_seek_at_108_17353 = NOVALUE;
        DeRef(_seek_1__tmp_at111_17355);
        _seek_1__tmp_at111_17355 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_17324) && IS_ATOM_INT(_n_17322)) {
            _9823 = _size_17324 - _n_17322;
            if ((long)((unsigned long)_9823 +(unsigned long) HIGH_BITS) >= 0){
                _9823 = NewDouble((double)_9823);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17324)) {
                _9823 = NewDouble((double)_size_17324 - DBL_PTR(_n_17322)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17322)) {
                    _9823 = NewDouble(DBL_PTR(_size_17324)->dbl - (double)_n_17322);
                }
                else
                _9823 = NewDouble(DBL_PTR(_size_17324)->dbl - DBL_PTR(_n_17322)->dbl);
            }
        }
        if (IS_ATOM_INT(_9823)) {
            _9824 = _9823 - 4;
            if ((long)((unsigned long)_9824 +(unsigned long) HIGH_BITS) >= 0){
                _9824 = NewDouble((double)_9824);
            }
        }
        else {
            _9824 = NewDouble(DBL_PTR(_9823)->dbl - (double)4);
        }
        DeRef(_9823);
        _9823 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_17359);
        _x_inlined_put4_at_134_17359 = _9824;
        _9824 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_17359)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_17359;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_17359)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_17360);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_17360 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at137_17360); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_17359);
        _x_inlined_put4_at_134_17359 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_17360);
        _put4_1__tmp_at137_17360 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_17325);
        DeRef(_seek_1__tmp_at167_17363);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _size_ptr_17325;
        _seek_1__tmp_at167_17363 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_17362 = machine(19, _seek_1__tmp_at167_17363);
        DeRef(_seek_1__tmp_at167_17363);
        _seek_1__tmp_at167_17363 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_17324) && IS_ATOM_INT(_n_17322)) {
            _9825 = _size_17324 - _n_17322;
            if ((long)((unsigned long)_9825 +(unsigned long) HIGH_BITS) >= 0){
                _9825 = NewDouble((double)_9825);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17324)) {
                _9825 = NewDouble((double)_size_17324 - DBL_PTR(_n_17322)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17322)) {
                    _9825 = NewDouble(DBL_PTR(_size_17324)->dbl - (double)_n_17322);
                }
                else
                _9825 = NewDouble(DBL_PTR(_size_17324)->dbl - DBL_PTR(_n_17322)->dbl);
            }
        }
        if (IS_ATOM_INT(_9825)) {
            _9826 = _9825 - 4;
            if ((long)((unsigned long)_9826 +(unsigned long) HIGH_BITS) >= 0){
                _9826 = NewDouble((double)_9826);
            }
        }
        else {
            _9826 = NewDouble(DBL_PTR(_9825)->dbl - (double)4);
        }
        DeRef(_9825);
        _9825 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_17367);
        _x_inlined_put4_at_190_17367 = _9826;
        _9826 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_17367)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_17367;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_17367)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_17368);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_17368 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at193_17368); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_17367);
        _x_inlined_put4_at_190_17367 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_17368);
        _put4_1__tmp_at193_17368 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_17324) && IS_ATOM_INT(_n_17322)) {
            _9827 = _size_17324 - _n_17322;
            if ((long)((unsigned long)_9827 +(unsigned long) HIGH_BITS) >= 0){
                _9827 = NewDouble((double)_9827);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17324)) {
                _9827 = NewDouble((double)_size_17324 - DBL_PTR(_n_17322)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17322)) {
                    _9827 = NewDouble(DBL_PTR(_size_17324)->dbl - (double)_n_17322);
                }
                else
                _9827 = NewDouble(DBL_PTR(_size_17324)->dbl - DBL_PTR(_n_17322)->dbl);
            }
        }
        if (IS_ATOM_INT(_9827)) {
            _9828 = _9827 - 4;
            if ((long)((unsigned long)_9828 +(unsigned long) HIGH_BITS) >= 0){
                _9828 = NewDouble((double)_9828);
            }
        }
        else {
            _9828 = NewDouble(DBL_PTR(_9827)->dbl - (double)4);
        }
        DeRef(_9827);
        _9827 = NOVALUE;
        _0 = _addr_17326;
        if (IS_ATOM_INT(_addr_17326) && IS_ATOM_INT(_9828)) {
            _addr_17326 = _addr_17326 + _9828;
            if ((long)((unsigned long)_addr_17326 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_17326 = NewDouble((double)_addr_17326);
        }
        else {
            if (IS_ATOM_INT(_addr_17326)) {
                _addr_17326 = NewDouble((double)_addr_17326 + DBL_PTR(_9828)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9828)) {
                    _addr_17326 = NewDouble(DBL_PTR(_addr_17326)->dbl + (double)_9828);
                }
                else
                _addr_17326 = NewDouble(DBL_PTR(_addr_17326)->dbl + DBL_PTR(_9828)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_9828);
        _9828 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_17326)) {
            _9830 = _addr_17326 - 4;
            if ((long)((unsigned long)_9830 +(unsigned long) HIGH_BITS) >= 0){
                _9830 = NewDouble((double)_9830);
            }
        }
        else {
            _9830 = NewDouble(DBL_PTR(_addr_17326)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_17374);
        _pos_inlined_seek_at_241_17374 = _9830;
        _9830 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_17374);
        DeRef(_seek_1__tmp_at244_17376);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_17374;
        _seek_1__tmp_at244_17376 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_17375 = machine(19, _seek_1__tmp_at244_17376);
        DeRef(_pos_inlined_seek_at_241_17374);
        _pos_inlined_seek_at_241_17374 = NOVALUE;
        DeRef(_seek_1__tmp_at244_17376);
        _seek_1__tmp_at244_17376 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_17322)) {
            _9831 = _n_17322 + 4;
            if ((long)((unsigned long)_9831 + (unsigned long)HIGH_BITS) >= 0) 
            _9831 = NewDouble((double)_9831);
        }
        else {
            _9831 = NewDouble(DBL_PTR(_n_17322)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_17379);
        _x_inlined_put4_at_263_17379 = _9831;
        _9831 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_17379)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_17379;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_17379)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_17380);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_17380 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at266_17380); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_17379);
        _x_inlined_put4_at_263_17379 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_17380);
        _put4_1__tmp_at266_17380 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _9832 = _free_count_17327 - _i_17341;
        if ((long)((unsigned long)_9832 +(unsigned long) HIGH_BITS) >= 0){
            _9832 = NewDouble((double)_9832);
        }
        if (IS_ATOM_INT(_9832)) {
            if (_9832 == (short)_9832)
            _9833 = _9832 * 8;
            else
            _9833 = NewDouble(_9832 * (double)8);
        }
        else {
            _9833 = NewDouble(DBL_PTR(_9832)->dbl * (double)8);
        }
        DeRef(_9832);
        _9832 = NOVALUE;
        _0 = _remaining_17328;
        _remaining_17328 = _18get_bytes(_38current_db_16699, _9833);
        DeRef(_0);
        _9833 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _9835 = _i_17341 - 1;
        if (_9835 <= INT15)
        _9836 = 8 * _9835;
        else
        _9836 = NewDouble(8 * (double)_9835);
        _9835 = NOVALUE;
        if (IS_ATOM_INT(_free_list_17323) && IS_ATOM_INT(_9836)) {
            _9837 = _free_list_17323 + _9836;
            if ((long)((unsigned long)_9837 + (unsigned long)HIGH_BITS) >= 0) 
            _9837 = NewDouble((double)_9837);
        }
        else {
            if (IS_ATOM_INT(_free_list_17323)) {
                _9837 = NewDouble((double)_free_list_17323 + DBL_PTR(_9836)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9836)) {
                    _9837 = NewDouble(DBL_PTR(_free_list_17323)->dbl + (double)_9836);
                }
                else
                _9837 = NewDouble(DBL_PTR(_free_list_17323)->dbl + DBL_PTR(_9836)->dbl);
            }
        }
        DeRef(_9836);
        _9836 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_17389);
        _pos_inlined_seek_at_330_17389 = _9837;
        _9837 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_17389);
        DeRef(_seek_1__tmp_at333_17391);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_17389;
        _seek_1__tmp_at333_17391 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_17390 = machine(19, _seek_1__tmp_at333_17391);
        DeRef(_pos_inlined_seek_at_330_17389);
        _pos_inlined_seek_at_330_17389 = NOVALUE;
        DeRef(_seek_1__tmp_at333_17391);
        _seek_1__tmp_at333_17391 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_38current_db_16699, _remaining_17328); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_17395);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_17395 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_17394 = machine(19, _seek_1__tmp_at364_17395);
        DeRefi(_seek_1__tmp_at364_17395);
        _seek_1__tmp_at364_17395 = NOVALUE;

        /** 					put4(free_count-1)*/
        _9838 = _free_count_17327 - 1;
        if ((long)((unsigned long)_9838 +(unsigned long) HIGH_BITS) >= 0){
            _9838 = NewDouble((double)_9838);
        }
        DeRef(_x_inlined_put4_at_383_17398);
        _x_inlined_put4_at_383_17398 = _9838;
        _9838 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_17398)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_17398;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_17398)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_17399);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_17399 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at386_17399); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_17398);
        _x_inlined_put4_at_383_17398 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_17399);
        _put4_1__tmp_at386_17399 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17326)) {
            _9839 = _addr_17326 - 4;
            if ((long)((unsigned long)_9839 +(unsigned long) HIGH_BITS) >= 0){
                _9839 = NewDouble((double)_9839);
            }
        }
        else {
            _9839 = NewDouble(DBL_PTR(_addr_17326)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_17402);
        _pos_inlined_seek_at_420_17402 = _9839;
        _9839 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_17402);
        DeRef(_seek_1__tmp_at423_17404);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_17402;
        _seek_1__tmp_at423_17404 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_17403 = machine(19, _seek_1__tmp_at423_17404);
        DeRef(_pos_inlined_seek_at_420_17402);
        _pos_inlined_seek_at_420_17402 = NOVALUE;
        DeRef(_seek_1__tmp_at423_17404);
        _seek_1__tmp_at423_17404 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_size_17324)) {
            *poke4_addr = (unsigned long)_size_17324;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_17324)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_17406);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_17406 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at438_17406); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_17406);
        _put4_1__tmp_at438_17406 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_17322);
        DeRef(_free_list_17323);
        DeRef(_size_17324);
        DeRef(_size_ptr_17325);
        DeRef(_remaining_17328);
        return _addr_17326;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_17325;
        if (IS_ATOM_INT(_size_ptr_17325)) {
            _size_ptr_17325 = _size_ptr_17325 + 8;
            if ((long)((unsigned long)_size_ptr_17325 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_17325 = NewDouble((double)_size_ptr_17325);
        }
        else {
            _size_ptr_17325 = NewDouble(DBL_PTR(_size_ptr_17325)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_17341 = _i_17341 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_17410);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_17410 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_17409 = machine(19, _seek_1__tmp_at490_17410);
    DeRefi(_seek_1__tmp_at490_17410);
    _seek_1__tmp_at490_17410 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_17322)) {
        _9841 = _n_17322 + 4;
        if ((long)((unsigned long)_9841 + (unsigned long)HIGH_BITS) >= 0) 
        _9841 = NewDouble((double)_9841);
    }
    else {
        _9841 = NewDouble(DBL_PTR(_n_17322)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_17413);
    _x_inlined_put4_at_509_17413 = _9841;
    _9841 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_17413)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_17413;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_17413)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_17414);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_17414 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at512_17414); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_17413);
    _x_inlined_put4_at_509_17413 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_17414);
    _put4_1__tmp_at512_17414 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_17416);
    _where_inlined_where_at_542_17416 = machine(20, _38current_db_16699);
    DeRef(_n_17322);
    DeRef(_free_list_17323);
    DeRef(_size_17324);
    DeRef(_size_ptr_17325);
    DeRef(_addr_17326);
    DeRef(_remaining_17328);
    return _where_inlined_where_at_542_17416;
    ;
}


void _38db_free(int _p_17419)
{
    int _psize_17420 = NOVALUE;
    int _i_17421 = NOVALUE;
    int _size_17422 = NOVALUE;
    int _addr_17423 = NOVALUE;
    int _free_list_17424 = NOVALUE;
    int _free_list_space_17425 = NOVALUE;
    int _new_space_17426 = NOVALUE;
    int _to_be_freed_17427 = NOVALUE;
    int _prev_addr_17428 = NOVALUE;
    int _prev_size_17429 = NOVALUE;
    int _free_count_17430 = NOVALUE;
    int _remaining_17431 = NOVALUE;
    int _seek_1__tmp_at11_17436 = NOVALUE;
    int _seek_inlined_seek_at_11_17435 = NOVALUE;
    int _pos_inlined_seek_at_8_17434 = NOVALUE;
    int _seek_1__tmp_at33_17440 = NOVALUE;
    int _seek_inlined_seek_at_33_17439 = NOVALUE;
    int _seek_1__tmp_at69_17447 = NOVALUE;
    int _seek_inlined_seek_at_69_17446 = NOVALUE;
    int _pos_inlined_seek_at_66_17445 = NOVALUE;
    int _seek_1__tmp_at133_17460 = NOVALUE;
    int _seek_inlined_seek_at_133_17459 = NOVALUE;
    int _seek_1__tmp_at157_17464 = NOVALUE;
    int _seek_inlined_seek_at_157_17463 = NOVALUE;
    int _put4_1__tmp_at172_17466 = NOVALUE;
    int _seek_1__tmp_at202_17469 = NOVALUE;
    int _seek_inlined_seek_at_202_17468 = NOVALUE;
    int _seek_1__tmp_at234_17474 = NOVALUE;
    int _seek_inlined_seek_at_234_17473 = NOVALUE;
    int _s_inlined_putn_at_274_17480 = NOVALUE;
    int _seek_1__tmp_at297_17483 = NOVALUE;
    int _seek_inlined_seek_at_297_17482 = NOVALUE;
    int _seek_1__tmp_at430_17504 = NOVALUE;
    int _seek_inlined_seek_at_430_17503 = NOVALUE;
    int _pos_inlined_seek_at_427_17502 = NOVALUE;
    int _put4_1__tmp_at482_17514 = NOVALUE;
    int _x_inlined_put4_at_479_17513 = NOVALUE;
    int _seek_1__tmp_at523_17520 = NOVALUE;
    int _seek_inlined_seek_at_523_17519 = NOVALUE;
    int _pos_inlined_seek_at_520_17518 = NOVALUE;
    int _seek_1__tmp_at574_17530 = NOVALUE;
    int _seek_inlined_seek_at_574_17529 = NOVALUE;
    int _pos_inlined_seek_at_571_17528 = NOVALUE;
    int _seek_1__tmp_at611_17535 = NOVALUE;
    int _seek_inlined_seek_at_611_17534 = NOVALUE;
    int _put4_1__tmp_at626_17537 = NOVALUE;
    int _put4_1__tmp_at664_17542 = NOVALUE;
    int _x_inlined_put4_at_661_17541 = NOVALUE;
    int _seek_1__tmp_at737_17554 = NOVALUE;
    int _seek_inlined_seek_at_737_17553 = NOVALUE;
    int _pos_inlined_seek_at_734_17552 = NOVALUE;
    int _put4_1__tmp_at752_17556 = NOVALUE;
    int _put4_1__tmp_at789_17560 = NOVALUE;
    int _x_inlined_put4_at_786_17559 = NOVALUE;
    int _seek_1__tmp_at837_17568 = NOVALUE;
    int _seek_inlined_seek_at_837_17567 = NOVALUE;
    int _pos_inlined_seek_at_834_17566 = NOVALUE;
    int _seek_1__tmp_at883_17576 = NOVALUE;
    int _seek_inlined_seek_at_883_17575 = NOVALUE;
    int _put4_1__tmp_at898_17578 = NOVALUE;
    int _seek_1__tmp_at943_17585 = NOVALUE;
    int _seek_inlined_seek_at_943_17584 = NOVALUE;
    int _pos_inlined_seek_at_940_17583 = NOVALUE;
    int _put4_1__tmp_at958_17587 = NOVALUE;
    int _put4_1__tmp_at986_17589 = NOVALUE;
    int _9909 = NOVALUE;
    int _9908 = NOVALUE;
    int _9907 = NOVALUE;
    int _9904 = NOVALUE;
    int _9903 = NOVALUE;
    int _9902 = NOVALUE;
    int _9901 = NOVALUE;
    int _9900 = NOVALUE;
    int _9899 = NOVALUE;
    int _9898 = NOVALUE;
    int _9897 = NOVALUE;
    int _9896 = NOVALUE;
    int _9895 = NOVALUE;
    int _9894 = NOVALUE;
    int _9893 = NOVALUE;
    int _9892 = NOVALUE;
    int _9891 = NOVALUE;
    int _9890 = NOVALUE;
    int _9888 = NOVALUE;
    int _9887 = NOVALUE;
    int _9886 = NOVALUE;
    int _9884 = NOVALUE;
    int _9883 = NOVALUE;
    int _9882 = NOVALUE;
    int _9881 = NOVALUE;
    int _9880 = NOVALUE;
    int _9879 = NOVALUE;
    int _9878 = NOVALUE;
    int _9877 = NOVALUE;
    int _9876 = NOVALUE;
    int _9875 = NOVALUE;
    int _9874 = NOVALUE;
    int _9873 = NOVALUE;
    int _9872 = NOVALUE;
    int _9871 = NOVALUE;
    int _9870 = NOVALUE;
    int _9869 = NOVALUE;
    int _9868 = NOVALUE;
    int _9867 = NOVALUE;
    int _9861 = NOVALUE;
    int _9860 = NOVALUE;
    int _9859 = NOVALUE;
    int _9857 = NOVALUE;
    int _9853 = NOVALUE;
    int _9852 = NOVALUE;
    int _9850 = NOVALUE;
    int _9849 = NOVALUE;
    int _9847 = NOVALUE;
    int _9846 = NOVALUE;
    int _9842 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_17419)) {
        _9842 = _p_17419 - 4;
        if ((long)((unsigned long)_9842 +(unsigned long) HIGH_BITS) >= 0){
            _9842 = NewDouble((double)_9842);
        }
    }
    else {
        _9842 = NewDouble(DBL_PTR(_p_17419)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_17434);
    _pos_inlined_seek_at_8_17434 = _9842;
    _9842 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17434);
    DeRef(_seek_1__tmp_at11_17436);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_17434;
    _seek_1__tmp_at11_17436 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17435 = machine(19, _seek_1__tmp_at11_17436);
    DeRef(_pos_inlined_seek_at_8_17434);
    _pos_inlined_seek_at_8_17434 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17436);
    _seek_1__tmp_at11_17436 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_17420;
    _psize_17420 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_17440);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_17440 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_17439 = machine(19, _seek_1__tmp_at33_17440);
    DeRefi(_seek_1__tmp_at33_17440);
    _seek_1__tmp_at33_17440 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17430 = _38get4();
    if (!IS_ATOM_INT(_free_count_17430)) {
        _1 = (long)(DBL_PTR(_free_count_17430)->dbl);
        DeRefDS(_free_count_17430);
        _free_count_17430 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_17424;
    _free_list_17424 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_17424)) {
        _9846 = _free_list_17424 - 4;
        if ((long)((unsigned long)_9846 +(unsigned long) HIGH_BITS) >= 0){
            _9846 = NewDouble((double)_9846);
        }
    }
    else {
        _9846 = NewDouble(DBL_PTR(_free_list_17424)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_17445);
    _pos_inlined_seek_at_66_17445 = _9846;
    _9846 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_17445);
    DeRef(_seek_1__tmp_at69_17447);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_17445;
    _seek_1__tmp_at69_17447 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_17446 = machine(19, _seek_1__tmp_at69_17447);
    DeRef(_pos_inlined_seek_at_66_17445);
    _pos_inlined_seek_at_66_17445 = NOVALUE;
    DeRef(_seek_1__tmp_at69_17447);
    _seek_1__tmp_at69_17447 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _9847 = _38get4();
    DeRef(_free_list_space_17425);
    if (IS_ATOM_INT(_9847)) {
        _free_list_space_17425 = _9847 - 4;
        if ((long)((unsigned long)_free_list_space_17425 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_17425 = NewDouble((double)_free_list_space_17425);
        }
    }
    else {
        _free_list_space_17425 = binary_op(MINUS, _9847, 4);
    }
    DeRef(_9847);
    _9847 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _9849 = _free_count_17430 + 1;
    if (_9849 > MAXINT){
        _9849 = NewDouble((double)_9849);
    }
    if (IS_ATOM_INT(_9849)) {
        if (_9849 <= INT15 && _9849 >= -INT15)
        _9850 = 8 * _9849;
        else
        _9850 = NewDouble(8 * (double)_9849);
    }
    else {
        _9850 = NewDouble((double)8 * DBL_PTR(_9849)->dbl);
    }
    DeRef(_9849);
    _9849 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_17425, _9850)){
        DeRef(_9850);
        _9850 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_9850);
    _9850 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_17425)) {
        if (_free_list_space_17425 & 1) {
            _9852 = NewDouble((_free_list_space_17425 >> 1) + 0.5);
        }
        else
        _9852 = _free_list_space_17425 >> 1;
    }
    else {
        _9852 = binary_op(DIVIDE, _free_list_space_17425, 2);
    }
    if (IS_ATOM_INT(_free_list_space_17425) && IS_ATOM_INT(_9852)) {
        _9853 = _free_list_space_17425 + _9852;
        if ((long)((unsigned long)_9853 + (unsigned long)HIGH_BITS) >= 0) 
        _9853 = NewDouble((double)_9853);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_17425)) {
            _9853 = NewDouble((double)_free_list_space_17425 + DBL_PTR(_9852)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9852)) {
                _9853 = NewDouble(DBL_PTR(_free_list_space_17425)->dbl + (double)_9852);
            }
            else
            _9853 = NewDouble(DBL_PTR(_free_list_space_17425)->dbl + DBL_PTR(_9852)->dbl);
        }
    }
    DeRef(_9852);
    _9852 = NOVALUE;
    DeRef(_new_space_17426);
    if (IS_ATOM_INT(_9853))
    _new_space_17426 = e_floor(_9853);
    else
    _new_space_17426 = unary_op(FLOOR, _9853);
    DeRef(_9853);
    _9853 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_17424);
    DeRef(_to_be_freed_17427);
    _to_be_freed_17427 = _free_list_17424;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_17426);
    _0 = _free_list_17424;
    _free_list_17424 = _38db_allocate(_new_space_17426);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_17460);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_17460 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_17459 = machine(19, _seek_1__tmp_at133_17460);
    DeRefi(_seek_1__tmp_at133_17460);
    _seek_1__tmp_at133_17460 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_17430 = _38get4();
    if (!IS_ATOM_INT(_free_count_17430)) {
        _1 = (long)(DBL_PTR(_free_count_17430)->dbl);
        DeRefDS(_free_count_17430);
        _free_count_17430 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_17464);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_17464 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_17463 = machine(19, _seek_1__tmp_at157_17464);
    DeRefi(_seek_1__tmp_at157_17464);
    _seek_1__tmp_at157_17464 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_free_list_17424)) {
        *poke4_addr = (unsigned long)_free_list_17424;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_17424)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_17466);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_17466 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at172_17466); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_17466);
    _put4_1__tmp_at172_17466 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_17427);
    DeRef(_seek_1__tmp_at202_17469);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _to_be_freed_17427;
    _seek_1__tmp_at202_17469 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_17468 = machine(19, _seek_1__tmp_at202_17469);
    DeRef(_seek_1__tmp_at202_17469);
    _seek_1__tmp_at202_17469 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_17430 <= INT15 && _free_count_17430 >= -INT15)
    _9857 = 8 * _free_count_17430;
    else
    _9857 = NewDouble(8 * (double)_free_count_17430);
    _0 = _remaining_17431;
    _remaining_17431 = _18get_bytes(_38current_db_16699, _9857);
    DeRef(_0);
    _9857 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17424);
    DeRef(_seek_1__tmp_at234_17474);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _free_list_17424;
    _seek_1__tmp_at234_17474 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_17473 = machine(19, _seek_1__tmp_at234_17474);
    DeRef(_seek_1__tmp_at234_17474);
    _seek_1__tmp_at234_17474 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_17431); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_17431)){
            _9859 = SEQ_PTR(_remaining_17431)->length;
    }
    else {
        _9859 = 1;
    }
    if (IS_ATOM_INT(_new_space_17426)) {
        _9860 = _new_space_17426 - _9859;
    }
    else {
        _9860 = NewDouble(DBL_PTR(_new_space_17426)->dbl - (double)_9859);
    }
    _9859 = NOVALUE;
    _9861 = Repeat(0, _9860);
    DeRef(_9860);
    _9860 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_17480);
    _s_inlined_putn_at_274_17480 = _9861;
    _9861 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_274_17480); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_17480);
    _s_inlined_putn_at_274_17480 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17424);
    DeRef(_seek_1__tmp_at297_17483);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _free_list_17424;
    _seek_1__tmp_at297_17483 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_17482 = machine(19, _seek_1__tmp_at297_17483);
    DeRef(_seek_1__tmp_at297_17483);
    _seek_1__tmp_at297_17483 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_17426);
    _new_space_17426 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_17421);
    _i_17421 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_17428);
    _prev_addr_17428 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_17429);
    _prev_size_17429 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_17421, _free_count_17430)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_17423;
    _addr_17423 = _38get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_17422;
    _size_17422 = _38get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_17419, _addr_17423)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_17423);
    DeRef(_prev_addr_17428);
    _prev_addr_17428 = _addr_17423;

    /** 		prev_size = size*/
    Ref(_size_17422);
    DeRef(_prev_size_17429);
    _prev_size_17429 = _size_17422;

    /** 		i += 1*/
    _0 = _i_17421;
    if (IS_ATOM_INT(_i_17421)) {
        _i_17421 = _i_17421 + 1;
        if (_i_17421 > MAXINT){
            _i_17421 = NewDouble((double)_i_17421);
        }
    }
    else
    _i_17421 = binary_op(PLUS, 1, _i_17421);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_17421)) {
        _9867 = (_i_17421 > 1);
    }
    else {
        _9867 = (DBL_PTR(_i_17421)->dbl > (double)1);
    }
    if (_9867 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_17428) && IS_ATOM_INT(_prev_size_17429)) {
        _9869 = _prev_addr_17428 + _prev_size_17429;
        if ((long)((unsigned long)_9869 + (unsigned long)HIGH_BITS) >= 0) 
        _9869 = NewDouble((double)_9869);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_17428)) {
            _9869 = NewDouble((double)_prev_addr_17428 + DBL_PTR(_prev_size_17429)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_17429)) {
                _9869 = NewDouble(DBL_PTR(_prev_addr_17428)->dbl + (double)_prev_size_17429);
            }
            else
            _9869 = NewDouble(DBL_PTR(_prev_addr_17428)->dbl + DBL_PTR(_prev_size_17429)->dbl);
        }
    }
    if (IS_ATOM_INT(_9869) && IS_ATOM_INT(_p_17419)) {
        _9870 = (_9869 == _p_17419);
    }
    else {
        if (IS_ATOM_INT(_9869)) {
            _9870 = ((double)_9869 == DBL_PTR(_p_17419)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_17419)) {
                _9870 = (DBL_PTR(_9869)->dbl == (double)_p_17419);
            }
            else
            _9870 = (DBL_PTR(_9869)->dbl == DBL_PTR(_p_17419)->dbl);
        }
    }
    DeRef(_9869);
    _9869 = NOVALUE;
    if (_9870 == 0)
    {
        DeRef(_9870);
        _9870 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_9870);
        _9870 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9871 = _i_17421 - 2;
        if ((long)((unsigned long)_9871 +(unsigned long) HIGH_BITS) >= 0){
            _9871 = NewDouble((double)_9871);
        }
    }
    else {
        _9871 = NewDouble(DBL_PTR(_i_17421)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_9871)) {
        if (_9871 == (short)_9871)
        _9872 = _9871 * 8;
        else
        _9872 = NewDouble(_9871 * (double)8);
    }
    else {
        _9872 = NewDouble(DBL_PTR(_9871)->dbl * (double)8);
    }
    DeRef(_9871);
    _9871 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9872)) {
        _9873 = _free_list_17424 + _9872;
        if ((long)((unsigned long)_9873 + (unsigned long)HIGH_BITS) >= 0) 
        _9873 = NewDouble((double)_9873);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9873 = NewDouble((double)_free_list_17424 + DBL_PTR(_9872)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9872)) {
                _9873 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9872);
            }
            else
            _9873 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9872)->dbl);
        }
    }
    DeRef(_9872);
    _9872 = NOVALUE;
    if (IS_ATOM_INT(_9873)) {
        _9874 = _9873 + 4;
        if ((long)((unsigned long)_9874 + (unsigned long)HIGH_BITS) >= 0) 
        _9874 = NewDouble((double)_9874);
    }
    else {
        _9874 = NewDouble(DBL_PTR(_9873)->dbl + (double)4);
    }
    DeRef(_9873);
    _9873 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_17502);
    _pos_inlined_seek_at_427_17502 = _9874;
    _9874 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_17502);
    DeRef(_seek_1__tmp_at430_17504);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_17502;
    _seek_1__tmp_at430_17504 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_17503 = machine(19, _seek_1__tmp_at430_17504);
    DeRef(_pos_inlined_seek_at_427_17502);
    _pos_inlined_seek_at_427_17502 = NOVALUE;
    DeRef(_seek_1__tmp_at430_17504);
    _seek_1__tmp_at430_17504 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17421)) {
        _9875 = (_i_17421 < _free_count_17430);
    }
    else {
        _9875 = (DBL_PTR(_i_17421)->dbl < (double)_free_count_17430);
    }
    if (_9875 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_17419) && IS_ATOM_INT(_psize_17420)) {
        _9877 = _p_17419 + _psize_17420;
        if ((long)((unsigned long)_9877 + (unsigned long)HIGH_BITS) >= 0) 
        _9877 = NewDouble((double)_9877);
    }
    else {
        if (IS_ATOM_INT(_p_17419)) {
            _9877 = NewDouble((double)_p_17419 + DBL_PTR(_psize_17420)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17420)) {
                _9877 = NewDouble(DBL_PTR(_p_17419)->dbl + (double)_psize_17420);
            }
            else
            _9877 = NewDouble(DBL_PTR(_p_17419)->dbl + DBL_PTR(_psize_17420)->dbl);
        }
    }
    if (IS_ATOM_INT(_9877) && IS_ATOM_INT(_addr_17423)) {
        _9878 = (_9877 == _addr_17423);
    }
    else {
        if (IS_ATOM_INT(_9877)) {
            _9878 = ((double)_9877 == DBL_PTR(_addr_17423)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17423)) {
                _9878 = (DBL_PTR(_9877)->dbl == (double)_addr_17423);
            }
            else
            _9878 = (DBL_PTR(_9877)->dbl == DBL_PTR(_addr_17423)->dbl);
        }
    }
    DeRef(_9877);
    _9877 = NOVALUE;
    if (_9878 == 0)
    {
        DeRef(_9878);
        _9878 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_9878);
        _9878 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17429) && IS_ATOM_INT(_psize_17420)) {
        _9879 = _prev_size_17429 + _psize_17420;
        if ((long)((unsigned long)_9879 + (unsigned long)HIGH_BITS) >= 0) 
        _9879 = NewDouble((double)_9879);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17429)) {
            _9879 = NewDouble((double)_prev_size_17429 + DBL_PTR(_psize_17420)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17420)) {
                _9879 = NewDouble(DBL_PTR(_prev_size_17429)->dbl + (double)_psize_17420);
            }
            else
            _9879 = NewDouble(DBL_PTR(_prev_size_17429)->dbl + DBL_PTR(_psize_17420)->dbl);
        }
    }
    if (IS_ATOM_INT(_9879) && IS_ATOM_INT(_size_17422)) {
        _9880 = _9879 + _size_17422;
        if ((long)((unsigned long)_9880 + (unsigned long)HIGH_BITS) >= 0) 
        _9880 = NewDouble((double)_9880);
    }
    else {
        if (IS_ATOM_INT(_9879)) {
            _9880 = NewDouble((double)_9879 + DBL_PTR(_size_17422)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17422)) {
                _9880 = NewDouble(DBL_PTR(_9879)->dbl + (double)_size_17422);
            }
            else
            _9880 = NewDouble(DBL_PTR(_9879)->dbl + DBL_PTR(_size_17422)->dbl);
        }
    }
    DeRef(_9879);
    _9879 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_17513);
    _x_inlined_put4_at_479_17513 = _9880;
    _9880 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_17513)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_17513;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_17513)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_17514);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_17514 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at482_17514); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_17513);
    _x_inlined_put4_at_479_17513 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_17514);
    _put4_1__tmp_at482_17514 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        if (_i_17421 == (short)_i_17421)
        _9881 = _i_17421 * 8;
        else
        _9881 = NewDouble(_i_17421 * (double)8);
    }
    else {
        _9881 = NewDouble(DBL_PTR(_i_17421)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9881)) {
        _9882 = _free_list_17424 + _9881;
        if ((long)((unsigned long)_9882 + (unsigned long)HIGH_BITS) >= 0) 
        _9882 = NewDouble((double)_9882);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9882 = NewDouble((double)_free_list_17424 + DBL_PTR(_9881)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9881)) {
                _9882 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9881);
            }
            else
            _9882 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9881)->dbl);
        }
    }
    DeRef(_9881);
    _9881 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_17518);
    _pos_inlined_seek_at_520_17518 = _9882;
    _9882 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_17518);
    DeRef(_seek_1__tmp_at523_17520);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_17518;
    _seek_1__tmp_at523_17520 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_17519 = machine(19, _seek_1__tmp_at523_17520);
    DeRef(_pos_inlined_seek_at_520_17518);
    _pos_inlined_seek_at_520_17518 = NOVALUE;
    DeRef(_seek_1__tmp_at523_17520);
    _seek_1__tmp_at523_17520 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9883 = _free_count_17430 - _i_17421;
        if ((long)((unsigned long)_9883 +(unsigned long) HIGH_BITS) >= 0){
            _9883 = NewDouble((double)_9883);
        }
    }
    else {
        _9883 = NewDouble((double)_free_count_17430 - DBL_PTR(_i_17421)->dbl);
    }
    if (IS_ATOM_INT(_9883)) {
        if (_9883 == (short)_9883)
        _9884 = _9883 * 8;
        else
        _9884 = NewDouble(_9883 * (double)8);
    }
    else {
        _9884 = NewDouble(DBL_PTR(_9883)->dbl * (double)8);
    }
    DeRef(_9883);
    _9883 = NOVALUE;
    _0 = _remaining_17431;
    _remaining_17431 = _18get_bytes(_38current_db_16699, _9884);
    DeRef(_0);
    _9884 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9886 = _i_17421 - 1;
        if ((long)((unsigned long)_9886 +(unsigned long) HIGH_BITS) >= 0){
            _9886 = NewDouble((double)_9886);
        }
    }
    else {
        _9886 = NewDouble(DBL_PTR(_i_17421)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9886)) {
        if (_9886 == (short)_9886)
        _9887 = _9886 * 8;
        else
        _9887 = NewDouble(_9886 * (double)8);
    }
    else {
        _9887 = NewDouble(DBL_PTR(_9886)->dbl * (double)8);
    }
    DeRef(_9886);
    _9886 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9887)) {
        _9888 = _free_list_17424 + _9887;
        if ((long)((unsigned long)_9888 + (unsigned long)HIGH_BITS) >= 0) 
        _9888 = NewDouble((double)_9888);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9888 = NewDouble((double)_free_list_17424 + DBL_PTR(_9887)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9887)) {
                _9888 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9887);
            }
            else
            _9888 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9887)->dbl);
        }
    }
    DeRef(_9887);
    _9887 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_17528);
    _pos_inlined_seek_at_571_17528 = _9888;
    _9888 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_17528);
    DeRef(_seek_1__tmp_at574_17530);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_17528;
    _seek_1__tmp_at574_17530 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_17529 = machine(19, _seek_1__tmp_at574_17530);
    DeRef(_pos_inlined_seek_at_571_17528);
    _pos_inlined_seek_at_571_17528 = NOVALUE;
    DeRef(_seek_1__tmp_at574_17530);
    _seek_1__tmp_at574_17530 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_17431); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_17430 = _free_count_17430 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_17535);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_17535 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_17534 = machine(19, _seek_1__tmp_at611_17535);
    DeRefi(_seek_1__tmp_at611_17535);
    _seek_1__tmp_at611_17535 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17430;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_17537);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_17537 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at626_17537); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_17537);
    _put4_1__tmp_at626_17537 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17429) && IS_ATOM_INT(_psize_17420)) {
        _9890 = _prev_size_17429 + _psize_17420;
        if ((long)((unsigned long)_9890 + (unsigned long)HIGH_BITS) >= 0) 
        _9890 = NewDouble((double)_9890);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17429)) {
            _9890 = NewDouble((double)_prev_size_17429 + DBL_PTR(_psize_17420)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17420)) {
                _9890 = NewDouble(DBL_PTR(_prev_size_17429)->dbl + (double)_psize_17420);
            }
            else
            _9890 = NewDouble(DBL_PTR(_prev_size_17429)->dbl + DBL_PTR(_psize_17420)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_17541);
    _x_inlined_put4_at_661_17541 = _9890;
    _9890 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_17541)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_17541;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_17541)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_17542);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_17542 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at664_17542); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_17541);
    _x_inlined_put4_at_661_17541 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_17542);
    _put4_1__tmp_at664_17542 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17421)) {
        _9891 = (_i_17421 < _free_count_17430);
    }
    else {
        _9891 = (DBL_PTR(_i_17421)->dbl < (double)_free_count_17430);
    }
    if (_9891 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_17419) && IS_ATOM_INT(_psize_17420)) {
        _9893 = _p_17419 + _psize_17420;
        if ((long)((unsigned long)_9893 + (unsigned long)HIGH_BITS) >= 0) 
        _9893 = NewDouble((double)_9893);
    }
    else {
        if (IS_ATOM_INT(_p_17419)) {
            _9893 = NewDouble((double)_p_17419 + DBL_PTR(_psize_17420)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17420)) {
                _9893 = NewDouble(DBL_PTR(_p_17419)->dbl + (double)_psize_17420);
            }
            else
            _9893 = NewDouble(DBL_PTR(_p_17419)->dbl + DBL_PTR(_psize_17420)->dbl);
        }
    }
    if (IS_ATOM_INT(_9893) && IS_ATOM_INT(_addr_17423)) {
        _9894 = (_9893 == _addr_17423);
    }
    else {
        if (IS_ATOM_INT(_9893)) {
            _9894 = ((double)_9893 == DBL_PTR(_addr_17423)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17423)) {
                _9894 = (DBL_PTR(_9893)->dbl == (double)_addr_17423);
            }
            else
            _9894 = (DBL_PTR(_9893)->dbl == DBL_PTR(_addr_17423)->dbl);
        }
    }
    DeRef(_9893);
    _9893 = NOVALUE;
    if (_9894 == 0)
    {
        DeRef(_9894);
        _9894 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_9894);
        _9894 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9895 = _i_17421 - 1;
        if ((long)((unsigned long)_9895 +(unsigned long) HIGH_BITS) >= 0){
            _9895 = NewDouble((double)_9895);
        }
    }
    else {
        _9895 = NewDouble(DBL_PTR(_i_17421)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9895)) {
        if (_9895 == (short)_9895)
        _9896 = _9895 * 8;
        else
        _9896 = NewDouble(_9895 * (double)8);
    }
    else {
        _9896 = NewDouble(DBL_PTR(_9895)->dbl * (double)8);
    }
    DeRef(_9895);
    _9895 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9896)) {
        _9897 = _free_list_17424 + _9896;
        if ((long)((unsigned long)_9897 + (unsigned long)HIGH_BITS) >= 0) 
        _9897 = NewDouble((double)_9897);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9897 = NewDouble((double)_free_list_17424 + DBL_PTR(_9896)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9896)) {
                _9897 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9896);
            }
            else
            _9897 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9896)->dbl);
        }
    }
    DeRef(_9896);
    _9896 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_17552);
    _pos_inlined_seek_at_734_17552 = _9897;
    _9897 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_17552);
    DeRef(_seek_1__tmp_at737_17554);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_17552;
    _seek_1__tmp_at737_17554 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_17553 = machine(19, _seek_1__tmp_at737_17554);
    DeRef(_pos_inlined_seek_at_734_17552);
    _pos_inlined_seek_at_734_17552 = NOVALUE;
    DeRef(_seek_1__tmp_at737_17554);
    _seek_1__tmp_at737_17554 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_p_17419)) {
        *poke4_addr = (unsigned long)_p_17419;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17419)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_17556);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_17556 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at752_17556); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_17556);
    _put4_1__tmp_at752_17556 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_17420) && IS_ATOM_INT(_size_17422)) {
        _9898 = _psize_17420 + _size_17422;
        if ((long)((unsigned long)_9898 + (unsigned long)HIGH_BITS) >= 0) 
        _9898 = NewDouble((double)_9898);
    }
    else {
        if (IS_ATOM_INT(_psize_17420)) {
            _9898 = NewDouble((double)_psize_17420 + DBL_PTR(_size_17422)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17422)) {
                _9898 = NewDouble(DBL_PTR(_psize_17420)->dbl + (double)_size_17422);
            }
            else
            _9898 = NewDouble(DBL_PTR(_psize_17420)->dbl + DBL_PTR(_size_17422)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_17559);
    _x_inlined_put4_at_786_17559 = _9898;
    _9898 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_17559)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_17559;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_17559)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_17560);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_17560 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at789_17560); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_17559);
    _x_inlined_put4_at_786_17559 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_17560);
    _put4_1__tmp_at789_17560 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9899 = _i_17421 - 1;
        if ((long)((unsigned long)_9899 +(unsigned long) HIGH_BITS) >= 0){
            _9899 = NewDouble((double)_9899);
        }
    }
    else {
        _9899 = NewDouble(DBL_PTR(_i_17421)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9899)) {
        if (_9899 == (short)_9899)
        _9900 = _9899 * 8;
        else
        _9900 = NewDouble(_9899 * (double)8);
    }
    else {
        _9900 = NewDouble(DBL_PTR(_9899)->dbl * (double)8);
    }
    DeRef(_9899);
    _9899 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9900)) {
        _9901 = _free_list_17424 + _9900;
        if ((long)((unsigned long)_9901 + (unsigned long)HIGH_BITS) >= 0) 
        _9901 = NewDouble((double)_9901);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9901 = NewDouble((double)_free_list_17424 + DBL_PTR(_9900)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9900)) {
                _9901 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9900);
            }
            else
            _9901 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9900)->dbl);
        }
    }
    DeRef(_9900);
    _9900 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_17566);
    _pos_inlined_seek_at_834_17566 = _9901;
    _9901 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_17566);
    DeRef(_seek_1__tmp_at837_17568);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_17566;
    _seek_1__tmp_at837_17568 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_17567 = machine(19, _seek_1__tmp_at837_17568);
    DeRef(_pos_inlined_seek_at_834_17566);
    _pos_inlined_seek_at_834_17566 = NOVALUE;
    DeRef(_seek_1__tmp_at837_17568);
    _seek_1__tmp_at837_17568 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9902 = _free_count_17430 - _i_17421;
        if ((long)((unsigned long)_9902 +(unsigned long) HIGH_BITS) >= 0){
            _9902 = NewDouble((double)_9902);
        }
    }
    else {
        _9902 = NewDouble((double)_free_count_17430 - DBL_PTR(_i_17421)->dbl);
    }
    if (IS_ATOM_INT(_9902)) {
        _9903 = _9902 + 1;
        if (_9903 > MAXINT){
            _9903 = NewDouble((double)_9903);
        }
    }
    else
    _9903 = binary_op(PLUS, 1, _9902);
    DeRef(_9902);
    _9902 = NOVALUE;
    if (IS_ATOM_INT(_9903)) {
        if (_9903 == (short)_9903)
        _9904 = _9903 * 8;
        else
        _9904 = NewDouble(_9903 * (double)8);
    }
    else {
        _9904 = NewDouble(DBL_PTR(_9903)->dbl * (double)8);
    }
    DeRef(_9903);
    _9903 = NOVALUE;
    _0 = _remaining_17431;
    _remaining_17431 = _18get_bytes(_38current_db_16699, _9904);
    DeRef(_0);
    _9904 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_17430 = _free_count_17430 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_17576);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_17576 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_17575 = machine(19, _seek_1__tmp_at883_17576);
    DeRefi(_seek_1__tmp_at883_17576);
    _seek_1__tmp_at883_17576 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17430;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_17578);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_17578 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at898_17578); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_17578);
    _put4_1__tmp_at898_17578 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17421)) {
        _9907 = _i_17421 - 1;
        if ((long)((unsigned long)_9907 +(unsigned long) HIGH_BITS) >= 0){
            _9907 = NewDouble((double)_9907);
        }
    }
    else {
        _9907 = NewDouble(DBL_PTR(_i_17421)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_9907)) {
        if (_9907 == (short)_9907)
        _9908 = _9907 * 8;
        else
        _9908 = NewDouble(_9907 * (double)8);
    }
    else {
        _9908 = NewDouble(DBL_PTR(_9907)->dbl * (double)8);
    }
    DeRef(_9907);
    _9907 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17424) && IS_ATOM_INT(_9908)) {
        _9909 = _free_list_17424 + _9908;
        if ((long)((unsigned long)_9909 + (unsigned long)HIGH_BITS) >= 0) 
        _9909 = NewDouble((double)_9909);
    }
    else {
        if (IS_ATOM_INT(_free_list_17424)) {
            _9909 = NewDouble((double)_free_list_17424 + DBL_PTR(_9908)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9908)) {
                _9909 = NewDouble(DBL_PTR(_free_list_17424)->dbl + (double)_9908);
            }
            else
            _9909 = NewDouble(DBL_PTR(_free_list_17424)->dbl + DBL_PTR(_9908)->dbl);
        }
    }
    DeRef(_9908);
    _9908 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_17583);
    _pos_inlined_seek_at_940_17583 = _9909;
    _9909 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_17583);
    DeRef(_seek_1__tmp_at943_17585);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_17583;
    _seek_1__tmp_at943_17585 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_17584 = machine(19, _seek_1__tmp_at943_17585);
    DeRef(_pos_inlined_seek_at_940_17583);
    _pos_inlined_seek_at_940_17583 = NOVALUE;
    DeRef(_seek_1__tmp_at943_17585);
    _seek_1__tmp_at943_17585 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_p_17419)) {
        *poke4_addr = (unsigned long)_p_17419;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17419)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_17587);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_17587 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at958_17587); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_17587);
    _put4_1__tmp_at958_17587 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_psize_17420)) {
        *poke4_addr = (unsigned long)_psize_17420;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_17420)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_17589);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_17589 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at986_17589); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_17589);
    _put4_1__tmp_at986_17589 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_17431); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_17426 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_17426) && DBL_PTR(_new_space_17426)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_17427);
    _38db_free(_to_be_freed_17427);
L17: 

    /** end procedure*/
    DeRef(_p_17419);
    DeRef(_psize_17420);
    DeRef(_i_17421);
    DeRef(_size_17422);
    DeRef(_addr_17423);
    DeRef(_free_list_17424);
    DeRef(_free_list_space_17425);
    DeRef(_new_space_17426);
    DeRef(_to_be_freed_17427);
    DeRef(_prev_addr_17428);
    DeRef(_prev_size_17429);
    DeRef(_remaining_17431);
    DeRef(_9867);
    _9867 = NOVALUE;
    DeRef(_9875);
    _9875 = NOVALUE;
    DeRef(_9891);
    _9891 = NOVALUE;
    return;
    ;
}


void _38save_keys()
{
    int _k_17594 = NOVALUE;
    int _9916 = NOVALUE;
    int _9912 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/
    if (_38caching_option_16709 != 1)
    goto L1; // [5] 82

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _38current_table_pos_16700, 0)){
        goto L2; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16700);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _9912 = MAKE_SEQ(_1);
    _k_17594 = find_from(_9912, _38cache_index_16708, 1);
    DeRefDS(_9912);
    _9912 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_17594 == 0)
    goto L3; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_38key_pointers_16706);
    _2 = (int)SEQ_PTR(_38key_cache_16707);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38key_cache_16707 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_17594);
    _1 = *(int *)_2;
    *(int *)_2 = _38key_pointers_16706;
    DeRef(_1);
    goto L4; // [50] 80
L3: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_38key_pointers_16706);
    Append(&_38key_cache_16707, _38key_cache_16707, _38key_pointers_16706);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_38current_table_pos_16700);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _9916 = MAKE_SEQ(_1);
    RefDS(_9916);
    Append(&_38cache_index_16708, _38cache_index_16708, _9916);
    DeRefDS(_9916);
    _9916 = NOVALUE;
L4: 
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int  __stdcall _38db_connect(int _dbalias_17609, int _path_17610, int _dboptions_17611)
{
    int _lPos_17612 = NOVALUE;
    int _lOptions_17613 = NOVALUE;
    int _9973 = NOVALUE;
    int _9972 = NOVALUE;
    int _9971 = NOVALUE;
    int _9968 = NOVALUE;
    int _9965 = NOVALUE;
    int _9964 = NOVALUE;
    int _9963 = NOVALUE;
    int _9962 = NOVALUE;
    int _9960 = NOVALUE;
    int _9959 = NOVALUE;
    int _9958 = NOVALUE;
    int _9957 = NOVALUE;
    int _9956 = NOVALUE;
    int _9955 = NOVALUE;
    int _9954 = NOVALUE;
    int _9951 = NOVALUE;
    int _9950 = NOVALUE;
    int _9949 = NOVALUE;
    int _9947 = NOVALUE;
    int _9946 = NOVALUE;
    int _9945 = NOVALUE;
    int _9943 = NOVALUE;
    int _9942 = NOVALUE;
    int _9941 = NOVALUE;
    int _9940 = NOVALUE;
    int _9939 = NOVALUE;
    int _9937 = NOVALUE;
    int _9935 = NOVALUE;
    int _9934 = NOVALUE;
    int _9932 = NOVALUE;
    int _9931 = NOVALUE;
    int _9930 = NOVALUE;
    int _9929 = NOVALUE;
    int _9928 = NOVALUE;
    int _9927 = NOVALUE;
    int _9926 = NOVALUE;
    int _9924 = NOVALUE;
    int _9921 = NOVALUE;
    int _9919 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	lPos = find(dbalias, Known_Aliases)*/
    _lPos_17612 = find_from(_dbalias_17609, _38Known_Aliases_16720, 1);

    /** 	if lPos then*/
    if (_lPos_17612 == 0)
    {
        goto L1; // [18] 108
    }
    else{
    }

    /** 		if equal(dboptions, DISCONNECT) or find(DISCONNECT, dboptions) then*/
    if (_dboptions_17611 == _38DISCONNECT_16710)
    _9919 = 1;
    else if (IS_ATOM_INT(_dboptions_17611) && IS_ATOM_INT(_38DISCONNECT_16710))
    _9919 = 0;
    else
    _9919 = (compare(_dboptions_17611, _38DISCONNECT_16710) == 0);
    if (_9919 != 0) {
        goto L2; // [27] 41
    }
    _9921 = find_from(_38DISCONNECT_16710, _dboptions_17611, 1);
    if (_9921 == 0)
    {
        _9921 = NOVALUE;
        goto L3; // [37] 66
    }
    else{
        _9921 = NOVALUE;
    }
L2: 

    /** 			Known_Aliases = remove(Known_Aliases, lPos)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38Known_Aliases_16720);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPos_17612)) ? _lPos_17612 : (long)(DBL_PTR(_lPos_17612)->dbl);
        int stop = (IS_ATOM_INT(_lPos_17612)) ? _lPos_17612 : (long)(DBL_PTR(_lPos_17612)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38Known_Aliases_16720), start, &_38Known_Aliases_16720 );
            }
            else Tail(SEQ_PTR(_38Known_Aliases_16720), stop+1, &_38Known_Aliases_16720);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38Known_Aliases_16720), start, &_38Known_Aliases_16720);
        }
        else {
            assign_slice_seq = &assign_space;
            _38Known_Aliases_16720 = Remove_elements(start, stop, (SEQ_PTR(_38Known_Aliases_16720)->ref == 1));
        }
    }

    /** 			Alias_Details = remove(Alias_Details, lPos)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38Alias_Details_16721);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPos_17612)) ? _lPos_17612 : (long)(DBL_PTR(_lPos_17612)->dbl);
        int stop = (IS_ATOM_INT(_lPos_17612)) ? _lPos_17612 : (long)(DBL_PTR(_lPos_17612)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38Alias_Details_16721), start, &_38Alias_Details_16721 );
            }
            else Tail(SEQ_PTR(_38Alias_Details_16721), stop+1, &_38Alias_Details_16721);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38Alias_Details_16721), start, &_38Alias_Details_16721);
        }
        else {
            assign_slice_seq = &assign_space;
            _38Alias_Details_16721 = Remove_elements(start, stop, (SEQ_PTR(_38Alias_Details_16721)->ref == 1));
        }
    }

    /** 			return DB_OK*/
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRef(_lOptions_17613);
    return 0;
L3: 

    /** 		if equal(dboptions, CONNECTION) or find(CONNECTION, dboptions) then*/
    if (_dboptions_17611 == _38CONNECTION_16718)
    _9924 = 1;
    else if (IS_ATOM_INT(_dboptions_17611) && IS_ATOM_INT(_38CONNECTION_16718))
    _9924 = 0;
    else
    _9924 = (compare(_dboptions_17611, _38CONNECTION_16718) == 0);
    if (_9924 != 0) {
        goto L4; // [72] 86
    }
    _9926 = find_from(_38CONNECTION_16718, _dboptions_17611, 1);
    if (_9926 == 0)
    {
        _9926 = NOVALUE;
        goto L5; // [82] 99
    }
    else{
        _9926 = NOVALUE;
    }
L4: 

    /** 			return Alias_Details[lPos]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _9927 = (int)*(((s1_ptr)_2)->base + _lPos_17612);
    Ref(_9927);
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRef(_lOptions_17613);
    return _9927;
L5: 

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRef(_lOptions_17613);
    _9927 = NOVALUE;
    return -1;
    goto L6; // [105] 161
L1: 

    /** 		if equal(dboptions, DISCONNECT) or find(DISCONNECT, dboptions) or*/
    if (_dboptions_17611 == _38DISCONNECT_16710)
    _9928 = 1;
    else if (IS_ATOM_INT(_dboptions_17611) && IS_ATOM_INT(_38DISCONNECT_16710))
    _9928 = 0;
    else
    _9928 = (compare(_dboptions_17611, _38DISCONNECT_16710) == 0);
    if (_9928 != 0) {
        _9929 = 1;
        goto L7; // [114] 127
    }
    _9930 = find_from(_38DISCONNECT_16710, _dboptions_17611, 1);
    _9929 = (_9930 != 0);
L7: 
    if (_9929 != 0) {
        _9931 = 1;
        goto L8; // [127] 139
    }
    if (_dboptions_17611 == _38CONNECTION_16718)
    _9932 = 1;
    else if (IS_ATOM_INT(_dboptions_17611) && IS_ATOM_INT(_38CONNECTION_16718))
    _9932 = 0;
    else
    _9932 = (compare(_dboptions_17611, _38CONNECTION_16718) == 0);
    _9931 = (_9932 != 0);
L8: 
    if (_9931 != 0) {
        goto L9; // [139] 153
    }
    _9934 = find_from(_38CONNECTION_16718, _dboptions_17611, 1);
    if (_9934 == 0)
    {
        _9934 = NOVALUE;
        goto LA; // [149] 160
    }
    else{
        _9934 = NOVALUE;
    }
L9: 

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRef(_lOptions_17613);
    _9927 = NOVALUE;
    return -1;
LA: 
L6: 

    /** 	if length(path) = 0 then*/
    if (IS_SEQUENCE(_path_17610)){
            _9935 = SEQ_PTR(_path_17610)->length;
    }
    else {
        _9935 = 1;
    }
    if (_9935 != 0)
    goto LB; // [166] 177

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRef(_lOptions_17613);
    _9927 = NOVALUE;
    return -1;
LB: 

    /** 	if types:string(dboptions) then*/
    RefDS(_dboptions_17611);
    _9937 = _7string(_dboptions_17611);
    if (_9937 == 0) {
        DeRef(_9937);
        _9937 = NOVALUE;
        goto LC; // [183] 261
    }
    else {
        if (!IS_ATOM_INT(_9937) && DBL_PTR(_9937)->dbl == 0.0){
            DeRef(_9937);
            _9937 = NOVALUE;
            goto LC; // [183] 261
        }
        DeRef(_9937);
        _9937 = NOVALUE;
    }
    DeRef(_9937);
    _9937 = NOVALUE;

    /** 		dboptions = text:keyvalues(dboptions)*/
    RefDS(_dboptions_17611);
    RefDS(_5372);
    RefDS(_5373);
    RefDS(_5374);
    RefDS(_307);
    _0 = _dboptions_17611;
    _dboptions_17611 = _6keyvalues(_dboptions_17611, _5372, _5373, _5374, _307, 1);
    DeRefDS(_0);

    /** 		for i = 1 to length(dboptions) do*/
    if (IS_SEQUENCE(_dboptions_17611)){
            _9939 = SEQ_PTR(_dboptions_17611)->length;
    }
    else {
        _9939 = 1;
    }
    {
        int _i_17643;
        _i_17643 = 1;
LD: 
        if (_i_17643 > _9939){
            goto LE; // [204] 260
        }

        /** 			if types:string(dboptions[i][2]) then*/
        _2 = (int)SEQ_PTR(_dboptions_17611);
        _9940 = (int)*(((s1_ptr)_2)->base + _i_17643);
        _2 = (int)SEQ_PTR(_9940);
        _9941 = (int)*(((s1_ptr)_2)->base + 2);
        _9940 = NOVALUE;
        Ref(_9941);
        _9942 = _7string(_9941);
        _9941 = NOVALUE;
        if (_9942 == 0) {
            DeRef(_9942);
            _9942 = NOVALUE;
            goto LF; // [225] 253
        }
        else {
            if (!IS_ATOM_INT(_9942) && DBL_PTR(_9942)->dbl == 0.0){
                DeRef(_9942);
                _9942 = NOVALUE;
                goto LF; // [225] 253
            }
            DeRef(_9942);
            _9942 = NOVALUE;
        }
        DeRef(_9942);
        _9942 = NOVALUE;

        /** 				dboptions[i][2] = convert:to_number(dboptions[i][2])*/
        _2 = (int)SEQ_PTR(_dboptions_17611);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dboptions_17611 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_17643 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_dboptions_17611);
        _9945 = (int)*(((s1_ptr)_2)->base + _i_17643);
        _2 = (int)SEQ_PTR(_9945);
        _9946 = (int)*(((s1_ptr)_2)->base + 2);
        _9945 = NOVALUE;
        Ref(_9946);
        _9947 = _8to_number(_9946, 0);
        _9946 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _9947;
        if( _1 != _9947 ){
            DeRef(_1);
        }
        _9947 = NOVALUE;
        _9943 = NOVALUE;
LF: 

        /** 		end for*/
        _i_17643 = _i_17643 + 1;
        goto LD; // [255] 211
LE: 
        ;
    }
LC: 

    /** 	lOptions = {DB_LOCK_NO, DEF_INIT_TABLES, DEF_INIT_TABLES}*/
    _0 = _lOptions_17613;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 5;
    *((int *)(_2+12)) = 5;
    _lOptions_17613 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(dboptions) do*/
    if (IS_SEQUENCE(_dboptions_17611)){
            _9949 = SEQ_PTR(_dboptions_17611)->length;
    }
    else {
        _9949 = 1;
    }
    {
        int _i_17656;
        _i_17656 = 1;
L10: 
        if (_i_17656 > _9949){
            goto L11; // [274] 374
        }

        /** 		switch dboptions[i][1] do*/
        _2 = (int)SEQ_PTR(_dboptions_17611);
        _9950 = (int)*(((s1_ptr)_2)->base + _i_17656);
        _2 = (int)SEQ_PTR(_9950);
        _9951 = (int)*(((s1_ptr)_2)->base + 1);
        _9950 = NOVALUE;
        _1 = find(_9951, _9952);
        _9951 = NOVALUE;
        switch ( _1 ){ 

            /** 			case LOCK_METHOD then*/
            case 1:

            /** 				lOptions[CONNECT_LOCK] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17611);
            _9954 = (int)*(((s1_ptr)_2)->base + _i_17656);
            _2 = (int)SEQ_PTR(_9954);
            _9955 = (int)*(((s1_ptr)_2)->base + 2);
            _9954 = NOVALUE;
            Ref(_9955);
            _2 = (int)SEQ_PTR(_lOptions_17613);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17613 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _9955;
            if( _1 != _9955 ){
                DeRef(_1);
            }
            _9955 = NOVALUE;
            goto L12; // [314] 367

            /** 			case INIT_TABLES then*/
            case 2:

            /** 				lOptions[CONNECT_TABLES] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17611);
            _9956 = (int)*(((s1_ptr)_2)->base + _i_17656);
            _2 = (int)SEQ_PTR(_9956);
            _9957 = (int)*(((s1_ptr)_2)->base + 2);
            _9956 = NOVALUE;
            Ref(_9957);
            _2 = (int)SEQ_PTR(_lOptions_17613);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17613 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _9957;
            if( _1 != _9957 ){
                DeRef(_1);
            }
            _9957 = NOVALUE;
            goto L12; // [334] 367

            /** 			case INIT_FREE then*/
            case 3:

            /** 				lOptions[CONNECT_FREE] = dboptions[i][2]*/
            _2 = (int)SEQ_PTR(_dboptions_17611);
            _9958 = (int)*(((s1_ptr)_2)->base + _i_17656);
            _2 = (int)SEQ_PTR(_9958);
            _9959 = (int)*(((s1_ptr)_2)->base + 2);
            _9958 = NOVALUE;
            Ref(_9959);
            _2 = (int)SEQ_PTR(_lOptions_17613);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _lOptions_17613 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 3);
            _1 = *(int *)_2;
            *(int *)_2 = _9959;
            if( _1 != _9959 ){
                DeRef(_1);
            }
            _9959 = NOVALUE;
            goto L12; // [354] 367

            /** 			case else				*/
            case 0:

            /** 				return DB_OPEN_FAIL*/
            DeRefDS(_dbalias_17609);
            DeRefDS(_path_17610);
            DeRefDS(_dboptions_17611);
            DeRef(_lOptions_17613);
            _9927 = NOVALUE;
            return -1;
        ;}L12: 

        /** 	end for*/
        _i_17656 = _i_17656 + 1;
        goto L10; // [369] 281
L11: 
        ;
    }

    /** 	if lOptions[CONNECT_TABLES] < 1 then*/
    _2 = (int)SEQ_PTR(_lOptions_17613);
    _9960 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _9960, 1)){
        _9960 = NOVALUE;
        goto L13; // [380] 391
    }
    _9960 = NOVALUE;

    /** 		lOptions[CONNECT_TABLES] = DEF_INIT_TABLES*/
    _2 = (int)SEQ_PTR(_lOptions_17613);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17613 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
L13: 

    /** 	lOptions[CONNECT_FREE] = math:min({lOptions[CONNECT_TABLES], MAX_INDEX})*/
    _2 = (int)SEQ_PTR(_lOptions_17613);
    _9962 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9962);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9962;
    ((int *)_2)[2] = 10;
    _9963 = MAKE_SEQ(_1);
    _9962 = NOVALUE;
    _9964 = _20min(_9963);
    _9963 = NOVALUE;
    _2 = (int)SEQ_PTR(_lOptions_17613);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17613 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _9964;
    if( _1 != _9964 ){
        DeRef(_1);
    }
    _9964 = NOVALUE;

    /** 	if lOptions[CONNECT_FREE] < 1 then*/
    _2 = (int)SEQ_PTR(_lOptions_17613);
    _9965 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _9965, 1)){
        _9965 = NOVALUE;
        goto L14; // [415] 430
    }
    _9965 = NOVALUE;

    /** 		lOptions[CONNECT_FREE] = math:min({DEF_INIT_TABLES, MAX_INDEX})*/
    RefDS(_9967);
    _9968 = _20min(_9967);
    _2 = (int)SEQ_PTR(_lOptions_17613);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _lOptions_17613 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _9968;
    if( _1 != _9968 ){
        DeRef(_1);
    }
    _9968 = NOVALUE;
L14: 

    /** 	Known_Aliases = append(Known_Aliases, dbalias)*/
    RefDS(_dbalias_17609);
    Append(&_38Known_Aliases_16720, _38Known_Aliases_16720, _dbalias_17609);

    /** 	Alias_Details = append(Alias_Details, { filesys:canonical_path( filesys:defaultext(path, "edb") ) , lOptions})*/
    RefDS(_path_17610);
    RefDS(_9970);
    _9971 = _11defaultext(_path_17610, _9970);
    _9972 = _11canonical_path(_9971, 0, 0);
    _9971 = NOVALUE;
    RefDS(_lOptions_17613);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9972;
    ((int *)_2)[2] = _lOptions_17613;
    _9973 = MAKE_SEQ(_1);
    _9972 = NOVALUE;
    RefDS(_9973);
    Append(&_38Alias_Details_16721, _38Alias_Details_16721, _9973);
    DeRefDS(_9973);
    _9973 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_dbalias_17609);
    DeRefDS(_path_17610);
    DeRefDS(_dboptions_17611);
    DeRefDS(_lOptions_17613);
    _9927 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _38db_create(int _path_17691, int _lock_method_17692, int _init_tables_17693, int _init_free_17694)
{
    int _db_17695 = NOVALUE;
    int _lock_file_1__tmp_at222_17734 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_17733 = NOVALUE;
    int _put4_1__tmp_at342_17743 = NOVALUE;
    int _put4_1__tmp_at370_17745 = NOVALUE;
    int _put4_1__tmp_at413_17751 = NOVALUE;
    int _x_inlined_put4_at_410_17750 = NOVALUE;
    int _put4_1__tmp_at452_17756 = NOVALUE;
    int _x_inlined_put4_at_449_17755 = NOVALUE;
    int _put4_1__tmp_at480_17758 = NOVALUE;
    int _s_inlined_putn_at_516_17762 = NOVALUE;
    int _put4_1__tmp_at548_17767 = NOVALUE;
    int _x_inlined_put4_at_545_17766 = NOVALUE;
    int _s_inlined_putn_at_584_17771 = NOVALUE;
    int _10014 = NOVALUE;
    int _10013 = NOVALUE;
    int _10012 = NOVALUE;
    int _10011 = NOVALUE;
    int _10010 = NOVALUE;
    int _10009 = NOVALUE;
    int _10008 = NOVALUE;
    int _10007 = NOVALUE;
    int _10006 = NOVALUE;
    int _10005 = NOVALUE;
    int _10004 = NOVALUE;
    int _9987 = NOVALUE;
    int _9985 = NOVALUE;
    int _9984 = NOVALUE;
    int _9982 = NOVALUE;
    int _9981 = NOVALUE;
    int _9979 = NOVALUE;
    int _9978 = NOVALUE;
    int _9976 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17692)) {
        _1 = (long)(DBL_PTR(_lock_method_17692)->dbl);
        DeRefDS(_lock_method_17692);
        _lock_method_17692 = _1;
    }
    if (!IS_ATOM_INT(_init_tables_17693)) {
        _1 = (long)(DBL_PTR(_init_tables_17693)->dbl);
        DeRefDS(_init_tables_17693);
        _init_tables_17693 = _1;
    }
    if (!IS_ATOM_INT(_init_free_17694)) {
        _1 = (long)(DBL_PTR(_init_free_17694)->dbl);
        DeRefDS(_init_free_17694);
        _init_free_17694 = _1;
    }

    /** 	db = find(path, Known_Aliases)*/
    _db_17695 = find_from(_path_17691, _38Known_Aliases_16720, 1);

    /** 	if db then*/
    if (_db_17695 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _9976 = (int)*(((s1_ptr)_2)->base + _db_17695);
    DeRefDS(_path_17691);
    _2 = (int)SEQ_PTR(_9976);
    _path_17691 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17691);
    _9976 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _9978 = (int)*(((s1_ptr)_2)->base + _db_17695);
    _2 = (int)SEQ_PTR(_9978);
    _9979 = (int)*(((s1_ptr)_2)->base + 2);
    _9978 = NOVALUE;
    _2 = (int)SEQ_PTR(_9979);
    _lock_method_17692 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17692)){
        _lock_method_17692 = (long)DBL_PTR(_lock_method_17692)->dbl;
    }
    _9979 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _9981 = (int)*(((s1_ptr)_2)->base + _db_17695);
    _2 = (int)SEQ_PTR(_9981);
    _9982 = (int)*(((s1_ptr)_2)->base + 2);
    _9981 = NOVALUE;
    _2 = (int)SEQ_PTR(_9982);
    _init_tables_17693 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_17693)){
        _init_tables_17693 = (long)DBL_PTR(_init_tables_17693)->dbl;
    }
    _9982 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _9984 = (int)*(((s1_ptr)_2)->base + _db_17695);
    _2 = (int)SEQ_PTR(_9984);
    _9985 = (int)*(((s1_ptr)_2)->base + 2);
    _9984 = NOVALUE;
    _2 = (int)SEQ_PTR(_9985);
    _init_free_17694 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_17694)){
        _init_free_17694 = (long)DBL_PTR(_init_free_17694)->dbl;
    }
    _9985 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_17691);
    RefDS(_9970);
    _9987 = _11defaultext(_path_17691, _9970);
    _0 = _path_17691;
    _path_17691 = _11canonical_path(_9987, 0, 0);
    DeRefDS(_0);
    _9987 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_17693 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_17693 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_17694 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_17694 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_17695 = EOpen(_path_17691, _1309, 0);

    /** 	if db != -1 then*/
    if (_db_17695 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_17695);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_17691);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_17695 = EOpen(_path_17691, _1354, 0);

    /** 	if db = -1 then*/
    if (_db_17695 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17691);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_17695);

    /** 	db = open(path, "ub")*/
    _db_17695 = EOpen(_path_17691, _9995, 0);

    /** 	if db = -1 then*/
    if (_db_17695 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17691);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17692 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_17692 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17692 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_17734;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17695;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_17734 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_17733 = machine(61, _lock_file_1__tmp_at222_17734);
    DeRef(_lock_file_1__tmp_at222_17734);
    _lock_file_1__tmp_at222_17734 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_17733 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17691);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db*/
    _38current_db_16699 = _db_17695;

    /** 	current_lock = lock_method*/
    _38current_lock_16705 = _lock_method_17692;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_17691);
    Append(&_38db_names_16702, _38db_names_16702, _path_17691);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_38db_lock_methods_16704, _38db_lock_methods_16704, _lock_method_17692);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_38db_file_nums_16703, _38db_file_nums_16703, _db_17695);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16699, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16699, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_38current_db_16699, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_17743);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_17743 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at342_17743); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_17743);
    _put4_1__tmp_at342_17743 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_17745);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_17745 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at370_17745); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_17745);
    _put4_1__tmp_at370_17745 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_17693 == (short)_init_tables_17693)
    _10004 = _init_tables_17693 * 16;
    else
    _10004 = NewDouble(_init_tables_17693 * (double)16);
    if (IS_ATOM_INT(_10004)) {
        _10005 = 23 + _10004;
        if ((long)((unsigned long)_10005 + (unsigned long)HIGH_BITS) >= 0) 
        _10005 = NewDouble((double)_10005);
    }
    else {
        _10005 = NewDouble((double)23 + DBL_PTR(_10004)->dbl);
    }
    DeRef(_10004);
    _10004 = NOVALUE;
    if (IS_ATOM_INT(_10005)) {
        _10006 = _10005 + 4;
        if ((long)((unsigned long)_10006 + (unsigned long)HIGH_BITS) >= 0) 
        _10006 = NewDouble((double)_10006);
    }
    else {
        _10006 = NewDouble(DBL_PTR(_10005)->dbl + (double)4);
    }
    DeRef(_10005);
    _10005 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_17750);
    _x_inlined_put4_at_410_17750 = _10006;
    _10006 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_17750)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_17750;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_17750)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_17751);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_17751 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at413_17751); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_17750);
    _x_inlined_put4_at_410_17750 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_17751);
    _put4_1__tmp_at413_17751 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_17693 == (short)_init_tables_17693)
    _10007 = _init_tables_17693 * 16;
    else
    _10007 = NewDouble(_init_tables_17693 * (double)16);
    if (IS_ATOM_INT(_10007)) {
        _10008 = 8 + _10007;
        if ((long)((unsigned long)_10008 + (unsigned long)HIGH_BITS) >= 0) 
        _10008 = NewDouble((double)_10008);
    }
    else {
        _10008 = NewDouble((double)8 + DBL_PTR(_10007)->dbl);
    }
    DeRef(_10007);
    _10007 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_17755);
    _x_inlined_put4_at_449_17755 = _10008;
    _10008 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_17755)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_17755;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_17755)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_17756);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_17756 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at452_17756); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_17755);
    _x_inlined_put4_at_449_17755 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_17756);
    _put4_1__tmp_at452_17756 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_17758);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_17758 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at480_17758); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_17758);
    _put4_1__tmp_at480_17758 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _10009 = _init_tables_17693 * 16;
    _10010 = Repeat(0, _10009);
    _10009 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_17762);
    _s_inlined_putn_at_516_17762 = _10010;
    _10010 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_516_17762); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_17762);
    _s_inlined_putn_at_516_17762 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_17694 == (short)_init_free_17694)
    _10011 = _init_free_17694 * 8;
    else
    _10011 = NewDouble(_init_free_17694 * (double)8);
    if (IS_ATOM_INT(_10011)) {
        _10012 = 4 + _10011;
        if ((long)((unsigned long)_10012 + (unsigned long)HIGH_BITS) >= 0) 
        _10012 = NewDouble((double)_10012);
    }
    else {
        _10012 = NewDouble((double)4 + DBL_PTR(_10011)->dbl);
    }
    DeRef(_10011);
    _10011 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_17766);
    _x_inlined_put4_at_545_17766 = _10012;
    _10012 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_17766)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_17766;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_17766)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_17767);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_17767 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at548_17767); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_17766);
    _x_inlined_put4_at_545_17766 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_17767);
    _put4_1__tmp_at548_17767 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _10013 = _init_free_17694 * 8;
    _10014 = Repeat(0, _10013);
    _10013 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_17771);
    _s_inlined_putn_at_584_17771 = _10014;
    _10014 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_584_17771); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_17771);
    _s_inlined_putn_at_584_17771 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_17691);
    return 0;
    ;
}


int  __stdcall _38db_open(int _path_17774, int _lock_method_17775)
{
    int _db_17776 = NOVALUE;
    int _magic_17777 = NOVALUE;
    int _lock_file_1__tmp_at141_17804 = NOVALUE;
    int _lock_file_inlined_lock_file_at_141_17803 = NOVALUE;
    int _lock_file_1__tmp_at181_17811 = NOVALUE;
    int _lock_file_inlined_lock_file_at_181_17810 = NOVALUE;
    int _10025 = NOVALUE;
    int _10023 = NOVALUE;
    int _10021 = NOVALUE;
    int _10019 = NOVALUE;
    int _10018 = NOVALUE;
    int _10016 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17775)) {
        _1 = (long)(DBL_PTR(_lock_method_17775)->dbl);
        DeRefDS(_lock_method_17775);
        _lock_method_17775 = _1;
    }

    /** 	db = find(path, Known_Aliases)*/
    _db_17776 = find_from(_path_17774, _38Known_Aliases_16720, 1);

    /** 	if db then*/
    if (_db_17776 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _10016 = (int)*(((s1_ptr)_2)->base + _db_17776);
    DeRefDS(_path_17774);
    _2 = (int)SEQ_PTR(_10016);
    _path_17774 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17774);
    _10016 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _10018 = (int)*(((s1_ptr)_2)->base + _db_17776);
    _2 = (int)SEQ_PTR(_10018);
    _10019 = (int)*(((s1_ptr)_2)->base + 2);
    _10018 = NOVALUE;
    _2 = (int)SEQ_PTR(_10019);
    _lock_method_17775 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17775)){
        _lock_method_17775 = (long)DBL_PTR(_lock_method_17775)->dbl;
    }
    _10019 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17774);
    RefDS(_9970);
    _10021 = _11defaultext(_path_17774, _9970);
    _0 = _path_17774;
    _path_17774 = _11canonical_path(_10021, 0, 0);
    DeRefDS(_0);
    _10021 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _10023 = (_lock_method_17775 == 0);
    if (_10023 != 0) {
        goto L3; // [76] 89
    }
    _10025 = (_lock_method_17775 == 2);
    if (_10025 == 0)
    {
        DeRef(_10025);
        _10025 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10025);
        _10025 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_17776 = EOpen(_path_17774, _9995, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_17776 = EOpen(_path_17774, _1309, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17775 != 1)
    goto L6; // [111] 121

    /** 		lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_17775 = 2;
L6: 

    /** 	if db = -1 then*/
    if (_db_17776 != -1)
    goto L7; // [123] 134

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17774);
    DeRef(_10023);
    _10023 = NOVALUE;
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17775 != 2)
    goto L8; // [136] 174

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_17804;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17776;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at141_17804 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_17803 = machine(61, _lock_file_1__tmp_at141_17804);
    DeRef(_lock_file_1__tmp_at141_17804);
    _lock_file_1__tmp_at141_17804 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_17803 != 0)
    goto L9; // [157] 213

    /** 			close(db)*/
    EClose(_db_17776);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17774);
    DeRef(_10023);
    _10023 = NOVALUE;
    return -3;
    goto L9; // [171] 213
L8: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17775 != 1)
    goto LA; // [176] 212

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_17811;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_17776;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at181_17811 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_17810 = machine(61, _lock_file_1__tmp_at181_17811);
    DeRef(_lock_file_1__tmp_at181_17811);
    _lock_file_1__tmp_at181_17811 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_17810 != 0)
    goto LB; // [197] 211

    /** 			close(db)*/
    EClose(_db_17776);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_17774);
    DeRef(_10023);
    _10023 = NOVALUE;
    return -3;
LB: 
LA: 
L9: 

    /** 	magic = getc(db)*/
    if (_db_17776 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_17776, EF_READ);
        last_r_file_no = _db_17776;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_17777 = getKBchar();
        }
        else
        _magic_17777 = getc(last_r_file_ptr);
    }
    else
    _magic_17777 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_17777 == 77)
    goto LC; // [220] 235

    /** 		close(db)*/
    EClose(_db_17776);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_17774);
    DeRef(_10023);
    _10023 = NOVALUE;
    return -1;
LC: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db */
    _38current_db_16699 = _db_17776;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _5;

    /** 	current_lock = lock_method*/
    _38current_lock_16705 = _lock_method_17775;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_17774);
    Append(&_38db_names_16702, _38db_names_16702, _path_17774);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_38db_lock_methods_16704, _38db_lock_methods_16704, _lock_method_17775);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_38db_file_nums_16703, _38db_file_nums_16703, _db_17776);

    /** 	return DB_OK*/
    DeRefDS(_path_17774);
    DeRef(_10023);
    _10023 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _38db_select(int _path_17821, int _lock_method_17822)
{
    int _index_17823 = NOVALUE;
    int _10045 = NOVALUE;
    int _10043 = NOVALUE;
    int _10042 = NOVALUE;
    int _10040 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method_17822)) {
        _1 = (long)(DBL_PTR(_lock_method_17822)->dbl);
        DeRefDS(_lock_method_17822);
        _lock_method_17822 = _1;
    }

    /** 	index = find(path, Known_Aliases)*/
    _index_17823 = find_from(_path_17821, _38Known_Aliases_16720, 1);

    /** 	if index then*/
    if (_index_17823 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _10040 = (int)*(((s1_ptr)_2)->base + _index_17823);
    DeRefDS(_path_17821);
    _2 = (int)SEQ_PTR(_10040);
    _path_17821 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17821);
    _10040 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_38Alias_Details_16721);
    _10042 = (int)*(((s1_ptr)_2)->base + _index_17823);
    _2 = (int)SEQ_PTR(_10042);
    _10043 = (int)*(((s1_ptr)_2)->base + 2);
    _10042 = NOVALUE;
    _2 = (int)SEQ_PTR(_10043);
    _lock_method_17822 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17822)){
        _lock_method_17822 = (long)DBL_PTR(_lock_method_17822)->dbl;
    }
    _10043 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17821);
    RefDS(_9970);
    _10045 = _11defaultext(_path_17821, _9970);
    _0 = _path_17821;
    _path_17821 = _11canonical_path(_10045, 0, 0);
    DeRefDS(_0);
    _10045 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_17823 = find_from(_path_17821, _38db_names_16702, 1);

    /** 	if index = 0 then*/
    if (_index_17823 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_17822 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_17821);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_17821);
    _index_17823 = _38db_open(_path_17821, _lock_method_17822);
    if (!IS_ATOM_INT(_index_17823)) {
        _1 = (long)(DBL_PTR(_index_17823)->dbl);
        DeRefDS(_index_17823);
        _index_17823 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_17823 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_17821);
    return _index_17823;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_17823 = find_from(_path_17821, _38db_names_16702, 1);
L3: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_38db_file_nums_16703);
    _38current_db_16699 = (int)*(((s1_ptr)_2)->base + _index_17823);
    if (!IS_ATOM_INT(_38current_db_16699))
    _38current_db_16699 = (long)DBL_PTR(_38current_db_16699)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_38db_lock_methods_16704);
    _38current_lock_16705 = (int)*(((s1_ptr)_2)->base + _index_17823);
    if (!IS_ATOM_INT(_38current_lock_16705))
    _38current_lock_16705 = (long)DBL_PTR(_38current_lock_16705)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16706);
    _38key_pointers_16706 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_17821);
    return 0;
    ;
}


void  __stdcall _38db_close()
{
    int _unlock_file_1__tmp_at25_17852 = NOVALUE;
    int _index_17847 = NOVALUE;
    int _10062 = NOVALUE;
    int _10061 = NOVALUE;
    int _10060 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16699 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_38current_lock_16705 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_17852);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_17852 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_17852);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_17852);
    _unlock_file_1__tmp_at25_17852 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_38current_db_16699);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_17847 = find_from(_38current_db_16699, _38db_file_nums_16703, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_names_16702);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        int stop = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_names_16702), start, &_38db_names_16702 );
            }
            else Tail(SEQ_PTR(_38db_names_16702), stop+1, &_38db_names_16702);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_names_16702), start, &_38db_names_16702);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_names_16702 = Remove_elements(start, stop, (SEQ_PTR(_38db_names_16702)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_file_nums_16703);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        int stop = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_file_nums_16703), start, &_38db_file_nums_16703 );
            }
            else Tail(SEQ_PTR(_38db_file_nums_16703), stop+1, &_38db_file_nums_16703);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_file_nums_16703), start, &_38db_file_nums_16703);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_file_nums_16703 = Remove_elements(start, stop, (SEQ_PTR(_38db_file_nums_16703)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38db_lock_methods_16704);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        int stop = (IS_ATOM_INT(_index_17847)) ? _index_17847 : (long)(DBL_PTR(_index_17847)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38db_lock_methods_16704), start, &_38db_lock_methods_16704 );
            }
            else Tail(SEQ_PTR(_38db_lock_methods_16704), stop+1, &_38db_lock_methods_16704);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38db_lock_methods_16704), start, &_38db_lock_methods_16704);
        }
        else {
            assign_slice_seq = &assign_space;
            _38db_lock_methods_16704 = Remove_elements(start, stop, (SEQ_PTR(_38db_lock_methods_16704)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_38cache_index_16708)){
            _10060 = SEQ_PTR(_38cache_index_16708)->length;
    }
    else {
        _10060 = 1;
    }
    {
        int _i_17858;
        _i_17858 = _10060;
L4: 
        if (_i_17858 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_38cache_index_16708);
        _10061 = (int)*(((s1_ptr)_2)->base + _i_17858);
        _2 = (int)SEQ_PTR(_10061);
        _10062 = (int)*(((s1_ptr)_2)->base + 1);
        _10061 = NOVALUE;
        if (binary_op_a(NOTEQ, _10062, _38current_db_16699)){
            _10062 = NOVALUE;
            goto L6; // [115] 138
        }
        _10062 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_38cache_index_16708);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17858)) ? _i_17858 : (long)(DBL_PTR(_i_17858)->dbl);
            int stop = (IS_ATOM_INT(_i_17858)) ? _i_17858 : (long)(DBL_PTR(_i_17858)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708 );
                }
                else Tail(SEQ_PTR(_38cache_index_16708), stop+1, &_38cache_index_16708);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708);
            }
            else {
                assign_slice_seq = &assign_space;
                _38cache_index_16708 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16708)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_38key_cache_16707);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17858)) ? _i_17858 : (long)(DBL_PTR(_i_17858)->dbl);
            int stop = (IS_ATOM_INT(_i_17858)) ? _i_17858 : (long)(DBL_PTR(_i_17858)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707 );
                }
                else Tail(SEQ_PTR(_38key_cache_16707), stop+1, &_38key_cache_16707);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707);
            }
            else {
                assign_slice_seq = &assign_space;
                _38key_cache_16707 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16707)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_17858 = _i_17858 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _5;

    /** 	current_db = -1*/
    _38current_db_16699 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16706);
    _38key_pointers_16706 = _5;

    /** end procedure*/
    return;
    ;
}


int _38table_find(int _name_17868)
{
    int _tables_17869 = NOVALUE;
    int _nt_17870 = NOVALUE;
    int _t_header_17871 = NOVALUE;
    int _name_ptr_17872 = NOVALUE;
    int _seek_1__tmp_at6_17875 = NOVALUE;
    int _seek_inlined_seek_at_6_17874 = NOVALUE;
    int _seek_1__tmp_at44_17882 = NOVALUE;
    int _seek_inlined_seek_at_44_17881 = NOVALUE;
    int _seek_1__tmp_at84_17890 = NOVALUE;
    int _seek_inlined_seek_at_84_17889 = NOVALUE;
    int _seek_1__tmp_at106_17894 = NOVALUE;
    int _seek_inlined_seek_at_106_17893 = NOVALUE;
    int _10073 = NOVALUE;
    int _10071 = NOVALUE;
    int _10066 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_17875);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_17875 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_17874 = machine(19, _seek_1__tmp_at6_17875);
    DeRefi(_seek_1__tmp_at6_17875);
    _seek_1__tmp_at6_17875 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _10066 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _10066 = 1;
    }
    if (_10066 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_17868);
    DeRef(_tables_17869);
    DeRef(_nt_17870);
    DeRef(_t_header_17871);
    DeRef(_name_ptr_17872);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_17869;
    _tables_17869 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17869);
    DeRef(_seek_1__tmp_at44_17882);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_17869;
    _seek_1__tmp_at44_17882 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_17881 = machine(19, _seek_1__tmp_at44_17882);
    DeRef(_seek_1__tmp_at44_17882);
    _seek_1__tmp_at44_17882 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_17870;
    _nt_17870 = _38get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_17871);
    if (IS_ATOM_INT(_tables_17869)) {
        _t_header_17871 = _tables_17869 + 4;
        if ((long)((unsigned long)_t_header_17871 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_17871 = NewDouble((double)_t_header_17871);
    }
    else {
        _t_header_17871 = NewDouble(DBL_PTR(_tables_17869)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_17870);
    DeRef(_10071);
    _10071 = _nt_17870;
    {
        int _i_17886;
        _i_17886 = 1;
L2: 
        if (binary_op_a(GREATER, _i_17886, _10071)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_17871);
        DeRef(_seek_1__tmp_at84_17890);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _t_header_17871;
        _seek_1__tmp_at84_17890 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_17889 = machine(19, _seek_1__tmp_at84_17890);
        DeRef(_seek_1__tmp_at84_17890);
        _seek_1__tmp_at84_17890 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_17872;
        _name_ptr_17872 = _38get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_17872);
        DeRef(_seek_1__tmp_at106_17894);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _name_ptr_17872;
        _seek_1__tmp_at106_17894 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_17893 = machine(19, _seek_1__tmp_at106_17894);
        DeRef(_seek_1__tmp_at106_17894);
        _seek_1__tmp_at106_17894 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_17868);
        _10073 = _38equal_string(_name_17868);
        if (binary_op_a(LESSEQ, _10073, 0)){
            DeRef(_10073);
            _10073 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10073);
        _10073 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_17886);
        DeRefDS(_name_17868);
        DeRef(_tables_17869);
        DeRef(_nt_17870);
        DeRef(_name_ptr_17872);
        return _t_header_17871;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_17871;
        if (IS_ATOM_INT(_t_header_17871)) {
            _t_header_17871 = _t_header_17871 + 16;
            if ((long)((unsigned long)_t_header_17871 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_17871 = NewDouble((double)_t_header_17871);
        }
        else {
            _t_header_17871 = NewDouble(DBL_PTR(_t_header_17871)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_17886;
        if (IS_ATOM_INT(_i_17886)) {
            _i_17886 = _i_17886 + 1;
            if ((long)((unsigned long)_i_17886 +(unsigned long) HIGH_BITS) >= 0){
                _i_17886 = NewDouble((double)_i_17886);
            }
        }
        else {
            _i_17886 = binary_op_a(PLUS, _i_17886, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_17886);
    }

    /** 	return -1*/
    DeRefDS(_name_17868);
    DeRef(_tables_17869);
    DeRef(_nt_17870);
    DeRef(_t_header_17871);
    DeRef(_name_ptr_17872);
    return -1;
    ;
}


int  __stdcall _38db_select_table(int _name_17901)
{
    int _table_17902 = NOVALUE;
    int _nkeys_17903 = NOVALUE;
    int _index_17904 = NOVALUE;
    int _block_ptr_17905 = NOVALUE;
    int _block_size_17906 = NOVALUE;
    int _blocks_17907 = NOVALUE;
    int _k_17908 = NOVALUE;
    int _seek_1__tmp_at120_17927 = NOVALUE;
    int _seek_inlined_seek_at_120_17926 = NOVALUE;
    int _pos_inlined_seek_at_117_17925 = NOVALUE;
    int _seek_1__tmp_at178_17937 = NOVALUE;
    int _seek_inlined_seek_at_178_17936 = NOVALUE;
    int _seek_1__tmp_at205_17942 = NOVALUE;
    int _seek_inlined_seek_at_205_17941 = NOVALUE;
    int _10094 = NOVALUE;
    int _10093 = NOVALUE;
    int _10090 = NOVALUE;
    int _10085 = NOVALUE;
    int _10080 = NOVALUE;
    int _10076 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_38current_table_name_16701 == _name_17901)
    _10076 = 1;
    else if (IS_ATOM_INT(_38current_table_name_16701) && IS_ATOM_INT(_name_17901))
    _10076 = 0;
    else
    _10076 = (compare(_38current_table_name_16701, _name_17901) == 0);
    if (_10076 == 0)
    {
        _10076 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10076 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_17901);
    DeRef(_table_17902);
    DeRef(_nkeys_17903);
    DeRef(_index_17904);
    DeRef(_block_ptr_17905);
    DeRef(_block_size_17906);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_17901);
    _0 = _table_17902;
    _table_17902 = _38table_find(_name_17901);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17902, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_17901);
    DeRef(_table_17902);
    DeRef(_nkeys_17903);
    DeRef(_index_17904);
    DeRef(_block_ptr_17905);
    DeRef(_block_size_17906);
    return -1;
L2: 

    /** 	save_keys()*/
    _38save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_17902);
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = _table_17902;

    /** 	current_table_name = name*/
    RefDS(_name_17901);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _name_17901;

    /** 	k = 0*/
    _k_17908 = 0;

    /** 	if caching_option = 1 then*/
    if (_38caching_option_16709 != 1)
    goto L3; // [65] 104

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16700);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _10080 = MAKE_SEQ(_1);
    _k_17908 = find_from(_10080, _38cache_index_16708, 1);
    DeRefDS(_10080);
    _10080 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_17908 == 0)
    goto L4; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_38key_pointers_16706);
    _2 = (int)SEQ_PTR(_38key_cache_16707);
    _38key_pointers_16706 = (int)*(((s1_ptr)_2)->base + _k_17908);
    Ref(_38key_pointers_16706);
L4: 
L3: 

    /** 	if k = 0 then*/
    if (_k_17908 != 0)
    goto L5; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_17902)) {
        _10085 = _table_17902 + 4;
        if ((long)((unsigned long)_10085 + (unsigned long)HIGH_BITS) >= 0) 
        _10085 = NewDouble((double)_10085);
    }
    else {
        _10085 = NewDouble(DBL_PTR(_table_17902)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_17925);
    _pos_inlined_seek_at_117_17925 = _10085;
    _10085 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_17925);
    DeRef(_seek_1__tmp_at120_17927);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_17925;
    _seek_1__tmp_at120_17927 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_17926 = machine(19, _seek_1__tmp_at120_17927);
    DeRef(_pos_inlined_seek_at_117_17925);
    _pos_inlined_seek_at_117_17925 = NOVALUE;
    DeRef(_seek_1__tmp_at120_17927);
    _seek_1__tmp_at120_17927 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_17903;
    _nkeys_17903 = _38get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_17907 = _38get4();
    if (!IS_ATOM_INT(_blocks_17907)) {
        _1 = (long)(DBL_PTR(_blocks_17907)->dbl);
        DeRefDS(_blocks_17907);
        _blocks_17907 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_17904;
    _index_17904 = _38get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_38key_pointers_16706);
    _38key_pointers_16706 = Repeat(0, _nkeys_17903);

    /** 		k = 1*/
    _k_17908 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _10090 = _blocks_17907 - 1;
    if ((long)((unsigned long)_10090 +(unsigned long) HIGH_BITS) >= 0){
        _10090 = NewDouble((double)_10090);
    }
    {
        int _b_17933;
        _b_17933 = 0;
L6: 
        if (binary_op_a(GREATER, _b_17933, _10090)){
            goto L7; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_17904);
        DeRef(_seek_1__tmp_at178_17937);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _index_17904;
        _seek_1__tmp_at178_17937 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_17936 = machine(19, _seek_1__tmp_at178_17937);
        DeRef(_seek_1__tmp_at178_17937);
        _seek_1__tmp_at178_17937 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_17906;
        _block_size_17906 = _38get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_17905;
        _block_ptr_17905 = _38get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_17905);
        DeRef(_seek_1__tmp_at205_17942);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _block_ptr_17905;
        _seek_1__tmp_at205_17942 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_17941 = machine(19, _seek_1__tmp_at205_17942);
        DeRef(_seek_1__tmp_at205_17942);
        _seek_1__tmp_at205_17942 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_17906);
        DeRef(_10093);
        _10093 = _block_size_17906;
        {
            int _j_17944;
            _j_17944 = 1;
L8: 
            if (binary_op_a(GREATER, _j_17944, _10093)){
                goto L9; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _10094 = _38get4();
            _2 = (int)SEQ_PTR(_38key_pointers_16706);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _38key_pointers_16706 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_17908);
            _1 = *(int *)_2;
            *(int *)_2 = _10094;
            if( _1 != _10094 ){
                DeRef(_1);
            }
            _10094 = NOVALUE;

            /** 				k += 1*/
            _k_17908 = _k_17908 + 1;

            /** 			end for*/
            _0 = _j_17944;
            if (IS_ATOM_INT(_j_17944)) {
                _j_17944 = _j_17944 + 1;
                if ((long)((unsigned long)_j_17944 +(unsigned long) HIGH_BITS) >= 0){
                    _j_17944 = NewDouble((double)_j_17944);
                }
            }
            else {
                _j_17944 = binary_op_a(PLUS, _j_17944, 1);
            }
            DeRef(_0);
            goto L8; // [250] 231
L9: 
            ;
            DeRef(_j_17944);
        }

        /** 			index += 8*/
        _0 = _index_17904;
        if (IS_ATOM_INT(_index_17904)) {
            _index_17904 = _index_17904 + 8;
            if ((long)((unsigned long)_index_17904 + (unsigned long)HIGH_BITS) >= 0) 
            _index_17904 = NewDouble((double)_index_17904);
        }
        else {
            _index_17904 = NewDouble(DBL_PTR(_index_17904)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_17933;
        if (IS_ATOM_INT(_b_17933)) {
            _b_17933 = _b_17933 + 1;
            if ((long)((unsigned long)_b_17933 +(unsigned long) HIGH_BITS) >= 0){
                _b_17933 = NewDouble((double)_b_17933);
            }
        }
        else {
            _b_17933 = binary_op_a(PLUS, _b_17933, 1);
        }
        DeRef(_0);
        goto L6; // [263] 175
L7: 
        ;
        DeRef(_b_17933);
    }
L5: 

    /** 	return DB_OK*/
    DeRefDS(_name_17901);
    DeRef(_table_17902);
    DeRef(_nkeys_17903);
    DeRef(_index_17904);
    DeRef(_block_ptr_17905);
    DeRef(_block_size_17906);
    DeRef(_10090);
    _10090 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _38db_current_table()
{
    int _0, _1, _2;
    

    /** 	return current_table_name*/
    RefDS(_38current_table_name_16701);
    return _38current_table_name_16701;
    ;
}


int  __stdcall _38db_create_table(int _name_17953, int _init_records_17954)
{
    int _name_ptr_17955 = NOVALUE;
    int _nt_17956 = NOVALUE;
    int _tables_17957 = NOVALUE;
    int _newtables_17958 = NOVALUE;
    int _table_17959 = NOVALUE;
    int _records_ptr_17960 = NOVALUE;
    int _size_17961 = NOVALUE;
    int _newsize_17962 = NOVALUE;
    int _index_ptr_17963 = NOVALUE;
    int _remaining_17964 = NOVALUE;
    int _init_index_17965 = NOVALUE;
    int _seek_1__tmp_at68_17979 = NOVALUE;
    int _seek_inlined_seek_at_68_17978 = NOVALUE;
    int _seek_1__tmp_at97_17985 = NOVALUE;
    int _seek_inlined_seek_at_97_17984 = NOVALUE;
    int _pos_inlined_seek_at_94_17983 = NOVALUE;
    int _put4_1__tmp_at159_17998 = NOVALUE;
    int _seek_1__tmp_at196_18003 = NOVALUE;
    int _seek_inlined_seek_at_196_18002 = NOVALUE;
    int _pos_inlined_seek_at_193_18001 = NOVALUE;
    int _seek_1__tmp_at239_18011 = NOVALUE;
    int _seek_inlined_seek_at_239_18010 = NOVALUE;
    int _pos_inlined_seek_at_236_18009 = NOVALUE;
    int _s_inlined_putn_at_288_18019 = NOVALUE;
    int _seek_1__tmp_at316_18022 = NOVALUE;
    int _seek_inlined_seek_at_316_18021 = NOVALUE;
    int _put4_1__tmp_at331_18024 = NOVALUE;
    int _seek_1__tmp_at369_18028 = NOVALUE;
    int _seek_inlined_seek_at_369_18027 = NOVALUE;
    int _put4_1__tmp_at384_18030 = NOVALUE;
    int _s_inlined_putn_at_431_18036 = NOVALUE;
    int _put4_1__tmp_at462_18040 = NOVALUE;
    int _put4_1__tmp_at490_18042 = NOVALUE;
    int _s_inlined_putn_at_530_18047 = NOVALUE;
    int _s_inlined_putn_at_568_18053 = NOVALUE;
    int _seek_1__tmp_at610_18061 = NOVALUE;
    int _seek_inlined_seek_at_610_18060 = NOVALUE;
    int _pos_inlined_seek_at_607_18059 = NOVALUE;
    int _put4_1__tmp_at625_18063 = NOVALUE;
    int _put4_1__tmp_at653_18065 = NOVALUE;
    int _put4_1__tmp_at681_18067 = NOVALUE;
    int _put4_1__tmp_at709_18069 = NOVALUE;
    int _10143 = NOVALUE;
    int _10142 = NOVALUE;
    int _10141 = NOVALUE;
    int _10140 = NOVALUE;
    int _10139 = NOVALUE;
    int _10138 = NOVALUE;
    int _10136 = NOVALUE;
    int _10135 = NOVALUE;
    int _10134 = NOVALUE;
    int _10133 = NOVALUE;
    int _10132 = NOVALUE;
    int _10130 = NOVALUE;
    int _10129 = NOVALUE;
    int _10128 = NOVALUE;
    int _10126 = NOVALUE;
    int _10125 = NOVALUE;
    int _10124 = NOVALUE;
    int _10123 = NOVALUE;
    int _10122 = NOVALUE;
    int _10121 = NOVALUE;
    int _10120 = NOVALUE;
    int _10118 = NOVALUE;
    int _10117 = NOVALUE;
    int _10116 = NOVALUE;
    int _10113 = NOVALUE;
    int _10112 = NOVALUE;
    int _10110 = NOVALUE;
    int _10109 = NOVALUE;
    int _10107 = NOVALUE;
    int _10105 = NOVALUE;
    int _10102 = NOVALUE;
    int _10097 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_init_records_17954)) {
        _1 = (long)(DBL_PTR(_init_records_17954)->dbl);
        DeRefDS(_init_records_17954);
        _init_records_17954 = _1;
    }

    /** 	if not cstring(name) then*/
    RefDS(_name_17953);
    _10097 = _7cstring(_name_17953);
    if (IS_ATOM_INT(_10097)) {
        if (_10097 != 0){
            DeRef(_10097);
            _10097 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_10097)->dbl != 0.0){
            DeRef(_10097);
            _10097 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_10097);
    _10097 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_17953);
    DeRef(_name_ptr_17955);
    DeRef(_nt_17956);
    DeRef(_tables_17957);
    DeRef(_newtables_17958);
    DeRef(_table_17959);
    DeRef(_records_ptr_17960);
    DeRef(_size_17961);
    DeRef(_newsize_17962);
    DeRef(_index_ptr_17963);
    DeRef(_remaining_17964);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_17953);
    _0 = _table_17959;
    _table_17959 = _38table_find(_name_17953);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_17959, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_17953);
    DeRef(_name_ptr_17955);
    DeRef(_nt_17956);
    DeRef(_tables_17957);
    DeRef(_newtables_17958);
    DeRef(_table_17959);
    DeRef(_records_ptr_17960);
    DeRef(_size_17961);
    DeRef(_newsize_17962);
    DeRef(_index_ptr_17963);
    DeRef(_remaining_17964);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_17954 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_17954 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_17954;
    ((int *)_2)[2] = 10;
    _10102 = MAKE_SEQ(_1);
    _init_index_17965 = _20min(_10102);
    _10102 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_17965)) {
        _1 = (long)(DBL_PTR(_init_index_17965)->dbl);
        DeRefDS(_init_index_17965);
        _init_index_17965 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_17979);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_17979 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_17978 = machine(19, _seek_1__tmp_at68_17979);
    DeRefi(_seek_1__tmp_at68_17979);
    _seek_1__tmp_at68_17979 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_17957;
    _tables_17957 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_17957)) {
        _10105 = _tables_17957 - 4;
        if ((long)((unsigned long)_10105 +(unsigned long) HIGH_BITS) >= 0){
            _10105 = NewDouble((double)_10105);
        }
    }
    else {
        _10105 = NewDouble(DBL_PTR(_tables_17957)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_17983);
    _pos_inlined_seek_at_94_17983 = _10105;
    _10105 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_17983);
    DeRef(_seek_1__tmp_at97_17985);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_17983;
    _seek_1__tmp_at97_17985 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_17984 = machine(19, _seek_1__tmp_at97_17985);
    DeRef(_pos_inlined_seek_at_94_17983);
    _pos_inlined_seek_at_94_17983 = NOVALUE;
    DeRef(_seek_1__tmp_at97_17985);
    _seek_1__tmp_at97_17985 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_17961;
    _size_17961 = _38get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _10107 = _38get4();
    DeRef(_nt_17956);
    if (IS_ATOM_INT(_10107)) {
        _nt_17956 = _10107 + 1;
        if (_nt_17956 > MAXINT){
            _nt_17956 = NewDouble((double)_nt_17956);
        }
    }
    else
    _nt_17956 = binary_op(PLUS, 1, _10107);
    DeRef(_10107);
    _10107 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_17956)) {
        if (_nt_17956 == (short)_nt_17956)
        _10109 = _nt_17956 * 16;
        else
        _10109 = NewDouble(_nt_17956 * (double)16);
    }
    else {
        _10109 = NewDouble(DBL_PTR(_nt_17956)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10109)) {
        _10110 = _10109 + 8;
        if ((long)((unsigned long)_10110 + (unsigned long)HIGH_BITS) >= 0) 
        _10110 = NewDouble((double)_10110);
    }
    else {
        _10110 = NewDouble(DBL_PTR(_10109)->dbl + (double)8);
    }
    DeRef(_10109);
    _10109 = NOVALUE;
    if (binary_op_a(LESSEQ, _10110, _size_17961)){
        DeRef(_10110);
        _10110 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_10110);
    _10110 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_17961)) {
        if (_size_17961 & 1) {
            _10112 = NewDouble((_size_17961 >> 1) + 0.5);
        }
        else
        _10112 = _size_17961 >> 1;
    }
    else {
        _10112 = binary_op(DIVIDE, _size_17961, 2);
    }
    if (IS_ATOM_INT(_size_17961) && IS_ATOM_INT(_10112)) {
        _10113 = _size_17961 + _10112;
        if ((long)((unsigned long)_10113 + (unsigned long)HIGH_BITS) >= 0) 
        _10113 = NewDouble((double)_10113);
    }
    else {
        if (IS_ATOM_INT(_size_17961)) {
            _10113 = NewDouble((double)_size_17961 + DBL_PTR(_10112)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10112)) {
                _10113 = NewDouble(DBL_PTR(_size_17961)->dbl + (double)_10112);
            }
            else
            _10113 = NewDouble(DBL_PTR(_size_17961)->dbl + DBL_PTR(_10112)->dbl);
        }
    }
    DeRef(_10112);
    _10112 = NOVALUE;
    DeRef(_newsize_17962);
    if (IS_ATOM_INT(_10113))
    _newsize_17962 = e_floor(_10113);
    else
    _newsize_17962 = unary_op(FLOOR, _10113);
    DeRef(_10113);
    _10113 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_17962);
    _0 = _newtables_17958;
    _newtables_17958 = _38db_allocate(_newsize_17962);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nt_17956)) {
        *poke4_addr = (unsigned long)_nt_17956;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_17956)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_17998);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_17998 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at159_17998); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_17998);
    _put4_1__tmp_at159_17998 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_17957)) {
        _10116 = _tables_17957 + 4;
        if ((long)((unsigned long)_10116 + (unsigned long)HIGH_BITS) >= 0) 
        _10116 = NewDouble((double)_10116);
    }
    else {
        _10116 = NewDouble(DBL_PTR(_tables_17957)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_18001);
    _pos_inlined_seek_at_193_18001 = _10116;
    _10116 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_18001);
    DeRef(_seek_1__tmp_at196_18003);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_18001;
    _seek_1__tmp_at196_18003 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_18002 = machine(19, _seek_1__tmp_at196_18003);
    DeRef(_pos_inlined_seek_at_193_18001);
    _pos_inlined_seek_at_193_18001 = NOVALUE;
    DeRef(_seek_1__tmp_at196_18003);
    _seek_1__tmp_at196_18003 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_17956)) {
        _10117 = _nt_17956 - 1;
        if ((long)((unsigned long)_10117 +(unsigned long) HIGH_BITS) >= 0){
            _10117 = NewDouble((double)_10117);
        }
    }
    else {
        _10117 = NewDouble(DBL_PTR(_nt_17956)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10117)) {
        if (_10117 == (short)_10117)
        _10118 = _10117 * 16;
        else
        _10118 = NewDouble(_10117 * (double)16);
    }
    else {
        _10118 = NewDouble(DBL_PTR(_10117)->dbl * (double)16);
    }
    DeRef(_10117);
    _10117 = NOVALUE;
    _0 = _remaining_17964;
    _remaining_17964 = _18get_bytes(_38current_db_16699, _10118);
    DeRef(_0);
    _10118 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_17958)) {
        _10120 = _newtables_17958 + 4;
        if ((long)((unsigned long)_10120 + (unsigned long)HIGH_BITS) >= 0) 
        _10120 = NewDouble((double)_10120);
    }
    else {
        _10120 = NewDouble(DBL_PTR(_newtables_17958)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_18009);
    _pos_inlined_seek_at_236_18009 = _10120;
    _10120 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_18009);
    DeRef(_seek_1__tmp_at239_18011);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_18009;
    _seek_1__tmp_at239_18011 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_18010 = machine(19, _seek_1__tmp_at239_18011);
    DeRef(_pos_inlined_seek_at_236_18009);
    _pos_inlined_seek_at_236_18009 = NOVALUE;
    DeRef(_seek_1__tmp_at239_18011);
    _seek_1__tmp_at239_18011 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_17964); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_17962)) {
        _10121 = _newsize_17962 - 4;
        if ((long)((unsigned long)_10121 +(unsigned long) HIGH_BITS) >= 0){
            _10121 = NewDouble((double)_10121);
        }
    }
    else {
        _10121 = NewDouble(DBL_PTR(_newsize_17962)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_17956)) {
        _10122 = _nt_17956 - 1;
        if ((long)((unsigned long)_10122 +(unsigned long) HIGH_BITS) >= 0){
            _10122 = NewDouble((double)_10122);
        }
    }
    else {
        _10122 = NewDouble(DBL_PTR(_nt_17956)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10122)) {
        if (_10122 == (short)_10122)
        _10123 = _10122 * 16;
        else
        _10123 = NewDouble(_10122 * (double)16);
    }
    else {
        _10123 = NewDouble(DBL_PTR(_10122)->dbl * (double)16);
    }
    DeRef(_10122);
    _10122 = NOVALUE;
    if (IS_ATOM_INT(_10121) && IS_ATOM_INT(_10123)) {
        _10124 = _10121 - _10123;
    }
    else {
        if (IS_ATOM_INT(_10121)) {
            _10124 = NewDouble((double)_10121 - DBL_PTR(_10123)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10123)) {
                _10124 = NewDouble(DBL_PTR(_10121)->dbl - (double)_10123);
            }
            else
            _10124 = NewDouble(DBL_PTR(_10121)->dbl - DBL_PTR(_10123)->dbl);
        }
    }
    DeRef(_10121);
    _10121 = NOVALUE;
    DeRef(_10123);
    _10123 = NOVALUE;
    _10125 = Repeat(0, _10124);
    DeRef(_10124);
    _10124 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_18019);
    _s_inlined_putn_at_288_18019 = _10125;
    _10125 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_288_18019); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_18019);
    _s_inlined_putn_at_288_18019 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_17957);
    _38db_free(_tables_17957);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_18022);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_18022 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_18021 = machine(19, _seek_1__tmp_at316_18022);
    DeRefi(_seek_1__tmp_at316_18022);
    _seek_1__tmp_at316_18022 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_newtables_17958)) {
        *poke4_addr = (unsigned long)_newtables_17958;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_17958)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_18024);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_18024 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at331_18024); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_18024);
    _put4_1__tmp_at331_18024 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_17958);
    DeRef(_tables_17957);
    _tables_17957 = _newtables_17958;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17957);
    DeRef(_seek_1__tmp_at369_18028);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_17957;
    _seek_1__tmp_at369_18028 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_18027 = machine(19, _seek_1__tmp_at369_18028);
    DeRef(_seek_1__tmp_at369_18028);
    _seek_1__tmp_at369_18028 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nt_17956)) {
        *poke4_addr = (unsigned long)_nt_17956;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_17956)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_18030);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_18030 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at384_18030); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_18030);
    _put4_1__tmp_at384_18030 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_17954 == (short)_init_records_17954)
    _10126 = _init_records_17954 * 4;
    else
    _10126 = NewDouble(_init_records_17954 * (double)4);
    _0 = _records_ptr_17960;
    _records_ptr_17960 = _38db_allocate(_10126);
    DeRef(_0);
    _10126 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10128 = _init_records_17954 * 4;
    _10129 = Repeat(0, _10128);
    _10128 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_18036);
    _s_inlined_putn_at_431_18036 = _10129;
    _10129 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_431_18036); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_18036);
    _s_inlined_putn_at_431_18036 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_17965 == (short)_init_index_17965)
    _10130 = _init_index_17965 * 8;
    else
    _10130 = NewDouble(_init_index_17965 * (double)8);
    _0 = _index_ptr_17963;
    _index_ptr_17963 = _38db_allocate(_10130);
    DeRef(_0);
    _10130 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_18040);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_18040 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at462_18040); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_18040);
    _put4_1__tmp_at462_18040 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_17960)) {
        *poke4_addr = (unsigned long)_records_ptr_17960;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_17960)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_18042);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_18042 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at490_18042); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_18042);
    _put4_1__tmp_at490_18042 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10132 = _init_index_17965 - 1;
    if ((long)((unsigned long)_10132 +(unsigned long) HIGH_BITS) >= 0){
        _10132 = NewDouble((double)_10132);
    }
    if (IS_ATOM_INT(_10132)) {
        _10133 = _10132 * 8;
    }
    else {
        _10133 = NewDouble(DBL_PTR(_10132)->dbl * (double)8);
    }
    DeRef(_10132);
    _10132 = NOVALUE;
    _10134 = Repeat(0, _10133);
    DeRef(_10133);
    _10133 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_18047);
    _s_inlined_putn_at_530_18047 = _10134;
    _10134 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_530_18047); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_18047);
    _s_inlined_putn_at_530_18047 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_17953)){
            _10135 = SEQ_PTR(_name_17953)->length;
    }
    else {
        _10135 = 1;
    }
    _10136 = _10135 + 1;
    _10135 = NOVALUE;
    _0 = _name_ptr_17955;
    _name_ptr_17955 = _38db_allocate(_10136);
    DeRef(_0);
    _10136 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_10138, _name_17953, 0);
    DeRef(_s_inlined_putn_at_568_18053);
    _s_inlined_putn_at_568_18053 = _10138;
    _10138 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_568_18053); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_18053);
    _s_inlined_putn_at_568_18053 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_17957)) {
        _10139 = _tables_17957 + 4;
        if ((long)((unsigned long)_10139 + (unsigned long)HIGH_BITS) >= 0) 
        _10139 = NewDouble((double)_10139);
    }
    else {
        _10139 = NewDouble(DBL_PTR(_tables_17957)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_17956)) {
        _10140 = _nt_17956 - 1;
        if ((long)((unsigned long)_10140 +(unsigned long) HIGH_BITS) >= 0){
            _10140 = NewDouble((double)_10140);
        }
    }
    else {
        _10140 = NewDouble(DBL_PTR(_nt_17956)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10140)) {
        if (_10140 == (short)_10140)
        _10141 = _10140 * 16;
        else
        _10141 = NewDouble(_10140 * (double)16);
    }
    else {
        _10141 = NewDouble(DBL_PTR(_10140)->dbl * (double)16);
    }
    DeRef(_10140);
    _10140 = NOVALUE;
    if (IS_ATOM_INT(_10139) && IS_ATOM_INT(_10141)) {
        _10142 = _10139 + _10141;
        if ((long)((unsigned long)_10142 + (unsigned long)HIGH_BITS) >= 0) 
        _10142 = NewDouble((double)_10142);
    }
    else {
        if (IS_ATOM_INT(_10139)) {
            _10142 = NewDouble((double)_10139 + DBL_PTR(_10141)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10141)) {
                _10142 = NewDouble(DBL_PTR(_10139)->dbl + (double)_10141);
            }
            else
            _10142 = NewDouble(DBL_PTR(_10139)->dbl + DBL_PTR(_10141)->dbl);
        }
    }
    DeRef(_10139);
    _10139 = NOVALUE;
    DeRef(_10141);
    _10141 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_18059);
    _pos_inlined_seek_at_607_18059 = _10142;
    _10142 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_18059);
    DeRef(_seek_1__tmp_at610_18061);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_18059;
    _seek_1__tmp_at610_18061 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_18060 = machine(19, _seek_1__tmp_at610_18061);
    DeRef(_pos_inlined_seek_at_607_18059);
    _pos_inlined_seek_at_607_18059 = NOVALUE;
    DeRef(_seek_1__tmp_at610_18061);
    _seek_1__tmp_at610_18061 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_17955)) {
        *poke4_addr = (unsigned long)_name_ptr_17955;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_17955)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_18063);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_18063 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at625_18063); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_18063);
    _put4_1__tmp_at625_18063 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_18065);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_18065 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at653_18065); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_18065);
    _put4_1__tmp_at653_18065 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_18067);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_18067 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at681_18067); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_18067);
    _put4_1__tmp_at681_18067 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17963)) {
        *poke4_addr = (unsigned long)_index_ptr_17963;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_17963)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_18069);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_18069 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at709_18069); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_18069);
    _put4_1__tmp_at709_18069 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_17953);
    _10143 = _38db_select_table(_name_17953);
    if (_10143 == 0) {
        DeRef(_10143);
        _10143 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_10143) && DBL_PTR(_10143)->dbl == 0.0){
            DeRef(_10143);
            _10143 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_10143);
        _10143 = NOVALUE;
    }
    DeRef(_10143);
    _10143 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_17953);
    DeRef(_name_ptr_17955);
    DeRef(_nt_17956);
    DeRef(_tables_17957);
    DeRef(_newtables_17958);
    DeRef(_table_17959);
    DeRef(_records_ptr_17960);
    DeRef(_size_17961);
    DeRef(_newsize_17962);
    DeRef(_index_ptr_17963);
    DeRef(_remaining_17964);
    return 0;
    ;
}


void  __stdcall _38db_delete_table(int _name_18074)
{
    int _table_18075 = NOVALUE;
    int _tables_18076 = NOVALUE;
    int _nt_18077 = NOVALUE;
    int _nrecs_18078 = NOVALUE;
    int _records_ptr_18079 = NOVALUE;
    int _blocks_18080 = NOVALUE;
    int _p_18081 = NOVALUE;
    int _data_ptr_18082 = NOVALUE;
    int _index_18083 = NOVALUE;
    int _remaining_18084 = NOVALUE;
    int _k_18085 = NOVALUE;
    int _seek_1__tmp_at24_18091 = NOVALUE;
    int _seek_inlined_seek_at_24_18090 = NOVALUE;
    int _seek_1__tmp_at56_18097 = NOVALUE;
    int _seek_inlined_seek_at_56_18096 = NOVALUE;
    int _pos_inlined_seek_at_53_18095 = NOVALUE;
    int _seek_1__tmp_at112_18109 = NOVALUE;
    int _seek_inlined_seek_at_112_18108 = NOVALUE;
    int _pos_inlined_seek_at_109_18107 = NOVALUE;
    int _seek_1__tmp_at163_18120 = NOVALUE;
    int _seek_inlined_seek_at_163_18119 = NOVALUE;
    int _pos_inlined_seek_at_160_18118 = NOVALUE;
    int _seek_1__tmp_at185_18124 = NOVALUE;
    int _seek_inlined_seek_at_185_18123 = NOVALUE;
    int _seek_1__tmp_at241_18128 = NOVALUE;
    int _seek_inlined_seek_at_241_18127 = NOVALUE;
    int _seek_1__tmp_at263_18132 = NOVALUE;
    int _seek_inlined_seek_at_263_18131 = NOVALUE;
    int _seek_1__tmp_at292_18138 = NOVALUE;
    int _seek_inlined_seek_at_292_18137 = NOVALUE;
    int _pos_inlined_seek_at_289_18136 = NOVALUE;
    int _seek_1__tmp_at340_18147 = NOVALUE;
    int _seek_inlined_seek_at_340_18146 = NOVALUE;
    int _seek_1__tmp_at377_18152 = NOVALUE;
    int _seek_inlined_seek_at_377_18151 = NOVALUE;
    int _put4_1__tmp_at392_18154 = NOVALUE;
    int _seek_1__tmp_at505_18168 = NOVALUE;
    int _seek_inlined_seek_at_505_18167 = NOVALUE;
    int _seek_1__tmp_at527_18172 = NOVALUE;
    int _seek_inlined_seek_at_527_18171 = NOVALUE;
    int _10171 = NOVALUE;
    int _10168 = NOVALUE;
    int _10167 = NOVALUE;
    int _10166 = NOVALUE;
    int _10165 = NOVALUE;
    int _10164 = NOVALUE;
    int _10163 = NOVALUE;
    int _10158 = NOVALUE;
    int _10157 = NOVALUE;
    int _10156 = NOVALUE;
    int _10153 = NOVALUE;
    int _10152 = NOVALUE;
    int _10151 = NOVALUE;
    int _10147 = NOVALUE;
    int _10146 = NOVALUE;
    int _0, _1, _2;
    

    /** 	table = table_find(name)*/
    RefDS(_name_18074);
    _0 = _table_18075;
    _table_18075 = _38table_find(_name_18074);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18075, -1)){
        goto L1; // [11] 21
    }

    /** 		return*/
    DeRefDS(_name_18074);
    DeRef(_table_18075);
    DeRef(_tables_18076);
    DeRef(_nt_18077);
    DeRef(_nrecs_18078);
    DeRef(_records_ptr_18079);
    DeRef(_blocks_18080);
    DeRef(_p_18081);
    DeRef(_data_ptr_18082);
    DeRef(_index_18083);
    DeRef(_remaining_18084);
    return;
L1: 

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_18075);
    DeRef(_seek_1__tmp_at24_18091);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _table_18075;
    _seek_1__tmp_at24_18091 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_24_18090 = machine(19, _seek_1__tmp_at24_18091);
    DeRef(_seek_1__tmp_at24_18091);
    _seek_1__tmp_at24_18091 = NOVALUE;

    /** 	db_free(get4())*/
    _10146 = _38get4();
    _38db_free(_10146);
    _10146 = NOVALUE;

    /** 	io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18075)) {
        _10147 = _table_18075 + 4;
        if ((long)((unsigned long)_10147 + (unsigned long)HIGH_BITS) >= 0) 
        _10147 = NewDouble((double)_10147);
    }
    else {
        _10147 = NewDouble(DBL_PTR(_table_18075)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_53_18095);
    _pos_inlined_seek_at_53_18095 = _10147;
    _10147 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_53_18095);
    DeRef(_seek_1__tmp_at56_18097);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_53_18095;
    _seek_1__tmp_at56_18097 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_56_18096 = machine(19, _seek_1__tmp_at56_18097);
    DeRef(_pos_inlined_seek_at_53_18095);
    _pos_inlined_seek_at_53_18095 = NOVALUE;
    DeRef(_seek_1__tmp_at56_18097);
    _seek_1__tmp_at56_18097 = NOVALUE;

    /** 	nrecs = get4()*/
    _0 = _nrecs_18078;
    _nrecs_18078 = _38get4();
    DeRef(_0);

    /** 	blocks = get4()*/
    _0 = _blocks_18080;
    _blocks_18080 = _38get4();
    DeRef(_0);

    /** 	index = get4()*/
    _0 = _index_18083;
    _index_18083 = _38get4();
    DeRef(_0);

    /** 	for b = 0 to blocks-1 do*/
    if (IS_ATOM_INT(_blocks_18080)) {
        _10151 = _blocks_18080 - 1;
        if ((long)((unsigned long)_10151 +(unsigned long) HIGH_BITS) >= 0){
            _10151 = NewDouble((double)_10151);
        }
    }
    else {
        _10151 = NewDouble(DBL_PTR(_blocks_18080)->dbl - (double)1);
    }
    {
        int _b_18102;
        _b_18102 = 0;
L2: 
        if (binary_op_a(GREATER, _b_18102, _10151)){
            goto L3; // [91] 233
        }

        /** 		io:seek(current_db, index+b*8)*/
        if (IS_ATOM_INT(_b_18102)) {
            if (_b_18102 == (short)_b_18102)
            _10152 = _b_18102 * 8;
            else
            _10152 = NewDouble(_b_18102 * (double)8);
        }
        else {
            _10152 = NewDouble(DBL_PTR(_b_18102)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_index_18083) && IS_ATOM_INT(_10152)) {
            _10153 = _index_18083 + _10152;
            if ((long)((unsigned long)_10153 + (unsigned long)HIGH_BITS) >= 0) 
            _10153 = NewDouble((double)_10153);
        }
        else {
            if (IS_ATOM_INT(_index_18083)) {
                _10153 = NewDouble((double)_index_18083 + DBL_PTR(_10152)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10152)) {
                    _10153 = NewDouble(DBL_PTR(_index_18083)->dbl + (double)_10152);
                }
                else
                _10153 = NewDouble(DBL_PTR(_index_18083)->dbl + DBL_PTR(_10152)->dbl);
            }
        }
        DeRef(_10152);
        _10152 = NOVALUE;
        DeRef(_pos_inlined_seek_at_109_18107);
        _pos_inlined_seek_at_109_18107 = _10153;
        _10153 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_109_18107);
        DeRef(_seek_1__tmp_at112_18109);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_109_18107;
        _seek_1__tmp_at112_18109 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_112_18108 = machine(19, _seek_1__tmp_at112_18109);
        DeRef(_pos_inlined_seek_at_109_18107);
        _pos_inlined_seek_at_109_18107 = NOVALUE;
        DeRef(_seek_1__tmp_at112_18109);
        _seek_1__tmp_at112_18109 = NOVALUE;

        /** 		nrecs = get4()*/
        _0 = _nrecs_18078;
        _nrecs_18078 = _38get4();
        DeRef(_0);

        /** 		records_ptr = get4()*/
        _0 = _records_ptr_18079;
        _records_ptr_18079 = _38get4();
        DeRef(_0);

        /** 		for r = 0 to nrecs-1 do*/
        if (IS_ATOM_INT(_nrecs_18078)) {
            _10156 = _nrecs_18078 - 1;
            if ((long)((unsigned long)_10156 +(unsigned long) HIGH_BITS) >= 0){
                _10156 = NewDouble((double)_10156);
            }
        }
        else {
            _10156 = NewDouble(DBL_PTR(_nrecs_18078)->dbl - (double)1);
        }
        {
            int _r_18113;
            _r_18113 = 0;
L4: 
            if (binary_op_a(GREATER, _r_18113, _10156)){
                goto L5; // [142] 221
            }

            /** 			io:seek(current_db, records_ptr + r*4)*/
            if (IS_ATOM_INT(_r_18113)) {
                if (_r_18113 == (short)_r_18113)
                _10157 = _r_18113 * 4;
                else
                _10157 = NewDouble(_r_18113 * (double)4);
            }
            else {
                _10157 = NewDouble(DBL_PTR(_r_18113)->dbl * (double)4);
            }
            if (IS_ATOM_INT(_records_ptr_18079) && IS_ATOM_INT(_10157)) {
                _10158 = _records_ptr_18079 + _10157;
                if ((long)((unsigned long)_10158 + (unsigned long)HIGH_BITS) >= 0) 
                _10158 = NewDouble((double)_10158);
            }
            else {
                if (IS_ATOM_INT(_records_ptr_18079)) {
                    _10158 = NewDouble((double)_records_ptr_18079 + DBL_PTR(_10157)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_10157)) {
                        _10158 = NewDouble(DBL_PTR(_records_ptr_18079)->dbl + (double)_10157);
                    }
                    else
                    _10158 = NewDouble(DBL_PTR(_records_ptr_18079)->dbl + DBL_PTR(_10157)->dbl);
                }
            }
            DeRef(_10157);
            _10157 = NOVALUE;
            DeRef(_pos_inlined_seek_at_160_18118);
            _pos_inlined_seek_at_160_18118 = _10158;
            _10158 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_160_18118);
            DeRef(_seek_1__tmp_at163_18120);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16699;
            ((int *)_2)[2] = _pos_inlined_seek_at_160_18118;
            _seek_1__tmp_at163_18120 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_163_18119 = machine(19, _seek_1__tmp_at163_18120);
            DeRef(_pos_inlined_seek_at_160_18118);
            _pos_inlined_seek_at_160_18118 = NOVALUE;
            DeRef(_seek_1__tmp_at163_18120);
            _seek_1__tmp_at163_18120 = NOVALUE;

            /** 			p = get4()*/
            _0 = _p_18081;
            _p_18081 = _38get4();
            DeRef(_0);

            /** 			io:seek(current_db, p)*/

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_p_18081);
            DeRef(_seek_1__tmp_at185_18124);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16699;
            ((int *)_2)[2] = _p_18081;
            _seek_1__tmp_at185_18124 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_185_18123 = machine(19, _seek_1__tmp_at185_18124);
            DeRef(_seek_1__tmp_at185_18124);
            _seek_1__tmp_at185_18124 = NOVALUE;

            /** 			data_ptr = get4()*/
            _0 = _data_ptr_18082;
            _data_ptr_18082 = _38get4();
            DeRef(_0);

            /** 			db_free(data_ptr)*/
            Ref(_data_ptr_18082);
            _38db_free(_data_ptr_18082);

            /** 			db_free(p)*/
            Ref(_p_18081);
            _38db_free(_p_18081);

            /** 		end for*/
            _0 = _r_18113;
            if (IS_ATOM_INT(_r_18113)) {
                _r_18113 = _r_18113 + 1;
                if ((long)((unsigned long)_r_18113 +(unsigned long) HIGH_BITS) >= 0){
                    _r_18113 = NewDouble((double)_r_18113);
                }
            }
            else {
                _r_18113 = binary_op_a(PLUS, _r_18113, 1);
            }
            DeRef(_0);
            goto L4; // [216] 149
L5: 
            ;
            DeRef(_r_18113);
        }

        /** 		db_free(records_ptr)*/
        Ref(_records_ptr_18079);
        _38db_free(_records_ptr_18079);

        /** 	end for*/
        _0 = _b_18102;
        if (IS_ATOM_INT(_b_18102)) {
            _b_18102 = _b_18102 + 1;
            if ((long)((unsigned long)_b_18102 +(unsigned long) HIGH_BITS) >= 0){
                _b_18102 = NewDouble((double)_b_18102);
            }
        }
        else {
            _b_18102 = binary_op_a(PLUS, _b_18102, 1);
        }
        DeRef(_0);
        goto L2; // [228] 98
L3: 
        ;
        DeRef(_b_18102);
    }

    /** 	db_free(index)*/
    Ref(_index_18083);
    _38db_free(_index_18083);

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at241_18128);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at241_18128 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_241_18127 = machine(19, _seek_1__tmp_at241_18128);
    DeRefi(_seek_1__tmp_at241_18128);
    _seek_1__tmp_at241_18128 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_18076;
    _tables_18076 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18076);
    DeRef(_seek_1__tmp_at263_18132);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_18076;
    _seek_1__tmp_at263_18132 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_263_18131 = machine(19, _seek_1__tmp_at263_18132);
    DeRef(_seek_1__tmp_at263_18132);
    _seek_1__tmp_at263_18132 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18077;
    _nt_18077 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, table+SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_table_18075)) {
        _10163 = _table_18075 + 16;
        if ((long)((unsigned long)_10163 + (unsigned long)HIGH_BITS) >= 0) 
        _10163 = NewDouble((double)_10163);
    }
    else {
        _10163 = NewDouble(DBL_PTR(_table_18075)->dbl + (double)16);
    }
    DeRef(_pos_inlined_seek_at_289_18136);
    _pos_inlined_seek_at_289_18136 = _10163;
    _10163 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_289_18136);
    DeRef(_seek_1__tmp_at292_18138);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_289_18136;
    _seek_1__tmp_at292_18138 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_292_18137 = machine(19, _seek_1__tmp_at292_18138);
    DeRef(_pos_inlined_seek_at_289_18136);
    _pos_inlined_seek_at_289_18136 = NOVALUE;
    DeRef(_seek_1__tmp_at292_18138);
    _seek_1__tmp_at292_18138 = NOVALUE;

    /** 	remaining = io:get_bytes(current_db,*/
    if (IS_ATOM_INT(_tables_18076)) {
        _10164 = _tables_18076 + 4;
        if ((long)((unsigned long)_10164 + (unsigned long)HIGH_BITS) >= 0) 
        _10164 = NewDouble((double)_10164);
    }
    else {
        _10164 = NewDouble(DBL_PTR(_tables_18076)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_18077)) {
        if (_nt_18077 == (short)_nt_18077)
        _10165 = _nt_18077 * 16;
        else
        _10165 = NewDouble(_nt_18077 * (double)16);
    }
    else {
        _10165 = NewDouble(DBL_PTR(_nt_18077)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10164) && IS_ATOM_INT(_10165)) {
        _10166 = _10164 + _10165;
        if ((long)((unsigned long)_10166 + (unsigned long)HIGH_BITS) >= 0) 
        _10166 = NewDouble((double)_10166);
    }
    else {
        if (IS_ATOM_INT(_10164)) {
            _10166 = NewDouble((double)_10164 + DBL_PTR(_10165)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10165)) {
                _10166 = NewDouble(DBL_PTR(_10164)->dbl + (double)_10165);
            }
            else
            _10166 = NewDouble(DBL_PTR(_10164)->dbl + DBL_PTR(_10165)->dbl);
        }
    }
    DeRef(_10164);
    _10164 = NOVALUE;
    DeRef(_10165);
    _10165 = NOVALUE;
    if (IS_ATOM_INT(_table_18075)) {
        _10167 = _table_18075 + 16;
        if ((long)((unsigned long)_10167 + (unsigned long)HIGH_BITS) >= 0) 
        _10167 = NewDouble((double)_10167);
    }
    else {
        _10167 = NewDouble(DBL_PTR(_table_18075)->dbl + (double)16);
    }
    if (IS_ATOM_INT(_10166) && IS_ATOM_INT(_10167)) {
        _10168 = _10166 - _10167;
        if ((long)((unsigned long)_10168 +(unsigned long) HIGH_BITS) >= 0){
            _10168 = NewDouble((double)_10168);
        }
    }
    else {
        if (IS_ATOM_INT(_10166)) {
            _10168 = NewDouble((double)_10166 - DBL_PTR(_10167)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10167)) {
                _10168 = NewDouble(DBL_PTR(_10166)->dbl - (double)_10167);
            }
            else
            _10168 = NewDouble(DBL_PTR(_10166)->dbl - DBL_PTR(_10167)->dbl);
        }
    }
    DeRef(_10166);
    _10166 = NOVALUE;
    DeRef(_10167);
    _10167 = NOVALUE;
    _0 = _remaining_18084;
    _remaining_18084 = _18get_bytes(_38current_db_16699, _10168);
    DeRef(_0);
    _10168 = NOVALUE;

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_18075);
    DeRef(_seek_1__tmp_at340_18147);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _table_18075;
    _seek_1__tmp_at340_18147 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_340_18146 = machine(19, _seek_1__tmp_at340_18147);
    DeRef(_seek_1__tmp_at340_18147);
    _seek_1__tmp_at340_18147 = NOVALUE;

    /** 	putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_18084); // DJP 

    /** end procedure*/
    goto L6; // [365] 368
L6: 

    /** 	nt -= 1*/
    _0 = _nt_18077;
    if (IS_ATOM_INT(_nt_18077)) {
        _nt_18077 = _nt_18077 - 1;
        if ((long)((unsigned long)_nt_18077 +(unsigned long) HIGH_BITS) >= 0){
            _nt_18077 = NewDouble((double)_nt_18077);
        }
    }
    else {
        _nt_18077 = NewDouble(DBL_PTR(_nt_18077)->dbl - (double)1);
    }
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18076);
    DeRef(_seek_1__tmp_at377_18152);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_18076;
    _seek_1__tmp_at377_18152 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_377_18151 = machine(19, _seek_1__tmp_at377_18152);
    DeRef(_seek_1__tmp_at377_18152);
    _seek_1__tmp_at377_18152 = NOVALUE;

    /** 	put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nt_18077)) {
        *poke4_addr = (unsigned long)_nt_18077;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18077)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at392_18154);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at392_18154 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at392_18154); // DJP 

    /** end procedure*/
    goto L7; // [414] 417
L7: 
    DeRefi(_put4_1__tmp_at392_18154);
    _put4_1__tmp_at392_18154 = NOVALUE;

    /** 	k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16700);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _10171 = MAKE_SEQ(_1);
    _k_18085 = find_from(_10171, _38cache_index_16708, 1);
    DeRefDS(_10171);
    _10171 = NOVALUE;

    /** 	if k != 0 then*/
    if (_k_18085 == 0)
    goto L8; // [438] 461

    /** 		cache_index = remove(cache_index, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38cache_index_16708);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_18085)) ? _k_18085 : (long)(DBL_PTR(_k_18085)->dbl);
        int stop = (IS_ATOM_INT(_k_18085)) ? _k_18085 : (long)(DBL_PTR(_k_18085)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708 );
            }
            else Tail(SEQ_PTR(_38cache_index_16708), stop+1, &_38cache_index_16708);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708);
        }
        else {
            assign_slice_seq = &assign_space;
            _38cache_index_16708 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16708)->ref == 1));
        }
    }

    /** 		key_cache = remove(key_cache, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38key_cache_16707);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_18085)) ? _k_18085 : (long)(DBL_PTR(_k_18085)->dbl);
        int stop = (IS_ATOM_INT(_k_18085)) ? _k_18085 : (long)(DBL_PTR(_k_18085)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707 );
            }
            else Tail(SEQ_PTR(_38key_cache_16707), stop+1, &_38key_cache_16707);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707);
        }
        else {
            assign_slice_seq = &assign_space;
            _38key_cache_16707 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16707)->ref == 1));
        }
    }
L8: 

    /** 	if table = current_table_pos then*/
    if (binary_op_a(NOTEQ, _table_18075, _38current_table_pos_16700)){
        goto L9; // [465] 484
    }

    /** 		current_table_pos = -1*/
    DeRef(_38current_table_pos_16700);
    _38current_table_pos_16700 = -1;

    /** 		current_table_name = ""*/
    RefDS(_5);
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _5;
    goto LA; // [481] 550
L9: 

    /** 	elsif table < current_table_pos then*/
    if (binary_op_a(GREATEREQ, _table_18075, _38current_table_pos_16700)){
        goto LB; // [488] 549
    }

    /** 		current_table_pos -= SIZEOF_TABLE_HEADER*/
    _0 = _38current_table_pos_16700;
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _38current_table_pos_16700 = _38current_table_pos_16700 - 16;
        if ((long)((unsigned long)_38current_table_pos_16700 +(unsigned long) HIGH_BITS) >= 0){
            _38current_table_pos_16700 = NewDouble((double)_38current_table_pos_16700);
        }
    }
    else {
        _38current_table_pos_16700 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl - (double)16);
    }
    DeRef(_0);

    /** 		io:seek(current_db, current_table_pos)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_38current_table_pos_16700);
    DeRef(_seek_1__tmp_at505_18168);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _seek_1__tmp_at505_18168 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_505_18167 = machine(19, _seek_1__tmp_at505_18168);
    DeRef(_seek_1__tmp_at505_18168);
    _seek_1__tmp_at505_18168 = NOVALUE;

    /** 		data_ptr = get4()*/
    _0 = _data_ptr_18082;
    _data_ptr_18082 = _38get4();
    DeRef(_0);

    /** 		io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18082);
    DeRef(_seek_1__tmp_at527_18172);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _data_ptr_18082;
    _seek_1__tmp_at527_18172 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_527_18171 = machine(19, _seek_1__tmp_at527_18172);
    DeRef(_seek_1__tmp_at527_18172);
    _seek_1__tmp_at527_18172 = NOVALUE;

    /** 		current_table_name = get_string()*/
    _0 = _38get_string();
    DeRef(_38current_table_name_16701);
    _38current_table_name_16701 = _0;
LB: 
LA: 

    /** end procedure*/
    DeRefDS(_name_18074);
    DeRef(_table_18075);
    DeRef(_tables_18076);
    DeRef(_nt_18077);
    DeRef(_nrecs_18078);
    DeRef(_records_ptr_18079);
    DeRef(_blocks_18080);
    DeRef(_p_18081);
    DeRef(_data_ptr_18082);
    DeRef(_index_18083);
    DeRef(_remaining_18084);
    DeRef(_10151);
    _10151 = NOVALUE;
    DeRef(_10156);
    _10156 = NOVALUE;
    return;
    ;
}


void  __stdcall _38db_clear_table(int _name_18176, int _init_records_18177)
{
    int _table_18178 = NOVALUE;
    int _nrecs_18179 = NOVALUE;
    int _records_ptr_18180 = NOVALUE;
    int _blocks_18181 = NOVALUE;
    int _p_18182 = NOVALUE;
    int _data_ptr_18183 = NOVALUE;
    int _index_ptr_18184 = NOVALUE;
    int _k_18185 = NOVALUE;
    int _init_index_18186 = NOVALUE;
    int _seek_1__tmp_at57_18198 = NOVALUE;
    int _seek_inlined_seek_at_57_18197 = NOVALUE;
    int _pos_inlined_seek_at_54_18196 = NOVALUE;
    int _seek_1__tmp_at113_18210 = NOVALUE;
    int _seek_inlined_seek_at_113_18209 = NOVALUE;
    int _pos_inlined_seek_at_110_18208 = NOVALUE;
    int _seek_1__tmp_at164_18221 = NOVALUE;
    int _seek_inlined_seek_at_164_18220 = NOVALUE;
    int _pos_inlined_seek_at_161_18219 = NOVALUE;
    int _seek_1__tmp_at186_18225 = NOVALUE;
    int _seek_inlined_seek_at_186_18224 = NOVALUE;
    int _s_inlined_putn_at_258_18232 = NOVALUE;
    int _put4_1__tmp_at289_18236 = NOVALUE;
    int _put4_1__tmp_at317_18238 = NOVALUE;
    int _s_inlined_putn_at_357_18243 = NOVALUE;
    int _seek_1__tmp_at387_18248 = NOVALUE;
    int _seek_inlined_seek_at_387_18247 = NOVALUE;
    int _pos_inlined_seek_at_384_18246 = NOVALUE;
    int _put4_1__tmp_at402_18250 = NOVALUE;
    int _put4_1__tmp_at430_18252 = NOVALUE;
    int _put4_1__tmp_at458_18254 = NOVALUE;
    int _10210 = NOVALUE;
    int _10209 = NOVALUE;
    int _10208 = NOVALUE;
    int _10207 = NOVALUE;
    int _10206 = NOVALUE;
    int _10204 = NOVALUE;
    int _10203 = NOVALUE;
    int _10202 = NOVALUE;
    int _10200 = NOVALUE;
    int _10197 = NOVALUE;
    int _10196 = NOVALUE;
    int _10195 = NOVALUE;
    int _10192 = NOVALUE;
    int _10191 = NOVALUE;
    int _10190 = NOVALUE;
    int _10186 = NOVALUE;
    int _10184 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_init_records_18177)) {
        _1 = (long)(DBL_PTR(_init_records_18177)->dbl);
        DeRefDS(_init_records_18177);
        _init_records_18177 = _1;
    }

    /** 	table = table_find(name)*/
    RefDS(_name_18176);
    _0 = _table_18178;
    _table_18178 = _38table_find(_name_18176);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18178, -1)){
        goto L1; // [13] 23
    }

    /** 		return*/
    DeRefDS(_name_18176);
    DeRef(_table_18178);
    DeRef(_nrecs_18179);
    DeRef(_records_ptr_18180);
    DeRef(_blocks_18181);
    DeRef(_p_18182);
    DeRef(_data_ptr_18183);
    DeRef(_index_ptr_18184);
    return;
L1: 

    /** 	if init_records < 1 then*/
    if (_init_records_18177 >= 1)
    goto L2; // [25] 35

    /** 		init_records = 1*/
    _init_records_18177 = 1;
L2: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_18177;
    ((int *)_2)[2] = 10;
    _10184 = MAKE_SEQ(_1);
    _init_index_18186 = _20min(_10184);
    _10184 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_18186)) {
        _1 = (long)(DBL_PTR(_init_index_18186)->dbl);
        DeRefDS(_init_index_18186);
        _init_index_18186 = _1;
    }

    /** 	io:seek(current_db, table + 4)*/
    if (IS_ATOM_INT(_table_18178)) {
        _10186 = _table_18178 + 4;
        if ((long)((unsigned long)_10186 + (unsigned long)HIGH_BITS) >= 0) 
        _10186 = NewDouble((double)_10186);
    }
    else {
        _10186 = NewDouble(DBL_PTR(_table_18178)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_54_18196);
    _pos_inlined_seek_at_54_18196 = _10186;
    _10186 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_54_18196);
    DeRef(_seek_1__tmp_at57_18198);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_54_18196;
    _seek_1__tmp_at57_18198 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_57_18197 = machine(19, _seek_1__tmp_at57_18198);
    DeRef(_pos_inlined_seek_at_54_18196);
    _pos_inlined_seek_at_54_18196 = NOVALUE;
    DeRef(_seek_1__tmp_at57_18198);
    _seek_1__tmp_at57_18198 = NOVALUE;

    /** 	nrecs = get4()*/
    _0 = _nrecs_18179;
    _nrecs_18179 = _38get4();
    DeRef(_0);

    /** 	blocks = get4()*/
    _0 = _blocks_18181;
    _blocks_18181 = _38get4();
    DeRef(_0);

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18184;
    _index_ptr_18184 = _38get4();
    DeRef(_0);

    /** 	for b = 0 to blocks-1 do*/
    if (IS_ATOM_INT(_blocks_18181)) {
        _10190 = _blocks_18181 - 1;
        if ((long)((unsigned long)_10190 +(unsigned long) HIGH_BITS) >= 0){
            _10190 = NewDouble((double)_10190);
        }
    }
    else {
        _10190 = NewDouble(DBL_PTR(_blocks_18181)->dbl - (double)1);
    }
    {
        int _b_18203;
        _b_18203 = 0;
L3: 
        if (binary_op_a(GREATER, _b_18203, _10190)){
            goto L4; // [92] 234
        }

        /** 		io:seek(current_db, index_ptr + b*8)*/
        if (IS_ATOM_INT(_b_18203)) {
            if (_b_18203 == (short)_b_18203)
            _10191 = _b_18203 * 8;
            else
            _10191 = NewDouble(_b_18203 * (double)8);
        }
        else {
            _10191 = NewDouble(DBL_PTR(_b_18203)->dbl * (double)8);
        }
        if (IS_ATOM_INT(_index_ptr_18184) && IS_ATOM_INT(_10191)) {
            _10192 = _index_ptr_18184 + _10191;
            if ((long)((unsigned long)_10192 + (unsigned long)HIGH_BITS) >= 0) 
            _10192 = NewDouble((double)_10192);
        }
        else {
            if (IS_ATOM_INT(_index_ptr_18184)) {
                _10192 = NewDouble((double)_index_ptr_18184 + DBL_PTR(_10191)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10191)) {
                    _10192 = NewDouble(DBL_PTR(_index_ptr_18184)->dbl + (double)_10191);
                }
                else
                _10192 = NewDouble(DBL_PTR(_index_ptr_18184)->dbl + DBL_PTR(_10191)->dbl);
            }
        }
        DeRef(_10191);
        _10191 = NOVALUE;
        DeRef(_pos_inlined_seek_at_110_18208);
        _pos_inlined_seek_at_110_18208 = _10192;
        _10192 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_110_18208);
        DeRef(_seek_1__tmp_at113_18210);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_110_18208;
        _seek_1__tmp_at113_18210 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_113_18209 = machine(19, _seek_1__tmp_at113_18210);
        DeRef(_pos_inlined_seek_at_110_18208);
        _pos_inlined_seek_at_110_18208 = NOVALUE;
        DeRef(_seek_1__tmp_at113_18210);
        _seek_1__tmp_at113_18210 = NOVALUE;

        /** 		nrecs = get4()*/
        _0 = _nrecs_18179;
        _nrecs_18179 = _38get4();
        DeRef(_0);

        /** 		records_ptr = get4()*/
        _0 = _records_ptr_18180;
        _records_ptr_18180 = _38get4();
        DeRef(_0);

        /** 		for r = 0 to nrecs-1 do*/
        if (IS_ATOM_INT(_nrecs_18179)) {
            _10195 = _nrecs_18179 - 1;
            if ((long)((unsigned long)_10195 +(unsigned long) HIGH_BITS) >= 0){
                _10195 = NewDouble((double)_10195);
            }
        }
        else {
            _10195 = NewDouble(DBL_PTR(_nrecs_18179)->dbl - (double)1);
        }
        {
            int _r_18214;
            _r_18214 = 0;
L5: 
            if (binary_op_a(GREATER, _r_18214, _10195)){
                goto L6; // [143] 222
            }

            /** 			io:seek(current_db, records_ptr + r*4)*/
            if (IS_ATOM_INT(_r_18214)) {
                if (_r_18214 == (short)_r_18214)
                _10196 = _r_18214 * 4;
                else
                _10196 = NewDouble(_r_18214 * (double)4);
            }
            else {
                _10196 = NewDouble(DBL_PTR(_r_18214)->dbl * (double)4);
            }
            if (IS_ATOM_INT(_records_ptr_18180) && IS_ATOM_INT(_10196)) {
                _10197 = _records_ptr_18180 + _10196;
                if ((long)((unsigned long)_10197 + (unsigned long)HIGH_BITS) >= 0) 
                _10197 = NewDouble((double)_10197);
            }
            else {
                if (IS_ATOM_INT(_records_ptr_18180)) {
                    _10197 = NewDouble((double)_records_ptr_18180 + DBL_PTR(_10196)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_10196)) {
                        _10197 = NewDouble(DBL_PTR(_records_ptr_18180)->dbl + (double)_10196);
                    }
                    else
                    _10197 = NewDouble(DBL_PTR(_records_ptr_18180)->dbl + DBL_PTR(_10196)->dbl);
                }
            }
            DeRef(_10196);
            _10196 = NOVALUE;
            DeRef(_pos_inlined_seek_at_161_18219);
            _pos_inlined_seek_at_161_18219 = _10197;
            _10197 = NOVALUE;

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_pos_inlined_seek_at_161_18219);
            DeRef(_seek_1__tmp_at164_18221);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16699;
            ((int *)_2)[2] = _pos_inlined_seek_at_161_18219;
            _seek_1__tmp_at164_18221 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_164_18220 = machine(19, _seek_1__tmp_at164_18221);
            DeRef(_pos_inlined_seek_at_161_18219);
            _pos_inlined_seek_at_161_18219 = NOVALUE;
            DeRef(_seek_1__tmp_at164_18221);
            _seek_1__tmp_at164_18221 = NOVALUE;

            /** 			p = get4()*/
            _0 = _p_18182;
            _p_18182 = _38get4();
            DeRef(_0);

            /** 			io:seek(current_db, p)*/

            /** 	return machine_func(M_SEEK, {fn, pos})*/
            Ref(_p_18182);
            DeRef(_seek_1__tmp_at186_18225);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _38current_db_16699;
            ((int *)_2)[2] = _p_18182;
            _seek_1__tmp_at186_18225 = MAKE_SEQ(_1);
            _seek_inlined_seek_at_186_18224 = machine(19, _seek_1__tmp_at186_18225);
            DeRef(_seek_1__tmp_at186_18225);
            _seek_1__tmp_at186_18225 = NOVALUE;

            /** 			data_ptr = get4()*/
            _0 = _data_ptr_18183;
            _data_ptr_18183 = _38get4();
            DeRef(_0);

            /** 			db_free(data_ptr)*/
            Ref(_data_ptr_18183);
            _38db_free(_data_ptr_18183);

            /** 			db_free(p)*/
            Ref(_p_18182);
            _38db_free(_p_18182);

            /** 		end for*/
            _0 = _r_18214;
            if (IS_ATOM_INT(_r_18214)) {
                _r_18214 = _r_18214 + 1;
                if ((long)((unsigned long)_r_18214 +(unsigned long) HIGH_BITS) >= 0){
                    _r_18214 = NewDouble((double)_r_18214);
                }
            }
            else {
                _r_18214 = binary_op_a(PLUS, _r_18214, 1);
            }
            DeRef(_0);
            goto L5; // [217] 150
L6: 
            ;
            DeRef(_r_18214);
        }

        /** 		db_free(records_ptr)*/
        Ref(_records_ptr_18180);
        _38db_free(_records_ptr_18180);

        /** 	end for*/
        _0 = _b_18203;
        if (IS_ATOM_INT(_b_18203)) {
            _b_18203 = _b_18203 + 1;
            if ((long)((unsigned long)_b_18203 +(unsigned long) HIGH_BITS) >= 0){
                _b_18203 = NewDouble((double)_b_18203);
            }
        }
        else {
            _b_18203 = binary_op_a(PLUS, _b_18203, 1);
        }
        DeRef(_0);
        goto L3; // [229] 99
L4: 
        ;
        DeRef(_b_18203);
    }

    /** 	db_free(index_ptr)*/
    Ref(_index_ptr_18184);
    _38db_free(_index_ptr_18184);

    /** 	data_ptr = db_allocate(init_records * 4)*/
    if (_init_records_18177 == (short)_init_records_18177)
    _10200 = _init_records_18177 * 4;
    else
    _10200 = NewDouble(_init_records_18177 * (double)4);
    _0 = _data_ptr_18183;
    _data_ptr_18183 = _38db_allocate(_10200);
    DeRef(_0);
    _10200 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10202 = _init_records_18177 * 4;
    _10203 = Repeat(0, _10202);
    _10202 = NOVALUE;
    DeRefi(_s_inlined_putn_at_258_18232);
    _s_inlined_putn_at_258_18232 = _10203;
    _10203 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_258_18232); // DJP 

    /** end procedure*/
    goto L7; // [273] 276
L7: 
    DeRefi(_s_inlined_putn_at_258_18232);
    _s_inlined_putn_at_258_18232 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_18186 == (short)_init_index_18186)
    _10204 = _init_index_18186 * 8;
    else
    _10204 = NewDouble(_init_index_18186 * (double)8);
    _0 = _index_ptr_18184;
    _index_ptr_18184 = _38db_allocate(_10204);
    DeRef(_0);
    _10204 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at289_18236);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at289_18236 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at289_18236); // DJP 

    /** end procedure*/
    goto L8; // [311] 314
L8: 
    DeRefi(_put4_1__tmp_at289_18236);
    _put4_1__tmp_at289_18236 = NOVALUE;

    /** 	put4(data_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18183)) {
        *poke4_addr = (unsigned long)_data_ptr_18183;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18183)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at317_18238);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at317_18238 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at317_18238); // DJP 

    /** end procedure*/
    goto L9; // [339] 342
L9: 
    DeRefi(_put4_1__tmp_at317_18238);
    _put4_1__tmp_at317_18238 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10206 = _init_index_18186 - 1;
    if ((long)((unsigned long)_10206 +(unsigned long) HIGH_BITS) >= 0){
        _10206 = NewDouble((double)_10206);
    }
    if (IS_ATOM_INT(_10206)) {
        _10207 = _10206 * 8;
    }
    else {
        _10207 = NewDouble(DBL_PTR(_10206)->dbl * (double)8);
    }
    DeRef(_10206);
    _10206 = NOVALUE;
    _10208 = Repeat(0, _10207);
    DeRef(_10207);
    _10207 = NOVALUE;
    DeRefi(_s_inlined_putn_at_357_18243);
    _s_inlined_putn_at_357_18243 = _10208;
    _10208 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_357_18243); // DJP 

    /** end procedure*/
    goto LA; // [372] 375
LA: 
    DeRefi(_s_inlined_putn_at_357_18243);
    _s_inlined_putn_at_357_18243 = NOVALUE;

    /** 	io:seek(current_db, table + 4)*/
    if (IS_ATOM_INT(_table_18178)) {
        _10209 = _table_18178 + 4;
        if ((long)((unsigned long)_10209 + (unsigned long)HIGH_BITS) >= 0) 
        _10209 = NewDouble((double)_10209);
    }
    else {
        _10209 = NewDouble(DBL_PTR(_table_18178)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_384_18246);
    _pos_inlined_seek_at_384_18246 = _10209;
    _10209 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_384_18246);
    DeRef(_seek_1__tmp_at387_18248);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_384_18246;
    _seek_1__tmp_at387_18248 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_387_18247 = machine(19, _seek_1__tmp_at387_18248);
    DeRef(_pos_inlined_seek_at_384_18246);
    _pos_inlined_seek_at_384_18246 = NOVALUE;
    DeRef(_seek_1__tmp_at387_18248);
    _seek_1__tmp_at387_18248 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at402_18250);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at402_18250 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at402_18250); // DJP 

    /** end procedure*/
    goto LB; // [424] 427
LB: 
    DeRefi(_put4_1__tmp_at402_18250);
    _put4_1__tmp_at402_18250 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at430_18252);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at430_18252 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at430_18252); // DJP 

    /** end procedure*/
    goto LC; // [452] 455
LC: 
    DeRefi(_put4_1__tmp_at430_18252);
    _put4_1__tmp_at430_18252 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_18184)) {
        *poke4_addr = (unsigned long)_index_ptr_18184;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_18184)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at458_18254);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at458_18254 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at458_18254); // DJP 

    /** end procedure*/
    goto LD; // [480] 483
LD: 
    DeRefi(_put4_1__tmp_at458_18254);
    _put4_1__tmp_at458_18254 = NOVALUE;

    /** 	k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_38current_table_pos_16700);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _38current_table_pos_16700;
    _10210 = MAKE_SEQ(_1);
    _k_18185 = find_from(_10210, _38cache_index_16708, 1);
    DeRefDS(_10210);
    _10210 = NOVALUE;

    /** 	if k != 0 then*/
    if (_k_18185 == 0)
    goto LE; // [504] 527

    /** 		cache_index = remove(cache_index, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38cache_index_16708);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_18185)) ? _k_18185 : (long)(DBL_PTR(_k_18185)->dbl);
        int stop = (IS_ATOM_INT(_k_18185)) ? _k_18185 : (long)(DBL_PTR(_k_18185)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708 );
            }
            else Tail(SEQ_PTR(_38cache_index_16708), stop+1, &_38cache_index_16708);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38cache_index_16708), start, &_38cache_index_16708);
        }
        else {
            assign_slice_seq = &assign_space;
            _38cache_index_16708 = Remove_elements(start, stop, (SEQ_PTR(_38cache_index_16708)->ref == 1));
        }
    }

    /** 		key_cache = remove(key_cache, k)*/
    {
        s1_ptr assign_space = SEQ_PTR(_38key_cache_16707);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_k_18185)) ? _k_18185 : (long)(DBL_PTR(_k_18185)->dbl);
        int stop = (IS_ATOM_INT(_k_18185)) ? _k_18185 : (long)(DBL_PTR(_k_18185)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707 );
            }
            else Tail(SEQ_PTR(_38key_cache_16707), stop+1, &_38key_cache_16707);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38key_cache_16707), start, &_38key_cache_16707);
        }
        else {
            assign_slice_seq = &assign_space;
            _38key_cache_16707 = Remove_elements(start, stop, (SEQ_PTR(_38key_cache_16707)->ref == 1));
        }
    }
LE: 

    /** 	if table = current_table_pos then*/
    if (binary_op_a(NOTEQ, _table_18178, _38current_table_pos_16700)){
        goto LF; // [531] 543
    }

    /** 		key_pointers = {}*/
    RefDS(_5);
    DeRef(_38key_pointers_16706);
    _38key_pointers_16706 = _5;
LF: 

    /** end procedure*/
    DeRefDS(_name_18176);
    DeRef(_table_18178);
    DeRef(_nrecs_18179);
    DeRef(_records_ptr_18180);
    DeRef(_blocks_18181);
    DeRef(_p_18182);
    DeRef(_data_ptr_18183);
    DeRef(_index_ptr_18184);
    DeRef(_10190);
    _10190 = NOVALUE;
    DeRef(_10195);
    _10195 = NOVALUE;
    return;
    ;
}


void  __stdcall _38db_rename_table(int _name_18265, int _new_name_18266)
{
    int _table_18267 = NOVALUE;
    int _table_ptr_18268 = NOVALUE;
    int _seek_1__tmp_at66_18282 = NOVALUE;
    int _seek_inlined_seek_at_66_18281 = NOVALUE;
    int _s_inlined_putn_at_106_18289 = NOVALUE;
    int _seek_1__tmp_at129_18292 = NOVALUE;
    int _seek_inlined_seek_at_129_18291 = NOVALUE;
    int _put4_1__tmp_at144_18294 = NOVALUE;
    int _10230 = NOVALUE;
    int _10229 = NOVALUE;
    int _10227 = NOVALUE;
    int _10226 = NOVALUE;
    int _10225 = NOVALUE;
    int _10224 = NOVALUE;
    int _10221 = NOVALUE;
    int _10220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	table = table_find(name)*/
    RefDS(_name_18265);
    _0 = _table_18267;
    _table_18267 = _38table_find(_name_18265);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18267, -1)){
        goto L1; // [13] 35
    }

    /** 		fatal(NO_TABLE, "source table doesn't exist", "db_rename_table", {name, new_name})*/
    RefDS(_new_name_18266);
    RefDS(_name_18265);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_18265;
    ((int *)_2)[2] = _new_name_18266;
    _10220 = MAKE_SEQ(_1);
    RefDS(_10218);
    RefDS(_10219);
    _38fatal(903, _10218, _10219, _10220);
    _10220 = NOVALUE;

    /** 		return*/
    DeRefDS(_name_18265);
    DeRefDS(_new_name_18266);
    DeRef(_table_18267);
    DeRef(_table_ptr_18268);
    return;
L1: 

    /** 	if table_find(new_name) != -1 then*/
    RefDS(_new_name_18266);
    _10221 = _38table_find(_new_name_18266);
    if (binary_op_a(EQUALS, _10221, -1)){
        DeRef(_10221);
        _10221 = NOVALUE;
        goto L2; // [41] 63
    }
    DeRef(_10221);
    _10221 = NOVALUE;

    /** 		fatal(DUP_TABLE, "target table name already exists", "db_rename_table", {name, new_name})*/
    RefDS(_new_name_18266);
    RefDS(_name_18265);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _name_18265;
    ((int *)_2)[2] = _new_name_18266;
    _10224 = MAKE_SEQ(_1);
    RefDS(_10223);
    RefDS(_10219);
    _38fatal(904, _10223, _10219, _10224);
    _10224 = NOVALUE;

    /** 		return*/
    DeRefDS(_name_18265);
    DeRefDS(_new_name_18266);
    DeRef(_table_18267);
    DeRef(_table_ptr_18268);
    return;
L2: 

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_18267);
    DeRef(_seek_1__tmp_at66_18282);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _table_18267;
    _seek_1__tmp_at66_18282 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_66_18281 = machine(19, _seek_1__tmp_at66_18282);
    DeRef(_seek_1__tmp_at66_18282);
    _seek_1__tmp_at66_18282 = NOVALUE;

    /** 	db_free(get4())*/
    _10225 = _38get4();
    _38db_free(_10225);
    _10225 = NOVALUE;

    /** 	table_ptr = db_allocate(length(new_name)+1)*/
    if (IS_SEQUENCE(_new_name_18266)){
            _10226 = SEQ_PTR(_new_name_18266)->length;
    }
    else {
        _10226 = 1;
    }
    _10227 = _10226 + 1;
    _10226 = NOVALUE;
    _0 = _table_ptr_18268;
    _table_ptr_18268 = _38db_allocate(_10227);
    DeRef(_0);
    _10227 = NOVALUE;

    /** 	putn(new_name & 0)*/
    Append(&_10229, _new_name_18266, 0);
    DeRef(_s_inlined_putn_at_106_18289);
    _s_inlined_putn_at_106_18289 = _10229;
    _10229 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_106_18289); // DJP 

    /** end procedure*/
    goto L3; // [121] 124
L3: 
    DeRef(_s_inlined_putn_at_106_18289);
    _s_inlined_putn_at_106_18289 = NOVALUE;

    /** 	io:seek(current_db, table)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_table_18267);
    DeRef(_seek_1__tmp_at129_18292);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _table_18267;
    _seek_1__tmp_at129_18292 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_129_18291 = machine(19, _seek_1__tmp_at129_18292);
    DeRef(_seek_1__tmp_at129_18292);
    _seek_1__tmp_at129_18292 = NOVALUE;

    /** 	put4(table_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_table_ptr_18268)) {
        *poke4_addr = (unsigned long)_table_ptr_18268;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_table_ptr_18268)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at144_18294);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at144_18294 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at144_18294); // DJP 

    /** end procedure*/
    goto L4; // [166] 169
L4: 
    DeRefi(_put4_1__tmp_at144_18294);
    _put4_1__tmp_at144_18294 = NOVALUE;

    /** 	if equal(current_table_name, name) then*/
    if (_38current_table_name_16701 == _name_18265)
    _10230 = 1;
    else if (IS_ATOM_INT(_38current_table_name_16701) && IS_ATOM_INT(_name_18265))
    _10230 = 0;
    else
    _10230 = (compare(_38current_table_name_16701, _name_18265) == 0);
    if (_10230 == 0)
    {
        _10230 = NOVALUE;
        goto L5; // [179] 190
    }
    else{
        _10230 = NOVALUE;
    }

    /** 		current_table_name = new_name*/
    RefDS(_new_name_18266);
    DeRefDS(_38current_table_name_16701);
    _38current_table_name_16701 = _new_name_18266;
L5: 

    /** end procedure*/
    DeRefDS(_name_18265);
    DeRefDS(_new_name_18266);
    DeRef(_table_18267);
    DeRef(_table_ptr_18268);
    return;
    ;
}


int  __stdcall _38db_table_list()
{
    int _seek_1__tmp_at120_18328 = NOVALUE;
    int _seek_inlined_seek_at_120_18327 = NOVALUE;
    int _seek_1__tmp_at98_18324 = NOVALUE;
    int _seek_inlined_seek_at_98_18323 = NOVALUE;
    int _pos_inlined_seek_at_95_18322 = NOVALUE;
    int _seek_1__tmp_at42_18312 = NOVALUE;
    int _seek_inlined_seek_at_42_18311 = NOVALUE;
    int _seek_1__tmp_at4_18305 = NOVALUE;
    int _seek_inlined_seek_at_4_18304 = NOVALUE;
    int _table_names_18299 = NOVALUE;
    int _tables_18300 = NOVALUE;
    int _nt_18301 = NOVALUE;
    int _name_18302 = NOVALUE;
    int _10242 = NOVALUE;
    int _10241 = NOVALUE;
    int _10239 = NOVALUE;
    int _10238 = NOVALUE;
    int _10237 = NOVALUE;
    int _10236 = NOVALUE;
    int _10231 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18305);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_18305 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18304 = machine(19, _seek_1__tmp_at4_18305);
    DeRefi(_seek_1__tmp_at4_18305);
    _seek_1__tmp_at4_18305 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _10231 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _10231 = 1;
    }
    if (_10231 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18299);
    DeRef(_tables_18300);
    DeRef(_nt_18301);
    DeRef(_name_18302);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18300;
    _tables_18300 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18300);
    DeRef(_seek_1__tmp_at42_18312);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _tables_18300;
    _seek_1__tmp_at42_18312 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18311 = machine(19, _seek_1__tmp_at42_18312);
    DeRef(_seek_1__tmp_at42_18312);
    _seek_1__tmp_at42_18312 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18301;
    _nt_18301 = _38get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_18299);
    _table_names_18299 = Repeat(0, _nt_18301);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18301)) {
        _10236 = _nt_18301 - 1;
        if ((long)((unsigned long)_10236 +(unsigned long) HIGH_BITS) >= 0){
            _10236 = NewDouble((double)_10236);
        }
    }
    else {
        _10236 = NewDouble(DBL_PTR(_nt_18301)->dbl - (double)1);
    }
    {
        int _i_18316;
        _i_18316 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18316, _10236)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18300)) {
            _10237 = _tables_18300 + 4;
            if ((long)((unsigned long)_10237 + (unsigned long)HIGH_BITS) >= 0) 
            _10237 = NewDouble((double)_10237);
        }
        else {
            _10237 = NewDouble(DBL_PTR(_tables_18300)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_18316)) {
            if (_i_18316 == (short)_i_18316)
            _10238 = _i_18316 * 16;
            else
            _10238 = NewDouble(_i_18316 * (double)16);
        }
        else {
            _10238 = NewDouble(DBL_PTR(_i_18316)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10237) && IS_ATOM_INT(_10238)) {
            _10239 = _10237 + _10238;
            if ((long)((unsigned long)_10239 + (unsigned long)HIGH_BITS) >= 0) 
            _10239 = NewDouble((double)_10239);
        }
        else {
            if (IS_ATOM_INT(_10237)) {
                _10239 = NewDouble((double)_10237 + DBL_PTR(_10238)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10238)) {
                    _10239 = NewDouble(DBL_PTR(_10237)->dbl + (double)_10238);
                }
                else
                _10239 = NewDouble(DBL_PTR(_10237)->dbl + DBL_PTR(_10238)->dbl);
            }
        }
        DeRef(_10237);
        _10237 = NOVALUE;
        DeRef(_10238);
        _10238 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18322);
        _pos_inlined_seek_at_95_18322 = _10239;
        _10239 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18322);
        DeRef(_seek_1__tmp_at98_18324);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_18322;
        _seek_1__tmp_at98_18324 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18323 = machine(19, _seek_1__tmp_at98_18324);
        DeRef(_pos_inlined_seek_at_95_18322);
        _pos_inlined_seek_at_95_18322 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18324);
        _seek_1__tmp_at98_18324 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_18302;
        _name_18302 = _38get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18302);
        DeRef(_seek_1__tmp_at120_18328);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _38current_db_16699;
        ((int *)_2)[2] = _name_18302;
        _seek_1__tmp_at120_18328 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18327 = machine(19, _seek_1__tmp_at120_18328);
        DeRef(_seek_1__tmp_at120_18328);
        _seek_1__tmp_at120_18328 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18316)) {
            _10241 = _i_18316 + 1;
            if (_10241 > MAXINT){
                _10241 = NewDouble((double)_10241);
            }
        }
        else
        _10241 = binary_op(PLUS, 1, _i_18316);
        _10242 = _38get_string();
        _2 = (int)SEQ_PTR(_table_names_18299);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_18299 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10241))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10241)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10241);
        _1 = *(int *)_2;
        *(int *)_2 = _10242;
        if( _1 != _10242 ){
            DeRef(_1);
        }
        _10242 = NOVALUE;

        /** 	end for*/
        _0 = _i_18316;
        if (IS_ATOM_INT(_i_18316)) {
            _i_18316 = _i_18316 + 1;
            if ((long)((unsigned long)_i_18316 +(unsigned long) HIGH_BITS) >= 0){
                _i_18316 = NewDouble((double)_i_18316);
            }
        }
        else {
            _i_18316 = binary_op_a(PLUS, _i_18316, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18316);
    }

    /** 	return table_names*/
    DeRef(_tables_18300);
    DeRef(_nt_18301);
    DeRef(_name_18302);
    DeRef(_10236);
    _10236 = NOVALUE;
    DeRef(_10241);
    _10241 = NOVALUE;
    return _table_names_18299;
    ;
}


int _38key_value(int _ptr_18333)
{
    int _seek_1__tmp_at11_18338 = NOVALUE;
    int _seek_inlined_seek_at_11_18337 = NOVALUE;
    int _pos_inlined_seek_at_8_18336 = NOVALUE;
    int _10244 = NOVALUE;
    int _10243 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18333)) {
        _10243 = _ptr_18333 + 4;
        if ((long)((unsigned long)_10243 + (unsigned long)HIGH_BITS) >= 0) 
        _10243 = NewDouble((double)_10243);
    }
    else {
        _10243 = NewDouble(DBL_PTR(_ptr_18333)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18336);
    _pos_inlined_seek_at_8_18336 = _10243;
    _10243 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18336);
    DeRef(_seek_1__tmp_at11_18338);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18336;
    _seek_1__tmp_at11_18338 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18337 = machine(19, _seek_1__tmp_at11_18338);
    DeRef(_pos_inlined_seek_at_8_18336);
    _pos_inlined_seek_at_8_18336 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18338);
    _seek_1__tmp_at11_18338 = NOVALUE;

    /** 	return decompress(0)*/
    _10244 = _38decompress(0);
    DeRef(_ptr_18333);
    return _10244;
    ;
}


int  __stdcall _38db_find_key(int _key_18342, int _table_name_18343)
{
    int _lo_18344 = NOVALUE;
    int _hi_18345 = NOVALUE;
    int _mid_18346 = NOVALUE;
    int _c_18347 = NOVALUE;
    int _10268 = NOVALUE;
    int _10260 = NOVALUE;
    int _10259 = NOVALUE;
    int _10257 = NOVALUE;
    int _10254 = NOVALUE;
    int _10251 = NOVALUE;
    int _10247 = NOVALUE;
    int _10245 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18343 == _38current_table_name_16701)
    _10245 = 1;
    else if (IS_ATOM_INT(_table_name_18343) && IS_ATOM_INT(_38current_table_name_16701))
    _10245 = 0;
    else
    _10245 = (compare(_table_name_18343, _38current_table_name_16701) == 0);
    if (_10245 != 0)
    goto L1; // [9] 42
    _10245 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18343);
    _10247 = _38db_select_table(_table_name_18343);
    if (binary_op_a(EQUALS, _10247, 0)){
        DeRef(_10247);
        _10247 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10247);
    _10247 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    Ref(_table_name_18343);
    Ref(_key_18342);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18342;
    ((int *)_2)[2] = _table_name_18343;
    _10251 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10250);
    _38fatal(903, _10249, _10250, _10251);
    _10251 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18342);
    DeRef(_table_name_18343);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18343);
    Ref(_key_18342);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18342;
    ((int *)_2)[2] = _table_name_18343;
    _10254 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10250);
    _38fatal(903, _10253, _10250, _10254);
    _10254 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18342);
    DeRef(_table_name_18343);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18344 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _hi_18345 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _hi_18345 = 1;
    }

    /** 	mid = 1*/
    _mid_18346 = 1;

    /** 	c = 0*/
    _c_18347 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18344 > _hi_18345)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10257 = _lo_18344 + _hi_18345;
    if ((long)((unsigned long)_10257 + (unsigned long)HIGH_BITS) >= 0) 
    _10257 = NewDouble((double)_10257);
    if (IS_ATOM_INT(_10257)) {
        _mid_18346 = _10257 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10257, 2);
        _mid_18346 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10257);
    _10257 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18346)) {
        _1 = (long)(DBL_PTR(_mid_18346)->dbl);
        DeRefDS(_mid_18346);
        _mid_18346 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10259 = (int)*(((s1_ptr)_2)->base + _mid_18346);
    Ref(_10259);
    _10260 = _38key_value(_10259);
    _10259 = NOVALUE;
    if (IS_ATOM_INT(_key_18342) && IS_ATOM_INT(_10260)){
        _c_18347 = (_key_18342 < _10260) ? -1 : (_key_18342 > _10260);
    }
    else{
        _c_18347 = compare(_key_18342, _10260);
    }
    DeRef(_10260);
    _10260 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18347 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18345 = _mid_18346 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18347 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18344 = _mid_18346 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_18342);
    DeRef(_table_name_18343);
    return _mid_18346;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_18347 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_18346 = _mid_18346 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_18346 == 0xC0000000)
    _10268 = (int)NewDouble((double)-0xC0000000);
    else
    _10268 = - _mid_18346;
    DeRef(_key_18342);
    DeRef(_table_name_18343);
    return _10268;
    ;
}


int  __stdcall _38db_insert(int _key_18382, int _data_18383, int _table_name_18384)
{
    int _key_string_18385 = NOVALUE;
    int _data_string_18386 = NOVALUE;
    int _last_part_18387 = NOVALUE;
    int _remaining_18388 = NOVALUE;
    int _key_ptr_18389 = NOVALUE;
    int _data_ptr_18390 = NOVALUE;
    int _records_ptr_18391 = NOVALUE;
    int _nrecs_18392 = NOVALUE;
    int _current_block_18393 = NOVALUE;
    int _size_18394 = NOVALUE;
    int _new_size_18395 = NOVALUE;
    int _key_location_18396 = NOVALUE;
    int _new_block_18397 = NOVALUE;
    int _index_ptr_18398 = NOVALUE;
    int _new_index_ptr_18399 = NOVALUE;
    int _total_recs_18400 = NOVALUE;
    int _r_18401 = NOVALUE;
    int _blocks_18402 = NOVALUE;
    int _new_recs_18403 = NOVALUE;
    int _n_18404 = NOVALUE;
    int _put4_1__tmp_at79_18418 = NOVALUE;
    int _seek_1__tmp_at132_18424 = NOVALUE;
    int _seek_inlined_seek_at_132_18423 = NOVALUE;
    int _pos_inlined_seek_at_129_18422 = NOVALUE;
    int _seek_1__tmp_at174_18432 = NOVALUE;
    int _seek_inlined_seek_at_174_18431 = NOVALUE;
    int _pos_inlined_seek_at_171_18430 = NOVALUE;
    int _put4_1__tmp_at189_18434 = NOVALUE;
    int _seek_1__tmp_at317_18451 = NOVALUE;
    int _seek_inlined_seek_at_317_18450 = NOVALUE;
    int _pos_inlined_seek_at_314_18449 = NOVALUE;
    int _seek_1__tmp_at339_18455 = NOVALUE;
    int _seek_inlined_seek_at_339_18454 = NOVALUE;
    int _where_inlined_where_at_404_18464 = NOVALUE;
    int _seek_1__tmp_at448_18474 = NOVALUE;
    int _seek_inlined_seek_at_448_18473 = NOVALUE;
    int _pos_inlined_seek_at_445_18472 = NOVALUE;
    int _put4_1__tmp_at493_18483 = NOVALUE;
    int _x_inlined_put4_at_490_18482 = NOVALUE;
    int _seek_1__tmp_at530_18486 = NOVALUE;
    int _seek_inlined_seek_at_530_18485 = NOVALUE;
    int _put4_1__tmp_at551_18489 = NOVALUE;
    int _seek_1__tmp_at588_18494 = NOVALUE;
    int _seek_inlined_seek_at_588_18493 = NOVALUE;
    int _pos_inlined_seek_at_585_18492 = NOVALUE;
    int _seek_1__tmp_at690_18518 = NOVALUE;
    int _seek_inlined_seek_at_690_18517 = NOVALUE;
    int _pos_inlined_seek_at_687_18516 = NOVALUE;
    int _s_inlined_putn_at_751_18527 = NOVALUE;
    int _seek_1__tmp_at774_18530 = NOVALUE;
    int _seek_inlined_seek_at_774_18529 = NOVALUE;
    int _put4_1__tmp_at796_18534 = NOVALUE;
    int _x_inlined_put4_at_793_18533 = NOVALUE;
    int _seek_1__tmp_at833_18539 = NOVALUE;
    int _seek_inlined_seek_at_833_18538 = NOVALUE;
    int _pos_inlined_seek_at_830_18537 = NOVALUE;
    int _seek_1__tmp_at884_18549 = NOVALUE;
    int _seek_inlined_seek_at_884_18548 = NOVALUE;
    int _pos_inlined_seek_at_881_18547 = NOVALUE;
    int _put4_1__tmp_at899_18551 = NOVALUE;
    int _put4_1__tmp_at927_18553 = NOVALUE;
    int _seek_1__tmp_at980_18559 = NOVALUE;
    int _seek_inlined_seek_at_980_18558 = NOVALUE;
    int _pos_inlined_seek_at_977_18557 = NOVALUE;
    int _put4_1__tmp_at1001_18562 = NOVALUE;
    int _seek_1__tmp_at1038_18567 = NOVALUE;
    int _seek_inlined_seek_at_1038_18566 = NOVALUE;
    int _pos_inlined_seek_at_1035_18565 = NOVALUE;
    int _s_inlined_putn_at_1136_18585 = NOVALUE;
    int _seek_1__tmp_at1173_18590 = NOVALUE;
    int _seek_inlined_seek_at_1173_18589 = NOVALUE;
    int _pos_inlined_seek_at_1170_18588 = NOVALUE;
    int _put4_1__tmp_at1188_18592 = NOVALUE;
    int _10362 = NOVALUE;
    int _10361 = NOVALUE;
    int _10360 = NOVALUE;
    int _10359 = NOVALUE;
    int _10356 = NOVALUE;
    int _10355 = NOVALUE;
    int _10353 = NOVALUE;
    int _10351 = NOVALUE;
    int _10350 = NOVALUE;
    int _10348 = NOVALUE;
    int _10347 = NOVALUE;
    int _10345 = NOVALUE;
    int _10344 = NOVALUE;
    int _10342 = NOVALUE;
    int _10341 = NOVALUE;
    int _10340 = NOVALUE;
    int _10339 = NOVALUE;
    int _10338 = NOVALUE;
    int _10337 = NOVALUE;
    int _10336 = NOVALUE;
    int _10335 = NOVALUE;
    int _10334 = NOVALUE;
    int _10331 = NOVALUE;
    int _10330 = NOVALUE;
    int _10329 = NOVALUE;
    int _10328 = NOVALUE;
    int _10325 = NOVALUE;
    int _10322 = NOVALUE;
    int _10321 = NOVALUE;
    int _10320 = NOVALUE;
    int _10319 = NOVALUE;
    int _10316 = NOVALUE;
    int _10315 = NOVALUE;
    int _10313 = NOVALUE;
    int _10312 = NOVALUE;
    int _10310 = NOVALUE;
    int _10309 = NOVALUE;
    int _10308 = NOVALUE;
    int _10307 = NOVALUE;
    int _10306 = NOVALUE;
    int _10305 = NOVALUE;
    int _10304 = NOVALUE;
    int _10302 = NOVALUE;
    int _10299 = NOVALUE;
    int _10294 = NOVALUE;
    int _10293 = NOVALUE;
    int _10292 = NOVALUE;
    int _10290 = NOVALUE;
    int _10289 = NOVALUE;
    int _10288 = NOVALUE;
    int _10285 = NOVALUE;
    int _10283 = NOVALUE;
    int _10280 = NOVALUE;
    int _10279 = NOVALUE;
    int _10277 = NOVALUE;
    int _10276 = NOVALUE;
    int _10274 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_18382);
    Ref(_table_name_18384);
    _0 = _key_location_18396;
    _key_location_18396 = _38db_find_key(_key_18382, _table_name_18384);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_18396, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_18382);
    DeRef(_data_18383);
    DeRef(_table_name_18384);
    DeRef(_key_string_18385);
    DeRef(_data_string_18386);
    DeRef(_last_part_18387);
    DeRef(_remaining_18388);
    DeRef(_key_ptr_18389);
    DeRef(_data_ptr_18390);
    DeRef(_records_ptr_18391);
    DeRef(_nrecs_18392);
    DeRef(_current_block_18393);
    DeRef(_size_18394);
    DeRef(_new_size_18395);
    DeRef(_key_location_18396);
    DeRef(_new_block_18397);
    DeRef(_index_ptr_18398);
    DeRef(_new_index_ptr_18399);
    DeRef(_total_recs_18400);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_18396;
    if (IS_ATOM_INT(_key_location_18396)) {
        if ((unsigned long)_key_location_18396 == 0xC0000000)
        _key_location_18396 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_18396 = - _key_location_18396;
    }
    else {
        _key_location_18396 = unary_op(UMINUS, _key_location_18396);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    Ref(_data_18383);
    _0 = _data_string_18386;
    _data_string_18386 = _38compress(_data_18383);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_18382);
    _0 = _key_string_18385;
    _key_string_18385 = _38compress(_key_18382);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_18386)){
            _10274 = SEQ_PTR(_data_string_18386)->length;
    }
    else {
        _10274 = 1;
    }
    _0 = _data_ptr_18390;
    _data_ptr_18390 = _38db_allocate(_10274);
    DeRef(_0);
    _10274 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _data_string_18386); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_18385)){
            _10276 = SEQ_PTR(_key_string_18385)->length;
    }
    else {
        _10276 = 1;
    }
    _10277 = 4 + _10276;
    _10276 = NOVALUE;
    _0 = _key_ptr_18389;
    _key_ptr_18389 = _38db_allocate(_10277);
    DeRef(_0);
    _10277 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18390)) {
        *poke4_addr = (unsigned long)_data_ptr_18390;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18390)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_18418);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_18418 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at79_18418); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_18418);
    _put4_1__tmp_at79_18418 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _key_string_18385); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10279 = _38current_table_pos_16700 + 4;
        if ((long)((unsigned long)_10279 + (unsigned long)HIGH_BITS) >= 0) 
        _10279 = NewDouble((double)_10279);
    }
    else {
        _10279 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_18422);
    _pos_inlined_seek_at_129_18422 = _10279;
    _10279 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_18422);
    DeRef(_seek_1__tmp_at132_18424);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_18422;
    _seek_1__tmp_at132_18424 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_18423 = machine(19, _seek_1__tmp_at132_18424);
    DeRef(_pos_inlined_seek_at_129_18422);
    _pos_inlined_seek_at_129_18422 = NOVALUE;
    DeRef(_seek_1__tmp_at132_18424);
    _seek_1__tmp_at132_18424 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10280 = _38get4();
    DeRef(_total_recs_18400);
    if (IS_ATOM_INT(_10280)) {
        _total_recs_18400 = _10280 + 1;
        if (_total_recs_18400 > MAXINT){
            _total_recs_18400 = NewDouble((double)_total_recs_18400);
        }
    }
    else
    _total_recs_18400 = binary_op(PLUS, 1, _10280);
    DeRef(_10280);
    _10280 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18402 = _38get4();
    if (!IS_ATOM_INT(_blocks_18402)) {
        _1 = (long)(DBL_PTR(_blocks_18402)->dbl);
        DeRefDS(_blocks_18402);
        _blocks_18402 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10283 = _38current_table_pos_16700 + 4;
        if ((long)((unsigned long)_10283 + (unsigned long)HIGH_BITS) >= 0) 
        _10283 = NewDouble((double)_10283);
    }
    else {
        _10283 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_18430);
    _pos_inlined_seek_at_171_18430 = _10283;
    _10283 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_18430);
    DeRef(_seek_1__tmp_at174_18432);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_18430;
    _seek_1__tmp_at174_18432 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_18431 = machine(19, _seek_1__tmp_at174_18432);
    DeRef(_pos_inlined_seek_at_171_18430);
    _pos_inlined_seek_at_171_18430 = NOVALUE;
    DeRef(_seek_1__tmp_at174_18432);
    _seek_1__tmp_at174_18432 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_18400)) {
        *poke4_addr = (unsigned long)_total_recs_18400;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_18400)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_18434);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_18434 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at189_18434); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_18434);
    _put4_1__tmp_at189_18434 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _n_18404 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _n_18404 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10285 = _n_18404 >> 1;
    if (binary_op_a(LESS, _key_location_18396, _10285)){
        _10285 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10285);
    _10285 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_38key_pointers_16706, _38key_pointers_16706, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_18396)) {
        _10288 = _key_location_18396 + 1;
        if (_10288 > MAXINT){
            _10288 = NewDouble((double)_10288);
        }
    }
    else
    _10288 = binary_op(PLUS, 1, _key_location_18396);
    _10289 = _n_18404 + 1;
    rhs_slice_target = (object_ptr)&_10290;
    RHS_Slice(_38key_pointers_16706, _key_location_18396, _n_18404);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16706;
    AssignSlice(_10288, _10289, _10290);
    DeRef(_10288);
    _10288 = NOVALUE;
    _10289 = NOVALUE;
    DeRefDS(_10290);
    _10290 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_38key_pointers_16706, _38key_pointers_16706, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_18396)) {
        _10292 = _key_location_18396 - 1;
        if ((long)((unsigned long)_10292 +(unsigned long) HIGH_BITS) >= 0){
            _10292 = NewDouble((double)_10292);
        }
    }
    else {
        _10292 = NewDouble(DBL_PTR(_key_location_18396)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10293;
    RHS_Slice(_38key_pointers_16706, 2, _key_location_18396);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16706;
    AssignSlice(1, _10292, _10293);
    DeRef(_10292);
    _10292 = NOVALUE;
    DeRefDS(_10293);
    _10293 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_18389);
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38key_pointers_16706 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_18396))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_18396)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_18396);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_18389;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10294 = _38current_table_pos_16700 + 12;
        if ((long)((unsigned long)_10294 + (unsigned long)HIGH_BITS) >= 0) 
        _10294 = NewDouble((double)_10294);
    }
    else {
        _10294 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_18449);
    _pos_inlined_seek_at_314_18449 = _10294;
    _10294 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_18449);
    DeRef(_seek_1__tmp_at317_18451);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_18449;
    _seek_1__tmp_at317_18451 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_18450 = machine(19, _seek_1__tmp_at317_18451);
    DeRef(_pos_inlined_seek_at_314_18449);
    _pos_inlined_seek_at_314_18449 = NOVALUE;
    DeRef(_seek_1__tmp_at317_18451);
    _seek_1__tmp_at317_18451 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18398;
    _index_ptr_18398 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18398);
    DeRef(_seek_1__tmp_at339_18455);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _index_ptr_18398;
    _seek_1__tmp_at339_18455 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_18454 = machine(19, _seek_1__tmp_at339_18455);
    DeRef(_seek_1__tmp_at339_18455);
    _seek_1__tmp_at339_18455 = NOVALUE;

    /** 	r = 0*/
    _r_18401 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18392;
    _nrecs_18392 = _38get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18391;
    _records_ptr_18391 = _38get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _r_18401 = _r_18401 + _nrecs_18392;
    }
    else {
        _r_18401 = NewDouble((double)_r_18401 + DBL_PTR(_nrecs_18392)->dbl);
    }
    if (!IS_ATOM_INT(_r_18401)) {
        _1 = (long)(DBL_PTR(_r_18401)->dbl);
        DeRefDS(_r_18401);
        _r_18401 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10299 = _r_18401 + 1;
    if (_10299 > MAXINT){
        _10299 = NewDouble((double)_10299);
    }
    if (binary_op_a(LESS, _10299, _key_location_18396)){
        DeRef(_10299);
        _10299 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10299);
    _10299 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_18464);
    _where_inlined_where_at_404_18464 = machine(20, _38current_db_16699);
    DeRef(_current_block_18393);
    if (IS_ATOM_INT(_where_inlined_where_at_404_18464)) {
        _current_block_18393 = _where_inlined_where_at_404_18464 - 8;
        if ((long)((unsigned long)_current_block_18393 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18393 = NewDouble((double)_current_block_18393);
        }
    }
    else {
        _current_block_18393 = NewDouble(DBL_PTR(_where_inlined_where_at_404_18464)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _10302 = _r_18401 - _nrecs_18392;
        if ((long)((unsigned long)_10302 +(unsigned long) HIGH_BITS) >= 0){
            _10302 = NewDouble((double)_10302);
        }
    }
    else {
        _10302 = NewDouble((double)_r_18401 - DBL_PTR(_nrecs_18392)->dbl);
    }
    _0 = _key_location_18396;
    if (IS_ATOM_INT(_key_location_18396) && IS_ATOM_INT(_10302)) {
        _key_location_18396 = _key_location_18396 - _10302;
        if ((long)((unsigned long)_key_location_18396 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_18396 = NewDouble((double)_key_location_18396);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_18396)) {
            _key_location_18396 = NewDouble((double)_key_location_18396 - DBL_PTR(_10302)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10302)) {
                _key_location_18396 = NewDouble(DBL_PTR(_key_location_18396)->dbl - (double)_10302);
            }
            else
            _key_location_18396 = NewDouble(DBL_PTR(_key_location_18396)->dbl - DBL_PTR(_10302)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10302);
    _10302 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_18396)) {
        _10304 = _key_location_18396 - 1;
        if ((long)((unsigned long)_10304 +(unsigned long) HIGH_BITS) >= 0){
            _10304 = NewDouble((double)_10304);
        }
    }
    else {
        _10304 = NewDouble(DBL_PTR(_key_location_18396)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10304)) {
        if (_10304 <= INT15 && _10304 >= -INT15)
        _10305 = 4 * _10304;
        else
        _10305 = NewDouble(4 * (double)_10304);
    }
    else {
        _10305 = NewDouble((double)4 * DBL_PTR(_10304)->dbl);
    }
    DeRef(_10304);
    _10304 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18391) && IS_ATOM_INT(_10305)) {
        _10306 = _records_ptr_18391 + _10305;
        if ((long)((unsigned long)_10306 + (unsigned long)HIGH_BITS) >= 0) 
        _10306 = NewDouble((double)_10306);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18391)) {
            _10306 = NewDouble((double)_records_ptr_18391 + DBL_PTR(_10305)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10305)) {
                _10306 = NewDouble(DBL_PTR(_records_ptr_18391)->dbl + (double)_10305);
            }
            else
            _10306 = NewDouble(DBL_PTR(_records_ptr_18391)->dbl + DBL_PTR(_10305)->dbl);
        }
    }
    DeRef(_10305);
    _10305 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_18472);
    _pos_inlined_seek_at_445_18472 = _10306;
    _10306 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_18472);
    DeRef(_seek_1__tmp_at448_18474);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_18472;
    _seek_1__tmp_at448_18474 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_18473 = machine(19, _seek_1__tmp_at448_18474);
    DeRef(_pos_inlined_seek_at_445_18472);
    _pos_inlined_seek_at_445_18472 = NOVALUE;
    DeRef(_seek_1__tmp_at448_18474);
    _seek_1__tmp_at448_18474 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _10307 = _nrecs_18392 + 1;
        if (_10307 > MAXINT){
            _10307 = NewDouble((double)_10307);
        }
    }
    else
    _10307 = binary_op(PLUS, 1, _nrecs_18392);
    {
        int _i_18476;
        Ref(_key_location_18396);
        _i_18476 = _key_location_18396;
LA: 
        if (binary_op_a(GREATER, _i_18476, _10307)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_18476)) {
            _10308 = _i_18476 + _r_18401;
            if ((long)((unsigned long)_10308 + (unsigned long)HIGH_BITS) >= 0) 
            _10308 = NewDouble((double)_10308);
        }
        else {
            _10308 = NewDouble(DBL_PTR(_i_18476)->dbl + (double)_r_18401);
        }
        if (IS_ATOM_INT(_10308) && IS_ATOM_INT(_nrecs_18392)) {
            _10309 = _10308 - _nrecs_18392;
        }
        else {
            if (IS_ATOM_INT(_10308)) {
                _10309 = NewDouble((double)_10308 - DBL_PTR(_nrecs_18392)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_18392)) {
                    _10309 = NewDouble(DBL_PTR(_10308)->dbl - (double)_nrecs_18392);
                }
                else
                _10309 = NewDouble(DBL_PTR(_10308)->dbl - DBL_PTR(_nrecs_18392)->dbl);
            }
        }
        DeRef(_10308);
        _10308 = NOVALUE;
        _2 = (int)SEQ_PTR(_38key_pointers_16706);
        if (!IS_ATOM_INT(_10309)){
            _10310 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10309)->dbl));
        }
        else{
            _10310 = (int)*(((s1_ptr)_2)->base + _10309);
        }
        Ref(_10310);
        DeRef(_x_inlined_put4_at_490_18482);
        _x_inlined_put4_at_490_18482 = _10310;
        _10310 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_18482)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_18482;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_18482)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_18482)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_18482);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_18483);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_18483 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at493_18483); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_18482);
        _x_inlined_put4_at_490_18482 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_18483);
        _put4_1__tmp_at493_18483 = NOVALUE;

        /** 	end for*/
        _0 = _i_18476;
        if (IS_ATOM_INT(_i_18476)) {
            _i_18476 = _i_18476 + 1;
            if ((long)((unsigned long)_i_18476 +(unsigned long) HIGH_BITS) >= 0){
                _i_18476 = NewDouble((double)_i_18476);
            }
        }
        else {
            _i_18476 = binary_op_a(PLUS, _i_18476, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_18476);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18393);
    DeRef(_seek_1__tmp_at530_18486);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _current_block_18393;
    _seek_1__tmp_at530_18486 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_18485 = machine(19, _seek_1__tmp_at530_18486);
    DeRef(_seek_1__tmp_at530_18486);
    _seek_1__tmp_at530_18486 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_18392;
    if (IS_ATOM_INT(_nrecs_18392)) {
        _nrecs_18392 = _nrecs_18392 + 1;
        if (_nrecs_18392 > MAXINT){
            _nrecs_18392 = NewDouble((double)_nrecs_18392);
        }
    }
    else
    _nrecs_18392 = binary_op(PLUS, 1, _nrecs_18392);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18392)) {
        *poke4_addr = (unsigned long)_nrecs_18392;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18392)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_18489);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_18489 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at551_18489); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_18489);
    _put4_1__tmp_at551_18489 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_18391)) {
        _10312 = _records_ptr_18391 - 4;
        if ((long)((unsigned long)_10312 +(unsigned long) HIGH_BITS) >= 0){
            _10312 = NewDouble((double)_10312);
        }
    }
    else {
        _10312 = NewDouble(DBL_PTR(_records_ptr_18391)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_18492);
    _pos_inlined_seek_at_585_18492 = _10312;
    _10312 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_18492);
    DeRef(_seek_1__tmp_at588_18494);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_18492;
    _seek_1__tmp_at588_18494 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_18493 = machine(19, _seek_1__tmp_at588_18494);
    DeRef(_pos_inlined_seek_at_585_18492);
    _pos_inlined_seek_at_585_18492 = NOVALUE;
    DeRef(_seek_1__tmp_at588_18494);
    _seek_1__tmp_at588_18494 = NOVALUE;

    /** 	size = get4() - 4*/
    _10313 = _38get4();
    DeRef(_size_18394);
    if (IS_ATOM_INT(_10313)) {
        _size_18394 = _10313 - 4;
        if ((long)((unsigned long)_size_18394 +(unsigned long) HIGH_BITS) >= 0){
            _size_18394 = NewDouble((double)_size_18394);
        }
    }
    else {
        _size_18394 = binary_op(MINUS, _10313, 4);
    }
    DeRef(_10313);
    _10313 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        if (_nrecs_18392 == (short)_nrecs_18392)
        _10315 = _nrecs_18392 * 4;
        else
        _10315 = NewDouble(_nrecs_18392 * (double)4);
    }
    else {
        _10315 = NewDouble(DBL_PTR(_nrecs_18392)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_18394)) {
        _10316 = _size_18394 - 4;
        if ((long)((unsigned long)_10316 +(unsigned long) HIGH_BITS) >= 0){
            _10316 = NewDouble((double)_10316);
        }
    }
    else {
        _10316 = NewDouble(DBL_PTR(_size_18394)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10315, _10316)){
        DeRef(_10315);
        _10315 = NOVALUE;
        DeRef(_10316);
        _10316 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10315);
    _10315 = NOVALUE;
    DeRef(_10316);
    _10316 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_18400)) {
        _10319 = NewDouble(DBL_PTR(_10318)->dbl * (double)_total_recs_18400);
    }
    else
    _10319 = NewDouble(DBL_PTR(_10318)->dbl * DBL_PTR(_total_recs_18400)->dbl);
    _10320 = unary_op(SQRT, _10319);
    DeRefDS(_10319);
    _10319 = NOVALUE;
    _10321 = unary_op(FLOOR, _10320);
    DeRefDS(_10320);
    _10320 = NOVALUE;
    if (IS_ATOM_INT(_10321)) {
        _10322 = 20 + _10321;
        if ((long)((unsigned long)_10322 + (unsigned long)HIGH_BITS) >= 0) 
        _10322 = NewDouble((double)_10322);
    }
    else {
        _10322 = NewDouble((double)20 + DBL_PTR(_10321)->dbl);
    }
    DeRef(_10321);
    _10321 = NOVALUE;
    DeRef(_new_size_18395);
    if (IS_ATOM_INT(_10322)) {
        if (_10322 <= INT15 && _10322 >= -INT15)
        _new_size_18395 = 8 * _10322;
        else
        _new_size_18395 = NewDouble(8 * (double)_10322);
    }
    else {
        _new_size_18395 = NewDouble((double)8 * DBL_PTR(_10322)->dbl);
    }
    DeRef(_10322);
    _10322 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_18395)) {
        if (8 > 0 && _new_size_18395 >= 0) {
            _new_recs_18403 = _new_size_18395 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_18395 / (double)8);
            _new_recs_18403 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_18395, 8);
        _new_recs_18403 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_18403)) {
        _1 = (long)(DBL_PTR(_new_recs_18403)->dbl);
        DeRefDS(_new_recs_18403);
        _new_recs_18403 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _10325 = _nrecs_18392 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18392, 2);
        _10325 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_18403, _10325)){
        DeRef(_10325);
        _10325 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10325);
    _10325 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _new_recs_18403 = _nrecs_18392 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18392, 2);
        _new_recs_18403 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_18403)) {
        _1 = (long)(DBL_PTR(_new_recs_18403)->dbl);
        DeRefDS(_new_recs_18403);
        _new_recs_18403 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _10328 = _nrecs_18392 - _new_recs_18403;
        if ((long)((unsigned long)_10328 +(unsigned long) HIGH_BITS) >= 0){
            _10328 = NewDouble((double)_10328);
        }
    }
    else {
        _10328 = NewDouble(DBL_PTR(_nrecs_18392)->dbl - (double)_new_recs_18403);
    }
    if (IS_ATOM_INT(_10328)) {
        if (_10328 == (short)_10328)
        _10329 = _10328 * 4;
        else
        _10329 = NewDouble(_10328 * (double)4);
    }
    else {
        _10329 = NewDouble(DBL_PTR(_10328)->dbl * (double)4);
    }
    DeRef(_10328);
    _10328 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18391) && IS_ATOM_INT(_10329)) {
        _10330 = _records_ptr_18391 + _10329;
        if ((long)((unsigned long)_10330 + (unsigned long)HIGH_BITS) >= 0) 
        _10330 = NewDouble((double)_10330);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18391)) {
            _10330 = NewDouble((double)_records_ptr_18391 + DBL_PTR(_10329)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10329)) {
                _10330 = NewDouble(DBL_PTR(_records_ptr_18391)->dbl + (double)_10329);
            }
            else
            _10330 = NewDouble(DBL_PTR(_records_ptr_18391)->dbl + DBL_PTR(_10329)->dbl);
        }
    }
    DeRef(_10329);
    _10329 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_18516);
    _pos_inlined_seek_at_687_18516 = _10330;
    _10330 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_18516);
    DeRef(_seek_1__tmp_at690_18518);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_18516;
    _seek_1__tmp_at690_18518 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_18517 = machine(19, _seek_1__tmp_at690_18518);
    DeRef(_pos_inlined_seek_at_687_18516);
    _pos_inlined_seek_at_687_18516 = NOVALUE;
    DeRef(_seek_1__tmp_at690_18518);
    _seek_1__tmp_at690_18518 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_18403 == (short)_new_recs_18403)
    _10331 = _new_recs_18403 * 4;
    else
    _10331 = NewDouble(_new_recs_18403 * (double)4);
    _0 = _last_part_18387;
    _last_part_18387 = _18get_bytes(_38current_db_16699, _10331);
    DeRef(_0);
    _10331 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_18395);
    _0 = _new_block_18397;
    _new_block_18397 = _38db_allocate(_new_size_18395);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _last_part_18387); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_18387)){
            _10334 = SEQ_PTR(_last_part_18387)->length;
    }
    else {
        _10334 = 1;
    }
    if (IS_ATOM_INT(_new_size_18395)) {
        _10335 = _new_size_18395 - _10334;
    }
    else {
        _10335 = NewDouble(DBL_PTR(_new_size_18395)->dbl - (double)_10334);
    }
    _10334 = NOVALUE;
    _10336 = Repeat(0, _10335);
    DeRef(_10335);
    _10335 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_18527);
    _s_inlined_putn_at_751_18527 = _10336;
    _10336 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_751_18527); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_18527);
    _s_inlined_putn_at_751_18527 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18393);
    DeRef(_seek_1__tmp_at774_18530);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _current_block_18393;
    _seek_1__tmp_at774_18530 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_18529 = machine(19, _seek_1__tmp_at774_18530);
    DeRef(_seek_1__tmp_at774_18530);
    _seek_1__tmp_at774_18530 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_18392)) {
        _10337 = _nrecs_18392 - _new_recs_18403;
        if ((long)((unsigned long)_10337 +(unsigned long) HIGH_BITS) >= 0){
            _10337 = NewDouble((double)_10337);
        }
    }
    else {
        _10337 = NewDouble(DBL_PTR(_nrecs_18392)->dbl - (double)_new_recs_18403);
    }
    DeRef(_x_inlined_put4_at_793_18533);
    _x_inlined_put4_at_793_18533 = _10337;
    _10337 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_18533)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_18533;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_18533)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_18534);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_18534 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at796_18534); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_18533);
    _x_inlined_put4_at_793_18533 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_18534);
    _put4_1__tmp_at796_18534 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18393)) {
        _10338 = _current_block_18393 + 8;
        if ((long)((unsigned long)_10338 + (unsigned long)HIGH_BITS) >= 0) 
        _10338 = NewDouble((double)_10338);
    }
    else {
        _10338 = NewDouble(DBL_PTR(_current_block_18393)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_18537);
    _pos_inlined_seek_at_830_18537 = _10338;
    _10338 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_18537);
    DeRef(_seek_1__tmp_at833_18539);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_18537;
    _seek_1__tmp_at833_18539 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_18538 = machine(19, _seek_1__tmp_at833_18539);
    DeRef(_pos_inlined_seek_at_830_18537);
    _pos_inlined_seek_at_830_18537 = NOVALUE;
    DeRef(_seek_1__tmp_at833_18539);
    _seek_1__tmp_at833_18539 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18402 == (short)_blocks_18402)
    _10339 = _blocks_18402 * 8;
    else
    _10339 = NewDouble(_blocks_18402 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18398) && IS_ATOM_INT(_10339)) {
        _10340 = _index_ptr_18398 + _10339;
        if ((long)((unsigned long)_10340 + (unsigned long)HIGH_BITS) >= 0) 
        _10340 = NewDouble((double)_10340);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18398)) {
            _10340 = NewDouble((double)_index_ptr_18398 + DBL_PTR(_10339)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10339)) {
                _10340 = NewDouble(DBL_PTR(_index_ptr_18398)->dbl + (double)_10339);
            }
            else
            _10340 = NewDouble(DBL_PTR(_index_ptr_18398)->dbl + DBL_PTR(_10339)->dbl);
        }
    }
    DeRef(_10339);
    _10339 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18393)) {
        _10341 = _current_block_18393 + 8;
        if ((long)((unsigned long)_10341 + (unsigned long)HIGH_BITS) >= 0) 
        _10341 = NewDouble((double)_10341);
    }
    else {
        _10341 = NewDouble(DBL_PTR(_current_block_18393)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10340) && IS_ATOM_INT(_10341)) {
        _10342 = _10340 - _10341;
        if ((long)((unsigned long)_10342 +(unsigned long) HIGH_BITS) >= 0){
            _10342 = NewDouble((double)_10342);
        }
    }
    else {
        if (IS_ATOM_INT(_10340)) {
            _10342 = NewDouble((double)_10340 - DBL_PTR(_10341)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10341)) {
                _10342 = NewDouble(DBL_PTR(_10340)->dbl - (double)_10341);
            }
            else
            _10342 = NewDouble(DBL_PTR(_10340)->dbl - DBL_PTR(_10341)->dbl);
        }
    }
    DeRef(_10340);
    _10340 = NOVALUE;
    DeRef(_10341);
    _10341 = NOVALUE;
    _0 = _remaining_18388;
    _remaining_18388 = _18get_bytes(_38current_db_16699, _10342);
    DeRef(_0);
    _10342 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18393)) {
        _10344 = _current_block_18393 + 8;
        if ((long)((unsigned long)_10344 + (unsigned long)HIGH_BITS) >= 0) 
        _10344 = NewDouble((double)_10344);
    }
    else {
        _10344 = NewDouble(DBL_PTR(_current_block_18393)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_18547);
    _pos_inlined_seek_at_881_18547 = _10344;
    _10344 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_18547);
    DeRef(_seek_1__tmp_at884_18549);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_18547;
    _seek_1__tmp_at884_18549 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_18548 = machine(19, _seek_1__tmp_at884_18549);
    DeRef(_pos_inlined_seek_at_881_18547);
    _pos_inlined_seek_at_881_18547 = NOVALUE;
    DeRef(_seek_1__tmp_at884_18549);
    _seek_1__tmp_at884_18549 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_18403;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_18551);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_18551 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at899_18551); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_18551);
    _put4_1__tmp_at899_18551 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_new_block_18397)) {
        *poke4_addr = (unsigned long)_new_block_18397;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_18397)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_18553);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_18553 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at927_18553); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_18553);
    _put4_1__tmp_at927_18553 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_18388); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10345 = _38current_table_pos_16700 + 8;
        if ((long)((unsigned long)_10345 + (unsigned long)HIGH_BITS) >= 0) 
        _10345 = NewDouble((double)_10345);
    }
    else {
        _10345 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_18557);
    _pos_inlined_seek_at_977_18557 = _10345;
    _10345 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_18557);
    DeRef(_seek_1__tmp_at980_18559);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_18557;
    _seek_1__tmp_at980_18559 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_18558 = machine(19, _seek_1__tmp_at980_18559);
    DeRef(_pos_inlined_seek_at_977_18557);
    _pos_inlined_seek_at_977_18557 = NOVALUE;
    DeRef(_seek_1__tmp_at980_18559);
    _seek_1__tmp_at980_18559 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_18402 = _blocks_18402 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_18402;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_18562);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_18562 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at1001_18562); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_18562);
    _put4_1__tmp_at1001_18562 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_18398)) {
        _10347 = _index_ptr_18398 - 4;
        if ((long)((unsigned long)_10347 +(unsigned long) HIGH_BITS) >= 0){
            _10347 = NewDouble((double)_10347);
        }
    }
    else {
        _10347 = NewDouble(DBL_PTR(_index_ptr_18398)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_18565);
    _pos_inlined_seek_at_1035_18565 = _10347;
    _10347 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_18565);
    DeRef(_seek_1__tmp_at1038_18567);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_18565;
    _seek_1__tmp_at1038_18567 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_18566 = machine(19, _seek_1__tmp_at1038_18567);
    DeRef(_pos_inlined_seek_at_1035_18565);
    _pos_inlined_seek_at_1035_18565 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_18567);
    _seek_1__tmp_at1038_18567 = NOVALUE;

    /** 		size = get4() - 4*/
    _10348 = _38get4();
    DeRef(_size_18394);
    if (IS_ATOM_INT(_10348)) {
        _size_18394 = _10348 - 4;
        if ((long)((unsigned long)_size_18394 +(unsigned long) HIGH_BITS) >= 0){
            _size_18394 = NewDouble((double)_size_18394);
        }
    }
    else {
        _size_18394 = binary_op(MINUS, _10348, 4);
    }
    DeRef(_10348);
    _10348 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_18402 == (short)_blocks_18402)
    _10350 = _blocks_18402 * 8;
    else
    _10350 = NewDouble(_blocks_18402 * (double)8);
    if (IS_ATOM_INT(_size_18394)) {
        _10351 = _size_18394 - 8;
        if ((long)((unsigned long)_10351 +(unsigned long) HIGH_BITS) >= 0){
            _10351 = NewDouble((double)_10351);
        }
    }
    else {
        _10351 = NewDouble(DBL_PTR(_size_18394)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10350, _10351)){
        DeRef(_10350);
        _10350 = NOVALUE;
        DeRef(_10351);
        _10351 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10350);
    _10350 = NOVALUE;
    DeRef(_10351);
    _10351 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_18402 == (short)_blocks_18402)
    _10353 = _blocks_18402 * 8;
    else
    _10353 = NewDouble(_blocks_18402 * (double)8);
    _0 = _remaining_18388;
    _remaining_18388 = _18get_bytes(_38current_db_16699, _10353);
    DeRef(_0);
    _10353 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_18394)) {
        if (_size_18394 & 1) {
            _10355 = NewDouble((_size_18394 >> 1) + 0.5);
        }
        else
        _10355 = _size_18394 >> 1;
    }
    else {
        _10355 = binary_op(DIVIDE, _size_18394, 2);
    }
    if (IS_ATOM_INT(_size_18394) && IS_ATOM_INT(_10355)) {
        _10356 = _size_18394 + _10355;
        if ((long)((unsigned long)_10356 + (unsigned long)HIGH_BITS) >= 0) 
        _10356 = NewDouble((double)_10356);
    }
    else {
        if (IS_ATOM_INT(_size_18394)) {
            _10356 = NewDouble((double)_size_18394 + DBL_PTR(_10355)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10355)) {
                _10356 = NewDouble(DBL_PTR(_size_18394)->dbl + (double)_10355);
            }
            else
            _10356 = NewDouble(DBL_PTR(_size_18394)->dbl + DBL_PTR(_10355)->dbl);
        }
    }
    DeRef(_10355);
    _10355 = NOVALUE;
    DeRef(_new_size_18395);
    if (IS_ATOM_INT(_10356))
    _new_size_18395 = e_floor(_10356);
    else
    _new_size_18395 = unary_op(FLOOR, _10356);
    DeRef(_10356);
    _10356 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_18395);
    _0 = _new_index_ptr_18399;
    _new_index_ptr_18399 = _38db_allocate(_new_size_18395);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_18388); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_18402 == (short)_blocks_18402)
    _10359 = _blocks_18402 * 8;
    else
    _10359 = NewDouble(_blocks_18402 * (double)8);
    if (IS_ATOM_INT(_new_size_18395) && IS_ATOM_INT(_10359)) {
        _10360 = _new_size_18395 - _10359;
    }
    else {
        if (IS_ATOM_INT(_new_size_18395)) {
            _10360 = NewDouble((double)_new_size_18395 - DBL_PTR(_10359)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10359)) {
                _10360 = NewDouble(DBL_PTR(_new_size_18395)->dbl - (double)_10359);
            }
            else
            _10360 = NewDouble(DBL_PTR(_new_size_18395)->dbl - DBL_PTR(_10359)->dbl);
        }
    }
    DeRef(_10359);
    _10359 = NOVALUE;
    _10361 = Repeat(0, _10360);
    DeRef(_10360);
    _10360 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_18585);
    _s_inlined_putn_at_1136_18585 = _10361;
    _10361 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _s_inlined_putn_at_1136_18585); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_18585);
    _s_inlined_putn_at_1136_18585 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_18398);
    _38db_free(_index_ptr_18398);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10362 = _38current_table_pos_16700 + 12;
        if ((long)((unsigned long)_10362 + (unsigned long)HIGH_BITS) >= 0) 
        _10362 = NewDouble((double)_10362);
    }
    else {
        _10362 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_18588);
    _pos_inlined_seek_at_1170_18588 = _10362;
    _10362 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_18588);
    DeRef(_seek_1__tmp_at1173_18590);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_18588;
    _seek_1__tmp_at1173_18590 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_18589 = machine(19, _seek_1__tmp_at1173_18590);
    DeRef(_pos_inlined_seek_at_1170_18588);
    _pos_inlined_seek_at_1170_18588 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_18590);
    _seek_1__tmp_at1173_18590 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_18399)) {
        *poke4_addr = (unsigned long)_new_index_ptr_18399;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_18399)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_18592);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_18592 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at1188_18592); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_18592);
    _put4_1__tmp_at1188_18592 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_18382);
    DeRef(_data_18383);
    DeRef(_table_name_18384);
    DeRef(_key_string_18385);
    DeRef(_data_string_18386);
    DeRef(_last_part_18387);
    DeRef(_remaining_18388);
    DeRef(_key_ptr_18389);
    DeRef(_data_ptr_18390);
    DeRef(_records_ptr_18391);
    DeRef(_nrecs_18392);
    DeRef(_current_block_18393);
    DeRef(_size_18394);
    DeRef(_new_size_18395);
    DeRef(_key_location_18396);
    DeRef(_new_block_18397);
    DeRef(_index_ptr_18398);
    DeRef(_new_index_ptr_18399);
    DeRef(_total_recs_18400);
    DeRef(_10307);
    _10307 = NOVALUE;
    DeRef(_10309);
    _10309 = NOVALUE;
    return 0;
    ;
}


void  __stdcall _38db_delete_record(int _key_location_18595, int _table_name_18596)
{
    int _key_ptr_18597 = NOVALUE;
    int _nrecs_18598 = NOVALUE;
    int _records_ptr_18599 = NOVALUE;
    int _data_ptr_18600 = NOVALUE;
    int _index_ptr_18601 = NOVALUE;
    int _current_block_18602 = NOVALUE;
    int _r_18603 = NOVALUE;
    int _blocks_18604 = NOVALUE;
    int _n_18605 = NOVALUE;
    int _remaining_18606 = NOVALUE;
    int _seek_1__tmp_at122_18628 = NOVALUE;
    int _seek_inlined_seek_at_122_18627 = NOVALUE;
    int _seek_1__tmp_at265_18650 = NOVALUE;
    int _seek_inlined_seek_at_265_18649 = NOVALUE;
    int _pos_inlined_seek_at_262_18648 = NOVALUE;
    int _seek_1__tmp_at307_18658 = NOVALUE;
    int _seek_inlined_seek_at_307_18657 = NOVALUE;
    int _pos_inlined_seek_at_304_18656 = NOVALUE;
    int _put4_1__tmp_at322_18660 = NOVALUE;
    int _seek_1__tmp_at361_18665 = NOVALUE;
    int _seek_inlined_seek_at_361_18664 = NOVALUE;
    int _pos_inlined_seek_at_358_18663 = NOVALUE;
    int _seek_1__tmp_at383_18669 = NOVALUE;
    int _seek_inlined_seek_at_383_18668 = NOVALUE;
    int _where_inlined_where_at_452_18678 = NOVALUE;
    int _seek_1__tmp_at518_18692 = NOVALUE;
    int _seek_inlined_seek_at_518_18691 = NOVALUE;
    int _seek_1__tmp_at558_18698 = NOVALUE;
    int _seek_inlined_seek_at_558_18697 = NOVALUE;
    int _pos_inlined_seek_at_555_18696 = NOVALUE;
    int _put4_1__tmp_at580_18702 = NOVALUE;
    int _x_inlined_put4_at_577_18701 = NOVALUE;
    int _seek_1__tmp_at626_18707 = NOVALUE;
    int _seek_inlined_seek_at_626_18706 = NOVALUE;
    int _put4_1__tmp_at641_18709 = NOVALUE;
    int _seek_1__tmp_at688_18716 = NOVALUE;
    int _seek_inlined_seek_at_688_18715 = NOVALUE;
    int _pos_inlined_seek_at_685_18714 = NOVALUE;
    int _put4_1__tmp_at728_18724 = NOVALUE;
    int _x_inlined_put4_at_725_18723 = NOVALUE;
    int _10422 = NOVALUE;
    int _10421 = NOVALUE;
    int _10420 = NOVALUE;
    int _10419 = NOVALUE;
    int _10418 = NOVALUE;
    int _10417 = NOVALUE;
    int _10415 = NOVALUE;
    int _10414 = NOVALUE;
    int _10412 = NOVALUE;
    int _10411 = NOVALUE;
    int _10410 = NOVALUE;
    int _10409 = NOVALUE;
    int _10408 = NOVALUE;
    int _10407 = NOVALUE;
    int _10406 = NOVALUE;
    int _10397 = NOVALUE;
    int _10396 = NOVALUE;
    int _10393 = NOVALUE;
    int _10392 = NOVALUE;
    int _10390 = NOVALUE;
    int _10389 = NOVALUE;
    int _10387 = NOVALUE;
    int _10386 = NOVALUE;
    int _10385 = NOVALUE;
    int _10384 = NOVALUE;
    int _10382 = NOVALUE;
    int _10378 = NOVALUE;
    int _10376 = NOVALUE;
    int _10374 = NOVALUE;
    int _10373 = NOVALUE;
    int _10371 = NOVALUE;
    int _10370 = NOVALUE;
    int _10368 = NOVALUE;
    int _10365 = NOVALUE;
    int _10363 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18595)) {
        _1 = (long)(DBL_PTR(_key_location_18595)->dbl);
        DeRefDS(_key_location_18595);
        _key_location_18595 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18596 == _38current_table_name_16701)
    _10363 = 1;
    else if (IS_ATOM_INT(_table_name_18596) && IS_ATOM_INT(_38current_table_name_16701))
    _10363 = 0;
    else
    _10363 = (compare(_table_name_18596, _38current_table_name_16701) == 0);
    if (_10363 != 0)
    goto L1; // [11] 43
    _10363 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18596);
    _10365 = _38db_select_table(_table_name_18596);
    if (binary_op_a(EQUALS, _10365, 0)){
        DeRef(_10365);
        _10365 = NOVALUE;
        goto L2; // [20] 42
    }
    DeRef(_10365);
    _10365 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18596);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18595;
    ((int *)_2)[2] = _table_name_18596;
    _10368 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10367);
    _38fatal(903, _10249, _10367, _10368);
    _10368 = NOVALUE;

    /** 			return*/
    DeRef(_table_name_18596);
    DeRef(_key_ptr_18597);
    DeRef(_nrecs_18598);
    DeRef(_records_ptr_18599);
    DeRef(_data_ptr_18600);
    DeRef(_index_ptr_18601);
    DeRef(_current_block_18602);
    DeRef(_remaining_18606);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [47] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18596);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18595;
    ((int *)_2)[2] = _table_name_18596;
    _10370 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10367);
    _38fatal(903, _10253, _10367, _10370);
    _10370 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_18596);
    DeRef(_key_ptr_18597);
    DeRef(_nrecs_18598);
    DeRef(_records_ptr_18599);
    DeRef(_data_ptr_18600);
    DeRef(_index_ptr_18601);
    DeRef(_current_block_18602);
    DeRef(_remaining_18606);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10371 = (_key_location_18595 < 1);
    if (_10371 != 0) {
        goto L4; // [75] 93
    }
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _10373 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _10373 = 1;
    }
    _10374 = (_key_location_18595 > _10373);
    _10373 = NOVALUE;
    if (_10374 == 0)
    {
        DeRef(_10374);
        _10374 = NOVALUE;
        goto L5; // [89] 111
    }
    else{
        DeRef(_10374);
        _10374 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_delete_record", {key_location, table_name})*/
    Ref(_table_name_18596);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18595;
    ((int *)_2)[2] = _table_name_18596;
    _10376 = MAKE_SEQ(_1);
    RefDS(_10375);
    RefDS(_10367);
    _38fatal(905, _10375, _10367, _10376);
    _10376 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_18596);
    DeRef(_key_ptr_18597);
    DeRef(_nrecs_18598);
    DeRef(_records_ptr_18599);
    DeRef(_data_ptr_18600);
    DeRef(_index_ptr_18601);
    DeRef(_current_block_18602);
    DeRef(_remaining_18606);
    DeRef(_10371);
    _10371 = NOVALUE;
    return;
L5: 

    /** 	key_ptr = key_pointers[key_location]*/
    DeRef(_key_ptr_18597);
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _key_ptr_18597 = (int)*(((s1_ptr)_2)->base + _key_location_18595);
    Ref(_key_ptr_18597);

    /** 	io:seek(current_db, key_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_key_ptr_18597);
    DeRef(_seek_1__tmp_at122_18628);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _key_ptr_18597;
    _seek_1__tmp_at122_18628 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_122_18627 = machine(19, _seek_1__tmp_at122_18628);
    DeRef(_seek_1__tmp_at122_18628);
    _seek_1__tmp_at122_18628 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _10378 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _10378 = 1;
    }
    if (_10378 <= 0)
    goto L6; // [143] 151
    DeRef(_table_name_18596);
    DeRef(_key_ptr_18597);
    DeRef(_nrecs_18598);
    DeRef(_records_ptr_18599);
    DeRef(_data_ptr_18600);
    DeRef(_index_ptr_18601);
    DeRef(_current_block_18602);
    DeRef(_remaining_18606);
    DeRef(_10371);
    _10371 = NOVALUE;
    return;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18600;
    _data_ptr_18600 = _38get4();
    DeRef(_0);

    /** 	db_free(key_ptr)*/
    Ref(_key_ptr_18597);
    _38db_free(_key_ptr_18597);

    /** 	db_free(data_ptr)*/
    Ref(_data_ptr_18600);
    _38db_free(_data_ptr_18600);

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _n_18605 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _n_18605 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10382 = _n_18605 >> 1;
    if (_key_location_18595 < _10382)
    goto L7; // [179] 223

    /** 		key_pointers[key_location..n-1] = key_pointers[key_location+1..n]*/
    _10384 = _n_18605 - 1;
    _10385 = _key_location_18595 + 1;
    rhs_slice_target = (object_ptr)&_10386;
    RHS_Slice(_38key_pointers_16706, _10385, _n_18605);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16706;
    AssignSlice(_key_location_18595, _10384, _10386);
    _10384 = NOVALUE;
    DeRefDS(_10386);
    _10386 = NOVALUE;

    /** 		key_pointers = key_pointers[1..n-1]*/
    _10387 = _n_18605 - 1;
    rhs_slice_target = (object_ptr)&_38key_pointers_16706;
    RHS_Slice(_38key_pointers_16706, 1, _10387);
    goto L8; // [220] 253
L7: 

    /** 		key_pointers[2..key_location] = key_pointers[1..key_location-1]*/
    _10389 = _key_location_18595 - 1;
    rhs_slice_target = (object_ptr)&_10390;
    RHS_Slice(_38key_pointers_16706, 1, _10389);
    assign_slice_seq = (s1_ptr *)&_38key_pointers_16706;
    AssignSlice(2, _key_location_18595, _10390);
    DeRefDS(_10390);
    _10390 = NOVALUE;

    /** 		key_pointers = key_pointers[2..n]*/
    rhs_slice_target = (object_ptr)&_38key_pointers_16706;
    RHS_Slice(_38key_pointers_16706, 2, _n_18605);
L8: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10392 = _38current_table_pos_16700 + 4;
        if ((long)((unsigned long)_10392 + (unsigned long)HIGH_BITS) >= 0) 
        _10392 = NewDouble((double)_10392);
    }
    else {
        _10392 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_262_18648);
    _pos_inlined_seek_at_262_18648 = _10392;
    _10392 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_262_18648);
    DeRef(_seek_1__tmp_at265_18650);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_262_18648;
    _seek_1__tmp_at265_18650 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_265_18649 = machine(19, _seek_1__tmp_at265_18650);
    DeRef(_pos_inlined_seek_at_262_18648);
    _pos_inlined_seek_at_262_18648 = NOVALUE;
    DeRef(_seek_1__tmp_at265_18650);
    _seek_1__tmp_at265_18650 = NOVALUE;

    /** 	nrecs = get4()-1*/
    _10393 = _38get4();
    DeRef(_nrecs_18598);
    if (IS_ATOM_INT(_10393)) {
        _nrecs_18598 = _10393 - 1;
        if ((long)((unsigned long)_nrecs_18598 +(unsigned long) HIGH_BITS) >= 0){
            _nrecs_18598 = NewDouble((double)_nrecs_18598);
        }
    }
    else {
        _nrecs_18598 = binary_op(MINUS, _10393, 1);
    }
    DeRef(_10393);
    _10393 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18604 = _38get4();
    if (!IS_ATOM_INT(_blocks_18604)) {
        _1 = (long)(DBL_PTR(_blocks_18604)->dbl);
        DeRefDS(_blocks_18604);
        _blocks_18604 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10396 = _38current_table_pos_16700 + 4;
        if ((long)((unsigned long)_10396 + (unsigned long)HIGH_BITS) >= 0) 
        _10396 = NewDouble((double)_10396);
    }
    else {
        _10396 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_304_18656);
    _pos_inlined_seek_at_304_18656 = _10396;
    _10396 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_304_18656);
    DeRef(_seek_1__tmp_at307_18658);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_304_18656;
    _seek_1__tmp_at307_18658 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_307_18657 = machine(19, _seek_1__tmp_at307_18658);
    DeRef(_pos_inlined_seek_at_304_18656);
    _pos_inlined_seek_at_304_18656 = NOVALUE;
    DeRef(_seek_1__tmp_at307_18658);
    _seek_1__tmp_at307_18658 = NOVALUE;

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18598)) {
        *poke4_addr = (unsigned long)_nrecs_18598;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18598)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at322_18660);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at322_18660 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at322_18660); // DJP 

    /** end procedure*/
    goto L9; // [344] 347
L9: 
    DeRefi(_put4_1__tmp_at322_18660);
    _put4_1__tmp_at322_18660 = NOVALUE;

    /** 	io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10397 = _38current_table_pos_16700 + 12;
        if ((long)((unsigned long)_10397 + (unsigned long)HIGH_BITS) >= 0) 
        _10397 = NewDouble((double)_10397);
    }
    else {
        _10397 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_358_18663);
    _pos_inlined_seek_at_358_18663 = _10397;
    _10397 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_358_18663);
    DeRef(_seek_1__tmp_at361_18665);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_358_18663;
    _seek_1__tmp_at361_18665 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_361_18664 = machine(19, _seek_1__tmp_at361_18665);
    DeRef(_pos_inlined_seek_at_358_18663);
    _pos_inlined_seek_at_358_18663 = NOVALUE;
    DeRef(_seek_1__tmp_at361_18665);
    _seek_1__tmp_at361_18665 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18601;
    _index_ptr_18601 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18601);
    DeRef(_seek_1__tmp_at383_18669);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _index_ptr_18601;
    _seek_1__tmp_at383_18669 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_383_18668 = machine(19, _seek_1__tmp_at383_18669);
    DeRef(_seek_1__tmp_at383_18669);
    _seek_1__tmp_at383_18669 = NOVALUE;

    /** 	r = 0*/
    _r_18603 = 0;

    /** 	while TRUE do*/
LA: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18598;
    _nrecs_18598 = _38get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18599;
    _records_ptr_18599 = _38get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18598)) {
        _r_18603 = _r_18603 + _nrecs_18598;
    }
    else {
        _r_18603 = NewDouble((double)_r_18603 + DBL_PTR(_nrecs_18598)->dbl);
    }
    if (!IS_ATOM_INT(_r_18603)) {
        _1 = (long)(DBL_PTR(_r_18603)->dbl);
        DeRefDS(_r_18603);
        _r_18603 = _1;
    }

    /** 		if r >= key_location then*/
    if (_r_18603 < _key_location_18595)
    goto LA; // [427] 407

    /** 			exit*/
    goto LB; // [433] 441

    /** 	end while*/
    goto LA; // [438] 407
LB: 

    /** 	r -= nrecs*/
    if (IS_ATOM_INT(_nrecs_18598)) {
        _r_18603 = _r_18603 - _nrecs_18598;
    }
    else {
        _r_18603 = NewDouble((double)_r_18603 - DBL_PTR(_nrecs_18598)->dbl);
    }
    if (!IS_ATOM_INT(_r_18603)) {
        _1 = (long)(DBL_PTR(_r_18603)->dbl);
        DeRefDS(_r_18603);
        _r_18603 = _1;
    }

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_452_18678);
    _where_inlined_where_at_452_18678 = machine(20, _38current_db_16699);
    DeRef(_current_block_18602);
    if (IS_ATOM_INT(_where_inlined_where_at_452_18678)) {
        _current_block_18602 = _where_inlined_where_at_452_18678 - 8;
        if ((long)((unsigned long)_current_block_18602 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18602 = NewDouble((double)_current_block_18602);
        }
    }
    else {
        _current_block_18602 = NewDouble(DBL_PTR(_where_inlined_where_at_452_18678)->dbl - (double)8);
    }

    /** 	nrecs -= 1*/
    _0 = _nrecs_18598;
    if (IS_ATOM_INT(_nrecs_18598)) {
        _nrecs_18598 = _nrecs_18598 - 1;
        if ((long)((unsigned long)_nrecs_18598 +(unsigned long) HIGH_BITS) >= 0){
            _nrecs_18598 = NewDouble((double)_nrecs_18598);
        }
    }
    else {
        _nrecs_18598 = NewDouble(DBL_PTR(_nrecs_18598)->dbl - (double)1);
    }
    DeRef(_0);

    /** 	if nrecs = 0 and blocks > 1 then*/
    if (IS_ATOM_INT(_nrecs_18598)) {
        _10406 = (_nrecs_18598 == 0);
    }
    else {
        _10406 = (DBL_PTR(_nrecs_18598)->dbl == (double)0);
    }
    if (_10406 == 0) {
        goto LC; // [476] 617
    }
    _10408 = (_blocks_18604 > 1);
    if (_10408 == 0)
    {
        DeRef(_10408);
        _10408 = NOVALUE;
        goto LC; // [485] 617
    }
    else{
        DeRef(_10408);
        _10408 = NOVALUE;
    }

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18604 == (short)_blocks_18604)
    _10409 = _blocks_18604 * 8;
    else
    _10409 = NewDouble(_blocks_18604 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18601) && IS_ATOM_INT(_10409)) {
        _10410 = _index_ptr_18601 + _10409;
        if ((long)((unsigned long)_10410 + (unsigned long)HIGH_BITS) >= 0) 
        _10410 = NewDouble((double)_10410);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18601)) {
            _10410 = NewDouble((double)_index_ptr_18601 + DBL_PTR(_10409)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10409)) {
                _10410 = NewDouble(DBL_PTR(_index_ptr_18601)->dbl + (double)_10409);
            }
            else
            _10410 = NewDouble(DBL_PTR(_index_ptr_18601)->dbl + DBL_PTR(_10409)->dbl);
        }
    }
    DeRef(_10409);
    _10409 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18602)) {
        _10411 = _current_block_18602 + 8;
        if ((long)((unsigned long)_10411 + (unsigned long)HIGH_BITS) >= 0) 
        _10411 = NewDouble((double)_10411);
    }
    else {
        _10411 = NewDouble(DBL_PTR(_current_block_18602)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10410) && IS_ATOM_INT(_10411)) {
        _10412 = _10410 - _10411;
        if ((long)((unsigned long)_10412 +(unsigned long) HIGH_BITS) >= 0){
            _10412 = NewDouble((double)_10412);
        }
    }
    else {
        if (IS_ATOM_INT(_10410)) {
            _10412 = NewDouble((double)_10410 - DBL_PTR(_10411)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10411)) {
                _10412 = NewDouble(DBL_PTR(_10410)->dbl - (double)_10411);
            }
            else
            _10412 = NewDouble(DBL_PTR(_10410)->dbl - DBL_PTR(_10411)->dbl);
        }
    }
    DeRef(_10410);
    _10410 = NOVALUE;
    DeRef(_10411);
    _10411 = NOVALUE;
    _0 = _remaining_18606;
    _remaining_18606 = _18get_bytes(_38current_db_16699, _10412);
    DeRef(_0);
    _10412 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18602);
    DeRef(_seek_1__tmp_at518_18692);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _current_block_18602;
    _seek_1__tmp_at518_18692 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_518_18691 = machine(19, _seek_1__tmp_at518_18692);
    DeRef(_seek_1__tmp_at518_18692);
    _seek_1__tmp_at518_18692 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _remaining_18606); // DJP 

    /** end procedure*/
    goto LD; // [543] 546
LD: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_38current_table_pos_16700)) {
        _10414 = _38current_table_pos_16700 + 8;
        if ((long)((unsigned long)_10414 + (unsigned long)HIGH_BITS) >= 0) 
        _10414 = NewDouble((double)_10414);
    }
    else {
        _10414 = NewDouble(DBL_PTR(_38current_table_pos_16700)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_555_18696);
    _pos_inlined_seek_at_555_18696 = _10414;
    _10414 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_555_18696);
    DeRef(_seek_1__tmp_at558_18698);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_555_18696;
    _seek_1__tmp_at558_18698 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_558_18697 = machine(19, _seek_1__tmp_at558_18698);
    DeRef(_pos_inlined_seek_at_555_18696);
    _pos_inlined_seek_at_555_18696 = NOVALUE;
    DeRef(_seek_1__tmp_at558_18698);
    _seek_1__tmp_at558_18698 = NOVALUE;

    /** 		put4(blocks-1)*/
    _10415 = _blocks_18604 - 1;
    if ((long)((unsigned long)_10415 +(unsigned long) HIGH_BITS) >= 0){
        _10415 = NewDouble((double)_10415);
    }
    DeRef(_x_inlined_put4_at_577_18701);
    _x_inlined_put4_at_577_18701 = _10415;
    _10415 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_577_18701)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_577_18701;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_577_18701)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at580_18702);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at580_18702 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at580_18702); // DJP 

    /** end procedure*/
    goto LE; // [602] 605
LE: 
    DeRef(_x_inlined_put4_at_577_18701);
    _x_inlined_put4_at_577_18701 = NOVALUE;
    DeRefi(_put4_1__tmp_at580_18702);
    _put4_1__tmp_at580_18702 = NOVALUE;

    /** 		db_free(records_ptr)*/
    Ref(_records_ptr_18599);
    _38db_free(_records_ptr_18599);
    goto LF; // [614] 763
LC: 

    /** 		key_location -= r*/
    _key_location_18595 = _key_location_18595 - _r_18603;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18602);
    DeRef(_seek_1__tmp_at626_18707);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _current_block_18602;
    _seek_1__tmp_at626_18707 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_626_18706 = machine(19, _seek_1__tmp_at626_18707);
    DeRef(_seek_1__tmp_at626_18707);
    _seek_1__tmp_at626_18707 = NOVALUE;

    /** 		put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18598)) {
        *poke4_addr = (unsigned long)_nrecs_18598;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18598)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at641_18709);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at641_18709 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at641_18709); // DJP 

    /** end procedure*/
    goto L10; // [663] 666
L10: 
    DeRefi(_put4_1__tmp_at641_18709);
    _put4_1__tmp_at641_18709 = NOVALUE;

    /** 		io:seek(current_db, records_ptr+4*(key_location-1))*/
    _10417 = _key_location_18595 - 1;
    if ((long)((unsigned long)_10417 +(unsigned long) HIGH_BITS) >= 0){
        _10417 = NewDouble((double)_10417);
    }
    if (IS_ATOM_INT(_10417)) {
        if (_10417 <= INT15 && _10417 >= -INT15)
        _10418 = 4 * _10417;
        else
        _10418 = NewDouble(4 * (double)_10417);
    }
    else {
        _10418 = NewDouble((double)4 * DBL_PTR(_10417)->dbl);
    }
    DeRef(_10417);
    _10417 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18599) && IS_ATOM_INT(_10418)) {
        _10419 = _records_ptr_18599 + _10418;
        if ((long)((unsigned long)_10419 + (unsigned long)HIGH_BITS) >= 0) 
        _10419 = NewDouble((double)_10419);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18599)) {
            _10419 = NewDouble((double)_records_ptr_18599 + DBL_PTR(_10418)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10418)) {
                _10419 = NewDouble(DBL_PTR(_records_ptr_18599)->dbl + (double)_10418);
            }
            else
            _10419 = NewDouble(DBL_PTR(_records_ptr_18599)->dbl + DBL_PTR(_10418)->dbl);
        }
    }
    DeRef(_10418);
    _10418 = NOVALUE;
    DeRef(_pos_inlined_seek_at_685_18714);
    _pos_inlined_seek_at_685_18714 = _10419;
    _10419 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_685_18714);
    DeRef(_seek_1__tmp_at688_18716);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_685_18714;
    _seek_1__tmp_at688_18716 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_688_18715 = machine(19, _seek_1__tmp_at688_18716);
    DeRef(_pos_inlined_seek_at_685_18714);
    _pos_inlined_seek_at_685_18714 = NOVALUE;
    DeRef(_seek_1__tmp_at688_18716);
    _seek_1__tmp_at688_18716 = NOVALUE;

    /** 		for i = key_location to nrecs do*/
    Ref(_nrecs_18598);
    DeRef(_10420);
    _10420 = _nrecs_18598;
    {
        int _i_18718;
        _i_18718 = _key_location_18595;
L11: 
        if (binary_op_a(GREATER, _i_18718, _10420)){
            goto L12; // [707] 762
        }

        /** 			put4(key_pointers[i+r])*/
        if (IS_ATOM_INT(_i_18718)) {
            _10421 = _i_18718 + _r_18603;
        }
        else {
            _10421 = NewDouble(DBL_PTR(_i_18718)->dbl + (double)_r_18603);
        }
        _2 = (int)SEQ_PTR(_38key_pointers_16706);
        if (!IS_ATOM_INT(_10421)){
            _10422 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10421)->dbl));
        }
        else{
            _10422 = (int)*(((s1_ptr)_2)->base + _10421);
        }
        Ref(_10422);
        DeRef(_x_inlined_put4_at_725_18723);
        _x_inlined_put4_at_725_18723 = _10422;
        _10422 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_38mem0_16741)){
            poke4_addr = (unsigned long *)_38mem0_16741;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_725_18723)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_725_18723;
        }
        else if (IS_ATOM(_x_inlined_put4_at_725_18723)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_725_18723)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_725_18723);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at728_18724);
        _1 = (int)SEQ_PTR(_38memseq_16961);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at728_18724 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_38current_db_16699, _put4_1__tmp_at728_18724); // DJP 

        /** end procedure*/
        goto L13; // [750] 753
L13: 
        DeRef(_x_inlined_put4_at_725_18723);
        _x_inlined_put4_at_725_18723 = NOVALUE;
        DeRefi(_put4_1__tmp_at728_18724);
        _put4_1__tmp_at728_18724 = NOVALUE;

        /** 		end for*/
        _0 = _i_18718;
        if (IS_ATOM_INT(_i_18718)) {
            _i_18718 = _i_18718 + 1;
            if ((long)((unsigned long)_i_18718 +(unsigned long) HIGH_BITS) >= 0){
                _i_18718 = NewDouble((double)_i_18718);
            }
        }
        else {
            _i_18718 = binary_op_a(PLUS, _i_18718, 1);
        }
        DeRef(_0);
        goto L11; // [757] 714
L12: 
        ;
        DeRef(_i_18718);
    }
LF: 

    /** end procedure*/
    DeRef(_table_name_18596);
    DeRef(_key_ptr_18597);
    DeRef(_nrecs_18598);
    DeRef(_records_ptr_18599);
    DeRef(_data_ptr_18600);
    DeRef(_index_ptr_18601);
    DeRef(_current_block_18602);
    DeRef(_remaining_18606);
    DeRef(_10371);
    _10371 = NOVALUE;
    DeRef(_10382);
    _10382 = NOVALUE;
    DeRef(_10387);
    _10387 = NOVALUE;
    DeRef(_10385);
    _10385 = NOVALUE;
    DeRef(_10389);
    _10389 = NOVALUE;
    DeRef(_10406);
    _10406 = NOVALUE;
    DeRef(_10421);
    _10421 = NOVALUE;
    return;
    ;
}


void  __stdcall _38db_replace_data(int _key_location_18727, int _data_18728, int _table_name_18729)
{
    int _10436 = NOVALUE;
    int _10435 = NOVALUE;
    int _10434 = NOVALUE;
    int _10433 = NOVALUE;
    int _10431 = NOVALUE;
    int _10430 = NOVALUE;
    int _10428 = NOVALUE;
    int _10425 = NOVALUE;
    int _10423 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18727)) {
        _1 = (long)(DBL_PTR(_key_location_18727)->dbl);
        DeRefDS(_key_location_18727);
        _key_location_18727 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18729 == _38current_table_name_16701)
    _10423 = 1;
    else if (IS_ATOM_INT(_table_name_18729) && IS_ATOM_INT(_38current_table_name_16701))
    _10423 = 0;
    else
    _10423 = (compare(_table_name_18729, _38current_table_name_16701) == 0);
    if (_10423 != 0)
    goto L1; // [11] 45
    _10423 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18729);
    _10425 = _38db_select_table(_table_name_18729);
    if (binary_op_a(EQUALS, _10425, 0)){
        DeRef(_10425);
        _10425 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10425);
    _10425 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18727;
    Ref(_data_18728);
    *((int *)(_2+8)) = _data_18728;
    Ref(_table_name_18729);
    *((int *)(_2+12)) = _table_name_18729;
    _10428 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10427);
    _38fatal(903, _10249, _10427, _10428);
    _10428 = NOVALUE;

    /** 			return*/
    DeRef(_data_18728);
    DeRef(_table_name_18729);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18727;
    Ref(_data_18728);
    *((int *)(_2+8)) = _data_18728;
    Ref(_table_name_18729);
    *((int *)(_2+12)) = _table_name_18729;
    _10430 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10427);
    _38fatal(903, _10253, _10427, _10430);
    _10430 = NOVALUE;

    /** 		return*/
    DeRef(_data_18728);
    DeRef(_table_name_18729);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10431 = (_key_location_18727 < 1);
    if (_10431 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _10433 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _10433 = 1;
    }
    _10434 = (_key_location_18727 > _10433);
    _10433 = NOVALUE;
    if (_10434 == 0)
    {
        DeRef(_10434);
        _10434 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10434);
        _10434 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_18727;
    Ref(_data_18728);
    *((int *)(_2+8)) = _data_18728;
    Ref(_table_name_18729);
    *((int *)(_2+12)) = _table_name_18729;
    _10435 = MAKE_SEQ(_1);
    RefDS(_10375);
    RefDS(_10427);
    _38fatal(905, _10375, _10427, _10435);
    _10435 = NOVALUE;

    /** 		return*/
    DeRef(_data_18728);
    DeRef(_table_name_18729);
    DeRef(_10431);
    _10431 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10436 = (int)*(((s1_ptr)_2)->base + _key_location_18727);
    Ref(_10436);
    Ref(_data_18728);
    _38db_replace_recid(_10436, _data_18728);
    _10436 = NOVALUE;

    /** end procedure*/
    DeRef(_data_18728);
    DeRef(_table_name_18729);
    DeRef(_10431);
    _10431 = NOVALUE;
    return;
    ;
}


int  __stdcall _38db_table_size(int _table_name_18751)
{
    int _10445 = NOVALUE;
    int _10444 = NOVALUE;
    int _10442 = NOVALUE;
    int _10439 = NOVALUE;
    int _10437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18751 == _38current_table_name_16701)
    _10437 = 1;
    else if (IS_ATOM_INT(_table_name_18751) && IS_ATOM_INT(_38current_table_name_16701))
    _10437 = 0;
    else
    _10437 = (compare(_table_name_18751, _38current_table_name_16701) == 0);
    if (_10437 != 0)
    goto L1; // [9] 42
    _10437 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18751);
    _10439 = _38db_select_table(_table_name_18751);
    if (binary_op_a(EQUALS, _10439, 0)){
        DeRef(_10439);
        _10439 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10439);
    _10439 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_18751);
    *((int *)(_2+4)) = _table_name_18751;
    _10442 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10441);
    _38fatal(903, _10249, _10441, _10442);
    _10442 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18751);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_18751);
    *((int *)(_2+4)) = _table_name_18751;
    _10444 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10441);
    _38fatal(903, _10253, _10441, _10444);
    _10444 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18751);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _10445 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _10445 = 1;
    }
    DeRef(_table_name_18751);
    return _10445;
    ;
}


int  __stdcall _38db_record_data(int _key_location_18766, int _table_name_18767)
{
    int _data_ptr_18768 = NOVALUE;
    int _data_value_18769 = NOVALUE;
    int _seek_1__tmp_at126_18791 = NOVALUE;
    int _seek_inlined_seek_at_126_18790 = NOVALUE;
    int _pos_inlined_seek_at_123_18789 = NOVALUE;
    int _seek_1__tmp_at164_18798 = NOVALUE;
    int _seek_inlined_seek_at_164_18797 = NOVALUE;
    int _10460 = NOVALUE;
    int _10459 = NOVALUE;
    int _10458 = NOVALUE;
    int _10457 = NOVALUE;
    int _10456 = NOVALUE;
    int _10454 = NOVALUE;
    int _10453 = NOVALUE;
    int _10451 = NOVALUE;
    int _10448 = NOVALUE;
    int _10446 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18766)) {
        _1 = (long)(DBL_PTR(_key_location_18766)->dbl);
        DeRefDS(_key_location_18766);
        _key_location_18766 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18767 == _38current_table_name_16701)
    _10446 = 1;
    else if (IS_ATOM_INT(_table_name_18767) && IS_ATOM_INT(_38current_table_name_16701))
    _10446 = 0;
    else
    _10446 = (compare(_table_name_18767, _38current_table_name_16701) == 0);
    if (_10446 != 0)
    goto L1; // [11] 44
    _10446 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18767);
    _10448 = _38db_select_table(_table_name_18767);
    if (binary_op_a(EQUALS, _10448, 0)){
        DeRef(_10448);
        _10448 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10448);
    _10448 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18767);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18766;
    ((int *)_2)[2] = _table_name_18767;
    _10451 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10450);
    _38fatal(903, _10249, _10450, _10451);
    _10451 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18767);
    DeRef(_data_ptr_18768);
    DeRef(_data_value_18769);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18767);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18766;
    ((int *)_2)[2] = _table_name_18767;
    _10453 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10450);
    _38fatal(903, _10253, _10450, _10453);
    _10453 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18767);
    DeRef(_data_ptr_18768);
    DeRef(_data_value_18769);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10454 = (_key_location_18766 < 1);
    if (_10454 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _10456 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _10456 = 1;
    }
    _10457 = (_key_location_18766 > _10456);
    _10456 = NOVALUE;
    if (_10457 == 0)
    {
        DeRef(_10457);
        _10457 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10457);
        _10457 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18767);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18766;
    ((int *)_2)[2] = _table_name_18767;
    _10458 = MAKE_SEQ(_1);
    RefDS(_10375);
    RefDS(_10450);
    _38fatal(905, _10375, _10450, _10458);
    _10458 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18767);
    DeRef(_data_ptr_18768);
    DeRef(_data_value_18769);
    DeRef(_10454);
    _10454 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10459 = (int)*(((s1_ptr)_2)->base + _key_location_18766);
    Ref(_10459);
    DeRef(_pos_inlined_seek_at_123_18789);
    _pos_inlined_seek_at_123_18789 = _10459;
    _10459 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_18789);
    DeRef(_seek_1__tmp_at126_18791);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_18789;
    _seek_1__tmp_at126_18791 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_18790 = machine(19, _seek_1__tmp_at126_18791);
    DeRef(_pos_inlined_seek_at_123_18789);
    _pos_inlined_seek_at_123_18789 = NOVALUE;
    DeRef(_seek_1__tmp_at126_18791);
    _seek_1__tmp_at126_18791 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_38vLastErrors_16723)){
            _10460 = SEQ_PTR(_38vLastErrors_16723)->length;
    }
    else {
        _10460 = 1;
    }
    if (_10460 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_18767);
    DeRef(_data_ptr_18768);
    DeRef(_data_value_18769);
    DeRef(_10454);
    _10454 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18768;
    _data_ptr_18768 = _38get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18768);
    DeRef(_seek_1__tmp_at164_18798);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38current_db_16699;
    ((int *)_2)[2] = _data_ptr_18768;
    _seek_1__tmp_at164_18798 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_18797 = machine(19, _seek_1__tmp_at164_18798);
    DeRef(_seek_1__tmp_at164_18798);
    _seek_1__tmp_at164_18798 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_18769;
    _data_value_18769 = _38decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_18767);
    DeRef(_data_ptr_18768);
    DeRef(_10454);
    _10454 = NOVALUE;
    return _data_value_18769;
    ;
}


int  __stdcall _38db_fetch_record(int _key_18802, int _table_name_18803)
{
    int _pos_18804 = NOVALUE;
    int _10466 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_18802);
    Ref(_table_name_18803);
    _pos_18804 = _38db_find_key(_key_18802, _table_name_18803);
    if (!IS_ATOM_INT(_pos_18804)) {
        _1 = (long)(DBL_PTR(_pos_18804)->dbl);
        DeRefDS(_pos_18804);
        _pos_18804 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_18804 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    Ref(_table_name_18803);
    _10466 = _38db_record_data(_pos_18804, _table_name_18803);
    DeRef(_key_18802);
    DeRef(_table_name_18803);
    return _10466;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_18802);
    DeRef(_table_name_18803);
    DeRef(_10466);
    _10466 = NOVALUE;
    return _pos_18804;
L2: 
    ;
}


int  __stdcall _38db_record_key(int _key_location_18812, int _table_name_18813)
{
    int _10481 = NOVALUE;
    int _10480 = NOVALUE;
    int _10479 = NOVALUE;
    int _10478 = NOVALUE;
    int _10477 = NOVALUE;
    int _10475 = NOVALUE;
    int _10474 = NOVALUE;
    int _10472 = NOVALUE;
    int _10469 = NOVALUE;
    int _10467 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18812)) {
        _1 = (long)(DBL_PTR(_key_location_18812)->dbl);
        DeRefDS(_key_location_18812);
        _key_location_18812 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18813 == _38current_table_name_16701)
    _10467 = 1;
    else if (IS_ATOM_INT(_table_name_18813) && IS_ATOM_INT(_38current_table_name_16701))
    _10467 = 0;
    else
    _10467 = (compare(_table_name_18813, _38current_table_name_16701) == 0);
    if (_10467 != 0)
    goto L1; // [11] 44
    _10467 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18813);
    _10469 = _38db_select_table(_table_name_18813);
    if (binary_op_a(EQUALS, _10469, 0)){
        DeRef(_10469);
        _10469 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10469);
    _10469 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18813);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18812;
    ((int *)_2)[2] = _table_name_18813;
    _10472 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10471);
    _38fatal(903, _10249, _10471, _10472);
    _10472 = NOVALUE;

    /** 			return -1*/
    DeRef(_table_name_18813);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18813);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18812;
    ((int *)_2)[2] = _table_name_18813;
    _10474 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10471);
    _38fatal(903, _10253, _10471, _10474);
    _10474 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18813);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10475 = (_key_location_18812 < 1);
    if (_10475 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _10477 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _10477 = 1;
    }
    _10478 = (_key_location_18812 > _10477);
    _10477 = NOVALUE;
    if (_10478 == 0)
    {
        DeRef(_10478);
        _10478 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10478);
        _10478 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18813);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_18812;
    ((int *)_2)[2] = _table_name_18813;
    _10479 = MAKE_SEQ(_1);
    RefDS(_10375);
    RefDS(_10471);
    _38fatal(905, _10375, _10471, _10479);
    _10479 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_18813);
    DeRef(_10475);
    _10475 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10480 = (int)*(((s1_ptr)_2)->base + _key_location_18812);
    Ref(_10480);
    _10481 = _38key_value(_10480);
    _10480 = NOVALUE;
    DeRef(_table_name_18813);
    DeRef(_10475);
    _10475 = NOVALUE;
    return _10481;
    ;
}


int  __stdcall _38db_compress()
{
    int _index_18835 = NOVALUE;
    int _chunk_size_18836 = NOVALUE;
    int _nrecs_18837 = NOVALUE;
    int _r_18838 = NOVALUE;
    int _fn_18839 = NOVALUE;
    int _new_path_18840 = NOVALUE;
    int _table_list_18841 = NOVALUE;
    int _record_18842 = NOVALUE;
    int _chunk_18843 = NOVALUE;
    int _temp_path_18851 = NOVALUE;
    int _10527 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10521 = NOVALUE;
    int _10520 = NOVALUE;
    int _10519 = NOVALUE;
    int _10518 = NOVALUE;
    int _10516 = NOVALUE;
    int _10511 = NOVALUE;
    int _10510 = NOVALUE;
    int _10509 = NOVALUE;
    int _10506 = NOVALUE;
    int _10502 = NOVALUE;
    int _10499 = NOVALUE;
    int _10497 = NOVALUE;
    int _10494 = NOVALUE;
    int _10491 = NOVALUE;
    int _10486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_38current_db_16699 != -1)
    goto L1; // [5] 24

    /** 		fatal(NO_DATABASE, "no current database", "db_compress", {})*/
    RefDS(_10483);
    RefDS(_10484);
    RefDS(_5);
    _38fatal(901, _10483, _10484, _5);

    /** 		return -1*/
    DeRef(_new_path_18840);
    DeRef(_table_list_18841);
    DeRef(_record_18842);
    DeRef(_chunk_18843);
    DeRef(_temp_path_18851);
    return -1;
L1: 

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18835 = find_from(_38current_db_16699, _38db_file_nums_16703, 1);

    /** 	new_path = text:trim(db_names[index])*/
    _2 = (int)SEQ_PTR(_38db_names_16702);
    _10486 = (int)*(((s1_ptr)_2)->base + _index_18835);
    Ref(_10486);
    RefDS(_4563);
    _0 = _new_path_18840;
    _new_path_18840 = _6trim(_10486, _4563, 0);
    DeRef(_0);
    _10486 = NOVALUE;

    /** 	db_close()*/
    _38db_close();

    /** 	fn = -1*/
    _fn_18839 = -1;

    /** 	sequence temp_path = filesys:temp_file()*/
    RefDS(_5);
    RefDS(_5);
    RefDS(_4644);
    _0 = _temp_path_18851;
    _temp_path_18851 = _11temp_file(_5, _5, _4644, 0);
    DeRef(_0);

    /** 	fn = open( temp_path, "r" )*/
    _fn_18839 = EOpen(_temp_path_18851, _1256, 0);

    /** 	if fn != -1 then*/
    if (_fn_18839 == -1)
    goto L2; // [80] 91

    /** 		return DB_EXISTS_ALREADY -- you better delete some temp files*/
    DeRefDS(_new_path_18840);
    DeRef(_table_list_18841);
    DeRef(_record_18842);
    DeRef(_chunk_18843);
    DeRefDS(_temp_path_18851);
    return -2;
L2: 

    /** 	filesys:move_file( new_path, temp_path )*/
    RefDS(_new_path_18840);
    RefDS(_temp_path_18851);
    _10491 = _11move_file(_new_path_18840, _temp_path_18851, 0);

    /** 	index = db_create(new_path, DB_LOCK_NO)*/
    RefDS(_new_path_18840);
    _index_18835 = _38db_create(_new_path_18840, 0, 5, 5);
    if (!IS_ATOM_INT(_index_18835)) {
        _1 = (long)(DBL_PTR(_index_18835)->dbl);
        DeRefDS(_index_18835);
        _index_18835 = _1;
    }

    /** 	if index != DB_OK then*/
    if (_index_18835 == 0)
    goto L3; // [112] 131

    /** 		filesys:move_file( temp_path, new_path )*/
    RefDS(_temp_path_18851);
    RefDS(_new_path_18840);
    _10494 = _11move_file(_temp_path_18851, _new_path_18840, 0);

    /** 		return index*/
    DeRefDS(_new_path_18840);
    DeRef(_table_list_18841);
    DeRef(_record_18842);
    DeRef(_chunk_18843);
    DeRefDS(_temp_path_18851);
    DeRef(_10491);
    _10491 = NOVALUE;
    DeRef(_10494);
    _10494 = NOVALUE;
    return _index_18835;
L3: 

    /** 	index = db_open(temp_path, DB_LOCK_NO)*/
    RefDS(_temp_path_18851);
    _index_18835 = _38db_open(_temp_path_18851, 0);
    if (!IS_ATOM_INT(_index_18835)) {
        _1 = (long)(DBL_PTR(_index_18835)->dbl);
        DeRefDS(_index_18835);
        _index_18835 = _1;
    }

    /** 	table_list = db_table_list()*/
    _0 = _table_list_18841;
    _table_list_18841 = _38db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length(table_list) do*/
    if (IS_SEQUENCE(_table_list_18841)){
            _10497 = SEQ_PTR(_table_list_18841)->length;
    }
    else {
        _10497 = 1;
    }
    {
        int _i_18864;
        _i_18864 = 1;
L4: 
        if (_i_18864 > _10497){
            goto L5; // [152] 424
        }

        /** 		index = db_select(new_path)*/
        RefDS(_new_path_18840);
        _index_18835 = _38db_select(_new_path_18840, -1);
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 		index = db_create_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18841);
        _10499 = (int)*(((s1_ptr)_2)->base + _i_18864);
        Ref(_10499);
        _index_18835 = _38db_create_table(_10499, 50);
        _10499 = NOVALUE;
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 		index = db_select(temp_path)*/
        RefDS(_temp_path_18851);
        _index_18835 = _38db_select(_temp_path_18851, -1);
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 		index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18841);
        _10502 = (int)*(((s1_ptr)_2)->base + _i_18864);
        Ref(_10502);
        _index_18835 = _38db_select_table(_10502);
        _10502 = NOVALUE;
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 		nrecs = db_table_size()*/
        RefDS(_38current_table_name_16701);
        _nrecs_18837 = _38db_table_size(_38current_table_name_16701);
        if (!IS_ATOM_INT(_nrecs_18837)) {
            _1 = (long)(DBL_PTR(_nrecs_18837)->dbl);
            DeRefDS(_nrecs_18837);
            _nrecs_18837 = _1;
        }

        /** 		r = 1*/
        _r_18838 = 1;

        /** 		while r <= nrecs do*/
L6: 
        if (_r_18838 > _nrecs_18837)
        goto L7; // [222] 417

        /** 			chunk_size = nrecs - r + 1*/
        _10506 = _nrecs_18837 - _r_18838;
        if ((long)((unsigned long)_10506 +(unsigned long) HIGH_BITS) >= 0){
            _10506 = NewDouble((double)_10506);
        }
        if (IS_ATOM_INT(_10506)) {
            _chunk_size_18836 = _10506 + 1;
        }
        else
        { // coercing _chunk_size_18836 to an integer 1
            _chunk_size_18836 = 1+(long)(DBL_PTR(_10506)->dbl);
            if( !IS_ATOM_INT(_chunk_size_18836) ){
                _chunk_size_18836 = (object)DBL_PTR(_chunk_size_18836)->dbl;
            }
        }
        DeRef(_10506);
        _10506 = NOVALUE;

        /** 			if chunk_size > 20 then*/
        if (_chunk_size_18836 <= 20)
        goto L8; // [238] 248

        /** 				chunk_size = 20  -- copy up to 20 records at a time*/
        _chunk_size_18836 = 20;
L8: 

        /** 			chunk = {}*/
        RefDS(_5);
        DeRef(_chunk_18843);
        _chunk_18843 = _5;

        /** 			for j = 1 to chunk_size do*/
        _10509 = _chunk_size_18836;
        {
            int _j_18880;
            _j_18880 = 1;
L9: 
            if (_j_18880 > _10509){
                goto LA; // [260] 306
            }

            /** 				record = {db_record_key(r), db_record_data(r)}*/
            RefDS(_38current_table_name_16701);
            _10510 = _38db_record_key(_r_18838, _38current_table_name_16701);
            RefDS(_38current_table_name_16701);
            _10511 = _38db_record_data(_r_18838, _38current_table_name_16701);
            DeRef(_record_18842);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _10510;
            ((int *)_2)[2] = _10511;
            _record_18842 = MAKE_SEQ(_1);
            _10511 = NOVALUE;
            _10510 = NOVALUE;

            /** 				r += 1*/
            _r_18838 = _r_18838 + 1;

            /** 				chunk = append(chunk, record)*/
            RefDS(_record_18842);
            Append(&_chunk_18843, _chunk_18843, _record_18842);

            /** 			end for*/
            _j_18880 = _j_18880 + 1;
            goto L9; // [301] 267
LA: 
            ;
        }

        /** 			index = db_select(new_path)*/
        RefDS(_new_path_18840);
        _index_18835 = _38db_select(_new_path_18840, -1);
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 			index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18841);
        _10516 = (int)*(((s1_ptr)_2)->base + _i_18864);
        Ref(_10516);
        _index_18835 = _38db_select_table(_10516);
        _10516 = NOVALUE;
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 			for j = 1 to chunk_size do*/
        _10518 = _chunk_size_18836;
        {
            int _j_18891;
            _j_18891 = 1;
LB: 
            if (_j_18891 > _10518){
                goto LC; // [332] 391
            }

            /** 				if db_insert(chunk[j][1], chunk[j][2]) != DB_OK then*/
            _2 = (int)SEQ_PTR(_chunk_18843);
            _10519 = (int)*(((s1_ptr)_2)->base + _j_18891);
            _2 = (int)SEQ_PTR(_10519);
            _10520 = (int)*(((s1_ptr)_2)->base + 1);
            _10519 = NOVALUE;
            _2 = (int)SEQ_PTR(_chunk_18843);
            _10521 = (int)*(((s1_ptr)_2)->base + _j_18891);
            _2 = (int)SEQ_PTR(_10521);
            _10522 = (int)*(((s1_ptr)_2)->base + 2);
            _10521 = NOVALUE;
            Ref(_10520);
            Ref(_10522);
            RefDS(_38current_table_name_16701);
            _10523 = _38db_insert(_10520, _10522, _38current_table_name_16701);
            _10520 = NOVALUE;
            _10522 = NOVALUE;
            if (binary_op_a(EQUALS, _10523, 0)){
                DeRef(_10523);
                _10523 = NOVALUE;
                goto LD; // [365] 384
            }
            DeRef(_10523);
            _10523 = NOVALUE;

            /** 					fatal(INSERT_FAILED, "couldn't insert into new database", "db_compress", {})*/
            RefDS(_10525);
            RefDS(_10484);
            RefDS(_5);
            _38fatal(906, _10525, _10484, _5);

            /** 					return DB_FATAL_FAIL*/
            DeRef(_new_path_18840);
            DeRef(_table_list_18841);
            DeRef(_record_18842);
            DeRefDS(_chunk_18843);
            DeRef(_temp_path_18851);
            DeRef(_10491);
            _10491 = NOVALUE;
            DeRef(_10494);
            _10494 = NOVALUE;
            return -404;
LD: 

            /** 			end for*/
            _j_18891 = _j_18891 + 1;
            goto LB; // [386] 339
LC: 
            ;
        }

        /** 			index = db_select(temp_path)*/
        RefDS(_temp_path_18851);
        _index_18835 = _38db_select(_temp_path_18851, -1);
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 			index = db_select_table(table_list[i])*/
        _2 = (int)SEQ_PTR(_table_list_18841);
        _10527 = (int)*(((s1_ptr)_2)->base + _i_18864);
        Ref(_10527);
        _index_18835 = _38db_select_table(_10527);
        _10527 = NOVALUE;
        if (!IS_ATOM_INT(_index_18835)) {
            _1 = (long)(DBL_PTR(_index_18835)->dbl);
            DeRefDS(_index_18835);
            _index_18835 = _1;
        }

        /** 		end while*/
        goto L6; // [414] 222
L7: 

        /** 	end for*/
        _i_18864 = _i_18864 + 1;
        goto L4; // [419] 159
L5: 
        ;
    }

    /** 	db_close()*/
    _38db_close();

    /** 	index = db_select(new_path)*/
    RefDS(_new_path_18840);
    _index_18835 = _38db_select(_new_path_18840, -1);
    if (!IS_ATOM_INT(_index_18835)) {
        _1 = (long)(DBL_PTR(_index_18835)->dbl);
        DeRefDS(_index_18835);
        _index_18835 = _1;
    }

    /** 	return DB_OK*/
    DeRefDS(_new_path_18840);
    DeRef(_table_list_18841);
    DeRef(_record_18842);
    DeRef(_chunk_18843);
    DeRef(_temp_path_18851);
    DeRef(_10491);
    _10491 = NOVALUE;
    DeRef(_10494);
    _10494 = NOVALUE;
    return 0;
    ;
}


int  __stdcall _38db_current()
{
    int _index_18907 = NOVALUE;
    int _10532 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find (current_db, db_file_nums)*/
    _index_18907 = find_from(_38current_db_16699, _38db_file_nums_16703, 1);

    /** 	if index != 0 then*/
    if (_index_18907 == 0)
    goto L1; // [14] 33

    /** 		return db_names [index]*/
    _2 = (int)SEQ_PTR(_38db_names_16702);
    _10532 = (int)*(((s1_ptr)_2)->base + _index_18907);
    Ref(_10532);
    return _10532;
    goto L2; // [30] 40
L1: 

    /** 		return ""*/
    RefDS(_5);
    _10532 = NOVALUE;
    return _5;
L2: 
    ;
}


void  __stdcall _38db_cache_clear()
{
    int _0, _1, _2;
    

    /** 	cache_index = {}*/
    RefDS(_5);
    DeRef(_38cache_index_16708);
    _38cache_index_16708 = _5;

    /** 	key_cache = {}*/
    RefDS(_5);
    DeRef(_38key_cache_16707);
    _38key_cache_16707 = _5;

    /** end procedure*/
    return;
    ;
}


int  __stdcall _38db_set_caching(int _new_setting_18917)
{
    int _lOldVal_18918 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lOldVal = caching_option*/
    _lOldVal_18918 = _38caching_option_16709;

    /** 	caching_option = (new_setting != 0)*/
    if (IS_ATOM_INT(_new_setting_18917)) {
        _38caching_option_16709 = (_new_setting_18917 != 0);
    }
    else {
        _38caching_option_16709 = (DBL_PTR(_new_setting_18917)->dbl != (double)0);
    }

    /** 	if caching_option = 0 then*/
    if (_38caching_option_16709 != 0)
    goto L1; // [20] 46

    /** 		db_cache_clear()*/

    /** 	cache_index = {}*/
    RefDS(_5);
    DeRef(_38cache_index_16708);
    _38cache_index_16708 = _5;

    /** 	key_cache = {}*/
    RefDS(_5);
    DeRef(_38key_cache_16707);
    _38key_cache_16707 = _5;

    /** end procedure*/
    goto L2; // [42] 45
L2: 
L1: 

    /** 	return lOldVal*/
    DeRef(_new_setting_18917);
    return _lOldVal_18918;
    ;
}


void  __stdcall _38db_replace_recid(int _recid_18925, int _data_18926)
{
    int _old_size_18927 = NOVALUE;
    int _new_size_18928 = NOVALUE;
    int _data_ptr_18929 = NOVALUE;
    int _data_string_18930 = NOVALUE;
    int _put4_1__tmp_at111_18950 = NOVALUE;
    int _10579 = NOVALUE;
    int _10578 = NOVALUE;
    int _10577 = NOVALUE;
    int _10576 = NOVALUE;
    int _10575 = NOVALUE;
    int _10547 = NOVALUE;
    int _10545 = NOVALUE;
    int _10544 = NOVALUE;
    int _10543 = NOVALUE;
    int _10542 = NOVALUE;
    int _10541 = NOVALUE;
    int _10537 = NOVALUE;
    int _10536 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18925)) {
        _1 = (long)(DBL_PTR(_recid_18925)->dbl);
        DeRefDS(_recid_18925);
        _recid_18925 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10579 = _18seek(_38current_db_16699, _recid_18925);
    DeRef(_10579);
    _10579 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18929;
    _data_ptr_18929 = _38get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_18929)) {
        _10536 = _data_ptr_18929 - 4;
        if ((long)((unsigned long)_10536 +(unsigned long) HIGH_BITS) >= 0){
            _10536 = NewDouble((double)_10536);
        }
    }
    else {
        _10536 = NewDouble(DBL_PTR(_data_ptr_18929)->dbl - (double)4);
    }
    _10578 = _18seek(_38current_db_16699, _10536);
    _10536 = NOVALUE;
    DeRef(_10578);
    _10578 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10537 = _38get4();
    DeRef(_old_size_18927);
    if (IS_ATOM_INT(_10537)) {
        _old_size_18927 = _10537 - 4;
        if ((long)((unsigned long)_old_size_18927 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_18927 = NewDouble((double)_old_size_18927);
        }
    }
    else {
        _old_size_18927 = binary_op(MINUS, _10537, 4);
    }
    DeRef(_10537);
    _10537 = NOVALUE;

    /** 	data_string = compress(data)*/
    Ref(_data_18926);
    _0 = _data_string_18930;
    _data_string_18930 = _38compress(_data_18926);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_18930)){
            _new_size_18928 = SEQ_PTR(_data_string_18930)->length;
    }
    else {
        _new_size_18928 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_18927)) {
        _10541 = (_new_size_18928 <= _old_size_18927);
    }
    else {
        _10541 = ((double)_new_size_18928 <= DBL_PTR(_old_size_18927)->dbl);
    }
    if (_10541 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_18927)) {
        _10543 = _old_size_18927 - 16;
        if ((long)((unsigned long)_10543 +(unsigned long) HIGH_BITS) >= 0){
            _10543 = NewDouble((double)_10543);
        }
    }
    else {
        _10543 = NewDouble(DBL_PTR(_old_size_18927)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10543)) {
        _10544 = (_new_size_18928 >= _10543);
    }
    else {
        _10544 = ((double)_new_size_18928 >= DBL_PTR(_10543)->dbl);
    }
    DeRef(_10543);
    _10543 = NOVALUE;
    if (_10544 == 0)
    {
        DeRef(_10544);
        _10544 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10544);
        _10544 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_18929);
    _10577 = _18seek(_38current_db_16699, _data_ptr_18929);
    DeRef(_10577);
    _10577 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_18929);
    _38db_free(_data_ptr_18929);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10545 = _new_size_18928 + 8;
    if ((long)((unsigned long)_10545 + (unsigned long)HIGH_BITS) >= 0) 
    _10545 = NewDouble((double)_10545);
    _0 = _data_ptr_18929;
    _data_ptr_18929 = _38db_allocate(_10545);
    DeRef(_0);
    _10545 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10576 = _18seek(_38current_db_16699, _recid_18925);
    DeRef(_10576);
    _10576 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_38mem0_16741)){
        poke4_addr = (unsigned long *)_38mem0_16741;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_38mem0_16741)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18929)) {
        *poke4_addr = (unsigned long)_data_ptr_18929;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18929)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_18950);
    _1 = (int)SEQ_PTR(_38memseq_16961);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_18950 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_38current_db_16699, _put4_1__tmp_at111_18950); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_18950);
    _put4_1__tmp_at111_18950 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_18929);
    _10575 = _18seek(_38current_db_16699, _data_ptr_18929);
    DeRef(_10575);
    _10575 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10547 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_18930, _data_string_18930, _10547);
    DeRefDS(_10547);
    _10547 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_38current_db_16699, _data_string_18930); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_data_18926);
    DeRef(_old_size_18927);
    DeRef(_data_ptr_18929);
    DeRef(_data_string_18930);
    DeRef(_10541);
    _10541 = NOVALUE;
    return;
    ;
}


int  __stdcall _38db_record_recid(int _recid_18957)
{
    int _data_ptr_18958 = NOVALUE;
    int _data_value_18959 = NOVALUE;
    int _key_value_18960 = NOVALUE;
    int _10574 = NOVALUE;
    int _10573 = NOVALUE;
    int _10552 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18957)) {
        _1 = (long)(DBL_PTR(_recid_18957)->dbl);
        DeRefDS(_recid_18957);
        _recid_18957 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10574 = _18seek(_38current_db_16699, _recid_18957);
    DeRef(_10574);
    _10574 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_18958;
    _data_ptr_18958 = _38get4();
    DeRef(_0);

    /** 	key_value = decompress(0)*/
    _0 = _key_value_18960;
    _key_value_18960 = _38decompress(0);
    DeRef(_0);

    /** 	seek(current_db, data_ptr)*/
    Ref(_data_ptr_18958);
    _10573 = _18seek(_38current_db_16699, _data_ptr_18958);
    DeRef(_10573);
    _10573 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_18959;
    _data_value_18959 = _38decompress(0);
    DeRef(_0);

    /** 	return {key_value, data_value}*/
    Ref(_data_value_18959);
    Ref(_key_value_18960);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_value_18960;
    ((int *)_2)[2] = _data_value_18959;
    _10552 = MAKE_SEQ(_1);
    DeRef(_data_ptr_18958);
    DeRef(_data_value_18959);
    DeRef(_key_value_18960);
    return _10552;
    ;
}


int  __stdcall _38db_get_recid(int _key_18969, int _table_name_18970)
{
    int _lo_18971 = NOVALUE;
    int _hi_18972 = NOVALUE;
    int _mid_18973 = NOVALUE;
    int _c_18974 = NOVALUE;
    int _10572 = NOVALUE;
    int _10566 = NOVALUE;
    int _10565 = NOVALUE;
    int _10563 = NOVALUE;
    int _10560 = NOVALUE;
    int _10558 = NOVALUE;
    int _10555 = NOVALUE;
    int _10553 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18970 == _38current_table_name_16701)
    _10553 = 1;
    else if (IS_ATOM_INT(_table_name_18970) && IS_ATOM_INT(_38current_table_name_16701))
    _10553 = 0;
    else
    _10553 = (compare(_table_name_18970, _38current_table_name_16701) == 0);
    if (_10553 != 0)
    goto L1; // [9] 42
    _10553 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    Ref(_table_name_18970);
    _10555 = _38db_select_table(_table_name_18970);
    if (binary_op_a(EQUALS, _10555, 0)){
        DeRef(_10555);
        _10555 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10555);
    _10555 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_get_recid", {key, table_name})*/
    Ref(_table_name_18970);
    Ref(_key_18969);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18969;
    ((int *)_2)[2] = _table_name_18970;
    _10558 = MAKE_SEQ(_1);
    RefDS(_10249);
    RefDS(_10557);
    _38fatal(903, _10249, _10557, _10558);
    _10558 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18969);
    DeRef(_table_name_18970);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _38current_table_pos_16700, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_get_recid", {key, table_name})*/
    Ref(_table_name_18970);
    Ref(_key_18969);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18969;
    ((int *)_2)[2] = _table_name_18970;
    _10560 = MAKE_SEQ(_1);
    RefDS(_10253);
    RefDS(_10557);
    _38fatal(903, _10253, _10557, _10560);
    _10560 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18969);
    DeRef(_table_name_18970);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18971 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_38key_pointers_16706)){
            _hi_18972 = SEQ_PTR(_38key_pointers_16706)->length;
    }
    else {
        _hi_18972 = 1;
    }

    /** 	mid = 1*/
    _mid_18973 = 1;

    /** 	c = 0*/
    _c_18974 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18971 > _hi_18972)
    goto L5; // [96] 176

    /** 		mid = floor((lo + hi) / 2)*/
    _10563 = _lo_18971 + _hi_18972;
    if ((long)((unsigned long)_10563 + (unsigned long)HIGH_BITS) >= 0) 
    _10563 = NewDouble((double)_10563);
    if (IS_ATOM_INT(_10563)) {
        _mid_18973 = _10563 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10563, 2);
        _mid_18973 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10563);
    _10563 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18973)) {
        _1 = (long)(DBL_PTR(_mid_18973)->dbl);
        DeRefDS(_mid_18973);
        _mid_18973 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10565 = (int)*(((s1_ptr)_2)->base + _mid_18973);
    Ref(_10565);
    _10566 = _38key_value(_10565);
    _10565 = NOVALUE;
    if (IS_ATOM_INT(_key_18969) && IS_ATOM_INT(_10566)){
        _c_18974 = (_key_18969 < _10566) ? -1 : (_key_18969 > _10566);
    }
    else{
        _c_18974 = compare(_key_18969, _10566);
    }
    DeRef(_10566);
    _10566 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18974 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18972 = _mid_18973 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18974 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18971 = _mid_18973 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return key_pointers[mid]*/
    _2 = (int)SEQ_PTR(_38key_pointers_16706);
    _10572 = (int)*(((s1_ptr)_2)->base + _mid_18973);
    Ref(_10572);
    DeRef(_key_18969);
    DeRef(_table_name_18970);
    return _10572;

    /** 	end while*/
    goto L4; // [173] 96
L5: 

    /** 	return -1*/
    DeRef(_key_18969);
    DeRef(_table_name_18970);
    _10572 = NOVALUE;
    return -1;
    ;
}



// 0x4125C99C
