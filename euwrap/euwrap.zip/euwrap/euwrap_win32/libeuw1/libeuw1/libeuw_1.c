// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_1eu_call_func(int _rid, int _did)
{
    int _i;
    int _2629 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = call_func(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2629 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2629);
    _1 = (int)SEQ_PTR(_2629);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid].convention) {
                _1 = (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
    }
    _i = _1;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	return i
    DeRef(_2629);
    return _i;
    ;
}


int __stdcall
_1eu_call_proc(int _rid, int _did)
{
    int _2631 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	call_proc(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2631 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2631);
    _1 = (int)SEQ_PTR(_2631);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                     );
            }
            else {
                (*(int (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref(*(int *)(_2+4));
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
            }
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
            }
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
            }
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
            }
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            if (_00[_rid].convention) {
                (*(int (__stdcall *)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            else {
                (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
            }
            break;
    }

    // end procedure
    DeRef(_2631);
    return 0;
    ;
}


int __stdcall
_1eu_routine_id(int _did)
{
    int _i;
    int _2632 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = routine_id(data[did]) -- this is the only time it uses a string
    _2 = (int)SEQ_PTR(_1data);
    _2632 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2632);
    _i = CRoutineId(370, 1, _2632);

    // 	return i
    DeRef(_2632);
    return _i;
    ;
}


int __stdcall
_1eu_routine_id_str(int _low, int _high)
{
    int _i;
    int _2634 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string
    _2634 = _1get_address(_low, _high);
    Ref(_2634);
    _0 = _2634;
    _2634 = _12peek_string(_2634);
    DeRef(_0);
    _i = CRoutineId(371, 1, _2634);

    // 	return i
    DeRefDSi(_2634);
    return _i;
    ;
}


