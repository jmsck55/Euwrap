// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_7wait_key()
{
    int _432;
    int _0, _1, _2;
    

    //     return machine_func(M_WAIT_KEY, 0)
    _432 = machine(26, 0);
    return _432;
    ;
}


int _7get_ch()
{
    int _433;
    int _0, _1, _2;
    

    //     if sequence(input_string) then
    _433 = IS_SEQUENCE(_7input_string);
    if (_433 == 0)
        goto L1;

    // 	if string_next <= length(input_string) then
    _433 = SEQ_PTR(_7input_string)->length;
    if (_7string_next > _433)
        goto L2;

    // 	    ch = input_string[string_next]
    _2 = (int)SEQ_PTR(_7input_string);
    _7ch = (int)*(((s1_ptr)_2)->base + _7string_next);
    if (!IS_ATOM_INT(_7ch))
        _7ch = (long)DBL_PTR(_7ch)->dbl;

    // 	    string_next += 1
    _7string_next = _7string_next + 1;
    goto L3;
L2:

    // 	    ch = GET_EOF
    _7ch = -1;
L4:
    goto L3;
L1:

    // 	ch = getc(input_file)
    if (_7input_file != last_r_file_no) {
        last_r_file_ptr = which_file(_7input_file, EF_READ);
        last_r_file_no = _7input_file;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _7ch = wingetch();
        }
        else
            _7ch = getc(last_r_file_ptr);
    }
    else
        _7ch = getc(last_r_file_ptr);
L3:

    // end procedure
    return 0;
    ;
}


int _7skip_blanks()
{
    int _440;
    int _0, _1, _2;
    

    //     while find(ch, " \t\n\r") do
L1:
    _440 = find(_7ch, _439);
    if (_440 == 0)
        goto L2;

    // 	get_ch()
    _7get_ch();

    //     end while
    goto L1;
L2:

    // end procedure
    return 0;
    ;
}


int _7escape_char(int _c)
{
    int _i;
    int _443;
    int _0, _1, _2;
    

    //     i = find(c, ESCAPE_CHARS)
    _i = find(_c, _7ESCAPE_CHARS);

    //     if i = 0 then
    if (_i != 0)
        goto L1;

    // 	return GET_FAIL
    return 1;
    goto L2;
L1:

    // 	return ESCAPED_CHARS[i]
    _2 = (int)SEQ_PTR(_7ESCAPED_CHARS);
    _443 = (int)*(((s1_ptr)_2)->base + _i);
    return _443;
L2:
    ;
}


int _7get_qchar()
{
    int _c;
    int _446 = 0;
    int _0, _1, _2;
    

    //     get_ch()
    _7get_ch();

    //     c = ch
    _c = _7ch;

    //     if ch = '\\' then
    if (_7ch != 92)
        goto L1;

    // 	get_ch()
    _7get_ch();

    // 	c = escape_char(ch)
    _c = _7escape_char(_7ch);

    // 	if c = GET_FAIL then
    if (_c != 1)
        goto L2;

    // 	    return {GET_FAIL, 0}
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _446 = MAKE_SEQ(_1);
    return _446;
L3:
    goto L2;
L1:

    //     elsif ch = '\'' then
    if (_7ch != 39)
        goto L4;

    // 	return {GET_FAIL, 0}
    DeRef(_446);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _446 = MAKE_SEQ(_1);
    return _446;
L4:
L2:

    //     get_ch()
    _7get_ch();

    //     if ch != '\'' then
    if (_7ch == 39)
        goto L5;

    // 	return {GET_FAIL, 0}
    DeRef(_446);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _446 = MAKE_SEQ(_1);
    return _446;
    goto L6;
L5:

    // 	get_ch()
    _7get_ch();

    // 	return {GET_SUCCESS, c}
    DeRef(_446);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c;
    _446 = MAKE_SEQ(_1);
    return _446;
L6:
    ;
}


int _7get_string()
{
    int _text = 0;
    int _457 = 0;
    int _455;
    int _0, _1, _2;
    

    //     text = ""
    RefDS(_202);
    _text = _202;

    //     while TRUE do
L1:

    // 	get_ch()
    _7get_ch();

    // 	if ch = GET_EOF or ch = '\n' then
    _455 = (_7ch == -1);
    if (_455 != 0) {
        goto L2;
    }
    DeRef(_457);
    _457 = (_7ch == 10);
L3:
    if (_457 == 0)
        goto L4;
L2:

    // 	    return {GET_FAIL, 0}
    DeRef(_457);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _457 = MAKE_SEQ(_1);
    DeRefi(_text);
    return _457;
    goto L5;
L4:

    // 	elsif ch = '"' then
    if (_7ch != 34)
        goto L6;

    // 	    get_ch()
    _7get_ch();

    // 	    return {GET_SUCCESS, text}
    DeRef(_457);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text;
    RefDS(_text);
    _457 = MAKE_SEQ(_1);
    DeRefDSi(_text);
    return _457;
    goto L5;
L6:

    // 	elsif ch = '\\' then
    if (_7ch != 92)
        goto L7;

    // 	    get_ch()
    _7get_ch();

    // 	    ch = escape_char(ch)
    _0 = _7escape_char(_7ch);
    _7ch = _0;

    // 	    if ch = GET_FAIL then
    if (_7ch != 1)
        goto L8;

    // 		return {GET_FAIL, 0}
    DeRef(_457);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _457 = MAKE_SEQ(_1);
    DeRefi(_text);
    return _457;
L8:
L7:
L5:

    // 	text = text & ch
    Append(&_text, _text, _7ch);

    //     end while
    goto L1;
L9:
    ;
}


int _7get_number()
{
    int _sign;
    int _e_sign;
    int _ndigits;
    int _hex_digit;
    int _mantissa = 0;
    int _dec = 0;
    int _e_mag = 0;
    int _485 = 0;
    int _470 = 0;
    int _0, _1, _2;
    

    //     sign = +1
    _sign = 1;

    //     mantissa = 0
    _mantissa = 0;

    //     ndigits = 0
    _ndigits = 0;

    //     if ch = '-' then
    if (_7ch != 45)
        goto L1;

    // 	sign = -1
    _sign = -1;

    // 	get_ch()
    _7get_ch();
    goto L2;
L1:

    //     elsif ch = '+' then
    if (_7ch != 43)
        goto L3;

    // 	get_ch()
    _7get_ch();
L3:
L2:

    //     if ch = '#' then
    if (_7ch != 35)
        goto L4;

    // 	get_ch()
    _7get_ch();

    // 	while TRUE do
L5:

    // 	    hex_digit = find(ch, HEX_DIGITS)-1
    DeRef(_470);
    _470 = find(_7ch, _7HEX_DIGITS);
    _hex_digit = _470 - 1;

    // 	    if hex_digit >= 0 then
    if (_hex_digit < 0)
        goto L6;

    // 		ndigits += 1
    _ndigits = _ndigits + 1;

    // 		mantissa = mantissa * 16 + hex_digit
    if (IS_ATOM_INT(_mantissa)) {
        if (_mantissa == (short)_mantissa)
            _470 = _mantissa * 16;
        else
            _470 = NewDouble(_mantissa * (double)16);
    }
    else {
        _470 = NewDouble(DBL_PTR(_mantissa)->dbl * (double)16);
    }
    DeRef(_mantissa);
    if (IS_ATOM_INT(_470)) {
        _mantissa = _470 + _hex_digit;
        if ((long)((unsigned long)_mantissa + (unsigned long)HIGH_BITS) >= 0) 
            _mantissa = NewDouble((double)_mantissa);
    }
    else {
        _mantissa = NewDouble(DBL_PTR(_470)->dbl + (double)_hex_digit);
    }

    // 		get_ch()
    _7get_ch();
    goto L5;
L6:

    // 		if ndigits > 0 then
    if (_ndigits <= 0)
        goto L7;

    // 		    return {GET_SUCCESS, sign * mantissa}
    DeRef(_470);
    if (IS_ATOM_INT(_mantissa)) {
        if (_mantissa <= INT15 && _mantissa >= -INT15)
            _470 = _sign * _mantissa;
        else
            _470 = NewDouble(_sign * (double)_mantissa);
    }
    else {
        _470 = NewDouble((double)_sign * DBL_PTR(_mantissa)->dbl);
    }
    _0 = _470;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _470;
    Ref(_470);
    _470 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_mantissa);
    DeRef(_dec);
    DeRef(_e_mag);
    DeRef(_485);
    return _470;
    goto L5;
L7:

    // 		    return {GET_FAIL, 0}
    DeRef(_470);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _470 = MAKE_SEQ(_1);
    DeRef(_mantissa);
    DeRef(_dec);
    DeRef(_e_mag);
    DeRef(_485);
    return _470;
L8:
L9:

    // 	end while       
    goto L5;
LA:
L4:

    //     while ch >= '0' and ch <= '9' do
LB:
    DeRef(_470);
    _470 = (_7ch >= 48);
    if (_470 == 0) {
        goto LC;
    }
    DeRef(_485);
    _485 = (_7ch <= 57);
LD:
    if (_485 == 0)
        goto LC;

    // 	ndigits += 1
    _ndigits = _ndigits + 1;

    // 	mantissa = mantissa * 10 + (ch - '0')
    DeRef(_485);
    if (IS_ATOM_INT(_mantissa)) {
        if (_mantissa == (short)_mantissa)
            _485 = _mantissa * 10;
        else
            _485 = NewDouble(_mantissa * (double)10);
    }
    else {
        _485 = NewDouble(DBL_PTR(_mantissa)->dbl * (double)10);
    }
    DeRef(_470);
    _470 = _7ch - 48;
    if ((long)((unsigned long)_470 +(unsigned long) HIGH_BITS) >= 0)
        _470 = NewDouble((double)_470);
    DeRef(_mantissa);
    if (IS_ATOM_INT(_485) && IS_ATOM_INT(_470)) {
        _mantissa = _485 + _470;
        if ((long)((unsigned long)_mantissa + (unsigned long)HIGH_BITS) >= 0) 
            _mantissa = NewDouble((double)_mantissa);
    }
    else {
        if (IS_ATOM_INT(_485)) {
            _mantissa = NewDouble((double)_485 + DBL_PTR(_470)->dbl);
        }
        else {
            if (IS_ATOM_INT(_470)) {
                _mantissa = NewDouble(DBL_PTR(_485)->dbl + (double)_470);
            }
            else
                _mantissa = NewDouble(DBL_PTR(_485)->dbl + DBL_PTR(_470)->dbl);
        }
    }

    // 	get_ch()
    _7get_ch();

    //     end while
    goto LB;
LC:

    //     if ch = '.' then
    if (_7ch != 46)
        goto LE;

    // 	get_ch()
    _7get_ch();

    // 	dec = 10
    DeRef(_dec);
    _dec = 10;

    // 	while ch >= '0' and ch <= '9' do
LF:
    DeRef(_470);
    _470 = (_7ch >= 48);
    if (_470 == 0) {
        goto L10;
    }
    DeRef(_485);
    _485 = (_7ch <= 57);
L11:
    if (_485 == 0)
        goto L10;

    // 	    ndigits += 1
    _ndigits = _ndigits + 1;

    // 	    mantissa += (ch - '0') / dec
    DeRef(_485);
    _485 = _7ch - 48;
    if ((long)((unsigned long)_485 +(unsigned long) HIGH_BITS) >= 0)
        _485 = NewDouble((double)_485);
    _0 = _485;
    if (IS_ATOM_INT(_485) && IS_ATOM_INT(_dec)) {
        _485 = (_485 % _dec) ? NewDouble((double)_485 / _dec) : (_485 / _dec);
    }
    else {
        if (IS_ATOM_INT(_485)) {
            _485 = NewDouble((double)_485 / DBL_PTR(_dec)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec)) {
                _485 = NewDouble(DBL_PTR(_485)->dbl / (double)_dec);
            }
            else
                _485 = NewDouble(DBL_PTR(_485)->dbl / DBL_PTR(_dec)->dbl);
        }
    }
    DeRef(_0);
    _0 = _mantissa;
    if (IS_ATOM_INT(_mantissa) && IS_ATOM_INT(_485)) {
        _mantissa = _mantissa + _485;
        if ((long)((unsigned long)_mantissa + (unsigned long)HIGH_BITS) >= 0) 
            _mantissa = NewDouble((double)_mantissa);
    }
    else {
        if (IS_ATOM_INT(_mantissa)) {
            _mantissa = NewDouble((double)_mantissa + DBL_PTR(_485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_485)) {
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl + (double)_485);
            }
            else
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl + DBL_PTR(_485)->dbl);
        }
    }
    DeRef(_0);

    // 	    dec *= 10
    _0 = _dec;
    if (IS_ATOM_INT(_dec)) {
        if (_dec == (short)_dec)
            _dec = _dec * 10;
        else
            _dec = NewDouble(_dec * (double)10);
    }
    else {
        _dec = NewDouble(DBL_PTR(_dec)->dbl * (double)10);
    }
    DeRef(_0);

    // 	    get_ch()
    _7get_ch();

    // 	end while
    goto LF;
L10:
LE:

    //     if ndigits = 0 then
    if (_ndigits != 0)
        goto L12;

    // 	return {GET_FAIL, 0}
    DeRef(_485);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _485 = MAKE_SEQ(_1);
    DeRef(_mantissa);
    DeRef(_dec);
    DeRef(_e_mag);
    DeRef(_470);
    return _485;
L12:

    //     mantissa = sign * mantissa
    _0 = _mantissa;
    if (IS_ATOM_INT(_mantissa)) {
        if (_mantissa <= INT15 && _mantissa >= -INT15)
            _mantissa = _sign * _mantissa;
        else
            _mantissa = NewDouble(_sign * (double)_mantissa);
    }
    else {
        _mantissa = NewDouble((double)_sign * DBL_PTR(_mantissa)->dbl);
    }
    DeRef(_0);

    //     if ch = 'e' or ch = 'E' then
    DeRef(_485);
    _485 = (_7ch == 101);
    if (_485 != 0) {
        goto L13;
    }
    DeRef(_470);
    _470 = (_7ch == 69);
L14:
    if (_470 == 0)
        goto L15;
L13:

    // 	e_sign = +1
    _e_sign = 1;

    // 	e_mag = 0
    DeRef(_e_mag);
    _e_mag = 0;

    // 	get_ch()
    _7get_ch();

    // 	if ch = '-' then
    if (_7ch != 45)
        goto L16;

    // 	    e_sign = -1
    _e_sign = -1;

    // 	    get_ch()
    _7get_ch();
    goto L17;
L16:

    // 	elsif ch = '+' then
    if (_7ch != 43)
        goto L18;

    // 	    get_ch()
    _7get_ch();
L18:
L17:

    // 	if ch >= '0' and ch <= '9' then
    DeRef(_470);
    _470 = (_7ch >= 48);
    if (_470 == 0) {
        goto L19;
    }
    DeRef(_485);
    _485 = (_7ch <= 57);
L1A:
    if (_485 == 0)
        goto L19;

    // 	    e_mag = ch - '0'
    DeRef(_e_mag);
    _e_mag = _7ch - 48;
    if ((long)((unsigned long)_e_mag +(unsigned long) HIGH_BITS) >= 0)
        _e_mag = NewDouble((double)_e_mag);

    // 	    get_ch()
    _7get_ch();

    // 	    while ch >= '0' and ch <= '9' do
L1B:
    DeRef(_485);
    _485 = (_7ch >= 48);
    if (_485 == 0) {
        goto L1C;
    }
    DeRef(_470);
    _470 = (_7ch <= 57);
L1D:
    if (_470 == 0)
        goto L1C;

    // 		e_mag = e_mag * 10 + ch - '0'
    DeRef(_470);
    if (IS_ATOM_INT(_e_mag)) {
        if (_e_mag == (short)_e_mag)
            _470 = _e_mag * 10;
        else
            _470 = NewDouble(_e_mag * (double)10);
    }
    else {
        _470 = NewDouble(DBL_PTR(_e_mag)->dbl * (double)10);
    }
    _0 = _470;
    if (IS_ATOM_INT(_470)) {
        _470 = _470 + _7ch;
        if ((long)((unsigned long)_470 + (unsigned long)HIGH_BITS) >= 0) 
            _470 = NewDouble((double)_470);
    }
    else {
        _470 = NewDouble(DBL_PTR(_470)->dbl + (double)_7ch);
    }
    DeRef(_0);
    DeRef(_e_mag);
    if (IS_ATOM_INT(_470)) {
        _e_mag = _470 - 48;
        if ((long)((unsigned long)_e_mag +(unsigned long) HIGH_BITS) >= 0)
            _e_mag = NewDouble((double)_e_mag);
    }
    else {
        _e_mag = NewDouble(DBL_PTR(_470)->dbl - (double)48);
    }

    // 		get_ch()                          
    _7get_ch();

    // 	    end while
    goto L1B;
L1E:
    goto L1C;
L19:

    // 	    return {GET_FAIL, 0} -- no exponent
    DeRef(_470);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _470 = MAKE_SEQ(_1);
    DeRef(_mantissa);
    DeRef(_dec);
    DeRef(_e_mag);
    DeRef(_485);
    return _470;
L1C:

    // 	e_mag *= e_sign 
    _0 = _e_mag;
    if (IS_ATOM_INT(_e_mag)) {
        if (_e_mag == (short)_e_mag)
            _e_mag = _e_mag * _e_sign;
        else
            _e_mag = NewDouble(_e_mag * (double)_e_sign);
    }
    else {
        _e_mag = NewDouble(DBL_PTR(_e_mag)->dbl * (double)_e_sign);
    }
    DeRef(_0);

    // 	if e_mag > 308 then
    if (binary_op_a(LESSEQ, _e_mag, 308))
        goto L1F;

    // 	    mantissa *= power(10, 308)
    DeRef(_470);
    _470 = power(10, 308);
    _0 = _mantissa;
    if (IS_ATOM_INT(_mantissa) && IS_ATOM_INT(_470)) {
        if (_mantissa == (short)_mantissa && _470 <= INT15 && _470 >= -INT15)
            _mantissa = _mantissa * _470;
        else
            _mantissa = NewDouble(_mantissa * (double)_470);
    }
    else {
        if (IS_ATOM_INT(_mantissa)) {
            _mantissa = NewDouble((double)_mantissa * DBL_PTR(_470)->dbl);
        }
        else {
            if (IS_ATOM_INT(_470)) {
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl * (double)_470);
            }
            else
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl * DBL_PTR(_470)->dbl);
        }
    }
    DeRef(_0);

    // 	    if e_mag > 1000 then
    if (binary_op_a(LESSEQ, _e_mag, 1000))
        goto L20;

    // 		e_mag = 1000 
    DeRef(_e_mag);
    _e_mag = 1000;
L20:

    // 	    for i = 1 to e_mag - 308 do
    DeRef(_470);
    if (IS_ATOM_INT(_e_mag)) {
        _470 = _e_mag - 308;
        if ((long)((unsigned long)_470 +(unsigned long) HIGH_BITS) >= 0)
            _470 = NewDouble((double)_470);
    }
    else {
        _470 = NewDouble(DBL_PTR(_e_mag)->dbl - (double)308);
    }
    { int _i;
        _i = 1;
L21:
        if (binary_op_a(GREATER, _i, _470))
            goto L22;

        // 		mantissa *= 10
        _0 = _mantissa;
        if (IS_ATOM_INT(_mantissa)) {
            if (_mantissa == (short)_mantissa)
                _mantissa = _mantissa * 10;
            else
                _mantissa = NewDouble(_mantissa * (double)10);
        }
        else {
            _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl * (double)10);
        }
        DeRef(_0);

        // 	    end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L21;
L22:
        ;
        DeRef(_i);
    }
    goto L23;
L1F:

    // 	    mantissa *= power(10, e_mag)
    DeRef(_485);
    if (IS_ATOM_INT(_e_mag)) {
        _485 = power(10, _e_mag);
    }
    else {
        temp_d.dbl = (double)10;
        _485 = Dpower(&temp_d, DBL_PTR(_e_mag));
    }
    _0 = _mantissa;
    if (IS_ATOM_INT(_mantissa) && IS_ATOM_INT(_485)) {
        if (_mantissa == (short)_mantissa && _485 <= INT15 && _485 >= -INT15)
            _mantissa = _mantissa * _485;
        else
            _mantissa = NewDouble(_mantissa * (double)_485);
    }
    else {
        if (IS_ATOM_INT(_mantissa)) {
            _mantissa = NewDouble((double)_mantissa * DBL_PTR(_485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_485)) {
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl * (double)_485);
            }
            else
                _mantissa = NewDouble(DBL_PTR(_mantissa)->dbl * DBL_PTR(_485)->dbl);
        }
    }
    DeRef(_0);
L23:
L15:

    //     return {GET_SUCCESS, mantissa}
    DeRef(_485);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa;
    Ref(_mantissa);
    _485 = MAKE_SEQ(_1);
    DeRef(_mantissa);
    DeRef(_dec);
    DeRef(_e_mag);
    DeRef(_470);
    return _485;
    ;
}


int _7Get()
{
    int _s = 0;
    int _e = 0;
    int _532 = 0;
    int _0, _1, _2;
    

    //     skip_blanks()
    _7skip_blanks();

    //     if find(ch, START_NUMERIC) then
    _532 = find(_7ch, _7START_NUMERIC);
    if (_532 == 0)
        goto L1;

    // 	return get_number()
    _532 = _7get_number();
    return _532;
    goto L2;
L1:

    //     elsif ch = '{' then
    if (_7ch != 123)
        goto L3;

    // 	s = {}
    RefDS(_202);
    DeRef(_s);
    _s = _202;

    // 	get_ch()
    _7get_ch();

    // 	skip_blanks()
    _7skip_blanks();

    // 	if ch = '}' then
    if (_7ch != 125)
        goto L4;

    // 	    get_ch()
    _7get_ch();

    // 	    return {GET_SUCCESS, s} -- empty sequence
    DeRef(_532);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s;
    RefDS(_s);
    _532 = MAKE_SEQ(_1);
    DeRefDS(_s);
    DeRef(_e);
    return _532;
L4:

    // 	while TRUE do
L5:

    // 	    e = Get() -- read next element
    _0 = _e;
    _e = _7Get();
    DeRef(_0);

    // 	    if e[1] != GET_SUCCESS then
    DeRef(_532);
    _2 = (int)SEQ_PTR(_e);
    _532 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_532);
    if (binary_op_a(EQUALS, _532, 0))
        goto L6;

    // 		return e
    DeRef(_s);
    DeRef(_532);
    return _e;
L6:

    // 	    s = append(s, e[2])
    DeRef(_532);
    _2 = (int)SEQ_PTR(_e);
    _532 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_532);
    Ref(_532);
    Append(&_s, _s, _532);

    // 	    skip_blanks()
    _7skip_blanks();

    // 	    if ch = '}' then
    if (_7ch != 125)
        goto L7;

    // 		get_ch()
    _7get_ch();

    // 		return {GET_SUCCESS, s}
    DeRef(_532);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s;
    RefDS(_s);
    _532 = MAKE_SEQ(_1);
    DeRefDS(_s);
    DeRefDS(_e);
    return _532;
    goto L8;
L7:

    // 	    elsif ch != ',' then
    if (_7ch == 44)
        goto L9;

    // 		return {GET_FAIL, 0}
    DeRef(_532);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _532 = MAKE_SEQ(_1);
    DeRef(_s);
    DeRef(_e);
    return _532;
L9:
L8:

    // 	    get_ch() -- skip comma
    _7get_ch();

    // 	end while
    goto L5;
LA:
    goto L2;
L3:

    //     elsif ch = '\"' then
    if (_7ch != 34)
        goto LB;

    // 	return get_string()
    _0 = _532;
    _532 = _7get_string();
    DeRef(_0);
    DeRef(_s);
    DeRef(_e);
    return _532;
    goto L2;
LB:

    //     elsif ch = '\'' then
    if (_7ch != 39)
        goto LC;

    // 	return get_qchar()
    _0 = _532;
    _532 = _7get_qchar();
    DeRef(_0);
    DeRef(_s);
    DeRef(_e);
    return _532;
    goto L2;
LC:

    //     elsif ch = -1 then
    if (_7ch != -1)
        goto LD;

    // 	return {GET_EOF, 0}
    DeRef(_532);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _532 = MAKE_SEQ(_1);
    DeRef(_s);
    DeRef(_e);
    return _532;
    goto L2;
LD:

    // 	return {GET_FAIL, 0}
    DeRef(_532);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _532 = MAKE_SEQ(_1);
    DeRef(_s);
    DeRef(_e);
    return _532;
L2:
    ;
}


int __stdcall
_7get(int _file)
{
    int _553 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file)) {
        _1 = (long)(DBL_PTR(_file)->dbl);
        DeRefDS(_file);
        _file = _1;
    }

    //     input_file = file
    _7input_file = _file;

    //     input_string = 0
    DeRef(_7input_string);
    _7input_string = 0;

    //     get_ch()
    _7get_ch();

    //     return Get()
    _553 = _7Get();
    return _553;
    ;
}


int __stdcall
_7value(int _string)
{
    int _554 = 0;
    int _0, _1, _2;
    

    //     input_string = string
    RefDS(_string);
    DeRef(_7input_string);
    _7input_string = _string;

    //     string_next = 1
    _7string_next = 1;

    //     get_ch()
    _7get_ch();

    //     return Get()
    _554 = _7Get();
    DeRefDS(_string);
    return _554;
    ;
}


int __stdcall
_7prompt_number(int _prompt, int _range)
{
    int _answer = 0;
    int _570 = 0;
    int _560 = 0;
    int _555 = 0;
    int _0, _1, _2;
    

    //     while 1 do
L1:

    // 	 puts(1, prompt)
    EPuts(1, _prompt);

    // 	 answer = gets(0) -- make sure whole line is read
    DeRef(_answer);
    _answer = EGets(0);

    // 	 puts(1, '\n')
    EPuts(1, 10);

    // 	 answer = value(answer)
    Ref(_answer);
    _0 = _answer;
    _answer = _7value(_answer);
    DeRefi(_0);

    // 	 if answer[1] != GET_SUCCESS or sequence(answer[2]) then
    DeRef(_555);
    _2 = (int)SEQ_PTR(_answer);
    _555 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_555);
    _0 = _555;
    if (IS_ATOM_INT(_555)) {
        _555 = (_555 != 0);
    }
    else {
        _555 = binary_op(NOTEQ, _555, 0);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_555)) {
        if (_555 != 0) {
            goto L2;
        }
    }
    else {
        if (DBL_PTR(_555)->dbl != 0.0) {
            goto L2;
        }
    }
    DeRef(_560);
    _2 = (int)SEQ_PTR(_answer);
    _560 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_560);
    _0 = _560;
    _560 = IS_SEQUENCE(_560);
    DeRef(_0);
L3:
    if (_560 == 0)
        goto L4;
L2:

    // 	      puts(1, "A number is expected - try again\n")
    EPuts(1, _562);
    goto L1;
L4:

    // 	     if length(range) = 2 then
    DeRef(_560);
    _560 = SEQ_PTR(_range)->length;
    if (_560 != 2)
        goto L5;

    // 		  if range[1] <= answer[2] and answer[2] <= range[2] then
    _2 = (int)SEQ_PTR(_range);
    _560 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_560);
    DeRef(_555);
    _2 = (int)SEQ_PTR(_answer);
    _555 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_555);
    _0 = _555;
    if (IS_ATOM_INT(_560) && IS_ATOM_INT(_555)) {
        _555 = (_560 <= _555);
    }
    else {
        _555 = binary_op(LESSEQ, _560, _555);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_555)) {
        if (_555 == 0) {
            goto L6;
        }
    }
    else {
        if (DBL_PTR(_555)->dbl == 0.0) {
            goto L6;
        }
    }
    DeRef(_560);
    _2 = (int)SEQ_PTR(_answer);
    _560 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_560);
    DeRef(_570);
    _2 = (int)SEQ_PTR(_range);
    _570 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_570);
    _0 = _570;
    if (IS_ATOM_INT(_560) && IS_ATOM_INT(_570)) {
        _570 = (_560 <= _570);
    }
    else {
        _570 = binary_op(LESSEQ, _560, _570);
    }
    DeRef(_0);
L7:
    if (_570 == 0) {
        goto L6;
    }
    else {
        if (!IS_ATOM_INT(_570) && DBL_PTR(_570)->dbl == 0.0)
            goto L6;
    }

    // 		      return answer[2]
    DeRef(_570);
    _2 = (int)SEQ_PTR(_answer);
    _570 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_570);
    DeRefDS(_prompt);
    DeRefDS(_range);
    DeRef(_answer);
    DeRef(_560);
    DeRef(_555);
    return _570;
    goto L1;
L6:

    // 		      printf(1,
    EPrintf(1, _573, _range);
L8:
    goto L1;
L5:

    // 		  return answer[2]
    DeRef(_570);
    _2 = (int)SEQ_PTR(_answer);
    _570 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_570);
    DeRefDS(_prompt);
    DeRefDS(_range);
    DeRef(_answer);
    DeRef(_560);
    DeRef(_555);
    return _570;
L9:
LA:

    //     end while
    goto L1;
LB:
    ;
}


int __stdcall
_7prompt_string(int _prompt)
{
    int _answer = 0;
    int _578 = 0;
    int _575;
    int _0, _1, _2;
    

    //     puts(1, prompt)
    EPuts(1, _prompt);

    //     answer = gets(0)
    _answer = EGets(0);

    //     puts(1, '\n')
    EPuts(1, 10);

    //     if sequence(answer) and length(answer) > 0 then
    _575 = IS_SEQUENCE(_answer);
    if (_575 == 0) {
        goto L1;
    }
    _578 = SEQ_PTR(_answer)->length;
    _578 = (_578 > 0);
L2:
    if (_578 == 0)
        goto L1;

    // 	return answer[1..$-1] -- trim the \n
    DeRef(_578);
    _578 = SEQ_PTR(_answer)->length;
    _578 = _578 - 1;
    rhs_slice_target = (object_ptr)&_578;
    RHS_Slice((s1_ptr)_answer, 1, _578);
    DeRefDS(_prompt);
    DeRefi(_answer);
    return _578;
    goto L3;
L1:

    // 	return ""
    RefDS(_202);
    DeRefDS(_prompt);
    DeRefi(_answer);
    DeRef(_578);
    return _202;
L3:
    ;
}


int __stdcall
_7get_bytes(int _fn, int _n)
{
    int _s = 0;
    int _c;
    int _first;
    int _last;
    int _592 = 0;
    int _583;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn)) {
        _1 = (long)(DBL_PTR(_fn)->dbl);
        DeRefDS(_fn);
        _fn = _1;
    }
    if (!IS_ATOM_INT(_n)) {
        _1 = (long)(DBL_PTR(_n)->dbl);
        DeRefDS(_n);
        _n = _1;
    }

    //     if n = 0 then
    if (_n != 0)
        goto L1;

    // 	return {}
    RefDS(_202);
    return _202;
L1:

    //     c = getc(fn)
    if (_fn != last_r_file_no) {
        last_r_file_ptr = which_file(_fn, EF_READ);
        last_r_file_no = _fn;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c = wingetch();
        }
        else
            _c = getc(last_r_file_ptr);
    }
    else
        _c = getc(last_r_file_ptr);

    //     if c = GET_EOF then
    if (_c != -1)
        goto L2;

    // 	return {}
    RefDS(_202);
    DeRefi(_s);
    DeRef(_592);
    return _202;
L2:

    //     s = repeat(c, n)
    DeRefi(_s);
    _s = Repeat(_c, _n);

    //     last = 1
    _last = 1;

    //     while last < n do
L3:
    if (_last >= _n)
        goto L4;

    // 	first = last+1
    _first = _last + 1;

    // 	last  = last+CHUNK
    _last = _last + 100;

    // 	if last > n then
    if (_last <= _n)
        goto L5;

    // 	    last = n
    _last = _n;
L5:

    // 	for i = first to last do
    _583 = _last;
    { int _i;
        _i = _first;
L6:
        if (_i > _583)
            goto L7;

        // 	    s[i] = getc(fn)
        DeRef(_592);
        if (_fn != last_r_file_no) {
            last_r_file_ptr = which_file(_fn, EF_READ);
            last_r_file_no = _fn;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _592 = wingetch();
            }
            else
                _592 = getc(last_r_file_ptr);
        }
        else
            _592 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        *(int *)_2 = _592;

        // 	end for
        _i = _i + 1;
        goto L6;
L7:
        ;
    }

    // 	if s[last] = GET_EOF then  
    DeRef(_592);
    _2 = (int)SEQ_PTR(_s);
    _592 = (int)*(((s1_ptr)_2)->base + _last);
    if (_592 != -1)
        goto L3;

    // 	    while s[last] = GET_EOF do
L8:
    DeRef(_592);
    _2 = (int)SEQ_PTR(_s);
    _592 = (int)*(((s1_ptr)_2)->base + _last);
    if (_592 != -1)
        goto L9;

    // 		last -= 1
    _last = _last - 1;

    // 	    end while 
    goto L8;
L9:

    // 	    return s[1..last]
    rhs_slice_target = (object_ptr)&_592;
    RHS_Slice((s1_ptr)_s, 1, _last);
    DeRefDSi(_s);
    return _592;
LA:

    //     end while   
    goto L3;
L4:

    //     return s
    DeRef(_592);
    return _s;
    ;
}


