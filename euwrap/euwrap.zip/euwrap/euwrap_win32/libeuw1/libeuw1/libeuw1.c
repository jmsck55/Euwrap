// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_1get_version()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = VERSION
    _i = 1;

    // 	return i
    return 1;
    ;
}


int _1binary_search(int _needle, int _haystack)
{
    int _start_point;
    int _end_point;
    int _lo;
    int _hi;
    int _mid;
    int _c;
    int _2183 = 0;
    int _2177;
    int _0, _1, _2;
    

    // 	start_point = 1
    _start_point = 1;

    // 	end_point = 0
    _end_point = 0;

    // 	lo = start_point
    _lo = 1;

    // 	if end_point <= 0 then

    // 		hi = length(haystack) + end_point
    _2177 = SEQ_PTR(_haystack)->length;
    _hi = _2177 + 0;
    goto L1;
L2:

    // 		hi = end_point
    _hi = 0;
L1:

    // 	if lo<1 then
    if (_lo >= 1)
        goto L3;

    // 		lo=1
    _lo = 1;
L3:

    // 	if lo > hi and length(haystack) > 0 then
    _2177 = (_lo > _hi);
    if (_2177 == 0) {
        goto L4;
    }
    DeRef(_2183);
    _2183 = SEQ_PTR(_haystack)->length;
    _2183 = (_2183 > 0);
L5:
    if (_2183 == 0)
        goto L4;

    // 		hi = length(haystack)
    _hi = SEQ_PTR(_haystack)->length;
L4:

    // 	mid = start_point
    _mid = 1;

    // 	c = 0
    _c = 0;

    // 	while lo <= hi do
L6:
    if (_lo > _hi)
        goto L7;

    // 		mid = floor((lo + hi) / 2)
    DeRef(_2183);
    _2183 = _lo + _hi;
    if ((long)((unsigned long)_2183 + (unsigned long)HIGH_BITS) >= 0) 
        _2183 = NewDouble((double)_2183);
    if (IS_ATOM_INT(_2183)) {
        _mid = _2183 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2183, 2);
        _mid = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_mid)) {
        _1 = (long)(DBL_PTR(_mid)->dbl);
        DeRefDS(_mid);
        _mid = _1;
    }

    // 		c = compare(needle, haystack[mid])
    DeRef(_2183);
    _2 = (int)SEQ_PTR(_haystack);
    _2183 = (int)*(((s1_ptr)_2)->base + _mid);
    Ref(_2183);
    if (IS_ATOM_INT(_needle) && IS_ATOM_INT(_2183))
        _c = (_needle < _2183) ? -1 : (_needle > _2183);
    else
        _c = compare(_needle, _2183);

    // 		if c < 0 then
    if (_c >= 0)
        goto L8;

    // 			hi = mid - 1
    _hi = _mid - 1;
    goto L6;
L8:

    // 		elsif c > 0 then
    if (_c <= 0)
        goto L9;

    // 			lo = mid + 1
    _lo = _mid + 1;
    goto L6;
L9:

    // 			return mid
    DeRef(_needle);
    DeRefDS(_haystack);
    DeRef(_2183);
    return _mid;
LA:

    // 	end while
    goto L6;
L7:

    // 	if c > 0 then
    if (_c <= 0)
        goto LB;

    // 		mid += 1
    _mid = _mid + 1;
LB:

    // 	return -mid
    DeRef(_2183);
    if (_mid == 0xC0000000)
        _2183 = (int)NewDouble((double)-0xC0000000);
    else
        _2183 = - _mid;
    DeRef(_needle);
    DeRefDS(_haystack);
    return _2183;
    ;
}


int __stdcall
_1init()
{
    int _0, _1, _2;
    

    // 	high_address = 0
    _1high_address = 0;

    // 	data = {} -- objects
    RefDS(_202);
    DeRef(_1data);
    _1data = _202;

    // 	free_list = {} -- list of free "data" objects
    RefDS(_202);
    DeRef(_1free_list);
    _1free_list = _202;

    // end procedure
    return 0;
    ;
}


int __stdcall
_1get_high_address()
{
    int _0, _1, _2;
    

    // 	return high_address
    return _1high_address;
    ;
}


int _1set_high_address(int _ma)
{
    int _i;
    int _0, _1, _2;
    

    // 	high_address = floor( ma / #00010000 )
    if (IS_ATOM_INT(_ma)) {
        if (65536 > 0 && _ma >= 0) {
            _1high_address = _ma / 65536;
        }
        else {
            temp_dbl = floor((double)_ma / (double)65536);
            _1high_address = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma, 65536);
        _1high_address = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address)) {
        _1 = (long)(DBL_PTR(_1high_address)->dbl);
        DeRefDS(_1high_address);
        _1high_address = _1;
    }

    // 	i = and_bits( ma, #0000FFFF )
    if (IS_ATOM_INT(_ma)) {
        _i = (_ma & 65535);
    }
    else {
        temp_d.dbl = (double)65535;
        _i = Dand_bits(DBL_PTR(_ma), &temp_d);
    }
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	return i
    DeRef(_ma);
    return _i;
    ;
}


int _1get_address(int _low, int _high)
{
    int _2201 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	return high * #00010000 + low
    _2201 = NewDouble(_high * (double)65536);
    _0 = _2201;
    if (IS_ATOM_INT(_2201)) {
        _2201 = _2201 + _low;
        if ((long)((unsigned long)_2201 + (unsigned long)HIGH_BITS) >= 0) 
            _2201 = NewDouble((double)_2201);
    }
    else {
        _2201 = NewDouble(DBL_PTR(_2201)->dbl + (double)_low);
    }
    DeRef(_0);
    return _2201;
    ;
}


int _1register_data(int _ob)
{
    int _i;
    int _ret;
    int _a = 0;
    int _s = 0;
    int _2203;
    int _0, _1, _2;
    

    // 	if length(free_list) then
    _2203 = SEQ_PTR(_1free_list)->length;
    if (_2203 == 0)
        goto L1;

    // 		ret = free_list[1]
    _2 = (int)SEQ_PTR(_1free_list);
    _ret = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_ret))
        _ret = (long)DBL_PTR(_ret)->dbl;

    // 		free_list = free_list[2..length(free_list)]
    _2203 = SEQ_PTR(_1free_list)->length;
    rhs_slice_target = (object_ptr)&_1free_list;
    RHS_Slice((s1_ptr)_1free_list, 2, _2203);

    // 		if integer(ob) then
    if (IS_ATOM_INT(_ob))
        _2203 = 1;
    else if (IS_ATOM_DBL(_ob))
        _2203 = IS_ATOM_INT(DoubleToInt(_ob));
    else
        _2203 = 0;
    if (_2203 == 0)
        goto L2;

    // 			i = ob
    Ref(_ob);
    _i = _ob;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 			data[ret] = i
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _i;
    DeRef(_1);
    goto L3;
L2:

    // 		elsif atom(ob) then
    _2203 = IS_ATOM(_ob);
    if (_2203 == 0)
        goto L4;

    // 			a = ob
    Ref(_ob);
    DeRef(_a);
    _a = _ob;

    // 			data[ret] = a
    Ref(_a);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _a;
    DeRef(_1);
    goto L3;
L4:

    // 			s = ob
    Ref(_ob);
    DeRef(_s);
    _s = _ob;

    // 			data[ret] = s
    RefDS(_s);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _s;
    DeRef(_1);
L3:

    // 		return ret
    DeRef(_ob);
    DeRef(_a);
    DeRef(_s);
    return _ret;
L1:

    // 	if integer(ob) then
    if (IS_ATOM_INT(_ob))
        _2203 = 1;
    else if (IS_ATOM_DBL(_ob))
        _2203 = IS_ATOM_INT(DoubleToInt(_ob));
    else
        _2203 = 0;
    if (_2203 == 0)
        goto L5;

    // 		i = ob
    Ref(_ob);
    _i = _ob;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 		data = append(data, i)
    Append(&_1data, _1data, _i);
    goto L6;
L5:

    // 	elsif atom(ob) then
    _2203 = IS_ATOM(_ob);
    if (_2203 == 0)
        goto L7;

    // 		a = ob
    Ref(_ob);
    DeRef(_a);
    _a = _ob;

    // 		data = append(data, a)
    Ref(_a);
    Append(&_1data, _1data, _a);
    goto L6;
L7:

    // 		s = ob
    Ref(_ob);
    DeRef(_s);
    _s = _ob;

    // 		data = append(data, s)
    RefDS(_s);
    Append(&_1data, _1data, _s);
L6:

    // 	return length(data)
    _2203 = SEQ_PTR(_1data)->length;
    DeRef(_ob);
    DeRef(_a);
    DeRef(_s);
    return _2203;
    ;
}


int _1retval(int _ob)
{
    int _i;
    int _0, _1, _2;
    

    // 	i = register_data(ob)
    Ref(_ob);
    _i = _1register_data(_ob);

    // 	return i
    DeRef(_ob);
    return _i;
    ;
}


int __stdcall
_1length_of_data()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = length(data)
    _i = SEQ_PTR(_1data)->length;

    // 	return i
    return _i;
    ;
}


int __stdcall
_1is_free(int _id)
{
    int _i;
    int _2217;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = find(id, free_list) and 1 -- boolean
    _2217 = find(_id, _1free_list);
    _i = (_2217 != 0 && 1 != 0);

    // 	return i
    return _i;
    ;
}


int __stdcall
_1access_free_list()
{
    int _i;
    int _ma = 0;
    int _2219 = 0;
    int _0, _1, _2;
    

    // 	ma = 0
    _ma = 0;

    // 	if length(free_list) then
    _2219 = SEQ_PTR(_1free_list)->length;
    if (_2219 == 0)
        goto L1;

    // 		ma = allocate(length(free_list) * 4)
    _2219 = SEQ_PTR(_1free_list)->length;
    if (_2219 == (short)_2219)
        _2219 = _2219 * 4;
    else
        _2219 = NewDouble(_2219 * (double)4);
    Ref(_2219);
    _ma = _2allocate(_2219);

    // 		poke4(ma, free_list)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    _1 = (int)SEQ_PTR(_1free_list);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
L1:

    // 	i = set_high_address(ma)
    Ref(_ma);
    _i = _1set_high_address(_ma);

    // 	return i
    DeRef(_ma);
    DeRef(_2219);
    return _i;
    ;
}


int __stdcall
_1generic_free(int _low, int _high)
{
    int _ma = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	ma = get_address(low, high)
    _ma = _1get_address(_low, _high);

    // 	if ma then
    if (_ma == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_ma) && DBL_PTR(_ma)->dbl == 0.0)
            goto L1;
    }

    // 		free(ma)
    Ref(_ma);
    _2free(_ma);
L1:

    // end procedure
    DeRef(_ma);
    return 0;
    ;
}


int __stdcall
_1delete_linked_list(int _id)
{
    int _pos;
    int _2230 = 0;
    int _2231 = 0;
    int _2225 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	pos = binary_search(id, free_list)
    RefDS(_1free_list);
    _pos = _1binary_search(_id, _1free_list);
    if (!IS_ATOM_INT(_pos)) {
        _1 = (long)(DBL_PTR(_pos)->dbl);
        DeRefDS(_pos);
        _pos = _1;
    }

    // 	if pos < 0 then -- if not in free_list, insert
    if (_pos >= 0)
        goto L1;

    // 		data[id] = {}
    RefDS(_202);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id);
    _1 = *(int *)_2;
    *(int *)_2 = _202;
    DeRef(_1);

    // 		pos = -pos
    _pos = - _pos;

    // 		free_list = free_list[1..pos-1] & {id} & free_list[pos..$]
    _2225 = _pos - 1;
    rhs_slice_target = (object_ptr)&_2225;
    RHS_Slice((s1_ptr)_1free_list, 1, _2225);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _id;
    _2230 = MAKE_SEQ(_1);
    _2231 = SEQ_PTR(_1free_list)->length;
    rhs_slice_target = (object_ptr)&_2231;
    RHS_Slice((s1_ptr)_1free_list, _pos, _2231);
    {
        int concat_list[3];

        concat_list[0] = _2231;
        concat_list[1] = _2230;
        concat_list[2] = _2225;
        Concat_N((object_ptr)&_1free_list, concat_list, 3);
    }

    // 		for i = length(free_list) to 1 by -1 do
    DeRefDS(_2231);
    _2231 = SEQ_PTR(_1free_list)->length;
    { int _i;
        _i = _2231;
L2:
        if (_i < 1)
            goto L3;

        // 			if free_list[$] = length(data) then
        DeRef(_2231);
        _2231 = SEQ_PTR(_1free_list)->length;
        _2 = (int)SEQ_PTR(_1free_list);
        _2231 = (int)*(((s1_ptr)_2)->base + _2231);
        Ref(_2231);
        DeRef(_2230);
        _2230 = SEQ_PTR(_1data)->length;
        if (binary_op_a(NOTEQ, _2231, _2230))
            goto L3;

        // 				data = data[1..$-1]
        _2230 = SEQ_PTR(_1data)->length;
        _2230 = _2230 - 1;
        rhs_slice_target = (object_ptr)&_1data;
        RHS_Slice((s1_ptr)_1data, 1, _2230);

        // 				free_list = free_list[1..$-1]
        _2230 = SEQ_PTR(_1free_list)->length;
        _2230 = _2230 - 1;
        rhs_slice_target = (object_ptr)&_1free_list;
        RHS_Slice((s1_ptr)_1free_list, 1, _2230);
        goto L4;
L5:

        // 				exit
        goto L3;
L4:

        // 		end for
        _i = _i + -1;
        goto L2;
L3:
        ;
    }
L1:

    // end procedure
    DeRef(_2230);
    DeRef(_2231);
    DeRef(_2225);
    return 0;
    ;
}


int __stdcall
_1free_linked_lists(int _low, int _high, int _len)
{
    int _array = 0;
    int _ma = 0;
    int _2249 = 0;
    int _2245 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	ma = get_address(low, high)
    _ma = _1get_address(_low, _high);

    // 	array = peek4u({ma, len}) -- note: it is an array of "unsigned int"
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ma;
    Ref(_ma);
    ((int *)_2)[2] = _len;
    _2245 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_2245);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _array = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }

    // 	for i = 1 to length(array) do
    DeRefDS(_2245);
    _2245 = SEQ_PTR(_array)->length;
    { int _i;
        _i = 1;
L1:
        if (_i > _2245)
            goto L2;

        // 		delete_linked_list(array[i])
        DeRef(_2249);
        _2 = (int)SEQ_PTR(_array);
        _2249 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_2249);
        Ref(_2249);
        _1delete_linked_list(_2249);

        // 	end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRef(_array);
    DeRef(_ma);
    DeRef(_2249);
    DeRef(_2245);
    return 0;
    ;
}


int __stdcall
_1register_linked_list(int _low, int _high)
{
    int _i;
    int _2250 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = register_data(linked_list_to_sequence(get_address(low, high)))
    _2250 = _1get_address(_low, _high);
    Ref(_2250);
    _0 = _2250;
    _2250 = _12linked_list_to_sequence(_2250);
    DeRef(_0);
    Ref(_2250);
    _i = _1register_data(_2250);

    // 	return i
    DeRef(_2250);
    return _i;
    ;
}


int __stdcall
_1new_linked_list(int _low, int _high)
{
    int _i;
    int _2253 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = register_data(linked_list_to_sequence(get_address(low, high)))
    _2253 = _1get_address(_low, _high);
    Ref(_2253);
    _0 = _2253;
    _2253 = _12linked_list_to_sequence(_2253);
    DeRef(_0);
    Ref(_2253);
    _i = _1register_data(_2253);

    // 	return i
    DeRef(_2253);
    return _i;
    ;
}


int __stdcall
_1store_linked_list(int _id, int _low, int _high)
{
    int _2256 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	data[id] = linked_list_to_sequence(get_address(low, high))
    _2256 = _1get_address(_low, _high);
    Ref(_2256);
    _0 = _2256;
    _2256 = _12linked_list_to_sequence(_2256);
    DeRef(_0);
    Ref(_2256);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id);
    _1 = *(int *)_2;
    *(int *)_2 = _2256;
    DeRef(_1);

    // end procedure
    DeRef(_2256);
    return 0;
    ;
}


int __stdcall
_1access_linked_list(int _id)
{
    int _i;
    int _2258 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = set_high_address(sequence_to_linked_list(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2258 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2258);
    Ref(_2258);
    _0 = _2258;
    _2258 = _12sequence_to_linked_list(_2258);
    DeRef(_0);
    Ref(_2258);
    _i = _1set_high_address(_2258);

    // 	return i
    DeRef(_2258);
    return _i;
    ;
}


int __stdcall
_1at_linked_list(int _id, int _index)
{
    int _i;
    int _2261 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_index)) {
        _1 = (long)(DBL_PTR(_index)->dbl);
        DeRefDS(_index);
        _index = _1;
    }

    // 	i = set_high_address(sequence_to_linked_list(data[id][index]))
    _2 = (int)SEQ_PTR(_1data);
    _2261 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2261);
    _0 = _2261;
    _2 = (int)SEQ_PTR(_2261);
    _2261 = (int)*(((s1_ptr)_2)->base + _index);
    Ref(_2261);
    DeRef(_0);
    Ref(_2261);
    _0 = _2261;
    _2261 = _12sequence_to_linked_list(_2261);
    DeRef(_0);
    Ref(_2261);
    _i = _1set_high_address(_2261);

    // 	return i
    DeRef(_2261);
    return _i;
    ;
}


int __stdcall
_1free_linked_list_dll(int _low, int _high)
{
    int _2265 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	free_linked_list(get_address(low, high))
    _2265 = _1get_address(_low, _high);
    Ref(_2265);
    _12free_linked_list(_2265);

    // end procedure
    DeRef(_2265);
    return 0;
    ;
}


int __stdcall
_1length_linked_list(int _id)
{
    int _i;
    int _2266 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	if atom(data[id]) then
    _2 = (int)SEQ_PTR(_1data);
    _2266 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2266);
    _0 = _2266;
    _2266 = IS_ATOM(_2266);
    DeRef(_0);
    if (_2266 == 0)
        goto L1;

    // 		i = -1
    _i = -1;
    goto L2;
L1:

    // 		i = length(data[id])
    DeRef(_2266);
    _2 = (int)SEQ_PTR(_1data);
    _2266 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2266);
    _i = SEQ_PTR(_2266)->length;
L2:

    // 	return i
    DeRef(_2266);
    return _i;
    ;
}


int __stdcall
_1store_at_linked_list(int _id, int _index, int _low, int _high)
{
    int _2272 = 0;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_index)) {
        _1 = (long)(DBL_PTR(_index)->dbl);
        DeRefDS(_index);
        _index = _1;
    }
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	data[id][index] = linked_list_to_sequence(get_address(low, high))
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _3 = (int)(_id + ((s1_ptr)_2)->base);
    _2272 = _1get_address(_low, _high);
    Ref(_2272);
    _0 = _2272;
    _2272 = _12linked_list_to_sequence(_2272);
    DeRef(_0);
    Ref(_2272);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index);
    _1 = *(int *)_2;
    *(int *)_2 = _2272;
    DeRef(_1);

    // end procedure
    DeRef(_2272);
    return 0;
    ;
}


int __stdcall
_1eu_repeat(int _id, int _len)
{
    int _2274 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	return retval(repeat(data[id], len))
    _2 = (int)SEQ_PTR(_1data);
    _2274 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2274);
    _0 = _2274;
    _2274 = Repeat(_2274, _len);
    DeRef(_0);
    RefDS(_2274);
    _0 = _2274;
    _2274 = _1retval(_2274);
    DeRefDS(_0);
    return _2274;
    ;
}


int __stdcall
_1eu_mem_set(int _low, int _high, int _byte_val, int _how_many)
{
    int _2277 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_byte_val)) {
        _1 = (long)(DBL_PTR(_byte_val)->dbl);
        DeRefDS(_byte_val);
        _byte_val = _1;
    }
    if (!IS_ATOM_INT(_how_many)) {
        _1 = (long)(DBL_PTR(_how_many)->dbl);
        DeRefDS(_how_many);
        _how_many = _1;
    }

    // 	mem_set(get_address(low, high), byte_val, how_many)
    _2277 = _1get_address(_low, _high);
    memory_set(_2277, _byte_val, _how_many);

    // end procedure
    DeRef(_2277);
    return 0;
    ;
}


int __stdcall
_1eu_mem_copy(int _dstlow, int _dsthigh, int _srclow, int _srchigh, int _len)
{
    int _2279 = 0;
    int _2278 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow)) {
        _1 = (long)(DBL_PTR(_dstlow)->dbl);
        DeRefDS(_dstlow);
        _dstlow = _1;
    }
    if (!IS_ATOM_INT(_dsthigh)) {
        _1 = (long)(DBL_PTR(_dsthigh)->dbl);
        DeRefDS(_dsthigh);
        _dsthigh = _1;
    }
    if (!IS_ATOM_INT(_srclow)) {
        _1 = (long)(DBL_PTR(_srclow)->dbl);
        DeRefDS(_srclow);
        _srclow = _1;
    }
    if (!IS_ATOM_INT(_srchigh)) {
        _1 = (long)(DBL_PTR(_srchigh)->dbl);
        DeRefDS(_srchigh);
        _srchigh = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)
    _2278 = _1get_address(_dstlow, _dsthigh);
    _2279 = _1get_address(_srclow, _srchigh);
    memory_copy(_2278, _2279, _len);

    // end procedure
    DeRef(_2279);
    DeRef(_2278);
    return 0;
    ;
}


int __stdcall
_1eu_add(int _id1, int _id2)
{
    int _2281 = 0;
    int _2280 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] + data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2280 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2280);
    _2 = (int)SEQ_PTR(_1data);
    _2281 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2281);
    _0 = _2281;
    if (IS_ATOM_INT(_2280) && IS_ATOM_INT(_2281)) {
        _2281 = _2280 + _2281;
        if ((long)((unsigned long)_2281 + (unsigned long)HIGH_BITS) >= 0) 
            _2281 = NewDouble((double)_2281);
    }
    else {
        _2281 = binary_op(PLUS, _2280, _2281);
    }
    DeRef(_0);
    Ref(_2281);
    _0 = _2281;
    _2281 = _1retval(_2281);
    DeRef(_0);
    DeRef(_2280);
    return _2281;
    ;
}


int __stdcall
_1eu_subtract(int _id1, int _id2)
{
    int _2285 = 0;
    int _2284 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] - data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2284 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2284);
    _2 = (int)SEQ_PTR(_1data);
    _2285 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2285);
    _0 = _2285;
    if (IS_ATOM_INT(_2284) && IS_ATOM_INT(_2285)) {
        _2285 = _2284 - _2285;
        if ((long)((unsigned long)_2285 +(unsigned long) HIGH_BITS) >= 0)
            _2285 = NewDouble((double)_2285);
    }
    else {
        _2285 = binary_op(MINUS, _2284, _2285);
    }
    DeRef(_0);
    Ref(_2285);
    _0 = _2285;
    _2285 = _1retval(_2285);
    DeRef(_0);
    DeRef(_2284);
    return _2285;
    ;
}


int __stdcall
_1eu_multiply(int _id1, int _id2)
{
    int _2289 = 0;
    int _2288 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] * data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2288 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2288);
    _2 = (int)SEQ_PTR(_1data);
    _2289 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2289);
    _0 = _2289;
    if (IS_ATOM_INT(_2288) && IS_ATOM_INT(_2289)) {
        if (_2288 == (short)_2288 && _2289 <= INT15 && _2289 >= -INT15)
            _2289 = _2288 * _2289;
        else
            _2289 = NewDouble(_2288 * (double)_2289);
    }
    else {
        _2289 = binary_op(MULTIPLY, _2288, _2289);
    }
    DeRef(_0);
    Ref(_2289);
    _0 = _2289;
    _2289 = _1retval(_2289);
    DeRef(_0);
    DeRef(_2288);
    return _2289;
    ;
}


int __stdcall
_1eu_divide(int _id1, int _id2)
{
    int _2293 = 0;
    int _2292 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] / data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2292 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2292);
    _2 = (int)SEQ_PTR(_1data);
    _2293 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2293);
    _0 = _2293;
    if (IS_ATOM_INT(_2292) && IS_ATOM_INT(_2293)) {
        _2293 = (_2292 % _2293) ? NewDouble((double)_2292 / _2293) : (_2292 / _2293);
    }
    else {
        _2293 = binary_op(DIVIDE, _2292, _2293);
    }
    DeRef(_0);
    Ref(_2293);
    _0 = _2293;
    _2293 = _1retval(_2293);
    DeRef(_0);
    DeRef(_2292);
    return _2293;
    ;
}


int __stdcall
_1eu_negate(int _id)
{
    int _2296 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(-data[id])
    _2 = (int)SEQ_PTR(_1data);
    _2296 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2296);
    _0 = _2296;
    if (IS_ATOM_INT(_2296)) {
        if (_2296 == 0xC0000000)
            _2296 = (int)NewDouble((double)-0xC0000000);
        else
            _2296 = - _2296;
    }
    else {
        _2296 = unary_op(UMINUS, _2296);
    }
    DeRef(_0);
    Ref(_2296);
    _0 = _2296;
    _2296 = _1retval(_2296);
    DeRef(_0);
    return _2296;
    ;
}


int __stdcall
_1eu_not(int _id)
{
    int _2299 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(not data[id])
    _2 = (int)SEQ_PTR(_1data);
    _2299 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2299);
    _0 = _2299;
    if (IS_ATOM_INT(_2299)) {
        _2299 = (_2299 == 0);
    }
    else {
        _2299 = unary_op(NOT, _2299);
    }
    DeRef(_0);
    Ref(_2299);
    _0 = _2299;
    _2299 = _1retval(_2299);
    DeRef(_0);
    return _2299;
    ;
}


int __stdcall
_1eu_equals(int _id1, int _id2)
{
    int _2303 = 0;
    int _2302 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] = data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2302 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2302);
    _2 = (int)SEQ_PTR(_1data);
    _2303 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2303);
    _0 = _2303;
    if (IS_ATOM_INT(_2302) && IS_ATOM_INT(_2303)) {
        _2303 = (_2302 == _2303);
    }
    else {
        _2303 = binary_op(EQUALS, _2302, _2303);
    }
    DeRef(_0);
    Ref(_2303);
    _0 = _2303;
    _2303 = _1retval(_2303);
    DeRef(_0);
    DeRef(_2302);
    return _2303;
    ;
}


int __stdcall
_1eu_and(int _id1, int _id2)
{
    int _2307 = 0;
    int _2306 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] and data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2306 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2306);
    _2 = (int)SEQ_PTR(_1data);
    _2307 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2307);
    _0 = _2307;
    if (IS_ATOM_INT(_2306) && IS_ATOM_INT(_2307)) {
        _2307 = (_2306 != 0 && _2307 != 0);
    }
    else {
        _2307 = binary_op(AND, _2306, _2307);
    }
    DeRef(_0);
    Ref(_2307);
    _0 = _2307;
    _2307 = _1retval(_2307);
    DeRef(_0);
    DeRef(_2306);
    return _2307;
    ;
}


int __stdcall
_1eu_or(int _id1, int _id2)
{
    int _2311 = 0;
    int _2310 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] or data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2310 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2310);
    _2 = (int)SEQ_PTR(_1data);
    _2311 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2311);
    _0 = _2311;
    if (IS_ATOM_INT(_2310) && IS_ATOM_INT(_2311)) {
        _2311 = (_2310 != 0 || _2311 != 0);
    }
    else {
        _2311 = binary_op(OR, _2310, _2311);
    }
    DeRef(_0);
    Ref(_2311);
    _0 = _2311;
    _2311 = _1retval(_2311);
    DeRef(_0);
    DeRef(_2310);
    return _2311;
    ;
}


int __stdcall
_1eu_xor(int _id1, int _id2)
{
    int _2315 = 0;
    int _2314 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] xor data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2314 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2314);
    _2 = (int)SEQ_PTR(_1data);
    _2315 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2315);
    _0 = _2315;
    if (IS_ATOM_INT(_2314) && IS_ATOM_INT(_2315)) {
        _2315 = ((_2314 != 0) != (_2315 != 0));
    }
    else {
        _2315 = binary_op(XOR, _2314, _2315);
    }
    DeRef(_0);
    Ref(_2315);
    _0 = _2315;
    _2315 = _1retval(_2315);
    DeRef(_0);
    DeRef(_2314);
    return _2315;
    ;
}


int __stdcall
_1eu_question_mark(int _id)
{
    int _2318 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	? data[id]
    _2 = (int)SEQ_PTR(_1data);
    _2318 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2318);
    StdPrint(1, _2318, 1);

    // end procedure
    DeRef(_2318);
    return 0;
    ;
}


int __stdcall
_1eu_abort(int _ret)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret)) {
        _1 = (long)(DBL_PTR(_ret)->dbl);
        DeRefDS(_ret);
        _ret = _1;
    }

    // 	abort(ret)
    UserCleanup(_ret);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_and_bits(int _id1, int _id2)
{
    int _2320 = 0;
    int _2319 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(and_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2319 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2319);
    _2 = (int)SEQ_PTR(_1data);
    _2320 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2320);
    _0 = _2320;
    if (IS_ATOM_INT(_2319) && IS_ATOM_INT(_2320)) {
        _2320 = (_2319 & _2320);
    }
    else {
        _2320 = binary_op(AND_BITS, _2319, _2320);
    }
    DeRef(_0);
    Ref(_2320);
    _0 = _2320;
    _2320 = _1retval(_2320);
    DeRef(_0);
    DeRef(_2319);
    return _2320;
    ;
}


int __stdcall
_1eu_append(int _id1, int _id2)
{
    int _2324 = 0;
    int _2323 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(append(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2323 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2323);
    _2 = (int)SEQ_PTR(_1data);
    _2324 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2324);
    Ref(_2324);
    Append(&_2324, _2323, _2324);
    RefDS(_2324);
    _0 = _2324;
    _2324 = _1retval(_2324);
    DeRefDS(_0);
    DeRef(_2323);
    return _2324;
    ;
}


int __stdcall
_1eu_arctan(int _id)
{
    int _2327 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(arctan(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2327 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2327);
    _0 = _2327;
    if (IS_ATOM_INT(_2327))
        _2327 = e_arctan(_2327);
    else
        _2327 = unary_op(ARCTAN, _2327);
    DeRef(_0);
    Ref(_2327);
    _0 = _2327;
    _2327 = _1retval(_2327);
    DeRef(_0);
    return _2327;
    ;
}


int __stdcall
_1eu_atom(int _id)
{
    int _i;
    int _2330 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = atom(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _2330 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2330);
    _i = IS_ATOM(_2330);

    // 	return i
    DeRef(_2330);
    return _i;
    ;
}


int __stdcall
_1eu_c_func(int _rid, int _id1)
{
    int _2332 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(c_func(rid, data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2332 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2332);
    _0 = _2332;
    _2332 = call_c(1, _rid, _2332);
    DeRef(_0);
    Ref(_2332);
    _0 = _2332;
    _2332 = _1retval(_2332);
    DeRef(_0);
    return _2332;
    ;
}


int __stdcall
_1eu_c_proc(int _rid, int _id1)
{
    int _2335 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	c_proc(rid, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _2335 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2335);
    call_c(0, _rid, _2335);

    // end procedure
    DeRef(_2335);
    return 0;
    ;
}


int __stdcall
_1eu_call(int _low, int _high)
{
    int _2336 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	call(get_address(low, high))
    _2336 = _1get_address(_low, _high);
    if (IS_ATOM_INT(_2336))
        _0 = (int)_2336;
    else
        _0 = (int)(unsigned long)(DBL_PTR(_2336)->dbl);
    (*(void(*)())_0)();

    // end procedure
    DeRef(_2336);
    return 0;
    ;
}


int __stdcall
_1eu_clear_screen()
{
    int _0, _1, _2;
    

    // 	clear_screen()
    ClearScreen();

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_close(int _fn_id)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	close(fn_id)
    EClose(_fn_id);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_command_line()
{
    int _2337 = 0;
    int _0, _1, _2;
    

    // 	return retval(command_line())
    _2337 = Command_Line();
    RefDS(_2337);
    _0 = _2337;
    _2337 = _1retval(_2337);
    DeRefDS(_0);
    return _2337;
    ;
}


int __stdcall
_1eu_compare(int _id1, int _id2)
{
    int _i;
    int _2340 = 0;
    int _2339 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	i = compare(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2339 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2339);
    _2 = (int)SEQ_PTR(_1data);
    _2340 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2340);
    if (IS_ATOM_INT(_2339) && IS_ATOM_INT(_2340))
        _i = (_2339 < _2340) ? -1 : (_2339 > _2340);
    else
        _i = compare(_2339, _2340);

    // 	return i
    DeRef(_2340);
    DeRef(_2339);
    return _i;
    ;
}


int __stdcall
_1eu_concat(int _id1, int _id2)
{
    int _2343 = 0;
    int _2342 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] & data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2342 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2342);
    _2 = (int)SEQ_PTR(_1data);
    _2343 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2343);
    if (IS_SEQUENCE(_2342) && IS_ATOM(_2343)) {
        Ref(_2343);
        Append(&_2343, _2342, _2343);
    }
    else if (IS_ATOM(_2342) && IS_SEQUENCE(_2343)) {
        Ref(_2342);
        Prepend(&_2343, _2343, _2342);
    }
    else {
        Concat((object_ptr)&_2343, _2342, (s1_ptr)_2343);
    }
    RefDS(_2343);
    _0 = _2343;
    _2343 = _1retval(_2343);
    DeRefDS(_0);
    DeRef(_2342);
    return _2343;
    ;
}


int __stdcall
_1eu_cos(int _id)
{
    int _2346 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(cos(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2346 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2346);
    _0 = _2346;
    if (IS_ATOM_INT(_2346))
        _2346 = e_cos(_2346);
    else
        _2346 = unary_op(COS, _2346);
    DeRef(_0);
    Ref(_2346);
    _0 = _2346;
    _2346 = _1retval(_2346);
    DeRef(_0);
    return _2346;
    ;
}


int __stdcall
_1eu_date()
{
    int _2349 = 0;
    int _0, _1, _2;
    

    // 	return retval(date())
    _2349 = Date();
    RefDS(_2349);
    _0 = _2349;
    _2349 = _1retval(_2349);
    DeRefDSi(_0);
    return _2349;
    ;
}


int __stdcall
_1eu_equal(int _id1, int _id2)
{
    int _i;
    int _2352 = 0;
    int _2351 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	i = equal(data[id1], data[id2]) -- boolean, returns 0 or 1
    _2 = (int)SEQ_PTR(_1data);
    _2351 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2351);
    _2 = (int)SEQ_PTR(_1data);
    _2352 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2352);
    if (_2351 == _2352)
        _i = 1;
    else if (IS_ATOM_INT(_2351) && IS_ATOM_INT(_2352))
        _i = 0;
    else
        _i = (compare(_2351, _2352) == 0);

    // 	return i
    DeRef(_2352);
    DeRef(_2351);
    return _i;
    ;
}


int __stdcall
_1eu_find_from(int _id1, int _id2, int _start)
{
    int _i;
    int _2355 = 0;
    int _2354 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }

    // 	i = find_from(data[id1], data[id2], start) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _2354 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2354);
    _2 = (int)SEQ_PTR(_1data);
    _2355 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2355);
    _i = find_from(_2354, _2355, _start);

    // 	return i
    DeRef(_2355);
    DeRef(_2354);
    return _i;
    ;
}


int __stdcall
_1eu_floor(int _id1)
{
    int _2357 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(floor(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2357 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2357);
    _0 = _2357;
    if (IS_ATOM_INT(_2357))
        _2357 = e_floor(_2357);
    else
        _2357 = unary_op(FLOOR, _2357);
    DeRef(_0);
    Ref(_2357);
    _0 = _2357;
    _2357 = _1retval(_2357);
    DeRef(_0);
    return _2357;
    ;
}


int __stdcall
_1eu_integer_division(int _id1, int _id2)
{
    int _2361 = 0;
    int _2360 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(floor(data[id1] / data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2360 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2360);
    _2 = (int)SEQ_PTR(_1data);
    _2361 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2361);
    _0 = _2361;
    if (IS_ATOM_INT(_2360) && IS_ATOM_INT(_2361)) {
        if (_2361 > 0 && _2360 >= 0) {
            _2361 = _2360 / _2361;
        }
        else {
            temp_dbl = floor((double)_2360 / (double)_2361);
            if (_2360 != MININT)
                _2361 = (long)temp_dbl;
            else
                _2361 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _2360, _2361);
        _2361 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);
    Ref(_2361);
    _0 = _2361;
    _2361 = _1retval(_2361);
    DeRef(_0);
    DeRef(_2360);
    return _2361;
    ;
}


int __stdcall
_1eu_get_key()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = get_key() -- returns an integer
    show_console();
    _i = get_key(0);

    // 	return i
    return _i;
    ;
}


int __stdcall
_1eu_getc(int _fn_id)
{
    int _i;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	i = getc(fn_id) -- returns a character or byte
    if (_fn_id != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id, EF_READ);
        last_r_file_no = _fn_id;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _i = wingetch();
        }
        else
            _i = getc(last_r_file_ptr);
    }
    else
        _i = getc(last_r_file_ptr);

    // 	return i
    return _i;
    ;
}


int __stdcall
_1eu_getenv(int _id1)
{
    int _2366 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(getenv(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2366 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2366);
    DeRef(_2366);
    _2366 = EGetEnv(_2366);
    Ref(_2366);
    _0 = _2366;
    _2366 = _1retval(_2366);
    DeRefi(_0);
    return _2366;
    ;
}


int __stdcall
_1eu_gets(int _fn_id)
{
    int _2369 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	return retval(gets(fn_id))
    _2369 = EGets(_fn_id);
    Ref(_2369);
    _0 = _2369;
    _2369 = _1retval(_2369);
    DeRefi(_0);
    return _2369;
    ;
}


int __stdcall
_1eu_integer(int _id)
{
    int _i;
    int _2371 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = integer(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _2371 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2371);
    if (IS_ATOM_INT(_2371))
        _i = 1;
    else if (IS_ATOM_DBL(_2371))
        _i = IS_ATOM_INT(DoubleToInt(_2371));
    else
        _i = 0;

    // 	return i
    DeRef(_2371);
    return _i;
    ;
}


int __stdcall
_1eu_length(int _id)
{
    int _i;
    int _2373 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = length(data[id]) -- small integer
    _2 = (int)SEQ_PTR(_1data);
    _2373 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2373);
    _i = SEQ_PTR(_2373)->length;

    // 	return i
    DeRef(_2373);
    return _i;
    ;
}


int __stdcall
_1eu_log(int _id)
{
    int _2375 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(log(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2375 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2375);
    _0 = _2375;
    if (IS_ATOM_INT(_2375))
        _2375 = e_log(_2375);
    else
        _2375 = unary_op(LOG, _2375);
    DeRef(_0);
    Ref(_2375);
    _0 = _2375;
    _2375 = _1retval(_2375);
    DeRef(_0);
    return _2375;
    ;
}


int __stdcall
_1eu_machine_func(int _machine_id, int _id1)
{
    int _2378 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id)) {
        _1 = (long)(DBL_PTR(_machine_id)->dbl);
        DeRefDS(_machine_id);
        _machine_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(machine_func(machine_id, data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2378 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2378);
    _0 = _2378;
    _2378 = machine(_machine_id, _2378);
    DeRef(_0);
    Ref(_2378);
    _0 = _2378;
    _2378 = _1retval(_2378);
    DeRef(_0);
    return _2378;
    ;
}


int __stdcall
_1eu_machine_proc(int _machine_id, int _id1)
{
    int _2381 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id)) {
        _1 = (long)(DBL_PTR(_machine_id)->dbl);
        DeRefDS(_machine_id);
        _machine_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	machine_proc(machine_id, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _2381 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2381);
    machine(_machine_id, _2381);

    // end procedure
    DeRef(_2381);
    return 0;
    ;
}


int __stdcall
_1eu_match_from(int _id1, int _id2, int _start)
{
    int _i;
    int _2383 = 0;
    int _2382 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }

    // 	i = match_from(data[id1], data[id2], start) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _2382 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2382);
    _2 = (int)SEQ_PTR(_1data);
    _2383 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2383);
    _i = e_match_from(_2382, _2383, _start);

    // 	return i
    DeRef(_2383);
    DeRef(_2382);
    return _i;
    ;
}


int __stdcall
_1eu_not_bits(int _id1)
{
    int _2385 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(not_bits(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2385 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2385);
    _0 = _2385;
    if (IS_ATOM_INT(_2385))
        _2385 = not_bits(_2385);
    else
        _2385 = unary_op(NOT_BITS, _2385);
    DeRef(_0);
    Ref(_2385);
    _0 = _2385;
    _2385 = _1retval(_2385);
    DeRef(_0);
    return _2385;
    ;
}


int __stdcall
_1eu_object(int _id)
{
    int _2388;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return not find(id, free_list)
    _2388 = find(_id, _1free_list);
    _2388 = (_2388 == 0);
    return _2388;
    ;
}


int __stdcall
_1eu_open(int _id1, int _id2)
{
    int _i;
    int _2391 = 0;
    int _2390 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	i = open(data[id1], data[id2]) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _2390 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2390);
    _2 = (int)SEQ_PTR(_1data);
    _2391 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2391);
    _i = EOpen(_2390, _2391);

    // 	return i
    DeRef(_2391);
    DeRef(_2390);
    return _i;
    ;
}


int __stdcall
_1eu_open_str(int _low, int _high, int _did)
{
    int _i;
    int _2395 = 0;
    int _2393 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = open(peek_string(get_address(low, high)), data[did])
    _2393 = _1get_address(_low, _high);
    Ref(_2393);
    _0 = _2393;
    _2393 = _12peek_string(_2393);
    DeRef(_0);
    _2 = (int)SEQ_PTR(_1data);
    _2395 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2395);
    _i = EOpen(_2393, _2395);

    // 	return i
    DeRefDSi(_2393);
    DeRef(_2395);
    return _i;
    ;
}


int __stdcall
_1eu_or_bits(int _id1, int _id2)
{
    int _2398 = 0;
    int _2397 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(or_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2397 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2397);
    _2 = (int)SEQ_PTR(_1data);
    _2398 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2398);
    _0 = _2398;
    if (IS_ATOM_INT(_2397) && IS_ATOM_INT(_2398)) {
        _2398 = (_2397 | _2398);
    }
    else {
        _2398 = binary_op(OR_BITS, _2397, _2398);
    }
    DeRef(_0);
    Ref(_2398);
    _0 = _2398;
    _2398 = _1retval(_2398);
    DeRef(_0);
    DeRef(_2397);
    return _2398;
    ;
}


int __stdcall
_1eu_peek(int _id1)
{
    int _2401 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2401 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2401);
    _0 = _2401;
    if (IS_ATOM_INT(_2401)) {
        _2401 = *(unsigned char *)_2401;
    }
    else if (IS_ATOM(_2401)) {
        _2401 = *(unsigned char *)(unsigned long)(DBL_PTR(_2401)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_2401);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _2401 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
    }
    DeRef(_0);
    Ref(_2401);
    _0 = _2401;
    _2401 = _1retval(_2401);
    DeRef(_0);
    return _2401;
    ;
}


int __stdcall
_1eu_peek4s(int _id1)
{
    int _2404 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek4s(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2404 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2404);
    _0 = _2404;
    if (IS_ATOM_INT(_2404)) {
        _2404 = *(unsigned long *)_2404;
        if (_2404 < MININT || _2404 > MAXINT)
            _2404 = NewDouble((double)(long)_2404);
    }
    else if (IS_ATOM(_2404)) {
        _2404 = *(unsigned long *)(unsigned long)(DBL_PTR(_2404)->dbl);
        if (_2404 < MININT || _2404 > MAXINT)
            _2404 = NewDouble((double)(long)_2404);
    }
    else {
        _1 = (int)SEQ_PTR(_2404);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _2404 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
                _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    DeRef(_0);
    Ref(_2404);
    _0 = _2404;
    _2404 = _1retval(_2404);
    DeRef(_0);
    return _2404;
    ;
}


int __stdcall
_1eu_peek4u(int _id1)
{
    int _2407 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek4u(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2407 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2407);
    _0 = _2407;
    if (IS_ATOM_INT(_2407)) {
        _2407 = *(unsigned long *)_2407;
        if ((unsigned)_2407 > (unsigned)MAXINT)
            _2407 = NewDouble((double)(unsigned long)_2407);
    }
    else if (IS_ATOM(_2407)) {
        _2407 = *(unsigned long *)(unsigned long)(DBL_PTR(_2407)->dbl);
        if ((unsigned)_2407 > (unsigned)MAXINT)
            _2407 = NewDouble((double)(unsigned long)_2407);
    }
    else {
        _1 = (int)SEQ_PTR(_2407);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _2407 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
                _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    DeRef(_0);
    Ref(_2407);
    _0 = _2407;
    _2407 = _1retval(_2407);
    DeRef(_0);
    return _2407;
    ;
}


int __stdcall
_1eu_platform()
{
    int _0, _1, _2;
    

    // 	return platform() -- returns an integer
    return 2;
    ;
}


int __stdcall
_1eu_poke(int _id1, int _id2)
{
    int _2411 = 0;
    int _2410 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	poke(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2410 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2410);
    _2 = (int)SEQ_PTR(_1data);
    _2411 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2411);
    if (IS_ATOM_INT(_2410))
        poke_addr = (unsigned char *)_2410;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_2410)->dbl);
    if (IS_ATOM_INT(_2411)) {
        *poke_addr = (unsigned char)_2411;
    }
    else if (IS_ATOM(_2411)) {
        *poke_addr = (signed char)DBL_PTR(_2411)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_2411);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    // end procedure
    DeRef(_2411);
    DeRef(_2410);
    return 0;
    ;
}


int __stdcall
_1eu_poke4(int _id1, int _id2)
{
    int _2413 = 0;
    int _2412 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	poke4(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2412 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2412);
    _2 = (int)SEQ_PTR(_1data);
    _2413 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2413);
    if (IS_ATOM_INT(_2412))
        poke4_addr = (unsigned long *)_2412;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_2412)->dbl);
    if (IS_ATOM_INT(_2413)) {
        *poke4_addr = (unsigned long)_2413;
    }
    else if (IS_ATOM(_2413)) {
        *poke4_addr = (unsigned long)DBL_PTR(_2413)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_2413);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // end procedure
    DeRef(_2413);
    DeRef(_2412);
    return 0;
    ;
}


int __stdcall
_1eu_position(int _row, int _column)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_row)) {
        _1 = (long)(DBL_PTR(_row)->dbl);
        DeRefDS(_row);
        _row = _1;
    }
    if (!IS_ATOM_INT(_column)) {
        _1 = (long)(DBL_PTR(_column)->dbl);
        DeRefDS(_column);
        _column = _1;
    }

    // 	position(row, column)
    Position(_row, _column);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_power(int _id1, int _id2)
{
    int _2415 = 0;
    int _2414 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(power(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2414 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2414);
    _2 = (int)SEQ_PTR(_1data);
    _2415 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2415);
    _0 = _2415;
    if (IS_ATOM_INT(_2414) && IS_ATOM_INT(_2415)) {
        _2415 = power(_2414, _2415);
    }
    else {
        _2415 = binary_op(POWER, _2414, _2415);
    }
    DeRef(_0);
    Ref(_2415);
    _0 = _2415;
    _2415 = _1retval(_2415);
    DeRef(_0);
    DeRef(_2414);
    return _2415;
    ;
}


