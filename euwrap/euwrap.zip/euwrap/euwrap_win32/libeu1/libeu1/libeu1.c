// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_1get_version()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = VERSION
    _i = 1;

    // 	return i
    return 1;
    ;
}


int _1binary_search(int _needle, int _haystack)
{
    int _start_point;
    int _end_point;
    int _lo;
    int _hi;
    int _mid;
    int _c;
    int _317 = 0;
    int _311;
    int _0, _1, _2;
    

    // 	start_point = 1
    _start_point = 1;

    // 	end_point = 0
    _end_point = 0;

    // 	lo = start_point
    _lo = 1;

    // 	if end_point <= 0 then

    // 		hi = length(haystack) + end_point
    _311 = SEQ_PTR(_haystack)->length;
    _hi = _311 + 0;
    goto L1;
L2:

    // 		hi = end_point
    _hi = 0;
L1:

    // 	if lo<1 then
    if (_lo >= 1)
        goto L3;

    // 		lo=1
    _lo = 1;
L3:

    // 	if lo > hi and length(haystack) > 0 then
    _311 = (_lo > _hi);
    if (_311 == 0) {
        goto L4;
    }
    DeRef(_317);
    _317 = SEQ_PTR(_haystack)->length;
    _317 = (_317 > 0);
L5:
    if (_317 == 0)
        goto L4;

    // 		hi = length(haystack)
    _hi = SEQ_PTR(_haystack)->length;
L4:

    // 	mid = start_point
    _mid = 1;

    // 	c = 0
    _c = 0;

    // 	while lo <= hi do
L6:
    if (_lo > _hi)
        goto L7;

    // 		mid = floor((lo + hi) / 2)
    DeRef(_317);
    _317 = _lo + _hi;
    if ((long)((unsigned long)_317 + (unsigned long)HIGH_BITS) >= 0) 
        _317 = NewDouble((double)_317);
    if (IS_ATOM_INT(_317)) {
        _mid = _317 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _317, 2);
        _mid = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_mid)) {
        _1 = (long)(DBL_PTR(_mid)->dbl);
        DeRefDS(_mid);
        _mid = _1;
    }

    // 		c = compare(needle, haystack[mid])
    DeRef(_317);
    _2 = (int)SEQ_PTR(_haystack);
    _317 = (int)*(((s1_ptr)_2)->base + _mid);
    Ref(_317);
    if (IS_ATOM_INT(_needle) && IS_ATOM_INT(_317))
        _c = (_needle < _317) ? -1 : (_needle > _317);
    else
        _c = compare(_needle, _317);

    // 		if c < 0 then
    if (_c >= 0)
        goto L8;

    // 			hi = mid - 1
    _hi = _mid - 1;
    goto L6;
L8:

    // 		elsif c > 0 then
    if (_c <= 0)
        goto L9;

    // 			lo = mid + 1
    _lo = _mid + 1;
    goto L6;
L9:

    // 			return mid
    DeRef(_needle);
    DeRefDS(_haystack);
    DeRef(_317);
    return _mid;
LA:

    // 	end while
    goto L6;
L7:

    // 	if c > 0 then
    if (_c <= 0)
        goto LB;

    // 		mid += 1
    _mid = _mid + 1;
LB:

    // 	return -mid
    DeRef(_317);
    if (_mid == 0xC0000000)
        _317 = (int)NewDouble((double)-0xC0000000);
    else
        _317 = - _mid;
    DeRef(_needle);
    DeRefDS(_haystack);
    return _317;
    ;
}


int __stdcall
_1init()
{
    int _0, _1, _2;
    

    // 	high_address = 0
    _1high_address = 0;

    // 	data = {} -- objects
    RefDS(_112);
    DeRef(_1data);
    _1data = _112;

    // 	free_list = {} -- list of free "data" objects
    RefDS(_112);
    DeRef(_1free_list);
    _1free_list = _112;

    // end procedure
    return 0;
    ;
}


int __stdcall
_1get_high_address()
{
    int _0, _1, _2;
    

    // 	return high_address
    return _1high_address;
    ;
}


int _1set_high_address(int _ma)
{
    int _i;
    int _0, _1, _2;
    

    // 	high_address = floor( ma / #00010000 )
    if (IS_ATOM_INT(_ma)) {
        if (65536 > 0 && _ma >= 0) {
            _1high_address = _ma / 65536;
        }
        else {
            temp_dbl = floor((double)_ma / (double)65536);
            _1high_address = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma, 65536);
        _1high_address = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address)) {
        _1 = (long)(DBL_PTR(_1high_address)->dbl);
        DeRefDS(_1high_address);
        _1high_address = _1;
    }

    // 	i = and_bits( ma, #0000FFFF )
    if (IS_ATOM_INT(_ma)) {
        _i = (_ma & 65535);
    }
    else {
        temp_d.dbl = (double)65535;
        _i = Dand_bits(DBL_PTR(_ma), &temp_d);
    }
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	return i
    DeRef(_ma);
    return _i;
    ;
}


int _1get_address(int _low, int _high)
{
    int _336 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	return high * #00010000 + low
    _336 = NewDouble(_high * (double)65536);
    _0 = _336;
    if (IS_ATOM_INT(_336)) {
        _336 = _336 + _low;
        if ((long)((unsigned long)_336 + (unsigned long)HIGH_BITS) >= 0) 
            _336 = NewDouble((double)_336);
    }
    else {
        _336 = NewDouble(DBL_PTR(_336)->dbl + (double)_low);
    }
    DeRef(_0);
    return _336;
    ;
}


int _1register_data(int _ob)
{
    int _i;
    int _ret;
    int _a = 0;
    int _s = 0;
    int _338;
    int _0, _1, _2;
    

    // 	if length(free_list) then
    _338 = SEQ_PTR(_1free_list)->length;
    if (_338 == 0)
        goto L1;

    // 		ret = free_list[1]
    _2 = (int)SEQ_PTR(_1free_list);
    _ret = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_ret))
        _ret = (long)DBL_PTR(_ret)->dbl;

    // 		free_list = free_list[2..length(free_list)]
    _338 = SEQ_PTR(_1free_list)->length;
    rhs_slice_target = (object_ptr)&_1free_list;
    RHS_Slice((s1_ptr)_1free_list, 2, _338);

    // 		if integer(ob) then
    if (IS_ATOM_INT(_ob))
        _338 = 1;
    else if (IS_ATOM_DBL(_ob))
        _338 = IS_ATOM_INT(DoubleToInt(_ob));
    else
        _338 = 0;
    if (_338 == 0)
        goto L2;

    // 			i = ob
    Ref(_ob);
    _i = _ob;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 			data[ret] = i
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _i;
    DeRef(_1);
    goto L3;
L2:

    // 		elsif atom(ob) then
    _338 = IS_ATOM(_ob);
    if (_338 == 0)
        goto L4;

    // 			a = ob
    Ref(_ob);
    DeRef(_a);
    _a = _ob;

    // 			data[ret] = a
    Ref(_a);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _a;
    DeRef(_1);
    goto L3;
L4:

    // 			s = ob
    Ref(_ob);
    DeRef(_s);
    _s = _ob;

    // 			data[ret] = s
    RefDS(_s);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret);
    _1 = *(int *)_2;
    *(int *)_2 = _s;
    DeRef(_1);
L3:

    // 		return ret
    DeRef(_ob);
    DeRef(_a);
    DeRef(_s);
    return _ret;
L1:

    // 	if integer(ob) then
    if (IS_ATOM_INT(_ob))
        _338 = 1;
    else if (IS_ATOM_DBL(_ob))
        _338 = IS_ATOM_INT(DoubleToInt(_ob));
    else
        _338 = 0;
    if (_338 == 0)
        goto L5;

    // 		i = ob
    Ref(_ob);
    _i = _ob;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 		data = append(data, i)
    Append(&_1data, _1data, _i);
    goto L6;
L5:

    // 	elsif atom(ob) then
    _338 = IS_ATOM(_ob);
    if (_338 == 0)
        goto L7;

    // 		a = ob
    Ref(_ob);
    DeRef(_a);
    _a = _ob;

    // 		data = append(data, a)
    Ref(_a);
    Append(&_1data, _1data, _a);
    goto L6;
L7:

    // 		s = ob
    Ref(_ob);
    DeRef(_s);
    _s = _ob;

    // 		data = append(data, s)
    RefDS(_s);
    Append(&_1data, _1data, _s);
L6:

    // 	return length(data)
    _338 = SEQ_PTR(_1data)->length;
    DeRef(_ob);
    DeRef(_a);
    DeRef(_s);
    return _338;
    ;
}


int _1retval(int _ob)
{
    int _i;
    int _0, _1, _2;
    

    // 	i = register_data(ob)
    Ref(_ob);
    _i = _1register_data(_ob);

    // 	return i
    DeRef(_ob);
    return _i;
    ;
}


int __stdcall
_1length_of_data()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = length(data)
    _i = SEQ_PTR(_1data)->length;

    // 	return i
    return _i;
    ;
}


int __stdcall
_1is_free(int _id)
{
    int _i;
    int _352;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = find(id, free_list) and 1
    _352 = find(_id, _1free_list);
    _i = (_352 != 0 && 1 != 0);

    // 	return i
    return _i;
    ;
}


int __stdcall
_1access_free_list()
{
    int _i;
    int _ma = 0;
    int _354 = 0;
    int _0, _1, _2;
    

    // 	ma = 0
    _ma = 0;

    // 	if length(free_list) then
    _354 = SEQ_PTR(_1free_list)->length;
    if (_354 == 0)
        goto L1;

    // 		ma = allocate(length(free_list) * 4)
    _354 = SEQ_PTR(_1free_list)->length;
    if (_354 == (short)_354)
        _354 = _354 * 4;
    else
        _354 = NewDouble(_354 * (double)4);
    Ref(_354);
    _ma = _2allocate(_354);

    // 		poke4(ma, free_list)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    _1 = (int)SEQ_PTR(_1free_list);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
L1:

    // 	i = set_high_address(ma)
    Ref(_ma);
    _i = _1set_high_address(_ma);

    // 	return i
    DeRef(_ma);
    DeRef(_354);
    return _i;
    ;
}


int __stdcall
_1generic_free(int _low, int _high)
{
    int _ma = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	ma = get_address(low, high)
    _ma = _1get_address(_low, _high);

    // 	if ma then
    if (_ma == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_ma) && DBL_PTR(_ma)->dbl == 0.0)
            goto L1;
    }

    // 		free(ma)
    Ref(_ma);
    _2free(_ma);
L1:

    // end procedure
    DeRef(_ma);
    return 0;
    ;
}


int __stdcall
_1delete_linked_list(int _id)
{
    int _pos;
    int _365 = 0;
    int _366 = 0;
    int _360 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	pos = binary_search(id, free_list)
    RefDS(_1free_list);
    _pos = _1binary_search(_id, _1free_list);
    if (!IS_ATOM_INT(_pos)) {
        _1 = (long)(DBL_PTR(_pos)->dbl);
        DeRefDS(_pos);
        _pos = _1;
    }

    // 	if pos < 0 then -- if not in free_list, insert
    if (_pos >= 0)
        goto L1;

    // 		data[id] = {}
    RefDS(_112);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id);
    _1 = *(int *)_2;
    *(int *)_2 = _112;
    DeRef(_1);

    // 		pos = -pos
    _pos = - _pos;

    // 		free_list = free_list[1..pos-1] & {id} & free_list[pos..$]
    _360 = _pos - 1;
    rhs_slice_target = (object_ptr)&_360;
    RHS_Slice((s1_ptr)_1free_list, 1, _360);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _id;
    _365 = MAKE_SEQ(_1);
    _366 = SEQ_PTR(_1free_list)->length;
    rhs_slice_target = (object_ptr)&_366;
    RHS_Slice((s1_ptr)_1free_list, _pos, _366);
    {
        int concat_list[3];

        concat_list[0] = _366;
        concat_list[1] = _365;
        concat_list[2] = _360;
        Concat_N((object_ptr)&_1free_list, concat_list, 3);
    }

    // 		for i = length(free_list) to 1 by -1 do
    DeRefDS(_366);
    _366 = SEQ_PTR(_1free_list)->length;
    { int _i;
        _i = _366;
L2:
        if (_i < 1)
            goto L3;

        // 			if free_list[$] = length(data) then
        DeRef(_366);
        _366 = SEQ_PTR(_1free_list)->length;
        _2 = (int)SEQ_PTR(_1free_list);
        _366 = (int)*(((s1_ptr)_2)->base + _366);
        Ref(_366);
        DeRef(_365);
        _365 = SEQ_PTR(_1data)->length;
        if (binary_op_a(NOTEQ, _366, _365))
            goto L3;

        // 				data = data[1..$-1]
        _365 = SEQ_PTR(_1data)->length;
        _365 = _365 - 1;
        rhs_slice_target = (object_ptr)&_1data;
        RHS_Slice((s1_ptr)_1data, 1, _365);

        // 				free_list = free_list[1..$-1]
        _365 = SEQ_PTR(_1free_list)->length;
        _365 = _365 - 1;
        rhs_slice_target = (object_ptr)&_1free_list;
        RHS_Slice((s1_ptr)_1free_list, 1, _365);
        goto L4;
L5:

        // 				exit
        goto L3;
L4:

        // 		end for
        _i = _i + -1;
        goto L2;
L3:
        ;
    }
L1:

    // end procedure
    DeRef(_365);
    DeRef(_366);
    DeRef(_360);
    return 0;
    ;
}


int __stdcall
_1free_linked_lists(int _low, int _high, int _len)
{
    int _array = 0;
    int _ma = 0;
    int _385 = 0;
    int _381 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	ma = get_address(low, high)
    _ma = _1get_address(_low, _high);

    // 	array = peek4u({ma, len})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ma;
    Ref(_ma);
    ((int *)_2)[2] = _len;
    _381 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_381);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _array = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }

    // 	for i = 1 to length(array) do
    DeRefDS(_381);
    _381 = SEQ_PTR(_array)->length;
    { int _i;
        _i = 1;
L1:
        if (_i > _381)
            goto L2;

        // 		delete_linked_list(array[i])
        DeRef(_385);
        _2 = (int)SEQ_PTR(_array);
        _385 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_385);
        Ref(_385);
        _1delete_linked_list(_385);

        // 	end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRef(_array);
    DeRef(_ma);
    DeRef(_385);
    DeRef(_381);
    return 0;
    ;
}


int __stdcall
_1register_linked_list(int _low, int _high)
{
    int _i;
    int _386 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = register_data(linked_list_to_sequence(get_address(low, high)))
    _386 = _1get_address(_low, _high);
    Ref(_386);
    _0 = _386;
    _386 = _3linked_list_to_sequence(_386);
    DeRef(_0);
    Ref(_386);
    _i = _1register_data(_386);

    // 	return i
    DeRef(_386);
    return _i;
    ;
}


int __stdcall
_1new_linked_list(int _low, int _high)
{
    int _i;
    int _389 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = register_data(linked_list_to_sequence(get_address(low, high)))
    _389 = _1get_address(_low, _high);
    Ref(_389);
    _0 = _389;
    _389 = _3linked_list_to_sequence(_389);
    DeRef(_0);
    Ref(_389);
    _i = _1register_data(_389);

    // 	return i
    DeRef(_389);
    return _i;
    ;
}


int __stdcall
_1store_linked_list(int _id, int _low, int _high)
{
    int _392 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	data[id] = linked_list_to_sequence(get_address(low, high))
    _392 = _1get_address(_low, _high);
    Ref(_392);
    _0 = _392;
    _392 = _3linked_list_to_sequence(_392);
    DeRef(_0);
    Ref(_392);
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _id);
    _1 = *(int *)_2;
    *(int *)_2 = _392;
    DeRef(_1);

    // end procedure
    DeRef(_392);
    return 0;
    ;
}


int __stdcall
_1access_linked_list(int _id)
{
    int _i;
    int _394 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = set_high_address(sequence_to_linked_list(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _394 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_394);
    Ref(_394);
    _0 = _394;
    _394 = _3sequence_to_linked_list(_394);
    DeRef(_0);
    Ref(_394);
    _i = _1set_high_address(_394);

    // 	return i
    DeRef(_394);
    return _i;
    ;
}


int __stdcall
_1at_linked_list(int _id, int _index)
{
    int _i;
    int _397 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_index)) {
        _1 = (long)(DBL_PTR(_index)->dbl);
        DeRefDS(_index);
        _index = _1;
    }

    // 	i = set_high_address(sequence_to_linked_list(data[id][index]))
    _2 = (int)SEQ_PTR(_1data);
    _397 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_397);
    _0 = _397;
    _2 = (int)SEQ_PTR(_397);
    _397 = (int)*(((s1_ptr)_2)->base + _index);
    Ref(_397);
    DeRef(_0);
    Ref(_397);
    _0 = _397;
    _397 = _3sequence_to_linked_list(_397);
    DeRef(_0);
    Ref(_397);
    _i = _1set_high_address(_397);

    // 	return i
    DeRef(_397);
    return _i;
    ;
}


int __stdcall
_1free_linked_list_dll(int _low, int _high)
{
    int _401 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	free_linked_list(get_address(low, high))
    _401 = _1get_address(_low, _high);
    Ref(_401);
    _3free_linked_list(_401);

    // end procedure
    DeRef(_401);
    return 0;
    ;
}


int __stdcall
_1length_linked_list(int _id)
{
    int _i;
    int _402 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	if atom(data[id]) then
    _2 = (int)SEQ_PTR(_1data);
    _402 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_402);
    _0 = _402;
    _402 = IS_ATOM(_402);
    DeRef(_0);
    if (_402 == 0)
        goto L1;

    // 		i = -1
    _i = -1;
    goto L2;
L1:

    // 		i = length(data[id])
    DeRef(_402);
    _2 = (int)SEQ_PTR(_1data);
    _402 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_402);
    _i = SEQ_PTR(_402)->length;
L2:

    // 	return i
    DeRef(_402);
    return _i;
    ;
}


int __stdcall
_1store_at_linked_list(int _id, int _index, int _low, int _high)
{
    int _408 = 0;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_index)) {
        _1 = (long)(DBL_PTR(_index)->dbl);
        DeRefDS(_index);
        _index = _1;
    }
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	data[id][index] = linked_list_to_sequence(get_address(low, high))
    _2 = (int)SEQ_PTR(_1data);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _1data = MAKE_SEQ(_2);
    }
    _3 = (int)(_id + ((s1_ptr)_2)->base);
    _408 = _1get_address(_low, _high);
    Ref(_408);
    _0 = _408;
    _408 = _3linked_list_to_sequence(_408);
    DeRef(_0);
    Ref(_408);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index);
    _1 = *(int *)_2;
    *(int *)_2 = _408;
    DeRef(_1);

    // end procedure
    DeRef(_408);
    return 0;
    ;
}


int __stdcall
_1eu_repeat(int _id, int _len)
{
    int _410 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	return retval(repeat(data[id], len))
    _2 = (int)SEQ_PTR(_1data);
    _410 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_410);
    _0 = _410;
    _410 = Repeat(_410, _len);
    DeRef(_0);
    RefDS(_410);
    _0 = _410;
    _410 = _1retval(_410);
    DeRefDS(_0);
    return _410;
    ;
}


int __stdcall
_1eu_mem_set(int _low, int _high, int _byte_val, int _how_many)
{
    int _413 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_byte_val)) {
        _1 = (long)(DBL_PTR(_byte_val)->dbl);
        DeRefDS(_byte_val);
        _byte_val = _1;
    }
    if (!IS_ATOM_INT(_how_many)) {
        _1 = (long)(DBL_PTR(_how_many)->dbl);
        DeRefDS(_how_many);
        _how_many = _1;
    }

    // 	mem_set(get_address(low, high), byte_val, how_many)
    _413 = _1get_address(_low, _high);
    memory_set(_413, _byte_val, _how_many);

    // end procedure
    DeRef(_413);
    return 0;
    ;
}


int __stdcall
_1eu_mem_copy(int _dstlow, int _dsthigh, int _srclow, int _srchigh, int _len)
{
    int _415 = 0;
    int _414 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow)) {
        _1 = (long)(DBL_PTR(_dstlow)->dbl);
        DeRefDS(_dstlow);
        _dstlow = _1;
    }
    if (!IS_ATOM_INT(_dsthigh)) {
        _1 = (long)(DBL_PTR(_dsthigh)->dbl);
        DeRefDS(_dsthigh);
        _dsthigh = _1;
    }
    if (!IS_ATOM_INT(_srclow)) {
        _1 = (long)(DBL_PTR(_srclow)->dbl);
        DeRefDS(_srclow);
        _srclow = _1;
    }
    if (!IS_ATOM_INT(_srchigh)) {
        _1 = (long)(DBL_PTR(_srchigh)->dbl);
        DeRefDS(_srchigh);
        _srchigh = _1;
    }
    if (!IS_ATOM_INT(_len)) {
        _1 = (long)(DBL_PTR(_len)->dbl);
        DeRefDS(_len);
        _len = _1;
    }

    // 	mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)
    _414 = _1get_address(_dstlow, _dsthigh);
    _415 = _1get_address(_srclow, _srchigh);
    memory_copy(_414, _415, _len);

    // end procedure
    DeRef(_415);
    DeRef(_414);
    return 0;
    ;
}


int __stdcall
_1eu_add(int _id1, int _id2)
{
    int _417 = 0;
    int _416 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] + data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _416 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_416);
    _2 = (int)SEQ_PTR(_1data);
    _417 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_417);
    _0 = _417;
    if (IS_ATOM_INT(_416) && IS_ATOM_INT(_417)) {
        _417 = _416 + _417;
        if ((long)((unsigned long)_417 + (unsigned long)HIGH_BITS) >= 0) 
            _417 = NewDouble((double)_417);
    }
    else {
        _417 = binary_op(PLUS, _416, _417);
    }
    DeRef(_0);
    Ref(_417);
    _0 = _417;
    _417 = _1retval(_417);
    DeRef(_0);
    DeRef(_416);
    return _417;
    ;
}


int __stdcall
_1eu_subtract(int _id1, int _id2)
{
    int _421 = 0;
    int _420 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] - data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _420 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_420);
    _2 = (int)SEQ_PTR(_1data);
    _421 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_421);
    _0 = _421;
    if (IS_ATOM_INT(_420) && IS_ATOM_INT(_421)) {
        _421 = _420 - _421;
        if ((long)((unsigned long)_421 +(unsigned long) HIGH_BITS) >= 0)
            _421 = NewDouble((double)_421);
    }
    else {
        _421 = binary_op(MINUS, _420, _421);
    }
    DeRef(_0);
    Ref(_421);
    _0 = _421;
    _421 = _1retval(_421);
    DeRef(_0);
    DeRef(_420);
    return _421;
    ;
}


int __stdcall
_1eu_multiply(int _id1, int _id2)
{
    int _425 = 0;
    int _424 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] * data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _424 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_424);
    _2 = (int)SEQ_PTR(_1data);
    _425 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_425);
    _0 = _425;
    if (IS_ATOM_INT(_424) && IS_ATOM_INT(_425)) {
        if (_424 == (short)_424 && _425 <= INT15 && _425 >= -INT15)
            _425 = _424 * _425;
        else
            _425 = NewDouble(_424 * (double)_425);
    }
    else {
        _425 = binary_op(MULTIPLY, _424, _425);
    }
    DeRef(_0);
    Ref(_425);
    _0 = _425;
    _425 = _1retval(_425);
    DeRef(_0);
    DeRef(_424);
    return _425;
    ;
}


int __stdcall
_1eu_divide(int _id1, int _id2)
{
    int _429 = 0;
    int _428 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] / data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _428 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_428);
    _2 = (int)SEQ_PTR(_1data);
    _429 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_429);
    _0 = _429;
    if (IS_ATOM_INT(_428) && IS_ATOM_INT(_429)) {
        _429 = (_428 % _429) ? NewDouble((double)_428 / _429) : (_428 / _429);
    }
    else {
        _429 = binary_op(DIVIDE, _428, _429);
    }
    DeRef(_0);
    Ref(_429);
    _0 = _429;
    _429 = _1retval(_429);
    DeRef(_0);
    DeRef(_428);
    return _429;
    ;
}


int __stdcall
_1eu_negate(int _id)
{
    int _432 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(-data[id])
    _2 = (int)SEQ_PTR(_1data);
    _432 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_432);
    _0 = _432;
    if (IS_ATOM_INT(_432)) {
        if (_432 == 0xC0000000)
            _432 = (int)NewDouble((double)-0xC0000000);
        else
            _432 = - _432;
    }
    else {
        _432 = unary_op(UMINUS, _432);
    }
    DeRef(_0);
    Ref(_432);
    _0 = _432;
    _432 = _1retval(_432);
    DeRef(_0);
    return _432;
    ;
}


int __stdcall
_1eu_not(int _id)
{
    int _435 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(not data[id])
    _2 = (int)SEQ_PTR(_1data);
    _435 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_435);
    _0 = _435;
    if (IS_ATOM_INT(_435)) {
        _435 = (_435 == 0);
    }
    else {
        _435 = unary_op(NOT, _435);
    }
    DeRef(_0);
    Ref(_435);
    _0 = _435;
    _435 = _1retval(_435);
    DeRef(_0);
    return _435;
    ;
}


int __stdcall
_1eu_equals(int _id1, int _id2)
{
    int _439 = 0;
    int _438 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] = data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _438 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_438);
    _2 = (int)SEQ_PTR(_1data);
    _439 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_439);
    _0 = _439;
    if (IS_ATOM_INT(_438) && IS_ATOM_INT(_439)) {
        _439 = (_438 == _439);
    }
    else {
        _439 = binary_op(EQUALS, _438, _439);
    }
    DeRef(_0);
    Ref(_439);
    _0 = _439;
    _439 = _1retval(_439);
    DeRef(_0);
    DeRef(_438);
    return _439;
    ;
}


int __stdcall
_1eu_and(int _id1, int _id2)
{
    int _443 = 0;
    int _442 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] and data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _442 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_442);
    _2 = (int)SEQ_PTR(_1data);
    _443 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_443);
    _0 = _443;
    if (IS_ATOM_INT(_442) && IS_ATOM_INT(_443)) {
        _443 = (_442 != 0 && _443 != 0);
    }
    else {
        _443 = binary_op(AND, _442, _443);
    }
    DeRef(_0);
    Ref(_443);
    _0 = _443;
    _443 = _1retval(_443);
    DeRef(_0);
    DeRef(_442);
    return _443;
    ;
}


int __stdcall
_1eu_or(int _id1, int _id2)
{
    int _447 = 0;
    int _446 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] or data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _446 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_446);
    _2 = (int)SEQ_PTR(_1data);
    _447 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_447);
    _0 = _447;
    if (IS_ATOM_INT(_446) && IS_ATOM_INT(_447)) {
        _447 = (_446 != 0 || _447 != 0);
    }
    else {
        _447 = binary_op(OR, _446, _447);
    }
    DeRef(_0);
    Ref(_447);
    _0 = _447;
    _447 = _1retval(_447);
    DeRef(_0);
    DeRef(_446);
    return _447;
    ;
}


int __stdcall
_1eu_xor(int _id1, int _id2)
{
    int _451 = 0;
    int _450 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] xor data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _450 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_450);
    _2 = (int)SEQ_PTR(_1data);
    _451 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_451);
    _0 = _451;
    if (IS_ATOM_INT(_450) && IS_ATOM_INT(_451)) {
        _451 = ((_450 != 0) != (_451 != 0));
    }
    else {
        _451 = binary_op(XOR, _450, _451);
    }
    DeRef(_0);
    Ref(_451);
    _0 = _451;
    _451 = _1retval(_451);
    DeRef(_0);
    DeRef(_450);
    return _451;
    ;
}


int __stdcall
_1eu_question_mark(int _id)
{
    int _454 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	? data[id]
    _2 = (int)SEQ_PTR(_1data);
    _454 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_454);
    StdPrint(1, _454, 1);

    // end procedure
    DeRef(_454);
    return 0;
    ;
}


int __stdcall
_1eu_abort(int _ret)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret)) {
        _1 = (long)(DBL_PTR(_ret)->dbl);
        DeRefDS(_ret);
        _ret = _1;
    }

    // 	abort(ret)
    UserCleanup(_ret);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_and_bits(int _id1, int _id2)
{
    int _456 = 0;
    int _455 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(and_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _455 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_455);
    _2 = (int)SEQ_PTR(_1data);
    _456 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_456);
    _0 = _456;
    if (IS_ATOM_INT(_455) && IS_ATOM_INT(_456)) {
        _456 = (_455 & _456);
    }
    else {
        _456 = binary_op(AND_BITS, _455, _456);
    }
    DeRef(_0);
    Ref(_456);
    _0 = _456;
    _456 = _1retval(_456);
    DeRef(_0);
    DeRef(_455);
    return _456;
    ;
}


int __stdcall
_1eu_append(int _id1, int _id2)
{
    int _460 = 0;
    int _459 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(append(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _459 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_459);
    _2 = (int)SEQ_PTR(_1data);
    _460 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_460);
    Ref(_460);
    Append(&_460, _459, _460);
    RefDS(_460);
    _0 = _460;
    _460 = _1retval(_460);
    DeRefDS(_0);
    DeRef(_459);
    return _460;
    ;
}


int __stdcall
_1eu_arctan(int _id)
{
    int _463 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(arctan(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _463 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_463);
    _0 = _463;
    if (IS_ATOM_INT(_463))
        _463 = e_arctan(_463);
    else
        _463 = unary_op(ARCTAN, _463);
    DeRef(_0);
    Ref(_463);
    _0 = _463;
    _463 = _1retval(_463);
    DeRef(_0);
    return _463;
    ;
}


int __stdcall
_1eu_atom(int _id)
{
    int _466 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return atom(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _466 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_466);
    _0 = _466;
    _466 = IS_ATOM(_466);
    DeRef(_0);
    return _466;
    ;
}


int __stdcall
_1eu_c_func(int _rid, int _id1)
{
    int _468 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(c_func(rid, data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _468 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_468);
    _0 = _468;
    _468 = call_c(1, _rid, _468);
    DeRef(_0);
    Ref(_468);
    _0 = _468;
    _468 = _1retval(_468);
    DeRef(_0);
    return _468;
    ;
}


int __stdcall
_1eu_c_proc(int _rid, int _id1)
{
    int _471 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	c_proc(rid, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _471 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_471);
    call_c(0, _rid, _471);

    // end procedure
    DeRef(_471);
    return 0;
    ;
}


int __stdcall
_1eu_call(int _low, int _high)
{
    int _472 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	call(get_address(low, high))
    _472 = _1get_address(_low, _high);
    if (IS_ATOM_INT(_472))
        _0 = (int)_472;
    else
        _0 = (int)(unsigned long)(DBL_PTR(_472)->dbl);
    (*(void(*)())_0)();

    // end procedure
    DeRef(_472);
    return 0;
    ;
}


int __stdcall
_1eu_clear_screen()
{
    int _0, _1, _2;
    

    // 	clear_screen()
    ClearScreen();

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_close(int _fn_id)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	close(fn_id)
    EClose(_fn_id);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_command_line()
{
    int _473 = 0;
    int _0, _1, _2;
    

    // 	return retval(command_line())
    _473 = Command_Line();
    RefDS(_473);
    _0 = _473;
    _473 = _1retval(_473);
    DeRefDS(_0);
    return _473;
    ;
}


int __stdcall
_1eu_compare(int _id1, int _id2)
{
    int _476 = 0;
    int _475 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return compare(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _475 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_475);
    _2 = (int)SEQ_PTR(_1data);
    _476 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_476);
    _0 = _476;
    if (IS_ATOM_INT(_475) && IS_ATOM_INT(_476))
        _476 = (_475 < _476) ? -1 : (_475 > _476);
    else
        _476 = compare(_475, _476);
    DeRef(_0);
    DeRef(_475);
    return _476;
    ;
}


int __stdcall
_1eu_concat(int _id1, int _id2)
{
    int _479 = 0;
    int _478 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(data[id1] & data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _478 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_478);
    _2 = (int)SEQ_PTR(_1data);
    _479 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_479);
    if (IS_SEQUENCE(_478) && IS_ATOM(_479)) {
        Ref(_479);
        Append(&_479, _478, _479);
    }
    else if (IS_ATOM(_478) && IS_SEQUENCE(_479)) {
        Ref(_478);
        Prepend(&_479, _479, _478);
    }
    else {
        Concat((object_ptr)&_479, _478, (s1_ptr)_479);
    }
    RefDS(_479);
    _0 = _479;
    _479 = _1retval(_479);
    DeRefDS(_0);
    DeRef(_478);
    return _479;
    ;
}


int __stdcall
_1eu_cos(int _id)
{
    int _482 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(cos(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _482 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_482);
    _0 = _482;
    if (IS_ATOM_INT(_482))
        _482 = e_cos(_482);
    else
        _482 = unary_op(COS, _482);
    DeRef(_0);
    Ref(_482);
    _0 = _482;
    _482 = _1retval(_482);
    DeRef(_0);
    return _482;
    ;
}


int __stdcall
_1eu_date()
{
    int _485 = 0;
    int _0, _1, _2;
    

    // 	return retval(date())
    _485 = Date();
    RefDS(_485);
    _0 = _485;
    _485 = _1retval(_485);
    DeRefDSi(_0);
    return _485;
    ;
}


int __stdcall
_1eu_equal(int _id1, int _id2)
{
    int _488 = 0;
    int _487 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return equal(data[id1], data[id2]) -- boolean, returns 0 or 1
    _2 = (int)SEQ_PTR(_1data);
    _487 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_487);
    _2 = (int)SEQ_PTR(_1data);
    _488 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_488);
    _0 = _488;
    if (_487 == _488)
        _488 = 1;
    else if (IS_ATOM_INT(_487) && IS_ATOM_INT(_488))
        _488 = 0;
    else
        _488 = (compare(_487, _488) == 0);
    DeRef(_0);
    DeRef(_487);
    return _488;
    ;
}


int __stdcall
_1eu_find_from(int _id1, int _id2, int _start)
{
    int _491 = 0;
    int _490 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }

    // 	return find_from(data[id1], data[id2], start) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _490 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_490);
    _2 = (int)SEQ_PTR(_1data);
    _491 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_491);
    _0 = _491;
    _491 = find_from(_490, _491, _start);
    DeRef(_0);
    DeRef(_490);
    return _491;
    ;
}


int __stdcall
_1eu_floor(int _id1)
{
    int _493 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(floor(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _493 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_493);
    _0 = _493;
    if (IS_ATOM_INT(_493))
        _493 = e_floor(_493);
    else
        _493 = unary_op(FLOOR, _493);
    DeRef(_0);
    Ref(_493);
    _0 = _493;
    _493 = _1retval(_493);
    DeRef(_0);
    return _493;
    ;
}


int __stdcall
_1eu_integer_division(int _id1, int _id2)
{
    int _497 = 0;
    int _496 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(floor(data[id1] / data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _496 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_496);
    _2 = (int)SEQ_PTR(_1data);
    _497 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_497);
    _0 = _497;
    if (IS_ATOM_INT(_496) && IS_ATOM_INT(_497)) {
        if (_497 > 0 && _496 >= 0) {
            _497 = _496 / _497;
        }
        else {
            temp_dbl = floor((double)_496 / (double)_497);
            if (_496 != MININT)
                _497 = (long)temp_dbl;
            else
                _497 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _496, _497);
        _497 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);
    Ref(_497);
    _0 = _497;
    _497 = _1retval(_497);
    DeRef(_0);
    DeRef(_496);
    return _497;
    ;
}


int __stdcall
_1eu_get_key()
{
    int _500;
    int _0, _1, _2;
    

    // 	return get_key() -- returns an integer
    show_console();
    _500 = get_key(0);
    return _500;
    ;
}


int __stdcall
_1eu_getc(int _fn_id)
{
    int _501;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	return getc(fn_id) -- returns a character or byte
    if (_fn_id != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id, EF_READ);
        last_r_file_no = _fn_id;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _501 = wingetch();
        }
        else
            _501 = getc(last_r_file_ptr);
    }
    else
        _501 = getc(last_r_file_ptr);
    return _501;
    ;
}


int __stdcall
_1eu_getenv(int _id1)
{
    int _502 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(getenv(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _502 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_502);
    DeRef(_502);
    _502 = EGetEnv(_502);
    Ref(_502);
    _0 = _502;
    _502 = _1retval(_502);
    DeRefi(_0);
    return _502;
    ;
}


int __stdcall
_1eu_gets(int _fn_id)
{
    int _505 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	return retval(gets(fn_id))
    _505 = EGets(_fn_id);
    Ref(_505);
    _0 = _505;
    _505 = _1retval(_505);
    DeRefi(_0);
    return _505;
    ;
}


int __stdcall
_1eu_integer(int _id)
{
    int _507 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return integer(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _507 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_507);
    _0 = _507;
    if (IS_ATOM_INT(_507))
        _507 = 1;
    else if (IS_ATOM_DBL(_507))
        _507 = IS_ATOM_INT(DoubleToInt(_507));
    else
        _507 = 0;
    DeRef(_0);
    return _507;
    ;
}


int __stdcall
_1eu_length(int _id)
{
    int _509 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return length(data[id]) -- small integer
    _2 = (int)SEQ_PTR(_1data);
    _509 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_509);
    _0 = _509;
    _509 = SEQ_PTR(_509)->length;
    DeRef(_0);
    return _509;
    ;
}


int __stdcall
_1eu_log(int _id)
{
    int _511 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(log(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _511 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_511);
    _0 = _511;
    if (IS_ATOM_INT(_511))
        _511 = e_log(_511);
    else
        _511 = unary_op(LOG, _511);
    DeRef(_0);
    Ref(_511);
    _0 = _511;
    _511 = _1retval(_511);
    DeRef(_0);
    return _511;
    ;
}


int __stdcall
_1eu_machine_func(int _machine_id, int _id1)
{
    int _514 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id)) {
        _1 = (long)(DBL_PTR(_machine_id)->dbl);
        DeRefDS(_machine_id);
        _machine_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(machine_func(machine_id, data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _514 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_514);
    _0 = _514;
    _514 = machine(_machine_id, _514);
    DeRef(_0);
    Ref(_514);
    _0 = _514;
    _514 = _1retval(_514);
    DeRef(_0);
    return _514;
    ;
}


int __stdcall
_1eu_machine_proc(int _machine_id, int _id1)
{
    int _517 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id)) {
        _1 = (long)(DBL_PTR(_machine_id)->dbl);
        DeRefDS(_machine_id);
        _machine_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	machine_proc(machine_id, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _517 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_517);
    machine(_machine_id, _517);

    // end procedure
    DeRef(_517);
    return 0;
    ;
}


int __stdcall
_1eu_match_from(int _id1, int _id2, int _start)
{
    int _519 = 0;
    int _518 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }

    // 	return match_from(data[id1], data[id2], start) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _518 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_518);
    _2 = (int)SEQ_PTR(_1data);
    _519 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_519);
    _0 = _519;
    _519 = e_match_from(_518, _519, _start);
    DeRef(_0);
    DeRef(_518);
    return _519;
    ;
}


int __stdcall
_1eu_not_bits(int _id1)
{
    int _521 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(not_bits(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _521 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_521);
    _0 = _521;
    if (IS_ATOM_INT(_521))
        _521 = not_bits(_521);
    else
        _521 = unary_op(NOT_BITS, _521);
    DeRef(_0);
    Ref(_521);
    _0 = _521;
    _521 = _1retval(_521);
    DeRef(_0);
    return _521;
    ;
}


int __stdcall
_1eu_object(int _id)
{
    int _524;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return not find(id, free_list)
    _524 = find(_id, _1free_list);
    _524 = (_524 == 0);
    return _524;
    ;
}


int __stdcall
_1eu_open(int _id1, int _id2)
{
    int _527 = 0;
    int _526 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return open(data[id1], data[id2]) -- returns a small integer
    _2 = (int)SEQ_PTR(_1data);
    _526 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_526);
    _2 = (int)SEQ_PTR(_1data);
    _527 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_527);
    _0 = _527;
    _527 = EOpen(_526, _527);
    DeRef(_0);
    DeRef(_526);
    return _527;
    ;
}


int __stdcall
_1eu_open_str(int _low, int _high, int _did)
{
    int _531 = 0;
    int _529 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return open(peek_string(get_address(low, high)), data[did])
    _529 = _1get_address(_low, _high);
    Ref(_529);
    _0 = _529;
    _529 = _3peek_string(_529);
    DeRef(_0);
    _2 = (int)SEQ_PTR(_1data);
    _531 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_531);
    _0 = _531;
    _531 = EOpen(_529, _531);
    DeRef(_0);
    DeRefDSi(_529);
    return _531;
    ;
}


int __stdcall
_1eu_or_bits(int _id1, int _id2)
{
    int _534 = 0;
    int _533 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(or_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _533 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_533);
    _2 = (int)SEQ_PTR(_1data);
    _534 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_534);
    _0 = _534;
    if (IS_ATOM_INT(_533) && IS_ATOM_INT(_534)) {
        _534 = (_533 | _534);
    }
    else {
        _534 = binary_op(OR_BITS, _533, _534);
    }
    DeRef(_0);
    Ref(_534);
    _0 = _534;
    _534 = _1retval(_534);
    DeRef(_0);
    DeRef(_533);
    return _534;
    ;
}


int __stdcall
_1eu_peek(int _id1)
{
    int _537 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _537 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_537);
    _0 = _537;
    if (IS_ATOM_INT(_537)) {
        _537 = *(unsigned char *)_537;
    }
    else if (IS_ATOM(_537)) {
        _537 = *(unsigned char *)(unsigned long)(DBL_PTR(_537)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_537);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _537 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
    }
    DeRef(_0);
    Ref(_537);
    _0 = _537;
    _537 = _1retval(_537);
    DeRef(_0);
    return _537;
    ;
}


int __stdcall
_1eu_peek4s(int _id1)
{
    int _540 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek4s(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _540 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_540);
    _0 = _540;
    if (IS_ATOM_INT(_540)) {
        _540 = *(unsigned long *)_540;
        if (_540 < MININT || _540 > MAXINT)
            _540 = NewDouble((double)(long)_540);
    }
    else if (IS_ATOM(_540)) {
        _540 = *(unsigned long *)(unsigned long)(DBL_PTR(_540)->dbl);
        if (_540 < MININT || _540 > MAXINT)
            _540 = NewDouble((double)(long)_540);
    }
    else {
        _1 = (int)SEQ_PTR(_540);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _540 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
                _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    DeRef(_0);
    Ref(_540);
    _0 = _540;
    _540 = _1retval(_540);
    DeRef(_0);
    return _540;
    ;
}


int __stdcall
_1eu_peek4u(int _id1)
{
    int _543 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(peek4u(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _543 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_543);
    _0 = _543;
    if (IS_ATOM_INT(_543)) {
        _543 = *(unsigned long *)_543;
        if ((unsigned)_543 > (unsigned)MAXINT)
            _543 = NewDouble((double)(unsigned long)_543);
    }
    else if (IS_ATOM(_543)) {
        _543 = *(unsigned long *)(unsigned long)(DBL_PTR(_543)->dbl);
        if ((unsigned)_543 > (unsigned)MAXINT)
            _543 = NewDouble((double)(unsigned long)_543);
    }
    else {
        _1 = (int)SEQ_PTR(_543);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _543 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
                _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    DeRef(_0);
    Ref(_543);
    _0 = _543;
    _543 = _1retval(_543);
    DeRef(_0);
    return _543;
    ;
}


int __stdcall
_1eu_platform()
{
    int _0, _1, _2;
    

    // 	return platform() -- returns an integer
    return 2;
    ;
}


int __stdcall
_1eu_poke(int _id1, int _id2)
{
    int _547 = 0;
    int _546 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	poke(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _546 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_546);
    _2 = (int)SEQ_PTR(_1data);
    _547 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_547);
    if (IS_ATOM_INT(_546))
        poke_addr = (unsigned char *)_546;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_546)->dbl);
    if (IS_ATOM_INT(_547)) {
        *poke_addr = (unsigned char)_547;
    }
    else if (IS_ATOM(_547)) {
        *poke_addr = (signed char)DBL_PTR(_547)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_547);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    // end procedure
    DeRef(_547);
    DeRef(_546);
    return 0;
    ;
}


int __stdcall
_1eu_poke4(int _id1, int _id2)
{
    int _549 = 0;
    int _548 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	poke4(data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _548 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_548);
    _2 = (int)SEQ_PTR(_1data);
    _549 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_549);
    if (IS_ATOM_INT(_548))
        poke4_addr = (unsigned long *)_548;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_548)->dbl);
    if (IS_ATOM_INT(_549)) {
        *poke4_addr = (unsigned long)_549;
    }
    else if (IS_ATOM(_549)) {
        *poke4_addr = (unsigned long)DBL_PTR(_549)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_549);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // end procedure
    DeRef(_549);
    DeRef(_548);
    return 0;
    ;
}


int __stdcall
_1eu_position(int _row, int _column)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_row)) {
        _1 = (long)(DBL_PTR(_row)->dbl);
        DeRefDS(_row);
        _row = _1;
    }
    if (!IS_ATOM_INT(_column)) {
        _1 = (long)(DBL_PTR(_column)->dbl);
        DeRefDS(_column);
        _column = _1;
    }

    // 	position(row, column)
    Position(_row, _column);

    // end procedure
    return 0;
    ;
}


int __stdcall
_1eu_power(int _id1, int _id2)
{
    int _551 = 0;
    int _550 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(power(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _550 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_550);
    _2 = (int)SEQ_PTR(_1data);
    _551 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_551);
    _0 = _551;
    if (IS_ATOM_INT(_550) && IS_ATOM_INT(_551)) {
        _551 = power(_550, _551);
    }
    else {
        _551 = binary_op(POWER, _550, _551);
    }
    DeRef(_0);
    Ref(_551);
    _0 = _551;
    _551 = _1retval(_551);
    DeRef(_0);
    DeRef(_550);
    return _551;
    ;
}


