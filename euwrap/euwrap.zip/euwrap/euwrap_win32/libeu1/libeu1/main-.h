extern int _112;
extern int _138;
extern int _139;
extern int _141;
extern int _144;
extern int _148;
extern int _149;
extern int _150;
extern int _151;
extern int _152;
extern int Argc;
extern char **Argv;
extern unsigned long *peek4_addr;
extern unsigned char *poke_addr;
extern unsigned long *poke4_addr;
extern struct d temp_d;
extern double temp_dbl;
extern char *stack_base;
extern int total_stack_size;
extern int _2MAX_ADDR;
extern int _2LOW_ADDR;
extern int _2mem;
extern int _2check_calls;
extern int _3always_linked_list;
extern int _3SIGN_MASK;
extern int _3SIGN_FLAG;
extern int _3DOUBLE_FLAG;
extern int _3INT_FLAG;
extern int _3UINT_FLAG;
extern int _3FLOAT_FLAG;
extern int _3CSTRING;
extern int _3CBYTES;
extern int _1high_address;
extern int _1data;
extern int _1free_list;

extern struct routine_list _00[];
int __stdcall
_2allocate(int);
int __stdcall
_2free(int);
int __stdcall
_2allocate_low(int);
int __stdcall
_2free_low(int);
int __stdcall
_2dos_interrupt(int, int);
int __stdcall
_2int_to_bytes(int);
int __stdcall
_2bytes_to_int(int);
int __stdcall
_2int_to_bits(int, int);
int __stdcall
_2bits_to_int(int);
int __stdcall
_2set_rand(int);
int __stdcall
_2use_vesa(int);
int __stdcall
_2crash_message(int);
int __stdcall
_2crash_file(int);
int __stdcall
_2crash_routine(int);
int __stdcall
_2tick_rate(int);
int __stdcall
_2get_vector(int);
int __stdcall
_2set_vector(int, int);
int __stdcall
_2lock_memory(int, int);
int __stdcall
_2atom_to_float64(int);
int __stdcall
_2atom_to_float32(int);
int __stdcall
_2float64_to_atom(int);
int __stdcall
_2float32_to_atom(int);
int __stdcall
_2allocate_string(int);
int __stdcall
_2register_block(int, int);
int __stdcall
_2unregister_block(int);
int __stdcall
_2check_all_blocks();
int __stdcall
_3set_return_linked_list(int);
int __stdcall
_3get_return_linked_list();
int __stdcall
_3peek_string(int);
int __stdcall
_3mystring(int);
int __stdcall
_3myarray(int);
int __stdcall
_3sequence_to_linked_list(int);
int __stdcall
_3free_linked_list(int);
int __stdcall
_3linked_list_to_sequence(int);
int __stdcall
_1get_version();
int _1binary_search(int, int);
int __stdcall
_1init();
int __stdcall
_1get_high_address();
int _1set_high_address(int);
int _1get_address(int, int);
int _1register_data(int);
int _1retval(int);
int __stdcall
_1length_of_data();
int __stdcall
_1is_free(int);
int __stdcall
_1access_free_list();
int __stdcall
_1generic_free(int, int);
int __stdcall
_1delete_linked_list(int);
int __stdcall
_1free_linked_lists(int, int, int);
int __stdcall
_1register_linked_list(int, int);
int __stdcall
_1new_linked_list(int, int);
int __stdcall
_1store_linked_list(int, int, int);
int __stdcall
_1access_linked_list(int);
int __stdcall
_1at_linked_list(int, int);
int __stdcall
_1free_linked_list_dll(int, int);
int __stdcall
_1length_linked_list(int);
int __stdcall
_1store_at_linked_list(int, int, int, int);
int __stdcall
_1eu_repeat(int, int);
int __stdcall
_1eu_mem_set(int, int, int, int);
int __stdcall
_1eu_mem_copy(int, int, int, int, int);
int __stdcall
_1eu_add(int, int);
int __stdcall
_1eu_subtract(int, int);
int __stdcall
_1eu_multiply(int, int);
int __stdcall
_1eu_divide(int, int);
int __stdcall
_1eu_negate(int);
int __stdcall
_1eu_not(int);
int __stdcall
_1eu_equals(int, int);
int __stdcall
_1eu_and(int, int);
int __stdcall
_1eu_or(int, int);
int __stdcall
_1eu_xor(int, int);
int __stdcall
_1eu_question_mark(int);
int __stdcall
_1eu_abort(int);
int __stdcall
_1eu_and_bits(int, int);
int __stdcall
_1eu_append(int, int);
int __stdcall
_1eu_arctan(int);
int __stdcall
_1eu_atom(int);
int __stdcall
_1eu_c_func(int, int);
int __stdcall
_1eu_c_proc(int, int);
int __stdcall
_1eu_call(int, int);
int __stdcall
_1eu_clear_screen();
int __stdcall
_1eu_close(int);
int __stdcall
_1eu_command_line();
int __stdcall
_1eu_compare(int, int);
int __stdcall
_1eu_concat(int, int);
int __stdcall
_1eu_cos(int);
int __stdcall
_1eu_date();
int __stdcall
_1eu_equal(int, int);
int __stdcall
_1eu_find_from(int, int, int);
int __stdcall
_1eu_floor(int);
int __stdcall
_1eu_integer_division(int, int);
int __stdcall
_1eu_get_key();
int __stdcall
_1eu_getc(int);
int __stdcall
_1eu_getenv(int);
int __stdcall
_1eu_gets(int);
int __stdcall
_1eu_integer(int);
int __stdcall
_1eu_length(int);
int __stdcall
_1eu_log(int);
int __stdcall
_1eu_machine_func(int, int);
int __stdcall
_1eu_machine_proc(int, int);
int __stdcall
_1eu_match_from(int, int, int);
int __stdcall
_1eu_not_bits(int);
int __stdcall
_1eu_object(int);
int __stdcall
_1eu_open(int, int);
int __stdcall
_1eu_open_str(int, int, int);
int __stdcall
_1eu_or_bits(int, int);
int __stdcall
_1eu_peek(int);
int __stdcall
_1eu_peek4s(int);
int __stdcall
_1eu_peek4u(int);
int __stdcall
_1eu_platform();
int __stdcall
_1eu_poke(int, int);
int __stdcall
_1eu_poke4(int, int);
int __stdcall
_1eu_position(int, int);
int __stdcall
_1eu_power(int, int);
int __stdcall
_1eu_prepend(int, int);
int __stdcall
_1eu_print(int, int);
int __stdcall
_1eu_printf(int, int, int);
int __stdcall
_1eu_puts(int, int);
int __stdcall
_1eu_rand(int);
int __stdcall
_1eu_remainder(int, int);
int __stdcall
_1eu_sequence(int);
int __stdcall
_1eu_sin(int);
int __stdcall
_1eu_sprintf(int, int);
int __stdcall
_1eu_sqrt(int);
int __stdcall
_1eu_subscript(int, int, int);
int __stdcall
_1eu_system(int, int);
int __stdcall
_1eu_system_exec(int, int);
int __stdcall
_1eu_tan(int);
int __stdcall
_1eu_time();
int __stdcall
_1eu_xor_bits(int, int);
int __stdcall
_1eu_call_func_std(int, int);
int __stdcall
_1eu_call_func_val(int, int);
int __stdcall
_1eu_call_func(int, int);
int __stdcall
_1eu_call_proc(int, int);
int __stdcall
_1eu_routine_id(int);
int __stdcall
_1eu_routine_id_str(int, int);
extern struct ns_list _01[];
extern int TraceOn;
extern object_ptr rhs_slice_target;
extern s1_ptr *assign_slice_seq;
extern object last_r_file_no;
extern void *last_r_file_ptr;
extern int in_from_keyb;
extern void *xstdin;
extern struct tcb *tcb;
extern int current_task;
extern void *winInstance;

