// Euphoria To C version 3.1.1
#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int __stdcall
_3set_return_linked_list(int _i)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	always_linked_list = i
    _3always_linked_list = _i;

    // end procedure
    return 0;
    ;
}


int __stdcall
_3get_return_linked_list()
{
    int _0, _1, _2;
    

    // 	return always_linked_list
    return _3always_linked_list;
    ;
}


int __stdcall
_3peek_string(int _ma)
{
    int _ch;
    int _s = 0;
    int _0, _1, _2;
    

    // 	s = {}
    RefDS(_112);
    _s = _112;

    // 	while 1 do
L1:

    // 		ch = peek(ma)
    if (IS_ATOM_INT(_ma)) {
        _ch = *(unsigned char *)_ma;
    }
    else {
        _ch = *(unsigned char *)(unsigned long)(DBL_PTR(_ma)->dbl);
    }

    // 		if ch = 0 then
    if (_ch != 0)
        goto L2;

    // 			exit
    goto L3;
L2:

    // 		s = append(s, ch)
    Append(&_s, _s, _ch);

    // 		ma += 1
    _0 = _ma;
    if (IS_ATOM_INT(_ma)) {
        _ma = _ma + 1;
        if (_ma > MAXINT)
            _ma = NewDouble((double)_ma);
    }
    else
        _ma = binary_op(PLUS, 1, _ma);
    DeRef(_0);

    // 	end while
    goto L1;
L3:

    // 	return s
    DeRef(_ma);
    return _s;
    ;
}


int __stdcall
_3mystring(int _x)
{
    int _flag;
    int _i;
    int _ob = 0;
    int _120;
    int _117;
    int _0, _1, _2;
    

    // 	if not sequence(x) then
    _117 = IS_SEQUENCE(_x);
    if (_117 != 0)
        goto L1;

    // 		return 0
    DeRef(_x);
    return 0;
L1:

    // 	flag = 0
    _flag = 0;

    // 	for j = 1 to length(x) do
    _117 = SEQ_PTR(_x)->length;
    { int _j;
        _j = 1;
L2:
        if (_j > _117)
            goto L3;

        // 		ob = x[j]
        DeRef(_ob);
        _2 = (int)SEQ_PTR(_x);
        _ob = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_ob);

        // 		if not integer(ob) then
        if (IS_ATOM_INT(_ob))
            _120 = 1;
        else if (IS_ATOM_DBL(_ob))
            _120 = IS_ATOM_INT(DoubleToInt(_ob));
        else
            _120 = 0;
        if (_120 != 0)
            goto L4;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L4:

        // 		i = ob
        Ref(_ob);
        _i = _ob;
        if (!IS_ATOM_INT(_i)) {
            _1 = (long)(DBL_PTR(_i)->dbl);
            DeRefDS(_i);
            _i = _1;
        }

        // 		if i < 0 then
        if (_i >= 0)
            goto L5;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L5:

        // 		if i > 255 then
        if (_i <= 255)
            goto L6;

        // 			return 0
        DeRef(_x);
        DeRef(_ob);
        return 0;
L6:

        // 		if flag = 0 then
        if (_flag != 0)
            goto L7;

        // 			flag = (i = 0)
        _flag = (_i == 0);
L7:

        // 	end for
        _j = _j + 1;
        goto L2;
L3:
        ;
    }

    // 	return 1 + flag
    _120 = _flag + 1;
    DeRef(_x);
    DeRef(_ob);
    return _120;
    ;
}


int __stdcall
_3myarray(int _x)
{
    int _flag;
    int _i = 0;
    int _ob = 0;
    int _132 = 0;
    int _129;
    int _0, _1, _2;
    

    // 	if not sequence(x) then
    _129 = IS_SEQUENCE(_x);
    if (_129 != 0)
        goto L1;

    // 		return 0
    DeRef(_x);
    return 0;
L1:

    // 	flag = 1
    _flag = 1;

    // 	for j = 1 to length(x) do
    _129 = SEQ_PTR(_x)->length;
    { int _j;
        _j = 1;
L2:
        if (_j > _129)
            goto L3;

        // 		ob = x[j]
        DeRef(_ob);
        _2 = (int)SEQ_PTR(_x);
        _ob = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_ob);

        // 		if not atom(ob) then
        DeRef(_132);
        _132 = IS_ATOM(_ob);
        if (_132 != 0)
            goto L4;

        // 			return 0
        DeRef(_x);
        DeRef(_i);
        DeRef(_ob);
        return 0;
L4:

        // 		if flag <= 2 then
        if (_flag > 2)
            goto L5;

        // 			i = ob
        Ref(_ob);
        DeRef(_i);
        _i = _ob;

        // 			if floor(i) != i then
        DeRef(_132);
        if (IS_ATOM_INT(_i))
            _132 = e_floor(_i);
        else
            _132 = unary_op(FLOOR, _i);
        if (binary_op_a(EQUALS, _132, _i))
            goto L6;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L6:

        // 			elsif i < (-2147483648) then
        if (binary_op_a(GREATEREQ, _i, _139))
            goto L8;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L8:

        // 			elsif i > 4294967295 then
        if (binary_op_a(LESSEQ, _i, _141))
            goto L9;

        // 				flag = 3 -- for double
        _flag = 3;
        goto L7;
L9:

        // 			elsif flag = 2 then
        if (_flag != 2)
            goto LA;

        // 				if i > 2147483647 then
        if (binary_op_a(LESSEQ, _i, _144))
            goto L7;

        // 					flag = 3 -- for double
        _flag = 3;
LB:
        goto L7;
LA:

        // 			elsif i < 0 then
        if (binary_op_a(GREATEREQ, _i, 0))
            goto LC;

        // 				flag = 2 -- for signed int
        _flag = 2;
LC:
L7:
L5:

        // 	end for
        _j = _j + 1;
        goto L2;
L3:
        ;
    }

    // 	return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list
    DeRef(_x);
    DeRef(_i);
    DeRef(_ob);
    DeRef(_132);
    return _flag;
    ;
}


int __stdcall
_3sequence_to_linked_list(int _s)
{
    int _ma = 0;
    int _next = 0;
    int _tmp = 0;
    int _a = 0;
    int _i;
    int _153 = 0;
    int _162 = 0;
    int _0, _1, _2;
    

    // 	ma = allocate(SIZE_OF_STRUCT)
    _ma = _2allocate(16);

    // 	if integer(s) then -- most of the time it will be an integer(a)
    if (IS_ATOM_INT(_s))
        _153 = 1;
    else if (IS_ATOM_DBL(_s))
        _153 = IS_ATOM_INT(DoubleToInt(_s));
    else
        _153 = 0;
    if (_153 == 0)
        goto L1;

    // 		i = s
    Ref(_s);
    _i = _s;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 		if i >= 0 then
    if (_i < 0)
        goto L2;

    // 			poke4(ma, UINT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3UINT_FLAG)->dbl;
    goto L3;
L2:

    // 			poke4(ma, INT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3INT_FLAG)->dbl;
L3:

    // 		poke4(ma + 4, i)
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    *poke4_addr = (unsigned long)_i;
    goto L4;
L1:

    // 	elsif atom(s) then
    DeRef(_153);
    _153 = IS_ATOM(_s);
    if (_153 == 0)
        goto L5;

    // 		a = s
    Ref(_s);
    DeRef(_a);
    _a = _s;

    // 		if a = floor(a) then
    if (IS_ATOM_INT(_a))
        _153 = e_floor(_a);
    else
        _153 = unary_op(FLOOR, _a);
    if (binary_op_a(NOTEQ, _a, _153))
        goto L6;

    // 			if a <= #FFFFFFFF and a >= 0 then
    DeRef(_153);
    if (IS_ATOM_INT(_a)) {
        _153 = ((double)_a <= DBL_PTR(_141)->dbl);
    }
    else {
        _153 = (DBL_PTR(_a)->dbl <= DBL_PTR(_141)->dbl);
    }
    if (_153 == 0) {
        goto L7;
    }
    DeRef(_162);
    if (IS_ATOM_INT(_a)) {
        _162 = (_a >= 0);
    }
    else {
        _162 = (DBL_PTR(_a)->dbl >= (double)0);
    }
L8:
    if (_162 == 0)
        goto L7;

    // 				poke4(ma, UINT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3UINT_FLAG)->dbl;

    // 				poke4(ma + 4, a)
    DeRef(_162);
    if (IS_ATOM_INT(_ma)) {
        _162 = _ma + 4;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
    goto L4;
L7:

    // 			elsif a <= 2147483647 and a >= -2147483648 then
    DeRef(_162);
    if (IS_ATOM_INT(_a)) {
        _162 = ((double)_a <= DBL_PTR(_144)->dbl);
    }
    else {
        _162 = (DBL_PTR(_a)->dbl <= DBL_PTR(_144)->dbl);
    }
    if (_162 == 0) {
        goto L9;
    }
    DeRef(_153);
    if (IS_ATOM_INT(_a)) {
        _153 = ((double)_a >= DBL_PTR(_139)->dbl);
    }
    else {
        _153 = (DBL_PTR(_a)->dbl >= DBL_PTR(_139)->dbl);
    }
LA:
    if (_153 == 0)
        goto L9;

    // 				poke4(ma, INT_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3INT_FLAG)->dbl;

    // 				poke4(ma + 4, a)
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
    goto L4;
L9:

    // 				tmp = allocate(8)
    _0 = _tmp;
    _tmp = _2allocate(8);
    DeRef(_0);

    // 				poke(tmp, atom_to_float64(a))
    Ref(_a);
    _0 = _153;
    _153 = _2atom_to_float64(_a);
    DeRef(_0);
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    _1 = (int)SEQ_PTR(_153);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    // 				poke4(ma, DOUBLE_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3DOUBLE_FLAG)->dbl;

    // 				poke4(ma + 4, tmp)
    DeRefDSi(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
LB:
    goto L4;
L6:

    // 			tmp = allocate(8)
    _0 = _tmp;
    _tmp = _2allocate(8);
    DeRef(_0);

    // 			poke(tmp, atom_to_float64(a))
    Ref(_a);
    _0 = _153;
    _153 = _2atom_to_float64(_a);
    DeRef(_0);
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    _1 = (int)SEQ_PTR(_153);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    // 			poke4(ma, DOUBLE_FLAG)
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3DOUBLE_FLAG)->dbl;

    // 			poke4(ma + 4, tmp)
    DeRefDSi(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
LC:
    goto L4;
L5:

    // 	elsif length(s) = 0 then
    DeRef(_153);
    _153 = SEQ_PTR(_s)->length;
    if (_153 != 0)
        goto LD;

    // 		poke4(ma, {NULL,NULL})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _153 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    _1 = (int)SEQ_PTR(_153);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    goto L4;
LD:

    // 		if not always_linked_list then
    if (_3always_linked_list != 0)
        goto LE;

    // 			i = mystring(s)
    Ref(_s);
    _i = _3mystring(_s);

    // 			if i then -- string
    if (_i == 0)
        goto LF;

    // 				if i = 2 then
    if (_i != 2)
        goto L10;

    // 					tmp = allocate(length(s))
    DeRef(_153);
    _153 = SEQ_PTR(_s)->length;
    _0 = _tmp;
    _tmp = _2allocate(_153);
    DeRef(_0);

    // 					poke(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke_addr = (unsigned char *)_tmp;
    else
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke_addr = (unsigned char)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke_addr = (signed char)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH
    _153 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_153;
    _153 = Dor_bits(DBL_PTR(_3CBYTES), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_153)) {
        *poke4_addr = (unsigned long)_153;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_153)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L11;
L10:

    // 					tmp = allocate_string(s)
    Ref(_s);
    _0 = _tmp;
    _tmp = _2allocate_string(_s);
    DeRef(_0);

    // 					poke4(ma, CSTRING) -- why?
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)DBL_PTR(_3CSTRING)->dbl;

    // 					poke4(ma + 4, tmp)
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
L11:

    // 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 8;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_162);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _162 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    _1 = (int)SEQ_PTR(_162);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 				return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_162);
    DeRef(_153);
    return _ma;
LF:

    // 			i = myarray(s)
    Ref(_s);
    _i = _3myarray(_s);

    // 			if i then
    if (_i == 0)
        goto L12;

    // 				if i = 1 then
    if (_i != 1)
        goto L13;

    // 					tmp = allocate(length(s) * 4)
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    if (_162 == (short)_162)
        _162 = _162 * 4;
    else
        _162 = NewDouble(_162 * (double)4);
    Ref(_162);
    _0 = _tmp;
    _tmp = _2allocate(_162);
    DeRef(_0);

    // 					poke4(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke4_addr = (unsigned long *)_tmp;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke4_addr = (unsigned long)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(UINT_FLAG, length(s)))
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_162;
    _162 = Dor_bits(DBL_PTR(_3UINT_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_162)) {
        *poke4_addr = (unsigned long)_162;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_162)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_162);
    if (IS_ATOM_INT(_ma)) {
        _162 = _ma + 4;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L14;
L13:

    // 				elsif i = 2 then
    if (_i != 2)
        goto L15;

    // 					tmp = allocate(length(s) * 4)
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    if (_162 == (short)_162)
        _162 = _162 * 4;
    else
        _162 = NewDouble(_162 * (double)4);
    Ref(_162);
    _0 = _tmp;
    _tmp = _2allocate(_162);
    DeRef(_0);

    // 					poke4(tmp, s)
    if (IS_ATOM_INT(_tmp))
        poke4_addr = (unsigned long *)_tmp;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
    if (IS_ATOM_INT(_s)) {
        *poke4_addr = (unsigned long)_s;
    }
    else if (IS_ATOM(_s)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    // 					poke4(ma, or_bits(INT_FLAG, length(s)))
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_162;
    _162 = Dor_bits(DBL_PTR(_3INT_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_162)) {
        *poke4_addr = (unsigned long)_162;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_162)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_162);
    if (IS_ATOM_INT(_ma)) {
        _162 = _ma + 4;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
    goto L14;
L15:

    // 				elsif i = 3 then
    if (_i != 3)
        goto L16;

    // 					tmp = allocate(length(s) * 8)
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    if (_162 == (short)_162)
        _162 = _162 * 8;
    else
        _162 = NewDouble(_162 * (double)8);
    Ref(_162);
    _0 = _tmp;
    _tmp = _2allocate(_162);
    DeRef(_0);

    // 					for j = 1 to length(s) do
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    { int _j;
        _j = 1;
L17:
        if (_j > _162)
            goto L18;

        // 						poke(tmp, atom_to_float64(s[j]))
        DeRef(_153);
        _2 = (int)SEQ_PTR(_s);
        _153 = (int)*(((s1_ptr)_2)->base + _j);
        Ref(_153);
        Ref(_153);
        _0 = _153;
        _153 = _2atom_to_float64(_153);
        DeRef(_0);
        if (IS_ATOM_INT(_tmp))
            poke_addr = (unsigned char *)_tmp;
        else
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp)->dbl);
        _1 = (int)SEQ_PTR(_153);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
                break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }

        // 						tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 					end for
        _j = _j + 1;
        goto L17;
L18:
        ;
    }

    // 					poke4(ma, or_bits(DOUBLE_FLAG, length(s)))
    DeRef(_153);
    _153 = SEQ_PTR(_s)->length;
    temp_d.dbl = (double)_153;
    _153 = Dor_bits(DBL_PTR(_3DOUBLE_FLAG), &temp_d);
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    if (IS_ATOM_INT(_153)) {
        *poke4_addr = (unsigned long)_153;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_153)->dbl;
    }

    // 					poke4(ma + 4, tmp)
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 4;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }
L16:
L14:

    // 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_153);
    if (IS_ATOM_INT(_ma)) {
        _153 = _ma + 8;
        if ((long)((unsigned long)_153 + (unsigned long)HIGH_BITS) >= 0) 
            _153 = NewDouble((double)_153);
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_162);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _162 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_153))
        poke4_addr = (unsigned long *)_153;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_153)->dbl);
    _1 = (int)SEQ_PTR(_162);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 				return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_162);
    DeRef(_153);
    return _ma;
L12:
LE:

    // 		next = NULL -- 0
    DeRef(_next);
    _next = 0;

    // 		poke4(ma, length(s))
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    if (IS_ATOM_INT(_ma))
        poke4_addr = (unsigned long *)_ma;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
    *poke4_addr = (unsigned long)_162;

    // 		if length(s) then
    _162 = SEQ_PTR(_s)->length;
    if (_162 == 0)
        goto L19;

    // 			a = allocate(8) -- iterators to beginning and end of list
    _0 = _a;
    _a = _2allocate(8);
    DeRef(_0);

    // 			next = sequence_to_linked_list(s[$])
    _162 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _162 = (int)*(((s1_ptr)_2)->base + _162);
    Ref(_162);
    Ref(_162);
    _next = _3sequence_to_linked_list(_162);

    // 			s = s[1..$-1]
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    _162 = _162 - 1;
    rhs_slice_target = (object_ptr)&_s;
    RHS_Slice((s1_ptr)_s, 1, _162);

    // 			poke4(a + 4, next) -- store the end iterator
    if (IS_ATOM_INT(_a)) {
        _162 = _a + 4;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_a)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 			while length(s) do
L1A:
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    if (_162 == 0)
        goto L1B;

    // 				tmp = sequence_to_linked_list(s[$])
    _162 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _162 = (int)*(((s1_ptr)_2)->base + _162);
    Ref(_162);
    Ref(_162);
    _0 = _tmp;
    _tmp = _3sequence_to_linked_list(_162);
    DeRef(_0);

    // 				s = s[1..$-1]
    DeRef(_162);
    _162 = SEQ_PTR(_s)->length;
    _162 = _162 - 1;
    rhs_slice_target = (object_ptr)&_s;
    RHS_Slice((s1_ptr)_s, 1, _162);

    // 				poke4(next + 8, tmp)
    if (IS_ATOM_INT(_next)) {
        _162 = _next + 8;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_next)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_tmp)) {
        *poke4_addr = (unsigned long)_tmp;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp)->dbl;
    }

    // 				poke4(tmp + 12, next)
    DeRef(_162);
    if (IS_ATOM_INT(_tmp)) {
        _162 = _tmp + 12;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 				next = tmp
    Ref(_tmp);
    DeRef(_next);
    _next = _tmp;

    // 			end while
    goto L1A;
L1B:
L19:

    // 		poke4(a, next) -- store the beginning iterator
    if (IS_ATOM_INT(_a))
        poke4_addr = (unsigned long *)_a;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_a)->dbl);
    if (IS_ATOM_INT(_next)) {
        *poke4_addr = (unsigned long)_next;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next)->dbl;
    }

    // 		poke4(ma + 4, a) -- point data to the iterators
    DeRef(_162);
    if (IS_ATOM_INT(_ma)) {
        _162 = _ma + 4;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    if (IS_ATOM_INT(_a)) {
        *poke4_addr = (unsigned long)_a;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a)->dbl;
    }
L4:

    // 	poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.
    DeRef(_162);
    if (IS_ATOM_INT(_ma)) {
        _162 = _ma + 8;
        if ((long)((unsigned long)_162 + (unsigned long)HIGH_BITS) >= 0) 
            _162 = NewDouble((double)_162);
    }
    else {
        _162 = NewDouble(DBL_PTR(_ma)->dbl + (double)8);
    }
    DeRef(_153);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _153 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_162))
        poke4_addr = (unsigned long *)_162;
    else
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_162)->dbl);
    _1 = (int)SEQ_PTR(_153);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
            break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }

    // 	return ma
    DeRef(_s);
    DeRef(_next);
    DeRef(_tmp);
    DeRef(_a);
    DeRefDSi(_153);
    DeRef(_162);
    return _ma;
    ;
}


int __stdcall
_3free_linked_list(int _ma)
{
    int _len = 0;
    int _tmp = 0;
    int _next = 0;
    int _ptr = 0;
    int _249 = 0;
    int _240 = 0;
    int _0, _1, _2;
    

    // 	len = peek4u(ma)
    if (IS_ATOM_INT(_ma)) {
        _len = *(unsigned long *)_ma;
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }
    else {
        _len = *(unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }

    // 	ptr = peek4u(ma + 4)
    if (IS_ATOM_INT(_ma)) {
        _240 = _ma + 4;
        if ((long)((unsigned long)_240 + (unsigned long)HIGH_BITS) >= 0) 
            _240 = NewDouble((double)_240);
    }
    else {
        _240 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_240)) {
        _ptr = *(unsigned long *)_240;
        if ((unsigned)_ptr > (unsigned)MAXINT)
            _ptr = NewDouble((double)(unsigned long)_ptr);
    }
    else {
        _ptr = *(unsigned long *)(unsigned long)(DBL_PTR(_240)->dbl);
        if ((unsigned)_ptr > (unsigned)MAXINT)
            _ptr = NewDouble((double)(unsigned long)_ptr);
    }

    // 	if and_bits(len, SIGN_FLAG) then
    DeRef(_240);
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _240 = Dand_bits(&temp_d, DBL_PTR(_3SIGN_FLAG));
    }
    else {
        _240 = Dand_bits(DBL_PTR(_len), DBL_PTR(_3SIGN_FLAG));
    }
    if (_240 == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_240) && DBL_PTR(_240)->dbl == 0.0)
            goto L1;
    }

    // 	 	if and_bits(len, MAX_LENGTH) then
    DeRef(_240);
    if (IS_ATOM_INT(_len)) {
        _240 = (_len & 268435455);
    }
    else {
        temp_d.dbl = (double)268435455;
        _240 = Dand_bits(DBL_PTR(_len), &temp_d);
    }
    if (_240 == 0) {
        goto L2;
    }
    else {
        if (!IS_ATOM_INT(_240) && DBL_PTR(_240)->dbl == 0.0)
            goto L2;
    }

    // 			free(ptr)
    Ref(_ptr);
    _2free(_ptr);
    goto L3;
L2:

    // 		elsif len = DOUBLE_FLAG then
    if (binary_op_a(NOTEQ, _len, _3DOUBLE_FLAG))
        goto L3;

    // 			free(ptr)
    Ref(_ptr);
    _2free(_ptr);
L4:
L5:
    goto L3;
L1:

    // 	elsif len > 0 then
    if (binary_op_a(LESSEQ, _len, 0))
        goto L6;

    // 		tmp = peek4u(ptr) -- iterator to the beginning of the list
    DeRef(_tmp);
    if (IS_ATOM_INT(_ptr)) {
        _tmp = *(unsigned long *)_ptr;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_ptr)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		free(ptr) -- free the iterators
    Ref(_ptr);
    _2free(_ptr);

    // 		for i = 1 to len do
    Ref(_len);
    DeRef(_240);
    _240 = _len;
    { int _i;
        _i = 1;
L7:
        if (binary_op_a(GREATER, _i, _240))
            goto L8;

        // 			next = peek4u(tmp + 12)
        DeRef(_249);
        if (IS_ATOM_INT(_tmp)) {
            _249 = _tmp + 12;
            if ((long)((unsigned long)_249 + (unsigned long)HIGH_BITS) >= 0) 
                _249 = NewDouble((double)_249);
        }
        else {
            _249 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
        }
        DeRef(_next);
        if (IS_ATOM_INT(_249)) {
            _next = *(unsigned long *)_249;
            if ((unsigned)_next > (unsigned)MAXINT)
                _next = NewDouble((double)(unsigned long)_next);
        }
        else {
            _next = *(unsigned long *)(unsigned long)(DBL_PTR(_249)->dbl);
            if ((unsigned)_next > (unsigned)MAXINT)
                _next = NewDouble((double)(unsigned long)_next);
        }

        // 			free_linked_list(tmp)
        Ref(_tmp);
        DeRef(_249);
        _249 = _tmp;
        Ref(_249);
        _3free_linked_list(_249);

        // 			tmp = next
        Ref(_next);
        DeRef(_tmp);
        _tmp = _next;

        // 		end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L7;
L8:
        ;
        DeRef(_i);
    }
L6:
L3:

    // 	free(ma)
    Ref(_ma);
    _2free(_ma);

    // end procedure
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_next);
    DeRef(_ptr);
    DeRef(_249);
    DeRef(_240);
    return 0;
    ;
}


int __stdcall
_3linked_list_to_sequence(int _ma)
{
    int _len = 0;
    int _tmp = 0;
    int _val = 0;
    int _s = 0;
    int _277 = 0;
    int _252 = 0;
    int _0, _1, _2;
    

    // 	len = peek4u(ma)
    if (IS_ATOM_INT(_ma)) {
        _len = *(unsigned long *)_ma;
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }
    else {
        _len = *(unsigned long *)(unsigned long)(DBL_PTR(_ma)->dbl);
        if ((unsigned)_len > (unsigned)MAXINT)
            _len = NewDouble((double)(unsigned long)_len);
    }

    // 	if and_bits(len, SIGN_FLAG) then
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _252 = Dand_bits(&temp_d, DBL_PTR(_3SIGN_FLAG));
    }
    else {
        _252 = Dand_bits(DBL_PTR(_len), DBL_PTR(_3SIGN_FLAG));
    }
    if (_252 == 0) {
        goto L1;
    }
    else {
        if (!IS_ATOM_INT(_252) && DBL_PTR(_252)->dbl == 0.0)
            goto L1;
    }

    // 		if len = CSTRING then
    if (binary_op_a(NOTEQ, _len, _3CSTRING))
        goto L2;

    // 			tmp = peek4u(ma + 4)
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_252)) {
        _tmp = *(unsigned long *)_252;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_252)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 			s = peek_string(tmp)
    Ref(_tmp);
    _s = _3peek_string(_tmp);

    // 			return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_252);
    return _s;
L2:

    // 		val = and_bits(len, SIGN_MASK)
    DeRef(_val);
    if (IS_ATOM_INT(_len)) {
        temp_d.dbl = (double)_len;
        _val = Dand_bits(&temp_d, DBL_PTR(_3SIGN_MASK));
    }
    else {
        _val = Dand_bits(DBL_PTR(_len), DBL_PTR(_3SIGN_MASK));
    }

    // 		len = and_bits(len, MAX_LENGTH)
    _0 = _len;
    if (IS_ATOM_INT(_len)) {
        _len = (_len & 268435455);
    }
    else {
        temp_d.dbl = (double)268435455;
        _len = Dand_bits(DBL_PTR(_len), &temp_d);
    }
    DeRef(_0);

    // 		if val = UINT_FLAG then
    if (binary_op_a(NOTEQ, _val, _3UINT_FLAG))
        goto L3;

    // 			if len then
    if (_len == 0) {
        goto L4;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto L4;
    }

    // 				s = peek4u({ma + 4, len})
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _252;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _252;
    Ref(_252);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _252 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_252);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_252);
    DeRef(_277);
    return _s;
    goto L5;
L4:

    // 				tmp = peek4u(ma + 4)
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_252)) {
        _tmp = *(unsigned long *)_252;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_252)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRef(_277);
    DeRef(_252);
    return _tmp;
L5:
L3:

    // 		if val = INT_FLAG then
    if (binary_op_a(NOTEQ, _val, _3INT_FLAG))
        goto L6;

    // 			if len then
    if (_len == 0) {
        goto L7;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto L7;
    }

    // 				s = peek4s({ma + 4, len})
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _252;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _252;
    Ref(_252);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _252 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_252);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_252);
    DeRef(_277);
    return _s;
    goto L8;
L7:

    // 				tmp = peek4s(ma + 4)
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_252)) {
        _tmp = *(unsigned long *)_252;
        if (_tmp < MININT || _tmp > MAXINT)
            _tmp = NewDouble((double)(long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_252)->dbl);
        if (_tmp < MININT || _tmp > MAXINT)
            _tmp = NewDouble((double)(long)_tmp);
    }

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRef(_277);
    DeRef(_252);
    return _tmp;
L8:
L6:

    // 		if val = FLOAT_FLAG then
    if (binary_op_a(NOTEQ, _val, _3FLOAT_FLAG))
        goto L9;

    // 			if len then
    if (_len == 0) {
        goto LA;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto LA;
    }

    // 				tmp = peek4u(ma + 4)
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_252)) {
        _tmp = *(unsigned long *)_252;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_252)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 				s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 				for i = 1 to len do
    Ref(_len);
    DeRef(_252);
    _252 = _len;
    { int _i;
        _i = 1;
LB:
        if (binary_op_a(GREATER, _i, _252))
            goto LC;

        // 					s[i] = float32_to_atom(peek({tmp, 4}))
        DeRef(_277);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp;
        Ref(_tmp);
        ((int *)_2)[2] = 4;
        _277 = MAKE_SEQ(_1);
        _0 = _277;
        _1 = (int)SEQ_PTR(_277);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _277 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
        DeRefDS(_0);
        RefDS(_277);
        _0 = _277;
        _277 = _2float32_to_atom(_277);
        DeRefDSi(_0);
        Ref(_277);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i)->dbl));
        else
            _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _277;
        DeRef(_1);

        // 					tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 				end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto LB;
LC:
        ;
        DeRef(_i);
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_277);
    DeRef(_252);
    return _s;
    goto LD;
LA:

    // 				tmp = float32_to_atom(peek({ma + 4, 4}))
    DeRef(_277);
    if (IS_ATOM_INT(_ma)) {
        _277 = _ma + 4;
        if ((long)((unsigned long)_277 + (unsigned long)HIGH_BITS) >= 0) 
            _277 = NewDouble((double)_277);
    }
    else {
        _277 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    _0 = _277;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _277;
    Ref(_277);
    ((int *)_2)[2] = 4;
    _277 = MAKE_SEQ(_1);
    DeRef(_0);
    _0 = _277;
    _1 = (int)SEQ_PTR(_277);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _277 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }
    DeRefDS(_0);
    RefDS(_277);
    _0 = _tmp;
    _tmp = _2float32_to_atom(_277);
    DeRef(_0);

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRefDSi(_277);
    DeRef(_252);
    return _tmp;
LD:
L9:

    // 		tmp = peek4u(ma + 4)
    DeRef(_277);
    if (IS_ATOM_INT(_ma)) {
        _277 = _ma + 4;
        if ((long)((unsigned long)_277 + (unsigned long)HIGH_BITS) >= 0) 
            _277 = NewDouble((double)_277);
    }
    else {
        _277 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_277)) {
        _tmp = *(unsigned long *)_277;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_277)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		if val = DOUBLE_FLAG then
    if (binary_op_a(NOTEQ, _val, _3DOUBLE_FLAG))
        goto LE;

    // 			if len then
    if (_len == 0) {
        goto LF;
    }
    else {
        if (!IS_ATOM_INT(_len) && DBL_PTR(_len)->dbl == 0.0)
            goto LF;
    }

    // 				s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 				for i = 1 to len do
    Ref(_len);
    DeRef(_277);
    _277 = _len;
    { int _i;
        _i = 1;
L10:
        if (binary_op_a(GREATER, _i, _277))
            goto L11;

        // 					s[i] = float64_to_atom(peek({tmp, 8}))
        DeRef(_252);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp;
        Ref(_tmp);
        ((int *)_2)[2] = 8;
        _252 = MAKE_SEQ(_1);
        _0 = _252;
        _1 = (int)SEQ_PTR(_252);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _252 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
        DeRefDS(_0);
        RefDS(_252);
        _0 = _252;
        _252 = _2float64_to_atom(_252);
        DeRefDSi(_0);
        Ref(_252);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i)->dbl));
        else
            _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _252;
        DeRef(_1);

        // 					tmp += 8
        _0 = _tmp;
        if (IS_ATOM_INT(_tmp)) {
            _tmp = _tmp + 8;
            if ((long)((unsigned long)_tmp + (unsigned long)HIGH_BITS) >= 0) 
                _tmp = NewDouble((double)_tmp);
        }
        else {
            _tmp = NewDouble(DBL_PTR(_tmp)->dbl + (double)8);
        }
        DeRef(_0);

        // 				end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L10;
L11:
        ;
        DeRef(_i);
    }

    // 				return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_277);
    DeRef(_252);
    return _s;
    goto L12;
LF:

    // 				tmp = float64_to_atom(peek({tmp, 8}))
    DeRef(_252);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp;
    Ref(_tmp);
    ((int *)_2)[2] = 8;
    _252 = MAKE_SEQ(_1);
    _0 = _252;
    _1 = (int)SEQ_PTR(_252);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _252 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }
    DeRefDS(_0);
    RefDS(_252);
    _0 = _tmp;
    _tmp = _2float64_to_atom(_252);
    DeRef(_0);

    // 				return tmp
    DeRef(_ma);
    DeRef(_len);
    DeRef(_val);
    DeRef(_s);
    DeRefDSi(_252);
    DeRef(_277);
    return _tmp;
L12:
LE:

    // 		s = peek({tmp, len})
    DeRef(_252);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp;
    Ref(_tmp);
    ((int *)_2)[2] = _len;
    Ref(_len);
    _252 = MAKE_SEQ(_1);
    DeRef(_s);
    _1 = (int)SEQ_PTR(_252);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        *(int *)poke4_addr = *poke_addr++;
    }

    // 		return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRefDS(_252);
    DeRef(_277);
    return _s;
    goto L13;
L1:

    // 	elsif len > 0 then
    if (binary_op_a(LESSEQ, _len, 0))
        goto L14;

    // 		tmp = peek4u(ma + 4)
    DeRef(_252);
    if (IS_ATOM_INT(_ma)) {
        _252 = _ma + 4;
        if ((long)((unsigned long)_252 + (unsigned long)HIGH_BITS) >= 0) 
            _252 = NewDouble((double)_252);
    }
    else {
        _252 = NewDouble(DBL_PTR(_ma)->dbl + (double)4);
    }
    DeRef(_tmp);
    if (IS_ATOM_INT(_252)) {
        _tmp = *(unsigned long *)_252;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_252)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }

    // 		tmp = peek4u(tmp)
    _0 = _tmp;
    if (IS_ATOM_INT(_tmp)) {
        _tmp = *(unsigned long *)_tmp;
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    else {
        _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_tmp)->dbl);
        if ((unsigned)_tmp > (unsigned)MAXINT)
            _tmp = NewDouble((double)(unsigned long)_tmp);
    }
    DeRef(_0);

    // 		s = repeat(0, len)
    DeRef(_s);
    _s = Repeat(0, _len);

    // 		s[1] = linked_list_to_sequence(tmp)
    Ref(_tmp);
    DeRef(_252);
    _252 = _tmp;
    Ref(_252);
    _0 = _252;
    _252 = _3linked_list_to_sequence(_252);
    DeRef(_0);
    Ref(_252);
    _2 = (int)SEQ_PTR(_s);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _252;

    // 		for i = 2 to length(s) do
    DeRef(_252);
    _252 = SEQ_PTR(_s)->length;
    { int _i;
        _i = 2;
L15:
        if (_i > _252)
            goto L16;

        // 			tmp = peek4u(tmp + 12)
        DeRef(_277);
        if (IS_ATOM_INT(_tmp)) {
            _277 = _tmp + 12;
            if ((long)((unsigned long)_277 + (unsigned long)HIGH_BITS) >= 0) 
                _277 = NewDouble((double)_277);
        }
        else {
            _277 = NewDouble(DBL_PTR(_tmp)->dbl + (double)12);
        }
        DeRef(_tmp);
        if (IS_ATOM_INT(_277)) {
            _tmp = *(unsigned long *)_277;
            if ((unsigned)_tmp > (unsigned)MAXINT)
                _tmp = NewDouble((double)(unsigned long)_tmp);
        }
        else {
            _tmp = *(unsigned long *)(unsigned long)(DBL_PTR(_277)->dbl);
            if ((unsigned)_tmp > (unsigned)MAXINT)
                _tmp = NewDouble((double)(unsigned long)_tmp);
        }

        // 			s[i] = linked_list_to_sequence(tmp)
        Ref(_tmp);
        DeRef(_277);
        _277 = _tmp;
        Ref(_277);
        _0 = _277;
        _277 = _3linked_list_to_sequence(_277);
        DeRef(_0);
        Ref(_277);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        _1 = *(int *)_2;
        *(int *)_2 = _277;
        DeRef(_1);

        // 		end for
        _i = _i + 1;
        goto L15;
L16:
        ;
    }

    // 		return s
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_277);
    DeRef(_252);
    return _s;
    goto L13;
L14:

    // 		return {}
    RefDS(_112);
    DeRef(_ma);
    DeRef(_len);
    DeRef(_tmp);
    DeRef(_val);
    DeRef(_s);
    DeRef(_277);
    DeRef(_252);
    return _112;
L13:
    ;
}


